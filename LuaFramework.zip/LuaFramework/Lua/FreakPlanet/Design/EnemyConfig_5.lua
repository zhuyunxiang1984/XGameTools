
EnemyConfig[EnemyID.Id6001] =
{
	Id = 6001,
	Name = "丛林史莱姆",
	Rarity = 1,
	Element = 210003,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：偷到丛林冒险者掉在地上的物品不还。",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	IconName = "Arena_RPG_Slime_Green",
	PrefabBundle = "character_arenaenemy",
	PrefabName = "Arena_RPG_Slime_green",
	PrefabScale = 50,
	HPBarHeight = 69,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 2215, Gain = 443},
		{Value = 200002, Base = 34, Gain = 7},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "受风元素敌人伤害 -50%",
		Skill = {
			{
				Id = 105035,
				Value = -50,
			},
		},
	},
	Tags = {
		560111,
		564556,
	},
}
EnemyConfig[EnemyID.Id6002] =
{
	Id = 6002,
	Name = "丛林史莱姆",
	Rarity = 1,
	Element = 210003,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：偷到丛林冒险者掉在地上的物品不还。",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	IconName = "Arena_RPG_Slime_Green",
	PrefabBundle = "character_arenaenemy",
	PrefabName = "Arena_RPG_Slime_green",
	PrefabScale = 50,
	HPBarHeight = 69,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 2430, Gain = 486},
		{Value = 200002, Base = 37, Gain = 8},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "受风元素敌人伤害 -50%",
		Skill = {
			{
				Id = 105035,
				Value = -50,
			},
		},
	},
	Tags = {
		560111,
		564556,
	},
}
EnemyConfig[EnemyID.Id6003] =
{
	Id = 6003,
	Name = "丛林史莱姆",
	Rarity = 1,
	Element = 210003,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：偷到丛林冒险者掉在地上的物品不还。",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	IconName = "Arena_RPG_Slime_Green",
	PrefabBundle = "character_arenaenemy",
	PrefabName = "Arena_RPG_Slime_green",
	PrefabScale = 50,
	HPBarHeight = 69,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 3160, Gain = 632},
		{Value = 200002, Base = 41, Gain = 9},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "受风元素敌人伤害 -50%",
		Skill = {
			{
				Id = 105035,
				Value = -50,
			},
		},
	},
	Tags = {
		560111,
		564556,
	},
}
EnemyConfig[EnemyID.Id6004] =
{
	Id = 6004,
	Name = "地下史莱姆",
	Rarity = 1,
	Element = 210001,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：偷到地城冒险者掉在地上的物品不还。",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	IconName = "Arena_RPG_Slime_Blue",
	PrefabBundle = "character_arenaenemy",
	PrefabName = "Arena_RPG_Slime_blue",
	PrefabScale = 50,
	HPBarHeight = 69,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 2215, Gain = 443},
		{Value = 200002, Base = 34, Gain = 7},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "受水元素敌人伤害 -50%",
		Skill = {
			{
				Id = 105033,
				Value = -50,
			},
		},
	},
	Tags = {
		560111,
		564556,
	},
}
EnemyConfig[EnemyID.Id6005] =
{
	Id = 6005,
	Name = "地下史莱姆",
	Rarity = 1,
	Element = 210001,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：偷到地城冒险者掉在地上的物品不还。",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	IconName = "Arena_RPG_Slime_Blue",
	PrefabBundle = "character_arenaenemy",
	PrefabName = "Arena_RPG_Slime_blue",
	PrefabScale = 50,
	HPBarHeight = 69,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 2430, Gain = 486},
		{Value = 200002, Base = 37, Gain = 8},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "受水元素敌人伤害 -50%",
		Skill = {
			{
				Id = 105033,
				Value = -50,
			},
		},
	},
	Tags = {
		560111,
		564556,
	},
}
EnemyConfig[EnemyID.Id6006] =
{
	Id = 6006,
	Name = "地下史莱姆",
	Rarity = 1,
	Element = 210001,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：偷到地城冒险者掉在地上的物品不还。",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	IconName = "Arena_RPG_Slime_Blue",
	PrefabBundle = "character_arenaenemy",
	PrefabName = "Arena_RPG_Slime_blue",
	PrefabScale = 50,
	HPBarHeight = 69,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 3160, Gain = 632},
		{Value = 200002, Base = 41, Gain = 9},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "受水元素敌人伤害 -50%",
		Skill = {
			{
				Id = 105033,
				Value = -50,
			},
		},
	},
	Tags = {
		560111,
		564556,
	},
}
EnemyConfig[EnemyID.Id6007] =
{
	Id = 6007,
	Name = "沼泽史莱姆",
	Rarity = 1,
	Element = 210005,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：偷到沼泽冒险者掉在地上的物品不还。",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	IconName = "Arena_RPG_Slime_Purple",
	PrefabBundle = "character_arenaenemy",
	PrefabName = "Arena_RPG_Slime_purple",
	PrefabScale = 50,
	HPBarHeight = 69,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 2215, Gain = 443},
		{Value = 200002, Base = 34, Gain = 7},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "受暗元素敌人伤害 -50%",
		Skill = {
			{
				Id = 105037,
				Value = -50,
			},
		},
	},
	Tags = {
		560111,
		564556,
	},
}
EnemyConfig[EnemyID.Id6008] =
{
	Id = 6008,
	Name = "沼泽史莱姆",
	Rarity = 1,
	Element = 210005,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：偷到沼泽冒险者掉在地上的物品不还。",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	IconName = "Arena_RPG_Slime_Purple",
	PrefabBundle = "character_arenaenemy",
	PrefabName = "Arena_RPG_Slime_purple",
	PrefabScale = 50,
	HPBarHeight = 69,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 2430, Gain = 486},
		{Value = 200002, Base = 37, Gain = 8},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "受暗元素敌人伤害 -50%",
		Skill = {
			{
				Id = 105037,
				Value = -50,
			},
		},
	},
	Tags = {
		560111,
		564556,
	},
}
EnemyConfig[EnemyID.Id6009] =
{
	Id = 6009,
	Name = "沼泽史莱姆",
	Rarity = 1,
	Element = 210005,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：偷到沼泽冒险者掉在地上的物品不还。",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	IconName = "Arena_RPG_Slime_Purple",
	PrefabBundle = "character_arenaenemy",
	PrefabName = "Arena_RPG_Slime_purple",
	PrefabScale = 50,
	HPBarHeight = 69,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 3160, Gain = 632},
		{Value = 200002, Base = 41, Gain = 9},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "受暗元素敌人伤害 -50%",
		Skill = {
			{
				Id = 105037,
				Value = -50,
			},
		},
	},
	Tags = {
		560111,
		564556,
	},
}
EnemyConfig[EnemyID.Id6010] =
{
	Id = 6010,
	Name = "火山史莱姆",
	Rarity = 1,
	Element = 210002,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：偷到火山冒险者掉在地上的物品不还。",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	IconName = "Arena_RPG_Slime_Red",
	PrefabBundle = "character_arenaenemy",
	PrefabName = "Arena_RPG_Slime_red",
	PrefabScale = 50,
	HPBarHeight = 69,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 2215, Gain = 443},
		{Value = 200002, Base = 34, Gain = 7},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "受火元素敌人伤害 -50%",
		Skill = {
			{
				Id = 105034,
				Value = -50,
			},
		},
	},
	Tags = {
		560111,
		564556,
	},
}
EnemyConfig[EnemyID.Id6011] =
{
	Id = 6011,
	Name = "火山史莱姆",
	Rarity = 1,
	Element = 210002,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：偷到火山冒险者掉在地上的物品不还。",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	IconName = "Arena_RPG_Slime_Red",
	PrefabBundle = "character_arenaenemy",
	PrefabName = "Arena_RPG_Slime_red",
	PrefabScale = 50,
	HPBarHeight = 69,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 2430, Gain = 486},
		{Value = 200002, Base = 37, Gain = 8},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "受火元素敌人伤害 -50%",
		Skill = {
			{
				Id = 105034,
				Value = -50,
			},
		},
	},
	Tags = {
		560111,
		564556,
	},
}
EnemyConfig[EnemyID.Id6012] =
{
	Id = 6012,
	Name = "火山史莱姆",
	Rarity = 1,
	Element = 210002,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：偷到火山冒险者掉在地上的物品不还。",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	IconName = "Arena_RPG_Slime_Red",
	PrefabBundle = "character_arenaenemy",
	PrefabName = "Arena_RPG_Slime_red",
	PrefabScale = 50,
	HPBarHeight = 69,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 3160, Gain = 632},
		{Value = 200002, Base = 41, Gain = 9},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "受火元素敌人伤害 -50%",
		Skill = {
			{
				Id = 105034,
				Value = -50,
			},
		},
	},
	Tags = {
		560111,
		564556,
	},
}
EnemyConfig[EnemyID.Id6013] =
{
	Id = 6013,
	Name = "偷窥花丛",
	Rarity = 2,
	Element = 210003,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：在路边假装花丛偷看路人裙底。",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	IconName = "Arena_RPG_huacong",
	PrefabBundle = "character_arenaenemy",
	PrefabName = "Arena_RPG_huacong",
	PrefabScale = 50,
	HPBarHeight = 76,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 2124, Gain = 425},
		{Value = 200002, Base = 33, Gain = 7},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "有50%概率额外攻击1次",
		Skill = {
			{
				Id = 105023,
				Value = 50,
			},
		},
	},
	Tags = {
		560111,
		564556,
		564558,
	},
}
EnemyConfig[EnemyID.Id6014] =
{
	Id = 6014,
	Name = "偷窥花丛",
	Rarity = 2,
	Element = 210003,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：在路边假装花丛偷看路人裙底。",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	IconName = "Arena_RPG_huacong",
	PrefabBundle = "character_arenaenemy",
	PrefabName = "Arena_RPG_huacong",
	PrefabScale = 50,
	HPBarHeight = 76,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 2314, Gain = 463},
		{Value = 200002, Base = 36, Gain = 8},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "有50%概率额外攻击1次",
		Skill = {
			{
				Id = 105023,
				Value = 50,
			},
		},
	},
	Tags = {
		560111,
		564556,
		564558,
	},
}
EnemyConfig[EnemyID.Id6015] =
{
	Id = 6015,
	Name = "偷窥花丛",
	Rarity = 2,
	Element = 210003,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：在路边假装花丛偷看路人裙底。",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	IconName = "Arena_RPG_huacong",
	PrefabBundle = "character_arenaenemy",
	PrefabName = "Arena_RPG_huacong",
	PrefabScale = 50,
	HPBarHeight = 76,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 2990, Gain = 598},
		{Value = 200002, Base = 39, Gain = 8},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "有50%概率额外攻击1次",
		Skill = {
			{
				Id = 105023,
				Value = 50,
			},
		},
	},
	Tags = {
		560111,
		564556,
		564558,
	},
}
EnemyConfig[EnemyID.Id6016] =
{
	Id = 6016,
	Name = "不良花",
	Rarity = 2,
	Element = 210003,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：躲在小学门口，敲诈放学回家的小学生。",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	IconName = "Arena_RPG_xiaohuaqiu",
	PrefabBundle = "character_arenaenemy",
	PrefabName = "Arena_RPG_xiaohuaqiu",
	PrefabScale = 50,
	HPBarHeight = 76,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 2040, Gain = 408},
		{Value = 200002, Base = 32, Gain = 7},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "每3回合攻击 +36%，最多3次",
		Skill = {
			{
				Id = 105010,
				Value = 36,
			},
		},
	},
	Tags = {
		560111,
		564556,
		564561,
	},
}
EnemyConfig[EnemyID.Id6017] =
{
	Id = 6017,
	Name = "不良花",
	Rarity = 2,
	Element = 210003,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：躲在小学门口，敲诈放学回家的小学生。",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	IconName = "Arena_RPG_xiaohuaqiu",
	PrefabBundle = "character_arenaenemy",
	PrefabName = "Arena_RPG_xiaohuaqiu",
	PrefabScale = 50,
	HPBarHeight = 76,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 2209, Gain = 442},
		{Value = 200002, Base = 35, Gain = 7},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "每3回合攻击 +36%，最多3次",
		Skill = {
			{
				Id = 105010,
				Value = 36,
			},
		},
	},
	Tags = {
		560111,
		564556,
		564561,
	},
}
EnemyConfig[EnemyID.Id6018] =
{
	Id = 6018,
	Name = "不良花",
	Rarity = 2,
	Element = 210003,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：躲在小学门口，敲诈放学回家的小学生。",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	IconName = "Arena_RPG_xiaohuaqiu",
	PrefabBundle = "character_arenaenemy",
	PrefabName = "Arena_RPG_xiaohuaqiu",
	PrefabScale = 50,
	HPBarHeight = 76,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 2837, Gain = 568},
		{Value = 200002, Base = 38, Gain = 8},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "每3回合攻击 +36%，最多3次",
		Skill = {
			{
				Id = 105010,
				Value = 36,
			},
		},
	},
	Tags = {
		560111,
		564556,
		564561,
	},
}
EnemyConfig[EnemyID.Id6019] =
{
	Id = 6019,
	Name = "灰狼小弟",
	Rarity = 2,
	Element = 210001,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：疑似帮派分子。",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	IconName = "Arena_RPG_Wolf",
	PrefabBundle = "character_arenaenemy",
	PrefabName = "Arena_RPG_Wolf",
	PrefabScale = 50,
	HPBarHeight = 89,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 1963, Gain = 393},
		{Value = 200002, Base = 31, Gain = 7},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "暴击伤害 +200%\n每回合暴击 +20，最多5次",
		Skill = {
			{
				Id = 105038,
				Value = 200,
			},
			{
				Id = 105008,
				Value = 20,
			},
		},
	},
	Tags = {
		560111,
		564556,
		564561,
	},
}
EnemyConfig[EnemyID.Id6020] =
{
	Id = 6020,
	Name = "灰狼小弟",
	Rarity = 2,
	Element = 210001,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：疑似帮派分子。",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	IconName = "Arena_RPG_Wolf",
	PrefabBundle = "character_arenaenemy",
	PrefabName = "Arena_RPG_Wolf",
	PrefabScale = 50,
	HPBarHeight = 89,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 2113, Gain = 423},
		{Value = 200002, Base = 34, Gain = 7},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "暴击伤害 +200%\n每回合暴击 +20，最多5次",
		Skill = {
			{
				Id = 105038,
				Value = 200,
			},
			{
				Id = 105008,
				Value = 20,
			},
		},
	},
	Tags = {
		560111,
		564556,
		564561,
	},
}
EnemyConfig[EnemyID.Id6021] =
{
	Id = 6021,
	Name = "灰狼小弟",
	Rarity = 2,
	Element = 210001,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：疑似帮派分子。",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	IconName = "Arena_RPG_Wolf",
	PrefabBundle = "character_arenaenemy",
	PrefabName = "Arena_RPG_Wolf",
	PrefabScale = 50,
	HPBarHeight = 89,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 2699, Gain = 540},
		{Value = 200002, Base = 37, Gain = 8},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "暴击伤害 +200%\n每回合暴击 +20，最多5次",
		Skill = {
			{
				Id = 105038,
				Value = 200,
			},
			{
				Id = 105008,
				Value = 20,
			},
		},
	},
	Tags = {
		560111,
		564556,
		564561,
	},
}
EnemyConfig[EnemyID.Id6022] =
{
	Id = 6022,
	Name = "枯萎树精",
	Rarity = 3,
	Element = 210003,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：把鼻涕抹在公共场所，弄得粘乎乎的。",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	IconName = "Arena_RPG_xiaoshuyang",
	PrefabBundle = "character_arenaenemy",
	PrefabName = "Arena_RPG_xiaoshuyang",
	PrefabScale = 50,
	HPBarHeight = 85,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 2049, Gain = 410},
		{Value = 200002, Base = 35, Gain = 7},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "5回合后，自身属性变为暗元素\n每3回合对前3个队员造成75%攻击伤害",
		Skill = {
			{
				Id = 105160,
				Value = 210005,
			},
			{
				Id = 105057,
				Value = 75,
			},
		},
	},
	Tags = {
		560111,
		564555,
	},
}
EnemyConfig[EnemyID.Id6023] =
{
	Id = 6023,
	Name = "枯萎树精",
	Rarity = 3,
	Element = 210003,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：把鼻涕抹在公共场所，弄得粘乎乎的。",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	IconName = "Arena_RPG_xiaoshuyang",
	PrefabBundle = "character_arenaenemy",
	PrefabName = "Arena_RPG_xiaoshuyang",
	PrefabScale = 50,
	HPBarHeight = 85,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 2534, Gain = 507},
		{Value = 200002, Base = 36, Gain = 8},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "5回合后，自身属性变为暗元素\n每3回合对前3个队员造成75%攻击伤害",
		Skill = {
			{
				Id = 105160,
				Value = 210005,
			},
			{
				Id = 105057,
				Value = 75,
			},
		},
	},
	Tags = {
		560111,
		564555,
	},
}
EnemyConfig[EnemyID.Id6024] =
{
	Id = 6024,
	Name = "枯萎树精",
	Rarity = 3,
	Element = 210003,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：把鼻涕抹在公共场所，弄得粘乎乎的。",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	IconName = "Arena_RPG_xiaoshuyang",
	PrefabBundle = "character_arenaenemy",
	PrefabName = "Arena_RPG_xiaoshuyang",
	PrefabScale = 50,
	HPBarHeight = 85,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 2975, Gain = 595},
		{Value = 200002, Base = 37, Gain = 8},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "5回合后，自身属性变为暗元素\n每3回合对前3个队员造成75%攻击伤害",
		Skill = {
			{
				Id = 105160,
				Value = 210005,
			},
			{
				Id = 105057,
				Value = 75,
			},
		},
	},
	Tags = {
		560111,
		564555,
	},
}
EnemyConfig[EnemyID.Id6025] =
{
	Id = 6025,
	Name = "白狼老大",
	Rarity = 3,
	Element = 210004,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：组织并经营非法团伙，疑似有收取保护费行为。",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	IconName = "Arena_RPG_WhiteWolf",
	PrefabBundle = "character_arenaenemy",
	PrefabName = "Arena_RPG_WhiteWolf",
	PrefabScale = 50,
	HPBarHeight = 102,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 2049, Gain = 410},
		{Value = 200002, Base = 35, Gain = 7},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "有35%概率额外攻击2次\n33%概率闪避攻击",
		Skill = {
			{
				Id = 105024,
				Value = 35,
			},
			{
				Id = 105026,
				Value = 33,
			},
		},
	},
	Tags = {
		560111,
		564555,
		564557,
		564558,
	},
}
EnemyConfig[EnemyID.Id6026] =
{
	Id = 6026,
	Name = "白狼老大",
	Rarity = 3,
	Element = 210004,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：组织并经营非法团伙，疑似有收取保护费行为。",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	IconName = "Arena_RPG_WhiteWolf",
	PrefabBundle = "character_arenaenemy",
	PrefabName = "Arena_RPG_WhiteWolf",
	PrefabScale = 50,
	HPBarHeight = 102,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 2534, Gain = 507},
		{Value = 200002, Base = 36, Gain = 8},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "有35%概率额外攻击2次\n33%概率闪避攻击",
		Skill = {
			{
				Id = 105024,
				Value = 35,
			},
			{
				Id = 105026,
				Value = 33,
			},
		},
	},
	Tags = {
		560111,
		564555,
		564557,
		564558,
	},
}
EnemyConfig[EnemyID.Id6027] =
{
	Id = 6027,
	Name = "白狼老大",
	Rarity = 3,
	Element = 210004,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：组织并经营非法团伙，疑似有收取保护费行为。",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	IconName = "Arena_RPG_WhiteWolf",
	PrefabBundle = "character_arenaenemy",
	PrefabName = "Arena_RPG_WhiteWolf",
	PrefabScale = 50,
	HPBarHeight = 102,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 2975, Gain = 595},
		{Value = 200002, Base = 37, Gain = 8},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "有35%概率额外攻击2次\n33%概率闪避攻击",
		Skill = {
			{
				Id = 105024,
				Value = 35,
			},
			{
				Id = 105026,
				Value = 33,
			},
		},
	},
	Tags = {
		560111,
		564555,
		564557,
		564558,
	},
}
EnemyConfig[EnemyID.Id6028] =
{
	Id = 6028,
	Name = "鬼影树",
	Rarity = 2,
	Element = 210003,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：有人在树下躲雨时，故意让人淋湿感冒。",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	IconName = "Arena_RPG_dashu",
	PrefabBundle = "character_arenaenemy",
	PrefabName = "Arena_RPG_dashu",
	PrefabScale = 50,
	HPBarHeight = 141,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 2293, Gain = 459},
		{Value = 200002, Base = 37, Gain = 8},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "每3回合回血 25%，最多5次",
		Skill = {
			{
				Id = 105009,
				Value = 25,
			},
		},
	},
	Tags = {
		560111,
		564556,
		564560,
	},
}
EnemyConfig[EnemyID.Id6029] =
{
	Id = 6029,
	Name = "鬼影树",
	Rarity = 2,
	Element = 210003,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：有人在树下躲雨时，故意让人淋湿感冒。",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	IconName = "Arena_RPG_dashu",
	PrefabBundle = "character_arenaenemy",
	PrefabName = "Arena_RPG_dashu",
	PrefabScale = 50,
	HPBarHeight = 141,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 2442, Gain = 489},
		{Value = 200002, Base = 40, Gain = 8},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "每3回合回血 25%，最多5次",
		Skill = {
			{
				Id = 105009,
				Value = 25,
			},
		},
	},
	Tags = {
		560111,
		564556,
		564560,
	},
}
EnemyConfig[EnemyID.Id6030] =
{
	Id = 6030,
	Name = "鬼影树",
	Rarity = 2,
	Element = 210003,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：有人在树下躲雨时，故意让人淋湿感冒。",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	IconName = "Arena_RPG_dashu",
	PrefabBundle = "character_arenaenemy",
	PrefabName = "Arena_RPG_dashu",
	PrefabScale = 50,
	HPBarHeight = 141,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 3091, Gain = 619},
		{Value = 200002, Base = 44, Gain = 9},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "每3回合回血 25%，最多5次",
		Skill = {
			{
				Id = 105009,
				Value = 25,
			},
		},
	},
	Tags = {
		560111,
		564556,
		564560,
	},
}
EnemyConfig[EnemyID.Id6031] =
{
	Id = 6031,
	Name = "红眼猴",
	Rarity = 2,
	Element = 210003,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：得了红眼病还故意传染给别人。",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	IconName = "Arena_RPG_shuzhuangguai",
	PrefabBundle = "character_arenaenemy",
	PrefabName = "Arena_RPG_shuzhuangguai",
	PrefabScale = 50,
	HPBarHeight = 69,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 2293, Gain = 459},
		{Value = 200002, Base = 37, Gain = 8},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "有15%概率额外攻击1次\n15%概率闪避攻击",
		Skill = {
			{
				Id = 105023,
				Value = 15,
			},
			{
				Id = 105026,
				Value = 15,
			},
		},
	},
	Tags = {
		560111,
		564556,
		564557,
		564558,
	},
}
EnemyConfig[EnemyID.Id6032] =
{
	Id = 6032,
	Name = "红眼猴",
	Rarity = 2,
	Element = 210003,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：得了红眼病还故意传染给别人。",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	IconName = "Arena_RPG_shuzhuangguai",
	PrefabBundle = "character_arenaenemy",
	PrefabName = "Arena_RPG_shuzhuangguai",
	PrefabScale = 50,
	HPBarHeight = 69,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 2442, Gain = 489},
		{Value = 200002, Base = 40, Gain = 8},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "有15%概率额外攻击1次\n15%概率闪避攻击",
		Skill = {
			{
				Id = 105023,
				Value = 15,
			},
			{
				Id = 105026,
				Value = 15,
			},
		},
	},
	Tags = {
		560111,
		564556,
		564557,
		564558,
	},
}
EnemyConfig[EnemyID.Id6033] =
{
	Id = 6033,
	Name = "红眼猴",
	Rarity = 2,
	Element = 210003,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：得了红眼病还故意传染给别人。",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	IconName = "Arena_RPG_shuzhuangguai",
	PrefabBundle = "character_arenaenemy",
	PrefabName = "Arena_RPG_shuzhuangguai",
	PrefabScale = 50,
	HPBarHeight = 69,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 3091, Gain = 619},
		{Value = 200002, Base = 44, Gain = 9},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "有15%概率额外攻击1次\n15%概率闪避攻击",
		Skill = {
			{
				Id = 105023,
				Value = 15,
			},
			{
				Id = 105026,
				Value = 15,
			},
		},
	},
	Tags = {
		560111,
		564556,
		564557,
		564558,
	},
}
EnemyConfig[EnemyID.Id6034] =
{
	Id = 6034,
	Name = "胶水泥怪",
	Rarity = 2,
	Element = 210001,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：喜欢在公园长椅上涂胶水捉弄别人。",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	IconName = "Arena_RPG_niannianguai",
	PrefabBundle = "character_arenaenemy",
	PrefabName = "Arena_RPG_niannianguai",
	PrefabScale = 50,
	HPBarHeight = 81,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 2215, Gain = 443},
		{Value = 200002, Base = 36, Gain = 8},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "受到的暴击伤害 -75%\n每回合忍耐 +20，最多5次",
		Skill = {
			{
				Id = 105039,
				Value = -75,
			},
			{
				Id = 105007,
				Value = 20,
			},
		},
	},
	Tags = {
		560111,
		564556,
		564561,
	},
}
EnemyConfig[EnemyID.Id6035] =
{
	Id = 6035,
	Name = "胶水泥怪",
	Rarity = 2,
	Element = 210001,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：喜欢在公园长椅上涂胶水捉弄别人。",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	IconName = "Arena_RPG_niannianguai",
	PrefabBundle = "character_arenaenemy",
	PrefabName = "Arena_RPG_niannianguai",
	PrefabScale = 50,
	HPBarHeight = 81,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 2348, Gain = 470},
		{Value = 200002, Base = 40, Gain = 8},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "受到的暴击伤害 -75%\n每回合忍耐 +20，最多5次",
		Skill = {
			{
				Id = 105039,
				Value = -75,
			},
			{
				Id = 105007,
				Value = 20,
			},
		},
	},
	Tags = {
		560111,
		564556,
		564561,
	},
}
EnemyConfig[EnemyID.Id6036] =
{
	Id = 6036,
	Name = "胶水泥怪",
	Rarity = 2,
	Element = 210001,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：喜欢在公园长椅上涂胶水捉弄别人。",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	IconName = "Arena_RPG_niannianguai",
	PrefabBundle = "character_arenaenemy",
	PrefabName = "Arena_RPG_niannianguai",
	PrefabScale = 50,
	HPBarHeight = 81,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 2960, Gain = 592},
		{Value = 200002, Base = 43, Gain = 9},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "受到的暴击伤害 -75%\n每回合忍耐 +20，最多5次",
		Skill = {
			{
				Id = 105039,
				Value = -75,
			},
			{
				Id = 105007,
				Value = 20,
			},
		},
	},
	Tags = {
		560111,
		564556,
		564561,
	},
}
EnemyConfig[EnemyID.Id6037] =
{
	Id = 6037,
	Name = "磨蹭石",
	Rarity = 2,
	Element = 210004,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：一边走路一边看手机，导致路况拥堵。",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	IconName = "Arena_RPG_dashitou",
	PrefabBundle = "character_arenaenemy",
	PrefabName = "Arena_RPG_dashitou",
	PrefabScale = 50,
	HPBarHeight = 102,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 2142, Gain = 429},
		{Value = 200002, Base = 36, Gain = 8},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "5回合后，回血 50%\n每回合忍耐 +20，最多5次",
		Skill = {
			{
				Id = 105013,
				Value = 50,
			},
			{
				Id = 105007,
				Value = 20,
			},
		},
	},
	Tags = {
		560111,
		564556,
		564560,
		564561,
	},
}
EnemyConfig[EnemyID.Id6038] =
{
	Id = 6038,
	Name = "磨蹭石",
	Rarity = 2,
	Element = 210004,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：一边走路一边看手机，导致路况拥堵。",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	IconName = "Arena_RPG_dashitou",
	PrefabBundle = "character_arenaenemy",
	PrefabName = "Arena_RPG_dashitou",
	PrefabScale = 50,
	HPBarHeight = 102,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 2261, Gain = 453},
		{Value = 200002, Base = 39, Gain = 8},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "5回合后，回血 50%\n每回合忍耐 +20，最多5次",
		Skill = {
			{
				Id = 105013,
				Value = 50,
			},
			{
				Id = 105007,
				Value = 20,
			},
		},
	},
	Tags = {
		560111,
		564556,
		564560,
		564561,
	},
}
EnemyConfig[EnemyID.Id6039] =
{
	Id = 6039,
	Name = "磨蹭石",
	Rarity = 2,
	Element = 210004,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：一边走路一边看手机，导致路况拥堵。",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	IconName = "Arena_RPG_dashitou",
	PrefabBundle = "character_arenaenemy",
	PrefabName = "Arena_RPG_dashitou",
	PrefabScale = 50,
	HPBarHeight = 102,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 2840, Gain = 568},
		{Value = 200002, Base = 42, Gain = 9},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "5回合后，回血 50%\n每回合忍耐 +20，最多5次",
		Skill = {
			{
				Id = 105013,
				Value = 50,
			},
			{
				Id = 105007,
				Value = 20,
			},
		},
	},
	Tags = {
		560111,
		564556,
		564560,
		564561,
	},
}
EnemyConfig[EnemyID.Id6040] =
{
	Id = 6040,
	Name = "吵架石",
	Rarity = 2,
	Element = 210004,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：动不动就会和别人吵起来，还会动手动脚。",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	IconName = "Arena_RPG_xiaoshiguai",
	PrefabBundle = "character_arenaenemy",
	PrefabName = "Arena_RPG_xiaoshiguai",
	PrefabScale = 50,
	HPBarHeight = 76,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 2142, Gain = 429},
		{Value = 200002, Base = 36, Gain = 8},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "每3回合对所有队员造成100%攻击伤害\n暴击 +40",
		Skill = {
			{
				Id = 105063,
				Value = 100,
			},
			{
				Id = 105004,
				Value = 40,
			},
		},
	},
	Tags = {
		560111,
		564556,
		564561,
	},
}
EnemyConfig[EnemyID.Id6041] =
{
	Id = 6041,
	Name = "吵架石",
	Rarity = 2,
	Element = 210004,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：动不动就会和别人吵起来，还会动手动脚。",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	IconName = "Arena_RPG_xiaoshiguai",
	PrefabBundle = "character_arenaenemy",
	PrefabName = "Arena_RPG_xiaoshiguai",
	PrefabScale = 50,
	HPBarHeight = 76,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 2261, Gain = 453},
		{Value = 200002, Base = 39, Gain = 8},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "每3回合对所有队员造成100%攻击伤害\n暴击 +40",
		Skill = {
			{
				Id = 105063,
				Value = 100,
			},
			{
				Id = 105004,
				Value = 40,
			},
		},
	},
	Tags = {
		560111,
		564556,
		564561,
	},
}
EnemyConfig[EnemyID.Id6042] =
{
	Id = 6042,
	Name = "吵架石",
	Rarity = 2,
	Element = 210004,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：动不动就会和别人吵起来，还会动手动脚。",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	IconName = "Arena_RPG_xiaoshiguai",
	PrefabBundle = "character_arenaenemy",
	PrefabName = "Arena_RPG_xiaoshiguai",
	PrefabScale = 50,
	HPBarHeight = 76,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 2840, Gain = 568},
		{Value = 200002, Base = 42, Gain = 9},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "每3回合对所有队员造成100%攻击伤害\n暴击 +40",
		Skill = {
			{
				Id = 105063,
				Value = 100,
			},
			{
				Id = 105004,
				Value = 40,
			},
		},
	},
	Tags = {
		560111,
		564556,
		564561,
	},
}
EnemyConfig[EnemyID.Id6043] =
{
	Id = 6043,
	Name = "钢钉球",
	Rarity = 2,
	Element = 210005,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：挤地铁的时候故意刺痛附近的人。",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	IconName = "Arena_RPG_SeaUrchin",
	PrefabBundle = "character_arenaenemy",
	PrefabName = "Arena_RPG_SeaUrchin",
	PrefabScale = 50,
	HPBarHeight = 76,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 2074, Gain = 415},
		{Value = 200002, Base = 35, Gain = 7},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "每回合对前2个队员造成100%攻击伤害\n忍耐 +50",
		Skill = {
			{
				Id = 105040,
				Value = 100,
			},
			{
				Id = 105003,
				Value = 50,
			},
		},
	},
	Tags = {
		560111,
		564556,
		564561,
	},
}
EnemyConfig[EnemyID.Id6044] =
{
	Id = 6044,
	Name = "钢钉球",
	Rarity = 2,
	Element = 210005,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：挤地铁的时候故意刺痛附近的人。",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	IconName = "Arena_RPG_SeaUrchin",
	PrefabBundle = "character_arenaenemy",
	PrefabName = "Arena_RPG_SeaUrchin",
	PrefabScale = 50,
	HPBarHeight = 76,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 2180, Gain = 436},
		{Value = 200002, Base = 38, Gain = 8},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "每回合对前2个队员造成100%攻击伤害\n忍耐 +50",
		Skill = {
			{
				Id = 105040,
				Value = 100,
			},
			{
				Id = 105003,
				Value = 50,
			},
		},
	},
	Tags = {
		560111,
		564556,
		564561,
	},
}
EnemyConfig[EnemyID.Id6045] =
{
	Id = 6045,
	Name = "钢钉球",
	Rarity = 2,
	Element = 210005,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：挤地铁的时候故意刺痛附近的人。",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	IconName = "Arena_RPG_SeaUrchin",
	PrefabBundle = "character_arenaenemy",
	PrefabName = "Arena_RPG_SeaUrchin",
	PrefabScale = 50,
	HPBarHeight = 76,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 2729, Gain = 546},
		{Value = 200002, Base = 42, Gain = 9},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "每回合对前2个队员造成100%攻击伤害\n忍耐 +50",
		Skill = {
			{
				Id = 105040,
				Value = 100,
			},
			{
				Id = 105003,
				Value = 50,
			},
		},
	},
	Tags = {
		560111,
		564556,
		564561,
	},
}
EnemyConfig[EnemyID.Id6046] =
{
	Id = 6046,
	Name = "矿洞刺毛怪",
	Rarity = 4,
	Element = 210005,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：开采过程中偷吃矿石导致矿队亏本。",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	IconName = "Arena_RPG_BigSeaUrchin",
	PrefabBundle = "character_arenaenemy",
	PrefabName = "Arena_RPG_BigSeaUrchin",
	PrefabScale = 50,
	HPBarHeight = 102,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 2177, Gain = 436},
		{Value = 200002, Base = 40, Gain = 8},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "每回合对前3个队员造成100%攻击伤害\n忍耐 +75",
		Skill = {
			{
				Id = 105041,
				Value = 100,
			},
			{
				Id = 105003,
				Value = 75,
			},
		},
	},
	Tags = {
		560111,
		564555,
		564561,
	},
}
EnemyConfig[EnemyID.Id6047] =
{
	Id = 6047,
	Name = "矿洞刺毛怪",
	Rarity = 4,
	Element = 210005,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：开采过程中偷吃矿石导致矿队亏本。",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	IconName = "Arena_RPG_BigSeaUrchin",
	PrefabBundle = "character_arenaenemy",
	PrefabName = "Arena_RPG_BigSeaUrchin",
	PrefabScale = 50,
	HPBarHeight = 102,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 2636, Gain = 528},
		{Value = 200002, Base = 41, Gain = 9},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "每回合对前3个队员造成100%攻击伤害\n忍耐 +75",
		Skill = {
			{
				Id = 105041,
				Value = 100,
			},
			{
				Id = 105003,
				Value = 75,
			},
		},
	},
	Tags = {
		560111,
		564555,
		564561,
	},
}
EnemyConfig[EnemyID.Id6048] =
{
	Id = 6048,
	Name = "矿洞刺毛怪",
	Rarity = 4,
	Element = 210005,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：开采过程中偷吃矿石导致矿队亏本。",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	IconName = "Arena_RPG_BigSeaUrchin",
	PrefabBundle = "character_arenaenemy",
	PrefabName = "Arena_RPG_BigSeaUrchin",
	PrefabScale = 50,
	HPBarHeight = 102,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 3035, Gain = 607},
		{Value = 200002, Base = 42, Gain = 9},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "每回合对前3个队员造成100%攻击伤害\n忍耐 +75",
		Skill = {
			{
				Id = 105041,
				Value = 100,
			},
			{
				Id = 105003,
				Value = 75,
			},
		},
	},
	Tags = {
		560111,
		564555,
		564561,
	},
}
EnemyConfig[EnemyID.Id6049] =
{
	Id = 6049,
	Name = "熔岩石巨人",
	Rarity = 3,
	Element = 210004,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：拒不配合房屋拆迁工作，还大肆破坏公共财产。",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	IconName = "Arena_RPG_Stoneman",
	PrefabBundle = "character_arenaenemy",
	PrefabName = "Arena_RPG_Stoneman",
	PrefabScale = 50,
	HPBarHeight = 114,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 2177, Gain = 436},
		{Value = 200002, Base = 40, Gain = 8},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "每回合回血 10%，最多5次\n5回合后，忍耐 +100",
		Skill = {
			{
				Id = 105005,
				Value = 10,
			},
			{
				Id = 105015,
				Value = 100,
			},
		},
	},
	Tags = {
		560111,
		564555,
		564560,
		564561,
	},
}
EnemyConfig[EnemyID.Id6050] =
{
	Id = 6050,
	Name = "熔岩石巨人",
	Rarity = 3,
	Element = 210004,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：拒不配合房屋拆迁工作，还大肆破坏公共财产。",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	IconName = "Arena_RPG_Stoneman",
	PrefabBundle = "character_arenaenemy",
	PrefabName = "Arena_RPG_Stoneman",
	PrefabScale = 50,
	HPBarHeight = 114,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 2636, Gain = 528},
		{Value = 200002, Base = 41, Gain = 9},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "每回合回血 10%，最多5次\n5回合后，忍耐 +100",
		Skill = {
			{
				Id = 105005,
				Value = 10,
			},
			{
				Id = 105015,
				Value = 100,
			},
		},
	},
	Tags = {
		560111,
		564555,
		564560,
		564561,
	},
}
EnemyConfig[EnemyID.Id6051] =
{
	Id = 6051,
	Name = "熔岩石巨人",
	Rarity = 3,
	Element = 210004,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：拒不配合房屋拆迁工作，还大肆破坏公共财产。",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	IconName = "Arena_RPG_Stoneman",
	PrefabBundle = "character_arenaenemy",
	PrefabName = "Arena_RPG_Stoneman",
	PrefabScale = 50,
	HPBarHeight = 114,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 3035, Gain = 607},
		{Value = 200002, Base = 42, Gain = 9},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "每回合回血 10%，最多5次\n5回合后，忍耐 +100",
		Skill = {
			{
				Id = 105005,
				Value = 10,
			},
			{
				Id = 105015,
				Value = 100,
			},
		},
	},
	Tags = {
		560111,
		564555,
		564560,
		564561,
	},
}
EnemyConfig[EnemyID.Id6052] =
{
	Id = 6052,
	Name = "臭臭淤泥",
	Rarity = 2,
	Element = 210002,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：在干净的马路上留下大量泥痕。",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	IconName = "Arena_RPG_chouniguai",
	PrefabBundle = "character_arenaenemy",
	PrefabName = "Arena_RPG_chouniguai",
	PrefabScale = 50,
	HPBarHeight = 76,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 2328, Gain = 466},
		{Value = 200002, Base = 41, Gain = 9},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "每3回合将自身元素变为随机元素\n每3回合有50%概率对后2个队员造成75%攻击伤害",
		Skill = {
			{
				Id = 105163,
				Value = -1,
			},
			{
				Id = 105100,
				Value = 75,
			},
		},
	},
	Tags = {
		560111,
		564556,
	},
}
EnemyConfig[EnemyID.Id6053] =
{
	Id = 6053,
	Name = "臭臭淤泥",
	Rarity = 2,
	Element = 210002,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：在干净的马路上留下大量泥痕。",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	IconName = "Arena_RPG_chouniguai",
	PrefabBundle = "character_arenaenemy",
	PrefabName = "Arena_RPG_chouniguai",
	PrefabScale = 50,
	HPBarHeight = 76,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 2430, Gain = 486},
		{Value = 200002, Base = 45, Gain = 9},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "每3回合将自身元素变为随机元素\n每3回合有50%概率对后2个队员造成75%攻击伤害",
		Skill = {
			{
				Id = 105163,
				Value = -1,
			},
			{
				Id = 105100,
				Value = 75,
			},
		},
	},
	Tags = {
		560111,
		564556,
	},
}
EnemyConfig[EnemyID.Id6054] =
{
	Id = 6054,
	Name = "臭臭淤泥",
	Rarity = 2,
	Element = 210002,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：在干净的马路上留下大量泥痕。",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	IconName = "Arena_RPG_chouniguai",
	PrefabBundle = "character_arenaenemy",
	PrefabName = "Arena_RPG_chouniguai",
	PrefabScale = 50,
	HPBarHeight = 76,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 3021, Gain = 605},
		{Value = 200002, Base = 49, Gain = 10},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "每3回合将自身元素变为随机元素\n每3回合有50%概率对后2个队员造成75%攻击伤害",
		Skill = {
			{
				Id = 105163,
				Value = -1,
			},
			{
				Id = 105100,
				Value = 75,
			},
		},
	},
	Tags = {
		560111,
		564556,
	},
}
EnemyConfig[EnemyID.Id6055] =
{
	Id = 6055,
	Name = "鬼火球",
	Rarity = 2,
	Element = 210002,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：经常出没坟场，吓前来祭拜的人。",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	IconName = "Arena_RPG_Fireball",
	PrefabBundle = "character_arenaenemy",
	PrefabName = "Arena_RPG_Fireball",
	PrefabScale = 50,
	HPBarHeight = 76,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 2260, Gain = 452},
		{Value = 200002, Base = 40, Gain = 8},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "每回合有50%概率对末位队员造成100%攻击伤害\n受火元素敌人伤害 -100%",
		Skill = {
			{
				Id = 105083,
				Value = 100,
			},
			{
				Id = 105034,
				Value = -100,
			},
		},
	},
	Tags = {
		560111,
		564556,
	},
}
EnemyConfig[EnemyID.Id6056] =
{
	Id = 6056,
	Name = "鬼火球",
	Rarity = 2,
	Element = 210002,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：经常出没坟场，吓前来祭拜的人。",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	IconName = "Arena_RPG_Fireball",
	PrefabBundle = "character_arenaenemy",
	PrefabName = "Arena_RPG_Fireball",
	PrefabScale = 50,
	HPBarHeight = 76,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 2351, Gain = 471},
		{Value = 200002, Base = 44, Gain = 9},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "每回合有50%概率对末位队员造成100%攻击伤害\n受火元素敌人伤害 -100%",
		Skill = {
			{
				Id = 105083,
				Value = 100,
			},
			{
				Id = 105034,
				Value = -100,
			},
		},
	},
	Tags = {
		560111,
		564556,
	},
}
EnemyConfig[EnemyID.Id6057] =
{
	Id = 6057,
	Name = "鬼火球",
	Rarity = 2,
	Element = 210002,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：经常出没坟场，吓前来祭拜的人。",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	IconName = "Arena_RPG_Fireball",
	PrefabBundle = "character_arenaenemy",
	PrefabName = "Arena_RPG_Fireball",
	PrefabScale = 50,
	HPBarHeight = 76,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 2916, Gain = 584},
		{Value = 200002, Base = 48, Gain = 10},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "每回合有50%概率对末位队员造成100%攻击伤害\n受火元素敌人伤害 -100%",
		Skill = {
			{
				Id = 105083,
				Value = 100,
			},
			{
				Id = 105034,
				Value = -100,
			},
		},
	},
	Tags = {
		560111,
		564556,
	},
}
EnemyConfig[EnemyID.Id6058] =
{
	Id = 6058,
	Name = "鬼火山",
	Rarity = 2,
	Element = 210004,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：在公共场所吃很难闻的食物，边吃边打嗝。",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	IconName = "Arena_RPG_Volcano",
	PrefabBundle = "character_arenaenemy",
	PrefabName = "Arena_RPG_Volcano",
	PrefabScale = 50,
	HPBarHeight = 81,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 2260, Gain = 452},
		{Value = 200002, Base = 40, Gain = 8},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "每3回合对所有队员造成120%攻击伤害\n每回合攻击 +15%，最多5次",
		Skill = {
			{
				Id = 105063,
				Value = 120,
			},
			{
				Id = 105006,
				Value = 15,
			},
		},
	},
	Tags = {
		560111,
		564556,
		564561,
	},
}
EnemyConfig[EnemyID.Id6059] =
{
	Id = 6059,
	Name = "鬼火山",
	Rarity = 2,
	Element = 210004,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：在公共场所吃很难闻的食物，边吃边打嗝。",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	IconName = "Arena_RPG_Volcano",
	PrefabBundle = "character_arenaenemy",
	PrefabName = "Arena_RPG_Volcano",
	PrefabScale = 50,
	HPBarHeight = 81,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 2351, Gain = 471},
		{Value = 200002, Base = 44, Gain = 9},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "每3回合对所有队员造成120%攻击伤害\n每回合攻击 +15%，最多5次",
		Skill = {
			{
				Id = 105063,
				Value = 120,
			},
			{
				Id = 105006,
				Value = 15,
			},
		},
	},
	Tags = {
		560111,
		564556,
		564561,
	},
}
EnemyConfig[EnemyID.Id6060] =
{
	Id = 6060,
	Name = "鬼火山",
	Rarity = 2,
	Element = 210004,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：在公共场所吃很难闻的食物，边吃边打嗝。",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	IconName = "Arena_RPG_Volcano",
	PrefabBundle = "character_arenaenemy",
	PrefabName = "Arena_RPG_Volcano",
	PrefabScale = 50,
	HPBarHeight = 81,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 2916, Gain = 584},
		{Value = 200002, Base = 48, Gain = 10},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "每3回合对所有队员造成120%攻击伤害\n每回合攻击 +15%，最多5次",
		Skill = {
			{
				Id = 105063,
				Value = 120,
			},
			{
				Id = 105006,
				Value = 15,
			},
		},
	},
	Tags = {
		560111,
		564556,
		564561,
	},
}
EnemyConfig[EnemyID.Id6061] =
{
	Id = 6061,
	Name = "逆行猪",
	Rarity = 2,
	Element = 210002,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：喜欢在高速公路上逆向散步，引起交通事故。",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	IconName = "Arena_RPG_LavaPig",
	PrefabBundle = "character_arenaenemy",
	PrefabName = "Arena_RPG_LavaPig",
	PrefabScale = 50,
	HPBarHeight = 76,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 2196, Gain = 440},
		{Value = 200002, Base = 40, Gain = 8},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "每3回合攻击 +30%，最多3次\n每3回合忍耐 +30，最多3次",
		Skill = {
			{
				Id = 105010,
				Value = 30,
			},
			{
				Id = 105011,
				Value = 30,
			},
		},
	},
	Tags = {
		560111,
		564556,
		564561,
	},
}
EnemyConfig[EnemyID.Id6062] =
{
	Id = 6062,
	Name = "逆行猪",
	Rarity = 2,
	Element = 210002,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：喜欢在高速公路上逆向散步，引起交通事故。",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	IconName = "Arena_RPG_LavaPig",
	PrefabBundle = "character_arenaenemy",
	PrefabName = "Arena_RPG_LavaPig",
	PrefabScale = 50,
	HPBarHeight = 76,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 2278, Gain = 456},
		{Value = 200002, Base = 44, Gain = 9},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "每3回合攻击 +30%，最多3次\n每3回合忍耐 +30，最多3次",
		Skill = {
			{
				Id = 105010,
				Value = 30,
			},
			{
				Id = 105011,
				Value = 30,
			},
		},
	},
	Tags = {
		560111,
		564556,
		564561,
	},
}
EnemyConfig[EnemyID.Id6063] =
{
	Id = 6063,
	Name = "逆行猪",
	Rarity = 2,
	Element = 210002,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：喜欢在高速公路上逆向散步，引起交通事故。",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	IconName = "Arena_RPG_LavaPig",
	PrefabBundle = "character_arenaenemy",
	PrefabName = "Arena_RPG_LavaPig",
	PrefabScale = 50,
	HPBarHeight = 76,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 2817, Gain = 564},
		{Value = 200002, Base = 47, Gain = 10},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "每3回合攻击 +30%，最多3次\n每3回合忍耐 +30，最多3次",
		Skill = {
			{
				Id = 105010,
				Value = 30,
			},
			{
				Id = 105011,
				Value = 30,
			},
		},
	},
	Tags = {
		560111,
		564556,
		564561,
	},
}
EnemyConfig[EnemyID.Id6064] =
{
	Id = 6064,
	Name = "冷焰精灵",
	Rarity = 2,
	Element = 210002,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：打喷嚏的时候故意打到别人脸上。",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	IconName = "Arena_RPG_Salamander",
	PrefabBundle = "character_arenaenemy",
	PrefabName = "Arena_RPG_Salamander",
	PrefabScale = 50,
	HPBarHeight = 81,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 2196, Gain = 440},
		{Value = 200002, Base = 40, Gain = 8},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "33%概率闪避攻击\n5回合后，攻击 +150%",
		Skill = {
			{
				Id = 105026,
				Value = 33,
			},
			{
				Id = 105014,
				Value = 150,
			},
		},
	},
	Tags = {
		560111,
		564556,
		564557,
		564561,
	},
}
EnemyConfig[EnemyID.Id6065] =
{
	Id = 6065,
	Name = "冷焰精灵",
	Rarity = 2,
	Element = 210002,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：打喷嚏的时候故意打到别人脸上。",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	IconName = "Arena_RPG_Salamander",
	PrefabBundle = "character_arenaenemy",
	PrefabName = "Arena_RPG_Salamander",
	PrefabScale = 50,
	HPBarHeight = 81,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 2278, Gain = 456},
		{Value = 200002, Base = 44, Gain = 9},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "33%概率闪避攻击\n5回合后，攻击 +150%",
		Skill = {
			{
				Id = 105026,
				Value = 33,
			},
			{
				Id = 105014,
				Value = 150,
			},
		},
	},
	Tags = {
		560111,
		564556,
		564557,
		564561,
	},
}
EnemyConfig[EnemyID.Id6066] =
{
	Id = 6066,
	Name = "冷焰精灵",
	Rarity = 2,
	Element = 210002,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：打喷嚏的时候故意打到别人脸上。",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	IconName = "Arena_RPG_Salamander",
	PrefabBundle = "character_arenaenemy",
	PrefabName = "Arena_RPG_Salamander",
	PrefabScale = 50,
	HPBarHeight = 81,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 2817, Gain = 564},
		{Value = 200002, Base = 47, Gain = 10},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "33%概率闪避攻击\n5回合后，攻击 +150%",
		Skill = {
			{
				Id = 105026,
				Value = 33,
			},
			{
				Id = 105014,
				Value = 150,
			},
		},
	},
	Tags = {
		560111,
		564556,
		564557,
		564561,
	},
}
EnemyConfig[EnemyID.Id6067] =
{
	Id = 6067,
	Name = "幽灵巨蟹",
	Rarity = 3,
	Element = 210004,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：喜欢破坏公共区的植物。",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	IconName = "Arena_RPG_Firecrab",
	PrefabBundle = "character_arenaenemy",
	PrefabName = "Arena_RPG_Firecrab",
	PrefabScale = 50,
	HPBarHeight = 76,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 2136, Gain = 428},
		{Value = 200002, Base = 40, Gain = 8},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "暴击伤害 +200%\n每3回合，本回合暴率 +50%\n受到的暴击伤害 -75%",
		Skill = {
			{
				Id = 105038,
				Value = 200,
			},
			{
				Id = 105135,
				Value = 50,
			},
			{
				Id = 105039,
				Value = -75,
			},
		},
	},
	Tags = {
		560111,
		564556,
	},
}
EnemyConfig[EnemyID.Id6068] =
{
	Id = 6068,
	Name = "幽灵巨蟹",
	Rarity = 3,
	Element = 210004,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：喜欢破坏公共区的植物。",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	IconName = "Arena_RPG_Firecrab",
	PrefabBundle = "character_arenaenemy",
	PrefabName = "Arena_RPG_Firecrab",
	PrefabScale = 50,
	HPBarHeight = 76,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 2209, Gain = 442},
		{Value = 200002, Base = 43, Gain = 9},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "暴击伤害 +200%\n每3回合，本回合暴率 +50%\n受到的暴击伤害 -75%",
		Skill = {
			{
				Id = 105038,
				Value = 200,
			},
			{
				Id = 105135,
				Value = 50,
			},
			{
				Id = 105039,
				Value = -75,
			},
		},
	},
	Tags = {
		560111,
		564556,
	},
}
EnemyConfig[EnemyID.Id6069] =
{
	Id = 6069,
	Name = "幽灵巨蟹",
	Rarity = 3,
	Element = 210004,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：喜欢破坏公共区的植物。",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	IconName = "Arena_RPG_Firecrab",
	PrefabBundle = "character_arenaenemy",
	PrefabName = "Arena_RPG_Firecrab",
	PrefabScale = 50,
	HPBarHeight = 76,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 2725, Gain = 545},
		{Value = 200002, Base = 47, Gain = 10},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "暴击伤害 +200%\n处决：每2回合，本回合暴率 +50%\n受到的暴击伤害 -75%\n每2回合，100%概率无视敌人闪避",
		Skill = {
			{
				Id = 105038,
				Value = 200,
			},
			{
				Id = 105128,
				Value = 50,
			},
			{
				Id = 105039,
				Value = -75,
			},
			{
				Id = 105134,
				Value = 100,
			},
		},
	},
	Tags = {
		560111,
		564556,
		564559,
	},
}
EnemyConfig[EnemyID.Id6070] =
{
	Id = 6070,
	Name = "亡灵巨人",
	Rarity = 4,
	Element = 210002,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：在公共场所大声说话，把口水喷到别人脸上。",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	IconName = "Arena_RPG_GiantFire",
	PrefabBundle = "character_arenaenemy",
	PrefabName = "Arena_RPG_GiantFire",
	PrefabScale = 50,
	HPBarHeight = 114,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 2136, Gain = 428},
		{Value = 200002, Base = 40, Gain = 8},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "每回合对前2个队员造成150%攻击伤害\n每回合攻击 +20%，最多5次\n5回合后，回血 50%",
		Skill = {
			{
				Id = 105040,
				Value = 150,
			},
			{
				Id = 105006,
				Value = 20,
			},
			{
				Id = 105013,
				Value = 50,
			},
		},
	},
	Tags = {
		560111,
		564556,
		564560,
		564561,
	},
}
EnemyConfig[EnemyID.Id6071] =
{
	Id = 6071,
	Name = "亡灵巨人",
	Rarity = 4,
	Element = 210002,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：在公共场所大声说话，把口水喷到别人脸上。",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	IconName = "Arena_RPG_GiantFire",
	PrefabBundle = "character_arenaenemy",
	PrefabName = "Arena_RPG_GiantFire",
	PrefabScale = 50,
	HPBarHeight = 114,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 2209, Gain = 442},
		{Value = 200002, Base = 43, Gain = 9},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "每回合对前2个队员造成150%攻击伤害\n每回合攻击 +20%，最多5次\n5回合后，回血 50%",
		Skill = {
			{
				Id = 105040,
				Value = 150,
			},
			{
				Id = 105006,
				Value = 20,
			},
			{
				Id = 105013,
				Value = 50,
			},
		},
	},
	Tags = {
		560111,
		564556,
		564560,
		564561,
	},
}
EnemyConfig[EnemyID.Id6072] =
{
	Id = 6072,
	Name = "亡灵巨人",
	Rarity = 4,
	Element = 210002,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：在公共场所大声说话，把口水喷到别人脸上。",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	IconName = "Arena_RPG_GiantFire",
	PrefabBundle = "character_arenaenemy",
	PrefabName = "Arena_RPG_GiantFire",
	PrefabScale = 50,
	HPBarHeight = 114,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 2725, Gain = 545},
		{Value = 200002, Base = 47, Gain = 10},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "每回合对前2个队员造成150%攻击伤害\n每回合攻击 +20%，最多5次\n5回合后，回血 50%",
		Skill = {
			{
				Id = 105040,
				Value = 150,
			},
			{
				Id = 105006,
				Value = 20,
			},
			{
				Id = 105013,
				Value = 50,
			},
		},
	},
	Tags = {
		560111,
		564556,
		564560,
		564561,
	},
}
EnemyConfig[EnemyID.Id6073] =
{
	Id = 6073,
	Name = "黑斑莓",
	Rarity = 1,
	Element = 210003,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：兜售吃剩的水果给路人。",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	IconName = "Arena_FAT_Strawberry",
	PrefabBundle = "character_arenaenemy",
	PrefabName = "Arena_FAT_Strawberry",
	PrefabScale = 50,
	HPBarHeight = 90,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 2215, Gain = 443},
		{Value = 200002, Base = 34, Gain = 7},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "受水元素敌人伤害 -50%",
		Skill = {
			{
				Id = 105033,
				Value = -50,
			},
		},
	},
	Tags = {
		560111,
		564556,
	},
}
EnemyConfig[EnemyID.Id6074] =
{
	Id = 6074,
	Name = "黑斑莓",
	Rarity = 1,
	Element = 210003,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：兜售吃剩的水果给路人。",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	IconName = "Arena_FAT_Strawberry",
	PrefabBundle = "character_arenaenemy",
	PrefabName = "Arena_FAT_Strawberry",
	PrefabScale = 50,
	HPBarHeight = 90,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 2430, Gain = 486},
		{Value = 200002, Base = 37, Gain = 8},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "受水元素敌人伤害 -50%",
		Skill = {
			{
				Id = 105033,
				Value = -50,
			},
		},
	},
	Tags = {
		560111,
		564556,
	},
}
EnemyConfig[EnemyID.Id6075] =
{
	Id = 6075,
	Name = "黑斑莓",
	Rarity = 1,
	Element = 210003,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：兜售吃剩的水果给路人。",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	IconName = "Arena_FAT_Strawberry",
	PrefabBundle = "character_arenaenemy",
	PrefabName = "Arena_FAT_Strawberry",
	PrefabScale = 50,
	HPBarHeight = 90,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 3160, Gain = 632},
		{Value = 200002, Base = 41, Gain = 9},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "受水元素敌人伤害 -50%",
		Skill = {
			{
				Id = 105033,
				Value = -50,
			},
		},
	},
	Tags = {
		560111,
		564556,
	},
}
EnemyConfig[EnemyID.Id6076] =
{
	Id = 6076,
	Name = "毛桃几",
	Rarity = 1,
	Element = 210003,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：散播会引发鼻炎的绒毛。",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	IconName = "Arena_FAT_Peach",
	PrefabBundle = "character_arenaenemy",
	PrefabName = "Arena_FAT_Peach",
	PrefabScale = 50,
	HPBarHeight = 97,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 2215, Gain = 443},
		{Value = 200002, Base = 34, Gain = 7},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "受水元素敌人伤害 -50%",
		Skill = {
			{
				Id = 105033,
				Value = -50,
			},
		},
	},
	Tags = {
		560111,
		564556,
	},
}
EnemyConfig[EnemyID.Id6077] =
{
	Id = 6077,
	Name = "毛桃几",
	Rarity = 1,
	Element = 210003,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：散播会引发鼻炎的绒毛。",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	IconName = "Arena_FAT_Peach",
	PrefabBundle = "character_arenaenemy",
	PrefabName = "Arena_FAT_Peach",
	PrefabScale = 50,
	HPBarHeight = 97,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 2430, Gain = 486},
		{Value = 200002, Base = 37, Gain = 8},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "受水元素敌人伤害 -50%",
		Skill = {
			{
				Id = 105033,
				Value = -50,
			},
		},
	},
	Tags = {
		560111,
		564556,
	},
}
EnemyConfig[EnemyID.Id6078] =
{
	Id = 6078,
	Name = "毛桃几",
	Rarity = 1,
	Element = 210003,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：散播会引发鼻炎的绒毛。",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	IconName = "Arena_FAT_Peach",
	PrefabBundle = "character_arenaenemy",
	PrefabName = "Arena_FAT_Peach",
	PrefabScale = 50,
	HPBarHeight = 97,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 3160, Gain = 632},
		{Value = 200002, Base = 41, Gain = 9},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "受水元素敌人伤害 -50%",
		Skill = {
			{
				Id = 105033,
				Value = -50,
			},
		},
	},
	Tags = {
		560111,
		564556,
	},
}
EnemyConfig[EnemyID.Id6079] =
{
	Id = 6079,
	Name = "化学梨几",
	Rarity = 1,
	Element = 210003,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：表皮具有腐蚀性。",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	IconName = "Arena_FAT_Pear",
	PrefabBundle = "character_arenaenemy",
	PrefabName = "Arena_FAT_Pear",
	PrefabScale = 50,
	HPBarHeight = 120,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 2124, Gain = 425},
		{Value = 200002, Base = 33, Gain = 7},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "暴击 +120",
		Skill = {
			{
				Id = 105004,
				Value = 120,
			},
		},
	},
	Tags = {
		560111,
		564556,
		564561,
	},
}
EnemyConfig[EnemyID.Id6080] =
{
	Id = 6080,
	Name = "化学梨几",
	Rarity = 1,
	Element = 210003,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：表皮具有腐蚀性。",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	IconName = "Arena_FAT_Pear",
	PrefabBundle = "character_arenaenemy",
	PrefabName = "Arena_FAT_Pear",
	PrefabScale = 50,
	HPBarHeight = 120,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 2314, Gain = 463},
		{Value = 200002, Base = 36, Gain = 8},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "暴击 +120",
		Skill = {
			{
				Id = 105004,
				Value = 120,
			},
		},
	},
	Tags = {
		560111,
		564556,
		564561,
	},
}
EnemyConfig[EnemyID.Id6081] =
{
	Id = 6081,
	Name = "化学梨几",
	Rarity = 1,
	Element = 210003,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：表皮具有腐蚀性。",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	IconName = "Arena_FAT_Pear",
	PrefabBundle = "character_arenaenemy",
	PrefabName = "Arena_FAT_Pear",
	PrefabScale = 50,
	HPBarHeight = 120,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 2990, Gain = 598},
		{Value = 200002, Base = 39, Gain = 8},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "暴击 +120",
		Skill = {
			{
				Id = 105004,
				Value = 120,
			},
		},
	},
	Tags = {
		560111,
		564556,
		564561,
	},
}
EnemyConfig[EnemyID.Id6082] =
{
	Id = 6082,
	Name = "腐败苹狗",
	Rarity = 1,
	Element = 210003,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：用烂苹果做果汁卖给口渴的路人。",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	IconName = "Arena_FAT_Apple",
	PrefabBundle = "character_arenaenemy",
	PrefabName = "Arena_FAT_Apple",
	PrefabScale = 50,
	HPBarHeight = 120,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 2124, Gain = 425},
		{Value = 200002, Base = 33, Gain = 7},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "5回合后，自身属性变为水元素\n受风元素敌人伤害 -50%",
		Skill = {
			{
				Id = 105156,
				Value = 210001,
			},
			{
				Id = 105035,
				Value = -50,
			},
		},
	},
	Tags = {
		560111,
		564556,
	},
}
EnemyConfig[EnemyID.Id6083] =
{
	Id = 6083,
	Name = "腐败苹狗",
	Rarity = 1,
	Element = 210003,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：用烂苹果做果汁卖给口渴的路人。",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	IconName = "Arena_FAT_Apple",
	PrefabBundle = "character_arenaenemy",
	PrefabName = "Arena_FAT_Apple",
	PrefabScale = 50,
	HPBarHeight = 120,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 2314, Gain = 463},
		{Value = 200002, Base = 36, Gain = 8},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "5回合后，自身属性变为水元素\n受风元素敌人伤害 -50%",
		Skill = {
			{
				Id = 105156,
				Value = 210001,
			},
			{
				Id = 105035,
				Value = -50,
			},
		},
	},
	Tags = {
		560111,
		564556,
	},
}
EnemyConfig[EnemyID.Id6084] =
{
	Id = 6084,
	Name = "腐败苹狗",
	Rarity = 1,
	Element = 210003,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：用烂苹果做果汁卖给口渴的路人。",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	IconName = "Arena_FAT_Apple",
	PrefabBundle = "character_arenaenemy",
	PrefabName = "Arena_FAT_Apple",
	PrefabScale = 50,
	HPBarHeight = 120,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 2990, Gain = 598},
		{Value = 200002, Base = 39, Gain = 8},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "5回合后，自身属性变为水元素\n受风元素敌人伤害 -50%",
		Skill = {
			{
				Id = 105156,
				Value = 210001,
			},
			{
				Id = 105035,
				Value = -50,
			},
		},
	},
	Tags = {
		560111,
		564556,
	},
}
EnemyConfig[EnemyID.Id6085] =
{
	Id = 6085,
	Name = "咸鱼头",
	Rarity = 2,
	Element = 210002,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：在吉利的日子里，去人家家门口说不吉利的话。",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	IconName = "Arena_FAT_FishHead",
	PrefabBundle = "character_arenaenemy",
	PrefabName = "Arena_FAT_FishHead",
	PrefabScale = 50,
	HPBarHeight = 125,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 2040, Gain = 408},
		{Value = 200002, Base = 32, Gain = 7},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "每回合攻击 +8%，最多5次\n每3回合对前2个队员造成80%攻击伤害",
		Skill = {
			{
				Id = 105006,
				Value = 8,
			},
			{
				Id = 105056,
				Value = 80,
			},
		},
	},
	Tags = {
		560111,
		564556,
		564561,
	},
}
EnemyConfig[EnemyID.Id6086] =
{
	Id = 6086,
	Name = "咸鱼头",
	Rarity = 2,
	Element = 210002,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：在吉利的日子里，去人家家门口说不吉利的话。",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	IconName = "Arena_FAT_FishHead",
	PrefabBundle = "character_arenaenemy",
	PrefabName = "Arena_FAT_FishHead",
	PrefabScale = 50,
	HPBarHeight = 125,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 2209, Gain = 442},
		{Value = 200002, Base = 35, Gain = 7},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "每回合攻击 +8%，最多5次\n每3回合对前2个队员造成80%攻击伤害",
		Skill = {
			{
				Id = 105006,
				Value = 8,
			},
			{
				Id = 105056,
				Value = 80,
			},
		},
	},
	Tags = {
		560111,
		564556,
		564561,
	},
}
EnemyConfig[EnemyID.Id6087] =
{
	Id = 6087,
	Name = "咸鱼头",
	Rarity = 2,
	Element = 210002,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：在吉利的日子里，去人家家门口说不吉利的话。",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	IconName = "Arena_FAT_FishHead",
	PrefabBundle = "character_arenaenemy",
	PrefabName = "Arena_FAT_FishHead",
	PrefabScale = 50,
	HPBarHeight = 125,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 2837, Gain = 568},
		{Value = 200002, Base = 38, Gain = 8},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "每回合攻击 +8%，最多5次\n每3回合对前2个队员造成80%攻击伤害",
		Skill = {
			{
				Id = 105006,
				Value = 8,
			},
			{
				Id = 105056,
				Value = 80,
			},
		},
	},
	Tags = {
		560111,
		564556,
		564561,
	},
}
EnemyConfig[EnemyID.Id6088] =
{
	Id = 6088,
	Name = "咸鱼尾",
	Rarity = 2,
	Element = 210002,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：伪装成馅料很多的样子欺骗消费者。",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	IconName = "Arena_FAT_FishTail",
	PrefabBundle = "character_arenaenemy",
	PrefabName = "Arena_FAT_FishTail",
	PrefabScale = 50,
	HPBarHeight = 125,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 2040, Gain = 408},
		{Value = 200002, Base = 32, Gain = 7},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "每回合回血 8%，最多5次\n每3回合对后2个队员造成80%攻击伤害",
		Skill = {
			{
				Id = 105005,
				Value = 8,
			},
			{
				Id = 105060,
				Value = 80,
			},
		},
	},
	Tags = {
		560111,
		564556,
		564560,
	},
}
EnemyConfig[EnemyID.Id6089] =
{
	Id = 6089,
	Name = "咸鱼尾",
	Rarity = 2,
	Element = 210002,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：伪装成馅料很多的样子欺骗消费者。",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	IconName = "Arena_FAT_FishTail",
	PrefabBundle = "character_arenaenemy",
	PrefabName = "Arena_FAT_FishTail",
	PrefabScale = 50,
	HPBarHeight = 125,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 2209, Gain = 442},
		{Value = 200002, Base = 35, Gain = 7},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "每回合回血 8%，最多5次\n每3回合对后2个队员造成80%攻击伤害",
		Skill = {
			{
				Id = 105005,
				Value = 8,
			},
			{
				Id = 105060,
				Value = 80,
			},
		},
	},
	Tags = {
		560111,
		564556,
		564560,
	},
}
EnemyConfig[EnemyID.Id6090] =
{
	Id = 6090,
	Name = "咸鱼尾",
	Rarity = 2,
	Element = 210002,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：伪装成馅料很多的样子欺骗消费者。",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	IconName = "Arena_FAT_FishTail",
	PrefabBundle = "character_arenaenemy",
	PrefabName = "Arena_FAT_FishTail",
	PrefabScale = 50,
	HPBarHeight = 125,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 2837, Gain = 568},
		{Value = 200002, Base = 38, Gain = 8},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "每回合回血 8%，最多5次\n每3回合对后2个队员造成80%攻击伤害",
		Skill = {
			{
				Id = 105005,
				Value = 8,
			},
			{
				Id = 105060,
				Value = 80,
			},
		},
	},
	Tags = {
		560111,
		564556,
		564560,
	},
}
EnemyConfig[EnemyID.Id6091] =
{
	Id = 6091,
	Name = "落地冰淇淋",
	Rarity = 2,
	Element = 210001,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：在马路上洒成一滩，造成非常严重的交通事故。",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	IconName = "Arena_FAT_ChocolateIceCream",
	PrefabBundle = "character_arenaenemy",
	PrefabName = "Arena_FAT_ChocolateIceCream",
	PrefabScale = 50,
	HPBarHeight = 125,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 1963, Gain = 393},
		{Value = 200002, Base = 31, Gain = 7},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "5回合后，自身属性变为暗元素\n受水元素敌人伤害 -50%",
		Skill = {
			{
				Id = 105160,
				Value = 210005,
			},
			{
				Id = 105033,
				Value = -50,
			},
		},
	},
	Tags = {
		560111,
		564556,
	},
}
EnemyConfig[EnemyID.Id6092] =
{
	Id = 6092,
	Name = "落地冰淇淋",
	Rarity = 2,
	Element = 210001,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：在马路上洒成一滩，造成非常严重的交通事故。",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	IconName = "Arena_FAT_ChocolateIceCream",
	PrefabBundle = "character_arenaenemy",
	PrefabName = "Arena_FAT_ChocolateIceCream",
	PrefabScale = 50,
	HPBarHeight = 125,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 2113, Gain = 423},
		{Value = 200002, Base = 34, Gain = 7},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "5回合后，自身属性变为暗元素\n受水元素敌人伤害 -50%",
		Skill = {
			{
				Id = 105160,
				Value = 210005,
			},
			{
				Id = 105033,
				Value = -50,
			},
		},
	},
	Tags = {
		560111,
		564556,
	},
}
EnemyConfig[EnemyID.Id6093] =
{
	Id = 6093,
	Name = "落地冰淇淋",
	Rarity = 2,
	Element = 210001,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：在马路上洒成一滩，造成非常严重的交通事故。",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	IconName = "Arena_FAT_ChocolateIceCream",
	PrefabBundle = "character_arenaenemy",
	PrefabName = "Arena_FAT_ChocolateIceCream",
	PrefabScale = 50,
	HPBarHeight = 125,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 2699, Gain = 540},
		{Value = 200002, Base = 37, Gain = 8},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "5回合后，自身属性变为暗元素\n受水元素敌人伤害 -50%",
		Skill = {
			{
				Id = 105160,
				Value = 210005,
			},
			{
				Id = 105033,
				Value = -50,
			},
		},
	},
	Tags = {
		560111,
		564556,
	},
}
EnemyConfig[EnemyID.Id6094] =
{
	Id = 6094,
	Name = "泥浆冰淇淋",
	Rarity = 2,
	Element = 210001,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：星际非法移民。",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	IconName = "Arena_FAT_GreenTeaIceCream",
	PrefabBundle = "character_arenaenemy",
	PrefabName = "Arena_FAT_GreenTeaIceCream",
	PrefabScale = 50,
	HPBarHeight = 125,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 2049, Gain = 410},
		{Value = 200002, Base = 35, Gain = 7},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "33%概率闪避攻击\n生命 +100%",
		Skill = {
			{
				Id = 105026,
				Value = 33,
			},
			{
				Id = 105001,
				Value = 100,
			},
		},
	},
	Tags = {
		560111,
		564555,
		564557,
		564561,
	},
}
EnemyConfig[EnemyID.Id6095] =
{
	Id = 6095,
	Name = "泥浆冰淇淋",
	Rarity = 2,
	Element = 210001,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：星际非法移民。",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	IconName = "Arena_FAT_GreenTeaIceCream",
	PrefabBundle = "character_arenaenemy",
	PrefabName = "Arena_FAT_GreenTeaIceCream",
	PrefabScale = 50,
	HPBarHeight = 125,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 2534, Gain = 507},
		{Value = 200002, Base = 36, Gain = 8},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "33%概率闪避攻击\n生命 +100%",
		Skill = {
			{
				Id = 105026,
				Value = 33,
			},
			{
				Id = 105001,
				Value = 100,
			},
		},
	},
	Tags = {
		560111,
		564555,
		564557,
		564561,
	},
}
EnemyConfig[EnemyID.Id6096] =
{
	Id = 6096,
	Name = "泥浆冰淇淋",
	Rarity = 2,
	Element = 210001,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：星际非法移民。",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	IconName = "Arena_FAT_GreenTeaIceCream",
	PrefabBundle = "character_arenaenemy",
	PrefabName = "Arena_FAT_GreenTeaIceCream",
	PrefabScale = 50,
	HPBarHeight = 125,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 2975, Gain = 595},
		{Value = 200002, Base = 37, Gain = 8},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "33%概率闪避攻击\n生命 +100%",
		Skill = {
			{
				Id = 105026,
				Value = 33,
			},
			{
				Id = 105001,
				Value = 100,
			},
		},
	},
	Tags = {
		560111,
		564555,
		564557,
		564561,
	},
}
EnemyConfig[EnemyID.Id6097] =
{
	Id = 6097,
	Name = "弹珠军舰",
	Rarity = 2,
	Element = 210005,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：使用弹力超强的橡皮糖假冒鱼子制作军舰寿司卖给食客。",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	IconName = "Arena_FAT_FishRoeWarshipSushi",
	PrefabBundle = "character_arenaenemy",
	PrefabName = "Arena_FAT_FishRoeWarshipSushi",
	PrefabScale = 50,
	HPBarHeight = 125,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 2049, Gain = 410},
		{Value = 200002, Base = 35, Gain = 7},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "受暗元素敌人伤害 -50%\n每3回合对所有队员造成75%攻击伤害",
		Skill = {
			{
				Id = 105037,
				Value = -50,
			},
			{
				Id = 105063,
				Value = 75,
			},
		},
	},
	Tags = {
		560111,
		564555,
	},
}
EnemyConfig[EnemyID.Id6098] =
{
	Id = 6098,
	Name = "弹珠军舰",
	Rarity = 2,
	Element = 210005,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：使用弹力超强的橡皮糖假冒鱼子制作军舰寿司卖给食客。",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	IconName = "Arena_FAT_FishRoeWarshipSushi",
	PrefabBundle = "character_arenaenemy",
	PrefabName = "Arena_FAT_FishRoeWarshipSushi",
	PrefabScale = 50,
	HPBarHeight = 125,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 2534, Gain = 507},
		{Value = 200002, Base = 36, Gain = 8},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "受暗元素敌人伤害 -50%\n每3回合对所有队员造成75%攻击伤害",
		Skill = {
			{
				Id = 105037,
				Value = -50,
			},
			{
				Id = 105063,
				Value = 75,
			},
		},
	},
	Tags = {
		560111,
		564555,
	},
}
EnemyConfig[EnemyID.Id6099] =
{
	Id = 6099,
	Name = "弹珠军舰",
	Rarity = 2,
	Element = 210005,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：使用弹力超强的橡皮糖假冒鱼子制作军舰寿司卖给食客。",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	IconName = "Arena_FAT_FishRoeWarshipSushi",
	PrefabBundle = "character_arenaenemy",
	PrefabName = "Arena_FAT_FishRoeWarshipSushi",
	PrefabScale = 50,
	HPBarHeight = 125,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 2975, Gain = 595},
		{Value = 200002, Base = 37, Gain = 8},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "受暗元素敌人伤害 -50%\n每3回合对所有队员造成75%攻击伤害",
		Skill = {
			{
				Id = 105037,
				Value = -50,
			},
			{
				Id = 105063,
				Value = 75,
			},
		},
	},
	Tags = {
		560111,
		564555,
	},
}
EnemyConfig[EnemyID.Id6100] =
{
	Id = 6100,
	Name = "变心糖",
	Rarity = 2,
	Element = 210003,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：同时和多个女生交往。",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	IconName = "Arena_FAT_LaffyTaffy",
	PrefabBundle = "character_arenaenemy",
	PrefabName = "Arena_FAT_LaffyTaffy",
	PrefabScale = 50,
	HPBarHeight = 125,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 2293, Gain = 459},
		{Value = 200002, Base = 37, Gain = 8},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "每3回合有50%概率对末位队员造成50%攻击伤害\n33%概率闪避攻击",
		Skill = {
			{
				Id = 105099,
				Value = 50,
			},
			{
				Id = 105026,
				Value = 33,
			},
		},
	},
	Tags = {
		560111,
		564556,
		564557,
	},
}
EnemyConfig[EnemyID.Id6101] =
{
	Id = 6101,
	Name = "变心糖",
	Rarity = 2,
	Element = 210003,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：同时和多个女生交往。",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	IconName = "Arena_FAT_LaffyTaffy",
	PrefabBundle = "character_arenaenemy",
	PrefabName = "Arena_FAT_LaffyTaffy",
	PrefabScale = 50,
	HPBarHeight = 125,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 2442, Gain = 489},
		{Value = 200002, Base = 40, Gain = 8},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "每3回合有50%概率对末位队员造成50%攻击伤害\n33%概率闪避攻击",
		Skill = {
			{
				Id = 105099,
				Value = 50,
			},
			{
				Id = 105026,
				Value = 33,
			},
		},
	},
	Tags = {
		560111,
		564556,
		564557,
	},
}
EnemyConfig[EnemyID.Id6102] =
{
	Id = 6102,
	Name = "变心糖",
	Rarity = 2,
	Element = 210003,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：同时和多个女生交往。",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	IconName = "Arena_FAT_LaffyTaffy",
	PrefabBundle = "character_arenaenemy",
	PrefabName = "Arena_FAT_LaffyTaffy",
	PrefabScale = 50,
	HPBarHeight = 125,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 3091, Gain = 619},
		{Value = 200002, Base = 44, Gain = 9},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "每3回合有50%概率对末位队员造成50%攻击伤害\n33%概率闪避攻击",
		Skill = {
			{
				Id = 105099,
				Value = 50,
			},
			{
				Id = 105026,
				Value = 33,
			},
		},
	},
	Tags = {
		560111,
		564556,
		564557,
	},
}
EnemyConfig[EnemyID.Id6103] =
{
	Id = 6103,
	Name = "黑心糖",
	Rarity = 3,
	Element = 210003,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：非常难吃，还经常装成好吃的糖果骗人品尝。",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	IconName = "Arena_FAT_Toffee",
	PrefabBundle = "character_arenaenemy",
	PrefabName = "Arena_FAT_Toffee",
	PrefabScale = 50,
	HPBarHeight = 80,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 2293, Gain = 459},
		{Value = 200002, Base = 37, Gain = 8},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "有30%概率额外攻击1次\n攻击 +50%",
		Skill = {
			{
				Id = 105023,
				Value = 30,
			},
			{
				Id = 105002,
				Value = 50,
			},
		},
	},
	Tags = {
		560111,
		564556,
		564558,
		564561,
	},
}
EnemyConfig[EnemyID.Id6104] =
{
	Id = 6104,
	Name = "黑心糖",
	Rarity = 3,
	Element = 210003,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：非常难吃，还经常装成好吃的糖果骗人品尝。",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	IconName = "Arena_FAT_Toffee",
	PrefabBundle = "character_arenaenemy",
	PrefabName = "Arena_FAT_Toffee",
	PrefabScale = 50,
	HPBarHeight = 80,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 2442, Gain = 489},
		{Value = 200002, Base = 40, Gain = 8},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "有30%概率额外攻击1次\n攻击 +50%",
		Skill = {
			{
				Id = 105023,
				Value = 30,
			},
			{
				Id = 105002,
				Value = 50,
			},
		},
	},
	Tags = {
		560111,
		564556,
		564558,
		564561,
	},
}
EnemyConfig[EnemyID.Id6105] =
{
	Id = 6105,
	Name = "黑心糖",
	Rarity = 3,
	Element = 210003,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：非常难吃，还经常装成好吃的糖果骗人品尝。",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	IconName = "Arena_FAT_Toffee",
	PrefabBundle = "character_arenaenemy",
	PrefabName = "Arena_FAT_Toffee",
	PrefabScale = 50,
	HPBarHeight = 80,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 3091, Gain = 619},
		{Value = 200002, Base = 44, Gain = 9},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "有30%概率额外攻击1次\n攻击 +50%",
		Skill = {
			{
				Id = 105023,
				Value = 30,
			},
			{
				Id = 105002,
				Value = 50,
			},
		},
	},
	Tags = {
		560111,
		564556,
		564558,
		564561,
	},
}
EnemyConfig[EnemyID.Id6106] =
{
	Id = 6106,
	Name = "培根老赖",
	Rarity = 2,
	Element = 210002,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：在街上故意把酱料蹭到别人新买的衣服上。",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	IconName = "Arena_FAT_Bacon",
	PrefabBundle = "character_arenaenemy",
	PrefabName = "Arena_FAT_Bacon",
	PrefabScale = 50,
	HPBarHeight = 125,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 2215, Gain = 443},
		{Value = 200002, Base = 36, Gain = 8},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "每回合攻击 +15%，最多5次\n33%概率闪避攻击",
		Skill = {
			{
				Id = 105006,
				Value = 15,
			},
			{
				Id = 105026,
				Value = 33,
			},
		},
	},
	Tags = {
		560111,
		564556,
		564557,
		564561,
	},
}
EnemyConfig[EnemyID.Id6107] =
{
	Id = 6107,
	Name = "培根老赖",
	Rarity = 2,
	Element = 210002,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：在街上故意把酱料蹭到别人新买的衣服上。",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	IconName = "Arena_FAT_Bacon",
	PrefabBundle = "character_arenaenemy",
	PrefabName = "Arena_FAT_Bacon",
	PrefabScale = 50,
	HPBarHeight = 125,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 2348, Gain = 470},
		{Value = 200002, Base = 40, Gain = 8},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "每回合攻击 +15%，最多5次\n33%概率闪避攻击",
		Skill = {
			{
				Id = 105006,
				Value = 15,
			},
			{
				Id = 105026,
				Value = 33,
			},
		},
	},
	Tags = {
		560111,
		564556,
		564557,
		564561,
	},
}
EnemyConfig[EnemyID.Id6108] =
{
	Id = 6108,
	Name = "培根老赖",
	Rarity = 2,
	Element = 210002,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：在街上故意把酱料蹭到别人新买的衣服上。",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	IconName = "Arena_FAT_Bacon",
	PrefabBundle = "character_arenaenemy",
	PrefabName = "Arena_FAT_Bacon",
	PrefabScale = 50,
	HPBarHeight = 125,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 2960, Gain = 592},
		{Value = 200002, Base = 43, Gain = 9},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "每回合攻击 +15%，最多5次\n33%概率闪避攻击",
		Skill = {
			{
				Id = 105006,
				Value = 15,
			},
			{
				Id = 105026,
				Value = 33,
			},
		},
	},
	Tags = {
		560111,
		564556,
		564557,
		564561,
	},
}
EnemyConfig[EnemyID.Id6109] =
{
	Id = 6109,
	Name = "急冻冰淇淋",
	Rarity = 2,
	Element = 210001,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：兜售只要舔一口就会三叉神经痛的超级冰球给路人。",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	IconName = "Arena_FAT_IceCream",
	PrefabBundle = "character_arenaenemy",
	PrefabName = "Arena_FAT_IceCream",
	PrefabScale = 50,
	HPBarHeight = 125,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 2215, Gain = 443},
		{Value = 200002, Base = 36, Gain = 8},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "受风元素敌人伤害 -75%\n受光元素敌人伤害 -75%",
		Skill = {
			{
				Id = 105035,
				Value = -75,
			},
			{
				Id = 105036,
				Value = -75,
			},
		},
	},
	Tags = {
		560111,
		564556,
	},
}
EnemyConfig[EnemyID.Id6110] =
{
	Id = 6110,
	Name = "急冻冰淇淋",
	Rarity = 2,
	Element = 210001,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：兜售只要舔一口就会三叉神经痛的超级冰球给路人。",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	IconName = "Arena_FAT_IceCream",
	PrefabBundle = "character_arenaenemy",
	PrefabName = "Arena_FAT_IceCream",
	PrefabScale = 50,
	HPBarHeight = 125,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 2348, Gain = 470},
		{Value = 200002, Base = 40, Gain = 8},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "受风元素敌人伤害 -75%\n受光元素敌人伤害 -75%",
		Skill = {
			{
				Id = 105035,
				Value = -75,
			},
			{
				Id = 105036,
				Value = -75,
			},
		},
	},
	Tags = {
		560111,
		564556,
	},
}
EnemyConfig[EnemyID.Id6111] =
{
	Id = 6111,
	Name = "急冻冰淇淋",
	Rarity = 2,
	Element = 210001,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：兜售只要舔一口就会三叉神经痛的超级冰球给路人。",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	IconName = "Arena_FAT_IceCream",
	PrefabBundle = "character_arenaenemy",
	PrefabName = "Arena_FAT_IceCream",
	PrefabScale = 50,
	HPBarHeight = 125,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 2960, Gain = 592},
		{Value = 200002, Base = 43, Gain = 9},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "受风元素敌人伤害 -75%\n受光元素敌人伤害 -75%",
		Skill = {
			{
				Id = 105035,
				Value = -75,
			},
			{
				Id = 105036,
				Value = -75,
			},
		},
	},
	Tags = {
		560111,
		564556,
	},
}
EnemyConfig[EnemyID.Id6112] =
{
	Id = 6112,
	Name = "馊饭团",
	Rarity = 2,
	Element = 210005,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：贩卖超过保质期的饭团给肚子饿的路人。",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	IconName = "Arena_FAT_RiceBall",
	PrefabBundle = "character_arenaenemy",
	PrefabName = "Arena_FAT_RiceBall",
	PrefabScale = 50,
	HPBarHeight = 82,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 2142, Gain = 429},
		{Value = 200002, Base = 36, Gain = 8},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "每3回合回血 20%，最多5次\n受光元素敌人伤害 -100%",
		Skill = {
			{
				Id = 105009,
				Value = 20,
			},
			{
				Id = 105036,
				Value = -100,
			},
		},
	},
	Tags = {
		560111,
		564556,
		564560,
	},
}
EnemyConfig[EnemyID.Id6113] =
{
	Id = 6113,
	Name = "馊饭团",
	Rarity = 2,
	Element = 210005,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：贩卖超过保质期的饭团给肚子饿的路人。",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	IconName = "Arena_FAT_RiceBall",
	PrefabBundle = "character_arenaenemy",
	PrefabName = "Arena_FAT_RiceBall",
	PrefabScale = 50,
	HPBarHeight = 82,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 2261, Gain = 453},
		{Value = 200002, Base = 39, Gain = 8},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "每3回合回血 20%，最多5次\n受光元素敌人伤害 -100%",
		Skill = {
			{
				Id = 105009,
				Value = 20,
			},
			{
				Id = 105036,
				Value = -100,
			},
		},
	},
	Tags = {
		560111,
		564556,
		564560,
	},
}
EnemyConfig[EnemyID.Id6114] =
{
	Id = 6114,
	Name = "馊饭团",
	Rarity = 2,
	Element = 210005,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：贩卖超过保质期的饭团给肚子饿的路人。",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	IconName = "Arena_FAT_RiceBall",
	PrefabBundle = "character_arenaenemy",
	PrefabName = "Arena_FAT_RiceBall",
	PrefabScale = 50,
	HPBarHeight = 82,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 2840, Gain = 568},
		{Value = 200002, Base = 42, Gain = 9},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "每3回合回血 20%，最多5次\n受光元素敌人伤害 -100%",
		Skill = {
			{
				Id = 105009,
				Value = 20,
			},
			{
				Id = 105036,
				Value = -100,
			},
		},
	},
	Tags = {
		560111,
		564556,
		564560,
	},
}
EnemyConfig[EnemyID.Id6115] =
{
	Id = 6115,
	Name = "扮鬼饭团",
	Rarity = 2,
	Element = 210005,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：凌晨躲在办公区树丛里跳出来吓加班回来的人。",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	IconName = "Arena_FAT_BlackRiceBall",
	PrefabBundle = "character_arenaenemy",
	PrefabName = "Arena_FAT_BlackRiceBall",
	PrefabScale = 50,
	HPBarHeight = 125,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 2142, Gain = 429},
		{Value = 200002, Base = 36, Gain = 8},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "每回合有50%概率对末位队员造成150%攻击伤害\n受光元素敌人伤害 -50%",
		Skill = {
			{
				Id = 105083,
				Value = 150,
			},
			{
				Id = 105036,
				Value = -50,
			},
		},
	},
	Tags = {
		560111,
		564556,
	},
}
EnemyConfig[EnemyID.Id6116] =
{
	Id = 6116,
	Name = "扮鬼饭团",
	Rarity = 2,
	Element = 210005,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：凌晨躲在办公区树丛里跳出来吓加班回来的人。",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	IconName = "Arena_FAT_BlackRiceBall",
	PrefabBundle = "character_arenaenemy",
	PrefabName = "Arena_FAT_BlackRiceBall",
	PrefabScale = 50,
	HPBarHeight = 125,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 2261, Gain = 453},
		{Value = 200002, Base = 39, Gain = 8},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "每回合有50%概率对末位队员造成150%攻击伤害\n受光元素敌人伤害 -50%",
		Skill = {
			{
				Id = 105083,
				Value = 150,
			},
			{
				Id = 105036,
				Value = -50,
			},
		},
	},
	Tags = {
		560111,
		564556,
	},
}
EnemyConfig[EnemyID.Id6117] =
{
	Id = 6117,
	Name = "扮鬼饭团",
	Rarity = 2,
	Element = 210005,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：凌晨躲在办公区树丛里跳出来吓加班回来的人。",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	IconName = "Arena_FAT_BlackRiceBall",
	PrefabBundle = "character_arenaenemy",
	PrefabName = "Arena_FAT_BlackRiceBall",
	PrefabScale = 50,
	HPBarHeight = 125,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 2840, Gain = 568},
		{Value = 200002, Base = 42, Gain = 9},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "每回合有50%概率对末位队员造成150%攻击伤害\n受光元素敌人伤害 -50%",
		Skill = {
			{
				Id = 105083,
				Value = 150,
			},
			{
				Id = 105036,
				Value = -50,
			},
		},
	},
	Tags = {
		560111,
		564556,
	},
}
EnemyConfig[EnemyID.Id6118] =
{
	Id = 6118,
	Name = "变质饭团",
	Rarity = 2,
	Element = 210005,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：躲进人家的下水道，造成管道堵塞。",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	IconName = "Arena_FAT_CabbageRiceBall",
	PrefabBundle = "character_arenaenemy",
	PrefabName = "Arena_FAT_CabbageRiceBall",
	PrefabScale = 50,
	HPBarHeight = 82,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 2142, Gain = 429},
		{Value = 200002, Base = 36, Gain = 8},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "暴击伤害 +200%\n受光元素敌人伤害 -100%",
		Skill = {
			{
				Id = 105038,
				Value = 200,
			},
			{
				Id = 105036,
				Value = -100,
			},
		},
	},
	Tags = {
		560111,
		564556,
	},
}
EnemyConfig[EnemyID.Id6119] =
{
	Id = 6119,
	Name = "变质饭团",
	Rarity = 2,
	Element = 210005,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：躲进人家的下水道，造成管道堵塞。",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	IconName = "Arena_FAT_CabbageRiceBall",
	PrefabBundle = "character_arenaenemy",
	PrefabName = "Arena_FAT_CabbageRiceBall",
	PrefabScale = 50,
	HPBarHeight = 82,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 2261, Gain = 453},
		{Value = 200002, Base = 39, Gain = 8},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "暴击伤害 +200%\n受光元素敌人伤害 -100%",
		Skill = {
			{
				Id = 105038,
				Value = 200,
			},
			{
				Id = 105036,
				Value = -100,
			},
		},
	},
	Tags = {
		560111,
		564556,
	},
}
EnemyConfig[EnemyID.Id6120] =
{
	Id = 6120,
	Name = "变质饭团",
	Rarity = 2,
	Element = 210005,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：躲进人家的下水道，造成管道堵塞。",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	IconName = "Arena_FAT_CabbageRiceBall",
	PrefabBundle = "character_arenaenemy",
	PrefabName = "Arena_FAT_CabbageRiceBall",
	PrefabScale = 50,
	HPBarHeight = 82,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 2840, Gain = 568},
		{Value = 200002, Base = 42, Gain = 9},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "暴击伤害 +200%\n受光元素敌人伤害 -100%",
		Skill = {
			{
				Id = 105038,
				Value = 200,
			},
			{
				Id = 105036,
				Value = -100,
			},
		},
	},
	Tags = {
		560111,
		564556,
	},
}
EnemyConfig[EnemyID.Id6121] =
{
	Id = 6121,
	Name = "注水龟龟",
	Rarity = 2,
	Element = 210004,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：在自己的小店中卖出注水率500%的劣质肉品。",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	IconName = "Arena_FAT_EggSushi",
	PrefabBundle = "character_arenaenemy",
	PrefabName = "Arena_FAT_EggSushi",
	PrefabScale = 50,
	HPBarHeight = 90,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 2074, Gain = 415},
		{Value = 200002, Base = 35, Gain = 7},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "每回合回血 5%，最多5次\n5回合后，回血 50%",
		Skill = {
			{
				Id = 105005,
				Value = 5,
			},
			{
				Id = 105013,
				Value = 50,
			},
		},
	},
	Tags = {
		560111,
		564556,
		564560,
	},
}
EnemyConfig[EnemyID.Id6122] =
{
	Id = 6122,
	Name = "注水龟龟",
	Rarity = 2,
	Element = 210004,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：在自己的小店中卖出注水率500%的劣质肉品。",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	IconName = "Arena_FAT_EggSushi",
	PrefabBundle = "character_arenaenemy",
	PrefabName = "Arena_FAT_EggSushi",
	PrefabScale = 50,
	HPBarHeight = 90,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 2180, Gain = 436},
		{Value = 200002, Base = 38, Gain = 8},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "每回合回血 5%，最多5次\n5回合后，回血 50%",
		Skill = {
			{
				Id = 105005,
				Value = 5,
			},
			{
				Id = 105013,
				Value = 50,
			},
		},
	},
	Tags = {
		560111,
		564556,
		564560,
	},
}
EnemyConfig[EnemyID.Id6123] =
{
	Id = 6123,
	Name = "注水龟龟",
	Rarity = 2,
	Element = 210004,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：在自己的小店中卖出注水率500%的劣质肉品。",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	IconName = "Arena_FAT_EggSushi",
	PrefabBundle = "character_arenaenemy",
	PrefabName = "Arena_FAT_EggSushi",
	PrefabScale = 50,
	HPBarHeight = 90,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 2729, Gain = 546},
		{Value = 200002, Base = 42, Gain = 9},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "每回合回血 5%，最多5次\n5回合后，回血 50%",
		Skill = {
			{
				Id = 105005,
				Value = 5,
			},
			{
				Id = 105013,
				Value = 50,
			},
		},
	},
	Tags = {
		560111,
		564556,
		564560,
	},
}
EnemyConfig[EnemyID.Id6124] =
{
	Id = 6124,
	Name = "肥肉龟龟",
	Rarity = 2,
	Element = 210004,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：使用全肥肉冒充五花肉制作寿司，卖给食客。",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	IconName = "Arena_FAT_SalmonSushi",
	PrefabBundle = "character_arenaenemy",
	PrefabName = "Arena_FAT_SalmonSushi",
	PrefabScale = 50,
	HPBarHeight = 80,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 2074, Gain = 415},
		{Value = 200002, Base = 35, Gain = 7},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "每回合回血 5%，最多5次\n生命 +30%",
		Skill = {
			{
				Id = 105005,
				Value = 5,
			},
			{
				Id = 105001,
				Value = 30,
			},
		},
	},
	Tags = {
		560111,
		564556,
		564560,
		564561,
	},
}
EnemyConfig[EnemyID.Id6125] =
{
	Id = 6125,
	Name = "肥肉龟龟",
	Rarity = 2,
	Element = 210004,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：使用全肥肉冒充五花肉制作寿司，卖给食客。",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	IconName = "Arena_FAT_SalmonSushi",
	PrefabBundle = "character_arenaenemy",
	PrefabName = "Arena_FAT_SalmonSushi",
	PrefabScale = 50,
	HPBarHeight = 80,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 2180, Gain = 436},
		{Value = 200002, Base = 38, Gain = 8},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "每回合回血 5%，最多5次\n生命 +30%",
		Skill = {
			{
				Id = 105005,
				Value = 5,
			},
			{
				Id = 105001,
				Value = 30,
			},
		},
	},
	Tags = {
		560111,
		564556,
		564560,
		564561,
	},
}
EnemyConfig[EnemyID.Id6126] =
{
	Id = 6126,
	Name = "肥肉龟龟",
	Rarity = 2,
	Element = 210004,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：使用全肥肉冒充五花肉制作寿司，卖给食客。",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	IconName = "Arena_FAT_SalmonSushi",
	PrefabBundle = "character_arenaenemy",
	PrefabName = "Arena_FAT_SalmonSushi",
	PrefabScale = 50,
	HPBarHeight = 80,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 2729, Gain = 546},
		{Value = 200002, Base = 42, Gain = 9},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "每回合回血 5%，最多5次\n生命 +30%",
		Skill = {
			{
				Id = 105005,
				Value = 5,
			},
			{
				Id = 105001,
				Value = 30,
			},
		},
	},
	Tags = {
		560111,
		564556,
		564560,
		564561,
	},
}
EnemyConfig[EnemyID.Id6127] =
{
	Id = 6127,
	Name = "臭虾龟龟",
	Rarity = 2,
	Element = 210004,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：为了省钱买了劣质的冰柜储存鲜虾，还将这种虾加了很多调料卖给食客。",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	IconName = "Arena_FAT_ShrimpSushi",
	PrefabBundle = "character_arenaenemy",
	PrefabName = "Arena_FAT_ShrimpSushi",
	PrefabScale = 50,
	HPBarHeight = 80,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 2074, Gain = 415},
		{Value = 200002, Base = 35, Gain = 7},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "每回合回血 5%，最多5次\n攻击 +20%",
		Skill = {
			{
				Id = 105005,
				Value = 5,
			},
			{
				Id = 105002,
				Value = 20,
			},
		},
	},
	Tags = {
		560111,
		564556,
		564560,
		564561,
	},
}
EnemyConfig[EnemyID.Id6128] =
{
	Id = 6128,
	Name = "臭虾龟龟",
	Rarity = 2,
	Element = 210004,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：为了省钱买了劣质的冰柜储存鲜虾，还将这种虾加了很多调料卖给食客。",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	IconName = "Arena_FAT_ShrimpSushi",
	PrefabBundle = "character_arenaenemy",
	PrefabName = "Arena_FAT_ShrimpSushi",
	PrefabScale = 50,
	HPBarHeight = 80,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 2180, Gain = 436},
		{Value = 200002, Base = 38, Gain = 8},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "每回合回血 5%，最多5次\n攻击 +20%",
		Skill = {
			{
				Id = 105005,
				Value = 5,
			},
			{
				Id = 105002,
				Value = 20,
			},
		},
	},
	Tags = {
		560111,
		564556,
		564560,
		564561,
	},
}
EnemyConfig[EnemyID.Id6129] =
{
	Id = 6129,
	Name = "臭虾龟龟",
	Rarity = 2,
	Element = 210004,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：为了省钱买了劣质的冰柜储存鲜虾，还将这种虾加了很多调料卖给食客。",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	IconName = "Arena_FAT_ShrimpSushi",
	PrefabBundle = "character_arenaenemy",
	PrefabName = "Arena_FAT_ShrimpSushi",
	PrefabScale = 50,
	HPBarHeight = 80,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 2729, Gain = 546},
		{Value = 200002, Base = 42, Gain = 9},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "每回合回血 5%，最多5次\n攻击 +20%",
		Skill = {
			{
				Id = 105005,
				Value = 5,
			},
			{
				Id = 105002,
				Value = 20,
			},
		},
	},
	Tags = {
		560111,
		564556,
		564560,
		564561,
	},
}
EnemyConfig[EnemyID.Id6130] =
{
	Id = 6130,
	Name = "乌贼丸子",
	Rarity = 4,
	Element = 210004,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：用墨汁做丸子馅料，让吃了丸子的食客牙齿变黑。",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	IconName = "Arena_FAT_Takesan",
	PrefabBundle = "character_arenaenemy",
	PrefabName = "Arena_FAT_Takesan",
	PrefabScale = 50,
	HPBarHeight = 110,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 2177, Gain = 436},
		{Value = 200002, Base = 40, Gain = 8},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "受暗元素敌人伤害 -100%\n有15%概率额外攻击1次",
		Skill = {
			{
				Id = 105037,
				Value = -100,
			},
			{
				Id = 105023,
				Value = 15,
			},
		},
	},
	Tags = {
		560111,
		564555,
		564558,
	},
}
EnemyConfig[EnemyID.Id6131] =
{
	Id = 6131,
	Name = "乌贼丸子",
	Rarity = 4,
	Element = 210004,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：用墨汁做丸子馅料，让吃了丸子的食客牙齿变黑。",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	IconName = "Arena_FAT_Takesan",
	PrefabBundle = "character_arenaenemy",
	PrefabName = "Arena_FAT_Takesan",
	PrefabScale = 50,
	HPBarHeight = 110,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 2636, Gain = 528},
		{Value = 200002, Base = 41, Gain = 9},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "受暗元素敌人伤害 -100%\n有15%概率额外攻击1次",
		Skill = {
			{
				Id = 105037,
				Value = -100,
			},
			{
				Id = 105023,
				Value = 15,
			},
		},
	},
	Tags = {
		560111,
		564555,
		564558,
	},
}
EnemyConfig[EnemyID.Id6132] =
{
	Id = 6132,
	Name = "乌贼丸子",
	Rarity = 4,
	Element = 210004,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：用墨汁做丸子馅料，让吃了丸子的食客牙齿变黑。",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	IconName = "Arena_FAT_Takesan",
	PrefabBundle = "character_arenaenemy",
	PrefabName = "Arena_FAT_Takesan",
	PrefabScale = 50,
	HPBarHeight = 110,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 3035, Gain = 607},
		{Value = 200002, Base = 42, Gain = 9},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "受暗元素敌人伤害 -100%\n有15%概率额外攻击1次",
		Skill = {
			{
				Id = 105037,
				Value = -100,
			},
			{
				Id = 105023,
				Value = 15,
			},
		},
	},
	Tags = {
		560111,
		564555,
		564558,
	},
}
EnemyConfig[EnemyID.Id6133] =
{
	Id = 6133,
	Name = "超辣布丁",
	Rarity = 3,
	Element = 210001,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：在接吻时往男朋友嘴里灌辣椒油。",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	IconName = "Arena_FAT_Pudding",
	PrefabBundle = "character_arenaenemy",
	PrefabName = "Arena_FAT_Pudding",
	PrefabScale = 50,
	HPBarHeight = 120,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 2177, Gain = 436},
		{Value = 200002, Base = 40, Gain = 8},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "生命 +100%\n每回合攻击 +20%，最多5次",
		Skill = {
			{
				Id = 105001,
				Value = 100,
			},
			{
				Id = 105006,
				Value = 20,
			},
		},
	},
	Tags = {
		560111,
		564555,
		564561,
	},
}
EnemyConfig[EnemyID.Id6134] =
{
	Id = 6134,
	Name = "超辣布丁",
	Rarity = 3,
	Element = 210001,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：在接吻时往男朋友嘴里灌辣椒油。",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	IconName = "Arena_FAT_Pudding",
	PrefabBundle = "character_arenaenemy",
	PrefabName = "Arena_FAT_Pudding",
	PrefabScale = 50,
	HPBarHeight = 120,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 2636, Gain = 528},
		{Value = 200002, Base = 41, Gain = 9},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "生命 +100%\n每回合攻击 +20%，最多5次",
		Skill = {
			{
				Id = 105001,
				Value = 100,
			},
			{
				Id = 105006,
				Value = 20,
			},
		},
	},
	Tags = {
		560111,
		564555,
		564561,
	},
}
EnemyConfig[EnemyID.Id6135] =
{
	Id = 6135,
	Name = "超辣布丁",
	Rarity = 3,
	Element = 210001,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：在接吻时往男朋友嘴里灌辣椒油。",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	IconName = "Arena_FAT_Pudding",
	PrefabBundle = "character_arenaenemy",
	PrefabName = "Arena_FAT_Pudding",
	PrefabScale = 50,
	HPBarHeight = 120,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 3035, Gain = 607},
		{Value = 200002, Base = 42, Gain = 9},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "生命 +100%\n每回合攻击 +20%，最多5次",
		Skill = {
			{
				Id = 105001,
				Value = 100,
			},
			{
				Id = 105006,
				Value = 20,
			},
		},
	},
	Tags = {
		560111,
		564555,
		564561,
	},
}
EnemyConfig[EnemyID.Id6136] =
{
	Id = 6136,
	Name = "化工肉球",
	Rarity = 2,
	Element = 210002,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：传播具有毒性的气体。",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	IconName = "Arena_FAT_MeatBalls",
	PrefabBundle = "character_arenaenemy",
	PrefabName = "Arena_FAT_MeatBalls",
	PrefabScale = 50,
	HPBarHeight = 125,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 2328, Gain = 466},
		{Value = 200002, Base = 41, Gain = 9},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "暴击伤害 +200%\n暴击 +40",
		Skill = {
			{
				Id = 105038,
				Value = 200,
			},
			{
				Id = 105004,
				Value = 40,
			},
		},
	},
	Tags = {
		560111,
		564556,
		564561,
	},
}
EnemyConfig[EnemyID.Id6137] =
{
	Id = 6137,
	Name = "化工肉球",
	Rarity = 2,
	Element = 210002,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：传播具有毒性的气体。",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	IconName = "Arena_FAT_MeatBalls",
	PrefabBundle = "character_arenaenemy",
	PrefabName = "Arena_FAT_MeatBalls",
	PrefabScale = 50,
	HPBarHeight = 125,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 2430, Gain = 486},
		{Value = 200002, Base = 45, Gain = 9},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "暴击伤害 +200%\n暴击 +40",
		Skill = {
			{
				Id = 105038,
				Value = 200,
			},
			{
				Id = 105004,
				Value = 40,
			},
		},
	},
	Tags = {
		560111,
		564556,
		564561,
	},
}
EnemyConfig[EnemyID.Id6138] =
{
	Id = 6138,
	Name = "化工肉球",
	Rarity = 2,
	Element = 210002,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：传播具有毒性的气体。",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	IconName = "Arena_FAT_MeatBalls",
	PrefabBundle = "character_arenaenemy",
	PrefabName = "Arena_FAT_MeatBalls",
	PrefabScale = 50,
	HPBarHeight = 125,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 3021, Gain = 605},
		{Value = 200002, Base = 49, Gain = 10},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "暴击伤害 +200%\n暴击 +40",
		Skill = {
			{
				Id = 105038,
				Value = 200,
			},
			{
				Id = 105004,
				Value = 40,
			},
		},
	},
	Tags = {
		560111,
		564556,
		564561,
	},
}
EnemyConfig[EnemyID.Id6139] =
{
	Id = 6139,
	Name = "黑心饺子",
	Rarity = 3,
	Element = 210001,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：给客人下饺子时，故意把饺子皮挑破，让客人吃到的都是破饺子。",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	IconName = "Arena_FAT_Dumplings",
	PrefabBundle = "character_arenaenemy",
	PrefabName = "Arena_FAT_Dumplings",
	PrefabScale = 50,
	HPBarHeight = 75,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 2328, Gain = 466},
		{Value = 200002, Base = 41, Gain = 9},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "每3回合将自身元素变为随机元素\n有10%概率额外攻击2次",
		Skill = {
			{
				Id = 105163,
				Value = -1,
			},
			{
				Id = 105024,
				Value = 10,
			},
		},
	},
	Tags = {
		560111,
		564556,
		564558,
	},
}
EnemyConfig[EnemyID.Id6140] =
{
	Id = 6140,
	Name = "黑心饺子",
	Rarity = 3,
	Element = 210001,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：给客人下饺子时，故意把饺子皮挑破，让客人吃到的都是破饺子。",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	IconName = "Arena_FAT_Dumplings",
	PrefabBundle = "character_arenaenemy",
	PrefabName = "Arena_FAT_Dumplings",
	PrefabScale = 50,
	HPBarHeight = 75,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 2430, Gain = 486},
		{Value = 200002, Base = 45, Gain = 9},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "每3回合将自身元素变为随机元素\n有10%概率额外攻击2次",
		Skill = {
			{
				Id = 105163,
				Value = -1,
			},
			{
				Id = 105024,
				Value = 10,
			},
		},
	},
	Tags = {
		560111,
		564556,
		564558,
	},
}
EnemyConfig[EnemyID.Id6141] =
{
	Id = 6141,
	Name = "黑心饺子",
	Rarity = 3,
	Element = 210001,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：给客人下饺子时，故意把饺子皮挑破，让客人吃到的都是破饺子。",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	IconName = "Arena_FAT_Dumplings",
	PrefabBundle = "character_arenaenemy",
	PrefabName = "Arena_FAT_Dumplings",
	PrefabScale = 50,
	HPBarHeight = 75,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 3021, Gain = 605},
		{Value = 200002, Base = 49, Gain = 10},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "每3回合将自身元素变为随机元素\n有10%概率额外攻击2次",
		Skill = {
			{
				Id = 105163,
				Value = -1,
			},
			{
				Id = 105024,
				Value = 10,
			},
		},
	},
	Tags = {
		560111,
		564556,
		564558,
	},
}
EnemyConfig[EnemyID.Id6142] =
{
	Id = 6142,
	Name = "变质圈",
	Rarity = 2,
	Element = 210005,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：伪装成轮胎，给汽车造成故障。",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	IconName = "Arena_FAT_MangoDoughnut",
	PrefabBundle = "character_arenaenemy",
	PrefabName = "Arena_FAT_MangoDoughnut",
	PrefabScale = 50,
	HPBarHeight = 125,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 2260, Gain = 452},
		{Value = 200002, Base = 40, Gain = 8},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "33%概率闪避攻击\n每3回合对所有队员造成80%攻击伤害",
		Skill = {
			{
				Id = 105026,
				Value = 33,
			},
			{
				Id = 105063,
				Value = 80,
			},
		},
	},
	Tags = {
		560111,
		564556,
		564557,
	},
}
EnemyConfig[EnemyID.Id6143] =
{
	Id = 6143,
	Name = "变质圈",
	Rarity = 2,
	Element = 210005,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：伪装成轮胎，给汽车造成故障。",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	IconName = "Arena_FAT_MangoDoughnut",
	PrefabBundle = "character_arenaenemy",
	PrefabName = "Arena_FAT_MangoDoughnut",
	PrefabScale = 50,
	HPBarHeight = 125,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 2351, Gain = 471},
		{Value = 200002, Base = 44, Gain = 9},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "33%概率闪避攻击\n每3回合对所有队员造成80%攻击伤害",
		Skill = {
			{
				Id = 105026,
				Value = 33,
			},
			{
				Id = 105063,
				Value = 80,
			},
		},
	},
	Tags = {
		560111,
		564556,
		564557,
	},
}
EnemyConfig[EnemyID.Id6144] =
{
	Id = 6144,
	Name = "变质圈",
	Rarity = 2,
	Element = 210005,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：伪装成轮胎，给汽车造成故障。",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	IconName = "Arena_FAT_MangoDoughnut",
	PrefabBundle = "character_arenaenemy",
	PrefabName = "Arena_FAT_MangoDoughnut",
	PrefabScale = 50,
	HPBarHeight = 125,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 2916, Gain = 584},
		{Value = 200002, Base = 48, Gain = 10},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "33%概率闪避攻击\n每3回合对所有队员造成80%攻击伤害",
		Skill = {
			{
				Id = 105026,
				Value = 33,
			},
			{
				Id = 105063,
				Value = 80,
			},
		},
	},
	Tags = {
		560111,
		564556,
		564557,
	},
}
EnemyConfig[EnemyID.Id6145] =
{
	Id = 6145,
	Name = "浓浆多拿滋",
	Rarity = 2,
	Element = 210005,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：使用未经许可的特浓糖浆制作甜甜圈，使小孩子蛀牙。",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	IconName = "Arena_FAT_Doughnut",
	PrefabBundle = "character_arenaenemy",
	PrefabName = "Arena_FAT_Doughnut",
	PrefabScale = 50,
	HPBarHeight = 125,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 2260, Gain = 452},
		{Value = 200002, Base = 40, Gain = 8},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "33%概率闪避攻击\n有15%概率额外攻击1次",
		Skill = {
			{
				Id = 105026,
				Value = 33,
			},
			{
				Id = 105023,
				Value = 15,
			},
		},
	},
	Tags = {
		560111,
		564556,
		564557,
		564558,
	},
}
EnemyConfig[EnemyID.Id6146] =
{
	Id = 6146,
	Name = "浓浆多拿滋",
	Rarity = 2,
	Element = 210005,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：使用未经许可的特浓糖浆制作甜甜圈，使小孩子蛀牙。",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	IconName = "Arena_FAT_Doughnut",
	PrefabBundle = "character_arenaenemy",
	PrefabName = "Arena_FAT_Doughnut",
	PrefabScale = 50,
	HPBarHeight = 125,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 2351, Gain = 471},
		{Value = 200002, Base = 44, Gain = 9},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "33%概率闪避攻击\n有15%概率额外攻击1次",
		Skill = {
			{
				Id = 105026,
				Value = 33,
			},
			{
				Id = 105023,
				Value = 15,
			},
		},
	},
	Tags = {
		560111,
		564556,
		564557,
		564558,
	},
}
EnemyConfig[EnemyID.Id6147] =
{
	Id = 6147,
	Name = "浓浆多拿滋",
	Rarity = 2,
	Element = 210005,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：使用未经许可的特浓糖浆制作甜甜圈，使小孩子蛀牙。",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	IconName = "Arena_FAT_Doughnut",
	PrefabBundle = "character_arenaenemy",
	PrefabName = "Arena_FAT_Doughnut",
	PrefabScale = 50,
	HPBarHeight = 125,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 2916, Gain = 584},
		{Value = 200002, Base = 48, Gain = 10},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "33%概率闪避攻击\n有15%概率额外攻击1次",
		Skill = {
			{
				Id = 105026,
				Value = 33,
			},
			{
				Id = 105023,
				Value = 15,
			},
		},
	},
	Tags = {
		560111,
		564556,
		564557,
		564558,
	},
}
EnemyConfig[EnemyID.Id6148] =
{
	Id = 6148,
	Name = "僵尸肉猪",
	Rarity = 3,
	Element = 210002,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名:传播僵尸病毒。",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	IconName = "Arena_FAT_HamPig",
	PrefabBundle = "character_arenaenemy",
	PrefabName = "Arena_FAT_HamPig",
	PrefabScale = 50,
	HPBarHeight = 120,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 2196, Gain = 440},
		{Value = 200002, Base = 40, Gain = 8},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "每回合攻击 +20%，最多5次\n每回合对前2个队员造成100%攻击伤害",
		Skill = {
			{
				Id = 105006,
				Value = 20,
			},
			{
				Id = 105040,
				Value = 100,
			},
		},
	},
	Tags = {
		560111,
		564556,
		564561,
	},
}
EnemyConfig[EnemyID.Id6149] =
{
	Id = 6149,
	Name = "僵尸肉猪",
	Rarity = 3,
	Element = 210002,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名:传播僵尸病毒。",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	IconName = "Arena_FAT_HamPig",
	PrefabBundle = "character_arenaenemy",
	PrefabName = "Arena_FAT_HamPig",
	PrefabScale = 50,
	HPBarHeight = 120,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 2278, Gain = 456},
		{Value = 200002, Base = 44, Gain = 9},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "每回合攻击 +20%，最多5次\n每回合对前2个队员造成100%攻击伤害",
		Skill = {
			{
				Id = 105006,
				Value = 20,
			},
			{
				Id = 105040,
				Value = 100,
			},
		},
	},
	Tags = {
		560111,
		564556,
		564561,
	},
}
EnemyConfig[EnemyID.Id6150] =
{
	Id = 6150,
	Name = "僵尸肉猪",
	Rarity = 3,
	Element = 210002,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名:传播僵尸病毒。",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	IconName = "Arena_FAT_HamPig",
	PrefabBundle = "character_arenaenemy",
	PrefabName = "Arena_FAT_HamPig",
	PrefabScale = 50,
	HPBarHeight = 120,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 2817, Gain = 564},
		{Value = 200002, Base = 47, Gain = 10},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "每回合攻击 +20%，最多5次\n每回合对前2个队员造成100%攻击伤害",
		Skill = {
			{
				Id = 105006,
				Value = 20,
			},
			{
				Id = 105040,
				Value = 100,
			},
		},
	},
	Tags = {
		560111,
		564556,
		564561,
	},
}
EnemyConfig[EnemyID.Id6151] =
{
	Id = 6151,
	Name = "硬化豆泥",
	Rarity = 2,
	Element = 210002,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：制作如同水泥般坚硬的豆泥，让毫无准备的食客门牙崩裂。",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	IconName = "Arena_FAT_Cheese",
	PrefabBundle = "character_arenaenemy",
	PrefabName = "Arena_FAT_Cheese",
	PrefabScale = 50,
	HPBarHeight = 75,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 2196, Gain = 440},
		{Value = 200002, Base = 40, Gain = 8},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "忍耐 +120\n每3回合对前3个队员造成100%攻击伤害",
		Skill = {
			{
				Id = 105003,
				Value = 120,
			},
			{
				Id = 105057,
				Value = 100,
			},
		},
	},
	Tags = {
		560111,
		564556,
		564561,
	},
}
EnemyConfig[EnemyID.Id6152] =
{
	Id = 6152,
	Name = "硬化豆泥",
	Rarity = 2,
	Element = 210002,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：制作如同水泥般坚硬的豆泥，让毫无准备的食客门牙崩裂。",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	IconName = "Arena_FAT_Cheese",
	PrefabBundle = "character_arenaenemy",
	PrefabName = "Arena_FAT_Cheese",
	PrefabScale = 50,
	HPBarHeight = 75,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 2278, Gain = 456},
		{Value = 200002, Base = 44, Gain = 9},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "忍耐 +120\n每3回合对前3个队员造成100%攻击伤害",
		Skill = {
			{
				Id = 105003,
				Value = 120,
			},
			{
				Id = 105057,
				Value = 100,
			},
		},
	},
	Tags = {
		560111,
		564556,
		564561,
	},
}
EnemyConfig[EnemyID.Id6153] =
{
	Id = 6153,
	Name = "硬化豆泥",
	Rarity = 2,
	Element = 210002,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：制作如同水泥般坚硬的豆泥，让毫无准备的食客门牙崩裂。",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	IconName = "Arena_FAT_Cheese",
	PrefabBundle = "character_arenaenemy",
	PrefabName = "Arena_FAT_Cheese",
	PrefabScale = 50,
	HPBarHeight = 75,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 2817, Gain = 564},
		{Value = 200002, Base = 47, Gain = 10},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "忍耐 +120\n每3回合对前3个队员造成100%攻击伤害",
		Skill = {
			{
				Id = 105003,
				Value = 120,
			},
			{
				Id = 105057,
				Value = 100,
			},
		},
	},
	Tags = {
		560111,
		564556,
		564561,
	},
}
EnemyConfig[EnemyID.Id6154] =
{
	Id = 6154,
	Name = "下水道比撒",
	Rarity = 4,
	Element = 210002,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：外送披萨时，一定会失手将披萨掉在地上，然后重新捡回去送给客人。",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	IconName = "Arena_FAT_Pizza",
	PrefabBundle = "character_arenaenemy",
	PrefabName = "Arena_FAT_Pizza",
	PrefabScale = 50,
	HPBarHeight = 110,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 2136, Gain = 428},
		{Value = 200002, Base = 40, Gain = 8},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "受水元素敌人伤害 -100%\n受暗元素敌人伤害 -100%\n暴击 +80",
		Skill = {
			{
				Id = 105033,
				Value = -100,
			},
			{
				Id = 105037,
				Value = -100,
			},
			{
				Id = 105004,
				Value = 80,
			},
		},
	},
	Tags = {
		560111,
		564556,
		564561,
	},
}
EnemyConfig[EnemyID.Id6155] =
{
	Id = 6155,
	Name = "下水道比撒",
	Rarity = 4,
	Element = 210002,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：外送披萨时，一定会失手将披萨掉在地上，然后重新捡回去送给客人。",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	IconName = "Arena_FAT_Pizza",
	PrefabBundle = "character_arenaenemy",
	PrefabName = "Arena_FAT_Pizza",
	PrefabScale = 50,
	HPBarHeight = 110,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 2209, Gain = 442},
		{Value = 200002, Base = 43, Gain = 9},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "受水元素敌人伤害 -100%\n受暗元素敌人伤害 -100%\n暴击 +80",
		Skill = {
			{
				Id = 105033,
				Value = -100,
			},
			{
				Id = 105037,
				Value = -100,
			},
			{
				Id = 105004,
				Value = 80,
			},
		},
	},
	Tags = {
		560111,
		564556,
		564561,
	},
}
EnemyConfig[EnemyID.Id6156] =
{
	Id = 6156,
	Name = "下水道比撒",
	Rarity = 4,
	Element = 210002,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：外送披萨时，一定会失手将披萨掉在地上，然后重新捡回去送给客人。",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	IconName = "Arena_FAT_Pizza",
	PrefabBundle = "character_arenaenemy",
	PrefabName = "Arena_FAT_Pizza",
	PrefabScale = 50,
	HPBarHeight = 110,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 2725, Gain = 545},
		{Value = 200002, Base = 47, Gain = 10},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "受水元素敌人伤害 -100%\n受暗元素敌人伤害 -100%\n暴击 +80",
		Skill = {
			{
				Id = 105033,
				Value = -100,
			},
			{
				Id = 105037,
				Value = -100,
			},
			{
				Id = 105004,
				Value = 80,
			},
		},
	},
	Tags = {
		560111,
		564556,
		564561,
	},
}
EnemyConfig[EnemyID.Id6157] =
{
	Id = 6157,
	Name = "铁饭碗左",
	Rarity = 1,
	Element = 210003,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：砸了家里安排好的铁饭碗。",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	IconName = "Arena_MUS_GreenBowlLeft",
	PrefabBundle = "character_arenaenemy",
	PrefabName = "Arena_MUS_GreenBowlLeft",
	PrefabScale = 50,
	HPBarHeight = 125,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 2263, Gain = 453},
		{Value = 200002, Base = 34, Gain = 7},
		{Value = 200003, Base = 0, Gain = 1},
		{Value = 200004, Base = 0, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "生命 +50%",
		Skill = {
			{
				Id = 105001,
				Value = 50,
			},
		},
	},
	Tags = {
		560111,
		564556,
		564561,
	},
}
EnemyConfig[EnemyID.Id6158] =
{
	Id = 6158,
	Name = "铁饭碗左",
	Rarity = 1,
	Element = 210003,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：砸了家里安排好的铁饭碗。",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	IconName = "Arena_MUS_GreenBowlLeft",
	PrefabBundle = "character_arenaenemy",
	PrefabName = "Arena_MUS_GreenBowlLeft",
	PrefabScale = 50,
	HPBarHeight = 125,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 2481, Gain = 497},
		{Value = 200002, Base = 38, Gain = 8},
		{Value = 200003, Base = 0, Gain = 1},
		{Value = 200004, Base = 0, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "生命 +50%",
		Skill = {
			{
				Id = 105001,
				Value = 50,
			},
		},
	},
	Tags = {
		560111,
		564556,
		564561,
	},
}
EnemyConfig[EnemyID.Id6159] =
{
	Id = 6159,
	Name = "铁饭碗左",
	Rarity = 1,
	Element = 210003,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：砸了家里安排好的铁饭碗。",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	IconName = "Arena_MUS_GreenBowlLeft",
	PrefabBundle = "character_arenaenemy",
	PrefabName = "Arena_MUS_GreenBowlLeft",
	PrefabScale = 50,
	HPBarHeight = 125,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 3226, Gain = 646},
		{Value = 200002, Base = 41, Gain = 9},
		{Value = 200003, Base = 0, Gain = 1},
		{Value = 200004, Base = 0, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "生命 +50%",
		Skill = {
			{
				Id = 105001,
				Value = 50,
			},
		},
	},
	Tags = {
		560111,
		564556,
		564561,
	},
}
EnemyConfig[EnemyID.Id6160] =
{
	Id = 6160,
	Name = "铁饭碗右",
	Rarity = 1,
	Element = 210003,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：砸了家里安排好的铁饭碗。",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	IconName = "Arena_MUS_GreenBowlRight",
	PrefabBundle = "character_arenaenemy",
	PrefabName = "Arena_MUS_GreenBowlRight",
	PrefabScale = 50,
	HPBarHeight = 125,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 2263, Gain = 453},
		{Value = 200002, Base = 34, Gain = 7},
		{Value = 200003, Base = 0, Gain = 1},
		{Value = 200004, Base = 0, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "生命 +25%",
		Skill = {
			{
				Id = 105001,
				Value = 25,
			},
		},
	},
	Tags = {
		560111,
		564556,
		564561,
	},
}
EnemyConfig[EnemyID.Id6161] =
{
	Id = 6161,
	Name = "铁饭碗右",
	Rarity = 1,
	Element = 210003,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：砸了家里安排好的铁饭碗。",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	IconName = "Arena_MUS_GreenBowlRight",
	PrefabBundle = "character_arenaenemy",
	PrefabName = "Arena_MUS_GreenBowlRight",
	PrefabScale = 50,
	HPBarHeight = 125,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 2481, Gain = 497},
		{Value = 200002, Base = 38, Gain = 8},
		{Value = 200003, Base = 0, Gain = 1},
		{Value = 200004, Base = 0, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "生命 +25%",
		Skill = {
			{
				Id = 105001,
				Value = 25,
			},
		},
	},
	Tags = {
		560111,
		564556,
		564561,
	},
}
EnemyConfig[EnemyID.Id6162] =
{
	Id = 6162,
	Name = "铁饭碗右",
	Rarity = 1,
	Element = 210003,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：砸了家里安排好的铁饭碗。",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	IconName = "Arena_MUS_GreenBowlRight",
	PrefabBundle = "character_arenaenemy",
	PrefabName = "Arena_MUS_GreenBowlRight",
	PrefabScale = 50,
	HPBarHeight = 125,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 3226, Gain = 646},
		{Value = 200002, Base = 41, Gain = 9},
		{Value = 200003, Base = 0, Gain = 1},
		{Value = 200004, Base = 0, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "生命 +25%",
		Skill = {
			{
				Id = 105001,
				Value = 25,
			},
		},
	},
	Tags = {
		560111,
		564556,
		564561,
	},
}
EnemyConfig[EnemyID.Id6163] =
{
	Id = 6163,
	Name = "隔热碗左",
	Rarity = 2,
	Element = 210002,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：在顾客喝汤时裂开，烫伤顾客。",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	IconName = "Arena_MUS_BlueBowlLeft",
	PrefabBundle = "character_arenaenemy",
	PrefabName = "Arena_MUS_BlueBowlLeft",
	PrefabScale = 50,
	HPBarHeight = 125,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 2168, Gain = 434},
		{Value = 200002, Base = 33, Gain = 7},
		{Value = 200003, Base = 0, Gain = 1},
		{Value = 200004, Base = 0, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "受火元素敌人伤害 -100%",
		Skill = {
			{
				Id = 105034,
				Value = -100,
			},
		},
	},
	Tags = {
		560111,
		564556,
	},
}
EnemyConfig[EnemyID.Id6164] =
{
	Id = 6164,
	Name = "隔热碗左",
	Rarity = 2,
	Element = 210002,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：在顾客喝汤时裂开，烫伤顾客。",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	IconName = "Arena_MUS_BlueBowlLeft",
	PrefabBundle = "character_arenaenemy",
	PrefabName = "Arena_MUS_BlueBowlLeft",
	PrefabScale = 50,
	HPBarHeight = 125,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 2361, Gain = 473},
		{Value = 200002, Base = 36, Gain = 8},
		{Value = 200003, Base = 0, Gain = 1},
		{Value = 200004, Base = 0, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "受火元素敌人伤害 -100%",
		Skill = {
			{
				Id = 105034,
				Value = -100,
			},
		},
	},
	Tags = {
		560111,
		564556,
	},
}
EnemyConfig[EnemyID.Id6165] =
{
	Id = 6165,
	Name = "隔热碗左",
	Rarity = 2,
	Element = 210002,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：在顾客喝汤时裂开，烫伤顾客。",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	IconName = "Arena_MUS_BlueBowlLeft",
	PrefabBundle = "character_arenaenemy",
	PrefabName = "Arena_MUS_BlueBowlLeft",
	PrefabScale = 50,
	HPBarHeight = 125,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 3049, Gain = 610},
		{Value = 200002, Base = 40, Gain = 8},
		{Value = 200003, Base = 0, Gain = 1},
		{Value = 200004, Base = 0, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "受火元素敌人伤害 -100%",
		Skill = {
			{
				Id = 105034,
				Value = -100,
			},
		},
	},
	Tags = {
		560111,
		564556,
	},
}
EnemyConfig[EnemyID.Id6166] =
{
	Id = 6166,
	Name = "隔热碗右",
	Rarity = 2,
	Element = 210002,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：在顾客喝汤时裂开，烫伤顾客。",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	IconName = "Arena_MUS_BlueBowlRight",
	PrefabBundle = "character_arenaenemy",
	PrefabName = "Arena_MUS_BlueBowlRight",
	PrefabScale = 50,
	HPBarHeight = 125,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 2168, Gain = 434},
		{Value = 200002, Base = 33, Gain = 7},
		{Value = 200003, Base = 0, Gain = 1},
		{Value = 200004, Base = 0, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "受火元素敌人伤害 -100%",
		Skill = {
			{
				Id = 105034,
				Value = -100,
			},
		},
	},
	Tags = {
		560111,
		564556,
	},
}
EnemyConfig[EnemyID.Id6167] =
{
	Id = 6167,
	Name = "隔热碗右",
	Rarity = 2,
	Element = 210002,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：在顾客喝汤时裂开，烫伤顾客。",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	IconName = "Arena_MUS_BlueBowlRight",
	PrefabBundle = "character_arenaenemy",
	PrefabName = "Arena_MUS_BlueBowlRight",
	PrefabScale = 50,
	HPBarHeight = 125,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 2361, Gain = 473},
		{Value = 200002, Base = 36, Gain = 8},
		{Value = 200003, Base = 0, Gain = 1},
		{Value = 200004, Base = 0, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "受火元素敌人伤害 -100%",
		Skill = {
			{
				Id = 105034,
				Value = -100,
			},
		},
	},
	Tags = {
		560111,
		564556,
	},
}
EnemyConfig[EnemyID.Id6168] =
{
	Id = 6168,
	Name = "隔热碗右",
	Rarity = 2,
	Element = 210002,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：在顾客喝汤时裂开，烫伤顾客。",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	IconName = "Arena_MUS_BlueBowlRight",
	PrefabBundle = "character_arenaenemy",
	PrefabName = "Arena_MUS_BlueBowlRight",
	PrefabScale = 50,
	HPBarHeight = 125,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 3049, Gain = 610},
		{Value = 200002, Base = 40, Gain = 8},
		{Value = 200003, Base = 0, Gain = 1},
		{Value = 200004, Base = 0, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "受火元素敌人伤害 -100%",
		Skill = {
			{
				Id = 105034,
				Value = -100,
			},
		},
	},
	Tags = {
		560111,
		564556,
	},
}
EnemyConfig[EnemyID.Id6169] =
{
	Id = 6169,
	Name = "假入口",
	Rarity = 2,
	Element = 210004,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：指向错误的方向，让游客晕头转向。",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	IconName = "Arena_MUS_Enter",
	PrefabBundle = "character_arenaenemy",
	PrefabName = "Arena_MUS_Enter",
	PrefabScale = 50,
	HPBarHeight = 125,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 2081, Gain = 417},
		{Value = 200002, Base = 32, Gain = 7},
		{Value = 200003, Base = 0, Gain = 1},
		{Value = 200004, Base = 0, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "5回合后，回血 80%",
		Skill = {
			{
				Id = 105013,
				Value = 80,
			},
		},
	},
	Tags = {
		560111,
		564556,
		564560,
	},
}
EnemyConfig[EnemyID.Id6170] =
{
	Id = 6170,
	Name = "假入口",
	Rarity = 2,
	Element = 210004,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：指向错误的方向，让游客晕头转向。",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	IconName = "Arena_MUS_Enter",
	PrefabBundle = "character_arenaenemy",
	PrefabName = "Arena_MUS_Enter",
	PrefabScale = 50,
	HPBarHeight = 125,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 2251, Gain = 451},
		{Value = 200002, Base = 35, Gain = 7},
		{Value = 200003, Base = 0, Gain = 1},
		{Value = 200004, Base = 0, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "5回合后，回血 80%",
		Skill = {
			{
				Id = 105013,
				Value = 80,
			},
		},
	},
	Tags = {
		560111,
		564556,
		564560,
	},
}
EnemyConfig[EnemyID.Id6171] =
{
	Id = 6171,
	Name = "假入口",
	Rarity = 2,
	Element = 210004,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：指向错误的方向，让游客晕头转向。",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	IconName = "Arena_MUS_Enter",
	PrefabBundle = "character_arenaenemy",
	PrefabName = "Arena_MUS_Enter",
	PrefabScale = 50,
	HPBarHeight = 125,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 2890, Gain = 578},
		{Value = 200002, Base = 38, Gain = 8},
		{Value = 200003, Base = 0, Gain = 1},
		{Value = 200004, Base = 0, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "5回合后，回血 80%",
		Skill = {
			{
				Id = 105013,
				Value = 80,
			},
		},
	},
	Tags = {
		560111,
		564556,
		564560,
	},
}
EnemyConfig[EnemyID.Id6172] =
{
	Id = 6172,
	Name = "危险出口",
	Rarity = 2,
	Element = 210005,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：指向错误的出口，让游客陷入危险。",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	IconName = "Arena_MUS_Exit",
	PrefabBundle = "character_arenaenemy",
	PrefabName = "Arena_MUS_Exit",
	PrefabScale = 50,
	HPBarHeight = 125,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 2081, Gain = 417},
		{Value = 200002, Base = 32, Gain = 7},
		{Value = 200003, Base = 0, Gain = 1},
		{Value = 200004, Base = 0, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "5回合后，攻击 +100%",
		Skill = {
			{
				Id = 105014,
				Value = 100,
			},
		},
	},
	Tags = {
		560111,
		564556,
		564561,
	},
}
EnemyConfig[EnemyID.Id6173] =
{
	Id = 6173,
	Name = "危险出口",
	Rarity = 2,
	Element = 210005,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：指向错误的出口，让游客陷入危险。",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	IconName = "Arena_MUS_Exit",
	PrefabBundle = "character_arenaenemy",
	PrefabName = "Arena_MUS_Exit",
	PrefabScale = 50,
	HPBarHeight = 125,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 2251, Gain = 451},
		{Value = 200002, Base = 35, Gain = 7},
		{Value = 200003, Base = 0, Gain = 1},
		{Value = 200004, Base = 0, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "5回合后，攻击 +100%",
		Skill = {
			{
				Id = 105014,
				Value = 100,
			},
		},
	},
	Tags = {
		560111,
		564556,
		564561,
	},
}
EnemyConfig[EnemyID.Id6174] =
{
	Id = 6174,
	Name = "危险出口",
	Rarity = 2,
	Element = 210005,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：指向错误的出口，让游客陷入危险。",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	IconName = "Arena_MUS_Exit",
	PrefabBundle = "character_arenaenemy",
	PrefabName = "Arena_MUS_Exit",
	PrefabScale = 50,
	HPBarHeight = 125,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 2890, Gain = 578},
		{Value = 200002, Base = 38, Gain = 8},
		{Value = 200003, Base = 0, Gain = 1},
		{Value = 200004, Base = 0, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "5回合后，攻击 +100%",
		Skill = {
			{
				Id = 105014,
				Value = 100,
			},
		},
	},
	Tags = {
		560111,
		564556,
		564561,
	},
}
EnemyConfig[EnemyID.Id6175] =
{
	Id = 6175,
	Name = "劣质漆瓷片",
	Rarity = 2,
	Element = 210003,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：企图伪装成玉器，并把绿油漆弄到工作人员身上。",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	IconName = "Arena_MUS_Pottery",
	PrefabBundle = "character_arenaenemy",
	PrefabName = "Arena_MUS_Pottery",
	PrefabScale = 50,
	HPBarHeight = 125,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 2001, Gain = 401},
		{Value = 200002, Base = 31, Gain = 7},
		{Value = 200003, Base = 0, Gain = 1},
		{Value = 200004, Base = 0, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "每3回合有50%概率对所有队员造成200%攻击伤害",
		Skill = {
			{
				Id = 105103,
				Value = 200,
			},
		},
	},
	Tags = {
		560111,
		564556,
	},
}
EnemyConfig[EnemyID.Id6176] =
{
	Id = 6176,
	Name = "劣质漆瓷片",
	Rarity = 2,
	Element = 210003,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：企图伪装成玉器，并把绿油漆弄到工作人员身上。",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	IconName = "Arena_MUS_Pottery",
	PrefabBundle = "character_arenaenemy",
	PrefabName = "Arena_MUS_Pottery",
	PrefabScale = 50,
	HPBarHeight = 125,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 2152, Gain = 431},
		{Value = 200002, Base = 34, Gain = 7},
		{Value = 200003, Base = 0, Gain = 1},
		{Value = 200004, Base = 0, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "每3回合有50%概率对所有队员造成200%攻击伤害",
		Skill = {
			{
				Id = 105103,
				Value = 200,
			},
		},
	},
	Tags = {
		560111,
		564556,
	},
}
EnemyConfig[EnemyID.Id6177] =
{
	Id = 6177,
	Name = "劣质漆瓷片",
	Rarity = 2,
	Element = 210003,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：企图伪装成玉器，并把绿油漆弄到工作人员身上。",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	IconName = "Arena_MUS_Pottery",
	PrefabBundle = "character_arenaenemy",
	PrefabName = "Arena_MUS_Pottery",
	PrefabScale = 50,
	HPBarHeight = 125,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 2747, Gain = 550},
		{Value = 200002, Base = 37, Gain = 8},
		{Value = 200003, Base = 0, Gain = 1},
		{Value = 200004, Base = 0, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "每3回合有50%概率对所有队员造成200%攻击伤害",
		Skill = {
			{
				Id = 105103,
				Value = 200,
			},
		},
	},
	Tags = {
		560111,
		564556,
	},
}
EnemyConfig[EnemyID.Id6178] =
{
	Id = 6178,
	Name = "噪音编钟",
	Rarity = 2,
	Element = 210001,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：混入乐团，发出不和谐的声音。",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	IconName = "Arena_MUS_Chimes",
	PrefabBundle = "character_arenaenemy",
	PrefabName = "Arena_MUS_Chimes",
	PrefabScale = 50,
	HPBarHeight = 120,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 2001, Gain = 401},
		{Value = 200002, Base = 31, Gain = 7},
		{Value = 200003, Base = 0, Gain = 1},
		{Value = 200004, Base = 0, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "每回合对所有队员造成80%攻击伤害",
		Skill = {
			{
				Id = 105047,
				Value = 80,
			},
		},
	},
	Tags = {
		560111,
		564556,
	},
}
EnemyConfig[EnemyID.Id6179] =
{
	Id = 6179,
	Name = "噪音编钟",
	Rarity = 2,
	Element = 210001,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：混入乐团，发出不和谐的声音。",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	IconName = "Arena_MUS_Chimes",
	PrefabBundle = "character_arenaenemy",
	PrefabName = "Arena_MUS_Chimes",
	PrefabScale = 50,
	HPBarHeight = 120,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 2152, Gain = 431},
		{Value = 200002, Base = 34, Gain = 7},
		{Value = 200003, Base = 0, Gain = 1},
		{Value = 200004, Base = 0, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "每回合对所有队员造成80%攻击伤害",
		Skill = {
			{
				Id = 105047,
				Value = 80,
			},
		},
	},
	Tags = {
		560111,
		564556,
	},
}
EnemyConfig[EnemyID.Id6180] =
{
	Id = 6180,
	Name = "噪音编钟",
	Rarity = 2,
	Element = 210001,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：混入乐团，发出不和谐的声音。",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	IconName = "Arena_MUS_Chimes",
	PrefabBundle = "character_arenaenemy",
	PrefabName = "Arena_MUS_Chimes",
	PrefabScale = 50,
	HPBarHeight = 120,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 2747, Gain = 550},
		{Value = 200002, Base = 37, Gain = 8},
		{Value = 200003, Base = 0, Gain = 1},
		{Value = 200004, Base = 0, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "每回合对所有队员造成80%攻击伤害",
		Skill = {
			{
				Id = 105047,
				Value = 80,
			},
		},
	},
	Tags = {
		560111,
		564556,
	},
}
EnemyConfig[EnemyID.Id6181] =
{
	Id = 6181,
	Name = "腐味兽面鼎",
	Rarity = 2,
	Element = 210005,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：散发刺鼻的腐味，影响居民生活。",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	IconName = "Arena_MUS_BeastFaceTripod",
	PrefabBundle = "character_arenaenemy",
	PrefabName = "Arena_MUS_BeastFaceTripod",
	PrefabScale = 50,
	HPBarHeight = 125,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 2087, Gain = 418},
		{Value = 200002, Base = 35, Gain = 7},
		{Value = 200003, Base = 0, Gain = 1},
		{Value = 200004, Base = 0, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "有50%概率额外攻击2次\n有50%概率额外攻击1次",
		Skill = {
			{
				Id = 105024,
				Value = 50,
			},
			{
				Id = 105023,
				Value = 50,
			},
		},
	},
	Tags = {
		560111,
		564555,
		564558,
	},
}
EnemyConfig[EnemyID.Id6182] =
{
	Id = 6182,
	Name = "腐味兽面鼎",
	Rarity = 2,
	Element = 210005,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：散发刺鼻的腐味，影响居民生活。",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	IconName = "Arena_MUS_BeastFaceTripod",
	PrefabBundle = "character_arenaenemy",
	PrefabName = "Arena_MUS_BeastFaceTripod",
	PrefabScale = 50,
	HPBarHeight = 125,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 2579, Gain = 516},
		{Value = 200002, Base = 36, Gain = 8},
		{Value = 200003, Base = 0, Gain = 1},
		{Value = 200004, Base = 0, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "有50%概率额外攻击2次\n有50%概率额外攻击1次",
		Skill = {
			{
				Id = 105024,
				Value = 50,
			},
			{
				Id = 105023,
				Value = 50,
			},
		},
	},
	Tags = {
		560111,
		564555,
		564558,
	},
}
EnemyConfig[EnemyID.Id6183] =
{
	Id = 6183,
	Name = "腐味兽面鼎",
	Rarity = 2,
	Element = 210005,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：散发刺鼻的腐味，影响居民生活。",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	IconName = "Arena_MUS_BeastFaceTripod",
	PrefabBundle = "character_arenaenemy",
	PrefabName = "Arena_MUS_BeastFaceTripod",
	PrefabScale = 50,
	HPBarHeight = 125,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 3025, Gain = 605},
		{Value = 200002, Base = 37, Gain = 8},
		{Value = 200003, Base = 0, Gain = 1},
		{Value = 200004, Base = 0, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "有50%概率额外攻击2次\n有50%概率额外攻击1次",
		Skill = {
			{
				Id = 105024,
				Value = 50,
			},
			{
				Id = 105023,
				Value = 50,
			},
		},
	},
	Tags = {
		560111,
		564555,
		564558,
	},
}
EnemyConfig[EnemyID.Id6184] =
{
	Id = 6184,
	Name = "坟头碑",
	Rarity = 3,
	Element = 210005,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：在睡觉时立在别人头上，让人误以为是死亡。",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	IconName = "Arena_MUS_QuestionMark",
	PrefabBundle = "character_arenaenemy",
	PrefabName = "Arena_MUS_QuestionMark",
	PrefabScale = 50,
	HPBarHeight = 110,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 2087, Gain = 418},
		{Value = 200002, Base = 35, Gain = 7},
		{Value = 200003, Base = 0, Gain = 1},
		{Value = 200004, Base = 0, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "受暗元素敌人伤害 -100%\n5回合后，回血 80%",
		Skill = {
			{
				Id = 105037,
				Value = -100,
			},
			{
				Id = 105013,
				Value = 80,
			},
		},
	},
	Tags = {
		560111,
		564555,
		564560,
	},
}
EnemyConfig[EnemyID.Id6185] =
{
	Id = 6185,
	Name = "坟头碑",
	Rarity = 3,
	Element = 210005,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：在睡觉时立在别人头上，让人误以为是死亡。",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	IconName = "Arena_MUS_QuestionMark",
	PrefabBundle = "character_arenaenemy",
	PrefabName = "Arena_MUS_QuestionMark",
	PrefabScale = 50,
	HPBarHeight = 110,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 2579, Gain = 516},
		{Value = 200002, Base = 36, Gain = 8},
		{Value = 200003, Base = 0, Gain = 1},
		{Value = 200004, Base = 0, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "受暗元素敌人伤害 -100%\n5回合后，回血 80%",
		Skill = {
			{
				Id = 105037,
				Value = -100,
			},
			{
				Id = 105013,
				Value = 80,
			},
		},
	},
	Tags = {
		560111,
		564555,
		564560,
	},
}
EnemyConfig[EnemyID.Id6186] =
{
	Id = 6186,
	Name = "坟头碑",
	Rarity = 3,
	Element = 210005,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：在睡觉时立在别人头上，让人误以为是死亡。",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	IconName = "Arena_MUS_QuestionMark",
	PrefabBundle = "character_arenaenemy",
	PrefabName = "Arena_MUS_QuestionMark",
	PrefabScale = 50,
	HPBarHeight = 110,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 3025, Gain = 605},
		{Value = 200002, Base = 37, Gain = 8},
		{Value = 200003, Base = 0, Gain = 1},
		{Value = 200004, Base = 0, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "受暗元素敌人伤害 -100%\n5回合后，回血 80%",
		Skill = {
			{
				Id = 105037,
				Value = -100,
			},
			{
				Id = 105013,
				Value = 80,
			},
		},
	},
	Tags = {
		560111,
		564555,
		564560,
	},
}
EnemyConfig[EnemyID.Id6187] =
{
	Id = 6187,
	Name = "狂躁警戒线",
	Rarity = 3,
	Element = 210002,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：滥用警戒线封锁，造成秩序混乱。",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	IconName = "Arena_MUS_Cordon",
	PrefabBundle = "character_arenaenemy",
	PrefabName = "Arena_MUS_Cordon",
	PrefabScale = 50,
	HPBarHeight = 110,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 2334, Gain = 467},
		{Value = 200002, Base = 37, Gain = 8},
		{Value = 200003, Base = 0, Gain = 1},
		{Value = 200004, Base = 0, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "每回合攻击 +30%，最多5次\n忍耐 -20",
		Skill = {
			{
				Id = 105006,
				Value = 30,
			},
			{
				Id = 105003,
				Value = -20,
			},
		},
	},
	Tags = {
		560111,
		564556,
		564561,
	},
}
EnemyConfig[EnemyID.Id6188] =
{
	Id = 6188,
	Name = "狂躁警戒线",
	Rarity = 3,
	Element = 210002,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：滥用警戒线封锁，造成秩序混乱。",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	IconName = "Arena_MUS_Cordon",
	PrefabBundle = "character_arenaenemy",
	PrefabName = "Arena_MUS_Cordon",
	PrefabScale = 50,
	HPBarHeight = 110,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 2484, Gain = 497},
		{Value = 200002, Base = 41, Gain = 9},
		{Value = 200003, Base = 0, Gain = 1},
		{Value = 200004, Base = 0, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "每回合攻击 +30%，最多5次\n忍耐 -20",
		Skill = {
			{
				Id = 105006,
				Value = 30,
			},
			{
				Id = 105003,
				Value = -20,
			},
		},
	},
	Tags = {
		560111,
		564556,
		564561,
	},
}
EnemyConfig[EnemyID.Id6189] =
{
	Id = 6189,
	Name = "狂躁警戒线",
	Rarity = 3,
	Element = 210002,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：滥用警戒线封锁，造成秩序混乱。",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	IconName = "Arena_MUS_Cordon",
	PrefabBundle = "character_arenaenemy",
	PrefabName = "Arena_MUS_Cordon",
	PrefabScale = 50,
	HPBarHeight = 110,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 3141, Gain = 629},
		{Value = 200002, Base = 44, Gain = 9},
		{Value = 200003, Base = 0, Gain = 1},
		{Value = 200004, Base = 0, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "每回合攻击 +30%，最多5次\n忍耐 -20",
		Skill = {
			{
				Id = 105006,
				Value = 30,
			},
			{
				Id = 105003,
				Value = -20,
			},
		},
	},
	Tags = {
		560111,
		564556,
		564561,
	},
}
EnemyConfig[EnemyID.Id6190] =
{
	Id = 6190,
	Name = "收款机",
	Rarity = 2,
	Element = 210004,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：在客人扫码付款的时候会偷偷多刷一次，造成客人钱财损失。",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	IconName = "Arena_MUS_InfraredDetector",
	PrefabBundle = "character_arenaenemy",
	PrefabName = "Arena_MUS_InfraredDetector",
	PrefabScale = 50,
	HPBarHeight = 120,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 2334, Gain = 467},
		{Value = 200002, Base = 37, Gain = 8},
		{Value = 200003, Base = 0, Gain = 1},
		{Value = 200004, Base = 0, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "生命 +50%\n50%概率无视敌人闪避",
		Skill = {
			{
				Id = 105001,
				Value = 50,
			},
			{
				Id = 105027,
				Value = 50,
			},
		},
	},
	Tags = {
		560111,
		564556,
		564559,
		564561,
	},
}
EnemyConfig[EnemyID.Id6191] =
{
	Id = 6191,
	Name = "收款机",
	Rarity = 2,
	Element = 210004,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：在客人扫码付款的时候会偷偷多刷一次，造成客人钱财损失。",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	IconName = "Arena_MUS_InfraredDetector",
	PrefabBundle = "character_arenaenemy",
	PrefabName = "Arena_MUS_InfraredDetector",
	PrefabScale = 50,
	HPBarHeight = 120,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 2484, Gain = 497},
		{Value = 200002, Base = 41, Gain = 9},
		{Value = 200003, Base = 0, Gain = 1},
		{Value = 200004, Base = 0, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "生命 +50%\n50%概率无视敌人闪避",
		Skill = {
			{
				Id = 105001,
				Value = 50,
			},
			{
				Id = 105027,
				Value = 50,
			},
		},
	},
	Tags = {
		560111,
		564556,
		564559,
		564561,
	},
}
EnemyConfig[EnemyID.Id6192] =
{
	Id = 6192,
	Name = "收款机",
	Rarity = 2,
	Element = 210004,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：在客人扫码付款的时候会偷偷多刷一次，造成客人钱财损失。",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	IconName = "Arena_MUS_InfraredDetector",
	PrefabBundle = "character_arenaenemy",
	PrefabName = "Arena_MUS_InfraredDetector",
	PrefabScale = 50,
	HPBarHeight = 120,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 3141, Gain = 629},
		{Value = 200002, Base = 44, Gain = 9},
		{Value = 200003, Base = 0, Gain = 1},
		{Value = 200004, Base = 0, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "生命 +50%\n50%概率无视敌人闪避",
		Skill = {
			{
				Id = 105001,
				Value = 50,
			},
			{
				Id = 105027,
				Value = 50,
			},
		},
	},
	Tags = {
		560111,
		564556,
		564559,
		564561,
	},
}
EnemyConfig[EnemyID.Id6193] =
{
	Id = 6193,
	Name = "隐形摄像头",
	Rarity = 2,
	Element = 210005,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：名字叫隐形却不能隐形。",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	IconName = "Arena_MUS_BlackCamera",
	PrefabBundle = "character_arenaenemy",
	PrefabName = "Arena_MUS_BlackCamera",
	PrefabScale = 50,
	HPBarHeight = 110,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 2253, Gain = 451},
		{Value = 200002, Base = 37, Gain = 8},
		{Value = 200003, Base = 0, Gain = 1},
		{Value = 200004, Base = 0, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "每回合对前3个队员造成120%攻击伤害\n50%概率无视敌人闪避",
		Skill = {
			{
				Id = 105041,
				Value = 120,
			},
			{
				Id = 105027,
				Value = 50,
			},
		},
	},
	Tags = {
		560111,
		564556,
		564559,
	},
}
EnemyConfig[EnemyID.Id6194] =
{
	Id = 6194,
	Name = "隐形摄像头",
	Rarity = 2,
	Element = 210005,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：名字叫隐形却不能隐形。",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	IconName = "Arena_MUS_BlackCamera",
	PrefabBundle = "character_arenaenemy",
	PrefabName = "Arena_MUS_BlackCamera",
	PrefabScale = 50,
	HPBarHeight = 110,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 2386, Gain = 478},
		{Value = 200002, Base = 40, Gain = 8},
		{Value = 200003, Base = 0, Gain = 1},
		{Value = 200004, Base = 0, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "每回合对前3个队员造成120%攻击伤害\n50%概率无视敌人闪避",
		Skill = {
			{
				Id = 105041,
				Value = 120,
			},
			{
				Id = 105027,
				Value = 50,
			},
		},
	},
	Tags = {
		560111,
		564556,
		564559,
	},
}
EnemyConfig[EnemyID.Id6195] =
{
	Id = 6195,
	Name = "隐形摄像头",
	Rarity = 2,
	Element = 210005,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：名字叫隐形却不能隐形。",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	IconName = "Arena_MUS_BlackCamera",
	PrefabBundle = "character_arenaenemy",
	PrefabName = "Arena_MUS_BlackCamera",
	PrefabScale = 50,
	HPBarHeight = 110,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 3006, Gain = 602},
		{Value = 200002, Base = 43, Gain = 9},
		{Value = 200003, Base = 0, Gain = 1},
		{Value = 200004, Base = 0, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "每回合对前3个队员造成120%攻击伤害\n50%概率无视敌人闪避",
		Skill = {
			{
				Id = 105041,
				Value = 120,
			},
			{
				Id = 105027,
				Value = 50,
			},
		},
	},
	Tags = {
		560111,
		564556,
		564559,
	},
}
EnemyConfig[EnemyID.Id6196] =
{
	Id = 6196,
	Name = "碰碰瓷家属",
	Rarity = 2,
	Element = 210002,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：敲诈目睹碰碰瓷碎裂的游客。",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	IconName = "Arena_MUS_Porcelain",
	PrefabBundle = "character_arenaenemy",
	PrefabName = "Arena_MUS_Porcelain",
	PrefabScale = 50,
	HPBarHeight = 110,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 2253, Gain = 451},
		{Value = 200002, Base = 37, Gain = 8},
		{Value = 200003, Base = 0, Gain = 1},
		{Value = 200004, Base = 0, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "受到的暴击伤害 -75%\n33%概率闪避攻击",
		Skill = {
			{
				Id = 105039,
				Value = -75,
			},
			{
				Id = 105026,
				Value = 33,
			},
		},
	},
	Tags = {
		560111,
		564556,
		564557,
	},
}
EnemyConfig[EnemyID.Id6197] =
{
	Id = 6197,
	Name = "碰碰瓷家属",
	Rarity = 2,
	Element = 210002,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：敲诈目睹碰碰瓷碎裂的游客。",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	IconName = "Arena_MUS_Porcelain",
	PrefabBundle = "character_arenaenemy",
	PrefabName = "Arena_MUS_Porcelain",
	PrefabScale = 50,
	HPBarHeight = 110,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 2386, Gain = 478},
		{Value = 200002, Base = 40, Gain = 8},
		{Value = 200003, Base = 0, Gain = 1},
		{Value = 200004, Base = 0, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "受到的暴击伤害 -75%\n33%概率闪避攻击",
		Skill = {
			{
				Id = 105039,
				Value = -75,
			},
			{
				Id = 105026,
				Value = 33,
			},
		},
	},
	Tags = {
		560111,
		564556,
		564557,
	},
}
EnemyConfig[EnemyID.Id6198] =
{
	Id = 6198,
	Name = "碰碰瓷家属",
	Rarity = 2,
	Element = 210002,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：敲诈目睹碰碰瓷碎裂的游客。",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	IconName = "Arena_MUS_Porcelain",
	PrefabBundle = "character_arenaenemy",
	PrefabName = "Arena_MUS_Porcelain",
	PrefabScale = 50,
	HPBarHeight = 110,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 3006, Gain = 602},
		{Value = 200002, Base = 43, Gain = 9},
		{Value = 200003, Base = 0, Gain = 1},
		{Value = 200004, Base = 0, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "受到的暴击伤害 -75%\n33%概率闪避攻击",
		Skill = {
			{
				Id = 105039,
				Value = -75,
			},
			{
				Id = 105026,
				Value = 33,
			},
		},
	},
	Tags = {
		560111,
		564556,
		564557,
	},
}
EnemyConfig[EnemyID.Id6199] =
{
	Id = 6199,
	Name = "伪造鱼化石",
	Rarity = 2,
	Element = 210001,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：伪造身份证件。",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	IconName = "Arena_MUS_FishboneFossils",
	PrefabBundle = "character_arenaenemy",
	PrefabName = "Arena_MUS_FishboneFossils",
	PrefabScale = 50,
	HPBarHeight = 125,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 2178, Gain = 436},
		{Value = 200002, Base = 36, Gain = 8},
		{Value = 200003, Base = 0, Gain = 1},
		{Value = 200004, Base = 0, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "5回合后，自身属性变为火元素\n5回合后，回血 100%",
		Skill = {
			{
				Id = 105157,
				Value = 210002,
			},
			{
				Id = 105013,
				Value = 100,
			},
		},
	},
	Tags = {
		560111,
		564556,
		564560,
	},
}
EnemyConfig[EnemyID.Id6200] =
{
	Id = 6200,
	Name = "伪造鱼化石",
	Rarity = 2,
	Element = 210001,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：伪造身份证件。",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	IconName = "Arena_MUS_FishboneFossils",
	PrefabBundle = "character_arenaenemy",
	PrefabName = "Arena_MUS_FishboneFossils",
	PrefabScale = 50,
	HPBarHeight = 125,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 2297, Gain = 460},
		{Value = 200002, Base = 39, Gain = 8},
		{Value = 200003, Base = 0, Gain = 1},
		{Value = 200004, Base = 0, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "5回合后，自身属性变为火元素\n5回合后，回血 100%",
		Skill = {
			{
				Id = 105157,
				Value = 210002,
			},
			{
				Id = 105013,
				Value = 100,
			},
		},
	},
	Tags = {
		560111,
		564556,
		564560,
	},
}
EnemyConfig[EnemyID.Id6201] =
{
	Id = 6201,
	Name = "伪造鱼化石",
	Rarity = 2,
	Element = 210001,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：伪造身份证件。",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	IconName = "Arena_MUS_FishboneFossils",
	PrefabBundle = "character_arenaenemy",
	PrefabName = "Arena_MUS_FishboneFossils",
	PrefabScale = 50,
	HPBarHeight = 125,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 2882, Gain = 577},
		{Value = 200002, Base = 42, Gain = 9},
		{Value = 200003, Base = 0, Gain = 1},
		{Value = 200004, Base = 0, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "5回合后，自身属性变为火元素\n5回合后，回血 100%",
		Skill = {
			{
				Id = 105157,
				Value = 210002,
			},
			{
				Id = 105013,
				Value = 100,
			},
		},
	},
	Tags = {
		560111,
		564556,
		564560,
	},
}
EnemyConfig[EnemyID.Id6202] =
{
	Id = 6202,
	Name = "伪造龟化石",
	Rarity = 2,
	Element = 210001,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：伪造身份证件。",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	IconName = "Arena_MUS_FishboneFossils2",
	PrefabBundle = "character_arenaenemy",
	PrefabName = "Arena_MUS_FishboneFossils2",
	PrefabScale = 50,
	HPBarHeight = 110,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 2178, Gain = 436},
		{Value = 200002, Base = 36, Gain = 8},
		{Value = 200003, Base = 0, Gain = 1},
		{Value = 200004, Base = 0, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "5回合后，自身属性变为光元素\n5回合后，回血 100%",
		Skill = {
			{
				Id = 105159,
				Value = 210004,
			},
			{
				Id = 105013,
				Value = 100,
			},
		},
	},
	Tags = {
		560111,
		564556,
		564560,
	},
}
EnemyConfig[EnemyID.Id6203] =
{
	Id = 6203,
	Name = "伪造龟化石",
	Rarity = 2,
	Element = 210001,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：伪造身份证件。",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	IconName = "Arena_MUS_FishboneFossils2",
	PrefabBundle = "character_arenaenemy",
	PrefabName = "Arena_MUS_FishboneFossils2",
	PrefabScale = 50,
	HPBarHeight = 110,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 2297, Gain = 460},
		{Value = 200002, Base = 39, Gain = 8},
		{Value = 200003, Base = 0, Gain = 1},
		{Value = 200004, Base = 0, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "5回合后，自身属性变为光元素\n5回合后，回血 100%",
		Skill = {
			{
				Id = 105159,
				Value = 210004,
			},
			{
				Id = 105013,
				Value = 100,
			},
		},
	},
	Tags = {
		560111,
		564556,
		564560,
	},
}
EnemyConfig[EnemyID.Id6204] =
{
	Id = 6204,
	Name = "伪造龟化石",
	Rarity = 2,
	Element = 210001,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：伪造身份证件。",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	IconName = "Arena_MUS_FishboneFossils2",
	PrefabBundle = "character_arenaenemy",
	PrefabName = "Arena_MUS_FishboneFossils2",
	PrefabScale = 50,
	HPBarHeight = 110,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 2882, Gain = 577},
		{Value = 200002, Base = 42, Gain = 9},
		{Value = 200003, Base = 0, Gain = 1},
		{Value = 200004, Base = 0, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "5回合后，自身属性变为光元素\n5回合后，回血 100%",
		Skill = {
			{
				Id = 105159,
				Value = 210004,
			},
			{
				Id = 105013,
				Value = 100,
			},
		},
	},
	Tags = {
		560111,
		564556,
		564560,
	},
}
EnemyConfig[EnemyID.Id6205] =
{
	Id = 6205,
	Name = "黑鱬",
	Rarity = 2,
	Element = 210005,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：长期趴在地上留下难以清洗的污痕。",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	IconName = "Arena_MUS_GreenMermaid",
	PrefabBundle = "character_arenaenemy",
	PrefabName = "Arena_MUS_GreenMermaid",
	PrefabScale = 50,
	HPBarHeight = 125,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 2107, Gain = 422},
		{Value = 200002, Base = 35, Gain = 7},
		{Value = 200003, Base = 0, Gain = 1},
		{Value = 200004, Base = 0, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "5回合后，自身属性变为水元素\n受火元素敌人伤害 -75%",
		Skill = {
			{
				Id = 105156,
				Value = 210001,
			},
			{
				Id = 105034,
				Value = -75,
			},
		},
	},
	Tags = {
		560111,
		564556,
	},
}
EnemyConfig[EnemyID.Id6206] =
{
	Id = 6206,
	Name = "黑鱬",
	Rarity = 2,
	Element = 210005,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：长期趴在地上留下难以清洗的污痕。",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	IconName = "Arena_MUS_GreenMermaid",
	PrefabBundle = "character_arenaenemy",
	PrefabName = "Arena_MUS_GreenMermaid",
	PrefabScale = 50,
	HPBarHeight = 125,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 2213, Gain = 443},
		{Value = 200002, Base = 39, Gain = 8},
		{Value = 200003, Base = 0, Gain = 1},
		{Value = 200004, Base = 0, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "5回合后，自身属性变为水元素\n受火元素敌人伤害 -75%",
		Skill = {
			{
				Id = 105156,
				Value = 210001,
			},
			{
				Id = 105034,
				Value = -75,
			},
		},
	},
	Tags = {
		560111,
		564556,
	},
}
EnemyConfig[EnemyID.Id6207] =
{
	Id = 6207,
	Name = "黑鱬",
	Rarity = 2,
	Element = 210005,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：长期趴在地上留下难以清洗的污痕。",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	IconName = "Arena_MUS_GreenMermaid",
	PrefabBundle = "character_arenaenemy",
	PrefabName = "Arena_MUS_GreenMermaid",
	PrefabScale = 50,
	HPBarHeight = 125,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 2767, Gain = 554},
		{Value = 200002, Base = 42, Gain = 9},
		{Value = 200003, Base = 0, Gain = 1},
		{Value = 200004, Base = 0, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "5回合后，自身属性变为水元素\n受火元素敌人伤害 -75%",
		Skill = {
			{
				Id = 105156,
				Value = 210001,
			},
			{
				Id = 105034,
				Value = -75,
			},
		},
	},
	Tags = {
		560111,
		564556,
	},
}
EnemyConfig[EnemyID.Id6208] =
{
	Id = 6208,
	Name = "紫鱬",
	Rarity = 2,
	Element = 210001,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：长期来回移动留下难以清洗的污痕。",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	IconName = "Arena_MUS_BlownMermaid",
	PrefabBundle = "character_arenaenemy",
	PrefabName = "Arena_MUS_BlownMermaid",
	PrefabScale = 50,
	HPBarHeight = 125,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 2107, Gain = 422},
		{Value = 200002, Base = 35, Gain = 7},
		{Value = 200003, Base = 0, Gain = 1},
		{Value = 200004, Base = 0, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "每3回合将自身元素变为随机元素\n受火元素敌人伤害 -75%",
		Skill = {
			{
				Id = 105163,
				Value = -1,
			},
			{
				Id = 105034,
				Value = -75,
			},
		},
	},
	Tags = {
		560111,
		564556,
	},
}
EnemyConfig[EnemyID.Id6209] =
{
	Id = 6209,
	Name = "紫鱬",
	Rarity = 2,
	Element = 210001,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：长期来回移动留下难以清洗的污痕。",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	IconName = "Arena_MUS_BlownMermaid",
	PrefabBundle = "character_arenaenemy",
	PrefabName = "Arena_MUS_BlownMermaid",
	PrefabScale = 50,
	HPBarHeight = 125,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 2213, Gain = 443},
		{Value = 200002, Base = 39, Gain = 8},
		{Value = 200003, Base = 0, Gain = 1},
		{Value = 200004, Base = 0, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "每3回合将自身元素变为随机元素\n受火元素敌人伤害 -75%",
		Skill = {
			{
				Id = 105163,
				Value = -1,
			},
			{
				Id = 105034,
				Value = -75,
			},
		},
	},
	Tags = {
		560111,
		564556,
	},
}
EnemyConfig[EnemyID.Id6210] =
{
	Id = 6210,
	Name = "紫鱬",
	Rarity = 2,
	Element = 210001,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：长期来回移动留下难以清洗的污痕。",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	IconName = "Arena_MUS_BlownMermaid",
	PrefabBundle = "character_arenaenemy",
	PrefabName = "Arena_MUS_BlownMermaid",
	PrefabScale = 50,
	HPBarHeight = 125,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 2767, Gain = 554},
		{Value = 200002, Base = 42, Gain = 9},
		{Value = 200003, Base = 0, Gain = 1},
		{Value = 200004, Base = 0, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "每3回合将自身元素变为随机元素\n受火元素敌人伤害 -75%",
		Skill = {
			{
				Id = 105163,
				Value = -1,
			},
			{
				Id = 105034,
				Value = -75,
			},
		},
	},
	Tags = {
		560111,
		564556,
	},
}
EnemyConfig[EnemyID.Id6211] =
{
	Id = 6211,
	Name = "灾祸鸮卣",
	Rarity = 2,
	Element = 210005,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：什么都没做，但是会引来灾祸。",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	IconName = "Arena_MUS_WineJar",
	PrefabBundle = "character_arenaenemy",
	PrefabName = "Arena_MUS_WineJar",
	PrefabScale = 50,
	HPBarHeight = 144,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 2212, Gain = 443},
		{Value = 200002, Base = 40, Gain = 8},
		{Value = 200003, Base = 0, Gain = 1},
		{Value = 200004, Base = 0, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "每回合回血 10%，最多5次\n每回合有25%概率对前2个队员造成75%攻击伤害\n或对前3个队员造成50%攻击伤害\n或对所有队员造成30%攻击伤害",
		Skill = {
			{
				Id = 105005,
				Value = 10,
			},
			{
				Id = 105120,
				Value = 75,
			},
			{
				Id = 105121,
				Value = 50,
			},
			{
				Id = 105127,
				Value = 30,
			},
		},
	},
	Tags = {
		560111,
		564555,
		564560,
	},
}
EnemyConfig[EnemyID.Id6212] =
{
	Id = 6212,
	Name = "灾祸鸮卣",
	Rarity = 2,
	Element = 210005,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：什么都没做，但是会引来灾祸。",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	IconName = "Arena_MUS_WineJar",
	PrefabBundle = "character_arenaenemy",
	PrefabName = "Arena_MUS_WineJar",
	PrefabScale = 50,
	HPBarHeight = 144,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 2674, Gain = 535},
		{Value = 200002, Base = 41, Gain = 9},
		{Value = 200003, Base = 0, Gain = 1},
		{Value = 200004, Base = 0, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "每回合回血 10%，最多5次\n每回合有25%概率对前2个队员造成75%攻击伤害\n或对前3个队员造成50%攻击伤害\n或对所有队员造成30%攻击伤害",
		Skill = {
			{
				Id = 105005,
				Value = 10,
			},
			{
				Id = 105120,
				Value = 75,
			},
			{
				Id = 105121,
				Value = 50,
			},
			{
				Id = 105127,
				Value = 30,
			},
		},
	},
	Tags = {
		560111,
		564555,
		564560,
	},
}
EnemyConfig[EnemyID.Id6213] =
{
	Id = 6213,
	Name = "灾祸鸮卣",
	Rarity = 2,
	Element = 210005,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：什么都没做，但是会引来灾祸。",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	IconName = "Arena_MUS_WineJar",
	PrefabBundle = "character_arenaenemy",
	PrefabName = "Arena_MUS_WineJar",
	PrefabScale = 50,
	HPBarHeight = 144,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 3076, Gain = 616},
		{Value = 200002, Base = 43, Gain = 9},
		{Value = 200003, Base = 0, Gain = 1},
		{Value = 200004, Base = 0, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "每回合回血 10%，最多5次\n每回合有25%概率对前2个队员造成75%攻击伤害\n或对前3个队员造成50%攻击伤害\n或对所有队员造成30%攻击伤害",
		Skill = {
			{
				Id = 105005,
				Value = 10,
			},
			{
				Id = 105120,
				Value = 75,
			},
			{
				Id = 105121,
				Value = 50,
			},
			{
				Id = 105127,
				Value = 30,
			},
		},
	},
	Tags = {
		560111,
		564555,
		564560,
	},
}
EnemyConfig[EnemyID.Id6214] =
{
	Id = 6214,
	Name = "不详鸮卣",
	Rarity = 4,
	Element = 210001,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：破坏研究院，盗走核心芯片。",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	IconName = "Arena_MUS_GoldenWineJar",
	PrefabBundle = "character_arenaenemy",
	PrefabName = "Arena_MUS_GoldenWineJar",
	PrefabScale = 50,
	HPBarHeight = 120,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 2212, Gain = 443},
		{Value = 200002, Base = 40, Gain = 8},
		{Value = 200003, Base = 0, Gain = 1},
		{Value = 200004, Base = 0, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "每回合攻击 +20%，最多5次\n每回合有25%概率对前2个队员造成75%攻击伤害\n或对前3个队员造成50%攻击伤害\n或对所有队员造成30%攻击伤害",
		Skill = {
			{
				Id = 105006,
				Value = 20,
			},
			{
				Id = 105120,
				Value = 75,
			},
			{
				Id = 105121,
				Value = 50,
			},
			{
				Id = 105127,
				Value = 30,
			},
		},
	},
	Tags = {
		560111,
		564555,
		564561,
	},
}
EnemyConfig[EnemyID.Id6215] =
{
	Id = 6215,
	Name = "不详鸮卣",
	Rarity = 4,
	Element = 210001,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：破坏研究院，盗走核心芯片。",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	IconName = "Arena_MUS_GoldenWineJar",
	PrefabBundle = "character_arenaenemy",
	PrefabName = "Arena_MUS_GoldenWineJar",
	PrefabScale = 50,
	HPBarHeight = 120,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 2674, Gain = 535},
		{Value = 200002, Base = 41, Gain = 9},
		{Value = 200003, Base = 0, Gain = 1},
		{Value = 200004, Base = 0, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "每回合攻击 +20%，最多5次\n每回合有25%概率对前2个队员造成75%攻击伤害\n或对前3个队员造成50%攻击伤害\n或对所有队员造成30%攻击伤害",
		Skill = {
			{
				Id = 105006,
				Value = 20,
			},
			{
				Id = 105120,
				Value = 75,
			},
			{
				Id = 105121,
				Value = 50,
			},
			{
				Id = 105127,
				Value = 30,
			},
		},
	},
	Tags = {
		560111,
		564555,
		564561,
	},
}
EnemyConfig[EnemyID.Id6216] =
{
	Id = 6216,
	Name = "不详鸮卣",
	Rarity = 4,
	Element = 210001,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：破坏研究院，盗走核心芯片。",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	IconName = "Arena_MUS_GoldenWineJar",
	PrefabBundle = "character_arenaenemy",
	PrefabName = "Arena_MUS_GoldenWineJar",
	PrefabScale = 50,
	HPBarHeight = 120,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 3076, Gain = 616},
		{Value = 200002, Base = 43, Gain = 9},
		{Value = 200003, Base = 0, Gain = 1},
		{Value = 200004, Base = 0, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "每回合攻击 +20%，最多5次\n每回合有25%概率对前2个队员造成75%攻击伤害\n或对前3个队员造成50%攻击伤害\n或对所有队员造成30%攻击伤害",
		Skill = {
			{
				Id = 105006,
				Value = 20,
			},
			{
				Id = 105120,
				Value = 75,
			},
			{
				Id = 105121,
				Value = 50,
			},
			{
				Id = 105127,
				Value = 30,
			},
		},
	},
	Tags = {
		560111,
		564555,
		564561,
	},
}
EnemyConfig[EnemyID.Id6217] =
{
	Id = 6217,
	Name = "火山快走龙",
	Rarity = 2,
	Element = 210002,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：不顾身体高温易燃，随意在馆内散步，引发火灾。",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	IconName = "Arena_MUS_DinosaurEgg",
	PrefabBundle = "character_arenaenemy",
	PrefabName = "Arena_MUS_DinosaurEgg",
	PrefabScale = 50,
	HPBarHeight = 110,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 2363, Gain = 473},
		{Value = 200002, Base = 41, Gain = 9},
		{Value = 200003, Base = 0, Gain = 1},
		{Value = 200004, Base = 0, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "有15%概率额外攻击2次\n受光元素敌人伤害 -75%",
		Skill = {
			{
				Id = 105024,
				Value = 15,
			},
			{
				Id = 105036,
				Value = -75,
			},
		},
	},
	Tags = {
		560111,
		564556,
		564558,
	},
}
EnemyConfig[EnemyID.Id6218] =
{
	Id = 6218,
	Name = "火山快走龙",
	Rarity = 2,
	Element = 210002,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：不顾身体高温易燃，随意在馆内散步，引发火灾。",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	IconName = "Arena_MUS_DinosaurEgg",
	PrefabBundle = "character_arenaenemy",
	PrefabName = "Arena_MUS_DinosaurEgg",
	PrefabScale = 50,
	HPBarHeight = 110,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 2464, Gain = 493},
		{Value = 200002, Base = 45, Gain = 9},
		{Value = 200003, Base = 0, Gain = 1},
		{Value = 200004, Base = 0, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "有15%概率额外攻击2次\n受光元素敌人伤害 -75%",
		Skill = {
			{
				Id = 105024,
				Value = 15,
			},
			{
				Id = 105036,
				Value = -75,
			},
		},
	},
	Tags = {
		560111,
		564556,
		564558,
	},
}
EnemyConfig[EnemyID.Id6219] =
{
	Id = 6219,
	Name = "火山快走龙",
	Rarity = 2,
	Element = 210002,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：不顾身体高温易燃，随意在馆内散步，引发火灾。",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	IconName = "Arena_MUS_DinosaurEgg",
	PrefabBundle = "character_arenaenemy",
	PrefabName = "Arena_MUS_DinosaurEgg",
	PrefabScale = 50,
	HPBarHeight = 110,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 3061, Gain = 613},
		{Value = 200002, Base = 49, Gain = 10},
		{Value = 200003, Base = 0, Gain = 1},
		{Value = 200004, Base = 0, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "有15%概率额外攻击2次\n受光元素敌人伤害 -75%",
		Skill = {
			{
				Id = 105024,
				Value = 15,
			},
			{
				Id = 105036,
				Value = -75,
			},
		},
	},
	Tags = {
		560111,
		564556,
		564558,
	},
}
EnemyConfig[EnemyID.Id6220] =
{
	Id = 6220,
	Name = "荒原快走龙",
	Rarity = 2,
	Element = 210003,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：喝掉太多水导致博物馆瓶装水价格上涨。",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	IconName = "Arena_MUS_DinosaurEgg2",
	PrefabBundle = "character_arenaenemy",
	PrefabName = "Arena_MUS_DinosaurEgg2",
	PrefabScale = 50,
	HPBarHeight = 110,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 2363, Gain = 473},
		{Value = 200002, Base = 41, Gain = 9},
		{Value = 200003, Base = 0, Gain = 1},
		{Value = 200004, Base = 0, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "暴击 +80\n暴击伤害 +100%\n受暗元素敌人伤害 -75%",
		Skill = {
			{
				Id = 105004,
				Value = 80,
			},
			{
				Id = 105038,
				Value = 100,
			},
			{
				Id = 105037,
				Value = -75,
			},
		},
	},
	Tags = {
		560111,
		564556,
		564561,
	},
}
EnemyConfig[EnemyID.Id6221] =
{
	Id = 6221,
	Name = "荒原快走龙",
	Rarity = 2,
	Element = 210003,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：喝掉太多水导致博物馆瓶装水价格上涨。",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	IconName = "Arena_MUS_DinosaurEgg2",
	PrefabBundle = "character_arenaenemy",
	PrefabName = "Arena_MUS_DinosaurEgg2",
	PrefabScale = 50,
	HPBarHeight = 110,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 2464, Gain = 493},
		{Value = 200002, Base = 45, Gain = 9},
		{Value = 200003, Base = 0, Gain = 1},
		{Value = 200004, Base = 0, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "暴击 +80\n暴击伤害 +100%\n受暗元素敌人伤害 -75%",
		Skill = {
			{
				Id = 105004,
				Value = 80,
			},
			{
				Id = 105038,
				Value = 100,
			},
			{
				Id = 105037,
				Value = -75,
			},
		},
	},
	Tags = {
		560111,
		564556,
		564561,
	},
}
EnemyConfig[EnemyID.Id6222] =
{
	Id = 6222,
	Name = "荒原快走龙",
	Rarity = 2,
	Element = 210003,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：喝掉太多水导致博物馆瓶装水价格上涨。",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	IconName = "Arena_MUS_DinosaurEgg2",
	PrefabBundle = "character_arenaenemy",
	PrefabName = "Arena_MUS_DinosaurEgg2",
	PrefabScale = 50,
	HPBarHeight = 110,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 3061, Gain = 613},
		{Value = 200002, Base = 49, Gain = 10},
		{Value = 200003, Base = 0, Gain = 1},
		{Value = 200004, Base = 0, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "暴击 +80\n暴击伤害 +100%\n受暗元素敌人伤害 -75%",
		Skill = {
			{
				Id = 105004,
				Value = 80,
			},
			{
				Id = 105038,
				Value = 100,
			},
			{
				Id = 105037,
				Value = -75,
			},
		},
	},
	Tags = {
		560111,
		564556,
		564561,
	},
}
EnemyConfig[EnemyID.Id6223] =
{
	Id = 6223,
	Name = "地狱一角龙",
	Rarity = 3,
	Element = 210005,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：在博物馆内挖洞。",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	IconName = "Arena_MUS_RedDinosaur",
	PrefabBundle = "character_arenaenemy",
	PrefabName = "Arena_MUS_RedDinosaur",
	PrefabScale = 50,
	HPBarHeight = 125,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 2293, Gain = 459},
		{Value = 200002, Base = 41, Gain = 9},
		{Value = 200003, Base = 0, Gain = 1},
		{Value = 200004, Base = 0, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "受火元素敌人伤害 -80%\n每回合对前2个队员造成100%攻击伤害",
		Skill = {
			{
				Id = 105034,
				Value = -80,
			},
			{
				Id = 105040,
				Value = 100,
			},
		},
	},
	Tags = {
		560111,
		564556,
	},
}
EnemyConfig[EnemyID.Id6224] =
{
	Id = 6224,
	Name = "地狱一角龙",
	Rarity = 3,
	Element = 210005,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：在博物馆内挖洞。",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	IconName = "Arena_MUS_RedDinosaur",
	PrefabBundle = "character_arenaenemy",
	PrefabName = "Arena_MUS_RedDinosaur",
	PrefabScale = 50,
	HPBarHeight = 125,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 2383, Gain = 477},
		{Value = 200002, Base = 44, Gain = 9},
		{Value = 200003, Base = 0, Gain = 1},
		{Value = 200004, Base = 0, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "受火元素敌人伤害 -80%\n每回合对前2个队员造成100%攻击伤害",
		Skill = {
			{
				Id = 105034,
				Value = -80,
			},
			{
				Id = 105040,
				Value = 100,
			},
		},
	},
	Tags = {
		560111,
		564556,
	},
}
EnemyConfig[EnemyID.Id6225] =
{
	Id = 6225,
	Name = "地狱一角龙",
	Rarity = 3,
	Element = 210005,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：在博物馆内挖洞。",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	IconName = "Arena_MUS_RedDinosaur",
	PrefabBundle = "character_arenaenemy",
	PrefabName = "Arena_MUS_RedDinosaur",
	PrefabScale = 50,
	HPBarHeight = 125,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 2952, Gain = 591},
		{Value = 200002, Base = 48, Gain = 10},
		{Value = 200003, Base = 0, Gain = 1},
		{Value = 200004, Base = 0, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "受火元素敌人伤害 -80%\n每回合对前2个队员造成100%攻击伤害",
		Skill = {
			{
				Id = 105034,
				Value = -80,
			},
			{
				Id = 105040,
				Value = 100,
			},
		},
	},
	Tags = {
		560111,
		564556,
	},
}
EnemyConfig[EnemyID.Id6226] =
{
	Id = 6226,
	Name = "雨林一角龙",
	Rarity = 2,
	Element = 210001,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：在博物馆内喷水。",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	IconName = "Arena_MUS_BlueDinosaur",
	PrefabBundle = "character_arenaenemy",
	PrefabName = "Arena_MUS_BlueDinosaur",
	PrefabScale = 50,
	HPBarHeight = 125,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 2293, Gain = 459},
		{Value = 200002, Base = 41, Gain = 9},
		{Value = 200003, Base = 0, Gain = 1},
		{Value = 200004, Base = 0, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "受暗元素敌人伤害 -80%\n忍耐 +120",
		Skill = {
			{
				Id = 105037,
				Value = -80,
			},
			{
				Id = 105003,
				Value = 120,
			},
		},
	},
	Tags = {
		560111,
		564556,
		564561,
	},
}
EnemyConfig[EnemyID.Id6227] =
{
	Id = 6227,
	Name = "雨林一角龙",
	Rarity = 2,
	Element = 210001,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：在博物馆内喷水。",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	IconName = "Arena_MUS_BlueDinosaur",
	PrefabBundle = "character_arenaenemy",
	PrefabName = "Arena_MUS_BlueDinosaur",
	PrefabScale = 50,
	HPBarHeight = 125,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 2383, Gain = 477},
		{Value = 200002, Base = 44, Gain = 9},
		{Value = 200003, Base = 0, Gain = 1},
		{Value = 200004, Base = 0, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "受暗元素敌人伤害 -80%\n忍耐 +120",
		Skill = {
			{
				Id = 105037,
				Value = -80,
			},
			{
				Id = 105003,
				Value = 120,
			},
		},
	},
	Tags = {
		560111,
		564556,
		564561,
	},
}
EnemyConfig[EnemyID.Id6228] =
{
	Id = 6228,
	Name = "雨林一角龙",
	Rarity = 2,
	Element = 210001,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：在博物馆内喷水。",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	IconName = "Arena_MUS_BlueDinosaur",
	PrefabBundle = "character_arenaenemy",
	PrefabName = "Arena_MUS_BlueDinosaur",
	PrefabScale = 50,
	HPBarHeight = 125,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 2952, Gain = 591},
		{Value = 200002, Base = 48, Gain = 10},
		{Value = 200003, Base = 0, Gain = 1},
		{Value = 200004, Base = 0, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "受暗元素敌人伤害 -80%\n忍耐 +120",
		Skill = {
			{
				Id = 105037,
				Value = -80,
			},
			{
				Id = 105003,
				Value = 120,
			},
		},
	},
	Tags = {
		560111,
		564556,
		564561,
	},
}
EnemyConfig[EnemyID.Id6229] =
{
	Id = 6229,
	Name = "黑客摄像头",
	Rarity = 4,
	Element = 210004,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：伪装成普通摄像头进行偷窥。",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	IconName = "Arena_MUS_Camera",
	PrefabBundle = "character_arenaenemy",
	PrefabName = "Arena_MUS_Camera",
	PrefabScale = 50,
	HPBarHeight = 110,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 2228, Gain = 446},
		{Value = 200002, Base = 40, Gain = 8},
		{Value = 200003, Base = 0, Gain = 1},
		{Value = 200004, Base = 0, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "每回合对所有队员造成35%攻击伤害\n每3回合，80%概率无视敌人闪避",
		Skill = {
			{
				Id = 105047,
				Value = 35,
			},
			{
				Id = 105141,
				Value = 80,
			},
		},
	},
	Tags = {
		560111,
		564556,
		564559,
	},
}
EnemyConfig[EnemyID.Id6230] =
{
	Id = 6230,
	Name = "黑客摄像头",
	Rarity = 4,
	Element = 210004,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：伪装成普通摄像头进行偷窥。",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	IconName = "Arena_MUS_Camera",
	PrefabBundle = "character_arenaenemy",
	PrefabName = "Arena_MUS_Camera",
	PrefabScale = 50,
	HPBarHeight = 110,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 2308, Gain = 462},
		{Value = 200002, Base = 44, Gain = 9},
		{Value = 200003, Base = 0, Gain = 1},
		{Value = 200004, Base = 0, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "每回合对所有队员造成35%攻击伤害\n每3回合，80%概率无视敌人闪避",
		Skill = {
			{
				Id = 105047,
				Value = 35,
			},
			{
				Id = 105141,
				Value = 80,
			},
		},
	},
	Tags = {
		560111,
		564556,
		564559,
	},
}
EnemyConfig[EnemyID.Id6231] =
{
	Id = 6231,
	Name = "黑客摄像头",
	Rarity = 4,
	Element = 210004,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：伪装成普通摄像头进行偷窥。",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	IconName = "Arena_MUS_Camera",
	PrefabBundle = "character_arenaenemy",
	PrefabName = "Arena_MUS_Camera",
	PrefabScale = 50,
	HPBarHeight = 110,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 2851, Gain = 571},
		{Value = 200002, Base = 48, Gain = 10},
		{Value = 200003, Base = 0, Gain = 1},
		{Value = 200004, Base = 0, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "每回合对所有队员造成35%攻击伤害\n每3回合，80%概率无视敌人闪避",
		Skill = {
			{
				Id = 105047,
				Value = 35,
			},
			{
				Id = 105141,
				Value = 80,
			},
		},
	},
	Tags = {
		560111,
		564556,
		564559,
	},
}
EnemyConfig[EnemyID.Id6232] =
{
	Id = 6232,
	Name = "斑点缸",
	Rarity = 3,
	Element = 210004,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：把所有的东西都涂上斑点。",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	IconName = "Arena_MUS_PigJar",
	PrefabBundle = "character_arenaenemy",
	PrefabName = "Arena_MUS_PigJar",
	PrefabScale = 50,
	HPBarHeight = 125,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 2228, Gain = 446},
		{Value = 200002, Base = 40, Gain = 8},
		{Value = 200003, Base = 0, Gain = 1},
		{Value = 200004, Base = 0, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "生命 +150%\n每回合回血 8%，最多5次",
		Skill = {
			{
				Id = 105001,
				Value = 150,
			},
			{
				Id = 105005,
				Value = 8,
			},
		},
	},
	Tags = {
		560111,
		564556,
		564560,
		564561,
	},
}
EnemyConfig[EnemyID.Id6233] =
{
	Id = 6233,
	Name = "斑点缸",
	Rarity = 3,
	Element = 210004,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：把所有的东西都涂上斑点。",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	IconName = "Arena_MUS_PigJar",
	PrefabBundle = "character_arenaenemy",
	PrefabName = "Arena_MUS_PigJar",
	PrefabScale = 50,
	HPBarHeight = 125,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 2308, Gain = 462},
		{Value = 200002, Base = 44, Gain = 9},
		{Value = 200003, Base = 0, Gain = 1},
		{Value = 200004, Base = 0, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "生命 +150%\n每回合回血 8%，最多5次",
		Skill = {
			{
				Id = 105001,
				Value = 150,
			},
			{
				Id = 105005,
				Value = 8,
			},
		},
	},
	Tags = {
		560111,
		564556,
		564560,
		564561,
	},
}
EnemyConfig[EnemyID.Id6234] =
{
	Id = 6234,
	Name = "斑点缸",
	Rarity = 3,
	Element = 210004,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：把所有的东西都涂上斑点。",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	IconName = "Arena_MUS_PigJar",
	PrefabBundle = "character_arenaenemy",
	PrefabName = "Arena_MUS_PigJar",
	PrefabScale = 50,
	HPBarHeight = 125,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 2851, Gain = 571},
		{Value = 200002, Base = 48, Gain = 10},
		{Value = 200003, Base = 0, Gain = 1},
		{Value = 200004, Base = 0, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "生命 +150%\n每回合回血 8%，最多5次",
		Skill = {
			{
				Id = 105001,
				Value = 150,
			},
			{
				Id = 105005,
				Value = 8,
			},
		},
	},
	Tags = {
		560111,
		564556,
		564560,
		564561,
	},
}
EnemyConfig[EnemyID.Id6235] =
{
	Id = 6235,
	Name = "克隆化石",
	Rarity = 3,
	Element = 210003,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：精神状态不稳定，容易做出出格行为。",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	IconName = "Arena_MUS_DinosaurFossils",
	PrefabBundle = "character_arenaenemy",
	PrefabName = "Arena_MUS_DinosaurFossils",
	PrefabScale = 50,
	HPBarHeight = 120,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 2166, Gain = 434},
		{Value = 200002, Base = 40, Gain = 8},
		{Value = 200003, Base = 0, Gain = 1},
		{Value = 200004, Base = 0, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "5回合后，回血 75%\n5回合后，攻击 +100%",
		Skill = {
			{
				Id = 105013,
				Value = 75,
			},
			{
				Id = 105014,
				Value = 100,
			},
		},
	},
	Tags = {
		560111,
		564556,
		564560,
		564561,
	},
}
EnemyConfig[EnemyID.Id6236] =
{
	Id = 6236,
	Name = "克隆化石",
	Rarity = 3,
	Element = 210003,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：精神状态不稳定，容易做出出格行为。",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	IconName = "Arena_MUS_DinosaurFossils",
	PrefabBundle = "character_arenaenemy",
	PrefabName = "Arena_MUS_DinosaurFossils",
	PrefabScale = 50,
	HPBarHeight = 120,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 2237, Gain = 448},
		{Value = 200002, Base = 43, Gain = 9},
		{Value = 200003, Base = 0, Gain = 1},
		{Value = 200004, Base = 0, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "5回合后，回血 75%\n5回合后，攻击 +100%",
		Skill = {
			{
				Id = 105013,
				Value = 75,
			},
			{
				Id = 105014,
				Value = 100,
			},
		},
	},
	Tags = {
		560111,
		564556,
		564560,
		564561,
	},
}
EnemyConfig[EnemyID.Id6237] =
{
	Id = 6237,
	Name = "克隆化石",
	Rarity = 3,
	Element = 210003,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：精神状态不稳定，容易做出出格行为。",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	IconName = "Arena_MUS_DinosaurFossils",
	PrefabBundle = "character_arenaenemy",
	PrefabName = "Arena_MUS_DinosaurFossils",
	PrefabScale = 50,
	HPBarHeight = 120,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 2757, Gain = 552},
		{Value = 200002, Base = 47, Gain = 10},
		{Value = 200003, Base = 0, Gain = 1},
		{Value = 200004, Base = 0, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "5回合后，回血 75%\n5回合后，攻击 +100%",
		Skill = {
			{
				Id = 105013,
				Value = 75,
			},
			{
				Id = 105014,
				Value = 100,
			},
		},
	},
	Tags = {
		560111,
		564556,
		564560,
		564561,
	},
}
EnemyConfig[EnemyID.Id6238] =
{
	Id = 6238,
	Name = "绝味鸭",
	Rarity = 4,
	Element = 210003,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：在禁止饮食的博物馆内贩卖鸭脖。",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	IconName = "Arena_MUS_WoodenDuck",
	PrefabBundle = "character_arenaenemy",
	PrefabName = "Arena_MUS_WoodenDuck",
	PrefabScale = 50,
	HPBarHeight = 120,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 2166, Gain = 434},
		{Value = 200002, Base = 40, Gain = 8},
		{Value = 200003, Base = 0, Gain = 1},
		{Value = 200004, Base = 0, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "受到的暴击伤害 -50%\n每3回合，100%概率闪避攻击\n受火元素敌人伤害 -75%\n5回合后，回血 30%",
		Skill = {
			{
				Id = 105039,
				Value = -50,
			},
			{
				Id = 105140,
				Value = 100,
			},
			{
				Id = 105034,
				Value = -75,
			},
			{
				Id = 105013,
				Value = 30,
			},
		},
	},
	Tags = {
		560111,
		564556,
		564557,
		564560,
	},
}
EnemyConfig[EnemyID.Id6239] =
{
	Id = 6239,
	Name = "绝味鸭",
	Rarity = 4,
	Element = 210003,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：在禁止饮食的博物馆内贩卖鸭脖。",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	IconName = "Arena_MUS_WoodenDuck",
	PrefabBundle = "character_arenaenemy",
	PrefabName = "Arena_MUS_WoodenDuck",
	PrefabScale = 50,
	HPBarHeight = 120,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 2237, Gain = 448},
		{Value = 200002, Base = 43, Gain = 9},
		{Value = 200003, Base = 0, Gain = 1},
		{Value = 200004, Base = 0, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "受到的暴击伤害 -50%\n每3回合，100%概率闪避攻击\n受火元素敌人伤害 -75%\n5回合后，回血 30%",
		Skill = {
			{
				Id = 105039,
				Value = -50,
			},
			{
				Id = 105140,
				Value = 100,
			},
			{
				Id = 105034,
				Value = -75,
			},
			{
				Id = 105013,
				Value = 30,
			},
		},
	},
	Tags = {
		560111,
		564556,
		564557,
		564560,
	},
}
EnemyConfig[EnemyID.Id6240] =
{
	Id = 6240,
	Name = "绝味鸭",
	Rarity = 4,
	Element = 210003,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：在禁止饮食的博物馆内贩卖鸭脖。",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	IconName = "Arena_MUS_WoodenDuck",
	PrefabBundle = "character_arenaenemy",
	PrefabName = "Arena_MUS_WoodenDuck",
	PrefabScale = 50,
	HPBarHeight = 120,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 2757, Gain = 552},
		{Value = 200002, Base = 47, Gain = 10},
		{Value = 200003, Base = 0, Gain = 1},
		{Value = 200004, Base = 0, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "受到的暴击伤害 -50%\n每3回合，100%概率闪避攻击\n不怕烫鸭：受火元素敌人伤害 -100%\n5回合后，回血 30%",
		Skill = {
			{
				Id = 105039,
				Value = -50,
			},
			{
				Id = 105140,
				Value = 100,
			},
			{
				Id = 105034,
				Value = -100,
			},
			{
				Id = 105013,
				Value = 30,
			},
		},
	},
	Tags = {
		560111,
		564556,
		564557,
		564560,
	},
}
EnemyConfig[EnemyID.Id6241] =
{
	Id = 6241,
	Name = "厕所牌",
	Rarity = 2,
	Element = 210001,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：弄混咖啡馆的男女厕所的标识，让顾客走错厕所。",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	IconName = "Arena_SUS_NumberPlate",
	PrefabBundle = "character_arenaenemy",
	PrefabName = "Arena_SUS_NumberPlate",
	PrefabScale = 50,
	HPBarHeight = 125,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 2263, Gain = 453},
		{Value = 200002, Base = 34, Gain = 7},
		{Value = 200003, Base = 0, Gain = 1},
		{Value = 200004, Base = 0, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "忍耐 +50",
		Skill = {
			{
				Id = 105003,
				Value = 50,
			},
		},
	},
	Tags = {
		560111,
		564556,
		564561,
	},
}
EnemyConfig[EnemyID.Id6242] =
{
	Id = 6242,
	Name = "厕所牌",
	Rarity = 2,
	Element = 210001,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：弄混咖啡馆的男女厕所的标识，让顾客走错厕所。",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	IconName = "Arena_SUS_NumberPlate",
	PrefabBundle = "character_arenaenemy",
	PrefabName = "Arena_SUS_NumberPlate",
	PrefabScale = 50,
	HPBarHeight = 125,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 2481, Gain = 497},
		{Value = 200002, Base = 38, Gain = 8},
		{Value = 200003, Base = 0, Gain = 1},
		{Value = 200004, Base = 0, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "忍耐 +50",
		Skill = {
			{
				Id = 105003,
				Value = 50,
			},
		},
	},
	Tags = {
		560111,
		564556,
		564561,
	},
}
EnemyConfig[EnemyID.Id6243] =
{
	Id = 6243,
	Name = "厕所牌",
	Rarity = 2,
	Element = 210001,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：弄混咖啡馆的男女厕所的标识，让顾客走错厕所。",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	IconName = "Arena_SUS_NumberPlate",
	PrefabBundle = "character_arenaenemy",
	PrefabName = "Arena_SUS_NumberPlate",
	PrefabScale = 50,
	HPBarHeight = 125,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 3226, Gain = 646},
		{Value = 200002, Base = 41, Gain = 9},
		{Value = 200003, Base = 0, Gain = 1},
		{Value = 200004, Base = 0, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "忍耐 +50",
		Skill = {
			{
				Id = 105003,
				Value = 50,
			},
		},
	},
	Tags = {
		560111,
		564556,
		564561,
	},
}
EnemyConfig[EnemyID.Id6244] =
{
	Id = 6244,
	Name = "八卦小报",
	Rarity = 2,
	Element = 210003,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：把居民的秘密刊登在自己脸上四处传播。",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	IconName = "Arena_SUS_Newspaper",
	PrefabBundle = "character_arenaenemy",
	PrefabName = "Arena_SUS_Newspaper",
	PrefabScale = 50,
	HPBarHeight = 125,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 2168, Gain = 434},
		{Value = 200002, Base = 33, Gain = 7},
		{Value = 200003, Base = 0, Gain = 1},
		{Value = 200004, Base = 0, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "80%概率无视敌人闪避",
		Skill = {
			{
				Id = 105027,
				Value = 80,
			},
		},
	},
	Tags = {
		560111,
		564556,
		564559,
	},
}
EnemyConfig[EnemyID.Id6245] =
{
	Id = 6245,
	Name = "八卦小报",
	Rarity = 2,
	Element = 210003,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：把居民的秘密刊登在自己脸上四处传播。",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	IconName = "Arena_SUS_Newspaper",
	PrefabBundle = "character_arenaenemy",
	PrefabName = "Arena_SUS_Newspaper",
	PrefabScale = 50,
	HPBarHeight = 125,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 2361, Gain = 473},
		{Value = 200002, Base = 36, Gain = 8},
		{Value = 200003, Base = 0, Gain = 1},
		{Value = 200004, Base = 0, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "80%概率无视敌人闪避",
		Skill = {
			{
				Id = 105027,
				Value = 80,
			},
		},
	},
	Tags = {
		560111,
		564556,
		564559,
	},
}
EnemyConfig[EnemyID.Id6246] =
{
	Id = 6246,
	Name = "八卦小报",
	Rarity = 2,
	Element = 210003,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：把居民的秘密刊登在自己脸上四处传播。",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	IconName = "Arena_SUS_Newspaper",
	PrefabBundle = "character_arenaenemy",
	PrefabName = "Arena_SUS_Newspaper",
	PrefabScale = 50,
	HPBarHeight = 125,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 3049, Gain = 610},
		{Value = 200002, Base = 40, Gain = 8},
		{Value = 200003, Base = 0, Gain = 1},
		{Value = 200004, Base = 0, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "80%概率无视敌人闪避",
		Skill = {
			{
				Id = 105027,
				Value = 80,
			},
		},
	},
	Tags = {
		560111,
		564556,
		564559,
	},
}
EnemyConfig[EnemyID.Id6247] =
{
	Id = 6247,
	Name = "停摆怀表",
	Rarity = 2,
	Element = 210004,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：谎报时间，影响人们的生活。",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	IconName = "Arena_SUS_PocketWatch",
	PrefabBundle = "character_arenaenemy",
	PrefabName = "Arena_SUS_PocketWatch",
	PrefabScale = 50,
	HPBarHeight = 125,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 2168, Gain = 434},
		{Value = 200002, Base = 33, Gain = 7},
		{Value = 200003, Base = 0, Gain = 1},
		{Value = 200004, Base = 0, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "每3回合对所有队员造成75%攻击伤害",
		Skill = {
			{
				Id = 105063,
				Value = 75,
			},
		},
	},
	Tags = {
		560111,
		564556,
	},
}
EnemyConfig[EnemyID.Id6248] =
{
	Id = 6248,
	Name = "停摆怀表",
	Rarity = 2,
	Element = 210004,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：谎报时间，影响人们的生活。",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	IconName = "Arena_SUS_PocketWatch",
	PrefabBundle = "character_arenaenemy",
	PrefabName = "Arena_SUS_PocketWatch",
	PrefabScale = 50,
	HPBarHeight = 125,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 2361, Gain = 473},
		{Value = 200002, Base = 36, Gain = 8},
		{Value = 200003, Base = 0, Gain = 1},
		{Value = 200004, Base = 0, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "每3回合对所有队员造成75%攻击伤害",
		Skill = {
			{
				Id = 105063,
				Value = 75,
			},
		},
	},
	Tags = {
		560111,
		564556,
	},
}
EnemyConfig[EnemyID.Id6249] =
{
	Id = 6249,
	Name = "停摆怀表",
	Rarity = 2,
	Element = 210004,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：谎报时间，影响人们的生活。",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	IconName = "Arena_SUS_PocketWatch",
	PrefabBundle = "character_arenaenemy",
	PrefabName = "Arena_SUS_PocketWatch",
	PrefabScale = 50,
	HPBarHeight = 125,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 3049, Gain = 610},
		{Value = 200002, Base = 40, Gain = 8},
		{Value = 200003, Base = 0, Gain = 1},
		{Value = 200004, Base = 0, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "每3回合对所有队员造成75%攻击伤害",
		Skill = {
			{
				Id = 105063,
				Value = 75,
			},
		},
	},
	Tags = {
		560111,
		564556,
	},
}
EnemyConfig[EnemyID.Id6250] =
{
	Id = 6250,
	Name = "小绿帽",
	Rarity = 3,
	Element = 210001,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：扣在发生了感情问题的居民的头上。",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	IconName = "Arena_SUS_BlackHat",
	PrefabBundle = "character_arenaenemy",
	PrefabName = "Arena_SUS_BlackHat",
	PrefabScale = 50,
	HPBarHeight = 125,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 2081, Gain = 417},
		{Value = 200002, Base = 32, Gain = 7},
		{Value = 200003, Base = 0, Gain = 1},
		{Value = 200004, Base = 0, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "5回合后，回血 40%\n5回合后，暴击 +240%",
		Skill = {
			{
				Id = 105013,
				Value = 40,
			},
			{
				Id = 105016,
				Value = 240,
			},
		},
	},
	Tags = {
		560111,
		564556,
		564560,
		564561,
	},
}
EnemyConfig[EnemyID.Id6251] =
{
	Id = 6251,
	Name = "小绿帽",
	Rarity = 3,
	Element = 210001,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：扣在发生了感情问题的居民的头上。",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	IconName = "Arena_SUS_BlackHat",
	PrefabBundle = "character_arenaenemy",
	PrefabName = "Arena_SUS_BlackHat",
	PrefabScale = 50,
	HPBarHeight = 125,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 2251, Gain = 451},
		{Value = 200002, Base = 35, Gain = 7},
		{Value = 200003, Base = 0, Gain = 1},
		{Value = 200004, Base = 0, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "5回合后，回血 40%\n5回合后，暴击 +240%",
		Skill = {
			{
				Id = 105013,
				Value = 40,
			},
			{
				Id = 105016,
				Value = 240,
			},
		},
	},
	Tags = {
		560111,
		564556,
		564560,
		564561,
	},
}
EnemyConfig[EnemyID.Id6252] =
{
	Id = 6252,
	Name = "小绿帽",
	Rarity = 3,
	Element = 210001,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：扣在发生了感情问题的居民的头上。",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	IconName = "Arena_SUS_BlackHat",
	PrefabBundle = "character_arenaenemy",
	PrefabName = "Arena_SUS_BlackHat",
	PrefabScale = 50,
	HPBarHeight = 125,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 2890, Gain = 578},
		{Value = 200002, Base = 38, Gain = 8},
		{Value = 200003, Base = 0, Gain = 1},
		{Value = 200004, Base = 0, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "5回合后，回血 40%\n5回合后，暴击 +240%",
		Skill = {
			{
				Id = 105013,
				Value = 40,
			},
			{
				Id = 105016,
				Value = 240,
			},
		},
	},
	Tags = {
		560111,
		564556,
		564560,
		564561,
	},
}
EnemyConfig[EnemyID.Id6253] =
{
	Id = 6253,
	Name = "小红帽",
	Rarity = 2,
	Element = 210001,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：管所有女性都称呼为奶奶。",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	IconName = "Arena_SUS_pinkHat",
	PrefabBundle = "character_arenaenemy",
	PrefabName = "Arena_SUS_PinkHat",
	PrefabScale = 50,
	HPBarHeight = 125,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 2081, Gain = 417},
		{Value = 200002, Base = 32, Gain = 7},
		{Value = 200003, Base = 0, Gain = 1},
		{Value = 200004, Base = 0, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "5回合后，攻击 +100%",
		Skill = {
			{
				Id = 105014,
				Value = 100,
			},
		},
	},
	Tags = {
		560111,
		564556,
		564561,
	},
}
EnemyConfig[EnemyID.Id6254] =
{
	Id = 6254,
	Name = "小红帽",
	Rarity = 2,
	Element = 210001,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：管所有女性都称呼为奶奶。",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	IconName = "Arena_SUS_pinkHat",
	PrefabBundle = "character_arenaenemy",
	PrefabName = "Arena_SUS_PinkHat",
	PrefabScale = 50,
	HPBarHeight = 125,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 2251, Gain = 451},
		{Value = 200002, Base = 35, Gain = 7},
		{Value = 200003, Base = 0, Gain = 1},
		{Value = 200004, Base = 0, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "5回合后，攻击 +100%",
		Skill = {
			{
				Id = 105014,
				Value = 100,
			},
		},
	},
	Tags = {
		560111,
		564556,
		564561,
	},
}
EnemyConfig[EnemyID.Id6255] =
{
	Id = 6255,
	Name = "小红帽",
	Rarity = 2,
	Element = 210001,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：管所有女性都称呼为奶奶。",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	IconName = "Arena_SUS_pinkHat",
	PrefabBundle = "character_arenaenemy",
	PrefabName = "Arena_SUS_PinkHat",
	PrefabScale = 50,
	HPBarHeight = 125,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 2890, Gain = 578},
		{Value = 200002, Base = 38, Gain = 8},
		{Value = 200003, Base = 0, Gain = 1},
		{Value = 200004, Base = 0, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "5回合后，攻击 +100%",
		Skill = {
			{
				Id = 105014,
				Value = 100,
			},
		},
	},
	Tags = {
		560111,
		564556,
		564561,
	},
}
EnemyConfig[EnemyID.Id6256] =
{
	Id = 6256,
	Name = "鬼火路灯",
	Rarity = 3,
	Element = 210002,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：把居民引入还在修路的地区。",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	IconName = "Arena_SUS_StreetLamp",
	PrefabBundle = "character_arenaenemy",
	PrefabName = "Arena_SUS_StreetLamp",
	PrefabScale = 50,
	HPBarHeight = 140,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 2001, Gain = 401},
		{Value = 200002, Base = 31, Gain = 7},
		{Value = 200003, Base = 0, Gain = 1},
		{Value = 200004, Base = 0, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "受火元素敌人伤害 -75%\n受暗元素敌人伤害 -75%",
		Skill = {
			{
				Id = 105034,
				Value = -75,
			},
			{
				Id = 105037,
				Value = -75,
			},
		},
	},
	Tags = {
		560111,
		564556,
	},
}
EnemyConfig[EnemyID.Id6257] =
{
	Id = 6257,
	Name = "鬼火路灯",
	Rarity = 3,
	Element = 210002,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：把居民引入还在修路的地区。",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	IconName = "Arena_SUS_StreetLamp",
	PrefabBundle = "character_arenaenemy",
	PrefabName = "Arena_SUS_StreetLamp",
	PrefabScale = 50,
	HPBarHeight = 140,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 2152, Gain = 431},
		{Value = 200002, Base = 34, Gain = 7},
		{Value = 200003, Base = 0, Gain = 1},
		{Value = 200004, Base = 0, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "受火元素敌人伤害 -75%\n受暗元素敌人伤害 -75%",
		Skill = {
			{
				Id = 105034,
				Value = -75,
			},
			{
				Id = 105037,
				Value = -75,
			},
		},
	},
	Tags = {
		560111,
		564556,
	},
}
EnemyConfig[EnemyID.Id6258] =
{
	Id = 6258,
	Name = "鬼火路灯",
	Rarity = 3,
	Element = 210002,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：把居民引入还在修路的地区。",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	IconName = "Arena_SUS_StreetLamp",
	PrefabBundle = "character_arenaenemy",
	PrefabName = "Arena_SUS_StreetLamp",
	PrefabScale = 50,
	HPBarHeight = 140,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 2747, Gain = 550},
		{Value = 200002, Base = 37, Gain = 8},
		{Value = 200003, Base = 0, Gain = 1},
		{Value = 200004, Base = 0, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "受火元素敌人伤害 -75%\n受暗元素敌人伤害 -75%",
		Skill = {
			{
				Id = 105034,
				Value = -75,
			},
			{
				Id = 105037,
				Value = -75,
			},
		},
	},
	Tags = {
		560111,
		564556,
	},
}
EnemyConfig[EnemyID.Id6259] =
{
	Id = 6259,
	Name = "手残笔",
	Rarity = 2,
	Element = 210003,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：让使用者写错字。",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	IconName = "Arena_SUS_FeatherPen",
	PrefabBundle = "character_arenaenemy",
	PrefabName = "Arena_SUS_FeatherPen",
	PrefabScale = 50,
	HPBarHeight = 110,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 2001, Gain = 401},
		{Value = 200002, Base = 31, Gain = 7},
		{Value = 200003, Base = 0, Gain = 1},
		{Value = 200004, Base = 0, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "每3回合，80%概率闪避攻击",
		Skill = {
			{
				Id = 105140,
				Value = 80,
			},
		},
	},
	Tags = {
		560111,
		564556,
		564557,
	},
}
EnemyConfig[EnemyID.Id6260] =
{
	Id = 6260,
	Name = "手残笔",
	Rarity = 2,
	Element = 210003,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：让使用者写错字。",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	IconName = "Arena_SUS_FeatherPen",
	PrefabBundle = "character_arenaenemy",
	PrefabName = "Arena_SUS_FeatherPen",
	PrefabScale = 50,
	HPBarHeight = 110,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 2152, Gain = 431},
		{Value = 200002, Base = 34, Gain = 7},
		{Value = 200003, Base = 0, Gain = 1},
		{Value = 200004, Base = 0, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "每3回合，80%概率闪避攻击",
		Skill = {
			{
				Id = 105140,
				Value = 80,
			},
		},
	},
	Tags = {
		560111,
		564556,
		564557,
	},
}
EnemyConfig[EnemyID.Id6261] =
{
	Id = 6261,
	Name = "手残笔",
	Rarity = 2,
	Element = 210003,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：让使用者写错字。",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	IconName = "Arena_SUS_FeatherPen",
	PrefabBundle = "character_arenaenemy",
	PrefabName = "Arena_SUS_FeatherPen",
	PrefabScale = 50,
	HPBarHeight = 110,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 2747, Gain = 550},
		{Value = 200002, Base = 37, Gain = 8},
		{Value = 200003, Base = 0, Gain = 1},
		{Value = 200004, Base = 0, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "每3回合，80%概率闪避攻击",
		Skill = {
			{
				Id = 105140,
				Value = 80,
			},
		},
	},
	Tags = {
		560111,
		564556,
		564557,
	},
}
EnemyConfig[EnemyID.Id6262] =
{
	Id = 6262,
	Name = "腹黑猫",
	Rarity = 1,
	Element = 210004,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：利用腹部的花色碰瓷。",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	IconName = "Arena_SUS_ColourfulCat",
	PrefabBundle = "character_arenaenemy",
	PrefabName = "Arena_SUS_ColourfulCat",
	PrefabScale = 50,
	HPBarHeight = 125,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 2087, Gain = 418},
		{Value = 200002, Base = 35, Gain = 7},
		{Value = 200003, Base = 0, Gain = 1},
		{Value = 200004, Base = 0, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "每回合有50%概率对末位队员造成100%攻击伤害\n每3回合回血 18%，最多5次",
		Skill = {
			{
				Id = 105083,
				Value = 100,
			},
			{
				Id = 105009,
				Value = 18,
			},
		},
	},
	Tags = {
		560111,
		564555,
		564560,
	},
}
EnemyConfig[EnemyID.Id6263] =
{
	Id = 6263,
	Name = "腹黑猫",
	Rarity = 1,
	Element = 210004,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：利用腹部的花色碰瓷。",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	IconName = "Arena_SUS_ColourfulCat",
	PrefabBundle = "character_arenaenemy",
	PrefabName = "Arena_SUS_ColourfulCat",
	PrefabScale = 50,
	HPBarHeight = 125,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 2579, Gain = 516},
		{Value = 200002, Base = 36, Gain = 8},
		{Value = 200003, Base = 0, Gain = 1},
		{Value = 200004, Base = 0, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "每回合有50%概率对末位队员造成100%攻击伤害\n每3回合回血 18%，最多5次",
		Skill = {
			{
				Id = 105083,
				Value = 100,
			},
			{
				Id = 105009,
				Value = 18,
			},
		},
	},
	Tags = {
		560111,
		564555,
		564560,
	},
}
EnemyConfig[EnemyID.Id6264] =
{
	Id = 6264,
	Name = "腹黑猫",
	Rarity = 1,
	Element = 210004,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：利用腹部的花色碰瓷。",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	IconName = "Arena_SUS_ColourfulCat",
	PrefabBundle = "character_arenaenemy",
	PrefabName = "Arena_SUS_ColourfulCat",
	PrefabScale = 50,
	HPBarHeight = 125,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 3025, Gain = 605},
		{Value = 200002, Base = 37, Gain = 8},
		{Value = 200003, Base = 0, Gain = 1},
		{Value = 200004, Base = 0, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "每回合有50%概率对末位队员造成100%攻击伤害\n每3回合回血 18%，最多5次",
		Skill = {
			{
				Id = 105083,
				Value = 100,
			},
			{
				Id = 105009,
				Value = 18,
			},
		},
	},
	Tags = {
		560111,
		564555,
		564560,
	},
}
EnemyConfig[EnemyID.Id6265] =
{
	Id = 6265,
	Name = "劣质警报器",
	Rarity = 2,
	Element = 210004,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：大声吵嚷，影响居民休息。",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	IconName = "Arena_SUS_Alarm",
	PrefabBundle = "character_arenaenemy",
	PrefabName = "Arena_SUS_Alarm",
	PrefabScale = 50,
	HPBarHeight = 125,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 2087, Gain = 418},
		{Value = 200002, Base = 35, Gain = 7},
		{Value = 200003, Base = 0, Gain = 1},
		{Value = 200004, Base = 0, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "受到的暴击伤害 -75%\n每3回合，本回合100%概率额外攻击1次",
		Skill = {
			{
				Id = 105039,
				Value = -75,
			},
			{
				Id = 105138,
				Value = 100,
			},
		},
	},
	Tags = {
		560111,
		564555,
		564558,
	},
}
EnemyConfig[EnemyID.Id6266] =
{
	Id = 6266,
	Name = "劣质警报器",
	Rarity = 2,
	Element = 210004,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：大声吵嚷，影响居民休息。",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	IconName = "Arena_SUS_Alarm",
	PrefabBundle = "character_arenaenemy",
	PrefabName = "Arena_SUS_Alarm",
	PrefabScale = 50,
	HPBarHeight = 125,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 2579, Gain = 516},
		{Value = 200002, Base = 36, Gain = 8},
		{Value = 200003, Base = 0, Gain = 1},
		{Value = 200004, Base = 0, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "受到的暴击伤害 -75%\n每3回合，本回合100%概率额外攻击1次",
		Skill = {
			{
				Id = 105039,
				Value = -75,
			},
			{
				Id = 105138,
				Value = 100,
			},
		},
	},
	Tags = {
		560111,
		564555,
		564558,
	},
}
EnemyConfig[EnemyID.Id6267] =
{
	Id = 6267,
	Name = "劣质警报器",
	Rarity = 2,
	Element = 210004,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：大声吵嚷，影响居民休息。",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	IconName = "Arena_SUS_Alarm",
	PrefabBundle = "character_arenaenemy",
	PrefabName = "Arena_SUS_Alarm",
	PrefabScale = 50,
	HPBarHeight = 125,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 3025, Gain = 605},
		{Value = 200002, Base = 37, Gain = 8},
		{Value = 200003, Base = 0, Gain = 1},
		{Value = 200004, Base = 0, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "受到的暴击伤害 -75%\n每3回合，本回合100%概率额外攻击1次",
		Skill = {
			{
				Id = 105039,
				Value = -75,
			},
			{
				Id = 105138,
				Value = 100,
			},
		},
	},
	Tags = {
		560111,
		564555,
		564558,
	},
}
EnemyConfig[EnemyID.Id6268] =
{
	Id = 6268,
	Name = "迷彩路障",
	Rarity = 3,
	Element = 210003,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：存在就是罪过。",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	IconName = "Arena_SUS_redBarrier",
	PrefabBundle = "character_arenaenemy",
	PrefabName = "Arena_SUS_RedBarrier",
	PrefabScale = 50,
	HPBarHeight = 110,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 2334, Gain = 467},
		{Value = 200002, Base = 37, Gain = 8},
		{Value = 200003, Base = 0, Gain = 1},
		{Value = 200004, Base = 0, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "受火元素敌人伤害 -75%\n受光元素敌人伤害 -75%",
		Skill = {
			{
				Id = 105034,
				Value = -75,
			},
			{
				Id = 105036,
				Value = -75,
			},
		},
	},
	Tags = {
		560111,
		564556,
	},
}
EnemyConfig[EnemyID.Id6269] =
{
	Id = 6269,
	Name = "迷彩路障",
	Rarity = 3,
	Element = 210003,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：存在就是罪过。",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	IconName = "Arena_SUS_redBarrier",
	PrefabBundle = "character_arenaenemy",
	PrefabName = "Arena_SUS_RedBarrier",
	PrefabScale = 50,
	HPBarHeight = 110,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 2484, Gain = 497},
		{Value = 200002, Base = 41, Gain = 9},
		{Value = 200003, Base = 0, Gain = 1},
		{Value = 200004, Base = 0, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "受火元素敌人伤害 -75%\n受光元素敌人伤害 -75%",
		Skill = {
			{
				Id = 105034,
				Value = -75,
			},
			{
				Id = 105036,
				Value = -75,
			},
		},
	},
	Tags = {
		560111,
		564556,
	},
}
EnemyConfig[EnemyID.Id6270] =
{
	Id = 6270,
	Name = "迷彩路障",
	Rarity = 3,
	Element = 210003,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：存在就是罪过。",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	IconName = "Arena_SUS_redBarrier",
	PrefabBundle = "character_arenaenemy",
	PrefabName = "Arena_SUS_RedBarrier",
	PrefabScale = 50,
	HPBarHeight = 110,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 3141, Gain = 629},
		{Value = 200002, Base = 44, Gain = 9},
		{Value = 200003, Base = 0, Gain = 1},
		{Value = 200004, Base = 0, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "受火元素敌人伤害 -75%\n受光元素敌人伤害 -75%",
		Skill = {
			{
				Id = 105034,
				Value = -75,
			},
			{
				Id = 105036,
				Value = -75,
			},
		},
	},
	Tags = {
		560111,
		564556,
	},
}
EnemyConfig[EnemyID.Id6271] =
{
	Id = 6271,
	Name = "占位路障",
	Rarity = 2,
	Element = 210004,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：影响他人正常通行。",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	IconName = "Arena_SUS_YellowBarrier",
	PrefabBundle = "character_arenaenemy",
	PrefabName = "Arena_SUS_YellowBarrier",
	PrefabScale = 50,
	HPBarHeight = 110,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 1527, Gain = 306},
		{Value = 200002, Base = 37, Gain = 8},
		{Value = 200003, Base = 0, Gain = 1},
		{Value = 200004, Base = 0, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "可上场队员数量 -1\n每回合回血 6%，最多5次",
		Skill = {
			{
				Id = 105165,
				Value = 1,
			},
			{
				Id = 105005,
				Value = 6,
			},
		},
	},
	Tags = {
		560111,
		564556,
		564560,
		564561,
	},
}
EnemyConfig[EnemyID.Id6272] =
{
	Id = 6272,
	Name = "占位路障",
	Rarity = 2,
	Element = 210004,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：影响他人正常通行。",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	IconName = "Arena_SUS_YellowBarrier",
	PrefabBundle = "character_arenaenemy",
	PrefabName = "Arena_SUS_YellowBarrier",
	PrefabScale = 50,
	HPBarHeight = 110,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 1624, Gain = 325},
		{Value = 200002, Base = 41, Gain = 9},
		{Value = 200003, Base = 0, Gain = 1},
		{Value = 200004, Base = 0, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "可上场队员数量 -1\n每回合回血 6%，最多5次",
		Skill = {
			{
				Id = 105165,
				Value = 1,
			},
			{
				Id = 105005,
				Value = 6,
			},
		},
	},
	Tags = {
		560111,
		564556,
		564560,
		564561,
	},
}
EnemyConfig[EnemyID.Id6273] =
{
	Id = 6273,
	Name = "占位路障",
	Rarity = 2,
	Element = 210004,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：影响他人正常通行。",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	IconName = "Arena_SUS_YellowBarrier",
	PrefabBundle = "character_arenaenemy",
	PrefabName = "Arena_SUS_YellowBarrier",
	PrefabScale = 50,
	HPBarHeight = 110,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 2055, Gain = 411},
		{Value = 200002, Base = 44, Gain = 9},
		{Value = 200003, Base = 0, Gain = 1},
		{Value = 200004, Base = 0, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "可上场队员数量 -1\n每回合回血 6%，最多5次",
		Skill = {
			{
				Id = 105165,
				Value = 1,
			},
			{
				Id = 105005,
				Value = 6,
			},
		},
	},
	Tags = {
		560111,
		564556,
		564560,
		564561,
	},
}
EnemyConfig[EnemyID.Id6274] =
{
	Id = 6274,
	Name = "藤蔓手铐",
	Rarity = 2,
	Element = 210003,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：对嫌疑人使用私刑。",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	IconName = "Arena_SUS_Handcuffs",
	PrefabBundle = "character_arenaenemy",
	PrefabName = "Arena_SUS_Handcuffs",
	PrefabScale = 50,
	HPBarHeight = 110,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 2253, Gain = 451},
		{Value = 200002, Base = 37, Gain = 8},
		{Value = 200003, Base = 0, Gain = 1},
		{Value = 200004, Base = 0, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "每3回合对后2个队员造成75%攻击伤害\n每回合忍耐 +30，最多5次",
		Skill = {
			{
				Id = 105060,
				Value = 75,
			},
			{
				Id = 105007,
				Value = 30,
			},
		},
	},
	Tags = {
		560111,
		564556,
		564561,
	},
}
EnemyConfig[EnemyID.Id6275] =
{
	Id = 6275,
	Name = "藤蔓手铐",
	Rarity = 2,
	Element = 210003,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：对嫌疑人使用私刑。",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	IconName = "Arena_SUS_Handcuffs",
	PrefabBundle = "character_arenaenemy",
	PrefabName = "Arena_SUS_Handcuffs",
	PrefabScale = 50,
	HPBarHeight = 110,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 2386, Gain = 478},
		{Value = 200002, Base = 40, Gain = 8},
		{Value = 200003, Base = 0, Gain = 1},
		{Value = 200004, Base = 0, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "每3回合对后2个队员造成75%攻击伤害\n每回合忍耐 +30，最多5次",
		Skill = {
			{
				Id = 105060,
				Value = 75,
			},
			{
				Id = 105007,
				Value = 30,
			},
		},
	},
	Tags = {
		560111,
		564556,
		564561,
	},
}
EnemyConfig[EnemyID.Id6276] =
{
	Id = 6276,
	Name = "藤蔓手铐",
	Rarity = 2,
	Element = 210003,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：对嫌疑人使用私刑。",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	IconName = "Arena_SUS_Handcuffs",
	PrefabBundle = "character_arenaenemy",
	PrefabName = "Arena_SUS_Handcuffs",
	PrefabScale = 50,
	HPBarHeight = 110,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 3006, Gain = 602},
		{Value = 200002, Base = 43, Gain = 9},
		{Value = 200003, Base = 0, Gain = 1},
		{Value = 200004, Base = 0, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "每3回合对后2个队员造成75%攻击伤害\n每回合忍耐 +30，最多5次",
		Skill = {
			{
				Id = 105060,
				Value = 75,
			},
			{
				Id = 105007,
				Value = 30,
			},
		},
	},
	Tags = {
		560111,
		564556,
		564561,
	},
}
EnemyConfig[EnemyID.Id6277] =
{
	Id = 6277,
	Name = "好兄弟手铐",
	Rarity = 2,
	Element = 210005,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：用好兄弟的名号诱骗他人，并勒索钱财。",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	IconName = "Arena_SUS_Handcuffs2",
	PrefabBundle = "character_arenaenemy",
	PrefabName = "Arena_SUS_Handcuffs2",
	PrefabScale = 50,
	HPBarHeight = 110,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 2253, Gain = 451},
		{Value = 200002, Base = 37, Gain = 8},
		{Value = 200003, Base = 0, Gain = 1},
		{Value = 200004, Base = 0, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "每3回合对前2个队员造成100%攻击伤害\n每回合攻击 +15%，最多5次",
		Skill = {
			{
				Id = 105056,
				Value = 100,
			},
			{
				Id = 105006,
				Value = 15,
			},
		},
	},
	Tags = {
		560111,
		564556,
		564561,
	},
}
EnemyConfig[EnemyID.Id6278] =
{
	Id = 6278,
	Name = "好兄弟手铐",
	Rarity = 2,
	Element = 210005,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：用好兄弟的名号诱骗他人，并勒索钱财。",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	IconName = "Arena_SUS_Handcuffs2",
	PrefabBundle = "character_arenaenemy",
	PrefabName = "Arena_SUS_Handcuffs2",
	PrefabScale = 50,
	HPBarHeight = 110,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 2386, Gain = 478},
		{Value = 200002, Base = 40, Gain = 8},
		{Value = 200003, Base = 0, Gain = 1},
		{Value = 200004, Base = 0, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "每3回合对前2个队员造成100%攻击伤害\n每回合攻击 +15%，最多5次",
		Skill = {
			{
				Id = 105056,
				Value = 100,
			},
			{
				Id = 105006,
				Value = 15,
			},
		},
	},
	Tags = {
		560111,
		564556,
		564561,
	},
}
EnemyConfig[EnemyID.Id6279] =
{
	Id = 6279,
	Name = "好兄弟手铐",
	Rarity = 2,
	Element = 210005,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：用好兄弟的名号诱骗他人，并勒索钱财。",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	IconName = "Arena_SUS_Handcuffs2",
	PrefabBundle = "character_arenaenemy",
	PrefabName = "Arena_SUS_Handcuffs2",
	PrefabScale = 50,
	HPBarHeight = 110,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 3006, Gain = 602},
		{Value = 200002, Base = 43, Gain = 9},
		{Value = 200003, Base = 0, Gain = 1},
		{Value = 200004, Base = 0, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "每3回合对前2个队员造成100%攻击伤害\n每回合攻击 +15%，最多5次",
		Skill = {
			{
				Id = 105056,
				Value = 100,
			},
			{
				Id = 105006,
				Value = 15,
			},
		},
	},
	Tags = {
		560111,
		564556,
		564561,
	},
}
EnemyConfig[EnemyID.Id6280] =
{
	Id = 6280,
	Name = "诅咒信",
	Rarity = 3,
	Element = 210005,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：接受犯罪委托，恐吓居民。",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	IconName = "Arena_SUS_Letter",
	PrefabBundle = "character_arenaenemy",
	PrefabName = "Arena_SUS_Letter",
	PrefabScale = 50,
	HPBarHeight = 125,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 2178, Gain = 436},
		{Value = 200002, Base = 36, Gain = 8},
		{Value = 200003, Base = 0, Gain = 1},
		{Value = 200004, Base = 0, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "80%概率无视敌人闪避\n每回合有25%概率对前2个队员造成75%攻击伤害\n或对前3个队员造成50%攻击伤害\n或对所有队员造成30%攻击伤害",
		Skill = {
			{
				Id = 105027,
				Value = 80,
			},
			{
				Id = 105120,
				Value = 75,
			},
			{
				Id = 105121,
				Value = 50,
			},
			{
				Id = 105127,
				Value = 30,
			},
		},
	},
	Tags = {
		560111,
		564556,
		564559,
	},
}
EnemyConfig[EnemyID.Id6281] =
{
	Id = 6281,
	Name = "诅咒信",
	Rarity = 3,
	Element = 210005,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：接受犯罪委托，恐吓居民。",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	IconName = "Arena_SUS_Letter",
	PrefabBundle = "character_arenaenemy",
	PrefabName = "Arena_SUS_Letter",
	PrefabScale = 50,
	HPBarHeight = 125,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 2297, Gain = 460},
		{Value = 200002, Base = 39, Gain = 8},
		{Value = 200003, Base = 0, Gain = 1},
		{Value = 200004, Base = 0, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "80%概率无视敌人闪避\n每回合有25%概率对前2个队员造成75%攻击伤害\n或对前3个队员造成50%攻击伤害\n或对所有队员造成30%攻击伤害",
		Skill = {
			{
				Id = 105027,
				Value = 80,
			},
			{
				Id = 105120,
				Value = 75,
			},
			{
				Id = 105121,
				Value = 50,
			},
			{
				Id = 105127,
				Value = 30,
			},
		},
	},
	Tags = {
		560111,
		564556,
		564559,
	},
}
EnemyConfig[EnemyID.Id6282] =
{
	Id = 6282,
	Name = "诅咒信",
	Rarity = 3,
	Element = 210005,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：接受犯罪委托，恐吓居民。",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	IconName = "Arena_SUS_Letter",
	PrefabBundle = "character_arenaenemy",
	PrefabName = "Arena_SUS_Letter",
	PrefabScale = 50,
	HPBarHeight = 125,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 2882, Gain = 577},
		{Value = 200002, Base = 42, Gain = 9},
		{Value = 200003, Base = 0, Gain = 1},
		{Value = 200004, Base = 0, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "80%概率无视敌人闪避\n每回合有25%概率对前2个队员造成75%攻击伤害\n或对前3个队员造成50%攻击伤害\n或对所有队员造成30%攻击伤害",
		Skill = {
			{
				Id = 105027,
				Value = 80,
			},
			{
				Id = 105120,
				Value = 75,
			},
			{
				Id = 105121,
				Value = 50,
			},
			{
				Id = 105127,
				Value = 30,
			},
		},
	},
	Tags = {
		560111,
		564556,
		564559,
	},
}
EnemyConfig[EnemyID.Id6283] =
{
	Id = 6283,
	Name = "分手信",
	Rarity = 2,
	Element = 210005,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：用误会拆散情侣，影响星球生育率。",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	IconName = "Arena_SUS_loveLetter",
	PrefabBundle = "character_arenaenemy",
	PrefabName = "Arena_SUS_loveLetter",
	PrefabScale = 50,
	HPBarHeight = 125,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 2178, Gain = 436},
		{Value = 200002, Base = 36, Gain = 8},
		{Value = 200003, Base = 0, Gain = 1},
		{Value = 200004, Base = 0, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "每回合将自身元素变为随机元素\n有50%概率额外攻击1次",
		Skill = {
			{
				Id = 105162,
				Value = -1,
			},
			{
				Id = 105023,
				Value = 50,
			},
		},
	},
	Tags = {
		560111,
		564556,
		564558,
	},
}
EnemyConfig[EnemyID.Id6284] =
{
	Id = 6284,
	Name = "分手信",
	Rarity = 2,
	Element = 210005,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：用误会拆散情侣，影响星球生育率。",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	IconName = "Arena_SUS_loveLetter",
	PrefabBundle = "character_arenaenemy",
	PrefabName = "Arena_SUS_loveLetter",
	PrefabScale = 50,
	HPBarHeight = 125,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 2297, Gain = 460},
		{Value = 200002, Base = 39, Gain = 8},
		{Value = 200003, Base = 0, Gain = 1},
		{Value = 200004, Base = 0, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "每回合将自身元素变为随机元素\n有50%概率额外攻击1次",
		Skill = {
			{
				Id = 105162,
				Value = -1,
			},
			{
				Id = 105023,
				Value = 50,
			},
		},
	},
	Tags = {
		560111,
		564556,
		564558,
	},
}
EnemyConfig[EnemyID.Id6285] =
{
	Id = 6285,
	Name = "分手信",
	Rarity = 2,
	Element = 210005,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：用误会拆散情侣，影响星球生育率。",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	IconName = "Arena_SUS_loveLetter",
	PrefabBundle = "character_arenaenemy",
	PrefabName = "Arena_SUS_loveLetter",
	PrefabScale = 50,
	HPBarHeight = 125,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 2882, Gain = 577},
		{Value = 200002, Base = 42, Gain = 9},
		{Value = 200003, Base = 0, Gain = 1},
		{Value = 200004, Base = 0, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "每回合将自身元素变为随机元素\n有50%概率额外攻击1次",
		Skill = {
			{
				Id = 105162,
				Value = -1,
			},
			{
				Id = 105023,
				Value = 50,
			},
		},
	},
	Tags = {
		560111,
		564556,
		564558,
	},
}
EnemyConfig[EnemyID.Id6286] =
{
	Id = 6286,
	Name = "诅咒笔记",
	Rarity = 3,
	Element = 210005,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：涉嫌抄袭其他作品。",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	IconName = "Arena_SUS_BrownNoteBook2",
	PrefabBundle = "character_arenaenemy",
	PrefabName = "Arena_SUS_BrownNoteBook2",
	PrefabScale = 50,
	HPBarHeight = 125,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 2107, Gain = 422},
		{Value = 200002, Base = 35, Gain = 7},
		{Value = 200003, Base = 0, Gain = 1},
		{Value = 200004, Base = 0, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "每3回合，本回合暴率 +100%\n每3回合，本回合暴击伤害 +150%",
		Skill = {
			{
				Id = 105135,
				Value = 100,
			},
			{
				Id = 105136,
				Value = 150,
			},
		},
	},
	Tags = {
		560111,
		564556,
	},
}
EnemyConfig[EnemyID.Id6287] =
{
	Id = 6287,
	Name = "诅咒笔记",
	Rarity = 3,
	Element = 210005,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：涉嫌抄袭其他作品。",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	IconName = "Arena_SUS_BrownNoteBook2",
	PrefabBundle = "character_arenaenemy",
	PrefabName = "Arena_SUS_BrownNoteBook2",
	PrefabScale = 50,
	HPBarHeight = 125,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 2213, Gain = 443},
		{Value = 200002, Base = 39, Gain = 8},
		{Value = 200003, Base = 0, Gain = 1},
		{Value = 200004, Base = 0, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "每3回合，本回合暴率 +100%\n每3回合，本回合暴击伤害 +150%",
		Skill = {
			{
				Id = 105135,
				Value = 100,
			},
			{
				Id = 105136,
				Value = 150,
			},
		},
	},
	Tags = {
		560111,
		564556,
	},
}
EnemyConfig[EnemyID.Id6288] =
{
	Id = 6288,
	Name = "诅咒笔记",
	Rarity = 3,
	Element = 210005,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：涉嫌抄袭其他作品。",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	IconName = "Arena_SUS_BrownNoteBook2",
	PrefabBundle = "character_arenaenemy",
	PrefabName = "Arena_SUS_BrownNoteBook2",
	PrefabScale = 50,
	HPBarHeight = 125,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 2767, Gain = 554},
		{Value = 200002, Base = 42, Gain = 9},
		{Value = 200003, Base = 0, Gain = 1},
		{Value = 200004, Base = 0, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "每3回合，本回合暴率 +100%\n每3回合，本回合暴击伤害 +150%",
		Skill = {
			{
				Id = 105135,
				Value = 100,
			},
			{
				Id = 105136,
				Value = 150,
			},
		},
	},
	Tags = {
		560111,
		564556,
	},
}
EnemyConfig[EnemyID.Id6289] =
{
	Id = 6289,
	Name = "剧透笔记",
	Rarity = 2,
	Element = 210002,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：剧透推理剧情。",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	IconName = "Arena_SUS_BrownNoteBook",
	PrefabBundle = "character_arenaenemy",
	PrefabName = "Arena_SUS_BrownNoteBook",
	PrefabScale = 50,
	HPBarHeight = 125,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 2107, Gain = 422},
		{Value = 200002, Base = 35, Gain = 7},
		{Value = 200003, Base = 0, Gain = 1},
		{Value = 200004, Base = 0, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "每3回合对所有队员造成50%攻击伤害\n每3回合，80%概率无视敌人闪避",
		Skill = {
			{
				Id = 105063,
				Value = 50,
			},
			{
				Id = 105141,
				Value = 80,
			},
		},
	},
	Tags = {
		560111,
		564556,
		564559,
	},
}
EnemyConfig[EnemyID.Id6290] =
{
	Id = 6290,
	Name = "剧透笔记",
	Rarity = 2,
	Element = 210002,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：剧透推理剧情。",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	IconName = "Arena_SUS_BrownNoteBook",
	PrefabBundle = "character_arenaenemy",
	PrefabName = "Arena_SUS_BrownNoteBook",
	PrefabScale = 50,
	HPBarHeight = 125,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 2213, Gain = 443},
		{Value = 200002, Base = 39, Gain = 8},
		{Value = 200003, Base = 0, Gain = 1},
		{Value = 200004, Base = 0, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "每3回合对所有队员造成50%攻击伤害\n每3回合，80%概率无视敌人闪避",
		Skill = {
			{
				Id = 105063,
				Value = 50,
			},
			{
				Id = 105141,
				Value = 80,
			},
		},
	},
	Tags = {
		560111,
		564556,
		564559,
	},
}
EnemyConfig[EnemyID.Id6291] =
{
	Id = 6291,
	Name = "剧透笔记",
	Rarity = 2,
	Element = 210002,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：剧透推理剧情。",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	IconName = "Arena_SUS_BrownNoteBook",
	PrefabBundle = "character_arenaenemy",
	PrefabName = "Arena_SUS_BrownNoteBook",
	PrefabScale = 50,
	HPBarHeight = 125,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 2767, Gain = 554},
		{Value = 200002, Base = 42, Gain = 9},
		{Value = 200003, Base = 0, Gain = 1},
		{Value = 200004, Base = 0, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "每3回合对所有队员造成50%攻击伤害\n每3回合，80%概率无视敌人闪避",
		Skill = {
			{
				Id = 105063,
				Value = 50,
			},
			{
				Id = 105141,
				Value = 80,
			},
		},
	},
	Tags = {
		560111,
		564556,
		564559,
	},
}
EnemyConfig[EnemyID.Id6292] =
{
	Id = 6292,
	Name = "诈骗信",
	Rarity = 4,
	Element = 210005,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：伪造账单进行诈骗。",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	IconName = "Arena_SUS_horribleLetter",
	PrefabBundle = "character_arenaenemy",
	PrefabName = "Arena_SUS_horribleLetter",
	PrefabScale = 50,
	HPBarHeight = 120,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 2212, Gain = 443},
		{Value = 200002, Base = 40, Gain = 8},
		{Value = 200003, Base = 0, Gain = 1},
		{Value = 200004, Base = 0, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "每3回合，100%概率闪避攻击\n每3回合回血 24%，最多5次",
		Skill = {
			{
				Id = 105140,
				Value = 100,
			},
			{
				Id = 105009,
				Value = 24,
			},
		},
	},
	Tags = {
		560111,
		564555,
		564557,
		564560,
	},
}
EnemyConfig[EnemyID.Id6293] =
{
	Id = 6293,
	Name = "诈骗信",
	Rarity = 4,
	Element = 210005,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：伪造账单进行诈骗。",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	IconName = "Arena_SUS_horribleLetter",
	PrefabBundle = "character_arenaenemy",
	PrefabName = "Arena_SUS_horribleLetter",
	PrefabScale = 50,
	HPBarHeight = 120,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 2674, Gain = 535},
		{Value = 200002, Base = 41, Gain = 9},
		{Value = 200003, Base = 0, Gain = 1},
		{Value = 200004, Base = 0, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "每3回合，100%概率闪避攻击\n每3回合回血 24%，最多5次",
		Skill = {
			{
				Id = 105140,
				Value = 100,
			},
			{
				Id = 105009,
				Value = 24,
			},
		},
	},
	Tags = {
		560111,
		564555,
		564557,
		564560,
	},
}
EnemyConfig[EnemyID.Id6294] =
{
	Id = 6294,
	Name = "诈骗信",
	Rarity = 4,
	Element = 210005,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：伪造账单进行诈骗。",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	IconName = "Arena_SUS_horribleLetter",
	PrefabBundle = "character_arenaenemy",
	PrefabName = "Arena_SUS_horribleLetter",
	PrefabScale = 50,
	HPBarHeight = 120,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 3076, Gain = 616},
		{Value = 200002, Base = 43, Gain = 9},
		{Value = 200003, Base = 0, Gain = 1},
		{Value = 200004, Base = 0, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "每3回合，100%概率闪避攻击\n每3回合回血 24%，最多5次",
		Skill = {
			{
				Id = 105140,
				Value = 100,
			},
			{
				Id = 105009,
				Value = 24,
			},
		},
	},
	Tags = {
		560111,
		564555,
		564557,
		564560,
	},
}
EnemyConfig[EnemyID.Id6295] =
{
	Id = 6295,
	Name = "高速行李车",
	Rarity = 4,
	Element = 210002,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：擅闯员工通道。",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	IconName = "Arena_SUS_Luggage",
	PrefabBundle = "character_arenaenemy",
	PrefabName = "Arena_SUS_Luggage",
	PrefabScale = 50,
	HPBarHeight = 130,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 2212, Gain = 443},
		{Value = 200002, Base = 40, Gain = 8},
		{Value = 200003, Base = 0, Gain = 1},
		{Value = 200004, Base = 0, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "每3回合有50%概率对所有队员造成50%攻击伤害\n每6回合，本回合100%概率额外攻击1次",
		Skill = {
			{
				Id = 105103,
				Value = 50,
			},
			{
				Id = 105152,
				Value = 100,
			},
		},
	},
	Tags = {
		560111,
		564555,
		564558,
	},
}
EnemyConfig[EnemyID.Id6296] =
{
	Id = 6296,
	Name = "高速行李车",
	Rarity = 4,
	Element = 210002,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：擅闯员工通道。",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	IconName = "Arena_SUS_Luggage",
	PrefabBundle = "character_arenaenemy",
	PrefabName = "Arena_SUS_Luggage",
	PrefabScale = 50,
	HPBarHeight = 130,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 2674, Gain = 535},
		{Value = 200002, Base = 41, Gain = 9},
		{Value = 200003, Base = 0, Gain = 1},
		{Value = 200004, Base = 0, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "每3回合有50%概率对所有队员造成50%攻击伤害\n每6回合，本回合100%概率额外攻击1次",
		Skill = {
			{
				Id = 105103,
				Value = 50,
			},
			{
				Id = 105152,
				Value = 100,
			},
		},
	},
	Tags = {
		560111,
		564555,
		564558,
	},
}
EnemyConfig[EnemyID.Id6297] =
{
	Id = 6297,
	Name = "高速行李车",
	Rarity = 4,
	Element = 210002,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：擅闯员工通道。",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	IconName = "Arena_SUS_Luggage",
	PrefabBundle = "character_arenaenemy",
	PrefabName = "Arena_SUS_Luggage",
	PrefabScale = 50,
	HPBarHeight = 130,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 3076, Gain = 616},
		{Value = 200002, Base = 43, Gain = 9},
		{Value = 200003, Base = 0, Gain = 1},
		{Value = 200004, Base = 0, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "每3回合有50%概率对所有队员造成50%攻击伤害\n每6回合，本回合100%概率额外攻击1次",
		Skill = {
			{
				Id = 105103,
				Value = 50,
			},
			{
				Id = 105152,
				Value = 100,
			},
		},
	},
	Tags = {
		560111,
		564555,
		564558,
	},
}
EnemyConfig[EnemyID.Id6298] =
{
	Id = 6298,
	Name = "牛油果墨水",
	Rarity = 3,
	Element = 210001,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：骗顾客食用墨水，造成食物中毒。",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	IconName = "Arena_SUS_redInk",
	PrefabBundle = "character_arenaenemy",
	PrefabName = "Arena_SUS_RedInk",
	PrefabScale = 50,
	HPBarHeight = 125,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 2363, Gain = 473},
		{Value = 200002, Base = 41, Gain = 9},
		{Value = 200003, Base = 0, Gain = 1},
		{Value = 200004, Base = 0, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "忍耐 +100\n每3回合对前3个队员造成80%攻击伤害",
		Skill = {
			{
				Id = 105003,
				Value = 100,
			},
			{
				Id = 105057,
				Value = 80,
			},
		},
	},
	Tags = {
		560111,
		564556,
		564561,
	},
}
EnemyConfig[EnemyID.Id6299] =
{
	Id = 6299,
	Name = "牛油果墨水",
	Rarity = 3,
	Element = 210001,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：骗顾客食用墨水，造成食物中毒。",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	IconName = "Arena_SUS_redInk",
	PrefabBundle = "character_arenaenemy",
	PrefabName = "Arena_SUS_RedInk",
	PrefabScale = 50,
	HPBarHeight = 125,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 2464, Gain = 493},
		{Value = 200002, Base = 45, Gain = 9},
		{Value = 200003, Base = 0, Gain = 1},
		{Value = 200004, Base = 0, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "忍耐 +100\n每3回合对前3个队员造成80%攻击伤害",
		Skill = {
			{
				Id = 105003,
				Value = 100,
			},
			{
				Id = 105057,
				Value = 80,
			},
		},
	},
	Tags = {
		560111,
		564556,
		564561,
	},
}
EnemyConfig[EnemyID.Id6300] =
{
	Id = 6300,
	Name = "牛油果墨水",
	Rarity = 3,
	Element = 210001,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：骗顾客食用墨水，造成食物中毒。",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	IconName = "Arena_SUS_redInk",
	PrefabBundle = "character_arenaenemy",
	PrefabName = "Arena_SUS_RedInk",
	PrefabScale = 50,
	HPBarHeight = 125,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 3061, Gain = 613},
		{Value = 200002, Base = 49, Gain = 10},
		{Value = 200003, Base = 0, Gain = 1},
		{Value = 200004, Base = 0, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "忍耐 +100\n每3回合对前3个队员造成80%攻击伤害",
		Skill = {
			{
				Id = 105003,
				Value = 100,
			},
			{
				Id = 105057,
				Value = 80,
			},
		},
	},
	Tags = {
		560111,
		564556,
		564561,
	},
}
EnemyConfig[EnemyID.Id6301] =
{
	Id = 6301,
	Name = "死亡芭比墨水",
	Rarity = 2,
	Element = 210001,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：把墨水弄到别人身上。",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	IconName = "Arena_SUS_BlueInk",
	PrefabBundle = "character_arenaenemy",
	PrefabName = "Arena_SUS_BlueInk",
	PrefabScale = 50,
	HPBarHeight = 125,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 2363, Gain = 473},
		{Value = 200002, Base = 41, Gain = 9},
		{Value = 200003, Base = 0, Gain = 1},
		{Value = 200004, Base = 0, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "攻击 +50%\n每回合回血 8%，最多5次",
		Skill = {
			{
				Id = 105002,
				Value = 50,
			},
			{
				Id = 105005,
				Value = 8,
			},
		},
	},
	Tags = {
		560111,
		564556,
		564560,
		564561,
	},
}
EnemyConfig[EnemyID.Id6302] =
{
	Id = 6302,
	Name = "死亡芭比墨水",
	Rarity = 2,
	Element = 210001,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：把墨水弄到别人身上。",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	IconName = "Arena_SUS_BlueInk",
	PrefabBundle = "character_arenaenemy",
	PrefabName = "Arena_SUS_BlueInk",
	PrefabScale = 50,
	HPBarHeight = 125,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 2464, Gain = 493},
		{Value = 200002, Base = 45, Gain = 9},
		{Value = 200003, Base = 0, Gain = 1},
		{Value = 200004, Base = 0, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "攻击 +50%\n每回合回血 8%，最多5次",
		Skill = {
			{
				Id = 105002,
				Value = 50,
			},
			{
				Id = 105005,
				Value = 8,
			},
		},
	},
	Tags = {
		560111,
		564556,
		564560,
		564561,
	},
}
EnemyConfig[EnemyID.Id6303] =
{
	Id = 6303,
	Name = "死亡芭比墨水",
	Rarity = 2,
	Element = 210001,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：把墨水弄到别人身上。",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	IconName = "Arena_SUS_BlueInk",
	PrefabBundle = "character_arenaenemy",
	PrefabName = "Arena_SUS_BlueInk",
	PrefabScale = 50,
	HPBarHeight = 125,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 3061, Gain = 613},
		{Value = 200002, Base = 49, Gain = 10},
		{Value = 200003, Base = 0, Gain = 1},
		{Value = 200004, Base = 0, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "攻击 +50%\n每回合回血 8%，最多5次",
		Skill = {
			{
				Id = 105002,
				Value = 50,
			},
			{
				Id = 105005,
				Value = 8,
			},
		},
	},
	Tags = {
		560111,
		564556,
		564560,
		564561,
	},
}
EnemyConfig[EnemyID.Id6304] =
{
	Id = 6304,
	Name = "瓦斯烟斗",
	Rarity = 3,
	Element = 210002,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：将有毒瓦斯灌入烟斗。",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	IconName = "Arena_SUS_Pipe",
	PrefabBundle = "character_arenaenemy",
	PrefabName = "Arena_SUS_Pipe",
	PrefabScale = 50,
	HPBarHeight = 125,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 2293, Gain = 459},
		{Value = 200002, Base = 41, Gain = 9},
		{Value = 200003, Base = 0, Gain = 1},
		{Value = 200004, Base = 0, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "5回合后，攻击 +100%\n每3回合对所有队员造成30%攻击伤害",
		Skill = {
			{
				Id = 105014,
				Value = 100,
			},
			{
				Id = 105063,
				Value = 30,
			},
		},
	},
	Tags = {
		560111,
		564556,
		564561,
	},
}
EnemyConfig[EnemyID.Id6305] =
{
	Id = 6305,
	Name = "瓦斯烟斗",
	Rarity = 3,
	Element = 210002,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：将有毒瓦斯灌入烟斗。",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	IconName = "Arena_SUS_Pipe",
	PrefabBundle = "character_arenaenemy",
	PrefabName = "Arena_SUS_Pipe",
	PrefabScale = 50,
	HPBarHeight = 125,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 2383, Gain = 477},
		{Value = 200002, Base = 44, Gain = 9},
		{Value = 200003, Base = 0, Gain = 1},
		{Value = 200004, Base = 0, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "5回合后，攻击 +100%\n每3回合对所有队员造成30%攻击伤害",
		Skill = {
			{
				Id = 105014,
				Value = 100,
			},
			{
				Id = 105063,
				Value = 30,
			},
		},
	},
	Tags = {
		560111,
		564556,
		564561,
	},
}
EnemyConfig[EnemyID.Id6306] =
{
	Id = 6306,
	Name = "瓦斯烟斗",
	Rarity = 3,
	Element = 210002,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：将有毒瓦斯灌入烟斗。",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	IconName = "Arena_SUS_Pipe",
	PrefabBundle = "character_arenaenemy",
	PrefabName = "Arena_SUS_Pipe",
	PrefabScale = 50,
	HPBarHeight = 125,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 2952, Gain = 591},
		{Value = 200002, Base = 48, Gain = 10},
		{Value = 200003, Base = 0, Gain = 1},
		{Value = 200004, Base = 0, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "5回合后，攻击 +100%\n每3回合对所有队员造成30%攻击伤害",
		Skill = {
			{
				Id = 105014,
				Value = 100,
			},
			{
				Id = 105063,
				Value = 30,
			},
		},
	},
	Tags = {
		560111,
		564556,
		564561,
	},
}
EnemyConfig[EnemyID.Id6307] =
{
	Id = 6307,
	Name = "缩小镜",
	Rarity = 2,
	Element = 210005,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：将放大镜镜片偷换成缩小镜。",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	IconName = "Arena_SUS_Magnifier",
	PrefabBundle = "character_arenaenemy",
	PrefabName = "Arena_SUS_Magnifier",
	PrefabScale = 50,
	HPBarHeight = 110,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 2293, Gain = 459},
		{Value = 200002, Base = 41, Gain = 9},
		{Value = 200003, Base = 0, Gain = 1},
		{Value = 200004, Base = 0, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "每2回合，本回合100%概率额外攻击1次\n每3回合暴击 +120，最多3次",
		Skill = {
			{
				Id = 105131,
				Value = 100,
			},
			{
				Id = 105012,
				Value = 120,
			},
		},
	},
	Tags = {
		560111,
		564556,
		564558,
		564561,
	},
}
EnemyConfig[EnemyID.Id6308] =
{
	Id = 6308,
	Name = "缩小镜",
	Rarity = 2,
	Element = 210005,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：将放大镜镜片偷换成缩小镜。",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	IconName = "Arena_SUS_Magnifier",
	PrefabBundle = "character_arenaenemy",
	PrefabName = "Arena_SUS_Magnifier",
	PrefabScale = 50,
	HPBarHeight = 110,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 2383, Gain = 477},
		{Value = 200002, Base = 44, Gain = 9},
		{Value = 200003, Base = 0, Gain = 1},
		{Value = 200004, Base = 0, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "每2回合，本回合100%概率额外攻击1次\n每3回合暴击 +120，最多3次",
		Skill = {
			{
				Id = 105131,
				Value = 100,
			},
			{
				Id = 105012,
				Value = 120,
			},
		},
	},
	Tags = {
		560111,
		564556,
		564558,
		564561,
	},
}
EnemyConfig[EnemyID.Id6309] =
{
	Id = 6309,
	Name = "缩小镜",
	Rarity = 2,
	Element = 210005,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：将放大镜镜片偷换成缩小镜。",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	IconName = "Arena_SUS_Magnifier",
	PrefabBundle = "character_arenaenemy",
	PrefabName = "Arena_SUS_Magnifier",
	PrefabScale = 50,
	HPBarHeight = 110,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 2952, Gain = 591},
		{Value = 200002, Base = 48, Gain = 10},
		{Value = 200003, Base = 0, Gain = 1},
		{Value = 200004, Base = 0, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "每2回合，本回合100%概率额外攻击1次\n每3回合暴击 +120，最多3次",
		Skill = {
			{
				Id = 105131,
				Value = 100,
			},
			{
				Id = 105012,
				Value = 120,
			},
		},
	},
	Tags = {
		560111,
		564556,
		564558,
		564561,
	},
}
EnemyConfig[EnemyID.Id6310] =
{
	Id = 6310,
	Name = "三眼神猫",
	Rarity = 3,
	Element = 210004,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：用算命先生的名号招摇撞骗，摆摊影响交通。",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	IconName = "Arena_SUS_BlackCat",
	PrefabBundle = "character_arenaenemy",
	PrefabName = "Arena_SUS_BlackCat",
	PrefabScale = 50,
	HPBarHeight = 125,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 2228, Gain = 446},
		{Value = 200002, Base = 40, Gain = 8},
		{Value = 200003, Base = 0, Gain = 1},
		{Value = 200004, Base = 0, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "每3回合，100%概率无视敌人闪避\n每3回合，75%概率闪避攻击\n每3回合回血 20%，最多5次",
		Skill = {
			{
				Id = 105141,
				Value = 100,
			},
			{
				Id = 105140,
				Value = 75,
			},
			{
				Id = 105009,
				Value = 20,
			},
		},
	},
	Tags = {
		560111,
		564556,
		564557,
		564559,
		564560,
	},
}
EnemyConfig[EnemyID.Id6311] =
{
	Id = 6311,
	Name = "三眼神猫",
	Rarity = 3,
	Element = 210004,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：用算命先生的名号招摇撞骗，摆摊影响交通。",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	IconName = "Arena_SUS_BlackCat",
	PrefabBundle = "character_arenaenemy",
	PrefabName = "Arena_SUS_BlackCat",
	PrefabScale = 50,
	HPBarHeight = 125,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 2308, Gain = 462},
		{Value = 200002, Base = 44, Gain = 9},
		{Value = 200003, Base = 0, Gain = 1},
		{Value = 200004, Base = 0, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "每3回合，100%概率无视敌人闪避\n每3回合，75%概率闪避攻击\n每3回合回血 20%，最多5次",
		Skill = {
			{
				Id = 105141,
				Value = 100,
			},
			{
				Id = 105140,
				Value = 75,
			},
			{
				Id = 105009,
				Value = 20,
			},
		},
	},
	Tags = {
		560111,
		564556,
		564557,
		564559,
		564560,
	},
}
EnemyConfig[EnemyID.Id6312] =
{
	Id = 6312,
	Name = "三眼神猫",
	Rarity = 3,
	Element = 210004,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：用算命先生的名号招摇撞骗，摆摊影响交通。",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	IconName = "Arena_SUS_BlackCat",
	PrefabBundle = "character_arenaenemy",
	PrefabName = "Arena_SUS_BlackCat",
	PrefabScale = 50,
	HPBarHeight = 125,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 2851, Gain = 571},
		{Value = 200002, Base = 48, Gain = 10},
		{Value = 200003, Base = 0, Gain = 1},
		{Value = 200004, Base = 0, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "每3回合，100%概率无视敌人闪避\n每3回合，75%概率闪避攻击\n每3回合回血 20%，最多5次",
		Skill = {
			{
				Id = 105141,
				Value = 100,
			},
			{
				Id = 105140,
				Value = 75,
			},
			{
				Id = 105009,
				Value = 20,
			},
		},
	},
	Tags = {
		560111,
		564556,
		564557,
		564559,
		564560,
	},
}
EnemyConfig[EnemyID.Id6313] =
{
	Id = 6313,
	Name = "化学试剂",
	Rarity = 2,
	Element = 210001,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：状态不稳定，容易爆炸。",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	IconName = "Arena_SUS_Blood",
	PrefabBundle = "character_arenaenemy",
	PrefabName = "Arena_SUS_Blood",
	PrefabScale = 50,
	HPBarHeight = 125,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 2228, Gain = 446},
		{Value = 200002, Base = 40, Gain = 8},
		{Value = 200003, Base = 0, Gain = 1},
		{Value = 200004, Base = 0, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "生命 +100%\n攻击 +50%",
		Skill = {
			{
				Id = 105001,
				Value = 100,
			},
			{
				Id = 105002,
				Value = 50,
			},
		},
	},
	Tags = {
		560111,
		564556,
		564561,
	},
}
EnemyConfig[EnemyID.Id6314] =
{
	Id = 6314,
	Name = "化学试剂",
	Rarity = 2,
	Element = 210001,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：状态不稳定，容易爆炸。",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	IconName = "Arena_SUS_Blood",
	PrefabBundle = "character_arenaenemy",
	PrefabName = "Arena_SUS_Blood",
	PrefabScale = 50,
	HPBarHeight = 125,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 2308, Gain = 462},
		{Value = 200002, Base = 44, Gain = 9},
		{Value = 200003, Base = 0, Gain = 1},
		{Value = 200004, Base = 0, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "生命 +100%\n攻击 +50%",
		Skill = {
			{
				Id = 105001,
				Value = 100,
			},
			{
				Id = 105002,
				Value = 50,
			},
		},
	},
	Tags = {
		560111,
		564556,
		564561,
	},
}
EnemyConfig[EnemyID.Id6315] =
{
	Id = 6315,
	Name = "化学试剂",
	Rarity = 2,
	Element = 210001,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：状态不稳定，容易爆炸。",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	IconName = "Arena_SUS_Blood",
	PrefabBundle = "character_arenaenemy",
	PrefabName = "Arena_SUS_Blood",
	PrefabScale = 50,
	HPBarHeight = 125,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 2851, Gain = 571},
		{Value = 200002, Base = 48, Gain = 10},
		{Value = 200003, Base = 0, Gain = 1},
		{Value = 200004, Base = 0, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "生命 +100%\n攻击 +50%",
		Skill = {
			{
				Id = 105001,
				Value = 100,
			},
			{
				Id = 105002,
				Value = 50,
			},
		},
	},
	Tags = {
		560111,
		564556,
		564561,
	},
}
EnemyConfig[EnemyID.Id6316] =
{
	Id = 6316,
	Name = "遗像框",
	Rarity = 2,
	Element = 210004,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：把居民的照片套进像框中，非常不吉利。",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	IconName = "Arena_SUS_Photo",
	PrefabBundle = "character_arenaenemy",
	PrefabName = "Arena_SUS_Photo",
	PrefabScale = 50,
	HPBarHeight = 125,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 2166, Gain = 434},
		{Value = 200002, Base = 40, Gain = 8},
		{Value = 200003, Base = 0, Gain = 1},
		{Value = 200004, Base = 0, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "受到的暴击伤害 -75%\n暴击伤害 +150%\n每回合有50%概率对末位队员造成100%攻击伤害",
		Skill = {
			{
				Id = 105039,
				Value = -75,
			},
			{
				Id = 105038,
				Value = 150,
			},
			{
				Id = 105083,
				Value = 100,
			},
		},
	},
	Tags = {
		560111,
		564556,
	},
}
EnemyConfig[EnemyID.Id6317] =
{
	Id = 6317,
	Name = "遗像框",
	Rarity = 2,
	Element = 210004,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：把居民的照片套进像框中，非常不吉利。",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	IconName = "Arena_SUS_Photo",
	PrefabBundle = "character_arenaenemy",
	PrefabName = "Arena_SUS_Photo",
	PrefabScale = 50,
	HPBarHeight = 125,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 2237, Gain = 448},
		{Value = 200002, Base = 43, Gain = 9},
		{Value = 200003, Base = 0, Gain = 1},
		{Value = 200004, Base = 0, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "受到的暴击伤害 -75%\n暴击伤害 +150%\n每回合有50%概率对末位队员造成100%攻击伤害",
		Skill = {
			{
				Id = 105039,
				Value = -75,
			},
			{
				Id = 105038,
				Value = 150,
			},
			{
				Id = 105083,
				Value = 100,
			},
		},
	},
	Tags = {
		560111,
		564556,
	},
}
EnemyConfig[EnemyID.Id6318] =
{
	Id = 6318,
	Name = "遗像框",
	Rarity = 2,
	Element = 210004,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：把居民的照片套进像框中，非常不吉利。",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	IconName = "Arena_SUS_Photo",
	PrefabBundle = "character_arenaenemy",
	PrefabName = "Arena_SUS_Photo",
	PrefabScale = 50,
	HPBarHeight = 125,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 2757, Gain = 552},
		{Value = 200002, Base = 47, Gain = 10},
		{Value = 200003, Base = 0, Gain = 1},
		{Value = 200004, Base = 0, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "受到的暴击伤害 -75%\n暴击伤害 +150%\n每回合有50%概率对末位队员造成100%攻击伤害",
		Skill = {
			{
				Id = 105039,
				Value = -75,
			},
			{
				Id = 105038,
				Value = 150,
			},
			{
				Id = 105083,
				Value = 100,
			},
		},
	},
	Tags = {
		560111,
		564556,
	},
}
EnemyConfig[EnemyID.Id6319] =
{
	Id = 6319,
	Name = "注水脑",
	Rarity = 4,
	Element = 210001,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：智力低下，拖慢科研进度。",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	IconName = "Arena_SUS_Brain",
	PrefabBundle = "character_arenaenemy",
	PrefabName = "Arena_SUS_Brain",
	PrefabScale = 50,
	HPBarHeight = 120,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 2166, Gain = 434},
		{Value = 200002, Base = 40, Gain = 8},
		{Value = 200003, Base = 0, Gain = 1},
		{Value = 200004, Base = 0, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "每3回合对所有队员造成50%攻击伤害\n每3回合，100%概率无视敌人闪避\n生命 +30%",
		Skill = {
			{
				Id = 105063,
				Value = 50,
			},
			{
				Id = 105141,
				Value = 100,
			},
			{
				Id = 105001,
				Value = 30,
			},
		},
	},
	Tags = {
		560111,
		564556,
		564559,
		564561,
	},
}
EnemyConfig[EnemyID.Id6320] =
{
	Id = 6320,
	Name = "注水脑",
	Rarity = 4,
	Element = 210001,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：智力低下，拖慢科研进度。",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	IconName = "Arena_SUS_Brain",
	PrefabBundle = "character_arenaenemy",
	PrefabName = "Arena_SUS_Brain",
	PrefabScale = 50,
	HPBarHeight = 120,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 2237, Gain = 448},
		{Value = 200002, Base = 43, Gain = 9},
		{Value = 200003, Base = 0, Gain = 1},
		{Value = 200004, Base = 0, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "每3回合对所有队员造成50%攻击伤害\n每3回合，100%概率无视敌人闪避\n生命 +30%",
		Skill = {
			{
				Id = 105063,
				Value = 50,
			},
			{
				Id = 105141,
				Value = 100,
			},
			{
				Id = 105001,
				Value = 30,
			},
		},
	},
	Tags = {
		560111,
		564556,
		564559,
		564561,
	},
}
EnemyConfig[EnemyID.Id6321] =
{
	Id = 6321,
	Name = "注水脑",
	Rarity = 4,
	Element = 210001,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：智力低下，拖慢科研进度。",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	IconName = "Arena_SUS_Brain",
	PrefabBundle = "character_arenaenemy",
	PrefabName = "Arena_SUS_Brain",
	PrefabScale = 50,
	HPBarHeight = 120,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 2757, Gain = 552},
		{Value = 200002, Base = 47, Gain = 10},
		{Value = 200003, Base = 0, Gain = 1},
		{Value = 200004, Base = 0, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "每3回合对所有队员造成50%攻击伤害\n每3回合，100%概率无视敌人闪避\n生命 +30%",
		Skill = {
			{
				Id = 105063,
				Value = 50,
			},
			{
				Id = 105141,
				Value = 100,
			},
			{
				Id = 105001,
				Value = 30,
			},
		},
	},
	Tags = {
		560111,
		564556,
		564559,
		564561,
	},
}
EnemyConfig[EnemyID.Id6322] =
{
	Id = 6322,
	Name = "粉红史莱姆",
	Rarity = 2,
	Element = 210001,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "史莱姆家族中的小妹，幼年女性成员，酷爱甜食。平时受到哥哥们的保护，很少去危险地区，主要在宝箱谷地区活动。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	IconName = "RPG_Slime_Pink",
	PrefabBundle = "character_enemy",
	PrefabName = "RPG_Slime_Pink",
	PrefabScale = 50,
	HPBarHeight = 125,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 2168, Gain = 434},
		{Value = 200002, Base = 33, Gain = 7},
		{Value = 200003, Base = 0, Gain = 1},
		{Value = 200004, Base = 0, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "每回合回血 8%，最多5次\n受到的暴击伤害 -50%",
		Skill = {
			{
				Id = 105005,
				Value = 8,
			},
			{
				Id = 105039,
				Value = -50,
			},
		},
	},
	Tags = {
		560111,
		564556,
		564560,
	},
}
EnemyConfig[EnemyID.Id6323] =
{
	Id = 6323,
	Name = "粉红史莱姆",
	Rarity = 2,
	Element = 210001,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "史莱姆家族中的小妹，幼年女性成员，酷爱甜食。平时受到哥哥们的保护，很少去危险地区，主要在宝箱谷地区活动。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	IconName = "RPG_Slime_Pink",
	PrefabBundle = "character_enemy",
	PrefabName = "RPG_Slime_Pink",
	PrefabScale = 50,
	HPBarHeight = 125,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 2361, Gain = 473},
		{Value = 200002, Base = 36, Gain = 8},
		{Value = 200003, Base = 0, Gain = 1},
		{Value = 200004, Base = 0, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "每回合回血 8%，最多5次\n受到的暴击伤害 -50%",
		Skill = {
			{
				Id = 105005,
				Value = 8,
			},
			{
				Id = 105039,
				Value = -50,
			},
		},
	},
	Tags = {
		560111,
		564556,
		564560,
	},
}
EnemyConfig[EnemyID.Id6324] =
{
	Id = 6324,
	Name = "粉红史莱姆",
	Rarity = 2,
	Element = 210001,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "史莱姆家族中的小妹，幼年女性成员，酷爱甜食。平时受到哥哥们的保护，很少去危险地区，主要在宝箱谷地区活动。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	IconName = "RPG_Slime_Pink",
	PrefabBundle = "character_enemy",
	PrefabName = "RPG_Slime_Pink",
	PrefabScale = 50,
	HPBarHeight = 125,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 3049, Gain = 610},
		{Value = 200002, Base = 40, Gain = 8},
		{Value = 200003, Base = 0, Gain = 1},
		{Value = 200004, Base = 0, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "每回合回血 8%，最多5次\n受到的暴击伤害 -50%",
		Skill = {
			{
				Id = 105005,
				Value = 8,
			},
			{
				Id = 105039,
				Value = -50,
			},
		},
	},
	Tags = {
		560111,
		564556,
		564560,
	},
}
EnemyConfig[EnemyID.Id6325] =
{
	Id = 6325,
	Name = "劣质宝箱怪",
	Rarity = 2,
	Element = 210003,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "活跃于野外地区的初级宝箱，通过其极具迷惑性的外表引诱冒险者靠近，然后“啊呜”一口吃掉。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	IconName = "RPG_NormalChest",
	PrefabBundle = "character_enemy",
	PrefabName = "RPG_NormalChest",
	PrefabScale = 50,
	HPBarHeight = 125,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 2087, Gain = 418},
		{Value = 200002, Base = 35, Gain = 7},
		{Value = 200003, Base = 0, Gain = 1},
		{Value = 200004, Base = 0, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "33%概率闪避攻击\n暴击伤害 +100%",
		Skill = {
			{
				Id = 105026,
				Value = 33,
			},
			{
				Id = 105038,
				Value = 100,
			},
		},
	},
	Tags = {
		560111,
		564555,
		564557,
	},
}
EnemyConfig[EnemyID.Id6326] =
{
	Id = 6326,
	Name = "劣质宝箱怪",
	Rarity = 2,
	Element = 210003,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "活跃于野外地区的初级宝箱，通过其极具迷惑性的外表引诱冒险者靠近，然后“啊呜”一口吃掉。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	IconName = "RPG_NormalChest",
	PrefabBundle = "character_enemy",
	PrefabName = "RPG_NormalChest",
	PrefabScale = 50,
	HPBarHeight = 125,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 2579, Gain = 516},
		{Value = 200002, Base = 36, Gain = 8},
		{Value = 200003, Base = 0, Gain = 1},
		{Value = 200004, Base = 0, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "33%概率闪避攻击\n暴击伤害 +100%",
		Skill = {
			{
				Id = 105026,
				Value = 33,
			},
			{
				Id = 105038,
				Value = 100,
			},
		},
	},
	Tags = {
		560111,
		564555,
		564557,
	},
}
EnemyConfig[EnemyID.Id6327] =
{
	Id = 6327,
	Name = "劣质宝箱怪",
	Rarity = 2,
	Element = 210003,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "活跃于野外地区的初级宝箱，通过其极具迷惑性的外表引诱冒险者靠近，然后“啊呜”一口吃掉。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	IconName = "RPG_NormalChest",
	PrefabBundle = "character_enemy",
	PrefabName = "RPG_NormalChest",
	PrefabScale = 50,
	HPBarHeight = 125,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 3025, Gain = 605},
		{Value = 200002, Base = 37, Gain = 8},
		{Value = 200003, Base = 0, Gain = 1},
		{Value = 200004, Base = 0, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "33%概率闪避攻击\n暴击伤害 +100%",
		Skill = {
			{
				Id = 105026,
				Value = 33,
			},
			{
				Id = 105038,
				Value = 100,
			},
		},
	},
	Tags = {
		560111,
		564555,
		564557,
	},
}
EnemyConfig[EnemyID.Id6328] =
{
	Id = 6328,
	Name = "咬人宝箱怪",
	Rarity = 3,
	Element = 210005,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "活跃于危险地区的中级宝箱，金色的光芒会让老练的冒险者忘乎所以地靠近，在他打开宝箱的一刹那，就把对方吃掉。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	IconName = "RPG_RareChest",
	PrefabBundle = "character_enemy",
	PrefabName = "RPG_RareChest",
	PrefabScale = 50,
	HPBarHeight = 125,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 2178, Gain = 436},
		{Value = 200002, Base = 36, Gain = 8},
		{Value = 200003, Base = 0, Gain = 1},
		{Value = 200004, Base = 0, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "100%概率无视敌人闪避\n有50%概率额外攻击1次",
		Skill = {
			{
				Id = 105027,
				Value = 100,
			},
			{
				Id = 105023,
				Value = 50,
			},
		},
	},
	Tags = {
		560111,
		564556,
		564558,
		564559,
	},
}
EnemyConfig[EnemyID.Id6329] =
{
	Id = 6329,
	Name = "咬人宝箱怪",
	Rarity = 3,
	Element = 210005,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "活跃于危险地区的中级宝箱，金色的光芒会让老练的冒险者忘乎所以地靠近，在他打开宝箱的一刹那，就把对方吃掉。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	IconName = "RPG_RareChest",
	PrefabBundle = "character_enemy",
	PrefabName = "RPG_RareChest",
	PrefabScale = 50,
	HPBarHeight = 125,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 2297, Gain = 460},
		{Value = 200002, Base = 39, Gain = 8},
		{Value = 200003, Base = 0, Gain = 1},
		{Value = 200004, Base = 0, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "100%概率无视敌人闪避\n有50%概率额外攻击1次",
		Skill = {
			{
				Id = 105027,
				Value = 100,
			},
			{
				Id = 105023,
				Value = 50,
			},
		},
	},
	Tags = {
		560111,
		564556,
		564558,
		564559,
	},
}
EnemyConfig[EnemyID.Id6330] =
{
	Id = 6330,
	Name = "咬人宝箱怪",
	Rarity = 3,
	Element = 210005,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "活跃于危险地区的中级宝箱，金色的光芒会让老练的冒险者忘乎所以地靠近，在他打开宝箱的一刹那，就把对方吃掉。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	IconName = "RPG_RareChest",
	PrefabBundle = "character_enemy",
	PrefabName = "RPG_RareChest",
	PrefabScale = 50,
	HPBarHeight = 125,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 2882, Gain = 577},
		{Value = 200002, Base = 42, Gain = 9},
		{Value = 200003, Base = 0, Gain = 1},
		{Value = 200004, Base = 0, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "100%概率无视敌人闪避\n有50%概率额外攻击1次",
		Skill = {
			{
				Id = 105027,
				Value = 100,
			},
			{
				Id = 105023,
				Value = 50,
			},
		},
	},
	Tags = {
		560111,
		564556,
		564558,
		564559,
	},
}
EnemyConfig[EnemyID.Id6331] =
{
	Id = 6331,
	Name = "闪耀史莱姆",
	Rarity = 4,
	Element = 210004,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "史莱姆一族中的稀有品种，对自我的定位是「金英怪」或「黄金史莱姆」。一旦听到有人喊它「黄色史莱姆」，就会陷入无法抑制的狂暴状态。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	IconName = "RPG_Slime_Gold",
	PrefabBundle = "character_enemy",
	PrefabName = "RPG_Slime_Gold",
	PrefabScale = 50,
	HPBarHeight = 125,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 2212, Gain = 443},
		{Value = 200002, Base = 40, Gain = 8},
		{Value = 200003, Base = 0, Gain = 1},
		{Value = 200004, Base = 0, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "每回合回血 8%，最多5次\n回合中，每次受击，忍耐 +8\n受光元素敌人伤害 -50%",
		Skill = {
			{
				Id = 105005,
				Value = 8,
			},
			{
				Id = 105171,
				Value = 8,
			},
			{
				Id = 105036,
				Value = -50,
			},
		},
	},
	Tags = {
		560111,
		564555,
		564560,
		564561,
	},
}
EnemyConfig[EnemyID.Id6332] =
{
	Id = 6332,
	Name = "闪耀史莱姆",
	Rarity = 4,
	Element = 210004,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "史莱姆一族中的稀有品种，对自我的定位是「金英怪」或「黄金史莱姆」。一旦听到有人喊它「黄色史莱姆」，就会陷入无法抑制的狂暴状态。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	IconName = "RPG_Slime_Gold",
	PrefabBundle = "character_enemy",
	PrefabName = "RPG_Slime_Gold",
	PrefabScale = 50,
	HPBarHeight = 125,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 2674, Gain = 535},
		{Value = 200002, Base = 41, Gain = 9},
		{Value = 200003, Base = 0, Gain = 1},
		{Value = 200004, Base = 0, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "每回合回血 8%，最多5次\n回合中，每次受击，忍耐 +8\n受光元素敌人伤害 -50%",
		Skill = {
			{
				Id = 105005,
				Value = 8,
			},
			{
				Id = 105171,
				Value = 8,
			},
			{
				Id = 105036,
				Value = -50,
			},
		},
	},
	Tags = {
		560111,
		564555,
		564560,
		564561,
	},
}
EnemyConfig[EnemyID.Id6333] =
{
	Id = 6333,
	Name = "闪耀史莱姆",
	Rarity = 4,
	Element = 210004,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "史莱姆一族中的稀有品种，对自我的定位是「金英怪」或「黄金史莱姆」。一旦听到有人喊它「黄色史莱姆」，就会陷入无法抑制的狂暴状态。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	IconName = "RPG_Slime_Gold",
	PrefabBundle = "character_enemy",
	PrefabName = "RPG_Slime_Gold",
	PrefabScale = 50,
	HPBarHeight = 125,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 3076, Gain = 616},
		{Value = 200002, Base = 43, Gain = 9},
		{Value = 200003, Base = 0, Gain = 1},
		{Value = 200004, Base = 0, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "每回合回血 8%，最多5次\n回合中，每次受击，忍耐 +8\n受光元素敌人伤害 -50%",
		Skill = {
			{
				Id = 105005,
				Value = 8,
			},
			{
				Id = 105171,
				Value = 8,
			},
			{
				Id = 105036,
				Value = -50,
			},
		},
	},
	Tags = {
		560111,
		564555,
		564560,
		564561,
	},
}
EnemyConfig[EnemyID.Id6334] =
{
	Id = 6334,
	Name = "诅咒宝箱怪",
	Rarity = 5,
	Element = 210004,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "深藏于顶级副本的史诗宝箱，再警惕的冒险者也无法抗拒他的璀璨光辉。而那些靠近的冒险者就再也回不来了。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	IconName = "RPG_EpicChest",
	PrefabBundle = "character_enemy",
	PrefabName = "RPG_EpicChest",
	PrefabScale = 50,
	HPBarHeight = 125,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 2166, Gain = 434},
		{Value = 200002, Base = 40, Gain = 8},
		{Value = 200003, Base = 0, Gain = 1},
		{Value = 200004, Base = 0, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "每回合对前3个队员造成80%攻击伤害\n回合中，每次受击，攻击 +3%\n每3回合回血 9%，最多5次\n5回合后，自身属性变为暗元素",
		Skill = {
			{
				Id = 105041,
				Value = 80,
			},
			{
				Id = 105170,
				Value = 3,
			},
			{
				Id = 105009,
				Value = 9,
			},
			{
				Id = 105160,
				Value = 210005,
			},
		},
	},
	Tags = {
		560111,
		564556,
		564560,
		564561,
	},
}
EnemyConfig[EnemyID.Id6335] =
{
	Id = 6335,
	Name = "诅咒宝箱怪",
	Rarity = 5,
	Element = 210004,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "深藏于顶级副本的史诗宝箱，再警惕的冒险者也无法抗拒他的璀璨光辉。而那些靠近的冒险者就再也回不来了。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	IconName = "RPG_EpicChest",
	PrefabBundle = "character_enemy",
	PrefabName = "RPG_EpicChest",
	PrefabScale = 50,
	HPBarHeight = 125,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 2237, Gain = 448},
		{Value = 200002, Base = 43, Gain = 9},
		{Value = 200003, Base = 0, Gain = 1},
		{Value = 200004, Base = 0, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "每回合对前3个队员造成80%攻击伤害\n回合中，每次受击，攻击 +3%\n每3回合回血 9%，最多5次\n5回合后，自身属性变为暗元素",
		Skill = {
			{
				Id = 105041,
				Value = 80,
			},
			{
				Id = 105170,
				Value = 3,
			},
			{
				Id = 105009,
				Value = 9,
			},
			{
				Id = 105160,
				Value = 210005,
			},
		},
	},
	Tags = {
		560111,
		564556,
		564560,
		564561,
	},
}
EnemyConfig[EnemyID.Id6336] =
{
	Id = 6336,
	Name = "诅咒宝箱怪",
	Rarity = 5,
	Element = 210004,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "深藏于顶级副本的史诗宝箱，再警惕的冒险者也无法抗拒他的璀璨光辉。而那些靠近的冒险者就再也回不来了。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	IconName = "RPG_EpicChest",
	PrefabBundle = "character_enemy",
	PrefabName = "RPG_EpicChest",
	PrefabScale = 50,
	HPBarHeight = 125,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 2757, Gain = 552},
		{Value = 200002, Base = 47, Gain = 10},
		{Value = 200003, Base = 0, Gain = 1},
		{Value = 200004, Base = 0, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "每回合对前3个队员造成80%攻击伤害\n回合中，每次受击，攻击 +3%\n每3回合回血 9%，最多5次\n5回合后，自身属性变为暗元素",
		Skill = {
			{
				Id = 105041,
				Value = 80,
			},
			{
				Id = 105170,
				Value = 3,
			},
			{
				Id = 105009,
				Value = 9,
			},
			{
				Id = 105160,
				Value = 210005,
			},
		},
	},
	Tags = {
		560111,
		564556,
		564560,
		564561,
	},
}
EnemyConfig[EnemyID.Id6337] =
{
	Id = 6337,
	Name = "麻痹花椒",
	Rarity = 1,
	Element = 210003,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：散布危险花椒种子，导致食客麻痹。",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "FAT",
	IconName = "FAT_SichuanPepper",
	PrefabBundle = "character_enemy",
	PrefabName = "FAT_SichuanPepper",
	PrefabScale = 50,
	HPBarHeight = 125,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 2168, Gain = 434},
		{Value = 200002, Base = 33, Gain = 7},
		{Value = 200003, Base = 0, Gain = 1},
		{Value = 200004, Base = 0, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "33%概率闪避攻击\n暴击伤害 +100%",
		Skill = {
			{
				Id = 105026,
				Value = 33,
			},
			{
				Id = 105038,
				Value = 100,
			},
		},
	},
	Tags = {
		560111,
		564556,
		564557,
	},
}
EnemyConfig[EnemyID.Id6338] =
{
	Id = 6338,
	Name = "麻痹花椒",
	Rarity = 1,
	Element = 210003,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：散布危险花椒种子，导致食客麻痹。",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "FAT",
	IconName = "FAT_SichuanPepper",
	PrefabBundle = "character_enemy",
	PrefabName = "FAT_SichuanPepper",
	PrefabScale = 50,
	HPBarHeight = 125,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 2361, Gain = 473},
		{Value = 200002, Base = 36, Gain = 8},
		{Value = 200003, Base = 0, Gain = 1},
		{Value = 200004, Base = 0, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "33%概率闪避攻击\n暴击伤害 +100%",
		Skill = {
			{
				Id = 105026,
				Value = 33,
			},
			{
				Id = 105038,
				Value = 100,
			},
		},
	},
	Tags = {
		560111,
		564556,
		564557,
	},
}
EnemyConfig[EnemyID.Id6339] =
{
	Id = 6339,
	Name = "麻痹花椒",
	Rarity = 1,
	Element = 210003,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：散布危险花椒种子，导致食客麻痹。",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "FAT",
	IconName = "FAT_SichuanPepper",
	PrefabBundle = "character_enemy",
	PrefabName = "FAT_SichuanPepper",
	PrefabScale = 50,
	HPBarHeight = 125,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 3049, Gain = 610},
		{Value = 200002, Base = 40, Gain = 8},
		{Value = 200003, Base = 0, Gain = 1},
		{Value = 200004, Base = 0, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "33%概率闪避攻击\n暴击伤害 +100%",
		Skill = {
			{
				Id = 105026,
				Value = 33,
			},
			{
				Id = 105038,
				Value = 100,
			},
		},
	},
	Tags = {
		560111,
		564556,
		564557,
	},
}
EnemyConfig[EnemyID.Id6340] =
{
	Id = 6340,
	Name = "白臭干",
	Rarity = 2,
	Element = 210004,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：四处散播浓重气味。",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "FAT",
	IconName = "FAT_StinkyTofuWhite",
	PrefabBundle = "character_enemy",
	PrefabName = "FAT_StinkyTofuWhite",
	PrefabScale = 50,
	HPBarHeight = 125,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 2087, Gain = 418},
		{Value = 200002, Base = 35, Gain = 7},
		{Value = 200003, Base = 0, Gain = 1},
		{Value = 200004, Base = 0, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "回合中，每次受击，攻击 +3%\n受到的暴击伤害 -50%",
		Skill = {
			{
				Id = 105170,
				Value = 3,
			},
			{
				Id = 105039,
				Value = -50,
			},
		},
	},
	Tags = {
		560111,
		564555,
		564561,
	},
}
EnemyConfig[EnemyID.Id6341] =
{
	Id = 6341,
	Name = "白臭干",
	Rarity = 2,
	Element = 210004,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：四处散播浓重气味。",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "FAT",
	IconName = "FAT_StinkyTofuWhite",
	PrefabBundle = "character_enemy",
	PrefabName = "FAT_StinkyTofuWhite",
	PrefabScale = 50,
	HPBarHeight = 125,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 2579, Gain = 516},
		{Value = 200002, Base = 36, Gain = 8},
		{Value = 200003, Base = 0, Gain = 1},
		{Value = 200004, Base = 0, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "回合中，每次受击，攻击 +3%\n受到的暴击伤害 -50%",
		Skill = {
			{
				Id = 105170,
				Value = 3,
			},
			{
				Id = 105039,
				Value = -50,
			},
		},
	},
	Tags = {
		560111,
		564555,
		564561,
	},
}
EnemyConfig[EnemyID.Id6342] =
{
	Id = 6342,
	Name = "白臭干",
	Rarity = 2,
	Element = 210004,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：四处散播浓重气味。",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "FAT",
	IconName = "FAT_StinkyTofuWhite",
	PrefabBundle = "character_enemy",
	PrefabName = "FAT_StinkyTofuWhite",
	PrefabScale = 50,
	HPBarHeight = 125,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 3025, Gain = 605},
		{Value = 200002, Base = 37, Gain = 8},
		{Value = 200003, Base = 0, Gain = 1},
		{Value = 200004, Base = 0, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "回合中，每次受击，攻击 +3%\n受到的暴击伤害 -50%",
		Skill = {
			{
				Id = 105170,
				Value = 3,
			},
			{
				Id = 105039,
				Value = -50,
			},
		},
	},
	Tags = {
		560111,
		564555,
		564561,
	},
}
EnemyConfig[EnemyID.Id6343] =
{
	Id = 6343,
	Name = "黑臭干",
	Rarity = 2,
	Element = 210005,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：四处散播浓重气味。",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "FAT",
	IconName = "FAT_StinkyTofuBlack",
	PrefabBundle = "character_enemy",
	PrefabName = "FAT_StinkyTofuBlack",
	PrefabScale = 50,
	HPBarHeight = 125,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 2178, Gain = 436},
		{Value = 200002, Base = 36, Gain = 8},
		{Value = 200003, Base = 0, Gain = 1},
		{Value = 200004, Base = 0, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "回合中，每次受击，攻击 +3%\n每回合回血 10%，最多5次",
		Skill = {
			{
				Id = 105170,
				Value = 3,
			},
			{
				Id = 105005,
				Value = 10,
			},
		},
	},
	Tags = {
		560111,
		564556,
		564560,
		564561,
	},
}
EnemyConfig[EnemyID.Id6344] =
{
	Id = 6344,
	Name = "黑臭干",
	Rarity = 2,
	Element = 210005,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：四处散播浓重气味。",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "FAT",
	IconName = "FAT_StinkyTofuBlack",
	PrefabBundle = "character_enemy",
	PrefabName = "FAT_StinkyTofuBlack",
	PrefabScale = 50,
	HPBarHeight = 125,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 2297, Gain = 460},
		{Value = 200002, Base = 39, Gain = 8},
		{Value = 200003, Base = 0, Gain = 1},
		{Value = 200004, Base = 0, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "回合中，每次受击，攻击 +3%\n每回合回血 10%，最多5次",
		Skill = {
			{
				Id = 105170,
				Value = 3,
			},
			{
				Id = 105005,
				Value = 10,
			},
		},
	},
	Tags = {
		560111,
		564556,
		564560,
		564561,
	},
}
EnemyConfig[EnemyID.Id6345] =
{
	Id = 6345,
	Name = "黑臭干",
	Rarity = 2,
	Element = 210005,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：四处散播浓重气味。",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "FAT",
	IconName = "FAT_StinkyTofuBlack",
	PrefabBundle = "character_enemy",
	PrefabName = "FAT_StinkyTofuBlack",
	PrefabScale = 50,
	HPBarHeight = 125,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 2882, Gain = 577},
		{Value = 200002, Base = 42, Gain = 9},
		{Value = 200003, Base = 0, Gain = 1},
		{Value = 200004, Base = 0, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "回合中，每次受击，攻击 +3%\n每回合回血 10%，最多5次",
		Skill = {
			{
				Id = 105170,
				Value = 3,
			},
			{
				Id = 105005,
				Value = 10,
			},
		},
	},
	Tags = {
		560111,
		564556,
		564560,
		564561,
	},
}
EnemyConfig[EnemyID.Id6346] =
{
	Id = 6346,
	Name = "仰望苍穹",
	Rarity = 3,
	Element = 210001,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：吸引其他路人仰望星空，导致颈椎病发。",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "FAT",
	IconName = "FAT_BreadFish",
	PrefabBundle = "character_enemy",
	PrefabName = "FAT_BreadFish",
	PrefabScale = 50,
	HPBarHeight = 125,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 2212, Gain = 443},
		{Value = 200002, Base = 40, Gain = 8},
		{Value = 200003, Base = 0, Gain = 1},
		{Value = 200004, Base = 0, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "每回合回血 8%，最多5次\n每回合对所有队员造成75%攻击伤害\n有33%概率额外攻击1次",
		Skill = {
			{
				Id = 105005,
				Value = 8,
			},
			{
				Id = 105047,
				Value = 75,
			},
			{
				Id = 105023,
				Value = 33,
			},
		},
	},
	Tags = {
		560111,
		564555,
		564558,
		564560,
	},
}
EnemyConfig[EnemyID.Id6347] =
{
	Id = 6347,
	Name = "仰望苍穹",
	Rarity = 3,
	Element = 210001,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：吸引其他路人仰望星空，导致颈椎病发。",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "FAT",
	IconName = "FAT_BreadFish",
	PrefabBundle = "character_enemy",
	PrefabName = "FAT_BreadFish",
	PrefabScale = 50,
	HPBarHeight = 125,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 2674, Gain = 535},
		{Value = 200002, Base = 41, Gain = 9},
		{Value = 200003, Base = 0, Gain = 1},
		{Value = 200004, Base = 0, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "每回合回血 8%，最多5次\n每回合对所有队员造成75%攻击伤害\n有33%概率额外攻击1次",
		Skill = {
			{
				Id = 105005,
				Value = 8,
			},
			{
				Id = 105047,
				Value = 75,
			},
			{
				Id = 105023,
				Value = 33,
			},
		},
	},
	Tags = {
		560111,
		564555,
		564558,
		564560,
	},
}
EnemyConfig[EnemyID.Id6348] =
{
	Id = 6348,
	Name = "仰望苍穹",
	Rarity = 3,
	Element = 210001,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：吸引其他路人仰望星空，导致颈椎病发。",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "FAT",
	IconName = "FAT_BreadFish",
	PrefabBundle = "character_enemy",
	PrefabName = "FAT_BreadFish",
	PrefabScale = 50,
	HPBarHeight = 125,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 3076, Gain = 616},
		{Value = 200002, Base = 43, Gain = 9},
		{Value = 200003, Base = 0, Gain = 1},
		{Value = 200004, Base = 0, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "每回合回血 8%，最多5次\n每回合对所有队员造成75%攻击伤害\n有33%概率额外攻击1次",
		Skill = {
			{
				Id = 105005,
				Value = 8,
			},
			{
				Id = 105047,
				Value = 75,
			},
			{
				Id = 105023,
				Value = 33,
			},
		},
	},
	Tags = {
		560111,
		564555,
		564558,
		564560,
	},
}
EnemyConfig[EnemyID.Id6349] =
{
	Id = 6349,
	Name = "不朽大列巴",
	Rarity = 4,
	Element = 210002,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：利用特殊硬化术挑战拳手，致人受伤。",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "FAT",
	IconName = "FAT_GreatLeba",
	PrefabBundle = "character_enemy",
	PrefabName = "FAT_GreatLeba",
	PrefabScale = 50,
	HPBarHeight = 110,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 2166, Gain = 434},
		{Value = 200002, Base = 40, Gain = 8},
		{Value = 200003, Base = 0, Gain = 1},
		{Value = 200004, Base = 0, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "回合中，每次受击，忍耐 +7\n受到的暴击伤害 -50%\n每2回合，回血5%\n5回合后，忍耐 +100",
		Skill = {
			{
				Id = 105171,
				Value = 7,
			},
			{
				Id = 105039,
				Value = -50,
			},
			{
				Id = 105182,
				Value = 5,
			},
			{
				Id = 105015,
				Value = 100,
			},
		},
	},
	Tags = {
		560111,
		564556,
		564560,
		564561,
	},
}
EnemyConfig[EnemyID.Id6350] =
{
	Id = 6350,
	Name = "不朽大列巴",
	Rarity = 4,
	Element = 210002,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：利用特殊硬化术挑战拳手，致人受伤。",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "FAT",
	IconName = "FAT_GreatLeba",
	PrefabBundle = "character_enemy",
	PrefabName = "FAT_GreatLeba",
	PrefabScale = 50,
	HPBarHeight = 110,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 2237, Gain = 448},
		{Value = 200002, Base = 43, Gain = 9},
		{Value = 200003, Base = 0, Gain = 1},
		{Value = 200004, Base = 0, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "回合中，每次受击，忍耐 +7\n受到的暴击伤害 -50%\n每2回合，回血5%\n5回合后，忍耐 +100",
		Skill = {
			{
				Id = 105171,
				Value = 7,
			},
			{
				Id = 105039,
				Value = -50,
			},
			{
				Id = 105182,
				Value = 5,
			},
			{
				Id = 105015,
				Value = 100,
			},
		},
	},
	Tags = {
		560111,
		564556,
		564560,
		564561,
	},
}
EnemyConfig[EnemyID.Id6351] =
{
	Id = 6351,
	Name = "不朽大列巴",
	Rarity = 4,
	Element = 210002,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：利用特殊硬化术挑战拳手，致人受伤。",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "FAT",
	IconName = "FAT_GreatLeba",
	PrefabBundle = "character_enemy",
	PrefabName = "FAT_GreatLeba",
	PrefabScale = 50,
	HPBarHeight = 110,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 2757, Gain = 552},
		{Value = 200002, Base = 47, Gain = 10},
		{Value = 200003, Base = 0, Gain = 1},
		{Value = 200004, Base = 0, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "回合中，每次受击，忍耐 +7\n受到的暴击伤害 -50%\n每2回合，回血5%\n5回合后，忍耐 +100",
		Skill = {
			{
				Id = 105171,
				Value = 7,
			},
			{
				Id = 105039,
				Value = -50,
			},
			{
				Id = 105182,
				Value = 5,
			},
			{
				Id = 105015,
				Value = 100,
			},
		},
	},
	Tags = {
		560111,
		564556,
		564560,
		564561,
	},
}
EnemyConfig[EnemyID.Id6352] =
{
	Id = 6352,
	Name = "腐烂草草",
	Rarity = 1,
	Element = 210003,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：偷走游客的物品，对警方的搜查拒不配合。",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	IconName = "Arena_SEA_Laminria1",
	PrefabBundle = "character_arenaenemy",
	PrefabName = "Arena_SEA_Laminria1",
	PrefabScale = 50,
	HPBarHeight = 125,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 2263, Gain = 453},
		{Value = 200002, Base = 34, Gain = 7},
		{Value = 200003, Base = 0, Gain = 1},
		{Value = 200004, Base = 0, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "每3回合，100%概率闪避攻击\n对暗元素敌人伤害 +100%",
		Skill = {
			{
				Id = 105140,
				Value = 100,
			},
			{
				Id = 105032,
				Value = 100,
			},
		},
	},
	Tags = {
		560111,
		564556,
		564557,
	},
}
EnemyConfig[EnemyID.Id6353] =
{
	Id = 6353,
	Name = "腐烂草草",
	Rarity = 1,
	Element = 210003,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：偷走游客的物品，对警方的搜查拒不配合。",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	IconName = "Arena_SEA_Laminria1",
	PrefabBundle = "character_arenaenemy",
	PrefabName = "Arena_SEA_Laminria1",
	PrefabScale = 50,
	HPBarHeight = 125,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 2481, Gain = 497},
		{Value = 200002, Base = 38, Gain = 8},
		{Value = 200003, Base = 0, Gain = 1},
		{Value = 200004, Base = 0, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "每3回合，100%概率闪避攻击\n对暗元素敌人伤害 +100%",
		Skill = {
			{
				Id = 105140,
				Value = 100,
			},
			{
				Id = 105032,
				Value = 100,
			},
		},
	},
	Tags = {
		560111,
		564556,
		564557,
	},
}
EnemyConfig[EnemyID.Id6354] =
{
	Id = 6354,
	Name = "腐烂草草",
	Rarity = 1,
	Element = 210003,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：偷走游客的物品，对警方的搜查拒不配合。",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	IconName = "Arena_SEA_Laminria1",
	PrefabBundle = "character_arenaenemy",
	PrefabName = "Arena_SEA_Laminria1",
	PrefabScale = 50,
	HPBarHeight = 125,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 3226, Gain = 646},
		{Value = 200002, Base = 41, Gain = 9},
		{Value = 200003, Base = 0, Gain = 1},
		{Value = 200004, Base = 0, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "每3回合，100%概率闪避攻击\n对暗元素敌人伤害 +100%",
		Skill = {
			{
				Id = 105140,
				Value = 100,
			},
			{
				Id = 105032,
				Value = 100,
			},
		},
	},
	Tags = {
		560111,
		564556,
		564557,
	},
}
EnemyConfig[EnemyID.Id6355] =
{
	Id = 6355,
	Name = "珊瑚草",
	Rarity = 2,
	Element = 210002,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：向广大居民赠送绿帽子，影响居民家庭关系。",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	IconName = "Arena_SEA_Coral2",
	PrefabBundle = "character_arenaenemy",
	PrefabName = "Arena_SEA_Coral2",
	PrefabScale = 50,
	HPBarHeight = 125,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 2168, Gain = 434},
		{Value = 200002, Base = 33, Gain = 7},
		{Value = 200003, Base = 0, Gain = 1},
		{Value = 200004, Base = 0, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "受火元素敌人伤害 -75%\n回合中，每次受击，攻击 +10%",
		Skill = {
			{
				Id = 105034,
				Value = -75,
			},
			{
				Id = 105170,
				Value = 10,
			},
		},
	},
	Tags = {
		560111,
		564556,
		564561,
	},
}
EnemyConfig[EnemyID.Id6356] =
{
	Id = 6356,
	Name = "珊瑚草",
	Rarity = 2,
	Element = 210002,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：向广大居民赠送绿帽子，影响居民家庭关系。",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	IconName = "Arena_SEA_Coral2",
	PrefabBundle = "character_arenaenemy",
	PrefabName = "Arena_SEA_Coral2",
	PrefabScale = 50,
	HPBarHeight = 125,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 2361, Gain = 473},
		{Value = 200002, Base = 36, Gain = 8},
		{Value = 200003, Base = 0, Gain = 1},
		{Value = 200004, Base = 0, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "受火元素敌人伤害 -75%\n回合中，每次受击，攻击 +10%",
		Skill = {
			{
				Id = 105034,
				Value = -75,
			},
			{
				Id = 105170,
				Value = 10,
			},
		},
	},
	Tags = {
		560111,
		564556,
		564561,
	},
}
EnemyConfig[EnemyID.Id6357] =
{
	Id = 6357,
	Name = "珊瑚草",
	Rarity = 2,
	Element = 210002,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：向广大居民赠送绿帽子，影响居民家庭关系。",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	IconName = "Arena_SEA_Coral2",
	PrefabBundle = "character_arenaenemy",
	PrefabName = "Arena_SEA_Coral2",
	PrefabScale = 50,
	HPBarHeight = 125,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 3049, Gain = 610},
		{Value = 200002, Base = 40, Gain = 8},
		{Value = 200003, Base = 0, Gain = 1},
		{Value = 200004, Base = 0, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "受火元素敌人伤害 -75%\n回合中，每次受击，攻击 +10%",
		Skill = {
			{
				Id = 105034,
				Value = -75,
			},
			{
				Id = 105170,
				Value = 10,
			},
		},
	},
	Tags = {
		560111,
		564556,
		564561,
	},
}
EnemyConfig[EnemyID.Id6358] =
{
	Id = 6358,
	Name = "暴走珊瑚",
	Rarity = 2,
	Element = 210001,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：疑似诱发海底龙卷风。",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	IconName = "Arena_SEA_Coral1",
	PrefabBundle = "character_arenaenemy",
	PrefabName = "Arena_SEA_Coral1",
	PrefabScale = 50,
	HPBarHeight = 110,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 2168, Gain = 434},
		{Value = 200002, Base = 33, Gain = 7},
		{Value = 200003, Base = 0, Gain = 1},
		{Value = 200004, Base = 0, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "受暗元素敌人伤害 -75%\n回合中，每次受击，攻击 +10%",
		Skill = {
			{
				Id = 105037,
				Value = -75,
			},
			{
				Id = 105170,
				Value = 10,
			},
		},
	},
	Tags = {
		560111,
		564556,
		564561,
	},
}
EnemyConfig[EnemyID.Id6359] =
{
	Id = 6359,
	Name = "暴走珊瑚",
	Rarity = 2,
	Element = 210001,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：疑似诱发海底龙卷风。",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	IconName = "Arena_SEA_Coral1",
	PrefabBundle = "character_arenaenemy",
	PrefabName = "Arena_SEA_Coral1",
	PrefabScale = 50,
	HPBarHeight = 110,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 2361, Gain = 473},
		{Value = 200002, Base = 36, Gain = 8},
		{Value = 200003, Base = 0, Gain = 1},
		{Value = 200004, Base = 0, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "受暗元素敌人伤害 -75%\n回合中，每次受击，攻击 +10%",
		Skill = {
			{
				Id = 105037,
				Value = -75,
			},
			{
				Id = 105170,
				Value = 10,
			},
		},
	},
	Tags = {
		560111,
		564556,
		564561,
	},
}
EnemyConfig[EnemyID.Id6360] =
{
	Id = 6360,
	Name = "暴走珊瑚",
	Rarity = 2,
	Element = 210001,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：疑似诱发海底龙卷风。",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	IconName = "Arena_SEA_Coral1",
	PrefabBundle = "character_arenaenemy",
	PrefabName = "Arena_SEA_Coral1",
	PrefabScale = 50,
	HPBarHeight = 110,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 3049, Gain = 610},
		{Value = 200002, Base = 40, Gain = 8},
		{Value = 200003, Base = 0, Gain = 1},
		{Value = 200004, Base = 0, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "受暗元素敌人伤害 -75%\n回合中，每次受击，攻击 +10%",
		Skill = {
			{
				Id = 105037,
				Value = -75,
			},
			{
				Id = 105170,
				Value = 10,
			},
		},
	},
	Tags = {
		560111,
		564556,
		564561,
	},
}
EnemyConfig[EnemyID.Id6361] =
{
	Id = 6361,
	Name = "腐坏贝壳",
	Rarity = 2,
	Element = 210002,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：打着算命的旗号诓骗游客且拒不还钱。",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	IconName = "Arena_SEA_Pectinid2",
	PrefabBundle = "character_arenaenemy",
	PrefabName = "Arena_SEA_Pectinid2",
	PrefabScale = 50,
	HPBarHeight = 110,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 2081, Gain = 417},
		{Value = 200002, Base = 32, Gain = 7},
		{Value = 200003, Base = 0, Gain = 1},
		{Value = 200004, Base = 0, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "受火元素敌人伤害 -75%\n暴击伤害 +100%",
		Skill = {
			{
				Id = 105034,
				Value = -75,
			},
			{
				Id = 105038,
				Value = 100,
			},
		},
	},
	Tags = {
		560111,
		564556,
	},
}
EnemyConfig[EnemyID.Id6362] =
{
	Id = 6362,
	Name = "腐坏贝壳",
	Rarity = 2,
	Element = 210002,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：打着算命的旗号诓骗游客且拒不还钱。",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	IconName = "Arena_SEA_Pectinid2",
	PrefabBundle = "character_arenaenemy",
	PrefabName = "Arena_SEA_Pectinid2",
	PrefabScale = 50,
	HPBarHeight = 110,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 2251, Gain = 451},
		{Value = 200002, Base = 35, Gain = 7},
		{Value = 200003, Base = 0, Gain = 1},
		{Value = 200004, Base = 0, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "受火元素敌人伤害 -75%\n暴击伤害 +100%",
		Skill = {
			{
				Id = 105034,
				Value = -75,
			},
			{
				Id = 105038,
				Value = 100,
			},
		},
	},
	Tags = {
		560111,
		564556,
	},
}
EnemyConfig[EnemyID.Id6363] =
{
	Id = 6363,
	Name = "腐坏贝壳",
	Rarity = 2,
	Element = 210002,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：打着算命的旗号诓骗游客且拒不还钱。",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	IconName = "Arena_SEA_Pectinid2",
	PrefabBundle = "character_arenaenemy",
	PrefabName = "Arena_SEA_Pectinid2",
	PrefabScale = 50,
	HPBarHeight = 110,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 2890, Gain = 578},
		{Value = 200002, Base = 38, Gain = 8},
		{Value = 200003, Base = 0, Gain = 1},
		{Value = 200004, Base = 0, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "受火元素敌人伤害 -75%\n暴击伤害 +100%",
		Skill = {
			{
				Id = 105034,
				Value = -75,
			},
			{
				Id = 105038,
				Value = 100,
			},
		},
	},
	Tags = {
		560111,
		564556,
	},
}
EnemyConfig[EnemyID.Id6364] =
{
	Id = 6364,
	Name = "脏贝壳",
	Rarity = 3,
	Element = 210004,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：强买强卖。",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	IconName = "Arena_SEA_Pectinid1",
	PrefabBundle = "character_arenaenemy",
	PrefabName = "Arena_SEA_Pectinid1",
	PrefabScale = 50,
	HPBarHeight = 125,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 2081, Gain = 417},
		{Value = 200002, Base = 32, Gain = 7},
		{Value = 200003, Base = 0, Gain = 1},
		{Value = 200004, Base = 0, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "受暗元素敌人伤害 -75%\n受到的暴击伤害 -50%",
		Skill = {
			{
				Id = 105037,
				Value = -75,
			},
			{
				Id = 105039,
				Value = -50,
			},
		},
	},
	Tags = {
		560111,
		564556,
	},
}
EnemyConfig[EnemyID.Id6365] =
{
	Id = 6365,
	Name = "脏贝壳",
	Rarity = 3,
	Element = 210004,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：强买强卖。",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	IconName = "Arena_SEA_Pectinid1",
	PrefabBundle = "character_arenaenemy",
	PrefabName = "Arena_SEA_Pectinid1",
	PrefabScale = 50,
	HPBarHeight = 125,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 2251, Gain = 451},
		{Value = 200002, Base = 35, Gain = 7},
		{Value = 200003, Base = 0, Gain = 1},
		{Value = 200004, Base = 0, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "受暗元素敌人伤害 -75%\n受到的暴击伤害 -50%",
		Skill = {
			{
				Id = 105037,
				Value = -75,
			},
			{
				Id = 105039,
				Value = -50,
			},
		},
	},
	Tags = {
		560111,
		564556,
	},
}
EnemyConfig[EnemyID.Id6366] =
{
	Id = 6366,
	Name = "脏贝壳",
	Rarity = 3,
	Element = 210004,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：强买强卖。",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	IconName = "Arena_SEA_Pectinid1",
	PrefabBundle = "character_arenaenemy",
	PrefabName = "Arena_SEA_Pectinid1",
	PrefabScale = 50,
	HPBarHeight = 125,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 2890, Gain = 578},
		{Value = 200002, Base = 38, Gain = 8},
		{Value = 200003, Base = 0, Gain = 1},
		{Value = 200004, Base = 0, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "受暗元素敌人伤害 -75%\n受到的暴击伤害 -50%",
		Skill = {
			{
				Id = 105037,
				Value = -75,
			},
			{
				Id = 105039,
				Value = -50,
			},
		},
	},
	Tags = {
		560111,
		564556,
	},
}
EnemyConfig[EnemyID.Id6367] =
{
	Id = 6367,
	Name = "血腥鱿鱼",
	Rarity = 2,
	Element = 210001,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：传播谣言，让海洋星居民人心惶惶。",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	IconName = "Arena_SEA_Inkfish",
	PrefabBundle = "character_arenaenemy",
	PrefabName = "Arena_SEA_Inkfish",
	PrefabScale = 50,
	HPBarHeight = 110,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 2087, Gain = 418},
		{Value = 200002, Base = 35, Gain = 7},
		{Value = 200003, Base = 0, Gain = 1},
		{Value = 200004, Base = 0, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "有100%概率额外攻击2次",
		Skill = {
			{
				Id = 105024,
				Value = 100,
			},
		},
	},
	Tags = {
		560111,
		564555,
		564558,
	},
}
EnemyConfig[EnemyID.Id6368] =
{
	Id = 6368,
	Name = "血腥鱿鱼",
	Rarity = 2,
	Element = 210001,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：传播谣言，让海洋星居民人心惶惶。",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	IconName = "Arena_SEA_Inkfish",
	PrefabBundle = "character_arenaenemy",
	PrefabName = "Arena_SEA_Inkfish",
	PrefabScale = 50,
	HPBarHeight = 110,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 2579, Gain = 516},
		{Value = 200002, Base = 36, Gain = 8},
		{Value = 200003, Base = 0, Gain = 1},
		{Value = 200004, Base = 0, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "有100%概率额外攻击2次",
		Skill = {
			{
				Id = 105024,
				Value = 100,
			},
		},
	},
	Tags = {
		560111,
		564555,
		564558,
	},
}
EnemyConfig[EnemyID.Id6369] =
{
	Id = 6369,
	Name = "血腥鱿鱼",
	Rarity = 2,
	Element = 210001,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：传播谣言，让海洋星居民人心惶惶。",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	IconName = "Arena_SEA_Inkfish",
	PrefabBundle = "character_arenaenemy",
	PrefabName = "Arena_SEA_Inkfish",
	PrefabScale = 50,
	HPBarHeight = 110,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 3025, Gain = 605},
		{Value = 200002, Base = 37, Gain = 8},
		{Value = 200003, Base = 0, Gain = 1},
		{Value = 200004, Base = 0, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "有100%概率额外攻击2次",
		Skill = {
			{
				Id = 105024,
				Value = 100,
			},
		},
	},
	Tags = {
		560111,
		564555,
		564558,
	},
}
EnemyConfig[EnemyID.Id6370] =
{
	Id = 6370,
	Name = "变质章鱼",
	Rarity = 4,
	Element = 210005,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：非法移民。",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	IconName = "Arena_SEA_Octupas1",
	PrefabBundle = "character_arenaenemy",
	PrefabName = "Arena_SEA_Octupas1",
	PrefabScale = 50,
	HPBarHeight = 125,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 2212, Gain = 443},
		{Value = 200002, Base = 40, Gain = 8},
		{Value = 200003, Base = 0, Gain = 1},
		{Value = 200004, Base = 0, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "有100%概率额外攻击2次\n受到的暴击伤害 -50%\n回合中，每次受击，攻击 +5%",
		Skill = {
			{
				Id = 105024,
				Value = 100,
			},
			{
				Id = 105039,
				Value = -50,
			},
			{
				Id = 105170,
				Value = 5,
			},
		},
	},
	Tags = {
		560111,
		564555,
		564558,
		564561,
	},
}
EnemyConfig[EnemyID.Id6371] =
{
	Id = 6371,
	Name = "变质章鱼",
	Rarity = 4,
	Element = 210005,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：非法移民。",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	IconName = "Arena_SEA_Octupas1",
	PrefabBundle = "character_arenaenemy",
	PrefabName = "Arena_SEA_Octupas1",
	PrefabScale = 50,
	HPBarHeight = 125,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 2674, Gain = 535},
		{Value = 200002, Base = 41, Gain = 9},
		{Value = 200003, Base = 0, Gain = 1},
		{Value = 200004, Base = 0, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "有100%概率额外攻击2次\n受到的暴击伤害 -50%\n回合中，每次受击，攻击 +5%",
		Skill = {
			{
				Id = 105024,
				Value = 100,
			},
			{
				Id = 105039,
				Value = -50,
			},
			{
				Id = 105170,
				Value = 5,
			},
		},
	},
	Tags = {
		560111,
		564555,
		564558,
		564561,
	},
}
EnemyConfig[EnemyID.Id6372] =
{
	Id = 6372,
	Name = "变质章鱼",
	Rarity = 4,
	Element = 210005,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：非法移民。",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	IconName = "Arena_SEA_Octupas1",
	PrefabBundle = "character_arenaenemy",
	PrefabName = "Arena_SEA_Octupas1",
	PrefabScale = 50,
	HPBarHeight = 125,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 3076, Gain = 616},
		{Value = 200002, Base = 43, Gain = 9},
		{Value = 200003, Base = 0, Gain = 1},
		{Value = 200004, Base = 0, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "有100%概率额外攻击2次\n受到的暴击伤害 -50%\n回合中，每次受击，攻击 +5%",
		Skill = {
			{
				Id = 105024,
				Value = 100,
			},
			{
				Id = 105039,
				Value = -50,
			},
			{
				Id = 105170,
				Value = 5,
			},
		},
	},
	Tags = {
		560111,
		564555,
		564558,
		564561,
	},
}
EnemyConfig[EnemyID.Id6373] =
{
	Id = 6373,
	Name = "霉草草",
	Rarity = 1,
	Element = 210002,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：偷走游客的物品，对警方的搜查拒不配合。",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	IconName = "Arena_SEA_Laminria2",
	PrefabBundle = "character_arenaenemy",
	PrefabName = "Arena_SEA_Laminria2",
	PrefabScale = 50,
	HPBarHeight = 125,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 2263, Gain = 453},
		{Value = 200002, Base = 34, Gain = 7},
		{Value = 200003, Base = 0, Gain = 1},
		{Value = 200004, Base = 0, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "每3回合，100%概率闪避攻击\n对光元素敌人伤害 +100%",
		Skill = {
			{
				Id = 105140,
				Value = 100,
			},
			{
				Id = 105031,
				Value = 100,
			},
		},
	},
	Tags = {
		560111,
		564556,
		564557,
	},
}
EnemyConfig[EnemyID.Id6374] =
{
	Id = 6374,
	Name = "霉草草",
	Rarity = 1,
	Element = 210002,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：偷走游客的物品，对警方的搜查拒不配合。",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	IconName = "Arena_SEA_Laminria2",
	PrefabBundle = "character_arenaenemy",
	PrefabName = "Arena_SEA_Laminria2",
	PrefabScale = 50,
	HPBarHeight = 125,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 2481, Gain = 497},
		{Value = 200002, Base = 38, Gain = 8},
		{Value = 200003, Base = 0, Gain = 1},
		{Value = 200004, Base = 0, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "每3回合，100%概率闪避攻击\n对光元素敌人伤害 +100%",
		Skill = {
			{
				Id = 105140,
				Value = 100,
			},
			{
				Id = 105031,
				Value = 100,
			},
		},
	},
	Tags = {
		560111,
		564556,
		564557,
	},
}
EnemyConfig[EnemyID.Id6375] =
{
	Id = 6375,
	Name = "霉草草",
	Rarity = 1,
	Element = 210002,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：偷走游客的物品，对警方的搜查拒不配合。",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	IconName = "Arena_SEA_Laminria2",
	PrefabBundle = "character_arenaenemy",
	PrefabName = "Arena_SEA_Laminria2",
	PrefabScale = 50,
	HPBarHeight = 125,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 3226, Gain = 646},
		{Value = 200002, Base = 41, Gain = 9},
		{Value = 200003, Base = 0, Gain = 1},
		{Value = 200004, Base = 0, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "每3回合，100%概率闪避攻击\n对光元素敌人伤害 +100%",
		Skill = {
			{
				Id = 105140,
				Value = 100,
			},
			{
				Id = 105031,
				Value = 100,
			},
		},
	},
	Tags = {
		560111,
		564556,
		564557,
	},
}
EnemyConfig[EnemyID.Id6376] =
{
	Id = 6376,
	Name = "多色海参",
	Rarity = 2,
	Element = 210001,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：肇事逃逸。",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	IconName = "Arena_SEA_SeaCucumber1",
	PrefabBundle = "character_arenaenemy",
	PrefabName = "Arena_SEA_SeaCucumber1",
	PrefabScale = 50,
	HPBarHeight = 125,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 2001, Gain = 401},
		{Value = 200002, Base = 31, Gain = 7},
		{Value = 200003, Base = 0, Gain = 1},
		{Value = 200004, Base = 0, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "每回合回血 8%，最多5次\n受水元素敌人伤害 -75%\n回合中，每次受击，忍耐 +8",
		Skill = {
			{
				Id = 105005,
				Value = 8,
			},
			{
				Id = 105033,
				Value = -75,
			},
			{
				Id = 105171,
				Value = 8,
			},
		},
	},
	Tags = {
		560111,
		564556,
		564560,
		564561,
	},
}
EnemyConfig[EnemyID.Id6377] =
{
	Id = 6377,
	Name = "多色海参",
	Rarity = 2,
	Element = 210001,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：肇事逃逸。",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	IconName = "Arena_SEA_SeaCucumber1",
	PrefabBundle = "character_arenaenemy",
	PrefabName = "Arena_SEA_SeaCucumber1",
	PrefabScale = 50,
	HPBarHeight = 125,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 2152, Gain = 431},
		{Value = 200002, Base = 34, Gain = 7},
		{Value = 200003, Base = 0, Gain = 1},
		{Value = 200004, Base = 0, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "每回合回血 8%，最多5次\n受水元素敌人伤害 -75%\n回合中，每次受击，忍耐 +8",
		Skill = {
			{
				Id = 105005,
				Value = 8,
			},
			{
				Id = 105033,
				Value = -75,
			},
			{
				Id = 105171,
				Value = 8,
			},
		},
	},
	Tags = {
		560111,
		564556,
		564560,
		564561,
	},
}
EnemyConfig[EnemyID.Id6378] =
{
	Id = 6378,
	Name = "多色海参",
	Rarity = 2,
	Element = 210001,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：肇事逃逸。",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	IconName = "Arena_SEA_SeaCucumber1",
	PrefabBundle = "character_arenaenemy",
	PrefabName = "Arena_SEA_SeaCucumber1",
	PrefabScale = 50,
	HPBarHeight = 125,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 2747, Gain = 550},
		{Value = 200002, Base = 37, Gain = 8},
		{Value = 200003, Base = 0, Gain = 1},
		{Value = 200004, Base = 0, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "每回合回血 8%，最多5次\n受水元素敌人伤害 -75%\n回合中，每次受击，忍耐 +8",
		Skill = {
			{
				Id = 105005,
				Value = 8,
			},
			{
				Id = 105033,
				Value = -75,
			},
			{
				Id = 105171,
				Value = 8,
			},
		},
	},
	Tags = {
		560111,
		564556,
		564560,
		564561,
	},
}
EnemyConfig[EnemyID.Id6379] =
{
	Id = 6379,
	Name = "沼泽海参",
	Rarity = 3,
	Element = 210002,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：打扰清洁人员清扫地面。",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	IconName = "Arena_SEA_SeaCucumber2",
	PrefabBundle = "character_arenaenemy",
	PrefabName = "Arena_SEA_SeaCucumber2",
	PrefabScale = 50,
	HPBarHeight = 125,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 2001, Gain = 401},
		{Value = 200002, Base = 31, Gain = 7},
		{Value = 200003, Base = 0, Gain = 1},
		{Value = 200004, Base = 0, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "每回合回血 8%，最多5次\n受火元素敌人伤害 -75%\n回合中，每次受击，忍耐 +8",
		Skill = {
			{
				Id = 105005,
				Value = 8,
			},
			{
				Id = 105034,
				Value = -75,
			},
			{
				Id = 105171,
				Value = 8,
			},
		},
	},
	Tags = {
		560111,
		564556,
		564560,
		564561,
	},
}
EnemyConfig[EnemyID.Id6380] =
{
	Id = 6380,
	Name = "沼泽海参",
	Rarity = 3,
	Element = 210002,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：打扰清洁人员清扫地面。",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	IconName = "Arena_SEA_SeaCucumber2",
	PrefabBundle = "character_arenaenemy",
	PrefabName = "Arena_SEA_SeaCucumber2",
	PrefabScale = 50,
	HPBarHeight = 125,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 2152, Gain = 431},
		{Value = 200002, Base = 34, Gain = 7},
		{Value = 200003, Base = 0, Gain = 1},
		{Value = 200004, Base = 0, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "每回合回血 8%，最多5次\n受火元素敌人伤害 -75%\n回合中，每次受击，忍耐 +8",
		Skill = {
			{
				Id = 105005,
				Value = 8,
			},
			{
				Id = 105034,
				Value = -75,
			},
			{
				Id = 105171,
				Value = 8,
			},
		},
	},
	Tags = {
		560111,
		564556,
		564560,
		564561,
	},
}
EnemyConfig[EnemyID.Id6381] =
{
	Id = 6381,
	Name = "沼泽海参",
	Rarity = 3,
	Element = 210002,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：打扰清洁人员清扫地面。",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	IconName = "Arena_SEA_SeaCucumber2",
	PrefabBundle = "character_arenaenemy",
	PrefabName = "Arena_SEA_SeaCucumber2",
	PrefabScale = 50,
	HPBarHeight = 125,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 2747, Gain = 550},
		{Value = 200002, Base = 37, Gain = 8},
		{Value = 200003, Base = 0, Gain = 1},
		{Value = 200004, Base = 0, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "每回合回血 8%，最多5次\n受火元素敌人伤害 -75%\n回合中，每次受击，忍耐 +8",
		Skill = {
			{
				Id = 105005,
				Value = 8,
			},
			{
				Id = 105034,
				Value = -75,
			},
			{
				Id = 105171,
				Value = 8,
			},
		},
	},
	Tags = {
		560111,
		564556,
		564560,
		564561,
	},
}
EnemyConfig[EnemyID.Id6382] =
{
	Id = 6382,
	Name = "芥末礁石",
	Rarity = 2,
	Element = 210003,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：用芥末对游客进行恶作剧。",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	IconName = "Arena_SEA_Stone1",
	PrefabBundle = "character_arenaenemy",
	PrefabName = "Arena_SEA_Stone1",
	PrefabScale = 50,
	HPBarHeight = 130,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 2334, Gain = 467},
		{Value = 200002, Base = 37, Gain = 8},
		{Value = 200003, Base = 0, Gain = 1},
		{Value = 200004, Base = 0, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "每2回合对末位队员造成100%攻击伤害\n有33%概率额外攻击1次\n回合中，每次受击，暴击 +8",
		Skill = {
			{
				Id = 105051,
				Value = 100,
			},
			{
				Id = 105023,
				Value = 33,
			},
			{
				Id = 105172,
				Value = 8,
			},
		},
	},
	Tags = {
		560111,
		564556,
		564558,
		564561,
	},
}
EnemyConfig[EnemyID.Id6383] =
{
	Id = 6383,
	Name = "芥末礁石",
	Rarity = 2,
	Element = 210003,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：用芥末对游客进行恶作剧。",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	IconName = "Arena_SEA_Stone1",
	PrefabBundle = "character_arenaenemy",
	PrefabName = "Arena_SEA_Stone1",
	PrefabScale = 50,
	HPBarHeight = 130,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 2484, Gain = 497},
		{Value = 200002, Base = 41, Gain = 9},
		{Value = 200003, Base = 0, Gain = 1},
		{Value = 200004, Base = 0, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "每2回合对末位队员造成100%攻击伤害\n有33%概率额外攻击1次\n回合中，每次受击，暴击 +8",
		Skill = {
			{
				Id = 105051,
				Value = 100,
			},
			{
				Id = 105023,
				Value = 33,
			},
			{
				Id = 105172,
				Value = 8,
			},
		},
	},
	Tags = {
		560111,
		564556,
		564558,
		564561,
	},
}
EnemyConfig[EnemyID.Id6384] =
{
	Id = 6384,
	Name = "芥末礁石",
	Rarity = 2,
	Element = 210003,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：用芥末对游客进行恶作剧。",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	IconName = "Arena_SEA_Stone1",
	PrefabBundle = "character_arenaenemy",
	PrefabName = "Arena_SEA_Stone1",
	PrefabScale = 50,
	HPBarHeight = 130,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 3141, Gain = 629},
		{Value = 200002, Base = 44, Gain = 9},
		{Value = 200003, Base = 0, Gain = 1},
		{Value = 200004, Base = 0, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "每2回合对末位队员造成100%攻击伤害\n有33%概率额外攻击1次\n回合中，每次受击，暴击 +8",
		Skill = {
			{
				Id = 105051,
				Value = 100,
			},
			{
				Id = 105023,
				Value = 33,
			},
			{
				Id = 105172,
				Value = 8,
			},
		},
	},
	Tags = {
		560111,
		564556,
		564558,
		564561,
	},
}
EnemyConfig[EnemyID.Id6385] =
{
	Id = 6385,
	Name = "邪恶礁石",
	Rarity = 3,
	Element = 210001,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：用胶水对游客进行恶作剧，并以此手段侵占游客私人物品。",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	IconName = "Arena_SEA_Stone2",
	PrefabBundle = "character_arenaenemy",
	PrefabName = "Arena_SEA_Stone2",
	PrefabScale = 50,
	HPBarHeight = 130,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 2334, Gain = 467},
		{Value = 200002, Base = 37, Gain = 8},
		{Value = 200003, Base = 0, Gain = 1},
		{Value = 200004, Base = 0, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "每2回合对末位队员造成100%攻击伤害\n暴击伤害 +100%\n回合中，每次受击，暴击 +8",
		Skill = {
			{
				Id = 105051,
				Value = 100,
			},
			{
				Id = 105038,
				Value = 100,
			},
			{
				Id = 105172,
				Value = 8,
			},
		},
	},
	Tags = {
		560111,
		564556,
		564561,
	},
}
EnemyConfig[EnemyID.Id6386] =
{
	Id = 6386,
	Name = "邪恶礁石",
	Rarity = 3,
	Element = 210001,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：用胶水对游客进行恶作剧，并以此手段侵占游客私人物品。",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	IconName = "Arena_SEA_Stone2",
	PrefabBundle = "character_arenaenemy",
	PrefabName = "Arena_SEA_Stone2",
	PrefabScale = 50,
	HPBarHeight = 130,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 2484, Gain = 497},
		{Value = 200002, Base = 41, Gain = 9},
		{Value = 200003, Base = 0, Gain = 1},
		{Value = 200004, Base = 0, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "每2回合对末位队员造成100%攻击伤害\n暴击伤害 +100%\n回合中，每次受击，暴击 +8",
		Skill = {
			{
				Id = 105051,
				Value = 100,
			},
			{
				Id = 105038,
				Value = 100,
			},
			{
				Id = 105172,
				Value = 8,
			},
		},
	},
	Tags = {
		560111,
		564556,
		564561,
	},
}
EnemyConfig[EnemyID.Id6387] =
{
	Id = 6387,
	Name = "邪恶礁石",
	Rarity = 3,
	Element = 210001,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：用胶水对游客进行恶作剧，并以此手段侵占游客私人物品。",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	IconName = "Arena_SEA_Stone2",
	PrefabBundle = "character_arenaenemy",
	PrefabName = "Arena_SEA_Stone2",
	PrefabScale = 50,
	HPBarHeight = 130,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 3141, Gain = 629},
		{Value = 200002, Base = 44, Gain = 9},
		{Value = 200003, Base = 0, Gain = 1},
		{Value = 200004, Base = 0, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "每2回合对末位队员造成100%攻击伤害\n暴击伤害 +100%\n回合中，每次受击，暴击 +8",
		Skill = {
			{
				Id = 105051,
				Value = 100,
			},
			{
				Id = 105038,
				Value = 100,
			},
			{
				Id = 105172,
				Value = 8,
			},
		},
	},
	Tags = {
		560111,
		564556,
		564561,
	},
}
EnemyConfig[EnemyID.Id6388] =
{
	Id = 6388,
	Name = "变异比目鱼",
	Rarity = 2,
	Element = 210003,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：危害公共交通安全。",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	IconName = "Arena_SEA_Flatfish",
	PrefabBundle = "character_arenaenemy",
	PrefabName = "Arena_SEA_Flatfish",
	PrefabScale = 50,
	HPBarHeight = 125,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 2253, Gain = 451},
		{Value = 200002, Base = 37, Gain = 8},
		{Value = 200003, Base = 0, Gain = 1},
		{Value = 200004, Base = 0, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "每回合对前3个队员造成100%攻击伤害\n75%概率无视敌人闪避",
		Skill = {
			{
				Id = 105041,
				Value = 100,
			},
			{
				Id = 105027,
				Value = 75,
			},
		},
	},
	Tags = {
		560111,
		564556,
		564559,
	},
}
EnemyConfig[EnemyID.Id6389] =
{
	Id = 6389,
	Name = "变异比目鱼",
	Rarity = 2,
	Element = 210003,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：危害公共交通安全。",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	IconName = "Arena_SEA_Flatfish",
	PrefabBundle = "character_arenaenemy",
	PrefabName = "Arena_SEA_Flatfish",
	PrefabScale = 50,
	HPBarHeight = 125,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 2386, Gain = 478},
		{Value = 200002, Base = 40, Gain = 8},
		{Value = 200003, Base = 0, Gain = 1},
		{Value = 200004, Base = 0, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "每回合对前3个队员造成100%攻击伤害\n75%概率无视敌人闪避",
		Skill = {
			{
				Id = 105041,
				Value = 100,
			},
			{
				Id = 105027,
				Value = 75,
			},
		},
	},
	Tags = {
		560111,
		564556,
		564559,
	},
}
EnemyConfig[EnemyID.Id6390] =
{
	Id = 6390,
	Name = "变异比目鱼",
	Rarity = 2,
	Element = 210003,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：危害公共交通安全。",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	IconName = "Arena_SEA_Flatfish",
	PrefabBundle = "character_arenaenemy",
	PrefabName = "Arena_SEA_Flatfish",
	PrefabScale = 50,
	HPBarHeight = 125,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 3006, Gain = 602},
		{Value = 200002, Base = 43, Gain = 9},
		{Value = 200003, Base = 0, Gain = 1},
		{Value = 200004, Base = 0, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "每回合对前3个队员造成100%攻击伤害\n75%概率无视敌人闪避",
		Skill = {
			{
				Id = 105041,
				Value = 100,
			},
			{
				Id = 105027,
				Value = 75,
			},
		},
	},
	Tags = {
		560111,
		564556,
		564559,
	},
}
EnemyConfig[EnemyID.Id6391] =
{
	Id = 6391,
	Name = "大丑鱼",
	Rarity = 3,
	Element = 210001,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：扰乱交通秩序。",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	IconName = "Arena_SEA_Nemo",
	PrefabBundle = "character_arenaenemy",
	PrefabName = "Arena_SEA_Nemo",
	PrefabScale = 50,
	HPBarHeight = 140,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 2253, Gain = 451},
		{Value = 200002, Base = 37, Gain = 8},
		{Value = 200003, Base = 0, Gain = 1},
		{Value = 200004, Base = 0, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "每回合对前3个队员造成120%攻击伤害\n每回合攻击 +20%，最多5次",
		Skill = {
			{
				Id = 105041,
				Value = 120,
			},
			{
				Id = 105006,
				Value = 20,
			},
		},
	},
	Tags = {
		560111,
		564556,
		564561,
	},
}
EnemyConfig[EnemyID.Id6392] =
{
	Id = 6392,
	Name = "大丑鱼",
	Rarity = 3,
	Element = 210001,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：扰乱交通秩序。",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	IconName = "Arena_SEA_Nemo",
	PrefabBundle = "character_arenaenemy",
	PrefabName = "Arena_SEA_Nemo",
	PrefabScale = 50,
	HPBarHeight = 140,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 2386, Gain = 478},
		{Value = 200002, Base = 40, Gain = 8},
		{Value = 200003, Base = 0, Gain = 1},
		{Value = 200004, Base = 0, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "每回合对前3个队员造成120%攻击伤害\n每回合攻击 +20%，最多5次",
		Skill = {
			{
				Id = 105041,
				Value = 120,
			},
			{
				Id = 105006,
				Value = 20,
			},
		},
	},
	Tags = {
		560111,
		564556,
		564561,
	},
}
EnemyConfig[EnemyID.Id6393] =
{
	Id = 6393,
	Name = "大丑鱼",
	Rarity = 3,
	Element = 210001,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：扰乱交通秩序。",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	IconName = "Arena_SEA_Nemo",
	PrefabBundle = "character_arenaenemy",
	PrefabName = "Arena_SEA_Nemo",
	PrefabScale = 50,
	HPBarHeight = 140,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 3006, Gain = 602},
		{Value = 200002, Base = 43, Gain = 9},
		{Value = 200003, Base = 0, Gain = 1},
		{Value = 200004, Base = 0, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "每回合对前3个队员造成120%攻击伤害\n每回合攻击 +20%，最多5次",
		Skill = {
			{
				Id = 105041,
				Value = 120,
			},
			{
				Id = 105006,
				Value = 20,
			},
		},
	},
	Tags = {
		560111,
		564556,
		564561,
	},
}
EnemyConfig[EnemyID.Id6394] =
{
	Id = 6394,
	Name = "斑斓妖怪鱼",
	Rarity = 4,
	Element = 210004,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：带乘客绕路来提高收入。",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	IconName = "Arena_SEA_TropicalFish",
	PrefabBundle = "character_arenaenemy",
	PrefabName = "Arena_SEA_TropicalFish",
	PrefabScale = 50,
	HPBarHeight = 125,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 2253, Gain = 451},
		{Value = 200002, Base = 37, Gain = 8},
		{Value = 200003, Base = 0, Gain = 1},
		{Value = 200004, Base = 0, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "每回合对前3个队员造成80%攻击伤害\n有50%概率额外攻击1次",
		Skill = {
			{
				Id = 105041,
				Value = 80,
			},
			{
				Id = 105023,
				Value = 50,
			},
		},
	},
	Tags = {
		560111,
		564556,
		564558,
	},
}
EnemyConfig[EnemyID.Id6395] =
{
	Id = 6395,
	Name = "斑斓妖怪鱼",
	Rarity = 4,
	Element = 210004,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：带乘客绕路来提高收入。",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	IconName = "Arena_SEA_TropicalFish",
	PrefabBundle = "character_arenaenemy",
	PrefabName = "Arena_SEA_TropicalFish",
	PrefabScale = 50,
	HPBarHeight = 125,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 2386, Gain = 478},
		{Value = 200002, Base = 40, Gain = 8},
		{Value = 200003, Base = 0, Gain = 1},
		{Value = 200004, Base = 0, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "每回合对前3个队员造成80%攻击伤害\n有50%概率额外攻击1次",
		Skill = {
			{
				Id = 105041,
				Value = 80,
			},
			{
				Id = 105023,
				Value = 50,
			},
		},
	},
	Tags = {
		560111,
		564556,
		564558,
	},
}
EnemyConfig[EnemyID.Id6396] =
{
	Id = 6396,
	Name = "斑斓妖怪鱼",
	Rarity = 4,
	Element = 210004,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：带乘客绕路来提高收入。",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	IconName = "Arena_SEA_TropicalFish",
	PrefabBundle = "character_arenaenemy",
	PrefabName = "Arena_SEA_TropicalFish",
	PrefabScale = 50,
	HPBarHeight = 125,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 3006, Gain = 602},
		{Value = 200002, Base = 43, Gain = 9},
		{Value = 200003, Base = 0, Gain = 1},
		{Value = 200004, Base = 0, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "每回合对前3个队员造成80%攻击伤害\n有50%概率额外攻击1次",
		Skill = {
			{
				Id = 105041,
				Value = 80,
			},
			{
				Id = 105023,
				Value = 50,
			},
		},
	},
	Tags = {
		560111,
		564556,
		564558,
	},
}
EnemyConfig[EnemyID.Id6397] =
{
	Id = 6397,
	Name = "灰水母",
	Rarity = 2,
	Element = 210001,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：为获取新闻私闯民宅。",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	IconName = "Arena_SEA_Jellyfish1",
	PrefabBundle = "character_arenaenemy",
	PrefabName = "Arena_SEA_Jellyfish1",
	PrefabScale = 50,
	HPBarHeight = 110,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 2178, Gain = 436},
		{Value = 200002, Base = 36, Gain = 8},
		{Value = 200003, Base = 0, Gain = 1},
		{Value = 200004, Base = 0, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "每回合回血 4%，最多5次\n回合中，每次受击，回血1%\n每回合，降低敌人50%攻击增强效果",
		Skill = {
			{
				Id = 105005,
				Value = 4,
			},
			{
				Id = 105186,
				Value = 1,
			},
			{
				Id = 105188,
				Value = 50,
			},
		},
	},
	Tags = {
		560111,
		564556,
		564560,
		564564,
	},
}
EnemyConfig[EnemyID.Id6398] =
{
	Id = 6398,
	Name = "灰水母",
	Rarity = 2,
	Element = 210001,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：为获取新闻私闯民宅。",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	IconName = "Arena_SEA_Jellyfish1",
	PrefabBundle = "character_arenaenemy",
	PrefabName = "Arena_SEA_Jellyfish1",
	PrefabScale = 50,
	HPBarHeight = 110,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 2297, Gain = 460},
		{Value = 200002, Base = 39, Gain = 8},
		{Value = 200003, Base = 0, Gain = 1},
		{Value = 200004, Base = 0, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "每回合回血 4%，最多5次\n回合中，每次受击，回血1%\n每回合，降低敌人50%攻击增强效果",
		Skill = {
			{
				Id = 105005,
				Value = 4,
			},
			{
				Id = 105186,
				Value = 1,
			},
			{
				Id = 105188,
				Value = 50,
			},
		},
	},
	Tags = {
		560111,
		564556,
		564560,
		564564,
	},
}
EnemyConfig[EnemyID.Id6399] =
{
	Id = 6399,
	Name = "灰水母",
	Rarity = 2,
	Element = 210001,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：为获取新闻私闯民宅。",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	IconName = "Arena_SEA_Jellyfish1",
	PrefabBundle = "character_arenaenemy",
	PrefabName = "Arena_SEA_Jellyfish1",
	PrefabScale = 50,
	HPBarHeight = 110,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 2882, Gain = 577},
		{Value = 200002, Base = 42, Gain = 9},
		{Value = 200003, Base = 0, Gain = 1},
		{Value = 200004, Base = 0, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "每回合回血 4%，最多5次\n回合中，每次受击，回血1%\n每回合，降低敌人50%攻击增强效果",
		Skill = {
			{
				Id = 105005,
				Value = 4,
			},
			{
				Id = 105186,
				Value = 1,
			},
			{
				Id = 105188,
				Value = 50,
			},
		},
	},
	Tags = {
		560111,
		564556,
		564560,
		564564,
	},
}
EnemyConfig[EnemyID.Id6400] =
{
	Id = 6400,
	Name = "腹黑水母",
	Rarity = 3,
	Element = 210005,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：损害偶像形象、偶像名誉权及个人隐私。",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	IconName = "Arena_SEA_Jellyfish3",
	PrefabBundle = "character_arenaenemy",
	PrefabName = "Arena_SEA_Jellyfish3",
	PrefabScale = 50,
	HPBarHeight = 125,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 2178, Gain = 436},
		{Value = 200002, Base = 36, Gain = 8},
		{Value = 200003, Base = 0, Gain = 1},
		{Value = 200004, Base = 0, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "每回合回血 5%，最多5次\n33%概率闪避攻击\n每回合，降低敌人50%忍耐增强效果",
		Skill = {
			{
				Id = 105005,
				Value = 5,
			},
			{
				Id = 105026,
				Value = 33,
			},
			{
				Id = 105189,
				Value = 50,
			},
		},
	},
	Tags = {
		560111,
		564556,
		564557,
		564560,
		564564,
	},
}
EnemyConfig[EnemyID.Id6401] =
{
	Id = 6401,
	Name = "腹黑水母",
	Rarity = 3,
	Element = 210005,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：损害偶像形象、偶像名誉权及个人隐私。",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	IconName = "Arena_SEA_Jellyfish3",
	PrefabBundle = "character_arenaenemy",
	PrefabName = "Arena_SEA_Jellyfish3",
	PrefabScale = 50,
	HPBarHeight = 125,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 2297, Gain = 460},
		{Value = 200002, Base = 39, Gain = 8},
		{Value = 200003, Base = 0, Gain = 1},
		{Value = 200004, Base = 0, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "每回合回血 5%，最多5次\n33%概率闪避攻击\n每回合，降低敌人50%忍耐增强效果",
		Skill = {
			{
				Id = 105005,
				Value = 5,
			},
			{
				Id = 105026,
				Value = 33,
			},
			{
				Id = 105189,
				Value = 50,
			},
		},
	},
	Tags = {
		560111,
		564556,
		564557,
		564560,
		564564,
	},
}
EnemyConfig[EnemyID.Id6402] =
{
	Id = 6402,
	Name = "腹黑水母",
	Rarity = 3,
	Element = 210005,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：损害偶像形象、偶像名誉权及个人隐私。",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	IconName = "Arena_SEA_Jellyfish3",
	PrefabBundle = "character_arenaenemy",
	PrefabName = "Arena_SEA_Jellyfish3",
	PrefabScale = 50,
	HPBarHeight = 125,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 2882, Gain = 577},
		{Value = 200002, Base = 42, Gain = 9},
		{Value = 200003, Base = 0, Gain = 1},
		{Value = 200004, Base = 0, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "每回合回血 5%，最多5次\n33%概率闪避攻击\n每回合，降低敌人50%忍耐增强效果",
		Skill = {
			{
				Id = 105005,
				Value = 5,
			},
			{
				Id = 105026,
				Value = 33,
			},
			{
				Id = 105189,
				Value = 50,
			},
		},
	},
	Tags = {
		560111,
		564556,
		564557,
		564560,
		564564,
	},
}
EnemyConfig[EnemyID.Id6403] =
{
	Id = 6403,
	Name = "绿水母",
	Rarity = 4,
	Element = 210004,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：标题党。",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	IconName = "Arena_SEA_Jellyfish2",
	PrefabBundle = "character_arenaenemy",
	PrefabName = "Arena_SEA_Jellyfish2",
	PrefabScale = 50,
	HPBarHeight = 110,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 2178, Gain = 436},
		{Value = 200002, Base = 36, Gain = 8},
		{Value = 200003, Base = 0, Gain = 1},
		{Value = 200004, Base = 0, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "每回合回血 5%，最多5次\n受到的暴击伤害 -50%\n每回合，降低敌人50%暴击增强效果",
		Skill = {
			{
				Id = 105005,
				Value = 5,
			},
			{
				Id = 105039,
				Value = -50,
			},
			{
				Id = 105190,
				Value = 50,
			},
		},
	},
	Tags = {
		560111,
		564556,
		564560,
		564564,
	},
}
EnemyConfig[EnemyID.Id6404] =
{
	Id = 6404,
	Name = "绿水母",
	Rarity = 4,
	Element = 210004,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：标题党。",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	IconName = "Arena_SEA_Jellyfish2",
	PrefabBundle = "character_arenaenemy",
	PrefabName = "Arena_SEA_Jellyfish2",
	PrefabScale = 50,
	HPBarHeight = 110,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 2297, Gain = 460},
		{Value = 200002, Base = 39, Gain = 8},
		{Value = 200003, Base = 0, Gain = 1},
		{Value = 200004, Base = 0, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "每回合回血 5%，最多5次\n受到的暴击伤害 -50%\n每回合，降低敌人50%暴击增强效果",
		Skill = {
			{
				Id = 105005,
				Value = 5,
			},
			{
				Id = 105039,
				Value = -50,
			},
			{
				Id = 105190,
				Value = 50,
			},
		},
	},
	Tags = {
		560111,
		564556,
		564560,
		564564,
	},
}
EnemyConfig[EnemyID.Id6405] =
{
	Id = 6405,
	Name = "绿水母",
	Rarity = 4,
	Element = 210004,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：标题党。",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	IconName = "Arena_SEA_Jellyfish2",
	PrefabBundle = "character_arenaenemy",
	PrefabName = "Arena_SEA_Jellyfish2",
	PrefabScale = 50,
	HPBarHeight = 110,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 2882, Gain = 577},
		{Value = 200002, Base = 42, Gain = 9},
		{Value = 200003, Base = 0, Gain = 1},
		{Value = 200004, Base = 0, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "每回合回血 5%，最多5次\n受到的暴击伤害 -50%\n每回合，降低敌人50%暴击增强效果",
		Skill = {
			{
				Id = 105005,
				Value = 5,
			},
			{
				Id = 105039,
				Value = -50,
			},
			{
				Id = 105190,
				Value = 50,
			},
		},
	},
	Tags = {
		560111,
		564556,
		564560,
		564564,
	},
}
EnemyConfig[EnemyID.Id6406] =
{
	Id = 6406,
	Name = "毒海蛇",
	Rarity = 2,
	Element = 210003,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：生产噪音扰民，且嘲讽居民们没有夜生活。",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	IconName = "Arena_SEA_Snake1",
	PrefabBundle = "character_arenaenemy",
	PrefabName = "Arena_SEA_Snake1",
	PrefabScale = 50,
	HPBarHeight = 130,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 2107, Gain = 422},
		{Value = 200002, Base = 35, Gain = 7},
		{Value = 200003, Base = 0, Gain = 1},
		{Value = 200004, Base = 0, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "100%概率无视敌人闪避\n暴击伤害 +100%\n每3回合有50%概率对前3个队员造成100%攻击伤害",
		Skill = {
			{
				Id = 105027,
				Value = 100,
			},
			{
				Id = 105038,
				Value = 100,
			},
			{
				Id = 105097,
				Value = 100,
			},
		},
	},
	Tags = {
		560111,
		564556,
		564559,
	},
}
EnemyConfig[EnemyID.Id6407] =
{
	Id = 6407,
	Name = "毒海蛇",
	Rarity = 2,
	Element = 210003,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：生产噪音扰民，且嘲讽居民们没有夜生活。",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	IconName = "Arena_SEA_Snake1",
	PrefabBundle = "character_arenaenemy",
	PrefabName = "Arena_SEA_Snake1",
	PrefabScale = 50,
	HPBarHeight = 130,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 2213, Gain = 443},
		{Value = 200002, Base = 39, Gain = 8},
		{Value = 200003, Base = 0, Gain = 1},
		{Value = 200004, Base = 0, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "100%概率无视敌人闪避\n暴击伤害 +100%\n每3回合有50%概率对前3个队员造成100%攻击伤害",
		Skill = {
			{
				Id = 105027,
				Value = 100,
			},
			{
				Id = 105038,
				Value = 100,
			},
			{
				Id = 105097,
				Value = 100,
			},
		},
	},
	Tags = {
		560111,
		564556,
		564559,
	},
}
EnemyConfig[EnemyID.Id6408] =
{
	Id = 6408,
	Name = "毒海蛇",
	Rarity = 2,
	Element = 210003,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：生产噪音扰民，且嘲讽居民们没有夜生活。",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	IconName = "Arena_SEA_Snake1",
	PrefabBundle = "character_arenaenemy",
	PrefabName = "Arena_SEA_Snake1",
	PrefabScale = 50,
	HPBarHeight = 130,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 2767, Gain = 554},
		{Value = 200002, Base = 42, Gain = 9},
		{Value = 200003, Base = 0, Gain = 1},
		{Value = 200004, Base = 0, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "100%概率无视敌人闪避\n暴击伤害 +100%\n每3回合有50%概率对前3个队员造成100%攻击伤害",
		Skill = {
			{
				Id = 105027,
				Value = 100,
			},
			{
				Id = 105038,
				Value = 100,
			},
			{
				Id = 105097,
				Value = 100,
			},
		},
	},
	Tags = {
		560111,
		564556,
		564559,
	},
}
EnemyConfig[EnemyID.Id6409] =
{
	Id = 6409,
	Name = "紫癣海蛇",
	Rarity = 4,
	Element = 210003,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：引起密集恐惧者不适且绝不悔改。",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	IconName = "Arena_SEA_Snake2",
	PrefabBundle = "character_arenaenemy",
	PrefabName = "Arena_SEA_Snake2",
	PrefabScale = 50,
	HPBarHeight = 130,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 2212, Gain = 443},
		{Value = 200002, Base = 40, Gain = 8},
		{Value = 200003, Base = 0, Gain = 1},
		{Value = 200004, Base = 0, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "100%概率无视敌人闪避\n暴击伤害 +150%\n每2回合有50%概率对前3个队员造成100%攻击伤害",
		Skill = {
			{
				Id = 105027,
				Value = 100,
			},
			{
				Id = 105038,
				Value = 150,
			},
			{
				Id = 105089,
				Value = 100,
			},
		},
	},
	Tags = {
		560111,
		564555,
		564559,
	},
}
EnemyConfig[EnemyID.Id6410] =
{
	Id = 6410,
	Name = "紫癣海蛇",
	Rarity = 4,
	Element = 210003,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：引起密集恐惧者不适且绝不悔改。",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	IconName = "Arena_SEA_Snake2",
	PrefabBundle = "character_arenaenemy",
	PrefabName = "Arena_SEA_Snake2",
	PrefabScale = 50,
	HPBarHeight = 130,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 2674, Gain = 535},
		{Value = 200002, Base = 41, Gain = 9},
		{Value = 200003, Base = 0, Gain = 1},
		{Value = 200004, Base = 0, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "100%概率无视敌人闪避\n暴击伤害 +150%\n每2回合有50%概率对前3个队员造成100%攻击伤害",
		Skill = {
			{
				Id = 105027,
				Value = 100,
			},
			{
				Id = 105038,
				Value = 150,
			},
			{
				Id = 105089,
				Value = 100,
			},
		},
	},
	Tags = {
		560111,
		564555,
		564559,
	},
}
EnemyConfig[EnemyID.Id6411] =
{
	Id = 6411,
	Name = "紫癣海蛇",
	Rarity = 4,
	Element = 210003,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：引起密集恐惧者不适且绝不悔改。",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	IconName = "Arena_SEA_Snake2",
	PrefabBundle = "character_arenaenemy",
	PrefabName = "Arena_SEA_Snake2",
	PrefabScale = 50,
	HPBarHeight = 130,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 3076, Gain = 616},
		{Value = 200002, Base = 43, Gain = 9},
		{Value = 200003, Base = 0, Gain = 1},
		{Value = 200004, Base = 0, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "100%概率无视敌人闪避\n暴击伤害 +150%\n每2回合有50%概率对前3个队员造成100%攻击伤害",
		Skill = {
			{
				Id = 105027,
				Value = 100,
			},
			{
				Id = 105038,
				Value = 150,
			},
			{
				Id = 105089,
				Value = 100,
			},
		},
	},
	Tags = {
		560111,
		564555,
		564559,
	},
}
EnemyConfig[EnemyID.Id6412] =
{
	Id = 6412,
	Name = "荧光海星",
	Rarity = 2,
	Element = 210001,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：光污染。",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	IconName = "Arena_SEA_SeaStar",
	PrefabBundle = "character_arenaenemy",
	PrefabName = "Arena_SEA_SeaStar",
	PrefabScale = 50,
	HPBarHeight = 125,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 2107, Gain = 422},
		{Value = 200002, Base = 35, Gain = 7},
		{Value = 200003, Base = 0, Gain = 1},
		{Value = 200004, Base = 0, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "每回合，降低敌人50%暴击增强效果\n每3回合回血 20%，最多5次",
		Skill = {
			{
				Id = 105190,
				Value = 50,
			},
			{
				Id = 105009,
				Value = 20,
			},
		},
	},
	Tags = {
		560111,
		564556,
		564560,
		564564,
	},
}
EnemyConfig[EnemyID.Id6413] =
{
	Id = 6413,
	Name = "荧光海星",
	Rarity = 2,
	Element = 210001,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：光污染。",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	IconName = "Arena_SEA_SeaStar",
	PrefabBundle = "character_arenaenemy",
	PrefabName = "Arena_SEA_SeaStar",
	PrefabScale = 50,
	HPBarHeight = 125,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 2213, Gain = 443},
		{Value = 200002, Base = 39, Gain = 8},
		{Value = 200003, Base = 0, Gain = 1},
		{Value = 200004, Base = 0, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "每回合，降低敌人50%暴击增强效果\n每3回合回血 20%，最多5次",
		Skill = {
			{
				Id = 105190,
				Value = 50,
			},
			{
				Id = 105009,
				Value = 20,
			},
		},
	},
	Tags = {
		560111,
		564556,
		564560,
		564564,
	},
}
EnemyConfig[EnemyID.Id6414] =
{
	Id = 6414,
	Name = "荧光海星",
	Rarity = 2,
	Element = 210001,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：光污染。",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	IconName = "Arena_SEA_SeaStar",
	PrefabBundle = "character_arenaenemy",
	PrefabName = "Arena_SEA_SeaStar",
	PrefabScale = 50,
	HPBarHeight = 125,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 2767, Gain = 554},
		{Value = 200002, Base = 42, Gain = 9},
		{Value = 200003, Base = 0, Gain = 1},
		{Value = 200004, Base = 0, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "每回合，降低敌人50%暴击增强效果\n每3回合回血 20%，最多5次",
		Skill = {
			{
				Id = 105190,
				Value = 50,
			},
			{
				Id = 105009,
				Value = 20,
			},
		},
	},
	Tags = {
		560111,
		564556,
		564560,
		564564,
	},
}
EnemyConfig[EnemyID.Id6415] =
{
	Id = 6415,
	Name = "淤泥海星",
	Rarity = 4,
	Element = 210001,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：搓澡时间过长，造成资源浪费。",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	IconName = "Arena_SEA_KingSeaStar",
	PrefabBundle = "character_arenaenemy",
	PrefabName = "Arena_SEA_KingSeaStar",
	PrefabScale = 50,
	HPBarHeight = 110,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 2212, Gain = 443},
		{Value = 200002, Base = 40, Gain = 8},
		{Value = 200003, Base = 0, Gain = 1},
		{Value = 200004, Base = 0, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "每回合，降低敌人50%攻击增强效果\n每回合回血 10%，最多5次\n回合中，每次受击，攻击 +5%",
		Skill = {
			{
				Id = 105188,
				Value = 50,
			},
			{
				Id = 105005,
				Value = 10,
			},
			{
				Id = 105170,
				Value = 5,
			},
		},
	},
	Tags = {
		560111,
		564555,
		564560,
		564561,
		564564,
	},
}
EnemyConfig[EnemyID.Id6416] =
{
	Id = 6416,
	Name = "淤泥海星",
	Rarity = 4,
	Element = 210001,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：搓澡时间过长，造成资源浪费。",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	IconName = "Arena_SEA_KingSeaStar",
	PrefabBundle = "character_arenaenemy",
	PrefabName = "Arena_SEA_KingSeaStar",
	PrefabScale = 50,
	HPBarHeight = 110,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 2674, Gain = 535},
		{Value = 200002, Base = 41, Gain = 9},
		{Value = 200003, Base = 0, Gain = 1},
		{Value = 200004, Base = 0, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "每回合，降低敌人50%攻击增强效果\n每回合回血 10%，最多5次\n回合中，每次受击，攻击 +5%",
		Skill = {
			{
				Id = 105188,
				Value = 50,
			},
			{
				Id = 105005,
				Value = 10,
			},
			{
				Id = 105170,
				Value = 5,
			},
		},
	},
	Tags = {
		560111,
		564555,
		564560,
		564561,
		564564,
	},
}
EnemyConfig[EnemyID.Id6417] =
{
	Id = 6417,
	Name = "淤泥海星",
	Rarity = 4,
	Element = 210001,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：搓澡时间过长，造成资源浪费。",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	IconName = "Arena_SEA_KingSeaStar",
	PrefabBundle = "character_arenaenemy",
	PrefabName = "Arena_SEA_KingSeaStar",
	PrefabScale = 50,
	HPBarHeight = 110,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 3076, Gain = 616},
		{Value = 200002, Base = 43, Gain = 9},
		{Value = 200003, Base = 0, Gain = 1},
		{Value = 200004, Base = 0, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "每回合，降低敌人50%攻击增强效果\n每回合回血 10%，最多5次\n回合中，每次受击，攻击 +5%",
		Skill = {
			{
				Id = 105188,
				Value = 50,
			},
			{
				Id = 105005,
				Value = 10,
			},
			{
				Id = 105170,
				Value = 5,
			},
		},
	},
	Tags = {
		560111,
		564555,
		564560,
		564561,
		564564,
	},
}
EnemyConfig[EnemyID.Id6418] =
{
	Id = 6418,
	Name = "紫薯水熊虫",
	Rarity = 1,
	Element = 210001,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：拉下成年男性的外裤，造成恶劣影响。",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	IconName = "Arena_SEA_WaterBear",
	PrefabBundle = "character_arenaenemy",
	PrefabName = "Arena_SEA_WaterBear",
	PrefabScale = 50,
	HPBarHeight = 130,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 2087, Gain = 418},
		{Value = 200002, Base = 35, Gain = 7},
		{Value = 200003, Base = 0, Gain = 1},
		{Value = 200004, Base = 0, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "忍耐 +150\n生命 +100%",
		Skill = {
			{
				Id = 105003,
				Value = 150,
			},
			{
				Id = 105001,
				Value = 100,
			},
		},
	},
	Tags = {
		560111,
		564555,
		564561,
	},
}
EnemyConfig[EnemyID.Id6419] =
{
	Id = 6419,
	Name = "紫薯水熊虫",
	Rarity = 1,
	Element = 210001,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：拉下成年男性的外裤，造成恶劣影响。",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	IconName = "Arena_SEA_WaterBear",
	PrefabBundle = "character_arenaenemy",
	PrefabName = "Arena_SEA_WaterBear",
	PrefabScale = 50,
	HPBarHeight = 130,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 2579, Gain = 516},
		{Value = 200002, Base = 36, Gain = 8},
		{Value = 200003, Base = 0, Gain = 1},
		{Value = 200004, Base = 0, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "忍耐 +150\n生命 +100%",
		Skill = {
			{
				Id = 105003,
				Value = 150,
			},
			{
				Id = 105001,
				Value = 100,
			},
		},
	},
	Tags = {
		560111,
		564555,
		564561,
	},
}
EnemyConfig[EnemyID.Id6420] =
{
	Id = 6420,
	Name = "紫薯水熊虫",
	Rarity = 1,
	Element = 210001,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：拉下成年男性的外裤，造成恶劣影响。",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	IconName = "Arena_SEA_WaterBear",
	PrefabBundle = "character_arenaenemy",
	PrefabName = "Arena_SEA_WaterBear",
	PrefabScale = 50,
	HPBarHeight = 130,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 3025, Gain = 605},
		{Value = 200002, Base = 37, Gain = 8},
		{Value = 200003, Base = 0, Gain = 1},
		{Value = 200004, Base = 0, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "忍耐 +150\n生命 +100%",
		Skill = {
			{
				Id = 105003,
				Value = 150,
			},
			{
				Id = 105001,
				Value = 100,
			},
		},
	},
	Tags = {
		560111,
		564555,
		564561,
	},
}
EnemyConfig[EnemyID.Id6421] =
{
	Id = 6421,
	Name = "霉菌海绵",
	Rarity = 2,
	Element = 210003,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：把房东太太的玻璃弄脏，并拒绝为其善后。",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	IconName = "Arena_SEA_CoralReef2",
	PrefabBundle = "character_arenaenemy",
	PrefabName = "Arena_SEA_CoralReef2",
	PrefabScale = 50,
	HPBarHeight = 130,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 2363, Gain = 473},
		{Value = 200002, Base = 41, Gain = 9},
		{Value = 200003, Base = 0, Gain = 1},
		{Value = 200004, Base = 0, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "受火元素敌人伤害 -100%\n攻击时无视敌人100忍耐\n每回合对前2个队员造成100%攻击伤害",
		Skill = {
			{
				Id = 105034,
				Value = -100,
			},
			{
				Id = 105169,
				Value = 100,
			},
			{
				Id = 105040,
				Value = 100,
			},
		},
	},
	Tags = {
		560111,
		564556,
		564563,
	},
}
EnemyConfig[EnemyID.Id6422] =
{
	Id = 6422,
	Name = "霉菌海绵",
	Rarity = 2,
	Element = 210003,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：把房东太太的玻璃弄脏，并拒绝为其善后。",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	IconName = "Arena_SEA_CoralReef2",
	PrefabBundle = "character_arenaenemy",
	PrefabName = "Arena_SEA_CoralReef2",
	PrefabScale = 50,
	HPBarHeight = 130,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 2464, Gain = 493},
		{Value = 200002, Base = 45, Gain = 9},
		{Value = 200003, Base = 0, Gain = 1},
		{Value = 200004, Base = 0, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "受火元素敌人伤害 -100%\n攻击时无视敌人100忍耐\n每回合对前2个队员造成100%攻击伤害",
		Skill = {
			{
				Id = 105034,
				Value = -100,
			},
			{
				Id = 105169,
				Value = 100,
			},
			{
				Id = 105040,
				Value = 100,
			},
		},
	},
	Tags = {
		560111,
		564556,
		564563,
	},
}
EnemyConfig[EnemyID.Id6423] =
{
	Id = 6423,
	Name = "霉菌海绵",
	Rarity = 2,
	Element = 210003,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：把房东太太的玻璃弄脏，并拒绝为其善后。",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	IconName = "Arena_SEA_CoralReef2",
	PrefabBundle = "character_arenaenemy",
	PrefabName = "Arena_SEA_CoralReef2",
	PrefabScale = 50,
	HPBarHeight = 130,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 3061, Gain = 613},
		{Value = 200002, Base = 49, Gain = 10},
		{Value = 200003, Base = 0, Gain = 1},
		{Value = 200004, Base = 0, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "受火元素敌人伤害 -100%\n攻击时无视敌人100忍耐\n每回合对前2个队员造成100%攻击伤害",
		Skill = {
			{
				Id = 105034,
				Value = -100,
			},
			{
				Id = 105169,
				Value = 100,
			},
			{
				Id = 105040,
				Value = 100,
			},
		},
	},
	Tags = {
		560111,
		564556,
		564563,
	},
}
EnemyConfig[EnemyID.Id6424] =
{
	Id = 6424,
	Name = "毒绵宝宝",
	Rarity = 3,
	Element = 210002,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：腐蚀玻璃，造成财产损失。",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	IconName = "Arena_SEA_CoralReef1",
	PrefabBundle = "character_arenaenemy",
	PrefabName = "Arena_SEA_CoralReef1",
	PrefabScale = 50,
	HPBarHeight = 130,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 2363, Gain = 473},
		{Value = 200002, Base = 41, Gain = 9},
		{Value = 200003, Base = 0, Gain = 1},
		{Value = 200004, Base = 0, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "受水元素敌人伤害 -100%\n攻击时无视敌人100忍耐\n每回合对前2个队员造成100%攻击伤害",
		Skill = {
			{
				Id = 105033,
				Value = -100,
			},
			{
				Id = 105169,
				Value = 100,
			},
			{
				Id = 105040,
				Value = 100,
			},
		},
	},
	Tags = {
		560111,
		564556,
		564563,
	},
}
EnemyConfig[EnemyID.Id6425] =
{
	Id = 6425,
	Name = "毒绵宝宝",
	Rarity = 3,
	Element = 210002,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：腐蚀玻璃，造成财产损失。",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	IconName = "Arena_SEA_CoralReef1",
	PrefabBundle = "character_arenaenemy",
	PrefabName = "Arena_SEA_CoralReef1",
	PrefabScale = 50,
	HPBarHeight = 130,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 2464, Gain = 493},
		{Value = 200002, Base = 45, Gain = 9},
		{Value = 200003, Base = 0, Gain = 1},
		{Value = 200004, Base = 0, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "受水元素敌人伤害 -100%\n攻击时无视敌人100忍耐\n每回合对前2个队员造成100%攻击伤害",
		Skill = {
			{
				Id = 105033,
				Value = -100,
			},
			{
				Id = 105169,
				Value = 100,
			},
			{
				Id = 105040,
				Value = 100,
			},
		},
	},
	Tags = {
		560111,
		564556,
		564563,
	},
}
EnemyConfig[EnemyID.Id6426] =
{
	Id = 6426,
	Name = "毒绵宝宝",
	Rarity = 3,
	Element = 210002,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：腐蚀玻璃，造成财产损失。",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	IconName = "Arena_SEA_CoralReef1",
	PrefabBundle = "character_arenaenemy",
	PrefabName = "Arena_SEA_CoralReef1",
	PrefabScale = 50,
	HPBarHeight = 130,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 3061, Gain = 613},
		{Value = 200002, Base = 49, Gain = 10},
		{Value = 200003, Base = 0, Gain = 1},
		{Value = 200004, Base = 0, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "受水元素敌人伤害 -100%\n攻击时无视敌人100忍耐\n每回合对前2个队员造成100%攻击伤害",
		Skill = {
			{
				Id = 105033,
				Value = -100,
			},
			{
				Id = 105169,
				Value = 100,
			},
			{
				Id = 105040,
				Value = 100,
			},
		},
	},
	Tags = {
		560111,
		564556,
		564563,
	},
}
EnemyConfig[EnemyID.Id6427] =
{
	Id = 6427,
	Name = "魔芋海葵",
	Rarity = 2,
	Element = 210002,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：欺骗移民官，用非法手段获得海洋星国籍。",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	IconName = "Arena_SEA_Actinian2",
	PrefabBundle = "character_arenaenemy",
	PrefabName = "Arena_SEA_Actinian2",
	PrefabScale = 50,
	HPBarHeight = 125,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 2293, Gain = 459},
		{Value = 200002, Base = 41, Gain = 9},
		{Value = 200003, Base = 0, Gain = 1},
		{Value = 200004, Base = 0, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "每2回合对后2个队员造成100%攻击伤害\n回合中，每次受击，攻击 +5%\n有33%概率额外攻击1次",
		Skill = {
			{
				Id = 105052,
				Value = 100,
			},
			{
				Id = 105170,
				Value = 5,
			},
			{
				Id = 105023,
				Value = 33,
			},
		},
	},
	Tags = {
		560111,
		564556,
		564558,
		564561,
	},
}
EnemyConfig[EnemyID.Id6428] =
{
	Id = 6428,
	Name = "魔芋海葵",
	Rarity = 2,
	Element = 210002,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：欺骗移民官，用非法手段获得海洋星国籍。",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	IconName = "Arena_SEA_Actinian2",
	PrefabBundle = "character_arenaenemy",
	PrefabName = "Arena_SEA_Actinian2",
	PrefabScale = 50,
	HPBarHeight = 125,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 2383, Gain = 477},
		{Value = 200002, Base = 44, Gain = 9},
		{Value = 200003, Base = 0, Gain = 1},
		{Value = 200004, Base = 0, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "每2回合对后2个队员造成100%攻击伤害\n回合中，每次受击，攻击 +5%\n有33%概率额外攻击1次",
		Skill = {
			{
				Id = 105052,
				Value = 100,
			},
			{
				Id = 105170,
				Value = 5,
			},
			{
				Id = 105023,
				Value = 33,
			},
		},
	},
	Tags = {
		560111,
		564556,
		564558,
		564561,
	},
}
EnemyConfig[EnemyID.Id6429] =
{
	Id = 6429,
	Name = "魔芋海葵",
	Rarity = 2,
	Element = 210002,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：欺骗移民官，用非法手段获得海洋星国籍。",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	IconName = "Arena_SEA_Actinian2",
	PrefabBundle = "character_arenaenemy",
	PrefabName = "Arena_SEA_Actinian2",
	PrefabScale = 50,
	HPBarHeight = 125,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 2952, Gain = 591},
		{Value = 200002, Base = 48, Gain = 10},
		{Value = 200003, Base = 0, Gain = 1},
		{Value = 200004, Base = 0, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "每2回合对后2个队员造成100%攻击伤害\n回合中，每次受击，攻击 +5%\n有33%概率额外攻击1次",
		Skill = {
			{
				Id = 105052,
				Value = 100,
			},
			{
				Id = 105170,
				Value = 5,
			},
			{
				Id = 105023,
				Value = 33,
			},
		},
	},
	Tags = {
		560111,
		564556,
		564558,
		564561,
	},
}
EnemyConfig[EnemyID.Id6430] =
{
	Id = 6430,
	Name = "血腥海葵",
	Rarity = 2,
	Element = 210001,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：帮助他人偷渡。",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	IconName = "Arena_SEA_Actinian1",
	PrefabBundle = "character_arenaenemy",
	PrefabName = "Arena_SEA_Actinian1",
	PrefabScale = 50,
	HPBarHeight = 125,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 2293, Gain = 459},
		{Value = 200002, Base = 41, Gain = 9},
		{Value = 200003, Base = 0, Gain = 1},
		{Value = 200004, Base = 0, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "每2回合对后2个队员造成100%攻击伤害\n回合中，每次受击，暴击 +5\n暴击伤害 +100%",
		Skill = {
			{
				Id = 105052,
				Value = 100,
			},
			{
				Id = 105172,
				Value = 5,
			},
			{
				Id = 105038,
				Value = 100,
			},
		},
	},
	Tags = {
		560111,
		564556,
		564561,
	},
}
EnemyConfig[EnemyID.Id6431] =
{
	Id = 6431,
	Name = "血腥海葵",
	Rarity = 2,
	Element = 210001,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：帮助他人偷渡。",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	IconName = "Arena_SEA_Actinian1",
	PrefabBundle = "character_arenaenemy",
	PrefabName = "Arena_SEA_Actinian1",
	PrefabScale = 50,
	HPBarHeight = 125,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 2383, Gain = 477},
		{Value = 200002, Base = 44, Gain = 9},
		{Value = 200003, Base = 0, Gain = 1},
		{Value = 200004, Base = 0, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "每2回合对后2个队员造成100%攻击伤害\n回合中，每次受击，暴击 +5\n暴击伤害 +100%",
		Skill = {
			{
				Id = 105052,
				Value = 100,
			},
			{
				Id = 105172,
				Value = 5,
			},
			{
				Id = 105038,
				Value = 100,
			},
		},
	},
	Tags = {
		560111,
		564556,
		564561,
	},
}
EnemyConfig[EnemyID.Id6432] =
{
	Id = 6432,
	Name = "血腥海葵",
	Rarity = 2,
	Element = 210001,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：帮助他人偷渡。",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	IconName = "Arena_SEA_Actinian1",
	PrefabBundle = "character_arenaenemy",
	PrefabName = "Arena_SEA_Actinian1",
	PrefabScale = 50,
	HPBarHeight = 125,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 2952, Gain = 591},
		{Value = 200002, Base = 48, Gain = 10},
		{Value = 200003, Base = 0, Gain = 1},
		{Value = 200004, Base = 0, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "每2回合对后2个队员造成100%攻击伤害\n回合中，每次受击，暴击 +5\n暴击伤害 +100%",
		Skill = {
			{
				Id = 105052,
				Value = 100,
			},
			{
				Id = 105172,
				Value = 5,
			},
			{
				Id = 105038,
				Value = 100,
			},
		},
	},
	Tags = {
		560111,
		564556,
		564561,
	},
}
EnemyConfig[EnemyID.Id6433] =
{
	Id = 6433,
	Name = "蟹员工",
	Rarity = 3,
	Element = 210003,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：带领众多同事一起摸鱼。",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	IconName = "Arena_SEA_Crab",
	PrefabBundle = "character_arenaenemy",
	PrefabName = "Arena_SEA_Crab",
	PrefabScale = 50,
	HPBarHeight = 125,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 2166, Gain = 434},
		{Value = 200002, Base = 40, Gain = 8},
		{Value = 200003, Base = 0, Gain = 1},
		{Value = 200004, Base = 0, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "每2回合，本回合暴率 +100%\n攻击时无视敌人100忍耐\n生命 +100%",
		Skill = {
			{
				Id = 105128,
				Value = 100,
			},
			{
				Id = 105169,
				Value = 100,
			},
			{
				Id = 105001,
				Value = 100,
			},
		},
	},
	Tags = {
		560111,
		564556,
		564561,
		564563,
	},
}
EnemyConfig[EnemyID.Id6434] =
{
	Id = 6434,
	Name = "蟹员工",
	Rarity = 3,
	Element = 210003,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：带领众多同事一起摸鱼。",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	IconName = "Arena_SEA_Crab",
	PrefabBundle = "character_arenaenemy",
	PrefabName = "Arena_SEA_Crab",
	PrefabScale = 50,
	HPBarHeight = 125,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 2237, Gain = 448},
		{Value = 200002, Base = 43, Gain = 9},
		{Value = 200003, Base = 0, Gain = 1},
		{Value = 200004, Base = 0, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "每2回合，本回合暴率 +100%\n攻击时无视敌人100忍耐\n生命 +100%",
		Skill = {
			{
				Id = 105128,
				Value = 100,
			},
			{
				Id = 105169,
				Value = 100,
			},
			{
				Id = 105001,
				Value = 100,
			},
		},
	},
	Tags = {
		560111,
		564556,
		564561,
		564563,
	},
}
EnemyConfig[EnemyID.Id6435] =
{
	Id = 6435,
	Name = "蟹员工",
	Rarity = 3,
	Element = 210003,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：带领众多同事一起摸鱼。",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	IconName = "Arena_SEA_Crab",
	PrefabBundle = "character_arenaenemy",
	PrefabName = "Arena_SEA_Crab",
	PrefabScale = 50,
	HPBarHeight = 125,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 2757, Gain = 552},
		{Value = 200002, Base = 47, Gain = 10},
		{Value = 200003, Base = 0, Gain = 1},
		{Value = 200004, Base = 0, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "每2回合，本回合暴率 +100%\n攻击时无视敌人100忍耐\n生命 +100%",
		Skill = {
			{
				Id = 105128,
				Value = 100,
			},
			{
				Id = 105169,
				Value = 100,
			},
			{
				Id = 105001,
				Value = 100,
			},
		},
	},
	Tags = {
		560111,
		564556,
		564561,
		564563,
	},
}
EnemyConfig[EnemyID.Id6436] =
{
	Id = 6436,
	Name = "蟹主管",
	Rarity = 4,
	Element = 210002,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：对真正的老板大不敬。",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	IconName = "Arena_SEA_KingCrab",
	PrefabBundle = "character_arenaenemy",
	PrefabName = "Arena_SEA_KingCrab",
	PrefabScale = 50,
	HPBarHeight = 125,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 2166, Gain = 434},
		{Value = 200002, Base = 40, Gain = 8},
		{Value = 200003, Base = 0, Gain = 1},
		{Value = 200004, Base = 0, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "每2回合，本回合暴率 +100%\n暴击伤害 +100%\n忍耐 +100",
		Skill = {
			{
				Id = 105128,
				Value = 100,
			},
			{
				Id = 105038,
				Value = 100,
			},
			{
				Id = 105003,
				Value = 100,
			},
		},
	},
	Tags = {
		560111,
		564556,
		564561,
	},
}
EnemyConfig[EnemyID.Id6437] =
{
	Id = 6437,
	Name = "蟹主管",
	Rarity = 4,
	Element = 210002,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：对真正的老板大不敬。",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	IconName = "Arena_SEA_KingCrab",
	PrefabBundle = "character_arenaenemy",
	PrefabName = "Arena_SEA_KingCrab",
	PrefabScale = 50,
	HPBarHeight = 125,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 2237, Gain = 448},
		{Value = 200002, Base = 43, Gain = 9},
		{Value = 200003, Base = 0, Gain = 1},
		{Value = 200004, Base = 0, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "每2回合，本回合暴率 +100%\n暴击伤害 +100%\n忍耐 +100",
		Skill = {
			{
				Id = 105128,
				Value = 100,
			},
			{
				Id = 105038,
				Value = 100,
			},
			{
				Id = 105003,
				Value = 100,
			},
		},
	},
	Tags = {
		560111,
		564556,
		564561,
	},
}
EnemyConfig[EnemyID.Id6438] =
{
	Id = 6438,
	Name = "蟹主管",
	Rarity = 4,
	Element = 210002,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：对真正的老板大不敬。",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	IconName = "Arena_SEA_KingCrab",
	PrefabBundle = "character_arenaenemy",
	PrefabName = "Arena_SEA_KingCrab",
	PrefabScale = 50,
	HPBarHeight = 125,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 2757, Gain = 552},
		{Value = 200002, Base = 47, Gain = 10},
		{Value = 200003, Base = 0, Gain = 1},
		{Value = 200004, Base = 0, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "每2回合，本回合暴率 +100%\n暴击伤害 +100%\n忍耐 +100",
		Skill = {
			{
				Id = 105128,
				Value = 100,
			},
			{
				Id = 105038,
				Value = 100,
			},
			{
				Id = 105003,
				Value = 100,
			},
		},
	},
	Tags = {
		560111,
		564556,
		564561,
	},
}
EnemyConfig[EnemyID.Id6439] =
{
	Id = 6439,
	Name = "腹黑海兔",
	Rarity = 2,
	Element = 210003,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：对众多女性放电，是名副其实的海王",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	IconName = "Arena_SEA_Aplysia3",
	PrefabBundle = "character_arenaenemy",
	PrefabName = "Arena_SEA_Aplysia3",
	PrefabScale = 50,
	HPBarHeight = 120,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 2228, Gain = 446},
		{Value = 200002, Base = 40, Gain = 8},
		{Value = 200003, Base = 0, Gain = 1},
		{Value = 200004, Base = 0, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "每回合回血 8%，最多5次\n每回合忍耐 +30，最多5次\n受火元素敌人伤害 -75%",
		Skill = {
			{
				Id = 105005,
				Value = 8,
			},
			{
				Id = 105007,
				Value = 30,
			},
			{
				Id = 105034,
				Value = -75,
			},
		},
	},
	Tags = {
		560111,
		564556,
		564560,
		564561,
	},
}
EnemyConfig[EnemyID.Id6440] =
{
	Id = 6440,
	Name = "腹黑海兔",
	Rarity = 2,
	Element = 210003,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：对众多女性放电，是名副其实的海王",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	IconName = "Arena_SEA_Aplysia3",
	PrefabBundle = "character_arenaenemy",
	PrefabName = "Arena_SEA_Aplysia3",
	PrefabScale = 50,
	HPBarHeight = 120,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 2308, Gain = 462},
		{Value = 200002, Base = 44, Gain = 9},
		{Value = 200003, Base = 0, Gain = 1},
		{Value = 200004, Base = 0, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "每回合回血 8%，最多5次\n每回合忍耐 +30，最多5次\n受火元素敌人伤害 -75%",
		Skill = {
			{
				Id = 105005,
				Value = 8,
			},
			{
				Id = 105007,
				Value = 30,
			},
			{
				Id = 105034,
				Value = -75,
			},
		},
	},
	Tags = {
		560111,
		564556,
		564560,
		564561,
	},
}
EnemyConfig[EnemyID.Id6441] =
{
	Id = 6441,
	Name = "腹黑海兔",
	Rarity = 2,
	Element = 210003,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：对众多女性放电，是名副其实的海王",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	IconName = "Arena_SEA_Aplysia3",
	PrefabBundle = "character_arenaenemy",
	PrefabName = "Arena_SEA_Aplysia3",
	PrefabScale = 50,
	HPBarHeight = 120,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 2851, Gain = 571},
		{Value = 200002, Base = 48, Gain = 10},
		{Value = 200003, Base = 0, Gain = 1},
		{Value = 200004, Base = 0, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "每回合回血 8%，最多5次\n每回合忍耐 +30，最多5次\n受火元素敌人伤害 -75%",
		Skill = {
			{
				Id = 105005,
				Value = 8,
			},
			{
				Id = 105007,
				Value = 30,
			},
			{
				Id = 105034,
				Value = -75,
			},
		},
	},
	Tags = {
		560111,
		564556,
		564560,
		564561,
	},
}
EnemyConfig[EnemyID.Id6442] =
{
	Id = 6442,
	Name = "梦幻海兔",
	Rarity = 3,
	Element = 210002,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：对同族成员颐指气使，给出不可能完成的任务。",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	IconName = "Arena_SEA_Aplysia1",
	PrefabBundle = "character_arenaenemy",
	PrefabName = "Arena_SEA_Aplysia1",
	PrefabScale = 50,
	HPBarHeight = 130,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 2228, Gain = 446},
		{Value = 200002, Base = 40, Gain = 8},
		{Value = 200003, Base = 0, Gain = 1},
		{Value = 200004, Base = 0, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "每回合回血 8%，最多5次\n每回合忍耐 +30，最多5次\n受水元素敌人伤害 -75%",
		Skill = {
			{
				Id = 105005,
				Value = 8,
			},
			{
				Id = 105007,
				Value = 30,
			},
			{
				Id = 105033,
				Value = -75,
			},
		},
	},
	Tags = {
		560111,
		564556,
		564560,
		564561,
	},
}
EnemyConfig[EnemyID.Id6443] =
{
	Id = 6443,
	Name = "梦幻海兔",
	Rarity = 3,
	Element = 210002,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：对同族成员颐指气使，给出不可能完成的任务。",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	IconName = "Arena_SEA_Aplysia1",
	PrefabBundle = "character_arenaenemy",
	PrefabName = "Arena_SEA_Aplysia1",
	PrefabScale = 50,
	HPBarHeight = 130,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 2308, Gain = 462},
		{Value = 200002, Base = 44, Gain = 9},
		{Value = 200003, Base = 0, Gain = 1},
		{Value = 200004, Base = 0, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "每回合回血 8%，最多5次\n每回合忍耐 +30，最多5次\n受水元素敌人伤害 -75%",
		Skill = {
			{
				Id = 105005,
				Value = 8,
			},
			{
				Id = 105007,
				Value = 30,
			},
			{
				Id = 105033,
				Value = -75,
			},
		},
	},
	Tags = {
		560111,
		564556,
		564560,
		564561,
	},
}
EnemyConfig[EnemyID.Id6444] =
{
	Id = 6444,
	Name = "梦幻海兔",
	Rarity = 3,
	Element = 210002,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：对同族成员颐指气使，给出不可能完成的任务。",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	IconName = "Arena_SEA_Aplysia1",
	PrefabBundle = "character_arenaenemy",
	PrefabName = "Arena_SEA_Aplysia1",
	PrefabScale = 50,
	HPBarHeight = 130,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 2851, Gain = 571},
		{Value = 200002, Base = 48, Gain = 10},
		{Value = 200003, Base = 0, Gain = 1},
		{Value = 200004, Base = 0, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "每回合回血 8%，最多5次\n每回合忍耐 +30，最多5次\n受水元素敌人伤害 -75%",
		Skill = {
			{
				Id = 105005,
				Value = 8,
			},
			{
				Id = 105007,
				Value = 30,
			},
			{
				Id = 105033,
				Value = -75,
			},
		},
	},
	Tags = {
		560111,
		564556,
		564560,
		564561,
	},
}
EnemyConfig[EnemyID.Id6445] =
{
	Id = 6445,
	Name = "噩梦海兔",
	Rarity = 4,
	Element = 210001,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：向别人描述噩梦。",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	IconName = "Arena_SEA_Aplysia2",
	PrefabBundle = "character_arenaenemy",
	PrefabName = "Arena_SEA_Aplysia2",
	PrefabScale = 50,
	HPBarHeight = 130,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 2228, Gain = 446},
		{Value = 200002, Base = 40, Gain = 8},
		{Value = 200003, Base = 0, Gain = 1},
		{Value = 200004, Base = 0, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "每回合回血 8%，最多5次\n每回合忍耐 +30，最多5次\n受风元素敌人伤害 -75%",
		Skill = {
			{
				Id = 105005,
				Value = 8,
			},
			{
				Id = 105007,
				Value = 30,
			},
			{
				Id = 105035,
				Value = -75,
			},
		},
	},
	Tags = {
		560111,
		564556,
		564560,
		564561,
	},
}
EnemyConfig[EnemyID.Id6446] =
{
	Id = 6446,
	Name = "噩梦海兔",
	Rarity = 4,
	Element = 210001,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：向别人描述噩梦。",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	IconName = "Arena_SEA_Aplysia2",
	PrefabBundle = "character_arenaenemy",
	PrefabName = "Arena_SEA_Aplysia2",
	PrefabScale = 50,
	HPBarHeight = 130,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 2308, Gain = 462},
		{Value = 200002, Base = 44, Gain = 9},
		{Value = 200003, Base = 0, Gain = 1},
		{Value = 200004, Base = 0, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "每回合回血 8%，最多5次\n每回合忍耐 +30，最多5次\n受风元素敌人伤害 -75%",
		Skill = {
			{
				Id = 105005,
				Value = 8,
			},
			{
				Id = 105007,
				Value = 30,
			},
			{
				Id = 105035,
				Value = -75,
			},
		},
	},
	Tags = {
		560111,
		564556,
		564560,
		564561,
	},
}
EnemyConfig[EnemyID.Id6447] =
{
	Id = 6447,
	Name = "噩梦海兔",
	Rarity = 4,
	Element = 210001,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：向别人描述噩梦。",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	IconName = "Arena_SEA_Aplysia2",
	PrefabBundle = "character_arenaenemy",
	PrefabName = "Arena_SEA_Aplysia2",
	PrefabScale = 50,
	HPBarHeight = 130,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 2851, Gain = 571},
		{Value = 200002, Base = 48, Gain = 10},
		{Value = 200003, Base = 0, Gain = 1},
		{Value = 200004, Base = 0, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "每回合回血 8%，最多5次\n每回合忍耐 +30，最多5次\n受风元素敌人伤害 -75%",
		Skill = {
			{
				Id = 105005,
				Value = 8,
			},
			{
				Id = 105007,
				Value = 30,
			},
			{
				Id = 105035,
				Value = -75,
			},
		},
	},
	Tags = {
		560111,
		564556,
		564560,
		564561,
	},
}
EnemyConfig[EnemyID.Id6448] =
{
	Id = 6448,
	Name = "红眼海螺",
	Rarity = 2,
	Element = 210001,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：从眼里发射红色射线，引发星球小范围恐慌。",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	IconName = "Arena_SEA_Conch",
	PrefabBundle = "character_arenaenemy",
	PrefabName = "Arena_SEA_Conch",
	PrefabScale = 50,
	HPBarHeight = 125,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 2087, Gain = 418},
		{Value = 200002, Base = 35, Gain = 7},
		{Value = 200003, Base = 0, Gain = 1},
		{Value = 200004, Base = 0, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "每回合攻击 +20%，最多5次\n100%概率无视敌人闪避",
		Skill = {
			{
				Id = 105006,
				Value = 20,
			},
			{
				Id = 105027,
				Value = 100,
			},
		},
	},
	Tags = {
		560111,
		564555,
		564559,
		564561,
	},
}
EnemyConfig[EnemyID.Id6449] =
{
	Id = 6449,
	Name = "红眼海螺",
	Rarity = 2,
	Element = 210001,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：从眼里发射红色射线，引发星球小范围恐慌。",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	IconName = "Arena_SEA_Conch",
	PrefabBundle = "character_arenaenemy",
	PrefabName = "Arena_SEA_Conch",
	PrefabScale = 50,
	HPBarHeight = 125,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 2579, Gain = 516},
		{Value = 200002, Base = 36, Gain = 8},
		{Value = 200003, Base = 0, Gain = 1},
		{Value = 200004, Base = 0, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "每回合攻击 +20%，最多5次\n100%概率无视敌人闪避",
		Skill = {
			{
				Id = 105006,
				Value = 20,
			},
			{
				Id = 105027,
				Value = 100,
			},
		},
	},
	Tags = {
		560111,
		564555,
		564559,
		564561,
	},
}
EnemyConfig[EnemyID.Id6450] =
{
	Id = 6450,
	Name = "红眼海螺",
	Rarity = 2,
	Element = 210001,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：从眼里发射红色射线，引发星球小范围恐慌。",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	IconName = "Arena_SEA_Conch",
	PrefabBundle = "character_arenaenemy",
	PrefabName = "Arena_SEA_Conch",
	PrefabScale = 50,
	HPBarHeight = 125,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 3025, Gain = 605},
		{Value = 200002, Base = 37, Gain = 8},
		{Value = 200003, Base = 0, Gain = 1},
		{Value = 200004, Base = 0, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "每回合攻击 +20%，最多5次\n100%概率无视敌人闪避",
		Skill = {
			{
				Id = 105006,
				Value = 20,
			},
			{
				Id = 105027,
				Value = 100,
			},
		},
	},
	Tags = {
		560111,
		564555,
		564559,
		564561,
	},
}
EnemyConfig[EnemyID.Id6451] =
{
	Id = 6451,
	Name = "绿藻海胆",
	Rarity = 2,
	Element = 210005,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：偷盗海藻并拒不承认。",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	IconName = "Arena_SEA_SeaUrchin",
	PrefabBundle = "character_arenaenemy",
	PrefabName = "Arena_SEA_SeaUrchin",
	PrefabScale = 50,
	HPBarHeight = 130,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 2087, Gain = 418},
		{Value = 200002, Base = 35, Gain = 7},
		{Value = 200003, Base = 0, Gain = 1},
		{Value = 200004, Base = 0, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "回合中，每次受击，攻击 +8%\n回合中，每次受击，暴击 +8",
		Skill = {
			{
				Id = 105170,
				Value = 8,
			},
			{
				Id = 105172,
				Value = 8,
			},
		},
	},
	Tags = {
		560111,
		564555,
		564561,
	},
}
EnemyConfig[EnemyID.Id6452] =
{
	Id = 6452,
	Name = "绿藻海胆",
	Rarity = 2,
	Element = 210005,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：偷盗海藻并拒不承认。",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	IconName = "Arena_SEA_SeaUrchin",
	PrefabBundle = "character_arenaenemy",
	PrefabName = "Arena_SEA_SeaUrchin",
	PrefabScale = 50,
	HPBarHeight = 130,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 2579, Gain = 516},
		{Value = 200002, Base = 36, Gain = 8},
		{Value = 200003, Base = 0, Gain = 1},
		{Value = 200004, Base = 0, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "回合中，每次受击，攻击 +8%\n回合中，每次受击，暴击 +8",
		Skill = {
			{
				Id = 105170,
				Value = 8,
			},
			{
				Id = 105172,
				Value = 8,
			},
		},
	},
	Tags = {
		560111,
		564555,
		564561,
	},
}
EnemyConfig[EnemyID.Id6453] =
{
	Id = 6453,
	Name = "绿藻海胆",
	Rarity = 2,
	Element = 210005,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：偷盗海藻并拒不承认。",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	IconName = "Arena_SEA_SeaUrchin",
	PrefabBundle = "character_arenaenemy",
	PrefabName = "Arena_SEA_SeaUrchin",
	PrefabScale = 50,
	HPBarHeight = 130,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 3025, Gain = 605},
		{Value = 200002, Base = 37, Gain = 8},
		{Value = 200003, Base = 0, Gain = 1},
		{Value = 200004, Base = 0, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "回合中，每次受击，攻击 +8%\n回合中，每次受击，暴击 +8",
		Skill = {
			{
				Id = 105170,
				Value = 8,
			},
			{
				Id = 105172,
				Value = 8,
			},
		},
	},
	Tags = {
		560111,
		564555,
		564561,
	},
}
EnemyConfig[EnemyID.Id6454] =
{
	Id = 6454,
	Name = "变异小飞象",
	Rarity = 3,
	Element = 210004,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：突然变脸。",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	IconName = "Arena_SEA_Octupas2",
	PrefabBundle = "character_arenaenemy",
	PrefabName = "Arena_SEA_Octupas2",
	PrefabScale = 50,
	HPBarHeight = 120,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 2212, Gain = 443},
		{Value = 200002, Base = 40, Gain = 8},
		{Value = 200003, Base = 0, Gain = 1},
		{Value = 200004, Base = 0, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "每3回合，100%概率闪避攻击\n33%概率闪避攻击\n有33%概率额外攻击1次",
		Skill = {
			{
				Id = 105140,
				Value = 100,
			},
			{
				Id = 105026,
				Value = 33,
			},
			{
				Id = 105023,
				Value = 33,
			},
		},
	},
	Tags = {
		560111,
		564555,
		564557,
		564558,
	},
}
EnemyConfig[EnemyID.Id6455] =
{
	Id = 6455,
	Name = "变异小飞象",
	Rarity = 3,
	Element = 210004,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：突然变脸。",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	IconName = "Arena_SEA_Octupas2",
	PrefabBundle = "character_arenaenemy",
	PrefabName = "Arena_SEA_Octupas2",
	PrefabScale = 50,
	HPBarHeight = 120,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 2674, Gain = 535},
		{Value = 200002, Base = 41, Gain = 9},
		{Value = 200003, Base = 0, Gain = 1},
		{Value = 200004, Base = 0, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "每3回合，100%概率闪避攻击\n33%概率闪避攻击\n有33%概率额外攻击1次",
		Skill = {
			{
				Id = 105140,
				Value = 100,
			},
			{
				Id = 105026,
				Value = 33,
			},
			{
				Id = 105023,
				Value = 33,
			},
		},
	},
	Tags = {
		560111,
		564555,
		564557,
		564558,
	},
}
EnemyConfig[EnemyID.Id6456] =
{
	Id = 6456,
	Name = "变异小飞象",
	Rarity = 3,
	Element = 210004,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：突然变脸。",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	IconName = "Arena_SEA_Octupas2",
	PrefabBundle = "character_arenaenemy",
	PrefabName = "Arena_SEA_Octupas2",
	PrefabScale = 50,
	HPBarHeight = 120,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 3076, Gain = 616},
		{Value = 200002, Base = 43, Gain = 9},
		{Value = 200003, Base = 0, Gain = 1},
		{Value = 200004, Base = 0, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "每3回合，100%概率闪避攻击\n33%概率闪避攻击\n有33%概率额外攻击1次",
		Skill = {
			{
				Id = 105140,
				Value = 100,
			},
			{
				Id = 105026,
				Value = 33,
			},
			{
				Id = 105023,
				Value = 33,
			},
		},
	},
	Tags = {
		560111,
		564555,
		564557,
		564558,
	},
}
EnemyConfig[EnemyID.Id6457] =
{
	Id = 6457,
	Name = "邪王龟",
	Rarity = 4,
	Element = 210001,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：毒打其他居民。",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	IconName = "Arena_SEA_SeaTurtle",
	PrefabBundle = "character_arenaenemy",
	PrefabName = "Arena_SEA_SeaTurtle",
	PrefabScale = 50,
	HPBarHeight = 125,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 2166, Gain = 434},
		{Value = 200002, Base = 40, Gain = 8},
		{Value = 200003, Base = 0, Gain = 1},
		{Value = 200004, Base = 0, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "每回合忍耐 +30，最多5次\n回合中，每次受击，忍耐 +8\n受到的暴击伤害 -50%",
		Skill = {
			{
				Id = 105007,
				Value = 30,
			},
			{
				Id = 105171,
				Value = 8,
			},
			{
				Id = 105039,
				Value = -50,
			},
		},
	},
	Tags = {
		560111,
		564556,
		564561,
	},
}
EnemyConfig[EnemyID.Id6458] =
{
	Id = 6458,
	Name = "邪王龟",
	Rarity = 4,
	Element = 210001,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：毒打其他居民。",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	IconName = "Arena_SEA_SeaTurtle",
	PrefabBundle = "character_arenaenemy",
	PrefabName = "Arena_SEA_SeaTurtle",
	PrefabScale = 50,
	HPBarHeight = 125,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 2237, Gain = 448},
		{Value = 200002, Base = 43, Gain = 9},
		{Value = 200003, Base = 0, Gain = 1},
		{Value = 200004, Base = 0, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "每回合忍耐 +30，最多5次\n回合中，每次受击，忍耐 +8\n受到的暴击伤害 -50%",
		Skill = {
			{
				Id = 105007,
				Value = 30,
			},
			{
				Id = 105171,
				Value = 8,
			},
			{
				Id = 105039,
				Value = -50,
			},
		},
	},
	Tags = {
		560111,
		564556,
		564561,
	},
}
EnemyConfig[EnemyID.Id6459] =
{
	Id = 6459,
	Name = "邪王龟",
	Rarity = 4,
	Element = 210001,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：毒打其他居民。",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	IconName = "Arena_SEA_SeaTurtle",
	PrefabBundle = "character_arenaenemy",
	PrefabName = "Arena_SEA_SeaTurtle",
	PrefabScale = 50,
	HPBarHeight = 125,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 2757, Gain = 552},
		{Value = 200002, Base = 47, Gain = 10},
		{Value = 200003, Base = 0, Gain = 1},
		{Value = 200004, Base = 0, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "每回合忍耐 +30，最多5次\n回合中，每次受击，忍耐 +8\n受到的暴击伤害 -50%",
		Skill = {
			{
				Id = 105007,
				Value = 30,
			},
			{
				Id = 105171,
				Value = 8,
			},
			{
				Id = 105039,
				Value = -50,
			},
		},
	},
	Tags = {
		560111,
		564556,
		564561,
	},
}
EnemyConfig[EnemyID.Id6460] =
{
	Id = 6460,
	Name = "布行布行",
	Rarity = 2,
	Element = 210003,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：袭击路人，并引起多起交通事故。",
	IconBundle = "atlas_activity_1",
	IconAtlas = "ActivityCharacterIcon",
	IconName = "All_BuJingYun",
	PrefabBundle = "character_enemy",
	PrefabName = "All_BuJingYun",
	PrefabScale = 50,
	HPBarHeight = 120,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 2087, Gain = 418},
		{Value = 200002, Base = 35, Gain = 7},
		{Value = 200003, Base = 0, Gain = 1},
		{Value = 200004, Base = 0, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "第1回合，对全部队员造成150%伤害\n第2回合，对全部队员造成 100%伤害\n回合3开始，每回合对全部队员造成 80%伤害",
		Skill = {
			{
				Id = 105211,
				Value = 150,
			},
			{
				Id = 105212,
				Value = 100,
			},
			{
				Id = 105213,
				Value = 80,
			},
		},
	},
	Tags = {
		560111,
		564555,
	},
}
EnemyConfig[EnemyID.Id6461] =
{
	Id = 6461,
	Name = "布行布行",
	Rarity = 2,
	Element = 210003,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：袭击路人，并引起多起交通事故。",
	IconBundle = "atlas_activity_1",
	IconAtlas = "ActivityCharacterIcon",
	IconName = "All_BuJingYun",
	PrefabBundle = "character_enemy",
	PrefabName = "All_BuJingYun",
	PrefabScale = 50,
	HPBarHeight = 120,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 2579, Gain = 516},
		{Value = 200002, Base = 36, Gain = 8},
		{Value = 200003, Base = 0, Gain = 1},
		{Value = 200004, Base = 0, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "第1回合，对全部队员造成150%伤害\n第2回合，对全部队员造成 100%伤害\n回合3开始，每回合对全部队员造成 80%伤害",
		Skill = {
			{
				Id = 105211,
				Value = 150,
			},
			{
				Id = 105212,
				Value = 100,
			},
			{
				Id = 105213,
				Value = 80,
			},
		},
	},
	Tags = {
		560111,
		564555,
	},
}
EnemyConfig[EnemyID.Id6462] =
{
	Id = 6462,
	Name = "布行布行",
	Rarity = 2,
	Element = 210003,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：袭击路人，并引起多起交通事故。",
	IconBundle = "atlas_activity_1",
	IconAtlas = "ActivityCharacterIcon",
	IconName = "All_BuJingYun",
	PrefabBundle = "character_enemy",
	PrefabName = "All_BuJingYun",
	PrefabScale = 50,
	HPBarHeight = 120,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 3025, Gain = 605},
		{Value = 200002, Base = 37, Gain = 8},
		{Value = 200003, Base = 0, Gain = 1},
		{Value = 200004, Base = 0, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "第1回合，对全部队员造成150%伤害\n第2回合，对全部队员造成 100%伤害\n回合3开始，每回合对全部队员造成 80%伤害",
		Skill = {
			{
				Id = 105211,
				Value = 150,
			},
			{
				Id = 105212,
				Value = 100,
			},
			{
				Id = 105213,
				Value = 80,
			},
		},
	},
	Tags = {
		560111,
		564555,
	},
}
EnemyConfig[EnemyID.Id6463] =
{
	Id = 6463,
	Name = "针滴戳",
	Rarity = 2,
	Element = 210003,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：幻想自己背负着童话诅咒，袭击金发女性。",
	IconBundle = "atlas_activity_1",
	IconAtlas = "ActivityCharacterIcon",
	IconName = "All_ZhenBuChuo",
	PrefabBundle = "character_enemy",
	PrefabName = "All_ZhenBuChuo",
	PrefabScale = 50,
	HPBarHeight = 120,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 2212, Gain = 443},
		{Value = 200002, Base = 40, Gain = 8},
		{Value = 200003, Base = 0, Gain = 1},
		{Value = 200004, Base = 0, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "对火元素敌人伤害 +60%\n受火元素敌人伤害 +60%\n攻击时无视敌人100%忍耐",
		Skill = {
			{
				Id = 105029,
				Value = 60,
			},
			{
				Id = 105218,
				Value = 60,
			},
			{
				Id = 105168,
				Value = 100,
			},
		},
	},
	Tags = {
		560111,
		564555,
		564563,
	},
}
EnemyConfig[EnemyID.Id6464] =
{
	Id = 6464,
	Name = "针滴戳",
	Rarity = 2,
	Element = 210003,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：幻想自己背负着童话诅咒，袭击金发女性。",
	IconBundle = "atlas_activity_1",
	IconAtlas = "ActivityCharacterIcon",
	IconName = "All_ZhenBuChuo",
	PrefabBundle = "character_enemy",
	PrefabName = "All_ZhenBuChuo",
	PrefabScale = 50,
	HPBarHeight = 120,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 2674, Gain = 535},
		{Value = 200002, Base = 41, Gain = 9},
		{Value = 200003, Base = 0, Gain = 1},
		{Value = 200004, Base = 0, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "对火元素敌人伤害 +60%\n受火元素敌人伤害 +60%\n攻击时无视敌人100%忍耐",
		Skill = {
			{
				Id = 105029,
				Value = 60,
			},
			{
				Id = 105218,
				Value = 60,
			},
			{
				Id = 105168,
				Value = 100,
			},
		},
	},
	Tags = {
		560111,
		564555,
		564563,
	},
}
EnemyConfig[EnemyID.Id6465] =
{
	Id = 6465,
	Name = "针滴戳",
	Rarity = 2,
	Element = 210003,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：幻想自己背负着童话诅咒，袭击金发女性。",
	IconBundle = "atlas_activity_1",
	IconAtlas = "ActivityCharacterIcon",
	IconName = "All_ZhenBuChuo",
	PrefabBundle = "character_enemy",
	PrefabName = "All_ZhenBuChuo",
	PrefabScale = 50,
	HPBarHeight = 120,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 3076, Gain = 616},
		{Value = 200002, Base = 43, Gain = 9},
		{Value = 200003, Base = 0, Gain = 1},
		{Value = 200004, Base = 0, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "对火元素敌人伤害 +60%\n受火元素敌人伤害 +60%\n攻击时无视敌人100%忍耐",
		Skill = {
			{
				Id = 105029,
				Value = 60,
			},
			{
				Id = 105218,
				Value = 60,
			},
			{
				Id = 105168,
				Value = 100,
			},
		},
	},
	Tags = {
		560111,
		564555,
		564563,
	},
}
EnemyConfig[EnemyID.Id6466] =
{
	Id = 6466,
	Name = "臭蛋香囊",
	Rarity = 2,
	Element = 210003,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：虚假宣传，售卖臭鸡蛋。",
	IconBundle = "atlas_activity_1",
	IconAtlas = "ActivityCharacterIcon",
	IconName = "All_ShiLiuXiangNiang",
	PrefabBundle = "character_enemy",
	PrefabName = "All_ShiLiuXiangNiang",
	PrefabScale = 50,
	HPBarHeight = 120,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 2166, Gain = 434},
		{Value = 200002, Base = 40, Gain = 8},
		{Value = 200003, Base = 0, Gain = 1},
		{Value = 200004, Base = 0, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "受风元素敌人伤害 +20%\n受火元素敌人伤害 +20%\n每回合对前3个队员造成80%攻击伤害",
		Skill = {
			{
				Id = 105219,
				Value = 20,
			},
			{
				Id = 105218,
				Value = 20,
			},
			{
				Id = 105041,
				Value = 80,
			},
		},
	},
	Tags = {
		560111,
		564555,
	},
}
EnemyConfig[EnemyID.Id6467] =
{
	Id = 6467,
	Name = "臭蛋香囊",
	Rarity = 2,
	Element = 210003,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：虚假宣传，售卖臭鸡蛋。",
	IconBundle = "atlas_activity_1",
	IconAtlas = "ActivityCharacterIcon",
	IconName = "All_ShiLiuXiangNiang",
	PrefabBundle = "character_enemy",
	PrefabName = "All_ShiLiuXiangNiang",
	PrefabScale = 50,
	HPBarHeight = 120,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 2237, Gain = 448},
		{Value = 200002, Base = 43, Gain = 9},
		{Value = 200003, Base = 0, Gain = 1},
		{Value = 200004, Base = 0, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "受风元素敌人伤害 +20%\n受火元素敌人伤害 +20%\n每回合对前3个队员造成80%攻击伤害",
		Skill = {
			{
				Id = 105219,
				Value = 20,
			},
			{
				Id = 105218,
				Value = 20,
			},
			{
				Id = 105041,
				Value = 80,
			},
		},
	},
	Tags = {
		560111,
		564555,
	},
}
EnemyConfig[EnemyID.Id6468] =
{
	Id = 6468,
	Name = "臭蛋香囊",
	Rarity = 2,
	Element = 210003,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：虚假宣传，售卖臭鸡蛋。",
	IconBundle = "atlas_activity_1",
	IconAtlas = "ActivityCharacterIcon",
	IconName = "All_ShiLiuXiangNiang",
	PrefabBundle = "character_enemy",
	PrefabName = "All_ShiLiuXiangNiang",
	PrefabScale = 50,
	HPBarHeight = 120,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 2757, Gain = 552},
		{Value = 200002, Base = 47, Gain = 10},
		{Value = 200003, Base = 0, Gain = 1},
		{Value = 200004, Base = 0, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "受风元素敌人伤害 +20%\n受火元素敌人伤害 +20%\n每回合对前3个队员造成80%攻击伤害",
		Skill = {
			{
				Id = 105219,
				Value = 20,
			},
			{
				Id = 105218,
				Value = 20,
			},
			{
				Id = 105041,
				Value = 80,
			},
		},
	},
	Tags = {
		560111,
		564555,
	},
}
EnemyConfig[EnemyID.Id6469] =
{
	Id = 6469,
	Name = "七夕果汁",
	Rarity = 2,
	Element = 210003,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：故意致使居民摔倒。",
	IconBundle = "atlas_activity_1",
	IconAtlas = "ActivityCharacterIcon",
	IconName = "All_QiXiGuoZi",
	PrefabBundle = "character_enemy",
	PrefabName = "All_QiXiGuoZi",
	PrefabScale = 50,
	HPBarHeight = 120,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 2087, Gain = 418},
		{Value = 200002, Base = 35, Gain = 7},
		{Value = 200003, Base = 0, Gain = 1},
		{Value = 200004, Base = 0, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "每3回合，60%概率闪避攻击\n回合中，每次受击，忍耐 +60\n攻击时无视敌人100%忍耐",
		Skill = {
			{
				Id = 105140,
				Value = 60,
			},
			{
				Id = 105171,
				Value = 60,
			},
			{
				Id = 105168,
				Value = 100,
			},
		},
	},
	Tags = {
		560111,
		564555,
		564557,
		564561,
		564563,
	},
}
EnemyConfig[EnemyID.Id6470] =
{
	Id = 6470,
	Name = "七夕果汁",
	Rarity = 2,
	Element = 210003,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：故意致使居民摔倒。",
	IconBundle = "atlas_activity_1",
	IconAtlas = "ActivityCharacterIcon",
	IconName = "All_QiXiGuoZi",
	PrefabBundle = "character_enemy",
	PrefabName = "All_QiXiGuoZi",
	PrefabScale = 50,
	HPBarHeight = 120,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 2579, Gain = 516},
		{Value = 200002, Base = 36, Gain = 8},
		{Value = 200003, Base = 0, Gain = 1},
		{Value = 200004, Base = 0, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "每3回合，60%概率闪避攻击\n回合中，每次受击，忍耐 +60\n攻击时无视敌人100%忍耐",
		Skill = {
			{
				Id = 105140,
				Value = 60,
			},
			{
				Id = 105171,
				Value = 60,
			},
			{
				Id = 105168,
				Value = 100,
			},
		},
	},
	Tags = {
		560111,
		564555,
		564557,
		564561,
		564563,
	},
}
EnemyConfig[EnemyID.Id6471] =
{
	Id = 6471,
	Name = "七夕果汁",
	Rarity = 2,
	Element = 210003,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：故意致使居民摔倒。",
	IconBundle = "atlas_activity_1",
	IconAtlas = "ActivityCharacterIcon",
	IconName = "All_QiXiGuoZi",
	PrefabBundle = "character_enemy",
	PrefabName = "All_QiXiGuoZi",
	PrefabScale = 50,
	HPBarHeight = 120,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 3025, Gain = 605},
		{Value = 200002, Base = 37, Gain = 8},
		{Value = 200003, Base = 0, Gain = 1},
		{Value = 200004, Base = 0, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "每3回合，60%概率闪避攻击\n回合中，每次受击，忍耐 +60\n攻击时无视敌人100%忍耐",
		Skill = {
			{
				Id = 105140,
				Value = 60,
			},
			{
				Id = 105171,
				Value = 60,
			},
			{
				Id = 105168,
				Value = 100,
			},
		},
	},
	Tags = {
		560111,
		564555,
		564557,
		564561,
		564563,
	},
}
EnemyConfig[EnemyID.Id6472] =
{
	Id = 6472,
	Name = "叽喳叽喳",
	Rarity = 2,
	Element = 210003,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：夜里高声尖叫，扰人清梦。",
	IconBundle = "atlas_activity_1",
	IconAtlas = "ActivityCharacterIcon",
	IconName = "All_PiKaPiKa",
	PrefabBundle = "character_enemy",
	PrefabName = "All_PiKaPiKa",
	PrefabScale = 50,
	HPBarHeight = 120,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 2212, Gain = 443},
		{Value = 200002, Base = 40, Gain = 8},
		{Value = 200003, Base = 0, Gain = 1},
		{Value = 200004, Base = 0, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "每回合攻击 +20%，最多5次\n回合中，每次受击，暴击 +20\n有80%概率额外攻击1次",
		Skill = {
			{
				Id = 105006,
				Value = 20,
			},
			{
				Id = 105172,
				Value = 20,
			},
			{
				Id = 105023,
				Value = 80,
			},
		},
	},
	Tags = {
		560111,
		564555,
		564558,
		564561,
	},
}
EnemyConfig[EnemyID.Id6473] =
{
	Id = 6473,
	Name = "叽喳叽喳",
	Rarity = 2,
	Element = 210003,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：夜里高声尖叫，扰人清梦。",
	IconBundle = "atlas_activity_1",
	IconAtlas = "ActivityCharacterIcon",
	IconName = "All_PiKaPiKa",
	PrefabBundle = "character_enemy",
	PrefabName = "All_PiKaPiKa",
	PrefabScale = 50,
	HPBarHeight = 120,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 2674, Gain = 535},
		{Value = 200002, Base = 41, Gain = 9},
		{Value = 200003, Base = 0, Gain = 1},
		{Value = 200004, Base = 0, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "每回合攻击 +20%，最多5次\n回合中，每次受击，暴击 +20\n有80%概率额外攻击1次",
		Skill = {
			{
				Id = 105006,
				Value = 20,
			},
			{
				Id = 105172,
				Value = 20,
			},
			{
				Id = 105023,
				Value = 80,
			},
		},
	},
	Tags = {
		560111,
		564555,
		564558,
		564561,
	},
}
EnemyConfig[EnemyID.Id6474] =
{
	Id = 6474,
	Name = "叽喳叽喳",
	Rarity = 2,
	Element = 210003,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：夜里高声尖叫，扰人清梦。",
	IconBundle = "atlas_activity_1",
	IconAtlas = "ActivityCharacterIcon",
	IconName = "All_PiKaPiKa",
	PrefabBundle = "character_enemy",
	PrefabName = "All_PiKaPiKa",
	PrefabScale = 50,
	HPBarHeight = 120,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 3076, Gain = 616},
		{Value = 200002, Base = 43, Gain = 9},
		{Value = 200003, Base = 0, Gain = 1},
		{Value = 200004, Base = 0, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "每回合攻击 +20%，最多5次\n回合中，每次受击，暴击 +20\n有80%概率额外攻击1次",
		Skill = {
			{
				Id = 105006,
				Value = 20,
			},
			{
				Id = 105172,
				Value = 20,
			},
			{
				Id = 105023,
				Value = 80,
			},
		},
	},
	Tags = {
		560111,
		564555,
		564558,
		564561,
	},
}
EnemyConfig[EnemyID.Id6501] =
{
	Id = 6501,
	Name = "黑暗料理大师",
	Rarity = 5,
	Element = 210002,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "与光明料理会不共戴天的料理者。被美食星驱逐后，成为了流亡街的居民。目前处于无照经营摊贩的状态，会推着料理小车，制作出让人无法拒绝的邪恶美食。",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	IconName = "Arena_Pir_DarkCooker",
	PrefabBundle = "character_boss",
	PrefabName = "Pir_01_DarkCooker",
	SkinName = "1_cat",
	PrefabScale = 50,
	HPBarHeight = 130,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_2",
		RangeAttackEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 3032, Gain = 607},
		{Value = 200002, Base = 42, Gain = 9},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "治愈料理：每3回合回血 15%，最多5次\n恐怖料理：每3回合攻击 +12%，最多3次\n异味风暴：每5回合对所有队员造成120%攻击伤害",
		Skill = {
			{
				Id = 105009,
				Value = 15,
			},
			{
				Id = 105010,
				Value = 12,
			},
			{
				Id = 105071,
				Value = 120,
			},
		},
	},
	Tags = {
		560111,
		564555,
		564560,
		564561,
	},
}
EnemyConfig[EnemyID.Id6502] =
{
	Id = 6502,
	Name = "死亡料理大师",
	Rarity = 5,
	Element = 210002,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "与光明料理会不共戴天的料理者。被美食星驱逐后，成为了流亡街的居民。目前处于无照经营摊贩的状态，会推着料理小车，制作出让人无法拒绝的邪恶美食。",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	IconName = "Arena_Pir_DarkCooker",
	PrefabBundle = "character_boss",
	PrefabName = "Pir_01_DarkCooker",
	SkinName = "1_cat",
	PrefabScale = 50,
	HPBarHeight = 130,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_2",
		RangeAttackEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 4447, Gain = 890},
		{Value = 200002, Base = 43, Gain = 9},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "治愈料理：每3回合回血 15%，最多5次\n恐怖料理：每3回合攻击 +12%，最多3次\n超级异味风暴：每5回合对所有队员造成120%攻击伤害",
		Skill = {
			{
				Id = 105009,
				Value = 15,
			},
			{
				Id = 105010,
				Value = 12,
			},
			{
				Id = 105071,
				Value = 120,
			},
		},
	},
	Tags = {
		560111,
		564555,
		564560,
		564561,
	},
}
EnemyConfig[EnemyID.Id6503] =
{
	Id = 6503,
	Name = "末日料理大师",
	Rarity = 5,
	Element = 210002,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "与光明料理会不共戴天的料理者。被美食星驱逐后，成为了流亡街的居民。目前处于无照经营摊贩的状态，会推着料理小车，制作出让人无法拒绝的邪恶美食。",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	IconName = "Arena_Pir_DarkCooker",
	PrefabBundle = "character_boss",
	PrefabName = "Pir_01_DarkCooker",
	SkinName = "1_cat",
	PrefabScale = 50,
	HPBarHeight = 130,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_2",
		RangeAttackEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 5644, Gain = 1129},
		{Value = 200002, Base = 45, Gain = 9},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "终极治愈料理：每3回合回血 20%，最多5次\n终极恐怖料理：每3回合攻击 +15%，最多3次\n终极异味风暴：每3回合对所有队员造成120%攻击伤害\n厨师天赋：受火元素敌人伤害 -100%",
		Skill = {
			{
				Id = 105009,
				Value = 20,
			},
			{
				Id = 105010,
				Value = 15,
			},
			{
				Id = 105063,
				Value = 120,
			},
			{
				Id = 105034,
				Value = -100,
			},
		},
	},
	Tags = {
		560111,
		564555,
		564560,
		564561,
	},
}
EnemyConfig[EnemyID.Id6504] =
{
	Id = 6504,
	Name = "超能少女",
	Rarity = 5,
	Element = 210004,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "从超能星被拐骗到流亡街的美丽少女，因为开朗的性格，很受到流亡街居民的喜爱。平时喜欢坐在博士特制的轮椅上思考人生，不过一旦被激活，就会展现出无与伦比的超能力。",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	IconName = "Arena_Pir_SuperGirl",
	PrefabBundle = "character_boss",
	PrefabName = "Pir_02_SuperGirl",
	SkinName = "1_cat",
	PrefabScale = 50,
	HPBarHeight = 130,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 3032, Gain = 607},
		{Value = 200002, Base = 42, Gain = 9},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "不稳定态：每3回合将自身元素变为随机元素\n能量冲击：每3回合对前3个队员造成150%攻击伤害\n力量解放：5回合后，攻击 +50%",
		Skill = {
			{
				Id = 105163,
				Value = -1,
			},
			{
				Id = 105057,
				Value = 150,
			},
			{
				Id = 105014,
				Value = 50,
			},
		},
	},
	Tags = {
		560111,
		564555,
		564561,
	},
}
EnemyConfig[EnemyID.Id6505] =
{
	Id = 6505,
	Name = "超能少女",
	Rarity = 5,
	Element = 210004,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "从超能星被拐骗到流亡街的美丽少女，因为开朗的性格，很受到流亡街居民的喜爱。平时喜欢坐在博士特制的轮椅上思考人生，不过一旦被激活，就会展现出无与伦比的超能力。",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	IconName = "Arena_Pir_SuperGirl",
	PrefabBundle = "character_boss",
	PrefabName = "Pir_02_SuperGirl",
	SkinName = "1_cat",
	PrefabScale = 50,
	HPBarHeight = 130,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 4169, Gain = 834},
		{Value = 200002, Base = 43, Gain = 9},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "不稳定态：每3回合将自身元素变为随机元素\n能量冲击：每3回合对前3个队员造成150%攻击伤害\n力量解放：5回合后，攻击 +50%",
		Skill = {
			{
				Id = 105163,
				Value = -1,
			},
			{
				Id = 105057,
				Value = 150,
			},
			{
				Id = 105014,
				Value = 50,
			},
		},
	},
	Tags = {
		560111,
		564555,
		564561,
	},
}
EnemyConfig[EnemyID.Id6506] =
{
	Id = 6506,
	Name = "超能少女",
	Rarity = 5,
	Element = 210004,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "从超能星被拐骗到流亡街的美丽少女，因为开朗的性格，很受到流亡街居民的喜爱。平时喜欢坐在博士特制的轮椅上思考人生，不过一旦被激活，就会展现出无与伦比的超能力。",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	IconName = "Arena_Pir_SuperGirl",
	PrefabBundle = "character_boss",
	PrefabName = "Pir_02_SuperGirl",
	SkinName = "1_cat",
	PrefabScale = 50,
	HPBarHeight = 130,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 5131, Gain = 1027},
		{Value = 200002, Base = 45, Gain = 9},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "不稳定态：每3回合将自身元素变为随机元素\n能量冲击：每3回合对前3个队员造成150%攻击伤害\n力量解放：5回合后，攻击 +50%\n超能觉醒：降低75%等级减少效果",
		Skill = {
			{
				Id = 105163,
				Value = -1,
			},
			{
				Id = 105057,
				Value = 150,
			},
			{
				Id = 105014,
				Value = 50,
			},
			{
				Id = 105173,
				Value = 75,
			},
		},
	},
	Tags = {
		560111,
		564555,
		564561,
		564564,
	},
}
EnemyConfig[EnemyID.Id6507] =
{
	Id = 6507,
	Name = "飙车王",
	Rarity = 5,
	Element = 210003,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "任何载具都能驾驭自如的星际飙车王，从独轮车到摩托车、小型飞机、快艇、星河战舰，只要是能驾驶的都能飙。不过喜欢风驰电掣的同时，飙车王也十分注意安全防护。",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	IconName = "Arena_Pir_RacingDriver",
	PrefabBundle = "character_boss",
	PrefabName = "Pir_03_RacingDriver",
	SkinName = "1_cat",
	PrefabScale = 50,
	HPBarHeight = 125,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1",
		},
		CritAttackAnim = "Attack_2",
		BattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_3",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 3032, Gain = 607},
		{Value = 200002, Base = 14, Gain = 3},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "危险驾驶：每5回合对所有队员造成75%攻击伤害\n紧急回避：每3回合，100%概率闪避攻击\n动力引擎：每2回合攻击 +60%，最多5次",
		Skill = {
			{
				Id = 105071,
				Value = 75,
			},
			{
				Id = 105140,
				Value = 100,
			},
			{
				Id = 105178,
				Value = 60,
			},
		},
	},
	Tags = {
		560111,
		564555,
		564557,
		564561,
	},
}
EnemyConfig[EnemyID.Id6508] =
{
	Id = 6508,
	Name = "冠军飙车王",
	Rarity = 5,
	Element = 210003,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "任何载具都能驾驭自如的星际飙车王，从独轮车到摩托车、小型飞机、快艇、星河战舰，只要是能驾驶的都能飙。不过喜欢风驰电掣的同时，飙车王也十分注意安全防护。",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	IconName = "Arena_Pir_RacingDriver",
	PrefabBundle = "character_boss",
	PrefabName = "Pir_03_RacingDriver",
	SkinName = "1_cat",
	PrefabScale = 50,
	HPBarHeight = 125,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1",
		},
		CritAttackAnim = "Attack_2",
		BattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_3",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 4169, Gain = 834},
		{Value = 200002, Base = 14, Gain = 3},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "危险驾驶：每3回合对前4个队员造成75%攻击伤害\n紧急回避：每3回合，100%概率闪避攻击\n核能引擎：每2回合攻击 +75%，最多5次",
		Skill = {
			{
				Id = 105058,
				Value = 75,
			},
			{
				Id = 105140,
				Value = 100,
			},
			{
				Id = 105178,
				Value = 75,
			},
		},
	},
	Tags = {
		560111,
		564555,
		564557,
		564561,
	},
}
EnemyConfig[EnemyID.Id6509] =
{
	Id = 6509,
	Name = "王牌Ace",
	Rarity = 5,
	Element = 210003,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "任何载具都能驾驭自如的星际飙车王，从独轮车到摩托车、小型飞机、快艇、星河战舰，只要是能驾驶的都能飙。不过喜欢风驰电掣的同时，飙车王也十分注意安全防护。",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	IconName = "Arena_Pir_RacingDriver",
	PrefabBundle = "character_boss",
	PrefabName = "Pir_03_RacingDriver",
	SkinName = "1_cat",
	PrefabScale = 50,
	HPBarHeight = 125,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1",
		},
		CritAttackAnim = "Attack_2",
		BattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_3",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 5131, Gain = 1027},
		{Value = 200002, Base = 15, Gain = 3},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "恐怖驾驶：每3回合对前4个队员造成75%攻击伤害\n条件反射：每3回合，100%概率闪避攻击\n黑洞引擎：每回合攻击 +60%，最多5次\n体育精神：降低75%等级减少效果",
		Skill = {
			{
				Id = 105058,
				Value = 75,
			},
			{
				Id = 105140,
				Value = 100,
			},
			{
				Id = 105006,
				Value = 60,
			},
			{
				Id = 105173,
				Value = 75,
			},
		},
	},
	Tags = {
		560111,
		564555,
		564557,
		564561,
		564564,
	},
}
EnemyConfig[EnemyID.Id6510] =
{
	Id = 6510,
	Name = "百变怪人",
	Rarity = 5,
	Element = 210005,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "来自遥远星球的百变怪人。因马戏团长克扣工资而出逃，凭借变形能力加入了某集团。据说，百变怪人不仅善于伪装，Ta的爆炸物制造能力也非比寻常。如果收到Ta的礼物，千万不要打开！",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	IconName = "Arena_Pir_ChangeableMan",
	PrefabBundle = "character_boss",
	PrefabName = "Pir_04_ChangeableMan",
	SkinName = "1_cat",
	PrefabScale = 50,
	HPBarHeight = 125,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 3032, Gain = 607},
		{Value = 200002, Base = 42, Gain = 9},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "节日惊喜：每3回合对前2个队员造成150%攻击伤害\n百变怪形：每回合将自身元素变为随机元素\n魔术手：每2回合，本回合100%概率额外攻击1次",
		Skill = {
			{
				Id = 105056,
				Value = 150,
			},
			{
				Id = 105162,
				Value = -1,
			},
			{
				Id = 105131,
				Value = 100,
			},
		},
	},
	Tags = {
		560111,
		564555,
		564558,
	},
}
EnemyConfig[EnemyID.Id6511] =
{
	Id = 6511,
	Name = "百变怪人",
	Rarity = 5,
	Element = 210005,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "来自遥远星球的百变怪人。因马戏团长克扣工资而出逃，凭借变形能力加入了某集团。据说，百变怪人不仅善于伪装，Ta的爆炸物制造能力也非比寻常。如果收到Ta的礼物，千万不要打开！",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	IconName = "Arena_Pir_ChangeableMan",
	PrefabBundle = "character_boss",
	PrefabName = "Pir_04_ChangeableMan",
	SkinName = "1_cat",
	PrefabScale = 50,
	HPBarHeight = 125,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 4169, Gain = 834},
		{Value = 200002, Base = 43, Gain = 9},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "节日惊喜：每3回合对前2个队员造成150%攻击伤害\n百变怪形：每回合将自身元素变为随机元素\n魔术手：每2回合，本回合100%概率额外攻击1次",
		Skill = {
			{
				Id = 105056,
				Value = 150,
			},
			{
				Id = 105162,
				Value = -1,
			},
			{
				Id = 105131,
				Value = 100,
			},
		},
	},
	Tags = {
		560111,
		564555,
		564558,
	},
}
EnemyConfig[EnemyID.Id6512] =
{
	Id = 6512,
	Name = "百变怪杰",
	Rarity = 5,
	Element = 210005,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "来自遥远星球的百变怪人。因马戏团长克扣工资而出逃，凭借变形能力加入了某集团。据说，百变怪人不仅善于伪装，Ta的爆炸物制造能力也非比寻常。如果收到Ta的礼物，千万不要打开！",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	IconName = "Arena_Pir_ChangeableMan",
	PrefabBundle = "character_boss",
	PrefabName = "Pir_04_ChangeableMan",
	SkinName = "1_cat",
	PrefabScale = 50,
	HPBarHeight = 125,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 5131, Gain = 1027},
		{Value = 200002, Base = 45, Gain = 9},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "节日惊喜：每3回合对前2个队员造成100%攻击伤害\n百变怪形：每回合将自身元素变为随机元素\n魔术手：每2回合，本回合100%概率额外攻击1次\n虚实交替：受到的暴击伤害 -33%",
		Skill = {
			{
				Id = 105056,
				Value = 100,
			},
			{
				Id = 105162,
				Value = -1,
			},
			{
				Id = 105131,
				Value = 100,
			},
			{
				Id = 105039,
				Value = -33,
			},
		},
	},
	Tags = {
		560111,
		564555,
		564558,
	},
}
EnemyConfig[EnemyID.Id6513] =
{
	Id = 6513,
	Name = "超能铁匠",
	Rarity = 5,
	Element = 210004,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "醉心于打造顶级装备的匠人，为了寻求极致的锻造术而潜入流亡街。身体大部分都替换成了机械物，能随意自如地控制这些机械义肢。他为不少星际名人定制过强力装备，其本人则使用铁锤作为武器。",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	IconName = "Arena_Pir_SuperBlacksmith",
	PrefabBundle = "character_boss",
	PrefabName = "Pir_05_SuperBlacksmith",
	SkinName = "1_cat",
	PrefabScale = 50,
	HPBarHeight = 125,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1",
		},
		CritAttackAnim = "Attack_2",
		BattleEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_3",
		RangeAttackEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 3032, Gain = 607},
		{Value = 200002, Base = 42, Gain = 9},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "强化武器：每3回合攻击 +40%，最多3次\n强化防具：每3回合忍耐 +80，最多3次\n熔能震击：每3回合对所有队员造成100%攻击伤害",
		Skill = {
			{
				Id = 105010,
				Value = 40,
			},
			{
				Id = 105011,
				Value = 80,
			},
			{
				Id = 105063,
				Value = 100,
			},
		},
	},
	Tags = {
		560111,
		564555,
		564561,
	},
}
EnemyConfig[EnemyID.Id6514] =
{
	Id = 6514,
	Name = "超能铁匠",
	Rarity = 5,
	Element = 210004,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "醉心于打造顶级装备的匠人，为了寻求极致的锻造术而潜入流亡街。身体大部分都替换成了机械物，能随意自如地控制这些机械义肢。他为不少星际名人定制过强力装备，其本人则使用铁锤作为武器。",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	IconName = "Arena_Pir_SuperBlacksmith",
	PrefabBundle = "character_boss",
	PrefabName = "Pir_05_SuperBlacksmith",
	SkinName = "1_cat",
	PrefabScale = 50,
	HPBarHeight = 125,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1",
		},
		CritAttackAnim = "Attack_2",
		BattleEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_3",
		RangeAttackEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 4169, Gain = 834},
		{Value = 200002, Base = 43, Gain = 9},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "强化武器：每3回合攻击 +40%，最多3次\n强化防具：每3回合忍耐 +80，最多3次\n熔能震击：每3回合对所有队员造成100%攻击伤害",
		Skill = {
			{
				Id = 105010,
				Value = 40,
			},
			{
				Id = 105011,
				Value = 80,
			},
			{
				Id = 105063,
				Value = 100,
			},
		},
	},
	Tags = {
		560111,
		564555,
		564561,
	},
}
EnemyConfig[EnemyID.Id6515] =
{
	Id = 6515,
	Name = "超能铁匠",
	Rarity = 5,
	Element = 210004,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "醉心于打造顶级装备的匠人，为了寻求极致的锻造术而潜入流亡街。身体大部分都替换成了机械物，能随意自如地控制这些机械义肢。他为不少星际名人定制过强力装备，其本人则使用铁锤作为武器。",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	IconName = "Arena_Pir_SuperBlacksmith",
	PrefabBundle = "character_boss",
	PrefabName = "Pir_05_SuperBlacksmith",
	SkinName = "1_cat",
	PrefabScale = 50,
	HPBarHeight = 125,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1",
		},
		CritAttackAnim = "Attack_2",
		BattleEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_3",
		RangeAttackEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 5131, Gain = 1027},
		{Value = 200002, Base = 45, Gain = 9},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "强化武器：每3回合攻击 +40%，最多3次\n强化防具：每3回合忍耐 +80，最多3次\n熔能震击：每3回合对所有队员造成100%攻击伤害",
		Skill = {
			{
				Id = 105010,
				Value = 40,
			},
			{
				Id = 105011,
				Value = 80,
			},
			{
				Id = 105063,
				Value = 100,
			},
		},
	},
	Tags = {
		560111,
		564555,
		564561,
	},
}
EnemyConfig[EnemyID.Id6516] =
{
	Id = 6516,
	Name = "波罗",
	Rarity = 5,
	Element = 210005,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "痴迷侦探小说的邪恶模仿者，本身也是著名侦探，在一次与正牌波罗的推理比赛中彻底败北，从此一面羡慕着波罗的一切，一面又对他恨之入骨，最终潜入流亡街，成为了真正的犯罪分子。",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	IconName = "Arena_Pir_DarkPolo",
	PrefabBundle = "character_boss",
	PrefabName = "Pir_06_DarkPolo",
	SkinName = "1_cat",
	PrefabScale = 50,
	HPBarHeight = 125,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1",
		},
		CritAttackAnim = "Attack_2",
		BattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_3",
		RangeAttackEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 3032, Gain = 607},
		{Value = 200002, Base = 42, Gain = 9},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "阴险射击：每3回合对后2个队员造成80%攻击伤害\n推理时间：每5回合，本回合暴率 +100%\n刻薄推论：暴击伤害 +150%",
		Skill = {
			{
				Id = 105060,
				Value = 80,
			},
			{
				Id = 105142,
				Value = 100,
			},
			{
				Id = 105038,
				Value = 150,
			},
		},
	},
	Tags = {
		560111,
		564555,
	},
}
EnemyConfig[EnemyID.Id6517] =
{
	Id = 6517,
	Name = "波罗",
	Rarity = 5,
	Element = 210005,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "痴迷侦探小说的邪恶模仿者，本身也是著名侦探，在一次与正牌波罗的推理比赛中彻底败北，从此一面羡慕着波罗的一切，一面又对他恨之入骨，最终潜入流亡街，成为了真正的犯罪分子。",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	IconName = "Arena_Pir_DarkPolo",
	PrefabBundle = "character_boss",
	PrefabName = "Pir_06_DarkPolo",
	SkinName = "1_cat",
	PrefabScale = 50,
	HPBarHeight = 125,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1",
		},
		CritAttackAnim = "Attack_2",
		BattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_3",
		RangeAttackEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 4169, Gain = 834},
		{Value = 200002, Base = 43, Gain = 9},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "阴险射击：每3回合对后2个队员造成80%攻击伤害\n推理时间：每5回合，本回合暴率 +100%\n刻薄推论：暴击伤害 +150%",
		Skill = {
			{
				Id = 105060,
				Value = 80,
			},
			{
				Id = 105142,
				Value = 100,
			},
			{
				Id = 105038,
				Value = 150,
			},
		},
	},
	Tags = {
		560111,
		564555,
	},
}
EnemyConfig[EnemyID.Id6518] =
{
	Id = 6518,
	Name = "波罗",
	Rarity = 5,
	Element = 210005,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "痴迷侦探小说的邪恶模仿者，本身也是著名侦探，在一次与正牌波罗的推理比赛中彻底败北，从此一面羡慕着波罗的一切，一面又对他恨之入骨，最终潜入流亡街，成为了真正的犯罪分子。",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	IconName = "Arena_Pir_DarkPolo",
	PrefabBundle = "character_boss",
	PrefabName = "Pir_06_DarkPolo",
	SkinName = "1_cat",
	PrefabScale = 50,
	HPBarHeight = 125,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1",
		},
		CritAttackAnim = "Attack_2",
		BattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_3",
		RangeAttackEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 5131, Gain = 1027},
		{Value = 200002, Base = 45, Gain = 9},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "阴险射击：每3回合对后2个队员造成80%攻击伤害\n推理时间：每5回合，本回合暴率 +100%\n刻薄推论：暴击伤害 +150%",
		Skill = {
			{
				Id = 105060,
				Value = 80,
			},
			{
				Id = 105142,
				Value = 100,
			},
			{
				Id = 105038,
				Value = 150,
			},
		},
	},
	Tags = {
		560111,
		564555,
	},
}
EnemyConfig[EnemyID.Id6519] =
{
	Id = 6519,
	Name = "鲨鱼老大",
	Rarity = 5,
	Element = 210001,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "海洋中的霸主，被猎鲸者无意间捕获后卖给了大海贼团。在即将被制成刺身时依然疯狂反抗着，最终其精神折服了所有海盗，于是被改造成了超强战士，能够在陆地行走，同时还能用嘴巴咬人。",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	IconName = "Arena_Pir_SharkBoss",
	PrefabBundle = "character_boss",
	PrefabName = "Pir_07_SharkBoss",
	SkinName = "1_cat",
	PrefabScale = 50,
	HPBarHeight = 125,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1",
		},
		CritAttackAnim = "Attack_2",
		BattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_3",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 3032, Gain = 607},
		{Value = 200002, Base = 42, Gain = 9},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "卷浪锚击:每3回合对前2个队员造成100%攻击伤害\n狂怒：回合中，每次受击，攻击 +5%\n嗜血：每3回合，有33%概率回血自身攻击120%的生命值\n深海霸主：受暗元素敌人伤害 -75%",
		Skill = {
			{
				Id = 105056,
				Value = 100,
			},
			{
				Id = 105170,
				Value = 5,
			},
			{
				Id = 105166,
				Value = 120,
			},
			{
				Id = 105037,
				Value = -75,
			},
		},
	},
	Tags = {
		560111,
		564555,
		564560,
		564561,
	},
}
EnemyConfig[EnemyID.Id6520] =
{
	Id = 6520,
	Name = "鲨鱼老大",
	Rarity = 5,
	Element = 210001,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "海洋中的霸主，被猎鲸者无意间捕获后卖给了大海贼团。在即将被制成刺身时依然疯狂反抗着，最终其精神折服了所有海盗，于是被改造成了超强战士，能够在陆地行走，同时还能用嘴巴咬人。",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	IconName = "Arena_Pir_SharkBoss",
	PrefabBundle = "character_boss",
	PrefabName = "Pir_07_SharkBoss",
	SkinName = "1_cat",
	PrefabScale = 50,
	HPBarHeight = 125,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1",
		},
		CritAttackAnim = "Attack_2",
		BattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_3",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 4169, Gain = 834},
		{Value = 200002, Base = 43, Gain = 9},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "卷浪锚击:每3回合对前2个队员造成100%攻击伤害\n狂怒：回合中，每次受击，攻击 +5%\n嗜血：每3回合，有33%概率回血自身攻击120%的生命值\n深海霸主：受暗元素敌人伤害 -75%",
		Skill = {
			{
				Id = 105056,
				Value = 100,
			},
			{
				Id = 105170,
				Value = 5,
			},
			{
				Id = 105166,
				Value = 120,
			},
			{
				Id = 105037,
				Value = -75,
			},
		},
	},
	Tags = {
		560111,
		564555,
		564560,
		564561,
	},
}
EnemyConfig[EnemyID.Id6521] =
{
	Id = 6521,
	Name = "鲨鱼老大",
	Rarity = 5,
	Element = 210001,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "海洋中的霸主，被猎鲸者无意间捕获后卖给了大海贼团。在即将被制成刺身时依然疯狂反抗着，最终其精神折服了所有海盗，于是被改造成了超强战士，能够在陆地行走，同时还能用嘴巴咬人。",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	IconName = "Arena_Pir_SharkBoss",
	PrefabBundle = "character_boss",
	PrefabName = "Pir_07_SharkBoss",
	SkinName = "1_cat",
	PrefabScale = 50,
	HPBarHeight = 125,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1",
		},
		CritAttackAnim = "Attack_2",
		BattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_3",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 5131, Gain = 1027},
		{Value = 200002, Base = 45, Gain = 9},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "狂暴之海:每3回合对前3个队员造成200%攻击伤害\n深海狂怒：回合中，每次受击，攻击 +6%\n嗜血：每3回合，有33%概率回血自身攻击120%的生命值\n深海霸主：受暗元素敌人伤害 -75%",
		Skill = {
			{
				Id = 105057,
				Value = 200,
			},
			{
				Id = 105170,
				Value = 6,
			},
			{
				Id = 105166,
				Value = 120,
			},
			{
				Id = 105037,
				Value = -75,
			},
		},
	},
	Tags = {
		560111,
		564555,
		564560,
		564561,
	},
}
EnemyConfig[EnemyID.Id6522] =
{
	Id = 6522,
	Name = "罗曼船长",
	Rarity = 5,
	Element = 210003,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "海洋偶像星历史上最臭名昭著的罪犯。罗曼船长驾驶着他那艘罪恶的捕鱼船，到处追猎美丽的海洋生物，并且大规模使用鱼炮炸鱼，破坏海洋平衡。在被联邦追捕过程中，左腿残疾，因此他发誓要报复联邦！",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	IconName = "Arena_Pir_CaptainRoamn",
	PrefabBundle = "character_boss",
	PrefabName = "Pir_08_CaptainRoamn",
	SkinName = "1_cat",
	PrefabScale = 50,
	HPBarHeight = 125,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_2",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 3032, Gain = 607},
		{Value = 200002, Base = 42, Gain = 9},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "破浪之风：每3回合对前2个队员造成150%攻击伤害\n音速斩：每2回合，本回合50%概率额外攻击1次\n穿肋刺击：暴击 +80",
		Skill = {
			{
				Id = 105056,
				Value = 150,
			},
			{
				Id = 105131,
				Value = 50,
			},
			{
				Id = 105004,
				Value = 80,
			},
		},
	},
	Tags = {
		560111,
		564555,
		564558,
		564561,
	},
}
EnemyConfig[EnemyID.Id6523] =
{
	Id = 6523,
	Name = "罗曼船长",
	Rarity = 5,
	Element = 210003,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "海洋偶像星历史上最臭名昭著的罪犯。罗曼船长驾驶着他那艘罪恶的捕鱼船，到处追猎美丽的海洋生物，并且大规模使用鱼炮炸鱼，破坏海洋平衡。在被联邦追捕过程中，左腿残疾，因此他发誓要报复联邦！",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	IconName = "Arena_Pir_CaptainRoamn",
	PrefabBundle = "character_boss",
	PrefabName = "Pir_08_CaptainRoamn",
	SkinName = "1_cat",
	PrefabScale = 50,
	HPBarHeight = 125,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_2",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 4169, Gain = 834},
		{Value = 200002, Base = 43, Gain = 9},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "破浪之风：每3回合对前2个队员造成150%攻击伤害\n音速斩：每2回合，本回合50%概率额外攻击1次\n穿肋刺击：暴击 +80",
		Skill = {
			{
				Id = 105056,
				Value = 150,
			},
			{
				Id = 105131,
				Value = 50,
			},
			{
				Id = 105004,
				Value = 80,
			},
		},
	},
	Tags = {
		560111,
		564555,
		564558,
		564561,
	},
}
EnemyConfig[EnemyID.Id6524] =
{
	Id = 6524,
	Name = "罗曼船长",
	Rarity = 5,
	Element = 210003,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "海洋偶像星历史上最臭名昭著的罪犯。罗曼船长驾驶着他那艘罪恶的捕鱼船，到处追猎美丽的海洋生物，并且大规模使用鱼炮炸鱼，破坏海洋平衡。在被联邦追捕过程中，左腿残疾，因此他发誓要报复联邦！",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	IconName = "Arena_Pir_CaptainRoamn",
	PrefabBundle = "character_boss",
	PrefabName = "Pir_08_CaptainRoamn",
	SkinName = "1_cat",
	PrefabScale = 50,
	HPBarHeight = 125,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_2",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 5131, Gain = 1027},
		{Value = 200002, Base = 45, Gain = 9},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "破浪之风：每3回合对前2个队员造成150%攻击伤害\n音速斩：每2回合，本回合50%概率额外攻击1次\n穿肋刺击：暴击 +80",
		Skill = {
			{
				Id = 105056,
				Value = 150,
			},
			{
				Id = 105131,
				Value = 50,
			},
			{
				Id = 105004,
				Value = 80,
			},
		},
	},
	Tags = {
		560111,
		564555,
		564558,
		564561,
	},
}
EnemyConfig[EnemyID.Id6525] =
{
	Id = 6525,
	Name = "“伯爵”",
	Rarity = 5,
	Element = 210005,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "代号“伯爵”的犯罪分子，相传出身自高贵的家族。因为追求极致的艺术品，“伯爵”变得越来越孤僻。他终日远离人群，独自钻研着赋予艺术品生命的方法。似乎，他还在研究着石化技术，可以将活物直接变为艺术品。",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	IconName = "Arena_Pir_DarkCount",
	PrefabBundle = "character_boss",
	PrefabName = "Pir_09_DarkCount",
	SkinName = "1_cat",
	PrefabScale = 50,
	HPBarHeight = 125,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1",
		},
		CritAttackAnim = "Attack_2",
		BattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_3",
		RangeAttackEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 3032, Gain = 607},
		{Value = 200002, Base = 42, Gain = 9},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "掠阵血蝠：每回合，降低敌人80%攻击增强效果\n活力仪式：每2回合，回血自身攻击600%的生命值\n青春永驻：每回合忍耐 +60，最多5次",
		Skill = {
			{
				Id = 105188,
				Value = 80,
			},
			{
				Id = 105019,
				Value = 600,
			},
			{
				Id = 105007,
				Value = 60,
			},
		},
	},
	Tags = {
		560111,
		564555,
		564560,
		564561,
		564564,
	},
}
EnemyConfig[EnemyID.Id6526] =
{
	Id = 6526,
	Name = "“伯爵”",
	Rarity = 5,
	Element = 210005,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "代号“伯爵”的犯罪分子，相传出身自高贵的家族。因为追求极致的艺术品，“伯爵”变得越来越孤僻。他终日远离人群，独自钻研着赋予艺术品生命的方法。似乎，他还在研究着石化技术，可以将活物直接变为艺术品。",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	IconName = "Arena_Pir_DarkCount",
	PrefabBundle = "character_boss",
	PrefabName = "Pir_09_DarkCount",
	SkinName = "1_cat",
	PrefabScale = 50,
	HPBarHeight = 125,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1",
		},
		CritAttackAnim = "Attack_2",
		BattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_3",
		RangeAttackEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 4169, Gain = 834},
		{Value = 200002, Base = 43, Gain = 9},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "掠阵血蝠：每回合，降低敌人80%攻击增强效果\n活力仪式：每2回合，回血自身攻击600%的生命值\n青春永驻：每回合忍耐 +60，最多5次",
		Skill = {
			{
				Id = 105188,
				Value = 80,
			},
			{
				Id = 105019,
				Value = 600,
			},
			{
				Id = 105007,
				Value = 60,
			},
		},
	},
	Tags = {
		560111,
		564555,
		564560,
		564561,
		564564,
	},
}
EnemyConfig[EnemyID.Id6527] =
{
	Id = 6527,
	Name = "“伯爵”",
	Rarity = 5,
	Element = 210005,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "代号“伯爵”的犯罪分子，相传出身自高贵的家族。因为追求极致的艺术品，“伯爵”变得越来越孤僻。他终日远离人群，独自钻研着赋予艺术品生命的方法。似乎，他还在研究着石化技术，可以将活物直接变为艺术品。",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	IconName = "Arena_Pir_DarkCount",
	PrefabBundle = "character_boss",
	PrefabName = "Pir_09_DarkCount",
	SkinName = "1_cat",
	PrefabScale = 50,
	HPBarHeight = 125,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1",
		},
		CritAttackAnim = "Attack_2",
		BattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_3",
		RangeAttackEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 5131, Gain = 1027},
		{Value = 200002, Base = 45, Gain = 9},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "掠阵血蝠：每回合，降低敌人80%攻击增强效果\n活力仪式：每2回合，回血自身攻击600%的生命值\n青春永驻：每回合忍耐 +60，最多5次",
		Skill = {
			{
				Id = 105188,
				Value = 80,
			},
			{
				Id = 105019,
				Value = 600,
			},
			{
				Id = 105007,
				Value = 60,
			},
		},
	},
	Tags = {
		560111,
		564555,
		564560,
		564561,
		564564,
	},
}
EnemyConfig[EnemyID.Id6528] =
{
	Id = 6528,
	Name = "“博士”",
	Rarity = 5,
	Element = 210003,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "代号“博士”的前高星实验室负责人之一，博士多数时间在实验室工作，创造威力强大的发明，或者组织新型的研究。当某地区发生异常现象时，他偶尔也会亲自到访。",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	IconName = "Arena_Pir_DarkDoctor",
	PrefabBundle = "character_boss",
	PrefabName = "Pir_10_DarkDoctor",
	SkinName = "1_cat",
	PrefabScale = 50,
	HPBarHeight = 125,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1",
		},
		CritAttackAnim = "Attack_2",
		BattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_3",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 3032, Gain = 607},
		{Value = 200002, Base = 42, Gain = 9},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "激光校准：80%概率无视敌人闪避\n瓦解射线：每3回合对前3个队员造成80%攻击伤害\n爆发：5回合后，攻击 +100%",
		Skill = {
			{
				Id = 105027,
				Value = 80,
			},
			{
				Id = 105057,
				Value = 80,
			},
			{
				Id = 105014,
				Value = 100,
			},
		},
	},
	Tags = {
		560111,
		564555,
		564559,
		564561,
	},
}
EnemyConfig[EnemyID.Id6529] =
{
	Id = 6529,
	Name = "“博士”",
	Rarity = 5,
	Element = 210003,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "代号“博士”的前高星实验室负责人之一，博士多数时间在实验室工作，创造威力强大的发明，或者组织新型的研究。当某地区发生异常现象时，他偶尔也会亲自到访。",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	IconName = "Arena_Pir_DarkDoctor",
	PrefabBundle = "character_boss",
	PrefabName = "Pir_10_DarkDoctor",
	SkinName = "1_cat",
	PrefabScale = 50,
	HPBarHeight = 125,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1",
		},
		CritAttackAnim = "Attack_2",
		BattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_3",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 4169, Gain = 834},
		{Value = 200002, Base = 43, Gain = 9},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "激光校准：80%概率无视敌人闪避\n瓦解射线：每3回合对前3个队员造成80%攻击伤害\n爆发：5回合后，攻击 +100%",
		Skill = {
			{
				Id = 105027,
				Value = 80,
			},
			{
				Id = 105057,
				Value = 80,
			},
			{
				Id = 105014,
				Value = 100,
			},
		},
	},
	Tags = {
		560111,
		564555,
		564559,
		564561,
	},
}
EnemyConfig[EnemyID.Id6530] =
{
	Id = 6530,
	Name = "“博士”",
	Rarity = 5,
	Element = 210003,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "代号“博士”的前高星实验室负责人之一，博士多数时间在实验室工作，创造威力强大的发明，或者组织新型的研究。当某地区发生异常现象时，他偶尔也会亲自到访。",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	IconName = "Arena_Pir_DarkDoctor",
	PrefabBundle = "character_boss",
	PrefabName = "Pir_10_DarkDoctor",
	SkinName = "1_cat",
	PrefabScale = 50,
	HPBarHeight = 125,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1",
		},
		CritAttackAnim = "Attack_2",
		BattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_3",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 5131, Gain = 1027},
		{Value = 200002, Base = 45, Gain = 9},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "激光校准：80%概率无视敌人闪避\n瓦解射线：每3回合对前3个队员造成80%攻击伤害\n爆发：5回合后，攻击 +100%",
		Skill = {
			{
				Id = 105027,
				Value = 80,
			},
			{
				Id = 105057,
				Value = 80,
			},
			{
				Id = 105014,
				Value = 100,
			},
		},
	},
	Tags = {
		560111,
		564555,
		564559,
		564561,
	},
}
EnemyConfig[EnemyID.Id6531] =
{
	Id = 6531,
	Name = "黑客剑士",
	Rarity = 5,
	Element = 210002,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "冒险星的二代勇者，因服务器数据错乱，导致能力倍增，并打算获取冒险星的统治权。在被闻名宇宙的大海贼团团长击败后，认识到了更可怕的力量，于是隐匿踪迹继续修行。",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	IconName = "Arena_Pir_HackerSwordsman",
	PrefabBundle = "character_boss",
	PrefabName = "Pir_11_HackerSwordsman",
	SkinName = "1_cat",
	PrefabScale = 50,
	HPBarHeight = 125,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1",
		},
		CritAttackAnim = "Attack_2",
		BattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_3",
		RangeAttackEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 3032, Gain = 607},
		{Value = 200002, Base = 42, Gain = 9},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "身体改造：每3回合，回血自身攻击9%的生命值\n肌肉强化：每3回合忍耐 +80，最多3次\n红外扫描：100%概率无视敌人闪避\n大地焚毁：每3回合对所有队员造成50%攻击伤害",
		Skill = {
			{
				Id = 105020,
				Value = 9,
			},
			{
				Id = 105011,
				Value = 80,
			},
			{
				Id = 105027,
				Value = 100,
			},
			{
				Id = 105063,
				Value = 50,
			},
		},
	},
	Tags = {
		560111,
		564555,
		564559,
		564560,
		564561,
	},
}
EnemyConfig[EnemyID.Id6532] =
{
	Id = 6532,
	Name = "黑客剑士",
	Rarity = 5,
	Element = 210002,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "冒险星的二代勇者，因服务器数据错乱，导致能力倍增，并打算获取冒险星的统治权。在被闻名宇宙的大海贼团团长击败后，认识到了更可怕的力量，于是隐匿踪迹继续修行。",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	IconName = "Arena_Pir_HackerSwordsman",
	PrefabBundle = "character_boss",
	PrefabName = "Pir_11_HackerSwordsman",
	SkinName = "1_cat",
	PrefabScale = 50,
	HPBarHeight = 125,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1",
		},
		CritAttackAnim = "Attack_2",
		BattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_3",
		RangeAttackEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 4169, Gain = 834},
		{Value = 200002, Base = 43, Gain = 9},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "身体改造：每3回合，回血自身攻击9%的生命值\n肌肉强化：每3回合忍耐 +80，最多3次\n红外扫描：100%概率无视敌人闪避\n大地焚毁：每3回合对所有队员造成50%攻击伤害",
		Skill = {
			{
				Id = 105020,
				Value = 9,
			},
			{
				Id = 105011,
				Value = 80,
			},
			{
				Id = 105027,
				Value = 100,
			},
			{
				Id = 105063,
				Value = 50,
			},
		},
	},
	Tags = {
		560111,
		564555,
		564559,
		564560,
		564561,
	},
}
EnemyConfig[EnemyID.Id6533] =
{
	Id = 6533,
	Name = "黑客剑士",
	Rarity = 5,
	Element = 210002,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "冒险星的二代勇者，因服务器数据错乱，导致能力倍增，并打算获取冒险星的统治权。在被闻名宇宙的大海贼团团长击败后，认识到了更可怕的力量，于是隐匿踪迹继续修行。",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	IconName = "Arena_Pir_HackerSwordsman",
	PrefabBundle = "character_boss",
	PrefabName = "Pir_11_HackerSwordsman",
	SkinName = "1_cat",
	PrefabScale = 50,
	HPBarHeight = 125,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1",
		},
		CritAttackAnim = "Attack_2",
		BattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_3",
		RangeAttackEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 5131, Gain = 1027},
		{Value = 200002, Base = 45, Gain = 9},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "身体改造：每3回合，回血自身攻击9%的生命值\n肌肉强化：每3回合忍耐 +80，最多3次\n红外扫描：100%概率无视敌人闪避\n大地焚毁：每3回合对所有队员造成50%攻击伤害",
		Skill = {
			{
				Id = 105020,
				Value = 9,
			},
			{
				Id = 105011,
				Value = 80,
			},
			{
				Id = 105027,
				Value = 100,
			},
			{
				Id = 105063,
				Value = 50,
			},
		},
	},
	Tags = {
		560111,
		564555,
		564559,
		564560,
		564561,
	},
}
EnemyConfig[EnemyID.Id6534] =
{
	Id = 6534,
	Name = "苍青驱魔师",
	Rarity = 5,
	Element = 210001,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "被认为是百年一见的驱魔天才。身体中有一半妖怪血统，因此能看穿普通妖怪的心事，听说读写妖怪文，还能辨别妖怪的气息。因行为偏差被流放到流亡街。他封印妖怪不为任何人，只为完成自己的图鉴大全。",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	IconName = "Arena_Pir_PaleBlueExorcist",
	PrefabBundle = "character_boss",
	PrefabName = "Pir_12_PaleBlueExorcist",
	SkinName = "1_cat",
	PrefabScale = 50,
	HPBarHeight = 125,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1",
		},
		CritAttackAnim = "Attack_2",
		BattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_3",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 3032, Gain = 607},
		{Value = 200002, Base = 42, Gain = 9},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "防暴结阵：受到的暴击伤害 -100%\n青狐避走：每3回合，80%概率闪避攻击\n四方结阵：每3回合对前4个队员造成80%攻击伤害",
		Skill = {
			{
				Id = 105039,
				Value = -100,
			},
			{
				Id = 105140,
				Value = 80,
			},
			{
				Id = 105058,
				Value = 80,
			},
		},
	},
	Tags = {
		560111,
		564555,
		564557,
	},
}
EnemyConfig[EnemyID.Id6535] =
{
	Id = 6535,
	Name = "苍青驱魔师",
	Rarity = 5,
	Element = 210001,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "被认为是百年一见的驱魔天才。身体中有一半妖怪血统，因此能看穿普通妖怪的心事，听说读写妖怪文，还能辨别妖怪的气息。因行为偏差被流放到流亡街。他封印妖怪不为任何人，只为完成自己的图鉴大全。",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	IconName = "Arena_Pir_PaleBlueExorcist",
	PrefabBundle = "character_boss",
	PrefabName = "Pir_12_PaleBlueExorcist",
	SkinName = "1_cat",
	PrefabScale = 50,
	HPBarHeight = 125,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1",
		},
		CritAttackAnim = "Attack_2",
		BattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_3",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 4169, Gain = 834},
		{Value = 200002, Base = 43, Gain = 9},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "防暴结阵：受到的暴击伤害 -100%\n青狐避走：每3回合，80%概率闪避攻击\n四方结阵：每3回合对前4个队员造成80%攻击伤害",
		Skill = {
			{
				Id = 105039,
				Value = -100,
			},
			{
				Id = 105140,
				Value = 80,
			},
			{
				Id = 105058,
				Value = 80,
			},
		},
	},
	Tags = {
		560111,
		564555,
		564557,
	},
}
EnemyConfig[EnemyID.Id6536] =
{
	Id = 6536,
	Name = "苍青驱魔师",
	Rarity = 5,
	Element = 210001,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "被认为是百年一见的驱魔天才。身体中有一半妖怪血统，因此能看穿普通妖怪的心事，听说读写妖怪文，还能辨别妖怪的气息。因行为偏差被流放到流亡街。他封印妖怪不为任何人，只为完成自己的图鉴大全。",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	IconName = "Arena_Pir_PaleBlueExorcist",
	PrefabBundle = "character_boss",
	PrefabName = "Pir_12_PaleBlueExorcist",
	SkinName = "1_cat",
	PrefabScale = 50,
	HPBarHeight = 125,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1",
		},
		CritAttackAnim = "Attack_2",
		BattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_3",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 5131, Gain = 1027},
		{Value = 200002, Base = 45, Gain = 9},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "防暴结阵：受到的暴击伤害 -100%\n青狐避走：每3回合，80%概率闪避攻击\n四方结阵：每3回合对前4个队员造成80%攻击伤害",
		Skill = {
			{
				Id = 105039,
				Value = -100,
			},
			{
				Id = 105140,
				Value = 80,
			},
			{
				Id = 105058,
				Value = 80,
			},
		},
	},
	Tags = {
		560111,
		564555,
		564557,
	},
}
EnemyConfig[EnemyID.Id6537] =
{
	Id = 6537,
	Name = "夕大人",
	Rarity = 5,
	Element = 210005,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "每年都会准时去各大星球作乱的怪兽。虽然每次都全副武装，但最后总会被击败，然后被绑着看烟花大会，吃年夜饭，最后发完压岁钱才能放回来。",
	IconBundle = "atlas_activity_1",
	IconAtlas = "ActivityCharacterIcon",
	IconName = "All_NewYearBeast_cos10",
	PrefabBundle = "character_sp",
	PrefabName = "All_NewYearBeast",
	SkinName = "2",
	PrefabScale = 50,
	HPBarHeight = 130,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1",
		},
		CritAttackAnim = "Attack_2",
		BattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_3",
		RangeAttackEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 1732, Gain = 347},
		{Value = 200002, Base = 38, Gain = 8},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "顽强意志：降低-75%等级减少效果\n大爆竹：每2回合对前3个队员造成100%攻击伤害\n稍作调整：每3回合回血 10%，最多5次\n年末冲刺：5回合后，攻击 +25%",
		Skill = {
			{
				Id = 105173,
				Value = -75,
			},
			{
				Id = 105049,
				Value = 100,
			},
			{
				Id = 105009,
				Value = 10,
			},
			{
				Id = 105014,
				Value = 25,
			},
		},
	},
	Tags = {
		562933,
		560111,
		564555,
		564560,
		564561,
		564564,
	},
}
EnemyConfig[EnemyID.Id6538] =
{
	Id = 6538,
	Name = "夕大人",
	Rarity = 5,
	Element = 210005,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "每年都会准时去各大星球作乱的怪兽。虽然每次都全副武装，但最后总会被击败，然后被绑着看烟花大会，吃年夜饭，最后发完压岁钱才能放回来。",
	IconBundle = "atlas_activity_1",
	IconAtlas = "ActivityCharacterIcon",
	IconName = "All_NewYearBeast_cos10",
	PrefabBundle = "character_sp",
	PrefabName = "All_NewYearBeast",
	SkinName = "2",
	PrefabScale = 50,
	HPBarHeight = 130,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1",
		},
		CritAttackAnim = "Attack_2",
		BattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_3",
		RangeAttackEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 2382, Gain = 477},
		{Value = 200002, Base = 38, Gain = 8},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "顽强意志：降低-75%等级减少效果\n大爆竹：每2回合对前3个队员造成100%攻击伤害\n稍作调整：每3回合回血 10%，最多5次\n年末冲刺：5回合后，攻击 +25%",
		Skill = {
			{
				Id = 105173,
				Value = -75,
			},
			{
				Id = 105049,
				Value = 100,
			},
			{
				Id = 105009,
				Value = 10,
			},
			{
				Id = 105014,
				Value = 25,
			},
		},
	},
	Tags = {
		562933,
		560111,
		564555,
		564560,
		564561,
		564564,
	},
}
EnemyConfig[EnemyID.Id6539] =
{
	Id = 6539,
	Name = "夕大人",
	Rarity = 5,
	Element = 210005,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "每年都会准时去各大星球作乱的怪兽。虽然每次都全副武装，但最后总会被击败，然后被绑着看烟花大会，吃年夜饭，最后发完压岁钱才能放回来。",
	IconBundle = "atlas_activity_1",
	IconAtlas = "ActivityCharacterIcon",
	IconName = "All_NewYearBeast_cos10",
	PrefabBundle = "character_sp",
	PrefabName = "All_NewYearBeast",
	SkinName = "2",
	PrefabScale = 50,
	HPBarHeight = 130,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1",
		},
		CritAttackAnim = "Attack_2",
		BattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_3",
		RangeAttackEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 2932, Gain = 587},
		{Value = 200002, Base = 40, Gain = 8},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "顽强意志：降低-75%等级减少效果\n大爆竹：每2回合对前3个队员造成100%攻击伤害\n稍作调整：每3回合回血 10%，最多5次\n年末冲刺：5回合后，攻击 +25%",
		Skill = {
			{
				Id = 105173,
				Value = -75,
			},
			{
				Id = 105049,
				Value = 100,
			},
			{
				Id = 105009,
				Value = 10,
			},
			{
				Id = 105014,
				Value = 25,
			},
		},
	},
	Tags = {
		562933,
		560111,
		564555,
		564560,
		564561,
		564564,
	},
}
EnemyConfig[EnemyID.Id6540] =
{
	Id = 6540,
	Name = "死亡骑士",
	Rarity = 5,
	Element = 210005,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "违反了骑士劳动合同，转会加入死亡军团的武士。其变节原因至今无人知晓，不过有消息人士指出，该人员常年沉湎于酷炫坐骑，拉风造型等时尚品，不排除其盲目追求外表而舍弃正道的可能性。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	IconName = "RPG_101_Paladin_cos10",
	PrefabBundle = "character_rpg",
	PrefabName = "RPG_101_Paladin",
	SkinName = "2",
	PrefabScale = 50,
	HPBarHeight = 130,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1",
		},
		CritAttackAnim = "Attack_2",
		BattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_3",
		RangeAttackEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 1732, Gain = 347},
		{Value = 200002, Base = 30, Gain = 6},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "死亡意志：降低-50%等级减少效果\n黯淡装甲：受到的暴击伤害 -25%\n死亡缠绕：每3回合回血 5%，最多5次\n灵魂之刃：每2回合对前2个队员造成75%攻击伤害",
		Skill = {
			{
				Id = 105173,
				Value = -50,
			},
			{
				Id = 105039,
				Value = -25,
			},
			{
				Id = 105009,
				Value = 5,
			},
			{
				Id = 105048,
				Value = 75,
			},
		},
	},
	Tags = {
		562933,
		560111,
		564555,
		564560,
		564564,
	},
}
EnemyConfig[EnemyID.Id6541] =
{
	Id = 6541,
	Name = "死亡骑士",
	Rarity = 5,
	Element = 210005,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "违反了骑士劳动合同，转会加入死亡军团的武士。其变节原因至今无人知晓，不过有消息人士指出，该人员常年沉湎于酷炫坐骑，拉风造型等时尚品，不排除其盲目追求外表而舍弃正道的可能性。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	IconName = "RPG_101_Paladin_cos10",
	PrefabBundle = "character_rpg",
	PrefabName = "RPG_101_Paladin",
	SkinName = "2",
	PrefabScale = 50,
	HPBarHeight = 130,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1",
		},
		CritAttackAnim = "Attack_2",
		BattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_3",
		RangeAttackEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 2382, Gain = 477},
		{Value = 200002, Base = 29, Gain = 6},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "死亡意志：降低-50%等级减少效果\n黯淡装甲：受到的暴击伤害 -25%\n死亡缠绕：每3回合回血 5%，最多5次\n灵魂之刃：每2回合对前2个队员造成75%攻击伤害",
		Skill = {
			{
				Id = 105173,
				Value = -50,
			},
			{
				Id = 105039,
				Value = -25,
			},
			{
				Id = 105009,
				Value = 5,
			},
			{
				Id = 105048,
				Value = 75,
			},
		},
	},
	Tags = {
		560111,
		564555,
		564560,
		564564,
	},
}
EnemyConfig[EnemyID.Id6542] =
{
	Id = 6542,
	Name = "死亡骑士",
	Rarity = 5,
	Element = 210005,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "违反了骑士劳动合同，转会加入死亡军团的武士。其变节原因至今无人知晓，不过有消息人士指出，该人员常年沉湎于酷炫坐骑，拉风造型等时尚品，不排除其盲目追求外表而舍弃正道的可能性。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	IconName = "RPG_101_Paladin_cos10",
	PrefabBundle = "character_rpg",
	PrefabName = "RPG_101_Paladin",
	SkinName = "2",
	PrefabScale = 50,
	HPBarHeight = 130,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1",
		},
		CritAttackAnim = "Attack_2",
		BattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_3",
		RangeAttackEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 2932, Gain = 587},
		{Value = 200002, Base = 28, Gain = 6},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "死亡意志：降低-75%等级减少效果\n黯淡装甲：受到的暴击伤害 -25%\n死亡之吻：每3回合回血 5%，最多5次\n灵魂邪刃：每2回合对前3个队员造成60%攻击伤害",
		Skill = {
			{
				Id = 105173,
				Value = -75,
			},
			{
				Id = 105039,
				Value = -25,
			},
			{
				Id = 105009,
				Value = 5,
			},
			{
				Id = 105049,
				Value = 60,
			},
		},
	},
	Tags = {
		560111,
		564555,
		564560,
		564564,
	},
}
EnemyConfig[EnemyID.Id6543] =
{
	Id = 6543,
	Name = "“白葡萄酒”",
	Rarity = 5,
	Element = 210001,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "为了追求极致酒道而不惜以身犯法的男性，酿制的酒品能够让人一滴断片，忘却任何愉快与烦恼，沉湎酒乡，不能自拔。",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "FAT",
	IconName = "Fat_101_Brandy_cos10",
	PrefabBundle = "character_fat",
	PrefabName = "Fat_101_Brandy",
	SkinName = "2",
	PrefabScale = 50,
	HPBarHeight = 130,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1",
		},
		CritAttackAnim = "Attack_2",
		BattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_3",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 1732, Gain = 347},
		{Value = 200002, Base = 30, Gain = 6},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "沉湎酒乡：降低50%等级减少效果\n迷醉身姿：33%概率闪避攻击\n自在世界：第4回合起，受到暴击伤害-33%\n璀璨雨露：每3回合对所有队员造成100%攻击伤害",
		Skill = {
			{
				Id = 105173,
				Value = 50,
			},
			{
				Id = 105026,
				Value = 33,
			},
			{
				Id = 105180,
				Value = -33,
			},
			{
				Id = 105063,
				Value = 100,
			},
		},
	},
	Tags = {
		562933,
		560111,
		564555,
		564557,
		564564,
	},
}
EnemyConfig[EnemyID.Id6544] =
{
	Id = 6544,
	Name = "“白葡萄酒”",
	Rarity = 5,
	Element = 210001,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "为了追求极致酒道而不惜以身犯法的男性，酿制的酒品能够让人一滴断片，忘却任何愉快与烦恼，沉湎酒乡，不能自拔。",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "FAT",
	IconName = "Fat_101_Brandy_cos10",
	PrefabBundle = "character_fat",
	PrefabName = "Fat_101_Brandy",
	SkinName = "2",
	PrefabScale = 50,
	HPBarHeight = 130,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1",
		},
		CritAttackAnim = "Attack_2",
		BattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_3",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 2382, Gain = 477},
		{Value = 200002, Base = 29, Gain = 6},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "沉湎酒乡：降低50%等级减少效果\n迷醉身姿：33%概率闪避攻击\n自在世界：第4回合起，受到暴击伤害-33%\n璀璨雨露：每3回合对所有队员造成100%攻击伤害",
		Skill = {
			{
				Id = 105173,
				Value = 50,
			},
			{
				Id = 105026,
				Value = 33,
			},
			{
				Id = 105180,
				Value = -33,
			},
			{
				Id = 105063,
				Value = 100,
			},
		},
	},
	Tags = {
		560111,
		564555,
		564557,
		564564,
	},
}
EnemyConfig[EnemyID.Id6545] =
{
	Id = 6545,
	Name = "“白葡萄酒”",
	Rarity = 5,
	Element = 210001,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "为了追求极致酒道而不惜以身犯法的男性，酿制的酒品能够让人一滴断片，忘却任何愉快与烦恼，沉湎酒乡，不能自拔。",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "FAT",
	IconName = "Fat_101_Brandy_cos10",
	PrefabBundle = "character_fat",
	PrefabName = "Fat_101_Brandy",
	SkinName = "2",
	PrefabScale = 50,
	HPBarHeight = 130,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1",
		},
		CritAttackAnim = "Attack_2",
		BattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_3",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 2932, Gain = 587},
		{Value = 200002, Base = 28, Gain = 6},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "沉湎酒乡：降低75%等级减少效果\n醉影迷踪：40%概率闪避攻击\n无忧世界：第4回合起，受到暴击伤害-50%\n璀璨雨露：每3回合对所有队员造成120%攻击伤害",
		Skill = {
			{
				Id = 105173,
				Value = 75,
			},
			{
				Id = 105026,
				Value = 40,
			},
			{
				Id = 105180,
				Value = -50,
			},
			{
				Id = 105063,
				Value = 120,
			},
		},
	},
	Tags = {
		560111,
		564555,
		564557,
		564564,
	},
}
EnemyConfig[EnemyID.Id6546] =
{
	Id = 6546,
	Name = "大魔王列车长",
	Rarity = 5,
	Element = 210002,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：扰乱交通秩序。",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	IconName = "SPBUS_08_longtoulaoda_cos10",
	PrefabBundle = "character_sp",
	PrefabName = "SPBUS_08_longtoulaoda",
	SkinName = "2",
	PrefabScale = 50,
	HPBarHeight = 135,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1",
		},
		CritAttackAnim = "Attack_2",
		BattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_3",
		RangeAttackEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 3032, Gain = 607},
		{Value = 200002, Base = 42, Gain = 9},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "轰隆轰隆：每3回合，本回合75%概率额外攻击1次\n车头轰击：每2回合对前3个队员造成80%攻击伤害\n精准定位：100%概率无视敌人闪避\n魔王威压：每回合，降低敌人100%攻击增强效果",
		Skill = {
			{
				Id = 105138,
				Value = 75,
			},
			{
				Id = 105049,
				Value = 80,
			},
			{
				Id = 105027,
				Value = 100,
			},
			{
				Id = 105188,
				Value = 100,
			},
		},
	},
	Tags = {
		562933,
		560111,
		564555,
		564558,
		564559,
		564564,
	},
}
EnemyConfig[EnemyID.Id6547] =
{
	Id = 6547,
	Name = "大魔王列车长",
	Rarity = 5,
	Element = 210002,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：扰乱交通秩序。",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	IconName = "SPBUS_08_longtoulaoda_cos10",
	PrefabBundle = "character_sp",
	PrefabName = "SPBUS_08_longtoulaoda",
	SkinName = "2",
	PrefabScale = 50,
	HPBarHeight = 135,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1",
		},
		CritAttackAnim = "Attack_2",
		BattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_3",
		RangeAttackEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 4169, Gain = 834},
		{Value = 200002, Base = 43, Gain = 9},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "轰隆轰隆：每3回合，本回合75%概率额外攻击1次\n车头轰击：每2回合对前3个队员造成80%攻击伤害\n精准定位：100%概率无视敌人闪避\n魔王威压：每回合，降低敌人100%攻击增强效果",
		Skill = {
			{
				Id = 105138,
				Value = 75,
			},
			{
				Id = 105049,
				Value = 80,
			},
			{
				Id = 105027,
				Value = 100,
			},
			{
				Id = 105188,
				Value = 100,
			},
		},
	},
	Tags = {
		560111,
		564555,
		564558,
		564559,
		564564,
	},
}
EnemyConfig[EnemyID.Id6548] =
{
	Id = 6548,
	Name = "大魔王列车长",
	Rarity = 5,
	Element = 210002,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：扰乱交通秩序。",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	IconName = "SPBUS_08_longtoulaoda_cos10",
	PrefabBundle = "character_sp",
	PrefabName = "SPBUS_08_longtoulaoda",
	SkinName = "2",
	PrefabScale = 50,
	HPBarHeight = 135,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1",
		},
		CritAttackAnim = "Attack_2",
		BattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_3",
		RangeAttackEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 5131, Gain = 1027},
		{Value = 200002, Base = 45, Gain = 9},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "轰隆轰隆：每3回合，本回合100%概率额外攻击1次\n车头轰击：每2回合对前4个队员造成90%攻击伤害\n精准定位：100%概率无视敌人闪避\n魔王威压：每回合，降低敌人100%攻击增强效果",
		Skill = {
			{
				Id = 105138,
				Value = 100,
			},
			{
				Id = 105050,
				Value = 90,
			},
			{
				Id = 105027,
				Value = 100,
			},
			{
				Id = 105188,
				Value = 100,
			},
		},
	},
	Tags = {
		560111,
		564555,
		564558,
		564559,
		564564,
	},
}
EnemyConfig[EnemyID.Id6549] =
{
	Id = 6549,
	Name = "大魔王售票员",
	Rarity = 5,
	Element = 210004,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：烧掉了乘客的头发。",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	IconName = "SPBUS_09_taigudaren_cos10",
	PrefabBundle = "character_sp",
	PrefabName = "SPBUS_09_taigudaren",
	SkinName = "2",
	PrefabScale = 50,
	HPBarHeight = 135,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1",
		},
		CritAttackAnim = "Attack_2",
		BattleEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_3",
		RangeAttackEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 1424, Gain = 285},
		{Value = 200002, Base = 30, Gain = 6},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "轰隆轰隆：每3回合，本回合75%概率额外攻击1次\n启迪鸣响：每回合攻击 +15%，最多5次\n补充燃料：每3回合回血 20%，最多5次\n中继站：回合中，每次受击，回血1%",
		Skill = {
			{
				Id = 105138,
				Value = 75,
			},
			{
				Id = 105006,
				Value = 15,
			},
			{
				Id = 105009,
				Value = 20,
			},
			{
				Id = 105186,
				Value = 1,
			},
		},
	},
	Tags = {
		562933,
		560111,
		564555,
		564558,
		564560,
		564561,
	},
}
EnemyConfig[EnemyID.Id6550] =
{
	Id = 6550,
	Name = "大魔王售票员",
	Rarity = 5,
	Element = 210004,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：烧掉了乘客的头发。",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	IconName = "SPBUS_09_taigudaren_cos10",
	PrefabBundle = "character_sp",
	PrefabName = "SPBUS_09_taigudaren",
	SkinName = "2",
	PrefabScale = 50,
	HPBarHeight = 135,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1",
		},
		CritAttackAnim = "Attack_2",
		BattleEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_3",
		RangeAttackEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 1472, Gain = 295},
		{Value = 200002, Base = 33, Gain = 7},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "轰隆轰隆：每3回合，本回合75%概率额外攻击1次\n启迪鸣响：每回合攻击 +15%，最多5次\n补充燃料：每3回合回血 20%，最多5次\n中继站：回合中，每次受击，回血1%",
		Skill = {
			{
				Id = 105138,
				Value = 75,
			},
			{
				Id = 105006,
				Value = 15,
			},
			{
				Id = 105009,
				Value = 20,
			},
			{
				Id = 105186,
				Value = 1,
			},
		},
	},
	Tags = {
		560111,
		564555,
		564558,
		564560,
		564561,
	},
}
EnemyConfig[EnemyID.Id6551] =
{
	Id = 6551,
	Name = "大魔王售票员",
	Rarity = 5,
	Element = 210004,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：烧掉了乘客的头发。",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	IconName = "SPBUS_09_taigudaren_cos10",
	PrefabBundle = "character_sp",
	PrefabName = "SPBUS_09_taigudaren",
	SkinName = "2",
	PrefabScale = 50,
	HPBarHeight = 135,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1",
		},
		CritAttackAnim = "Attack_2",
		BattleEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_3",
		RangeAttackEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 1816, Gain = 364},
		{Value = 200002, Base = 36, Gain = 8},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "轰隆轰隆：每3回合，本回合100%概率额外攻击1次\n启迪鸣响：每回合攻击 +15%，最多5次\n补充燃料：每3回合回血 20%，最多5次\n中继站：回合中，每次受击，回血1%",
		Skill = {
			{
				Id = 105138,
				Value = 100,
			},
			{
				Id = 105006,
				Value = 15,
			},
			{
				Id = 105009,
				Value = 20,
			},
			{
				Id = 105186,
				Value = 1,
			},
		},
	},
	Tags = {
		560111,
		564555,
		564558,
		564560,
		564561,
	},
}
EnemyConfig[EnemyID.Id6552] =
{
	Id = 6552,
	Name = "大魔王乘务员",
	Rarity = 5,
	Element = 210003,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：过于凡尔赛。",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	IconName = "SPBUS_10_jiangshou01_cos10",
	PrefabBundle = "character_sp",
	PrefabName = "SPBUS_10_jiangshou01",
	SkinName = "2",
	PrefabScale = 50,
	HPBarHeight = 135,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1",
		},
		CritAttackAnim = "Attack_2",
		BattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_3",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 1464, Gain = 293},
		{Value = 200002, Base = 31, Gain = 7},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "轰隆轰隆：每2回合，本回合75%概率额外攻击1次\n巨型车厢：暴击伤害 +100%\n钢铁车厢：受到的暴击伤害 -33%\n车厢反击：回合中，每次受击，攻击 +2%",
		Skill = {
			{
				Id = 105131,
				Value = 75,
			},
			{
				Id = 105038,
				Value = 100,
			},
			{
				Id = 105039,
				Value = -33,
			},
			{
				Id = 105170,
				Value = 2,
			},
		},
	},
	Tags = {
		562933,
		560111,
		564555,
		564558,
		564561,
	},
}
EnemyConfig[EnemyID.Id6553] =
{
	Id = 6553,
	Name = "大魔王乘务员",
	Rarity = 5,
	Element = 210003,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：过于凡尔赛。",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	IconName = "SPBUS_10_jiangshou01_cos10",
	PrefabBundle = "character_sp",
	PrefabName = "SPBUS_10_jiangshou01",
	SkinName = "2",
	PrefabScale = 50,
	HPBarHeight = 135,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1",
		},
		CritAttackAnim = "Attack_2",
		BattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_3",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 1518, Gain = 304},
		{Value = 200002, Base = 33, Gain = 7},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "轰隆轰隆：每2回合，本回合75%概率额外攻击1次\n巨型车厢：暴击伤害 +100%\n钢铁车厢：受到的暴击伤害 -33%\n车厢反击：回合中，每次受击，攻击 +2%",
		Skill = {
			{
				Id = 105131,
				Value = 75,
			},
			{
				Id = 105038,
				Value = 100,
			},
			{
				Id = 105039,
				Value = -33,
			},
			{
				Id = 105170,
				Value = 2,
			},
		},
	},
	Tags = {
		560111,
		564555,
		564558,
		564561,
	},
}
EnemyConfig[EnemyID.Id6554] =
{
	Id = 6554,
	Name = "大魔王乘务员",
	Rarity = 5,
	Element = 210003,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：过于凡尔赛。",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	IconName = "SPBUS_10_jiangshou01_cos10",
	PrefabBundle = "character_sp",
	PrefabName = "SPBUS_10_jiangshou01",
	SkinName = "2",
	PrefabScale = 50,
	HPBarHeight = 135,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1",
		},
		CritAttackAnim = "Attack_2",
		BattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_3",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 1878, Gain = 376},
		{Value = 200002, Base = 36, Gain = 8},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "轰隆轰隆：每2回合，本回合100%概率额外攻击1次\n巨型车厢：暴击伤害 +100%\n钢铁车厢：受到的暴击伤害 -50%\n车厢反击：回合中，每次受击，攻击 +2%",
		Skill = {
			{
				Id = 105131,
				Value = 100,
			},
			{
				Id = 105038,
				Value = 100,
			},
			{
				Id = 105039,
				Value = -50,
			},
			{
				Id = 105170,
				Value = 2,
			},
		},
	},
	Tags = {
		560111,
		564555,
		564558,
		564561,
	},
}
EnemyConfig[EnemyID.Id6555] =
{
	Id = 6555,
	Name = "大魔王维修工",
	Rarity = 5,
	Element = 210005,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：工作超划水。",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	IconName = "SPBUS_11_jiangshou02_cos10",
	PrefabBundle = "character_sp",
	PrefabName = "SPBUS_11_jiangshou02",
	SkinName = "2",
	PrefabScale = 50,
	HPBarHeight = 135,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1",
		},
		CritAttackAnim = "Attack_2",
		BattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_3",
		RangeAttackEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 1506, Gain = 302},
		{Value = 200002, Base = 31, Gain = 7},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "轰隆轰隆：每2回合，本回合75%概率额外攻击1次\n巨型车厢：攻击时无视敌人100%忍耐\n钢铁车厢：受到的暴击伤害 -33%\n车厢反击：回合中，每次受击，攻击 +2%",
		Skill = {
			{
				Id = 105131,
				Value = 75,
			},
			{
				Id = 105168,
				Value = 100,
			},
			{
				Id = 105039,
				Value = -33,
			},
			{
				Id = 105170,
				Value = 2,
			},
		},
	},
	Tags = {
		562933,
		560111,
		564555,
		564558,
		564561,
		564563,
	},
}
EnemyConfig[EnemyID.Id6556] =
{
	Id = 6556,
	Name = "大魔王维修工",
	Rarity = 5,
	Element = 210005,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：工作超划水。",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	IconName = "SPBUS_11_jiangshou02_cos10",
	PrefabBundle = "character_sp",
	PrefabName = "SPBUS_11_jiangshou02",
	SkinName = "2",
	PrefabScale = 50,
	HPBarHeight = 135,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1",
		},
		CritAttackAnim = "Attack_2",
		BattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_3",
		RangeAttackEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 1567, Gain = 314},
		{Value = 200002, Base = 34, Gain = 7},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "轰隆轰隆：每2回合，本回合75%概率额外攻击1次\n巨型车厢：攻击时无视敌人100%忍耐\n钢铁车厢：受到的暴击伤害 -33%\n车厢反击：回合中，每次受击，攻击 +2%",
		Skill = {
			{
				Id = 105131,
				Value = 75,
			},
			{
				Id = 105168,
				Value = 100,
			},
			{
				Id = 105039,
				Value = -33,
			},
			{
				Id = 105170,
				Value = 2,
			},
		},
	},
	Tags = {
		560111,
		564555,
		564558,
		564561,
		564563,
	},
}
EnemyConfig[EnemyID.Id6557] =
{
	Id = 6557,
	Name = "大魔王维修工",
	Rarity = 5,
	Element = 210005,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：工作超划水。",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	IconName = "SPBUS_11_jiangshou02_cos10",
	PrefabBundle = "character_sp",
	PrefabName = "SPBUS_11_jiangshou02",
	SkinName = "2",
	PrefabScale = 50,
	HPBarHeight = 135,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1",
		},
		CritAttackAnim = "Attack_2",
		BattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_3",
		RangeAttackEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 1944, Gain = 389},
		{Value = 200002, Base = 37, Gain = 8},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "轰隆轰隆：每2回合，本回合100%概率额外攻击1次\n巨型车厢：攻击时无视敌人100%忍耐\n钢铁车厢：受到的暴击伤害 -50%\n车厢反击：回合中，每次受击，攻击 +2%",
		Skill = {
			{
				Id = 105131,
				Value = 100,
			},
			{
				Id = 105168,
				Value = 100,
			},
			{
				Id = 105039,
				Value = -50,
			},
			{
				Id = 105170,
				Value = 2,
			},
		},
	},
	Tags = {
		560111,
		564555,
		564558,
		564561,
		564563,
	},
}
EnemyConfig[EnemyID.Id6558] =
{
	Id = 6558,
	Name = "大魔王吊车尾",
	Rarity = 5,
	Element = 210001,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：吃乘客的食物且屡教不改。",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	IconName = "SPBUS_12_longweixiaodi_cos10",
	PrefabBundle = "character_sp",
	PrefabName = "SPBUS_12_longweixiaodi",
	SkinName = "2",
	PrefabScale = 50,
	HPBarHeight = 135,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1",
		},
		CritAttackAnim = "Attack_2",
		BattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_3",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 1552, Gain = 311},
		{Value = 200002, Base = 31, Gain = 7},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "轰隆轰隆：每2回合，本回合75%概率额外攻击1次\n吊车尾：每2回合对末位队员造成33%攻击伤害\n摇摆车尾：每2回合，-33%概率闪避攻击",
		Skill = {
			{
				Id = 105131,
				Value = 75,
			},
			{
				Id = 105051,
				Value = 33,
			},
			{
				Id = 105133,
				Value = -33,
			},
		},
	},
	Tags = {
		562933,
		560111,
		564555,
		564557,
		564558,
	},
}
EnemyConfig[EnemyID.Id6559] =
{
	Id = 6559,
	Name = "大魔王吊车尾",
	Rarity = 5,
	Element = 210001,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：吃乘客的食物且屡教不改。",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	IconName = "SPBUS_12_longweixiaodi_cos10",
	PrefabBundle = "character_sp",
	PrefabName = "SPBUS_12_longweixiaodi",
	SkinName = "2",
	PrefabScale = 50,
	HPBarHeight = 135,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1",
		},
		CritAttackAnim = "Attack_2",
		BattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_3",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 1620, Gain = 324},
		{Value = 200002, Base = 34, Gain = 7},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "轰隆轰隆：每2回合，本回合75%概率额外攻击1次\n吊车尾：每2回合对末位队员造成33%攻击伤害\n摇摆车尾：每2回合，-33%概率闪避攻击",
		Skill = {
			{
				Id = 105131,
				Value = 75,
			},
			{
				Id = 105051,
				Value = 33,
			},
			{
				Id = 105133,
				Value = -33,
			},
		},
	},
	Tags = {
		560111,
		564555,
		564557,
		564558,
	},
}
EnemyConfig[EnemyID.Id6560] =
{
	Id = 6560,
	Name = "大魔王吊车尾",
	Rarity = 5,
	Element = 210001,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：吃乘客的食物且屡教不改。",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	IconName = "SPBUS_12_longweixiaodi_cos10",
	PrefabBundle = "character_sp",
	PrefabName = "SPBUS_12_longweixiaodi",
	SkinName = "2",
	PrefabScale = 50,
	HPBarHeight = 135,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1",
		},
		CritAttackAnim = "Attack_2",
		BattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_3",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 2014, Gain = 403},
		{Value = 200002, Base = 37, Gain = 8},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "轰隆轰隆：每2回合，本回合100%概率额外攻击1次\n吊车尾：每2回合对末位队员造成40%攻击伤害\n摇摆车尾：每2回合，-50%概率闪避攻击",
		Skill = {
			{
				Id = 105131,
				Value = 100,
			},
			{
				Id = 105051,
				Value = 40,
			},
			{
				Id = 105133,
				Value = -50,
			},
		},
	},
	Tags = {
		560111,
		564555,
		564557,
		564558,
	},
}
EnemyConfig[EnemyID.Id6561] =
{
	Id = 6561,
	Name = "斗篷木乃伊",
	Rarity = 5,
	Element = 210003,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：影响居民们进行广场舞活动。",
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "Mus",
	IconName = "MUS_05_munaiyi_cos20",
	PrefabBundle = "character_mus",
	PrefabName = "MUS_05_munaiyi",
	SkinName = "3",
	PrefabScale = 50,
	HPBarHeight = 135,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 4917, Gain = 984},
		{Value = 200002, Base = 46, Gain = 10},
		{Value = 200003, Base = 0, Gain = 1},
		{Value = 200004, Base = 0, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "爆发之舞：回合2开始，每回合造成失去生命15%的额外伤害\n暗中观察：每3回合，回血20%\n扶风之舞：回合中，每次受击，忍耐 -25\n脑袋空空：降低100%等级减少效果",
		Skill = {
			{
				Id = 105216,
				Value = 15,
			},
			{
				Id = 105183,
				Value = 20,
			},
			{
				Id = 105215,
				Value = -25,
			},
			{
				Id = 105173,
				Value = 100,
			},
		},
	},
	Tags = {
		560111,
		564555,
		564560,
		564561,
		564562,
		564564,
	},
}
EnemyConfig[EnemyID.Id6562] =
{
	Id = 6562,
	Name = "斗篷木乃伊",
	Rarity = 5,
	Element = 210003,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：影响居民们进行广场舞活动。",
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "Mus",
	IconName = "MUS_05_munaiyi_cos20",
	PrefabBundle = "character_mus",
	PrefabName = "MUS_05_munaiyi",
	SkinName = "3",
	PrefabScale = 50,
	HPBarHeight = 135,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 5306, Gain = 1062},
		{Value = 200002, Base = 46, Gain = 10},
		{Value = 200003, Base = 0, Gain = 1},
		{Value = 200004, Base = 0, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "爆发之舞：回合2开始，每回合造成失去生命15%的额外伤害\n暗中观察：每3回合，回血20%\n扶风之舞：回合中，每次受击，忍耐 -25\n脑袋空空：降低100%等级减少效果",
		Skill = {
			{
				Id = 105216,
				Value = 15,
			},
			{
				Id = 105183,
				Value = 20,
			},
			{
				Id = 105215,
				Value = -25,
			},
			{
				Id = 105173,
				Value = 100,
			},
		},
	},
	Tags = {
		560111,
		564555,
		564560,
		564561,
		564562,
		564564,
	},
}
EnemyConfig[EnemyID.Id6563] =
{
	Id = 6563,
	Name = "斗篷木乃伊",
	Rarity = 5,
	Element = 210003,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：影响居民们进行广场舞活动。",
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "Mus",
	IconName = "MUS_05_munaiyi_cos20",
	PrefabBundle = "character_mus",
	PrefabName = "MUS_05_munaiyi",
	SkinName = "3",
	PrefabScale = 50,
	HPBarHeight = 135,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 3341, Gain = 669},
		{Value = 200002, Base = 48, Gain = 10},
		{Value = 200003, Base = 300, Gain = 1},
		{Value = 200004, Base = 0, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "爆发之舞：回合2开始，每回合造成失去生命15%的额外伤害\n暗中观察：每3回合，回血20%\n扶风之舞：回合中，每次受击，忍耐 -25\n脑袋空空：降低100%等级减少效果",
		Skill = {
			{
				Id = 105216,
				Value = 15,
			},
			{
				Id = 105183,
				Value = 20,
			},
			{
				Id = 105215,
				Value = -25,
			},
			{
				Id = 105173,
				Value = 100,
			},
		},
	},
	Tags = {
		560111,
		564555,
		564560,
		564561,
		564562,
		564564,
	},
}
EnemyConfig[EnemyID.Id6564] =
{
	Id = 6564,
	Name = "绝命法医",
	Rarity = 5,
	Element = 210001,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：引起法医们恐慌，且屡教不改。",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	IconName = "Sus_04_fayi_cos20",
	PrefabBundle = "character_sus",
	PrefabName = "Sus_04_fayi",
	SkinName = "3",
	PrefabScale = 50,
	HPBarHeight = 135,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 2282, Gain = 457},
		{Value = 200002, Base = 46, Gain = 10},
		{Value = 200003, Base = 0, Gain = 1},
		{Value = 200004, Base = 0, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "回春秘药：暴击伤害 +100%\n爆裂鹰眼：每2回合，100%概率闪避攻击\n阴影之下：每2回合对所有队员造成100%攻击伤害\n绝顶聪明：奇数回合，降低敌人80%回血效果",
		Skill = {
			{
				Id = 105038,
				Value = 100,
			},
			{
				Id = 105133,
				Value = 100,
			},
			{
				Id = 105055,
				Value = 100,
			},
			{
				Id = 105207,
				Value = 80,
			},
		},
	},
	Tags = {
		560111,
		564555,
		564557,
		564564,
	},
}
EnemyConfig[EnemyID.Id6565] =
{
	Id = 6565,
	Name = "绝命法医",
	Rarity = 5,
	Element = 210001,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：引起法医们恐慌，且屡教不改。",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	IconName = "Sus_04_fayi_cos20",
	PrefabBundle = "character_sus",
	PrefabName = "Sus_04_fayi",
	SkinName = "3",
	PrefabScale = 50,
	HPBarHeight = 135,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 2717, Gain = 544},
		{Value = 200002, Base = 63, Gain = 13},
		{Value = 200003, Base = 0, Gain = 1},
		{Value = 200004, Base = 0, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "回春秘药：暴击伤害 +100%\n爆裂鹰眼：每2回合，100%概率闪避攻击\n阴影之下：每2回合对所有队员造成100%攻击伤害\n绝顶聪明：奇数回合，降低敌人80%回血效果",
		Skill = {
			{
				Id = 105038,
				Value = 100,
			},
			{
				Id = 105133,
				Value = 100,
			},
			{
				Id = 105055,
				Value = 100,
			},
			{
				Id = 105207,
				Value = 80,
			},
		},
	},
	Tags = {
		560111,
		564555,
		564557,
		564564,
	},
}
EnemyConfig[EnemyID.Id6566] =
{
	Id = 6566,
	Name = "绝命法医",
	Rarity = 5,
	Element = 210001,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：引起法医们恐慌，且屡教不改。",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	IconName = "Sus_04_fayi_cos20",
	PrefabBundle = "character_sus",
	PrefabName = "Sus_04_fayi",
	SkinName = "3",
	PrefabScale = 50,
	HPBarHeight = 135,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 3084, Gain = 617},
		{Value = 200002, Base = 79, Gain = 16},
		{Value = 200003, Base = 0, Gain = 1},
		{Value = 200004, Base = 0, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "回春秘药：暴击伤害 +200%\n爆裂鹰眼：每2回合，100%概率闪避攻击\n阴影之下：每2回合对所有队员造成100%攻击伤害\n绝顶聪明：奇数回合，降低敌人80%回血效果",
		Skill = {
			{
				Id = 105038,
				Value = 200,
			},
			{
				Id = 105133,
				Value = 100,
			},
			{
				Id = 105055,
				Value = 100,
			},
			{
				Id = 105207,
				Value = 80,
			},
		},
	},
	Tags = {
		560111,
		564555,
		564557,
		564564,
	},
}
EnemyConfig[EnemyID.Id6567] =
{
	Id = 6567,
	Name = "划水姻缘神",
	Rarity = 5,
	Element = 210004,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：让许多人吃到了爱情的苦。",
	IconBundle = "atlas_activity_1",
	IconAtlas = "ActivityCharacterIcon",
	IconName = "SPBUS_21_YueLao_cos10",
	PrefabBundle = "character_sp",
	PrefabName = "SPBUS_21_YueLao",
	SkinName = "2",
	PrefabScale = 50,
	HPBarHeight = 135,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 2282, Gain = 457},
		{Value = 200002, Base = 46, Gain = 10},
		{Value = 200003, Base = 0, Gain = 1},
		{Value = 200004, Base = 0, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "轻舞成双：奇数回合，攻击后三名队员\n双人成行：偶数回合，攻击前三名队员\n看破：100%概率无视敌人闪避\n保护保护：降低100%等级减少效果",
		Skill = {
			{
				Id = 105222,
				Value = 60,
			},
			{
				Id = 105223,
				Value = 60,
			},
			{
				Id = 105027,
				Value = 100,
			},
			{
				Id = 105173,
				Value = 100,
			},
		},
	},
	Tags = {
		560111,
		564555,
		564559,
		564564,
	},
}
EnemyConfig[EnemyID.Id6568] =
{
	Id = 6568,
	Name = "划水姻缘神",
	Rarity = 5,
	Element = 210004,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：让许多人吃到了爱情的苦。",
	IconBundle = "atlas_activity_1",
	IconAtlas = "ActivityCharacterIcon",
	IconName = "SPBUS_21_YueLao_cos10",
	PrefabBundle = "character_sp",
	PrefabName = "SPBUS_21_YueLao",
	SkinName = "2",
	PrefabScale = 50,
	HPBarHeight = 135,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 2717, Gain = 544},
		{Value = 200002, Base = 46, Gain = 10},
		{Value = 200003, Base = 0, Gain = 1},
		{Value = 200004, Base = 0, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "轻舞成双：奇数回合，攻击后三名队员\n双人成行：偶数回合，攻击前三名队员\n看破：100%概率无视敌人闪避\n保护保护：降低100%等级减少效果",
		Skill = {
			{
				Id = 105222,
				Value = 80,
			},
			{
				Id = 105223,
				Value = 80,
			},
			{
				Id = 105027,
				Value = 100,
			},
			{
				Id = 105173,
				Value = 100,
			},
		},
	},
	Tags = {
		560111,
		564555,
		564559,
		564564,
	},
}
EnemyConfig[EnemyID.Id6569] =
{
	Id = 6569,
	Name = "划水姻缘神",
	Rarity = 5,
	Element = 210004,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：让许多人吃到了爱情的苦。",
	IconBundle = "atlas_activity_1",
	IconAtlas = "ActivityCharacterIcon",
	IconName = "SPBUS_21_YueLao_cos10",
	PrefabBundle = "character_sp",
	PrefabName = "SPBUS_21_YueLao",
	SkinName = "2",
	PrefabScale = 50,
	HPBarHeight = 135,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 3084, Gain = 617},
		{Value = 200002, Base = 48, Gain = 10},
		{Value = 200003, Base = 0, Gain = 1},
		{Value = 200004, Base = 0, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "轻舞成双：奇数回合，攻击后三名队员\n双人成行：偶数回合，攻击前三名队员\n看破：100%概率无视敌人闪避\n保护保护：降低100%等级减少效果",
		Skill = {
			{
				Id = 105222,
				Value = 100,
			},
			{
				Id = 105223,
				Value = 100,
			},
			{
				Id = 105027,
				Value = 100,
			},
			{
				Id = 105173,
				Value = 100,
			},
		},
	},
	Tags = {
		560111,
		564555,
		564559,
		564564,
	},
}
EnemyConfig[EnemyID.Id6570] =
{
	Id = 6570,
	Name = "变味小紫",
	Rarity = 5,
	Element = 210001,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：喂无辜居民吃死鱼味的零食。",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	IconName = "Fat_18_xiaozi",
	PrefabBundle = "character_fat",
	PrefabName = "Fat_18_xiaozi",
	SkinName = "2",
	PrefabScale = 50,
	HPBarHeight = 135,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 2282, Gain = 457},
		{Value = 200002, Base = 46, Gain = 10},
		{Value = 200003, Base = 0, Gain = 1},
		{Value = 200004, Base = 0, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "紫气东来：暴击伤害 +100%\n姹紫嫣红：每2回合，本回合暴率 +100%\n小紫反击：回合中，每次受击，攻击 +100%\n万紫千红：100%概率无视敌人闪避",
		Skill = {
			{
				Id = 105038,
				Value = 100,
			},
			{
				Id = 105128,
				Value = 100,
			},
			{
				Id = 105170,
				Value = 100,
			},
			{
				Id = 105027,
				Value = 100,
			},
		},
	},
	Tags = {
		560111,
		564555,
		564559,
		564561,
	},
}
EnemyConfig[EnemyID.Id6571] =
{
	Id = 6571,
	Name = "变味小紫",
	Rarity = 5,
	Element = 210001,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：喂无辜居民吃死鱼味的零食。",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	IconName = "Fat_18_xiaozi",
	PrefabBundle = "character_fat",
	PrefabName = "Fat_18_xiaozi",
	SkinName = "2",
	PrefabScale = 50,
	HPBarHeight = 135,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 2717, Gain = 544},
		{Value = 200002, Base = 63, Gain = 13},
		{Value = 200003, Base = 0, Gain = 1},
		{Value = 200004, Base = 0, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "紫气东来：暴击伤害 +100%\n姹紫嫣红：每2回合，本回合暴率 +100%\n小紫反击：回合中，每次受击，攻击 +100%\n万紫千红：100%概率无视敌人闪避",
		Skill = {
			{
				Id = 105038,
				Value = 100,
			},
			{
				Id = 105128,
				Value = 100,
			},
			{
				Id = 105170,
				Value = 100,
			},
			{
				Id = 105027,
				Value = 100,
			},
		},
	},
	Tags = {
		560111,
		564555,
		564559,
		564561,
	},
}
EnemyConfig[EnemyID.Id6572] =
{
	Id = 6572,
	Name = "变味小紫",
	Rarity = 5,
	Element = 210001,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：喂无辜居民吃死鱼味的零食。",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	IconName = "Fat_18_xiaozi",
	PrefabBundle = "character_fat",
	PrefabName = "Fat_18_xiaozi",
	SkinName = "2",
	PrefabScale = 50,
	HPBarHeight = 135,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 3084, Gain = 617},
		{Value = 200002, Base = 79, Gain = 16},
		{Value = 200003, Base = 0, Gain = 1},
		{Value = 200004, Base = 0, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "紫气东来：暴击伤害 +150%\n姹紫嫣红：每2回合，本回合暴率 +100%\n小紫反击：回合中，每次受击，攻击 +200%\n万紫千红：100%概率无视敌人闪避",
		Skill = {
			{
				Id = 105038,
				Value = 150,
			},
			{
				Id = 105128,
				Value = 100,
			},
			{
				Id = 105170,
				Value = 200,
			},
			{
				Id = 105027,
				Value = 100,
			},
		},
	},
	Tags = {
		560111,
		564555,
		564559,
		564561,
	},
}
EnemyConfig[EnemyID.Id6573] =
{
	Id = 6573,
	Name = "剧毒丝丝",
	Rarity = 5,
	Element = 210004,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：不分昼夜地演唱，并且唱歌跑调，影响居民精神健康。",
	IconBundle = "atlas_charactericon_sea",
	IconAtlas = "Sea",
	IconName = "Sea_04_dengtashuimu",
	PrefabBundle = "character_sea",
	PrefabName = "Sea_04_dengtashuimu",
	SkinName = "1",
	PrefabScale = 50,
	HPBarHeight = 135,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 2282, Gain = 457},
		{Value = 200002, Base = 46, Gain = 10},
		{Value = 200003, Base = 0, Gain = 1},
		{Value = 200004, Base = 0, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "坚不可摧：100%概率无视敌人闪避\n忽明忽暗：每2回合，100%概率闪避攻击\n心如明镜：每2回合对所有队员造成100%攻击伤害\n千变万化：每回合将自身元素变为随机元素",
		Skill = {
			{
				Id = 105027,
				Value = 100,
			},
			{
				Id = 105133,
				Value = 100,
			},
			{
				Id = 105055,
				Value = 100,
			},
			{
				Id = 105162,
				Value = -1,
			},
		},
	},
	Tags = {
		560111,
		564555,
		564557,
		564559,
	},
}
EnemyConfig[EnemyID.Id6574] =
{
	Id = 6574,
	Name = "剧毒丝丝",
	Rarity = 5,
	Element = 210004,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：不分昼夜地演唱，并且唱歌跑调，影响居民精神健康。",
	IconBundle = "atlas_charactericon_sea",
	IconAtlas = "Sea",
	IconName = "Sea_04_dengtashuimu",
	PrefabBundle = "character_sea",
	PrefabName = "Sea_04_dengtashuimu",
	SkinName = "1",
	PrefabScale = 50,
	HPBarHeight = 135,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 2717, Gain = 544},
		{Value = 200002, Base = 63, Gain = 13},
		{Value = 200003, Base = 0, Gain = 1},
		{Value = 200004, Base = 0, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "坚不可摧：100%概率无视敌人闪避\n忽明忽暗：每2回合，100%概率闪避攻击\n心如明镜：每2回合对所有队员造成100%攻击伤害\n千变万化：每回合将自身元素变为随机元素",
		Skill = {
			{
				Id = 105027,
				Value = 100,
			},
			{
				Id = 105133,
				Value = 100,
			},
			{
				Id = 105055,
				Value = 100,
			},
			{
				Id = 105162,
				Value = -1,
			},
		},
	},
	Tags = {
		560111,
		564555,
		564557,
		564559,
	},
}
EnemyConfig[EnemyID.Id6575] =
{
	Id = 6575,
	Name = "剧毒丝丝",
	Rarity = 5,
	Element = 210004,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：不分昼夜地演唱，并且唱歌跑调，影响居民精神健康。",
	IconBundle = "atlas_charactericon_sea",
	IconAtlas = "Sea",
	IconName = "Sea_04_dengtashuimu",
	PrefabBundle = "character_sea",
	PrefabName = "Sea_04_dengtashuimu",
	SkinName = "1",
	PrefabScale = 50,
	HPBarHeight = 135,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 3084, Gain = 617},
		{Value = 200002, Base = 79, Gain = 16},
		{Value = 200003, Base = 0, Gain = 1},
		{Value = 200004, Base = 0, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "坚不可摧：100%概率无视敌人闪避\n忽明忽暗：每2回合，100%概率闪避攻击\n心如明镜：每2回合对所有队员造成110%攻击伤害\n千变万化：每回合将自身元素变为随机元素",
		Skill = {
			{
				Id = 105027,
				Value = 100,
			},
			{
				Id = 105133,
				Value = 100,
			},
			{
				Id = 105055,
				Value = 110,
			},
			{
				Id = 105162,
				Value = -1,
			},
		},
	},
	Tags = {
		560111,
		564555,
		564557,
		564559,
	},
}
EnemyConfig[EnemyID.Id6576] =
{
	Id = 6576,
	Name = "高级非酋",
	Rarity = 5,
	Element = 210005,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：严重影响不夜城的商业声誉。",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	IconName = "SPDraw_05_UnlockChiefSister",
	PrefabBundle = "character_sp",
	PrefabName = "SPDraw_05_UnlockChiefSister",
	SkinName = "1",
	PrefabScale = 50,
	HPBarHeight = 135,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 2282, Gain = 457},
		{Value = 200002, Base = 46, Gain = 10},
		{Value = 200003, Base = 0, Gain = 1},
		{Value = 200004, Base = 0, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "一起摇摆：攻击 +15%\n凌波微步：第2回合，对全部队员造成 60%伤害\n舞动节拍：每3回合，本回合100%概率额外攻击2次\n音频律动：每5回合，100%概率闪避攻击",
		Skill = {
			{
				Id = 105002,
				Value = 15,
			},
			{
				Id = 105212,
				Value = 60,
			},
			{
				Id = 105139,
				Value = 100,
			},
			{
				Id = 105147,
				Value = 100,
			},
		},
	},
	Tags = {
		560111,
		564555,
		564557,
		564558,
		564561,
	},
}
EnemyConfig[EnemyID.Id6577] =
{
	Id = 6577,
	Name = "高级非酋",
	Rarity = 5,
	Element = 210005,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：严重影响不夜城的商业声誉。",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	IconName = "SPDraw_05_UnlockChiefSister",
	PrefabBundle = "character_sp",
	PrefabName = "SPDraw_05_UnlockChiefSister",
	SkinName = "1",
	PrefabScale = 50,
	HPBarHeight = 135,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 2717, Gain = 544},
		{Value = 200002, Base = 63, Gain = 13},
		{Value = 200003, Base = 0, Gain = 1},
		{Value = 200004, Base = 0, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "一起摇摆：攻击 +25%\n凌波微步：第2回合，对全部队员造成 70%伤害\n舞动节拍：每3回合，本回合100%概率额外攻击2次\n音频律动：每5回合，100%概率闪避攻击",
		Skill = {
			{
				Id = 105002,
				Value = 25,
			},
			{
				Id = 105212,
				Value = 70,
			},
			{
				Id = 105139,
				Value = 100,
			},
			{
				Id = 105147,
				Value = 100,
			},
		},
	},
	Tags = {
		560111,
		564555,
		564557,
		564558,
		564561,
	},
}
EnemyConfig[EnemyID.Id6578] =
{
	Id = 6578,
	Name = "高级非酋",
	Rarity = 5,
	Element = 210005,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：严重影响不夜城的商业声誉。",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	IconName = "SPDraw_05_UnlockChiefSister",
	PrefabBundle = "character_sp",
	PrefabName = "SPDraw_05_UnlockChiefSister",
	SkinName = "1",
	PrefabScale = 50,
	HPBarHeight = 135,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 3084, Gain = 617},
		{Value = 200002, Base = 79, Gain = 16},
		{Value = 200003, Base = 0, Gain = 1},
		{Value = 200004, Base = 0, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "一起摇摆：攻击 +50%\n凌波微步：第2回合，对全部队员造成 99%伤害\n舞动节拍：每3回合，本回合100%概率额外攻击2次\n音频律动：每5回合，100%概率闪避攻击",
		Skill = {
			{
				Id = 105002,
				Value = 50,
			},
			{
				Id = 105212,
				Value = 99,
			},
			{
				Id = 105139,
				Value = 100,
			},
			{
				Id = 105147,
				Value = 100,
			},
		},
	},
	Tags = {
		560111,
		564555,
		564557,
		564558,
		564561,
	},
}
EnemyConfig[EnemyID.Id6579] =
{
	Id = 6579,
	Name = "幽灵骑士",
	Rarity = 5,
	Element = 210004,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：破坏决斗公平性。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	IconName = "RPG_101_Paladin_cos10",
	PrefabBundle = "character_rpg",
	PrefabName = "RPG_101_Paladin",
	SkinName = "2",
	PrefabScale = 50,
	HPBarHeight = 135,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 2282, Gain = 457},
		{Value = 200002, Base = 46, Gain = 10},
		{Value = 200003, Base = 0, Gain = 1},
		{Value = 200004, Base = 0, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "黑暗夺舍：攻击时无视敌人100%忍耐\n趋于黑暗：2~3回合对前2个队员造成100%攻击伤害\n黑暗治疗：每回合回血 20%，最多5次\n杀戮欲望：每3回合暴击 +80，最多3次",
		Skill = {
			{
				Id = 105168,
				Value = 100,
			},
			{
				Id = 105175,
				Value = 100,
			},
			{
				Id = 105005,
				Value = 20,
			},
			{
				Id = 105012,
				Value = 80,
			},
		},
	},
	Tags = {
		560111,
		564555,
		564560,
		564561,
		564563,
	},
}
EnemyConfig[EnemyID.Id6580] =
{
	Id = 6580,
	Name = "幽灵骑士",
	Rarity = 5,
	Element = 210004,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：破坏决斗公平性。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	IconName = "RPG_101_Paladin_cos10",
	PrefabBundle = "character_rpg",
	PrefabName = "RPG_101_Paladin",
	SkinName = "2",
	PrefabScale = 50,
	HPBarHeight = 135,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 2717, Gain = 544},
		{Value = 200002, Base = 63, Gain = 13},
		{Value = 200003, Base = 0, Gain = 1},
		{Value = 200004, Base = 0, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "黑暗夺舍：攻击时无视敌人100%忍耐\n趋于黑暗：2~3回合对前2个队员造成120%攻击伤害\n黑暗治疗：每回合回血 25%，最多5次\n杀戮欲望：每3回合暴击 +90，最多3次",
		Skill = {
			{
				Id = 105168,
				Value = 100,
			},
			{
				Id = 105175,
				Value = 120,
			},
			{
				Id = 105005,
				Value = 25,
			},
			{
				Id = 105012,
				Value = 90,
			},
		},
	},
	Tags = {
		560111,
		564555,
		564560,
		564561,
		564563,
	},
}
EnemyConfig[EnemyID.Id6581] =
{
	Id = 6581,
	Name = "幽灵骑士",
	Rarity = 5,
	Element = 210004,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：破坏决斗公平性。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	IconName = "RPG_101_Paladin_cos10",
	PrefabBundle = "character_rpg",
	PrefabName = "RPG_101_Paladin",
	SkinName = "2",
	PrefabScale = 50,
	HPBarHeight = 135,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 3084, Gain = 617},
		{Value = 200002, Base = 79, Gain = 16},
		{Value = 200003, Base = 0, Gain = 1},
		{Value = 200004, Base = 0, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "黑暗夺舍：攻击时无视敌人100%忍耐\n趋于黑暗：2~3回合对前2个队员造成150%攻击伤害\n黑暗治疗：每回合回血 35%，最多5次\n杀戮欲望：每3回合暴击 +100，最多3次",
		Skill = {
			{
				Id = 105168,
				Value = 100,
			},
			{
				Id = 105175,
				Value = 150,
			},
			{
				Id = 105005,
				Value = 35,
			},
			{
				Id = 105012,
				Value = 100,
			},
		},
	},
	Tags = {
		560111,
		564555,
		564560,
		564561,
		564563,
	},
}
EnemyConfig[EnemyID.Id6582] =
{
	Id = 6582,
	Name = "迈克罗夫特",
	Rarity = 5,
	Element = 210001,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：收取他人甜食，涉嫌贪污受贿。",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	IconName = "Sus_19_maikaofu",
	PrefabBundle = "character_sus",
	PrefabName = "Sus_19_maikaofu",
	SkinName = "1",
	PrefabScale = 50,
	HPBarHeight = 135,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 2282, Gain = 457},
		{Value = 200002, Base = 46, Gain = 10},
		{Value = 200003, Base = 0, Gain = 1},
		{Value = 200004, Base = 0, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "偶然发现：偶数回合，攻击前三名队员\n文思泉涌：每回合，恢复攻击100%生命\n机巧灵动：降低100%等级减少效果\n是个狠人：生命 +100%",
		Skill = {
			{
				Id = 105223,
				Value = 100,
			},
			{
				Id = 105214,
				Value = 100,
			},
			{
				Id = 105173,
				Value = 100,
			},
			{
				Id = 105001,
				Value = 100,
			},
		},
	},
	Tags = {
		560111,
		564555,
		564560,
		564561,
		564564,
	},
}
EnemyConfig[EnemyID.Id6583] =
{
	Id = 6583,
	Name = "迈克罗夫特",
	Rarity = 5,
	Element = 210001,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：收取他人甜食，涉嫌贪污受贿。",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	IconName = "Sus_19_maikaofu",
	PrefabBundle = "character_sus",
	PrefabName = "Sus_19_maikaofu",
	SkinName = "1",
	PrefabScale = 50,
	HPBarHeight = 135,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 2717, Gain = 544},
		{Value = 200002, Base = 46, Gain = 10},
		{Value = 200003, Base = 0, Gain = 1},
		{Value = 200004, Base = 0, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "偶然发现：偶数回合，攻击前三名队员\n文思泉涌：每回合，恢复攻击100%生命\n机巧灵动：降低100%等级减少效果\n是个狠人：生命 +130%",
		Skill = {
			{
				Id = 105223,
				Value = 100,
			},
			{
				Id = 105214,
				Value = 100,
			},
			{
				Id = 105173,
				Value = 100,
			},
			{
				Id = 105001,
				Value = 130,
			},
		},
	},
	Tags = {
		560111,
		564555,
		564560,
		564561,
		564564,
	},
}
EnemyConfig[EnemyID.Id6584] =
{
	Id = 6584,
	Name = "迈克罗夫特",
	Rarity = 5,
	Element = 210001,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：收取他人甜食，涉嫌贪污受贿。",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	IconName = "Sus_19_maikaofu",
	PrefabBundle = "character_sus",
	PrefabName = "Sus_19_maikaofu",
	SkinName = "1",
	PrefabScale = 50,
	HPBarHeight = 135,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 3084, Gain = 617},
		{Value = 200002, Base = 48, Gain = 10},
		{Value = 200003, Base = 0, Gain = 1},
		{Value = 200004, Base = 0, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "偶然发现：偶数回合，攻击前三名队员\n文思泉涌：每回合，恢复攻击100%生命\n机巧灵动：降低100%等级减少效果\n是个狠人：生命 +150%",
		Skill = {
			{
				Id = 105223,
				Value = 100,
			},
			{
				Id = 105214,
				Value = 100,
			},
			{
				Id = 105173,
				Value = 100,
			},
			{
				Id = 105001,
				Value = 150,
			},
		},
	},
	Tags = {
		560111,
		564555,
		564560,
		564561,
		564564,
	},
}
EnemyConfig[EnemyID.Id6585] =
{
	Id = 6585,
	Name = "指路NPC",
	Rarity = 5,
	Element = 210001,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：胡乱指路，导致勇者迷失。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	IconName = "Rpg_10_buluolaoda",
	PrefabBundle = "character_rpg",
	PrefabName = "Rpg_10_buluolaoda",
	SkinName = "1",
	PrefabScale = 50,
	HPBarHeight = 135,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 2282, Gain = 457},
		{Value = 200002, Base = 46, Gain = 10},
		{Value = 200003, Base = 0, Gain = 1},
		{Value = 200004, Base = 0, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "碎甲攻势：攻击时无视敌人66%忍耐\n蓄势待发：回合中，每次受击，暴击 +30\n伺机而动：回合中，每次受击，攻击 +5%\n以逸待劳：回合中，每次受击，回血2%",
		Skill = {
			{
				Id = 105168,
				Value = 66,
			},
			{
				Id = 105172,
				Value = 30,
			},
			{
				Id = 105170,
				Value = 5,
			},
			{
				Id = 105186,
				Value = 2,
			},
		},
	},
	Tags = {
		560111,
		564555,
		564560,
		564561,
		564563,
	},
}
EnemyConfig[EnemyID.Id6586] =
{
	Id = 6586,
	Name = "指路NPC",
	Rarity = 5,
	Element = 210001,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：胡乱指路，导致勇者迷失。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	IconName = "Rpg_10_buluolaoda",
	PrefabBundle = "character_rpg",
	PrefabName = "Rpg_10_buluolaoda",
	SkinName = "1",
	PrefabScale = 50,
	HPBarHeight = 135,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 2717, Gain = 544},
		{Value = 200002, Base = 63, Gain = 13},
		{Value = 200003, Base = 0, Gain = 1},
		{Value = 200004, Base = 0, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "碎甲攻势：攻击时无视敌人66%忍耐\n蓄势待发：回合中，每次受击，暴击 +30\n伺机而动：回合中，每次受击，攻击 +5%\n以逸待劳：回合中，每次受击，回血2%",
		Skill = {
			{
				Id = 105168,
				Value = 66,
			},
			{
				Id = 105172,
				Value = 30,
			},
			{
				Id = 105170,
				Value = 5,
			},
			{
				Id = 105186,
				Value = 2,
			},
		},
	},
	Tags = {
		560111,
		564555,
		564560,
		564561,
		564563,
	},
}
EnemyConfig[EnemyID.Id6587] =
{
	Id = 6587,
	Name = "指路NPC",
	Rarity = 5,
	Element = 210001,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：胡乱指路，导致勇者迷失。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	IconName = "Rpg_10_buluolaoda",
	PrefabBundle = "character_rpg",
	PrefabName = "Rpg_10_buluolaoda",
	SkinName = "1",
	PrefabScale = 50,
	HPBarHeight = 135,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 3084, Gain = 617},
		{Value = 200002, Base = 79, Gain = 16},
		{Value = 200003, Base = 0, Gain = 1},
		{Value = 200004, Base = 0, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "碎甲攻势：攻击时无视敌人66%忍耐\n蓄势待发：回合中，每次受击，暴击 +30\n伺机而动：回合中，每次受击，攻击 +5%\n以逸待劳：回合中，每次受击，回血2%",
		Skill = {
			{
				Id = 105168,
				Value = 66,
			},
			{
				Id = 105172,
				Value = 30,
			},
			{
				Id = 105170,
				Value = 5,
			},
			{
				Id = 105186,
				Value = 2,
			},
		},
	},
	Tags = {
		560111,
		564555,
		564560,
		564561,
		564563,
	},
}
EnemyConfig[EnemyID.Id6588] =
{
	Id = 6588,
	Name = "呐喊家",
	Rarity = 5,
	Element = 210003,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：震碎玻璃，间接导致文物失窃。",
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "Mus",
	IconName = "MUS_19_nahan",
	PrefabBundle = "character_mus",
	PrefabName = "MUS_19_nahan",
	SkinName = "1",
	PrefabScale = 50,
	HPBarHeight = 135,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 2282, Gain = 457},
		{Value = 200002, Base = 46, Gain = 10},
		{Value = 200003, Base = 0, Gain = 1},
		{Value = 200004, Base = 0, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "苦痛呐喊：每2回合对前2个队员造成100%攻击伤害\n尖声呐喊：每3回合对后3个队员造成100%攻击伤害\n困顿呐喊：每5回合对所有队员造成100%攻击伤害\n变调：生命 +100%",
		Skill = {
			{
				Id = 105048,
				Value = 100,
			},
			{
				Id = 105061,
				Value = 100,
			},
			{
				Id = 105071,
				Value = 100,
			},
			{
				Id = 105001,
				Value = 100,
			},
		},
	},
	Tags = {
		560111,
		564555,
		564561,
	},
}
EnemyConfig[EnemyID.Id6589] =
{
	Id = 6589,
	Name = "呐喊家",
	Rarity = 5,
	Element = 210003,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：震碎玻璃，间接导致文物失窃。",
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "Mus",
	IconName = "MUS_19_nahan",
	PrefabBundle = "character_mus",
	PrefabName = "MUS_19_nahan",
	SkinName = "1",
	PrefabScale = 50,
	HPBarHeight = 135,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 2717, Gain = 544},
		{Value = 200002, Base = 63, Gain = 13},
		{Value = 200003, Base = 0, Gain = 1},
		{Value = 200004, Base = 0, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "苦痛呐喊：每2回合对前2个队员造成100%攻击伤害\n尖声呐喊：每3回合对后3个队员造成100%攻击伤害\n困顿呐喊：每5回合对所有队员造成100%攻击伤害\n变调：生命 +100%",
		Skill = {
			{
				Id = 105048,
				Value = 100,
			},
			{
				Id = 105061,
				Value = 100,
			},
			{
				Id = 105071,
				Value = 100,
			},
			{
				Id = 105001,
				Value = 100,
			},
		},
	},
	Tags = {
		560111,
		564555,
		564561,
	},
}
EnemyConfig[EnemyID.Id6590] =
{
	Id = 6590,
	Name = "呐喊家",
	Rarity = 5,
	Element = 210003,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：震碎玻璃，间接导致文物失窃。",
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "Mus",
	IconName = "MUS_19_nahan",
	PrefabBundle = "character_mus",
	PrefabName = "MUS_19_nahan",
	SkinName = "1",
	PrefabScale = 50,
	HPBarHeight = 135,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 3084, Gain = 617},
		{Value = 200002, Base = 79, Gain = 16},
		{Value = 200003, Base = 0, Gain = 1},
		{Value = 200004, Base = 0, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "苦痛呐喊：每2回合对前2个队员造成100%攻击伤害\n尖声呐喊：每3回合对后3个队员造成100%攻击伤害\n困顿呐喊：每5回合对所有队员造成110%攻击伤害\n变调：生命 +160%",
		Skill = {
			{
				Id = 105048,
				Value = 100,
			},
			{
				Id = 105061,
				Value = 100,
			},
			{
				Id = 105071,
				Value = 110,
			},
			{
				Id = 105001,
				Value = 160,
			},
		},
	},
	Tags = {
		560111,
		564555,
		564561,
	},
}
EnemyConfig[EnemyID.Id6591] =
{
	Id = 6591,
	Name = "法官",
	Rarity = 5,
	Element = 210004,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：把木槌扔到律师的大脑门上。",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	IconName = "Sus_14_faguan",
	PrefabBundle = "character_sus",
	PrefabName = "Sus_14_faguan",
	SkinName = "1",
	PrefabScale = 50,
	HPBarHeight = 135,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 2282, Gain = 457},
		{Value = 200002, Base = 46, Gain = 10},
		{Value = 200003, Base = 0, Gain = 1},
		{Value = 200004, Base = 0, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "正义伸张：攻击 +80%\n正义裁决：4~5回合对前3个队员造成60%攻击伤害\n致命节奏：每3回合，本回合100%概率额外攻击2次\n礼法教术：回合中，每次受击，回血3%",
		Skill = {
			{
				Id = 105002,
				Value = 80,
			},
			{
				Id = 105176,
				Value = 60,
			},
			{
				Id = 105139,
				Value = 100,
			},
			{
				Id = 105186,
				Value = 3,
			},
		},
	},
	Tags = {
		560111,
		564555,
		564558,
		564560,
		564561,
	},
}
EnemyConfig[EnemyID.Id6592] =
{
	Id = 6592,
	Name = "法官",
	Rarity = 5,
	Element = 210004,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：把木槌扔到律师的大脑门上。",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	IconName = "Sus_14_faguan",
	PrefabBundle = "character_sus",
	PrefabName = "Sus_14_faguan",
	SkinName = "1",
	PrefabScale = 50,
	HPBarHeight = 135,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 2717, Gain = 544},
		{Value = 200002, Base = 63, Gain = 13},
		{Value = 200003, Base = 0, Gain = 1},
		{Value = 200004, Base = 0, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "正义伸张：攻击 +100%\n正义裁决：4~5回合对前3个队员造成80%攻击伤害\n致命节奏：每3回合，本回合100%概率额外攻击2次\n礼法教术：回合中，每次受击，回血3%",
		Skill = {
			{
				Id = 105002,
				Value = 100,
			},
			{
				Id = 105176,
				Value = 80,
			},
			{
				Id = 105139,
				Value = 100,
			},
			{
				Id = 105186,
				Value = 3,
			},
		},
	},
	Tags = {
		560111,
		564555,
		564558,
		564560,
		564561,
	},
}
EnemyConfig[EnemyID.Id6593] =
{
	Id = 6593,
	Name = "法官",
	Rarity = 5,
	Element = 210004,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：把木槌扔到律师的大脑门上。",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	IconName = "Sus_14_faguan",
	PrefabBundle = "character_sus",
	PrefabName = "Sus_14_faguan",
	SkinName = "1",
	PrefabScale = 50,
	HPBarHeight = 135,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 3084, Gain = 617},
		{Value = 200002, Base = 79, Gain = 16},
		{Value = 200003, Base = 0, Gain = 1},
		{Value = 200004, Base = 0, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "正义伸张：攻击 +150%\n正义裁决：4~5回合对前3个队员造成100%攻击伤害\n致命节奏：每3回合，本回合100%概率额外攻击2次\n礼法教术：回合中，每次受击，回血3%",
		Skill = {
			{
				Id = 105002,
				Value = 150,
			},
			{
				Id = 105176,
				Value = 100,
			},
			{
				Id = 105139,
				Value = 100,
			},
			{
				Id = 105186,
				Value = 3,
			},
		},
	},
	Tags = {
		560111,
		564555,
		564558,
		564560,
		564561,
	},
}
EnemyConfig[EnemyID.Id6594] =
{
	Id = 6594,
	Name = "骨头兵",
	Rarity = 5,
	Element = 210005,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：让魔王集团董事长摔倒，严重损害集团形象。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	IconName = "Rpg_30_kulou",
	PrefabBundle = "character_rpg",
	PrefabName = "Rpg_30_kulou",
	SkinName = "1",
	PrefabScale = 50,
	HPBarHeight = 135,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 2282, Gain = 457},
		{Value = 200002, Base = 46, Gain = 10},
		{Value = 200003, Base = 0, Gain = 1},
		{Value = 200004, Base = 0, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "夜之魅影：每2回合对前3个队员造成100%攻击伤害\n罪恶的骨：每6回合，回血自身攻击2000%的生命值\n黑暗禁疗：每2回合，降低敌人40%攻击增强效果\n杀戮涟漪：忍耐 +100",
		Skill = {
			{
				Id = 105049,
				Value = 100,
			},
			{
				Id = 105022,
				Value = 2000,
			},
			{
				Id = 105192,
				Value = 40,
			},
			{
				Id = 105003,
				Value = 100,
			},
		},
	},
	Tags = {
		560111,
		564555,
		564560,
		564561,
		564564,
	},
}
EnemyConfig[EnemyID.Id6595] =
{
	Id = 6595,
	Name = "骨头兵",
	Rarity = 5,
	Element = 210005,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：让魔王集团董事长摔倒，严重损害集团形象。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	IconName = "Rpg_30_kulou",
	PrefabBundle = "character_rpg",
	PrefabName = "Rpg_30_kulou",
	SkinName = "1",
	PrefabScale = 50,
	HPBarHeight = 135,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 2717, Gain = 544},
		{Value = 200002, Base = 63, Gain = 13},
		{Value = 200003, Base = 0, Gain = 1},
		{Value = 200004, Base = 0, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "夜之魅影：每2回合对前3个队员造成100%攻击伤害\n罪恶的骨：每6回合，回血自身攻击2000%的生命值\n黑暗禁疗：每2回合，降低敌人50%攻击增强效果\n杀戮涟漪：忍耐 +250",
		Skill = {
			{
				Id = 105049,
				Value = 100,
			},
			{
				Id = 105022,
				Value = 2000,
			},
			{
				Id = 105192,
				Value = 50,
			},
			{
				Id = 105003,
				Value = 250,
			},
		},
	},
	Tags = {
		560111,
		564555,
		564560,
		564561,
		564564,
	},
}
EnemyConfig[EnemyID.Id6596] =
{
	Id = 6596,
	Name = "骨头兵",
	Rarity = 5,
	Element = 210005,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：让魔王集团董事长摔倒，严重损害集团形象。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	IconName = "Rpg_30_kulou",
	PrefabBundle = "character_rpg",
	PrefabName = "Rpg_30_kulou",
	SkinName = "1",
	PrefabScale = 50,
	HPBarHeight = 135,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 3084, Gain = 617},
		{Value = 200002, Base = 79, Gain = 16},
		{Value = 200003, Base = 0, Gain = 1},
		{Value = 200004, Base = 0, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "夜之魅影：每2回合对前3个队员造成100%攻击伤害\n罪恶的骨：每6回合，回血自身攻击2000%的生命值\n黑暗禁疗：每2回合，降低敌人80%攻击增强效果\n杀戮涟漪：忍耐 +400",
		Skill = {
			{
				Id = 105049,
				Value = 100,
			},
			{
				Id = 105022,
				Value = 2000,
			},
			{
				Id = 105192,
				Value = 80,
			},
			{
				Id = 105003,
				Value = 400,
			},
		},
	},
	Tags = {
		560111,
		564555,
		564560,
		564561,
		564564,
	},
}
EnemyConfig[EnemyID.Id6597] =
{
	Id = 6597,
	Name = "年度邪神",
	Rarity = 5,
	Element = 210002,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：抢夺小朋友的压岁钱。",
	IconBundle = "atlas_activity_1",
	IconAtlas = "ActivityCharacterIcon",
	IconName = "All_NewYearBeast",
	PrefabBundle = "character_sp",
	PrefabName = "All_NewYearBeast",
	SkinName = "1",
	PrefabScale = 50,
	HPBarHeight = 135,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 2282, Gain = 457},
		{Value = 200002, Base = 134, Gain = 27},
		{Value = 200003, Base = 0, Gain = 1},
		{Value = 200004, Base = 0, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "年年岁岁：每3回合对后3个队员造成30%攻击伤害\n岁岁年年：每5回合对所有队员造成30%攻击伤害\n生命源泉：生命 +100%\n幸运的年：100%概率无视敌人闪避",
		Skill = {
			{
				Id = 105061,
				Value = 30,
			},
			{
				Id = 105071,
				Value = 30,
			},
			{
				Id = 105001,
				Value = 100,
			},
			{
				Id = 105027,
				Value = 100,
			},
		},
	},
	Tags = {
		560111,
		564555,
		564559,
		564561,
	},
}
EnemyConfig[EnemyID.Id6598] =
{
	Id = 6598,
	Name = "年度邪神",
	Rarity = 5,
	Element = 210002,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：抢夺小朋友的压岁钱。",
	IconBundle = "atlas_activity_1",
	IconAtlas = "ActivityCharacterIcon",
	IconName = "All_NewYearBeast",
	PrefabBundle = "character_sp",
	PrefabName = "All_NewYearBeast",
	SkinName = "1",
	PrefabScale = 50,
	HPBarHeight = 135,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 2717, Gain = 544},
		{Value = 200002, Base = 167, Gain = 34},
		{Value = 200003, Base = 0, Gain = 1},
		{Value = 200004, Base = 0, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "年年岁岁：每3回合对后3个队员造成40%攻击伤害\n岁岁年年：每5回合对所有队员造成40%攻击伤害\n生命源泉：生命 +150%\n幸运的年：100%概率无视敌人闪避",
		Skill = {
			{
				Id = 105061,
				Value = 40,
			},
			{
				Id = 105071,
				Value = 40,
			},
			{
				Id = 105001,
				Value = 150,
			},
			{
				Id = 105027,
				Value = 100,
			},
		},
	},
	Tags = {
		560111,
		564555,
		564559,
		564561,
	},
}
EnemyConfig[EnemyID.Id6599] =
{
	Id = 6599,
	Name = "年度邪神",
	Rarity = 5,
	Element = 210002,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：抢夺小朋友的压岁钱。",
	IconBundle = "atlas_activity_1",
	IconAtlas = "ActivityCharacterIcon",
	IconName = "All_NewYearBeast",
	PrefabBundle = "character_sp",
	PrefabName = "All_NewYearBeast",
	SkinName = "1",
	PrefabScale = 50,
	HPBarHeight = 135,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 3084, Gain = 617},
		{Value = 200002, Base = 206, Gain = 42},
		{Value = 200003, Base = 0, Gain = 1},
		{Value = 200004, Base = 0, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "年年岁岁：每3回合对后3个队员造成50%攻击伤害\n岁岁年年：每5回合对所有队员造成50%攻击伤害\n生命源泉：生命 +250%\n幸运的年：100%概率无视敌人闪避",
		Skill = {
			{
				Id = 105061,
				Value = 50,
			},
			{
				Id = 105071,
				Value = 50,
			},
			{
				Id = 105001,
				Value = 250,
			},
			{
				Id = 105027,
				Value = 100,
			},
		},
	},
	Tags = {
		560111,
		564555,
		564559,
		564561,
	},
}
EnemyConfig[EnemyID.Id6600] =
{
	Id = 6600,
	Name = "有始无终",
	Rarity = 5,
	Element = 210005,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：做事有始无终。",
	IconBundle = "atlas_activity_1",
	IconAtlas = "ActivityCharacterIcon",
	IconName = "All_BeginEnd",
	PrefabBundle = "character_sp",
	PrefabName = "All_BeginEnd",
	SkinName = "2",
	PrefabScale = 50,
	HPBarHeight = 135,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 2282, Gain = 457},
		{Value = 200002, Base = 46, Gain = 10},
		{Value = 200003, Base = 0, Gain = 1},
		{Value = 200004, Base = 0, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "有始无终：每2回合对前2个队员造成80%攻击伤害\n谨终如始：生命 +125%\n慎终如始：攻击时无视敌人50忍耐\n始乱终弃：每回合将自身元素变为随机元素",
		Skill = {
			{
				Id = 105048,
				Value = 80,
			},
			{
				Id = 105001,
				Value = 125,
			},
			{
				Id = 105169,
				Value = 50,
			},
			{
				Id = 105162,
				Value = -1,
			},
		},
	},
	Tags = {
		560111,
		564555,
		564561,
		564563,
	},
}
EnemyConfig[EnemyID.Id6601] =
{
	Id = 6601,
	Name = "有始无终",
	Rarity = 5,
	Element = 210005,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：做事有始无终。",
	IconBundle = "atlas_activity_1",
	IconAtlas = "ActivityCharacterIcon",
	IconName = "All_BeginEnd",
	PrefabBundle = "character_sp",
	PrefabName = "All_BeginEnd",
	SkinName = "2",
	PrefabScale = 50,
	HPBarHeight = 135,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 2717, Gain = 544},
		{Value = 200002, Base = 63, Gain = 13},
		{Value = 200003, Base = 0, Gain = 1},
		{Value = 200004, Base = 0, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "有始无终：每2回合对前2个队员造成100%攻击伤害\n谨终如始：生命 +250%\n慎终如始：攻击时无视敌人75忍耐\n始乱终弃：每回合将自身元素变为随机元素",
		Skill = {
			{
				Id = 105048,
				Value = 100,
			},
			{
				Id = 105001,
				Value = 250,
			},
			{
				Id = 105169,
				Value = 75,
			},
			{
				Id = 105162,
				Value = -1,
			},
		},
	},
	Tags = {
		560111,
		564555,
		564561,
		564563,
	},
}
EnemyConfig[EnemyID.Id6602] =
{
	Id = 6602,
	Name = "有始无终",
	Rarity = 5,
	Element = 210005,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：做事有始无终。",
	IconBundle = "atlas_activity_1",
	IconAtlas = "ActivityCharacterIcon",
	IconName = "All_BeginEnd",
	PrefabBundle = "character_sp",
	PrefabName = "All_BeginEnd",
	SkinName = "2",
	PrefabScale = 50,
	HPBarHeight = 135,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 3084, Gain = 617},
		{Value = 200002, Base = 79, Gain = 16},
		{Value = 200003, Base = 0, Gain = 1},
		{Value = 200004, Base = 0, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "有始无终：每2回合对前2个队员造成125%攻击伤害\n谨终如始：生命 +420%\n慎终如始：攻击时无视敌人100忍耐\n始乱终弃：每回合将自身元素变为随机元素",
		Skill = {
			{
				Id = 105048,
				Value = 125,
			},
			{
				Id = 105001,
				Value = 420,
			},
			{
				Id = 105169,
				Value = 100,
			},
			{
				Id = 105162,
				Value = -1,
			},
		},
	},
	Tags = {
		560111,
		564555,
		564561,
		564563,
	},
}
EnemyConfig[EnemyID.Id6603] =
{
	Id = 6603,
	Name = "极寒雪怪",
	Rarity = 5,
	Element = 210001,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：寒冬腊月里关掉居民们的空调和暖气。",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	IconName = "SPBUS_24_XueShen",
	PrefabBundle = "character_sp",
	PrefabName = "SPBUS_24_XueShen",
	SkinName = "1",
	PrefabScale = 50,
	HPBarHeight = 135,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 2282, Gain = 457},
		{Value = 200002, Base = 46, Gain = 10},
		{Value = 200003, Base = 0, Gain = 1},
		{Value = 200004, Base = 0, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "傲雪凌霜:每3回合，本回合100%概率额外攻击2次\n冰雪聪明:每2回合攻击 +100%，最多5次\n凛如霜雪：每3回合，回血自身攻击100%的生命值\n雪操冰心：每回合忍耐 +80，最多5次",
		Skill = {
			{
				Id = 105139,
				Value = 100,
			},
			{
				Id = 105178,
				Value = 100,
			},
			{
				Id = 105020,
				Value = 100,
			},
			{
				Id = 105007,
				Value = 80,
			},
		},
	},
	Tags = {
		560111,
		564555,
		564558,
		564560,
		564561,
	},
}
EnemyConfig[EnemyID.Id6604] =
{
	Id = 6604,
	Name = "极寒雪怪",
	Rarity = 5,
	Element = 210001,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：寒冬腊月里关掉居民们的空调和暖气。",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	IconName = "SPBUS_24_XueShen",
	PrefabBundle = "character_sp",
	PrefabName = "SPBUS_24_XueShen",
	SkinName = "1",
	PrefabScale = 50,
	HPBarHeight = 135,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 2717, Gain = 544},
		{Value = 200002, Base = 63, Gain = 13},
		{Value = 200003, Base = 0, Gain = 1},
		{Value = 200004, Base = 0, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "傲雪凌霜:每3回合，本回合100%概率额外攻击2次\n冰雪聪明:每2回合攻击 +150%，最多5次\n凛如霜雪：每3回合，回血自身攻击200%的生命值\n雪操冰心：每回合忍耐 +100，最多5次",
		Skill = {
			{
				Id = 105139,
				Value = 100,
			},
			{
				Id = 105178,
				Value = 150,
			},
			{
				Id = 105020,
				Value = 200,
			},
			{
				Id = 105007,
				Value = 100,
			},
		},
	},
	Tags = {
		560111,
		564555,
		564558,
		564560,
		564561,
	},
}
EnemyConfig[EnemyID.Id6605] =
{
	Id = 6605,
	Name = "极寒雪怪",
	Rarity = 5,
	Element = 210001,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：寒冬腊月里关掉居民们的空调和暖气。",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	IconName = "SPBUS_24_XueShen",
	PrefabBundle = "character_sp",
	PrefabName = "SPBUS_24_XueShen",
	SkinName = "1",
	PrefabScale = 50,
	HPBarHeight = 135,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 3084, Gain = 617},
		{Value = 200002, Base = 79, Gain = 16},
		{Value = 200003, Base = 0, Gain = 1},
		{Value = 200004, Base = 0, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "傲雪凌霜:每3回合，本回合100%概率额外攻击2次\n冰雪聪明:每2回合攻击 +200%，最多5次\n凛如霜雪：每3回合，回血自身攻击400%的生命值\n雪操冰心：每回合忍耐 +130，最多5次",
		Skill = {
			{
				Id = 105139,
				Value = 100,
			},
			{
				Id = 105178,
				Value = 200,
			},
			{
				Id = 105020,
				Value = 400,
			},
			{
				Id = 105007,
				Value = 130,
			},
		},
	},
	Tags = {
		560111,
		564555,
		564558,
		564560,
		564561,
	},
}
EnemyConfig[EnemyID.Id6606] =
{
	Id = 6606,
	Name = "猫爪厨娘",
	Rarity = 5,
	Element = 210002,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：偷吃菜品。",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	IconName = "SPBUS_25_MaoYanChuNiang",
	PrefabBundle = "character_sp",
	PrefabName = "SPBUS_25_MaoYanChuNiang",
	SkinName = "1",
	PrefabScale = 50,
	HPBarHeight = 135,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 2282, Gain = 457},
		{Value = 200002, Base = 46, Gain = 10},
		{Value = 200003, Base = 0, Gain = 1},
		{Value = 200004, Base = 0, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "爱心便当：每3回合，回血自身攻击100%的生命值\n黑暗料理：生命 +100%\n黑暗喵爪：每回合暴击 +20，最多5次\n厨具攻击：攻击时无视敌人40%忍耐",
		Skill = {
			{
				Id = 105020,
				Value = 100,
			},
			{
				Id = 105001,
				Value = 100,
			},
			{
				Id = 105008,
				Value = 20,
			},
			{
				Id = 105168,
				Value = 40,
			},
		},
	},
	Tags = {
		560111,
		564555,
		564560,
		564561,
		564563,
	},
}
EnemyConfig[EnemyID.Id6607] =
{
	Id = 6607,
	Name = "猫爪厨娘",
	Rarity = 5,
	Element = 210002,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：偷吃菜品。",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	IconName = "SPBUS_25_MaoYanChuNiang",
	PrefabBundle = "character_sp",
	PrefabName = "SPBUS_25_MaoYanChuNiang",
	SkinName = "1",
	PrefabScale = 50,
	HPBarHeight = 135,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 2717, Gain = 544},
		{Value = 200002, Base = 63, Gain = 13},
		{Value = 200003, Base = 0, Gain = 1},
		{Value = 200004, Base = 0, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "爱心便当：每3回合，回血自身攻击120%的生命值\n黑暗料理：生命 +200%\n黑暗喵爪：每回合暴击 +30，最多5次\n厨具攻击：攻击时无视敌人50%忍耐",
		Skill = {
			{
				Id = 105020,
				Value = 120,
			},
			{
				Id = 105001,
				Value = 200,
			},
			{
				Id = 105008,
				Value = 30,
			},
			{
				Id = 105168,
				Value = 50,
			},
		},
	},
	Tags = {
		560111,
		564555,
		564560,
		564561,
		564563,
	},
}
EnemyConfig[EnemyID.Id6608] =
{
	Id = 6608,
	Name = "猫爪厨娘",
	Rarity = 5,
	Element = 210002,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：偷吃菜品。",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	IconName = "SPBUS_25_MaoYanChuNiang",
	PrefabBundle = "character_sp",
	PrefabName = "SPBUS_25_MaoYanChuNiang",
	SkinName = "1",
	PrefabScale = 50,
	HPBarHeight = 135,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 3084, Gain = 617},
		{Value = 200002, Base = 79, Gain = 16},
		{Value = 200003, Base = 0, Gain = 1},
		{Value = 200004, Base = 0, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "爱心便当：每3回合，回血自身攻击180%的生命值\n黑暗料理：生命 +320%\n黑暗喵爪：每回合暴击 +40，最多5次\n厨具攻击：攻击时无视敌人75%忍耐",
		Skill = {
			{
				Id = 105020,
				Value = 180,
			},
			{
				Id = 105001,
				Value = 320,
			},
			{
				Id = 105008,
				Value = 40,
			},
			{
				Id = 105168,
				Value = 75,
			},
		},
	},
	Tags = {
		560111,
		564555,
		564560,
		564561,
		564563,
	},
}
EnemyConfig[EnemyID.Id6609] =
{
	Id = 6609,
	Name = "互联网黑话家",
	Rarity = 5,
	Element = 210003,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：过度使用黑话。",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	IconName = "SPBUS_26_WenQuanJianShanJia",
	PrefabBundle = "character_sp",
	PrefabName = "SPBUS_26_WenQuanJianShanJia",
	SkinName = "1",
	PrefabScale = 50,
	HPBarHeight = 135,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 2282, Gain = 457},
		{Value = 200002, Base = 46, Gain = 10},
		{Value = 200003, Base = 0, Gain = 1},
		{Value = 200004, Base = 0, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "拉通：每3回合对后2个队员造成100%攻击伤害\n对齐：每2回合对前3个队员造成100%攻击伤害\n抓手：生命 +100%\n赋能：忍耐 +100",
		Skill = {
			{
				Id = 105060,
				Value = 100,
			},
			{
				Id = 105049,
				Value = 100,
			},
			{
				Id = 105001,
				Value = 100,
			},
			{
				Id = 105003,
				Value = 100,
			},
		},
	},
	Tags = {
		560111,
		564555,
		564561,
	},
}
EnemyConfig[EnemyID.Id6610] =
{
	Id = 6610,
	Name = "互联网黑话家",
	Rarity = 5,
	Element = 210003,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：过度使用黑话。",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	IconName = "SPBUS_26_WenQuanJianShanJia",
	PrefabBundle = "character_sp",
	PrefabName = "SPBUS_26_WenQuanJianShanJia",
	SkinName = "1",
	PrefabScale = 50,
	HPBarHeight = 135,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 2717, Gain = 544},
		{Value = 200002, Base = 63, Gain = 13},
		{Value = 200003, Base = 0, Gain = 1},
		{Value = 200004, Base = 0, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "拉通：每3回合对后2个队员造成100%攻击伤害\n对齐：每2回合对前3个队员造成100%攻击伤害\n抓手：生命 +150%\n赋能：忍耐 +120",
		Skill = {
			{
				Id = 105060,
				Value = 100,
			},
			{
				Id = 105049,
				Value = 100,
			},
			{
				Id = 105001,
				Value = 150,
			},
			{
				Id = 105003,
				Value = 120,
			},
		},
	},
	Tags = {
		560111,
		564555,
		564561,
	},
}
EnemyConfig[EnemyID.Id6611] =
{
	Id = 6611,
	Name = "互联网黑话家",
	Rarity = 5,
	Element = 210003,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：过度使用黑话。",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	IconName = "SPBUS_26_WenQuanJianShanJia",
	PrefabBundle = "character_sp",
	PrefabName = "SPBUS_26_WenQuanJianShanJia",
	SkinName = "1",
	PrefabScale = 50,
	HPBarHeight = 135,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 3084, Gain = 617},
		{Value = 200002, Base = 79, Gain = 16},
		{Value = 200003, Base = 0, Gain = 1},
		{Value = 200004, Base = 0, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "拉通：每3回合对后2个队员造成100%攻击伤害\n对齐：每2回合对前3个队员造成100%攻击伤害\n抓手：生命 +240%\n赋能：忍耐 +160",
		Skill = {
			{
				Id = 105060,
				Value = 100,
			},
			{
				Id = 105049,
				Value = 100,
			},
			{
				Id = 105001,
				Value = 240,
			},
			{
				Id = 105003,
				Value = 160,
			},
		},
	},
	Tags = {
		560111,
		564555,
		564561,
	},
}
EnemyConfig[EnemyID.Id6612] =
{
	Id = 6612,
	Name = "枕头撕裂者",
	Rarity = 5,
	Element = 210005,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：撕裂枕头，影响附近施工。",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	IconName = "Sus_15_fangdongtaitai",
	PrefabBundle = "character_sus",
	PrefabName = "Sus_15_fangdongtaitai",
	SkinName = "2",
	PrefabScale = 50,
	HPBarHeight = 135,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 2282, Gain = 457},
		{Value = 200002, Base = 46, Gain = 10},
		{Value = 200003, Base = 0, Gain = 1},
		{Value = 200004, Base = 0, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "上门收租：每4回合对所有队员造成90%攻击伤害\n诱捕猫粮：5回合后，回血 100%\n熟能生巧：降低100%等级减少效果\n无理取闹：每3回合，100%概率闪避攻击",
		Skill = {
			{
				Id = 105226,
				Value = 90,
			},
			{
				Id = 105013,
				Value = 100,
			},
			{
				Id = 105173,
				Value = 100,
			},
			{
				Id = 105140,
				Value = 100,
			},
		},
	},
	Tags = {
		560111,
		564555,
		564557,
		564560,
		564564,
	},
}
EnemyConfig[EnemyID.Id6613] =
{
	Id = 6613,
	Name = "枕头撕裂者",
	Rarity = 5,
	Element = 210005,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：撕裂枕头，影响附近施工。",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	IconName = "Sus_15_fangdongtaitai",
	PrefabBundle = "character_sus",
	PrefabName = "Sus_15_fangdongtaitai",
	SkinName = "2",
	PrefabScale = 50,
	HPBarHeight = 135,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 2717, Gain = 544},
		{Value = 200002, Base = 63, Gain = 13},
		{Value = 200003, Base = 0, Gain = 1},
		{Value = 200004, Base = 0, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "上门收租：每4回合对所有队员造成90%攻击伤害\n诱捕猫粮：5回合后，回血 100%\n熟能生巧：降低100%等级减少效果\n无理取闹：每3回合，100%概率闪避攻击",
		Skill = {
			{
				Id = 105226,
				Value = 90,
			},
			{
				Id = 105013,
				Value = 100,
			},
			{
				Id = 105173,
				Value = 100,
			},
			{
				Id = 105140,
				Value = 100,
			},
		},
	},
	Tags = {
		560111,
		564555,
		564557,
		564560,
		564564,
	},
}
EnemyConfig[EnemyID.Id6614] =
{
	Id = 6614,
	Name = "枕头撕裂者",
	Rarity = 5,
	Element = 210005,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：撕裂枕头，影响附近施工。",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	IconName = "Sus_15_fangdongtaitai",
	PrefabBundle = "character_sus",
	PrefabName = "Sus_15_fangdongtaitai",
	SkinName = "2",
	PrefabScale = 50,
	HPBarHeight = 135,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 3084, Gain = 617},
		{Value = 200002, Base = 79, Gain = 16},
		{Value = 200003, Base = 0, Gain = 1},
		{Value = 200004, Base = 0, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "上门收租：每4回合对所有队员造成90%攻击伤害\n诱捕猫粮：5回合后，回血 110%\n熟能生巧：降低100%等级减少效果\n无理取闹：每3回合，100%概率闪避攻击",
		Skill = {
			{
				Id = 105226,
				Value = 90,
			},
			{
				Id = 105013,
				Value = 110,
			},
			{
				Id = 105173,
				Value = 100,
			},
			{
				Id = 105140,
				Value = 100,
			},
		},
	},
	Tags = {
		560111,
		564555,
		564557,
		564560,
		564564,
	},
}
EnemyConfig[EnemyID.Id6615] =
{
	Id = 6615,
	Name = "广场舞领舞",
	Rarity = 5,
	Element = 210001,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：侵占冒险协会训练广场。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	IconName = "RPG_104_DancingGirl",
	PrefabBundle = "character_rpg",
	PrefabName = "RPG_104_DancingGirl",
	SkinName = "1",
	PrefabScale = 50,
	HPBarHeight = 135,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 2282, Gain = 457},
		{Value = 200002, Base = 46, Gain = 10},
		{Value = 200003, Base = 0, Gain = 1},
		{Value = 200004, Base = 0, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "时代在召唤：每3回合，100%概率闪避攻击\n青春的活力：生命 +50%\n舞动青春:5回合后，回血 20%\n雏鹰起飞:每3回合对所有队员造成33%攻击伤害",
		Skill = {
			{
				Id = 105140,
				Value = 100,
			},
			{
				Id = 105001,
				Value = 50,
			},
			{
				Id = 105013,
				Value = 20,
			},
			{
				Id = 105063,
				Value = 33,
			},
		},
	},
	Tags = {
		560111,
		564555,
		564557,
		564560,
		564561,
	},
}
EnemyConfig[EnemyID.Id6616] =
{
	Id = 6616,
	Name = "广场舞领舞",
	Rarity = 5,
	Element = 210001,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：侵占冒险协会训练广场。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	IconName = "RPG_104_DancingGirl",
	PrefabBundle = "character_rpg",
	PrefabName = "RPG_104_DancingGirl",
	SkinName = "1",
	PrefabScale = 50,
	HPBarHeight = 135,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 2717, Gain = 544},
		{Value = 200002, Base = 63, Gain = 13},
		{Value = 200003, Base = 0, Gain = 1},
		{Value = 200004, Base = 0, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "时代在召唤：每3回合，100%概率闪避攻击\n青春的活力：生命 +75%\n舞动青春:5回合后，回血 30%\n雏鹰起飞:每3回合对所有队员造成50%攻击伤害",
		Skill = {
			{
				Id = 105140,
				Value = 100,
			},
			{
				Id = 105001,
				Value = 75,
			},
			{
				Id = 105013,
				Value = 30,
			},
			{
				Id = 105063,
				Value = 50,
			},
		},
	},
	Tags = {
		560111,
		564555,
		564557,
		564560,
		564561,
	},
}
EnemyConfig[EnemyID.Id6617] =
{
	Id = 6617,
	Name = "广场舞领舞",
	Rarity = 5,
	Element = 210001,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：侵占冒险协会训练广场。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	IconName = "RPG_104_DancingGirl",
	PrefabBundle = "character_rpg",
	PrefabName = "RPG_104_DancingGirl",
	SkinName = "1",
	PrefabScale = 50,
	HPBarHeight = 135,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 3084, Gain = 617},
		{Value = 200002, Base = 79, Gain = 16},
		{Value = 200003, Base = 0, Gain = 1},
		{Value = 200004, Base = 0, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "时代在召唤：每3回合，100%概率闪避攻击\n青春的活力：生命 +133%\n舞动青春:5回合后，回血 50%\n雏鹰起飞:每3回合对所有队员造成80%攻击伤害",
		Skill = {
			{
				Id = 105140,
				Value = 100,
			},
			{
				Id = 105001,
				Value = 133,
			},
			{
				Id = 105013,
				Value = 50,
			},
			{
				Id = 105063,
				Value = 80,
			},
		},
	},
	Tags = {
		560111,
		564555,
		564557,
		564560,
		564561,
	},
}
EnemyConfig[EnemyID.Id6618] =
{
	Id = 6618,
	Name = "鬼武者",
	Rarity = 5,
	Element = 210001,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：拔刀恐吓居民。",
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "Mus",
	IconName = "MUS_09_ribenwushi",
	PrefabBundle = "character_mus",
	PrefabName = "MUS_09_ribenwushi",
	SkinName = "1",
	PrefabScale = 50,
	HPBarHeight = 115,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 2282, Gain = 457},
		{Value = 200002, Base = 46, Gain = 10},
		{Value = 200003, Base = 0, Gain = 1},
		{Value = 200004, Base = 0, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "漩涡斩：每回合，降低敌人100%攻击增强效果\n裂地斩：每3回合，100%概率闪避攻击\n瞬影斩：攻击 +75%\n破魂斩:每3回合暴击 +30，最多3次",
		Skill = {
			{
				Id = 105188,
				Value = 100,
			},
			{
				Id = 105140,
				Value = 100,
			},
			{
				Id = 105002,
				Value = 75,
			},
			{
				Id = 105012,
				Value = 30,
			},
		},
	},
	Tags = {
		560111,
		564555,
		564557,
		564561,
		564564,
	},
}
EnemyConfig[EnemyID.Id6619] =
{
	Id = 6619,
	Name = "鬼武者",
	Rarity = 5,
	Element = 210001,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：拔刀恐吓居民。",
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "Mus",
	IconName = "MUS_09_ribenwushi",
	PrefabBundle = "character_mus",
	PrefabName = "MUS_09_ribenwushi",
	SkinName = "1",
	PrefabScale = 50,
	HPBarHeight = 115,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 2717, Gain = 544},
		{Value = 200002, Base = 63, Gain = 13},
		{Value = 200003, Base = 0, Gain = 1},
		{Value = 200004, Base = 0, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "漩涡斩：每回合，降低敌人100%攻击增强效果\n裂地斩：每3回合，100%概率闪避攻击\n瞬影斩：攻击 +125%\n破魂斩:每3回合暴击 +50，最多3次",
		Skill = {
			{
				Id = 105188,
				Value = 100,
			},
			{
				Id = 105140,
				Value = 100,
			},
			{
				Id = 105002,
				Value = 125,
			},
			{
				Id = 105012,
				Value = 50,
			},
		},
	},
	Tags = {
		560111,
		564555,
		564557,
		564561,
		564564,
	},
}
EnemyConfig[EnemyID.Id6620] =
{
	Id = 6620,
	Name = "鬼武者",
	Rarity = 5,
	Element = 210001,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：拔刀恐吓居民。",
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "Mus",
	IconName = "MUS_09_ribenwushi",
	PrefabBundle = "character_mus",
	PrefabName = "MUS_09_ribenwushi",
	SkinName = "1",
	PrefabScale = 50,
	HPBarHeight = 115,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 3084, Gain = 617},
		{Value = 200002, Base = 79, Gain = 16},
		{Value = 200003, Base = 0, Gain = 1},
		{Value = 200004, Base = 0, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "漩涡斩：每回合，降低敌人100%攻击增强效果\n裂地斩：每3回合，100%概率闪避攻击\n瞬影斩：攻击 +250%\n破魂斩:每3回合暴击 +80，最多3次",
		Skill = {
			{
				Id = 105188,
				Value = 100,
			},
			{
				Id = 105140,
				Value = 100,
			},
			{
				Id = 105002,
				Value = 250,
			},
			{
				Id = 105012,
				Value = 80,
			},
		},
	},
	Tags = {
		560111,
		564555,
		564557,
		564561,
		564564,
	},
}
EnemyConfig[EnemyID.Id6621] =
{
	Id = 6621,
	Name = "刺猬头律师",
	Rarity = 5,
	Element = 210003,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：多次破坏法庭财物。",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	IconName = "Sus_13_lvshi",
	PrefabBundle = "character_sus",
	PrefabName = "Sus_13_lvshi",
	SkinName = "1",
	PrefabScale = 50,
	HPBarHeight = 112,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 2282, Gain = 457},
		{Value = 200002, Base = 46, Gain = 10},
		{Value = 200003, Base = 0, Gain = 1},
		{Value = 200004, Base = 0, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "开诚布公：每2回合对前3个队员造成100%攻击伤害\n对簿公堂：每2回合，本回合100%概率额外攻击1次\n义正言辞：每回合，降低敌人50%回血效果\n平平无奇：每2回合，回血自身攻击200%的生命值",
		Skill = {
			{
				Id = 105049,
				Value = 100,
			},
			{
				Id = 105131,
				Value = 100,
			},
			{
				Id = 105187,
				Value = 50,
			},
			{
				Id = 105019,
				Value = 200,
			},
		},
	},
	Tags = {
		560111,
		564555,
		564558,
		564560,
		564564,
	},
}
EnemyConfig[EnemyID.Id6622] =
{
	Id = 6622,
	Name = "刺猬头律师",
	Rarity = 5,
	Element = 210003,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：多次破坏法庭财物。",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	IconName = "Sus_13_lvshi",
	PrefabBundle = "character_sus",
	PrefabName = "Sus_13_lvshi",
	SkinName = "1",
	PrefabScale = 50,
	HPBarHeight = 112,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 2717, Gain = 544},
		{Value = 200002, Base = 63, Gain = 13},
		{Value = 200003, Base = 0, Gain = 1},
		{Value = 200004, Base = 0, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "开诚布公：每2回合对前3个队员造成100%攻击伤害\n对簿公堂：每2回合，本回合100%概率额外攻击1次\n义正言辞：每回合，降低敌人60%回血效果\n平平无奇：每2回合，回血自身攻击300%的生命值",
		Skill = {
			{
				Id = 105049,
				Value = 100,
			},
			{
				Id = 105131,
				Value = 100,
			},
			{
				Id = 105187,
				Value = 60,
			},
			{
				Id = 105019,
				Value = 300,
			},
		},
	},
	Tags = {
		560111,
		564555,
		564558,
		564560,
		564564,
	},
}
EnemyConfig[EnemyID.Id6623] =
{
	Id = 6623,
	Name = "刺猬头律师",
	Rarity = 5,
	Element = 210003,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：多次破坏法庭财物。",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	IconName = "Sus_13_lvshi",
	PrefabBundle = "character_sus",
	PrefabName = "Sus_13_lvshi",
	SkinName = "1",
	PrefabScale = 50,
	HPBarHeight = 112,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 3084, Gain = 617},
		{Value = 200002, Base = 79, Gain = 16},
		{Value = 200003, Base = 0, Gain = 1},
		{Value = 200004, Base = 0, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "开诚布公：每2回合对前3个队员造成100%攻击伤害\n对簿公堂：每2回合，本回合100%概率额外攻击1次\n义正言辞：每回合，降低敌人70%回血效果\n平平无奇：每回合，回血自身攻击500%的生命值",
		Skill = {
			{
				Id = 105049,
				Value = 100,
			},
			{
				Id = 105131,
				Value = 100,
			},
			{
				Id = 105187,
				Value = 70,
			},
			{
				Id = 105018,
				Value = 500,
			},
		},
	},
	Tags = {
		560111,
		564555,
		564558,
		564560,
		564564,
	},
}
EnemyConfig[EnemyID.Id6624] =
{
	Id = 6624,
	Name = "白痴学者",
	Rarity = 5,
	Element = 210005,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：传播伪学术性谣言。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	IconName = "RPG_105_Scholar",
	PrefabBundle = "character_rpg",
	PrefabName = "RPG_105_Scholar",
	SkinName = "1",
	PrefabScale = 50,
	HPBarHeight = 135,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 2282, Gain = 457},
		{Value = 200002, Base = 46, Gain = 10},
		{Value = 200003, Base = 0, Gain = 1},
		{Value = 200004, Base = 0, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "民间科学：每回合忍耐 +40，最多5次\n一叶障目：每5回合对前4个队员造成80%攻击伤害\n掩耳盗铃：生命 +100%\n恃才傲物：100%概率无视敌人闪避",
		Skill = {
			{
				Id = 105007,
				Value = 40,
			},
			{
				Id = 105066,
				Value = 80,
			},
			{
				Id = 105001,
				Value = 100,
			},
			{
				Id = 105027,
				Value = 100,
			},
		},
	},
	Tags = {
		560111,
		564555,
		564559,
		564561,
	},
}
EnemyConfig[EnemyID.Id6625] =
{
	Id = 6625,
	Name = "白痴学者",
	Rarity = 5,
	Element = 210005,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：传播伪学术性谣言。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	IconName = "RPG_105_Scholar",
	PrefabBundle = "character_rpg",
	PrefabName = "RPG_105_Scholar",
	SkinName = "1",
	PrefabScale = 50,
	HPBarHeight = 135,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 2717, Gain = 544},
		{Value = 200002, Base = 63, Gain = 13},
		{Value = 200003, Base = 0, Gain = 1},
		{Value = 200004, Base = 0, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "民间科学：每回合忍耐 +60，最多5次\n一叶障目：每5回合对前4个队员造成100%攻击伤害\n掩耳盗铃：生命 +200%\n恃才傲物：100%概率无视敌人闪避",
		Skill = {
			{
				Id = 105007,
				Value = 60,
			},
			{
				Id = 105066,
				Value = 100,
			},
			{
				Id = 105001,
				Value = 200,
			},
			{
				Id = 105027,
				Value = 100,
			},
		},
	},
	Tags = {
		560111,
		564555,
		564559,
		564561,
	},
}
EnemyConfig[EnemyID.Id6626] =
{
	Id = 6626,
	Name = "白痴学者",
	Rarity = 5,
	Element = 210005,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：传播伪学术性谣言。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	IconName = "RPG_105_Scholar",
	PrefabBundle = "character_rpg",
	PrefabName = "RPG_105_Scholar",
	SkinName = "1",
	PrefabScale = 50,
	HPBarHeight = 135,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 3084, Gain = 617},
		{Value = 200002, Base = 79, Gain = 16},
		{Value = 200003, Base = 0, Gain = 1},
		{Value = 200004, Base = 0, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "民间科学：每回合忍耐 +80，最多5次\n一叶障目：每5回合对前4个队员造成120%攻击伤害\n掩耳盗铃：生命 +300%\n恃才傲物：100%概率无视敌人闪避",
		Skill = {
			{
				Id = 105007,
				Value = 80,
			},
			{
				Id = 105066,
				Value = 120,
			},
			{
				Id = 105001,
				Value = 300,
			},
			{
				Id = 105027,
				Value = 100,
			},
		},
	},
	Tags = {
		560111,
		564555,
		564559,
		564561,
	},
}
