
EnemyConfig[EnemyID.Id5001] =
{
	Id = 5001,
	Name = "猫猫博士",
	Rarity = 2,
	Element = 210003,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "普通行动舱的强化版本，更适于在恶劣环境中进行战斗。不过为了节省舱体容量，因此去除了大量工作模块。",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	IconName = "Sus_24_boshi_cos10",
	PrefabBundle = "character_sus",
	PrefabName = "Sus_24_boshi",
	SkinName = "2",
	PrefabScale = 50,
	HPBarHeight = 170,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 409, Gain = 82},
		{Value = 200002, Base = 40, Gain = 8},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id5002] =
{
	Id = 5002,
	Name = "猫猫博士",
	Rarity = 2,
	Element = 210003,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "普通行动舱的强化版本，更适于在恶劣环境中进行战斗。不过为了节省舱体容量，因此去除了大量工作模块。",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	IconName = "Sus_24_boshi_cos10",
	PrefabBundle = "character_sus",
	PrefabName = "Sus_24_boshi",
	SkinName = "2",
	PrefabScale = 50,
	HPBarHeight = 170,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 409, Gain = 82},
		{Value = 200002, Base = 40, Gain = 8},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id5003] =
{
	Id = 5003,
	Name = "拦路的魔王",
	Rarity = 2,
	Element = 210005,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "魔王公司中层干部，平时会带着低级雇员们在路上堵截低级勇者搞业绩。不过因为掉落物不错，所以也常被高级勇者蹲点刷。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	IconName = "Rpg_13_dashouxiaodi",
	PrefabBundle = "character_rpg",
	PrefabName = "Rpg_13_dashouxiaodi",
	SkinName = "1",
	PrefabScale = 50,
	HPBarHeight = 105,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 635, Gain = 127},
		{Value = 200002, Base = 30, Gain = 6},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id5004] =
{
	Id = 5004,
	Name = "精灵工匠",
	Rarity = 2,
	Element = 210002,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "铁匠打出的铁无可挑剔，唯一的问题就是没有运输工具。为此铁匠学会了套鹿的技能。套了100头鹿后，铁匠创立了顺鹿快递拉货公司。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	IconName = "Rpg_31_tiejiang_cos10",
	PrefabBundle = "character_rpg",
	PrefabName = "Rpg_31_tiejiang",
	SkinName = "2",
	PrefabScale = 50,
	HPBarHeight = 140,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 847, Gain = 170},
		{Value = 200002, Base = 40, Gain = 8},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id5005] =
{
	Id = 5005,
	Name = "中陷阱的白狼",
	Rarity = 2,
	Element = 210004,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "狼群的领袖，与众不同的颜色给人以强烈的压迫感。比较挑食，只接受带肉的骨头。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	IconName = "RPG_WhiteWolf",
	PrefabBundle = "character_enemy",
	PrefabName = "RPG_WhiteWolf",
	PrefabScale = 50,
	HPBarHeight = 102,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 847, Gain = 170},
		{Value = 200002, Base = 40, Gain = 8},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id5006] =
{
	Id = 5006,
	Name = "同族的面试者",
	Rarity = 2,
	Element = 210005,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "魔王有限公司临时雇员，即使被拆散了也能很快拼回去，是地城副本中很重要的成员。\n不过偶尔会发生重新拼装时，多出一些骨头的问题。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	IconName = "Rpg_30_kulou",
	PrefabBundle = "character_rpg",
	PrefabName = "Rpg_30_kulou",
	SkinName = "1",
	PrefabScale = 50,
	HPBarHeight = 105,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 847, Gain = 170},
		{Value = 200002, Base = 40, Gain = 8},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id5007] =
{
	Id = 5007,
	Name = "钢铁刺毛怪",
	Rarity = 2,
	Element = 210005,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "年龄超过两百岁的超级刺毛怪，身上的钢针带有令人麻痹的毒液，是令人无法靠近的存在。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	IconName = "RPG_BigSeaUrchin",
	PrefabBundle = "character_enemy",
	PrefabName = "RPG_BigSeaUrchin",
	PrefabScale = 50,
	HPBarHeight = 102,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 847, Gain = 170},
		{Value = 200002, Base = 40, Gain = 8},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id5008] =
{
	Id = 5008,
	Name = "勇者们的律师",
	Rarity = 2,
	Element = 210003,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "背负着被告所有希望的悬疑星上班族，根据表面上的证据往往能得出不同结论，帮助被告脱罪，顺带把证人席上的某人定罪。\n“上了证人席，你还想跑？”",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	IconName = "Sus_13_lvshi",
	PrefabBundle = "character_sus",
	PrefabName = "Sus_13_lvshi",
	SkinName = "1",
	PrefabScale = 50,
	HPBarHeight = 112,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 847, Gain = 170},
		{Value = 200002, Base = 40, Gain = 8},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id5009] =
{
	Id = 5009,
	Name = "勇者",
	Rarity = 3,
	Element = 210002,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "自称为冒险星的主角，身负打败魔王以及为世界带来和平的重任。虽然帮助村民不求回报，但缺物资时，会以正义之名进入NPC家中取走合用的财物。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	IconName = "Rpg_05_jianshi",
	PrefabBundle = "character_rpg",
	PrefabName = "Rpg_05_jianshi",
	SkinName = "1",
	PrefabScale = 50,
	HPBarHeight = 105,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 876, Gain = 176},
		{Value = 200002, Base = 41, Gain = 9},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id5010] =
{
	Id = 5010,
	Name = "魔法学院院长",
	Rarity = 3,
	Element = 210002,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "历代勇者的专用服装，每次穿上前会播放近1分钟的特效，如果遇到不讲规矩的敌人，那么变身过程中就会被揍得鼻青脸肿。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	IconName = "Rpg_20_laoyeye_cos10",
	PrefabBundle = "character_rpg",
	PrefabName = "Rpg_20_laoyeye",
	SkinName = "2",
	PrefabScale = 50,
	HPBarHeight = 150,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 876, Gain = 176},
		{Value = 200002, Base = 41, Gain = 9},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id5011] =
{
	Id = 5011,
	Name = "贪婪的勇者",
	Rarity = 1,
	Element = 210003,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "冒险星人气NPC，拥有没人见过的非凡实力。卖出去1000块的道具，下一秒就是100块的回收价，却没有谁敢和他们吵架。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	IconName = "Rpg_14_lvxingshangren",
	PrefabBundle = "character_rpg",
	PrefabName = "Rpg_14_lvxingshangren",
	SkinName = "1",
	PrefabScale = 50,
	HPBarHeight = 105,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 941, Gain = 189},
		{Value = 200002, Base = 44, Gain = 9},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id5012] =
{
	Id = 5012,
	Name = "交任务没奖励",
	Rarity = 1,
	Element = 210005,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "藏在暗处的异生物，随星球创造而生。内部有严格的等级制度，普通霸格偶尔被看到也会被无视，高危霸格反而每天都要担心被除虫者干掉。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	IconName = "Rpg_28_bug",
	PrefabBundle = "character_rpg",
	PrefabName = "Rpg_28_bug",
	SkinName = "1",
	PrefabScale = 50,
	HPBarHeight = 105,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 941, Gain = 189},
		{Value = 200002, Base = 44, Gain = 9},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id5013] =
{
	Id = 5013,
	Name = "交任务报错",
	Rarity = 1,
	Element = 210005,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "藏在暗处的异生物，随星球创造而生。内部有严格的等级制度，普通霸格偶尔被看到也会被无视，高危霸格反而每天都要担心被除虫者干掉。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	IconName = "Rpg_28_bug",
	PrefabBundle = "character_rpg",
	PrefabName = "Rpg_28_bug",
	SkinName = "1",
	PrefabScale = 50,
	HPBarHeight = 105,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 941, Gain = 189},
		{Value = 200002, Base = 44, Gain = 9},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id5014] =
{
	Id = 5014,
	Name = "无照医生",
	Rarity = 2,
	Element = 210001,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "穿着特制工作服的法医，包揽了悬疑星所有的法医及法证工作，经常出入于凶案现场，负责处理各种现场证物。",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	IconName = "Sus_04_fayi",
	PrefabBundle = "character_sus",
	PrefabName = "Sus_04_fayi",
	SkinName = "1",
	PrefabScale = 50,
	HPBarHeight = 123,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 847, Gain = 170},
		{Value = 200002, Base = 40, Gain = 8},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id5015] =
{
	Id = 5015,
	Name = "抓小贩的警察",
	Rarity = 2,
	Element = 210002,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "豆豆警官击败黑警长后在组织中建立的新身份。此后，他将以黑警长的身份继续深入调查组织内部的罪恶秘密，希望有一天能够将组织彻底捣毁。",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	IconName = "Sus_05_jingcha_cos10",
	PrefabBundle = "character_sus",
	PrefabName = "Sus_05_jingcha",
	SkinName = "2",
	PrefabScale = 50,
	HPBarHeight = 145,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 847, Gain = 170},
		{Value = 200002, Base = 40, Gain = 8},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id5016] =
{
	Id = 5016,
	Name = "村庄铁匠",
	Rarity = 2,
	Element = 210002,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "冒险星人气NPC，提供装备买卖、修理、强化等服务，是勇者不可或缺的好帮手。\n“哎呀，手一滑装备爆炸了，阁下运气不太好噢~”",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	IconName = "Rpg_31_tiejiang",
	PrefabBundle = "character_rpg",
	PrefabName = "Rpg_31_tiejiang",
	SkinName = "1",
	PrefabScale = 50,
	HPBarHeight = 115,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 847, Gain = 170},
		{Value = 200002, Base = 40, Gain = 8},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id5017] =
{
	Id = 5017,
	Name = "狡猾的异虫",
	Rarity = 2,
	Element = 210005,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "藏在暗处的异生物，随星球创造而生。内部有严格的等级制度，普通霸格偶尔被看到也会被无视，高危霸格反而每天都要担心被除虫者干掉。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	IconName = "Rpg_28_bug",
	PrefabBundle = "character_rpg",
	PrefabName = "Rpg_28_bug",
	SkinName = "1",
	PrefabScale = 50,
	HPBarHeight = 105,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 847, Gain = 170},
		{Value = 200002, Base = 40, Gain = 8},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id5018] =
{
	Id = 5018,
	Name = "认真的程序猿",
	Rarity = 2,
	Element = 210003,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "神秘组织成员，创造世界并维持运作。平时要和名为“项目经理”的生物磋商星球改造方案，同时清理霸格。\n“你们这样搞，这个月肯定上不了线的。”",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	IconName = "Rpg_01_chengxuyuan",
	PrefabBundle = "character_rpg",
	PrefabName = "Rpg_01_chengxuyuan",
	SkinName = "1",
	PrefabScale = 50,
	HPBarHeight = 105,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 847, Gain = 170},
		{Value = 200002, Base = 40, Gain = 8},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id5019] =
{
	Id = 5019,
	Name = "西部神枪手",
	Rarity = 3,
	Element = 210002,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "遥远世界的传奇枪手。在那个混乱的年代，他用他的正义与善良惩戒了邪恶，维护了正义。胆敢在他面前放肆的人，就要有身上多出几个窟窿的觉悟。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	IconName = "Rpg_26_huoqiangshou_cos10",
	PrefabBundle = "character_rpg",
	PrefabName = "Rpg_26_huoqiangshou",
	SkinName = "2",
	PrefabScale = 50,
	HPBarHeight = 135,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 876, Gain = 176},
		{Value = 200002, Base = 41, Gain = 9},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id5020] =
{
	Id = 5020,
	Name = "超灵敏摄像头",
	Rarity = 3,
	Element = 210004,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "能够把路人脸上的毛孔都拍得一清二楚的高级摄像头，可他们又忘了加麦克风。",
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "MUS",
	IconName = "MUS_Camera",
	PrefabBundle = "character_enemy",
	PrefabName = "MUS_Camera",
	PrefabScale = 50,
	HPBarHeight = 110,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 876, Gain = 176},
		{Value = 200002, Base = 41, Gain = 9},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id5021] =
{
	Id = 5021,
	Name = "吸血鬼猎人",
	Rarity = 3,
	Element = 210003,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "冒险世界中神秘又强大的组织，猎魔人以消灭企图摧毁世界的恶魔为己任，无论敌人多么强大，他们都不会后退一步，除非朋友们约他先打一局昆特牌。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	IconName = "Rpg_16_lieren_cos10",
	PrefabBundle = "character_rpg",
	PrefabName = "Rpg_16_lieren",
	SkinName = "2",
	PrefabScale = 50,
	HPBarHeight = 140,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 876, Gain = 176},
		{Value = 200002, Base = 41, Gain = 9},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id5022] =
{
	Id = 5022,
	Name = "动画模特",
	Rarity = 3,
	Element = 210005,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "魔王有限公司临时雇员，即使被拆散了也能很快拼回去，是地城副本中很重要的成员。\n不过偶尔会发生重新拼装时，多出一些骨头的问题。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	IconName = "Rpg_30_kulou",
	PrefabBundle = "character_rpg",
	PrefabName = "Rpg_30_kulou",
	SkinName = "1",
	PrefabScale = 50,
	HPBarHeight = 105,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 876, Gain = 176},
		{Value = 200002, Base = 41, Gain = 9},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id5023] =
{
	Id = 5023,
	Name = "呐喊家",
	Rarity = 3,
	Element = 210003,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "很久很久以前，一位画家为想要呐喊之人而作的画。流传至今变成了一个流行的表情。",
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "Mus",
	IconName = "MUS_19_nahan",
	PrefabBundle = "character_mus",
	PrefabName = "MUS_19_nahan",
	SkinName = "1",
	PrefabScale = 50,
	HPBarHeight = 115,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 876, Gain = 176},
		{Value = 200002, Base = 41, Gain = 9},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id5024] =
{
	Id = 5024,
	Name = "超断流师兄",
	Rarity = 3,
	Element = 210001,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "来自东方世界的武士蜡像，无论处于什么时代都坚持以手中的刀作为武器。即使被机关枪扫射，也能够将射来的子弹全部一劈为二。\n当他认真时，你的头上会出现红色的“危”字。",
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "Mus",
	IconName = "MUS_09_ribenwushi",
	PrefabBundle = "character_mus",
	PrefabName = "MUS_09_ribenwushi",
	SkinName = "1",
	PrefabScale = 50,
	HPBarHeight = 115,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 876, Gain = 176},
		{Value = 200002, Base = 41, Gain = 9},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id5025] =
{
	Id = 5025,
	Name = "苹狗",
	Rarity = 3,
	Element = 210003,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "营养丰富的苹狗，身体是健康的红色。最大的梦想是进化成传说中的物种——芒狗。",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "FAT",
	IconName = "FAT_Apple",
	PrefabBundle = "character_enemy",
	PrefabName = "FAT_Apple",
	PrefabScale = 50,
	HPBarHeight = 97,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 876, Gain = 176},
		{Value = 200002, Base = 41, Gain = 9},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id5026] =
{
	Id = 5026,
	Name = "黑龙王子",
	Rarity = 4,
	Element = 210005,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "龙族指定的接班人，喜欢假扮人类去城堡或村子里吃烤肉，高兴时会露出尾巴。最近不知道为什么，好像正在学习怎么和女孩子相处的样子。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	IconName = "Rpg_23_long",
	PrefabBundle = "character_rpg",
	PrefabName = "Rpg_23_long",
	SkinName = "1",
	PrefabScale = 50,
	HPBarHeight = 105,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 813, Gain = 163},
		{Value = 200002, Base = 38, Gain = 8},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id5027] =
{
	Id = 5027,
	Name = "游戏达人",
	Rarity = 4,
	Element = 210001,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "蓝星著名的高中生侦探的远房表弟，本来是初中生，因意外变成小学生。这个意外听上去是那么得不可思议，但不知为何大家都是以一幅理解的表情表示释然。",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	IconName = "Sus_20_lanyixiaoxuesheng",
	PrefabBundle = "character_sus",
	PrefabName = "Sus_20_lanyixiaoxuesheng",
	SkinName = "1",
	PrefabScale = 50,
	HPBarHeight = 112,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 813, Gain = 163},
		{Value = 200002, Base = 38, Gain = 8},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id5028] =
{
	Id = 5028,
	Name = "宠物商人",
	Rarity = 4,
	Element = 210003,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "冒险星人气NPC，拥有没人见过的非凡实力。卖出去1000块的道具，下一秒就是100块的回收价，却没有谁敢和他们吵架。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	IconName = "Rpg_14_lvxingshangren",
	PrefabBundle = "character_rpg",
	PrefabName = "Rpg_14_lvxingshangren",
	SkinName = "1",
	PrefabScale = 50,
	HPBarHeight = 105,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 813, Gain = 163},
		{Value = 200002, Base = 38, Gain = 8},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id5029] =
{
	Id = 5029,
	Name = "编剧",
	Rarity = 5,
	Element = 210001,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "名动悬疑星的大作家，笔下创作了绝对经典的侦探形象，为后世侦探小说定下了完美范本。其本人更是后世无数侦探的偶像。",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	IconName = "Sus_20_lanyixiaoxuesheng_cos10",
	PrefabBundle = "character_sus",
	PrefabName = "Sus_20_lanyixiaoxuesheng",
	SkinName = "2",
	PrefabScale = 50,
	HPBarHeight = 130,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 765, Gain = 153},
		{Value = 200002, Base = 36, Gain = 8},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id5030] =
{
	Id = 5030,
	Name = "编剧",
	Rarity = 5,
	Element = 210001,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "名动悬疑星的大作家，笔下创作了绝对经典的侦探形象，为后世侦探小说定下了完美范本。其本人更是后世无数侦探的偶像。",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	IconName = "Sus_20_lanyixiaoxuesheng_cos10",
	PrefabBundle = "character_sus",
	PrefabName = "Sus_20_lanyixiaoxuesheng",
	SkinName = "2",
	PrefabScale = 50,
	HPBarHeight = 130,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 693, Gain = 139},
		{Value = 200002, Base = 33, Gain = 7},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id5031] =
{
	Id = 5031,
	Name = "薯片夫人",
	Rarity = 3,
	Element = 210003,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "甜品镇的贵妇人，著名深夜节目主持人，访谈对象都是各国王室成员，加班太晚的时候会睡在抽屉式的罐头里。",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	IconName = "Fat_19_shupian",
	PrefabBundle = "character_fat",
	PrefabName = "Fat_19_shupian",
	SkinName = "1",
	PrefabScale = 50,
	HPBarHeight = 117,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 876, Gain = 176},
		{Value = 200002, Base = 41, Gain = 9},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id5032] =
{
	Id = 5032,
	Name = "汉堡小姐",
	Rarity = 3,
	Element = 210002,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "快餐街上最受欢迎的汉堡小姐，每次自拍都会使用美颜软件，并附上“一切以实物为准”……令看照片的人心情很复杂。",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	IconName = "Fat_29_hanbao",
	PrefabBundle = "character_fat",
	PrefabName = "Fat_29_hanbao",
	SkinName = "1",
	PrefabScale = 50,
	HPBarHeight = 99,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 876, Gain = 176},
		{Value = 200002, Base = 41, Gain = 9},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id5033] =
{
	Id = 5033,
	Name = "配音演员",
	Rarity = 3,
	Element = 210003,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "神秘组织成员，听说是前偶像歌手。歌唱事业达到瓶颈后尝试了配音工作，然后成功转型。职业病上身的她有时会在战斗中替被殴打的怪物惨叫。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	IconName = "Rpg_15_peiyinyanyuan",
	PrefabBundle = "character_rpg",
	PrefabName = "Rpg_15_peiyinyanyuan",
	SkinName = "1",
	PrefabScale = 50,
	HPBarHeight = 115,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 876, Gain = 176},
		{Value = 200002, Base = 41, Gain = 9},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id5034] =
{
	Id = 5034,
	Name = "调酒师",
	Rarity = 3,
	Element = 210001,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "年轻帅气的调酒师，其娴熟的技术和磁性的声线深受各种美女欢迎。从他这里可以拿到很多不容易获取的情报，但必需点一杯价格不菲的掺水威士忌。",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	IconName = "Sus_23_tiaojiushi",
	PrefabBundle = "character_sus",
	PrefabName = "Sus_23_tiaojiushi",
	SkinName = "1",
	PrefabScale = 50,
	HPBarHeight = 112,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 876, Gain = 176},
		{Value = 200002, Base = 41, Gain = 9},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id5035] =
{
	Id = 5035,
	Name = "红色史莱姆",
	Rarity = 1,
	Element = 210002,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "体内带有大量红色素的小精灵，喜欢捡冒险者丢掉的东西，被它碰到的东西就会被染成红色，但如果碰到蓝色史莱姆就会染成紫色。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	IconName = "RPG_Slime_red",
	PrefabBundle = "character_enemy",
	PrefabName = "RPG_Slime_red",
	PrefabScale = 50,
	HPBarHeight = 69,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 470, Gain = 94},
		{Value = 200002, Base = 44, Gain = 9},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id5036] =
{
	Id = 5036,
	Name = "红色史莱姆",
	Rarity = 1,
	Element = 210002,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "体内带有大量红色素的小精灵，喜欢捡冒险者丢掉的东西，被它碰到的东西就会被染成红色，但如果碰到蓝色史莱姆就会染成紫色。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	IconName = "RPG_Slime_red",
	PrefabBundle = "character_enemy",
	PrefabName = "RPG_Slime_red",
	PrefabScale = 50,
	HPBarHeight = 69,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 470, Gain = 94},
		{Value = 200002, Base = 44, Gain = 9},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id5037] =
{
	Id = 5037,
	Name = "红色史莱姆",
	Rarity = 1,
	Element = 210002,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "体内带有大量红色素的小精灵，喜欢捡冒险者丢掉的东西，被它碰到的东西就会被染成红色，但如果碰到蓝色史莱姆就会染成紫色。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	IconName = "RPG_Slime_red",
	PrefabBundle = "character_enemy",
	PrefabName = "RPG_Slime_red",
	PrefabScale = 50,
	HPBarHeight = 69,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 376, Gain = 76},
		{Value = 200002, Base = 44, Gain = 9},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id5038] =
{
	Id = 5038,
	Name = "红色史莱姆",
	Rarity = 1,
	Element = 210002,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "体内带有大量红色素的小精灵，喜欢捡冒险者丢掉的东西，被它碰到的东西就会被染成红色，但如果碰到蓝色史莱姆就会染成紫色。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	IconName = "RPG_Slime_red",
	PrefabBundle = "character_enemy",
	PrefabName = "RPG_Slime_red",
	PrefabScale = 50,
	HPBarHeight = 69,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 376, Gain = 76},
		{Value = 200002, Base = 44, Gain = 9},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id5039] =
{
	Id = 5039,
	Name = "绿色史莱姆",
	Rarity = 1,
	Element = 210003,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "体内带有大量绿色素的小精灵，喜欢捡冒险者丢掉的东西，被它碰到的东西就会被染成绿色，不要丢下帽子。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	IconName = "RPG_Slime_green",
	PrefabBundle = "character_enemy",
	PrefabName = "RPG_Slime_green",
	PrefabScale = 50,
	HPBarHeight = 69,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 376, Gain = 76},
		{Value = 200002, Base = 44, Gain = 9},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id5040] =
{
	Id = 5040,
	Name = "红色史莱姆",
	Rarity = 1,
	Element = 210002,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "体内带有大量红色素的小精灵，喜欢捡冒险者丢掉的东西，被它碰到的东西就会被染成红色，但如果碰到蓝色史莱姆就会染成紫色。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	IconName = "RPG_Slime_red",
	PrefabBundle = "character_enemy",
	PrefabName = "RPG_Slime_red",
	PrefabScale = 50,
	HPBarHeight = 69,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 470, Gain = 94},
		{Value = 200002, Base = 44, Gain = 9},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id5041] =
{
	Id = 5041,
	Name = "绿色史莱姆",
	Rarity = 1,
	Element = 210003,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "体内带有大量绿色素的小精灵，喜欢捡冒险者丢掉的东西，被它碰到的东西就会被染成绿色，不要丢下帽子。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	IconName = "RPG_Slime_green",
	PrefabBundle = "character_enemy",
	PrefabName = "RPG_Slime_green",
	PrefabScale = 50,
	HPBarHeight = 69,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 470, Gain = 94},
		{Value = 200002, Base = 44, Gain = 9},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id5042] =
{
	Id = 5042,
	Name = "绿色史莱姆",
	Rarity = 1,
	Element = 210003,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "体内带有大量绿色素的小精灵，喜欢捡冒险者丢掉的东西，被它碰到的东西就会被染成绿色，不要丢下帽子。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	IconName = "RPG_Slime_green",
	PrefabBundle = "character_enemy",
	PrefabName = "RPG_Slime_green",
	PrefabScale = 50,
	HPBarHeight = 69,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 470, Gain = 94},
		{Value = 200002, Base = 44, Gain = 9},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id5043] =
{
	Id = 5043,
	Name = "绿色史莱姆",
	Rarity = 1,
	Element = 210003,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "体内带有大量绿色素的小精灵，喜欢捡冒险者丢掉的东西，被它碰到的东西就会被染成绿色，不要丢下帽子。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	IconName = "RPG_Slime_green",
	PrefabBundle = "character_enemy",
	PrefabName = "RPG_Slime_green",
	PrefabScale = 50,
	HPBarHeight = 69,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 470, Gain = 94},
		{Value = 200002, Base = 44, Gain = 9},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id5044] =
{
	Id = 5044,
	Name = "绿色史莱姆",
	Rarity = 1,
	Element = 210003,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "体内带有大量绿色素的小精灵，喜欢捡冒险者丢掉的东西，被它碰到的东西就会被染成绿色，不要丢下帽子。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	IconName = "RPG_Slime_green",
	PrefabBundle = "character_enemy",
	PrefabName = "RPG_Slime_green",
	PrefabScale = 50,
	HPBarHeight = 69,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 470, Gain = 94},
		{Value = 200002, Base = 44, Gain = 9},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id5045] =
{
	Id = 5045,
	Name = "蓝色史莱姆",
	Rarity = 1,
	Element = 210001,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "体内带有大量蓝色素的小精灵，喜欢捡冒险者丢掉的东西，被它碰到的东西就会被染成蓝色。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	IconName = "RPG_Slime_blue",
	PrefabBundle = "character_enemy",
	PrefabName = "RPG_Slime_blue",
	PrefabScale = 50,
	HPBarHeight = 69,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 470, Gain = 94},
		{Value = 200002, Base = 44, Gain = 9},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id5046] =
{
	Id = 5046,
	Name = "蓝色史莱姆",
	Rarity = 1,
	Element = 210001,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "体内带有大量蓝色素的小精灵，喜欢捡冒险者丢掉的东西，被它碰到的东西就会被染成蓝色。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	IconName = "RPG_Slime_blue",
	PrefabBundle = "character_enemy",
	PrefabName = "RPG_Slime_blue",
	PrefabScale = 50,
	HPBarHeight = 69,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 470, Gain = 94},
		{Value = 200002, Base = 44, Gain = 9},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id5047] =
{
	Id = 5047,
	Name = "蓝色史莱姆",
	Rarity = 1,
	Element = 210001,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "体内带有大量蓝色素的小精灵，喜欢捡冒险者丢掉的东西，被它碰到的东西就会被染成蓝色。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	IconName = "RPG_Slime_blue",
	PrefabBundle = "character_enemy",
	PrefabName = "RPG_Slime_blue",
	PrefabScale = 50,
	HPBarHeight = 69,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 470, Gain = 94},
		{Value = 200002, Base = 44, Gain = 9},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id5048] =
{
	Id = 5048,
	Name = "红色史莱姆",
	Rarity = 1,
	Element = 210002,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "体内带有大量红色素的小精灵，喜欢捡冒险者丢掉的东西，被它碰到的东西就会被染成红色，但如果碰到蓝色史莱姆就会染成紫色。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	IconName = "RPG_Slime_red",
	PrefabBundle = "character_enemy",
	PrefabName = "RPG_Slime_red",
	PrefabScale = 50,
	HPBarHeight = 69,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 470, Gain = 94},
		{Value = 200002, Base = 44, Gain = 9},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id5049] =
{
	Id = 5049,
	Name = "蓝色史莱姆",
	Rarity = 1,
	Element = 210001,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "体内带有大量蓝色素的小精灵，喜欢捡冒险者丢掉的东西，被它碰到的东西就会被染成蓝色。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	IconName = "RPG_Slime_blue",
	PrefabBundle = "character_enemy",
	PrefabName = "RPG_Slime_blue",
	PrefabScale = 50,
	HPBarHeight = 69,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 470, Gain = 94},
		{Value = 200002, Base = 44, Gain = 9},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id5050] =
{
	Id = 5050,
	Name = "行李车",
	Rarity = 2,
	Element = 210002,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "旅店运送行李的工具，这辆车本身并不是行李。",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "SUS",
	IconName = "SUS_Luggage",
	PrefabBundle = "character_enemy",
	PrefabName = "SUS_Luggage",
	PrefabScale = 50,
	HPBarHeight = 130,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 847, Gain = 170},
		{Value = 200002, Base = 40, Gain = 8},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id5051] =
{
	Id = 5051,
	Name = "化掉的克林姆",
	Rarity = 2,
	Element = 210001,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "香草味的冰淇淋，加入了牛奶和香草粉制作而成，即使化开来味道也依然很好。性格热情开朗，一直渴望着一份火热的爱情。",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "FAT",
	IconName = "FAT_IceCream",
	PrefabBundle = "character_enemy",
	PrefabName = "FAT_IceCream",
	PrefabScale = 50,
	HPBarHeight = 89,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 847, Gain = 170},
		{Value = 200002, Base = 40, Gain = 8},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id5052] =
{
	Id = 5052,
	Name = "远古的美味蛋",
	Rarity = 2,
	Element = 210003,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "第二世代时生活在雨林地区的双足龙，走起来速度十分惊人，但是因为名字而不能奔跑。",
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "MUS",
	IconName = "MUS_DinosaurEgg",
	PrefabBundle = "character_enemy",
	PrefabName = "MUS_DinosaurEgg",
	PrefabScale = 50,
	HPBarHeight = 110,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 847, Gain = 170},
		{Value = 200002, Base = 40, Gain = 8},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id5053] =
{
	Id = 5053,
	Name = "醉人的男性",
	Rarity = 2,
	Element = 210004,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "这变幻莫测的魔力颜色，究竟是本来的颜色，还是醉了之后心中的幻想呢？",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	IconName = "Fat_09_pijiu_cos10",
	PrefabBundle = "character_fat",
	PrefabName = "Fat_09_pijiu",
	SkinName = "2",
	PrefabScale = 50,
	HPBarHeight = 140,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 847, Gain = 170},
		{Value = 200002, Base = 40, Gain = 8},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id5054] =
{
	Id = 5054,
	Name = "超大布丁怪",
	Rarity = 2,
	Element = 210004,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "撒上了特制焦糖的布丁，走过的地方都会有布丁的香气。在此地居住的居民需要常备胰岛素。",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "FAT",
	IconName = "FAT_Pudding",
	PrefabBundle = "character_enemy",
	PrefabName = "FAT_Pudding",
	PrefabScale = 50,
	HPBarHeight = 89,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 847, Gain = 170},
		{Value = 200002, Base = 40, Gain = 8},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id5055] =
{
	Id = 5055,
	Name = "不懂事的妹妹",
	Rarity = 2,
	Element = 210002,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "薯片夫人的小女儿，本身的香味和各种香料都很契合，因此随身携带着各种口味的调味包。\n最近在学习雷电法术。",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	IconName = "Fat_21_miaocuijiao",
	PrefabBundle = "character_fat",
	PrefabName = "Fat_21_miaocuijiao",
	SkinName = "1",
	PrefabScale = 50,
	HPBarHeight = 106,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 847, Gain = 170},
		{Value = 200002, Base = 40, Gain = 8},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id5056] =
{
	Id = 5056,
	Name = "欺负人的姐姐",
	Rarity = 2,
	Element = 210002,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "薯片夫人的大女儿，渴望成为王子的新娘。身边虽然有不少追求者，不过对方不是王子，她都一律无视。",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	IconName = "Fat_20_xiatiao",
	PrefabBundle = "character_fat",
	PrefabName = "Fat_20_xiatiao",
	SkinName = "1",
	PrefabScale = 50,
	HPBarHeight = 106,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 847, Gain = 170},
		{Value = 200002, Base = 40, Gain = 8},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id5057] =
{
	Id = 5057,
	Name = "香喷喷的培根",
	Rarity = 3,
	Element = 210002,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "星际著名的哲学家、科学家，在诸多学科都有很大贡献，为星际居民所敬仰……然而这跟我培根有什么关系呢？",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "FAT",
	IconName = "FAT_Bacon",
	PrefabBundle = "character_enemy",
	PrefabName = "FAT_Bacon",
	PrefabScale = 50,
	HPBarHeight = 71,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 876, Gain = 176},
		{Value = 200002, Base = 41, Gain = 9},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id5058] =
{
	Id = 5058,
	Name = "土豆之王",
	Rarity = 3,
	Element = 210003,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "热衷健身的美食城国王，每天健身8小时，之后去皇家油锅泡澡8小时，然后睡8小时。肌肉含量120%，用力的话可以撑爆背心。",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	IconName = "Fat_30_shutiao",
	PrefabBundle = "character_fat",
	PrefabName = "Fat_30_shutiao",
	SkinName = "1",
	PrefabScale = 50,
	HPBarHeight = 106,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 876, Gain = 176},
		{Value = 200002, Base = 41, Gain = 9},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id5059] =
{
	Id = 5059,
	Name = "外派程序猿",
	Rarity = 3,
	Element = 210003,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "无论是战争地区还是极端环境，只要对方有需求，外派程序猿就会火速抵达。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	IconName = "Rpg_01_chengxuyuan_cos10",
	PrefabBundle = "character_rpg",
	PrefabName = "Rpg_01_chengxuyuan",
	SkinName = "2",
	PrefabScale = 50,
	HPBarHeight = 135,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 876, Gain = 176},
		{Value = 200002, Base = 41, Gain = 9},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id5060] =
{
	Id = 5060,
	Name = "烤棉糖爱好者",
	Rarity = 3,
	Element = 210005,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "凝聚了自然与魔法力量的仙子法袍，仿佛具有生命一般，能够保护穿戴者。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	IconName = "Rpg_06_mofashi_cos10",
	PrefabBundle = "character_rpg",
	PrefabName = "Rpg_06_mofashi",
	SkinName = "2",
	PrefabScale = 50,
	HPBarHeight = 145,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 876, Gain = 176},
		{Value = 200002, Base = 41, Gain = 9},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id5061] =
{
	Id = 5061,
	Name = "送果篮的皇后",
	Rarity = 3,
	Element = 210005,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "冰淇淋公主的继母，非常在意市面上的畅销冷饮排行榜。每天都会查询若干次榜单，有时候为了第一，还会找人刷榜。",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	IconName = "Fat_11_tiantong",
	PrefabBundle = "character_fat",
	PrefabName = "Fat_11_tiantong",
	SkinName = "1",
	PrefabScale = 50,
	HPBarHeight = 114,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 876, Gain = 176},
		{Value = 200002, Base = 41, Gain = 9},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id5062] =
{
	Id = 5062,
	Name = "严厉的家长",
	Rarity = 3,
	Element = 210003,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "甜品镇的贵妇人，著名深夜节目主持人，访谈对象都是各国王室成员，加班太晚的时候会睡在抽屉式的罐头里。",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	IconName = "Fat_19_shupian",
	PrefabBundle = "character_fat",
	PrefabName = "Fat_19_shupian",
	SkinName = "1",
	PrefabScale = 50,
	HPBarHeight = 117,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 876, Gain = 176},
		{Value = 200002, Base = 41, Gain = 9},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id5063] =
{
	Id = 5063,
	Name = "搞事情的女巫",
	Rarity = 3,
	Element = 210002,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "腌制超过一百年的女巫，对于打理柔软的事物很有一手，因此被聘请照顾栗子慕斯公主的头发。在此后漫长的岁月里，如同大姐姐一般照顾着公主，给予了公主最好的陪伴。",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	IconName = "Fat_23_peigen",
	PrefabBundle = "character_fat",
	PrefabName = "Fat_23_peigen",
	SkinName = "1",
	PrefabScale = 50,
	HPBarHeight = 106,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 876, Gain = 176},
		{Value = 200002, Base = 41, Gain = 9},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id5064] =
{
	Id = 5064,
	Name = "高档的猪肉",
	Rarity = 3,
	Element = 210002,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "美食星特有的豚类，会定时产出美味的腌制火腿，很受烤肉店欢迎，至于产出过程……",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "FAT",
	IconName = "FAT_HamPig",
	PrefabBundle = "character_enemy",
	PrefabName = "FAT_HamPig",
	PrefabScale = 50,
	HPBarHeight = 110,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 876, Gain = 176},
		{Value = 200002, Base = 41, Gain = 9},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id5065] =
{
	Id = 5065,
	Name = "芥末爱好者",
	Rarity = 3,
	Element = 210004,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "采用了最高级的鱼背肉部位作为食材的寿司精灵，日常散步时经常让路人产生吃它的冲动。\n龟龟，这不就是米饭吗？",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "FAT",
	IconName = "FAT_SalmonSushi",
	PrefabBundle = "character_enemy",
	PrefabName = "FAT_SalmonSushi",
	PrefabScale = 50,
	HPBarHeight = 75,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 876, Gain = 176},
		{Value = 200002, Base = 41, Gain = 9},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id5066] =
{
	Id = 5066,
	Name = "薯条国王",
	Rarity = 3,
	Element = 210003,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "热衷健身的美食城国王，每天健身8小时，之后去皇家油锅泡澡8小时，然后睡8小时。肌肉含量120%，用力的话可以撑爆背心。",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	IconName = "Fat_30_shutiao",
	PrefabBundle = "character_fat",
	PrefabName = "Fat_30_shutiao",
	SkinName = "1",
	PrefabScale = 50,
	HPBarHeight = 106,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 876, Gain = 176},
		{Value = 200002, Base = 41, Gain = 9},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id5067] =
{
	Id = 5067,
	Name = "优质果木",
	Rarity = 4,
	Element = 210003,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "憨直的大树怪，结出的果实美味可口，听说还帮助科学家发现了万有引力。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	IconName = "RPG_dashu",
	PrefabBundle = "character_enemy",
	PrefabName = "RPG_dashu",
	PrefabScale = 50,
	HPBarHeight = 141,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 813, Gain = 163},
		{Value = 200002, Base = 38, Gain = 8},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id5068] =
{
	Id = 5068,
	Name = "影院的吉祥物",
	Rarity = 4,
	Element = 210005,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "教授的睡衣套装，和大侦探与侦探助理进行枕头大战的指定套装，玩累了以后，可以直接倒下来睡觉。",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	IconName = "Sus_03_moliyadi_cos20",
	PrefabBundle = "character_sus",
	PrefabName = "Sus_03_moliyadi",
	SkinName = "3",
	PrefabScale = 50,
	HPBarHeight = 140,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 813, Gain = 163},
		{Value = 200002, Base = 38, Gain = 8},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id5069] =
{
	Id = 5069,
	Name = "皇家健身教练",
	Rarity = 5,
	Element = 210001,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "国王御用侍卫，从小陪伴薯条国王长大。能根据薯条国王的状态，时刻调整自己的甜度，深得薯条国王信赖。每次战后他都会在第一时间被送往医院，尽管大部分时候只是包装袋破了。",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	IconName = "Fat_31_fanqiejiang",
	PrefabBundle = "character_fat",
	PrefabName = "Fat_31_fanqiejiang",
	SkinName = "1",
	PrefabScale = 50,
	HPBarHeight = 106,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 765, Gain = 153},
		{Value = 200002, Base = 36, Gain = 8},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id5070] =
{
	Id = 5070,
	Name = "特制铁饼",
	Rarity = 5,
	Element = 210005,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "勤恳踏实的底层员工，最大的梦想是有朝一日不被人踩在脸上。",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "SUS",
	IconName = "SUS_ManholeCover",
	PrefabBundle = "character_enemy",
	PrefabName = "SUS_ManholeCover",
	PrefabScale = 50,
	HPBarHeight = 100,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 693, Gain = 139},
		{Value = 200002, Base = 33, Gain = 7},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id5071] =
{
	Id = 5071,
	Name = "偷保暖杯的人",
	Rarity = 3,
	Element = 210002,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "特别喜欢参观博物馆的小浣熊，但每次都会因为没买票被拦在门外。他对此很气愤，因为自己有学生证，根本不需要买票。",
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "Mus",
	IconName = "MUS_13_dage",
	PrefabBundle = "character_mus",
	PrefabName = "MUS_13_dage",
	SkinName = "1",
	PrefabScale = 50,
	HPBarHeight = 115,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 876, Gain = 176},
		{Value = 200002, Base = 41, Gain = 9},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id5072] =
{
	Id = 5072,
	Name = "风衣专卖员",
	Rarity = 3,
	Element = 210004,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "前任大侦探老福的孙子，继承了爷爷的意志，经常帮助警局侦办悬疑案件。既是警局救星，也是警局克星。",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	IconName = "Sus_01_fuermosi_cat",
	PrefabBundle = "character_sus",
	PrefabName = "Sus_01_fuermosi",
	SkinName = "1_cat",
	PrefabScale = 50,
	HPBarHeight = 145,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 876, Gain = 176},
		{Value = 200002, Base = 41, Gain = 9},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id5073] =
{
	Id = 5073,
	Name = "知名寻宝者",
	Rarity = 3,
	Element = 210001,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "成天被勇者掳走家里的东西，终于决定自己成为一名勇者出去掠夺别人。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	IconName = "Rpg_09_putongcunmin_cos10",
	PrefabBundle = "character_rpg",
	PrefabName = "Rpg_09_putongcunmin",
	SkinName = "2",
	PrefabScale = 50,
	HPBarHeight = 135,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 876, Gain = 176},
		{Value = 200002, Base = 41, Gain = 9},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id5074] =
{
	Id = 5074,
	Name = "知名寻宝者",
	Rarity = 3,
	Element = 210001,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "成天被勇者掳走家里的东西，终于决定自己成为一名勇者出去掠夺别人。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	IconName = "Rpg_09_putongcunmin_cos10",
	PrefabBundle = "character_rpg",
	PrefabName = "Rpg_09_putongcunmin",
	SkinName = "2",
	PrefabScale = 50,
	HPBarHeight = 135,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 876, Gain = 176},
		{Value = 200002, Base = 41, Gain = 9},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id5075] =
{
	Id = 5075,
	Name = "知名寻宝者",
	Rarity = 3,
	Element = 210001,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "成天被勇者掳走家里的东西，终于决定自己成为一名勇者出去掠夺别人。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	IconName = "Rpg_09_putongcunmin_cos10",
	PrefabBundle = "character_rpg",
	PrefabName = "Rpg_09_putongcunmin",
	SkinName = "2",
	PrefabScale = 50,
	HPBarHeight = 135,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 876, Gain = 176},
		{Value = 200002, Base = 41, Gain = 9},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id5076] =
{
	Id = 5076,
	Name = "泳装女孩",
	Rarity = 1,
	Element = 210001,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "展现少女完美身姿的动感泳装。然而曼妙长裙下却隐藏着完整的强化作战骨骼。即使身着泳装，也能进行高强度格斗。",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	IconName = "Sus_26_xiaotong_cos10",
	PrefabBundle = "character_sus",
	PrefabName = "Sus_26_xiaotong",
	SkinName = "2",
	PrefabScale = 50,
	HPBarHeight = 140,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 941, Gain = 189},
		{Value = 200002, Base = 44, Gain = 9},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id5077] =
{
	Id = 5077,
	Name = "盗墓人",
	Rarity = 1,
	Element = 210001,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "成天被勇者掳走家里的东西，终于决定自己成为一名勇者出去掠夺别人。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	IconName = "Rpg_09_putongcunmin_cos10",
	PrefabBundle = "character_rpg",
	PrefabName = "Rpg_09_putongcunmin",
	SkinName = "2",
	PrefabScale = 50,
	HPBarHeight = 135,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 941, Gain = 189},
		{Value = 200002, Base = 44, Gain = 9},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id5078] =
{
	Id = 5078,
	Name = "美食星的游客",
	Rarity = 1,
	Element = 210002,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "来自深海的优雅礼服，穿在培根女巫身上时，展现出了独特的异国风情。不过，明明三文鱼也有很多脂肪，为什么和培根比却是健康食品呢？",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	IconName = "Fat_23_peigen_cos10",
	PrefabBundle = "character_fat",
	PrefabName = "Fat_23_peigen",
	SkinName = "2",
	PrefabScale = 50,
	HPBarHeight = 125,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 941, Gain = 189},
		{Value = 200002, Base = 44, Gain = 9},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id5079] =
{
	Id = 5079,
	Name = "悬疑星的游客",
	Rarity = 1,
	Element = 210001,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "“姐妹团”中的小妹，活泼可爱。平时躲在咖啡厅后厨研究新装备。时间够的话，火箭也是可以造出来的。",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	IconName = "Sus_27_xiaoai",
	PrefabBundle = "character_sus",
	PrefabName = "Sus_27_xiaoai",
	SkinName = "1",
	PrefabScale = 50,
	HPBarHeight = 112,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 941, Gain = 189},
		{Value = 200002, Base = 44, Gain = 9},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id5080] =
{
	Id = 5080,
	Name = "灵气的名作",
	Rarity = 2,
	Element = 210004,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "根据神话故事绘制的肖像，男孩举起的手指向了天空……\n因为上课时挡住了后面同学看黑板而被骂了好多次。",
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "Mus",
	IconName = "MUS_22_yadang_cat",
	PrefabBundle = "character_mus",
	PrefabName = "MUS_22_yadang",
	SkinName = "1_cat",
	PrefabScale = 50,
	HPBarHeight = 149,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 847, Gain = 170},
		{Value = 200002, Base = 40, Gain = 8},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id5081] =
{
	Id = 5081,
	Name = "圣洁的名作",
	Rarity = 2,
	Element = 210004,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "根据神话故事绘制的肖像，老人举起的手指向了地面……\n因为被误认为挑衅而被打了好多次。",
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "Mus",
	IconName = "MUS_23_chuangzaozhishen_cat",
	PrefabBundle = "character_mus",
	PrefabName = "MUS_23_chuangzaozhishen",
	SkinName = "1_cat",
	PrefabScale = 50,
	HPBarHeight = 149,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 847, Gain = 170},
		{Value = 200002, Base = 40, Gain = 8},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id5082] =
{
	Id = 5082,
	Name = "冒险星的游客",
	Rarity = 2,
	Element = 210003,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "神秘组织成员，为星球增添美丽色彩的仙女。一旦有灵感，就能让星球焕发活力~\n这里有点空空的？嗯，画头咩咩羊，咦？是不是再画条汪汪狗？",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	IconName = "Rpg_03_yuanhuameizi",
	PrefabBundle = "character_rpg",
	PrefabName = "Rpg_03_yuanhuameizi",
	SkinName = "1",
	PrefabScale = 50,
	HPBarHeight = 115,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 847, Gain = 170},
		{Value = 200002, Base = 40, Gain = 8},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id5083] =
{
	Id = 5083,
	Name = "呐喊爱好者",
	Rarity = 2,
	Element = 210003,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "很久很久以前，一位画家为想要呐喊之人而作的画。流传至今变成了一个流行的表情。",
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "Mus",
	IconName = "MUS_19_nahan_cat",
	PrefabBundle = "character_mus",
	PrefabName = "MUS_19_nahan",
	SkinName = "1_cat",
	PrefabScale = 50,
	HPBarHeight = 145,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 847, Gain = 170},
		{Value = 200002, Base = 40, Gain = 8},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id5084] =
{
	Id = 5084,
	Name = "小猪储蓄罐",
	Rarity = 2,
	Element = 210002,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "从遗迹里挖出来的猪形瓷罐，上方的小孔刚好够塞进去一枚铜币，但里面却是空的。",
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "MUS",
	IconName = "MUS_PigJar",
	PrefabBundle = "character_enemy",
	PrefabName = "MUS_PigJar",
	PrefabScale = 50,
	HPBarHeight = 100,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 847, Gain = 170},
		{Value = 200002, Base = 40, Gain = 8},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id5085] =
{
	Id = 5085,
	Name = "工资卡信封",
	Rarity = 2,
	Element = 210003,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "性格有些古怪，经常自言自语，会被周围的人所害怕。\n哦，想出来吗？哈哈！真可惜啊，你是绝对不可能突破我的封锁的！信！",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "SUS",
	IconName = "SUS_Letter",
	PrefabBundle = "character_enemy",
	PrefabName = "SUS_Letter",
	PrefabScale = 50,
	HPBarHeight = 100,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 847, Gain = 170},
		{Value = 200002, Base = 40, Gain = 8},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id5086] =
{
	Id = 5086,
	Name = "悬疑星的游客",
	Rarity = 2,
	Element = 210004,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "公平和正义的代表，手握小锤掌握生杀大权。头顶贵重的假发，不仅可以代表法官的公正无私，还能让人看起来容光焕发，但他的发量却日益减少。",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	IconName = "Sus_14_faguan",
	PrefabBundle = "character_sus",
	PrefabName = "Sus_14_faguan",
	SkinName = "1",
	PrefabScale = 50,
	HPBarHeight = 112,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 847, Gain = 170},
		{Value = 200002, Base = 40, Gain = 8},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id5087] =
{
	Id = 5087,
	Name = "旅行商人",
	Rarity = 2,
	Element = 210003,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "冒险星人气NPC，拥有没人见过的非凡实力。卖出去1000块的道具，下一秒就是100块的回收价，却没有谁敢和他们吵架。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	IconName = "Rpg_14_lvxingshangren",
	PrefabBundle = "character_rpg",
	PrefabName = "Rpg_14_lvxingshangren",
	SkinName = "1",
	PrefabScale = 50,
	HPBarHeight = 105,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 847, Gain = 170},
		{Value = 200002, Base = 40, Gain = 8},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id5088] =
{
	Id = 5088,
	Name = "珠宝工匠",
	Rarity = 3,
	Element = 210002,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "铁匠打出的铁无可挑剔，唯一的问题就是没有运输工具。为此铁匠学会了套鹿的技能。套了100头鹿后，铁匠创立了顺鹿快递拉货公司。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	IconName = "Rpg_31_tiejiang_cos10",
	PrefabBundle = "character_rpg",
	PrefabName = "Rpg_31_tiejiang",
	SkinName = "2",
	PrefabScale = 50,
	HPBarHeight = 140,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 876, Gain = 176},
		{Value = 200002, Base = 41, Gain = 9},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id5089] =
{
	Id = 5089,
	Name = "古代的秘宝箱",
	Rarity = 3,
	Element = 210004,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "使用贵重的黄金制成的大鼎，只是靠近都能感到鼎内散发出不祥的气息。\n你才是金鸟回！",
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "MUS",
	IconName = "MUS_GoldenWineJar",
	PrefabBundle = "character_enemy",
	PrefabName = "MUS_GoldenWineJar",
	PrefabScale = 50,
	HPBarHeight = 120,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 876, Gain = 176},
		{Value = 200002, Base = 41, Gain = 9},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id5090] =
{
	Id = 5090,
	Name = "风暴熊猫",
	Rarity = 3,
	Element = 210003,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "获得了自然界风之力的风暴小浣熊，除了召唤龙卷风把敌人吹起来，还可以让同伴觉得空气很清新。~",
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "Mus",
	IconName = "MUS_14_erge_cos10",
	PrefabBundle = "character_mus",
	PrefabName = "MUS_14_erge",
	SkinName = "2",
	PrefabScale = 50,
	HPBarHeight = 135,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 876, Gain = 176},
		{Value = 200002, Base = 41, Gain = 9},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id5091] =
{
	Id = 5091,
	Name = "大地熊猫",
	Rarity = 3,
	Element = 210004,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "获得了自然界土之力的大地小浣熊，除了丢出石头晕住敌人2秒，还可以给同伴安全感。~",
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "Mus",
	IconName = "MUS_15_xiaodi_cos10",
	PrefabBundle = "character_mus",
	PrefabName = "MUS_15_xiaodi",
	SkinName = "2",
	PrefabScale = 50,
	HPBarHeight = 125,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 876, Gain = 176},
		{Value = 200002, Base = 41, Gain = 9},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id5092] =
{
	Id = 5092,
	Name = "监察者",
	Rarity = 3,
	Element = 210004,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "能够把路人脸上的毛孔都拍得一清二楚的高级摄像头，可他们又忘了加麦克风。",
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "MUS",
	IconName = "MUS_Camera",
	PrefabBundle = "character_enemy",
	PrefabName = "MUS_Camera",
	PrefabScale = 50,
	HPBarHeight = 110,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 876, Gain = 176},
		{Value = 200002, Base = 41, Gain = 9},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id5093] =
{
	Id = 5093,
	Name = "无辜死者",
	Rarity = 3,
	Element = 210001,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "往往第一个被排除嫌疑的角色，但是世事无绝对。如果所有出场的嫌疑人都遇害了，那么一定要再重新检查一遍死者。",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	IconName = "Sus_12_sizhe",
	PrefabBundle = "character_sus",
	PrefabName = "Sus_12_sizhe",
	SkinName = "1",
	PrefabScale = 50,
	HPBarHeight = 129,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 350, Gain = 70},
		{Value = 200002, Base = 41, Gain = 9},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id5094] =
{
	Id = 5094,
	Name = "无辜死者",
	Rarity = 3,
	Element = 210001,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "脖子上套着粗麻绳的套装，对于每天要跑20个片场扮演死者的死者而言，在演出特定场景时，几乎不用怎么化妆就能直接出场，非常方便噢~",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	IconName = "Sus_12_sizhe_cos10",
	PrefabBundle = "character_sus",
	PrefabName = "Sus_12_sizhe",
	SkinName = "2",
	PrefabScale = 50,
	HPBarHeight = 140,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 350, Gain = 70},
		{Value = 200002, Base = 41, Gain = 9},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id5095] =
{
	Id = 5095,
	Name = "无辜死者",
	Rarity = 3,
	Element = 210001,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "头上套着注水金鱼缸的套装，对于每天要跑20个片场扮演死者的死者而言，在演出特定场景时，几乎不用怎么化妆就能直接出场，非常方便噢~",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	IconName = "Sus_12_sizhe_cos20",
	PrefabBundle = "character_sus",
	PrefabName = "Sus_12_sizhe",
	SkinName = "3",
	PrefabScale = 50,
	HPBarHeight = 130,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 350, Gain = 70},
		{Value = 200002, Base = 41, Gain = 9},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id5096] =
{
	Id = 5096,
	Name = "医护人员",
	Rarity = 4,
	Element = 210001,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "穿着特制工作服的法医，包揽了悬疑星所有的法医及法证工作，经常出入于凶案现场，负责处理各种现场证物。",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	IconName = "Sus_04_fayi",
	PrefabBundle = "character_sus",
	PrefabName = "Sus_04_fayi",
	SkinName = "1",
	PrefabScale = 50,
	HPBarHeight = 123,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 813, Gain = 163},
		{Value = 200002, Base = 38, Gain = 8},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id5097] =
{
	Id = 5097,
	Name = "美术妹子",
	Rarity = 4,
	Element = 210003,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "神秘组织成员，为星球增添美丽色彩的仙女。一旦有灵感，就能让星球焕发活力~\n这里有点空空的？嗯，画头咩咩羊，咦？是不是再画条汪汪狗？",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	IconName = "Rpg_03_yuanhuameizi",
	PrefabBundle = "character_rpg",
	PrefabName = "Rpg_03_yuanhuameizi",
	SkinName = "1",
	PrefabScale = 50,
	HPBarHeight = 115,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 813, Gain = 163},
		{Value = 200002, Base = 38, Gain = 8},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id5098] =
{
	Id = 5098,
	Name = "送信的信封",
	Rarity = 4,
	Element = 210003,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "性格有些古怪，经常自言自语，会被周围的人所害怕。\n哦，想出来吗？哈哈！真可惜啊，你是绝对不可能突破我的封锁的！信！",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "SUS",
	IconName = "SUS_Letter",
	PrefabBundle = "character_enemy",
	PrefabName = "SUS_Letter",
	PrefabScale = 50,
	HPBarHeight = 100,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 813, Gain = 163},
		{Value = 200002, Base = 38, Gain = 8},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id5099] =
{
	Id = 5099,
	Name = "金玫瑰发明人",
	Rarity = 4,
	Element = 210005,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "内置物质转换器的防化服，据说价值180亿。可以过滤任何形式的有害物质，对于进行危险实验能起到至关重要的保护作用。",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	IconName = "Sus_03_moliyadi_cos30",
	PrefabBundle = "character_sus",
	PrefabName = "Sus_03_moliyadi",
	SkinName = "4",
	PrefabScale = 50,
	HPBarHeight = 140,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 813, Gain = 163},
		{Value = 200002, Base = 38, Gain = 8},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id5100] =
{
	Id = 5100,
	Name = "妖刀的锻造者",
	Rarity = 4,
	Element = 210002,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "冒险星人气NPC，提供装备买卖、修理、强化等服务，是勇者不可或缺的好帮手。\n“哎呀，手一滑装备爆炸了，阁下运气不太好噢~”",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	IconName = "Rpg_31_tiejiang",
	PrefabBundle = "character_rpg",
	PrefabName = "Rpg_31_tiejiang",
	SkinName = "1",
	PrefabScale = 50,
	HPBarHeight = 115,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 813, Gain = 163},
		{Value = 200002, Base = 38, Gain = 8},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id5101] =
{
	Id = 5101,
	Name = "营养专家",
	Rarity = 5,
	Element = 210004,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "农场特制的奶牛装，用以感谢牧师帮助牧场破获了特大牛奶浪费事件。当地的居民也因为之后及时补充了钙质，骨折好得更快了。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	IconName = "Rpg_07_mushi_cos10",
	PrefabBundle = "character_rpg",
	PrefabName = "Rpg_07_mushi",
	SkinName = "2",
	PrefabScale = 50,
	HPBarHeight = 135,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 765, Gain = 153},
		{Value = 200002, Base = 36, Gain = 8},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id5102] =
{
	Id = 5102,
	Name = "场地工作人员",
	Rarity = 5,
	Element = 210001,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "工作三年后，保安终于晋升队长职级，不过除了工作内容大幅加剧外，其他一切，包括工资，都没有变化噢~",
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "Mus",
	IconName = "MUS_27_baoan_cos10",
	PrefabBundle = "character_mus",
	PrefabName = "MUS_27_baoan",
	SkinName = "2",
	PrefabScale = 50,
	HPBarHeight = 137,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 693, Gain = 139},
		{Value = 200002, Base = 33, Gain = 7},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id5103] =
{
	Id = 5103,
	Name = "另一个报童",
	Rarity = 1,
	Element = 210002,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "在悬疑星各大街道活动的报童，拥有大量未经证实的惊天消息。比如动物园老虎逃出笼子，且27人已遇害。\n事实是房东太太的猫散步时，被27人围着撸。",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	IconName = "Sus_17_baotong",
	PrefabBundle = "character_sus",
	PrefabName = "Sus_17_baotong",
	SkinName = "1",
	PrefabScale = 50,
	HPBarHeight = 112,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 941, Gain = 189},
		{Value = 200002, Base = 44, Gain = 9},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id5104] =
{
	Id = 5104,
	Name = "毒理学专家",
	Rarity = 3,
	Element = 210005,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "内置物质转换器的防化服，据说价值180亿。可以过滤任何形式的有害物质，对于进行危险实验能起到至关重要的保护作用。",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	IconName = "Sus_03_moliyadi_cos30",
	PrefabBundle = "character_sus",
	PrefabName = "Sus_03_moliyadi",
	SkinName = "4",
	PrefabScale = 50,
	HPBarHeight = 140,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 876, Gain = 176},
		{Value = 200002, Base = 41, Gain = 9},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id5105] =
{
	Id = 5105,
	Name = "坚决的死者",
	Rarity = 3,
	Element = 210001,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "往往第一个被排除嫌疑的角色，但是世事无绝对。如果所有出场的嫌疑人都遇害了，那么一定要再重新检查一遍死者。",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	IconName = "Sus_12_sizhe",
	PrefabBundle = "character_sus",
	PrefabName = "Sus_12_sizhe",
	SkinName = "1",
	PrefabScale = 50,
	HPBarHeight = 129,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 876, Gain = 176},
		{Value = 200002, Base = 41, Gain = 9},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id5106] =
{
	Id = 5106,
	Name = "不还书的朋友",
	Rarity = 3,
	Element = 210001,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "对阅读充满热情的小学生，每本杂志都会认真阅读。如果连载故事中断，会郑重其事地前往编辑部进行抗议。",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	IconName = "Sus_21_duzhe",
	PrefabBundle = "character_sus",
	PrefabName = "Sus_21_duzhe",
	SkinName = "1",
	PrefabScale = 50,
	HPBarHeight = 119,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 876, Gain = 176},
		{Value = 200002, Base = 41, Gain = 9},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id5107] =
{
	Id = 5107,
	Name = "冷漠的侦探",
	Rarity = 3,
	Element = 210001,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "蓝星著名的高中生侦探的远房表弟，本来是初中生，因意外变成小学生。这个意外听上去是那么得不可思议，但不知为何大家都是以一幅理解的表情表示释然。",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	IconName = "Sus_20_lanyixiaoxuesheng",
	PrefabBundle = "character_sus",
	PrefabName = "Sus_20_lanyixiaoxuesheng",
	SkinName = "1",
	PrefabScale = 50,
	HPBarHeight = 112,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 876, Gain = 176},
		{Value = 200002, Base = 41, Gain = 9},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id5108] =
{
	Id = 5108,
	Name = "辣手警探",
	Rarity = 2,
	Element = 210002,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "豆豆警官击败黑警长后在组织中建立的新身份。此后，他将以黑警长的身份继续深入调查组织内部的罪恶秘密，希望有一天能够将组织彻底捣毁。",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	IconName = "Sus_05_jingcha_cos10",
	PrefabBundle = "character_sus",
	PrefabName = "Sus_05_jingcha",
	SkinName = "2",
	PrefabScale = 50,
	HPBarHeight = 145,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 847, Gain = 170},
		{Value = 200002, Base = 40, Gain = 8},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id5109] =
{
	Id = 5109,
	Name = "辣手警探",
	Rarity = 2,
	Element = 210002,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "豆豆警官击败黑警长后在组织中建立的新身份。此后，他将以黑警长的身份继续深入调查组织内部的罪恶秘密，希望有一天能够将组织彻底捣毁。",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	IconName = "Sus_05_jingcha_cos10",
	PrefabBundle = "character_sus",
	PrefabName = "Sus_05_jingcha",
	SkinName = "2",
	PrefabScale = 50,
	HPBarHeight = 145,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 847, Gain = 170},
		{Value = 200002, Base = 40, Gain = 8},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id5110] =
{
	Id = 5110,
	Name = "辣手警探",
	Rarity = 2,
	Element = 210002,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "豆豆警官击败黑警长后在组织中建立的新身份。此后，他将以黑警长的身份继续深入调查组织内部的罪恶秘密，希望有一天能够将组织彻底捣毁。",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	IconName = "Sus_05_jingcha_cos10",
	PrefabBundle = "character_sus",
	PrefabName = "Sus_05_jingcha",
	SkinName = "2",
	PrefabScale = 50,
	HPBarHeight = 145,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 847, Gain = 170},
		{Value = 200002, Base = 40, Gain = 8},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id5111] =
{
	Id = 5111,
	Name = "推销人员",
	Rarity = 2,
	Element = 210003,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "背负着被告所有希望的悬疑星上班族，根据表面上的证据往往能得出不同结论，帮助被告脱罪，顺带把证人席上的某人定罪。\n“上了证人席，你还想跑？”",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	IconName = "Sus_13_lvshi_cat",
	PrefabBundle = "character_sus",
	PrefabName = "Sus_13_lvshi",
	SkinName = "1_cat",
	PrefabScale = 50,
	HPBarHeight = 125,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 847, Gain = 170},
		{Value = 200002, Base = 40, Gain = 8},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id5112] =
{
	Id = 5112,
	Name = "图书管理员",
	Rarity = 2,
	Element = 210001,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "经过一番学习后，读者终于从阅读爱好者变成了一位文字工作者，虽然目前还只能从事阅读翻译的工作，不过相信未来一定可以踏上写作的道路。",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	IconName = "Sus_21_duzhe_cos10",
	PrefabBundle = "character_sus",
	PrefabName = "Sus_21_duzhe",
	SkinName = "2",
	PrefabScale = 50,
	HPBarHeight = 135,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 847, Gain = 170},
		{Value = 200002, Base = 40, Gain = 8},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id5113] =
{
	Id = 5113,
	Name = "算命商人",
	Rarity = 2,
	Element = 210003,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "每当旅行商人没钱进货的时候，他就会拿出这套装备，从事那些无本买卖，比如：看相鉴运，风水命理，趋吉避凶，祈福除祸，还能算五行，算八卦，算中宫，测仕途，测财行，测爱情，定紫微，定北斗等等等等。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	IconName = "Rpg_14_lvxingshangren_cos10",
	PrefabBundle = "character_rpg",
	PrefabName = "Rpg_14_lvxingshangren",
	SkinName = "2",
	PrefabScale = 50,
	HPBarHeight = 150,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 847, Gain = 170},
		{Value = 200002, Base = 40, Gain = 8},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id5114] =
{
	Id = 5114,
	Name = "愤怒的法官",
	Rarity = 2,
	Element = 210004,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "公平和正义的代表，手握小锤掌握生杀大权。头顶贵重的假发，不仅可以代表法官的公正无私，还能让人看起来容光焕发，但他的发量却日益减少。",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	IconName = "Sus_14_faguan",
	PrefabBundle = "character_sus",
	PrefabName = "Sus_14_faguan",
	SkinName = "1",
	PrefabScale = 50,
	HPBarHeight = 112,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 847, Gain = 170},
		{Value = 200002, Base = 40, Gain = 8},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id5115] =
{
	Id = 5115,
	Name = "钥匙匠",
	Rarity = 2,
	Element = 210002,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "冒险星人气NPC，提供装备买卖、修理、强化等服务，是勇者不可或缺的好帮手。\n“哎呀，手一滑装备爆炸了，阁下运气不太好噢~”",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	IconName = "Rpg_31_tiejiang",
	PrefabBundle = "character_rpg",
	PrefabName = "Rpg_31_tiejiang",
	SkinName = "1",
	PrefabScale = 50,
	HPBarHeight = 115,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 847, Gain = 170},
		{Value = 200002, Base = 40, Gain = 8},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id5116] =
{
	Id = 5116,
	Name = "神秘人",
	Rarity = 2,
	Element = 210005,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "令人闻风丧胆的凶手，没人知道ta的身份。只要ta出现，大家就会放弃抵抗落荒而逃，然后露出破绽，被他轻易击杀。",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	IconName = "Sus_28_heiyiren_cat",
	PrefabBundle = "character_sus",
	PrefabName = "Sus_28_heiyiren",
	SkinName = "1_cat",
	PrefabScale = 50,
	HPBarHeight = 135,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 847, Gain = 170},
		{Value = 200002, Base = 40, Gain = 8},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id5117] =
{
	Id = 5117,
	Name = "博士2.0",
	Rarity = 3,
	Element = 210003,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "普通行动舱的强化版本，更适于在恶劣环境中进行战斗。不过为了节省舱体容量，因此去除了大量工作模块。",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	IconName = "Sus_24_boshi_cos10",
	PrefabBundle = "character_sus",
	PrefabName = "Sus_24_boshi",
	SkinName = "2",
	PrefabScale = 50,
	HPBarHeight = 170,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 876, Gain = 176},
		{Value = 200002, Base = 41, Gain = 9},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id5118] =
{
	Id = 5118,
	Name = "防御大师",
	Rarity = 3,
	Element = 210001,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "守护主城的卫兵，维护着城市的治安。战斗力很强，但是从不参与讨伐魔王，似乎是比较喜欢作息规律的工作。每天准时上床，绝不把压力和疲劳留到第二天，医生都说他很健康。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	IconName = "Rpg_17_chengzhenweibing",
	PrefabBundle = "character_rpg",
	PrefabName = "Rpg_17_chengzhenweibing",
	SkinName = "1",
	PrefabScale = 50,
	HPBarHeight = 105,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 876, Gain = 176},
		{Value = 200002, Base = 41, Gain = 9},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id5119] =
{
	Id = 5119,
	Name = "生物老师",
	Rarity = 3,
	Element = 210003,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "背负着被告所有希望的悬疑星上班族，根据表面上的证据往往能得出不同结论，帮助被告脱罪，顺带把证人席上的某人定罪。\n“上了证人席，你还想跑？”",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	IconName = "Sus_13_lvshi_cat",
	PrefabBundle = "character_sus",
	PrefabName = "Sus_13_lvshi",
	SkinName = "1_cat",
	PrefabScale = 50,
	HPBarHeight = 125,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 876, Gain = 176},
		{Value = 200002, Base = 41, Gain = 9},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id5120] =
{
	Id = 5120,
	Name = "作案中的凶手",
	Rarity = 3,
	Element = 210005,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "令人闻风丧胆的凶手，没人知道ta的身份。只要ta出现，大家就会放弃抵抗落荒而逃，然后露出破绽，被他轻易击杀。",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	IconName = "Sus_28_heiyiren",
	PrefabBundle = "character_sus",
	PrefabName = "Sus_28_heiyiren",
	SkinName = "1",
	PrefabScale = 50,
	HPBarHeight = 112,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 876, Gain = 176},
		{Value = 200002, Base = 41, Gain = 9},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id5121] =
{
	Id = 5121,
	Name = "推销人员",
	Rarity = 3,
	Element = 210003,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "背负着被告所有希望的悬疑星上班族，根据表面上的证据往往能得出不同结论，帮助被告脱罪，顺带把证人席上的某人定罪。\n“上了证人席，你还想跑？”",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	IconName = "Sus_13_lvshi_cat",
	PrefabBundle = "character_sus",
	PrefabName = "Sus_13_lvshi",
	SkinName = "1_cat",
	PrefabScale = 50,
	HPBarHeight = 125,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 876, Gain = 176},
		{Value = 200002, Base = 41, Gain = 9},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id5122] =
{
	Id = 5122,
	Name = "侦探用放大镜",
	Rarity = 3,
	Element = 210004,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "侦探们的好朋友，有时候没什么用，但是拿出来会让人觉得很有侦探的派头。",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "SUS",
	IconName = "SUS_Magnifier",
	PrefabBundle = "character_enemy",
	PrefabName = "SUS_Magnifier",
	PrefabScale = 50,
	HPBarHeight = 110,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 876, Gain = 176},
		{Value = 200002, Base = 41, Gain = 9},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id5123] =
{
	Id = 5123,
	Name = "剪刀之王",
	Rarity = 4,
	Element = 210005,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "杰克祖父留给他的代表复仇的外套，只有当杰克的仇人出现时，杰克才会穿上这件衣服，向对方施以愤怒之火。",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	IconName = "Sus_29_kaitangshoujieke_cos10",
	PrefabBundle = "character_sus",
	PrefabName = "Sus_29_kaitangshoujieke",
	SkinName = "2",
	PrefabScale = 50,
	HPBarHeight = 165,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 813, Gain = 163},
		{Value = 200002, Base = 38, Gain = 8},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id5124] =
{
	Id = 5124,
	Name = "报错的机器人",
	Rarity = 4,
	Element = 210003,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "普通行动舱的强化版本，更适于在恶劣环境中进行战斗。不过为了节省舱体容量，因此去除了大量工作模块。",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	IconName = "Sus_24_boshi_cos10",
	PrefabBundle = "character_sus",
	PrefabName = "Sus_24_boshi",
	SkinName = "2",
	PrefabScale = 50,
	HPBarHeight = 170,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 813, Gain = 163},
		{Value = 200002, Base = 38, Gain = 8},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id5125] =
{
	Id = 5125,
	Name = "神秘中枢",
	Rarity = 4,
	Element = 210001,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "实验室特别存保存下来的生物大脑，其中存储着大量重要的信息。",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "SUS",
	IconName = "SUS_Brain",
	PrefabBundle = "character_enemy",
	PrefabName = "SUS_Brain",
	PrefabScale = 50,
	HPBarHeight = 120,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 813, Gain = 163},
		{Value = 200002, Base = 38, Gain = 8},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id5126] =
{
	Id = 5126,
	Name = "剪网线的杰克",
	Rarity = 5,
	Element = 210005,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "杰克祖父留给他的代表复仇的外套，只有当杰克的仇人出现时，杰克才会穿上这件衣服，向对方施以愤怒之火。",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	IconName = "Sus_29_kaitangshoujieke_cos10",
	PrefabBundle = "character_sus",
	PrefabName = "Sus_29_kaitangshoujieke",
	SkinName = "2",
	PrefabScale = 50,
	HPBarHeight = 165,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 765, Gain = 153},
		{Value = 200002, Base = 36, Gain = 8},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id5127] =
{
	Id = 5127,
	Name = "名侦探",
	Rarity = 5,
	Element = 210004,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "前任大侦探老福的孙子，继承了爷爷的意志，经常帮助警局侦办悬疑案件。既是警局救星，也是警局克星。",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	IconName = "Sus_01_fuermosi_cat",
	PrefabBundle = "character_sus",
	PrefabName = "Sus_01_fuermosi",
	SkinName = "1_cat",
	PrefabScale = 50,
	HPBarHeight = 145,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 693, Gain = 139},
		{Value = 200002, Base = 33, Gain = 7},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id5128] =
{
	Id = 5128,
	Name = "实验室的血液",
	Rarity = 5,
	Element = 210005,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "生物身体中必不可少的关键液体，不过有些生物个体看到它时会不自觉地晕倒。",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "SUS",
	IconName = "SUS_Blood",
	PrefabBundle = "character_enemy",
	PrefabName = "SUS_Blood",
	PrefabScale = 50,
	HPBarHeight = 100,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 765, Gain = 153},
		{Value = 200002, Base = 36, Gain = 8},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id5129] =
{
	Id = 5129,
	Name = "正义执法者",
	Rarity = 5,
	Element = 210002,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "小镇新来的热血干探，一丝不苟且乐于助人。哪怕是宠物丢失，也会向附近的流浪猫狗们录下详细的口供，然后仔细去寻找，尽管他听不懂。",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	IconName = "Sus_05_jingcha_cat",
	PrefabBundle = "character_sus",
	PrefabName = "Sus_05_jingcha",
	SkinName = "1_cat",
	PrefabScale = 50,
	HPBarHeight = 145,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 693, Gain = 139},
		{Value = 200002, Base = 33, Gain = 7},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id5130] =
{
	Id = 5130,
	Name = "愤怒的抽卡者",
	Rarity = 3,
	Element = 210005,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "来自神秘星球的部落酋长，部族世代受到不幸之神的祝福，虽然不会遭遇什么变故，但是做什么事情都比一般人不顺很多。",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	IconName = "SPDraw_04_UnlockChief",
	PrefabBundle = "character_sp",
	PrefabName = "SPDraw_04_UnlockChief",
	SkinName = "1",
	PrefabScale = 50,
	HPBarHeight = 125,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 1183, Gain = 237},
		{Value = 200002, Base = 56, Gain = 12},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id5131] =
{
	Id = 5131,
	Name = "愤怒的抽卡者",
	Rarity = 4,
	Element = 210005,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "来自神秘星球的部落酋长，部族世代受到不幸之神的祝福，虽然不会遭遇什么变故，但是做什么事情都比一般人不顺很多。",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	IconName = "SPDraw_04_UnlockChief",
	PrefabBundle = "character_sp",
	PrefabName = "SPDraw_04_UnlockChief",
	SkinName = "1",
	PrefabScale = 50,
	HPBarHeight = 125,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 1118, Gain = 224},
		{Value = 200002, Base = 53, Gain = 11},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id5132] =
{
	Id = 5132,
	Name = "愤怒的抽卡者",
	Rarity = 5,
	Element = 210005,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "来自神秘星球的部落酋长，部族世代受到不幸之神的祝福，虽然不会遭遇什么变故，但是做什么事情都比一般人不顺很多。",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	IconName = "SPDraw_04_UnlockChief",
	PrefabBundle = "character_sp",
	PrefabName = "SPDraw_04_UnlockChief",
	SkinName = "1",
	PrefabScale = 50,
	HPBarHeight = 125,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 1147, Gain = 230},
		{Value = 200002, Base = 55, Gain = 11},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id5133] =
{
	Id = 5133,
	Name = "假电池受害者",
	Rarity = 5,
	Element = 210001,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "传奇历史人物，从普通士兵变成一国的统帅，威名传遍宇宙每个角落，最终功败垂成，令人扼腕叹息。制成蜡像后，经常有历史爱好者来和他合影。",
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "Mus",
	IconName = "MUS_30_Napoleon_cat",
	PrefabBundle = "character_mus",
	PrefabName = "MUS_30_Napoleon",
	SkinName = "1_cat",
	PrefabScale = 50,
	HPBarHeight = 145,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 1126, Gain = 226},
		{Value = 200002, Base = 55, Gain = 11},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id5134] =
{
	Id = 5134,
	Name = "一坨美食",
	Rarity = 3,
	Element = 210003,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "最恨人说烂泥扶不上墙，一旦听到就会发飙。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	IconName = "RPG_ruannidui",
	PrefabBundle = "character_enemy",
	PrefabName = "RPG_ruannidui",
	PrefabScale = 50,
	HPBarHeight = 76,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 1183, Gain = 237},
		{Value = 200002, Base = 56, Gain = 12},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id5135] =
{
	Id = 5135,
	Name = "化肥专家",
	Rarity = 2,
	Element = 210005,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "内置物质转换器的防化服，据说价值180亿。可以过滤任何形式的有害物质，对于进行危险实验能起到至关重要的保护作用。",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	IconName = "Sus_03_moliyadi_cos30",
	PrefabBundle = "character_sus",
	PrefabName = "Sus_03_moliyadi",
	SkinName = "4",
	PrefabScale = 50,
	HPBarHeight = 140,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 1270, Gain = 254},
		{Value = 200002, Base = 60, Gain = 12},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id5136] =
{
	Id = 5136,
	Name = "黑市交易员",
	Rarity = 2,
	Element = 210005,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "藏在暗处的异生物，随星球创造而生。内部有严格的等级制度，普通霸格偶尔被看到也会被无视，高危霸格反而每天都要担心被除虫者干掉。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	IconName = "Rpg_28_bug",
	PrefabBundle = "character_rpg",
	PrefabName = "Rpg_28_bug",
	SkinName = "1",
	PrefabScale = 50,
	HPBarHeight = 105,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 1270, Gain = 254},
		{Value = 200002, Base = 60, Gain = 12},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id5137] =
{
	Id = 5137,
	Name = "厨具守护者",
	Rarity = 4,
	Element = 210001,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "国王御用侍卫，从小陪伴薯条国王长大。能根据薯条国王的状态，时刻调整自己的甜度，深得薯条国王信赖。每次战后他都会在第一时间被送往医院，尽管大部分时候只是包装袋破了。",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	IconName = "Fat_31_fanqiejiang",
	PrefabBundle = "character_fat",
	PrefabName = "Fat_31_fanqiejiang",
	SkinName = "1",
	PrefabScale = 50,
	HPBarHeight = 106,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 813, Gain = 163},
		{Value = 200002, Base = 38, Gain = 8},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id5138] =
{
	Id = 5138,
	Name = "实验室负责人",
	Rarity = 4,
	Element = 210003,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "普通行动舱的强化版本，更适于在恶劣环境中进行战斗。不过为了节省舱体容量，因此去除了大量工作模块。",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	IconName = "Sus_24_boshi_cos10",
	PrefabBundle = "character_sus",
	PrefabName = "Sus_24_boshi",
	SkinName = "2",
	PrefabScale = 50,
	HPBarHeight = 170,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 813, Gain = 163},
		{Value = 200002, Base = 38, Gain = 8},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id5139] =
{
	Id = 5139,
	Name = "旅行商人",
	Rarity = 4,
	Element = 210003,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "冒险星人气NPC，拥有没人见过的非凡实力。卖出去1000块的道具，下一秒就是100块的回收价，却没有谁敢和他们吵架。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	IconName = "Rpg_14_lvxingshangren",
	PrefabBundle = "character_rpg",
	PrefabName = "Rpg_14_lvxingshangren",
	SkinName = "1",
	PrefabScale = 50,
	HPBarHeight = 105,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 813, Gain = 163},
		{Value = 200002, Base = 38, Gain = 8},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id5140] =
{
	Id = 5140,
	Name = "苦痛的回信",
	Rarity = 4,
	Element = 210003,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "为人们传递情意的信件，读的时候会起一身的鸡皮疙瘩，因此很棘手。",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "SUS",
	IconName = "SUS_LoveLetter",
	PrefabBundle = "character_enemy",
	PrefabName = "SUS_LoveLetter",
	PrefabScale = 50,
	HPBarHeight = 100,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 813, Gain = 163},
		{Value = 200002, Base = 38, Gain = 8},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id5141] =
{
	Id = 5141,
	Name = "旅行商人",
	Rarity = 4,
	Element = 210003,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "冒险星人气NPC，拥有没人见过的非凡实力。卖出去1000块的道具，下一秒就是100块的回收价，却没有谁敢和他们吵架。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	IconName = "Rpg_14_lvxingshangren",
	PrefabBundle = "character_rpg",
	PrefabName = "Rpg_14_lvxingshangren",
	SkinName = "1",
	PrefabScale = 50,
	HPBarHeight = 105,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 813, Gain = 163},
		{Value = 200002, Base = 38, Gain = 8},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id5142] =
{
	Id = 5142,
	Name = "旅行商人",
	Rarity = 4,
	Element = 210003,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "冒险星人气NPC，拥有没人见过的非凡实力。卖出去1000块的道具，下一秒就是100块的回收价，却没有谁敢和他们吵架。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	IconName = "Rpg_14_lvxingshangren",
	PrefabBundle = "character_rpg",
	PrefabName = "Rpg_14_lvxingshangren",
	SkinName = "1",
	PrefabScale = 50,
	HPBarHeight = 105,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 813, Gain = 163},
		{Value = 200002, Base = 38, Gain = 8},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id5143] =
{
	Id = 5143,
	Name = "旅行商人",
	Rarity = 4,
	Element = 210003,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "冒险星人气NPC，拥有没人见过的非凡实力。卖出去1000块的道具，下一秒就是100块的回收价，却没有谁敢和他们吵架。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	IconName = "Rpg_14_lvxingshangren",
	PrefabBundle = "character_rpg",
	PrefabName = "Rpg_14_lvxingshangren",
	SkinName = "1",
	PrefabScale = 50,
	HPBarHeight = 105,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 813, Gain = 163},
		{Value = 200002, Base = 38, Gain = 8},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id5144] =
{
	Id = 5144,
	Name = "旅行商人",
	Rarity = 4,
	Element = 210003,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "冒险星人气NPC，拥有没人见过的非凡实力。卖出去1000块的道具，下一秒就是100块的回收价，却没有谁敢和他们吵架。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	IconName = "Rpg_14_lvxingshangren",
	PrefabBundle = "character_rpg",
	PrefabName = "Rpg_14_lvxingshangren",
	SkinName = "1",
	PrefabScale = 50,
	HPBarHeight = 105,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 813, Gain = 163},
		{Value = 200002, Base = 38, Gain = 8},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id5145] =
{
	Id = 5145,
	Name = "旅行商人",
	Rarity = 4,
	Element = 210003,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "冒险星人气NPC，拥有没人见过的非凡实力。卖出去1000块的道具，下一秒就是100块的回收价，却没有谁敢和他们吵架。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	IconName = "Rpg_14_lvxingshangren",
	PrefabBundle = "character_rpg",
	PrefabName = "Rpg_14_lvxingshangren",
	SkinName = "1",
	PrefabScale = 50,
	HPBarHeight = 105,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 813, Gain = 163},
		{Value = 200002, Base = 38, Gain = 8},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id5146] =
{
	Id = 5146,
	Name = "旅行商人",
	Rarity = 4,
	Element = 210003,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "冒险星人气NPC，拥有没人见过的非凡实力。卖出去1000块的道具，下一秒就是100块的回收价，却没有谁敢和他们吵架。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	IconName = "Rpg_14_lvxingshangren",
	PrefabBundle = "character_rpg",
	PrefabName = "Rpg_14_lvxingshangren",
	SkinName = "1",
	PrefabScale = 50,
	HPBarHeight = 105,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 813, Gain = 163},
		{Value = 200002, Base = 38, Gain = 8},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id5147] =
{
	Id = 5147,
	Name = "旅行商人",
	Rarity = 5,
	Element = 210003,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "冒险星人气NPC，拥有没人见过的非凡实力。卖出去1000块的道具，下一秒就是100块的回收价，却没有谁敢和他们吵架。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	IconName = "Rpg_14_lvxingshangren",
	PrefabBundle = "character_rpg",
	PrefabName = "Rpg_14_lvxingshangren",
	SkinName = "1",
	PrefabScale = 50,
	HPBarHeight = 105,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 765, Gain = 153},
		{Value = 200002, Base = 36, Gain = 8},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id5148] =
{
	Id = 5148,
	Name = "旅行商人",
	Rarity = 5,
	Element = 210003,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "冒险星人气NPC，拥有没人见过的非凡实力。卖出去1000块的道具，下一秒就是100块的回收价，却没有谁敢和他们吵架。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	IconName = "Rpg_14_lvxingshangren",
	PrefabBundle = "character_rpg",
	PrefabName = "Rpg_14_lvxingshangren",
	SkinName = "1",
	PrefabScale = 50,
	HPBarHeight = 105,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 693, Gain = 139},
		{Value = 200002, Base = 33, Gain = 7},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id5149] =
{
	Id = 5149,
	Name = "旅行商人",
	Rarity = 5,
	Element = 210003,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "冒险星人气NPC，拥有没人见过的非凡实力。卖出去1000块的道具，下一秒就是100块的回收价，却没有谁敢和他们吵架。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	IconName = "Rpg_14_lvxingshangren",
	PrefabBundle = "character_rpg",
	PrefabName = "Rpg_14_lvxingshangren",
	SkinName = "1",
	PrefabScale = 50,
	HPBarHeight = 105,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 765, Gain = 153},
		{Value = 200002, Base = 36, Gain = 8},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id5150] =
{
	Id = 5150,
	Name = "旅行商人",
	Rarity = 5,
	Element = 210003,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "冒险星人气NPC，拥有没人见过的非凡实力。卖出去1000块的道具，下一秒就是100块的回收价，却没有谁敢和他们吵架。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	IconName = "Rpg_14_lvxingshangren",
	PrefabBundle = "character_rpg",
	PrefabName = "Rpg_14_lvxingshangren",
	SkinName = "1",
	PrefabScale = 50,
	HPBarHeight = 105,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 693, Gain = 139},
		{Value = 200002, Base = 33, Gain = 7},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id5151] =
{
	Id = 5151,
	Name = "旅行商人",
	Rarity = 4,
	Element = 210004,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "经典冒险组人气角色，携带着大量法器，能够给予其他冒险者们勇气和希望。\n听说，一起组队的男冒险者经常会偷偷给她递小纸条。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	IconName = "Rpg_07_mushi",
	PrefabBundle = "character_rpg",
	PrefabName = "Rpg_07_mushi",
	SkinName = "1",
	PrefabScale = 50,
	HPBarHeight = 115,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 813, Gain = 163},
		{Value = 200002, Base = 38, Gain = 8},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id5152] =
{
	Id = 5152,
	Name = "大声“公”",
	Rarity = 4,
	Element = 210003,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "很久很久以前，一位画家为想要呐喊之人而作的画。流传至今变成了一个流行的表情。",
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "Mus",
	IconName = "MUS_19_nahan",
	PrefabBundle = "character_mus",
	PrefabName = "MUS_19_nahan",
	SkinName = "1",
	PrefabScale = 50,
	HPBarHeight = 115,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 813, Gain = 163},
		{Value = 200002, Base = 38, Gain = 8},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id5153] =
{
	Id = 5153,
	Name = "狼族刺客",
	Rarity = 4,
	Element = 210003,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "经典冒险组的神秘狼族少年，因为俊朗的外形和冷酷的性格相当受异性欢迎。其实本人很富于爱心，平时还会照顾流浪的小动物。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	IconName = "Rpg_08_cike",
	PrefabBundle = "character_rpg",
	PrefabName = "Rpg_08_cike",
	SkinName = "1",
	PrefabScale = 50,
	HPBarHeight = 105,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 813, Gain = 163},
		{Value = 200002, Base = 38, Gain = 8},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id5154] =
{
	Id = 5154,
	Name = "鬼面的偶师",
	Rarity = 4,
	Element = 210005,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "神秘组织成员，脸上总是挂着一幅让人捉摸不透的表情，感觉像戴着面具。\n不过如果你和他聊起遥控飞机，那么很快就会熟络起来。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	IconName = "Rpg_27_donghua",
	PrefabBundle = "character_rpg",
	PrefabName = "Rpg_27_donghua",
	SkinName = "1",
	PrefabScale = 50,
	HPBarHeight = 105,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 813, Gain = 163},
		{Value = 200002, Base = 38, Gain = 8},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id5155] =
{
	Id = 5155,
	Name = "出版社社长",
	Rarity = 4,
	Element = 210002,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "认真负责的编辑长，为了不辜负读者，每天都在兢兢业业地工作。每5分钟都会联系约稿作家，防止对方放水。",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	IconName = "Sus_22_bianji",
	PrefabBundle = "character_sus",
	PrefabName = "Sus_22_bianji",
	SkinName = "1",
	PrefabScale = 50,
	HPBarHeight = 112,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 813, Gain = 163},
		{Value = 200002, Base = 38, Gain = 8},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id5156] =
{
	Id = 5156,
	Name = "万能解毒草",
	Rarity = 4,
	Element = 210003,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：躲在小学门口，敲诈放学回家的小学生。",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	IconName = "Arena_RPG_xiaohuaqiu",
	PrefabBundle = "character_arenaenemy",
	PrefabName = "Arena_RPG_xiaohuaqiu",
	PrefabScale = 50,
	HPBarHeight = 76,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 813, Gain = 163},
		{Value = 200002, Base = 38, Gain = 8},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id5157] =
{
	Id = 5157,
	Name = "竞争对手",
	Rarity = 4,
	Element = 210001,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "Sharkalaka的现役成员，温驯海族，性格温柔，是团队中的“和事佬”，当团队、粉丝、公司之间发生矛盾，一定会自告奋勇去解决。对自己有极高的要求，不管是采访还是演出，都要做到滴水不漏。",
	IconBundle = "atlas_charactericon_sea",
	IconAtlas = "Sea",
	IconName = "Sea_12_jingsha",
	PrefabBundle = "character_sea",
	PrefabName = "Sea_12_jingsha",
	SkinName = "1",
	PrefabScale = 50,
	HPBarHeight = 112,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 813, Gain = 163},
		{Value = 200002, Base = 38, Gain = 8},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id5158] =
{
	Id = 5158,
	Name = "特制玻璃罐",
	Rarity = 3,
	Element = 210001,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "实验室特别存保存下来的生物大脑，其中存储着大量重要的信息。",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "SUS",
	IconName = "SUS_Brain",
	PrefabBundle = "character_enemy",
	PrefabName = "SUS_Brain",
	PrefabScale = 50,
	HPBarHeight = 120,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 876, Gain = 176},
		{Value = 200002, Base = 41, Gain = 9},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id5159] =
{
	Id = 5159,
	Name = "礁石区看护",
	Rarity = 3,
	Element = 210003,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "穿着绿色制服的保安，保卫礁石区一方平安，会对危害公共安全的危险分子，会毫不留情发射藤壶。",
	IconBundle = "atlas_charactericon_sea",
	IconAtlas = "Sea",
	IconName = "SEA_Ston1",
	PrefabBundle = "character_enemy",
	PrefabName = "SEA_Stone1",
	PrefabScale = 50,
	HPBarHeight = 100,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 876, Gain = 176},
		{Value = 200002, Base = 41, Gain = 9},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id5160] =
{
	Id = 5160,
	Name = "外星采购商",
	Rarity = 3,
	Element = 210003,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "法庭上人见人怕的律政界女王，据说以前还是学校选美冠军之一呢~",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	IconName = "Sus_13_lvshi_cos10",
	PrefabBundle = "character_sus",
	PrefabName = "Sus_13_lvshi",
	SkinName = "2",
	PrefabScale = 50,
	HPBarHeight = 140,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 876, Gain = 176},
		{Value = 200002, Base = 41, Gain = 9},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id5161] =
{
	Id = 5161,
	Name = "黄金贝",
	Rarity = 4,
	Element = 210004,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "红贝壳的好友，当红贝壳的坑蒙拐骗被拆穿时，TA就负责出来收拾残局。",
	IconBundle = "atlas_charactericon_sea",
	IconAtlas = "Sea",
	IconName = "SEA_Pectinid1",
	PrefabBundle = "character_enemy",
	PrefabName = "SEA_Pectinid1",
	PrefabScale = 50,
	HPBarHeight = 100,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 813, Gain = 163},
		{Value = 200002, Base = 38, Gain = 8},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id5162] =
{
	Id = 5162,
	Name = "出版商",
	Rarity = 4,
	Element = 210002,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "认真负责的编辑长，为了不辜负读者，每天都在兢兢业业地工作。每5分钟都会联系约稿作家，防止对方放水。",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	IconName = "Sus_22_bianji",
	PrefabBundle = "character_sus",
	PrefabName = "Sus_22_bianji",
	SkinName = "1",
	PrefabScale = 50,
	HPBarHeight = 112,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 813, Gain = 163},
		{Value = 200002, Base = 38, Gain = 8},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id5163] =
{
	Id = 5163,
	Name = "通讯研究员",
	Rarity = 3,
	Element = 210003,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "普通行动舱的强化版本，更适于在恶劣环境中进行战斗。不过为了节省舱体容量，因此去除了大量工作模块。",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	IconName = "Sus_24_boshi_cos10",
	PrefabBundle = "character_sus",
	PrefabName = "Sus_24_boshi",
	SkinName = "2",
	PrefabScale = 50,
	HPBarHeight = 170,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 876, Gain = 176},
		{Value = 200002, Base = 41, Gain = 9},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id5164] =
{
	Id = 5164,
	Name = "扒手甲",
	Rarity = 3,
	Element = 210005,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "来自暗影大陆的经典冒险组成员，个性狡猾，不喜欢战斗和吵架。在他们的国家有一句谚语叫“取走敌人心头宝，好比刺他一百刀。”",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	IconName = "RPG_103_Thief",
	PrefabBundle = "character_rpg",
	PrefabName = "RPG_103_Thief",
	SkinName = "1",
	PrefabScale = 50,
	HPBarHeight = 135,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 876, Gain = 176},
		{Value = 200002, Base = 41, Gain = 9},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id5165] =
{
	Id = 5165,
	Name = "电力维修工",
	Rarity = 3,
	Element = 210005,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "杰克祖父留给他的代表复仇的外套，只有当杰克的仇人出现时，杰克才会穿上这件衣服，向对方施以愤怒之火。",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	IconName = "Sus_29_kaitangshoujieke_cos10",
	PrefabBundle = "character_sus",
	PrefabName = "Sus_29_kaitangshoujieke",
	SkinName = "2",
	PrefabScale = 50,
	HPBarHeight = 165,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 876, Gain = 176},
		{Value = 200002, Base = 41, Gain = 9},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id5166] =
{
	Id = 5166,
	Name = "流浪艺术家",
	Rarity = 3,
	Element = 210003,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "神秘组织成员，为星球增添美丽色彩的仙女。一旦有灵感，就能让星球焕发活力~\n这里有点空空的？嗯，画头咩咩羊，咦？是不是再画条汪汪狗？",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	IconName = "Rpg_03_yuanhuameizi",
	PrefabBundle = "character_rpg",
	PrefabName = "Rpg_03_yuanhuameizi",
	SkinName = "1",
	PrefabScale = 50,
	HPBarHeight = 115,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 876, Gain = 176},
		{Value = 200002, Base = 41, Gain = 9},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id5167] =
{
	Id = 5167,
	Name = "披风爱好者",
	Rarity = 3,
	Element = 210005,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "违反了骑士劳动合同，转会加入死亡军团的武士。其变节原因至今无人知晓，不过有消息人士指出，该人员常年沉湎于酷炫坐骑，拉风造型等时尚品，不排除其盲目追求外表而舍弃正道的可能性。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	IconName = "RPG_101_Paladin_cos10",
	PrefabBundle = "character_rpg",
	PrefabName = "RPG_101_Paladin",
	SkinName = "2",
	PrefabScale = 50,
	HPBarHeight = 130,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 876, Gain = 176},
		{Value = 200002, Base = 41, Gain = 9},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id5168] =
{
	Id = 5168,
	Name = "噪音制造者",
	Rarity = 3,
	Element = 210003,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "很久很久以前，一位画家为想要呐喊之人而作的画。流传至今变成了一个流行的表情。",
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "Mus",
	IconName = "MUS_19_nahan",
	PrefabBundle = "character_mus",
	PrefabName = "MUS_19_nahan",
	SkinName = "1",
	PrefabScale = 50,
	HPBarHeight = 115,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 876, Gain = 176},
		{Value = 200002, Base = 41, Gain = 9},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id5169] =
{
	Id = 5169,
	Name = "旗主",
	Rarity = 3,
	Element = 210001,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "前任主人是喜欢异国文化，剑术高超的顶级武士，性格高傲且正直开朗。即使面对多个敌人，也没有丝毫胆怯。",
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "Mus",
	IconName = "MUS_09_ribenwushi_cos20",
	PrefabBundle = "character_mus",
	PrefabName = "MUS_09_ribenwushi",
	SkinName = "3",
	PrefabScale = 50,
	HPBarHeight = 140,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 876, Gain = 176},
		{Value = 200002, Base = 41, Gain = 9},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id5170] =
{
	Id = 5170,
	Name = "女强人",
	Rarity = 3,
	Element = 210003,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "法庭上人见人怕的律政界女王，据说以前还是学校选美冠军之一呢~",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	IconName = "Sus_13_lvshi_cos10",
	PrefabBundle = "character_sus",
	PrefabName = "Sus_13_lvshi",
	SkinName = "2",
	PrefabScale = 50,
	HPBarHeight = 140,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 876, Gain = 176},
		{Value = 200002, Base = 41, Gain = 9},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id5171] =
{
	Id = 5171,
	Name = "旅行商人",
	Rarity = 3,
	Element = 210003,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "冒险星人气NPC，拥有没人见过的非凡实力。卖出去1000块的道具，下一秒就是100块的回收价，却没有谁敢和他们吵架。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	IconName = "Rpg_14_lvxingshangren",
	PrefabBundle = "character_rpg",
	PrefabName = "Rpg_14_lvxingshangren",
	SkinName = "1",
	PrefabScale = 50,
	HPBarHeight = 105,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 876, Gain = 176},
		{Value = 200002, Base = 41, Gain = 9},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id5172] =
{
	Id = 5172,
	Name = "发明少女",
	Rarity = 3,
	Element = 210001,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "“姐妹团”中的小妹，活泼可爱。平时躲在咖啡厅后厨研究新装备。时间够的话，火箭也是可以造出来的。",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	IconName = "Sus_27_xiaoai",
	PrefabBundle = "character_sus",
	PrefabName = "Sus_27_xiaoai",
	SkinName = "1",
	PrefabScale = 50,
	HPBarHeight = 112,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 876, Gain = 176},
		{Value = 200002, Base = 41, Gain = 9},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id5173] =
{
	Id = 5173,
	Name = "《假证指南》",
	Rarity = 3,
	Element = 210003,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "记录着大量水果资料的笔记本，不知道打算用来做什么用。",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "SUS",
	IconName = "SUS_BrownNoteBook",
	PrefabBundle = "character_enemy",
	PrefabName = "SUS_BrownNoteBook",
	PrefabScale = 50,
	HPBarHeight = 100,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 876, Gain = 176},
		{Value = 200002, Base = 41, Gain = 9},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id5174] =
{
	Id = 5174,
	Name = "通讯研究员",
	Rarity = 3,
	Element = 210003,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "普通行动舱的强化版本，更适于在恶劣环境中进行战斗。不过为了节省舱体容量，因此去除了大量工作模块。",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	IconName = "Sus_24_boshi_cos10",
	PrefabBundle = "character_sus",
	PrefabName = "Sus_24_boshi",
	SkinName = "2",
	PrefabScale = 50,
	HPBarHeight = 170,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 876, Gain = 176},
		{Value = 200002, Base = 41, Gain = 9},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id5175] =
{
	Id = 5175,
	Name = "蓝墨水",
	Rarity = 3,
	Element = 210001,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "使用贝壳和藻类制成的蓝色液体，通常用来记录信息类的文字，对海鲜过敏的人请务必谨慎使用。",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "SUS",
	IconName = "SUS_BlueInk",
	PrefabBundle = "character_enemy",
	PrefabName = "SUS_BlueInk",
	PrefabScale = 50,
	HPBarHeight = 100,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 876, Gain = 176},
		{Value = 200002, Base = 41, Gain = 9},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id5176] =
{
	Id = 5176,
	Name = "百年老树",
	Rarity = 3,
	Element = 210003,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "憨直的大树怪，结出的果实美味可口，听说还帮助科学家发现了万有引力。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	IconName = "RPG_dashu",
	PrefabBundle = "character_enemy",
	PrefabName = "RPG_dashu",
	PrefabScale = 50,
	HPBarHeight = 141,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 876, Gain = 176},
		{Value = 200002, Base = 41, Gain = 9},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id5177] =
{
	Id = 5177,
	Name = "古怪的牙医",
	Rarity = 3,
	Element = 210001,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "穿着特制工作服的法医，包揽了悬疑星所有的法医及法证工作，经常出入于凶案现场，负责处理各种现场证物。",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	IconName = "Sus_04_fayi",
	PrefabBundle = "character_sus",
	PrefabName = "Sus_04_fayi",
	SkinName = "1",
	PrefabScale = 50,
	HPBarHeight = 123,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 876, Gain = 176},
		{Value = 200002, Base = 41, Gain = 9},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id5178] =
{
	Id = 5178,
	Name = "抽卡爱好者",
	Rarity = 4,
	Element = 210005,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "来自神秘星球的部落酋长，部族世代受到不幸之神的祝福，虽然不会遭遇什么变故，但是做什么事情都比一般人不顺很多。",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	IconName = "SPDraw_04_UnlockChief",
	PrefabBundle = "character_sp",
	PrefabName = "SPDraw_04_UnlockChief",
	SkinName = "1",
	PrefabScale = 50,
	HPBarHeight = 125,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 813, Gain = 163},
		{Value = 200002, Base = 38, Gain = 8},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id5179] =
{
	Id = 5179,
	Name = "闪电海蛇",
	Rarity = 4,
	Element = 210003,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "曾是海蛇莱斯莉的队友，产出了许多重金属风格的demo，最近在尝试新的音乐风格。",
	IconBundle = "atlas_charactericon_sea",
	IconAtlas = "Sea",
	IconName = "SEA_Snake2",
	PrefabBundle = "character_enemy",
	PrefabName = "SEA_Snake2",
	PrefabScale = 50,
	HPBarHeight = 100,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 813, Gain = 163},
		{Value = 200002, Base = 38, Gain = 8},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id5180] =
{
	Id = 5180,
	Name = "王国的贵族",
	Rarity = 4,
	Element = 210001,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "某王国的女王大人，喜欢四处旅行。每次独自一人外出冒险，都会被路过的大小勇者带回城堡，时间久了甚至开始有勇者蹲她的刷新，以至于被误认为怪物。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	IconName = "Rpg_21_nvwangdaren",
	PrefabBundle = "character_rpg",
	PrefabName = "Rpg_21_nvwangdaren",
	SkinName = "1",
	PrefabScale = 50,
	HPBarHeight = 115,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 813, Gain = 163},
		{Value = 200002, Base = 38, Gain = 8},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id5181] =
{
	Id = 5181,
	Name = "记者",
	Rarity = 4,
	Element = 210003,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "背负着被告所有希望的悬疑星上班族，根据表面上的证据往往能得出不同结论，帮助被告脱罪，顺带把证人席上的某人定罪。\n“上了证人席，你还想跑？”",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	IconName = "Sus_13_lvshi",
	PrefabBundle = "character_sus",
	PrefabName = "Sus_13_lvshi",
	SkinName = "1",
	PrefabScale = 50,
	HPBarHeight = 112,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 813, Gain = 163},
		{Value = 200002, Base = 38, Gain = 8},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id5182] =
{
	Id = 5182,
	Name = "深海怪物",
	Rarity = 4,
	Element = 210005,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "精通伪装，不仅可以伪装自己的形态，还能把别人的声音模仿得惟妙惟肖。",
	IconBundle = "atlas_charactericon_sea",
	IconAtlas = "Sea",
	IconName = "SEA_Octupas1",
	PrefabBundle = "character_enemy",
	PrefabName = "SEA_Octupas1",
	PrefabScale = 50,
	HPBarHeight = 100,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 813, Gain = 163},
		{Value = 200002, Base = 38, Gain = 8},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id5183] =
{
	Id = 5183,
	Name = "像一颗海草",
	Rarity = 4,
	Element = 210003,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "完全没有一点主见的绿色海草，别人说什么就是什么，因此常常被其他鱼吐槽“绿草草，随风倒”。",
	IconBundle = "atlas_charactericon_sea",
	IconAtlas = "Sea",
	IconName = "SEA_Laminria1",
	PrefabBundle = "character_enemy",
	PrefabName = "SEA_Laminria1",
	PrefabScale = 50,
	HPBarHeight = 100,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 813, Gain = 163},
		{Value = 200002, Base = 38, Gain = 8},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id5184] =
{
	Id = 5184,
	Name = "原材料供应商",
	Rarity = 4,
	Element = 210002,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "海底自助化妆师，只要摸摸TA的头，TA就会突然窜出来，并迅速完成一套珊瑚红系的完美妆容，一次只要100海洋币。",
	IconBundle = "atlas_charactericon_sea",
	IconAtlas = "Sea",
	IconName = "SEA_Coral2",
	PrefabBundle = "character_enemy",
	PrefabName = "SEA_Coral2",
	PrefabScale = 50,
	HPBarHeight = 100,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 813, Gain = 163},
		{Value = 200002, Base = 38, Gain = 8},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id5185] =
{
	Id = 5185,
	Name = "狂热追求者",
	Rarity = 5,
	Element = 210004,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "事业有成的男性，平时很有教养，但是遇到让他抓狂的事情，就会暴露出可怕的一面。",
	IconBundle = "atlas_charactericon_npc",
	IconAtlas = "NPC",
	IconName = "NPC_men4",
	PrefabBundle = "character_npc",
	PrefabName = "NPC_men4",
	SkinName = "1",
	PrefabScale = 50,
	HPBarHeight = 100,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 765, Gain = 153},
		{Value = 200002, Base = 36, Gain = 8},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id5186] =
{
	Id = 5186,
	Name = "珍贵珊瑚",
	Rarity = 5,
	Element = 210001,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "海底自助化妆师，珊瑚红的同事，不过TA带来的是梅子紫系的全套妆容，一次150海洋币。",
	IconBundle = "atlas_charactericon_sea",
	IconAtlas = "Sea",
	IconName = "SEA_Coral1",
	PrefabBundle = "character_enemy",
	PrefabName = "SEA_Coral1",
	PrefabScale = 50,
	HPBarHeight = 100,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 693, Gain = 139},
		{Value = 200002, Base = 33, Gain = 7},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id5187] =
{
	Id = 5187,
	Name = "小护士",
	Rarity = 5,
	Element = 210004,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "整洁卫生的护士装，给人眼前一亮的感觉。同时取现代医学与古老奇迹之长处，将补血工作发挥到了极致。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	IconName = "Rpg_07_mushi_cos20",
	PrefabBundle = "character_rpg",
	PrefabName = "Rpg_07_mushi",
	SkinName = "3",
	PrefabScale = 50,
	HPBarHeight = 135,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 765, Gain = 153},
		{Value = 200002, Base = 36, Gain = 8},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id5188] =
{
	Id = 5188,
	Name = "无良老板",
	Rarity = 5,
	Element = 210003,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "天鱼公司总经理，唯董事长马首是瞻。",
	IconBundle = "atlas_charactericon_sea",
	IconAtlas = "Sea",
	IconName = "SEA_Crab",
	PrefabBundle = "character_enemy",
	PrefabName = "SEA_Crab",
	PrefabScale = 50,
	HPBarHeight = 130,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 693, Gain = 139},
		{Value = 200002, Base = 33, Gain = 7},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id5189] =
{
	Id = 5189,
	Name = "黑证办理员",
	Rarity = 4,
	Element = 210002,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "豆豆警官击败黑警长后在组织中建立的新身份。此后，他将以黑警长的身份继续深入调查组织内部的罪恶秘密，希望有一天能够将组织彻底捣毁。",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	IconName = "Sus_05_jingcha_cos10",
	PrefabBundle = "character_sus",
	PrefabName = "Sus_05_jingcha",
	SkinName = "2",
	PrefabScale = 50,
	HPBarHeight = 145,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 813, Gain = 163},
		{Value = 200002, Base = 38, Gain = 8},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id5190] =
{
	Id = 5190,
	Name = "行李怪人",
	Rarity = 4,
	Element = 210002,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "旅店运送行李的工具，这辆车本身并不是行李。",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "SUS",
	IconName = "SUS_Luggage",
	PrefabBundle = "character_enemy",
	PrefabName = "SUS_Luggage",
	PrefabScale = 50,
	HPBarHeight = 130,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 813, Gain = 163},
		{Value = 200002, Base = 38, Gain = 8},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id5191] =
{
	Id = 5191,
	Name = "豪车车主",
	Rarity = 4,
	Element = 210005,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "超人气王子，王子唱片董事长。每年都会开办36场演唱会，出18张专辑。不过唱片销量要靠常年打折外加赠送超值礼品才能维持。",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	IconName = "Fat_07_kele",
	PrefabBundle = "character_fat",
	PrefabName = "Fat_07_kele",
	SkinName = "1",
	PrefabScale = 50,
	HPBarHeight = 114,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 813, Gain = 163},
		{Value = 200002, Base = 38, Gain = 8},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id5192] =
{
	Id = 5192,
	Name = "发明家",
	Rarity = 4,
	Element = 210003,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "普通行动舱的强化版本，更适于在恶劣环境中进行战斗。不过为了节省舱体容量，因此去除了大量工作模块。",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	IconName = "Sus_24_boshi_cos10",
	PrefabBundle = "character_sus",
	PrefabName = "Sus_24_boshi",
	SkinName = "2",
	PrefabScale = 50,
	HPBarHeight = 170,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 813, Gain = 163},
		{Value = 200002, Base = 38, Gain = 8},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id5193] =
{
	Id = 5193,
	Name = "桃几本桃",
	Rarity = 3,
	Element = 210001,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "很受欢迎的桃几小姐，经常在宇宙间奔忙，为各大活动做代言人。每次自报家门的时候，对方都会以为她是大舌头。",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	IconName = "SPBUS_02_taozi",
	PrefabBundle = "character_sp",
	PrefabName = "SPBUS_02_taozi",
	SkinName = "1",
	PrefabScale = 50,
	HPBarHeight = 125,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 876, Gain = 176},
		{Value = 200002, Base = 41, Gain = 9},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id5194] =
{
	Id = 5194,
	Name = "卖履游商",
	Rarity = 3,
	Element = 210003,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "冒险星人气NPC，拥有没人见过的非凡实力。卖出去1000块的道具，下一秒就是100块的回收价，却没有谁敢和他们吵架。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	IconName = "Rpg_14_lvxingshangren",
	PrefabBundle = "character_rpg",
	PrefabName = "Rpg_14_lvxingshangren",
	SkinName = "1",
	PrefabScale = 50,
	HPBarHeight = 105,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 876, Gain = 176},
		{Value = 200002, Base = 41, Gain = 9},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id5195] =
{
	Id = 5195,
	Name = "时尚DJ",
	Rarity = 3,
	Element = 210005,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "酋长的DJ套装，只要他整个人沉浸入音乐王国时，双手就会不自觉地打出完美的节拍。",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	IconName = "SPDraw_04_UnlockChief_cos10",
	PrefabBundle = "character_sp",
	PrefabName = "SPDraw_04_UnlockChief",
	SkinName = "2",
	PrefabScale = 50,
	HPBarHeight = 140,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 876, Gain = 176},
		{Value = 200002, Base = 41, Gain = 9},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id5196] =
{
	Id = 5196,
	Name = "二手商贩",
	Rarity = 3,
	Element = 210003,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "冒险星人气NPC，拥有没人见过的非凡实力。卖出去1000块的道具，下一秒就是100块的回收价，却没有谁敢和他们吵架。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	IconName = "Rpg_14_lvxingshangren",
	PrefabBundle = "character_rpg",
	PrefabName = "Rpg_14_lvxingshangren",
	SkinName = "1",
	PrefabScale = 50,
	HPBarHeight = 105,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 876, Gain = 176},
		{Value = 200002, Base = 41, Gain = 9},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id5197] =
{
	Id = 5197,
	Name = "投降专业户",
	Rarity = 4,
	Element = 210002,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "守候在村子里德高望重的角色，同时担负着向冒险者发布主线任务及发放奖励的重要责任。不过会私下吞掉任务奖励的回扣，并瞒着妻子偷偷藏下私房钱。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	IconName = "Rpg_20_laoyeye",
	PrefabBundle = "character_rpg",
	PrefabName = "Rpg_20_laoyeye",
	SkinName = "1",
	PrefabScale = 50,
	HPBarHeight = 115,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 813, Gain = 163},
		{Value = 200002, Base = 38, Gain = 8},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id5198] =
{
	Id = 5198,
	Name = "黑武器发明家",
	Rarity = 4,
	Element = 210003,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "有深度近视的博士，想象力天马行空且行动力超强。发明虽然经常有非常致命的缺陷，但还是很受大家期待。",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	IconName = "Sus_24_boshi_cat",
	PrefabBundle = "character_sus",
	PrefabName = "Sus_24_boshi",
	SkinName = "1_cat",
	PrefabScale = 50,
	HPBarHeight = 185,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 813, Gain = 163},
		{Value = 200002, Base = 38, Gain = 8},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id5199] =
{
	Id = 5199,
	Name = "告密的珠宝匠",
	Rarity = 4,
	Element = 210002,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "铁匠打出的铁无可挑剔，唯一的问题就是没有运输工具。为此铁匠学会了套鹿的技能。套了100头鹿后，铁匠创立了顺鹿快递拉货公司。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	IconName = "Rpg_31_tiejiang_cos10",
	PrefabBundle = "character_rpg",
	PrefabName = "Rpg_31_tiejiang",
	SkinName = "2",
	PrefabScale = 50,
	HPBarHeight = 140,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 813, Gain = 163},
		{Value = 200002, Base = 38, Gain = 8},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id5200] =
{
	Id = 5200,
	Name = "长刺的动物",
	Rarity = 4,
	Element = 210005,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "在任何地区都能悠闲漫步的魔物。遇到危险时，就会竖起身上的钢针进行抵御。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	IconName = "RPG_SeaUrchin",
	PrefabBundle = "character_enemy",
	PrefabName = "RPG_SeaUrchin",
	PrefabScale = 50,
	HPBarHeight = 76,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 813, Gain = 163},
		{Value = 200002, Base = 38, Gain = 8},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id5201] =
{
	Id = 5201,
	Name = "跑酷达人",
	Rarity = 4,
	Element = 210003,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "经典冒险组的神秘狼族少年，因为俊朗的外形和冷酷的性格相当受异性欢迎。其实本人很富于爱心，平时还会照顾流浪的小动物。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	IconName = "Rpg_08_cike",
	PrefabBundle = "character_rpg",
	PrefabName = "Rpg_08_cike",
	SkinName = "1",
	PrefabScale = 50,
	HPBarHeight = 105,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 813, Gain = 163},
		{Value = 200002, Base = 38, Gain = 8},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id5202] =
{
	Id = 5202,
	Name = "阵亡骑士",
	Rarity = 3,
	Element = 210005,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "受到国王册封，荣升骑士头衔的战马，象征着王国高贵的骑士精神。平时虽然总是标榜自己的崇高道德，不过打完仗拿战利品时却毫不手软。",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	IconName = "All_Chess_WhiteKnight_cos10",
	PrefabBundle = "character_sp",
	PrefabName = "All_Chess_WhiteKnight",
	SkinName = "2",
	PrefabScale = 50,
	HPBarHeight = 145,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 876, Gain = 176},
		{Value = 200002, Base = 41, Gain = 9},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id5203] =
{
	Id = 5203,
	Name = "一坨美食",
	Rarity = 3,
	Element = 210003,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "最恨人说烂泥扶不上墙，一旦听到就会发飙。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	IconName = "RPG_ruannidui",
	PrefabBundle = "character_enemy",
	PrefabName = "RPG_ruannidui",
	PrefabScale = 50,
	HPBarHeight = 76,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 1183, Gain = 237},
		{Value = 200002, Base = 56, Gain = 12},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id5204] =
{
	Id = 5204,
	Name = "化肥专家",
	Rarity = 4,
	Element = 210005,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "内置物质转换器的防化服，据说价值180亿。可以过滤任何形式的有害物质，对于进行危险实验能起到至关重要的保护作用。",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	IconName = "Sus_03_moliyadi_cos30",
	PrefabBundle = "character_sus",
	PrefabName = "Sus_03_moliyadi",
	SkinName = "4",
	PrefabScale = 50,
	HPBarHeight = 140,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 1118, Gain = 224},
		{Value = 200002, Base = 53, Gain = 11},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id5205] =
{
	Id = 5205,
	Name = "黑市交易员",
	Rarity = 4,
	Element = 210005,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "藏在暗处的异生物，随星球创造而生。内部有严格的等级制度，普通霸格偶尔被看到也会被无视，高危霸格反而每天都要担心被除虫者干掉。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	IconName = "Rpg_28_bug",
	PrefabBundle = "character_rpg",
	PrefabName = "Rpg_28_bug",
	SkinName = "1",
	PrefabScale = 50,
	HPBarHeight = 105,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 1118, Gain = 224},
		{Value = 200002, Base = 53, Gain = 11},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id5206] =
{
	Id = 5206,
	Name = "厨具守护者",
	Rarity = 4,
	Element = 210001,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "国王御用侍卫，从小陪伴薯条国王长大。能根据薯条国王的状态，时刻调整自己的甜度，深得薯条国王信赖。每次战后他都会在第一时间被送往医院，尽管大部分时候只是包装袋破了。",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	IconName = "Fat_31_fanqiejiang",
	PrefabBundle = "character_fat",
	PrefabName = "Fat_31_fanqiejiang",
	SkinName = "1",
	PrefabScale = 50,
	HPBarHeight = 106,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 813, Gain = 163},
		{Value = 200002, Base = 38, Gain = 8},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id5207] =
{
	Id = 5207,
	Name = "实验室负责人",
	Rarity = 3,
	Element = 210003,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "普通行动舱的强化版本，更适于在恶劣环境中进行战斗。不过为了节省舱体容量，因此去除了大量工作模块。",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	IconName = "Sus_24_boshi_cos10",
	PrefabBundle = "character_sus",
	PrefabName = "Sus_24_boshi",
	SkinName = "2",
	PrefabScale = 50,
	HPBarHeight = 170,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 876, Gain = 176},
		{Value = 200002, Base = 41, Gain = 9},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id5208] =
{
	Id = 5208,
	Name = "旅行商人",
	Rarity = 2,
	Element = 210003,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "冒险星人气NPC，拥有没人见过的非凡实力。卖出去1000块的道具，下一秒就是100块的回收价，却没有谁敢和他们吵架。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	IconName = "Rpg_14_lvxingshangren",
	PrefabBundle = "character_rpg",
	PrefabName = "Rpg_14_lvxingshangren",
	SkinName = "1",
	PrefabScale = 50,
	HPBarHeight = 105,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 847, Gain = 170},
		{Value = 200002, Base = 40, Gain = 8},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id5209] =
{
	Id = 5209,
	Name = "旅行商人",
	Rarity = 2,
	Element = 210003,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "冒险星人气NPC，拥有没人见过的非凡实力。卖出去1000块的道具，下一秒就是100块的回收价，却没有谁敢和他们吵架。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	IconName = "Rpg_14_lvxingshangren",
	PrefabBundle = "character_rpg",
	PrefabName = "Rpg_14_lvxingshangren",
	SkinName = "1",
	PrefabScale = 50,
	HPBarHeight = 105,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 847, Gain = 170},
		{Value = 200002, Base = 40, Gain = 8},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id5210] =
{
	Id = 5210,
	Name = "旅行商人",
	Rarity = 2,
	Element = 210003,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "冒险星人气NPC，拥有没人见过的非凡实力。卖出去1000块的道具，下一秒就是100块的回收价，却没有谁敢和他们吵架。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	IconName = "Rpg_14_lvxingshangren",
	PrefabBundle = "character_rpg",
	PrefabName = "Rpg_14_lvxingshangren",
	SkinName = "1",
	PrefabScale = 50,
	HPBarHeight = 105,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 847, Gain = 170},
		{Value = 200002, Base = 40, Gain = 8},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id5211] =
{
	Id = 5211,
	Name = "旅行商人",
	Rarity = 2,
	Element = 210003,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "冒险星人气NPC，拥有没人见过的非凡实力。卖出去1000块的道具，下一秒就是100块的回收价，却没有谁敢和他们吵架。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	IconName = "Rpg_14_lvxingshangren",
	PrefabBundle = "character_rpg",
	PrefabName = "Rpg_14_lvxingshangren",
	SkinName = "1",
	PrefabScale = 50,
	HPBarHeight = 105,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 847, Gain = 170},
		{Value = 200002, Base = 40, Gain = 8},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id5212] =
{
	Id = 5212,
	Name = "旅行商人",
	Rarity = 2,
	Element = 210003,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "冒险星人气NPC，拥有没人见过的非凡实力。卖出去1000块的道具，下一秒就是100块的回收价，却没有谁敢和他们吵架。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	IconName = "Rpg_14_lvxingshangren",
	PrefabBundle = "character_rpg",
	PrefabName = "Rpg_14_lvxingshangren",
	SkinName = "1",
	PrefabScale = 50,
	HPBarHeight = 105,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 847, Gain = 170},
		{Value = 200002, Base = 40, Gain = 8},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id5213] =
{
	Id = 5213,
	Name = "旅行商人",
	Rarity = 2,
	Element = 210003,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "冒险星人气NPC，拥有没人见过的非凡实力。卖出去1000块的道具，下一秒就是100块的回收价，却没有谁敢和他们吵架。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	IconName = "Rpg_14_lvxingshangren",
	PrefabBundle = "character_rpg",
	PrefabName = "Rpg_14_lvxingshangren",
	SkinName = "1",
	PrefabScale = 50,
	HPBarHeight = 105,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 847, Gain = 170},
		{Value = 200002, Base = 40, Gain = 8},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id5214] =
{
	Id = 5214,
	Name = "旅行商人",
	Rarity = 3,
	Element = 210003,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "冒险星人气NPC，拥有没人见过的非凡实力。卖出去1000块的道具，下一秒就是100块的回收价，却没有谁敢和他们吵架。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	IconName = "Rpg_14_lvxingshangren",
	PrefabBundle = "character_rpg",
	PrefabName = "Rpg_14_lvxingshangren",
	SkinName = "1",
	PrefabScale = 50,
	HPBarHeight = 105,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 876, Gain = 176},
		{Value = 200002, Base = 41, Gain = 9},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id5215] =
{
	Id = 5215,
	Name = "旅行商人",
	Rarity = 3,
	Element = 210003,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "冒险星人气NPC，拥有没人见过的非凡实力。卖出去1000块的道具，下一秒就是100块的回收价，却没有谁敢和他们吵架。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	IconName = "Rpg_14_lvxingshangren",
	PrefabBundle = "character_rpg",
	PrefabName = "Rpg_14_lvxingshangren",
	SkinName = "1",
	PrefabScale = 50,
	HPBarHeight = 105,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 876, Gain = 176},
		{Value = 200002, Base = 41, Gain = 9},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id5216] =
{
	Id = 5216,
	Name = "旅行商人",
	Rarity = 3,
	Element = 210003,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "冒险星人气NPC，拥有没人见过的非凡实力。卖出去1000块的道具，下一秒就是100块的回收价，却没有谁敢和他们吵架。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	IconName = "Rpg_14_lvxingshangren",
	PrefabBundle = "character_rpg",
	PrefabName = "Rpg_14_lvxingshangren",
	SkinName = "1",
	PrefabScale = 50,
	HPBarHeight = 105,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 876, Gain = 176},
		{Value = 200002, Base = 41, Gain = 9},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id5217] =
{
	Id = 5217,
	Name = "旅行商人",
	Rarity = 3,
	Element = 210003,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "冒险星人气NPC，拥有没人见过的非凡实力。卖出去1000块的道具，下一秒就是100块的回收价，却没有谁敢和他们吵架。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	IconName = "Rpg_14_lvxingshangren",
	PrefabBundle = "character_rpg",
	PrefabName = "Rpg_14_lvxingshangren",
	SkinName = "1",
	PrefabScale = 50,
	HPBarHeight = 105,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 876, Gain = 176},
		{Value = 200002, Base = 41, Gain = 9},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id5218] =
{
	Id = 5218,
	Name = "旅行商人",
	Rarity = 3,
	Element = 210003,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "冒险星人气NPC，拥有没人见过的非凡实力。卖出去1000块的道具，下一秒就是100块的回收价，却没有谁敢和他们吵架。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	IconName = "Rpg_14_lvxingshangren",
	PrefabBundle = "character_rpg",
	PrefabName = "Rpg_14_lvxingshangren",
	SkinName = "1",
	PrefabScale = 50,
	HPBarHeight = 105,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 876, Gain = 176},
		{Value = 200002, Base = 41, Gain = 9},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id5219] =
{
	Id = 5219,
	Name = "旅行商人",
	Rarity = 3,
	Element = 210003,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "冒险星人气NPC，拥有没人见过的非凡实力。卖出去1000块的道具，下一秒就是100块的回收价，却没有谁敢和他们吵架。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	IconName = "Rpg_14_lvxingshangren",
	PrefabBundle = "character_rpg",
	PrefabName = "Rpg_14_lvxingshangren",
	SkinName = "1",
	PrefabScale = 50,
	HPBarHeight = 105,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 876, Gain = 176},
		{Value = 200002, Base = 41, Gain = 9},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id5220] =
{
	Id = 5220,
	Name = "旅行商人",
	Rarity = 3,
	Element = 210004,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "经典冒险组人气角色，携带着大量法器，能够给予其他冒险者们勇气和希望。\n听说，一起组队的男冒险者经常会偷偷给她递小纸条。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	IconName = "Rpg_07_mushi",
	PrefabBundle = "character_rpg",
	PrefabName = "Rpg_07_mushi",
	SkinName = "1",
	PrefabScale = 50,
	HPBarHeight = 115,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 876, Gain = 176},
		{Value = 200002, Base = 41, Gain = 9},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id5221] =
{
	Id = 5221,
	Name = "旅行商人",
	Rarity = 3,
	Element = 210003,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "很久很久以前，一位画家为想要呐喊之人而作的画。流传至今变成了一个流行的表情。",
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "Mus",
	IconName = "MUS_19_nahan",
	PrefabBundle = "character_mus",
	PrefabName = "MUS_19_nahan",
	SkinName = "1",
	PrefabScale = 50,
	HPBarHeight = 115,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 876, Gain = 176},
		{Value = 200002, Base = 41, Gain = 9},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id5222] =
{
	Id = 5222,
	Name = "旅行商人",
	Rarity = 3,
	Element = 210003,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "经典冒险组的神秘狼族少年，因为俊朗的外形和冷酷的性格相当受异性欢迎。其实本人很富于爱心，平时还会照顾流浪的小动物。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	IconName = "Rpg_08_cike",
	PrefabBundle = "character_rpg",
	PrefabName = "Rpg_08_cike",
	SkinName = "1",
	PrefabScale = 50,
	HPBarHeight = 105,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 876, Gain = 176},
		{Value = 200002, Base = 41, Gain = 9},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id5223] =
{
	Id = 5223,
	Name = "旅行商人",
	Rarity = 3,
	Element = 210005,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "神秘组织成员，脸上总是挂着一幅让人捉摸不透的表情，感觉像戴着面具。\n不过如果你和他聊起遥控飞机，那么很快就会熟络起来。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	IconName = "Rpg_27_donghua",
	PrefabBundle = "character_rpg",
	PrefabName = "Rpg_27_donghua",
	SkinName = "1",
	PrefabScale = 50,
	HPBarHeight = 105,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 876, Gain = 176},
		{Value = 200002, Base = 41, Gain = 9},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id5224] =
{
	Id = 5224,
	Name = "旅行商人",
	Rarity = 3,
	Element = 210002,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "认真负责的编辑长，为了不辜负读者，每天都在兢兢业业地工作。每5分钟都会联系约稿作家，防止对方放水。",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	IconName = "Sus_22_bianji",
	PrefabBundle = "character_sus",
	PrefabName = "Sus_22_bianji",
	SkinName = "1",
	PrefabScale = 50,
	HPBarHeight = 112,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 876, Gain = 176},
		{Value = 200002, Base = 41, Gain = 9},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id5225] =
{
	Id = 5225,
	Name = "旅行商人",
	Rarity = 4,
	Element = 210003,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：躲在小学门口，敲诈放学回家的小学生。",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	IconName = "Arena_RPG_xiaohuaqiu",
	PrefabBundle = "character_arenaenemy",
	PrefabName = "Arena_RPG_xiaohuaqiu",
	PrefabScale = 50,
	HPBarHeight = 76,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 813, Gain = 163},
		{Value = 200002, Base = 38, Gain = 8},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id5226] =
{
	Id = 5226,
	Name = "旅行商人",
	Rarity = 4,
	Element = 210003,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：躲在小学门口，敲诈放学回家的小学生。",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	IconName = "Arena_RPG_xiaohuaqiu",
	PrefabBundle = "character_arenaenemy",
	PrefabName = "Arena_RPG_xiaohuaqiu",
	PrefabScale = 50,
	HPBarHeight = 76,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 813, Gain = 163},
		{Value = 200002, Base = 38, Gain = 8},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id5227] =
{
	Id = 5227,
	Name = "旅行商人",
	Rarity = 4,
	Element = 210003,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：躲在小学门口，敲诈放学回家的小学生。",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	IconName = "Arena_RPG_xiaohuaqiu",
	PrefabBundle = "character_arenaenemy",
	PrefabName = "Arena_RPG_xiaohuaqiu",
	PrefabScale = 50,
	HPBarHeight = 76,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 813, Gain = 163},
		{Value = 200002, Base = 38, Gain = 8},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id5228] =
{
	Id = 5228,
	Name = "旅行商人",
	Rarity = 4,
	Element = 210003,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：躲在小学门口，敲诈放学回家的小学生。",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	IconName = "Arena_RPG_xiaohuaqiu",
	PrefabBundle = "character_arenaenemy",
	PrefabName = "Arena_RPG_xiaohuaqiu",
	PrefabScale = 50,
	HPBarHeight = 76,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 813, Gain = 163},
		{Value = 200002, Base = 38, Gain = 8},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id5229] =
{
	Id = 5229,
	Name = "旅行商人",
	Rarity = 4,
	Element = 210003,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：躲在小学门口，敲诈放学回家的小学生。",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	IconName = "Arena_RPG_xiaohuaqiu",
	PrefabBundle = "character_arenaenemy",
	PrefabName = "Arena_RPG_xiaohuaqiu",
	PrefabScale = 50,
	HPBarHeight = 76,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 813, Gain = 163},
		{Value = 200002, Base = 38, Gain = 8},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id5230] =
{
	Id = 5230,
	Name = "旅行商人",
	Rarity = 4,
	Element = 210003,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：躲在小学门口，敲诈放学回家的小学生。",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	IconName = "Arena_RPG_xiaohuaqiu",
	PrefabBundle = "character_arenaenemy",
	PrefabName = "Arena_RPG_xiaohuaqiu",
	PrefabScale = 50,
	HPBarHeight = 76,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 813, Gain = 163},
		{Value = 200002, Base = 38, Gain = 8},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id5231] =
{
	Id = 5231,
	Name = "旅行商人",
	Rarity = 5,
	Element = 210003,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：躲在小学门口，敲诈放学回家的小学生。",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	IconName = "Arena_RPG_xiaohuaqiu",
	PrefabBundle = "character_arenaenemy",
	PrefabName = "Arena_RPG_xiaohuaqiu",
	PrefabScale = 50,
	HPBarHeight = 76,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 765, Gain = 153},
		{Value = 200002, Base = 36, Gain = 8},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id5232] =
{
	Id = 5232,
	Name = "旅行商人",
	Rarity = 5,
	Element = 210003,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：躲在小学门口，敲诈放学回家的小学生。",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	IconName = "Arena_RPG_xiaohuaqiu",
	PrefabBundle = "character_arenaenemy",
	PrefabName = "Arena_RPG_xiaohuaqiu",
	PrefabScale = 50,
	HPBarHeight = 76,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 693, Gain = 139},
		{Value = 200002, Base = 33, Gain = 7},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id5233] =
{
	Id = 5233,
	Name = "旅行商人",
	Rarity = 5,
	Element = 210003,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：躲在小学门口，敲诈放学回家的小学生。",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	IconName = "Arena_RPG_xiaohuaqiu",
	PrefabBundle = "character_arenaenemy",
	PrefabName = "Arena_RPG_xiaohuaqiu",
	PrefabScale = 50,
	HPBarHeight = 76,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 765, Gain = 153},
		{Value = 200002, Base = 36, Gain = 8},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id5234] =
{
	Id = 5234,
	Name = "旅行商人",
	Rarity = 5,
	Element = 210003,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：躲在小学门口，敲诈放学回家的小学生。",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	IconName = "Arena_RPG_xiaohuaqiu",
	PrefabBundle = "character_arenaenemy",
	PrefabName = "Arena_RPG_xiaohuaqiu",
	PrefabScale = 50,
	HPBarHeight = 76,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 693, Gain = 139},
		{Value = 200002, Base = 33, Gain = 7},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id5235] =
{
	Id = 5235,
	Name = "仙界书法家",
	Rarity = 3,
	Element = 210003,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "因法力太弱而落在最后的八仙之一，与朋友走散后，被带入星际传销组织，凭着精明的头脑和过人的口才，目前已经成为该传销组织的精神领袖。组织在曹国舅的带领下转型成股票经纪公司。",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	IconName = "All_EightImmortal_CaoGuoJiu",
	PrefabBundle = "character_sp",
	PrefabName = "All_EightImmortal_CaoGuoJiu",
	SkinName = "1",
	PrefabScale = 50,
	HPBarHeight = 125,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 876, Gain = 176},
		{Value = 200002, Base = 41, Gain = 9},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id5236] =
{
	Id = 5236,
	Name = "仙界书法家",
	Rarity = 3,
	Element = 210003,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "因法力太弱而落在最后的八仙之一，与朋友走散后，被带入星际传销组织，凭着精明的头脑和过人的口才，目前已经成为该传销组织的精神领袖。组织在曹国舅的带领下转型成股票经纪公司。",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	IconName = "All_EightImmortal_CaoGuoJiu",
	PrefabBundle = "character_sp",
	PrefabName = "All_EightImmortal_CaoGuoJiu",
	SkinName = "1",
	PrefabScale = 50,
	HPBarHeight = 125,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 813, Gain = 163},
		{Value = 200002, Base = 38, Gain = 8},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id5237] =
{
	Id = 5237,
	Name = "仙界书法家",
	Rarity = 3,
	Element = 210003,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "因法力太弱而落在最后的八仙之一，与朋友走散后，被带入星际传销组织，凭着精明的头脑和过人的口才，目前已经成为该传销组织的精神领袖。组织在曹国舅的带领下转型成股票经纪公司。",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	IconName = "All_EightImmortal_CaoGuoJiu",
	PrefabBundle = "character_sp",
	PrefabName = "All_EightImmortal_CaoGuoJiu",
	SkinName = "1",
	PrefabScale = 50,
	HPBarHeight = 125,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 876, Gain = 176},
		{Value = 200002, Base = 41, Gain = 9},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id5238] =
{
	Id = 5238,
	Name = "仙界书法家",
	Rarity = 3,
	Element = 210003,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "因法力太弱而落在最后的八仙之一，与朋友走散后，被带入星际传销组织，凭着精明的头脑和过人的口才，目前已经成为该传销组织的精神领袖。组织在曹国舅的带领下转型成股票经纪公司。",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	IconName = "All_EightImmortal_CaoGuoJiu",
	PrefabBundle = "character_sp",
	PrefabName = "All_EightImmortal_CaoGuoJiu",
	SkinName = "1",
	PrefabScale = 50,
	HPBarHeight = 125,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 813, Gain = 163},
		{Value = 200002, Base = 38, Gain = 8},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id5239] =
{
	Id = 5239,
	Name = "仙界书法家",
	Rarity = 3,
	Element = 210003,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "因法力太弱而落在最后的八仙之一，与朋友走散后，被带入星际传销组织，凭着精明的头脑和过人的口才，目前已经成为该传销组织的精神领袖。组织在曹国舅的带领下转型成股票经纪公司。",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	IconName = "All_EightImmortal_CaoGuoJiu",
	PrefabBundle = "character_sp",
	PrefabName = "All_EightImmortal_CaoGuoJiu",
	SkinName = "1",
	PrefabScale = 50,
	HPBarHeight = 125,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 876, Gain = 176},
		{Value = 200002, Base = 41, Gain = 9},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id5240] =
{
	Id = 5240,
	Name = "仙界书法家",
	Rarity = 3,
	Element = 210003,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "因法力太弱而落在最后的八仙之一，与朋友走散后，被带入星际传销组织，凭着精明的头脑和过人的口才，目前已经成为该传销组织的精神领袖。组织在曹国舅的带领下转型成股票经纪公司。",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	IconName = "All_EightImmortal_CaoGuoJiu",
	PrefabBundle = "character_sp",
	PrefabName = "All_EightImmortal_CaoGuoJiu",
	SkinName = "1",
	PrefabScale = 50,
	HPBarHeight = 125,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 813, Gain = 163},
		{Value = 200002, Base = 38, Gain = 8},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id5241] =
{
	Id = 5241,
	Name = "仙界书法家",
	Rarity = 3,
	Element = 210003,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "因法力太弱而落在最后的八仙之一，与朋友走散后，被带入星际传销组织，凭着精明的头脑和过人的口才，目前已经成为该传销组织的精神领袖。组织在曹国舅的带领下转型成股票经纪公司。",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	IconName = "All_EightImmortal_CaoGuoJiu",
	PrefabBundle = "character_sp",
	PrefabName = "All_EightImmortal_CaoGuoJiu",
	SkinName = "1",
	PrefabScale = 50,
	HPBarHeight = 125,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 876, Gain = 176},
		{Value = 200002, Base = 41, Gain = 9},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id5242] =
{
	Id = 5242,
	Name = "仙界书法家",
	Rarity = 3,
	Element = 210003,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "因法力太弱而落在最后的八仙之一，与朋友走散后，被带入星际传销组织，凭着精明的头脑和过人的口才，目前已经成为该传销组织的精神领袖。组织在曹国舅的带领下转型成股票经纪公司。",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	IconName = "All_EightImmortal_CaoGuoJiu",
	PrefabBundle = "character_sp",
	PrefabName = "All_EightImmortal_CaoGuoJiu",
	SkinName = "1",
	PrefabScale = 50,
	HPBarHeight = 125,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 813, Gain = 163},
		{Value = 200002, Base = 38, Gain = 8},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id5243] =
{
	Id = 5243,
	Name = "仙界书法家",
	Rarity = 4,
	Element = 210003,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "因法力太弱而落在最后的八仙之一，与朋友走散后，被带入星际传销组织，凭着精明的头脑和过人的口才，目前已经成为该传销组织的精神领袖。组织在曹国舅的带领下转型成股票经纪公司。",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	IconName = "All_EightImmortal_CaoGuoJiu",
	PrefabBundle = "character_sp",
	PrefabName = "All_EightImmortal_CaoGuoJiu",
	SkinName = "1",
	PrefabScale = 50,
	HPBarHeight = 125,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 813, Gain = 163},
		{Value = 200002, Base = 38, Gain = 8},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id5244] =
{
	Id = 5244,
	Name = "仙界书法家",
	Rarity = 4,
	Element = 210003,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "因法力太弱而落在最后的八仙之一，与朋友走散后，被带入星际传销组织，凭着精明的头脑和过人的口才，目前已经成为该传销组织的精神领袖。组织在曹国舅的带领下转型成股票经纪公司。",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	IconName = "All_EightImmortal_CaoGuoJiu",
	PrefabBundle = "character_sp",
	PrefabName = "All_EightImmortal_CaoGuoJiu",
	SkinName = "1",
	PrefabScale = 50,
	HPBarHeight = 125,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 744, Gain = 149},
		{Value = 200002, Base = 35, Gain = 7},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id5245] =
{
	Id = 5245,
	Name = "点火装置",
	Rarity = 4,
	Element = 210002,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "数据证明，百分之九十九的冒险家无法分清不同的小火球。\n它从岩浆里跳了起来，它掉了下去。\n它的兄弟从岩浆里跳了起来。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	IconName = "RPG_Fireball",
	PrefabBundle = "character_enemy",
	PrefabName = "RPG_Fireball",
	PrefabScale = 50,
	HPBarHeight = 76,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 813, Gain = 163},
		{Value = 200002, Base = 38, Gain = 8},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id5246] =
{
	Id = 5246,
	Name = "调皮水花",
	Rarity = 5,
	Element = 210001,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "居住在溪谷的水之精灵，由魔法之泉构成。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	IconName = "RPG_Undine",
	PrefabBundle = "character_enemy",
	PrefabName = "RPG_Undine",
	PrefabScale = 50,
	HPBarHeight = 100,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 765, Gain = 153},
		{Value = 200002, Base = 36, Gain = 8},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id5247] =
{
	Id = 5247,
	Name = "算命商人",
	Rarity = 5,
	Element = 210003,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "每当旅行商人没钱进货的时候，他就会拿出这套装备，从事那些无本买卖，比如：看相鉴运，风水命理，趋吉避凶，祈福除祸，还能算五行，算八卦，算中宫，测仕途，测财行，测爱情，定紫微，定北斗等等等等。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	IconName = "Rpg_14_lvxingshangren_cos10",
	PrefabBundle = "character_rpg",
	PrefabName = "Rpg_14_lvxingshangren",
	SkinName = "2",
	PrefabScale = 50,
	HPBarHeight = 150,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 693, Gain = 139},
		{Value = 200002, Base = 33, Gain = 7},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id5248] =
{
	Id = 5248,
	Name = "恶魔卫士",
	Rarity = 4,
	Element = 210002,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "火山的可怕魔物，喷吐的烈焰可以融化矿石，是魔王城堡当之无愧的强者。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	IconName = "RPG_GiantFire",
	PrefabBundle = "character_enemy",
	PrefabName = "RPG_GiantFire",
	PrefabScale = 50,
	HPBarHeight = 114,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 813, Gain = 163},
		{Value = 200002, Base = 38, Gain = 8},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id5249] =
{
	Id = 5249,
	Name = "百花精灵",
	Rarity = 5,
	Element = 210003,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "活泼好动的小花球，有时候会溜进人类的城镇里探险。不喜欢自己的名字，正在努力减肥，希望能被人叫做小花干。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	IconName = "RPG_xiaohuaqiu",
	PrefabBundle = "character_enemy",
	PrefabName = "RPG_xiaohuaqiu",
	PrefabScale = 50,
	HPBarHeight = 76,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 765, Gain = 153},
		{Value = 200002, Base = 36, Gain = 8},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id5250] =
{
	Id = 5250,
	Name = "世界树之子",
	Rarity = 5,
	Element = 210003,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "憨直的大树怪，结出的果实美味可口，听说还帮助科学家发现了万有引力。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	IconName = "RPG_dashu",
	PrefabBundle = "character_enemy",
	PrefabName = "RPG_dashu",
	PrefabScale = 50,
	HPBarHeight = 141,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 693, Gain = 139},
		{Value = 200002, Base = 33, Gain = 7},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id5251] =
{
	Id = 5251,
	Name = "黑巧克力皇后",
	Rarity = 3,
	Element = 210005,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "冰淇淋公主的继母，非常在意市面上的畅销冷饮排行榜。每天都会查询若干次榜单，有时候为了第一，还会找人刷榜。",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	IconName = "Fat_11_tiantong",
	PrefabBundle = "character_fat",
	PrefabName = "Fat_11_tiantong",
	SkinName = "1",
	PrefabScale = 50,
	HPBarHeight = 114,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 876, Gain = 176},
		{Value = 200002, Base = 41, Gain = 9},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id5252] =
{
	Id = 5252,
	Name = "智力开发专家",
	Rarity = 3,
	Element = 210003,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "有深度近视的博士，想象力天马行空且行动力超强。发明虽然经常有非常致命的缺陷，但还是很受大家期待。",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	IconName = "Sus_24_boshi",
	PrefabBundle = "character_sus",
	PrefabName = "Sus_24_boshi",
	SkinName = "1",
	PrefabScale = 50,
	HPBarHeight = 119,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 876, Gain = 176},
		{Value = 200002, Base = 41, Gain = 9},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id5253] =
{
	Id = 5253,
	Name = "麻醉花椒",
	Rarity = 3,
	Element = 210003,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "花椒中的稀有品种，凡是接触到它的人，都会出现短暂的麻痹现象。",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "FAT",
	IconName = "FAT_SichuanPepper",
	PrefabBundle = "character_enemy",
	PrefabName = "FAT_SichuanPepper",
	PrefabScale = 50,
	HPBarHeight = 100,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 876, Gain = 176},
		{Value = 200002, Base = 41, Gain = 9},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id5254] =
{
	Id = 5254,
	Name = "温泉蛋专家",
	Rarity = 3,
	Element = 210002,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "与光明料理会不共戴天的料理者。被美食星驱逐后，成为了流亡街的居民。目前处于无照经营摊贩的状态，会推着料理小车，制作出让人无法拒绝的邪恶美食。",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	IconName = "Pir_01_DarkCooker",
	PrefabBundle = "character_boss",
	PrefabName = "Pir_01_DarkCooker",
	SkinName = "1",
	PrefabScale = 50,
	HPBarHeight = 125,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 876, Gain = 176},
		{Value = 200002, Base = 41, Gain = 9},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id5255] =
{
	Id = 5255,
	Name = "吃土达人",
	Rarity = 3,
	Element = 210005,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "来自神秘星球的部落酋长，部族世代受到不幸之神的祝福，虽然不会遭遇什么变故，但是做什么事情都比一般人不顺很多。",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	IconName = "SPDraw_04_UnlockChief",
	PrefabBundle = "character_sp",
	PrefabName = "SPDraw_04_UnlockChief",
	SkinName = "1",
	PrefabScale = 50,
	HPBarHeight = 125,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 876, Gain = 176},
		{Value = 200002, Base = 41, Gain = 9},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id5256] =
{
	Id = 5256,
	Name = "捏鼻子大王",
	Rarity = 4,
	Element = 210003,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "热衷健身的美食城国王，每天健身8小时，之后去皇家油锅泡澡8小时，然后睡8小时。肌肉含量120%，用力的话可以撑爆背心。",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	IconName = "Fat_30_shutiao",
	PrefabBundle = "character_fat",
	PrefabName = "Fat_30_shutiao",
	SkinName = "1",
	PrefabScale = 50,
	HPBarHeight = 106,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 813, Gain = 163},
		{Value = 200002, Base = 38, Gain = 8},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id5257] =
{
	Id = 5257,
	Name = "伪装的禽类",
	Rarity = 4,
	Element = 210003,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "非常喜欢结伴出游的鸟类，不过到了约定当天总是会接到Ta的各种表示无法如约的电话。",
	IconBundle = "atlas_charactericon_npc",
	IconAtlas = "NPC",
	IconName = "NPC_gugu1",
	PrefabBundle = "character_npc",
	PrefabName = "NPC_gugu1",
	SkinName = "1",
	PrefabScale = 50,
	HPBarHeight = 100,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 813, Gain = 163},
		{Value = 200002, Base = 38, Gain = 8},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id5258] =
{
	Id = 5258,
	Name = "智力开发专家",
	Rarity = 4,
	Element = 210003,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "有深度近视的博士，想象力天马行空且行动力超强。发明虽然经常有非常致命的缺陷，但还是很受大家期待。",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	IconName = "Sus_24_boshi",
	PrefabBundle = "character_sus",
	PrefabName = "Sus_24_boshi",
	SkinName = "1",
	PrefabScale = 50,
	HPBarHeight = 119,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 813, Gain = 163},
		{Value = 200002, Base = 38, Gain = 8},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id5259] =
{
	Id = 5259,
	Name = "咖啡女仆",
	Rarity = 4,
	Element = 210005,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "带着明星梦来到甜品镇的美丽女孩，目前在咖啡馆打工。每次电影试镜会都参加，希望能够在荧幕上展现自己。拿手绝技是转圈，但总是会烫到评委。",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	IconName = "Fat_06_kafei",
	PrefabBundle = "character_fat",
	PrefabName = "Fat_06_kafei",
	SkinName = "1",
	PrefabScale = 50,
	HPBarHeight = 106,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 813, Gain = 163},
		{Value = 200002, Base = 38, Gain = 8},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id5260] =
{
	Id = 5260,
	Name = "酒杯收藏家",
	Rarity = 5,
	Element = 210003,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "老年男性，享受着安详的退休生活，但是偶尔也会有发火的时候。",
	IconBundle = "atlas_charactericon_npc",
	IconAtlas = "NPC",
	IconName = "NPC_oldmen1",
	PrefabBundle = "character_npc",
	PrefabName = "NPC_oldmen1",
	SkinName = "1",
	PrefabScale = 50,
	HPBarHeight = 100,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 765, Gain = 153},
		{Value = 200002, Base = 36, Gain = 8},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id5261] =
{
	Id = 5261,
	Name = "安检专员",
	Rarity = 5,
	Element = 210002,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "小镇新来的热血干探，一丝不苟且乐于助人。哪怕是宠物丢失，也会向附近的流浪猫狗们录下详细的口供，然后仔细去寻找，尽管他听不懂。",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	IconName = "Sus_05_jingcha",
	PrefabBundle = "character_sus",
	PrefabName = "Sus_05_jingcha",
	SkinName = "1",
	PrefabScale = 50,
	HPBarHeight = 112,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 693, Gain = 139},
		{Value = 200002, Base = 33, Gain = 7},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id5262] =
{
	Id = 5262,
	Name = "地板精灵",
	Rarity = 3,
	Element = 210005,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "出没在遗迹附近的精灵，以死去之人残存的气息为食，如果惹到了它，它会偷偷跟在你后面，找机会绊你一跤。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	IconName = "RPG_chouniguai",
	PrefabBundle = "character_enemy",
	PrefabName = "RPG_chouniguai",
	PrefabScale = 50,
	HPBarHeight = 76,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 876, Gain = 176},
		{Value = 200002, Base = 41, Gain = 9},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id5263] =
{
	Id = 5263,
	Name = "偷种子的贼",
	Rarity = 3,
	Element = 210003,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "最恨人说烂泥扶不上墙，一旦听到就会发飙。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	IconName = "RPG_ruannidui",
	PrefabBundle = "character_enemy",
	PrefabName = "RPG_ruannidui",
	PrefabScale = 50,
	HPBarHeight = 76,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 876, Gain = 176},
		{Value = 200002, Base = 41, Gain = 9},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id5264] =
{
	Id = 5264,
	Name = "一匹村民",
	Rarity = 3,
	Element = 210001,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "冒险星的居民，勇者们的忠实拥护者，为了支持勇者而家徒四壁。如今嘴上虽然喊着要支持勇者，不过暗中把值钱东西都背在了身上。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	IconName = "Rpg_09_putongcunmin",
	PrefabBundle = "character_rpg",
	PrefabName = "Rpg_09_putongcunmin",
	SkinName = "1",
	PrefabScale = 50,
	HPBarHeight = 105,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 876, Gain = 176},
		{Value = 200002, Base = 41, Gain = 9},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id5265] =
{
	Id = 5265,
	Name = "神器守护者",
	Rarity = 5,
	Element = 210004,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "平原的守护者，对其他生物很不友好。其实是个慢性子，说话结巴，最大的梦想是有人能听完它的自我介绍。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	IconName = "RPG_Stoneman",
	PrefabBundle = "character_enemy",
	PrefabName = "RPG_Stoneman",
	PrefabScale = 50,
	HPBarHeight = 114,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 765, Gain = 153},
		{Value = 200002, Base = 36, Gain = 8},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id5266] =
{
	Id = 5266,
	Name = "梳妆的女子",
	Rarity = 5,
	Element = 210005,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "拥有武侠风格的套装，白衣飘飘，翩翩如仙，不过别致的头饰部分又让这身装扮层次变得更丰富，仿佛是在探讨古代侠士们的伙食问题。",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	IconName = "Fat_28_jichi_cos20",
	PrefabBundle = "character_fat",
	PrefabName = "Fat_28_jichi",
	SkinName = "3",
	PrefabScale = 50,
	HPBarHeight = 125,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 693, Gain = 139},
		{Value = 200002, Base = 33, Gain = 7},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id5267] =
{
	Id = 5267,
	Name = "路边的罪犯",
	Rarity = 5,
	Element = 210005,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "令人闻风丧胆的凶手，没人知道ta的身份。只要ta出现，大家就会放弃抵抗落荒而逃，然后露出破绽，被他轻易击杀。",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	IconName = "Sus_28_heiyiren",
	PrefabBundle = "character_sus",
	PrefabName = "Sus_28_heiyiren",
	SkinName = "1",
	PrefabScale = 50,
	HPBarHeight = 112,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 765, Gain = 153},
		{Value = 200002, Base = 36, Gain = 8},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id5268] =
{
	Id = 5268,
	Name = "奇怪的诗人",
	Rarity = 5,
	Element = 210003,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "因法力太弱而落在最后的八仙之一，与朋友走散后，被带入星际传销组织，凭着精明的头脑和过人的口才，目前已经成为该传销组织的精神领袖。组织在曹国舅的带领下转型成股票经纪公司。",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	IconName = "All_EightImmortal_CaoGuoJiu",
	PrefabBundle = "character_sp",
	PrefabName = "All_EightImmortal_CaoGuoJiu",
	SkinName = "1",
	PrefabScale = 50,
	HPBarHeight = 125,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 693, Gain = 139},
		{Value = 200002, Base = 33, Gain = 7},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id5269] =
{
	Id = 5269,
	Name = "上门的铁匠",
	Rarity = 4,
	Element = 210002,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "冒险星人气NPC，提供装备买卖、修理、强化等服务，是勇者不可或缺的好帮手。\n“哎呀，手一滑装备爆炸了，阁下运气不太好噢~”",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	IconName = "Rpg_31_tiejiang",
	PrefabBundle = "character_rpg",
	PrefabName = "Rpg_31_tiejiang",
	SkinName = "1",
	PrefabScale = 50,
	HPBarHeight = 115,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 813, Gain = 163},
		{Value = 200002, Base = 38, Gain = 8},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id5270] =
{
	Id = 5270,
	Name = "可爱的小姑娘",
	Rarity = 4,
	Element = 210002,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "喜欢阅读童话故事的少女，常常穿着红色的斗篷和裙子，还挎着一只木篮。但木篮子里装的究竟是什么，似乎没有人知道答案。",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	IconName = "SPBUS_06_xiaohongmao",
	PrefabBundle = "character_sp",
	PrefabName = "SPBUS_06_xiaohongmao",
	SkinName = "1",
	PrefabScale = 50,
	HPBarHeight = 125,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 813, Gain = 163},
		{Value = 200002, Base = 38, Gain = 8},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id5271] =
{
	Id = 5271,
	Name = "我不是计算器",
	Rarity = 3,
	Element = 210005,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "犯罪现场遗留下来的手机，被害人还来不及翻开盖子就遇害了。这个教训告诉我们要买智能机。",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "SUS",
	IconName = "SUS_MobilePhone",
	PrefabBundle = "character_enemy",
	PrefabName = "SUS_MobilePhone",
	PrefabScale = 50,
	HPBarHeight = 100,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 876, Gain = 176},
		{Value = 200002, Base = 41, Gain = 9},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id5272] =
{
	Id = 5272,
	Name = "帅气的白狼",
	Rarity = 3,
	Element = 210004,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：组织并经营非法团伙，疑似有收取保护费行为。",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	IconName = "Arena_RPG_WhiteWolf",
	PrefabBundle = "character_arenaenemy",
	PrefabName = "Arena_RPG_WhiteWolf",
	PrefabScale = 50,
	HPBarHeight = 102,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 876, Gain = 176},
		{Value = 200002, Base = 41, Gain = 9},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id5273] =
{
	Id = 5273,
	Name = "下班的龙套",
	Rarity = 3,
	Element = 210001,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "往往第一个被排除嫌疑的角色，但是世事无绝对。如果所有出场的嫌疑人都遇害了，那么一定要再重新检查一遍死者。",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	IconName = "Sus_12_sizhe",
	PrefabBundle = "character_sus",
	PrefabName = "Sus_12_sizhe",
	SkinName = "1",
	PrefabScale = 50,
	HPBarHeight = 129,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 876, Gain = 176},
		{Value = 200002, Base = 41, Gain = 9},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id5274] =
{
	Id = 5274,
	Name = "某集团员工",
	Rarity = 3,
	Element = 210005,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "魔王有限公司临时雇员，即使被拆散了也能很快拼回去，是地城副本中很重要的成员。\n不过偶尔会发生重新拼装时，多出一些骨头的问题。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	IconName = "Rpg_30_kulou",
	PrefabBundle = "character_rpg",
	PrefabName = "Rpg_30_kulou",
	SkinName = "1",
	PrefabScale = 50,
	HPBarHeight = 105,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 876, Gain = 176},
		{Value = 200002, Base = 41, Gain = 9},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id5275] =
{
	Id = 5275,
	Name = "流浪的小怪",
	Rarity = 4,
	Element = 210002,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "体内带有大量红色素的小精灵，喜欢捡冒险者丢掉的东西，被它碰到的东西就会被染成红色，但如果碰到蓝色史莱姆就会染成紫色。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	IconName = "RPG_Slime_red",
	PrefabBundle = "character_enemy",
	PrefabName = "RPG_Slime_red",
	PrefabScale = 50,
	HPBarHeight = 69,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 813, Gain = 163},
		{Value = 200002, Base = 38, Gain = 8},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id5276] =
{
	Id = 5276,
	Name = "夜班人员",
	Rarity = 4,
	Element = 210001,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "博物馆星新任保安，人生处于低谷时来到博物馆散心，无意间拿起保安招聘启事后便被馆长强行留了下来。",
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "Mus",
	IconName = "MUS_27_baoan",
	PrefabBundle = "character_mus",
	PrefabName = "MUS_27_baoan",
	SkinName = "1",
	PrefabScale = 50,
	HPBarHeight = 115,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 813, Gain = 163},
		{Value = 200002, Base = 38, Gain = 8},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id5277] =
{
	Id = 5277,
	Name = "化妆师",
	Rarity = 4,
	Element = 210003,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "神秘组织成员，听说是前偶像歌手。歌唱事业达到瓶颈后尝试了配音工作，然后成功转型。职业病上身的她有时会在战斗中替被殴打的怪物惨叫。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	IconName = "Rpg_15_peiyinyanyuan",
	PrefabBundle = "character_rpg",
	PrefabName = "Rpg_15_peiyinyanyuan",
	SkinName = "1",
	PrefabScale = 50,
	HPBarHeight = 115,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 813, Gain = 163},
		{Value = 200002, Base = 38, Gain = 8},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id5278] =
{
	Id = 5278,
	Name = "整蛊专家",
	Rarity = 4,
	Element = 210005,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "是来自遥远星球的百变怪人。因马戏团长克扣工资而逃走，凭借出色的变身能力潜入流亡街。根据记录，很少人见过他的本体，而他能够变身成任何形象，且快速学习并模仿对象的言行举止。",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	IconName = "Pir_04_ChangeableMan",
	PrefabBundle = "character_boss",
	PrefabName = "Pir_04_ChangeableMan",
	SkinName = "1",
	PrefabScale = 50,
	HPBarHeight = 125,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 813, Gain = 163},
		{Value = 200002, Base = 38, Gain = 8},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id5279] =
{
	Id = 5279,
	Name = "职业上班族",
	Rarity = 3,
	Element = 210003,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "背负着被告所有希望的悬疑星上班族，根据表面上的证据往往能得出不同结论，帮助被告脱罪，顺带把证人席上的某人定罪。\n“上了证人席，你还想跑？”",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	IconName = "Sus_13_lvshi",
	PrefabBundle = "character_sus",
	PrefabName = "Sus_13_lvshi",
	SkinName = "1",
	PrefabScale = 50,
	HPBarHeight = 112,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 876, Gain = 176},
		{Value = 200002, Base = 41, Gain = 9},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id5280] =
{
	Id = 5280,
	Name = "古董专家",
	Rarity = 3,
	Element = 210003,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "好几千年以前的一只猪蹄，被考古学家找到的时候，皮肤还有弹性，可是保存技术有限，没多久就氧化了。\n因社交能力出众，目前担任博物馆宣传部长。",
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "Mus",
	IconName = "MUS_20_zhutigudong",
	PrefabBundle = "character_mus",
	PrefabName = "MUS_20_zhutigudong",
	SkinName = "1",
	PrefabScale = 50,
	HPBarHeight = 115,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 876, Gain = 176},
		{Value = 200002, Base = 41, Gain = 9},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id5281] =
{
	Id = 5281,
	Name = "磨杵的老妇",
	Rarity = 3,
	Element = 210001,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "守候在村长身边的村长夫人，经常会发布难度高于主线的支线任务,但不知为什么奖励却比主线任务少。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	IconName = "Rpg_18_laonainai",
	PrefabBundle = "character_rpg",
	PrefabName = "Rpg_18_laonainai",
	SkinName = "1",
	PrefabScale = 50,
	HPBarHeight = 105,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 876, Gain = 176},
		{Value = 200002, Base = 41, Gain = 9},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id5282] =
{
	Id = 5282,
	Name = "小红娘",
	Rarity = 5,
	Element = 210004,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "美食星人气角色，拥有丰富的恋爱知识。遇到感情问题，向她进行咨询，就能得到圆满的答复。不过她本人目前似乎还有未能送出的白巧克力。",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	IconName = "Fat_32_baiseqiaokeli",
	PrefabBundle = "character_fat",
	PrefabName = "Fat_32_baiseqiaokeli",
	SkinName = "1",
	PrefabScale = 50,
	HPBarHeight = 125,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 765, Gain = 153},
		{Value = 200002, Base = 36, Gain = 8},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id5283] =
{
	Id = 5283,
	Name = "散仙",
	Rarity = 5,
	Element = 210004,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "星河彼岸东渡而来的八仙之一，因跨越星区，脱离北斗定位导航无法回到蓝星，目前正在卡兹星系流浪，靠卖药为生。作为八仙之首，支撑他继续走下去的动力是找到自己的另外七位仙友。",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	IconName = "All_EightImmortal_TieGuaiLi",
	PrefabBundle = "character_sp",
	PrefabName = "All_EightImmortal_TieGuaiLi",
	SkinName = "1",
	PrefabScale = 50,
	HPBarHeight = 115,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 693, Gain = 139},
		{Value = 200002, Base = 33, Gain = 7},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id5284] =
{
	Id = 5284,
	Name = "旅行商人",
	Rarity = 3,
	Element = 210003,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "冒险星人气NPC，拥有没人见过的非凡实力。卖出去1000块的道具，下一秒就是100块的回收价，却没有谁敢和他们吵架。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	IconName = "Rpg_14_lvxingshangren",
	PrefabBundle = "character_rpg",
	PrefabName = "Rpg_14_lvxingshangren",
	SkinName = "1",
	PrefabScale = 50,
	HPBarHeight = 105,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_2",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 991, Gain = 199},
		{Value = 200002, Base = 46, Gain = 10},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id5285] =
{
	Id = 5285,
	Name = "卖报纸的",
	Rarity = 3,
	Element = 210002,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "在悬疑星各大街道活动的报童，拥有大量未经证实的惊天消息。比如动物园老虎逃出笼子，且27人已遇害。\n事实是房东太太的猫散步时，被27人围着撸。",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	IconName = "Sus_17_baotong",
	PrefabBundle = "character_sus",
	PrefabName = "Sus_17_baotong",
	SkinName = "1",
	PrefabScale = 50,
	HPBarHeight = 112,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_3",
		RangeAttackEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 1183, Gain = 237},
		{Value = 200002, Base = 56, Gain = 12},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id5286] =
{
	Id = 5286,
	Name = "植物学家",
	Rarity = 4,
	Element = 210003,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "生活在风来谷的青年，虽然已加入经典冒险组，但是经常被人遗忘。本人的希望是尽可能帮助更多人摆脱疾病的困扰。为此正积极地前往世界各地寻找独特草药，制作着各种药剂。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	IconName = "RPG_106_Pharmacist",
	PrefabBundle = "character_rpg",
	PrefabName = "RPG_106_Pharmacist",
	SkinName = "1",
	PrefabScale = 50,
	HPBarHeight = 125,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_3",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 1118, Gain = 224},
		{Value = 200002, Base = 53, Gain = 11},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id5287] =
{
	Id = 5287,
	Name = "广场舞领舞",
	Rarity = 5,
	Element = 210001,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "守候在村长身边的村长夫人，经常会发布难度高于主线的支线任务,但不知为什么奖励却比主线任务少。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	IconName = "Rpg_18_laonainai",
	PrefabBundle = "character_rpg",
	PrefabName = "Rpg_18_laonainai",
	SkinName = "1",
	PrefabScale = 50,
	HPBarHeight = 105,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_3",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 1147, Gain = 230},
		{Value = 200002, Base = 55, Gain = 11},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id5288] =
{
	Id = 5288,
	Name = "蝴蝶爱好者",
	Rarity = 5,
	Element = 210003,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "伟大树林的守护者。十年前接到冒险节邀请后，便立刻踏上漫长旅程。秉持信念绝不使用任何现代工具，和小熊吃了很多苦头才来到了初始城镇。目前身无分文，被困不夜城。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	IconName = "RPG_107_Druid",
	PrefabBundle = "character_rpg",
	PrefabName = "RPG_107_Druid",
	SkinName = "1",
	PrefabScale = 50,
	HPBarHeight = 125,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_3",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 1126, Gain = 226},
		{Value = 200002, Base = 55, Gain = 11},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id5289] =
{
	Id = 5289,
	Name = "双马尾少女",
	Rarity = 5,
	Element = 210003,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "姐妹七人中年纪最小，最元气满满的女孩，喜欢织布与手工。虽然有时候被姐姐们吐槽“咋咋呼呼”的，但谁能不喜欢七织这样可爱的女孩子呢？",
	IconBundle = "atlas_activity_1",
	IconAtlas = "ActivityCharacterIcon",
	IconName = "SPBUS_20_QiZhi",
	PrefabBundle = "character_sp",
	PrefabName = "SPBUS_20_QiZhi",
	SkinName = "1",
	PrefabScale = 50,
	HPBarHeight = 125,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_3",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 1147, Gain = 230},
		{Value = 200002, Base = 55, Gain = 11},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id5290] =
{
	Id = 5290,
	Name = "高级酒保",
	Rarity = 5,
	Element = 210001,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "悬疑星有史以来最大型连续剧《朋克神探》中的酒保角色。虽然表面还是调酒师，但实际上负责情报的交易工作，是掌握着“朋克宇宙”最多秘密的男人。",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	IconName = "Sus_23_tiaojiushi_cos10",
	PrefabBundle = "character_sus",
	PrefabName = "Sus_23_tiaojiushi",
	SkinName = "2",
	PrefabScale = 50,
	HPBarHeight = 140,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_3",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 1126, Gain = 226},
		{Value = 200002, Base = 55, Gain = 11},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id5291] =
{
	Id = 5291,
	Name = "泡澡男",
	Rarity = 4,
	Element = 210004,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "根据神话故事绘制的肖像，男孩举起的手指向了天空……\n因为上课时挡住了后面同学看黑板而被骂了好多次。",
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "Mus",
	IconName = "MUS_22_yadang",
	PrefabBundle = "character_mus",
	PrefabName = "MUS_22_yadang",
	SkinName = "1",
	PrefabScale = 50,
	HPBarHeight = 115,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_3",
		RangeAttackEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 1118, Gain = 224},
		{Value = 200002, Base = 53, Gain = 11},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id5292] =
{
	Id = 5292,
	Name = "小奶牛",
	Rarity = 4,
	Element = 210004,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "农场特制的奶牛装，用以感谢牧师帮助牧场破获了特大牛奶浪费事件。当地的居民也因为之后及时补充了钙质，骨折好得更快了。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	IconName = "Rpg_07_mushi_cos10",
	PrefabBundle = "character_rpg",
	PrefabName = "Rpg_07_mushi",
	SkinName = "2",
	PrefabScale = 50,
	HPBarHeight = 135,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_3",
		RangeAttackEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 1118, Gain = 224},
		{Value = 200002, Base = 53, Gain = 11},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id5293] =
{
	Id = 5293,
	Name = "猎熊人",
	Rarity = 3,
	Element = 210003,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "换了伙伴的德鲁伊，很快和小狼也能够融洽地相处起来。原本打算偷偷溜走的小狼在吃了德鲁伊自制的饼干后，打算努力工作，永久性地顶替掉小熊。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	IconName = "RPG_107_Druid_cos10",
	PrefabBundle = "character_rpg",
	PrefabName = "RPG_107_Druid",
	SkinName = "2",
	PrefabScale = 50,
	HPBarHeight = 135,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_3",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 1183, Gain = 237},
		{Value = 200002, Base = 56, Gain = 12},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id5294] =
{
	Id = 5294,
	Name = "白发猎人",
	Rarity = 4,
	Element = 210003,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "冒险世界中神秘又强大的组织，猎魔人以消灭企图摧毁世界的恶魔为己任，无论敌人多么强大，他们都不会后退一步，除非朋友们约他先打一局昆特牌。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	IconName = "Rpg_16_lieren_cos10",
	PrefabBundle = "character_rpg",
	PrefabName = "Rpg_16_lieren",
	SkinName = "2",
	PrefabScale = 50,
	HPBarHeight = 140,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_3",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 1118, Gain = 224},
		{Value = 200002, Base = 53, Gain = 11},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id5295] =
{
	Id = 5295,
	Name = "黑衣人",
	Rarity = 4,
	Element = 210005,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "令人闻风丧胆的凶手，没人知道ta的身份。只要ta出现，大家就会放弃抵抗落荒而逃，然后露出破绽，被他轻易击杀。",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	IconName = "Sus_28_heiyiren",
	PrefabBundle = "character_sus",
	PrefabName = "Sus_28_heiyiren",
	SkinName = "1",
	PrefabScale = 50,
	HPBarHeight = 112,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_3",
		RangeAttackEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 1118, Gain = 224},
		{Value = 200002, Base = 53, Gain = 11},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id5296] =
{
	Id = 5296,
	Name = "布茎云",
	Rarity = 3,
	Element = 210003,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "手感极好的布，亲近人类，但被人类强行拿捏时，头发会变成乱糟糟的爆炸头，脾气也会暴躁起来。",
	IconBundle = "atlas_activity_1",
	IconAtlas = "ActivityCharacterIcon",
	IconName = "All_BuJingYun",
	PrefabBundle = "character_enemy",
	PrefabName = "All_BuJingYun",
	PrefabScale = 50,
	HPBarHeight = 120,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_3",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 1183, Gain = 237},
		{Value = 200002, Base = 56, Gain = 12},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
