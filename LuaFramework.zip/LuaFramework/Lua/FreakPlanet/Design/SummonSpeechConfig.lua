SummonSpeechConfig ={};
SummonSpeechID = 
{
	Id40001 = 40001,
	Id40002 = 40002,
	Id40003 = 40003,
	Id40004 = 40004,
}
SummonSpeechConfig[SummonSpeechID.Id40001] =
{
	Id = 40001,
	Position = 1,
	Text = "走过路过，不要错过",
}
SummonSpeechConfig[SummonSpeechID.Id40002] =
{
	Id = 40002,
	Position = 2,
	NextID = 40003,
	Text = "一块钱你买不到吃亏，一块钱你买不到上当",
}
SummonSpeechConfig[SummonSpeechID.Id40003] =
{
	Id = 40003,
	Position = 3,
	Text = "一块钱你什么都买不了…",
}
SummonSpeechConfig[SummonSpeechID.Id40004] =
{
	Id = 40004,
	Position = 3,
	Text = "曾经我也是了不起的冒险家，直到我的护卫膝盖中了一箭",
}
