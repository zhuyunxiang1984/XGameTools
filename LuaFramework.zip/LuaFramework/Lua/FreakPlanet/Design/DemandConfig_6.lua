
DemandConfig[DemandID.Id601] =
{
	Id = 601,
	Name = "订购封条1",
	Desc = "需要一些封条",
	Value = 321407,
	Active = true,
	Weight = 33000,
	PreGoal = 
	{
		300860,
		301301,
	},
	CloseGoal = 
	{
		301630,
	},
	GoodsId = 6101407,
	Priority = 1407670,
	Num = 36,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 37036,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 349,
				},
				{
					Value = 1,
					Num = 2136,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 349,
				},
				{
					Value = 1,
					Num = 2136,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 69,
				},
				{
					Value = 1,
					Num = 2536,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 69,
				},
				{
					Value = 1,
					Num = 2536,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 13,
				},
				{
					Value = 1,
					Num = 4536,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 13,
				},
				{
					Value = 1,
					Num = 4536,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 2,
				},
				{
					Value = 1,
					Num = 12036,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 2,
				},
				{
					Value = 1,
					Num = 12036,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 222,
				},
				{
					Value = 320051,
					Num = 148,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 44,
				},
				{
					Value = 320052,
					Num = 30,
				},
			},
		},
	},
	DemandID = 410601,
	DemandGroupList = {
		420002,
		420004,
		420005,
		420006,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id602] =
{
	Id = 602,
	Name = "订购海洋化石1",
	Desc = "需要一些海洋化石",
	Value = 321408,
	Active = true,
	Weight = 23805,
	PreGoal = 
	{
		300872,
	},
	CloseGoal = 
	{
		300900,
	},
	GoodsId = 6201408,
	Priority = 1408691,
	Num = 25,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 27762,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 235,
				},
				{
					Value = 1,
					Num = 4262,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 235,
				},
				{
					Value = 1,
					Num = 4262,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 47,
				},
				{
					Value = 1,
					Num = 4262,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 47,
				},
				{
					Value = 1,
					Num = 4262,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 9,
				},
				{
					Value = 1,
					Num = 5262,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 9,
				},
				{
					Value = 1,
					Num = 5262,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 1,
				},
				{
					Value = 1,
					Num = 15262,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 1,
				},
				{
					Value = 1,
					Num = 15262,
				},
			},
		},
	},
	DemandID = 410602,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id603] =
{
	Id = 603,
	Name = "订购海洋化石1",
	Desc = "需要一些海洋化石",
	Value = 321408,
	Active = true,
	Weight = 24495,
	PreGoal = 
	{
		300872,
		300880,
	},
	CloseGoal = 
	{
		301204,
	},
	GoodsId = 6201408,
	Priority = 1408692,
	Num = 26,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 28872,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 245,
				},
				{
					Value = 1,
					Num = 4372,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 245,
				},
				{
					Value = 1,
					Num = 4372,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 49,
				},
				{
					Value = 1,
					Num = 4372,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 49,
				},
				{
					Value = 1,
					Num = 4372,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 9,
				},
				{
					Value = 1,
					Num = 6372,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 9,
				},
				{
					Value = 1,
					Num = 6372,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 1,
				},
				{
					Value = 1,
					Num = 16372,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 1,
				},
				{
					Value = 1,
					Num = 16372,
				},
			},
		},
	},
	DemandID = 410603,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id604] =
{
	Id = 604,
	Name = "订购海洋化石1",
	Desc = "需要一些海洋化石",
	Value = 321408,
	Active = true,
	Weight = 25185,
	PreGoal = 
	{
		300872,
		300888,
	},
	CloseGoal = 
	{
		301224,
	},
	GoodsId = 6201408,
	Priority = 1408693,
	Num = 27,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 29982,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 254,
				},
				{
					Value = 1,
					Num = 4582,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 254,
				},
				{
					Value = 1,
					Num = 4582,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 50,
				},
				{
					Value = 1,
					Num = 4982,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 50,
				},
				{
					Value = 1,
					Num = 4982,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 10,
				},
				{
					Value = 1,
					Num = 4982,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 10,
				},
				{
					Value = 1,
					Num = 4982,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 2,
				},
				{
					Value = 1,
					Num = 4982,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 2,
				},
				{
					Value = 1,
					Num = 4982,
				},
			},
		},
	},
	DemandID = 410604,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id605] =
{
	Id = 605,
	Name = "订购海洋化石1",
	Desc = "需要一些海洋化石",
	Value = 321408,
	Active = true,
	Weight = 26220,
	PreGoal = 
	{
		300872,
		300900,
	},
	CloseGoal = 
	{
		301236,
	},
	GoodsId = 6201408,
	Priority = 1408694,
	Num = 28,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 31093,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 264,
				},
				{
					Value = 1,
					Num = 4693,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 264,
				},
				{
					Value = 1,
					Num = 4693,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 52,
				},
				{
					Value = 1,
					Num = 5093,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 52,
				},
				{
					Value = 1,
					Num = 5093,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 10,
				},
				{
					Value = 1,
					Num = 6093,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 10,
				},
				{
					Value = 1,
					Num = 6093,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 2,
				},
				{
					Value = 1,
					Num = 6093,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 2,
				},
				{
					Value = 1,
					Num = 6093,
				},
			},
		},
	},
	DemandID = 410605,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id606] =
{
	Id = 606,
	Name = "订购海洋化石1",
	Desc = "需要一些海洋化石",
	Value = 321408,
	Active = true,
	Weight = 27255,
	PreGoal = 
	{
		300872,
		301216,
	},
	CloseGoal = 
	{
		301252,
	},
	GoodsId = 6201408,
	Priority = 1408695,
	Num = 30,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 33314,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 283,
				},
				{
					Value = 1,
					Num = 5014,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 283,
				},
				{
					Value = 1,
					Num = 5014,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 56,
				},
				{
					Value = 1,
					Num = 5314,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 56,
				},
				{
					Value = 1,
					Num = 5314,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 11,
				},
				{
					Value = 1,
					Num = 5814,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 11,
				},
				{
					Value = 1,
					Num = 5814,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 2,
				},
				{
					Value = 1,
					Num = 8314,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 2,
				},
				{
					Value = 1,
					Num = 8314,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 199,
				},
				{
					Value = 320051,
					Num = 134,
				},
			},
		},
	},
	DemandID = 410606,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id607] =
{
	Id = 607,
	Name = "订购海洋化石1",
	Desc = "需要一些海洋化石",
	Value = 321408,
	Active = true,
	Weight = 28635,
	PreGoal = 
	{
		300872,
		301232,
	},
	CloseGoal = 
	{
		301268,
	},
	GoodsId = 6201408,
	Priority = 1408696,
	Num = 33,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 36645,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 311,
				},
				{
					Value = 1,
					Num = 5545,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 311,
				},
				{
					Value = 1,
					Num = 5545,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 62,
				},
				{
					Value = 1,
					Num = 5645,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 62,
				},
				{
					Value = 1,
					Num = 5645,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 12,
				},
				{
					Value = 1,
					Num = 6645,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 12,
				},
				{
					Value = 1,
					Num = 6645,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 2,
				},
				{
					Value = 1,
					Num = 11645,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 2,
				},
				{
					Value = 1,
					Num = 11645,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 219,
				},
				{
					Value = 320051,
					Num = 147,
				},
			},
		},
	},
	DemandID = 410607,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id608] =
{
	Id = 608,
	Name = "订购海洋化石1",
	Desc = "需要一些海洋化石",
	Value = 321408,
	Active = true,
	Weight = 30015,
	PreGoal = 
	{
		300872,
		301248,
	},
	CloseGoal = 
	{
		301288,
	},
	GoodsId = 6201408,
	Priority = 1408697,
	Num = 35,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 38866,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 330,
				},
				{
					Value = 1,
					Num = 5866,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 330,
				},
				{
					Value = 1,
					Num = 5866,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 66,
				},
				{
					Value = 1,
					Num = 5866,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 66,
				},
				{
					Value = 1,
					Num = 5866,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 13,
				},
				{
					Value = 1,
					Num = 6366,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 13,
				},
				{
					Value = 1,
					Num = 6366,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 2,
				},
				{
					Value = 1,
					Num = 13866,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 2,
				},
				{
					Value = 1,
					Num = 13866,
				},
			},
		},
	},
	DemandID = 410608,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id609] =
{
	Id = 609,
	Name = "订购海洋化石1",
	Desc = "需要一些海洋化石",
	Value = 321408,
	Active = true,
	Weight = 31740,
	PreGoal = 
	{
		300872,
		301268,
	},
	CloseGoal = 
	{
		301310,
	},
	GoodsId = 6201408,
	Priority = 1408698,
	Num = 36,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 39977,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 339,
				},
				{
					Value = 1,
					Num = 6077,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 339,
				},
				{
					Value = 1,
					Num = 6077,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 67,
				},
				{
					Value = 1,
					Num = 6477,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 67,
				},
				{
					Value = 1,
					Num = 6477,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 13,
				},
				{
					Value = 1,
					Num = 7477,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 13,
				},
				{
					Value = 1,
					Num = 7477,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 2,
				},
				{
					Value = 1,
					Num = 14977,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 2,
				},
				{
					Value = 1,
					Num = 14977,
				},
			},
		},
	},
	DemandID = 410609,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id610] =
{
	Id = 610,
	Name = "订购海洋化石1",
	Desc = "需要一些海洋化石",
	Value = 321408,
	Active = true,
	Weight = 33465,
	PreGoal = 
	{
		300872,
		301288,
	},
	CloseGoal = 
	{
		301615,
	},
	GoodsId = 6201408,
	Priority = 1408699,
	Num = 36,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 39977,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 339,
				},
				{
					Value = 1,
					Num = 6077,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 339,
				},
				{
					Value = 1,
					Num = 6077,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 67,
				},
				{
					Value = 1,
					Num = 6477,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 67,
				},
				{
					Value = 1,
					Num = 6477,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 13,
				},
				{
					Value = 1,
					Num = 7477,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 13,
				},
				{
					Value = 1,
					Num = 7477,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 2,
				},
				{
					Value = 1,
					Num = 14977,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 2,
				},
				{
					Value = 1,
					Num = 14977,
				},
			},
		},
	},
	DemandID = 410610,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id611] =
{
	Id = 611,
	Name = "订购海洋化石1",
	Desc = "需要一些海洋化石",
	Value = 321408,
	Active = true,
	Weight = 35535,
	PreGoal = 
	{
		300872,
		301314,
	},
	CloseGoal = 
	{
		301645,
	},
	GoodsId = 6201408,
	Priority = 1408700,
	Num = 36,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 39977,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 339,
				},
				{
					Value = 1,
					Num = 6077,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 339,
				},
				{
					Value = 1,
					Num = 6077,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 67,
				},
				{
					Value = 1,
					Num = 6477,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 67,
				},
				{
					Value = 1,
					Num = 6477,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 13,
				},
				{
					Value = 1,
					Num = 7477,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 13,
				},
				{
					Value = 1,
					Num = 7477,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 2,
				},
				{
					Value = 1,
					Num = 14977,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 2,
				},
				{
					Value = 1,
					Num = 14977,
				},
			},
		},
	},
	DemandID = 410611,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id612] =
{
	Id = 612,
	Name = "订购青面具1",
	Desc = "需要一些青面具",
	Value = 321409,
	Active = true,
	Weight = 25920,
	PreGoal = 
	{
		300884,
	},
	CloseGoal = 
	{
		301216,
	},
	GoodsId = 6301409,
	Priority = 1409721,
	Num = 26,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 29178,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 248,
				},
				{
					Value = 1,
					Num = 4378,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 248,
				},
				{
					Value = 1,
					Num = 4378,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 49,
				},
				{
					Value = 1,
					Num = 4678,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 49,
				},
				{
					Value = 1,
					Num = 4678,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 9,
				},
				{
					Value = 1,
					Num = 6678,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 9,
				},
				{
					Value = 1,
					Num = 6678,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 1,
				},
				{
					Value = 1,
					Num = 16678,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 1,
				},
				{
					Value = 1,
					Num = 16678,
				},
			},
		},
	},
	DemandID = 410612,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id613] =
{
	Id = 613,
	Name = "订购青面具1",
	Desc = "需要一些青面具",
	Value = 321409,
	Active = true,
	Weight = 26640,
	PreGoal = 
	{
		300884,
		300892,
	},
	CloseGoal = 
	{
		301224,
	},
	GoodsId = 6301409,
	Priority = 1409722,
	Num = 28,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 31422,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 267,
				},
				{
					Value = 1,
					Num = 4722,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 267,
				},
				{
					Value = 1,
					Num = 4722,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 53,
				},
				{
					Value = 1,
					Num = 4922,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 53,
				},
				{
					Value = 1,
					Num = 4922,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 10,
				},
				{
					Value = 1,
					Num = 6422,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 10,
				},
				{
					Value = 1,
					Num = 6422,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 2,
				},
				{
					Value = 1,
					Num = 6422,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 2,
				},
				{
					Value = 1,
					Num = 6422,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 188,
				},
				{
					Value = 320051,
					Num = 126,
				},
			},
		},
	},
	DemandID = 410613,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id614] =
{
	Id = 614,
	Name = "订购青面具1",
	Desc = "需要一些青面具",
	Value = 321409,
	Active = true,
	Weight = 27360,
	PreGoal = 
	{
		300884,
		300900,
	},
	CloseGoal = 
	{
		301236,
	},
	GoodsId = 6301409,
	Priority = 1409723,
	Num = 28,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 31422,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 267,
				},
				{
					Value = 1,
					Num = 4722,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 267,
				},
				{
					Value = 1,
					Num = 4722,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 53,
				},
				{
					Value = 1,
					Num = 4922,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 53,
				},
				{
					Value = 1,
					Num = 4922,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 10,
				},
				{
					Value = 1,
					Num = 6422,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 10,
				},
				{
					Value = 1,
					Num = 6422,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 2,
				},
				{
					Value = 1,
					Num = 6422,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 2,
				},
				{
					Value = 1,
					Num = 6422,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 188,
				},
				{
					Value = 320051,
					Num = 126,
				},
			},
		},
	},
	DemandID = 410614,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id615] =
{
	Id = 615,
	Name = "订购青面具1",
	Desc = "需要一些青面具",
	Value = 321409,
	Active = true,
	Weight = 28440,
	PreGoal = 
	{
		300884,
		301216,
	},
	CloseGoal = 
	{
		301248,
	},
	GoodsId = 6301409,
	Priority = 1409724,
	Num = 30,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 33667,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 286,
				},
				{
					Value = 1,
					Num = 5067,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 286,
				},
				{
					Value = 1,
					Num = 5067,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 57,
				},
				{
					Value = 1,
					Num = 5167,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 57,
				},
				{
					Value = 1,
					Num = 5167,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 11,
				},
				{
					Value = 1,
					Num = 6167,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 11,
				},
				{
					Value = 1,
					Num = 6167,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 2,
				},
				{
					Value = 1,
					Num = 8667,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 2,
				},
				{
					Value = 1,
					Num = 8667,
				},
			},
		},
	},
	DemandID = 410615,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id616] =
{
	Id = 616,
	Name = "订购青面具1",
	Desc = "需要一些青面具",
	Value = 321409,
	Active = true,
	Weight = 29520,
	PreGoal = 
	{
		300884,
		301228,
	},
	CloseGoal = 
	{
		301264,
	},
	GoodsId = 6301409,
	Priority = 1409725,
	Num = 32,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 35911,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 305,
				},
				{
					Value = 1,
					Num = 5411,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 305,
				},
				{
					Value = 1,
					Num = 5411,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 61,
				},
				{
					Value = 1,
					Num = 5411,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 61,
				},
				{
					Value = 1,
					Num = 5411,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 12,
				},
				{
					Value = 1,
					Num = 5911,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 12,
				},
				{
					Value = 1,
					Num = 5911,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 2,
				},
				{
					Value = 1,
					Num = 10911,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 2,
				},
				{
					Value = 1,
					Num = 10911,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 215,
				},
				{
					Value = 320051,
					Num = 144,
				},
			},
		},
	},
	DemandID = 410616,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id617] =
{
	Id = 617,
	Name = "订购青面具1",
	Desc = "需要一些青面具",
	Value = 321409,
	Active = true,
	Weight = 30960,
	PreGoal = 
	{
		300884,
		301244,
	},
	CloseGoal = 
	{
		301280,
	},
	GoodsId = 6301409,
	Priority = 1409726,
	Num = 35,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 39278,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 333,
				},
				{
					Value = 1,
					Num = 5978,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 333,
				},
				{
					Value = 1,
					Num = 5978,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 66,
				},
				{
					Value = 1,
					Num = 6278,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 66,
				},
				{
					Value = 1,
					Num = 6278,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 13,
				},
				{
					Value = 1,
					Num = 6778,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 13,
				},
				{
					Value = 1,
					Num = 6778,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 2,
				},
				{
					Value = 1,
					Num = 14278,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 2,
				},
				{
					Value = 1,
					Num = 14278,
				},
			},
		},
	},
	DemandID = 410617,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id618] =
{
	Id = 618,
	Name = "订购青面具1",
	Desc = "需要一些青面具",
	Value = 321409,
	Active = true,
	Weight = 32400,
	PreGoal = 
	{
		300884,
		301260,
	},
	CloseGoal = 
	{
		301301,
	},
	GoodsId = 6301409,
	Priority = 1409727,
	Num = 36,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 40400,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 343,
				},
				{
					Value = 1,
					Num = 6100,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 343,
				},
				{
					Value = 1,
					Num = 6100,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 68,
				},
				{
					Value = 1,
					Num = 6400,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 68,
				},
				{
					Value = 1,
					Num = 6400,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 13,
				},
				{
					Value = 1,
					Num = 7900,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 13,
				},
				{
					Value = 1,
					Num = 7900,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 2,
				},
				{
					Value = 1,
					Num = 15400,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 2,
				},
				{
					Value = 1,
					Num = 15400,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 242,
				},
				{
					Value = 320051,
					Num = 162,
				},
			},
		},
	},
	DemandID = 410618,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id619] =
{
	Id = 619,
	Name = "订购青面具1",
	Desc = "需要一些青面具",
	Value = 321409,
	Active = true,
	Weight = 34200,
	PreGoal = 
	{
		300884,
		301280,
	},
	CloseGoal = 
	{
		301322,
	},
	GoodsId = 6301409,
	Priority = 1409728,
	Num = 36,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 40400,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 343,
				},
				{
					Value = 1,
					Num = 6100,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 343,
				},
				{
					Value = 1,
					Num = 6100,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 68,
				},
				{
					Value = 1,
					Num = 6400,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 68,
				},
				{
					Value = 1,
					Num = 6400,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 13,
				},
				{
					Value = 1,
					Num = 7900,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 13,
				},
				{
					Value = 1,
					Num = 7900,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 2,
				},
				{
					Value = 1,
					Num = 15400,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 2,
				},
				{
					Value = 1,
					Num = 15400,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 242,
				},
				{
					Value = 320051,
					Num = 162,
				},
			},
		},
	},
	DemandID = 410619,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id620] =
{
	Id = 620,
	Name = "订购青面具1",
	Desc = "需要一些青面具",
	Value = 321409,
	Active = true,
	Weight = 36000,
	PreGoal = 
	{
		300884,
		301301,
	},
	CloseGoal = 
	{
		301630,
	},
	GoodsId = 6301409,
	Priority = 1409729,
	Num = 36,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 40400,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 343,
				},
				{
					Value = 1,
					Num = 6100,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 343,
				},
				{
					Value = 1,
					Num = 6100,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 68,
				},
				{
					Value = 1,
					Num = 6400,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 68,
				},
				{
					Value = 1,
					Num = 6400,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 13,
				},
				{
					Value = 1,
					Num = 7900,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 13,
				},
				{
					Value = 1,
					Num = 7900,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 2,
				},
				{
					Value = 1,
					Num = 15400,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 2,
				},
				{
					Value = 1,
					Num = 15400,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 242,
				},
				{
					Value = 320051,
					Num = 162,
				},
			},
		},
	},
	DemandID = 410620,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id621] =
{
	Id = 621,
	Name = "订购青面具1",
	Desc = "需要一些青面具",
	Value = 321409,
	Active = true,
	Weight = 38160,
	PreGoal = 
	{
		300884,
		301327,
	},
	CloseGoal = 
	{
		301660,
	},
	GoodsId = 6301409,
	Priority = 1409730,
	Num = 36,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 40400,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 343,
				},
				{
					Value = 1,
					Num = 6100,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 343,
				},
				{
					Value = 1,
					Num = 6100,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 68,
				},
				{
					Value = 1,
					Num = 6400,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 68,
				},
				{
					Value = 1,
					Num = 6400,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 13,
				},
				{
					Value = 1,
					Num = 7900,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 13,
				},
				{
					Value = 1,
					Num = 7900,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 2,
				},
				{
					Value = 1,
					Num = 15400,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 2,
				},
				{
					Value = 1,
					Num = 15400,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 242,
				},
				{
					Value = 320051,
					Num = 162,
				},
			},
		},
	},
	DemandID = 410621,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id622] =
{
	Id = 622,
	Name = "订购龙角1",
	Desc = "需要一些龙角",
	Value = 321410,
	Active = true,
	Weight = 27380,
	PreGoal = 
	{
		300892,
	},
	CloseGoal = 
	{
		301224,
	},
	GoodsId = 6401410,
	Priority = 1410741,
	Num = 26,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 32556,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 307,
				},
				{
					Value = 1,
					Num = 1856,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 307,
				},
				{
					Value = 1,
					Num = 1856,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 61,
				},
				{
					Value = 1,
					Num = 2056,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 61,
				},
				{
					Value = 1,
					Num = 2056,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 12,
				},
				{
					Value = 1,
					Num = 2556,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 12,
				},
				{
					Value = 1,
					Num = 2556,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 2,
				},
				{
					Value = 1,
					Num = 7556,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 2,
				},
				{
					Value = 1,
					Num = 7556,
				},
			},
		},
	},
	DemandID = 410622,
	DemandGroupList = {
		420002,
		420004,
		420005,
		420006,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id623] =
{
	Id = 623,
	Name = "订购龙角1",
	Desc = "需要一些龙角",
	Value = 321410,
	Active = true,
	Weight = 28120,
	PreGoal = 
	{
		300892,
		300900,
	},
	CloseGoal = 
	{
		301232,
	},
	GoodsId = 6401410,
	Priority = 1410742,
	Num = 26,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 32556,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 307,
				},
				{
					Value = 1,
					Num = 1856,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 307,
				},
				{
					Value = 1,
					Num = 1856,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 61,
				},
				{
					Value = 1,
					Num = 2056,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 61,
				},
				{
					Value = 1,
					Num = 2056,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 12,
				},
				{
					Value = 1,
					Num = 2556,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 12,
				},
				{
					Value = 1,
					Num = 2556,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 2,
				},
				{
					Value = 1,
					Num = 7556,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 2,
				},
				{
					Value = 1,
					Num = 7556,
				},
			},
		},
	},
	DemandID = 410623,
	DemandGroupList = {
		420002,
		420004,
		420005,
		420006,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id624] =
{
	Id = 624,
	Name = "订购龙角1",
	Desc = "需要一些龙角",
	Value = 321410,
	Active = true,
	Weight = 28860,
	PreGoal = 
	{
		300892,
		301204,
	},
	CloseGoal = 
	{
		301244,
	},
	GoodsId = 6401410,
	Priority = 1410743,
	Num = 27,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 33808,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 319,
				},
				{
					Value = 1,
					Num = 1908,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 319,
				},
				{
					Value = 1,
					Num = 1908,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 63,
				},
				{
					Value = 1,
					Num = 2308,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 63,
				},
				{
					Value = 1,
					Num = 2308,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 12,
				},
				{
					Value = 1,
					Num = 3808,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 12,
				},
				{
					Value = 1,
					Num = 3808,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 2,
				},
				{
					Value = 1,
					Num = 8808,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 2,
				},
				{
					Value = 1,
					Num = 8808,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 202,
				},
				{
					Value = 320051,
					Num = 136,
				},
			},
		},
	},
	DemandID = 410624,
	DemandGroupList = {
		420002,
		420004,
		420005,
		420006,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id625] =
{
	Id = 625,
	Name = "订购龙角1",
	Desc = "需要一些龙角",
	Value = 321410,
	Active = true,
	Weight = 29970,
	PreGoal = 
	{
		300892,
		301224,
	},
	CloseGoal = 
	{
		301256,
	},
	GoodsId = 6401410,
	Priority = 1410744,
	Num = 28,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 35060,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 331,
				},
				{
					Value = 1,
					Num = 1960,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 331,
				},
				{
					Value = 1,
					Num = 1960,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 66,
				},
				{
					Value = 1,
					Num = 2060,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 66,
				},
				{
					Value = 1,
					Num = 2060,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 13,
				},
				{
					Value = 1,
					Num = 2560,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 13,
				},
				{
					Value = 1,
					Num = 2560,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 2,
				},
				{
					Value = 1,
					Num = 10060,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 2,
				},
				{
					Value = 1,
					Num = 10060,
				},
			},
		},
	},
	DemandID = 410625,
	DemandGroupList = {
		420002,
		420004,
		420005,
		420006,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id626] =
{
	Id = 626,
	Name = "订购龙角1",
	Desc = "需要一些龙角",
	Value = 321410,
	Active = true,
	Weight = 31080,
	PreGoal = 
	{
		300892,
		301236,
	},
	CloseGoal = 
	{
		301272,
	},
	GoodsId = 6401410,
	Priority = 1410745,
	Num = 30,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 37564,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 354,
				},
				{
					Value = 1,
					Num = 2164,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 354,
				},
				{
					Value = 1,
					Num = 2164,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 70,
				},
				{
					Value = 1,
					Num = 2564,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 70,
				},
				{
					Value = 1,
					Num = 2564,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 14,
				},
				{
					Value = 1,
					Num = 2564,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 14,
				},
				{
					Value = 1,
					Num = 2564,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 2,
				},
				{
					Value = 1,
					Num = 12564,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 2,
				},
				{
					Value = 1,
					Num = 12564,
				},
			},
		},
	},
	DemandID = 410626,
	DemandGroupList = {
		420002,
		420004,
		420005,
		420006,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id627] =
{
	Id = 627,
	Name = "订购龙角1",
	Desc = "需要一些龙角",
	Value = 321410,
	Active = true,
	Weight = 32560,
	PreGoal = 
	{
		300892,
		301252,
	},
	CloseGoal = 
	{
		301288,
	},
	GoodsId = 6401410,
	Priority = 1410746,
	Num = 33,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 41321,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 390,
				},
				{
					Value = 1,
					Num = 2321,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 390,
				},
				{
					Value = 1,
					Num = 2321,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 78,
				},
				{
					Value = 1,
					Num = 2321,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 78,
				},
				{
					Value = 1,
					Num = 2321,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 15,
				},
				{
					Value = 1,
					Num = 3821,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 15,
				},
				{
					Value = 1,
					Num = 3821,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 3,
				},
				{
					Value = 1,
					Num = 3821,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 3,
				},
				{
					Value = 1,
					Num = 3821,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 247,
				},
				{
					Value = 320051,
					Num = 166,
				},
			},
		},
	},
	DemandID = 410627,
	DemandGroupList = {
		420002,
		420004,
		420005,
		420006,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id628] =
{
	Id = 628,
	Name = "订购龙角1",
	Desc = "需要一些龙角",
	Value = 321410,
	Active = true,
	Weight = 34040,
	PreGoal = 
	{
		300892,
		301268,
	},
	CloseGoal = 
	{
		301310,
	},
	GoodsId = 6401410,
	Priority = 1410747,
	Num = 33,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 41321,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 390,
				},
				{
					Value = 1,
					Num = 2321,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 390,
				},
				{
					Value = 1,
					Num = 2321,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 78,
				},
				{
					Value = 1,
					Num = 2321,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 78,
				},
				{
					Value = 1,
					Num = 2321,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 15,
				},
				{
					Value = 1,
					Num = 3821,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 15,
				},
				{
					Value = 1,
					Num = 3821,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 3,
				},
				{
					Value = 1,
					Num = 3821,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 3,
				},
				{
					Value = 1,
					Num = 3821,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 247,
				},
				{
					Value = 320051,
					Num = 166,
				},
			},
		},
	},
	DemandID = 410628,
	DemandGroupList = {
		420002,
		420004,
		420005,
		420006,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id629] =
{
	Id = 629,
	Name = "订购龙角1",
	Desc = "需要一些龙角",
	Value = 321410,
	Active = true,
	Weight = 35890,
	PreGoal = 
	{
		300892,
		301288,
	},
	CloseGoal = 
	{
		301605,
	},
	GoodsId = 6401410,
	Priority = 1410748,
	Num = 33,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 41321,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 390,
				},
				{
					Value = 1,
					Num = 2321,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 390,
				},
				{
					Value = 1,
					Num = 2321,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 78,
				},
				{
					Value = 1,
					Num = 2321,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 78,
				},
				{
					Value = 1,
					Num = 2321,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 15,
				},
				{
					Value = 1,
					Num = 3821,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 15,
				},
				{
					Value = 1,
					Num = 3821,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 3,
				},
				{
					Value = 1,
					Num = 3821,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 3,
				},
				{
					Value = 1,
					Num = 3821,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 247,
				},
				{
					Value = 320051,
					Num = 166,
				},
			},
		},
	},
	DemandID = 410629,
	DemandGroupList = {
		420002,
		420004,
		420005,
		420006,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id630] =
{
	Id = 630,
	Name = "订购龙角1",
	Desc = "需要一些龙角",
	Value = 321410,
	Active = true,
	Weight = 37740,
	PreGoal = 
	{
		300892,
		301310,
	},
	CloseGoal = 
	{
		301640,
	},
	GoodsId = 6401410,
	Priority = 1410749,
	Num = 33,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 41321,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 390,
				},
				{
					Value = 1,
					Num = 2321,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 390,
				},
				{
					Value = 1,
					Num = 2321,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 78,
				},
				{
					Value = 1,
					Num = 2321,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 78,
				},
				{
					Value = 1,
					Num = 2321,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 15,
				},
				{
					Value = 1,
					Num = 3821,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 15,
				},
				{
					Value = 1,
					Num = 3821,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 3,
				},
				{
					Value = 1,
					Num = 3821,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 3,
				},
				{
					Value = 1,
					Num = 3821,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 247,
				},
				{
					Value = 320051,
					Num = 166,
				},
			},
		},
	},
	DemandID = 410630,
	DemandGroupList = {
		420002,
		420004,
		420005,
		420006,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id631] =
{
	Id = 631,
	Name = "订购龙角1",
	Desc = "需要一些龙角",
	Value = 321410,
	Active = true,
	Weight = 39960,
	PreGoal = 
	{
		300892,
		301615,
	},
	CloseGoal = 
	{
		301670,
	},
	GoodsId = 6401410,
	Priority = 1410750,
	Num = 33,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 41321,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 390,
				},
				{
					Value = 1,
					Num = 2321,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 390,
				},
				{
					Value = 1,
					Num = 2321,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 78,
				},
				{
					Value = 1,
					Num = 2321,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 78,
				},
				{
					Value = 1,
					Num = 2321,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 15,
				},
				{
					Value = 1,
					Num = 3821,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 15,
				},
				{
					Value = 1,
					Num = 3821,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 3,
				},
				{
					Value = 1,
					Num = 3821,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 3,
				},
				{
					Value = 1,
					Num = 3821,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 247,
				},
				{
					Value = 320051,
					Num = 166,
				},
			},
		},
	},
	DemandID = 410631,
	DemandGroupList = {
		420002,
		420004,
		420005,
		420006,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id632] =
{
	Id = 632,
	Name = "订购箭头1",
	Desc = "需要一些箭头",
	Value = 321411,
	Active = true,
	Weight = 29645,
	PreGoal = 
	{
		300904,
	},
	CloseGoal = 
	{
		301236,
	},
	GoodsId = 6501411,
	Priority = 1411771,
	Num = 27,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 34103,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 289,
				},
				{
					Value = 1,
					Num = 5203,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 289,
				},
				{
					Value = 1,
					Num = 5203,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 57,
				},
				{
					Value = 1,
					Num = 5603,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 57,
				},
				{
					Value = 1,
					Num = 5603,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 11,
				},
				{
					Value = 1,
					Num = 6603,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 11,
				},
				{
					Value = 1,
					Num = 6603,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 2,
				},
				{
					Value = 1,
					Num = 9103,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 2,
				},
				{
					Value = 1,
					Num = 9103,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 204,
				},
				{
					Value = 320051,
					Num = 137,
				},
			},
		},
	},
	DemandID = 410632,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id633] =
{
	Id = 633,
	Name = "订购箭头1",
	Desc = "需要一些箭头",
	Value = 321411,
	Active = true,
	Weight = 30415,
	PreGoal = 
	{
		300904,
		301216,
	},
	CloseGoal = 
	{
		301244,
	},
	GoodsId = 6501411,
	Priority = 1411772,
	Num = 28,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 35366,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 300,
				},
				{
					Value = 1,
					Num = 5366,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 300,
				},
				{
					Value = 1,
					Num = 5366,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 60,
				},
				{
					Value = 1,
					Num = 5366,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 60,
				},
				{
					Value = 1,
					Num = 5366,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 12,
				},
				{
					Value = 1,
					Num = 5366,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 12,
				},
				{
					Value = 1,
					Num = 5366,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 2,
				},
				{
					Value = 1,
					Num = 10366,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 2,
				},
				{
					Value = 1,
					Num = 10366,
				},
			},
		},
	},
	DemandID = 410633,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id634] =
{
	Id = 634,
	Name = "订购箭头1",
	Desc = "需要一些箭头",
	Value = 321411,
	Active = true,
	Weight = 31185,
	PreGoal = 
	{
		300904,
		301224,
	},
	CloseGoal = 
	{
		301256,
	},
	GoodsId = 6501411,
	Priority = 1411773,
	Num = 28,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 35366,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 300,
				},
				{
					Value = 1,
					Num = 5366,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 300,
				},
				{
					Value = 1,
					Num = 5366,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 60,
				},
				{
					Value = 1,
					Num = 5366,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 60,
				},
				{
					Value = 1,
					Num = 5366,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 12,
				},
				{
					Value = 1,
					Num = 5366,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 12,
				},
				{
					Value = 1,
					Num = 5366,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 2,
				},
				{
					Value = 1,
					Num = 10366,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 2,
				},
				{
					Value = 1,
					Num = 10366,
				},
			},
		},
	},
	DemandID = 410634,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id635] =
{
	Id = 635,
	Name = "订购箭头1",
	Desc = "需要一些箭头",
	Value = 321411,
	Active = true,
	Weight = 32340,
	PreGoal = 
	{
		300904,
		301236,
	},
	CloseGoal = 
	{
		301268,
	},
	GoodsId = 6501411,
	Priority = 1411774,
	Num = 30,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 37892,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 322,
				},
				{
					Value = 1,
					Num = 5692,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 322,
				},
				{
					Value = 1,
					Num = 5692,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 64,
				},
				{
					Value = 1,
					Num = 5892,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 64,
				},
				{
					Value = 1,
					Num = 5892,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 12,
				},
				{
					Value = 1,
					Num = 7892,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 12,
				},
				{
					Value = 1,
					Num = 7892,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 2,
				},
				{
					Value = 1,
					Num = 12892,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 2,
				},
				{
					Value = 1,
					Num = 12892,
				},
			},
		},
	},
	DemandID = 410635,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id636] =
{
	Id = 636,
	Name = "订购箭头1",
	Desc = "需要一些箭头",
	Value = 321411,
	Active = true,
	Weight = 33495,
	PreGoal = 
	{
		300904,
		301248,
	},
	CloseGoal = 
	{
		301284,
	},
	GoodsId = 6501411,
	Priority = 1411775,
	Num = 33,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 41681,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 354,
				},
				{
					Value = 1,
					Num = 6281,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 354,
				},
				{
					Value = 1,
					Num = 6281,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 70,
				},
				{
					Value = 1,
					Num = 6681,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 70,
				},
				{
					Value = 1,
					Num = 6681,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 14,
				},
				{
					Value = 1,
					Num = 6681,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 14,
				},
				{
					Value = 1,
					Num = 6681,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 2,
				},
				{
					Value = 1,
					Num = 16681,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 2,
				},
				{
					Value = 1,
					Num = 16681,
				},
			},
		},
	},
	DemandID = 410636,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id637] =
{
	Id = 637,
	Name = "订购箭头1",
	Desc = "需要一些箭头",
	Value = 321411,
	Active = true,
	Weight = 35035,
	PreGoal = 
	{
		300904,
		301264,
	},
	CloseGoal = 
	{
		301301,
	},
	GoodsId = 6501411,
	Priority = 1411776,
	Num = 33,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 41681,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 354,
				},
				{
					Value = 1,
					Num = 6281,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 354,
				},
				{
					Value = 1,
					Num = 6281,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 70,
				},
				{
					Value = 1,
					Num = 6681,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 70,
				},
				{
					Value = 1,
					Num = 6681,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 14,
				},
				{
					Value = 1,
					Num = 6681,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 14,
				},
				{
					Value = 1,
					Num = 6681,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 2,
				},
				{
					Value = 1,
					Num = 16681,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 2,
				},
				{
					Value = 1,
					Num = 16681,
				},
			},
		},
	},
	DemandID = 410637,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id638] =
{
	Id = 638,
	Name = "订购箭头1",
	Desc = "需要一些箭头",
	Value = 321411,
	Active = true,
	Weight = 36575,
	PreGoal = 
	{
		300904,
		301280,
	},
	CloseGoal = 
	{
		301322,
	},
	GoodsId = 6501411,
	Priority = 1411777,
	Num = 33,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 41681,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 354,
				},
				{
					Value = 1,
					Num = 6281,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 354,
				},
				{
					Value = 1,
					Num = 6281,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 70,
				},
				{
					Value = 1,
					Num = 6681,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 70,
				},
				{
					Value = 1,
					Num = 6681,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 14,
				},
				{
					Value = 1,
					Num = 6681,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 14,
				},
				{
					Value = 1,
					Num = 6681,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 2,
				},
				{
					Value = 1,
					Num = 16681,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 2,
				},
				{
					Value = 1,
					Num = 16681,
				},
			},
		},
	},
	DemandID = 410638,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id639] =
{
	Id = 639,
	Name = "订购箭头1",
	Desc = "需要一些箭头",
	Value = 321411,
	Active = true,
	Weight = 38500,
	PreGoal = 
	{
		300904,
		301301,
	},
	CloseGoal = 
	{
		301625,
	},
	GoodsId = 6501411,
	Priority = 1411778,
	Num = 33,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 41681,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 354,
				},
				{
					Value = 1,
					Num = 6281,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 354,
				},
				{
					Value = 1,
					Num = 6281,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 70,
				},
				{
					Value = 1,
					Num = 6681,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 70,
				},
				{
					Value = 1,
					Num = 6681,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 14,
				},
				{
					Value = 1,
					Num = 6681,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 14,
				},
				{
					Value = 1,
					Num = 6681,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 2,
				},
				{
					Value = 1,
					Num = 16681,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 2,
				},
				{
					Value = 1,
					Num = 16681,
				},
			},
		},
	},
	DemandID = 410639,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id640] =
{
	Id = 640,
	Name = "订购箭头1",
	Desc = "需要一些箭头",
	Value = 321411,
	Active = true,
	Weight = 40425,
	PreGoal = 
	{
		300904,
		301322,
	},
	CloseGoal = 
	{
		301655,
	},
	GoodsId = 6501411,
	Priority = 1411779,
	Num = 33,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 41681,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 354,
				},
				{
					Value = 1,
					Num = 6281,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 354,
				},
				{
					Value = 1,
					Num = 6281,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 70,
				},
				{
					Value = 1,
					Num = 6681,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 70,
				},
				{
					Value = 1,
					Num = 6681,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 14,
				},
				{
					Value = 1,
					Num = 6681,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 14,
				},
				{
					Value = 1,
					Num = 6681,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 2,
				},
				{
					Value = 1,
					Num = 16681,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 2,
				},
				{
					Value = 1,
					Num = 16681,
				},
			},
		},
	},
	DemandID = 410640,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id641] =
{
	Id = 641,
	Name = "订购箭头1",
	Desc = "需要一些箭头",
	Value = 321411,
	Active = true,
	Weight = 42735,
	PreGoal = 
	{
		300904,
		301630,
	},
	CloseGoal = 
	{
		301685,
	},
	GoodsId = 6501411,
	Priority = 1411780,
	Num = 33,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 41681,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 354,
				},
				{
					Value = 1,
					Num = 6281,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 354,
				},
				{
					Value = 1,
					Num = 6281,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 70,
				},
				{
					Value = 1,
					Num = 6681,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 70,
				},
				{
					Value = 1,
					Num = 6681,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 14,
				},
				{
					Value = 1,
					Num = 6681,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 14,
				},
				{
					Value = 1,
					Num = 6681,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 2,
				},
				{
					Value = 1,
					Num = 16681,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 2,
				},
				{
					Value = 1,
					Num = 16681,
				},
			},
		},
	},
	DemandID = 410641,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id642] =
{
	Id = 642,
	Name = "订购黄蛋壳1",
	Desc = "需要一些黄蛋壳",
	Value = 321451,
	Active = true,
	Weight = 11532,
	PreGoal = 
	{
		301143,
		300844,
	},
	CloseGoal = 
	{
		300872,
	},
	GoodsId = 6601451,
	Priority = 1451621,
	Num = 10,
	RewardList = {
		{
			Weight = 0,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 72105,
				},
			},
		},
		{
			Weight = 80,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320001,
					Num = 7,
				},
				{
					Value = 1,
					Num = 11625,
				},
			},
		},
		{
			Weight = 60,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320002,
					Num = 2,
				},
				{
					Value = 1,
					Num = 20265,
				},
			},
		},
	},
	DemandID = 410642,
	DemandGroupList = {
		420003,
		420008,
		420009,
	},
}
DemandConfig[DemandID.Id643] =
{
	Id = 643,
	Name = "订购黄蛋壳1",
	Desc = "需要一些黄蛋壳",
	Value = 321451,
	Active = true,
	Weight = 11904,
	PreGoal = 
	{
		301143,
		300852,
	},
	CloseGoal = 
	{
		300880,
	},
	GoodsId = 6601451,
	Priority = 1451622,
	Num = 10,
	RewardList = {
		{
			Weight = 0,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 72105,
				},
			},
		},
		{
			Weight = 80,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320001,
					Num = 7,
				},
				{
					Value = 1,
					Num = 11625,
				},
			},
		},
		{
			Weight = 60,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320002,
					Num = 2,
				},
				{
					Value = 1,
					Num = 20265,
				},
			},
		},
	},
	DemandID = 410643,
	DemandGroupList = {
		420003,
		420008,
		420009,
	},
}
DemandConfig[DemandID.Id644] =
{
	Id = 644,
	Name = "订购黄蛋壳1",
	Desc = "需要一些黄蛋壳",
	Value = 321451,
	Active = true,
	Weight = 12276,
	PreGoal = 
	{
		301143,
		300860,
	},
	CloseGoal = 
	{
		300892,
	},
	GoodsId = 6601451,
	Priority = 1451623,
	Num = 12,
	RewardList = {
		{
			Weight = 0,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 86526,
				},
			},
		},
		{
			Weight = 80,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320001,
					Num = 9,
				},
				{
					Value = 1,
					Num = 8766,
				},
			},
		},
		{
			Weight = 60,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320002,
					Num = 3,
				},
				{
					Value = 1,
					Num = 8766,
				},
			},
		},
	},
	DemandID = 410644,
	DemandGroupList = {
		420003,
		420008,
		420009,
	},
}
DemandConfig[DemandID.Id645] =
{
	Id = 645,
	Name = "订购黄蛋壳1",
	Desc = "需要一些黄蛋壳",
	Value = 321451,
	Active = true,
	Weight = 12834,
	PreGoal = 
	{
		301143,
		300872,
	},
	CloseGoal = 
	{
		300904,
	},
	GoodsId = 6601451,
	Priority = 1451624,
	Num = 12,
	RewardList = {
		{
			Weight = 0,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 86526,
				},
			},
		},
		{
			Weight = 80,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320001,
					Num = 9,
				},
				{
					Value = 1,
					Num = 8766,
				},
			},
		},
		{
			Weight = 60,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320002,
					Num = 3,
				},
				{
					Value = 1,
					Num = 8766,
				},
			},
		},
	},
	DemandID = 410645,
	DemandGroupList = {
		420003,
		420008,
		420009,
	},
}
DemandConfig[DemandID.Id646] =
{
	Id = 646,
	Name = "订购黄蛋壳1",
	Desc = "需要一些黄蛋壳",
	Value = 321451,
	Active = true,
	Weight = 13392,
	PreGoal = 
	{
		301143,
		300884,
	},
	CloseGoal = 
	{
		301224,
	},
	GoodsId = 6601451,
	Priority = 1451625,
	Num = 12,
	RewardList = {
		{
			Weight = 0,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 86526,
				},
			},
		},
		{
			Weight = 80,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320001,
					Num = 9,
				},
				{
					Value = 1,
					Num = 8766,
				},
			},
		},
		{
			Weight = 60,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320002,
					Num = 3,
				},
				{
					Value = 1,
					Num = 8766,
				},
			},
		},
	},
	DemandID = 410646,
	DemandGroupList = {
		420003,
		420008,
		420009,
	},
}
DemandConfig[DemandID.Id647] =
{
	Id = 647,
	Name = "订购黄蛋壳1",
	Desc = "需要一些黄蛋壳",
	Value = 321451,
	Active = true,
	Weight = 14136,
	PreGoal = 
	{
		301143,
		300900,
	},
	CloseGoal = 
	{
		301240,
	},
	GoodsId = 6601451,
	Priority = 1451626,
	Num = 14,
	RewardList = {
		{
			Weight = 0,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 100947,
				},
			},
		},
		{
			Weight = 80,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320001,
					Num = 10,
				},
				{
					Value = 1,
					Num = 14547,
				},
			},
		},
		{
			Weight = 60,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320002,
					Num = 3,
				},
				{
					Value = 1,
					Num = 23187,
				},
			},
		},
		{
			Weight = 40,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320003,
					Num = 1,
				},
				{
					Value = 1,
					Num = 14547,
				},
			},
		},
	},
	DemandID = 410647,
	DemandGroupList = {
		420003,
		420008,
		420009,
	},
}
DemandConfig[DemandID.Id648] =
{
	Id = 648,
	Name = "订购黄蛋壳1",
	Desc = "需要一些黄蛋壳",
	Value = 321451,
	Active = true,
	Weight = 14880,
	PreGoal = 
	{
		301143,
		301220,
	},
	CloseGoal = 
	{
		301260,
	},
	GoodsId = 6601451,
	Priority = 1451627,
	Num = 15,
	RewardList = {
		{
			Weight = 0,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 108158,
				},
			},
		},
		{
			Weight = 80,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320001,
					Num = 11,
				},
				{
					Value = 1,
					Num = 13118,
				},
			},
		},
		{
			Weight = 60,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320002,
					Num = 3,
				},
				{
					Value = 1,
					Num = 30398,
				},
			},
		},
		{
			Weight = 40,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320003,
					Num = 1,
				},
				{
					Value = 1,
					Num = 21758,
				},
			},
		},
	},
	DemandID = 410648,
	DemandGroupList = {
		420003,
		420008,
		420009,
	},
}
DemandConfig[DemandID.Id649] =
{
	Id = 649,
	Name = "订购黄蛋壳1",
	Desc = "需要一些黄蛋壳",
	Value = 321451,
	Active = true,
	Weight = 15810,
	PreGoal = 
	{
		301143,
		301240,
	},
	CloseGoal = 
	{
		301280,
	},
	GoodsId = 6601451,
	Priority = 1451628,
	Num = 16,
	RewardList = {
		{
			Weight = 0,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 115368,
				},
			},
		},
		{
			Weight = 80,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320001,
					Num = 12,
				},
				{
					Value = 1,
					Num = 11688,
				},
			},
		},
		{
			Weight = 60,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320002,
					Num = 4,
				},
				{
					Value = 1,
					Num = 11688,
				},
			},
		},
		{
			Weight = 40,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320003,
					Num = 1,
				},
				{
					Value = 1,
					Num = 28968,
				},
			},
		},
	},
	DemandID = 410649,
	DemandGroupList = {
		420003,
		420008,
		420009,
	},
}
DemandConfig[DemandID.Id650] =
{
	Id = 650,
	Name = "订购黄蛋壳1",
	Desc = "需要一些黄蛋壳",
	Value = 321451,
	Active = true,
	Weight = 16740,
	PreGoal = 
	{
		301143,
		301260,
	},
	CloseGoal = 
	{
		301306,
	},
	GoodsId = 6601451,
	Priority = 1451629,
	Num = 18,
	RewardList = {
		{
			Weight = 0,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 129790,
				},
			},
		},
		{
			Weight = 80,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320001,
					Num = 13,
				},
				{
					Value = 1,
					Num = 17470,
				},
			},
		},
		{
			Weight = 60,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320002,
					Num = 4,
				},
				{
					Value = 1,
					Num = 26110,
				},
			},
		},
		{
			Weight = 40,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320003,
					Num = 1,
				},
				{
					Value = 1,
					Num = 43390,
				},
			},
		},
	},
	DemandID = 410650,
	DemandGroupList = {
		420003,
		420008,
		420009,
	},
}
DemandConfig[DemandID.Id651] =
{
	Id = 651,
	Name = "订购黄蛋壳1",
	Desc = "需要一些黄蛋壳",
	Value = 321451,
	Active = true,
	Weight = 17856,
	PreGoal = 
	{
		301143,
		301284,
	},
	CloseGoal = 
	{
		301605,
	},
	GoodsId = 6601451,
	Priority = 1451630,
	Num = 18,
	RewardList = {
		{
			Weight = 0,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 129790,
				},
			},
		},
		{
			Weight = 80,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320001,
					Num = 13,
				},
				{
					Value = 1,
					Num = 17470,
				},
			},
		},
		{
			Weight = 60,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320002,
					Num = 4,
				},
				{
					Value = 1,
					Num = 26110,
				},
			},
		},
		{
			Weight = 40,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320003,
					Num = 1,
				},
				{
					Value = 1,
					Num = 43390,
				},
			},
		},
	},
	DemandID = 410651,
	DemandGroupList = {
		420003,
		420008,
		420009,
	},
}
DemandConfig[DemandID.Id652] =
{
	Id = 652,
	Name = "订购黄面具1",
	Desc = "需要一些黄面具",
	Value = 321452,
	Active = true,
	Weight = 15552,
	PreGoal = 
	{
		301144,
		300884,
	},
	CloseGoal = 
	{
		301216,
	},
	GoodsId = 6701452,
	Priority = 1452721,
	Num = 12,
	RewardList = {
		{
			Weight = 0,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 102128,
				},
			},
		},
		{
			Weight = 80,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320001,
					Num = 10,
				},
				{
					Value = 1,
					Num = 15728,
				},
			},
		},
		{
			Weight = 60,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320002,
					Num = 3,
				},
				{
					Value = 1,
					Num = 24368,
				},
			},
		},
		{
			Weight = 40,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320003,
					Num = 1,
				},
				{
					Value = 1,
					Num = 15728,
				},
			},
		},
	},
	DemandID = 410652,
	DemandGroupList = {
		420003,
		420008,
		420009,
	},
}
DemandConfig[DemandID.Id653] =
{
	Id = 653,
	Name = "订购黄面具1",
	Desc = "需要一些黄面具",
	Value = 321452,
	Active = true,
	Weight = 15984,
	PreGoal = 
	{
		301144,
		300892,
	},
	CloseGoal = 
	{
		301224,
	},
	GoodsId = 6701452,
	Priority = 1452722,
	Num = 12,
	RewardList = {
		{
			Weight = 0,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 102128,
				},
			},
		},
		{
			Weight = 80,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320001,
					Num = 10,
				},
				{
					Value = 1,
					Num = 15728,
				},
			},
		},
		{
			Weight = 60,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320002,
					Num = 3,
				},
				{
					Value = 1,
					Num = 24368,
				},
			},
		},
		{
			Weight = 40,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320003,
					Num = 1,
				},
				{
					Value = 1,
					Num = 15728,
				},
			},
		},
	},
	DemandID = 410653,
	DemandGroupList = {
		420003,
		420008,
		420009,
	},
}
DemandConfig[DemandID.Id654] =
{
	Id = 654,
	Name = "订购黄面具1",
	Desc = "需要一些黄面具",
	Value = 321452,
	Active = true,
	Weight = 16416,
	PreGoal = 
	{
		301144,
		300900,
	},
	CloseGoal = 
	{
		301236,
	},
	GoodsId = 6701452,
	Priority = 1452723,
	Num = 12,
	RewardList = {
		{
			Weight = 0,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 102128,
				},
			},
		},
		{
			Weight = 80,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320001,
					Num = 10,
				},
				{
					Value = 1,
					Num = 15728,
				},
			},
		},
		{
			Weight = 60,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320002,
					Num = 3,
				},
				{
					Value = 1,
					Num = 24368,
				},
			},
		},
		{
			Weight = 40,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320003,
					Num = 1,
				},
				{
					Value = 1,
					Num = 15728,
				},
			},
		},
	},
	DemandID = 410654,
	DemandGroupList = {
		420003,
		420008,
		420009,
	},
}
DemandConfig[DemandID.Id655] =
{
	Id = 655,
	Name = "订购黄面具1",
	Desc = "需要一些黄面具",
	Value = 321452,
	Active = true,
	Weight = 17064,
	PreGoal = 
	{
		301144,
		301216,
	},
	CloseGoal = 
	{
		301248,
	},
	GoodsId = 6701452,
	Priority = 1452724,
	Num = 12,
	RewardList = {
		{
			Weight = 0,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 102128,
				},
			},
		},
		{
			Weight = 80,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320001,
					Num = 10,
				},
				{
					Value = 1,
					Num = 15728,
				},
			},
		},
		{
			Weight = 60,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320002,
					Num = 3,
				},
				{
					Value = 1,
					Num = 24368,
				},
			},
		},
		{
			Weight = 40,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320003,
					Num = 1,
				},
				{
					Value = 1,
					Num = 15728,
				},
			},
		},
	},
	DemandID = 410655,
	DemandGroupList = {
		420003,
		420008,
		420009,
	},
}
DemandConfig[DemandID.Id656] =
{
	Id = 656,
	Name = "订购黄面具1",
	Desc = "需要一些黄面具",
	Value = 321452,
	Active = true,
	Weight = 17712,
	PreGoal = 
	{
		301144,
		301228,
	},
	CloseGoal = 
	{
		301264,
	},
	GoodsId = 6701452,
	Priority = 1452725,
	Num = 14,
	RewardList = {
		{
			Weight = 0,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 119149,
				},
			},
		},
		{
			Weight = 80,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320001,
					Num = 12,
				},
				{
					Value = 1,
					Num = 15469,
				},
			},
		},
		{
			Weight = 60,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320002,
					Num = 4,
				},
				{
					Value = 1,
					Num = 15469,
				},
			},
		},
		{
			Weight = 40,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320003,
					Num = 1,
				},
				{
					Value = 1,
					Num = 32749,
				},
			},
		},
	},
	DemandID = 410656,
	DemandGroupList = {
		420003,
		420008,
		420009,
	},
}
DemandConfig[DemandID.Id657] =
{
	Id = 657,
	Name = "订购黄面具1",
	Desc = "需要一些黄面具",
	Value = 321452,
	Active = true,
	Weight = 18576,
	PreGoal = 
	{
		301144,
		301244,
	},
	CloseGoal = 
	{
		301280,
	},
	GoodsId = 6701452,
	Priority = 1452726,
	Num = 16,
	RewardList = {
		{
			Weight = 0,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 136170,
				},
			},
		},
		{
			Weight = 80,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320001,
					Num = 14,
				},
				{
					Value = 1,
					Num = 15210,
				},
			},
		},
		{
			Weight = 60,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320002,
					Num = 4,
				},
				{
					Value = 1,
					Num = 32490,
				},
			},
		},
		{
			Weight = 40,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320003,
					Num = 1,
				},
				{
					Value = 1,
					Num = 49770,
				},
			},
		},
	},
	DemandID = 410657,
	DemandGroupList = {
		420003,
		420008,
		420009,
	},
}
DemandConfig[DemandID.Id658] =
{
	Id = 658,
	Name = "订购黄面具1",
	Desc = "需要一些黄面具",
	Value = 321452,
	Active = true,
	Weight = 19440,
	PreGoal = 
	{
		301144,
		301260,
	},
	CloseGoal = 
	{
		301301,
	},
	GoodsId = 6701452,
	Priority = 1452727,
	Num = 16,
	RewardList = {
		{
			Weight = 0,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 136170,
				},
			},
		},
		{
			Weight = 80,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320001,
					Num = 14,
				},
				{
					Value = 1,
					Num = 15210,
				},
			},
		},
		{
			Weight = 60,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320002,
					Num = 4,
				},
				{
					Value = 1,
					Num = 32490,
				},
			},
		},
		{
			Weight = 40,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320003,
					Num = 1,
				},
				{
					Value = 1,
					Num = 49770,
				},
			},
		},
	},
	DemandID = 410658,
	DemandGroupList = {
		420003,
		420008,
		420009,
	},
}
DemandConfig[DemandID.Id659] =
{
	Id = 659,
	Name = "订购黄面具1",
	Desc = "需要一些黄面具",
	Value = 321452,
	Active = true,
	Weight = 20520,
	PreGoal = 
	{
		301144,
		301280,
	},
	CloseGoal = 
	{
		301322,
	},
	GoodsId = 6701452,
	Priority = 1452728,
	Num = 16,
	RewardList = {
		{
			Weight = 0,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 136170,
				},
			},
		},
		{
			Weight = 80,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320001,
					Num = 14,
				},
				{
					Value = 1,
					Num = 15210,
				},
			},
		},
		{
			Weight = 60,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320002,
					Num = 4,
				},
				{
					Value = 1,
					Num = 32490,
				},
			},
		},
		{
			Weight = 40,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320003,
					Num = 1,
				},
				{
					Value = 1,
					Num = 49770,
				},
			},
		},
	},
	DemandID = 410659,
	DemandGroupList = {
		420003,
		420008,
		420009,
	},
}
DemandConfig[DemandID.Id660] =
{
	Id = 660,
	Name = "订购黄面具1",
	Desc = "需要一些黄面具",
	Value = 321452,
	Active = true,
	Weight = 21600,
	PreGoal = 
	{
		301144,
		301301,
	},
	CloseGoal = 
	{
		301630,
	},
	GoodsId = 6701452,
	Priority = 1452729,
	Num = 16,
	RewardList = {
		{
			Weight = 0,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 136170,
				},
			},
		},
		{
			Weight = 80,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320001,
					Num = 14,
				},
				{
					Value = 1,
					Num = 15210,
				},
			},
		},
		{
			Weight = 60,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320002,
					Num = 4,
				},
				{
					Value = 1,
					Num = 32490,
				},
			},
		},
		{
			Weight = 40,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320003,
					Num = 1,
				},
				{
					Value = 1,
					Num = 49770,
				},
			},
		},
	},
	DemandID = 410660,
	DemandGroupList = {
		420003,
		420008,
		420009,
	},
}
DemandConfig[DemandID.Id661] =
{
	Id = 661,
	Name = "订购黄面具1",
	Desc = "需要一些黄面具",
	Value = 321452,
	Active = true,
	Weight = 22896,
	PreGoal = 
	{
		301144,
		301327,
	},
	CloseGoal = 
	{
		301660,
	},
	GoodsId = 6701452,
	Priority = 1452730,
	Num = 16,
	RewardList = {
		{
			Weight = 0,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 136170,
				},
			},
		},
		{
			Weight = 80,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320001,
					Num = 14,
				},
				{
					Value = 1,
					Num = 15210,
				},
			},
		},
		{
			Weight = 60,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320002,
					Num = 4,
				},
				{
					Value = 1,
					Num = 32490,
				},
			},
		},
		{
			Weight = 40,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320003,
					Num = 1,
				},
				{
					Value = 1,
					Num = 49770,
				},
			},
		},
	},
	DemandID = 410661,
	DemandGroupList = {
		420003,
		420008,
		420009,
	},
}
DemandConfig[DemandID.Id662] =
{
	Id = 662,
	Name = "订购化石骨1",
	Desc = "需要一些化石骨",
	Value = 321453,
	Active = true,
	Weight = 16428,
	PreGoal = 
	{
		301145,
		300892,
	},
	CloseGoal = 
	{
		301224,
	},
	GoodsId = 6801453,
	Priority = 1453741,
	Num = 10,
	RewardList = {
		{
			Weight = 0,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 105610,
				},
			},
		},
		{
			Weight = 80,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320001,
					Num = 11,
				},
				{
					Value = 1,
					Num = 10570,
				},
			},
		},
		{
			Weight = 60,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320002,
					Num = 3,
				},
				{
					Value = 1,
					Num = 27850,
				},
			},
		},
		{
			Weight = 40,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320003,
					Num = 1,
				},
				{
					Value = 1,
					Num = 19210,
				},
			},
		},
	},
	DemandID = 410662,
	DemandGroupList = {
		420003,
		420008,
		420009,
	},
}
DemandConfig[DemandID.Id663] =
{
	Id = 663,
	Name = "订购化石骨1",
	Desc = "需要一些化石骨",
	Value = 321453,
	Active = true,
	Weight = 16872,
	PreGoal = 
	{
		301145,
		300900,
	},
	CloseGoal = 
	{
		301232,
	},
	GoodsId = 6801453,
	Priority = 1453742,
	Num = 10,
	RewardList = {
		{
			Weight = 0,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 105610,
				},
			},
		},
		{
			Weight = 80,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320001,
					Num = 11,
				},
				{
					Value = 1,
					Num = 10570,
				},
			},
		},
		{
			Weight = 60,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320002,
					Num = 3,
				},
				{
					Value = 1,
					Num = 27850,
				},
			},
		},
		{
			Weight = 40,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320003,
					Num = 1,
				},
				{
					Value = 1,
					Num = 19210,
				},
			},
		},
	},
	DemandID = 410663,
	DemandGroupList = {
		420003,
		420008,
		420009,
	},
}
DemandConfig[DemandID.Id664] =
{
	Id = 664,
	Name = "订购化石骨1",
	Desc = "需要一些化石骨",
	Value = 321453,
	Active = true,
	Weight = 17316,
	PreGoal = 
	{
		301145,
		301204,
	},
	CloseGoal = 
	{
		301244,
	},
	GoodsId = 6801453,
	Priority = 1453743,
	Num = 10,
	RewardList = {
		{
			Weight = 0,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 105610,
				},
			},
		},
		{
			Weight = 80,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320001,
					Num = 11,
				},
				{
					Value = 1,
					Num = 10570,
				},
			},
		},
		{
			Weight = 60,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320002,
					Num = 3,
				},
				{
					Value = 1,
					Num = 27850,
				},
			},
		},
		{
			Weight = 40,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320003,
					Num = 1,
				},
				{
					Value = 1,
					Num = 19210,
				},
			},
		},
	},
	DemandID = 410664,
	DemandGroupList = {
		420003,
		420008,
		420009,
	},
}
DemandConfig[DemandID.Id665] =
{
	Id = 665,
	Name = "订购化石骨1",
	Desc = "需要一些化石骨",
	Value = 321453,
	Active = true,
	Weight = 17982,
	PreGoal = 
	{
		301145,
		301224,
	},
	CloseGoal = 
	{
		301256,
	},
	GoodsId = 6801453,
	Priority = 1453744,
	Num = 12,
	RewardList = {
		{
			Weight = 0,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 126732,
				},
			},
		},
		{
			Weight = 80,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320001,
					Num = 13,
				},
				{
					Value = 1,
					Num = 14412,
				},
			},
		},
		{
			Weight = 60,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320002,
					Num = 4,
				},
				{
					Value = 1,
					Num = 23052,
				},
			},
		},
		{
			Weight = 40,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320003,
					Num = 1,
				},
				{
					Value = 1,
					Num = 40332,
				},
			},
		},
	},
	DemandID = 410665,
	DemandGroupList = {
		420003,
		420008,
		420009,
	},
}
DemandConfig[DemandID.Id666] =
{
	Id = 666,
	Name = "订购化石骨1",
	Desc = "需要一些化石骨",
	Value = 321453,
	Active = true,
	Weight = 18648,
	PreGoal = 
	{
		301145,
		301236,
	},
	CloseGoal = 
	{
		301272,
	},
	GoodsId = 6801453,
	Priority = 1453745,
	Num = 12,
	RewardList = {
		{
			Weight = 0,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 126732,
				},
			},
		},
		{
			Weight = 80,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320001,
					Num = 13,
				},
				{
					Value = 1,
					Num = 14412,
				},
			},
		},
		{
			Weight = 60,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320002,
					Num = 4,
				},
				{
					Value = 1,
					Num = 23052,
				},
			},
		},
		{
			Weight = 40,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320003,
					Num = 1,
				},
				{
					Value = 1,
					Num = 40332,
				},
			},
		},
	},
	DemandID = 410666,
	DemandGroupList = {
		420003,
		420008,
		420009,
	},
}
DemandConfig[DemandID.Id667] =
{
	Id = 667,
	Name = "订购化石骨1",
	Desc = "需要一些化石骨",
	Value = 321453,
	Active = true,
	Weight = 19536,
	PreGoal = 
	{
		301145,
		301252,
	},
	CloseGoal = 
	{
		301288,
	},
	GoodsId = 6801453,
	Priority = 1453746,
	Num = 12,
	RewardList = {
		{
			Weight = 0,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 126732,
				},
			},
		},
		{
			Weight = 80,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320001,
					Num = 13,
				},
				{
					Value = 1,
					Num = 14412,
				},
			},
		},
		{
			Weight = 60,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320002,
					Num = 4,
				},
				{
					Value = 1,
					Num = 23052,
				},
			},
		},
		{
			Weight = 40,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320003,
					Num = 1,
				},
				{
					Value = 1,
					Num = 40332,
				},
			},
		},
	},
	DemandID = 410667,
	DemandGroupList = {
		420003,
		420008,
		420009,
	},
}
DemandConfig[DemandID.Id668] =
{
	Id = 668,
	Name = "订购化石骨1",
	Desc = "需要一些化石骨",
	Value = 321453,
	Active = true,
	Weight = 20424,
	PreGoal = 
	{
		301145,
		301268,
	},
	CloseGoal = 
	{
		301310,
	},
	GoodsId = 6801453,
	Priority = 1453747,
	Num = 12,
	RewardList = {
		{
			Weight = 0,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 126732,
				},
			},
		},
		{
			Weight = 80,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320001,
					Num = 13,
				},
				{
					Value = 1,
					Num = 14412,
				},
			},
		},
		{
			Weight = 60,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320002,
					Num = 4,
				},
				{
					Value = 1,
					Num = 23052,
				},
			},
		},
		{
			Weight = 40,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320003,
					Num = 1,
				},
				{
					Value = 1,
					Num = 40332,
				},
			},
		},
	},
	DemandID = 410668,
	DemandGroupList = {
		420003,
		420008,
		420009,
	},
}
DemandConfig[DemandID.Id669] =
{
	Id = 669,
	Name = "订购化石骨1",
	Desc = "需要一些化石骨",
	Value = 321453,
	Active = true,
	Weight = 21534,
	PreGoal = 
	{
		301145,
		301288,
	},
	CloseGoal = 
	{
		301605,
	},
	GoodsId = 6801453,
	Priority = 1453748,
	Num = 12,
	RewardList = {
		{
			Weight = 0,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 126732,
				},
			},
		},
		{
			Weight = 80,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320001,
					Num = 13,
				},
				{
					Value = 1,
					Num = 14412,
				},
			},
		},
		{
			Weight = 60,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320002,
					Num = 4,
				},
				{
					Value = 1,
					Num = 23052,
				},
			},
		},
		{
			Weight = 40,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320003,
					Num = 1,
				},
				{
					Value = 1,
					Num = 40332,
				},
			},
		},
	},
	DemandID = 410669,
	DemandGroupList = {
		420003,
		420008,
		420009,
	},
}
DemandConfig[DemandID.Id670] =
{
	Id = 670,
	Name = "订购化石骨1",
	Desc = "需要一些化石骨",
	Value = 321453,
	Active = true,
	Weight = 22644,
	PreGoal = 
	{
		301145,
		301310,
	},
	CloseGoal = 
	{
		301640,
	},
	GoodsId = 6801453,
	Priority = 1453749,
	Num = 12,
	RewardList = {
		{
			Weight = 0,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 126732,
				},
			},
		},
		{
			Weight = 80,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320001,
					Num = 13,
				},
				{
					Value = 1,
					Num = 14412,
				},
			},
		},
		{
			Weight = 60,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320002,
					Num = 4,
				},
				{
					Value = 1,
					Num = 23052,
				},
			},
		},
		{
			Weight = 40,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320003,
					Num = 1,
				},
				{
					Value = 1,
					Num = 40332,
				},
			},
		},
	},
	DemandID = 410670,
	DemandGroupList = {
		420003,
		420008,
		420009,
	},
}
DemandConfig[DemandID.Id671] =
{
	Id = 671,
	Name = "订购化石骨1",
	Desc = "需要一些化石骨",
	Value = 321453,
	Active = true,
	Weight = 23976,
	PreGoal = 
	{
		301145,
		301615,
	},
	CloseGoal = 
	{
		301670,
	},
	GoodsId = 6801453,
	Priority = 1453750,
	Num = 12,
	RewardList = {
		{
			Weight = 0,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 126732,
				},
			},
		},
		{
			Weight = 80,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320001,
					Num = 13,
				},
				{
					Value = 1,
					Num = 14412,
				},
			},
		},
		{
			Weight = 60,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320002,
					Num = 4,
				},
				{
					Value = 1,
					Num = 23052,
				},
			},
		},
		{
			Weight = 40,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320003,
					Num = 1,
				},
				{
					Value = 1,
					Num = 40332,
				},
			},
		},
	},
	DemandID = 410671,
	DemandGroupList = {
		420003,
		420008,
		420009,
	},
}
DemandConfig[DemandID.Id672] =
{
	Id = 672,
	Name = "订购导览图1",
	Desc = "需要一些导览图",
	Value = 321454,
	Active = true,
	Weight = 17787,
	PreGoal = 
	{
		301146,
		300904,
	},
	CloseGoal = 
	{
		301236,
	},
	GoodsId = 6901454,
	Priority = 1454771,
	Num = 10,
	RewardList = {
		{
			Weight = 0,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 108914,
				},
			},
		},
		{
			Weight = 80,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320001,
					Num = 11,
				},
				{
					Value = 1,
					Num = 13874,
				},
			},
		},
		{
			Weight = 60,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320002,
					Num = 3,
				},
				{
					Value = 1,
					Num = 31154,
				},
			},
		},
		{
			Weight = 40,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320003,
					Num = 1,
				},
				{
					Value = 1,
					Num = 22514,
				},
			},
		},
	},
	DemandID = 410672,
	DemandGroupList = {
		420003,
		420008,
		420009,
	},
}
DemandConfig[DemandID.Id673] =
{
	Id = 673,
	Name = "订购导览图1",
	Desc = "需要一些导览图",
	Value = 321454,
	Active = true,
	Weight = 18249,
	PreGoal = 
	{
		301146,
		301216,
	},
	CloseGoal = 
	{
		301244,
	},
	GoodsId = 6901454,
	Priority = 1454772,
	Num = 10,
	RewardList = {
		{
			Weight = 0,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 108914,
				},
			},
		},
		{
			Weight = 80,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320001,
					Num = 11,
				},
				{
					Value = 1,
					Num = 13874,
				},
			},
		},
		{
			Weight = 60,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320002,
					Num = 3,
				},
				{
					Value = 1,
					Num = 31154,
				},
			},
		},
		{
			Weight = 40,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320003,
					Num = 1,
				},
				{
					Value = 1,
					Num = 22514,
				},
			},
		},
	},
	DemandID = 410673,
	DemandGroupList = {
		420003,
		420008,
		420009,
	},
}
DemandConfig[DemandID.Id674] =
{
	Id = 674,
	Name = "订购导览图1",
	Desc = "需要一些导览图",
	Value = 321454,
	Active = true,
	Weight = 18711,
	PreGoal = 
	{
		301146,
		301224,
	},
	CloseGoal = 
	{
		301256,
	},
	GoodsId = 6901454,
	Priority = 1454773,
	Num = 12,
	RewardList = {
		{
			Weight = 0,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 130697,
				},
			},
		},
		{
			Weight = 80,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320001,
					Num = 13,
				},
				{
					Value = 1,
					Num = 18377,
				},
			},
		},
		{
			Weight = 60,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320002,
					Num = 4,
				},
				{
					Value = 1,
					Num = 27017,
				},
			},
		},
		{
			Weight = 40,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320003,
					Num = 1,
				},
				{
					Value = 1,
					Num = 44297,
				},
			},
		},
	},
	DemandID = 410674,
	DemandGroupList = {
		420003,
		420008,
		420009,
	},
}
DemandConfig[DemandID.Id675] =
{
	Id = 675,
	Name = "订购导览图1",
	Desc = "需要一些导览图",
	Value = 321454,
	Active = true,
	Weight = 19404,
	PreGoal = 
	{
		301146,
		301236,
	},
	CloseGoal = 
	{
		301268,
	},
	GoodsId = 6901454,
	Priority = 1454774,
	Num = 12,
	RewardList = {
		{
			Weight = 0,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 130697,
				},
			},
		},
		{
			Weight = 80,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320001,
					Num = 13,
				},
				{
					Value = 1,
					Num = 18377,
				},
			},
		},
		{
			Weight = 60,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320002,
					Num = 4,
				},
				{
					Value = 1,
					Num = 27017,
				},
			},
		},
		{
			Weight = 40,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320003,
					Num = 1,
				},
				{
					Value = 1,
					Num = 44297,
				},
			},
		},
	},
	DemandID = 410675,
	DemandGroupList = {
		420003,
		420008,
		420009,
	},
}
DemandConfig[DemandID.Id676] =
{
	Id = 676,
	Name = "订购导览图1",
	Desc = "需要一些导览图",
	Value = 321454,
	Active = true,
	Weight = 20097,
	PreGoal = 
	{
		301146,
		301248,
	},
	CloseGoal = 
	{
		301284,
	},
	GoodsId = 6901454,
	Priority = 1454775,
	Num = 12,
	RewardList = {
		{
			Weight = 0,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 130697,
				},
			},
		},
		{
			Weight = 80,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320001,
					Num = 13,
				},
				{
					Value = 1,
					Num = 18377,
				},
			},
		},
		{
			Weight = 60,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320002,
					Num = 4,
				},
				{
					Value = 1,
					Num = 27017,
				},
			},
		},
		{
			Weight = 40,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320003,
					Num = 1,
				},
				{
					Value = 1,
					Num = 44297,
				},
			},
		},
	},
	DemandID = 410676,
	DemandGroupList = {
		420003,
		420008,
		420009,
	},
}
DemandConfig[DemandID.Id677] =
{
	Id = 677,
	Name = "订购导览图1",
	Desc = "需要一些导览图",
	Value = 321454,
	Active = true,
	Weight = 21021,
	PreGoal = 
	{
		301146,
		301264,
	},
	CloseGoal = 
	{
		301301,
	},
	GoodsId = 6901454,
	Priority = 1454776,
	Num = 12,
	RewardList = {
		{
			Weight = 0,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 130697,
				},
			},
		},
		{
			Weight = 80,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320001,
					Num = 13,
				},
				{
					Value = 1,
					Num = 18377,
				},
			},
		},
		{
			Weight = 60,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320002,
					Num = 4,
				},
				{
					Value = 1,
					Num = 27017,
				},
			},
		},
		{
			Weight = 40,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320003,
					Num = 1,
				},
				{
					Value = 1,
					Num = 44297,
				},
			},
		},
	},
	DemandID = 410677,
	DemandGroupList = {
		420003,
		420008,
		420009,
	},
}
DemandConfig[DemandID.Id678] =
{
	Id = 678,
	Name = "订购导览图1",
	Desc = "需要一些导览图",
	Value = 321454,
	Active = true,
	Weight = 21945,
	PreGoal = 
	{
		301146,
		301280,
	},
	CloseGoal = 
	{
		301322,
	},
	GoodsId = 6901454,
	Priority = 1454777,
	Num = 12,
	RewardList = {
		{
			Weight = 0,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 130697,
				},
			},
		},
		{
			Weight = 80,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320001,
					Num = 13,
				},
				{
					Value = 1,
					Num = 18377,
				},
			},
		},
		{
			Weight = 60,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320002,
					Num = 4,
				},
				{
					Value = 1,
					Num = 27017,
				},
			},
		},
		{
			Weight = 40,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320003,
					Num = 1,
				},
				{
					Value = 1,
					Num = 44297,
				},
			},
		},
	},
	DemandID = 410678,
	DemandGroupList = {
		420003,
		420008,
		420009,
	},
}
DemandConfig[DemandID.Id679] =
{
	Id = 679,
	Name = "订购导览图1",
	Desc = "需要一些导览图",
	Value = 321454,
	Active = true,
	Weight = 23100,
	PreGoal = 
	{
		301146,
		301301,
	},
	CloseGoal = 
	{
		301625,
	},
	GoodsId = 6901454,
	Priority = 1454778,
	Num = 12,
	RewardList = {
		{
			Weight = 0,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 130697,
				},
			},
		},
		{
			Weight = 80,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320001,
					Num = 13,
				},
				{
					Value = 1,
					Num = 18377,
				},
			},
		},
		{
			Weight = 60,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320002,
					Num = 4,
				},
				{
					Value = 1,
					Num = 27017,
				},
			},
		},
		{
			Weight = 40,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320003,
					Num = 1,
				},
				{
					Value = 1,
					Num = 44297,
				},
			},
		},
	},
	DemandID = 410679,
	DemandGroupList = {
		420003,
		420008,
		420009,
	},
}
DemandConfig[DemandID.Id680] =
{
	Id = 680,
	Name = "订购导览图1",
	Desc = "需要一些导览图",
	Value = 321454,
	Active = true,
	Weight = 24255,
	PreGoal = 
	{
		301146,
		301322,
	},
	CloseGoal = 
	{
		301655,
	},
	GoodsId = 6901454,
	Priority = 1454779,
	Num = 12,
	RewardList = {
		{
			Weight = 0,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 130697,
				},
			},
		},
		{
			Weight = 80,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320001,
					Num = 13,
				},
				{
					Value = 1,
					Num = 18377,
				},
			},
		},
		{
			Weight = 60,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320002,
					Num = 4,
				},
				{
					Value = 1,
					Num = 27017,
				},
			},
		},
		{
			Weight = 40,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320003,
					Num = 1,
				},
				{
					Value = 1,
					Num = 44297,
				},
			},
		},
	},
	DemandID = 410680,
	DemandGroupList = {
		420003,
		420008,
		420009,
	},
}
DemandConfig[DemandID.Id681] =
{
	Id = 681,
	Name = "订购导览图1",
	Desc = "需要一些导览图",
	Value = 321454,
	Active = true,
	Weight = 25641,
	PreGoal = 
	{
		301146,
		301630,
	},
	CloseGoal = 
	{
		301685,
	},
	GoodsId = 6901454,
	Priority = 1454780,
	Num = 12,
	RewardList = {
		{
			Weight = 0,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 130697,
				},
			},
		},
		{
			Weight = 80,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320001,
					Num = 13,
				},
				{
					Value = 1,
					Num = 18377,
				},
			},
		},
		{
			Weight = 60,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320002,
					Num = 4,
				},
				{
					Value = 1,
					Num = 27017,
				},
			},
		},
		{
			Weight = 40,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320003,
					Num = 1,
				},
				{
					Value = 1,
					Num = 44297,
				},
			},
		},
	},
	DemandID = 410681,
	DemandGroupList = {
		420003,
		420008,
		420009,
	},
}
DemandConfig[DemandID.Id682] =
{
	Id = 682,
	Name = "订购暗恋1",
	Desc = "需要一些暗恋",
	Value = 321601,
	Active = true,
	Weight = 30420,
	PreGoal = 
	{
		301208,
		301204,
	},
	CloseGoal = 
	{
		301240,
	},
	GoodsId = 7001601,
	Priority = 1601781,
	Num = 27,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 34496,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 293,
				},
				{
					Value = 1,
					Num = 5196,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 293,
				},
				{
					Value = 1,
					Num = 5196,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 58,
				},
				{
					Value = 1,
					Num = 5496,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 58,
				},
				{
					Value = 1,
					Num = 5496,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 11,
				},
				{
					Value = 1,
					Num = 6996,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 11,
				},
				{
					Value = 1,
					Num = 6996,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 2,
				},
				{
					Value = 1,
					Num = 9496,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 2,
				},
				{
					Value = 1,
					Num = 9496,
				},
			},
		},
	},
	DemandID = 410682,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id683] =
{
	Id = 683,
	Name = "订购暗恋1",
	Desc = "需要一些暗恋",
	Value = 321601,
	Active = true,
	Weight = 31200,
	PreGoal = 
	{
		301208,
		301220,
	},
	CloseGoal = 
	{
		301248,
	},
	GoodsId = 7001601,
	Priority = 1601782,
	Num = 28,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 35773,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 304,
				},
				{
					Value = 1,
					Num = 5373,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 304,
				},
				{
					Value = 1,
					Num = 5373,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 60,
				},
				{
					Value = 1,
					Num = 5773,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 60,
				},
				{
					Value = 1,
					Num = 5773,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 12,
				},
				{
					Value = 1,
					Num = 5773,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 12,
				},
				{
					Value = 1,
					Num = 5773,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 2,
				},
				{
					Value = 1,
					Num = 10773,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 2,
				},
				{
					Value = 1,
					Num = 10773,
				},
			},
		},
	},
	DemandID = 410683,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id684] =
{
	Id = 684,
	Name = "订购暗恋1",
	Desc = "需要一些暗恋",
	Value = 321601,
	Active = true,
	Weight = 31980,
	PreGoal = 
	{
		301208,
		301228,
	},
	CloseGoal = 
	{
		301260,
	},
	GoodsId = 7001601,
	Priority = 1601783,
	Num = 30,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 38329,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 325,
				},
				{
					Value = 1,
					Num = 5829,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 325,
				},
				{
					Value = 1,
					Num = 5829,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 65,
				},
				{
					Value = 1,
					Num = 5829,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 65,
				},
				{
					Value = 1,
					Num = 5829,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 13,
				},
				{
					Value = 1,
					Num = 5829,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 13,
				},
				{
					Value = 1,
					Num = 5829,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 2,
				},
				{
					Value = 1,
					Num = 13329,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 2,
				},
				{
					Value = 1,
					Num = 13329,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 229,
				},
				{
					Value = 320051,
					Num = 154,
				},
			},
		},
	},
	DemandID = 410684,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id685] =
{
	Id = 685,
	Name = "订购暗恋1",
	Desc = "需要一些暗恋",
	Value = 321601,
	Active = true,
	Weight = 33150,
	PreGoal = 
	{
		301208,
		301240,
	},
	CloseGoal = 
	{
		301272,
	},
	GoodsId = 7001601,
	Priority = 1601784,
	Num = 32,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 40884,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 347,
				},
				{
					Value = 1,
					Num = 6184,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 347,
				},
				{
					Value = 1,
					Num = 6184,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 69,
				},
				{
					Value = 1,
					Num = 6384,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 69,
				},
				{
					Value = 1,
					Num = 6384,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 13,
				},
				{
					Value = 1,
					Num = 8384,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 13,
				},
				{
					Value = 1,
					Num = 8384,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 2,
				},
				{
					Value = 1,
					Num = 15884,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 2,
				},
				{
					Value = 1,
					Num = 15884,
				},
			},
		},
	},
	DemandID = 410685,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id686] =
{
	Id = 686,
	Name = "订购暗恋1",
	Desc = "需要一些暗恋",
	Value = 321601,
	Active = true,
	Weight = 34320,
	PreGoal = 
	{
		301208,
		301252,
	},
	CloseGoal = 
	{
		301288,
	},
	GoodsId = 7001601,
	Priority = 1601785,
	Num = 33,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 42162,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 358,
				},
				{
					Value = 1,
					Num = 6362,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 358,
				},
				{
					Value = 1,
					Num = 6362,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 71,
				},
				{
					Value = 1,
					Num = 6662,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 71,
				},
				{
					Value = 1,
					Num = 6662,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 14,
				},
				{
					Value = 1,
					Num = 7162,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 14,
				},
				{
					Value = 1,
					Num = 7162,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 2,
				},
				{
					Value = 1,
					Num = 17162,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 2,
				},
				{
					Value = 1,
					Num = 17162,
				},
			},
		},
	},
	DemandID = 410686,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id687] =
{
	Id = 687,
	Name = "订购暗恋1",
	Desc = "需要一些暗恋",
	Value = 321601,
	Active = true,
	Weight = 35880,
	PreGoal = 
	{
		301208,
		301268,
	},
	CloseGoal = 
	{
		301306,
	},
	GoodsId = 7001601,
	Priority = 1601786,
	Num = 33,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 42162,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 358,
				},
				{
					Value = 1,
					Num = 6362,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 358,
				},
				{
					Value = 1,
					Num = 6362,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 71,
				},
				{
					Value = 1,
					Num = 6662,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 71,
				},
				{
					Value = 1,
					Num = 6662,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 14,
				},
				{
					Value = 1,
					Num = 7162,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 14,
				},
				{
					Value = 1,
					Num = 7162,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 2,
				},
				{
					Value = 1,
					Num = 17162,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 2,
				},
				{
					Value = 1,
					Num = 17162,
				},
			},
		},
	},
	DemandID = 410687,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id688] =
{
	Id = 688,
	Name = "订购暗恋1",
	Desc = "需要一些暗恋",
	Value = 321601,
	Active = true,
	Weight = 37440,
	PreGoal = 
	{
		301208,
		301284,
	},
	CloseGoal = 
	{
		301327,
	},
	GoodsId = 7001601,
	Priority = 1601787,
	Num = 33,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 42162,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 358,
				},
				{
					Value = 1,
					Num = 6362,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 358,
				},
				{
					Value = 1,
					Num = 6362,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 71,
				},
				{
					Value = 1,
					Num = 6662,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 71,
				},
				{
					Value = 1,
					Num = 6662,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 14,
				},
				{
					Value = 1,
					Num = 7162,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 14,
				},
				{
					Value = 1,
					Num = 7162,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 2,
				},
				{
					Value = 1,
					Num = 17162,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 2,
				},
				{
					Value = 1,
					Num = 17162,
				},
			},
		},
	},
	DemandID = 410688,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id689] =
{
	Id = 689,
	Name = "订购暗恋1",
	Desc = "需要一些暗恋",
	Value = 321601,
	Active = true,
	Weight = 39390,
	PreGoal = 
	{
		301208,
		301306,
	},
	CloseGoal = 
	{
		301630,
	},
	GoodsId = 7001601,
	Priority = 1601788,
	Num = 33,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 42162,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 358,
				},
				{
					Value = 1,
					Num = 6362,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 358,
				},
				{
					Value = 1,
					Num = 6362,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 71,
				},
				{
					Value = 1,
					Num = 6662,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 71,
				},
				{
					Value = 1,
					Num = 6662,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 14,
				},
				{
					Value = 1,
					Num = 7162,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 14,
				},
				{
					Value = 1,
					Num = 7162,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 2,
				},
				{
					Value = 1,
					Num = 17162,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 2,
				},
				{
					Value = 1,
					Num = 17162,
				},
			},
		},
	},
	DemandID = 410689,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id690] =
{
	Id = 690,
	Name = "订购暗恋1",
	Desc = "需要一些暗恋",
	Value = 321601,
	Active = true,
	Weight = 41340,
	PreGoal = 
	{
		301208,
		301327,
	},
	CloseGoal = 
	{
		301660,
	},
	GoodsId = 7001601,
	Priority = 1601789,
	Num = 33,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 42162,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 358,
				},
				{
					Value = 1,
					Num = 6362,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 358,
				},
				{
					Value = 1,
					Num = 6362,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 71,
				},
				{
					Value = 1,
					Num = 6662,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 71,
				},
				{
					Value = 1,
					Num = 6662,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 14,
				},
				{
					Value = 1,
					Num = 7162,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 14,
				},
				{
					Value = 1,
					Num = 7162,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 2,
				},
				{
					Value = 1,
					Num = 17162,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 2,
				},
				{
					Value = 1,
					Num = 17162,
				},
			},
		},
	},
	DemandID = 410690,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id691] =
{
	Id = 691,
	Name = "订购暗恋1",
	Desc = "需要一些暗恋",
	Value = 321601,
	Active = true,
	Weight = 43680,
	PreGoal = 
	{
		301208,
		301635,
	},
	CloseGoal = 
	{
		301690,
	},
	GoodsId = 7001601,
	Priority = 1601790,
	Num = 33,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 42162,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 358,
				},
				{
					Value = 1,
					Num = 6362,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 358,
				},
				{
					Value = 1,
					Num = 6362,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 71,
				},
				{
					Value = 1,
					Num = 6662,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 71,
				},
				{
					Value = 1,
					Num = 6662,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 14,
				},
				{
					Value = 1,
					Num = 7162,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 14,
				},
				{
					Value = 1,
					Num = 7162,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 2,
				},
				{
					Value = 1,
					Num = 17162,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 2,
				},
				{
					Value = 1,
					Num = 17162,
				},
			},
		},
	},
	DemandID = 410691,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id692] =
{
	Id = 692,
	Name = "订购新闻1",
	Desc = "需要一些新闻",
	Value = 321602,
	Active = true,
	Weight = 32000,
	PreGoal = 
	{
		301505,
		301220,
	},
	CloseGoal = 
	{
		301248,
	},
	GoodsId = 7101602,
	Priority = 1602801,
	Num = 25,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 37352,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 317,
				},
				{
					Value = 1,
					Num = 5652,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 317,
				},
				{
					Value = 1,
					Num = 5652,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 63,
				},
				{
					Value = 1,
					Num = 5852,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 63,
				},
				{
					Value = 1,
					Num = 5852,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 12,
				},
				{
					Value = 1,
					Num = 7352,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 12,
				},
				{
					Value = 1,
					Num = 7352,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 2,
				},
				{
					Value = 1,
					Num = 12352,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 2,
				},
				{
					Value = 1,
					Num = 12352,
				},
			},
		},
	},
	DemandID = 410692,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id693] =
{
	Id = 693,
	Name = "订购新闻1",
	Desc = "需要一些新闻",
	Value = 321602,
	Active = true,
	Weight = 32800,
	PreGoal = 
	{
		301505,
		301228,
	},
	CloseGoal = 
	{
		301256,
	},
	GoodsId = 7101602,
	Priority = 1602802,
	Num = 26,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 38846,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 330,
				},
				{
					Value = 1,
					Num = 5846,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 330,
				},
				{
					Value = 1,
					Num = 5846,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 66,
				},
				{
					Value = 1,
					Num = 5846,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 66,
				},
				{
					Value = 1,
					Num = 5846,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 13,
				},
				{
					Value = 1,
					Num = 6346,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 13,
				},
				{
					Value = 1,
					Num = 6346,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 2,
				},
				{
					Value = 1,
					Num = 13846,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 2,
				},
				{
					Value = 1,
					Num = 13846,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 233,
				},
				{
					Value = 320051,
					Num = 155,
				},
			},
		},
	},
	DemandID = 410693,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id694] =
{
	Id = 694,
	Name = "订购新闻1",
	Desc = "需要一些新闻",
	Value = 321602,
	Active = true,
	Weight = 33600,
	PreGoal = 
	{
		301505,
		301236,
	},
	CloseGoal = 
	{
		301268,
	},
	GoodsId = 7101602,
	Priority = 1602803,
	Num = 27,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 40340,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 342,
				},
				{
					Value = 1,
					Num = 6140,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 342,
				},
				{
					Value = 1,
					Num = 6140,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 68,
				},
				{
					Value = 1,
					Num = 6340,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 68,
				},
				{
					Value = 1,
					Num = 6340,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 13,
				},
				{
					Value = 1,
					Num = 7840,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 13,
				},
				{
					Value = 1,
					Num = 7840,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 2,
				},
				{
					Value = 1,
					Num = 15340,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 2,
				},
				{
					Value = 1,
					Num = 15340,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 242,
				},
				{
					Value = 320051,
					Num = 161,
				},
			},
		},
	},
	DemandID = 410694,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id695] =
{
	Id = 695,
	Name = "订购新闻1",
	Desc = "需要一些新闻",
	Value = 321602,
	Active = true,
	Weight = 34800,
	PreGoal = 
	{
		301505,
		301248,
	},
	CloseGoal = 
	{
		301280,
	},
	GoodsId = 7101602,
	Priority = 1602804,
	Num = 28,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 41834,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 355,
				},
				{
					Value = 1,
					Num = 6334,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 355,
				},
				{
					Value = 1,
					Num = 6334,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 71,
				},
				{
					Value = 1,
					Num = 6334,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 71,
				},
				{
					Value = 1,
					Num = 6334,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 14,
				},
				{
					Value = 1,
					Num = 6834,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 14,
				},
				{
					Value = 1,
					Num = 6834,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 2,
				},
				{
					Value = 1,
					Num = 16834,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 2,
				},
				{
					Value = 1,
					Num = 16834,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 251,
				},
				{
					Value = 320051,
					Num = 167,
				},
			},
		},
	},
	DemandID = 410695,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id696] =
{
	Id = 696,
	Name = "订购新闻1",
	Desc = "需要一些新闻",
	Value = 321602,
	Active = true,
	Weight = 36000,
	PreGoal = 
	{
		301505,
		301260,
	},
	CloseGoal = 
	{
		301297,
	},
	GoodsId = 7101602,
	Priority = 1602805,
	Num = 28,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 41834,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 355,
				},
				{
					Value = 1,
					Num = 6334,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 355,
				},
				{
					Value = 1,
					Num = 6334,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 71,
				},
				{
					Value = 1,
					Num = 6334,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 71,
				},
				{
					Value = 1,
					Num = 6334,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 14,
				},
				{
					Value = 1,
					Num = 6834,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 14,
				},
				{
					Value = 1,
					Num = 6834,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 2,
				},
				{
					Value = 1,
					Num = 16834,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 2,
				},
				{
					Value = 1,
					Num = 16834,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 251,
				},
				{
					Value = 320051,
					Num = 167,
				},
			},
		},
	},
	DemandID = 410696,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id697] =
{
	Id = 697,
	Name = "订购新闻1",
	Desc = "需要一些新闻",
	Value = 321602,
	Active = true,
	Weight = 37600,
	PreGoal = 
	{
		301505,
		301276,
	},
	CloseGoal = 
	{
		301314,
	},
	GoodsId = 7101602,
	Priority = 1602806,
	Num = 28,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 41834,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 355,
				},
				{
					Value = 1,
					Num = 6334,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 355,
				},
				{
					Value = 1,
					Num = 6334,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 71,
				},
				{
					Value = 1,
					Num = 6334,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 71,
				},
				{
					Value = 1,
					Num = 6334,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 14,
				},
				{
					Value = 1,
					Num = 6834,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 14,
				},
				{
					Value = 1,
					Num = 6834,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 2,
				},
				{
					Value = 1,
					Num = 16834,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 2,
				},
				{
					Value = 1,
					Num = 16834,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 251,
				},
				{
					Value = 320051,
					Num = 167,
				},
			},
		},
	},
	DemandID = 410697,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id698] =
{
	Id = 698,
	Name = "订购新闻1",
	Desc = "需要一些新闻",
	Value = 321602,
	Active = true,
	Weight = 39200,
	PreGoal = 
	{
		301505,
		301292,
	},
	CloseGoal = 
	{
		301615,
	},
	GoodsId = 7101602,
	Priority = 1602807,
	Num = 28,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 41834,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 355,
				},
				{
					Value = 1,
					Num = 6334,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 355,
				},
				{
					Value = 1,
					Num = 6334,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 71,
				},
				{
					Value = 1,
					Num = 6334,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 71,
				},
				{
					Value = 1,
					Num = 6334,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 14,
				},
				{
					Value = 1,
					Num = 6834,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 14,
				},
				{
					Value = 1,
					Num = 6834,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 2,
				},
				{
					Value = 1,
					Num = 16834,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 2,
				},
				{
					Value = 1,
					Num = 16834,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 251,
				},
				{
					Value = 320051,
					Num = 167,
				},
			},
		},
	},
	DemandID = 410698,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id699] =
{
	Id = 699,
	Name = "订购新闻1",
	Desc = "需要一些新闻",
	Value = 321602,
	Active = true,
	Weight = 41200,
	PreGoal = 
	{
		301505,
		301314,
	},
	CloseGoal = 
	{
		301640,
	},
	GoodsId = 7101602,
	Priority = 1602808,
	Num = 28,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 41834,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 355,
				},
				{
					Value = 1,
					Num = 6334,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 355,
				},
				{
					Value = 1,
					Num = 6334,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 71,
				},
				{
					Value = 1,
					Num = 6334,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 71,
				},
				{
					Value = 1,
					Num = 6334,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 14,
				},
				{
					Value = 1,
					Num = 6834,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 14,
				},
				{
					Value = 1,
					Num = 6834,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 2,
				},
				{
					Value = 1,
					Num = 16834,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 2,
				},
				{
					Value = 1,
					Num = 16834,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 251,
				},
				{
					Value = 320051,
					Num = 167,
				},
			},
		},
	},
	DemandID = 410699,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id700] =
{
	Id = 700,
	Name = "订购新闻1",
	Desc = "需要一些新闻",
	Value = 321602,
	Active = true,
	Weight = 43200,
	PreGoal = 
	{
		301505,
		301615,
	},
	CloseGoal = 
	{
		301670,
	},
	GoodsId = 7101602,
	Priority = 1602809,
	Num = 28,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 41834,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 355,
				},
				{
					Value = 1,
					Num = 6334,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 355,
				},
				{
					Value = 1,
					Num = 6334,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 71,
				},
				{
					Value = 1,
					Num = 6334,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 71,
				},
				{
					Value = 1,
					Num = 6334,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 14,
				},
				{
					Value = 1,
					Num = 6834,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 14,
				},
				{
					Value = 1,
					Num = 6834,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 2,
				},
				{
					Value = 1,
					Num = 16834,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 2,
				},
				{
					Value = 1,
					Num = 16834,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 251,
				},
				{
					Value = 320051,
					Num = 167,
				},
			},
		},
	},
	DemandID = 410700,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
