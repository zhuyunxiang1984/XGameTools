HomeAchievementConfig ={};
HomeAchievementID = 
{
	Id001 = 1,
	Id002 = 2,
	Id003 = 3,
	Id004 = 4,
	Id005 = 5,
	Id006 = 6,
	Id007 = 7,
	Id008 = 8,
}
HomeAchievementConfig[HomeAchievementID.Id001] =
{
	Id = 1,
	Name = "家园成就1",
	IconInProgress = "MissionIconExplore",
	IconComplete = "MissionIconPlanet",
	GoalList = {
		309801,
		309802,
		309803,
		309804,
		309805,
	},
}
HomeAchievementConfig[HomeAchievementID.Id002] =
{
	Id = 2,
	Name = "家园成就2",
	IconInProgress = "MissionIconExplore",
	IconComplete = "MissionIconPlanet",
	GoalList = {
		309806,
		309807,
		309808,
	},
}
HomeAchievementConfig[HomeAchievementID.Id003] =
{
	Id = 3,
	Name = "家园成就3",
	IconInProgress = "MissionIconExplore",
	IconComplete = "MissionIconPlanet",
	GoalList = {
		309809,
		309810,
		309811,
	},
}
HomeAchievementConfig[HomeAchievementID.Id004] =
{
	Id = 4,
	Name = "家园成就4",
	IconInProgress = "MissionIconExplore",
	IconComplete = "MissionIconPlanet",
	GoalList = {
		309812,
	},
}
HomeAchievementConfig[HomeAchievementID.Id005] =
{
	Id = 5,
	Name = "家园成就5",
	IconInProgress = "MissionIconExplore",
	IconComplete = "MissionIconPlanet",
	GoalList = {
		309813,
		309814,
		309815,
	},
}
HomeAchievementConfig[HomeAchievementID.Id006] =
{
	Id = 6,
	Name = "家园成就6",
	IconInProgress = "MissionIconExplore",
	IconComplete = "MissionIconPlanet",
	GoalList = {
		309816,
		309817,
		309818,
	},
}
HomeAchievementConfig[HomeAchievementID.Id007] =
{
	Id = 7,
	Name = "家园成就7",
	IconInProgress = "MissionIconExplore",
	IconComplete = "MissionIconPlanet",
	GoalList = {
		309819,
		309820,
	},
}
HomeAchievementConfig[HomeAchievementID.Id008] =
{
	Id = 8,
	Name = "家园成就8",
	IconInProgress = "MissionIconExplore",
	IconComplete = "MissionIconPlanet",
	GoalList = {
		309821,
		309822,
		309823,
	},
}

