
AreaConfig[AreaID.Id201] =
{
	Id = 201,
	Name = "坠落点",
	Planet = 120005,
	Level = 137,
	AreaElement = 210003,
	NumCap = 5,
	Map = "SEA_map_01",
	LevelIcon = "Icon_SEABG01",
	LevelBG = "SEABG01",
	LevelAtlas = "EventBG",
	LevelBundle = "packed_eventbg",
	StartScene = "SEA_StartScene",
	LevelEnemy = {
		{
			NeedChallenge = 140802,
			Enemy = {
				{
					Value = 242119,
					Level = 268,
					Weight = 1000,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 100,
					FightPower = 17500,
					NeedElementList = {
						{
							Element = 210003,
							Count = 1,
						},
					},
				},
			},
		},
		{
			NeedChallenge = 140801,
			Enemy = {
				{
					Value = 242119,
					Level = 268,
					Weight = 1000,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 100,
					FightPower = 17500,
					NeedElementList = {
						{
							Element = 210003,
							Count = 1,
						},
					},
				},
			},
		},
		{
			Enemy = {
				{
					Value = 242119,
					Level = 268,
					Weight = 1000,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 200,
					FightPower = 17500,
					NeedElementList = {
						{
							Element = 210003,
							Count = 1,
						},
					},
				},
			},
		},
	},
	Challenge = {
		140801,
		140802,
	},
}
AreaConfig[AreaID.Id202] =
{
	Id = 202,
	Name = "音乐广场",
	Planet = 120005,
	Level = 137,
	AreaElement = 210001,
	NumCap = 5,
	Map = "SEA_map_02",
	LevelIcon = "Icon_SEABG02",
	LevelBG = "SEABG02",
	LevelAtlas = "EventBG",
	LevelBundle = "packed_eventbg",
	StartScene = "SEA_StartScene",
	LevelEnemy = {
		{
			NeedChallenge = 140804,
			Enemy = {
				{
					Value = 242119,
					Level = 268,
					Weight = 294,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 100,
					FightPower = 17500,
					NeedElementList = {
						{
							Element = 210003,
							Count = 1,
						},
					},
				},
				{
					Value = 242121,
					Level = 276,
					Weight = 352,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 240,
					FightPower = 22500,
					NeedElementList = {
						{
							Element = 210001,
							Count = 1,
						},
						{
							Element = 210002,
							Count = 1,
						},
					},
				},
				{
					Value = 242120,
					Level = 280,
					Weight = 352,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 240,
					FightPower = 22800,
					NeedElementList = {
						{
							Element = 210001,
							Count = 1,
						},
						{
							Element = 210003,
							Count = 1,
						},
					},
				},
			},
		},
		{
			NeedChallenge = 140803,
			Enemy = {
				{
					Value = 242119,
					Level = 268,
					Weight = 294,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 100,
					FightPower = 17500,
					NeedElementList = {
						{
							Element = 210003,
							Count = 1,
						},
					},
				},
				{
					Value = 242121,
					Level = 276,
					Weight = 352,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 240,
					FightPower = 22500,
					NeedElementList = {
						{
							Element = 210001,
							Count = 1,
						},
						{
							Element = 210002,
							Count = 1,
						},
					},
				},
			},
		},
		{
			Enemy = {
				{
					Value = 242119,
					Level = 268,
					Weight = 294,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 100,
					FightPower = 17500,
					NeedElementList = {
						{
							Element = 210003,
							Count = 1,
						},
					},
				},
			},
		},
	},
	Challenge = {
		140803,
		140804,
	},
	EventList = {
		310801,
		310802,
		310803,
		310804,
		310805,
	},
}
AreaConfig[AreaID.Id203] =
{
	Id = 203,
	Name = "浅海沙滩",
	Planet = 120005,
	Level = 139,
	AreaElement = 210003,
	NumCap = 5,
	Map = "SEA_map_03",
	LevelIcon = "Icon_SEABG03",
	LevelBG = "SEABG03",
	LevelAtlas = "EventBG",
	LevelBundle = "packed_eventbg",
	StartScene = "SEA_StartScene",
	LevelEnemy = {
		{
			NeedChallenge = 140806,
			Enemy = {
				{
					Value = 242119,
					Level = 268,
					Weight = 192,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 100,
					FightPower = 17500,
					NeedElementList = {
						{
							Element = 210003,
							Count = 1,
						},
					},
				},
				{
					Value = 242121,
					Level = 276,
					Weight = 230,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 240,
					FightPower = 22500,
					NeedElementList = {
						{
							Element = 210001,
							Count = 1,
						},
						{
							Element = 210002,
							Count = 1,
						},
					},
				},
				{
					Value = 242122,
					Level = 284,
					Weight = 230,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 240,
					FightPower = 23100,
					NeedElementList = {
						{
							Element = 210001,
							Count = 1,
						},
						{
							Element = 210002,
							Count = 1,
						},
					},
				},
				{
					Value = 242123,
					Level = 288,
					Weight = 346,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 900,
					FightPower = 26900,
					NeedElementList = {
						{
							Element = 210004,
							Count = 1,
						},
						{
							Element = 210005,
							Count = 1,
						},
					},
				},
			},
		},
		{
			NeedChallenge = 140805,
			Enemy = {
				{
					Value = 242119,
					Level = 268,
					Weight = 192,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 100,
					FightPower = 17500,
					NeedElementList = {
						{
							Element = 210003,
							Count = 1,
						},
					},
				},
				{
					Value = 242121,
					Level = 276,
					Weight = 230,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 240,
					FightPower = 22500,
					NeedElementList = {
						{
							Element = 210001,
							Count = 1,
						},
						{
							Element = 210002,
							Count = 1,
						},
					},
				},
				{
					Value = 242122,
					Level = 284,
					Weight = 230,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 240,
					FightPower = 23100,
					NeedElementList = {
						{
							Element = 210001,
							Count = 1,
						},
						{
							Element = 210002,
							Count = 1,
						},
					},
				},
			},
		},
		{
			Enemy = {
				{
					Value = 242119,
					Level = 268,
					Weight = 192,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 100,
					FightPower = 17500,
					NeedElementList = {
						{
							Element = 210003,
							Count = 1,
						},
					},
				},
				{
					Value = 242121,
					Level = 276,
					Weight = 230,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 240,
					FightPower = 22500,
					NeedElementList = {
						{
							Element = 210001,
							Count = 1,
						},
						{
							Element = 210002,
							Count = 1,
						},
					},
				},
			},
		},
	},
	Challenge = {
		140805,
		140806,
	},
	EventList = {
		310806,
		310807,
		310808,
		310809,
		310810,
		310811,
	},
}
AreaConfig[AreaID.Id204] =
{
	Id = 204,
	Name = "休息厅",
	Planet = 120005,
	Level = 149,
	AreaElement = 210003,
	NumCap = 5,
	Map = "SEA_map_04",
	LevelIcon = "Icon_SEABG03",
	LevelBG = "SEABG03",
	LevelAtlas = "EventBG",
	LevelBundle = "packed_eventbg",
	StartScene = "SEA_StartScene",
	LevelEnemy = {
		{
			NeedChallenge = 140809,
			Enemy = {
				{
					Value = 242121,
					Level = 268,
					Weight = 243,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 240,
					FightPower = 22500,
					NeedElementList = {
						{
							Element = 210001,
							Count = 1,
						},
						{
							Element = 210002,
							Count = 1,
						},
					},
				},
				{
					Value = 242124,
					Level = 292,
					Weight = 243,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 240,
					FightPower = 23800,
					NeedElementList = {
						{
							Element = 210001,
							Count = 3,
						},
					},
				},
				{
					Value = 242125,
					Level = 312,
					Weight = 512,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 3600,
					FightPower = 33000,
					NeedElementList = {
						{
							Element = 210001,
							Count = 3,
						},
					},
				},
			},
		},
		{
			NeedChallenge = 140808,
			Enemy = {
				{
					Value = 242121,
					Level = 268,
					Weight = 243,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 240,
					FightPower = 22500,
					NeedElementList = {
						{
							Element = 210001,
							Count = 1,
						},
						{
							Element = 210002,
							Count = 1,
						},
					},
				},
				{
					Value = 242124,
					Level = 292,
					Weight = 243,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 240,
					FightPower = 23800,
					NeedElementList = {
						{
							Element = 210001,
							Count = 3,
						},
					},
				},
				{
					Value = 242125,
					Level = 312,
					Weight = 512,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 3600,
					FightPower = 33000,
					NeedElementList = {
						{
							Element = 210001,
							Count = 3,
						},
					},
				},
			},
		},
		{
			NeedChallenge = 140807,
			Enemy = {
				{
					Value = 242121,
					Level = 268,
					Weight = 243,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 240,
					FightPower = 22500,
					NeedElementList = {
						{
							Element = 210001,
							Count = 1,
						},
						{
							Element = 210002,
							Count = 1,
						},
					},
				},
				{
					Value = 242124,
					Level = 292,
					Weight = 243,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 240,
					FightPower = 23800,
					NeedElementList = {
						{
							Element = 210001,
							Count = 3,
						},
					},
				},
			},
		},
		{
			Enemy = {
				{
					Value = 242121,
					Level = 268,
					Weight = 243,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 240,
					FightPower = 22500,
					NeedElementList = {
						{
							Element = 210001,
							Count = 1,
						},
						{
							Element = 210002,
							Count = 1,
						},
					},
				},
			},
		},
	},
	Challenge = {
		140807,
		140808,
		140809,
	},
	EventList = {
		310812,
		310813,
		310814,
		310815,
		310816,
	},
}
AreaConfig[AreaID.Id205] =
{
	Id = 205,
	Name = "回溯镇",
	Planet = 120005,
	Level = 145,
	AreaElement = 210003,
	NumCap = 5,
	Map = "SEA_map_05",
	LevelIcon = "Icon_SEABG03",
	LevelBG = "SEABG03",
	LevelAtlas = "EventBG",
	LevelBundle = "packed_eventbg",
	StartScene = "SEA_StartScene",
	LevelEnemy = {
		{
			NeedChallenge = 140813,
			Enemy = {
				{
					Value = 242119,
					Level = 268,
					Weight = 161,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 100,
					FightPower = 17500,
					NeedElementList = {
						{
							Element = 210003,
							Count = 1,
						},
					},
				},
				{
					Value = 242120,
					Level = 276,
					Weight = 193,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 240,
					FightPower = 22800,
					NeedElementList = {
						{
							Element = 210001,
							Count = 1,
						},
						{
							Element = 210003,
							Count = 1,
						},
					},
				},
				{
					Value = 242126,
					Level = 292,
					Weight = 161,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 100,
					FightPower = 19000,
					NeedElementList = {
						{
							Element = 210002,
							Count = 1,
						},
						{
							Element = 210003,
							Count = 1,
						},
					},
				},
				{
					Value = 242127,
					Level = 296,
					Weight = 193,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 240,
					FightPower = 24100,
					NeedElementList = {
						{
							Element = 210001,
							Count = 2,
						},
					},
				},
				{
					Value = 242128,
					Level = 300,
					Weight = 290,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 900,
					FightPower = 28000,
					NeedElementList = {
						{
							Element = 210001,
							Count = 1,
						},
						{
							Element = 210002,
							Count = 2,
						},
					},
				},
			},
		},
		{
			NeedChallenge = 140812,
			Enemy = {
				{
					Value = 242119,
					Level = 268,
					Weight = 161,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 100,
					FightPower = 17500,
					NeedElementList = {
						{
							Element = 210003,
							Count = 1,
						},
					},
				},
				{
					Value = 242120,
					Level = 276,
					Weight = 193,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 240,
					FightPower = 22800,
					NeedElementList = {
						{
							Element = 210001,
							Count = 1,
						},
						{
							Element = 210003,
							Count = 1,
						},
					},
				},
				{
					Value = 242126,
					Level = 292,
					Weight = 161,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 100,
					FightPower = 19000,
					NeedElementList = {
						{
							Element = 210002,
							Count = 1,
						},
						{
							Element = 210003,
							Count = 1,
						},
					},
				},
				{
					Value = 242127,
					Level = 296,
					Weight = 193,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 240,
					FightPower = 24100,
					NeedElementList = {
						{
							Element = 210001,
							Count = 2,
						},
					},
				},
				{
					Value = 242128,
					Level = 300,
					Weight = 290,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 900,
					FightPower = 28000,
					NeedElementList = {
						{
							Element = 210001,
							Count = 1,
						},
						{
							Element = 210002,
							Count = 2,
						},
					},
				},
			},
		},
		{
			NeedChallenge = 140811,
			Enemy = {
				{
					Value = 242119,
					Level = 268,
					Weight = 161,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 100,
					FightPower = 17500,
					NeedElementList = {
						{
							Element = 210003,
							Count = 1,
						},
					},
				},
				{
					Value = 242120,
					Level = 276,
					Weight = 193,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 240,
					FightPower = 22800,
					NeedElementList = {
						{
							Element = 210001,
							Count = 1,
						},
						{
							Element = 210003,
							Count = 1,
						},
					},
				},
				{
					Value = 242126,
					Level = 292,
					Weight = 161,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 100,
					FightPower = 19000,
					NeedElementList = {
						{
							Element = 210002,
							Count = 1,
						},
						{
							Element = 210003,
							Count = 1,
						},
					},
				},
				{
					Value = 242127,
					Level = 296,
					Weight = 193,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 240,
					FightPower = 24100,
					NeedElementList = {
						{
							Element = 210001,
							Count = 2,
						},
					},
				},
			},
		},
		{
			NeedChallenge = 140810,
			Enemy = {
				{
					Value = 242119,
					Level = 268,
					Weight = 161,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 100,
					FightPower = 17500,
					NeedElementList = {
						{
							Element = 210003,
							Count = 1,
						},
					},
				},
				{
					Value = 242120,
					Level = 276,
					Weight = 193,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 240,
					FightPower = 22800,
					NeedElementList = {
						{
							Element = 210001,
							Count = 1,
						},
						{
							Element = 210003,
							Count = 1,
						},
					},
				},
				{
					Value = 242126,
					Level = 292,
					Weight = 161,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 100,
					FightPower = 19000,
					NeedElementList = {
						{
							Element = 210002,
							Count = 1,
						},
						{
							Element = 210003,
							Count = 1,
						},
					},
				},
			},
		},
		{
			Enemy = {
				{
					Value = 242119,
					Level = 268,
					Weight = 161,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 100,
					FightPower = 17500,
					NeedElementList = {
						{
							Element = 210003,
							Count = 1,
						},
					},
				},
				{
					Value = 242120,
					Level = 276,
					Weight = 193,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 240,
					FightPower = 22800,
					NeedElementList = {
						{
							Element = 210001,
							Count = 1,
						},
						{
							Element = 210003,
							Count = 1,
						},
					},
				},
			},
		},
	},
	Challenge = {
		140810,
		140811,
		140812,
		140813,
	},
	EventList = {
		310817,
		310818,
		310819,
		310820,
		310821,
	},
}
AreaConfig[AreaID.Id206] =
{
	Id = 206,
	Name = "礁石区",
	Planet = 120005,
	Level = 145,
	AreaElement = 210003,
	NumCap = 5,
	Map = "SEA_map_06",
	LevelIcon = "Icon_SEABG03",
	LevelBG = "SEABG03",
	LevelAtlas = "EventBG",
	LevelBundle = "packed_eventbg",
	StartScene = "SEA_StartScene",
	LevelEnemy = {
		{
			NeedChallenge = 140815,
			Enemy = {
				{
					Value = 242119,
					Level = 268,
					Weight = 161,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 100,
					FightPower = 17500,
					NeedElementList = {
						{
							Element = 210003,
							Count = 1,
						},
					},
				},
				{
					Value = 242126,
					Level = 292,
					Weight = 161,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 100,
					FightPower = 19000,
					NeedElementList = {
						{
							Element = 210002,
							Count = 1,
						},
						{
							Element = 210003,
							Count = 1,
						},
					},
				},
				{
					Value = 242122,
					Level = 284,
					Weight = 193,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 240,
					FightPower = 23100,
					NeedElementList = {
						{
							Element = 210001,
							Count = 1,
						},
						{
							Element = 210002,
							Count = 1,
						},
					},
				},
				{
					Value = 242129,
					Level = 304,
					Weight = 193,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 240,
					FightPower = 24700,
					NeedElementList = {
						{
							Element = 210003,
							Count = 2,
						},
					},
				},
				{
					Value = 242130,
					Level = 308,
					Weight = 290,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 900,
					FightPower = 28800,
					NeedElementList = {
						{
							Element = 210001,
							Count = 2,
						},
						{
							Element = 210003,
							Count = 1,
						},
					},
				},
			},
		},
		{
			NeedChallenge = 140814,
			Enemy = {
				{
					Value = 242119,
					Level = 268,
					Weight = 161,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 100,
					FightPower = 17500,
					NeedElementList = {
						{
							Element = 210003,
							Count = 1,
						},
					},
				},
				{
					Value = 242126,
					Level = 292,
					Weight = 161,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 100,
					FightPower = 19000,
					NeedElementList = {
						{
							Element = 210002,
							Count = 1,
						},
						{
							Element = 210003,
							Count = 1,
						},
					},
				},
				{
					Value = 242122,
					Level = 284,
					Weight = 193,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 240,
					FightPower = 23100,
					NeedElementList = {
						{
							Element = 210001,
							Count = 1,
						},
						{
							Element = 210002,
							Count = 1,
						},
					},
				},
				{
					Value = 242129,
					Level = 304,
					Weight = 193,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 240,
					FightPower = 24700,
					NeedElementList = {
						{
							Element = 210003,
							Count = 2,
						},
					},
				},
			},
		},
		{
			Enemy = {
				{
					Value = 242119,
					Level = 268,
					Weight = 161,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 100,
					FightPower = 17500,
					NeedElementList = {
						{
							Element = 210003,
							Count = 1,
						},
					},
				},
				{
					Value = 242126,
					Level = 292,
					Weight = 161,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 100,
					FightPower = 19000,
					NeedElementList = {
						{
							Element = 210002,
							Count = 1,
						},
						{
							Element = 210003,
							Count = 1,
						},
					},
				},
				{
					Value = 242122,
					Level = 284,
					Weight = 193,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 240,
					FightPower = 23100,
					NeedElementList = {
						{
							Element = 210001,
							Count = 1,
						},
						{
							Element = 210002,
							Count = 1,
						},
					},
				},
			},
		},
	},
	Challenge = {
		140814,
		140815,
	},
	EventList = {
		310822,
		310823,
		310824,
		310825,
		310826,
		310827,
	},
}
AreaConfig[AreaID.Id207] =
{
	Id = 207,
	Name = "星光小道",
	Planet = 120005,
	Level = 154,
	AreaElement = 210003,
	NumCap = 5,
	Map = "SEA_map_07",
	LevelIcon = "Icon_SEABG03",
	LevelBG = "SEABG03",
	LevelAtlas = "EventBG",
	LevelBundle = "packed_eventbg",
	StartScene = "SEA_StartScene",
	LevelEnemy = {
		{
			NeedChallenge = 140818,
			Enemy = {
				{
					Value = 242126,
					Level = 292,
					Weight = 113,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 100,
					FightPower = 19000,
					NeedElementList = {
						{
							Element = 210002,
							Count = 1,
						},
						{
							Element = 210003,
							Count = 1,
						},
					},
				},
				{
					Value = 242124,
					Level = 308,
					Weight = 136,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 240,
					FightPower = 23800,
					NeedElementList = {
						{
							Element = 210001,
							Count = 3,
						},
					},
				},
				{
					Value = 242131,
					Level = 312,
					Weight = 136,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 240,
					FightPower = 25400,
					NeedElementList = {
						{
							Element = 210001,
							Count = 1,
						},
						{
							Element = 210003,
							Count = 1,
						},
					},
				},
				{
					Value = 242132,
					Level = 316,
					Weight = 204,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 900,
					FightPower = 29500,
					NeedElementList = {
						{
							Element = 210001,
							Count = 1,
						},
						{
							Element = 210003,
							Count = 1,
						},
					},
				},
				{
					Value = 242133,
					Level = 320,
					Weight = 409,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 3600,
					FightPower = 33800,
					NeedElementList = {
						{
							Element = 210003,
							Count = 1,
						},
						{
							Element = 210004,
							Count = 1,
						},
					},
				},
			},
		},
		{
			NeedChallenge = 140817,
			Enemy = {
				{
					Value = 242126,
					Level = 292,
					Weight = 113,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 100,
					FightPower = 19000,
					NeedElementList = {
						{
							Element = 210002,
							Count = 1,
						},
						{
							Element = 210003,
							Count = 1,
						},
					},
				},
				{
					Value = 242124,
					Level = 308,
					Weight = 136,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 240,
					FightPower = 23800,
					NeedElementList = {
						{
							Element = 210001,
							Count = 3,
						},
					},
				},
				{
					Value = 242131,
					Level = 312,
					Weight = 136,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 240,
					FightPower = 25400,
					NeedElementList = {
						{
							Element = 210001,
							Count = 1,
						},
						{
							Element = 210003,
							Count = 1,
						},
					},
				},
				{
					Value = 242132,
					Level = 316,
					Weight = 204,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 900,
					FightPower = 29500,
					NeedElementList = {
						{
							Element = 210001,
							Count = 1,
						},
						{
							Element = 210003,
							Count = 1,
						},
					},
				},
			},
		},
		{
			NeedChallenge = 140816,
			Enemy = {
				{
					Value = 242126,
					Level = 292,
					Weight = 113,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 100,
					FightPower = 19000,
					NeedElementList = {
						{
							Element = 210002,
							Count = 1,
						},
						{
							Element = 210003,
							Count = 1,
						},
					},
				},
				{
					Value = 242124,
					Level = 308,
					Weight = 136,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 240,
					FightPower = 23800,
					NeedElementList = {
						{
							Element = 210001,
							Count = 3,
						},
					},
				},
				{
					Value = 242131,
					Level = 312,
					Weight = 136,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 240,
					FightPower = 25400,
					NeedElementList = {
						{
							Element = 210001,
							Count = 1,
						},
						{
							Element = 210003,
							Count = 1,
						},
					},
				},
			},
		},
		{
			Enemy = {
				{
					Value = 242126,
					Level = 292,
					Weight = 113,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 100,
					FightPower = 19000,
					NeedElementList = {
						{
							Element = 210002,
							Count = 1,
						},
						{
							Element = 210003,
							Count = 1,
						},
					},
				},
				{
					Value = 242124,
					Level = 308,
					Weight = 136,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 240,
					FightPower = 23800,
					NeedElementList = {
						{
							Element = 210001,
							Count = 3,
						},
					},
				},
			},
		},
	},
	Challenge = {
		140816,
		140817,
		140818,
	},
	EventList = {
		310828,
		310829,
		310830,
		310831,
		310832,
	},
}
AreaConfig[AreaID.Id208] =
{
	Id = 208,
	Name = "深海区",
	Planet = 120005,
	Level = 152,
	AreaElement = 210003,
	NumCap = 5,
	Map = "SEA_map_08",
	LevelIcon = "Icon_SEABG03",
	LevelBG = "SEABG03",
	LevelAtlas = "EventBG",
	LevelBundle = "packed_eventbg",
	StartScene = "SEA_StartScene",
	LevelEnemy = {
		{
			NeedChallenge = 140821,
			Enemy = {
				{
					Value = 242119,
					Level = 268,
					Weight = 108,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 100,
					FightPower = 17500,
					NeedElementList = {
						{
							Element = 210003,
							Count = 1,
						},
					},
				},
				{
					Value = 242129,
					Level = 304,
					Weight = 130,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 240,
					FightPower = 24700,
					NeedElementList = {
						{
							Element = 210003,
							Count = 2,
						},
					},
				},
				{
					Value = 242127,
					Level = 296,
					Weight = 130,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 240,
					FightPower = 24100,
					NeedElementList = {
						{
							Element = 210001,
							Count = 2,
						},
					},
				},
				{
					Value = 242134,
					Level = 306,
					Weight = 162,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 300,
					FightPower = 24900,
					NeedElementList = {
						{
							Element = 210001,
							Count = 2,
						},
					},
				},
				{
					Value = 242135,
					Level = 321,
					Weight = 195,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 900,
					FightPower = 30000,
					NeedElementList = {
						{
							Element = 210001,
							Count = 2,
						},
						{
							Element = 210005,
							Count = 1,
						},
					},
				},
				{
					Value = 242136,
					Level = 336,
					Weight = 273,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 3600,
					FightPower = 35500,
					NeedElementList = {
						{
							Element = 210001,
							Count = 2,
						},
						{
							Element = 210004,
							Count = 1,
						},
					},
				},
			},
		},
		{
			NeedChallenge = 140820,
			Enemy = {
				{
					Value = 242119,
					Level = 268,
					Weight = 108,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 100,
					FightPower = 17500,
					NeedElementList = {
						{
							Element = 210003,
							Count = 1,
						},
					},
				},
				{
					Value = 242129,
					Level = 304,
					Weight = 130,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 240,
					FightPower = 24700,
					NeedElementList = {
						{
							Element = 210003,
							Count = 2,
						},
					},
				},
				{
					Value = 242127,
					Level = 296,
					Weight = 130,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 240,
					FightPower = 24100,
					NeedElementList = {
						{
							Element = 210001,
							Count = 2,
						},
					},
				},
				{
					Value = 242134,
					Level = 306,
					Weight = 162,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 300,
					FightPower = 24900,
					NeedElementList = {
						{
							Element = 210001,
							Count = 2,
						},
					},
				},
				{
					Value = 242135,
					Level = 321,
					Weight = 195,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 900,
					FightPower = 30000,
					NeedElementList = {
						{
							Element = 210001,
							Count = 2,
						},
						{
							Element = 210005,
							Count = 1,
						},
					},
				},
			},
		},
		{
			NeedChallenge = 140819,
			Enemy = {
				{
					Value = 242119,
					Level = 268,
					Weight = 108,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 100,
					FightPower = 17500,
					NeedElementList = {
						{
							Element = 210003,
							Count = 1,
						},
					},
				},
				{
					Value = 242129,
					Level = 304,
					Weight = 130,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 240,
					FightPower = 24700,
					NeedElementList = {
						{
							Element = 210003,
							Count = 2,
						},
					},
				},
				{
					Value = 242127,
					Level = 296,
					Weight = 130,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 240,
					FightPower = 24100,
					NeedElementList = {
						{
							Element = 210001,
							Count = 2,
						},
					},
				},
				{
					Value = 242134,
					Level = 306,
					Weight = 162,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 300,
					FightPower = 24900,
					NeedElementList = {
						{
							Element = 210001,
							Count = 2,
						},
					},
				},
			},
		},
		{
			Enemy = {
				{
					Value = 242119,
					Level = 268,
					Weight = 108,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 100,
					FightPower = 17500,
					NeedElementList = {
						{
							Element = 210003,
							Count = 1,
						},
					},
				},
				{
					Value = 242129,
					Level = 304,
					Weight = 130,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 240,
					FightPower = 24700,
					NeedElementList = {
						{
							Element = 210003,
							Count = 2,
						},
					},
				},
				{
					Value = 242127,
					Level = 296,
					Weight = 130,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 240,
					FightPower = 24100,
					NeedElementList = {
						{
							Element = 210001,
							Count = 2,
						},
					},
				},
			},
		},
	},
	Challenge = {
		140819,
		140820,
		140821,
	},
	EventList = {
		310833,
		310834,
		310835,
		310836,
		310837,
	},
}
AreaConfig[AreaID.Id209] =
{
	Id = 209,
	Name = "演播厅",
	Planet = 120005,
	Level = 159,
	AreaElement = 210003,
	NumCap = 5,
	Map = "SEA_map_09",
	LevelIcon = "Icon_SEABG03",
	LevelBG = "SEABG03",
	LevelAtlas = "EventBG",
	LevelBundle = "packed_eventbg",
	StartScene = "SEA_StartScene",
	LevelEnemy = {
		{
			NeedChallenge = 140824,
			Enemy = {
				{
					Value = 242126,
					Level = 292,
					Weight = 142,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 100,
					FightPower = 19000,
					NeedElementList = {
						{
							Element = 210002,
							Count = 1,
						},
						{
							Element = 210003,
							Count = 1,
						},
					},
				},
				{
					Value = 242131,
					Level = 312,
					Weight = 171,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 240,
					FightPower = 25400,
					NeedElementList = {
						{
							Element = 210001,
							Count = 1,
						},
						{
							Element = 210003,
							Count = 1,
						},
					},
				},
				{
					Value = 242137,
					Level = 324,
					Weight = 171,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 240,
					FightPower = 26300,
					NeedElementList = {
						{
							Element = 210003,
							Count = 2,
						},
						{
							Element = 210004,
							Count = 1,
						},
					},
				},
				{
					Value = 242138,
					Level = 328,
					Weight = 514,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 3600,
					FightPower = 34600,
					NeedElementList = {
						{
							Element = 210003,
							Count = 3,
						},
					},
				},
			},
		},
		{
			NeedChallenge = 140823,
			Enemy = {
				{
					Value = 242126,
					Level = 292,
					Weight = 142,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 100,
					FightPower = 19000,
					NeedElementList = {
						{
							Element = 210002,
							Count = 1,
						},
						{
							Element = 210003,
							Count = 1,
						},
					},
				},
				{
					Value = 242131,
					Level = 312,
					Weight = 171,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 240,
					FightPower = 25400,
					NeedElementList = {
						{
							Element = 210001,
							Count = 1,
						},
						{
							Element = 210003,
							Count = 1,
						},
					},
				},
				{
					Value = 242137,
					Level = 324,
					Weight = 171,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 240,
					FightPower = 26300,
					NeedElementList = {
						{
							Element = 210003,
							Count = 2,
						},
						{
							Element = 210004,
							Count = 1,
						},
					},
				},
				{
					Value = 242138,
					Level = 328,
					Weight = 514,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 3600,
					FightPower = 34600,
					NeedElementList = {
						{
							Element = 210003,
							Count = 3,
						},
					},
				},
			},
		},
		{
			NeedChallenge = 140822,
			Enemy = {
				{
					Value = 242126,
					Level = 292,
					Weight = 142,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 100,
					FightPower = 19000,
					NeedElementList = {
						{
							Element = 210002,
							Count = 1,
						},
						{
							Element = 210003,
							Count = 1,
						},
					},
				},
				{
					Value = 242131,
					Level = 312,
					Weight = 171,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 240,
					FightPower = 25400,
					NeedElementList = {
						{
							Element = 210001,
							Count = 1,
						},
						{
							Element = 210003,
							Count = 1,
						},
					},
				},
				{
					Value = 242137,
					Level = 324,
					Weight = 171,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 240,
					FightPower = 26300,
					NeedElementList = {
						{
							Element = 210003,
							Count = 2,
						},
						{
							Element = 210004,
							Count = 1,
						},
					},
				},
			},
		},
		{
			Enemy = {
				{
					Value = 242126,
					Level = 292,
					Weight = 142,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 100,
					FightPower = 19000,
					NeedElementList = {
						{
							Element = 210002,
							Count = 1,
						},
						{
							Element = 210003,
							Count = 1,
						},
					},
				},
				{
					Value = 242131,
					Level = 312,
					Weight = 171,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 240,
					FightPower = 25400,
					NeedElementList = {
						{
							Element = 210001,
							Count = 1,
						},
						{
							Element = 210003,
							Count = 1,
						},
					},
				},
			},
		},
	},
	Challenge = {
		140822,
		140823,
		140824,
	},
	EventList = {
		310838,
		310839,
		310840,
		310841,
	},
}
AreaConfig[AreaID.Id210] =
{
	Id = 210,
	Name = "面试舞台",
	Planet = 120005,
	Level = 164,
	AreaElement = 210003,
	NumCap = 5,
	Map = "SEA_map_10",
	LevelIcon = "Icon_SEABG03",
	LevelBG = "SEABG03",
	LevelAtlas = "EventBG",
	LevelBundle = "packed_eventbg",
	StartScene = "SEA_StartScene",
	LevelEnemy = {
		{
			NeedChallenge = 140826,
			Enemy = {
				{
					Value = 242126,
					Level = 292,
					Weight = 117,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 100,
					FightPower = 19000,
					NeedElementList = {
						{
							Element = 210002,
							Count = 1,
						},
						{
							Element = 210003,
							Count = 1,
						},
					},
				},
				{
					Value = 242134,
					Level = 328,
					Weight = 176,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 300,
					FightPower = 24900,
					NeedElementList = {
						{
							Element = 210001,
							Count = 2,
						},
					},
				},
				{
					Value = 242137,
					Level = 340,
					Weight = 141,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 240,
					FightPower = 26300,
					NeedElementList = {
						{
							Element = 210003,
							Count = 2,
						},
						{
							Element = 210004,
							Count = 1,
						},
					},
				},
				{
					Value = 242139,
					Level = 340,
					Weight = 141,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 240,
					FightPower = 27600,
					NeedElementList = {
						{
							Element = 210001,
							Count = 1,
						},
						{
							Element = 210004,
							Count = 1,
						},
					},
				},
				{
					Value = 242140,
					Level = 344,
					Weight = 423,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 3600,
					FightPower = 36300,
					NeedElementList = {
						{
							Element = 210001,
							Count = 2,
						},
						{
							Element = 210004,
							Count = 1,
						},
					},
				},
			},
		},
		{
			NeedChallenge = 140825,
			Enemy = {
				{
					Value = 242126,
					Level = 292,
					Weight = 117,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 100,
					FightPower = 19000,
					NeedElementList = {
						{
							Element = 210002,
							Count = 1,
						},
						{
							Element = 210003,
							Count = 1,
						},
					},
				},
				{
					Value = 242134,
					Level = 328,
					Weight = 176,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 300,
					FightPower = 24900,
					NeedElementList = {
						{
							Element = 210001,
							Count = 2,
						},
					},
				},
				{
					Value = 242137,
					Level = 340,
					Weight = 141,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 240,
					FightPower = 26300,
					NeedElementList = {
						{
							Element = 210003,
							Count = 2,
						},
						{
							Element = 210004,
							Count = 1,
						},
					},
				},
				{
					Value = 242139,
					Level = 340,
					Weight = 141,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 240,
					FightPower = 27600,
					NeedElementList = {
						{
							Element = 210001,
							Count = 1,
						},
						{
							Element = 210004,
							Count = 1,
						},
					},
				},
			},
		},
		{
			Enemy = {
				{
					Value = 242126,
					Level = 292,
					Weight = 117,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 100,
					FightPower = 19000,
					NeedElementList = {
						{
							Element = 210002,
							Count = 1,
						},
						{
							Element = 210003,
							Count = 1,
						},
					},
				},
				{
					Value = 242134,
					Level = 328,
					Weight = 176,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 300,
					FightPower = 24900,
					NeedElementList = {
						{
							Element = 210001,
							Count = 2,
						},
					},
				},
				{
					Value = 242137,
					Level = 340,
					Weight = 141,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 240,
					FightPower = 26300,
					NeedElementList = {
						{
							Element = 210003,
							Count = 2,
						},
						{
							Element = 210004,
							Count = 1,
						},
					},
				},
			},
		},
	},
	Challenge = {
		140825,
		140826,
	},
	EventList = {
		310842,
		310843,
		310844,
		310845,
		310846,
	},
}
AreaConfig[AreaID.Id211] =
{
	Id = 211,
	Name = "大舞台",
	Planet = 120005,
	Level = 164,
	AreaElement = 210003,
	NumCap = 5,
	Map = "SEA_map_11",
	LevelIcon = "Icon_SEABG03",
	LevelBG = "SEABG03",
	LevelAtlas = "EventBG",
	LevelBundle = "packed_eventbg",
	StartScene = "SEA_StartScene",
	LevelEnemy = {
		{
			NeedChallenge = 140829,
			Enemy = {
				{
					Value = 242141,
					Level = 332,
					Weight = 149,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 100,
					FightPower = 21600,
					NeedElementList = {
						{
							Element = 210001,
							Count = 1,
						},
					},
				},
				{
					Value = 242129,
					Level = 304,
					Weight = 179,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 240,
					FightPower = 24700,
					NeedElementList = {
						{
							Element = 210003,
							Count = 2,
						},
					},
				},
				{
					Value = 242134,
					Level = 328,
					Weight = 223,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 300,
					FightPower = 24900,
					NeedElementList = {
						{
							Element = 210001,
							Count = 2,
						},
					},
				},
				{
					Value = 242142,
					Level = 336,
					Weight = 179,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 240,
					FightPower = 27300,
					NeedElementList = {
						{
							Element = 210001,
							Count = 2,
						},
						{
							Element = 210003,
							Count = 1,
						},
					},
				},
				{
					Value = 242143,
					Level = 340,
					Weight = 268,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 900,
					FightPower = 31700,
					NeedElementList = {
						{
							Element = 210001,
							Count = 2,
						},
						{
							Element = 210002,
							Count = 1,
						},
					},
				},
			},
		},
		{
			NeedChallenge = 140828,
			Enemy = {
				{
					Value = 242141,
					Level = 332,
					Weight = 149,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 100,
					FightPower = 21600,
					NeedElementList = {
						{
							Element = 210001,
							Count = 1,
						},
					},
				},
				{
					Value = 242129,
					Level = 304,
					Weight = 179,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 240,
					FightPower = 24700,
					NeedElementList = {
						{
							Element = 210003,
							Count = 2,
						},
					},
				},
				{
					Value = 242134,
					Level = 328,
					Weight = 223,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 300,
					FightPower = 24900,
					NeedElementList = {
						{
							Element = 210001,
							Count = 2,
						},
					},
				},
				{
					Value = 242142,
					Level = 336,
					Weight = 179,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 240,
					FightPower = 27300,
					NeedElementList = {
						{
							Element = 210001,
							Count = 2,
						},
						{
							Element = 210003,
							Count = 1,
						},
					},
				},
			},
		},
		{
			NeedChallenge = 140827,
			Enemy = {
				{
					Value = 242141,
					Level = 332,
					Weight = 149,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 100,
					FightPower = 21600,
					NeedElementList = {
						{
							Element = 210001,
							Count = 1,
						},
					},
				},
				{
					Value = 242129,
					Level = 304,
					Weight = 179,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 240,
					FightPower = 24700,
					NeedElementList = {
						{
							Element = 210003,
							Count = 2,
						},
					},
				},
				{
					Value = 242134,
					Level = 328,
					Weight = 223,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 300,
					FightPower = 24900,
					NeedElementList = {
						{
							Element = 210001,
							Count = 2,
						},
					},
				},
			},
		},
		{
			Enemy = {
				{
					Value = 242141,
					Level = 332,
					Weight = 149,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 200,
					FightPower = 21600,
					NeedElementList = {
						{
							Element = 210001,
							Count = 1,
						},
					},
				},
				{
					Value = 242129,
					Level = 304,
					Weight = 179,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 240,
					FightPower = 24700,
					NeedElementList = {
						{
							Element = 210003,
							Count = 2,
						},
					},
				},
				{
					Value = 242134,
					Level = 328,
					Weight = 223,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 300,
					FightPower = 24900,
					NeedElementList = {
						{
							Element = 210001,
							Count = 2,
						},
					},
				},
			},
		},
	},
	Challenge = {
		140827,
		140828,
		140829,
	},
	EventList = {
		310847,
		310848,
		310849,
		310850,
		310851,
	},
}
AreaConfig[AreaID.Id212] =
{
	Id = 212,
	Name = "高音剧场",
	Planet = 120005,
	Level = 168,
	AreaElement = 210003,
	NumCap = 5,
	Map = "SEA_map_12",
	LevelIcon = "Icon_SEABG03",
	LevelBG = "SEABG03",
	LevelAtlas = "EventBG",
	LevelBundle = "packed_eventbg",
	StartScene = "SEA_StartScene",
	LevelEnemy = {
		{
			NeedChallenge = 140832,
			Enemy = {
				{
					Value = 242129,
					Level = 304,
					Weight = 187,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 240,
					FightPower = 24700,
					NeedElementList = {
						{
							Element = 210003,
							Count = 2,
						},
					},
				},
				{
					Value = 242132,
					Level = 316,
					Weight = 281,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 900,
					FightPower = 29500,
					NeedElementList = {
						{
							Element = 210001,
							Count = 1,
						},
						{
							Element = 210003,
							Count = 1,
						},
					},
				},
				{
					Value = 242141,
					Level = 348,
					Weight = 156,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 100,
					FightPower = 21600,
					NeedElementList = {
						{
							Element = 210001,
							Count = 1,
						},
					},
				},
				{
					Value = 242145,
					Level = 344,
					Weight = 187,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 240,
					FightPower = 27900,
					NeedElementList = {
						{
							Element = 210001,
							Count = 1,
						},
						{
							Element = 210003,
							Count = 1,
						},
					},
				},
				{
					Value = 242144,
					Level = 348,
					Weight = 187,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 240,
					FightPower = 28200,
					NeedElementList = {
						{
							Element = 210002,
							Count = 1,
						},
						{
							Element = 210003,
							Count = 2,
						},
					},
				},
			},
		},
		{
			NeedChallenge = 140831,
			Enemy = {
				{
					Value = 242129,
					Level = 304,
					Weight = 187,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 240,
					FightPower = 24700,
					NeedElementList = {
						{
							Element = 210003,
							Count = 2,
						},
					},
				},
				{
					Value = 242132,
					Level = 316,
					Weight = 281,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 900,
					FightPower = 29500,
					NeedElementList = {
						{
							Element = 210001,
							Count = 1,
						},
						{
							Element = 210003,
							Count = 1,
						},
					},
				},
				{
					Value = 242141,
					Level = 348,
					Weight = 156,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 100,
					FightPower = 21600,
					NeedElementList = {
						{
							Element = 210001,
							Count = 1,
						},
					},
				},
				{
					Value = 242145,
					Level = 344,
					Weight = 187,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 240,
					FightPower = 27900,
					NeedElementList = {
						{
							Element = 210001,
							Count = 1,
						},
						{
							Element = 210003,
							Count = 1,
						},
					},
				},
				{
					Value = 242144,
					Level = 348,
					Weight = 187,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 240,
					FightPower = 28200,
					NeedElementList = {
						{
							Element = 210002,
							Count = 1,
						},
						{
							Element = 210003,
							Count = 2,
						},
					},
				},
			},
		},
		{
			NeedChallenge = 140830,
			Enemy = {
				{
					Value = 242129,
					Level = 304,
					Weight = 187,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 240,
					FightPower = 24700,
					NeedElementList = {
						{
							Element = 210003,
							Count = 2,
						},
					},
				},
				{
					Value = 242132,
					Level = 316,
					Weight = 281,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 900,
					FightPower = 29500,
					NeedElementList = {
						{
							Element = 210001,
							Count = 1,
						},
						{
							Element = 210003,
							Count = 1,
						},
					},
				},
				{
					Value = 242141,
					Level = 348,
					Weight = 156,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 100,
					FightPower = 21600,
					NeedElementList = {
						{
							Element = 210001,
							Count = 1,
						},
					},
				},
				{
					Value = 242145,
					Level = 344,
					Weight = 187,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 240,
					FightPower = 27900,
					NeedElementList = {
						{
							Element = 210001,
							Count = 1,
						},
						{
							Element = 210003,
							Count = 1,
						},
					},
				},
			},
		},
		{
			Enemy = {
				{
					Value = 242129,
					Level = 304,
					Weight = 187,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 240,
					FightPower = 24700,
					NeedElementList = {
						{
							Element = 210003,
							Count = 2,
						},
					},
				},
				{
					Value = 242132,
					Level = 316,
					Weight = 281,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 900,
					FightPower = 29500,
					NeedElementList = {
						{
							Element = 210001,
							Count = 1,
						},
						{
							Element = 210003,
							Count = 1,
						},
					},
				},
				{
					Value = 242141,
					Level = 348,
					Weight = 156,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 100,
					FightPower = 21600,
					NeedElementList = {
						{
							Element = 210001,
							Count = 1,
						},
					},
				},
			},
		},
	},
	Challenge = {
		140830,
		140831,
		140832,
	},
	EventList = {
		310852,
		310853,
		310854,
		310855,
	},
}
AreaConfig[AreaID.Id213] =
{
	Id = 213,
	Name = "海底世界",
	Planet = 120005,
	Level = 176,
	AreaElement = 210003,
	NumCap = 5,
	Map = "SEA_map_13",
	LevelIcon = "Icon_SEABG03",
	LevelBG = "SEABG03",
	LevelAtlas = "EventBG",
	LevelBundle = "packed_eventbg",
	StartScene = "SEA_StartScene",
	LevelEnemy = {
		{
			NeedChallenge = 140834,
			Enemy = {
				{
					Value = 242139,
					Level = 344,
					Weight = 136,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 240,
					FightPower = 27600,
					NeedElementList = {
						{
							Element = 210001,
							Count = 1,
						},
						{
							Element = 210004,
							Count = 1,
						},
					},
				},
				{
					Value = 242141,
					Level = 348,
					Weight = 113,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 100,
					FightPower = 21600,
					NeedElementList = {
						{
							Element = 210001,
							Count = 1,
						},
					},
				},
				{
					Value = 242145,
					Level = 360,
					Weight = 136,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 240,
					FightPower = 27900,
					NeedElementList = {
						{
							Element = 210001,
							Count = 1,
						},
						{
							Element = 210003,
							Count = 1,
						},
					},
				},
				{
					Value = 242146,
					Level = 352,
					Weight = 204,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 900,
					FightPower = 32800,
					NeedElementList = {
						{
							Element = 210002,
							Count = 1,
						},
						{
							Element = 210005,
							Count = 1,
						},
					},
				},
				{
					Value = 242147,
					Level = 360,
					Weight = 409,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 3600,
					FightPower = 37900,
					NeedElementList = {
						{
							Element = 210002,
							Count = 2,
						},
						{
							Element = 210005,
							Count = 1,
						},
					},
				},
			},
		},
		{
			NeedChallenge = 140833,
			Enemy = {
				{
					Value = 242139,
					Level = 344,
					Weight = 136,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 240,
					FightPower = 27600,
					NeedElementList = {
						{
							Element = 210001,
							Count = 1,
						},
						{
							Element = 210004,
							Count = 1,
						},
					},
				},
				{
					Value = 242141,
					Level = 348,
					Weight = 113,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 100,
					FightPower = 21600,
					NeedElementList = {
						{
							Element = 210001,
							Count = 1,
						},
					},
				},
				{
					Value = 242145,
					Level = 360,
					Weight = 136,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 240,
					FightPower = 27900,
					NeedElementList = {
						{
							Element = 210001,
							Count = 1,
						},
						{
							Element = 210003,
							Count = 1,
						},
					},
				},
				{
					Value = 242146,
					Level = 352,
					Weight = 204,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 900,
					FightPower = 32800,
					NeedElementList = {
						{
							Element = 210002,
							Count = 1,
						},
						{
							Element = 210005,
							Count = 1,
						},
					},
				},
			},
		},
		{
			Enemy = {
				{
					Value = 242139,
					Level = 344,
					Weight = 136,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 240,
					FightPower = 27600,
					NeedElementList = {
						{
							Element = 210001,
							Count = 1,
						},
						{
							Element = 210004,
							Count = 1,
						},
					},
				},
				{
					Value = 242141,
					Level = 348,
					Weight = 113,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 100,
					FightPower = 21600,
					NeedElementList = {
						{
							Element = 210001,
							Count = 1,
						},
					},
				},
				{
					Value = 242145,
					Level = 360,
					Weight = 136,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 240,
					FightPower = 27900,
					NeedElementList = {
						{
							Element = 210001,
							Count = 1,
						},
						{
							Element = 210003,
							Count = 1,
						},
					},
				},
			},
		},
	},
	Challenge = {
		140833,
		140834,
	},
	EventList = {
		310856,
		310857,
		310858,
		310859,
	},
}
AreaConfig[AreaID.Id214] =
{
	Id = 214,
	Name = "大漩涡",
	Planet = 120005,
	Level = 186,
	AreaElement = 210003,
	NumCap = 5,
	Map = "SEA_map_14",
	LevelIcon = "Icon_SEABG03",
	LevelBG = "SEABG03",
	LevelAtlas = "EventBG",
	LevelBundle = "packed_eventbg",
	StartScene = "SEA_StartScene",
	LevelEnemy = {
		{
			NeedChallenge = 140838,
			Enemy = {
				{
					Value = 242141,
					Level = 348,
					Weight = 106,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 100,
					FightPower = 21600,
					NeedElementList = {
						{
							Element = 210001,
							Count = 1,
						},
					},
				},
				{
					Value = 242146,
					Level = 392,
					Weight = 191,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 900,
					FightPower = 32800,
					NeedElementList = {
						{
							Element = 210002,
							Count = 1,
						},
						{
							Element = 210005,
							Count = 1,
						},
					},
				},
				{
					Value = 242148,
					Level = 364,
					Weight = 127,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 240,
					FightPower = 29500,
					NeedElementList = {
						{
							Element = 210003,
							Count = 2,
						},
					},
				},
				{
					Value = 242149,
					Level = 368,
					Weight = 191,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 900,
					FightPower = 34300,
					NeedElementList = {
						{
							Element = 210002,
							Count = 1,
						},
						{
							Element = 210003,
							Count = 1,
						},
					},
				},
				{
					Value = 242150,
					Level = 372,
					Weight = 382,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 3600,
					FightPower = 39200,
					NeedElementList = {
						{
							Element = 210001,
							Count = 2,
						},
						{
							Element = 210003,
							Count = 1,
						},
					},
				},
			},
		},
		{
			NeedChallenge = 140837,
			Enemy = {
				{
					Value = 242141,
					Level = 348,
					Weight = 106,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 100,
					FightPower = 21600,
					NeedElementList = {
						{
							Element = 210001,
							Count = 1,
						},
					},
				},
				{
					Value = 242146,
					Level = 392,
					Weight = 191,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 900,
					FightPower = 32800,
					NeedElementList = {
						{
							Element = 210002,
							Count = 1,
						},
						{
							Element = 210005,
							Count = 1,
						},
					},
				},
				{
					Value = 242148,
					Level = 364,
					Weight = 127,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 240,
					FightPower = 29500,
					NeedElementList = {
						{
							Element = 210003,
							Count = 2,
						},
					},
				},
				{
					Value = 242149,
					Level = 368,
					Weight = 191,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 900,
					FightPower = 34300,
					NeedElementList = {
						{
							Element = 210002,
							Count = 1,
						},
						{
							Element = 210003,
							Count = 1,
						},
					},
				},
				{
					Value = 242150,
					Level = 372,
					Weight = 382,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 3600,
					FightPower = 39200,
					NeedElementList = {
						{
							Element = 210001,
							Count = 2,
						},
						{
							Element = 210003,
							Count = 1,
						},
					},
				},
			},
		},
		{
			NeedChallenge = 140836,
			Enemy = {
				{
					Value = 242141,
					Level = 348,
					Weight = 106,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 100,
					FightPower = 21600,
					NeedElementList = {
						{
							Element = 210001,
							Count = 1,
						},
					},
				},
				{
					Value = 242146,
					Level = 392,
					Weight = 191,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 900,
					FightPower = 32800,
					NeedElementList = {
						{
							Element = 210002,
							Count = 1,
						},
						{
							Element = 210005,
							Count = 1,
						},
					},
				},
				{
					Value = 242148,
					Level = 364,
					Weight = 127,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 240,
					FightPower = 29500,
					NeedElementList = {
						{
							Element = 210003,
							Count = 2,
						},
					},
				},
				{
					Value = 242149,
					Level = 368,
					Weight = 191,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 900,
					FightPower = 34300,
					NeedElementList = {
						{
							Element = 210002,
							Count = 1,
						},
						{
							Element = 210003,
							Count = 1,
						},
					},
				},
			},
		},
		{
			NeedChallenge = 140835,
			Enemy = {
				{
					Value = 242141,
					Level = 348,
					Weight = 106,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 100,
					FightPower = 21600,
					NeedElementList = {
						{
							Element = 210001,
							Count = 1,
						},
					},
				},
				{
					Value = 242146,
					Level = 392,
					Weight = 191,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 900,
					FightPower = 32800,
					NeedElementList = {
						{
							Element = 210002,
							Count = 1,
						},
						{
							Element = 210005,
							Count = 1,
						},
					},
				},
				{
					Value = 242148,
					Level = 364,
					Weight = 127,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 240,
					FightPower = 29500,
					NeedElementList = {
						{
							Element = 210003,
							Count = 2,
						},
					},
				},
			},
		},
		{
			Enemy = {
				{
					Value = 242141,
					Level = 348,
					Weight = 106,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 100,
					FightPower = 21600,
					NeedElementList = {
						{
							Element = 210001,
							Count = 1,
						},
					},
				},
				{
					Value = 242146,
					Level = 392,
					Weight = 191,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 900,
					FightPower = 32800,
					NeedElementList = {
						{
							Element = 210002,
							Count = 1,
						},
						{
							Element = 210005,
							Count = 1,
						},
					},
				},
			},
		},
	},
	Challenge = {
		140835,
		140836,
		140837,
		140838,
	},
	EventList = {
		310860,
		310861,
		310862,
		310863,
		310864,
	},
}
AreaConfig[AreaID.Id251] =
{
	Id = 251,
	Name = "着陆点",
	Planet = 120005,
	Level = 122,
	AreaElement = 210003,
	NumCap = 5,
	Map = "SUS_map_13",
	LevelIcon = "Icon_MUSBG01",
	LevelBG = "MUSBG01",
	LevelAtlas = "EventBG",
	LevelBundle = "packed_eventbg",
	StartScene = "SEA_StartScene",
	LevelEnemy = {
		{
			NeedChallenge = 141003,
			Enemy = {
			},
		},
		{
			NeedChallenge = 141002,
			Enemy = {
			},
		},
		{
			NeedChallenge = 141001,
			Enemy = {
			},
		},
		{
			Enemy = {
			},
		},
	},
	Challenge = {
		141001,
		141002,
		141003,
	},
}
AreaConfig[AreaID.Id252] =
{
	Id = 252,
	Name = "黄金之砂",
	Planet = 120005,
	Level = 125,
	AreaElement = 210001,
	NumCap = 5,
	Map = "SUS_map_13",
	LevelIcon = "Icon_MUSBG02",
	LevelBG = "MUSBG02",
	LevelAtlas = "EventBG",
	LevelBundle = "packed_eventbg",
	StartScene = "SEA_StartScene",
	LevelEnemy = {
		{
			NeedChallenge = 141007,
			Enemy = {
			},
		},
		{
			NeedChallenge = 141006,
			Enemy = {
			},
		},
		{
			NeedChallenge = 141005,
			Enemy = {
			},
		},
		{
			NeedChallenge = 141004,
			Enemy = {
			},
		},
		{
			Enemy = {
			},
		},
	},
	Challenge = {
		141004,
		141005,
		141006,
		141007,
	},
}
AreaConfig[AreaID.Id253] =
{
	Id = 253,
	Name = "地幔堡垒",
	Planet = 120005,
	Level = 130,
	AreaElement = 210003,
	NumCap = 5,
	Map = "SUS_map_13",
	LevelIcon = "Icon_MUSBG03",
	LevelBG = "MUSBG03",
	LevelAtlas = "EventBG",
	LevelBundle = "packed_eventbg",
	StartScene = "SEA_StartScene",
	LevelEnemy = {
		{
			NeedChallenge = 141010,
			Enemy = {
			},
		},
		{
			NeedChallenge = 141009,
			Enemy = {
			},
		},
		{
			NeedChallenge = 141008,
			Enemy = {
			},
		},
		{
			Enemy = {
			},
		},
	},
	Challenge = {
		141008,
		141009,
		141010,
	},
}
AreaConfig[AreaID.Id254] =
{
	Id = 254,
	Name = "试验场",
	Planet = 120005,
	Level = 140,
	AreaElement = 210003,
	NumCap = 5,
	Map = "SUS_map_13",
	LevelIcon = "Icon_MUSBG03",
	LevelBG = "MUSBG03",
	LevelAtlas = "EventBG",
	LevelBundle = "packed_eventbg",
	StartScene = "SEA_StartScene",
	LevelEnemy = {
		{
			NeedChallenge = 141014,
			Enemy = {
			},
		},
		{
			NeedChallenge = 141013,
			Enemy = {
			},
		},
		{
			NeedChallenge = 141012,
			Enemy = {
			},
		},
		{
			NeedChallenge = 141011,
			Enemy = {
			},
		},
		{
			Enemy = {
			},
		},
	},
	Challenge = {
		141011,
		141012,
		141013,
		141014,
	},
}
AreaConfig[AreaID.Id255] =
{
	Id = 255,
	Name = "流沙之河",
	Planet = 120005,
	Level = 132,
	AreaElement = 210003,
	NumCap = 5,
	Map = "SUS_map_13",
	LevelIcon = "Icon_MUSBG03",
	LevelBG = "MUSBG03",
	LevelAtlas = "EventBG",
	LevelBundle = "packed_eventbg",
	StartScene = "SEA_StartScene",
	LevelEnemy = {
		{
			NeedChallenge = 141017,
			Enemy = {
			},
		},
		{
			NeedChallenge = 141016,
			Enemy = {
			},
		},
		{
			NeedChallenge = 141015,
			Enemy = {
			},
		},
		{
			Enemy = {
			},
		},
	},
	Challenge = {
		141015,
		141016,
		141017,
	},
}
AreaConfig[AreaID.Id256] =
{
	Id = 256,
	Name = "绿洲寨",
	Planet = 120005,
	Level = 132,
	AreaElement = 210003,
	NumCap = 5,
	Map = "SUS_map_13",
	LevelIcon = "Icon_MUSBG03",
	LevelBG = "MUSBG03",
	LevelAtlas = "EventBG",
	LevelBundle = "packed_eventbg",
	StartScene = "SEA_StartScene",
	LevelEnemy = {
		{
			NeedChallenge = 141021,
			Enemy = {
			},
		},
		{
			NeedChallenge = 141020,
			Enemy = {
			},
		},
		{
			NeedChallenge = 141019,
			Enemy = {
			},
		},
		{
			NeedChallenge = 141018,
			Enemy = {
			},
		},
		{
			Enemy = {
			},
		},
	},
	Challenge = {
		141018,
		141019,
		141020,
		141021,
	},
}
AreaConfig[AreaID.Id257] =
{
	Id = 257,
	Name = "矿场",
	Planet = 120005,
	Level = 148,
	AreaElement = 210003,
	NumCap = 5,
	Map = "SUS_map_13",
	LevelIcon = "Icon_MUSBG03",
	LevelBG = "MUSBG03",
	LevelAtlas = "EventBG",
	LevelBundle = "packed_eventbg",
	StartScene = "SEA_StartScene",
	LevelEnemy = {
		{
			NeedChallenge = 141025,
			Enemy = {
			},
		},
		{
			NeedChallenge = 141024,
			Enemy = {
			},
		},
		{
			NeedChallenge = 141023,
			Enemy = {
			},
		},
		{
			NeedChallenge = 141022,
			Enemy = {
			},
		},
		{
			Enemy = {
			},
		},
	},
	Challenge = {
		141022,
		141023,
		141024,
		141025,
	},
}
AreaConfig[AreaID.Id258] =
{
	Id = 258,
	Name = "无法地带",
	Planet = 120005,
	Level = 143,
	AreaElement = 210003,
	NumCap = 5,
	Map = "SUS_map_13",
	LevelIcon = "Icon_MUSBG03",
	LevelBG = "MUSBG03",
	LevelAtlas = "EventBG",
	LevelBundle = "packed_eventbg",
	StartScene = "SEA_StartScene",
	LevelEnemy = {
		{
			NeedChallenge = 141029,
			Enemy = {
			},
		},
		{
			NeedChallenge = 141028,
			Enemy = {
			},
		},
		{
			NeedChallenge = 141027,
			Enemy = {
			},
		},
		{
			NeedChallenge = 141026,
			Enemy = {
			},
		},
		{
			Enemy = {
			},
		},
	},
	Challenge = {
		141026,
		141027,
		141028,
		141029,
	},
}
AreaConfig[AreaID.Id259] =
{
	Id = 259,
	Name = "机械车间",
	Planet = 120005,
	Level = 152,
	AreaElement = 210003,
	NumCap = 5,
	Map = "SUS_map_13",
	LevelIcon = "Icon_MUSBG03",
	LevelBG = "MUSBG03",
	LevelAtlas = "EventBG",
	LevelBundle = "packed_eventbg",
	StartScene = "SEA_StartScene",
	LevelEnemy = {
		{
			NeedChallenge = 141032,
			Enemy = {
			},
		},
		{
			NeedChallenge = 141031,
			Enemy = {
			},
		},
		{
			NeedChallenge = 141030,
			Enemy = {
			},
		},
		{
			Enemy = {
			},
		},
	},
	Challenge = {
		141030,
		141031,
		141032,
	},
}
AreaConfig[AreaID.Id260] =
{
	Id = 260,
	Name = "星核",
	Planet = 120005,
	Level = 158,
	AreaElement = 210003,
	NumCap = 5,
	Map = "SUS_map_13",
	LevelIcon = "Icon_MUSBG03",
	LevelBG = "MUSBG03",
	LevelAtlas = "EventBG",
	LevelBundle = "packed_eventbg",
	StartScene = "SEA_StartScene",
	LevelEnemy = {
		{
			NeedChallenge = 141036,
			Enemy = {
			},
		},
		{
			NeedChallenge = 141035,
			Enemy = {
			},
		},
		{
			NeedChallenge = 141034,
			Enemy = {
			},
		},
		{
			NeedChallenge = 141033,
			Enemy = {
			},
		},
		{
			Enemy = {
			},
		},
	},
	Challenge = {
		141033,
		141034,
		141035,
		141036,
	},
}
AreaConfig[AreaID.Id261] =
{
	Id = 261,
	Name = "地心城",
	Planet = 120005,
	Level = 160,
	AreaElement = 210003,
	NumCap = 5,
	Map = "SUS_map_13",
	LevelIcon = "Icon_MUSBG03",
	LevelBG = "MUSBG03",
	LevelAtlas = "EventBG",
	LevelBundle = "packed_eventbg",
	StartScene = "SEA_StartScene",
	LevelEnemy = {
		{
			NeedChallenge = 141039,
			Enemy = {
			},
		},
		{
			NeedChallenge = 141038,
			Enemy = {
			},
		},
		{
			NeedChallenge = 141037,
			Enemy = {
			},
		},
		{
			Enemy = {
			},
		},
	},
	Challenge = {
		141037,
		141038,
		141039,
	},
}
AreaConfig[AreaID.Id262] =
{
	Id = 262,
	Name = "城堡殿堂",
	Planet = 120005,
	Level = 145,
	AreaElement = 210003,
	NumCap = 5,
	Map = "SUS_map_13",
	LevelIcon = "Icon_MUSBG03",
	LevelBG = "MUSBG03",
	LevelAtlas = "EventBG",
	LevelBundle = "packed_eventbg",
	StartScene = "SEA_StartScene",
	LevelEnemy = {
		{
			NeedChallenge = 141041,
			Enemy = {
			},
		},
		{
			NeedChallenge = 141040,
			Enemy = {
			},
		},
		{
			Enemy = {
			},
		},
	},
	Challenge = {
		141040,
		141041,
	},
}
AreaConfig[AreaID.Id263] =
{
	Id = 263,
	Name = "巴别之路",
	Planet = 120005,
	Level = 182,
	AreaElement = 210003,
	NumCap = 5,
	Map = "SUS_map_13",
	LevelIcon = "Icon_MUSBG03",
	LevelBG = "MUSBG03",
	LevelAtlas = "EventBG",
	LevelBundle = "packed_eventbg",
	StartScene = "SEA_StartScene",
	LevelEnemy = {
		{
			NeedChallenge = 141045,
			Enemy = {
			},
		},
		{
			NeedChallenge = 141044,
			Enemy = {
			},
		},
		{
			NeedChallenge = 141043,
			Enemy = {
			},
		},
		{
			NeedChallenge = 141042,
			Enemy = {
			},
		},
		{
			Enemy = {
			},
		},
	},
	Challenge = {
		141042,
		141043,
		141044,
		141045,
	},
}
