require "FreakPlanet/Design/MiscConfig"
PostcardConfig ={};
PostcardID = 
{
	Id001 = 370001,
	Id002 = 370002,
	Id003 = 370003,
	Id004 = 370004,
	Id005 = 370005,
	Id006 = 370006,
	Id007 = 370007,
	Id008 = 370008,
	Id009 = 370009,
	Id010 = 370010,
	Id101 = 370101,
	Id102 = 370102,
	Id103 = 370103,
	Id104 = 370104,
	Id105 = 370105,
	Id106 = 370106,
	Id107 = 370107,
	Id108 = 370108,
	Id109 = 370109,
	Id110 = 370110,
	Id111 = 370111,
	Id201 = 370201,
	Id202 = 370202,
	Id203 = 370203,
	Id204 = 370204,
	Id205 = 370205,
	Id206 = 370206,
	Id207 = 370207,
	Id208 = 370208,
	Id209 = 370209,
	Id210 = 370210,
	Id301 = 370301,
	Id302 = 370302,
	Id303 = 370303,
	Id304 = 370304,
	Id305 = 370305,
	Id306 = 370306,
	Id307 = 370307,
	Id308 = 370308,
	Id309 = 370309,
	Id310 = 370310,
	Id401 = 370401,
	Id402 = 370402,
	Id403 = 370403,
	Id404 = 370404,
	Id405 = 370405,
	Id406 = 370406,
	Id407 = 370407,
	Id408 = 370408,
	Id409 = 370409,
	Id410 = 370410,
	Id8001 = 378001,
}
PostcardConfig[PostcardID.Id001] =
{
	Id = 1,
	Name = "钢铁的友谊",
	Gallery = 950001,
	Type = 0,
	GoalId = 309001,
	Desc = "    见信好~\n    我和漆漆已经抵达冒险世界了，这里的居民对我们很照顾喵~大家在探险的时候，我和漆漆在玩具间玩耍了喵~\n对了，对了~漆漆搭了一个小飞船送给我噢，是不是很厉害喵~~\n    那么最后，祝您也愉快喵！",
	Signature = "呜呜",
	IconBundle = "packed_postcard_01",
	IconAtlas = "Postcard-1",
	Icon = "RPG_Postcard2",
}
PostcardConfig[PostcardID.Id002] =
{
	Id = 2,
	Name = "黄金的友谊",
	Gallery = 950001,
	Type = 0,
	GoalId = 309002,
	Desc = "    见信好~\n    呼……这次遇到危险了……看到飞船上圆圆的红按钮，忍不住按下去了喵，一下子就被吸到太空里了……结果漂流了好久，头昏昏的……不过最后是漆漆找到了我喵……感动喵~\n    现在已经平安了，所以才敢给你写信~\n    那么，祝您今天也愉快喵！",
	Signature = "呜呜",
	IconBundle = "packed_postcard_01",
	IconAtlas = "Postcard-1",
	Icon = "RPG_Postcard3",
}
PostcardConfig[PostcardID.Id003] =
{
	Id = 3,
	Name = "白金的友谊",
	Gallery = 950001,
	Type = 0,
	GoalId = 309003,
	Desc = "    见信好~\n    和漆漆在博物馆一起参观了厉害的展览~在幕布天文馆里看了据说很罕见的景象喵~漆漆说您就在那上面的某颗星星上面呢~不知道您是不是也在哪颗星星上看着我们喵？\n    那么，今天也祝您愉快喵！",
	Signature = "呜呜",
	IconBundle = "packed_postcard_01",
	IconAtlas = "Postcard-1",
	Icon = "RPG_Postcard4",
}
PostcardConfig[PostcardID.Id004] =
{
	Id = 4,
	Name = "一起成为冒险家",
	Gallery = 950001,
	Type = 0,
	GoalId = 309004,
	Desc = "    见信好~\n    我和漆漆都成为冒险家了喵~大家都说我们厉害喵~~~厉害的战斗有时候我们也有登场噢~~啊，啊，大家叫我们了，要继续去冒险了，先写到这里喵~~\n    我和漆漆都很好，请放心~\n    那么，祝您今天愉快喵！",
	Signature = "呜呜",
	IconBundle = "packed_postcard_01",
	IconAtlas = "Postcard-1",
	Icon = "RPG_Postcard1",
}
PostcardConfig[PostcardID.Id005] =
{
	Id = 5,
	Name = "勇者去冒险",
	Gallery = 950001,
	Type = 0,
	GoalId = 309005,
	Desc = "    敬启，贸然叨扰请见谅喵。\n    一路上都是呜呜在给您寄信，我也该定期汇报一下任务了喵！\n    这次加入队伍的是被称为正义与光明的冒险者们，他们似乎一直都在合作着喵。看到他们，软乎乎的史莱姆就都老老实实的了。这是我第一次写冒险报告，不知道是否符合要求呢？\n    以及，我有好好地在照顾呜呜呢，他非常的健康哦！\n    那么祝您身体健康。",
	Signature = "漆漆",
	IconBundle = "packed_postcard_01",
	IconAtlas = "Postcard-1",
	Icon = "RPG_Postcard5",
}
PostcardConfig[PostcardID.Id006] =
{
	Id = 6,
	Name = "人虫大战",
	Gallery = 950001,
	Type = 0,
	GoalId = 309006,
	Desc = "    敬启，听说您也喜欢科幻故事喵。\n    最近航行时大家在说恐怖故事喵，除虫师和霸格讲了可怕的飞船事件。外星怪物潜入飞船了，而且把船员都吃掉了！最后未来女战士打败了它。呼……还好是一个圆满的结局。\n    在飞船上听飞船恐怖故事真的是有点可怕呢……呜呜听得很害怕，但还是抖着把故事听完了喵。\n    祝您今天愉快，等航行完成后，我也和你们一起看电影喵。",
	Signature = "漆漆",
	IconBundle = "packed_postcard_01",
	IconAtlas = "Postcard-1",
	Icon = "RPG_Postcard6",
}
PostcardConfig[PostcardID.Id007] =
{
	Id = 7,
	Name = "魔王的衣橱",
	Gallery = 950001,
	Type = 0,
	GoalId = 309007,
	Desc = "    敬启，我们结交了很厉害的朋友喵。\n    大家都很怕他，叫他大魔王喵。勇者们每次看到他额头都会忍不住滴下汗来。呜呜和我小心翼翼地潜入了他的房间。魔王先生一边念着台词，一边在试穿队伍里小姐姐们喜欢的衣服。气氛怪怪的喵……为了让你也看到，我偷偷拍了照片，应该没关系的喵……\n    呜呜已经睡着了，那么，祝您今天愉快喵。不过，是不是每个人都有大家不了解的一面呢？",
	Signature = "漆漆",
	IconBundle = "packed_postcard_01",
	IconAtlas = "Postcard-1",
	Icon = "RPG_Postcard7",
}
PostcardConfig[PostcardID.Id008] =
{
	Id = 8,
	Name = "困难的制作组",
	Gallery = 950001,
	Type = 0,
	GoalId = 309008,
	Desc = "    见信好，这次是呜呜的信噢~\n    这几位入驻飞船后，就一直在后舱捣鼓。今天我和漆漆去看的时候，发现那里多出一间独立的办公室了喵~他们一个用笔在黑色板子上划来划去，一个皱着眉头在熟练地敲键盘，一个头上的灯泡忽明忽暗的，表情时而轻松，时而紧张。他们在干什么呢~\n    嗯，暂时没有特别的了，那么这次到这里为止，祝您今天也愉快喵！",
	Signature = "呜呜",
	IconBundle = "packed_postcard_01",
	IconAtlas = "Postcard-1",
	Icon = "RPG_Postcard8",
}
PostcardConfig[PostcardID.Id009] =
{
	Id = 9,
	Name = "豪华的制作组",
	Gallery = 950001,
	Type = 0,
	GoalId = 309009,
	Desc = "    见信好，还是呜呜噢~\n    又有新成员加入了呢~~好像和原来后舱的那几位是认识的喵。\n    他们在后舱又鼓捣一阵后，我和漆漆就又偷偷溜去看了~原本的小房间变得更明亮了，工作桌也宽敞了，连显示器也升级成了液晶屏噢~看到我们后，招手叫我们过去，然后他们一边撸我和漆漆，一边在说着进度，版号什么的，挺滑稽的喵~\n    嗯，嗯，那么祝您今天也要愉快噢~",
	Signature = "呜呜",
	IconBundle = "packed_postcard_01",
	IconAtlas = "Postcard-1",
	Icon = "RPG_Postcard9",
}
PostcardConfig[PostcardID.Id010] =
{
	Id = 10,
	Name = "民居里的宝箱",
	Gallery = 950001,
	Type = 0,
	GoalId = 309010,
	Desc = "    敬启，这次是漆漆的汇报喵。\n    今天听居民NPC先生说了以前的经历喵，他在村里当NPC的时候，虽然没有魔物侵袭，但是家里经常有勇者前来“拜访”。勇者们会逼问居民先生有没有支线任务，然后就会把房间翻个遍才离开。祖传的宝物无论藏得多隐蔽，也会被这方面嗅觉特别灵敏的勇者发现的喵……说到这里时，居民先生长长地叹了口气，突然觉得他有些可怜喵。\n    这样的记录有价值吗？呜呜听得很入迷。那么，今天也祝您愉快。",
	Signature = "漆漆",
	IconBundle = "packed_postcard_01",
	IconAtlas = "Postcard-1",
	Icon = "RPG_Postcard10",
}
PostcardConfig[PostcardID.Id101] =
{
	Id = 101,
	Name = "七个小矮糖",
	Gallery = 950002,
	Type = 0,
	GoalId = 309051,
	Desc = "    敬启，您最近还吃甜食喵？\n    在美食星球的愉快旅途中遇到了七个颜色的糖豆豆，他们每个人身上都散发的不一样的香甜味道。不过他们比我和呜呜还调皮喵……新买的柜子被他们拆的乱七八糟了。呼……要去订新的柜子了喵……\n    对了~呜呜最近一切都好，我们在美食星的冒险也很顺利喵~最后，祝您也愉快喵。",
	Signature = "漆漆",
	IconBundle = "packed_postcard_01",
	IconAtlas = "Postcard-1",
	Icon = "FAT_Postcard1",
}
PostcardConfig[PostcardID.Id102] =
{
	Id = 102,
	Name = "公主和七个小矮糖",
	Gallery = 950002,
	Type = 0,
	GoalId = 309052,
	Desc = "    敬启，还记得上次的明信片喵？\n    原来也有可以让糖豆豆们瞬间安静下来的人噢，是个漂亮的大姐姐！美丽又大方的冰淇淋公主一登场，闹哄哄的糖豆豆们就都乖乖的安静下来了喵。\n    大概就像呜呜看见您一样~那么，祝您今天愉快！",
	Signature = "漆漆",
	IconBundle = "packed_postcard_01",
	IconAtlas = "Postcard-1",
	Icon = "FAT_Postcard2",
}
PostcardConfig[PostcardID.Id103] =
{
	Id = 103,
	Name = "问答游戏",
	Gallery = 950002,
	Type = 0,
	GoalId = 309053,
	Desc = "    敬启，继续接着上一次的汇报喵。\n    自从皇后和公主入驻飞船以后，大家会定期投票选出谁的味道比较好闻噢，好像一直是美丽大方的公主赢呢喵。呜呜和我今天路过皇后的舱室了，房间里那面镜子也偷偷给公主投了票，皇后正在和镜子发脾气，不过其实呜呜和我觉得两个都好吃喵。\n    最后，祝您今天愉快喵。希望无论遇到什么不顺心的事，都能保持着愉快的心情。",
	Signature = "漆漆",
	IconBundle = "packed_postcard_01",
	IconAtlas = "Postcard-1",
	Icon = "FAT_Postcard3",
}
PostcardConfig[PostcardID.Id104] =
{
	Id = 104,
	Name = "绝望主妇",
	Gallery = 950002,
	Type = 0,
	GoalId = 309054,
	Desc = "    见信好。\n    但是，今天呜呜要告状！公主们自己去吃野餐，不带我和漆漆。不过其实，我们躲在餐盒里偷偷跟去了~~~\n    她们好开心~在草地上吃烤串喝啤酒，而且似乎还谈到了王子们，我和漆漆躲在餐盒里也吃了个饱呢~\n    那么今天也要愉快喵~~另外，下次带我和漆漆去野餐吧~~",
	Signature = "呜呜",
	IconBundle = "packed_postcard_01",
	IconAtlas = "Postcard-1",
	Icon = "FAT_Postcard4",
}
PostcardConfig[PostcardID.Id105] =
{
	Id = 105,
	Name = "沉睡魔咒舞台剧",
	Gallery = 950002,
	Type = 0,
	GoalId = 309055,
	Desc = "    敬启，今天和呜呜一起看了舞台剧喵。\n    演员是美食星的皇后、公主和仙子们喵。故事大致讲的是一位怎么睡都睡不醒的公主，和一位怎么都睡不着的女巫，在三位仙子的帮助下恢复正常作息的故事。不过，呜呜把爆米花吃完后就立刻睡着了，完全没有看演出喵。\n    那么，祝您今天也愉快。",
	Signature = "漆漆",
	IconBundle = "packed_postcard_01",
	IconAtlas = "Postcard-1",
	Icon = "FAT_Postcard5",
}
PostcardConfig[PostcardID.Id106] =
{
	Id = 106,
	Name = "快餐联谊",
	Gallery = 950002,
	Type = 0,
	GoalId = 309056,
	Desc = "    见信好。\n    自从快餐街的这几位入驻飞船后，我们就经常有免费的快餐吃喵~~~他们偶尔会举办小型联谊会，听说大家都在帮忙撮合腼腆的热狗先生和害羞的汉堡小姐呢~~\n    那么，也祝今天一切顺利喵~~~",
	Signature = "呜呜",
	IconBundle = "packed_postcard_01",
	IconAtlas = "Postcard-1",
	Icon = "FAT_Postcard6",
}
PostcardConfig[PostcardID.Id107] =
{
	Id = 107,
	Name = "牵手成功",
	Gallery = 950002,
	Type = 0,
	GoalId = 309057,
	Desc = "    哇~~哇~~好像有人要表白了喵~~~\n    气氛很不错~~看来飞船上又要多一对情侣了噢~~~不过两个人真的都很腼腆。我和漆漆在旁边等了48小时喵，两个人却一直说着不相关的话题，不过当两人不小心手碰到一起时，这件事情好像有着落了下来。\n    以上是最近发生的飞船重大事件~~那么，祝今天也愉快~~",
	Signature = "呜呜",
	IconBundle = "packed_postcard_01",
	IconAtlas = "Postcard-1",
	Icon = "FAT_Postcard7",
}
PostcardConfig[PostcardID.Id108] =
{
	Id = 108,
	Name = "灰姑娘现场",
	Gallery = 950002,
	Type = 0,
	GoalId = 309058,
	Desc = "    敬启，您最近胖了吗？呜呜和我各胖了3斤喵……\n    薯片夫人也带着女儿们入驻了飞船喵，她们带来了大量零食，飞船也因此设置了专门的零食间喵。不过好像有些超重了……\n    但这家人似乎不像我们一样喜欢零食，薯片夫人每次吃到第30块蛋糕时都会露出抗拒的表情，您很好奇我们怎么知道的吧？因为呜呜和我每次都会坐在旁边数着，这应该可以算是详细的数据了吧。\n    那么，祝今天也愉快！另外，胖了一定要锻炼！",
	Signature = "漆漆",
	IconBundle = "packed_postcard_01",
	IconAtlas = "Postcard-1",
	Icon = "FAT_Postcard8",
}
PostcardConfig[PostcardID.Id109] =
{
	Id = 109,
	Name = "一见钟情？",
	Gallery = 950002,
	Type = 0,
	GoalId = 309059,
	Desc = "    敬启，您最近恋爱了吗？\n    美食星上的可乐王子和爆米花女王在电影院相遇了。据可乐王子事后回忆，当时两人间的距离只有0.5厘米，他的鼻子里能闻到爆米花的香气，于是他感到，会和这位优雅的女性发生些什么。不过据爆米花女王说，当时她打算再看一遍经典爱情电影《爱神见证》，只是手里正好拿着一杯可乐，没有注意到有个男子一直在盯着她看。\n    不知道事实如何喵，我和呜呜都很好奇。那么最后，祝您一切顺利喵。",
	Signature = "漆漆",
	IconBundle = "packed_postcard_01",
	IconAtlas = "Postcard-1",
	Icon = "FAT_Postcard9",
}
PostcardConfig[PostcardID.Id110] =
{
	Id = 110,
	Name = "秘密的约会",
	Gallery = 950002,
	Type = 0,
	GoalId = 309060,
	Desc = "    敬启。\n    上次和您说的八卦消息有了最新进展喵！我和呜呜撞见可乐王子和爆米花女王一起在电影院里看电影，连续看了24小时的电影喵……呜呜和我坐在旁边腿都坐麻了喵……不过最后我们还是互相扶着出了电影院喵。\n    说起来，久坐后要注意时常站起来运动一下，那么，祝您今天也愉快喵~",
	Signature = "漆漆",
	IconBundle = "packed_postcard_01",
	IconAtlas = "Postcard-1",
	Icon = "FAT_Postcard10",
}
PostcardConfig[PostcardID.Id111] =
{
	Id = 111,
	Name = "男人的周末",
	Gallery = 950002,
	Type = 0,
	GoalId = 309061,
	Desc = "    见信好。\n    公主们集体出游，这个周末只有孤孤单单的王子们了，不过他们似乎更高兴了喵~~一起喝着饮料打着扑克，他们说这是属于男生的周末，所有烦恼都留在昨天。\n    有点想念和您在一起的那些周末了。",
	Signature = "呜呜",
	IconBundle = "packed_postcard_01",
	IconAtlas = "Postcard-1",
	Icon = "FAT_Postcard11",
}
PostcardConfig[PostcardID.Id201] =
{
	Id = 201,
	Name = "创世界",
	Gallery = 950003,
	Type = 0,
	GoalId = 309101,
	Desc = "    敬启。\n    有特别的角色入驻飞船了喵，当圣父与圣子指尖相触的一刹那，整个飞船都感受到了一种神圣的气息。大家仿佛都看到了某个教堂上的壁画喵。\n    呜呜好像对艺术展品很感兴趣，看的很投入，但是有些太投入了，在一幅油画上留下了爪印，因此被管理人员骂了喵……那么祝今天愉快喵。",
	Signature = "漆漆",
	IconBundle = "packed_postcard_01",
	IconAtlas = "Postcard-1",
	Icon = "MUS_Postcard1",
}
PostcardConfig[PostcardID.Id202] =
{
	Id = 202,
	Name = "四神壁画",
	Gallery = 950003,
	Type = 0,
	GoalId = 309102,
	Desc = "    见信好~\n    这四位来的时候飞船里闹了好一阵子喵~~他们坚持要把恒温系统调整到39度，不过只试了一天，大家都汗淋淋了，村长先生甚至都中暑了。于是经过再三协议，这四位就搬进引擎室了喵~~而且他们把引擎室好好装扮了一番喵，在墙上还画上了自己的壁画呢~~\n    那么，祝一切顺利喵~~",
	Signature = "呜呜",
	IconBundle = "packed_postcard_01",
	IconAtlas = "Postcard-1",
	Icon = "MUS_Postcard2",
}
PostcardConfig[PostcardID.Id203] =
{
	Id = 203,
	Name = "浣熊三人组",
	Gallery = 950003,
	Type = 0,
	GoalId = 309103,
	Desc = "    见信好~\n    可爱的浣熊三兄弟都入驻飞船了喵~~不过他们太不安分了……每天都在到处打洞，冲击钻的声音吵得大家都睡不好喵。大家联手没收了他们的冲击钻后，他们现在改用刨子和铲子了……窸窸窣窣，窸窸窣窣的……喵……\n    那么，最近您睡得好吗？要注意休息喵~~",
	Signature = "漆漆",
	IconBundle = "packed_postcard_01",
	IconAtlas = "Postcard-1",
	Icon = "MUS_Postcard3",
}
PostcardConfig[PostcardID.Id204] =
{
	Id = 204,
	Name = "这次发财了！",
	Gallery = 950003,
	Type = 0,
	GoalId = 309104,
	Desc = "    敬启，我们已经适应博物馆星的生活了。\n    那三个小家伙挖进了储物室了喵，终于找到了他们最想要的东西，围着坚固的玻璃罩子，他们抱着柜子开心地睡着了喵。好消息是，这下地上不会再有新的洞了！\n    祝您今天愉快！",
	Signature = "漆漆",
	IconBundle = "packed_postcard_01",
	IconAtlas = "Postcard-1",
	Icon = "MUS_Postcard4",
}
PostcardConfig[PostcardID.Id205] =
{
	Id = 205,
	Name = "孤独的画像",
	Gallery = 950003,
	Type = 0,
	GoalId = 309105,
	Desc = "    敬启，今天也是美好的一天喵。\n    在飞船上，独耳先生一直以其充满生命力的艺术创作受到大家的尊重，这位先生也给呜呜和我画过不少画像喵。不过今天要给您介绍的是他的另两幅自画像，应该也是很厉害的作品吧。\n    那么，我和呜呜有空会再联络的，祝您一切安好喵。",
	Signature = "漆漆",
	IconBundle = "packed_postcard_01",
	IconAtlas = "Postcard-1",
	Icon = "MUS_Postcard5",
}
PostcardConfig[PostcardID.Id206] =
{
	Id = 206,
	Name = "怪盗与公爵夫人",
	Gallery = 950003,
	Type = 0,
	GoalId = 309106,
	Desc = "    见信好\n    博物馆星上有一位很擅长微笑的公爵夫人，她凭借自己独特的微笑成为星球上人气最高的女神。见过她微笑的人都会为之倾倒，其中有一位一直守护着她的神秘怪盗，公爵夫人曾经3次被绑架，都是他救回来的。\n    祝您今天愉快！",
	Signature = "呜呜",
	IconBundle = "packed_postcard_01",
	IconAtlas = "Postcard-1",
	Icon = "MUS_Postcard6",
}
PostcardConfig[PostcardID.Id207] =
{
	Id = 207,
	Name = "重见天日",
	Gallery = 950003,
	Type = 0,
	GoalId = 309107,
	Desc = "    见信好\n    四位石像正在为他们的出土举杯庆祝，虽然他们来自四个不同的文明，但是交流起来完全没有障碍。他们边喝茶边聊天，三天三夜都没聊完。看来在地下的时候真是寂寞坏了。\n    祝您今天愉快！",
	Signature = "呜呜",
	IconBundle = "packed_postcard_01",
	IconAtlas = "Postcard-1",
	Icon = "MUS_Postcard7",
}
PostcardConfig[PostcardID.Id208] =
{
	Id = 208,
	Name = "疯狂原始人",
	Gallery = 950003,
	Type = 0,
	GoalId = 309108,
	Desc = "    见信好\n    原始人一家也入驻飞船了喵~~而且带来了他们二十年份的食物喵~~据说他们的日常就是表演打猎，博物馆星的保安先生每天都要准备一只超大的猛犸象给他们一家。\n    有没有感到原始的气息呢？那么，也祝您今天愉快喵！",
	Signature = "呜呜",
	IconBundle = "packed_postcard_01",
	IconAtlas = "Postcard-1",
	Icon = "MUS_Postcard8",
}
PostcardConfig[PostcardID.Id209] =
{
	Id = 209,
	Name = "我爱我自己",
	Gallery = 950003,
	Type = 0,
	GoalId = 309109,
	Desc = "    见信好\n    有一位连眉女士在这个星球留下了三幅她的自画像，这位传奇的女士有好多好多自画像，这三幅是她最得意的作品。\n    祝您今天愉快！",
	Signature = "呜呜",
	IconBundle = "packed_postcard_01",
	IconAtlas = "Postcard-1",
	Icon = "MUS_Postcard9",
}
PostcardConfig[PostcardID.Id210] =
{
	Id = 210,
	Name = "艺术的冲击",
	Gallery = 950003,
	Type = 0,
	GoalId = 309110,
	Desc = "    敬启，又轮到我来联系了。\n    船上来了不可思议的角色喵~一位是看到他就让人感觉想要大声叫喊的呐喊家先生，另一位是看到就觉得充满了诡异又悲伤气氛的哭泣的女人小姐。大家围着他们讨论了半天，最后都摇着头离开了。搞得他们也很莫名其妙呢喵……\n    那么，您知道这两位想表达什么喵？",
	Signature = "漆漆",
	IconBundle = "packed_postcard_01",
	IconAtlas = "Postcard-1",
	Icon = "MUS_Postcard10",
}
PostcardConfig[PostcardID.Id301] =
{
	Id = 301,
	Name = "猫耳三姐妹",
	Gallery = 950004,
	Type = 0,
	GoalId = 309151,
	Desc = "    见信好~\n    三位青春活力的小姐加入了队伍喵~无论走到哪里，都会惹来飞船上年轻男船员的目光。不过每到晚上，三位都会驾驶着小型脱离舱离开飞船，不知道去哪里做什么喵，好神秘啊~~\n    我和漆漆不在家的时候，你要注意防盗噢~~那么，祝一切顺利喵~~",
	Signature = "呜呜",
	IconBundle = "packed_postcard_01",
	IconAtlas = "Postcard-2",
	Icon = "SUS_Postcard1",
}
PostcardConfig[PostcardID.Id302] =
{
	Id = 302,
	Name = "案件重演",
	Gallery = 950004,
	Type = 0,
	GoalId = 309152,
	Desc = "    哇~~~飞船上一直有推理故事听了喵~~~\n    大作家先生和阿加莎小姐入驻飞船了~~大家无聊的时候，他们会在游戏室举办推理游戏~每个人领取角色剧本，然后要找出扮演凶手的人噢~~说起来，漆漆每次一拿到凶手身份，就会一声不吭喵，表情特别严肃~~大家一下子就把它抓出来了~~\n    那么等我们回来了，我们也一起玩，好喵？",
	Signature = "呜呜",
	IconBundle = "packed_postcard_01",
	IconAtlas = "Postcard-2",
	Icon = "SUS_Postcard2",
}
PostcardConfig[PostcardID.Id303] =
{
	Id = 303,
	Name = "IQ 100,000,000",
	Gallery = 950004,
	Type = 0,
	GoalId = 309153,
	Desc = "    您好！\n    我们在这里遇到了不可思议的伙伴喵~听说，这几位聚集在一起以后，任何案件都能迅速找到突破点噢~~这就是推理和知识积累的魅力吧~~\n    那么，祝您今天也愉快噢~~",
	Signature = "呜呜",
	IconBundle = "packed_postcard_01",
	IconAtlas = "Postcard-2",
	Icon = "SUS_Postcard3",
}
PostcardConfig[PostcardID.Id304] =
{
	Id = 304,
	Name = "有生之年",
	Gallery = 950004,
	Type = 0,
	GoalId = 309154,
	Desc = "    敬启，我们在悬疑星一切都好。\n    虽然编辑长先生平时看起来一切都在掌握之中，不过好像也有让他毫无办法的人，只要他被读者们催促后，就会立刻给大作家打电话催稿喵。不过大作家每次都会有推脱的理由，最后潦草地结束谈话。看来每个人都有自己的苦恼喵……\n    那么，祝您今天也愉快，不要把事情都堆积到最后才做哦喵。",
	Signature = "漆漆",
	IconBundle = "packed_postcard_01",
	IconAtlas = "Postcard-2",
	Icon = "SUS_Postcard4",
}
PostcardConfig[PostcardID.Id305] =
{
	Id = 305,
	Name = "睡衣派对",
	Gallery = 950004,
	Type = 0,
	GoalId = 309155,
	Desc = "    见信好~\n    虽然被房东太太拜托，务必阻止这三位进行睡衣派对，但是我和漆漆第一次参加就完全沉迷了喵~~大家拿着枕头互相攻击，而且可以发明出新的招式噢~~~哇，好像新的一局要开始了，我先去玩了，下次告诉你战况喵~~\n    最后，祝一切顺利喵~~",
	Signature = "呜呜",
	IconBundle = "packed_postcard_01",
	IconAtlas = "Postcard-2",
	Icon = "SUS_Postcard5",
}
PostcardConfig[PostcardID.Id306] =
{
	Id = 306,
	Name = "坏蛋联盟",
	Gallery = 950004,
	Type = 0,
	GoalId = 309156,
	Desc = "    您好！\n    “世界不是非黑即白的，还有名为灰色的中间地带”。豆豆警官每次穿上这套卧底服装时，就会这么说，看起来酷酷的喵~教授和杰克先生也会在旁边一起拗造型……\n    感觉他们可能在做很危险的事情喵呢~~不过，做危险的事情时要注意安全噢~~~那么，祝一切顺利喵~",
	Signature = "呜呜",
	IconBundle = "packed_postcard_01",
	IconAtlas = "Postcard-2",
	Icon = "SUS_Postcard6",
}
PostcardConfig[PostcardID.Id307] =
{
	Id = 307,
	Name = "宿命对决",
	Gallery = 950004,
	Type = 0,
	GoalId = 309157,
	Desc = "    见信好~\n    悬疑星人气最高的正派和反派终于在飞船的推理室展开最终较量了喵~~漆漆似乎很期待呢，说一定是超级精彩的推理比赛喵~不过到了现场才发现，原来是打拇指枪大赛，两个顶级聪明的人一边嘴里“biubiubiu”地叫着，一边像在激烈枪战一样地躲来躲去喵……\n    漆漆似乎很失望喵……那么，等回来后，我们一起找部好看的推理电影看吧~~",
	Signature = "呜呜",
	IconBundle = "packed_postcard_01",
	IconAtlas = "Postcard-2",
	Icon = "SUS_Postcard7",
}
PostcardConfig[PostcardID.Id308] =
{
	Id = 308,
	Name = "最佳拍档",
	Gallery = 950004,
	Type = 0,
	GoalId = 309158,
	Desc = "    敬启，我们最近一切都好喵。\n    因为助理先生搞不定，所以大侦探要亲自出马了，听说是非常难买的限量版漫画喵。大侦探说自己只差那一本就集齐了，所以无论如何都要买到，说完就拉着助理一起去了喵。\n    您还在追漫画喵？有些漫画只能慢慢等待喵，不知道结局也不是什么坏事呢。",
	Signature = "漆漆",
	IconBundle = "packed_postcard_01",
	IconAtlas = "Postcard-2",
	Icon = "SUS_Postcard8",
}
PostcardConfig[PostcardID.Id309] =
{
	Id = 309,
	Name = "真相大白",
	Gallery = 950004,
	Type = 0,
	GoalId = 309159,
	Desc = "    见信好~\n    听大侦探说，所有线索都指向那个地方了喵~实验室里藏着所有问题的答案。为此，他一定要去一趟~他们是不是知道了什么喵？\n    不愧是最聪明的侦探~那么，祝一切顺利喵~~",
	Signature = "呜呜",
	IconBundle = "packed_postcard_01",
	IconAtlas = "Postcard-2",
	Icon = "SUS_Postcard9",
}
PostcardConfig[PostcardID.Id310] =
{
	Id = 310,
	Name = "现场采证",
	Gallery = 950004,
	Type = 0,
	GoalId = 309160,
	Desc = "    敬启，最近船上的气氛很活泼喵。\n    大家似乎在开心地玩着角色扮演游戏，现场非常逼真，大家也都很努力地扮演各自的角色。如果不是因为那个死者又站起来，我和呜呜都以为这是真的凶案现场呢。\n    那么，祝您也一切顺利喵。",
	Signature = "漆漆",
	IconBundle = "packed_postcard_01",
	IconAtlas = "Postcard-2",
	Icon = "SUS_Postcard10",
}
PostcardConfig[PostcardID.Id401] =
{
	Id = 401,
	Name = "最棒的演出",
	Gallery = 950005,
	Type = 0,
	GoalId = 309201,
	Desc = "    见信好~\n    终于看到sharkalaka的演出啦。不愧是全宇宙最高人气的偶像团体！\n    现场好多粉丝，还有很多颜色统一的应援棒和灯牌。sharkalaka的第一首歌就点燃了全场，所有粉丝都站起来和TA们一起跳跃，就连我和漆漆也情不自禁地跟着大家一起跳。对了，一直拒绝露出牙齿的白鲨牙牙，也终于露出了自信的笑容。\n    祝您今天愉快喵！对了，希望您也可以拥有像牙牙一样自信的笑容喵～",
	Signature = "呜呜",
	IconBundle = "packed_postcard_01",
	IconAtlas = "Postcard-1",
	Icon = "SEA_Postcard1",
}
PostcardConfig[PostcardID.Id402] =
{
	Id = 402,
	Name = "水母的友情",
	Gallery = 950005,
	Type = 0,
	GoalId = 309202,
	Desc = "    见信好～\n    今天我们去看了水母组合的演出，我超喜欢的喵～\n    TA们透明的裙摆在阳光下发光，实在是太好看了！\n    今天的演出就像舞台剧一样精彩，歌唱到一半，灯塔丝丝认真地看着身旁的同伴说：“我会一直保护你的。”\n    对了，好像漆漆也说过这样的话喵~\n    最后，祝您今天愉快喵～",
	Signature = "呜呜",
	IconBundle = "packed_postcard_01",
	IconAtlas = "Postcard-1",
	Icon = "SEA_Postcard2",
}
PostcardConfig[PostcardID.Id403] =
{
	Id = 403,
	Name = "和服写真",
	Gallery = 950005,
	Type = 0,
	GoalId = 309203,
	Desc = "    见信好～\n    今天我和呜呜，遇见珊瑚带领TA的朋友们去拍写真了喵。\n    四个人穿上和服，面对镜头摆出许多优雅的pose，还即兴来了一场非常精彩的演出。\n    不久后，TA们就穿着服装离开了，我和呜呜非常好奇，不需要归还衣服吗喵？\n    后来我们才知道，原来这些都是珊瑚阿卡买来的衣服，最后赠与给了大家。\n    最后，祝您今天愉快喵！\n    ",
	Signature = "漆漆",
	IconBundle = "packed_postcard_01",
	IconAtlas = "Postcard-1",
	Icon = "SEA_Postcard3",
}
PostcardConfig[PostcardID.Id404] =
{
	Id = 404,
	Name = "live house与魔术",
	Gallery = 950005,
	Type = 0,
	GoalId = 309204,
	Desc = "    见信好~您去看过livehouse喵？\n    我们今天去了演播厅的小房间，看到了海星寻沙、海蛇莱斯莉、蝠鲼凉风的现场演出。大家换了新的衣服和造型，感觉完全认不出来，只能靠声音和气味辨认。\n    整场演出都播放着爵士乐，TA们还表演了一场刺激的魔术。好想拉上漆漆一起去学习魔术啊喵~对了，之后我们去找魔术师吧！\n    祝您今天愉快喵！",
	Signature = "呜呜",
	IconBundle = "packed_postcard_01",
	IconAtlas = "Postcard-2",
	Icon = "SEA_Postcard4",
}
PostcardConfig[PostcardID.Id405] =
{
	Id = 405,
	Name = "遗落的相片",
	Gallery = 950005,
	Type = 0,
	GoalId = 309205,
	Desc = "    见信好~\n    我们在地上捡到了一张照片。\n    照片上八个人挤在一起，画面被填得满满当当。\n    大概是偶像们的自拍喵？这么好看的照片遗失了，失主一定会很着急的。\n    因为不知道失主是谁，于是我和呜呜决定，分别去问一下照片里的八位偶像，希望可以顺利找到TA们。\n    那么先说再见了，祝我们好运。\n    也祝您今天愉快喵！",
	Signature = "漆漆",
	IconBundle = "packed_postcard_01",
	IconAtlas = "Postcard-2",
	Icon = "SEA_Postcard5",
}
PostcardConfig[PostcardID.Id406] =
{
	Id = 406,
	Name = "秘密",
	Gallery = 950005,
	Type = 0,
	GoalId = 309206,
	Desc = "    见信好~\n    今天我们知道了鱼不翻的秘密喵！\n    看起来蠢蠢的鱼不翻，竟然有另一个人格的存在，听说那个人格聪明又机敏，会随时出来保护TA。\n    而且这两个人格还可以相互对话，真是太神奇了喵！\n    在您的世界，会不会也有这种人的存在呢？\n    对了，您说漆漆会不会也是我的另一个人格呢喵？\n    别当真喵……是开玩笑的喵！漆漆当然不是了！\n    最后，祝您今天愉快喵！",
	Signature = "呜呜",
	IconBundle = "packed_postcard_01",
	IconAtlas = "Postcard-2",
	Icon = "SEA_Postcard6",
}
PostcardConfig[PostcardID.Id407] =
{
	Id = 407,
	Name = "灵异现象",
	Gallery = 950005,
	Type = 0,
	GoalId = 309207,
	Desc = "    见信好~\n    这张明信片里的两个海螺，是不是很神奇喵？\n    当然这不是灵异现象，只是海螺美莎穿着男装和女装分别拍完了照片，再把它们合成在一起。\n    听说，海螺发展了直播带货的业务，为了吸引观众，会把自己打扮成帅帅的男孩的模样，但在舞台上，又会变成可爱的女孩~是不是很有意思呢？\n    最后，祝您今天愉快喵！\n    ",
	Signature = "漆漆",
	IconBundle = "packed_postcard_01",
	IconAtlas = "Postcard-2",
	Icon = "SEA_Postcard7",
}
PostcardConfig[PostcardID.Id408] =
{
	Id = 408,
	Name = "倒影",
	Gallery = 950005,
	Type = 0,
	GoalId = 309208,
	Desc = "    见信好~\n    今天见到了偶像海豹彩！不过TA似乎有些奇怪喵。\n    TA在水边看着自己的倒影，一边看一边微笑，还小心翼翼地伸出手去触碰水面，喃喃自语……我本来想去问好，但一不小心扑进了水里，海豹彩立刻脸色大变，吓得我立马就跑开了。不过漆漆刚刚告诉我，已经没事了，但我还是觉得好可怕的喵！\n    对了，也祝您今天愉快喵！",
	Signature = "呜呜",
	IconBundle = "packed_postcard_01",
	IconAtlas = "Postcard-2",
	Icon = "SEA_Postcard8",
}
PostcardConfig[PostcardID.Id409] =
{
	Id = 409,
	Name = "剪刀石头布",
	Gallery = 950005,
	Type = 0,
	GoalId = 309209,
	Desc = "    见信好~\n    今天又知道了一件有趣的事！\n    蟹香菜和虾伊洛最喜欢的活动，就是在一起玩石头剪刀布，但两个人从来没有分出胜负过。\n    因为我也很想玩喵，就加入了TA们的队伍，没想到我和漆漆输得一塌糊涂。看来我们也要去研究一下《猜拳攻略》了喵！对了，我也很想和您一起玩这个游戏，好喵？\n    最后，祝您今天愉快喵！",
	Signature = "呜呜",
	IconBundle = "packed_postcard_01",
	IconAtlas = "Postcard-2",
	Icon = "SEA_Postcard9",
}
PostcardConfig[PostcardID.Id410] =
{
	Id = 410,
	Name = "神奇的海兔",
	Gallery = 950005,
	Type = 0,
	GoalId = 309210,
	Desc = "    见信好~\n    今天我们遇到了海兔幻然。\n    TA过来向我们打招呼的时候，我们完全没有认出来。\n    后来才知道，TA的样子是会发生变化的，明天会变成我们熟悉样子，后天又会变成这个崭新的样子……\n    而且，TA皮肤的颜色，也会根据食物的颜色变化喵。\n    是不是很不可思议呢？呜呜瞪大了眼睛，完全不敢相信呢。\n    最后，祝您今天愉快喵！",
	Signature = "呜呜",
	IconBundle = "packed_postcard_01",
	IconAtlas = "Postcard-2",
	Icon = "SEA_Postcard10",
}
PostcardConfig[PostcardID.Id8001] =
{
	Id = 8001,
	Name = "神奇兔兔在哪里？",
	Gallery = 950101,
	Type = 1,
	Desc = "    见信好~\n    我和呜呜成功帮助嫦娥姐姐，找到了离家的兔子喵。\n    此前，我和呜呜坚信，我们在找一只淘气的兔子，不管劝了多少次，他仍然不愿意回家。今天才知道，原来我们找了很多很多只，一直在和不同的兔子们交流喵。\n    当然，我们也把兔子们的怨言告诉了嫦娥姐姐，嫦娥姐姐只是挠挠头说：哈哈…面对这么多孩子，就算是神仙也会犯错啊。\n    最后，祝您生活愉快喵。",
	Signature = "漆漆",
	IconBundle = "packed_postcard_01",
	IconAtlas = "Postcard-1",
	Icon = "ALL_Postcard1",
}

