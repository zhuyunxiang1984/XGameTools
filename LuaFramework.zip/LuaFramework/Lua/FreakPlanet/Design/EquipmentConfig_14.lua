
EquipmentConfig[EquipmentID.Id423] =
{
	Character = 220418,
	Rarity = 3,
	UpgradeId = 930030,
	LevelList = {
		{
			Level = 1,
			Info = 920378,
			Ability = {
				{
					Value = 200001,
					Num = 57,
				},
				{
					Value = 200006,
					Num = 15,
				},
			},
		},
		{
			Level = 2,
			Info = 920378,
			Ability = {
				{
					Value = 200001,
					Num = 114,
				},
				{
					Value = 200006,
					Num = 30,
				},
			},
		},
		{
			Level = 3,
			Info = 920378,
			Ability = {
				{
					Value = 200001,
					Num = 171,
				},
				{
					Value = 200006,
					Num = 45,
				},
			},
		},
		{
			Level = 4,
			Info = 920378,
			Ability = {
				{
					Value = 200001,
					Num = 228,
				},
				{
					Value = 200006,
					Num = 60,
				},
			},
		},
		{
			Level = 5,
			Info = 920378,
			Ability = {
				{
					Value = 200001,
					Num = 285,
				},
				{
					Value = 200006,
					Num = 75,
				},
			},
		},
		{
			Level = 6,
			Info = 920378,
			Ability = {
				{
					Value = 200001,
					Num = 342,
				},
				{
					Value = 200006,
					Num = 90,
				},
			},
		},
		{
			Level = 7,
			Info = 920378,
			Ability = {
				{
					Value = 200001,
					Num = 399,
				},
				{
					Value = 200006,
					Num = 105,
				},
			},
		},
		{
			Level = 8,
			Info = 920378,
			Ability = {
				{
					Value = 200001,
					Num = 456,
				},
				{
					Value = 200006,
					Num = 120,
				},
			},
			SkillList = {
				{
					Id = 101902,
					Value = 12,
				},
			},
		},
		{
			Level = 9,
			Info = 920378,
			Ability = {
				{
					Value = 200001,
					Num = 513,
				},
				{
					Value = 200006,
					Num = 135,
				},
			},
			SkillList = {
				{
					Id = 101902,
					Value = 12,
				},
			},
		},
		{
			Level = 10,
			Info = 920378,
			Ability = {
				{
					Value = 200001,
					Num = 570,
				},
				{
					Value = 200006,
					Num = 150,
				},
			},
			SkillList = {
				{
					Id = 101902,
					Value = 12,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id424] =
{
	Character = 220418,
	Rarity = 3,
	NeedChallenge = 145166,
	UpgradeId = 930031,
	LevelList = {
		{
			Level = 1,
			Info = 920379,
			Ability = {
				{
					Value = 200001,
					Num = 114,
				},
			},
		},
		{
			Level = 2,
			Info = 920379,
			Ability = {
				{
					Value = 200001,
					Num = 190,
				},
			},
		},
		{
			Level = 3,
			Info = 920379,
			Ability = {
				{
					Value = 200001,
					Num = 266,
				},
			},
		},
		{
			Level = 4,
			Info = 920379,
			Ability = {
				{
					Value = 200001,
					Num = 342,
				},
			},
		},
		{
			Level = 5,
			Info = 920379,
			Ability = {
				{
					Value = 200001,
					Num = 418,
				},
				{
					Value = 200003,
					Num = 25,
				},
			},
		},
		{
			Level = 6,
			Info = 920379,
			Ability = {
				{
					Value = 200001,
					Num = 494,
				},
				{
					Value = 200003,
					Num = 30,
				},
			},
		},
		{
			Level = 7,
			Info = 920379,
			Ability = {
				{
					Value = 200001,
					Num = 570,
				},
				{
					Value = 200003,
					Num = 35,
				},
			},
		},
		{
			Level = 8,
			Info = 920379,
			Ability = {
				{
					Value = 200001,
					Num = 646,
				},
				{
					Value = 200003,
					Num = 40,
				},
			},
			SkillList = {
				{
					Id = 100015,
					Value = -25,
				},
			},
		},
		{
			Level = 9,
			Info = 920379,
			Ability = {
				{
					Value = 200001,
					Num = 722,
				},
				{
					Value = 200003,
					Num = 45,
				},
			},
			SkillList = {
				{
					Id = 100015,
					Value = -25,
				},
			},
		},
		{
			Level = 10,
			Info = 920379,
			Ability = {
				{
					Value = 200001,
					Num = 798,
				},
				{
					Value = 200003,
					Num = 50,
				},
			},
			SkillList = {
				{
					Id = 100015,
					Value = -25,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id425] =
{
	Character = 220419,
	Rarity = 3,
	UpgradeId = 930029,
	LevelList = {
		{
			Level = 1,
			Info = 920380,
			Ability = {
				{
					Value = 200001,
					Num = 57,
				},
				{
					Value = 200005,
					Num = 9,
				},
			},
		},
		{
			Level = 2,
			Info = 920380,
			Ability = {
				{
					Value = 200001,
					Num = 114,
				},
				{
					Value = 200005,
					Num = 18,
				},
			},
		},
		{
			Level = 3,
			Info = 920380,
			Ability = {
				{
					Value = 200001,
					Num = 171,
				},
				{
					Value = 200005,
					Num = 27,
				},
			},
		},
		{
			Level = 4,
			Info = 920380,
			Ability = {
				{
					Value = 200001,
					Num = 228,
				},
				{
					Value = 200005,
					Num = 36,
				},
			},
		},
		{
			Level = 5,
			Info = 920380,
			Ability = {
				{
					Value = 200001,
					Num = 285,
				},
				{
					Value = 200005,
					Num = 45,
				},
			},
			SkillList = {
				{
					Id = 100651,
					Value = 5,
				},
			},
		},
		{
			Level = 6,
			Info = 920380,
			Ability = {
				{
					Value = 200001,
					Num = 342,
				},
				{
					Value = 200005,
					Num = 54,
				},
			},
			SkillList = {
				{
					Id = 100651,
					Value = 5,
				},
			},
		},
		{
			Level = 7,
			Info = 920380,
			Ability = {
				{
					Value = 200001,
					Num = 399,
				},
				{
					Value = 200005,
					Num = 63,
				},
			},
			SkillList = {
				{
					Id = 100651,
					Value = 5,
				},
			},
		},
		{
			Level = 8,
			Info = 920380,
			Ability = {
				{
					Value = 200001,
					Num = 456,
				},
				{
					Value = 200005,
					Num = 72,
				},
			},
			SkillList = {
				{
					Id = 100651,
					Value = 5,
				},
			},
		},
		{
			Level = 9,
			Info = 920380,
			Ability = {
				{
					Value = 200001,
					Num = 513,
				},
				{
					Value = 200005,
					Num = 81,
				},
			},
			SkillList = {
				{
					Id = 100651,
					Value = 5,
				},
			},
		},
		{
			Level = 10,
			Info = 920380,
			Ability = {
				{
					Value = 200001,
					Num = 570,
				},
				{
					Value = 200005,
					Num = 90,
				},
			},
			SkillList = {
				{
					Id = 100651,
					Value = 5,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id426] =
{
	Character = 220419,
	Rarity = 3,
	UpgradeId = 930030,
	LevelList = {
		{
			Level = 1,
			Info = 920381,
			Ability = {
				{
					Value = 200001,
					Num = 57,
				},
				{
					Value = 200007,
					Num = 6,
				},
			},
		},
		{
			Level = 2,
			Info = 920381,
			Ability = {
				{
					Value = 200001,
					Num = 114,
				},
				{
					Value = 200007,
					Num = 12,
				},
			},
		},
		{
			Level = 3,
			Info = 920381,
			Ability = {
				{
					Value = 200001,
					Num = 171,
				},
				{
					Value = 200007,
					Num = 18,
				},
			},
		},
		{
			Level = 4,
			Info = 920381,
			Ability = {
				{
					Value = 200001,
					Num = 228,
				},
				{
					Value = 200007,
					Num = 24,
				},
			},
		},
		{
			Level = 5,
			Info = 920381,
			Ability = {
				{
					Value = 200001,
					Num = 285,
				},
				{
					Value = 200007,
					Num = 30,
				},
			},
		},
		{
			Level = 6,
			Info = 920381,
			Ability = {
				{
					Value = 200001,
					Num = 342,
				},
				{
					Value = 200007,
					Num = 36,
				},
			},
		},
		{
			Level = 7,
			Info = 920381,
			Ability = {
				{
					Value = 200001,
					Num = 399,
				},
				{
					Value = 200007,
					Num = 42,
				},
			},
		},
		{
			Level = 8,
			Info = 920381,
			Ability = {
				{
					Value = 200001,
					Num = 456,
				},
				{
					Value = 200007,
					Num = 48,
				},
			},
			SkillList = {
				{
					Id = 100564,
					Value = -5,
				},
			},
		},
		{
			Level = 9,
			Info = 920381,
			Ability = {
				{
					Value = 200001,
					Num = 513,
				},
				{
					Value = 200007,
					Num = 54,
				},
			},
			SkillList = {
				{
					Id = 100564,
					Value = -5,
				},
			},
		},
		{
			Level = 10,
			Info = 920381,
			Ability = {
				{
					Value = 200001,
					Num = 570,
				},
				{
					Value = 200007,
					Num = 60,
				},
			},
			SkillList = {
				{
					Id = 100564,
					Value = -5,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id427] =
{
	Character = 220419,
	Rarity = 3,
	NeedChallenge = 145167,
	UpgradeId = 930031,
	LevelList = {
		{
			Level = 1,
			Info = 920382,
			Ability = {
				{
					Value = 200001,
					Num = 114,
				},
			},
		},
		{
			Level = 2,
			Info = 920382,
			Ability = {
				{
					Value = 200001,
					Num = 190,
				},
			},
		},
		{
			Level = 3,
			Info = 920382,
			Ability = {
				{
					Value = 200001,
					Num = 266,
				},
			},
		},
		{
			Level = 4,
			Info = 920382,
			Ability = {
				{
					Value = 200001,
					Num = 342,
				},
			},
		},
		{
			Level = 5,
			Info = 920382,
			Ability = {
				{
					Value = 200001,
					Num = 418,
				},
				{
					Value = 200003,
					Num = 25,
				},
			},
		},
		{
			Level = 6,
			Info = 920382,
			Ability = {
				{
					Value = 200001,
					Num = 494,
				},
				{
					Value = 200003,
					Num = 30,
				},
			},
		},
		{
			Level = 7,
			Info = 920382,
			Ability = {
				{
					Value = 200001,
					Num = 570,
				},
				{
					Value = 200003,
					Num = 35,
				},
			},
		},
		{
			Level = 8,
			Info = 920382,
			Ability = {
				{
					Value = 200001,
					Num = 646,
				},
				{
					Value = 200003,
					Num = 40,
				},
			},
			SkillList = {
				{
					Id = 101745,
					Value = 60,
				},
			},
		},
		{
			Level = 9,
			Info = 920382,
			Ability = {
				{
					Value = 200001,
					Num = 722,
				},
				{
					Value = 200003,
					Num = 45,
				},
			},
			SkillList = {
				{
					Id = 101745,
					Value = 60,
				},
			},
		},
		{
			Level = 10,
			Info = 920382,
			Ability = {
				{
					Value = 200001,
					Num = 798,
				},
				{
					Value = 200003,
					Num = 50,
				},
			},
			SkillList = {
				{
					Id = 101745,
					Value = 60,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id428] =
{
	Character = 220420,
	Rarity = 4,
	UpgradeId = 930033,
	LevelList = {
		{
			Level = 1,
			Info = 920383,
			Ability = {
				{
					Value = 200001,
					Num = 72,
				},
				{
					Value = 200005,
					Num = 12,
				},
			},
		},
		{
			Level = 2,
			Info = 920383,
			Ability = {
				{
					Value = 200001,
					Num = 144,
				},
				{
					Value = 200005,
					Num = 24,
				},
			},
		},
		{
			Level = 3,
			Info = 920383,
			Ability = {
				{
					Value = 200001,
					Num = 216,
				},
				{
					Value = 200005,
					Num = 36,
				},
			},
		},
		{
			Level = 4,
			Info = 920383,
			Ability = {
				{
					Value = 200001,
					Num = 288,
				},
				{
					Value = 200005,
					Num = 48,
				},
			},
		},
		{
			Level = 5,
			Info = 920383,
			Ability = {
				{
					Value = 200001,
					Num = 360,
				},
				{
					Value = 200005,
					Num = 60,
				},
			},
		},
		{
			Level = 6,
			Info = 920383,
			Ability = {
				{
					Value = 200001,
					Num = 432,
				},
				{
					Value = 200005,
					Num = 72,
				},
			},
		},
		{
			Level = 7,
			Info = 920383,
			Ability = {
				{
					Value = 200001,
					Num = 504,
				},
				{
					Value = 200005,
					Num = 84,
				},
			},
		},
		{
			Level = 8,
			Info = 920383,
			Ability = {
				{
					Value = 200001,
					Num = 576,
				},
				{
					Value = 200005,
					Num = 96,
				},
			},
			SkillList = {
				{
					Id = 100564,
					Value = -5,
				},
			},
		},
		{
			Level = 9,
			Info = 920383,
			Ability = {
				{
					Value = 200001,
					Num = 648,
				},
				{
					Value = 200005,
					Num = 108,
				},
			},
			SkillList = {
				{
					Id = 100564,
					Value = -5,
				},
			},
		},
		{
			Level = 10,
			Info = 920383,
			Ability = {
				{
					Value = 200001,
					Num = 720,
				},
				{
					Value = 200005,
					Num = 120,
				},
			},
			SkillList = {
				{
					Id = 100564,
					Value = -5,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id429] =
{
	Character = 220420,
	Rarity = 4,
	UpgradeId = 930034,
	LevelList = {
		{
			Level = 1,
			Info = 920384,
			Ability = {
				{
					Value = 200001,
					Num = 72,
				},
				{
					Value = 200008,
					Num = 12,
				},
			},
		},
		{
			Level = 2,
			Info = 920384,
			Ability = {
				{
					Value = 200001,
					Num = 144,
				},
				{
					Value = 200008,
					Num = 24,
				},
			},
		},
		{
			Level = 3,
			Info = 920384,
			Ability = {
				{
					Value = 200001,
					Num = 216,
				},
				{
					Value = 200008,
					Num = 36,
				},
			},
		},
		{
			Level = 4,
			Info = 920384,
			Ability = {
				{
					Value = 200001,
					Num = 288,
				},
				{
					Value = 200008,
					Num = 48,
				},
			},
		},
		{
			Level = 5,
			Info = 920384,
			Ability = {
				{
					Value = 200001,
					Num = 360,
				},
				{
					Value = 200008,
					Num = 60,
				},
			},
		},
		{
			Level = 6,
			Info = 920384,
			Ability = {
				{
					Value = 200001,
					Num = 432,
				},
				{
					Value = 200008,
					Num = 72,
				},
			},
		},
		{
			Level = 7,
			Info = 920384,
			Ability = {
				{
					Value = 200001,
					Num = 504,
				},
				{
					Value = 200008,
					Num = 84,
				},
			},
		},
		{
			Level = 8,
			Info = 920384,
			Ability = {
				{
					Value = 200001,
					Num = 576,
				},
				{
					Value = 200008,
					Num = 96,
				},
			},
			SkillList = {
				{
					Id = 101761,
					Value = 75,
				},
			},
		},
		{
			Level = 9,
			Info = 920384,
			Ability = {
				{
					Value = 200001,
					Num = 648,
				},
				{
					Value = 200008,
					Num = 108,
				},
			},
			SkillList = {
				{
					Id = 101761,
					Value = 75,
				},
			},
		},
		{
			Level = 10,
			Info = 920384,
			Ability = {
				{
					Value = 200001,
					Num = 720,
				},
				{
					Value = 200008,
					Num = 120,
				},
			},
			SkillList = {
				{
					Id = 101761,
					Value = 75,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id430] =
{
	Character = 220420,
	Rarity = 4,
	NeedChallenge = 145168,
	UpgradeId = 930035,
	LevelList = {
		{
			Level = 1,
			Info = 920385,
			Ability = {
				{
					Value = 200001,
					Num = 144,
				},
			},
		},
		{
			Level = 2,
			Info = 920385,
			Ability = {
				{
					Value = 200001,
					Num = 240,
				},
			},
		},
		{
			Level = 3,
			Info = 920385,
			Ability = {
				{
					Value = 200001,
					Num = 336,
				},
			},
		},
		{
			Level = 4,
			Info = 920385,
			Ability = {
				{
					Value = 200001,
					Num = 432,
				},
			},
		},
		{
			Level = 5,
			Info = 920385,
			Ability = {
				{
					Value = 200001,
					Num = 528,
				},
				{
					Value = 200003,
					Num = 25,
				},
			},
		},
		{
			Level = 6,
			Info = 920385,
			Ability = {
				{
					Value = 200001,
					Num = 624,
				},
				{
					Value = 200003,
					Num = 30,
				},
			},
		},
		{
			Level = 7,
			Info = 920385,
			Ability = {
				{
					Value = 200001,
					Num = 720,
				},
				{
					Value = 200003,
					Num = 35,
				},
			},
		},
		{
			Level = 8,
			Info = 920385,
			Ability = {
				{
					Value = 200001,
					Num = 816,
				},
				{
					Value = 200003,
					Num = 40,
				},
			},
			SkillList = {
				{
					Id = 101901,
					Value = 12,
				},
			},
		},
		{
			Level = 9,
			Info = 920385,
			Ability = {
				{
					Value = 200001,
					Num = 912,
				},
				{
					Value = 200003,
					Num = 45,
				},
			},
			SkillList = {
				{
					Id = 101901,
					Value = 12,
				},
			},
		},
		{
			Level = 10,
			Info = 920385,
			Ability = {
				{
					Value = 200001,
					Num = 1008,
				},
				{
					Value = 200003,
					Num = 50,
				},
			},
			SkillList = {
				{
					Id = 101901,
					Value = 12,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id431] =
{
	Character = 220403,
	Rarity = 4,
	UpgradeId = 930033,
	LevelList = {
		{
			Level = 1,
			Info = 920332,
			Ability = {
				{
					Value = 200001,
					Num = 69,
				},
				{
					Value = 200007,
					Num = 12,
				},
			},
		},
		{
			Level = 2,
			Info = 920332,
			Ability = {
				{
					Value = 200001,
					Num = 138,
				},
				{
					Value = 200007,
					Num = 24,
				},
			},
		},
		{
			Level = 3,
			Info = 920332,
			Ability = {
				{
					Value = 200001,
					Num = 207,
				},
				{
					Value = 200007,
					Num = 36,
				},
			},
		},
		{
			Level = 4,
			Info = 920332,
			Ability = {
				{
					Value = 200001,
					Num = 276,
				},
				{
					Value = 200007,
					Num = 48,
				},
			},
		},
		{
			Level = 5,
			Info = 920332,
			Ability = {
				{
					Value = 200001,
					Num = 345,
				},
				{
					Value = 200007,
					Num = 60,
				},
			},
		},
		{
			Level = 6,
			Info = 920332,
			Ability = {
				{
					Value = 200001,
					Num = 414,
				},
				{
					Value = 200007,
					Num = 72,
				},
			},
		},
		{
			Level = 7,
			Info = 920332,
			Ability = {
				{
					Value = 200001,
					Num = 483,
				},
				{
					Value = 200007,
					Num = 84,
				},
			},
		},
		{
			Level = 8,
			Info = 920332,
			Ability = {
				{
					Value = 200001,
					Num = 552,
				},
				{
					Value = 200007,
					Num = 96,
				},
			},
			SkillList = {
				{
					Id = 100561,
					Value = -5,
				},
			},
		},
		{
			Level = 9,
			Info = 920332,
			Ability = {
				{
					Value = 200001,
					Num = 621,
				},
				{
					Value = 200007,
					Num = 108,
				},
			},
			SkillList = {
				{
					Id = 100561,
					Value = -5,
				},
			},
		},
		{
			Level = 10,
			Info = 920332,
			Ability = {
				{
					Value = 200001,
					Num = 690,
				},
				{
					Value = 200007,
					Num = 120,
				},
			},
			SkillList = {
				{
					Id = 100561,
					Value = -5,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id432] =
{
	Character = 220403,
	Rarity = 4,
	UpgradeId = 930014,
	LevelList = {
		{
			Level = 1,
			Info = 920333,
			Ability = {
				{
					Value = 200002,
					Num = 57,
				},
				{
					Value = 200008,
					Num = 9,
				},
			},
		},
		{
			Level = 2,
			Info = 920333,
			Ability = {
				{
					Value = 200002,
					Num = 114,
				},
				{
					Value = 200008,
					Num = 18,
				},
			},
		},
		{
			Level = 3,
			Info = 920333,
			Ability = {
				{
					Value = 200002,
					Num = 171,
				},
				{
					Value = 200008,
					Num = 27,
				},
			},
		},
		{
			Level = 4,
			Info = 920333,
			Ability = {
				{
					Value = 200002,
					Num = 228,
				},
				{
					Value = 200008,
					Num = 36,
				},
			},
		},
		{
			Level = 5,
			Info = 920333,
			Ability = {
				{
					Value = 200002,
					Num = 285,
				},
				{
					Value = 200008,
					Num = 45,
				},
			},
		},
		{
			Level = 6,
			Info = 920333,
			Ability = {
				{
					Value = 200002,
					Num = 342,
				},
				{
					Value = 200008,
					Num = 54,
				},
			},
		},
		{
			Level = 7,
			Info = 920333,
			Ability = {
				{
					Value = 200002,
					Num = 399,
				},
				{
					Value = 200008,
					Num = 63,
				},
			},
		},
		{
			Level = 8,
			Info = 920333,
			Ability = {
				{
					Value = 200002,
					Num = 456,
				},
				{
					Value = 200008,
					Num = 72,
				},
			},
			SkillList = {
				{
					Id = 100551,
					Value = 25,
				},
			},
		},
		{
			Level = 9,
			Info = 920333,
			Ability = {
				{
					Value = 200002,
					Num = 513,
				},
				{
					Value = 200008,
					Num = 81,
				},
			},
			SkillList = {
				{
					Id = 100551,
					Value = 25,
				},
			},
		},
		{
			Level = 10,
			Info = 920333,
			Ability = {
				{
					Value = 200002,
					Num = 570,
				},
				{
					Value = 200008,
					Num = 90,
				},
			},
			SkillList = {
				{
					Id = 100551,
					Value = 25,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id433] =
{
	Character = 220403,
	Rarity = 4,
	NeedChallenge = 145169,
	UpgradeId = 930015,
	LevelList = {
		{
			Level = 1,
			Info = 920334,
			Ability = {
				{
					Value = 200002,
					Num = 114,
				},
			},
		},
		{
			Level = 2,
			Info = 920334,
			Ability = {
				{
					Value = 200002,
					Num = 190,
				},
			},
		},
		{
			Level = 3,
			Info = 920334,
			Ability = {
				{
					Value = 200002,
					Num = 266,
				},
			},
		},
		{
			Level = 4,
			Info = 920334,
			Ability = {
				{
					Value = 200002,
					Num = 342,
				},
			},
		},
		{
			Level = 5,
			Info = 920334,
			Ability = {
				{
					Value = 200002,
					Num = 418,
				},
				{
					Value = 200004,
					Num = 25,
				},
			},
		},
		{
			Level = 6,
			Info = 920334,
			Ability = {
				{
					Value = 200002,
					Num = 494,
				},
				{
					Value = 200004,
					Num = 30,
				},
			},
		},
		{
			Level = 7,
			Info = 920334,
			Ability = {
				{
					Value = 200002,
					Num = 570,
				},
				{
					Value = 200004,
					Num = 35,
				},
			},
		},
		{
			Level = 8,
			Info = 920334,
			Ability = {
				{
					Value = 200002,
					Num = 646,
				},
				{
					Value = 200004,
					Num = 40,
				},
			},
			SkillList = {
				{
					Id = 101719,
					Value = 113,
				},
			},
		},
		{
			Level = 9,
			Info = 920334,
			Ability = {
				{
					Value = 200002,
					Num = 722,
				},
				{
					Value = 200004,
					Num = 45,
				},
			},
			SkillList = {
				{
					Id = 101719,
					Value = 113,
				},
			},
		},
		{
			Level = 10,
			Info = 920334,
			Ability = {
				{
					Value = 200002,
					Num = 798,
				},
				{
					Value = 200004,
					Num = 50,
				},
			},
			SkillList = {
				{
					Id = 101719,
					Value = 113,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id434] =
{
	Character = 220421,
	Rarity = 4,
	UpgradeId = 930013,
	LevelList = {
		{
			Level = 1,
			Info = 920386,
			Ability = {
				{
					Value = 200002,
					Num = 57,
				},
				{
					Value = 200006,
					Num = 12,
				},
			},
		},
		{
			Level = 2,
			Info = 920386,
			Ability = {
				{
					Value = 200002,
					Num = 114,
				},
				{
					Value = 200006,
					Num = 24,
				},
			},
		},
		{
			Level = 3,
			Info = 920386,
			Ability = {
				{
					Value = 200002,
					Num = 171,
				},
				{
					Value = 200006,
					Num = 36,
				},
			},
		},
		{
			Level = 4,
			Info = 920386,
			Ability = {
				{
					Value = 200002,
					Num = 228,
				},
				{
					Value = 200006,
					Num = 48,
				},
			},
		},
		{
			Level = 5,
			Info = 920386,
			Ability = {
				{
					Value = 200002,
					Num = 285,
				},
				{
					Value = 200006,
					Num = 60,
				},
			},
		},
		{
			Level = 6,
			Info = 920386,
			Ability = {
				{
					Value = 200002,
					Num = 342,
				},
				{
					Value = 200006,
					Num = 72,
				},
			},
		},
		{
			Level = 7,
			Info = 920386,
			Ability = {
				{
					Value = 200002,
					Num = 399,
				},
				{
					Value = 200006,
					Num = 84,
				},
			},
		},
		{
			Level = 8,
			Info = 920386,
			Ability = {
				{
					Value = 200002,
					Num = 456,
				},
				{
					Value = 200006,
					Num = 96,
				},
			},
			SkillList = {
				{
					Id = 100552,
					Value = 25,
				},
			},
		},
		{
			Level = 9,
			Info = 920386,
			Ability = {
				{
					Value = 200002,
					Num = 513,
				},
				{
					Value = 200006,
					Num = 108,
				},
			},
			SkillList = {
				{
					Id = 100552,
					Value = 25,
				},
			},
		},
		{
			Level = 10,
			Info = 920386,
			Ability = {
				{
					Value = 200002,
					Num = 570,
				},
				{
					Value = 200006,
					Num = 120,
				},
			},
			SkillList = {
				{
					Id = 100552,
					Value = 25,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id435] =
{
	Character = 220421,
	Rarity = 4,
	UpgradeId = 930014,
	LevelList = {
		{
			Level = 1,
			Info = 920387,
			Ability = {
				{
					Value = 200002,
					Num = 57,
				},
				{
					Value = 200005,
					Num = 9,
				},
			},
		},
		{
			Level = 2,
			Info = 920387,
			Ability = {
				{
					Value = 200002,
					Num = 114,
				},
				{
					Value = 200005,
					Num = 18,
				},
			},
		},
		{
			Level = 3,
			Info = 920387,
			Ability = {
				{
					Value = 200002,
					Num = 171,
				},
				{
					Value = 200005,
					Num = 27,
				},
			},
		},
		{
			Level = 4,
			Info = 920387,
			Ability = {
				{
					Value = 200002,
					Num = 228,
				},
				{
					Value = 200005,
					Num = 36,
				},
			},
		},
		{
			Level = 5,
			Info = 920387,
			Ability = {
				{
					Value = 200002,
					Num = 285,
				},
				{
					Value = 200005,
					Num = 45,
				},
			},
		},
		{
			Level = 6,
			Info = 920387,
			Ability = {
				{
					Value = 200002,
					Num = 342,
				},
				{
					Value = 200005,
					Num = 54,
				},
			},
		},
		{
			Level = 7,
			Info = 920387,
			Ability = {
				{
					Value = 200002,
					Num = 399,
				},
				{
					Value = 200005,
					Num = 63,
				},
			},
		},
		{
			Level = 8,
			Info = 920387,
			Ability = {
				{
					Value = 200002,
					Num = 456,
				},
				{
					Value = 200005,
					Num = 72,
				},
			},
			SkillList = {
				{
					Id = 101703,
					Value = 300,
				},
			},
		},
		{
			Level = 9,
			Info = 920387,
			Ability = {
				{
					Value = 200002,
					Num = 513,
				},
				{
					Value = 200005,
					Num = 81,
				},
			},
			SkillList = {
				{
					Id = 101703,
					Value = 300,
				},
			},
		},
		{
			Level = 10,
			Info = 920387,
			Ability = {
				{
					Value = 200002,
					Num = 570,
				},
				{
					Value = 200005,
					Num = 90,
				},
			},
			SkillList = {
				{
					Id = 101703,
					Value = 300,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id436] =
{
	Character = 220421,
	Rarity = 4,
	NeedChallenge = 145170,
	UpgradeId = 930015,
	LevelList = {
		{
			Level = 1,
			Info = 920388,
			Ability = {
				{
					Value = 200002,
					Num = 114,
				},
			},
		},
		{
			Level = 2,
			Info = 920388,
			Ability = {
				{
					Value = 200002,
					Num = 190,
				},
			},
		},
		{
			Level = 3,
			Info = 920388,
			Ability = {
				{
					Value = 200002,
					Num = 266,
				},
			},
		},
		{
			Level = 4,
			Info = 920388,
			Ability = {
				{
					Value = 200002,
					Num = 342,
				},
			},
		},
		{
			Level = 5,
			Info = 920388,
			Ability = {
				{
					Value = 200002,
					Num = 418,
				},
				{
					Value = 200004,
					Num = 25,
				},
			},
		},
		{
			Level = 6,
			Info = 920388,
			Ability = {
				{
					Value = 200002,
					Num = 494,
				},
				{
					Value = 200004,
					Num = 30,
				},
			},
		},
		{
			Level = 7,
			Info = 920388,
			Ability = {
				{
					Value = 200002,
					Num = 570,
				},
				{
					Value = 200004,
					Num = 35,
				},
			},
		},
		{
			Level = 8,
			Info = 920388,
			Ability = {
				{
					Value = 200002,
					Num = 646,
				},
				{
					Value = 200004,
					Num = 40,
				},
			},
			SkillList = {
				{
					Id = 100794,
					Value = 2,
				},
			},
		},
		{
			Level = 9,
			Info = 920388,
			Ability = {
				{
					Value = 200002,
					Num = 722,
				},
				{
					Value = 200004,
					Num = 45,
				},
			},
			SkillList = {
				{
					Id = 100794,
					Value = 2,
				},
			},
		},
		{
			Level = 10,
			Info = 920388,
			Ability = {
				{
					Value = 200002,
					Num = 798,
				},
				{
					Value = 200004,
					Num = 50,
				},
			},
			SkillList = {
				{
					Id = 100794,
					Value = 2,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id437] =
{
	Character = 220422,
	Rarity = 4,
	UpgradeId = 930033,
	LevelList = {
		{
			Level = 1,
			Info = 920389,
			Ability = {
				{
					Value = 200001,
					Num = 75,
				},
				{
					Value = 200005,
					Num = 12,
				},
			},
		},
		{
			Level = 2,
			Info = 920389,
			Ability = {
				{
					Value = 200001,
					Num = 150,
				},
				{
					Value = 200005,
					Num = 24,
				},
			},
		},
		{
			Level = 3,
			Info = 920389,
			Ability = {
				{
					Value = 200001,
					Num = 225,
				},
				{
					Value = 200005,
					Num = 36,
				},
			},
		},
		{
			Level = 4,
			Info = 920389,
			Ability = {
				{
					Value = 200001,
					Num = 300,
				},
				{
					Value = 200005,
					Num = 48,
				},
			},
		},
		{
			Level = 5,
			Info = 920389,
			Ability = {
				{
					Value = 200001,
					Num = 375,
				},
				{
					Value = 200005,
					Num = 60,
				},
			},
		},
		{
			Level = 6,
			Info = 920389,
			Ability = {
				{
					Value = 200001,
					Num = 450,
				},
				{
					Value = 200005,
					Num = 72,
				},
			},
		},
		{
			Level = 7,
			Info = 920389,
			Ability = {
				{
					Value = 200001,
					Num = 525,
				},
				{
					Value = 200005,
					Num = 84,
				},
			},
		},
		{
			Level = 8,
			Info = 920389,
			Ability = {
				{
					Value = 200001,
					Num = 600,
				},
				{
					Value = 200005,
					Num = 96,
				},
			},
			SkillList = {
				{
					Id = 100564,
					Value = -5,
				},
			},
		},
		{
			Level = 9,
			Info = 920389,
			Ability = {
				{
					Value = 200001,
					Num = 675,
				},
				{
					Value = 200005,
					Num = 108,
				},
			},
			SkillList = {
				{
					Id = 100564,
					Value = -5,
				},
			},
		},
		{
			Level = 10,
			Info = 920389,
			Ability = {
				{
					Value = 200001,
					Num = 750,
				},
				{
					Value = 200005,
					Num = 120,
				},
			},
			SkillList = {
				{
					Id = 100564,
					Value = -5,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id438] =
{
	Character = 220422,
	Rarity = 4,
	UpgradeId = 930034,
	LevelList = {
		{
			Level = 1,
			Info = 920390,
			Ability = {
				{
					Value = 200001,
					Num = 75,
				},
				{
					Value = 200006,
					Num = 9,
				},
			},
		},
		{
			Level = 2,
			Info = 920390,
			Ability = {
				{
					Value = 200001,
					Num = 150,
				},
				{
					Value = 200006,
					Num = 18,
				},
			},
		},
		{
			Level = 3,
			Info = 920390,
			Ability = {
				{
					Value = 200001,
					Num = 225,
				},
				{
					Value = 200006,
					Num = 27,
				},
			},
		},
		{
			Level = 4,
			Info = 920390,
			Ability = {
				{
					Value = 200001,
					Num = 300,
				},
				{
					Value = 200006,
					Num = 36,
				},
			},
		},
		{
			Level = 5,
			Info = 920390,
			Ability = {
				{
					Value = 200001,
					Num = 375,
				},
				{
					Value = 200006,
					Num = 45,
				},
			},
		},
		{
			Level = 6,
			Info = 920390,
			Ability = {
				{
					Value = 200001,
					Num = 450,
				},
				{
					Value = 200006,
					Num = 54,
				},
			},
		},
		{
			Level = 7,
			Info = 920390,
			Ability = {
				{
					Value = 200001,
					Num = 525,
				},
				{
					Value = 200006,
					Num = 63,
				},
			},
		},
		{
			Level = 8,
			Info = 920390,
			Ability = {
				{
					Value = 200001,
					Num = 600,
				},
				{
					Value = 200006,
					Num = 72,
				},
			},
			SkillList = {
				{
					Id = 101704,
					Value = 30,
				},
			},
		},
		{
			Level = 9,
			Info = 920390,
			Ability = {
				{
					Value = 200001,
					Num = 675,
				},
				{
					Value = 200006,
					Num = 81,
				},
			},
			SkillList = {
				{
					Id = 101704,
					Value = 30,
				},
			},
		},
		{
			Level = 10,
			Info = 920390,
			Ability = {
				{
					Value = 200001,
					Num = 750,
				},
				{
					Value = 200006,
					Num = 90,
				},
			},
			SkillList = {
				{
					Id = 101704,
					Value = 30,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id439] =
{
	Character = 220422,
	Rarity = 4,
	NeedChallenge = 145171,
	UpgradeId = 930035,
	LevelList = {
		{
			Level = 1,
			Info = 920391,
			Ability = {
				{
					Value = 200001,
					Num = 150,
				},
			},
		},
		{
			Level = 2,
			Info = 920391,
			Ability = {
				{
					Value = 200001,
					Num = 250,
				},
			},
		},
		{
			Level = 3,
			Info = 920391,
			Ability = {
				{
					Value = 200001,
					Num = 350,
				},
			},
		},
		{
			Level = 4,
			Info = 920391,
			Ability = {
				{
					Value = 200001,
					Num = 450,
				},
			},
		},
		{
			Level = 5,
			Info = 920391,
			Ability = {
				{
					Value = 200001,
					Num = 550,
				},
				{
					Value = 200003,
					Num = 25,
				},
			},
		},
		{
			Level = 6,
			Info = 920391,
			Ability = {
				{
					Value = 200001,
					Num = 650,
				},
				{
					Value = 200003,
					Num = 30,
				},
			},
		},
		{
			Level = 7,
			Info = 920391,
			Ability = {
				{
					Value = 200001,
					Num = 750,
				},
				{
					Value = 200003,
					Num = 35,
				},
			},
		},
		{
			Level = 8,
			Info = 920391,
			Ability = {
				{
					Value = 200001,
					Num = 850,
				},
				{
					Value = 200003,
					Num = 40,
				},
			},
			SkillList = {
				{
					Id = 100793,
					Value = 2,
				},
			},
		},
		{
			Level = 9,
			Info = 920391,
			Ability = {
				{
					Value = 200001,
					Num = 950,
				},
				{
					Value = 200003,
					Num = 45,
				},
			},
			SkillList = {
				{
					Id = 100793,
					Value = 2,
				},
			},
		},
		{
			Level = 10,
			Info = 920391,
			Ability = {
				{
					Value = 200001,
					Num = 1050,
				},
				{
					Value = 200003,
					Num = 50,
				},
			},
			SkillList = {
				{
					Id = 100793,
					Value = 2,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id440] =
{
	Character = 220423,
	Rarity = 4,
	UpgradeId = 930033,
	LevelList = {
		{
			Level = 1,
			Info = 920392,
			Ability = {
				{
					Value = 200001,
					Num = 69,
				},
				{
					Value = 200008,
					Num = 12,
				},
			},
		},
		{
			Level = 2,
			Info = 920392,
			Ability = {
				{
					Value = 200001,
					Num = 138,
				},
				{
					Value = 200008,
					Num = 24,
				},
			},
		},
		{
			Level = 3,
			Info = 920392,
			Ability = {
				{
					Value = 200001,
					Num = 207,
				},
				{
					Value = 200008,
					Num = 36,
				},
			},
		},
		{
			Level = 4,
			Info = 920392,
			Ability = {
				{
					Value = 200001,
					Num = 276,
				},
				{
					Value = 200008,
					Num = 48,
				},
			},
		},
		{
			Level = 5,
			Info = 920392,
			Ability = {
				{
					Value = 200001,
					Num = 345,
				},
				{
					Value = 200008,
					Num = 60,
				},
			},
		},
		{
			Level = 6,
			Info = 920392,
			Ability = {
				{
					Value = 200001,
					Num = 414,
				},
				{
					Value = 200008,
					Num = 72,
				},
			},
		},
		{
			Level = 7,
			Info = 920392,
			Ability = {
				{
					Value = 200001,
					Num = 483,
				},
				{
					Value = 200008,
					Num = 84,
				},
			},
		},
		{
			Level = 8,
			Info = 920392,
			Ability = {
				{
					Value = 200001,
					Num = 552,
				},
				{
					Value = 200008,
					Num = 96,
				},
			},
			SkillList = {
				{
					Id = 100651,
					Value = 20,
				},
			},
		},
		{
			Level = 9,
			Info = 920392,
			Ability = {
				{
					Value = 200001,
					Num = 621,
				},
				{
					Value = 200008,
					Num = 108,
				},
			},
			SkillList = {
				{
					Id = 100651,
					Value = 20,
				},
			},
		},
		{
			Level = 10,
			Info = 920392,
			Ability = {
				{
					Value = 200001,
					Num = 690,
				},
				{
					Value = 200008,
					Num = 120,
				},
			},
			SkillList = {
				{
					Id = 100651,
					Value = 20,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id441] =
{
	Character = 220423,
	Rarity = 4,
	UpgradeId = 930014,
	LevelList = {
		{
			Level = 1,
			Info = 920393,
			Ability = {
				{
					Value = 200002,
					Num = 57,
				},
				{
					Value = 200005,
					Num = 9,
				},
			},
		},
		{
			Level = 2,
			Info = 920393,
			Ability = {
				{
					Value = 200002,
					Num = 114,
				},
				{
					Value = 200005,
					Num = 18,
				},
			},
		},
		{
			Level = 3,
			Info = 920393,
			Ability = {
				{
					Value = 200002,
					Num = 171,
				},
				{
					Value = 200005,
					Num = 27,
				},
			},
		},
		{
			Level = 4,
			Info = 920393,
			Ability = {
				{
					Value = 200002,
					Num = 228,
				},
				{
					Value = 200005,
					Num = 36,
				},
			},
		},
		{
			Level = 5,
			Info = 920393,
			Ability = {
				{
					Value = 200002,
					Num = 285,
				},
				{
					Value = 200005,
					Num = 45,
				},
			},
		},
		{
			Level = 6,
			Info = 920393,
			Ability = {
				{
					Value = 200002,
					Num = 342,
				},
				{
					Value = 200005,
					Num = 54,
				},
			},
		},
		{
			Level = 7,
			Info = 920393,
			Ability = {
				{
					Value = 200002,
					Num = 399,
				},
				{
					Value = 200005,
					Num = 63,
				},
			},
		},
		{
			Level = 8,
			Info = 920393,
			Ability = {
				{
					Value = 200002,
					Num = 456,
				},
				{
					Value = 200005,
					Num = 72,
				},
			},
			SkillList = {
				{
					Id = 101763,
					Value = 48,
				},
			},
		},
		{
			Level = 9,
			Info = 920393,
			Ability = {
				{
					Value = 200002,
					Num = 513,
				},
				{
					Value = 200005,
					Num = 81,
				},
			},
			SkillList = {
				{
					Id = 101763,
					Value = 48,
				},
			},
		},
		{
			Level = 10,
			Info = 920393,
			Ability = {
				{
					Value = 200002,
					Num = 570,
				},
				{
					Value = 200005,
					Num = 90,
				},
			},
			SkillList = {
				{
					Id = 101763,
					Value = 48,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id442] =
{
	Character = 220423,
	Rarity = 4,
	NeedChallenge = 145172,
	UpgradeId = 930015,
	LevelList = {
		{
			Level = 1,
			Info = 920394,
			Ability = {
				{
					Value = 200002,
					Num = 114,
				},
			},
		},
		{
			Level = 2,
			Info = 920394,
			Ability = {
				{
					Value = 200002,
					Num = 190,
				},
			},
		},
		{
			Level = 3,
			Info = 920394,
			Ability = {
				{
					Value = 200002,
					Num = 266,
				},
			},
		},
		{
			Level = 4,
			Info = 920394,
			Ability = {
				{
					Value = 200002,
					Num = 342,
				},
			},
		},
		{
			Level = 5,
			Info = 920394,
			Ability = {
				{
					Value = 200002,
					Num = 418,
				},
				{
					Value = 200004,
					Num = 25,
				},
			},
		},
		{
			Level = 6,
			Info = 920394,
			Ability = {
				{
					Value = 200002,
					Num = 494,
				},
				{
					Value = 200004,
					Num = 30,
				},
			},
		},
		{
			Level = 7,
			Info = 920394,
			Ability = {
				{
					Value = 200002,
					Num = 570,
				},
				{
					Value = 200004,
					Num = 35,
				},
			},
		},
		{
			Level = 8,
			Info = 920394,
			Ability = {
				{
					Value = 200002,
					Num = 646,
				},
				{
					Value = 200004,
					Num = 40,
				},
			},
			SkillList = {
				{
					Id = 101765,
					Value = 12,
				},
			},
		},
		{
			Level = 9,
			Info = 920394,
			Ability = {
				{
					Value = 200002,
					Num = 722,
				},
				{
					Value = 200004,
					Num = 45,
				},
			},
			SkillList = {
				{
					Id = 101765,
					Value = 12,
				},
			},
		},
		{
			Level = 10,
			Info = 920394,
			Ability = {
				{
					Value = 200002,
					Num = 798,
				},
				{
					Value = 200004,
					Num = 50,
				},
			},
			SkillList = {
				{
					Id = 101765,
					Value = 12,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id443] =
{
	Character = 220424,
	Rarity = 4,
	UpgradeId = 930033,
	LevelList = {
		{
			Level = 1,
			Info = 920395,
			Ability = {
				{
					Value = 200001,
					Num = 72,
				},
				{
					Value = 200008,
					Num = 12,
				},
			},
		},
		{
			Level = 2,
			Info = 920395,
			Ability = {
				{
					Value = 200001,
					Num = 144,
				},
				{
					Value = 200008,
					Num = 24,
				},
			},
		},
		{
			Level = 3,
			Info = 920395,
			Ability = {
				{
					Value = 200001,
					Num = 216,
				},
				{
					Value = 200008,
					Num = 36,
				},
			},
		},
		{
			Level = 4,
			Info = 920395,
			Ability = {
				{
					Value = 200001,
					Num = 288,
				},
				{
					Value = 200008,
					Num = 48,
				},
			},
		},
		{
			Level = 5,
			Info = 920395,
			Ability = {
				{
					Value = 200001,
					Num = 360,
				},
				{
					Value = 200008,
					Num = 60,
				},
			},
		},
		{
			Level = 6,
			Info = 920395,
			Ability = {
				{
					Value = 200001,
					Num = 432,
				},
				{
					Value = 200008,
					Num = 72,
				},
			},
		},
		{
			Level = 7,
			Info = 920395,
			Ability = {
				{
					Value = 200001,
					Num = 504,
				},
				{
					Value = 200008,
					Num = 84,
				},
			},
		},
		{
			Level = 8,
			Info = 920395,
			Ability = {
				{
					Value = 200001,
					Num = 576,
				},
				{
					Value = 200008,
					Num = 96,
				},
			},
			SkillList = {
				{
					Id = 100563,
					Value = -5,
				},
			},
		},
		{
			Level = 9,
			Info = 920395,
			Ability = {
				{
					Value = 200001,
					Num = 648,
				},
				{
					Value = 200008,
					Num = 108,
				},
			},
			SkillList = {
				{
					Id = 100563,
					Value = -5,
				},
			},
		},
		{
			Level = 10,
			Info = 920395,
			Ability = {
				{
					Value = 200001,
					Num = 720,
				},
				{
					Value = 200008,
					Num = 120,
				},
			},
			SkillList = {
				{
					Id = 100563,
					Value = -5,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id444] =
{
	Character = 220424,
	Rarity = 4,
	UpgradeId = 930034,
	LevelList = {
		{
			Level = 1,
			Info = 920396,
			Ability = {
				{
					Value = 200001,
					Num = 72,
				},
				{
					Value = 200005,
					Num = 9,
				},
			},
		},
		{
			Level = 2,
			Info = 920396,
			Ability = {
				{
					Value = 200001,
					Num = 144,
				},
				{
					Value = 200005,
					Num = 18,
				},
			},
		},
		{
			Level = 3,
			Info = 920396,
			Ability = {
				{
					Value = 200001,
					Num = 216,
				},
				{
					Value = 200005,
					Num = 27,
				},
			},
		},
		{
			Level = 4,
			Info = 920396,
			Ability = {
				{
					Value = 200001,
					Num = 288,
				},
				{
					Value = 200005,
					Num = 36,
				},
			},
		},
		{
			Level = 5,
			Info = 920396,
			Ability = {
				{
					Value = 200001,
					Num = 360,
				},
				{
					Value = 200005,
					Num = 45,
				},
			},
		},
		{
			Level = 6,
			Info = 920396,
			Ability = {
				{
					Value = 200001,
					Num = 432,
				},
				{
					Value = 200005,
					Num = 54,
				},
			},
		},
		{
			Level = 7,
			Info = 920396,
			Ability = {
				{
					Value = 200001,
					Num = 504,
				},
				{
					Value = 200005,
					Num = 63,
				},
			},
		},
		{
			Level = 8,
			Info = 920396,
			Ability = {
				{
					Value = 200001,
					Num = 576,
				},
				{
					Value = 200005,
					Num = 72,
				},
			},
			SkillList = {
				{
					Id = 100793,
					Value = 2,
				},
			},
		},
		{
			Level = 9,
			Info = 920396,
			Ability = {
				{
					Value = 200001,
					Num = 648,
				},
				{
					Value = 200005,
					Num = 81,
				},
			},
			SkillList = {
				{
					Id = 100793,
					Value = 2,
				},
			},
		},
		{
			Level = 10,
			Info = 920396,
			Ability = {
				{
					Value = 200001,
					Num = 720,
				},
				{
					Value = 200005,
					Num = 90,
				},
			},
			SkillList = {
				{
					Id = 100793,
					Value = 2,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id445] =
{
	Character = 220424,
	Rarity = 4,
	NeedChallenge = 145173,
	UpgradeId = 930035,
	LevelList = {
		{
			Level = 1,
			Info = 920397,
			Ability = {
				{
					Value = 200001,
					Num = 144,
				},
			},
		},
		{
			Level = 2,
			Info = 920397,
			Ability = {
				{
					Value = 200001,
					Num = 240,
				},
			},
		},
		{
			Level = 3,
			Info = 920397,
			Ability = {
				{
					Value = 200001,
					Num = 336,
				},
			},
		},
		{
			Level = 4,
			Info = 920397,
			Ability = {
				{
					Value = 200001,
					Num = 432,
				},
			},
		},
		{
			Level = 5,
			Info = 920397,
			Ability = {
				{
					Value = 200001,
					Num = 528,
				},
				{
					Value = 200003,
					Num = 25,
				},
			},
		},
		{
			Level = 6,
			Info = 920397,
			Ability = {
				{
					Value = 200001,
					Num = 624,
				},
				{
					Value = 200003,
					Num = 30,
				},
			},
		},
		{
			Level = 7,
			Info = 920397,
			Ability = {
				{
					Value = 200001,
					Num = 720,
				},
				{
					Value = 200003,
					Num = 35,
				},
			},
		},
		{
			Level = 8,
			Info = 920397,
			Ability = {
				{
					Value = 200001,
					Num = 816,
				},
				{
					Value = 200003,
					Num = 40,
				},
			},
			SkillList = {
				{
					Id = 101701,
					Value = 252,
				},
			},
		},
		{
			Level = 9,
			Info = 920397,
			Ability = {
				{
					Value = 200001,
					Num = 912,
				},
				{
					Value = 200003,
					Num = 45,
				},
			},
			SkillList = {
				{
					Id = 101701,
					Value = 252,
				},
			},
		},
		{
			Level = 10,
			Info = 920397,
			Ability = {
				{
					Value = 200001,
					Num = 1008,
				},
				{
					Value = 200003,
					Num = 50,
				},
			},
			SkillList = {
				{
					Id = 101701,
					Value = 252,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id446] =
{
	Character = 220425,
	Rarity = 4,
	UpgradeId = 930013,
	LevelList = {
		{
			Level = 1,
			Info = 920398,
			Ability = {
				{
					Value = 200002,
					Num = 60,
				},
				{
					Value = 200007,
					Num = 12,
				},
			},
		},
		{
			Level = 2,
			Info = 920398,
			Ability = {
				{
					Value = 200002,
					Num = 120,
				},
				{
					Value = 200007,
					Num = 24,
				},
			},
		},
		{
			Level = 3,
			Info = 920398,
			Ability = {
				{
					Value = 200002,
					Num = 180,
				},
				{
					Value = 200007,
					Num = 36,
				},
			},
		},
		{
			Level = 4,
			Info = 920398,
			Ability = {
				{
					Value = 200002,
					Num = 240,
				},
				{
					Value = 200007,
					Num = 48,
				},
			},
		},
		{
			Level = 5,
			Info = 920398,
			Ability = {
				{
					Value = 200002,
					Num = 300,
				},
				{
					Value = 200007,
					Num = 60,
				},
			},
		},
		{
			Level = 6,
			Info = 920398,
			Ability = {
				{
					Value = 200002,
					Num = 360,
				},
				{
					Value = 200007,
					Num = 72,
				},
			},
		},
		{
			Level = 7,
			Info = 920398,
			Ability = {
				{
					Value = 200002,
					Num = 420,
				},
				{
					Value = 200007,
					Num = 84,
				},
			},
		},
		{
			Level = 8,
			Info = 920398,
			Ability = {
				{
					Value = 200002,
					Num = 480,
				},
				{
					Value = 200007,
					Num = 96,
				},
			},
			SkillList = {
				{
					Id = 101738,
					Value = 15,
				},
			},
		},
		{
			Level = 9,
			Info = 920398,
			Ability = {
				{
					Value = 200002,
					Num = 540,
				},
				{
					Value = 200007,
					Num = 108,
				},
			},
			SkillList = {
				{
					Id = 101738,
					Value = 15,
				},
			},
		},
		{
			Level = 10,
			Info = 920398,
			Ability = {
				{
					Value = 200002,
					Num = 600,
				},
				{
					Value = 200007,
					Num = 120,
				},
			},
			SkillList = {
				{
					Id = 101738,
					Value = 15,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id447] =
{
	Character = 220425,
	Rarity = 4,
	UpgradeId = 930034,
	LevelList = {
		{
			Level = 1,
			Info = 920399,
			Ability = {
				{
					Value = 200001,
					Num = 69,
				},
				{
					Value = 200005,
					Num = 9,
				},
			},
		},
		{
			Level = 2,
			Info = 920399,
			Ability = {
				{
					Value = 200001,
					Num = 138,
				},
				{
					Value = 200005,
					Num = 18,
				},
			},
		},
		{
			Level = 3,
			Info = 920399,
			Ability = {
				{
					Value = 200001,
					Num = 207,
				},
				{
					Value = 200005,
					Num = 27,
				},
			},
		},
		{
			Level = 4,
			Info = 920399,
			Ability = {
				{
					Value = 200001,
					Num = 276,
				},
				{
					Value = 200005,
					Num = 36,
				},
			},
		},
		{
			Level = 5,
			Info = 920399,
			Ability = {
				{
					Value = 200001,
					Num = 345,
				},
				{
					Value = 200005,
					Num = 45,
				},
			},
		},
		{
			Level = 6,
			Info = 920399,
			Ability = {
				{
					Value = 200001,
					Num = 414,
				},
				{
					Value = 200005,
					Num = 54,
				},
			},
		},
		{
			Level = 7,
			Info = 920399,
			Ability = {
				{
					Value = 200001,
					Num = 483,
				},
				{
					Value = 200005,
					Num = 63,
				},
			},
		},
		{
			Level = 8,
			Info = 920399,
			Ability = {
				{
					Value = 200001,
					Num = 552,
				},
				{
					Value = 200005,
					Num = 72,
				},
			},
			SkillList = {
				{
					Id = 100561,
					Value = -5,
				},
			},
		},
		{
			Level = 9,
			Info = 920399,
			Ability = {
				{
					Value = 200001,
					Num = 621,
				},
				{
					Value = 200005,
					Num = 81,
				},
			},
			SkillList = {
				{
					Id = 100561,
					Value = -5,
				},
			},
		},
		{
			Level = 10,
			Info = 920399,
			Ability = {
				{
					Value = 200001,
					Num = 690,
				},
				{
					Value = 200005,
					Num = 90,
				},
			},
			SkillList = {
				{
					Id = 100561,
					Value = -5,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id448] =
{
	Character = 220425,
	Rarity = 4,
	NeedChallenge = 145174,
	UpgradeId = 930015,
	LevelList = {
		{
			Level = 1,
			Info = 920400,
			Ability = {
				{
					Value = 200002,
					Num = 120,
				},
			},
		},
		{
			Level = 2,
			Info = 920400,
			Ability = {
				{
					Value = 200002,
					Num = 200,
				},
			},
		},
		{
			Level = 3,
			Info = 920400,
			Ability = {
				{
					Value = 200002,
					Num = 280,
				},
			},
		},
		{
			Level = 4,
			Info = 920400,
			Ability = {
				{
					Value = 200002,
					Num = 360,
				},
			},
		},
		{
			Level = 5,
			Info = 920400,
			Ability = {
				{
					Value = 200002,
					Num = 440,
				},
				{
					Value = 200004,
					Num = 25,
				},
			},
		},
		{
			Level = 6,
			Info = 920400,
			Ability = {
				{
					Value = 200002,
					Num = 520,
				},
				{
					Value = 200004,
					Num = 30,
				},
			},
		},
		{
			Level = 7,
			Info = 920400,
			Ability = {
				{
					Value = 200002,
					Num = 600,
				},
				{
					Value = 200004,
					Num = 35,
				},
			},
		},
		{
			Level = 8,
			Info = 920400,
			Ability = {
				{
					Value = 200002,
					Num = 680,
				},
				{
					Value = 200004,
					Num = 40,
				},
			},
			SkillList = {
				{
					Id = 101733,
					Value = 90,
				},
			},
		},
		{
			Level = 9,
			Info = 920400,
			Ability = {
				{
					Value = 200002,
					Num = 760,
				},
				{
					Value = 200004,
					Num = 45,
				},
			},
			SkillList = {
				{
					Id = 101733,
					Value = 90,
				},
			},
		},
		{
			Level = 10,
			Info = 920400,
			Ability = {
				{
					Value = 200002,
					Num = 840,
				},
				{
					Value = 200004,
					Num = 50,
				},
			},
			SkillList = {
				{
					Id = 101733,
					Value = 90,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id449] =
{
	Character = 220429,
	Rarity = 5,
	UpgradeId = 930037,
	LevelList = {
		{
			Level = 1,
			Info = 920410,
			Ability = {
				{
					Value = 200001,
					Num = 84,
				},
				{
					Value = 200006,
					Num = 12,
				},
			},
		},
		{
			Level = 2,
			Info = 920410,
			Ability = {
				{
					Value = 200001,
					Num = 168,
				},
				{
					Value = 200006,
					Num = 24,
				},
			},
		},
		{
			Level = 3,
			Info = 920410,
			Ability = {
				{
					Value = 200001,
					Num = 252,
				},
				{
					Value = 200006,
					Num = 36,
				},
			},
		},
		{
			Level = 4,
			Info = 920410,
			Ability = {
				{
					Value = 200001,
					Num = 336,
				},
				{
					Value = 200006,
					Num = 48,
				},
			},
		},
		{
			Level = 5,
			Info = 920410,
			Ability = {
				{
					Value = 200001,
					Num = 420,
				},
				{
					Value = 200006,
					Num = 60,
				},
			},
		},
		{
			Level = 6,
			Info = 920410,
			Ability = {
				{
					Value = 200001,
					Num = 504,
				},
				{
					Value = 200006,
					Num = 72,
				},
			},
		},
		{
			Level = 7,
			Info = 920410,
			Ability = {
				{
					Value = 200001,
					Num = 588,
				},
				{
					Value = 200006,
					Num = 84,
				},
			},
		},
		{
			Level = 8,
			Info = 920410,
			Ability = {
				{
					Value = 200001,
					Num = 672,
				},
				{
					Value = 200006,
					Num = 96,
				},
			},
			SkillList = {
				{
					Id = 100562,
					Value = -5,
				},
			},
		},
		{
			Level = 9,
			Info = 920410,
			Ability = {
				{
					Value = 200001,
					Num = 756,
				},
				{
					Value = 200006,
					Num = 108,
				},
			},
			SkillList = {
				{
					Id = 100562,
					Value = -5,
				},
			},
		},
		{
			Level = 10,
			Info = 920410,
			Ability = {
				{
					Value = 200001,
					Num = 840,
				},
				{
					Value = 200006,
					Num = 120,
				},
			},
			SkillList = {
				{
					Id = 100562,
					Value = -5,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id450] =
{
	Character = 220429,
	Rarity = 5,
	UpgradeId = 930018,
	LevelList = {
		{
			Level = 1,
			Info = 920411,
			Ability = {
				{
					Value = 200002,
					Num = 66,
				},
				{
					Value = 200008,
					Num = 9,
				},
			},
		},
		{
			Level = 2,
			Info = 920411,
			Ability = {
				{
					Value = 200002,
					Num = 132,
				},
				{
					Value = 200008,
					Num = 18,
				},
			},
		},
		{
			Level = 3,
			Info = 920411,
			Ability = {
				{
					Value = 200002,
					Num = 198,
				},
				{
					Value = 200008,
					Num = 27,
				},
			},
		},
		{
			Level = 4,
			Info = 920411,
			Ability = {
				{
					Value = 200002,
					Num = 264,
				},
				{
					Value = 200008,
					Num = 36,
				},
			},
		},
		{
			Level = 5,
			Info = 920411,
			Ability = {
				{
					Value = 200002,
					Num = 330,
				},
				{
					Value = 200008,
					Num = 45,
				},
			},
		},
		{
			Level = 6,
			Info = 920411,
			Ability = {
				{
					Value = 200002,
					Num = 396,
				},
				{
					Value = 200008,
					Num = 54,
				},
			},
		},
		{
			Level = 7,
			Info = 920411,
			Ability = {
				{
					Value = 200002,
					Num = 462,
				},
				{
					Value = 200008,
					Num = 63,
				},
			},
		},
		{
			Level = 8,
			Info = 920411,
			Ability = {
				{
					Value = 200002,
					Num = 528,
				},
				{
					Value = 200008,
					Num = 72,
				},
			},
			SkillList = {
				{
					Id = 100667,
					Value = 2,
				},
			},
		},
		{
			Level = 9,
			Info = 920411,
			Ability = {
				{
					Value = 200002,
					Num = 594,
				},
				{
					Value = 200008,
					Num = 81,
				},
			},
			SkillList = {
				{
					Id = 100667,
					Value = 2,
				},
			},
		},
		{
			Level = 10,
			Info = 920411,
			Ability = {
				{
					Value = 200002,
					Num = 660,
				},
				{
					Value = 200008,
					Num = 90,
				},
			},
			SkillList = {
				{
					Id = 100667,
					Value = 2,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id451] =
{
	Character = 220429,
	Rarity = 5,
	NeedChallenge = 145175,
	UpgradeId = 930019,
	LevelList = {
		{
			Level = 1,
			Info = 920412,
			Ability = {
				{
					Value = 200002,
					Num = 132,
				},
			},
		},
		{
			Level = 2,
			Info = 920412,
			Ability = {
				{
					Value = 200002,
					Num = 220,
				},
			},
		},
		{
			Level = 3,
			Info = 920412,
			Ability = {
				{
					Value = 200002,
					Num = 308,
				},
			},
		},
		{
			Level = 4,
			Info = 920412,
			Ability = {
				{
					Value = 200002,
					Num = 396,
				},
			},
		},
		{
			Level = 5,
			Info = 920412,
			Ability = {
				{
					Value = 200002,
					Num = 484,
				},
				{
					Value = 200004,
					Num = 25,
				},
			},
		},
		{
			Level = 6,
			Info = 920412,
			Ability = {
				{
					Value = 200002,
					Num = 572,
				},
				{
					Value = 200004,
					Num = 30,
				},
			},
		},
		{
			Level = 7,
			Info = 920412,
			Ability = {
				{
					Value = 200002,
					Num = 660,
				},
				{
					Value = 200004,
					Num = 35,
				},
			},
		},
		{
			Level = 8,
			Info = 920412,
			Ability = {
				{
					Value = 200002,
					Num = 748,
				},
				{
					Value = 200004,
					Num = 40,
				},
			},
			SkillList = {
				{
					Id = 100605,
					Value = 36,
				},
			},
		},
		{
			Level = 9,
			Info = 920412,
			Ability = {
				{
					Value = 200002,
					Num = 836,
				},
				{
					Value = 200004,
					Num = 45,
				},
			},
			SkillList = {
				{
					Id = 100605,
					Value = 36,
				},
			},
		},
		{
			Level = 10,
			Info = 920412,
			Ability = {
				{
					Value = 200002,
					Num = 924,
				},
				{
					Value = 200004,
					Num = 50,
				},
			},
			SkillList = {
				{
					Id = 100605,
					Value = 36,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id452] =
{
	Character = 220429,
	Rarity = 5,
	NeedChallenge = 145176,
	UpgradeId = 930020,
	LevelList = {
		{
			Level = 1,
			Info = 920413,
			Ability = {
				{
					Value = 200002,
					Num = 198,
				},
			},
		},
		{
			Level = 2,
			Info = 920413,
			Ability = {
				{
					Value = 200002,
					Num = 308,
				},
			},
		},
		{
			Level = 3,
			Info = 920413,
			Ability = {
				{
					Value = 200002,
					Num = 418,
				},
			},
		},
		{
			Level = 4,
			Info = 920413,
			Ability = {
				{
					Value = 200002,
					Num = 528,
				},
			},
		},
		{
			Level = 5,
			Info = 920413,
			Ability = {
				{
					Value = 200002,
					Num = 638,
				},
				{
					Value = 200004,
					Num = 25,
				},
			},
		},
		{
			Level = 6,
			Info = 920413,
			Ability = {
				{
					Value = 200002,
					Num = 748,
				},
				{
					Value = 200004,
					Num = 30,
				},
			},
		},
		{
			Level = 7,
			Info = 920413,
			Ability = {
				{
					Value = 200002,
					Num = 858,
				},
				{
					Value = 200004,
					Num = 35,
				},
			},
		},
		{
			Level = 8,
			Info = 920413,
			Ability = {
				{
					Value = 200002,
					Num = 968,
				},
				{
					Value = 200004,
					Num = 40,
				},
			},
			SkillList = {
				{
					Id = 101765,
					Value = 12,
				},
			},
		},
		{
			Level = 9,
			Info = 920413,
			Ability = {
				{
					Value = 200002,
					Num = 1078,
				},
				{
					Value = 200004,
					Num = 45,
				},
			},
			SkillList = {
				{
					Id = 101765,
					Value = 12,
				},
			},
		},
		{
			Level = 10,
			Info = 920413,
			Ability = {
				{
					Value = 200002,
					Num = 1188,
				},
				{
					Value = 200004,
					Num = 50,
				},
			},
			SkillList = {
				{
					Id = 101765,
					Value = 12,
				},
			},
		},
	},
}
