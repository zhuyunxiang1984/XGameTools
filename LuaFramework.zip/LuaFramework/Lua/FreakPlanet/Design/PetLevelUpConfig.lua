PetLevelUpConfig ={};
PetLevelUpID = 
{
	Id001 = 910001,
	Id002 = 910002,
	Id003 = 910003,
	Id004 = 910004,
	Id005 = 910005,
	Id101 = 910101,
	Id102 = 910102,
	Id103 = 910103,
	Id104 = 910104,
	Id105 = 910105,
	Id201 = 910201,
	Id202 = 910202,
	Id203 = 910203,
	Id204 = 910204,
	Id205 = 910205,
	Id1001 = 911001,
	Id1002 = 911002,
}
PetLevelUpConfig[PetLevelUpID.Id001] =
{
	Id = 1,
	LevelUp = 
	{
		9,49,129,249,
	},
}
PetLevelUpConfig[PetLevelUpID.Id002] =
{
	Id = 2,
	LevelUp = 
	{
		9,39,99,189,
	},
}
PetLevelUpConfig[PetLevelUpID.Id003] =
{
	Id = 3,
	LevelUp = 
	{
		4,19,49,99,
	},
}
PetLevelUpConfig[PetLevelUpID.Id004] =
{
	Id = 4,
	LevelUp = 
	{
		2,9,19,49,
	},
}
PetLevelUpConfig[PetLevelUpID.Id005] =
{
	Id = 5,
	LevelUp = 
	{
		2,9,19,149,
	},
}
PetLevelUpConfig[PetLevelUpID.Id101] =
{
	Id = 101,
	LevelUp = 
	{
		2,14,29,49,
	},
}
PetLevelUpConfig[PetLevelUpID.Id102] =
{
	Id = 102,
	LevelUp = 
	{
		2,14,29,49,
	},
}
PetLevelUpConfig[PetLevelUpID.Id103] =
{
	Id = 103,
	LevelUp = 
	{
		2,14,29,49,
	},
}
PetLevelUpConfig[PetLevelUpID.Id104] =
{
	Id = 104,
	LevelUp = 
	{
		1,9,19,29,
	},
}
PetLevelUpConfig[PetLevelUpID.Id105] =
{
	Id = 105,
	LevelUp = 
	{
		1,9,19,29,
	},
}
PetLevelUpConfig[PetLevelUpID.Id201] =
{
	Id = 201,
	LevelUp = 
	{
		9,39,69,99,
	},
}
PetLevelUpConfig[PetLevelUpID.Id202] =
{
	Id = 202,
	LevelUp = 
	{
		9,29,49,69,
	},
}
PetLevelUpConfig[PetLevelUpID.Id203] =
{
	Id = 203,
	LevelUp = 
	{
		4,14,29,44,
	},
}
PetLevelUpConfig[PetLevelUpID.Id204] =
{
	Id = 204,
	LevelUp = 
	{
		2,7,14,24,
	},
}
PetLevelUpConfig[PetLevelUpID.Id205] =
{
	Id = 205,
	LevelUp = 
	{
		1,9,19,29,
	},
}
PetLevelUpConfig[PetLevelUpID.Id1001] =
{
	Id = 1001,
	LevelUp = 
	{
		1,2,3,4,5,6,7,8,9,10,11,12,
	},
}
PetLevelUpConfig[PetLevelUpID.Id1002] =
{
	Id = 1002,
	LevelUp = 
	{
		6,13,27,48,
	},
}

