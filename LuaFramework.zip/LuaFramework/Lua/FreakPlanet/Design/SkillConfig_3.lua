
SkillConfig[SkillID.Id3001] =
{
	Id = 3001,
	Name = "探索金币+",
	Desc = "探索金币数量 +{Value}%",
	Dialog = "会找到很多金币的喵~",
	EffectModule = EffectModule.ExploreDrop,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "GoodsDropNumber",
		EffectValue = 1,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
}
SkillConfig[SkillID.Id3002] =
{
	Id = 3002,
	Name = "躲避强敌",
	Desc = "强敌出现概率 -{Value}%",
	Dialog = "喵！危险的地方不去喵！",
	EffectModule = EffectModule.ExploreEnemy,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "EnemyWeight",
		Chance = 100,
		CompareFightPower = 1,
		EnemyWeightCondition = {
			CompareWin = 2,
		},
		CalculateType = CalculateType.Percent,
	},
}
SkillConfig[SkillID.Id3003] =
{
	Id = 3003,
	Name = "忍耐+",
	Desc = "忍耐 +{Value}",
	Dialog = "躲我后面就没事啦！",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200003,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id3004] =
{
	Id = 3004,
	Name = "暴击+",
	Desc = "暴击 +{Value}",
	Dialog = "百步穿羊！",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200004,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id3005] =
{
	Id = 3005,
	Name = "风元素敌人战力-",
	Desc = "风元素敌人战力 -{Value}%",
	Dialog = "我给大家讲讲怎么打猎~",
	EffectModule = EffectModule.ExploreEnemy,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "EnemyFightPower",
		Element = 210003,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
}
SkillConfig[SkillID.Id3006] =
{
	Id = 3006,
	Name = "风元素敌人掉落概率+",
	Desc = "风元素敌人道具掉落率 +{Value}%",
	EffectModule = EffectModule.ExploreDrop,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "EnemyDropChance",
		Element = 210003,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id3007] =
{
	Id = 3007,
	Name = "探索时间-",
	Desc = "探索等待时间 -{Value}%",
	Dialog = "俺知道一条近路呐！",
	EffectModule = EffectModule.ExploreTime,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "ExploreTime",
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
}
SkillConfig[SkillID.Id3008] =
{
	Id = 3008,
	Name = "敌人战力-",
	Desc = "敌人战力 -{Value}%",
	Dialog = "让本王看看这里的运作情况",
	EffectModule = EffectModule.ExploreEnemy,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "EnemyFightPower",
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
}
SkillConfig[SkillID.Id3009] =
{
	Id = 3009,
	Name = "攻击+",
	Desc = "攻击 +{Value}",
	Dialog = "知识就是力量~",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200002,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id3010] =
{
	Id = 3010,
	Name = "全队智力+",
	Desc = "全队智力 +{Value}",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Team,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200008,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id3011] =
{
	Id = 3011,
	Name = "打工金币+",
	Desc = "打工金币数量 +{Value}%",
	Dialog = "老板，让我加班吧！",
	EffectModule = EffectModule.WorkShop,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "WorkShopGoodsNumber",
		EffectValue = 1,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
}
SkillConfig[SkillID.Id3012] =
{
	Id = 3012,
	Name = "全队忍耐+",
	Desc = "全队忍耐 +{Value}",
	Dialog = "大家都要保护我啊！",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Team,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200003,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id3013] =
{
	Id = 3013,
	Name = "亲和+",
	Desc = "亲和 +{Value}",
	Dialog = "上班也要注意休息哟。",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200006,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id3014] =
{
	Id = 3014,
	Name = "升级消耗+",
	Desc = "升级要求的金币 -{Value}%",
	EffectModule = EffectModule.CharacterLevelUp,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "CharacterLevelUpCost",
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
}
SkillConfig[SkillID.Id3015] =
{
	Id = 3015,
	Name = "暗元素敌人战力-",
	Desc = "暗元素敌人战力 -{Value}%",
	Dialog = "别藏了！我看见你了！",
	EffectModule = EffectModule.ExploreEnemy,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "EnemyFightPower",
		Element = 210005,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
}
SkillConfig[SkillID.Id3016] =
{
	Id = 3016,
	Name = "升级消耗+",
	Desc = "升级要求的金币 -{Value}%",
	EffectModule = EffectModule.CharacterLevelUp,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "CharacterLevelUpCost",
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
}
SkillConfig[SkillID.Id3017] =
{
	Id = 3017,
	Name = "左右忍耐+",
	Desc = "自身及左右队员忍耐 +{Value}",
	Dialog = "再往前走就是危险地区了！",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.RelativePosition,
		PositionValue = 
		{
			1,0,-1,
		},
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200003,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id3018] =
{
	Id = 3018,
	Name = "全队攻击+",
	Desc = "全队攻击 +{Value}",
	Dialog = "热身运动都做了吗？",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Team,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200002,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id3019] =
{
	Id = 3019,
	Name = "全队力气+",
	Desc = "全队力气 +{Value}",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Team,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200007,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id3020] =
{
	Id = 3020,
	Name = "前方队员忍耐+",
	Desc = "自身及前身2名队员忍耐 +{Value}",
	Dialog = "有需要修理的装备吗？",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.RelativePosition,
		PositionValue = 
		{
			0,-1,-2,
		},
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200003,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id3021] =
{
	Id = 3021,
	Name = "探索金币+",
	Desc = "探索金币数量 +{Value}%",
	Dialog = "不知道这里的怪物买不买药水？",
	EffectModule = EffectModule.ExploreDrop,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "GoodsDropNumber",
		EffectValue = 1,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
}
SkillConfig[SkillID.Id3022] =
{
	Id = 3022,
	Name = "全队生命+",
	Desc = "全队生命 +{Value}",
	Dialog = "我给大家唱个歌~",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Team,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200001,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id3023] =
{
	Id = 3023,
	Name = "全队亲和+",
	Desc = "全队亲和 +{Value}",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Team,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200006,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id3024] =
{
	Id = 3024,
	Name = "每个火元素提供攻击+",
	Desc = "攻击 +{Value}",
	Dialog = "按住那个怪，我要开枪了！",
	EffectModule = EffectModule.BuildTeam,
	MultiCount = true,
	EffectCondition = {
		Element = 210002,
	},
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200002,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id3025] =
{
	Id = 3025,
	Name = "搜刮精英",
	Desc = "紫色及以上品质敌人道具掉落率 +{Value}%",
	Dialog = "被我盯上的目标一定逃不掉",
	EffectModule = EffectModule.ExploreDrop,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "EnemyDropChance",
		Rarity = 3,
		RarityOp = 0,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id3026] =
{
	Id = 3026,
	Name = "每个暗元素提供全队攻击+",
	Desc = "攻击 +{Value}",
	Dialog = "天黑请闭眼！",
	EffectModule = EffectModule.BuildTeam,
	MultiCount = true,
	EffectCondition = {
		Element = 210005,
	},
	EffectRange = {
		EffectScope = EffectScope.Team,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200002,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id3027] =
{
	Id = 3027,
	Name = "全队忍耐+",
	Desc = "全队忍耐 +{Value}",
	Dialog = "加点错误日志就知道问题在哪了！",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Team,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200003,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id3028] =
{
	Id = 3028,
	Name = "全队智力+",
	Desc = "全队智力 +{Value}",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Team,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200008,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id3029] =
{
	Id = 3029,
	Name = "全队暴击+",
	Desc = "全队暴击 +{Value}",
	Dialog = "刚做完的20个场景不要了？！",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Team,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200004,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id3030] =
{
	Id = 3030,
	Name = "全队技巧+",
	Desc = "全队技巧 +{Value}",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Team,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200005,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id3031] =
{
	Id = 3031,
	Name = "全队生命+",
	Desc = "全队生命 +{Value}",
	Dialog = "大家都要努力噢~",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Team,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200001,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id3032] =
{
	Id = 3032,
	Name = "全队亲和+",
	Desc = "全队亲和 +{Value}",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Team,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200006,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id3033] =
{
	Id = 3033,
	Name = "防御型队员攻击+",
	Desc = "防御型队员攻击 +{Value}",
	Dialog = "让我们冲破一切阻碍！",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Team,
		Tag = 
		{
			561207,
		},
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200002,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id3034] =
{
	Id = 3034,
	Name = "女队员生命+",
	Desc = "女队员生命 +{Value}",
	Dialog = "要骑在我背上吗？",
	EffectModule = EffectModule.BuildTeam,
	EffectCondition = {
		Tag = 
		{
			561703,
		},
	},
	EffectRange = {
		EffectScope = EffectScope.Team,
		Tag = 
		{
			561703,
		},
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200001,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id3035] =
{
	Id = 3035,
	Name = "全队生命+",
	Desc = "全队生命 +{Value}",
	Dialog = "来福，出去散步啦~",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Team,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200001,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id3036] =
{
	Id = 3036,
	Name = "全队忍耐+",
	Desc = "全队忍耐 +{Value}",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Team,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200003,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id3037] =
{
	Id = 3037,
	Name = "每个暗元素队员提供生命+",
	Desc = "每个暗元素队员提供生命 +{Value}",
	Dialog = "众卿随朕出征！",
	EffectModule = EffectModule.BuildTeam,
	MultiCount = true,
	EffectCondition = {
		Element = 210005,
	},
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200001,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id3038] =
{
	Id = 3038,
	Name = "每个暗元素队员提供攻击+",
	Desc = "每个暗元素队员提供攻击 +{Value}",
	EffectModule = EffectModule.BuildTeam,
	MultiCount = true,
	EffectCondition = {
		Element = 210005,
	},
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200002,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id3039] =
{
	Id = 3039,
	Name = "全队生命+",
	Desc = "全队生命 +{Value}",
	Dialog = "公主们的健康由我守护！",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Team,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200001,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id3040] =
{
	Id = 3040,
	Name = "全队亲和+",
	Desc = "全队亲和 +{Value}",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Team,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200006,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id3041] =
{
	Id = 3041,
	Name = "全队暴击+",
	Desc = "全队暴击 +{Value}",
	Dialog = "公主们的美丽由我守护！",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Team,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200004,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id3042] =
{
	Id = 3042,
	Name = "全队智力+",
	Desc = "全队智力 +{Value}",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Team,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200008,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id3043] =
{
	Id = 3043,
	Name = "全队忍耐+",
	Desc = "全队忍耐 +{Value}",
	Dialog = "公主们的高贵由我守护！",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Team,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200003,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id3044] =
{
	Id = 3044,
	Name = "全队技巧+",
	Desc = "全队技巧 +{Value}",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Team,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200005,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id3045] =
{
	Id = 3045,
	Name = "全队攻击+",
	Desc = "全队攻击 +{Value}",
	Dialog = "公主们的快乐由我守护！",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Team,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200002,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id3046] =
{
	Id = 3046,
	Name = "全队力气+",
	Desc = "全队力气 +{Value}",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Team,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200007,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id3047] =
{
	Id = 3047,
	Name = "每个糖豆组队员提供全队生命+",
	Desc = "全队生命 +{Value}",
	Dialog = "彩虹糖小红报到！",
	EffectModule = EffectModule.BuildTeam,
	MultiCount = true,
	EffectCondition = {
		Tag = 
		{
			562909,
		},
	},
	EffectRange = {
		EffectScope = EffectScope.Team,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200001,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id3048] =
{
	Id = 3048,
	Name = "每个糖豆组队员提供全队技巧+",
	Desc = "全队技巧 +{Value}",
	EffectModule = EffectModule.BuildTeam,
	MultiCount = true,
	EffectCondition = {
		Tag = 
		{
			562909,
		},
	},
	EffectRange = {
		EffectScope = EffectScope.Team,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200005,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id3049] =
{
	Id = 3049,
	Name = "每个糖豆组队员提供全队生命+",
	Desc = "全队生命 +{Value}",
	Dialog = "彩虹糖小橙报到！",
	EffectModule = EffectModule.BuildTeam,
	MultiCount = true,
	EffectCondition = {
		Tag = 
		{
			562909,
		},
	},
	EffectRange = {
		EffectScope = EffectScope.Team,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200001,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id3050] =
{
	Id = 3050,
	Name = "每个糖豆组队员提供全队亲和+",
	Desc = "全队亲和 +{Value}",
	EffectModule = EffectModule.BuildTeam,
	MultiCount = true,
	EffectCondition = {
		Tag = 
		{
			562909,
		},
	},
	EffectRange = {
		EffectScope = EffectScope.Team,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200006,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id3051] =
{
	Id = 3051,
	Name = "每个糖豆组队员提供全队忍耐+",
	Desc = "全队忍耐 +{Value}",
	Dialog = "彩虹糖小黄报到！",
	EffectModule = EffectModule.BuildTeam,
	MultiCount = true,
	EffectCondition = {
		Tag = 
		{
			562909,
		},
	},
	EffectRange = {
		EffectScope = EffectScope.Team,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200003,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id3052] =
{
	Id = 3052,
	Name = "每个糖豆组队员提供全队技巧+",
	Desc = "全队技巧 +{Value}",
	EffectModule = EffectModule.BuildTeam,
	MultiCount = true,
	EffectCondition = {
		Tag = 
		{
			562909,
		},
	},
	EffectRange = {
		EffectScope = EffectScope.Team,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200005,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id3053] =
{
	Id = 3053,
	Name = "每个糖豆组队员提供全队忍耐+",
	Desc = "全队忍耐 +{Value}",
	Dialog = "彩虹糖小绿报到！",
	EffectModule = EffectModule.BuildTeam,
	MultiCount = true,
	EffectCondition = {
		Tag = 
		{
			562909,
		},
	},
	EffectRange = {
		EffectScope = EffectScope.Team,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200003,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id3054] =
{
	Id = 3054,
	Name = "每个糖豆组队员提供全队亲和+",
	Desc = "全队亲和 +{Value}",
	EffectModule = EffectModule.BuildTeam,
	MultiCount = true,
	EffectCondition = {
		Tag = 
		{
			562909,
		},
	},
	EffectRange = {
		EffectScope = EffectScope.Team,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200006,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id3055] =
{
	Id = 3055,
	Name = "每个糖豆组队员提供全队攻击+",
	Desc = "全队攻击 +{Value}",
	Dialog = "彩虹糖小青报到！",
	EffectModule = EffectModule.BuildTeam,
	MultiCount = true,
	EffectCondition = {
		Tag = 
		{
			562909,
		},
	},
	EffectRange = {
		EffectScope = EffectScope.Team,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200002,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id3056] =
{
	Id = 3056,
	Name = "每个糖豆组队员提供全队技巧+",
	Desc = "全队技巧 +{Value}",
	EffectModule = EffectModule.BuildTeam,
	MultiCount = true,
	EffectCondition = {
		Tag = 
		{
			562909,
		},
	},
	EffectRange = {
		EffectScope = EffectScope.Team,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200005,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id3057] =
{
	Id = 3057,
	Name = "每个糖豆组队员提供全队攻击+",
	Desc = "全队攻击 +{Value}",
	Dialog = "彩虹糖小蓝报到！",
	EffectModule = EffectModule.BuildTeam,
	MultiCount = true,
	EffectCondition = {
		Tag = 
		{
			562909,
		},
	},
	EffectRange = {
		EffectScope = EffectScope.Team,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200002,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id3058] =
{
	Id = 3058,
	Name = "每个糖豆组队员提供全队亲和+",
	Desc = "全队亲和 +{Value}",
	EffectModule = EffectModule.BuildTeam,
	MultiCount = true,
	EffectCondition = {
		Tag = 
		{
			562909,
		},
	},
	EffectRange = {
		EffectScope = EffectScope.Team,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200006,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id3059] =
{
	Id = 3059,
	Name = "每个糖豆组队员提供全队亲和+",
	Desc = "全队亲和 +{Value}",
	Dialog = "彩虹糖小紫报到！",
	EffectModule = EffectModule.BuildTeam,
	MultiCount = true,
	EffectCondition = {
		Tag = 
		{
			562909,
		},
	},
	EffectRange = {
		EffectScope = EffectScope.Team,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200006,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id3060] =
{
	Id = 3060,
	Name = "每个糖豆组队员提供全队技巧+",
	Desc = "全队技巧 +{Value}",
	EffectModule = EffectModule.BuildTeam,
	MultiCount = true,
	EffectCondition = {
		Tag = 
		{
			562909,
		},
	},
	EffectRange = {
		EffectScope = EffectScope.Team,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200005,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id3061] =
{
	Id = 3061,
	Name = "敌人战力-",
	Desc = "敌人战力 -{Value}%",
	Dialog = "想喝就喝，不喝就滚！",
	EffectModule = EffectModule.ExploreEnemy,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "EnemyFightPower",
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id3062] =
{
	Id = 3062,
	Name = "全队战力+",
	Desc = "全队战力 +{Value}%",
	Dialog = "让我们一起努力吧！",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Team,
	},
	Effect = {
		EffectAttribute = "FightPower",
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id3063] =
{
	Id = 3063,
	Name = "每个王子组队员使攻击+",
	Desc = "攻击 +{Value}",
	Dialog = "王子们在哪里呢？",
	EffectModule = EffectModule.BuildTeam,
	MultiCount = true,
	EffectCondition = {
		Tag = 
		{
			562907,
		},
	},
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200002,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id3064] =
{
	Id = 3064,
	Name = "每个王子组队员使亲和+",
	Desc = "亲和 +{Value}",
	EffectModule = EffectModule.BuildTeam,
	MultiCount = true,
	EffectCondition = {
		Tag = 
		{
			562907,
		},
	},
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200006,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id3065] =
{
	Id = 3065,
	Name = "每个王子组队员使攻击+",
	Desc = "攻击 +{Value}",
	Dialog = "我能成为王子的新娘吗？",
	EffectModule = EffectModule.BuildTeam,
	MultiCount = true,
	EffectCondition = {
		Tag = 
		{
			562907,
		},
	},
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200002,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id3066] =
{
	Id = 3066,
	Name = "每个王子组队员使技巧+",
	Desc = "技巧 +{Value}",
	EffectModule = EffectModule.BuildTeam,
	MultiCount = true,
	EffectCondition = {
		Tag = 
		{
			562907,
		},
	},
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200005,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id3067] =
{
	Id = 3067,
	Name = "左右暴击+",
	Desc = "自身及左右队员暴击 +{Value}",
	Dialog = "饿了就吃华夫饼噢~",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.RelativePosition,
		PositionValue = 
		{
			1,0,-1,
		},
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200004,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id3068] =
{
	Id = 3068,
	Name = "左右亲和+",
	Desc = "自身及左右队员亲和 +{Value}",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.RelativePosition,
		PositionValue = 
		{
			1,0,-1,
		},
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200006,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id3069] =
{
	Id = 3069,
	Name = "左右攻击+",
	Desc = "自身及左右队员攻击 +{Value}",
	Dialog = "饿了就吃布丁噢~",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.RelativePosition,
		PositionValue = 
		{
			1,0,-1,
		},
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200002,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id3070] =
{
	Id = 3070,
	Name = "全队亲和+",
	Desc = "自身及左右队员亲和 +{Value}",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.RelativePosition,
		PositionValue = 
		{
			1,0,-1,
		},
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200006,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id3071] =
{
	Id = 3071,
	Name = "左右攻击+",
	Desc = "自身及左右队员攻击 +{Value}",
	Dialog = "饿了就吃松饼噢~",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.RelativePosition,
		PositionValue = 
		{
			1,0,-1,
		},
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200002,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id3072] =
{
	Id = 3072,
	Name = "左右智力+",
	Desc = "自身及左右队员智力 +{Value}",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.RelativePosition,
		PositionValue = 
		{
			1,0,-1,
		},
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200008,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id3073] =
{
	Id = 3073,
	Name = "自身及汽水王子生命+",
	Desc = "自身及汽水王子生命 +{Value}",
	Dialog = "我的汽水王子呢？",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Team,
		Characters = 
		{
			220122,
			220102,
		},
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200001,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id3074] =
{
	Id = 3074,
	Name = "自身及汽水王子亲和+",
	Desc = "自身及汽水王子亲和 +{Value}",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Team,
		Characters = 
		{
			220122,
			220102,
		},
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200006,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id3075] =
{
	Id = 3075,
	Name = "自身及奶茶王子暴击+",
	Desc = "自身及奶茶王子暴击 +{Value}",
	Dialog = "啊，想喝奶茶了~",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Team,
		Characters = 
		{
			220123,
			220101,
		},
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200004,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id3076] =
{
	Id = 3076,
	Name = "自身及奶茶王子智力+",
	Desc = "自身及奶茶王子智力 +{Value}",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Team,
		Characters = 
		{
			220123,
			220101,
		},
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200008,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id3077] =
{
	Id = 3077,
	Name = "自身及啤酒王子攻击+",
	Desc = "自身及啤酒王子攻击 +{Value}",
	Dialog = "好，去找啤酒王子吧！",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Team,
		Characters = 
		{
			220124,
			220104,
		},
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200002,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id3078] =
{
	Id = 3078,
	Name = "自身及啤酒王子力气+",
	Desc = "自身及啤酒王子力气 +{Value}",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Team,
		Characters = 
		{
			220124,
			220104,
		},
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200007,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id3079] =
{
	Id = 3079,
	Name = "自身及可乐王子忍耐+",
	Desc = "自身及可乐王子忍耐 +{Value}",
	Dialog = "可乐王子在想我吗？",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Team,
		Characters = 
		{
			220125,
			220103,
		},
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200003,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id3080] =
{
	Id = 3080,
	Name = "自身及可乐王子技巧+",
	Desc = "自身及可乐王子技巧 +{Value}",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Team,
		Characters = 
		{
			220125,
			220103,
		},
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200005,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id3081] =
{
	Id = 3081,
	Name = "风元素敌人战力-",
	Desc = "风元素敌人战力 -{Value}%",
	Dialog = "你能抵挡培根的美味嘛？",
	EffectModule = EffectModule.ExploreEnemy,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "EnemyFightPower",
		Element = 210003,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
}
SkillConfig[SkillID.Id3082] =
{
	Id = 3082,
	Name = "风元素敌人掉落概率+",
	Desc = "风元素敌人道具掉落率 +{Value}%",
	EffectModule = EffectModule.ExploreDrop,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "EnemyDropChance",
		Element = 210003,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id3083] =
{
	Id = 3083,
	Name = "火元素敌人战力-",
	Desc = "火元素敌人战力 -{Value}%",
	Dialog = "苦涩的甜味才更迷人~",
	EffectModule = EffectModule.ExploreEnemy,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "EnemyFightPower",
		Element = 210002,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
}
SkillConfig[SkillID.Id3084] =
{
	Id = 3084,
	Name = "火元素敌人掉落概率+",
	Desc = "火元素敌人道具掉落率 +{Value}%",
	EffectModule = EffectModule.ExploreDrop,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "EnemyDropChance",
		Element = 210002,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id3085] =
{
	Id = 3085,
	Name = "水元素敌人战力-",
	Desc = "水元素敌人战力 -{Value}%",
	Dialog = "站住！别再靠近我！",
	EffectModule = EffectModule.ExploreEnemy,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "EnemyFightPower",
		Element = 210001,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
}
SkillConfig[SkillID.Id3086] =
{
	Id = 3086,
	Name = "水元素敌人掉落概率+",
	Desc = "水元素敌人道具掉落率 +{Value}%",
	EffectModule = EffectModule.ExploreDrop,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "EnemyDropChance",
		Element = 210001,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id3087] =
{
	Id = 3087,
	Name = "火元素队员攻击+",
	Desc = "火元素队员攻击 +{Value}",
	Dialog = "热乎乎的汉堡来啦~",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Team,
		Element = 210002,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200002,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id3088] =
{
	Id = 3088,
	Name = "火元素队员力气+",
	Desc = "火元素队员力气 +{Value}",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Team,
		Element = 210002,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200007,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id3089] =
{
	Id = 3089,
	Name = "火元素队员生命+",
	Desc = "火元素队员生命 +{Value}",
	Dialog = "香喷喷的热狗来啦~",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Team,
		Element = 210002,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200001,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id3090] =
{
	Id = 3090,
	Name = "火元素队员亲和+",
	Desc = "火元素队员亲和 +{Value}",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Team,
		Element = 210002,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200006,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id3091] =
{
	Id = 3091,
	Name = "每个美食星队员提供全队忍耐+",
	Desc = "美食星队员提供全队忍耐 +{Value}",
	Dialog = "每种调料都放点应该不错吧？",
	EffectModule = EffectModule.BuildTeam,
	MultiCount = true,
	EffectCondition = {
		Tag = 
		{
			560104,
		},
	},
	EffectRange = {
		EffectScope = EffectScope.Team,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200003,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id3092] =
{
	Id = 3092,
	Name = "每个美食星队员提供全队暴击+",
	Desc = "美食星队员提供全队暴击 +{Value}",
	EffectModule = EffectModule.BuildTeam,
	MultiCount = true,
	EffectCondition = {
		Tag = 
		{
			560104,
		},
	},
	EffectRange = {
		EffectScope = EffectScope.Team,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200004,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id3093] =
{
	Id = 3093,
	Name = "每个美食星队员提供全队生命+",
	Desc = "美食星队员提供全队生命 +{Value}",
	Dialog = "一桶就能吃到100种口味噢~",
	EffectModule = EffectModule.BuildTeam,
	MultiCount = true,
	EffectCondition = {
		Tag = 
		{
			560104,
		},
	},
	EffectRange = {
		EffectScope = EffectScope.Team,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200001,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id3094] =
{
	Id = 3094,
	Name = "每个美食星队员提供全队攻击+",
	Desc = "美食星队员提供全队攻击 +{Value}",
	EffectModule = EffectModule.BuildTeam,
	MultiCount = true,
	EffectCondition = {
		Tag = 
		{
			560104,
		},
	},
	EffectRange = {
		EffectScope = EffectScope.Team,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200002,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id3095] =
{
	Id = 3095,
	Name = "美食星队员生命+",
	Desc = "美食星队员生命 +{Value}",
	Dialog = "御前侍卫番茄酱报到！",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Team,
		Tag = 
		{
			560104,
		},
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200001,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id3096] =
{
	Id = 3096,
	Name = "美食星队员忍耐+",
	Desc = "美食星队员忍耐 +{Value}",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Team,
		Tag = 
		{
			560104,
		},
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200003,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id3097] =
{
	Id = 3097,
	Name = "每个男的提供攻击+",
	Desc = "每个男队员提供攻击 +{Value}",
	Dialog = "来，都来摸摸我的肌肉！",
	EffectModule = EffectModule.BuildTeam,
	MultiCount = true,
	EffectCondition = {
		Tag = 
		{
			561702,
		},
	},
	EffectRange = {
		EffectScope = EffectScope.Team,
		Characters = 
		{
			220131,
		},
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200002,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id3098] =
{
	Id = 3098,
	Name = "每个男的提供力气+",
	Desc = "每个男队员提供力气 +{Value}",
	EffectModule = EffectModule.BuildTeam,
	MultiCount = true,
	EffectCondition = {
		Tag = 
		{
			561702,
		},
	},
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200007,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id3099] =
{
	Id = 3099,
	Name = "风元素敌人战力-",
	Desc = "风元素敌人战力 -{Value}%",
	Dialog = "战争，风暴，听我的召唤！",
	EffectModule = EffectModule.ExploreEnemy,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "EnemyFightPower",
		Element = 210003,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id3100] =
{
	Id = 3100,
	Name = "风元素敌人掉落概率+",
	Desc = "风元素敌人道具掉落率 +{Value}%",
	EffectModule = EffectModule.ExploreDrop,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "EnemyDropChance",
		Element = 210003,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id3101] =
{
	Id = 3101,
	Name = "暗元素敌人战力-",
	Desc = "暗元素敌人战力 -{Value}%",
	Dialog = "水、火、土、还有个什么来着？",
	EffectModule = EffectModule.ExploreEnemy,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "EnemyFightPower",
		Element = 210005,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id3102] =
{
	Id = 3102,
	Name = "暗元素敌人掉落概率+",
	Desc = "暗元素敌人道具掉落率 +{Value}%",
	EffectModule = EffectModule.ExploreDrop,
	EffectRange = {
		EffectScope = EffectScope.Self,
		Element = 210005,
	},
	Effect = {
		EffectAttribute = "EnemyDropChance",
		Element = 210005,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id3103] =
{
	Id = 3103,
	Name = "水元素敌人战力-",
	Desc = "水元素敌人战力 -{Value}%",
	Dialog = "法老的威严不容侵犯！",
	EffectModule = EffectModule.ExploreEnemy,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "EnemyFightPower",
		Element = 210001,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id3104] =
{
	Id = 3104,
	Name = "水元素敌人掉落概率+",
	Desc = "水元素敌人道具掉落率 +{Value}%",
	EffectModule = EffectModule.ExploreDrop,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "EnemyDropChance",
		Element = 210001,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id3105] =
{
	Id = 3105,
	Name = "光元素敌人战力-",
	Desc = "光元素敌人战力 -{Value}%",
	Dialog = "你的心脏会重过羽毛吗？",
	EffectModule = EffectModule.ExploreEnemy,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "EnemyFightPower",
		Element = 210004,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id3106] =
{
	Id = 3106,
	Name = "光元素敌人掉落概率+",
	Desc = "光元素敌人道具掉落率 +{Value}%",
	EffectModule = EffectModule.ExploreDrop,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "EnemyDropChance",
		Element = 210004,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id3107] =
{
	Id = 3107,
	Name = "每个石像组队员提供全队忍耐+",
	Desc = "石像组队员提供全队忍耐 +{Value}",
	Dialog = "出来活动活动~",
	EffectModule = EffectModule.BuildTeam,
	MultiCount = true,
	EffectCondition = {
		Tag = 
		{
			562912,
		},
	},
	EffectRange = {
		EffectScope = EffectScope.Team,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200003,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id3108] =
{
	Id = 3108,
	Name = "每个石像组队员提供全队亲和+",
	Desc = "石像组队员提供全队亲和 +{Value}",
	EffectModule = EffectModule.BuildTeam,
	MultiCount = true,
	EffectCondition = {
		Tag = 
		{
			562912,
		},
	},
	EffectRange = {
		EffectScope = EffectScope.Team,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200006,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id3109] =
{
	Id = 3109,
	Name = "每个石像组队员提供全队智力+",
	Desc = "石像组队员提供全队智力 +{Value}",
	EffectModule = EffectModule.BuildTeam,
	MultiCount = true,
	EffectCondition = {
		Tag = 
		{
			562912,
		},
	},
	EffectRange = {
		EffectScope = EffectScope.Team,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200008,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id3110] =
{
	Id = 3110,
	Name = "每个石像组队员提供全队攻击+",
	Desc = "石像组队员提供全队攻击 +{Value}",
	Dialog = "出来伸展伸展~",
	EffectModule = EffectModule.BuildTeam,
	MultiCount = true,
	EffectCondition = {
		Tag = 
		{
			562912,
		},
	},
	EffectRange = {
		EffectScope = EffectScope.Team,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200002,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id3111] =
{
	Id = 3111,
	Name = "每个石像组队员提供全队力气+",
	Desc = "石像组队员提供全队力气 +{Value}",
	EffectModule = EffectModule.BuildTeam,
	MultiCount = true,
	EffectCondition = {
		Tag = 
		{
			562912,
		},
	},
	EffectRange = {
		EffectScope = EffectScope.Team,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200007,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id3112] =
{
	Id = 3112,
	Name = "每个石像组队员提供全队亲和+",
	Desc = "石像组队员提供全队亲和 +{Value}",
	EffectModule = EffectModule.BuildTeam,
	MultiCount = true,
	EffectCondition = {
		Tag = 
		{
			562912,
		},
	},
	EffectRange = {
		EffectScope = EffectScope.Team,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200006,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id3113] =
{
	Id = 3113,
	Name = "每个石像组队员提供全队生命+",
	Desc = "石像组队员提供全队生命 +{Value}",
	Dialog = "出来晒晒太阳~",
	EffectModule = EffectModule.BuildTeam,
	MultiCount = true,
	EffectCondition = {
		Tag = 
		{
			562912,
		},
	},
	EffectRange = {
		EffectScope = EffectScope.Team,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200001,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id3114] =
{
	Id = 3114,
	Name = "每个石像组队员提供全队智力+",
	Desc = "石像组队员提供全队智力 +{Value}",
	EffectModule = EffectModule.BuildTeam,
	MultiCount = true,
	EffectCondition = {
		Tag = 
		{
			562912,
		},
	},
	EffectRange = {
		EffectScope = EffectScope.Team,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200008,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id3115] =
{
	Id = 3115,
	Name = "每个石像组队员提供全队技巧+",
	Desc = "石像组队员提供全队技巧 +{Value}",
	EffectModule = EffectModule.BuildTeam,
	MultiCount = true,
	EffectCondition = {
		Tag = 
		{
			562912,
		},
	},
	EffectRange = {
		EffectScope = EffectScope.Team,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200005,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id3116] =
{
	Id = 3116,
	Name = "每个石像组队员提供全队暴击+",
	Desc = "石像组队员提供全队暴击 +{Value}",
	Dialog = "出来溜达溜达~",
	EffectModule = EffectModule.BuildTeam,
	MultiCount = true,
	EffectCondition = {
		Tag = 
		{
			562912,
		},
	},
	EffectRange = {
		EffectScope = EffectScope.Team,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200004,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id3117] =
{
	Id = 3117,
	Name = "每个石像组队员提供全队技巧+",
	Desc = "石像组队员提供全队技巧 +{Value}",
	EffectModule = EffectModule.BuildTeam,
	MultiCount = true,
	EffectCondition = {
		Tag = 
		{
			562912,
		},
	},
	EffectRange = {
		EffectScope = EffectScope.Team,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200005,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id3118] =
{
	Id = 3118,
	Name = "每个石像组队员提供全队力气+",
	Desc = "石像组队员提供全队力气 +{Value}",
	EffectModule = EffectModule.BuildTeam,
	MultiCount = true,
	EffectCondition = {
		Tag = 
		{
			562912,
		},
	},
	EffectRange = {
		EffectScope = EffectScope.Team,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200007,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id3119] =
{
	Id = 3119,
	Name = "每个风元素提供生命+",
	Desc = "生命 +{Value}",
	Dialog = "别扯我布带！",
	EffectModule = EffectModule.BuildTeam,
	MultiCount = true,
	EffectCondition = {
		Element = 210003,
	},
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200001,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id3120] =
{
	Id = 3120,
	Name = "每个风元素提供忍耐+",
	Desc = "忍耐 +{Value}",
	EffectModule = EffectModule.BuildTeam,
	MultiCount = true,
	EffectCondition = {
		Element = 210003,
	},
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200003,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id3121] =
{
	Id = 3121,
	Name = "道具掉落率+",
	Desc = "道具掉落率 +{Value}%",
	Dialog = "这个是证物，我先没收!",
	EffectModule = EffectModule.ExploreDrop,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "GoodsDropChance",
		Tag = 
		{
			564305,
		},
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id3122] =
{
	Id = 3122,
	Name = "敌人战力-",
	Desc = "敌人战力 -{Value}%",
	Dialog = "555555~",
	EffectModule = EffectModule.ExploreEnemy,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "EnemyFightPower",
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
}
SkillConfig[SkillID.Id3123] =
{
	Id = 3123,
	Name = "敌人掉落概率+",
	Desc = "敌人道具掉落率 +{Value}%",
	Dialog = "啊~~~~~~~~~~~",
	EffectModule = EffectModule.ExploreDrop,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "EnemyDropChance",
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id3124] =
{
	Id = 3124,
	Name = "全队生命+",
	Desc = "全队生命 +{Value}",
	Dialog = "啊，新世界",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Team,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200001,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id3125] =
{
	Id = 3125,
	Name = "全队忍耐+",
	Desc = "全队忍耐 +{Value}",
	Dialog = "义人多有苦难",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Team,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200003,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id3126] =
{
	Id = 3126,
	Name = "探索时间-",
	Desc = "探索等待时间 -{Value}%",
	Dialog = "这次就挖地道进去吧！",
	EffectModule = EffectModule.ExploreTime,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "ExploreTime",
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
}
SkillConfig[SkillID.Id3127] =
{
	Id = 3127,
	Name = "道具掉落率+",
	Desc = "道具掉落率 +{Value}%",
	Dialog = "哇，这个值钱！",
	EffectModule = EffectModule.ExploreDrop,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "GoodsDropChance",
		Tag = 
		{
			564305,
		},
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id3128] =
{
	Id = 3128,
	Name = "探索金币+",
	Desc = "探索金币数量 +{Value}%",
	Dialog = "这次要多带点金币回去！",
	EffectModule = EffectModule.ExploreDrop,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "GoodsDropNumber",
		EffectValue = 1,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
}
SkillConfig[SkillID.Id3129] =
{
	Id = 3129,
	Name = "每个火元素提供生命+",
	Desc = "生命 +{Value}",
	Dialog = "呼哈！",
	EffectModule = EffectModule.BuildTeam,
	MultiCount = true,
	EffectCondition = {
		Element = 210002,
	},
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200001,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id3130] =
{
	Id = 3130,
	Name = "每个火元素提供力气+",
	Desc = "力气 +{Value}",
	EffectModule = EffectModule.BuildTeam,
	MultiCount = true,
	EffectCondition = {
		Element = 210002,
	},
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200007,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id3131] =
{
	Id = 3131,
	Name = "自身及原始人爸爸忍耐+",
	Desc = "自身及原始人爸爸忍耐 +{Value}",
	Dialog = "老公加油！",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Team,
		Characters = 
		{
			220214,
			220215,
		},
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200003,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id3132] =
{
	Id = 3132,
	Name = "自身及原始人爸爸力气+",
	Desc = "自身及原始人爸爸力气 +{Value}",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Team,
		Characters = 
		{
			220214,
			220215,
		},
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200007,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id3133] =
{
	Id = 3133,
	Name = "全队攻击+",
	Desc = "全队攻击 +{Value}",
	Dialog = "乌拉乌拉！",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Team,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200002,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id3134] =
{
	Id = 3134,
	Name = "全队力气+",
	Desc = "全队力气 +{Value}",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Team,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200007,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id3135] =
{
	Id = 3135,
	Name = "每个博物馆星队员提供全队生命+",
	Desc = "每个博物馆队员提供全队生命 +{Value}",
	Dialog = "我要报警了！",
	EffectModule = EffectModule.BuildTeam,
	MultiCount = true,
	EffectCondition = {
		Tag = 
		{
			560105,
		},
	},
	EffectRange = {
		EffectScope = EffectScope.Team,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200001,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id3136] =
{
	Id = 3136,
	Name = "每个博物馆星队员提供全队亲和+",
	Desc = "每个博物馆队员提供全队亲和 +{Value}",
	EffectModule = EffectModule.BuildTeam,
	MultiCount = true,
	EffectCondition = {
		Tag = 
		{
			560105,
		},
	},
	EffectRange = {
		EffectScope = EffectScope.Team,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200006,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id3137] =
{
	Id = 3137,
	Name = "男性队员攻击+",
	Desc = "男队员攻击 +{Value}",
	Dialog = "我的耳环好看吗？",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Team,
		Tag = 
		{
			561702,
		},
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200002,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id3138] =
{
	Id = 3138,
	Name = "男性队员力气+",
	Desc = "男队员力气 +{Value}",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Team,
		Tag = 
		{
			561702,
		},
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200007,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id3139] =
{
	Id = 3139,
	Name = "女性队员忍耐+",
	Desc = "女队员忍耐 +{Value}",
	Dialog = "我对你们都是真心的！",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Team,
		Tag = 
		{
			561703,
		},
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200003,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id3140] =
{
	Id = 3140,
	Name = "女性队员技巧+",
	Desc = "女队员技巧 +{Value}",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Team,
		Tag = 
		{
			561703,
		},
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200005,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id3141] =
{
	Id = 3141,
	Name = "全队生命+",
	Desc = "全队生命 +{Value}",
	Dialog = "(￣︶￣)",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Team,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200001,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id3142] =
{
	Id = 3142,
	Name = "全队攻击+",
	Desc = "全队攻击 +{Value}",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Team,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200002,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id3143] =
{
	Id = 3143,
	Name = "每个风元素提供生命+",
	Desc = "生命 +{Value}",
	Dialog = "这是我的生命，创造的力量！",
	EffectModule = EffectModule.BuildTeam,
	MultiCount = true,
	EffectCondition = {
		Element = 210003,
	},
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200001,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id3144] =
{
	Id = 3144,
	Name = "每个风元素提供忍耐+",
	Desc = "忍耐 +{Value}",
	EffectModule = EffectModule.BuildTeam,
	MultiCount = true,
	EffectCondition = {
		Element = 210003,
	},
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200003,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id3145] =
{
	Id = 3145,
	Name = "暴率+",
	Desc = "暴率 +{Value}%",
	Dialog = "你已经死了。",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "CritChance",
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id3146] =
{
	Id = 3146,
	Name = "暴击伤害+",
	Desc = "暴击伤害 +{Value}%",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "CritDamage",
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id3147] =
{
	Id = 3147,
	Name = "生命+",
	Desc = "生命 +{Value}",
	Dialog = "孤独，教会我们去了解自己。",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Team,
		Characters = 
		{
			220225,
		},
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200001,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id3148] =
{
	Id = 3148,
	Name = "攻击+",
	Desc = "攻击 +{Value}",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Team,
		Characters = 
		{
			220225,
		},
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200002,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id3149] =
{
	Id = 3149,
	Name = "忍耐+",
	Desc = "忍耐 +{Value}",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Team,
		Characters = 
		{
			220225,
		},
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200003,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id3150] =
{
	Id = 3150,
	Name = "暴击+",
	Desc = "暴击 +{Value}",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Team,
		Characters = 
		{
			220225,
		},
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200004,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id3151] =
{
	Id = 3151,
	Name = "探索时间-",
	Desc = "探索等待时间 -{Value}%",
	Dialog = "时间不能折叠吗？",
	EffectModule = EffectModule.ExploreTime,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "ExploreTime",
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
}
SkillConfig[SkillID.Id3152] =
{
	Id = 3152,
	Name = "道具掉落率+",
	Desc = "道具掉落率 +{Value}%",
	EffectModule = EffectModule.ExploreDrop,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "GoodsDropChance",
		Tag = 
		{
			564305,
		},
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id3153] =
{
	Id = 3153,
	Name = "全队生命+",
	Desc = "全队生命 +{Value}",
	Dialog = "真正的才智是刚毅的志向！",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Team,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200001,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id3154] =
{
	Id = 3154,
	Name = "全队攻击+",
	Desc = "全队攻击 +{Value}",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Team,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200002,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id3155] =
{
	Id = 3155,
	Name = "全队忍耐+",
	Desc = "全队忍耐 +{Value}",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Team,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200003,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id3156] =
{
	Id = 3156,
	Name = "全队暴击+",
	Desc = "全队暴击 +{Value}",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Team,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200004,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id3157] =
{
	Id = 3157,
	Name = "头目招来",
	Desc = "金色及以上品质敌人出现概率 +{Value}%",
	Dialog = "这里应该很安全吧？",
	EffectModule = EffectModule.ExploreEnemy,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "EnemyWeight",
		Rarity = 4,
		RarityOp = 0,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
}
SkillConfig[SkillID.Id3158] =
{
	Id = 3158,
	Name = "全队暴击+",
	Desc = "全队暴击 +{Value}",
	Dialog = "我给大家科普点法律知识。",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Team,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200004,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id3159] =
{
	Id = 3159,
	Name = "全队智力+",
	Desc = "全队智力 +{Value}",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Team,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200008,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id3160] =
{
	Id = 3160,
	Name = "每个悬疑星队员提供攻击+",
	Desc = "攻击 +{Value}",
	Dialog = "我要慢慢折磨你！",
	EffectModule = EffectModule.BuildTeam,
	MultiCount = true,
	EffectCondition = {
		Tag = 
		{
			560106,
		},
	},
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200002,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id3161] =
{
	Id = 3161,
	Name = "3回合后每回合攻击+",
	Desc = "3回合后，每回合攻击 +{Value}，最多3次",
	EffectModule = EffectModule.Battle,
	BattleParameter = {
		StartRound = 3,
		IntervalRound = 1,
		Limited = 3,
	},
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200002,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id3162] =
{
	Id = 3162,
	Name = "全队生命+",
	Desc = "全队生命 +{Value}",
	Dialog = "我代表正义起诉你们！",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Team,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200001,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id3163] =
{
	Id = 3163,
	Name = "全队暴击+",
	Desc = "全队暴击 +{Value}",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Team,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200004,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id3164] =
{
	Id = 3164,
	Name = "后方队员生命+",
	Desc = "自身及身后2名队员生命 +{Value}",
	Dialog = "嗯，完美的计划！",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.RelativePosition,
		PositionValue = 
		{
			0,1,2,
		},
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200001,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id3165] =
{
	Id = 3165,
	Name = "后方队员亲和+",
	Desc = "自身及身后2名队员亲和 +{Value}",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.RelativePosition,
		PositionValue = 
		{
			0,1,2,
		},
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200006,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id3166] =
{
	Id = 3166,
	Name = "左右队员攻击+",
	Desc = "自身及左右1名队员攻击 +{Value}",
	Dialog = "那么，准备出发了？",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.RelativePosition,
		PositionValue = 
		{
			1,0,-1,
		},
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200002,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id3167] =
{
	Id = 3167,
	Name = "左右队员亲和+",
	Desc = "自身及左右1名队员亲和 +{Value}",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.RelativePosition,
		PositionValue = 
		{
			1,0,-1,
		},
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200006,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id3168] =
{
	Id = 3168,
	Name = "前方队员暴击+",
	Desc = "自身及前身2名队员暴击 +{Value}",
	Dialog = "记得检查装备噢~",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.RelativePosition,
		PositionValue = 
		{
			0,-1,-2,
		},
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200004,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id3169] =
{
	Id = 3169,
	Name = "前方队员智力+",
	Desc = "自身及前身2名队员智力 +{Value}",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.RelativePosition,
		PositionValue = 
		{
			0,-1,-2,
		},
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200008,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id3170] =
{
	Id = 3170,
	Name = "打工金币+",
	Desc = "打工金币数量 +{Value}%",
	Dialog = "先生，来份早报吗？",
	EffectModule = EffectModule.WorkShop,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "WorkShopGoodsNumber",
		EffectValue = 1,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
}
SkillConfig[SkillID.Id3171] =
{
	Id = 3171,
	Name = "打工食物+",
	Desc = "打工食物数量 +{Value}%",
	Dialog = "书是最好的精神食粮！",
	EffectModule = EffectModule.WorkShop,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "WorkShopGoodsNumber",
		Tag = 
		{
			564306,
		},
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
}
SkillConfig[SkillID.Id3172] =
{
	Id = 3172,
	Name = "每个悬疑星队员提供生命+",
	Desc = "生命 +{Value}",
	Dialog = "今天的便当有鸡腿吗？",
	EffectModule = EffectModule.BuildTeam,
	MultiCount = true,
	EffectCondition = {
		Tag = 
		{
			560106,
		},
	},
	EffectRange = {
		EffectScope = EffectScope.Team,
		Characters = 
		{
			220303,
		},
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200001,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id3173] =
{
	Id = 3173,
	Name = "探索金币+",
	Desc = "探索金币数量 +{Value}%",
	Dialog = "我有一千种办法让你交租！",
	EffectModule = EffectModule.ExploreDrop,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "GoodsDropNumber",
		EffectValue = 1,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
}
SkillConfig[SkillID.Id3174] =
{
	Id = 3174,
	Name = "女性队员暴击+",
	Desc = "女队员暴击 +{Value}",
	Dialog = "美丽的小姐，来杯鸡尾酒吗？",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Team,
		Tag = 
		{
			561703,
		},
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200004,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id3175] =
{
	Id = 3175,
	Name = "女性队员亲和+",
	Desc = "女队员亲和 +{Value}",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Team,
		Tag = 
		{
			561703,
		},
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200006,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id3176] =
{
	Id = 3176,
	Name = "火元素队员忍耐+",
	Desc = "火元素队员忍耐 +{Value}",
	Dialog = "发现细节，找到问题！",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Team,
		Element = 210002,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200003,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id3177] =
{
	Id = 3177,
	Name = "火元素队员技巧+",
	Desc = "火元素队员技巧 +{Value}",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Team,
		Element = 210002,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200005,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id3178] =
{
	Id = 3178,
	Name = "生命+",
	Desc = "生命 +{Value}",
	Dialog = "需要新的调试数据。",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200001,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id3179] =
{
	Id = 3179,
	Name = "升级消耗+",
	Desc = "升级要求的金币 -{Value}%",
	EffectModule = EffectModule.CharacterLevelUp,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "CharacterLevelUpCost",
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
}
SkillConfig[SkillID.Id3180] =
{
	Id = 3180,
	Name = "敌人暴击+",
	Desc = "敌人暴击 -{Value}",
	Dialog = "被告控制情绪，否则判你藐视法庭",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "SpecificEnemyAbility",
		EffectValue = 200004,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
}
SkillConfig[SkillID.Id3181] =
{
	Id = 3181,
	Name = "全队攻击+",
	Desc = "全队攻击 +{Value}",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Team,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200002,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id3182] =
{
	Id = 3182,
	Name = "全队暴击伤害+",
	Desc = "全队暴击伤害 +{Value}%",
	Dialog = "我一定说出事实及事实全部！",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Team,
	},
	Effect = {
		EffectAttribute = "CritDamage",
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id3183] =
{
	Id = 3183,
	Name = "敌人战力-",
	Desc = "敌人战力 -{Value}%",
	Dialog = "里面的人立刻出来，交出赃物！",
	EffectModule = EffectModule.ExploreEnemy,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "EnemyFightPower",
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id3184] =
{
	Id = 3184,
	Name = "敌人掉落概率+",
	Desc = "敌人道具掉落率 +{Value}%",
	EffectModule = EffectModule.ExploreDrop,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "EnemyDropChance",
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id3185] =
{
	Id = 3185,
	Name = "每个悬疑星队员提供全队攻击+",
	Desc = "每个悬疑星队员提供全队攻击 +{Value}",
	Dialog = "被害者会说出真相的！",
	EffectModule = EffectModule.BuildTeam,
	MultiCount = true,
	EffectCondition = {
		Tag = 
		{
			560106,
		},
	},
	EffectRange = {
		EffectScope = EffectScope.Team,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200002,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id3186] =
{
	Id = 3186,
	Name = "悬疑星队员生命+",
	Desc = "悬疑星队员生命 +{Value}",
	Dialog = "生既是死,无时无刻。",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Team,
		Tag = 
		{
			560106,
		},
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200001,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id3187] =
{
	Id = 3187,
	Name = "悬疑星队员技巧+",
	Desc = "悬疑星队员技巧 +{Value}",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Team,
		Tag = 
		{
			560106,
		},
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200005,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id3188] =
{
	Id = 3188,
	Name = "自身及大侦探生命+",
	Desc = "生命 +{Value}",
	Dialog = "这到底是怎么一回事呢？",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Team,
		Characters = 
		{
			220320,
			220324,
		},
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200001,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id3189] =
{
	Id = 3189,
	Name = "自身及大侦探暴击+",
	Desc = "暴击 +{Value}",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Team,
		Characters = 
		{
			220320,
			220324,
		},
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200004,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id3190] =
{
	Id = 3190,
	Name = "敌人生命+",
	Desc = "敌人生命 -{Value}%",
	Dialog = "剪碎一切！！！",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "SpecificEnemyAbility",
		EffectValue = 200001,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
}
SkillConfig[SkillID.Id3191] =
{
	Id = 3191,
	Name = "暴率+",
	Desc = "5回合后暴率 +{Value}%",
	Dialog = "真相只有一个！",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "CritChance",
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id3192] =
{
	Id = 3192,
	Name = "5回合后暴率+",
	Desc = "5回合后，暴率 +{Value}%",
	EffectModule = EffectModule.Battle,
	BattleParameter = {
		StartRound = 5,
		IntervalRound = 1,
		Limited = 1,
	},
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "CritChance",
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id3193] =
{
	Id = 3193,
	Name = "暴击+",
	Desc = "自身暴击 +{Value}",
	Dialog = "我们来玩点益智问答吧~",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200004,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id3194] =
{
	Id = 3194,
	Name = "每回合暴击+",
	Desc = "每回合自身暴击 +{Value}，最多3次",
	EffectModule = EffectModule.Battle,
	BattleParameter = {
		StartRound = 1,
		IntervalRound = 1,
		Limited = 3,
	},
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200004,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id3195] =
{
	Id = 3195,
	Name = "全队攻击+",
	Desc = "全队攻击 +{Value}",
	Dialog = "排除所有不可能，剩下就是真相",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Team,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200002,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id3196] =
{
	Id = 3196,
	Name = "5回合后，全队攻击+",
	Desc = "5回合后，全队攻击 +{Value}",
	EffectModule = EffectModule.Battle,
	BattleParameter = {
		StartRound = 5,
		IntervalRound = 1,
		Limited = 1,
	},
	EffectRange = {
		EffectScope = EffectScope.Team,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200002,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id3197] =
{
	Id = 3197,
	Name = "全队攻击型队员闪避+",
	Desc = "全队攻击型队员{Value}%概率闪避攻击",
	Dialog = "你们的一举一动都在我意料之中",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Team,
		Tag = 
		{
			561208,
		},
	},
	Effect = {
		EffectAttribute = "Dodge",
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id3198] =
{
	Id = 3198,
	Name = "海洋星的敌人捕捉率+",
	Desc = "海洋星敌人捕捉成功率 +{Value}%",
	EffectModule = EffectModule.ExploreCatch,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "PetCatchSuccessChance",
		Tag = 
		{
			560107,
		},
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id3199] =
{
	Id = 3199,
	Name = "压制海洋星敌人战力",
	Desc = "海洋星敌人战力 -{Value}%",
	EffectModule = EffectModule.ExploreEnemy,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "EnemyFightPower",
		Tag = 
		{
			560107,
		},
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id3200] =
{
	Id = 3200,
	Name = "蓝色及以下品质敌人捕捉率+",
	Desc = "蓝色及以下品质敌人捕捉成功率 +{Value}%",
	EffectModule = EffectModule.ExploreCatch,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "PetCatchSuccessChance",
		Rarity = 3,
		RarityOp = 1,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id3201] =
{
	Id = 3201,
	Name = "躲避强敌",
	Desc = "打不过的怪物出现概率 -{Value}%",
	EffectModule = EffectModule.ExploreEnemy,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "EnemyWeight",
		Chance = 100,
		CompareFightPower = 1,
		EnemyWeightCondition = {
			CompareWin = 2,
		},
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id3202] =
{
	Id = 3202,
	Name = "每个水元素队员使敌人掉落概率+",
	Desc = "每个水元素队员使敌人道具掉落率 +{Value}%",
	EffectModule = EffectModule.ExploreDrop,
	MultiCount = true,
	EffectCondition = {
		Element = 210001,
	},
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "EnemyDropChance",
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id3203] =
{
	Id = 3203,
	Name = "打工食物+",
	Desc = "打工食物数量 +{Value}%",
	EffectModule = EffectModule.WorkShop,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "WorkShopGoodsNumber",
		Tag = 
		{
			564306,
		},
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id3204] =
{
	Id = 3204,
	Name = "火元素敌人战力-",
	Desc = "火元素敌人战力 -{Value}%",
	Dialog = "呼！我要生气啦~",
	EffectModule = EffectModule.ExploreEnemy,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "EnemyFightPower",
		Element = 210002,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id3205] =
{
	Id = 3205,
	Name = "火元素敌人掉落概率+",
	Desc = "火元素敌人道具掉落率 +{Value}%",
	EffectModule = EffectModule.ExploreDrop,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "EnemyDropChance",
		Element = 210002,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id3206] =
{
	Id = 3206,
	Name = "风元素敌人捕捉率+",
	Desc = "风元素敌人捕捉成功率 +{Value}%",
	EffectModule = EffectModule.ExploreCatch,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "PetCatchSuccessChance",
		Element = 210003,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id3207] =
{
	Id = 3207,
	Name = "躲避强敌",
	Desc = "打不过的怪物出现概率 -{Value}%",
	EffectModule = EffectModule.ExploreEnemy,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "EnemyWeight",
		Chance = 100,
		CompareFightPower = 1,
		EnemyWeightCondition = {
			CompareWin = 2,
		},
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id3208] =
{
	Id = 3208,
	Name = "前方队员生命+",
	Desc = "自身及前身2名队员生命 +{Value}",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.RelativePosition,
		PositionValue = 
		{
			0,-1,-2,
		},
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200001,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id3209] =
{
	Id = 3209,
	Name = "后方队员攻击+",
	Desc = "自身及身后2名队员攻击 +{Value}",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.RelativePosition,
		PositionValue = 
		{
			0,1,2,
		},
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200002,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id3210] =
{
	Id = 3210,
	Name = "工具箱捕捉率+",
	Desc = "工具箱捕捉成功率 +{Value}%",
	EffectModule = EffectModule.ExploreCatch,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "PetCatchSuccessChance",
		Tag = 
		{
			563105,
		},
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id3211] =
{
	Id = 3211,
	Name = "纸板箱捕捉率+",
	Desc = "纸板箱捕捉成功率 +{Value}%",
	EffectModule = EffectModule.ExploreCatch,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "PetCatchSuccessChance",
		Tag = 
		{
			563106,
		},
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id3212] =
{
	Id = 3212,
	Name = "水元素打击",
	Desc = "对水元素敌人伤害 +{Value}%",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "DamageToElement",
		EffectValue = 210001,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id3213] =
{
	Id = 3213,
	Name = "火元素打击",
	Desc = "对火元素敌人伤害 +{Value}%",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "DamageToElement",
		EffectValue = 210002,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id3214] =
{
	Id = 3214,
	Name = "风元素打击",
	Desc = "对风元素敌人伤害 +{Value}%",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "DamageToElement",
		EffectValue = 210003,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id3215] =
{
	Id = 3215,
	Name = "队员战力+",
	Desc = "探索中，队员战力 +{Value}%",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Team,
	},
	Effect = {
		EffectAttribute = "FightPower",
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id3216] =
{
	Id = 3216,
	Name = "道具掉落率+",
	Desc = "道具掉落率 +{Value}%",
	EffectModule = EffectModule.ExploreDrop,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "GoodsDropChance",
		Tag = 
		{
			564305,
		},
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id3217] =
{
	Id = 3217,
	Name = "暗元素队员攻击+",
	Desc = "暗元素队员攻击 +{Value}",
	EffectModule = EffectModule.BuildTeam,
	EffectCondition = {
		Element = 210005,
	},
	EffectRange = {
		EffectScope = EffectScope.Team,
		Element = 210005,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200002,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id3218] =
{
	Id = 3218,
	Name = "后方风元素队员闪避+",
	Desc = "自身及身后两名风元素队员{Value}%概率闪避攻击",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.RelativePosition,
		PositionValue = 
		{
			0,1,2,
		},
		Element = 210003,
	},
	Effect = {
		EffectAttribute = "Dodge",
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id3219] =
{
	Id = 3219,
	Name = "探索时间-",
	Desc = "探索等待时间 -{Value}%",
	EffectModule = EffectModule.ExploreTime,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "ExploreTime",
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id3220] =
{
	Id = 3220,
	Name = "打工金币+",
	Desc = "打工金币数量 +{Value}%",
	EffectModule = EffectModule.WorkShop,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "WorkShopGoodsNumber",
		EffectValue = 1,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id3221] =
{
	Id = 3221,
	Name = "打工工时+",
	Desc = "打工中，最大工时 +{Value}%",
	EffectModule = EffectModule.WorkShop,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "WorkShopMaxWorkTime",
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id3222] =
{
	Id = 3222,
	Name = "每回合攻击+",
	Desc = "每回合攻击 +{Value}，最多5次",
	EffectModule = EffectModule.Battle,
	BattleParameter = {
		StartRound = 1,
		IntervalRound = 1,
		Limited = 5,
	},
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200002,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id3223] =
{
	Id = 3223,
	Name = "每回合忍耐+",
	Desc = "每回合忍耐 +{Value}，最多5次",
	EffectModule = EffectModule.Battle,
	BattleParameter = {
		StartRound = 1,
		IntervalRound = 1,
		Limited = 5,
	},
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200003,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id3224] =
{
	Id = 3224,
	Name = "暗元素队员生命+",
	Desc = "暗元素队员生命 +{Value}",
	EffectModule = EffectModule.BuildTeam,
	EffectCondition = {
		Element = 210005,
	},
	EffectRange = {
		EffectScope = EffectScope.Team,
		Element = 210005,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200001,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id3225] =
{
	Id = 3225,
	Name = "前方暗元素打击",
	Desc = "自身及身前两名队员对暗元素敌人伤害 +{Value}%",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.RelativePosition,
		PositionValue = 
		{
			0,-1,-2,
		},
	},
	Effect = {
		EffectAttribute = "DamageToElement",
		EffectValue = 210005,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id3226] =
{
	Id = 3226,
	Name = "头目招来",
	Desc = "金色及以上品质敌人出现概率 +{Value}%",
	EffectModule = EffectModule.ExploreEnemy,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "EnemyWeight",
		Rarity = 4,
		RarityOp = 0,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id3227] =
{
	Id = 3227,
	Name = "道具掉落率+",
	Desc = "道具掉落率 +{Value}%",
	EffectModule = EffectModule.ExploreDrop,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "GoodsDropChance",
		Tag = 
		{
			564305,
		},
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id3228] =
{
	Id = 3228,
	Name = "全队攻击+",
	Desc = "全队攻击 +{Value}",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Team,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200002,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id3229] =
{
	Id = 3229,
	Name = "每回合全队攻击+",
	Desc = "每回合攻击 +{Value}，最多5次",
	EffectModule = EffectModule.Battle,
	BattleParameter = {
		StartRound = 1,
		IntervalRound = 1,
		Limited = 5,
	},
	EffectRange = {
		EffectScope = EffectScope.Team,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200002,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id3230] =
{
	Id = 3230,
	Name = "全队忍耐+",
	Desc = "全队忍耐 +{Value}",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Team,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200003,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id3231] =
{
	Id = 3231,
	Name = "每回合全队忍耐+",
	Desc = "每回合忍耐 +{Value}，最多5次",
	EffectModule = EffectModule.Battle,
	BattleParameter = {
		StartRound = 1,
		IntervalRound = 1,
		Limited = 5,
	},
	EffectRange = {
		EffectScope = EffectScope.Team,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200003,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id3232] =
{
	Id = 3232,
	Name = "水元素敌人掉落概率+",
	Desc = "水元素敌人道具掉落率 +{Value}%",
	EffectModule = EffectModule.ExploreDrop,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "EnemyDropChance",
		Element = 210001,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id3233] =
{
	Id = 3233,
	Name = "水元素敌人捕捉率+",
	Desc = "水元素敌人捕捉成功率 +{Value}%",
	EffectModule = EffectModule.ExploreCatch,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "PetCatchSuccessChance",
		Element = 210001,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id3234] =
{
	Id = 3234,
	Name = "打工捕捉道具+",
	Desc = "打工捕捉道具数量 +{Value}%",
	EffectModule = EffectModule.WorkShop,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "WorkShopGoodsNumber",
		Tag = 
		{
			564307,
		},
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id3235] =
{
	Id = 3235,
	Name = "风元素队员连击1次",
	Desc = "风元素队员有{Value}%概率额外攻击1次",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Team,
		Element = 210003,
	},
	Effect = {
		EffectAttribute = "ExtraAttack",
		EffectValue = 1,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id3236] =
{
	Id = 3236,
	Name = "每个海洋星队员提供攻击+",
	Desc = "攻击 +{Value}",
	EffectModule = EffectModule.BuildTeam,
	MultiCount = true,
	EffectCondition = {
		Tag = 
		{
			560107,
		},
	},
	EffectRange = {
		EffectScope = EffectScope.Team,
		Characters = 
		{
			220426,
		},
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200002,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id3237] =
{
	Id = 3237,
	Name = "每个海洋星队员提供暴击+",
	Desc = "暴击 +{Value}",
	EffectModule = EffectModule.BuildTeam,
	MultiCount = true,
	EffectCondition = {
		Tag = 
		{
			560107,
		},
	},
	EffectRange = {
		EffectScope = EffectScope.Team,
		Characters = 
		{
			220426,
		},
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200004,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id3238] =
{
	Id = 3238,
	Name = "每个海洋星队员提供生命+",
	Desc = "生命 +{Value}",
	EffectModule = EffectModule.BuildTeam,
	MultiCount = true,
	EffectCondition = {
		Tag = 
		{
			560107,
		},
	},
	EffectRange = {
		EffectScope = EffectScope.Team,
		Characters = 
		{
			220426,
		},
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200001,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id3239] =
{
	Id = 3239,
	Name = "每个海洋星队员提供忍耐+",
	Desc = "忍耐 +{Value}",
	EffectModule = EffectModule.BuildTeam,
	MultiCount = true,
	EffectCondition = {
		Tag = 
		{
			560107,
		},
	},
	EffectRange = {
		EffectScope = EffectScope.Team,
		Characters = 
		{
			220426,
		},
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200003,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id3240] =
{
	Id = 3240,
	Name = "全队战力+",
	Desc = "探索中，全队战力 +{Value}%",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Team,
	},
	Effect = {
		EffectAttribute = "FightPower",
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id3241] =
{
	Id = 3241,
	Name = "道具掉落率+",
	Desc = "道具掉落率 +{Value}%",
	EffectModule = EffectModule.ExploreDrop,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "GoodsDropChance",
		Tag = 
		{
			564305,
		},
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id3242] =
{
	Id = 3242,
	Name = "全队生命+",
	Desc = "全队生命 +{Value}",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Team,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200001,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id3243] =
{
	Id = 3243,
	Name = "全队忍耐+",
	Desc = "全队忍耐 +{Value}",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Team,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200003,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id3244] =
{
	Id = 3244,
	Name = "海洋星队员生命+",
	Desc = "全队生命 +{Value}",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Team,
		Tag = 
		{
			560107,
		},
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200001,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id3245] =
{
	Id = 3245,
	Name = "海洋星队员忍耐+",
	Desc = "全队忍耐 +{Value}",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Team,
		Tag = 
		{
			560107,
		},
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200003,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id3246] =
{
	Id = 3246,
	Name = "温驯海族生命+",
	Desc = "全队生命 +{Value}",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Team,
		Tag = 
		{
			561355,
		},
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200001,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id3247] =
{
	Id = 3247,
	Name = "温驯海族忍耐+",
	Desc = "全队忍耐 +{Value}",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Team,
		Tag = 
		{
			561355,
		},
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200003,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id3248] =
{
	Id = 3248,
	Name = "全队攻击+",
	Desc = "全队攻击 +{Value}",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Team,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200002,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id3249] =
{
	Id = 3249,
	Name = "全队暴击+",
	Desc = "全队暴击 +{Value}",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Team,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200004,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id3250] =
{
	Id = 3250,
	Name = "海洋星队员攻击+",
	Desc = "全队攻击 +{Value}",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Team,
		Tag = 
		{
			560107,
		},
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200002,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id3251] =
{
	Id = 3251,
	Name = "海洋星队员暴击+",
	Desc = "全队暴击 +{Value}",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Team,
		Tag = 
		{
			560107,
		},
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200004,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id3252] =
{
	Id = 3252,
	Name = "凶猛海族攻击+",
	Desc = "全队攻击 +{Value}",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Team,
		Tag = 
		{
			561356,
		},
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200002,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id3253] =
{
	Id = 3253,
	Name = "凶猛海族暴击+",
	Desc = "全队暴击 +{Value}",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Team,
		Tag = 
		{
			561356,
		},
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200004,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id3254] =
{
	Id = 3254,
	Name = "全队对水元素伤害+",
	Desc = "全队对水元素敌人伤害 +{Value}%",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Team,
	},
	Effect = {
		EffectAttribute = "DamageToElement",
		EffectValue = 210001,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id3255] =
{
	Id = 3255,
	Name = "临时技能名字",
	Desc = "生命 +{Value}",
	EffectModule = EffectModule.BuildTeam,
	MultiCount = true,
	EffectCondition = {
		Tag = 
		{
			560107,
		},
	},
	EffectRange = {
		EffectScope = EffectScope.Team,
		Characters = 
		{
			220426,
		},
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200001,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id3256] =
{
	Id = 3256,
	Name = "临时技能名字",
	Desc = "每个海洋星队员提供全队生命 +{Value}",
	EffectModule = EffectModule.BuildTeam,
	MultiCount = true,
	EffectCondition = {
		Tag = 
		{
			560107,
		},
	},
	EffectRange = {
		EffectScope = EffectScope.Team,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200001,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id3257] =
{
	Id = 3257,
	Name = "临时技能名字",
	Desc = "生命 +{Value}",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Team,
		Element = 210003,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200001,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id3258] =
{
	Id = 3258,
	Name = "临时技能名字",
	Desc = "攻击 +{Value}",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Team,
		Element = 210003,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200002,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id3259] =
{
	Id = 3259,
	Name = "临时技能名字",
	Desc = "敌人捕捉成功率 +{Value}%",
	EffectModule = EffectModule.ExploreCatch,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "PetCatchSuccessChance",
		Rarity = 4,
		RarityOp = 0,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id3260] =
{
	Id = 3260,
	Name = "临时技能名字",
	Desc = "金色及以上品质敌人出现概率 +{Value}%",
	EffectModule = EffectModule.ExploreEnemy,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "EnemyWeight",
		Rarity = 4,
		RarityOp = 0,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id3261] =
{
	Id = 3261,
	Name = "临时技能名字",
	Desc = "升级要求的金币 -{Value}%",
	EffectModule = EffectModule.CharacterLevelUp,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "CharacterLevelUpCost",
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id3262] =
{
	Id = 3262,
	Name = "临时技能名字",
	Desc = "风元素敌人生命 -{Value}%",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "SpecificEnemyAbility",
		EffectValue = 200001,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id3263] =
{
	Id = 3263,
	Name = "临时技能名字",
	Desc = "风元素敌人攻击 -{Value}%",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "SpecificEnemyAbility",
		EffectValue = 200002,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id3264] =
{
	Id = 3264,
	Name = "临时技能名字",
	Desc = "亲和 +{Value}",
	EffectModule = EffectModule.BuildTeam,
	MultiCount = true,
	EffectCondition = {
		Tag = 
		{
			561202,
		},
	},
	EffectRange = {
		EffectScope = EffectScope.Team,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200006,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id3265] =
{
	Id = 3265,
	Name = "临时技能名字",
	Desc = "全队亲和 +{Value}",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Team,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200006,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id3266] =
{
	Id = 3266,
	Name = "临时技能名字",
	Desc = "打工中，最大工时 +{Value}%",
	EffectModule = EffectModule.WorkShop,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "WorkShopMaxWorkTime",
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id3267] =
{
	Id = 3267,
	Name = "临时技能名字",
	Desc = "生命 +{Value}",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200001,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id3268] =
{
	Id = 3268,
	Name = "临时技能名字",
	Desc = "生命 +{Value}",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Team,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200001,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id3269] =
{
	Id = 3269,
	Name = "临时技能名字",
	Desc = "{Value}%概率闪避攻击",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Team,
		Element = 210001,
	},
	Effect = {
		EffectAttribute = "Dodge",
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id3270] =
{
	Id = 3270,
	Name = "临时技能名字",
	Desc = "5回合后，回血 {Value}%",
	EffectModule = EffectModule.Battle,
	BattleParameter = {
		StartRound = 5,
		IntervalRound = 1,
		Limited = 1,
	},
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "Recovery",
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id3271] =
{
	Id = 3271,
	Name = "临时技能名字",
	Desc = "每回合自身及左右队员回血 {Value}%，最多5次",
	EffectModule = EffectModule.Battle,
	BattleParameter = {
		StartRound = 1,
		IntervalRound = 1,
		Limited = 5,
	},
	EffectRange = {
		EffectScope = EffectScope.RelativePosition,
		PositionValue = 
		{
			1,0,-1,
		},
	},
	Effect = {
		EffectAttribute = "Recovery",
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id3272] =
{
	Id = 3272,
	Name = "临时技能名字",
	Desc = "每回合攻击 +{Value}，最多5次",
	EffectModule = EffectModule.Battle,
	BattleParameter = {
		StartRound = 1,
		IntervalRound = 1,
		Limited = 5,
	},
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200002,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id3273] =
{
	Id = 3273,
	Name = "临时技能名字",
	Desc = "打不过的怪物出现概率 -{Value}%",
	EffectModule = EffectModule.ExploreEnemy,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "EnemyWeight",
		Chance = 100,
		CompareFightPower = 1,
		EnemyWeightCondition = {
			CompareWin = 2,
		},
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id3274] =
{
	Id = 3274,
	Name = "临时技能名字",
	Desc = "生命 +{Value}",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200001,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id3275] =
{
	Id = 3275,
	Name = "临时技能名字",
	Desc = "攻击 +{Value}",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.RelativePosition,
		PositionValue = 
		{
			5,4,3,2,1,0,
		},
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200002,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id3276] =
{
	Id = 3276,
	Name = "临时技能名字",
	Desc = "{Value}%概率闪避攻击",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "Dodge",
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id3277] =
{
	Id = 3277,
	Name = "临时技能名字",
	Desc = "每个暗元素队员提供全队攻击 +{Value}",
	EffectModule = EffectModule.BuildTeam,
	MultiCount = true,
	EffectCondition = {
		Tag = 
		{
			561206,
		},
	},
	EffectRange = {
		EffectScope = EffectScope.Team,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200002,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id3278] =
{
	Id = 3278,
	Name = "临时技能名字",
	Desc = "每3回合攻击 +{Value}，最多3次",
	EffectModule = EffectModule.Battle,
	BattleParameter = {
		StartRound = 3,
		IntervalRound = 3,
		Limited = 3,
	},
	EffectRange = {
		EffectScope = EffectScope.Team,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200002,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id3279] =
{
	Id = 3279,
	Name = "临时技能名字",
	Desc = "每3回合全队回血 {Value}%，最多5次",
	EffectModule = EffectModule.Battle,
	BattleParameter = {
		StartRound = 3,
		IntervalRound = 3,
		Limited = 5,
	},
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "Recovery",
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id3280] =
{
	Id = 3280,
	Name = "临时技能名字",
	Desc = "战力 +{Value}%",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Team,
	},
	Effect = {
		EffectAttribute = "FightPower",
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id3281] =
{
	Id = 3281,
	Name = "临时技能名字",
	Desc = "有{Value}%概率额外攻击1次",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "ExtraAttack",
		EffectValue = 1,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id3282] =
{
	Id = 3282,
	Name = "临时技能名字",
	Desc = "水元素敌人战力 -{Value}%",
	EffectModule = EffectModule.ExploreEnemy,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "EnemyFightPower",
		Element = 210001,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id3283] =
{
	Id = 3283,
	Name = "临时技能名字",
	Desc = "全队生命 +{Value}",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Team,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200001,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id3284] =
{
	Id = 3284,
	Name = "临时技能名字",
	Desc = "全队攻击 +{Value}",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Team,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200002,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id3285] =
{
	Id = 3285,
	Name = "探索金币+",
	Desc = "探索金币数量 +{Value}%",
	Dialog = "本大王是全宇宙最富有的！",
	EffectModule = EffectModule.ExploreDrop,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "GoodsDropNumber",
		EffectValue = 1,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
}
SkillConfig[SkillID.Id3286] =
{
	Id = 3286,
	Name = "道具掉落率+",
	Desc = "道具掉落率 +{Value}%",
	Dialog = "看来这里有很多不错的素材啊！",
	EffectModule = EffectModule.ExploreDrop,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "GoodsDropChance",
		Tag = 
		{
			564305,
		},
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id3287] =
{
	Id = 3287,
	Name = "全队必中+",
	Desc = "全队{Value}%概率无视敌人闪避",
	Dialog = "再来一次，一定会中的！",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Team,
	},
	Effect = {
		EffectAttribute = "DodgeIgnore",
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
}
SkillConfig[SkillID.Id3288] =
{
	Id = 3288,
	Name = "探索金币+",
	Desc = "探索金币数量 +{Value}%",
	Dialog = "要去冒险了，应该会很坎坷吧…",
	EffectModule = EffectModule.ExploreDrop,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "GoodsDropNumber",
		EffectValue = 1,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id3289] =
{
	Id = 3289,
	Name = "发现强敌",
	Desc = "打不过的怪物出现概率 +{Value}%",
	EffectModule = EffectModule.ExploreEnemy,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "EnemyWeight",
		Chance = 100,
		CompareFightPower = 1,
		EnemyWeightCondition = {
			CompareWin = 2,
		},
		CalculateType = CalculateType.Percent,
	},
}
SkillConfig[SkillID.Id3290] =
{
	Id = 3290,
	Name = "风元素队员战力+",
	Desc = "探索中，风元素队员战力 +{Value}%",
	Dialog = "大家都要健健康康哒~",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Team,
		Element = 210003,
	},
	Effect = {
		EffectAttribute = "FightPower",
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id3291] =
{
	Id = 3291,
	Name = "发现菜鸡",
	Desc = "打得过的敌人出现概率 +{Value}%",
	Dialog = "大家有什么要反馈的吗？",
	EffectModule = EffectModule.ExploreEnemy,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "EnemyWeight",
		Chance = 100,
		CompareFightPower = 2,
		EnemyWeightCondition = {
			CompareWin = 1,
		},
		CalculateType = CalculateType.Percent,
	},
}
SkillConfig[SkillID.Id3292] =
{
	Id = 3292,
	Name = "全队非美食星生命+",
	Desc = "非美食星队员生命 +{Value}",
	Dialog = "吃点胃药，就可以开动啦~~",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Team,
		Tag = 
		{
			560204,
		},
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200001,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id3293] =
{
	Id = 3293,
	Name = "全队非美食星忍耐+",
	Desc = "非美食星队员忍耐 +{Value}",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Team,
		Tag = 
		{
			560204,
		},
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200003,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id3294] =
{
	Id = 3294,
	Name = "超级恢复",
	Desc = "5回合后，回血 {Value}%",
	Dialog = "唔…只想宅在家里…",
	EffectModule = EffectModule.Battle,
	BattleParameter = {
		StartRound = 5,
		IntervalRound = 1,
		Limited = 1,
	},
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "Recovery",
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id3295] =
{
	Id = 3295,
	Name = "超级战吼",
	Desc = "5回合后，攻击 +{Value}",
	EffectModule = EffectModule.Battle,
	BattleParameter = {
		StartRound = 5,
		IntervalRound = 1,
		Limited = 1,
	},
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200002,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id3296] =
{
	Id = 3296,
	Name = "超级全队恢复",
	Desc = "5回合后，全队回血 {Value}%",
	EffectModule = EffectModule.Battle,
	BattleParameter = {
		StartRound = 5,
		IntervalRound = 1,
		Limited = 1,
	},
	EffectRange = {
		EffectScope = EffectScope.Team,
	},
	Effect = {
		EffectAttribute = "Recovery",
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id3297] =
{
	Id = 3297,
	Name = "超级全队战吼",
	Desc = "5回合后，全队攻击 +{Value}",
	EffectModule = EffectModule.Battle,
	BattleParameter = {
		StartRound = 5,
		IntervalRound = 1,
		Limited = 1,
	},
	EffectRange = {
		EffectScope = EffectScope.Team,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200002,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id3298] =
{
	Id = 3298,
	Name = "探索时间-",
	Desc = "探索等待时间 -{Value}%",
	Dialog = "快上车，马上就要出发了！",
	EffectModule = EffectModule.ExploreTime,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "ExploreTime",
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
}
SkillConfig[SkillID.Id3299] =
{
	Id = 3299,
	Name = "躲避强敌",
	Desc = "打不过的怪物出现概率 -{Value}%",
	EffectModule = EffectModule.ExploreEnemy,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "EnemyWeight",
		Chance = 100,
		CompareFightPower = 1,
		EnemyWeightCondition = {
			CompareWin = 2,
		},
		CalculateType = CalculateType.Percent,
	},
}
SkillConfig[SkillID.Id3300] =
{
	Id = 3300,
	Name = "敌人战力-",
	Desc = "敌人战力 -{Value}%",
	Dialog = "别动手了~我们都是朋友~~",
	EffectModule = EffectModule.ExploreEnemy,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "EnemyFightPower",
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
}
SkillConfig[SkillID.Id3301] =
{
	Id = 3301,
	Name = "敌人捕捉率+",
	Desc = "敌人捕捉率 +{Value}%",
	EffectModule = EffectModule.ExploreCatch,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "PetCatchSuccessChance",
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
}
SkillConfig[SkillID.Id3302] =
{
	Id = 3302,
	Name = "光元素队员生命+",
	Desc = "光元素队员生命 +{Value}",
	Dialog = "你们的装备都该换了！",
	EffectModule = EffectModule.BuildTeam,
	EffectCondition = {
		Element = 210004,
	},
	EffectRange = {
		EffectScope = EffectScope.Team,
		Element = 210004,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200001,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id3303] =
{
	Id = 3303,
	Name = "光元素队员攻击+",
	Desc = "光元素队员攻击 +{Value}",
	EffectModule = EffectModule.BuildTeam,
	EffectCondition = {
		Element = 210004,
	},
	EffectRange = {
		EffectScope = EffectScope.Team,
		Element = 210004,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200002,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id3304] =
{
	Id = 3304,
	Name = "每个悬疑星反派组提供全队暴击+",
	Desc = "每个悬疑星反派队员提供全队暴击 +{Value}",
	Dialog = "我会成为你最可怕的对手~",
	EffectModule = EffectModule.BuildTeam,
	MultiCount = true,
	EffectCondition = {
		Tag = 
		{
			560106,
			561707,
		},
	},
	EffectRange = {
		EffectScope = EffectScope.Team,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200004,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id3305] =
{
	Id = 3305,
	Name = "每个悬疑星反派组提供全队暴击伤害+",
	Desc = "每个悬疑星反派组提供全队暴击伤害 +{Value}%",
	EffectModule = EffectModule.BuildTeam,
	MultiCount = true,
	EffectCondition = {
		Tag = 
		{
			560106,
			561707,
		},
	},
	EffectRange = {
		EffectScope = EffectScope.Team,
	},
	Effect = {
		EffectAttribute = "CritDamage",
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id3306] =
{
	Id = 3306,
	Name = "每个水元素队员提供生命+",
	Desc = "生命 +{Value}",
	Dialog = "咬碎一切！！",
	EffectModule = EffectModule.BuildTeam,
	MultiCount = true,
	EffectCondition = {
		Element = 210001,
	},
	EffectRange = {
		EffectScope = EffectScope.Team,
		Characters = 
		{
			222045,
		},
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200001,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id3307] =
{
	Id = 3307,
	Name = "每个水元素队员提供暴击+",
	Desc = "暴击 +{Value}",
	EffectModule = EffectModule.BuildTeam,
	MultiCount = true,
	EffectCondition = {
		Element = 210001,
	},
	EffectRange = {
		EffectScope = EffectScope.Team,
		Characters = 
		{
			222045,
		},
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200004,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id3308] =
{
	Id = 3308,
	Name = "全队非海洋星攻击+",
	Desc = "非海洋星队员攻击 +{Value}",
	Dialog = "真正的捕猎就要直面死亡！",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Team,
		Tag = 
		{
			560207,
		},
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200002,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id3309] =
{
	Id = 3309,
	Name = "全队忍耐+",
	Desc = "全队忍耐 +{Value}",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Team,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200003,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id3310] =
{
	Id = 3310,
	Name = "每个博物馆星队员提供生命+",
	Desc = "每个博物馆星队员使生命 +{Value}",
	Dialog = "用心感受，艺术的生命！",
	EffectModule = EffectModule.BuildTeam,
	MultiCount = true,
	EffectCondition = {
		Tag = 
		{
			560105,
		},
	},
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200001,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id3311] =
{
	Id = 3311,
	Name = "每个博物馆星队员提供攻击+",
	Desc = "每个博物馆星队员使攻击 +{Value}",
	EffectModule = EffectModule.BuildTeam,
	MultiCount = true,
	EffectCondition = {
		Tag = 
		{
			560105,
		},
	},
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200002,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id3312] =
{
	Id = 3312,
	Name = "敌人忍耐-",
	Desc = "敌人忍耐 -{Value}",
	Dialog = "嘿嘿，又能找点新样本了。",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "SpecificEnemyAbility",
		EffectValue = 200003,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id3313] =
{
	Id = 3313,
	Name = "每个火元素队员提供攻击+",
	Desc = "攻击 +{Value}",
	Dialog = "Ready ? Go !",
	EffectModule = EffectModule.BuildTeam,
	MultiCount = true,
	EffectCondition = {
		Element = 210002,
	},
	EffectRange = {
		EffectScope = EffectScope.Team,
		Characters = 
		{
			222049,
		},
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200002,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id3314] =
{
	Id = 3314,
	Name = "超级恢复",
	Desc = "5回合后，回血 {Value}%",
	Dialog = "I love you best !",
	EffectModule = EffectModule.Battle,
	BattleParameter = {
		StartRound = 5,
		IntervalRound = 1,
		Limited = 1,
	},
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "Recovery",
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id3315] =
{
	Id = 3315,
	Name = "敌人生命-",
	Desc = "敌人生命 -{Value}%",
	Dialog = "临兵斗者皆阵列在前！",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "SpecificEnemyAbility",
		EffectValue = 200001,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id3316] =
{
	Id = 3316,
	Name = "敌人攻击-",
	Desc = "敌人攻击 -{Value}%",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "SpecificEnemyAbility",
		EffectValue = 200002,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id3317] =
{
	Id = 3317,
	Name = "全队生命+",
	Desc = "全队生命 +{Value}",
	Dialog = "愿圣光与你我同在！",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Team,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200001,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id3318] =
{
	Id = 3318,
	Name = "全队忍耐+",
	Desc = "全队忍耐 +{Value}",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Team,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200003,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id3319] =
{
	Id = 3319,
	Name = "光元素队员生命+",
	Desc = "光元素队员生命 +{Value}",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Team,
		Element = 210004,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200001,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id3320] =
{
	Id = 3320,
	Name = "光元素队员忍耐+",
	Desc = "光元素队员忍耐 +{Value}",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Team,
		Element = 210004,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200003,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id3321] =
{
	Id = 3321,
	Name = "每个火元素队员提供生命+",
	Desc = "生命 +{Value}",
	Dialog = "啊~~我好生气啊~~",
	EffectModule = EffectModule.BuildTeam,
	MultiCount = true,
	EffectCondition = {
		Element = 210002,
	},
	EffectRange = {
		EffectScope = EffectScope.Team,
		Characters = 
		{
			223002,
		},
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200001,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id3322] =
{
	Id = 3322,
	Name = "每个火元素队员提供暴击+",
	Desc = "暴击 +{Value}",
	EffectModule = EffectModule.BuildTeam,
	MultiCount = true,
	EffectCondition = {
		Element = 210002,
	},
	EffectRange = {
		EffectScope = EffectScope.Team,
		Characters = 
		{
			223002,
		},
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200004,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id3323] =
{
	Id = 3323,
	Name = "每个4星队员提供探索金币+",
	Desc = "每个金色及以上品质队员提供探索金币数量 +{Value}%",
	Dialog = "人多拥挤时注意防盗噢~",
	EffectModule = EffectModule.ExploreDrop,
	MultiCount = true,
	EffectCondition = {
		Rarity = 4,
		RarityOp = 0,
	},
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "GoodsDropNumber",
		EffectValue = 1,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id3324] =
{
	Id = 3324,
	Name = "道具掉落率+",
	Desc = "道具掉落率 +{Value}%",
	Dialog = "愿丰收降临，灾难远离~",
	EffectModule = EffectModule.ExploreDrop,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "GoodsDropChance",
		Tag = 
		{
			564305,
		},
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id3325] =
{
	Id = 3325,
	Name = "躲避强敌",
	Desc = "强敌出现概率 -{Value}%",
	EffectModule = EffectModule.ExploreEnemy,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "EnemyWeight",
		Chance = 100,
		CompareFightPower = 1,
		EnemyWeightCondition = {
			CompareWin = 2,
		},
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id3326] =
{
	Id = 3326,
	Name = "水元素打击",
	Desc = "对水元素敌人伤害 +{Value}%",
	Dialog = "试下新魔法。",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "DamageToElement",
		EffectValue = 210001,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id3327] =
{
	Id = 3327,
	Name = "火元素打击",
	Desc = "对火元素敌人伤害 +{Value}%",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "DamageToElement",
		EffectValue = 210002,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id3328] =
{
	Id = 3328,
	Name = "风元素打击",
	Desc = "对风元素敌人伤害 +{Value}%",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "DamageToElement",
		EffectValue = 210003,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id3329] =
{
	Id = 3329,
	Name = "每个风元素队员组提供全队生命+",
	Desc = "每个风元素队员提供全队生命 +{Value}",
	Dialog = "有谁身体不舒服吗？",
	EffectModule = EffectModule.BuildTeam,
	MultiCount = true,
	EffectCondition = {
		Element = 210003,
	},
	EffectRange = {
		EffectScope = EffectScope.Team,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200001,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id3330] =
{
	Id = 3330,
	Name = "每个风元素队员组提供全队攻击+",
	Desc = "每个风元素队员提供全队攻击 +{Value}",
	EffectModule = EffectModule.BuildTeam,
	MultiCount = true,
	EffectCondition = {
		Element = 210003,
	},
	EffectRange = {
		EffectScope = EffectScope.Team,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200002,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id3331] =
{
	Id = 3331,
	Name = "每个水元素队员组提供攻击+",
	Desc = "每个水元素队员提供攻击 +{Value}",
	Dialog = "嘘，恶魔靠近了。",
	EffectModule = EffectModule.BuildTeam,
	MultiCount = true,
	EffectCondition = {
		Element = 210001,
	},
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200002,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id3332] =
{
	Id = 3332,
	Name = "每个暗元素队员组提供暴击+",
	Desc = "每个暗元素队员提供暴击 +{Value}",
	EffectModule = EffectModule.BuildTeam,
	MultiCount = true,
	EffectCondition = {
		Element = 210005,
	},
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200004,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id3333] =
{
	Id = 3333,
	Name = "3回合后，每回合全队回血%",
	Desc = "3回合后，每回合全队回血 {Value}%，最多4次",
	Dialog = "自然的奇迹！",
	EffectModule = EffectModule.Battle,
	BattleParameter = {
		StartRound = 3,
		IntervalRound = 1,
		Limited = 4,
	},
	EffectRange = {
		EffectScope = EffectScope.Team,
	},
	Effect = {
		EffectAttribute = "Recovery",
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id3334] =
{
	Id = 3334,
	Name = "3回合后，每回合全队回血",
	Desc = "3回合后，每回合全队回血 {Value}，最多4次",
	EffectModule = EffectModule.Battle,
	BattleParameter = {
		StartRound = 3,
		IntervalRound = 1,
		Limited = 4,
	},
	EffectRange = {
		EffectScope = EffectScope.Team,
	},
	Effect = {
		EffectAttribute = "Recovery",
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id3335] =
{
	Id = 3335,
	Name = "每个八仙组队员使全队忍耐+",
	Desc = "全队忍耐 +{Value}",
	EffectModule = EffectModule.BuildTeam,
	MultiCount = true,
	EffectCondition = {
		Tag = 
		{
			562930,
		},
	},
	EffectRange = {
		EffectScope = EffectScope.Team,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200003,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id3336] =
{
	Id = 3336,
	Name = "每个八仙组队员使全队生命+",
	Desc = "全队生命 +{Value}",
	EffectModule = EffectModule.BuildTeam,
	MultiCount = true,
	EffectCondition = {
		Tag = 
		{
			562930,
		},
	},
	EffectRange = {
		EffectScope = EffectScope.Team,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200001,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id3337] =
{
	Id = 3337,
	Name = "每个八仙组队员使全队暴击+",
	Desc = "全队暴击 +{Value}",
	EffectModule = EffectModule.BuildTeam,
	MultiCount = true,
	EffectCondition = {
		Tag = 
		{
			562930,
		},
	},
	EffectRange = {
		EffectScope = EffectScope.Team,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200004,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id3338] =
{
	Id = 3338,
	Name = "每个八仙组队员使全队攻击+",
	Desc = "全队攻击 +{Value}",
	EffectModule = EffectModule.BuildTeam,
	MultiCount = true,
	EffectCondition = {
		Tag = 
		{
			562930,
		},
	},
	EffectRange = {
		EffectScope = EffectScope.Team,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200002,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id3339] =
{
	Id = 3339,
	Name = "每个八仙组队员使全队亲和+",
	Desc = "全队亲和 +{Value}",
	EffectModule = EffectModule.BuildTeam,
	MultiCount = true,
	EffectCondition = {
		Tag = 
		{
			562930,
		},
	},
	EffectRange = {
		EffectScope = EffectScope.Team,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200006,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id3340] =
{
	Id = 3340,
	Name = "每个八仙组队员使全队力气+",
	Desc = "全队力气 +{Value}",
	EffectModule = EffectModule.BuildTeam,
	MultiCount = true,
	EffectCondition = {
		Tag = 
		{
			562930,
		},
	},
	EffectRange = {
		EffectScope = EffectScope.Team,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200007,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id3341] =
{
	Id = 3341,
	Name = "每个八仙组队员使全队技巧+",
	Desc = "全队技巧 +{Value}",
	EffectModule = EffectModule.BuildTeam,
	MultiCount = true,
	EffectCondition = {
		Tag = 
		{
			562930,
		},
	},
	EffectRange = {
		EffectScope = EffectScope.Team,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200005,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id3342] =
{
	Id = 3342,
	Name = "每个八仙组队员使全队智力+",
	Desc = "全队智力 +{Value}",
	EffectModule = EffectModule.BuildTeam,
	MultiCount = true,
	EffectCondition = {
		Tag = 
		{
			562930,
		},
	},
	EffectRange = {
		EffectScope = EffectScope.Team,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200008,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id3343] =
{
	Id = 3343,
	Name = "每个光元素队员使生命+",
	Desc = "每个光元素队员使自身生命 +{Value}",
	Dialog = "准备！进攻！",
	EffectModule = EffectModule.BuildTeam,
	MultiCount = true,
	EffectCondition = {
		Element = 210004,
	},
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200001,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id3344] =
{
	Id = 3344,
	Name = "每个象棋组队员使生命+",
	Desc = "每个象棋组队员使自身生命 +{Value}",
	EffectModule = EffectModule.BuildTeam,
	MultiCount = true,
	EffectCondition = {
		Tag = 
		{
			562931,
		},
	},
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200001,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id3345] =
{
	Id = 3345,
	Name = "每个光元素队员使攻击+",
	Desc = "每个光元素队员使自身攻击 +{Value}",
	Dialog = "助我剿灭敌寇！",
	EffectModule = EffectModule.BuildTeam,
	MultiCount = true,
	EffectCondition = {
		Element = 210004,
	},
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200002,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id3346] =
{
	Id = 3346,
	Name = "每个象棋组队员使攻击+",
	Desc = "每个象棋组队员使自身攻击 +{Value}",
	EffectModule = EffectModule.BuildTeam,
	MultiCount = true,
	EffectCondition = {
		Tag = 
		{
			562931,
		},
	},
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200002,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id3347] =
{
	Id = 3347,
	Name = "敌人忍耐-",
	Desc = "敌人忍耐 -{Value}",
	Dialog = "用神之怒惩罚敌人！",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "SpecificEnemyAbility",
		EffectValue = 200003,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id3348] =
{
	Id = 3348,
	Name = "身后的攻击型队员攻击+",
	Desc = "身后2名攻击型队员攻击 +{Value}",
	Dialog = "我们的据点无懈可击！",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.RelativePosition,
		PositionValue = 
		{
			1,2,
		},
		Tag = 
		{
			561208,
		},
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200002,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id3349] =
{
	Id = 3349,
	Name = "身前的防御型队员忍耐+",
	Desc = "身前2名防御型队员忍耐 +{Value}",
	Dialog = "誓卫吾王！吾剑所向！",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.RelativePosition,
		PositionValue = 
		{
			-1,-2,
		},
		Tag = 
		{
			561207,
		},
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200003,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id3350] =
{
	Id = 3350,
	Name = "敌人忍耐-",
	Desc = "敌人忍耐 -{Value}",
	Dialog = "陛下，小的戴哪顶帽子好？",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "SpecificEnemyAbility",
		EffectValue = 200003,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id3351] =
{
	Id = 3351,
	Name = "身后的攻击型队员攻击+",
	Desc = "身后两名攻击型队员攻击 +{Value}",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.RelativePosition,
		PositionValue = 
		{
			1,2,
		},
		Tag = 
		{
			561208,
		},
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200002,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id3352] =
{
	Id = 3352,
	Name = "身前的防御型队员忍耐+",
	Desc = "身前2名防御型队员忍耐 +{Value}",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.RelativePosition,
		PositionValue = 
		{
			-1,-2,
		},
		Tag = 
		{
			561207,
		},
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200003,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id3353] =
{
	Id = 3353,
	Name = "躲避强敌",
	Desc = "强敌出现概率 -{Value}%",
	Dialog = "青山不改，绿水长流。",
	EffectModule = EffectModule.ExploreEnemy,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "EnemyWeight",
		Chance = 100,
		CompareFightPower = 1,
		EnemyWeightCondition = {
			CompareWin = 2,
		},
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id3354] =
{
	Id = 3354,
	Name = "探索金币+",
	Desc = "探索金币数量 +{Value}%",
	Dialog = "地上捡到宝~",
	EffectModule = EffectModule.ExploreDrop,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "GoodsDropNumber",
		EffectValue = 1,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id3355] =
{
	Id = 3355,
	Name = "全队战力+",
	Desc = "全队战力 +{Value}%",
	Dialog = "大家跟着我，深呼吸~",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Team,
	},
	Effect = {
		EffectAttribute = "FightPower",
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id3356] =
{
	Id = 3356,
	Name = "敌人战力-",
	Desc = "敌人战力 -{Value}%",
	Dialog = "身正不怕影子斜~",
	EffectModule = EffectModule.ExploreEnemy,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "EnemyFightPower",
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id3357] =
{
	Id = 3357,
	Name = "探索时间-",
	Desc = "探索等待时间 -{Value}%",
	Dialog = "我们会快去快回哒~",
	EffectModule = EffectModule.ExploreTime,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "ExploreTime",
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id3358] =
{
	Id = 3358,
	Name = "全队攻击型队员暴率+",
	Desc = "全队攻击型队员暴率 +{Value}%",
	Dialog = "嘿！祝大家心想事成！",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Team,
		Tag = 
		{
			561208,
		},
	},
	Effect = {
		EffectAttribute = "CritChance",
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id3359] =
{
	Id = 3359,
	Name = "全队防御型队员受到暴伤+",
	Desc = "全队防御型队员受到的暴击伤害 -{Value}%",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Team,
		Tag = 
		{
			561207,
		},
	},
	Effect = {
		EffectAttribute = "DamageFromCritDamage",
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id3360] =
{
	Id = 3360,
	Name = "3回合后，每2回合暴率+",
	Desc = "3回合后，每2回合暴率 +{Value}",
	Dialog = "这次要闹个痛快！",
	EffectModule = EffectModule.Battle,
	BattleParameter = {
		StartRound = 2,
		IntervalRound = 2,
		Limited = 233,
	},
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "CritDamageOnce",
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id3361] =
{
	Id = 3361,
	Name = "3回合后，每2回合必中+",
	Desc = "3回合后，每2回合{Value}概率无视敌人闪避",
	EffectModule = EffectModule.Battle,
	BattleParameter = {
		StartRound = 2,
		IntervalRound = 2,
		Limited = 233,
	},
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "DodgeIgnoreOnce",
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id3362] =
{
	Id = 3362,
	Name = "每回合，每个女队员使男队员回血",
	Desc = "每回合，每个女队员使男队员回血 {Value}，最多3次",
	Dialog = "有爱就能战胜一切~",
	EffectModule = EffectModule.Battle,
	MultiCount = true,
	EffectCondition = {
		Tag = 
		{
			561703,
		},
	},
	BattleParameter = {
		StartRound = 1,
		IntervalRound = 1,
		Limited = 3,
	},
	EffectRange = {
		EffectScope = EffectScope.Team,
		Tag = 
		{
			561702,
		},
	},
	Effect = {
		EffectAttribute = "Recovery",
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id3363] =
{
	Id = 3363,
	Name = "每回合，每个男队员使女队员攻击+",
	Desc = "每回合，每个男队员使女队员攻击 +{Value}，最多3次",
	EffectModule = EffectModule.Battle,
	MultiCount = true,
	EffectCondition = {
		Tag = 
		{
			561702,
		},
	},
	BattleParameter = {
		StartRound = 1,
		IntervalRound = 1,
		Limited = 3,
	},
	EffectRange = {
		EffectScope = EffectScope.Team,
		Tag = 
		{
			561703,
		},
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200002,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id3364] =
{
	Id = 3364,
	Name = "全队智力+",
	Desc = "全队智力 +{Value}%",
	Dialog = "这道题我会！",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Team,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200008,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id3365] =
{
	Id = 3365,
	Name = "风元素敌人战力-",
	Desc = "风元素敌人战力 -{Value}%",
	Dialog = "这个辣度可以吗？",
	EffectModule = EffectModule.ExploreEnemy,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "EnemyFightPower",
		Element = 210003,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id3366] =
{
	Id = 3366,
	Name = "火元素队员战力+",
	Desc = "火元素队员战力 +{Value}%",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Team,
		Element = 210002,
	},
	Effect = {
		EffectAttribute = "FightPower",
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id3367] =
{
	Id = 3367,
	Name = "水元素敌人战力-",
	Desc = "水元素敌人战力 -{Value}%",
	Dialog = "填肚子又清火的面来了！",
	EffectModule = EffectModule.ExploreEnemy,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "EnemyFightPower",
		Element = 210001,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id3368] =
{
	Id = 3368,
	Name = "风元素队员战力+",
	Desc = "风元素队员战力 +{Value}%",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Team,
		Element = 210003,
	},
	Effect = {
		EffectAttribute = "FightPower",
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id3369] =
{
	Id = 3369,
	Name = "光元素敌人战力-",
	Desc = "光元素敌人战力 -{Value}%",
	Dialog = "闻着呛，吃着香。",
	EffectModule = EffectModule.ExploreEnemy,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "EnemyFightPower",
		Element = 210004,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id3370] =
{
	Id = 3370,
	Name = "暗元素队员战力+",
	Desc = "暗元素敌人战力 +{Value}%",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Team,
		Element = 210005,
	},
	Effect = {
		EffectAttribute = "FightPower",
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id3371] =
{
	Id = 3371,
	Name = "水元素敌人攻击-",
	Desc = "水元素敌人攻击 -{Value}%",
	Dialog = "别怕臭，先吃吃看！",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "SpecificEnemyAbility",
		EffectValue = 200002,
		Element = 210001,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id3372] =
{
	Id = 3372,
	Name = "风元素队员忍耐+",
	Desc = "风元素队员忍耐 +{Value}",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Team,
		Element = 210003,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200003,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id3373] =
{
	Id = 3373,
	Name = "暗元素敌人暴击-",
	Desc = "暗元素敌人暴击 -{Value}",
	Dialog = "吸溜吸溜着就习惯啦~",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "SpecificEnemyAbility",
		EffectValue = 200004,
		Element = 210005,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id3374] =
{
	Id = 3374,
	Name = "光元素队员生命+",
	Desc = "光元素队员生命 +{Value}",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Team,
		Element = 210004,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200002,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id3375] =
{
	Id = 3375,
	Name = "风元素敌人忍耐-",
	Desc = "风元素敌人忍耐 -{Value}",
	Dialog = "嫩嫩的馅料~",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "SpecificEnemyAbility",
		EffectValue = 200003,
		Element = 210003,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id3376] =
{
	Id = 3376,
	Name = "火元素队员攻击+",
	Desc = "火元素队员攻击 +{Value}",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Team,
		Element = 210002,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200001,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id3377] =
{
	Id = 3377,
	Name = "自身及身后队员攻击+",
	Desc = "攻击 +{Value}",
	Dialog = "有味道的咖啡喝吗？",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.RelativePosition,
		PositionValue = 
		{
			5,4,3,2,1,0,
		},
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200002,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id3378] =
{
	Id = 3378,
	Name = "自身及身后队员暴击+",
	Desc = "暴击 +{Value}",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.RelativePosition,
		PositionValue = 
		{
			5,4,3,2,1,0,
		},
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200004,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id3379] =
{
	Id = 3379,
	Name = "每回合攻击+",
	Desc = "每回合，全队攻击 +{Value}，最多3次",
	Dialog = "啊，宝贝，你醉了。",
	EffectModule = EffectModule.Battle,
	BattleParameter = {
		StartRound = 1,
		IntervalRound = 1,
		Limited = 3,
	},
	EffectRange = {
		EffectScope = EffectScope.Team,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200002,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id3380] =
{
	Id = 3380,
	Name = "4回合后，全队暴击伤害+",
	Desc = "3回合后，全队暴击伤害 +{Value}%",
	EffectModule = EffectModule.Battle,
	BattleParameter = {
		StartRound = 3,
		IntervalRound = 1,
		Limited = 233,
	},
	EffectRange = {
		EffectScope = EffectScope.Team,
	},
	Effect = {
		EffectAttribute = "CritDamageOnce",
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id3381] =
{
	Id = 3381,
	Name = "升级消耗+",
	Desc = "升级要求的金币 -{Value}%",
	EffectModule = EffectModule.CharacterLevelUp,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "CharacterLevelUpCost",
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id3382] =
{
	Id = 3382,
	Name = "自身及左右技巧+",
	Desc = "自身及左右队员技巧 +{Value}%",
	Dialog = "客人脚挪挪，我扫扫叽~",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.RelativePosition,
		PositionValue = 
		{
			1,0,-1,
		},
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200005,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id3383] =
{
	Id = 3383,
	Name = "自身及左右亲和+",
	Desc = "自身及左右队员亲和 +{Value}%",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.RelativePosition,
		PositionValue = 
		{
			1,0,-1,
		},
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200006,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id3384] =
{
	Id = 3384,
	Name = "每个男队员使探索金币+",
	Desc = "每个男队员使探索金币 + {Value}%",
	Dialog = "亲爱的，出去玩吗？",
	EffectModule = EffectModule.ExploreDrop,
	MultiCount = true,
	EffectCondition = {
		Tag = 
		{
			561702,
		},
	},
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "GoodsDropNumber",
		EffectValue = 1,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id3385] =
{
	Id = 3385,
	Name = "每个女队员使敌人道具掉落率+",
	Desc = "每个女队员使敌人道具掉落率 +{Value}%",
	EffectModule = EffectModule.ExploreDrop,
	MultiCount = true,
	EffectCondition = {
		Tag = 
		{
			561703,
		},
	},
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "EnemyDropChance",
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id3386] =
{
	Id = 3386,
	Name = "敌人忍耐-",
	Desc = "敌人忍耐 -{Value}",
	Dialog = "真的要吃掉我嘛？",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "SpecificEnemyAbility",
		EffectValue = 200003,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id3387] =
{
	Id = 3387,
	Name = "每3回合单次暴率+",
	Desc = "每3回合，本回合暴率 +{Value}%",
	EffectModule = EffectModule.Battle,
	BattleParameter = {
		StartRound = 2,
		IntervalRound = 3,
		Limited = 233,
	},
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "CritChanceOnce",
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id3388] =
{
	Id = 3388,
	Name = "战力+",
	Desc = "战力 +{Value}%",
	Dialog = "尺有所短，寸有所长！",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "FightPower",
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id3389] =
{
	Id = 3389,
	Name = "水元素敌人捕捉率+",
	Desc = "水元素敌人捕捉成功率 +{Value}%",
	EffectModule = EffectModule.ExploreCatch,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "PetCatchSuccessChance",
		Element = 210001,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id3390] =
{
	Id = 3390,
	Name = "全队生命+",
	Desc = "全队生命 +{Value}%",
	Dialog = "都动起来！",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Team,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200001,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id3391] =
{
	Id = 3391,
	Name = "全队力气+",
	Desc = "全队力气 +{Value}",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Team,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200007,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id3392] =
{
	Id = 3392,
	Name = "全队生命+",
	Desc = "全队生命 +{Value}%",
	EffectModule = EffectModule.BuildTeam,
	EffectCondition = {
		SelfPosition = 1,
	},
	EffectRange = {
		EffectScope = EffectScope.Team,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200001,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id3393] =
{
	Id = 3393,
	Name = "全队力气+",
	Desc = "全队力气 +{Value}",
	EffectModule = EffectModule.BuildTeam,
	EffectCondition = {
		SelfPosition = 1,
	},
	EffectRange = {
		EffectScope = EffectScope.Team,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200007,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id3394] =
{
	Id = 3394,
	Name = "全队暴击+",
	Desc = "全队暴击 +{Value}",
	Dialog = "准备加速了！",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Team,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200004,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id3395] =
{
	Id = 3395,
	Name = "全队亲和+",
	Desc = "全队亲和 +{Value}",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Team,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200006,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id3396] =
{
	Id = 3396,
	Name = "全队暴击+",
	Desc = "全队暴击 +{Value}",
	EffectModule = EffectModule.BuildTeam,
	EffectCondition = {
		SelfPosition = 2,
	},
	EffectRange = {
		EffectScope = EffectScope.Team,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200004,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id3397] =
{
	Id = 3397,
	Name = "全队亲和+",
	Desc = "全队亲和 +{Value}",
	EffectModule = EffectModule.BuildTeam,
	EffectCondition = {
		SelfPosition = 2,
	},
	EffectRange = {
		EffectScope = EffectScope.Team,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200006,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id3398] =
{
	Id = 3398,
	Name = "攻击+",
	Desc = "攻击 +{Value}%",
	Dialog = "我要认真划水了！",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200002,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id3399] =
{
	Id = 3399,
	Name = "力气+",
	Desc = "力气 +{Value}",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200007,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id3400] =
{
	Id = 3400,
	Name = "攻击+",
	Desc = "攻击 +{Value}%",
	EffectModule = EffectModule.BuildTeam,
	EffectCondition = {
		Teamer = 
		{
			223128,
		},
	},
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200002,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id3401] =
{
	Id = 3401,
	Name = "力气+",
	Desc = "力气 +{Value}",
	EffectModule = EffectModule.BuildTeam,
	EffectCondition = {
		Teamer = 
		{
			223128,
		},
	},
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200007,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id3402] =
{
	Id = 3402,
	Name = "攻击+",
	Desc = "攻击 +{Value}%",
	Dialog = "这次划水不能输！",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200002,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id3403] =
{
	Id = 3403,
	Name = "力气+",
	Desc = "力气 +{Value}",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200007,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id3404] =
{
	Id = 3404,
	Name = "攻击+",
	Desc = "攻击 +{Value}%",
	EffectModule = EffectModule.BuildTeam,
	EffectCondition = {
		Teamer = 
		{
			223127,
		},
	},
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200002,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id3405] =
{
	Id = 3405,
	Name = "力气+",
	Desc = "力气 +{Value}",
	EffectModule = EffectModule.BuildTeam,
	EffectCondition = {
		Teamer = 
		{
			223127,
		},
	},
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200007,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id3406] =
{
	Id = 3406,
	Name = "全队攻击+",
	Desc = "全队攻击 +{Value}%",
	Dialog = "我就跟着大家啦~",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Team,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200002,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id3407] =
{
	Id = 3407,
	Name = "全队技巧+",
	Desc = "全队技巧 +{Value}",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Team,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200005,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id3408] =
{
	Id = 3408,
	Name = "全队攻击+",
	Desc = "全队攻击 +{Value}%",
	EffectModule = EffectModule.BuildTeam,
	EffectCondition = {
		SelfPosition = -1,
	},
	EffectRange = {
		EffectScope = EffectScope.Team,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200002,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id3409] =
{
	Id = 3409,
	Name = "全队技巧+",
	Desc = "全队技巧 +{Value}",
	EffectModule = EffectModule.BuildTeam,
	EffectCondition = {
		SelfPosition = -1,
	},
	EffectRange = {
		EffectScope = EffectScope.Team,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200005,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id3410] =
{
	Id = 3410,
	Name = "全员亲和+",
	Desc = "全员亲和 +{Value}",
	Dialog = "我会加油的，上吧！",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Team,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200006,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id3411] =
{
	Id = 3411,
	Name = "全员力气+",
	Desc = "全员力气 +{Value}",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Team,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200007,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id3412] =
{
	Id = 3412,
	Name = "每个输出队员使生命+",
	Desc = "每个输出队员使生命 +{Value}",
	Dialog = "获胜率...是秘密。",
	EffectModule = EffectModule.BuildTeam,
	MultiCount = true,
	EffectCondition = {
		Tag = 
		{
			561208,
		},
	},
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200001,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id3413] =
{
	Id = 3413,
	Name = "每3回合受到暴击伤害-",
	Desc = "每3回合，本回合受到暴击伤害-{Value}%",
	Dialog = "真是的，现在才让我上场。",
	EffectModule = EffectModule.Battle,
	BattleParameter = {
		StartRound = 2,
		IntervalRound = 3,
		Limited = 233,
	},
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "DamageFromCritDamageOnce",
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id3414] =
{
	Id = 3414,
	Name = "攻击+",
	Desc = "攻击 +{Value}",
	Dialog = "上场喵，出击喵~",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200002,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id3415] =
{
	Id = 3415,
	Name = "每个喵星人使攻击+",
	Desc = "每个喵星人使攻击 +{Value}",
	EffectModule = EffectModule.BuildTeam,
	MultiCount = true,
	EffectCondition = {
		Tag = 
		{
			561309,
		},
	},
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200002,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id3416] =
{
	Id = 3416,
	Name = "躲避强敌",
	Desc = "打不过的敌人出现率-{Value}%",
	Dialog = "先让我来吓吓对面吧？",
	EffectModule = EffectModule.ExploreEnemy,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "EnemyWeight",
		Chance = 100,
		CompareFightPower = 1,
		EnemyWeightCondition = {
			CompareWin = 2,
		},
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id3417] =
{
	Id = 3417,
	Name = "全队生命+",
	Desc = "全队生命 +{Value}%",
	Dialog = "这样的阵容搭配，还不错嘛。",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Team,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200001,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id3418] =
{
	Id = 3418,
	Name = "智力+",
	Desc = "全队智力 +{Value}",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Team,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200008,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id3419] =
{
	Id = 3419,
	Name = "暗元素敌人掉落率+",
	Desc = "暗元素敌人道具掉落概率 +{Value}%",
	Dialog = "呜…打架…我，我会加油的。",
	EffectModule = EffectModule.ExploreDrop,
	EffectRange = {
		EffectScope = EffectScope.Self,
		Element = 210005,
	},
	Effect = {
		EffectAttribute = "EnemyDropChance",
		Element = 210005,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id3420] =
{
	Id = 3420,
	Name = "全队技巧+",
	Desc = "全队技巧 +{Value}",
	Dialog = "打架了吗？好耶好耶！",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Team,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200005,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id3421] =
{
	Id = 3421,
	Name = "全队智力+",
	Desc = "全队智力 +{Value}",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Team,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200008,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id3422] =
{
	Id = 3422,
	Name = "每个男性使生命+",
	Desc = "每个男性队员使生命 +{Value}",
	Dialog = "对面仁兄，你印堂发黑啊。",
	EffectModule = EffectModule.BuildTeam,
	MultiCount = true,
	EffectCondition = {
		Tag = 
		{
			561702,
		},
	},
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200001,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id3423] =
{
	Id = 3423,
	Name = "每个女性使攻击+",
	Desc = "每个女性队员使攻击 +{Value}",
	EffectModule = EffectModule.BuildTeam,
	MultiCount = true,
	EffectCondition = {
		Tag = 
		{
			561703,
		},
	},
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200002,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id3424] =
{
	Id = 3424,
	Name = "敌人战力+",
	Desc = "敌人战力 +{Value}%",
	EffectModule = EffectModule.ExploreEnemy,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "EnemyFightPower",
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id3425] =
{
	Id = 3425,
	Name = "探索金币+",
	Desc = "金币掉落数量 +{Value}%",
	EffectModule = EffectModule.ExploreDrop,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "GoodsDropNumber",
		EffectValue = 1,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id3426] =
{
	Id = 3426,
	Name = "美食星队员技巧+",
	Desc = "美食星队员技巧 +{Value}",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Team,
		Tag = 
		{
			560104,
		},
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200005,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id3427] =
{
	Id = 3427,
	Name = "美食星队员亲和+",
	Desc = "美食星队员亲和 +{Value}",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Team,
		Tag = 
		{
			560104,
		},
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200006,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id3428] =
{
	Id = 3428,
	Name = "美食星队员力气+",
	Desc = "美食星队员力气 +{Value}",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Team,
		Tag = 
		{
			560104,
		},
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200007,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id3429] =
{
	Id = 3429,
	Name = "美食星队员智力+",
	Desc = "美食星队员智力 +{Value}",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Team,
		Tag = 
		{
			560104,
		},
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200008,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id3430] =
{
	Id = 3430,
	Name = "每个光元素队员使生命+",
	Desc = "每个光元素队员使全队生命 +{Value}",
	EffectModule = EffectModule.BuildTeam,
	MultiCount = true,
	EffectCondition = {
		Element = 210004,
	},
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200001,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id3431] =
{
	Id = 3431,
	Name = "每个光元素队员使攻击+",
	Desc = "每个光元素队员使全队攻击 +{Value}",
	EffectModule = EffectModule.BuildTeam,
	MultiCount = true,
	EffectCondition = {
		Element = 210004,
	},
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200002,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id3432] =
{
	Id = 3432,
	Name = "每个水元素队员使生命+",
	Desc = "每个水元素队员使生命 +{Value}",
	EffectModule = EffectModule.BuildTeam,
	MultiCount = true,
	EffectCondition = {
		Element = 210001,
	},
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200001,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id3433] =
{
	Id = 3433,
	Name = "每个水元素队员使恢复+",
	Desc = "每回合，每个水元素队员使回血{Value}，最多5次",
	EffectModule = EffectModule.Battle,
	MultiCount = true,
	EffectCondition = {
		Element = 210001,
	},
	BattleParameter = {
		StartRound = 1,
		IntervalRound = 1,
		Limited = 5,
	},
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "Recovery",
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id3434] =
{
	Id = 3434,
	Name = "每个美食星队员使攻击+",
	Desc = "每个美食星队员使攻击 +{Value}",
	EffectModule = EffectModule.BuildTeam,
	MultiCount = true,
	EffectCondition = {
		Tag = 
		{
			560104,
		},
	},
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200002,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id3435] =
{
	Id = 3435,
	Name = "全队美食星队员生命+",
	Desc = "美食星队员生命 +{Value}",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Team,
		Tag = 
		{
			560104,
		},
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200001,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id3436] =
{
	Id = 3436,
	Name = "每个肉盾型队员提供全队生命+",
	Desc = "每个防御型队员使全队生命 +{Value}",
	EffectModule = EffectModule.BuildTeam,
	MultiCount = true,
	EffectCondition = {
		Tag = 
		{
			561207,
		},
	},
	EffectRange = {
		EffectScope = EffectScope.Team,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200001,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id3437] =
{
	Id = 3437,
	Name = "每个肉盾型队员提供全队亲和+",
	Desc = "每个防御型队员使全队亲和 +{Value}",
	EffectModule = EffectModule.BuildTeam,
	MultiCount = true,
	EffectCondition = {
		Tag = 
		{
			561207,
		},
	},
	EffectRange = {
		EffectScope = EffectScope.Team,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200006,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id3438] =
{
	Id = 3438,
	Name = "每个肉盾型队员提供全队攻击+",
	Desc = "每个防御型队员使全队攻击 -{Value}",
	EffectModule = EffectModule.BuildTeam,
	MultiCount = true,
	EffectCondition = {
		Tag = 
		{
			561207,
		},
	},
	EffectRange = {
		EffectScope = EffectScope.Team,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200002,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id3439] =
{
	Id = 3439,
	Name = "每个肉盾型队员提供全队力气+",
	Desc = "每个防御型队员使全队力气 +{Value}",
	EffectModule = EffectModule.BuildTeam,
	MultiCount = true,
	EffectCondition = {
		Tag = 
		{
			561207,
		},
	},
	EffectRange = {
		EffectScope = EffectScope.Team,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200007,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id3440] =
{
	Id = 3440,
	Name = "全队女性队员生命+",
	Desc = "女性队员生命 +{Value}",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Team,
		Tag = 
		{
			561703,
		},
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200001,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id3441] =
{
	Id = 3441,
	Name = "全体女性队员亲和+",
	Desc = "女性队员亲和 +{Value}",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Team,
		Tag = 
		{
			561703,
		},
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200006,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id3442] =
{
	Id = 3442,
	Name = "水元素敌人捕捉率+",
	Desc = "水元素敌人捕捉成功率 +{Value}%",
	EffectModule = EffectModule.ExploreCatch,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "PetCatchSuccessChance",
		Element = 210001,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id3443] =
{
	Id = 3443,
	Name = "悬疑星队员生命+",
	Desc = "悬疑星队员生命 +{Value}",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Team,
		Tag = 
		{
			560106,
		},
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200001,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id3444] =
{
	Id = 3444,
	Name = "悬疑星队员智力+",
	Desc = "悬疑星队员智力 +{Value}",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Team,
		Tag = 
		{
			560106,
		},
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200008,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id3445] =
{
	Id = 3445,
	Name = "亲和+",
	Desc = "亲和 +{Value}%",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200006,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id3446] =
{
	Id = 3446,
	Name = "打工金币+",
	Desc = "打工获得金币+{Value}%",
	EffectModule = EffectModule.WorkShop,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "WorkShopGoodsNumber",
		EffectValue = 1,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id4001] =
{
	Id = 4001,
	Name = "生命+",
	Desc = "生命 +{Value}%",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200001,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
}
SkillConfig[SkillID.Id4002] =
{
	Id = 4002,
	Name = "攻击+",
	Desc = "攻击 +{Value}%",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200002,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
}
SkillConfig[SkillID.Id4003] =
{
	Id = 4003,
	Name = "生命+",
	Desc = "生命 +{Value}",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200001,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id4004] =
{
	Id = 4004,
	Name = "概率闪避敌人攻击",
	Desc = "{Value}%概率闪避攻击",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "Dodge",
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id4005] =
{
	Id = 4005,
	Name = "攻击+",
	Desc = "攻击 +{Value}",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200002,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id4006] =
{
	Id = 4006,
	Name = "暴率+",
	Desc = "暴率 +{Value}%",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "CritChance",
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id4007] =
{
	Id = 4007,
	Name = "生命+",
	Desc = "生命 +{Value}",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200001,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id4008] =
{
	Id = 4008,
	Name = "攻击+",
	Desc = "攻击 +{Value}",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200002,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id4009] =
{
	Id = 4009,
	Name = "压制敌人攻击",
	Desc = "敌人攻击 -{Value}%",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "SpecificEnemyAbility",
		EffectValue = 200002,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
}
SkillConfig[SkillID.Id4010] =
{
	Id = 4010,
	Name = "压制敌人暴击",
	Desc = "敌人暴击 -{Value}",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "SpecificEnemyAbility",
		EffectValue = 200004,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
}
SkillConfig[SkillID.Id4011] =
{
	Id = 4011,
	Name = "战力+",
	Desc = "战力 +{Value}%",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "FightPower",
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id4012] =
{
	Id = 4012,
	Name = "全队攻击+",
	Desc = "全队攻击 +{Value}%",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Team,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200002,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id4013] =
{
	Id = 4013,
	Name = "生命+",
	Desc = "生命 +{Value}",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200001,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
}
SkillConfig[SkillID.Id4014] =
{
	Id = 4014,
	Name = "攻击+",
	Desc = "攻击 +{Value}",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200002,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
}
SkillConfig[SkillID.Id4015] =
{
	Id = 4015,
	Name = "攻击+",
	Desc = "攻击 +{Value}",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200002,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
}
SkillConfig[SkillID.Id4016] =
{
	Id = 4016,
	Name = "光元素免伤",
	Desc = "受光元素敌人伤害 -{Value}%",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "DamageFromElement",
		EffectValue = 210004,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
}
SkillConfig[SkillID.Id4017] =
{
	Id = 4017,
	Name = "攻击+",
	Desc = "攻击 +{Value}",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200002,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
}
SkillConfig[SkillID.Id4018] =
{
	Id = 4018,
	Name = "每3回合概率闪避敌人攻击",
	Desc = "每3回合{Value}%概率闪避攻击",
	EffectModule = EffectModule.Battle,
	BattleParameter = {
		StartRound = 2,
		IntervalRound = 3,
		Limited = 233,
	},
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "DodgeOnce",
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
}
SkillConfig[SkillID.Id4019] =
{
	Id = 4019,
	Name = "忍耐+",
	Desc = "忍耐 +{Value}",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200003,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
}
SkillConfig[SkillID.Id4020] =
{
	Id = 4020,
	Name = "全队攻击+",
	Desc = "全队攻击 +{Value}%",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Team,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200002,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id4021] =
{
	Id = 4021,
	Name = "全队生命+",
	Desc = "全队生命 +{Value}%",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Team,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200001,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id4022] =
{
	Id = 4022,
	Name = "生命+",
	Desc = "生命 +{Value}",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200001,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id4023] =
{
	Id = 4023,
	Name = "攻击+",
	Desc = "攻击 +{Value}",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200002,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id4024] =
{
	Id = 4024,
	Name = "恢复",
	Desc = "每回合回血 {Value}%，最多5次",
	EffectModule = EffectModule.Battle,
	BattleParameter = {
		StartRound = 1,
		IntervalRound = 1,
		Limited = 5,
	},
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "Recovery",
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id4025] =
{
	Id = 4025,
	Name = "全队暴击+",
	Desc = "全队暴击 +{Value}",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Team,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200004,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id4026] =
{
	Id = 4026,
	Name = "敌人忍耐-",
	Desc = "敌人忍耐 -{Value}",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "SpecificEnemyAbility",
		EffectValue = 200003,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id4027] =
{
	Id = 4027,
	Name = "忍耐+",
	Desc = "忍耐 +{Value}",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200003,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id4028] =
{
	Id = 4028,
	Name = "暗元素打击",
	Desc = "对暗元素敌人伤害 +{Value}%",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "DamageToElement",
		EffectValue = 210005,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id4029] =
{
	Id = 4029,
	Name = "攻击+",
	Desc = "攻击 +{Value}",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200002,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id4030] =
{
	Id = 4030,
	Name = "概率闪避敌人攻击",
	Desc = "{Value}%概率闪避攻击",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "Dodge",
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id4031] =
{
	Id = 4031,
	Name = "每5回合连击6次",
	Desc = "每6回合有{Value}%概率发动6连击",
	EffectModule = EffectModule.Battle,
	BattleParameter = {
		StartRound = 4,
		IntervalRound = 5,
		Limited = 233,
	},
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "ExtraAttackOnce",
		EffectValue = 5,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
}
SkillConfig[SkillID.Id4032] =
{
	Id = 4032,
	Name = "暴击+",
	Desc = "暴击 +{Value}",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200004,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
}
SkillConfig[SkillID.Id4033] =
{
	Id = 4033,
	Name = "忍耐+",
	Desc = "忍耐 +{Value}",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200003,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
}
SkillConfig[SkillID.Id4034] =
{
	Id = 4034,
	Name = "概率闪避敌人攻击",
	Desc = "{Value}%概率闪避攻击",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "Dodge",
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id4035] =
{
	Id = 4035,
	Name = "生命+",
	Desc = "生命 +{Value}",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200001,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id4036] =
{
	Id = 4036,
	Name = "忍耐+",
	Desc = "忍耐 +{Value}",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200003,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id4037] =
{
	Id = 4037,
	Name = "全队3回合后一次性大恢复",
	Desc = "3回合后，每回合全队回血 {Value}%，最多2次",
	EffectModule = EffectModule.Battle,
	BattleParameter = {
		StartRound = 3,
		IntervalRound = 1,
		Limited = 2,
	},
	EffectRange = {
		EffectScope = EffectScope.Team,
	},
	Effect = {
		EffectAttribute = "Recovery",
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
}
SkillConfig[SkillID.Id4038] =
{
	Id = 4038,
	Name = "光元素打击",
	Desc = "对光元素敌人伤害 +{Value}%",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "DamageToElement",
		EffectValue = 210004,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id4039] =
{
	Id = 4039,
	Name = "NPC组生命+",
	Desc = "生命 +{Value}%",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Team,
		Tag = 
		{
			562905,
		},
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200001,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id4040] =
{
	Id = 4040,
	Name = "NPC组攻击+",
	Desc = "攻击 +{Value}%",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Team,
		Tag = 
		{
			562905,
		},
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200002,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id4041] =
{
	Id = 4041,
	Name = "NPC组忍耐+",
	Desc = "忍耐 +{Value}",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Team,
		Tag = 
		{
			562905,
		},
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200003,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id4042] =
{
	Id = 4042,
	Name = "NPC组暴击+",
	Desc = "暴击 +{Value}",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Team,
		Tag = 
		{
			562905,
		},
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200004,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id4043] =
{
	Id = 4043,
	Name = "NPC组技巧+",
	Desc = "技巧 +{Value}%",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Team,
		Tag = 
		{
			562905,
		},
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200005,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id4044] =
{
	Id = 4044,
	Name = "NPC组亲和+",
	Desc = "亲和 +{Value}%",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Team,
		Tag = 
		{
			562905,
		},
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200006,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id4045] =
{
	Id = 4045,
	Name = "NPC组力气+",
	Desc = "力气 +{Value}%",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Team,
		Tag = 
		{
			562905,
		},
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200007,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id4046] =
{
	Id = 4046,
	Name = "NPC组智力+",
	Desc = "智力 +{Value}%",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Team,
		Tag = 
		{
			562905,
		},
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200008,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id4047] =
{
	Id = 4047,
	Name = "忍耐+",
	Desc = "忍耐 +{Value}",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200003,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id4048] =
{
	Id = 4048,
	Name = "忍耐+",
	Desc = "忍耐 +{Value}",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200003,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id4049] =
{
	Id = 4049,
	Name = "生命+",
	Desc = "生命 +{Value}%",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200001,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id4050] =
{
	Id = 4050,
	Name = "水元素免伤",
	Desc = "受水元素敌人伤害 -{Value}%",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "DamageFromElement",
		EffectValue = 210001,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id4051] =
{
	Id = 4051,
	Name = "生命+",
	Desc = "生命 +{Value}%",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200001,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id4052] =
{
	Id = 4052,
	Name = "攻击+",
	Desc = "攻击 +{Value}",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200002,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id4053] =
{
	Id = 4053,
	Name = "光元素免伤",
	Desc = "受光元素敌人伤害 -{Value}%",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "DamageFromElement",
		EffectValue = 210004,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id4054] =
{
	Id = 4054,
	Name = "生命+",
	Desc = "生命 +{Value}%",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200001,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id4055] =
{
	Id = 4055,
	Name = "火元素免伤",
	Desc = "受火元素敌人伤害 -{Value}%",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "DamageFromElement",
		EffectValue = 210002,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id4056] =
{
	Id = 4056,
	Name = "攻击+",
	Desc = "攻击 +{Value}",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200002,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id4057] =
{
	Id = 4057,
	Name = "火元素打击",
	Desc = "对火元素敌人伤害 +{Value}%",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "DamageToElement",
		EffectValue = 210002,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id4058] =
{
	Id = 4058,
	Name = "攻击+",
	Desc = "攻击 +{Value}%",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200002,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id4059] =
{
	Id = 4059,
	Name = "光元素打击",
	Desc = "对光元素敌人伤害 +{Value}%",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "DamageToElement",
		EffectValue = 210004,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id4060] =
{
	Id = 4060,
	Name = "攻击+",
	Desc = "攻击 +{Value}%",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200002,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id4061] =
{
	Id = 4061,
	Name = "暗元素打击",
	Desc = "对暗元素敌人伤害 +{Value}%",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "DamageToElement",
		EffectValue = 210005,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id4062] =
{
	Id = 4062,
	Name = "生命+",
	Desc = "生命 +{Value}",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200001,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id4063] =
{
	Id = 4063,
	Name = "攻击+",
	Desc = "攻击 +{Value}%",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200002,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id4064] =
{
	Id = 4064,
	Name = "压制敌人等级",
	Desc = "敌人等级 -{Value}",
	Dialog = "石化凝视！",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "EnemyLevel",
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id4065] =
{
	Id = 4065,
	Name = "生命",
	Desc = "生命 {Value}%",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200001,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id4066] =
{
	Id = 4066,
	Name = "攻击+",
	Desc = "攻击 +{Value}",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200002,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id4067] =
{
	Id = 4067,
	Name = "敌人生命+",
	Desc = "敌人生命 -{Value}%",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "SpecificEnemyAbility",
		EffectValue = 200001,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id4068] =
{
	Id = 4068,
	Name = "忍耐+",
	Desc = "忍耐 +{Value}",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200003,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id4069] =
{
	Id = 4069,
	Name = "攻击+",
	Desc = "攻击 +{Value}",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200002,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id4070] =
{
	Id = 4070,
	Name = "生命+",
	Desc = "生命 +{Value}",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200001,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id4071] =
{
	Id = 4071,
	Name = "概率闪避敌人攻击",
	Desc = "{Value}%概率闪避攻击",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "Dodge",
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id4072] =
{
	Id = 4072,
	Name = "火元素免伤",
	Desc = "受火元素敌人伤害 -{Value}%",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "DamageFromElement",
		EffectValue = 210002,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id4073] =
{
	Id = 4073,
	Name = "暴击+",
	Desc = "暴击 +{Value}",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200004,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id4074] =
{
	Id = 4074,
	Name = "力气+",
	Desc = "力气 +{Value}%",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200007,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id4075] =
{
	Id = 4075,
	Name = "亲和+",
	Desc = "亲和 +{Value}%",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200006,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id4076] =
{
	Id = 4076,
	Name = "力气+",
	Desc = "力气 +{Value}%",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200007,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id4077] =
{
	Id = 4077,
	Name = "技巧+",
	Desc = "技巧 +{Value}%",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200005,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id4078] =
{
	Id = 4078,
	Name = "力气+",
	Desc = "力气 +{Value}%",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200007,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id4079] =
{
	Id = 4079,
	Name = "智力+",
	Desc = "智力 +{Value}%",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200008,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id4080] =
{
	Id = 4080,
	Name = "技巧+",
	Desc = "技巧 +{Value}%",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200005,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id4081] =
{
	Id = 4081,
	Name = "亲和+",
	Desc = "亲和 +{Value}%",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200006,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id4082] =
{
	Id = 4082,
	Name = "亲和+",
	Desc = "亲和 +{Value}%",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200006,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id4083] =
{
	Id = 4083,
	Name = "技巧+",
	Desc = "技巧 +{Value}%",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200005,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id4084] =
{
	Id = 4084,
	Name = "智力+",
	Desc = "智力 +{Value}%",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200008,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id4085] =
{
	Id = 4085,
	Name = "技巧+",
	Desc = "技巧 +{Value}%",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200005,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id4086] =
{
	Id = 4086,
	Name = "智力+",
	Desc = "智力 +{Value}%",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200008,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id4087] =
{
	Id = 4087,
	Name = "亲和+",
	Desc = "亲和 +{Value}%",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200006,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id4088] =
{
	Id = 4088,
	Name = "技巧+",
	Desc = "生命 +{Value}%",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200005,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id4089] =
{
	Id = 4089,
	Name = "技巧+",
	Desc = "攻击 +{Value}%",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200005,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id4090] =
{
	Id = 4090,
	Name = "生命+",
	Desc = "生命 +{Value}",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200001,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id4091] =
{
	Id = 4091,
	Name = "生命+",
	Desc = "生命 +{Value}",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200001,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id4092] =
{
	Id = 4092,
	Name = "生命+",
	Desc = "生命 +{Value}",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200001,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id4093] =
{
	Id = 4093,
	Name = "忍耐+",
	Desc = "忍耐 +{Value}",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200003,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id4094] =
{
	Id = 4094,
	Name = "压制敌人生命",
	Desc = "敌人生命 -{Value}%",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "SpecificEnemyAbility",
		EffectValue = 200001,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id4095] =
{
	Id = 4095,
	Name = "生命+",
	Desc = "生命 +{Value}",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200001,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id4096] =
{
	Id = 4096,
	Name = "火元素免伤",
	Desc = "受火元素敌人伤害 -{Value}%",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "DamageFromElement",
		EffectValue = 210002,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id4097] =
{
	Id = 4097,
	Name = "暴击+",
	Desc = "暴击 +{Value}",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200004,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id4098] =
{
	Id = 4098,
	Name = "火元素打击",
	Desc = "对火元素敌人伤害 +{Value}%",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "DamageToElement",
		EffectValue = 210002,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id4099] =
{
	Id = 4099,
	Name = "面板火元素队员提供攻击+",
	Desc = "每个火元素队员提供攻击 +{Value}",
	EffectModule = EffectModule.BuildTeam,
	MultiCount = true,
	EffectCondition = {
		Element = 210002,
	},
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200002,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id4100] =
{
	Id = 4100,
	Name = "生命+",
	Desc = "生命 +{Value}",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200001,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id4101] =
{
	Id = 4101,
	Name = "攻击+",
	Desc = "攻击 +{Value}",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200002,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id4102] =
{
	Id = 4102,
	Name = "攻击+",
	Desc = "攻击 +{Value}",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200002,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id4103] =
{
	Id = 4103,
	Name = "生命+",
	Desc = "生命 +{Value}",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200001,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id4104] =
{
	Id = 4104,
	Name = "生命+",
	Desc = "生命 +{Value}",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200001,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id4105] =
{
	Id = 4105,
	Name = "攻击+",
	Desc = "攻击 +{Value}",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200002,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id4106] =
{
	Id = 4106,
	Name = "全队暴击+",
	Desc = "全队暴击 +{Value}",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Team,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200004,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id4107] =
{
	Id = 4107,
	Name = "全队忍耐+",
	Desc = "全队忍耐 +{Value}",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Team,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200003,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id4108] =
{
	Id = 4108,
	Name = "全队生命+",
	Desc = "全队生命 +{Value}%",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Team,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200001,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id4109] =
{
	Id = 4109,
	Name = "攻击+",
	Desc = "攻击 +{Value}",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200002,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id4110] =
{
	Id = 4110,
	Name = "生命+",
	Desc = "生命 +{Value}%",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200001,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id4111] =
{
	Id = 4111,
	Name = "必中术",
	Desc = "{Value}%概率无视敌人闪避",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "DodgeIgnore",
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id4112] =
{
	Id = 4112,
	Name = "暴击+",
	Desc = "暴击 +{Value}",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200004,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id4113] =
{
	Id = 4113,
	Name = "暴击伤害+",
	Desc = "暴击伤害 +{Value}%",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "CritDamage",
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id4114] =
{
	Id = 4114,
	Name = "全队忍耐+",
	Desc = "全队忍耐 +{Value}",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Team,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200003,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id4115] =
{
	Id = 4115,
	Name = "攻击+",
	Desc = "攻击 +{Value}%",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200002,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id4116] =
{
	Id = 4116,
	Name = "暴击伤害+",
	Desc = "暴击伤害 +{Value}%",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "CritDamage",
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id4117] =
{
	Id = 4117,
	Name = "全队生命+",
	Desc = "全队生命 +{Value}",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Team,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200001,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id4118] =
{
	Id = 4118,
	Name = "光元素打击",
	Desc = "对光元素敌人伤害 +{Value}%",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "DamageToElement",
		EffectValue = 210004,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id4119] =
{
	Id = 4119,
	Name = "暗元素打击",
	Desc = "对暗元素敌人伤害 +{Value}%",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "DamageToElement",
		EffectValue = 210005,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id4120] =
{
	Id = 4120,
	Name = "攻击+",
	Desc = "攻击 +{Value}",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200001,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id4121] =
{
	Id = 4121,
	Name = "攻击",
	Desc = "攻击 +{Value}%",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200002,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id4122] =
{
	Id = 4122,
	Name = "暴击伤害+",
	Desc = "暴击伤害 +{Value}%",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "CritDamage",
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id4123] =
{
	Id = 4123,
	Name = "暴率+",
	Desc = "暴率 +{Value}%",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "CritChance",
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id4124] =
{
	Id = 4124,
	Name = "火元素队员攻击+",
	Desc = "火元素队员攻击 +{Value}",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Team,
		Element = 210002,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200002,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id4125] =
{
	Id = 4125,
	Name = "风元素队员暴击+",
	Desc = "风元素队员暴击 +{Value}",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Team,
		Element = 210003,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200004,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id4126] =
{
	Id = 4126,
	Name = "光元素队员忍耐+",
	Desc = "光元素队员忍耐 +{Value}",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Team,
		Element = 210004,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200003,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id4127] =
{
	Id = 4127,
	Name = "每个博物馆星队员提供全队生命+",
	Desc = "每个博物馆队员提供全队攻击 +{Value}%",
	EffectModule = EffectModule.BuildTeam,
	MultiCount = true,
	EffectCondition = {
		Tag = 
		{
			560105,
		},
	},
	EffectRange = {
		EffectScope = EffectScope.Team,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200002,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id4128] =
{
	Id = 4128,
	Name = "每个博物馆星队员提供全队忍耐+",
	Desc = "每个博物馆队员提供全队暴击 +{Value}",
	EffectModule = EffectModule.BuildTeam,
	MultiCount = true,
	EffectCondition = {
		Tag = 
		{
			560105,
		},
	},
	EffectRange = {
		EffectScope = EffectScope.Team,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200004,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id4129] =
{
	Id = 4129,
	Name = "每个光元素队员提供全队生命+",
	Desc = "每个光元素队员提供全队生命 +{Value}",
	EffectModule = EffectModule.BuildTeam,
	MultiCount = true,
	EffectCondition = {
		Element = 210004,
	},
	EffectRange = {
		EffectScope = EffectScope.Team,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200001,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id4130] =
{
	Id = 4130,
	Name = "每个风元素队员提供全队暴击+",
	Desc = "每个风元素队员提供全队暴击 +{Value}",
	EffectModule = EffectModule.BuildTeam,
	MultiCount = true,
	EffectCondition = {
		Element = 210003,
	},
	EffectRange = {
		EffectScope = EffectScope.Team,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200004,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id4131] =
{
	Id = 4131,
	Name = "每个暗元素队员提供全队忍耐+",
	Desc = "每个暗元素队员提供全队忍耐 +{Value}",
	EffectModule = EffectModule.BuildTeam,
	MultiCount = true,
	EffectCondition = {
		Element = 210005,
	},
	EffectRange = {
		EffectScope = EffectScope.Team,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200003,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id4132] =
{
	Id = 4132,
	Name = "每个风元素队员提供全队攻击+",
	Desc = "每个风元素队员提供全队攻击 +{Value}",
	EffectModule = EffectModule.BuildTeam,
	MultiCount = true,
	EffectCondition = {
		Element = 210003,
	},
	EffectRange = {
		EffectScope = EffectScope.Team,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200002,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id4133] =
{
	Id = 4133,
	Name = "全队力气+",
	Desc = "全队力气 +{Value}%",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Team,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200007,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id4134] =
{
	Id = 4134,
	Name = "全队智力+",
	Desc = "全队智力 +{Value}%",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Team,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200008,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id4135] =
{
	Id = 4135,
	Name = "全队技巧+",
	Desc = "全队技巧 +{Value}%",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Team,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200005,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id4136] =
{
	Id = 4136,
	Name = "全队亲和+",
	Desc = "全队亲和 +{Value}%",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Team,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200006,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id4137] =
{
	Id = 4137,
	Name = "全队战力+",
	Desc = "探索中，全队战力 +{Value}%",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Team,
	},
	Effect = {
		EffectAttribute = "FightPower",
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id4138] =
{
	Id = 4138,
	Name = "压制敌人暴击",
	Desc = "敌人暴击 -{Value}",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "SpecificEnemyAbility",
		EffectValue = 200004,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id4139] =
{
	Id = 4139,
	Name = "生命+",
	Desc = "生命 +{Value}",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200001,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id4140] =
{
	Id = 4140,
	Name = "攻击+",
	Desc = "攻击 +{Value}",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200002,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id4141] =
{
	Id = 4141,
	Name = "生命+",
	Desc = "生命 +{Value}",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200001,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id4142] =
{
	Id = 4142,
	Name = "攻击+",
	Desc = "攻击 +{Value}",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200002,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id4143] =
{
	Id = 4143,
	Name = "生命+",
	Desc = "生命 +{Value}",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200001,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id4144] =
{
	Id = 4144,
	Name = "攻击+",
	Desc = "攻击 +{Value}",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200002,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id4145] =
{
	Id = 4145,
	Name = "生命+",
	Desc = "生命 +{Value}",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200001,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id4146] =
{
	Id = 4146,
	Name = "攻击+",
	Desc = "攻击 +{Value}",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200002,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id4147] =
{
	Id = 4147,
	Name = "每个男队员提供生命+",
	Desc = "生命 +{Value}",
	EffectModule = EffectModule.BuildTeam,
	MultiCount = true,
	EffectCondition = {
		Tag = 
		{
			561702,
		},
	},
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200001,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id4148] =
{
	Id = 4148,
	Name = "每个女队员提供攻击+",
	Desc = "攻击 +{Value}",
	EffectModule = EffectModule.BuildTeam,
	MultiCount = true,
	EffectCondition = {
		Tag = 
		{
			561703,
		},
	},
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200002,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id4149] =
{
	Id = 4149,
	Name = "生命+",
	Desc = "生命 +{Value}",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200001,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id4150] =
{
	Id = 4150,
	Name = "攻击+",
	Desc = "攻击 +{Value}",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200002,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id4151] =
{
	Id = 4151,
	Name = "生命+",
	Desc = "生命 +{Value}",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200001,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id4152] =
{
	Id = 4152,
	Name = "攻击+",
	Desc = "攻击 +{Value}",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200002,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id4153] =
{
	Id = 4153,
	Name = "生命+",
	Desc = "生命 +{Value}",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200001,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id4154] =
{
	Id = 4154,
	Name = "攻击+",
	Desc = "攻击 +{Value}",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200002,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id4155] =
{
	Id = 4155,
	Name = "生命+",
	Desc = "生命 +{Value}",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200001,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id4156] =
{
	Id = 4156,
	Name = "攻击+",
	Desc = "攻击 +{Value}",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200002,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id4157] =
{
	Id = 4157,
	Name = "生命+",
	Desc = "生命 +{Value}%",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200001,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id4158] =
{
	Id = 4158,
	Name = "压制敌人攻击",
	Desc = "敌人攻击 -{Value}%",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "SpecificEnemyAbility",
		EffectValue = 200002,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id4159] =
{
	Id = 4159,
	Name = "每3回合概率闪避敌人攻击",
	Desc = "每3回合{Value}%概率闪避攻击",
	EffectModule = EffectModule.Battle,
	BattleParameter = {
		StartRound = 2,
		IntervalRound = 3,
		Limited = 233,
	},
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "DodgeOnce",
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
}
SkillConfig[SkillID.Id4160] =
{
	Id = 4160,
	Name = "连击1次",
	Desc = "有{Value}%概率额外攻击1次",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "ExtraAttack",
		EffectValue = 1,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id4161] =
{
	Id = 4161,
	Name = "全队暴击+",
	Desc = "全队暴击 +{Value}",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Team,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200004,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id4162] =
{
	Id = 4162,
	Name = "全队忍耐+",
	Desc = "全队忍耐 +{Value}",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Team,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200003,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id4163] =
{
	Id = 4163,
	Name = "光元素打击",
	Desc = "对光元素敌人伤害 +{Value}%",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "DamageToElement",
		EffectValue = 210004,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id4164] =
{
	Id = 4164,
	Name = "暗元素打击",
	Desc = "对暗元素敌人伤害 +{Value}%",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "DamageToElement",
		EffectValue = 210005,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id4165] =
{
	Id = 4165,
	Name = "生命+",
	Desc = "生命 +{Value}",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200001,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id4166] =
{
	Id = 4166,
	Name = "攻击+",
	Desc = "攻击 +{Value}%",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200002,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id4167] =
{
	Id = 4167,
	Name = "攻击+",
	Desc = "攻击 +{Value}",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200002,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id4168] =
{
	Id = 4168,
	Name = "技巧+",
	Desc = "技巧 +{Value}%",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200005,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id4169] =
{
	Id = 4169,
	Name = "攻击+",
	Desc = "攻击 +{Value}",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200002,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id4170] =
{
	Id = 4170,
	Name = "概率闪避敌人攻击",
	Desc = "{Value}%概率闪避攻击",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "Dodge",
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id4171] =
{
	Id = 4171,
	Name = "生命+",
	Desc = "生命 +{Value}%",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200001,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
}
SkillConfig[SkillID.Id4172] =
{
	Id = 4172,
	Name = "攻击+",
	Desc = "攻击 +{Value}",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200002,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id4173] =
{
	Id = 4173,
	Name = "全队攻击+",
	Desc = "全队攻击 +{Value}%",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Team,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200002,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id4174] =
{
	Id = 4174,
	Name = "生命+",
	Desc = "生命 +{Value}%",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200001,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id4175] =
{
	Id = 4175,
	Name = "全队生命+",
	Desc = "全队生命 +{Value}%",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Team,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200001,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id4176] =
{
	Id = 4176,
	Name = "生命+",
	Desc = "生命 +{Value}%",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200001,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id4177] =
{
	Id = 4177,
	Name = "攻击+",
	Desc = "攻击 +{Value}",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200002,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id4178] =
{
	Id = 4178,
	Name = "全队暴击+",
	Desc = "全队暴击 +{Value}",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Team,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200004,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id4179] =
{
	Id = 4179,
	Name = "每个悬疑星队员提供攻击+",
	Desc = "攻击 +{Value}",
	EffectModule = EffectModule.BuildTeam,
	MultiCount = true,
	EffectCondition = {
		Tag = 
		{
			560106,
		},
	},
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200002,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id4180] =
{
	Id = 4180,
	Name = "全队忍耐+",
	Desc = "全队忍耐 +{Value}",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Team,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200003,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id4181] =
{
	Id = 4181,
	Name = "每个水元素队员提供生命+",
	Desc = "每个水元素队员提供生命 +{Value}",
	EffectModule = EffectModule.BuildTeam,
	MultiCount = true,
	EffectCondition = {
		Element = 210001,
	},
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200001,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id4182] =
{
	Id = 4182,
	Name = "生命+",
	Desc = "生命 +{Value}",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200001,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id4183] =
{
	Id = 4183,
	Name = "连击1次",
	Desc = "有{Value}%概率额外攻击1次",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "ExtraAttack",
		EffectValue = 1,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id4184] =
{
	Id = 4184,
	Name = "暴击伤害+",
	Desc = "暴击伤害 +{Value}%",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "CritDamage",
		Chance = 80,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id4185] =
{
	Id = 4185,
	Name = "悬疑星队员暴击+",
	Desc = "悬疑星队员暴击 +{Value}",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Team,
		Tag = 
		{
			560106,
		},
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200004,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id4186] =
{
	Id = 4186,
	Name = "暴击+",
	Desc = "暴击 +{Value}",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200004,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id4187] =
{
	Id = 4187,
	Name = "暴击+",
	Desc = "暴击 +{Value}",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200004,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id4188] =
{
	Id = 4188,
	Name = "暴击+",
	Desc = "暴击 +{Value}",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200004,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id4189] =
{
	Id = 4189,
	Name = "探索时间+",
	Desc = "探索等待时间 -{Value}%",
	EffectModule = EffectModule.ExploreTime,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "ExploreTime",
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id4190] =
{
	Id = 4190,
	Name = "生命+",
	Desc = "生命 +{Value}",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200001,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id4191] =
{
	Id = 4191,
	Name = "智力+",
	Desc = "智力 +{Value}%",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200008,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id4192] =
{
	Id = 4192,
	Name = "3星以上敌人捕捉率+",
	Desc = "紫色以上品质敌人捕捉成功率 +{Value}%",
	EffectModule = EffectModule.ExploreCatch,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "PetCatchSuccessChance",
		Element = 210001,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id4193] =
{
	Id = 4193,
	Name = "暴击+",
	Desc = "暴击 +{Value}",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200004,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
}
SkillConfig[SkillID.Id4194] =
{
	Id = 4194,
	Name = "暴击伤害+",
	Desc = "暴击伤害 +{Value}%",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "CritDamage",
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
}
SkillConfig[SkillID.Id4195] =
{
	Id = 4195,
	Name = "技巧+",
	Desc = "技巧 +{Value}%",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200005,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id4196] =
{
	Id = 4196,
	Name = "亲和+",
	Desc = "亲和 +{Value}%",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200006,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id4197] =
{
	Id = 4197,
	Name = "每个女队员提供攻击+",
	Desc = "攻击 +{Value}",
	EffectModule = EffectModule.BuildTeam,
	MultiCount = true,
	EffectCondition = {
		Tag = 
		{
			561703,
		},
	},
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200002,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id4198] =
{
	Id = 4198,
	Name = "生命+",
	Desc = "生命 +{Value}",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200001,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id4199] =
{
	Id = 4199,
	Name = "攻击+",
	Desc = "攻击 +{Value}",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200002,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id4200] =
{
	Id = 4200,
	Name = "忍耐+",
	Desc = "忍耐 +{Value}",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200003,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id4201] =
{
	Id = 4201,
	Name = "暴击+",
	Desc = "暴击 +{Value}",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200004,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id4202] =
{
	Id = 4202,
	Name = "技巧+",
	Desc = "技巧 +{Value}%",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200005,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id4203] =
{
	Id = 4203,
	Name = "亲和+",
	Desc = "亲和 +{Value}%",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200006,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id4204] =
{
	Id = 4204,
	Name = "力气+",
	Desc = "力气 +{Value}%",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200007,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id4205] =
{
	Id = 4205,
	Name = "智力+",
	Desc = "智力 +{Value}%",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200008,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id4206] =
{
	Id = 4206,
	Name = "生命+",
	Desc = "生命 +{Value}",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200001,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id4207] =
{
	Id = 4207,
	Name = "攻击+",
	Desc = "攻击 +{Value}",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200002,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id4208] =
{
	Id = 4208,
	Name = "生命+",
	Desc = "生命 +{Value}",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200001,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
}
SkillConfig[SkillID.Id4209] =
{
	Id = 4209,
	Name = "攻击+",
	Desc = "攻击 +{Value}",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200002,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
}
SkillConfig[SkillID.Id4210] =
{
	Id = 4210,
	Name = "压制敌人攻击",
	Desc = "敌人攻击 -{Value}%",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "SpecificEnemyAbility",
		EffectValue = 200002,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id4211] =
{
	Id = 4211,
	Name = "攻击+",
	Desc = "攻击 +{Value}",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200002,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id4212] =
{
	Id = 4212,
	Name = "暗元素打击",
	Desc = "对暗元素敌人伤害 +{Value}%",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "DamageToElement",
		EffectValue = 210005,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id4213] =
{
	Id = 4213,
	Name = "生命+",
	Desc = "生命 +{Value}",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200001,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id4214] =
{
	Id = 4214,
	Name = "忍耐+",
	Desc = "忍耐 +{Value}",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200003,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id4215] =
{
	Id = 4215,
	Name = "暴击+",
	Desc = "暴击 +{Value}",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200004,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id4216] =
{
	Id = 4216,
	Name = "暴击伤害+",
	Desc = "暴击伤害 +{Value}%",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "CritDamage",
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id4217] =
{
	Id = 4217,
	Name = "生命+",
	Desc = "生命 +{Value}",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200001,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id4218] =
{
	Id = 4218,
	Name = "恢复",
	Desc = "每回合回血 {Value}%，最多5次",
	EffectModule = EffectModule.Battle,
	BattleParameter = {
		StartRound = 1,
		IntervalRound = 1,
		Limited = 5,
	},
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "Recovery",
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id4219] =
{
	Id = 4219,
	Name = "暴击伤害+",
	Desc = "暴击伤害 +{Value}%",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "CritDamage",
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id4220] =
{
	Id = 4220,
	Name = "每个悬疑星队员提供攻击+",
	Desc = "攻击 +{Value}",
	EffectModule = EffectModule.BuildTeam,
	MultiCount = true,
	EffectCondition = {
		Tag = 
		{
			560106,
		},
	},
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200002,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id4221] =
{
	Id = 4221,
	Name = "生命+",
	Desc = "生命 +{Value}",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200001,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id4222] =
{
	Id = 4222,
	Name = "攻击+",
	Desc = "攻击 +{Value}%",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200002,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id4223] =
{
	Id = 4223,
	Name = "压制敌人暴击",
	Desc = "敌人暴击 -{Value}",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "SpecificEnemyAbility",
		EffectValue = 200004,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id4224] =
{
	Id = 4224,
	Name = "生命+",
	Desc = "生命 +{Value}",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200001,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id4225] =
{
	Id = 4225,
	Name = "恢复",
	Desc = "每回合回血 {Value}%，最多5次",
	EffectModule = EffectModule.Battle,
	BattleParameter = {
		StartRound = 1,
		IntervalRound = 1,
		Limited = 5,
	},
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "Recovery",
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id4226] =
{
	Id = 4226,
	Name = "生命+",
	Desc = "生命 +{Value}",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200001,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id4227] =
{
	Id = 4227,
	Name = "忍耐+",
	Desc = "忍耐 +{Value}",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200003,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id4228] =
{
	Id = 4228,
	Name = "攻击+",
	Desc = "攻击 +{Value}%",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200002,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id4229] =
{
	Id = 4229,
	Name = "生命+",
	Desc = "生命 +{Value}",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200001,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id4230] =
{
	Id = 4230,
	Name = "忍耐+",
	Desc = "忍耐 +{Value}",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200003,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id4231] =
{
	Id = 4231,
	Name = "生命+",
	Desc = "生命 +{Value}",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200001,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id4232] =
{
	Id = 4232,
	Name = "恢复",
	Desc = "每回合回血 {Value}%，最多5次",
	EffectModule = EffectModule.Battle,
	BattleParameter = {
		StartRound = 1,
		IntervalRound = 1,
		Limited = 5,
	},
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "Recovery",
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id4233] =
{
	Id = 4233,
	Name = "攻击+",
	Desc = "攻击 +{Value}%",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200002,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id4234] =
{
	Id = 4234,
	Name = "攻击+",
	Desc = "攻击 +{Value}",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200002,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id4235] =
{
	Id = 4235,
	Name = "必中术",
	Desc = "{Value}%概率无视敌人闪避",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "DodgeIgnore",
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id4236] =
{
	Id = 4236,
	Name = "生命+",
	Desc = "生命 +{Value}",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200001,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id4237] =
{
	Id = 4237,
	Name = "每3回合后受到暴击伤害-",
	Desc = "每3回合，本回合受到暴击伤害 -{Value}%",
	EffectModule = EffectModule.Battle,
	BattleParameter = {
		StartRound = 2,
		IntervalRound = 3,
		Limited = 233,
	},
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "DamageFromCritDamageOnce",
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id4238] =
{
	Id = 4238,
	Name = "生命+",
	Desc = "生命 +{Value}",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200001,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id4239] =
{
	Id = 4239,
	Name = "每回合攻击+",
	Desc = "每回合攻击 +{Value}，最多5次",
	EffectModule = EffectModule.Battle,
	BattleParameter = {
		StartRound = 1,
		IntervalRound = 1,
		Limited = 5,
	},
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200002,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id4240] =
{
	Id = 4240,
	Name = "女性队员技巧+",
	Desc = "女性队员技巧 +{Value}",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Team,
		Tag = 
		{
			561703,
		},
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200005,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id4241] =
{
	Id = 4241,
	Name = "女性队员亲和+",
	Desc = "女性队员亲和 +{Value}",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Team,
		Tag = 
		{
			561703,
		},
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200006,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id4242] =
{
	Id = 4242,
	Name = "生命+",
	Desc = "生命 +{Value}",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200001,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id4243] =
{
	Id = 4243,
	Name = "根据受击次数攻击+",
	Desc = "回合中，每次受击，攻击 +{Value}",
	EffectModule = EffectModule.Battle,
	BattleParameter = {
		StartRound = 1,
		IntervalRound = 1,
		Limited = 233,
	},
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "AttributeWithHurt",
		EffectValue = 200002,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id4244] =
{
	Id = 4244,
	Name = "忍耐+",
	Desc = "忍耐 +{Value}",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200003,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id4245] =
{
	Id = 4245,
	Name = "根据受击次数忍耐-",
	Desc = "回合中，每次受击，忍耐-{Value}",
	EffectModule = EffectModule.Battle,
	BattleParameter = {
		StartRound = 1,
		IntervalRound = 1,
		Limited = 233,
	},
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "AttributeWithHurt",
		EffectValue = 200003,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id4246] =
{
	Id = 4246,
	Name = "生命+",
	Desc = "生命 +{Value}",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200001,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id4247] =
{
	Id = 4247,
	Name = "概率闪避敌人攻击",
	Desc = "{Value}%概率闪避攻击",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "Dodge",
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id4248] =
{
	Id = 4248,
	Name = "攻击+",
	Desc = "攻击 +{Value}",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200002,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id4249] =
{
	Id = 4249,
	Name = "连击1次",
	Desc = "有{Value}%概率额外攻击1次",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "ExtraAttack",
		EffectValue = 1,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id4250] =
{
	Id = 4250,
	Name = "压制敌人暴击",
	Desc = "敌人暴击 -{Value}",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "SpecificEnemyAbility",
		EffectValue = 200004,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id4251] =
{
	Id = 4251,
	Name = "压制敌人忍耐",
	Desc = "敌人忍耐 -{Value}",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "SpecificEnemyAbility",
		EffectValue = 200003,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id4252] =
{
	Id = 4252,
	Name = "攻击+",
	Desc = "攻击 +{Value}",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200002,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id4253] =
{
	Id = 4253,
	Name = "无视敌人忍耐攻击%",
	Desc = "1回合后攻击时无视敌人{Value}%忍耐",
	EffectModule = EffectModule.Battle,
	BattleParameter = {
		StartRound = 1,
		IntervalRound = 1,
		Limited = 233,
	},
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "DefendIgnoreOnce",
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id4254] =
{
	Id = 4254,
	Name = "打工金币+",
	Desc = "打工金币数量 +{Value}%",
	EffectModule = EffectModule.WorkShop,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "WorkShopGoodsNumber",
		EffectValue = 1,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id4255] =
{
	Id = 4255,
	Name = "生命+",
	Desc = "生命 +{Value}",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200001,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id4256] =
{
	Id = 4256,
	Name = "无视敌人忍耐攻击%",
	Desc = "1回合后攻击时无视敌人{Value}%忍耐",
	EffectModule = EffectModule.Battle,
	BattleParameter = {
		StartRound = 1,
		IntervalRound = 1,
		Limited = 233,
	},
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "DefendIgnoreOnce",
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id4257] =
{
	Id = 4257,
	Name = "生命+",
	Desc = "生命 +{Value}",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200001,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id4258] =
{
	Id = 4258,
	Name = "攻击附加损失生命%",
	Desc = "1回合后攻击附加自身损失生命{Value}%的伤害",
	EffectModule = EffectModule.Battle,
	BattleParameter = {
		StartRound = 1,
		IntervalRound = 1,
		Limited = 233,
	},
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "HpAttackOnce",
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id4259] =
{
	Id = 4259,
	Name = "生命+",
	Desc = "生命 +{Value}",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200001,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id4260] =
{
	Id = 4260,
	Name = "每3回合连击1次",
	Desc = "每3回合有{Value}%概率额外攻击1次",
	EffectModule = EffectModule.Battle,
	BattleParameter = {
		StartRound = 2,
		IntervalRound = 3,
		Limited = 233,
	},
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "ExtraAttackOnce",
		EffectValue = 1,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id4261] =
{
	Id = 4261,
	Name = "左右智力+",
	Desc = "自身及左右队员智力 +{Value}",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.RelativePosition,
		PositionValue = 
		{
			1,0,-1,
		},
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200008,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id4262] =
{
	Id = 4262,
	Name = "左右技巧+",
	Desc = "自身及左右队员技巧 +{Value}",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.RelativePosition,
		PositionValue = 
		{
			1,0,-1,
		},
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200005,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id4263] =
{
	Id = 4263,
	Name = "根据受击次数恢复",
	Desc = "回合中，每次受击，回血{Value}",
	EffectModule = EffectModule.Battle,
	BattleParameter = {
		StartRound = 1,
		IntervalRound = 1,
		Limited = 233,
	},
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "RecoveryWithHurt",
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id4264] =
{
	Id = 4264,
	Name = "根据受击次数攻击+",
	Desc = "回合中，每次受击，攻击 +{Value}",
	EffectModule = EffectModule.Battle,
	BattleParameter = {
		StartRound = 1,
		IntervalRound = 1,
		Limited = 233,
	},
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "AttributeWithHurt",
		EffectValue = 200002,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id4265] =
{
	Id = 4265,
	Name = "生命+",
	Desc = "生命 +{Value}",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200001,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id4266] =
{
	Id = 4266,
	Name = "根据受击次数恢复",
	Desc = "回合中，每次受击，回血{Value}",
	EffectModule = EffectModule.Battle,
	BattleParameter = {
		StartRound = 1,
		IntervalRound = 1,
		Limited = 233,
	},
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "RecoveryWithHurt",
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id4267] =
{
	Id = 4267,
	Name = "生命+",
	Desc = "生命 +{Value}",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200001,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id4268] =
{
	Id = 4268,
	Name = "攻击+",
	Desc = "攻击 +{Value}",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200002,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id4269] =
{
	Id = 4269,
	Name = "后方暗元素打击",
	Desc = "自身及身后两名队员对暗元素敌人伤害 +{Value}%",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.RelativePosition,
		PositionValue = 
		{
			2,1,0,
		},
	},
	Effect = {
		EffectAttribute = "DamageToElement",
		EffectValue = 210005,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id4270] =
{
	Id = 4270,
	Name = "每3回合，本回合暴率",
	Desc = "每3回合，本回合暴率 +{Value}%",
	EffectModule = EffectModule.Battle,
	BattleParameter = {
		StartRound = 2,
		IntervalRound = 3,
		Limited = 233,
	},
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "CritChanceOnce",
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id4271] =
{
	Id = 4271,
	Name = "每3回合，本回合暴击伤害",
	Desc = "每3回合，本回合暴击伤害 +{Value}%",
	EffectModule = EffectModule.Battle,
	BattleParameter = {
		StartRound = 2,
		IntervalRound = 3,
		Limited = 233,
	},
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "CritDamageOnce",
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id4272] =
{
	Id = 4272,
	Name = "压制敌人生命",
	Desc = "敌人生命 -{Value}",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "SpecificEnemyAbility",
		EffectValue = 200001,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id4273] =
{
	Id = 4273,
	Name = "生命+",
	Desc = "生命 +{Value}",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200001,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id4274] =
{
	Id = 4274,
	Name = "根据受击次数恢复",
	Desc = "回合中，每次受击，回血{Value}",
	EffectModule = EffectModule.Battle,
	BattleParameter = {
		StartRound = 1,
		IntervalRound = 1,
		Limited = 233,
	},
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "RecoveryWithHurt",
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id4275] =
{
	Id = 4275,
	Name = "生命+",
	Desc = "生命 +{Value}",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200001,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id4276] =
{
	Id = 4276,
	Name = "攻击+",
	Desc = "攻击 +{Value}",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200002,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id4277] =
{
	Id = 4277,
	Name = "压制敌人攻击",
	Desc = "敌人攻击 -{Value}",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "SpecificEnemyAbility",
		EffectValue = 200002,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id4278] =
{
	Id = 4278,
	Name = "攻击+",
	Desc = "攻击 +{Value}",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200002,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id4279] =
{
	Id = 4279,
	Name = "每回合每个海洋星队员提供攻击+",
	Desc = "每回合，每个海洋性队员提供攻击 +{Value}，最多5次",
	EffectModule = EffectModule.Battle,
	MultiCount = true,
	EffectCondition = {
		Tag = 
		{
			560107,
		},
	},
	BattleParameter = {
		StartRound = 1,
		IntervalRound = 1,
		Limited = 5,
	},
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200002,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id4280] =
{
	Id = 4280,
	Name = "必中术",
	Desc = "{Value}%概率无视敌人闪避",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "DodgeIgnore",
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id4281] =
{
	Id = 4281,
	Name = "概率闪避敌人攻击",
	Desc = "{Value}%概率闪避攻击",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "Dodge",
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id4282] =
{
	Id = 4282,
	Name = "生命+",
	Desc = "生命 +{Value}",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200001,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id4283] =
{
	Id = 4283,
	Name = "恢复",
	Desc = "每回合回血 {Value}，最多5次",
	EffectModule = EffectModule.Battle,
	BattleParameter = {
		StartRound = 1,
		IntervalRound = 1,
		Limited = 5,
	},
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "Recovery",
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id4284] =
{
	Id = 4284,
	Name = "水元素敌人战力-",
	Desc = "水元素敌人战力 -{Value}%",
	EffectModule = EffectModule.ExploreEnemy,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "EnemyFightPower",
		Element = 210001,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id4285] =
{
	Id = 4285,
	Name = "水元素敌人掉落概率+",
	Desc = "水元素敌人道具掉落率 +{Value}%",
	EffectModule = EffectModule.ExploreDrop,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "EnemyDropChance",
		Element = 210001,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id4286] =
{
	Id = 4286,
	Name = "攻击+",
	Desc = "攻击 +{Value}",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200002,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id4287] =
{
	Id = 4287,
	Name = "每3回合受击恢复",
	Desc = "每3回合，每次受击回血{Value}%",
	EffectModule = EffectModule.Battle,
	BattleParameter = {
		StartRound = 3,
		IntervalRound = 3,
		Limited = 233,
	},
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "RecoveryWithHurt",
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id4288] =
{
	Id = 4288,
	Name = "生命+",
	Desc = "生命 +{Value}",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200001,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id4289] =
{
	Id = 4289,
	Name = "攻击+",
	Desc = "攻击 +{Value}",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200002,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id4290] =
{
	Id = 4290,
	Name = "生命+",
	Desc = "生命 +{Value}",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200001,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id4291] =
{
	Id = 4291,
	Name = "攻击+",
	Desc = "攻击 +{Value}",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200002,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id4292] =
{
	Id = 4292,
	Name = "每个海洋星队员提供生命+",
	Desc = "生命 +{Value}%",
	EffectModule = EffectModule.BuildTeam,
	MultiCount = true,
	EffectCondition = {
		Tag = 
		{
			560107,
		},
	},
	EffectRange = {
		EffectScope = EffectScope.Team,
		Characters = 
		{
			220426,
		},
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200001,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id4293] =
{
	Id = 4293,
	Name = "每个海洋星队员提供全队生命+",
	Desc = "每个海洋星队员提供全队生命 +{Value}%",
	EffectModule = EffectModule.BuildTeam,
	MultiCount = true,
	EffectCondition = {
		Tag = 
		{
			560107,
		},
	},
	EffectRange = {
		EffectScope = EffectScope.Team,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200001,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id4294] =
{
	Id = 4294,
	Name = "风元素队员生命+",
	Desc = "风元素队员生命 +{Value}%",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Team,
		Element = 210003,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200001,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id4295] =
{
	Id = 4295,
	Name = "风元素队员攻击+",
	Desc = "风元素队员攻击 +{Value}%",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Team,
		Element = 210003,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200002,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id4296] =
{
	Id = 4296,
	Name = "敌人捕捉率+",
	Desc = "敌人捕捉成功率 +{Value}%",
	EffectModule = EffectModule.ExploreCatch,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "PetCatchSuccessChance",
		Rarity = 4,
		RarityOp = 0,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id4297] =
{
	Id = 4297,
	Name = "头目招来",
	Desc = "金色及以上品质敌人出现概率 +{Value}%",
	EffectModule = EffectModule.ExploreEnemy,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "EnemyWeight",
		Rarity = 4,
		RarityOp = 0,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id4298] =
{
	Id = 4298,
	Name = "升级消耗+",
	Desc = "升级要求的金币 -{Value}%",
	EffectModule = EffectModule.CharacterLevelUp,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "CharacterLevelUpCost",
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id4299] =
{
	Id = 4299,
	Name = "风元素敌人生命+",
	Desc = "风元素敌人生命 -{Value}%",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "SpecificEnemyAbility",
		EffectValue = 200001,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id4300] =
{
	Id = 4300,
	Name = "风元素敌人攻击+",
	Desc = "风元素敌人攻击 -{Value}%",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "SpecificEnemyAbility",
		EffectValue = 200002,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id4301] =
{
	Id = 4301,
	Name = "每个水元素队员提供全队亲和+",
	Desc = "亲和 +{Value}%",
	EffectModule = EffectModule.BuildTeam,
	MultiCount = true,
	EffectCondition = {
		Tag = 
		{
			561202,
		},
	},
	EffectRange = {
		EffectScope = EffectScope.Team,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200006,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id4302] =
{
	Id = 4302,
	Name = "全队亲和+",
	Desc = "全队亲和 +{Value}%",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Team,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200006,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id4303] =
{
	Id = 4303,
	Name = "打工工时+",
	Desc = "打工中，最大工时 +{Value}%",
	EffectModule = EffectModule.WorkShop,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "WorkShopMaxWorkTime",
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id4304] =
{
	Id = 4304,
	Name = "生命+",
	Desc = "生命 +{Value}",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200001,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id4305] =
{
	Id = 4305,
	Name = "风元素队员生命+",
	Desc = "风元素队员生命 +{Value}%",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Team,
		Element = 210003,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200001,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id4306] =
{
	Id = 4306,
	Name = "水元素队员闪避+",
	Desc = "水元素队员{Value}%概率闪避攻击",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Team,
		Element = 210001,
	},
	Effect = {
		EffectAttribute = "Dodge",
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id4307] =
{
	Id = 4307,
	Name = "5回合后一次性恢复",
	Desc = "5回合后，回血 {Value}%",
	EffectModule = EffectModule.Battle,
	BattleParameter = {
		StartRound = 5,
		IntervalRound = 1,
		Limited = 1,
	},
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "Recovery",
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id4308] =
{
	Id = 4308,
	Name = "每回合左右队员回血",
	Desc = "每回合自身及左右队员回血 {Value}%，最多5次",
	EffectModule = EffectModule.Battle,
	BattleParameter = {
		StartRound = 1,
		IntervalRound = 1,
		Limited = 5,
	},
	EffectRange = {
		EffectScope = EffectScope.RelativePosition,
		PositionValue = 
		{
			1,0,-1,
		},
	},
	Effect = {
		EffectAttribute = "Recovery",
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id4309] =
{
	Id = 4309,
	Name = "每回合攻击+",
	Desc = "每回合攻击 +{Value}，最多5次",
	EffectModule = EffectModule.Battle,
	BattleParameter = {
		StartRound = 1,
		IntervalRound = 1,
		Limited = 5,
	},
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200002,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id4310] =
{
	Id = 4310,
	Name = "躲避强敌",
	Desc = "打不过的怪物出现概率 -{Value}%",
	EffectModule = EffectModule.ExploreEnemy,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "EnemyWeight",
		Chance = 100,
		CompareFightPower = 1,
		EnemyWeightCondition = {
			CompareWin = 2,
		},
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id4311] =
{
	Id = 4311,
	Name = "生命+",
	Desc = "生命 +{Value}",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200001,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id4312] =
{
	Id = 4312,
	Name = "自身及身后队员攻击+",
	Desc = "攻击 +{Value}",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.RelativePosition,
		PositionValue = 
		{
			5,4,3,2,1,0,
		},
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200002,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id4313] =
{
	Id = 4313,
	Name = "闪避+",
	Desc = "{Value}%概率闪避攻击",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "Dodge",
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id4314] =
{
	Id = 4314,
	Name = "每个暗元素队员提供全队攻击+",
	Desc = "每个暗元素队员提供全队攻击 +{Value}%",
	EffectModule = EffectModule.BuildTeam,
	MultiCount = true,
	EffectCondition = {
		Tag = 
		{
			561206,
		},
	},
	EffectRange = {
		EffectScope = EffectScope.Team,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200002,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id4315] =
{
	Id = 4315,
	Name = "每3回合全队攻击+",
	Desc = "每3回合攻击 +{Value}%，最多3次",
	EffectModule = EffectModule.Battle,
	BattleParameter = {
		StartRound = 3,
		IntervalRound = 3,
		Limited = 3,
	},
	EffectRange = {
		EffectScope = EffectScope.Team,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200002,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id4316] =
{
	Id = 4316,
	Name = "每3回合恢复",
	Desc = "每3回合全队回血 {Value}%，最多5次",
	EffectModule = EffectModule.Battle,
	BattleParameter = {
		StartRound = 3,
		IntervalRound = 3,
		Limited = 5,
	},
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "Recovery",
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id4317] =
{
	Id = 4317,
	Name = "全队战力+",
	Desc = "战力 +{Value}%",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Team,
	},
	Effect = {
		EffectAttribute = "FightPower",
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id4318] =
{
	Id = 4318,
	Name = "连击1次",
	Desc = "有{Value}%概率额外攻击1次",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "ExtraAttack",
		EffectValue = 1,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id4319] =
{
	Id = 4319,
	Name = "水元素敌人战力-",
	Desc = "水元素敌人战力 -{Value}%",
	EffectModule = EffectModule.ExploreEnemy,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "EnemyFightPower",
		Element = 210001,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id4320] =
{
	Id = 4320,
	Name = "全队生命+",
	Desc = "全队生命 +{Value}%",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Team,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200001,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id4321] =
{
	Id = 4321,
	Name = "全队攻击+",
	Desc = "全队攻击 +{Value}%",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Team,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200002,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id4322] =
{
	Id = 4322,
	Name = "生命+",
	Desc = "生命 +{Value}",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200001,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id4323] =
{
	Id = 4323,
	Name = "忍耐+",
	Desc = "忍耐 +{Value}",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200003,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id4324] =
{
	Id = 4324,
	Name = "暴击+",
	Desc = "暴击 +{Value}",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200004,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id4325] =
{
	Id = 4325,
	Name = "暴击伤害+",
	Desc = "暴击伤害 +{Value}%",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "CritDamage",
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id4326] =
{
	Id = 4326,
	Name = "全队攻击+",
	Desc = "全队攻击 +{Value}%",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200002,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id4327] =
{
	Id = 4327,
	Name = "处于首位时，全队攻击+",
	Desc = "处于首位时，全队攻击 +{Value}%",
	EffectModule = EffectModule.BuildTeam,
	EffectCondition = {
		SelfPosition = 1,
	},
	EffectRange = {
		EffectScope = EffectScope.Team,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200002,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id4328] =
{
	Id = 4328,
	Name = "处于末位时，全队每回合恢复",
	Desc = "处于末位时，全队每回合回血{Value}%",
	EffectModule = EffectModule.Battle,
	EffectCondition = {
		SelfPosition = -1,
	},
	BattleParameter = {
		StartRound = 1,
		IntervalRound = 1,
		Limited = 233,
	},
	EffectRange = {
		EffectScope = EffectScope.Team,
	},
	Effect = {
		EffectAttribute = "Recovery",
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id4329] =
{
	Id = 4329,
	Name = "全队技巧+",
	Desc = "全队技巧 +{Value}%",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Team,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200005,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id4330] =
{
	Id = 4330,
	Name = "全队亲和+",
	Desc = "全队亲和 +{Value}%",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Team,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200006,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id4331] =
{
	Id = 4331,
	Name = "全队力气+",
	Desc = "全队力气 +{Value}%",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Team,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200007,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id4332] =
{
	Id = 4332,
	Name = "全队智力+",
	Desc = "全队智力 +{Value}%",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Team,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200008,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id4333] =
{
	Id = 4333,
	Name = "全队战力+",
	Desc = "探索中，全队战力 +{Value}%",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Team,
	},
	Effect = {
		EffectAttribute = "FightPower",
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id4334] =
{
	Id = 4334,
	Name = "生命+",
	Desc = "生命 +{Value}%",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200001,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id4335] =
{
	Id = 4335,
	Name = "攻击+",
	Desc = "攻击 +{Value}",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200002,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id4336] =
{
	Id = 4336,
	Name = "暴击+",
	Desc = "暴击 +{Value}",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200004,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id4337] =
{
	Id = 4337,
	Name = "暴击伤害+",
	Desc = "暴击伤害 +{Value}%",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "CritDamage",
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id4338] =
{
	Id = 4338,
	Name = "全队连击1次",
	Desc = "全队有{Value}%概率额外攻击1次",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Team,
	},
	Effect = {
		EffectAttribute = "ExtraAttack",
		EffectValue = 1,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id4339] =
{
	Id = 4339,
	Name = "全队闪避+",
	Desc = "全队{Value}%概率闪避攻击",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Team,
	},
	Effect = {
		EffectAttribute = "Dodge",
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id4340] =
{
	Id = 4340,
	Name = "暗元素队员攻击+",
	Desc = "暗元素队员攻击 +{Value}%",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Team,
		Element = 210005,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200002,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id4341] =
{
	Id = 4341,
	Name = "攻击+",
	Desc = "攻击 +{Value}%",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200002,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id4342] =
{
	Id = 4342,
	Name = "生命+",
	Desc = "生命 +{Value}%",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200001,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id4343] =
{
	Id = 4343,
	Name = "火元素免伤",
	Desc = "受火元素敌人伤害 -{Value}%",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "DamageFromElement",
		EffectValue = 210002,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id4344] =
{
	Id = 4344,
	Name = "压制敌人忍耐",
	Desc = "敌人忍耐 -{Value}",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "SpecificEnemyAbility",
		EffectValue = 200003,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id4345] =
{
	Id = 4345,
	Name = "压制敌人暴击",
	Desc = "敌人暴击 -{Value}",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "SpecificEnemyAbility",
		EffectValue = 200004,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id4346] =
{
	Id = 4346,
	Name = "攻击+",
	Desc = "攻击 +{Value}%",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200002,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id4347] =
{
	Id = 4347,
	Name = "连击1次",
	Desc = "有{Value}%概率额外攻击1次",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "ExtraAttack",
		EffectValue = 1,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id4348] =
{
	Id = 4348,
	Name = "暗元素免伤",
	Desc = "受暗元素敌人伤害 -{Value}%",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "DamageFromElement",
		EffectValue = 210005,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id4349] =
{
	Id = 4349,
	Name = "光元素打击",
	Desc = "对光元素敌人伤害 +{Value}%",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "DamageToElement",
		EffectValue = 210004,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id4350] =
{
	Id = 4350,
	Name = "光元素打击",
	Desc = "对光元素敌人伤害 +{Value}%",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "DamageToElement",
		EffectValue = 210004,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id4351] =
{
	Id = 4351,
	Name = "暗元素免伤",
	Desc = "受暗元素敌人伤害 -{Value}%",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "DamageFromElement",
		EffectValue = 210005,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id4352] =
{
	Id = 4352,
	Name = "光元素打击",
	Desc = "对光元素敌人伤害 +{Value}%",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "DamageToElement",
		EffectValue = 210004,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id4353] =
{
	Id = 4353,
	Name = "暗元素免伤",
	Desc = "受暗元素敌人伤害 -{Value}%",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "DamageFromElement",
		EffectValue = 210005,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id4354] =
{
	Id = 4354,
	Name = "打工工时+",
	Desc = "打工中，最大工时 +{Value}%",
	EffectModule = EffectModule.WorkShop,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "WorkShopMaxWorkTime",
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id4355] =
{
	Id = 4355,
	Name = "打工金币+",
	Desc = "打工金币数量 +{Value}%",
	EffectModule = EffectModule.WorkShop,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "WorkShopGoodsNumber",
		EffectValue = 1,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id4356] =
{
	Id = 4356,
	Name = "打工食物+",
	Desc = "打工食物数量 +{Value}%",
	EffectModule = EffectModule.WorkShop,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "WorkShopGoodsNumber",
		Tag = 
		{
			564306,
		},
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id4357] =
{
	Id = 4357,
	Name = "打工捕捉道具+",
	Desc = "打工捕捉道具数量 +{Value}%",
	EffectModule = EffectModule.WorkShop,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "WorkShopGoodsNumber",
		Tag = 
		{
			564307,
		},
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id4358] =
{
	Id = 4358,
	Name = "每个五福组使全队技巧+",
	Desc = "每个五福组使全队技巧 +{Value}%",
	EffectModule = EffectModule.BuildTeam,
	MultiCount = true,
	EffectCondition = {
		Tag = 
		{
			562932,
		},
	},
	EffectRange = {
		EffectScope = EffectScope.Team,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200005,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id4359] =
{
	Id = 4359,
	Name = "每个五福组使全队亲和+",
	Desc = "每个五福组使全队亲和 +{Value}%",
	EffectModule = EffectModule.BuildTeam,
	MultiCount = true,
	EffectCondition = {
		Tag = 
		{
			562932,
		},
	},
	EffectRange = {
		EffectScope = EffectScope.Team,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200006,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id4360] =
{
	Id = 4360,
	Name = "每个五福组使全队力气+",
	Desc = "每个五福组使全队力气 +{Value}%",
	EffectModule = EffectModule.BuildTeam,
	MultiCount = true,
	EffectCondition = {
		Tag = 
		{
			562932,
		},
	},
	EffectRange = {
		EffectScope = EffectScope.Team,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200007,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id4361] =
{
	Id = 4361,
	Name = "每个五福组使全队智力+",
	Desc = "每个五福组使全队智力 +{Value}%",
	EffectModule = EffectModule.BuildTeam,
	MultiCount = true,
	EffectCondition = {
		Tag = 
		{
			562932,
		},
	},
	EffectRange = {
		EffectScope = EffectScope.Team,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200008,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id4362] =
{
	Id = 4362,
	Name = "防御型队员生命+",
	Desc = "防御型队员生命 +{Value}%",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Team,
		Tag = 
		{
			561207,
		},
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200001,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id4363] =
{
	Id = 4363,
	Name = "攻击型队员攻击+",
	Desc = "攻击型队员攻击 +{Value}%",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Team,
		Tag = 
		{
			561208,
		},
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200002,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id4364] =
{
	Id = 4364,
	Name = "攻击+",
	Desc = "攻击型队员攻击 +{Value}%",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200002,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id4365] =
{
	Id = 4365,
	Name = "3回合后，每2回合闪避",
	Desc = "3回合后，每2回合有{Value}%概率闪避攻击",
	EffectModule = EffectModule.Battle,
	BattleParameter = {
		StartRound = 2,
		IntervalRound = 2,
		Limited = 233,
	},
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "DodgeOnce",
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id4366] =
{
	Id = 4366,
	Name = "春节敌人生命-",
	Desc = "春节挑战敌人生命 -{Value}%",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "SpecificEnemyAbility",
		EffectValue = 200001,
		Tag = 
		{
			562933,
		},
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id4367] =
{
	Id = 4367,
	Name = "春节敌人攻击-",
	Desc = "春节挑战敌人攻击 -{Value}%",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "SpecificEnemyAbility",
		EffectValue = 200002,
		Tag = 
		{
			562933,
		},
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id4368] =
{
	Id = 4368,
	Name = "敌人攻击-",
	Desc = "敌人攻击 -{Value}%",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "SpecificEnemyAbility",
		EffectValue = 200002,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id4369] =
{
	Id = 4369,
	Name = "敌人暴击-",
	Desc = "敌人暴击 -{Value}",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "SpecificEnemyAbility",
		EffectValue = 200004,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id4370] =
{
	Id = 4370,
	Name = "每回合恢复",
	Desc = "每回合回血 {Value}%，最多5次",
	Dialog = "谁再敢说我笨！",
	EffectModule = EffectModule.Battle,
	BattleParameter = {
		StartRound = 1,
		IntervalRound = 1,
		Limited = 5,
	},
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "Recovery",
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id4371] =
{
	Id = 4371,
	Name = "每回合攻击+",
	Desc = "每回合攻击 +{Value}，最多5次",
	EffectModule = EffectModule.Battle,
	BattleParameter = {
		StartRound = 1,
		IntervalRound = 1,
		Limited = 5,
	},
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200002,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id4372] =
{
	Id = 4372,
	Name = "火元素敌人捕捉率+",
	Desc = "火元素敌人捕捉成功率 +{Value}%",
	EffectModule = EffectModule.ExploreCatch,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "PetCatchSuccessChance",
		Element = 210002,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id4373] =
{
	Id = 4373,
	Name = "水元素敌人捕捉率+",
	Desc = "水元素敌人捕捉成功率 +{Value}%",
	EffectModule = EffectModule.ExploreCatch,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "PetCatchSuccessChance",
		Element = 210001,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id4374] =
{
	Id = 4374,
	Name = "光元素敌人捕捉率+",
	Desc = "光元素敌人捕捉成功率 +{Value}%",
	EffectModule = EffectModule.ExploreCatch,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "PetCatchSuccessChance",
		Element = 210004,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id4375] =
{
	Id = 4375,
	Name = "生命+",
	Desc = "生命 +{Value}%",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200001,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id4376] =
{
	Id = 4376,
	Name = "攻击+",
	Desc = "攻击 +{Value}",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200002,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id4377] =
{
	Id = 4377,
	Name = "生命+",
	Desc = "生命 +{Value}%",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200001,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id4378] =
{
	Id = 4378,
	Name = "根据受击次数攻击+",
	Desc = "回合中，每次受击，攻击 +{Value}",
	EffectModule = EffectModule.Battle,
	BattleParameter = {
		StartRound = 1,
		IntervalRound = 1,
		Limited = 233,
	},
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "AttributeWithHurt",
		EffectValue = 200002,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id4379] =
{
	Id = 4379,
	Name = "生命+",
	Desc = "生命 +{Value}%",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200001,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id4380] =
{
	Id = 4380,
	Name = "每次受击回血+",
	Desc = "1回合后，每次受击回血{Value}",
	EffectModule = EffectModule.Battle,
	BattleParameter = {
		StartRound = 1,
		IntervalRound = 1,
		Limited = 233,
	},
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "RecoveryWithHurt",
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id4381] =
{
	Id = 4381,
	Name = "攻击+",
	Desc = "攻击 +{Value}",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200002,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id4382] =
{
	Id = 4382,
	Name = "每3回合概率闪避敌人攻击",
	Desc = "每3回合{Value}%概率闪避攻击",
	EffectModule = EffectModule.Battle,
	BattleParameter = {
		StartRound = 2,
		IntervalRound = 3,
		Limited = 233,
	},
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "DodgeOnce",
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id4383] =
{
	Id = 4383,
	Name = "每回合全队恢复",
	Desc = "每回合，全队回血 {Value}，最多3次",
	EffectModule = EffectModule.Battle,
	BattleParameter = {
		StartRound = 1,
		IntervalRound = 1,
		Limited = 3,
	},
	EffectRange = {
		EffectScope = EffectScope.Team,
	},
	Effect = {
		EffectAttribute = "Recovery",
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id4384] =
{
	Id = 4384,
	Name = "4回合后，全队受到暴伤-",
	Desc = "4回合后，全队受到暴伤 -{Value}%",
	EffectModule = EffectModule.Battle,
	BattleParameter = {
		StartRound = 3,
		IntervalRound = 1,
		Limited = 233,
	},
	EffectRange = {
		EffectScope = EffectScope.Team,
	},
	Effect = {
		EffectAttribute = "DamageFromCritDamageOnce",
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id4385] =
{
	Id = 4385,
	Name = "自身及左右力气+",
	Desc = "探索金币数量 +{Value}%",
	Dialog = "客人脚挪挪，我扫扫叽~",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.RelativePosition,
		PositionValue = 
		{
			1,0,-1,
		},
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200007,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id4386] =
{
	Id = 4386,
	Name = "自身及左右智力+",
	Desc = "探索金币数量 +{Value}%",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.RelativePosition,
		PositionValue = 
		{
			1,0,-1,
		},
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200008,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id4387] =
{
	Id = 4387,
	Name = "敌人生命-",
	Desc = "敌人生命 -{Value}%",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "SpecificEnemyAbility",
		EffectValue = 200001,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id4388] =
{
	Id = 4388,
	Name = "敌人忍耐-",
	Desc = "敌人忍耐 -{Value}",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "SpecificEnemyAbility",
		EffectValue = 200003,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id4389] =
{
	Id = 4389,
	Name = "每3回合单次暴伤+",
	Desc = "每3回合，本回合暴伤 +{Value}%",
	EffectModule = EffectModule.Battle,
	BattleParameter = {
		StartRound = 2,
		IntervalRound = 3,
		Limited = 233,
	},
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "CritDamageOnce",
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id4390] =
{
	Id = 4390,
	Name = "每3回合概率闪避敌人攻击",
	Desc = "每3回合{Value}%概率闪避攻击",
	EffectModule = EffectModule.Battle,
	BattleParameter = {
		StartRound = 2,
		IntervalRound = 3,
		Limited = 233,
	},
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "DodgeOnce",
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id4391] =
{
	Id = 4391,
	Name = "攻击+",
	Desc = "攻击 +{Value}",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200002,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id4392] =
{
	Id = 4392,
	Name = "敌人掉落概率+",
	Desc = "敌人道具掉落率 +{Value}%",
	EffectModule = EffectModule.ExploreDrop,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "EnemyDropChance",
		Rarity = 4,
		RarityOp = 1,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id4393] =
{
	Id = 4393,
	Name = "忍耐+",
	Desc = "忍耐 +{Value}",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200003,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id4394] =
{
	Id = 4394,
	Name = "每3回合身后队员概率闪避敌人攻击",
	Desc = "每3回合身后1名组队员{Value}%概率闪避攻击，最多2次",
	EffectModule = EffectModule.Battle,
	BattleParameter = {
		StartRound = 2,
		IntervalRound = 3,
		Limited = 2,
	},
	EffectRange = {
		EffectScope = EffectScope.RelativePosition,
		PositionValue = 
		{
			1,
		},
	},
	Effect = {
		EffectAttribute = "DodgeOnce",
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id4395] =
{
	Id = 4395,
	Name = "生命+",
	Desc = "生命 +{Value}%",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200001,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id4396] =
{
	Id = 4396,
	Name = "每3回合，身后2龙舟组队员概率连击1次",
	Desc = "每3回合，身后2龙舟组队员有{Value}%概率额外攻击1次",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.RelativePosition,
		PositionValue = 
		{
			1,2,
		},
	},
	Effect = {
		EffectAttribute = "ExtraAttack",
		EffectValue = 1,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id4397] =
{
	Id = 4397,
	Name = "生命+",
	Desc = "生命 +{Value}",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200001,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id4398] =
{
	Id = 4398,
	Name = "攻击+",
	Desc = "攻击 +{Value}%",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200002,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id4399] =
{
	Id = 4399,
	Name = "连击1次",
	Desc = "攻击有{Value}%概率额外攻击1次",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "ExtraAttack",
		EffectValue = 1,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id4400] =
{
	Id = 4400,
	Name = "生命+",
	Desc = "生命 +{Value}",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200001,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id4401] =
{
	Id = 4401,
	Name = "攻击+",
	Desc = "攻击 +{Value}%",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200002,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id4402] =
{
	Id = 4402,
	Name = "连击1次",
	Desc = "攻击有{Value}%概率额外攻击1次",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "ExtraAttack",
		EffectValue = 1,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id4403] =
{
	Id = 4403,
	Name = "每个龙舟组队员提供攻击+",
	Desc = "每个龙舟组队员提供攻击 +{Value}%",
	EffectModule = EffectModule.BuildTeam,
	MultiCount = true,
	EffectCondition = {
		Tag = 
		{
			562934,
		},
	},
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200002,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id4404] =
{
	Id = 4404,
	Name = "战力+",
	Desc = "探索中，自身战力 +{Value}%",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "FightPower",
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id4405] =
{
	Id = 4405,
	Name = "水元素敌人捕捉率+",
	Desc = "水元素敌人捕捉成功率 +{Value}%",
	EffectModule = EffectModule.ExploreCatch,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "PetCatchSuccessChance",
		Element = 210001,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id4406] =
{
	Id = 4406,
	Name = "战力+",
	Desc = "探索中，自身战力 +{Value}%",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "FightPower",
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id4407] =
{
	Id = 4407,
	Name = "水元素敌人掉落概率+",
	Desc = "水元素敌人道具掉落率 +{Value}%",
	EffectModule = EffectModule.ExploreDrop,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "EnemyDropChance",
		Element = 210001,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id4408] =
{
	Id = 4408,
	Name = "七织在场时，生命+",
	Desc = "生命 +{Value}%",
	EffectModule = EffectModule.BuildTeam,
	EffectCondition = {
		Teamer = 
		{
			223137,
		},
	},
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200001,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id4409] =
{
	Id = 4409,
	Name = "七织在场时，攻击+",
	Desc = "攻击 +{Value}%",
	EffectModule = EffectModule.BuildTeam,
	EffectCondition = {
		Teamer = 
		{
			223137,
		},
	},
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200002,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id4410] =
{
	Id = 4410,
	Name = "七织在场时，忍耐+",
	Desc = "忍耐 +{Value}",
	EffectModule = EffectModule.BuildTeam,
	EffectCondition = {
		Teamer = 
		{
			223137,
		},
	},
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200003,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id4411] =
{
	Id = 4411,
	Name = "七织在场时，暴击+",
	Desc = "暴击 +{Value}",
	EffectModule = EffectModule.BuildTeam,
	EffectCondition = {
		Teamer = 
		{
			223137,
		},
	},
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200004,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id4412] =
{
	Id = 4412,
	Name = "七织在场时，技巧+",
	Desc = "技巧 +{Value}%",
	EffectModule = EffectModule.BuildTeam,
	EffectCondition = {
		Teamer = 
		{
			223137,
		},
	},
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200005,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id4413] =
{
	Id = 4413,
	Name = "七织在场时，亲和+",
	Desc = "亲和 +{Value}%",
	EffectModule = EffectModule.BuildTeam,
	EffectCondition = {
		Teamer = 
		{
			223137,
		},
	},
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200006,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id4414] =
{
	Id = 4414,
	Name = "七织在场时，力气+",
	Desc = "力气 +{Value}%",
	EffectModule = EffectModule.BuildTeam,
	EffectCondition = {
		Teamer = 
		{
			223137,
		},
	},
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200007,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id4415] =
{
	Id = 4415,
	Name = "七织在场时，智力+",
	Desc = "智力 +{Value}%",
	EffectModule = EffectModule.BuildTeam,
	EffectCondition = {
		Teamer = 
		{
			223137,
		},
	},
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200008,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id4416] =
{
	Id = 4416,
	Name = "生命+",
	Desc = "生命 +{Value}%",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200001,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id4417] =
{
	Id = 4417,
	Name = "攻击+",
	Desc = "攻击 +{Value}",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200002,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id4418] =
{
	Id = 4418,
	Name = "生命+",
	Desc = "生命 +{Value}%",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200001,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id4419] =
{
	Id = 4419,
	Name = "前三个回合恢复",
	Desc = "每回合，回血{Value}%，最多3次",
	EffectModule = EffectModule.Battle,
	BattleParameter = {
		StartRound = 1,
		IntervalRound = 1,
		Limited = 3,
	},
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "Recovery",
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id4420] =
{
	Id = 4420,
	Name = "攻击+",
	Desc = "攻击 +{Value}%",
	Dialog = "  ",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200002,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id4421] =
{
	Id = 4421,
	Name = "无视敌人忍耐攻击%",
	Desc = "每2回合攻击时无视敌人{Value}%忍耐",
	EffectModule = EffectModule.Battle,
	BattleParameter = {
		StartRound = 1,
		IntervalRound = 2,
		Limited = 233,
	},
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "DefendIgnoreOnce",
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id4422] =
{
	Id = 4422,
	Name = "攻击+",
	Desc = "攻击 +{Value}%",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200002,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id4423] =
{
	Id = 4423,
	Name = "连击1次",
	Desc = "有{Value}%概率额外攻击1次",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "ExtraAttack",
		EffectValue = 1,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id4424] =
{
	Id = 4424,
	Name = "每2回合全队恢复",
	Desc = "每2回合，全队回血{Value}，最多5次",
	EffectModule = EffectModule.Battle,
	BattleParameter = {
		StartRound = 2,
		IntervalRound = 2,
		Limited = 5,
	},
	EffectRange = {
		EffectScope = EffectScope.Team,
	},
	Effect = {
		EffectAttribute = "Recovery",
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id4425] =
{
	Id = 4425,
	Name = "敌人生命-",
	Desc = "敌人生命 -{Value}%",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "SpecificEnemyAbility",
		EffectValue = 200001,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id4426] =
{
	Id = 4426,
	Name = "牵牛在场时，生命+",
	Desc = "生命 +{Value}%",
	EffectModule = EffectModule.BuildTeam,
	EffectCondition = {
		Teamer = 
		{
			223130,
		},
	},
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200001,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id4427] =
{
	Id = 4427,
	Name = "牵牛在场时，攻击+",
	Desc = "攻击 +{Value}%",
	EffectModule = EffectModule.BuildTeam,
	EffectCondition = {
		Teamer = 
		{
			223130,
		},
	},
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200002,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id4428] =
{
	Id = 4428,
	Name = "牵牛在场时，忍耐+",
	Desc = "忍耐 +{Value}",
	EffectModule = EffectModule.BuildTeam,
	EffectCondition = {
		Teamer = 
		{
			223130,
		},
	},
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200003,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id4429] =
{
	Id = 4429,
	Name = "牵牛在场时，暴击+",
	Desc = "暴击 +{Value}",
	EffectModule = EffectModule.BuildTeam,
	EffectCondition = {
		Teamer = 
		{
			223130,
		},
	},
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200004,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id4430] =
{
	Id = 4430,
	Name = "牵牛在场时，技巧+",
	Desc = "技巧 +{Value}%",
	EffectModule = EffectModule.BuildTeam,
	EffectCondition = {
		Teamer = 
		{
			223130,
		},
	},
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200005,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id4431] =
{
	Id = 4431,
	Name = "牵牛在场时，亲和+",
	Desc = "亲和 +{Value}%",
	EffectModule = EffectModule.BuildTeam,
	EffectCondition = {
		Teamer = 
		{
			223130,
		},
	},
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200006,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id4432] =
{
	Id = 4432,
	Name = "牵牛在场时，力气+",
	Desc = "力气 +{Value}%",
	EffectModule = EffectModule.BuildTeam,
	EffectCondition = {
		Teamer = 
		{
			223130,
		},
	},
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200007,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id4433] =
{
	Id = 4433,
	Name = "牵牛在场时，智力+",
	Desc = "智力 +{Value}%",
	EffectModule = EffectModule.BuildTeam,
	EffectCondition = {
		Teamer = 
		{
			223130,
		},
	},
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200008,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id4434] =
{
	Id = 4434,
	Name = "每个男性使破甲攻击+",
	Desc = "回合2开始，每个男性提供{Value}%忍耐无视",
	EffectModule = EffectModule.Battle,
	MultiCount = true,
	EffectCondition = {
		Tag = 
		{
			561702,
		},
	},
	BattleParameter = {
		StartRound = 1,
		IntervalRound = 1,
		Limited = 233,
	},
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "DefendIgnoreOnce",
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id4435] =
{
	Id = 4435,
	Name = "每回合，每个女性使恢复",
	Desc = "每回合每个女性使自身回血{Value}%",
	EffectModule = EffectModule.Battle,
	MultiCount = true,
	EffectCondition = {
		Tag = 
		{
			561703,
		},
	},
	BattleParameter = {
		StartRound = 1,
		IntervalRound = 1,
		Limited = 233,
	},
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "Recovery",
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id4436] =
{
	Id = 4436,
	Name = "全队攻击+",
	Desc = "全队攻击 +{Value}%",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Team,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200002,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id4437] =
{
	Id = 4437,
	Name = "5回合后全队攻击+",
	Desc = "5回合后全队攻击 + {Value}",
	EffectModule = EffectModule.Battle,
	BattleParameter = {
		StartRound = 5,
		IntervalRound = 1,
		Limited = 1,
	},
	EffectRange = {
		EffectScope = EffectScope.Team,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200002,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id4438] =
{
	Id = 4438,
	Name = "活动探索中，火元素敌人掉落率+",
	Desc = "活动探索中，火元素敌人掉落率 +{Value}%",
	EffectModule = EffectModule.ExploreDrop,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "EnemyDropChance",
		Element = 210002,
		Tag = 
		{
			564553,
		},
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id4439] =
{
	Id = 4439,
	Name = "生命+",
	Desc = "生命 +{Value}",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200001,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id4440] =
{
	Id = 4440,
	Name = "流亡街boss类敌人忍耐-",
	Desc = "流亡街boss类敌人忍耐 -{Value}",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "SpecificEnemyAbility",
		EffectValue = 200003,
		Tag = 
		{
			560111,
			564555,
		},
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id4441] =
{
	Id = 4441,
	Name = "攻击+",
	Desc = "攻击 +{Value}",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200002,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id4442] =
{
	Id = 4442,
	Name = "流亡街boss类敌人暴击-",
	Desc = "流亡街boss类敌人暴击 -{Value}",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "SpecificEnemyAbility",
		EffectValue = 200004,
		Tag = 
		{
			560111,
			564555,
		},
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id4443] =
{
	Id = 4443,
	Name = "活动探索中，稀有度3以上敌人掉落率+",
	Desc = "活动探索中，紫色及以上品质敌人掉落率 +{Value}%",
	EffectModule = EffectModule.ExploreDrop,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "EnemyDropChance",
		Rarity = 3,
		RarityOp = 0,
		Tag = 
		{
			564553,
		},
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id4444] =
{
	Id = 4444,
	Name = "生命+",
	Desc = "生命 +{Value}%",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200001,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id4445] =
{
	Id = 4445,
	Name = "每2回合攻击+",
	Desc = "每2回合，攻击 +{Value}",
	EffectModule = EffectModule.Battle,
	BattleParameter = {
		StartRound = 2,
		IntervalRound = 2,
		Limited = 5,
	},
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200002,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id4446] =
{
	Id = 4446,
	Name = "每2回合攻击附加损失生命%",
	Desc = "每2回合，攻击附加自身损失生命{Value}%的伤害",
	EffectModule = EffectModule.Battle,
	BattleParameter = {
		StartRound = 1,
		IntervalRound = 2,
		Limited = 233,
	},
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "HpAttackOnce",
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id4447] =
{
	Id = 4447,
	Name = "活动探索中，风元素敌人捕捉率+",
	Desc = "活动探索中，风元素敌人捕捉率 +{Value}%",
	EffectModule = EffectModule.ExploreCatch,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "PetCatchSuccessChance",
		Element = 210003,
		Tag = 
		{
			564553,
		},
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id4448] =
{
	Id = 4448,
	Name = "活动探索中，风元素敌人掉落率+",
	Desc = "活动探索中，风元素敌人掉落率 +{Value}%",
	EffectModule = EffectModule.ExploreDrop,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "EnemyDropChance",
		Element = 210003,
		Tag = 
		{
			564553,
		},
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id4449] =
{
	Id = 4449,
	Name = "全队亲和+",
	Desc = "全队亲和 +{Value}",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Team,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200006,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id4450] =
{
	Id = 4450,
	Name = "打工金币+",
	Desc = "打工金币 +{Value}%",
	EffectModule = EffectModule.WorkShop,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "WorkShopGoodsNumber",
		EffectValue = 1,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id4451] =
{
	Id = 4451,
	Name = "全队智力+",
	Desc = "全队智力 +{Value}",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Team,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200008,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id4452] =
{
	Id = 4452,
	Name = "打工金币+",
	Desc = "打工金币 +{Value}%",
	EffectModule = EffectModule.WorkShop,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "WorkShopGoodsNumber",
		EffectValue = 1,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id4453] =
{
	Id = 4453,
	Name = "全队技巧+",
	Desc = "全队技巧 +{Value}",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Team,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200005,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id4454] =
{
	Id = 4454,
	Name = "打工金币+",
	Desc = "打工金币 +{Value}%",
	EffectModule = EffectModule.WorkShop,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "WorkShopGoodsNumber",
		EffectValue = 1,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id4455] =
{
	Id = 4455,
	Name = "全队力气+",
	Desc = "全队力气 +{Value}",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Team,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200007,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id4456] =
{
	Id = 4456,
	Name = "打工金币+",
	Desc = "打工金币 +{Value}%",
	EffectModule = EffectModule.WorkShop,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "WorkShopGoodsNumber",
		EffectValue = 1,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id4457] =
{
	Id = 4457,
	Name = "战力+",
	Desc = "战力 +{Value}%",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "FightPower",
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id4458] =
{
	Id = 4458,
	Name = "战力+",
	Desc = "战力 +{Value}%",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "FightPower",
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id4459] =
{
	Id = 4459,
	Name = "战力+",
	Desc = "战力 +{Value}%",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "FightPower",
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id4460] =
{
	Id = 4460,
	Name = "活动中，火元素敌人捕捉率+",
	Desc = "活动中，火元素敌人捕捉率 +{Value}%",
	EffectModule = EffectModule.ExploreCatch,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "PetCatchSuccessChance",
		Element = 210002,
		Tag = 
		{
			564553,
		},
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id4461] =
{
	Id = 4461,
	Name = "捕捉道具产能+",
	Desc = "打工获得捕捉道具产能 +{Value}%",
	EffectModule = EffectModule.WorkShop,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "WorkShopGoodsNumber",
		Tag = 
		{
			564307,
		},
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id4462] =
{
	Id = 4462,
	Name = "每回合，男性队员回血",
	Desc = "每回合，男队员回血{Value}%",
	EffectModule = EffectModule.Battle,
	BattleParameter = {
		StartRound = 1,
		IntervalRound = 1,
		Limited = 5,
	},
	EffectRange = {
		EffectScope = EffectScope.Team,
		Tag = 
		{
			561702,
		},
	},
	Effect = {
		EffectAttribute = "Recovery",
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id4463] =
{
	Id = 4463,
	Name = "打工金币+",
	Desc = "打工金币 +{Value}%",
	EffectModule = EffectModule.WorkShop,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "WorkShopGoodsNumber",
		EffectValue = 1,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id4464] =
{
	Id = 4464,
	Name = "打工金币+",
	Desc = "打工金币 +{Value}%",
	EffectModule = EffectModule.WorkShop,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "WorkShopGoodsNumber",
		EffectValue = 1,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id4465] =
{
	Id = 4465,
	Name = "生命+",
	Desc = "生命 +{Value}",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200001,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id4466] =
{
	Id = 4466,
	Name = "每3回合必定暴击",
	Desc = "每3回合，本回合暴击概率 +{Value}%",
	EffectModule = EffectModule.Battle,
	BattleParameter = {
		StartRound = 2,
		IntervalRound = 3,
		Limited = 233,
	},
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "CritChanceOnce",
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id4467] =
{
	Id = 4467,
	Name = "暴击伤害+",
	Desc = "暴击伤害 +{Value}%",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "CritDamage",
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id4468] =
{
	Id = 4468,
	Name = "活动探索中，打不过的暗元素敌人出现率-",
	Desc = "活动探索中，打不过的暗元素敌人出现率-{Value}%",
	EffectModule = EffectModule.ExploreEnemy,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "EnemyWeight",
		Element = 210005,
		Tag = 
		{
			564553,
		},
		Chance = 100,
		CompareFightPower = 1,
		EnemyWeightCondition = {
			CompareWin = 2,
		},
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id4469] =
{
	Id = 4469,
	Name = "捕捉道具有概率不损坏",
	Desc = "敌人捕捉时道具损毁率 -{Value}%",
	EffectModule = EffectModule.ExploreCatch,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "PetCatchDamageChance",
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id4470] =
{
	Id = 4470,
	Name = "回合3及回合4,100%闪避",
	Desc = "回合3及回合4,{Value}%闪避",
	EffectModule = EffectModule.Battle,
	BattleParameter = {
		StartRound = 2,
		IntervalRound = 1,
		Limited = 2,
	},
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "DodgeOnce",
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id4471] =
{
	Id = 4471,
	Name = "流亡街boss，生命-",
	Desc = "流亡街boss，生命-{Value}%",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "SpecificEnemyAbility",
		EffectValue = 200001,
		Tag = 
		{
			560111,
			564555,
		},
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id4472] =
{
	Id = 4472,
	Name = "活动探索中，蓝色品质及以下敌人捕捉率+",
	Desc = "活动探索中，蓝色品质及以下敌人捕捉率 +{Value}%",
	EffectModule = EffectModule.ExploreCatch,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "PetCatchSuccessChance",
		Rarity = 3,
		RarityOp = 1,
		Tag = 
		{
			564553,
		},
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id4473] =
{
	Id = 4473,
	Name = "活动探索中，暗元素敌人捕捉成功率 +",
	Desc = "活动探索中，暗元素敌人捕捉成功率 +{Value}%",
	EffectModule = EffectModule.ExploreCatch,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "PetCatchSuccessChance",
		Element = 210005,
		Tag = 
		{
			564553,
		},
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id4474] =
{
	Id = 4474,
	Name = "活动探索中，水元素敌人素材掉落率 +",
	Desc = "活动探索中，水元素敌人素材掉落率 +{Value}%",
	EffectModule = EffectModule.ExploreDrop,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "EnemyDropChance",
		Element = 210001,
		Tag = 
		{
			564553,
		},
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id4475] =
{
	Id = 4475,
	Name = "活动探索中，水元素敌人捕捉成功率 +",
	Desc = "活动探索中，水元素敌人捕捉成功率 +{Value}%",
	EffectModule = EffectModule.ExploreCatch,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "PetCatchSuccessChance",
		Element = 210001,
		Tag = 
		{
			564553,
		},
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id4476] =
{
	Id = 4476,
	Name = "活动探索中，打不过的水元素敌人出现率 -",
	Desc = "活动探索中，打不过的水元素敌人出现率 -{Value}%",
	EffectModule = EffectModule.ExploreEnemy,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "EnemyWeight",
		Element = 210001,
		Tag = 
		{
			564553,
		},
		Chance = 100,
		CompareFightPower = 1,
		EnemyWeightCondition = {
			CompareWin = 2,
		},
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id4477] =
{
	Id = 4477,
	Name = "流亡街光元素敌人，攻击-%",
	Desc = "流亡街光元素敌人，攻击-{Value}%",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "SpecificEnemyAbility",
		EffectValue = 200002,
		Element = 210004,
		Tag = 
		{
			560111,
		},
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id4478] =
{
	Id = 4478,
	Name = "3回合后回血",
	Desc = "3回合后，回血{Value}%，最多5次",
	EffectModule = EffectModule.Battle,
	BattleParameter = {
		StartRound = 3,
		IntervalRound = 1,
		Limited = 5,
	},
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "Recovery",
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id4479] =
{
	Id = 4479,
	Name = "火元素打击",
	Desc = "对火元素敌人伤害 +{Value}%",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "DamageToElement",
		EffectValue = 210002,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id4480] =
{
	Id = 4480,
	Name = "光元素免伤",
	Desc = "受光元素敌人伤害 -{Value}%",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "DamageFromElement",
		EffectValue = 210004,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id4481] =
{
	Id = 4481,
	Name = "身后1名队员单次闪避",
	Desc = "第2、3回合，身后1位的队员{Value}%闪避攻击",
	EffectModule = EffectModule.Battle,
	BattleParameter = {
		StartRound = 1,
		IntervalRound = 1,
		Limited = 2,
	},
	EffectRange = {
		EffectScope = EffectScope.RelativePosition,
		PositionValue = 
		{
			1,
		},
	},
	Effect = {
		EffectAttribute = "DodgeOnce",
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id4482] =
{
	Id = 4482,
	Name = "攻击+",
	Desc = "攻击 +{Value}%",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200002,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id4483] =
{
	Id = 4483,
	Name = "每3回合暴率+",
	Desc = "每3回合，本回合暴率 +{Value}%，最多5次",
	EffectModule = EffectModule.Battle,
	BattleParameter = {
		StartRound = 2,
		IntervalRound = 3,
		Limited = 5,
	},
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "CritChanceOnce",
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id4484] =
{
	Id = 4484,
	Name = "海洋星队员每回合攻击+",
	Desc = "海洋星队员每回合攻击 +{Value}，最多5次",
	EffectModule = EffectModule.Battle,
	BattleParameter = {
		StartRound = 1,
		IntervalRound = 1,
		Limited = 5,
	},
	EffectRange = {
		EffectScope = EffectScope.Team,
		Tag = 
		{
			560107,
		},
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200002,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id4485] =
{
	Id = 4485,
	Name = "探索金币+",
	Desc = "探索金币 +{Value}%",
	EffectModule = EffectModule.ExploreDrop,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "GoodsDropNumber",
		EffectValue = 1,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id4486] =
{
	Id = 4486,
	Name = "探索时间-",
	Desc = "探索时间-{Value}%",
	EffectModule = EffectModule.ExploreTime,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "ExploreTime",
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id4487] =
{
	Id = 4487,
	Name = "风元素敌人战力 -",
	Desc = "风元素敌人战力 -{Value}%",
	EffectModule = EffectModule.ExploreEnemy,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "EnemyFightPower",
		Element = 210003,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id4488] =
{
	Id = 4488,
	Name = "风元素敌人道具掉落率+",
	Desc = "风元素敌人道具掉落率 +{Value}%",
	EffectModule = EffectModule.ExploreDrop,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "EnemyDropChance",
		Element = 210003,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id4489] =
{
	Id = 4489,
	Name = "光元素敌人攻击-",
	Desc = "光元素敌人攻击 -{Value}%",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "SpecificEnemyAbility",
		EffectValue = 200002,
		Element = 210004,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id4490] =
{
	Id = 4490,
	Name = "光元素敌人生命-",
	Desc = "光元素敌人生命 -{Value}%",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "SpecificEnemyAbility",
		EffectValue = 200001,
		Element = 210004,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id4491] =
{
	Id = 4491,
	Name = "战力+",
	Desc = "战力 +{Value}%",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "FightPower",
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id4492] =
{
	Id = 4492,
	Name = "风元素敌人掉落率+",
	Desc = "风元素敌人道具掉落概率 +{Value}%",
	EffectModule = EffectModule.ExploreDrop,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "EnemyDropChance",
		Element = 210003,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id4493] =
{
	Id = 4493,
	Name = "每个光元素队员使战力+",
	Desc = "每个光元素队员使战力 +{Value}%",
	EffectModule = EffectModule.BuildTeam,
	MultiCount = true,
	EffectCondition = {
		Element = 210004,
	},
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "FightPower",
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id4494] =
{
	Id = 4494,
	Name = "每个光元素队员使敌人掉率+",
	Desc = "每个光元素队员使敌人道具掉落概率 +{Value}%",
	EffectModule = EffectModule.ExploreDrop,
	MultiCount = true,
	EffectCondition = {
		Element = 210004,
	},
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "EnemyDropChance",
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id4495] =
{
	Id = 4495,
	Name = "生命+",
	Desc = "生命 +{Value}%",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200001,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id4496] =
{
	Id = 4496,
	Name = "暗元素敌人捕捉率+",
	Desc = "暗元素敌人捕捉成功率 +{Value}%",
	EffectModule = EffectModule.ExploreCatch,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "PetCatchSuccessChance",
		Element = 210005,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id4497] =
{
	Id = 4497,
	Name = "攻击+",
	Desc = "攻击 +{Value}%",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200002,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id4498] =
{
	Id = 4498,
	Name = "暗元素敌人道具掉落率+",
	Desc = "暗元素敌人道具掉落概率 +{Value}%",
	EffectModule = EffectModule.ExploreDrop,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "EnemyDropChance",
		Element = 210005,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id4499] =
{
	Id = 4499,
	Name = "攻击+",
	Desc = "攻击 +{Value}%",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200002,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id4500] =
{
	Id = 4500,
	Name = "回合2,4,6，全队恢复",
	Desc = "每2回合，全队回血{Value}，最多5次",
	EffectModule = EffectModule.Battle,
	BattleParameter = {
		StartRound = 2,
		IntervalRound = 2,
		Limited = 5,
	},
	EffectRange = {
		EffectScope = EffectScope.Team,
	},
	Effect = {
		EffectAttribute = "Recovery",
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id4501] =
{
	Id = 4501,
	Name = "生命+",
	Desc = "生命 +{Value}",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200001,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id4502] =
{
	Id = 4502,
	Name = "攻击+%",
	Desc = "攻击 +{Value}",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200002,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id4503] =
{
	Id = 4503,
	Name = "生命+",
	Desc = "生命 +{Value}",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200001,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id4504] =
{
	Id = 4504,
	Name = "水元素免伤",
	Desc = "受水元素敌人伤害 -{Value}%",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "DamageFromElement",
		EffectValue = 210001,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id4505] =
{
	Id = 4505,
	Name = "每个防御型角色提供全队忍耐+",
	Desc = "每个防御型队员使全队忍耐 +{Value}",
	EffectModule = EffectModule.BuildTeam,
	MultiCount = true,
	EffectCondition = {
		Tag = 
		{
			561207,
		},
	},
	EffectRange = {
		EffectScope = EffectScope.Team,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200003,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id4506] =
{
	Id = 4506,
	Name = "技巧+",
	Desc = "技巧 +{Value}",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200005,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id4507] =
{
	Id = 4507,
	Name = "生命+",
	Desc = "生命 +{Value}",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200001,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id4508] =
{
	Id = 4508,
	Name = "攻击+",
	Desc = "攻击 +{Value}",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200002,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id4509] =
{
	Id = 4509,
	Name = "生命+",
	Desc = "生命 +{Value}",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200001,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id4510] =
{
	Id = 4510,
	Name = "暴击+",
	Desc = "暴击 +{Value}",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200004,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id4511] =
{
	Id = 4511,
	Name = "战力+%",
	Desc = "战力 +{Value}%",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "FightPower",
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id4512] =
{
	Id = 4512,
	Name = "打不过的敌人出现率-%",
	Desc = "打不过的敌人出现概率 +{Value}%",
	EffectModule = EffectModule.ExploreEnemy,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "EnemyWeight",
		Chance = 100,
		CompareFightPower = 1,
		EnemyWeightCondition = {
			CompareWin = 2,
		},
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id4513] =
{
	Id = 4513,
	Name = "力气+",
	Desc = "力气 +{Value}",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200007,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id4514] =
{
	Id = 4514,
	Name = "金币获得+%",
	Desc = "打工获得金币+{Value}%",
	EffectModule = EffectModule.WorkShop,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "WorkShopGoodsNumber",
		EffectValue = 1,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
