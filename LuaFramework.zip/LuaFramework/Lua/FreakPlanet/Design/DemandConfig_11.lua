
DemandConfig[DemandID.Id2263] =
{
	Id = 2263,
	Name = "练习空手道",
	Desc = "这次要一下子劈断好几块木头!",
	Value = 321002,
	Active = true,
	Weight = 475,
	PreGoal = 
	{
		300017,
		300072,
	},
	CloseGoal = 
	{
		300406,
	},
	GoodsId = 161002,
	Num = 21,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 1631,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 15,
				},
				{
					Value = 1,
					Num = 131,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 15,
				},
				{
					Value = 1,
					Num = 131,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 3,
				},
				{
					Value = 1,
					Num = 131,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 3,
				},
				{
					Value = 1,
					Num = 131,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 9,
				},
				{
					Value = 320051,
					Num = 7,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 1,
				},
				{
					Value = 320052,
					Num = 2,
				},
			},
		},
	},
	DemandID = 412263,
	DemandGroupList = {
		420010,
		420011,
		420012,
		420013,
		420014,
		420015,
	},
}
DemandConfig[DemandID.Id2264] =
{
	Id = 2264,
	Name = "练习空手道",
	Desc = "这次要一下子劈断好几块木头!",
	Value = 321002,
	Active = true,
	Weight = 825,
	PreGoal = 
	{
		300017,
		300424,
	},
	CloseGoal = 
	{
		300466,
	},
	GoodsId = 191002,
	Num = 51,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 3962,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 37,
				},
				{
					Value = 1,
					Num = 262,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 37,
				},
				{
					Value = 1,
					Num = 262,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 7,
				},
				{
					Value = 1,
					Num = 462,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 7,
				},
				{
					Value = 1,
					Num = 462,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 1,
				},
				{
					Value = 1,
					Num = 1462,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 1,
				},
				{
					Value = 1,
					Num = 1462,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 23,
				},
				{
					Value = 320051,
					Num = 16,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 4,
				},
				{
					Value = 320052,
					Num = 3,
				},
			},
		},
	},
	DemandID = 412264,
	DemandGroupList = {
		420010,
		420011,
		420012,
		420013,
		420014,
		420015,
	},
}
DemandConfig[DemandID.Id2272] =
{
	Id = 2272,
	Name = "浓醇高汤",
	Desc = "老伴摔了一跤就骨折了，得补点钙。",
	Value = 321003,
	Active = true,
	Weight = 480,
	PreGoal = 
	{
		300030,
		300046,
	},
	CloseGoal = 
	{
		300075,
	},
	GoodsId = 131003,
	Num = 9,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 970,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 8,
				},
				{
					Value = 1,
					Num = 170,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 7,
				},
				{
					Value = 1,
					Num = 270,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 1,
				},
				{
					Value = 1,
					Num = 470,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 1,
				},
				{
					Value = 1,
					Num = 470,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 6,
				},
				{
					Value = 320051,
					Num = 3,
				},
			},
		},
	},
	DemandID = 412272,
	DemandGroupList = {
		420010,
		420011,
		420012,
		420013,
		420014,
		420015,
	},
}
DemandConfig[DemandID.Id2273] =
{
	Id = 2273,
	Name = "浓醇高汤",
	Desc = "老伴摔了一跤就骨折了，得补点钙。",
	Value = 321003,
	Active = true,
	Weight = 880,
	PreGoal = 
	{
		300030,
		300084,
	},
	CloseGoal = 
	{
		300417,
	},
	GoodsId = 161003,
	Num = 24,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 2587,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 22,
				},
				{
					Value = 1,
					Num = 387,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 20,
				},
				{
					Value = 1,
					Num = 587,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 4,
				},
				{
					Value = 1,
					Num = 587,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 4,
				},
				{
					Value = 1,
					Num = 587,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 18,
				},
				{
					Value = 320051,
					Num = 7,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 3,
				},
				{
					Value = 320052,
					Num = 2,
				},
			},
		},
	},
	DemandID = 412273,
	DemandGroupList = {
		420010,
		420011,
		420012,
		420013,
		420014,
		420015,
	},
}
DemandConfig[DemandID.Id2274] =
{
	Id = 2274,
	Name = "浓醇高汤",
	Desc = "老伴摔了一跤就骨折了，得补点钙。",
	Value = 321003,
	Active = true,
	Weight = 1440,
	PreGoal = 
	{
		300030,
		300436,
	},
	CloseGoal = 
	{
		300478,
	},
	GoodsId = 191003,
	Num = 49,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 5282,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 45,
				},
				{
					Value = 1,
					Num = 782,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 42,
				},
				{
					Value = 1,
					Num = 1082,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 9,
				},
				{
					Value = 1,
					Num = 782,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 8,
				},
				{
					Value = 1,
					Num = 1282,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 1,
				},
				{
					Value = 1,
					Num = 2782,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 1,
				},
				{
					Value = 1,
					Num = 2782,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 38,
				},
				{
					Value = 320051,
					Num = 14,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 7,
				},
				{
					Value = 320052,
					Num = 3,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 1,
				},
				{
					Value = 320053,
					Num = 1,
				},
			},
		},
	},
	DemandID = 412274,
	DemandGroupList = {
		420010,
		420011,
		420012,
		420013,
		420014,
		420015,
	},
}
DemandConfig[DemandID.Id2282] =
{
	Id = 2282,
	Name = "矿石收藏家",
	Desc = "喜欢各种不同矿石独特的质感~",
	Value = 321004,
	Active = true,
	Weight = 960,
	PreGoal = 
	{
		300046,
		300062,
	},
	CloseGoal = 
	{
		300091,
	},
	GoodsId = 131004,
	Num = 13,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 1591,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 8,
				},
				{
					Value = 320051,
					Num = 7,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 1,
				},
				{
					Value = 320052,
					Num = 2,
				},
			},
		},
	},
	DemandID = 412282,
	DemandGroupList = {
		420010,
		420011,
		420012,
		420013,
		420014,
		420015,
	},
}
DemandConfig[DemandID.Id2283] =
{
	Id = 2283,
	Name = "矿石收藏家",
	Desc = "喜欢各种不同矿石独特的质感~",
	Value = 321004,
	Active = true,
	Weight = 1560,
	PreGoal = 
	{
		300046,
		300102,
	},
	CloseGoal = 
	{
		300431,
	},
	GoodsId = 161004,
	Num = 40,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 4897,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 46,
				},
				{
					Value = 1,
					Num = 297,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 46,
				},
				{
					Value = 1,
					Num = 297,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 9,
				},
				{
					Value = 1,
					Num = 397,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 9,
				},
				{
					Value = 1,
					Num = 397,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 1,
				},
				{
					Value = 1,
					Num = 2397,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 1,
				},
				{
					Value = 1,
					Num = 2397,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 26,
				},
				{
					Value = 320051,
					Num = 22,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 5,
				},
				{
					Value = 320052,
					Num = 4,
				},
			},
		},
	},
	DemandID = 412283,
	DemandGroupList = {
		420010,
		420011,
		420012,
		420013,
		420014,
		420015,
	},
}
DemandConfig[DemandID.Id2284] =
{
	Id = 2284,
	Name = "矿石收藏家",
	Desc = "喜欢各种不同矿石独特的质感~",
	Value = 321004,
	Active = true,
	Weight = 2400,
	PreGoal = 
	{
		300046,
		300450,
	},
	CloseGoal = 
	{
		300494,
	},
	GoodsId = 191004,
	Num = 51,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 6243,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 58,
				},
				{
					Value = 1,
					Num = 443,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 58,
				},
				{
					Value = 1,
					Num = 443,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 11,
				},
				{
					Value = 1,
					Num = 743,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 11,
				},
				{
					Value = 1,
					Num = 743,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 2,
				},
				{
					Value = 1,
					Num = 1243,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 2,
				},
				{
					Value = 1,
					Num = 1243,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 34,
				},
				{
					Value = 320051,
					Num = 28,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 6,
				},
				{
					Value = 320052,
					Num = 6,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 1,
				},
				{
					Value = 320053,
					Num = 1,
				},
			},
		},
	},
	DemandID = 412284,
	DemandGroupList = {
		420010,
		420011,
		420012,
		420013,
		420014,
		420015,
	},
}
DemandConfig[DemandID.Id2292] =
{
	Id = 2292,
	Name = "地图校对",
	Desc = "有偿回收旧版地图~",
	Value = 321005,
	Active = true,
	Weight = 1425,
	PreGoal = 
	{
		300058,
		300072,
	},
	CloseGoal = 
	{
		300403,
	},
	GoodsId = 131005,
	Num = 18,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 2993,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 14,
				},
				{
					Value = 1,
					Num = 1593,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 14,
				},
				{
					Value = 1,
					Num = 1593,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 2,
				},
				{
					Value = 1,
					Num = 1993,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 2,
				},
				{
					Value = 1,
					Num = 1993,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 17,
				},
				{
					Value = 320051,
					Num = 12,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 3,
				},
				{
					Value = 320052,
					Num = 2,
				},
			},
		},
	},
	DemandID = 412292,
	DemandGroupList = {
		420010,
		420011,
		420012,
		420013,
		420014,
		420015,
	},
}
DemandConfig[DemandID.Id2293] =
{
	Id = 2293,
	Name = "地图校对",
	Desc = "有偿回收旧版地图~",
	Value = 321005,
	Active = true,
	Weight = 2175,
	PreGoal = 
	{
		300058,
		300410,
	},
	CloseGoal = 
	{
		300443,
	},
	GoodsId = 161005,
	Num = 40,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 6652,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 33,
				},
				{
					Value = 1,
					Num = 3352,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 33,
				},
				{
					Value = 1,
					Num = 3352,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 6,
				},
				{
					Value = 1,
					Num = 3652,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 6,
				},
				{
					Value = 1,
					Num = 3652,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 1,
				},
				{
					Value = 1,
					Num = 4152,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 1,
				},
				{
					Value = 1,
					Num = 4152,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 39,
				},
				{
					Value = 320051,
					Num = 27,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 7,
				},
				{
					Value = 320052,
					Num = 6,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 1,
				},
				{
					Value = 320053,
					Num = 1,
				},
			},
		},
	},
	DemandID = 412293,
	DemandGroupList = {
		420010,
		420011,
		420012,
		420013,
		420014,
		420015,
	},
}
DemandConfig[DemandID.Id2294] =
{
	Id = 2294,
	Name = "地图校对",
	Desc = "有偿回收旧版地图~",
	Value = 321005,
	Active = true,
	Weight = 3225,
	PreGoal = 
	{
		300058,
		300462,
	},
	CloseGoal = 
	{
		300810,
	},
	GoodsId = 191005,
	Num = 49,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 8149,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 40,
				},
				{
					Value = 1,
					Num = 4149,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 40,
				},
				{
					Value = 1,
					Num = 4149,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 8,
				},
				{
					Value = 1,
					Num = 4149,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 8,
				},
				{
					Value = 1,
					Num = 4149,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 1,
				},
				{
					Value = 1,
					Num = 5649,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 1,
				},
				{
					Value = 1,
					Num = 5649,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 48,
				},
				{
					Value = 320051,
					Num = 33,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 9,
				},
				{
					Value = 320052,
					Num = 7,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 1,
				},
				{
					Value = 320053,
					Num = 2,
				},
			},
		},
	},
	DemandID = 412294,
	DemandGroupList = {
		420010,
		420011,
		420012,
		420013,
		420014,
		420015,
	},
}
DemandConfig[DemandID.Id2302] =
{
	Id = 2302,
	Name = "制作地图集",
	Desc = "上次制作的地图集卖了个好价钱~",
	Value = 321006,
	Active = true,
	Weight = 1260,
	PreGoal = 
	{
		300055,
		300069,
	},
	CloseGoal = 
	{
		300102,
	},
	GoodsId = 131006,
	Num = 13,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 2673,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 22,
				},
				{
					Value = 1,
					Num = 473,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 22,
				},
				{
					Value = 1,
					Num = 473,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 4,
				},
				{
					Value = 1,
					Num = 673,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 4,
				},
				{
					Value = 1,
					Num = 673,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 16,
				},
				{
					Value = 320051,
					Num = 10,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 3,
				},
				{
					Value = 320052,
					Num = 2,
				},
			},
		},
	},
	DemandID = 412302,
	DemandGroupList = {
		420010,
		420011,
		420012,
		420013,
		420014,
		420015,
	},
}
DemandConfig[DemandID.Id2303] =
{
	Id = 2303,
	Name = "制作地图集",
	Desc = "上次制作的地图集卖了个好价钱~",
	Value = 321006,
	Active = true,
	Weight = 1960,
	PreGoal = 
	{
		300055,
		300406,
	},
	CloseGoal = 
	{
		300439,
	},
	GoodsId = 161006,
	Num = 37,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 7609,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 64,
				},
				{
					Value = 1,
					Num = 1209,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 64,
				},
				{
					Value = 1,
					Num = 1209,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 12,
				},
				{
					Value = 1,
					Num = 1609,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 12,
				},
				{
					Value = 1,
					Num = 1609,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 2,
				},
				{
					Value = 1,
					Num = 2609,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 2,
				},
				{
					Value = 1,
					Num = 2609,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 45,
				},
				{
					Value = 320051,
					Num = 31,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 9,
				},
				{
					Value = 320052,
					Num = 6,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 1,
				},
				{
					Value = 320053,
					Num = 2,
				},
			},
		},
	},
	DemandID = 412303,
	DemandGroupList = {
		420010,
		420011,
		420012,
		420013,
		420014,
		420015,
	},
}
DemandConfig[DemandID.Id2304] =
{
	Id = 2304,
	Name = "制作地图集",
	Desc = "上次制作的地图集卖了个好价钱~",
	Value = 321006,
	Active = true,
	Weight = 2940,
	PreGoal = 
	{
		300055,
		300458,
	},
	CloseGoal = 
	{
		300804,
	},
	GoodsId = 191006,
	Num = 45,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 9254,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 78,
				},
				{
					Value = 1,
					Num = 1454,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 78,
				},
				{
					Value = 1,
					Num = 1454,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 15,
				},
				{
					Value = 1,
					Num = 1754,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 15,
				},
				{
					Value = 1,
					Num = 1754,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 3,
				},
				{
					Value = 1,
					Num = 1754,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 3,
				},
				{
					Value = 1,
					Num = 1754,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 55,
				},
				{
					Value = 320051,
					Num = 37,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 11,
				},
				{
					Value = 320052,
					Num = 7,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 2,
				},
				{
					Value = 320053,
					Num = 1,
				},
			},
		},
	},
	DemandID = 412304,
	DemandGroupList = {
		420010,
		420011,
		420012,
		420013,
		420014,
		420015,
	},
}
DemandConfig[DemandID.Id2312] =
{
	Id = 2312,
	Name = "标本制作",
	Desc = "需要一些尖刺来制作野兽标本。",
	Value = 321007,
	Active = true,
	Weight = 1425,
	PreGoal = 
	{
		300304,
		300072,
	},
	CloseGoal = 
	{
		300403,
	},
	GoodsId = 131007,
	Num = 48,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 10920,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 93,
				},
				{
					Value = 1,
					Num = 1620,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 87,
				},
				{
					Value = 1,
					Num = 2220,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 18,
				},
				{
					Value = 1,
					Num = 1920,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 17,
				},
				{
					Value = 1,
					Num = 2420,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 3,
				},
				{
					Value = 1,
					Num = 3420,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 3,
				},
				{
					Value = 1,
					Num = 3420,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 91,
				},
				{
					Value = 320051,
					Num = 18,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 18,
				},
				{
					Value = 320052,
					Num = 3,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 3,
				},
				{
					Value = 320053,
					Num = 1,
				},
			},
		},
	},
	DemandID = 412312,
	DemandGroupList = {
		420010,
		420011,
		420012,
		420013,
		420014,
		420015,
	},
}
DemandConfig[DemandID.Id2313] =
{
	Id = 2313,
	Name = "标本制作",
	Desc = "需要一些尖刺来制作野兽标本。",
	Value = 321007,
	Active = true,
	Weight = 2175,
	PreGoal = 
	{
		300304,
		300410,
	},
	CloseGoal = 
	{
		300443,
	},
	GoodsId = 161007,
	Num = 111,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 25252,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 216,
				},
				{
					Value = 1,
					Num = 3652,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 202,
				},
				{
					Value = 1,
					Num = 5052,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 43,
				},
				{
					Value = 1,
					Num = 3752,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 40,
				},
				{
					Value = 1,
					Num = 5252,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 8,
				},
				{
					Value = 1,
					Num = 5252,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 8,
				},
				{
					Value = 1,
					Num = 5252,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 1,
				},
				{
					Value = 1,
					Num = 12752,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 1,
				},
				{
					Value = 1,
					Num = 12752,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 212,
				},
				{
					Value = 320051,
					Num = 40,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 42,
				},
				{
					Value = 320052,
					Num = 8,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 8,
				},
				{
					Value = 320053,
					Num = 2,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 1,
				},
				{
					Value = 320054,
					Num = 1,
				},
			},
		},
	},
	DemandID = 412313,
	DemandGroupList = {
		420010,
		420011,
		420012,
		420013,
		420014,
		420015,
	},
}
DemandConfig[DemandID.Id2314] =
{
	Id = 2314,
	Name = "标本制作",
	Desc = "需要一些尖刺来制作野兽标本。",
	Value = 321007,
	Active = true,
	Weight = 3225,
	PreGoal = 
	{
		300304,
		300462,
	},
	CloseGoal = 
	{
		300810,
	},
	GoodsId = 191007,
	Num = 138,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 31395,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 269,
				},
				{
					Value = 1,
					Num = 4495,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 251,
				},
				{
					Value = 1,
					Num = 6295,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 53,
				},
				{
					Value = 1,
					Num = 4895,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 50,
				},
				{
					Value = 1,
					Num = 6395,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 10,
				},
				{
					Value = 1,
					Num = 6395,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 10,
				},
				{
					Value = 1,
					Num = 6395,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 2,
				},
				{
					Value = 1,
					Num = 6395,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 2,
				},
				{
					Value = 1,
					Num = 6395,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 263,
				},
				{
					Value = 320051,
					Num = 50,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 52,
				},
				{
					Value = 320052,
					Num = 10,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 10,
				},
				{
					Value = 320053,
					Num = 2,
				},
			},
		},
	},
	DemandID = 412314,
	DemandGroupList = {
		420010,
		420011,
		420012,
		420013,
		420014,
		420015,
	},
}
DemandConfig[DemandID.Id2322] =
{
	Id = 2322,
	Name = "纪念品",
	Desc = "找不到合适的星沙，用这个代替吧。",
	Value = 321008,
	Active = true,
	Weight = 1980,
	PreGoal = 
	{
		300315,
		300084,
	},
	CloseGoal = 
	{
		300413,
	},
	GoodsId = 131008,
	Num = 21,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 5638,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 28,
				},
				{
					Value = 1,
					Num = 2838,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 28,
				},
				{
					Value = 1,
					Num = 2838,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 5,
				},
				{
					Value = 1,
					Num = 3138,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 5,
				},
				{
					Value = 1,
					Num = 3138,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 1,
				},
				{
					Value = 1,
					Num = 3138,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 1,
				},
				{
					Value = 1,
					Num = 3138,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 33,
				},
				{
					Value = 320051,
					Num = 23,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 6,
				},
				{
					Value = 320052,
					Num = 5,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 1,
				},
				{
					Value = 320053,
					Num = 1,
				},
			},
		},
	},
	DemandID = 412322,
	DemandGroupList = {
		420010,
		420011,
		420012,
		420013,
		420014,
		420015,
	},
}
DemandConfig[DemandID.Id2323] =
{
	Id = 2323,
	Name = "纪念品",
	Desc = "找不到合适的星沙，用这个代替吧。",
	Value = 321008,
	Active = true,
	Weight = 2880,
	PreGoal = 
	{
		300315,
		300421,
	},
	CloseGoal = 
	{
		300454,
	},
	GoodsId = 161008,
	Num = 33,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 8861,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 44,
				},
				{
					Value = 1,
					Num = 4461,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 44,
				},
				{
					Value = 1,
					Num = 4461,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 8,
				},
				{
					Value = 1,
					Num = 4861,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 8,
				},
				{
					Value = 1,
					Num = 4861,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 1,
				},
				{
					Value = 1,
					Num = 6361,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 1,
				},
				{
					Value = 1,
					Num = 6361,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 53,
				},
				{
					Value = 320051,
					Num = 35,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 10,
				},
				{
					Value = 320052,
					Num = 7,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 2,
				},
				{
					Value = 320053,
					Num = 1,
				},
			},
		},
	},
	DemandID = 412323,
	DemandGroupList = {
		420010,
		420011,
		420012,
		420013,
		420014,
		420015,
	},
}
DemandConfig[DemandID.Id2324] =
{
	Id = 2324,
	Name = "纪念品",
	Desc = "找不到合适的星沙，用这个代替吧。",
	Value = 321008,
	Active = true,
	Weight = 4140,
	PreGoal = 
	{
		300315,
		300474,
	},
	CloseGoal = 
	{
		300823,
	},
	GoodsId = 191008,
	Num = 45,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 12083,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 60,
				},
				{
					Value = 1,
					Num = 6083,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 60,
				},
				{
					Value = 1,
					Num = 6083,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 12,
				},
				{
					Value = 1,
					Num = 6083,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 12,
				},
				{
					Value = 1,
					Num = 6083,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 2,
				},
				{
					Value = 1,
					Num = 7083,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 2,
				},
				{
					Value = 1,
					Num = 7083,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 72,
				},
				{
					Value = 320051,
					Num = 48,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 14,
				},
				{
					Value = 320052,
					Num = 10,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 2,
				},
				{
					Value = 320053,
					Num = 2,
				},
			},
		},
	},
	DemandID = 412324,
	DemandGroupList = {
		420010,
		420011,
		420012,
		420013,
		420014,
		420015,
	},
}
DemandConfig[DemandID.Id2332] =
{
	Id = 2332,
	Name = "危险魔术",
	Desc = "老是丢保龄球瓶也挺无聊的…",
	Value = 321009,
	Active = true,
	Weight = 3105,
	PreGoal = 
	{
		300087,
		300403,
	},
	CloseGoal = 
	{
		300431,
	},
	GoodsId = 131009,
	Num = 33,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 9184,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 76,
				},
				{
					Value = 1,
					Num = 1584,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 76,
				},
				{
					Value = 1,
					Num = 1584,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 15,
				},
				{
					Value = 1,
					Num = 1684,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 15,
				},
				{
					Value = 1,
					Num = 1684,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 3,
				},
				{
					Value = 1,
					Num = 1684,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 3,
				},
				{
					Value = 1,
					Num = 1684,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 55,
				},
				{
					Value = 320051,
					Num = 36,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 11,
				},
				{
					Value = 320052,
					Num = 7,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 2,
				},
				{
					Value = 320053,
					Num = 1,
				},
			},
		},
	},
	DemandID = 412332,
	DemandGroupList = {
		420010,
		420011,
		420012,
		420013,
		420014,
		420015,
	},
}
DemandConfig[DemandID.Id2333] =
{
	Id = 2333,
	Name = "危险魔术",
	Desc = "老是丢保龄球瓶也挺无聊的…",
	Value = 321009,
	Active = true,
	Weight = 4255,
	PreGoal = 
	{
		300087,
		300439,
	},
	CloseGoal = 
	{
		300474,
	},
	GoodsId = 161009,
	Num = 39,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 10854,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 90,
				},
				{
					Value = 1,
					Num = 1854,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 90,
				},
				{
					Value = 1,
					Num = 1854,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 18,
				},
				{
					Value = 1,
					Num = 1854,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 18,
				},
				{
					Value = 1,
					Num = 1854,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 3,
				},
				{
					Value = 1,
					Num = 3354,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 3,
				},
				{
					Value = 1,
					Num = 3354,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 65,
				},
				{
					Value = 320051,
					Num = 43,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 13,
				},
				{
					Value = 320052,
					Num = 8,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 2,
				},
				{
					Value = 320053,
					Num = 2,
				},
			},
		},
	},
	DemandID = 412333,
	DemandGroupList = {
		420010,
		420011,
		420012,
		420013,
		420014,
		420015,
	},
}
DemandConfig[DemandID.Id2334] =
{
	Id = 2334,
	Name = "危险魔术",
	Desc = "老是丢保龄球瓶也挺无聊的…",
	Value = 321009,
	Active = true,
	Weight = 5865,
	PreGoal = 
	{
		300087,
		300494,
	},
	CloseGoal = 
	{
		300844,
	},
	GoodsId = 191009,
	Num = 48,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 13359,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 111,
				},
				{
					Value = 1,
					Num = 2259,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 111,
				},
				{
					Value = 1,
					Num = 2259,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 22,
				},
				{
					Value = 1,
					Num = 2359,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 22,
				},
				{
					Value = 1,
					Num = 2359,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 4,
				},
				{
					Value = 1,
					Num = 3359,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 4,
				},
				{
					Value = 1,
					Num = 3359,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 80,
				},
				{
					Value = 320051,
					Num = 53,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 16,
				},
				{
					Value = 320052,
					Num = 10,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 3,
				},
				{
					Value = 320053,
					Num = 2,
				},
			},
		},
	},
	DemandID = 412334,
	DemandGroupList = {
		420010,
		420011,
		420012,
		420013,
		420014,
		420015,
	},
}
DemandConfig[DemandID.Id2342] =
{
	Id = 2342,
	Name = "勇敢的证明",
	Desc = "需要道具证明我去过魔王城堡。",
	Value = 321010,
	Active = true,
	Weight = 3625,
	PreGoal = 
	{
		300326,
		300410,
	},
	CloseGoal = 
	{
		300439,
	},
	GoodsId = 131010,
	Num = 27,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 13430,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 114,
				},
				{
					Value = 1,
					Num = 2030,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 114,
				},
				{
					Value = 1,
					Num = 2030,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 22,
				},
				{
					Value = 1,
					Num = 2430,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 22,
				},
				{
					Value = 1,
					Num = 2430,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 4,
				},
				{
					Value = 1,
					Num = 3430,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 4,
				},
				{
					Value = 1,
					Num = 3430,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 80,
				},
				{
					Value = 320051,
					Num = 54,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 16,
				},
				{
					Value = 320052,
					Num = 10,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 3,
				},
				{
					Value = 320053,
					Num = 2,
				},
			},
		},
	},
	DemandID = 412342,
	DemandGroupList = {
		420010,
		420011,
		420012,
		420013,
		420014,
		420015,
	},
}
DemandConfig[DemandID.Id2343] =
{
	Id = 2343,
	Name = "勇敢的证明",
	Desc = "需要道具证明我去过魔王城堡。",
	Value = 321010,
	Active = true,
	Weight = 4875,
	PreGoal = 
	{
		300326,
		300446,
	},
	CloseGoal = 
	{
		300482,
	},
	GoodsId = 161010,
	Num = 33,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 16414,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 139,
				},
				{
					Value = 1,
					Num = 2514,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 139,
				},
				{
					Value = 1,
					Num = 2514,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 27,
				},
				{
					Value = 1,
					Num = 2914,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 27,
				},
				{
					Value = 1,
					Num = 2914,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 5,
				},
				{
					Value = 1,
					Num = 3914,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 5,
				},
				{
					Value = 1,
					Num = 3914,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 1,
				},
				{
					Value = 1,
					Num = 3914,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 1,
				},
				{
					Value = 1,
					Num = 3914,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 98,
				},
				{
					Value = 320051,
					Num = 66,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 19,
				},
				{
					Value = 320052,
					Num = 13,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 3,
				},
				{
					Value = 320053,
					Num = 3,
				},
			},
		},
	},
	DemandID = 412343,
	DemandGroupList = {
		420010,
		420011,
		420012,
		420013,
		420014,
		420015,
	},
}
DemandConfig[DemandID.Id2344] =
{
	Id = 2344,
	Name = "勇敢的证明",
	Desc = "需要道具证明我去过魔王城堡。",
	Value = 321010,
	Active = true,
	Weight = 6625,
	PreGoal = 
	{
		300326,
		300804,
	},
	CloseGoal = 
	{
		300852,
	},
	GoodsId = 191010,
	Num = 42,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 20891,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 177,
				},
				{
					Value = 1,
					Num = 3191,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 177,
				},
				{
					Value = 1,
					Num = 3191,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 35,
				},
				{
					Value = 1,
					Num = 3391,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 35,
				},
				{
					Value = 1,
					Num = 3391,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 7,
				},
				{
					Value = 1,
					Num = 3391,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 7,
				},
				{
					Value = 1,
					Num = 3391,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 1,
				},
				{
					Value = 1,
					Num = 8391,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 1,
				},
				{
					Value = 1,
					Num = 8391,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 125,
				},
				{
					Value = 320051,
					Num = 83,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 25,
				},
				{
					Value = 320052,
					Num = 16,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 5,
				},
				{
					Value = 320053,
					Num = 3,
				},
			},
		},
	},
	DemandID = 412344,
	DemandGroupList = {
		420010,
		420011,
		420012,
		420013,
		420014,
		420015,
	},
}
DemandConfig[DemandID.Id2352] =
{
	Id = 2352,
	Name = "黑巫师委托",
	Desc = "需要很多头骨才能完成节阵。",
	Value = 321051,
	Active = true,
	Weight = 576,
	PreGoal = 
	{
		300331,
		300062,
	},
	CloseGoal = 
	{
		300091,
	},
	GoodsId = 131051,
	Num = 3,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 3453,
				},
			},
		},
	},
	DemandID = 412352,
	DemandGroupList = {
		420010,
		420011,
		420012,
		420013,
		420014,
		420015,
	},
}
DemandConfig[DemandID.Id2353] =
{
	Id = 2353,
	Name = "黑巫师委托",
	Desc = "需要很多头骨才能完成节阵。",
	Value = 321051,
	Active = true,
	Weight = 936,
	PreGoal = 
	{
		300331,
		300084,
	},
	CloseGoal = 
	{
		300431,
	},
	GoodsId = 161051,
	Num = 12,
	RewardList = {
		{
			Weight = 0,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 13813,
				},
			},
		},
		{
			Weight = 80,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320001,
					Num = 1,
				},
				{
					Value = 1,
					Num = 5173,
				},
			},
		},
	},
	DemandID = 412353,
	DemandGroupList = {
		420010,
		420011,
		420012,
		420013,
		420014,
		420015,
	},
}
DemandConfig[DemandID.Id2354] =
{
	Id = 2354,
	Name = "黑巫师委托",
	Desc = "需要很多头骨才能完成节阵。",
	Value = 321051,
	Active = true,
	Weight = 1440,
	PreGoal = 
	{
		300331,
		300450,
	},
	CloseGoal = 
	{
		300494,
	},
	GoodsId = 191051,
	Num = 15,
	RewardList = {
		{
			Weight = 0,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 17267,
				},
			},
		},
		{
			Weight = 80,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320001,
					Num = 1,
				},
				{
					Value = 1,
					Num = 8627,
				},
			},
		},
	},
	DemandID = 412354,
	DemandGroupList = {
		420010,
		420011,
		420012,
		420013,
		420014,
		420015,
	},
}
DemandConfig[DemandID.Id2362] =
{
	Id = 2362,
	Name = "游戏攻略网",
	Desc = "有偿征集游戏攻略，欢迎投稿。",
	Value = 321052,
	Active = true,
	Weight = 1311,
	PreGoal = 
	{
		300332,
		300087,
	},
	CloseGoal = 
	{
		300417,
	},
	GoodsId = 131052,
	Num = 4,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 7439,
				},
			},
		},
	},
	DemandID = 412362,
	DemandGroupList = {
		420010,
		420011,
		420012,
		420013,
		420014,
		420015,
	},
}
DemandConfig[DemandID.Id2363] =
{
	Id = 2363,
	Name = "游戏攻略网",
	Desc = "有偿征集游戏攻略，欢迎投稿。",
	Value = 321052,
	Active = true,
	Weight = 1881,
	PreGoal = 
	{
		300332,
		300424,
	},
	CloseGoal = 
	{
		300458,
	},
	GoodsId = 161052,
	Num = 12,
	RewardList = {
		{
			Weight = 0,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 22318,
				},
			},
		},
		{
			Weight = 80,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320001,
					Num = 2,
				},
				{
					Value = 1,
					Num = 5038,
				},
			},
		},
	},
	DemandID = 412363,
	DemandGroupList = {
		420010,
		420011,
		420012,
		420013,
		420014,
		420015,
	},
}
DemandConfig[DemandID.Id2364] =
{
	Id = 2364,
	Name = "游戏攻略网",
	Desc = "有偿征集游戏攻略，欢迎投稿。",
	Value = 321052,
	Active = true,
	Weight = 2679,
	PreGoal = 
	{
		300332,
		300478,
	},
	CloseGoal = 
	{
		300827,
	},
	GoodsId = 191052,
	Num = 15,
	RewardList = {
		{
			Weight = 0,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 27898,
				},
			},
		},
		{
			Weight = 80,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320001,
					Num = 2,
				},
				{
					Value = 1,
					Num = 10618,
				},
			},
		},
	},
	DemandID = 412364,
	DemandGroupList = {
		420010,
		420011,
		420012,
		420013,
		420014,
		420015,
	},
}
DemandConfig[DemandID.Id2372] =
{
	Id = 2372,
	Name = "魔法实验室",
	Desc = "需要符合法师们品味的计时器。",
	Value = 321053,
	Active = true,
	Weight = 1188,
	PreGoal = 
	{
		300333,
		300084,
	},
	CloseGoal = 
	{
		300413,
	},
	GoodsId = 131053,
	Num = 1,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 2033,
				},
			},
		},
	},
	DemandID = 412372,
	DemandGroupList = {
		420010,
		420011,
		420012,
		420013,
		420014,
		420015,
	},
}
DemandConfig[DemandID.Id2373] =
{
	Id = 2373,
	Name = "魔法实验室",
	Desc = "需要符合法师们品味的计时器。",
	Value = 321053,
	Active = true,
	Weight = 1728,
	PreGoal = 
	{
		300333,
		300421,
	},
	CloseGoal = 
	{
		300454,
	},
	GoodsId = 161053,
	Num = 6,
	RewardList = {
		{
			Weight = 0,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 12200,
				},
			},
		},
		{
			Weight = 80,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320001,
					Num = 1,
				},
				{
					Value = 1,
					Num = 3560,
				},
			},
		},
	},
	DemandID = 412373,
	DemandGroupList = {
		420010,
		420011,
		420012,
		420013,
		420014,
		420015,
	},
}
DemandConfig[DemandID.Id2374] =
{
	Id = 2374,
	Name = "魔法实验室",
	Desc = "需要符合法师们品味的计时器。",
	Value = 321053,
	Active = true,
	Weight = 2484,
	PreGoal = 
	{
		300333,
		300474,
	},
	CloseGoal = 
	{
		300823,
	},
	GoodsId = 191053,
	Num = 6,
	RewardList = {
		{
			Weight = 0,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 12200,
				},
			},
		},
		{
			Weight = 80,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320001,
					Num = 1,
				},
				{
					Value = 1,
					Num = 3560,
				},
			},
		},
	},
	DemandID = 412374,
	DemandGroupList = {
		420010,
		420011,
		420012,
		420013,
		420014,
		420015,
	},
}
DemandConfig[DemandID.Id2382] =
{
	Id = 2382,
	Name = "洞穴探险队",
	Desc = "前往黑暗的地方必须要这些！",
	Value = 321054,
	Active = true,
	Weight = 1863,
	PreGoal = 
	{
		300334,
		300403,
	},
	CloseGoal = 
	{
		300431,
	},
	GoodsId = 131054,
	Num = 7,
	RewardList = {
		{
			Weight = 0,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 16673,
				},
			},
		},
		{
			Weight = 80,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320001,
					Num = 1,
				},
				{
					Value = 1,
					Num = 8033,
				},
			},
		},
	},
	DemandID = 412382,
	DemandGroupList = {
		420010,
		420011,
		420012,
		420013,
		420014,
		420015,
	},
}
DemandConfig[DemandID.Id2383] =
{
	Id = 2383,
	Name = "洞穴探险队",
	Desc = "前往黑暗的地方必须要这些！",
	Value = 321054,
	Active = true,
	Weight = 2553,
	PreGoal = 
	{
		300334,
		300439,
	},
	CloseGoal = 
	{
		300474,
	},
	GoodsId = 161054,
	Num = 7,
	RewardList = {
		{
			Weight = 0,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 16673,
				},
			},
		},
		{
			Weight = 80,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320001,
					Num = 1,
				},
				{
					Value = 1,
					Num = 8033,
				},
			},
		},
	},
	DemandID = 412383,
	DemandGroupList = {
		420010,
		420011,
		420012,
		420013,
		420014,
		420015,
	},
}
DemandConfig[DemandID.Id2384] =
{
	Id = 2384,
	Name = "洞穴探险队",
	Desc = "前往黑暗的地方必须要这些！",
	Value = 321054,
	Active = true,
	Weight = 3519,
	PreGoal = 
	{
		300334,
		300494,
	},
	CloseGoal = 
	{
		300844,
	},
	GoodsId = 191054,
	Num = 9,
	RewardList = {
		{
			Weight = 0,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 21437,
				},
			},
		},
		{
			Weight = 80,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320001,
					Num = 2,
				},
				{
					Value = 1,
					Num = 4157,
				},
			},
		},
	},
	DemandID = 412384,
	DemandGroupList = {
		420010,
		420011,
		420012,
		420013,
		420014,
		420015,
	},
}
DemandConfig[DemandID.Id2392] =
{
	Id = 2392,
	Name = "订购豆沙1",
	Desc = "需要一些豆沙",
	Value = 321201,
	Active = true,
	Weight = 4480,
	PreGoal = 
	{
		300406,
		300421,
	},
	CloseGoal = 
	{
		300450,
	},
	GoodsId = 131201,
	Num = 33,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 11503,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 97,
				},
				{
					Value = 1,
					Num = 1803,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 97,
				},
				{
					Value = 1,
					Num = 1803,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 19,
				},
				{
					Value = 1,
					Num = 2003,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 19,
				},
				{
					Value = 1,
					Num = 2003,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 3,
				},
				{
					Value = 1,
					Num = 4003,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 3,
				},
				{
					Value = 1,
					Num = 4003,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 69,
				},
				{
					Value = 320051,
					Num = 46,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 13,
				},
				{
					Value = 320052,
					Num = 10,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 2,
				},
				{
					Value = 320053,
					Num = 2,
				},
			},
		},
	},
	DemandID = 412392,
	DemandGroupList = {
		420010,
		420011,
		420012,
		420013,
		420014,
		420015,
	},
}
DemandConfig[DemandID.Id2393] =
{
	Id = 2393,
	Name = "订购豆沙1",
	Desc = "需要一些豆沙",
	Value = 321201,
	Active = true,
	Weight = 5880,
	PreGoal = 
	{
		300406,
		300458,
	},
	CloseGoal = 
	{
		300494,
	},
	GoodsId = 161201,
	Num = 39,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 13595,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 115,
				},
				{
					Value = 1,
					Num = 2095,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 115,
				},
				{
					Value = 1,
					Num = 2095,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 23,
				},
				{
					Value = 1,
					Num = 2095,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 23,
				},
				{
					Value = 1,
					Num = 2095,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 4,
				},
				{
					Value = 1,
					Num = 3595,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 4,
				},
				{
					Value = 1,
					Num = 3595,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 81,
				},
				{
					Value = 320051,
					Num = 54,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 16,
				},
				{
					Value = 320052,
					Num = 11,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 3,
				},
				{
					Value = 320053,
					Num = 2,
				},
			},
		},
	},
	DemandID = 412393,
	DemandGroupList = {
		420010,
		420011,
		420012,
		420013,
		420014,
		420015,
	},
}
DemandConfig[DemandID.Id2394] =
{
	Id = 2394,
	Name = "订购豆沙1",
	Desc = "需要一些豆沙",
	Value = 321201,
	Active = true,
	Weight = 7840,
	PreGoal = 
	{
		300406,
		300819,
	},
	CloseGoal = 
	{
		300864,
	},
	GoodsId = 191201,
	Num = 49,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 17081,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 145,
				},
				{
					Value = 1,
					Num = 2581,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 145,
				},
				{
					Value = 1,
					Num = 2581,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 29,
				},
				{
					Value = 1,
					Num = 2581,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 29,
				},
				{
					Value = 1,
					Num = 2581,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 5,
				},
				{
					Value = 1,
					Num = 4581,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 5,
				},
				{
					Value = 1,
					Num = 4581,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 1,
				},
				{
					Value = 1,
					Num = 4581,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 1,
				},
				{
					Value = 1,
					Num = 4581,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 102,
				},
				{
					Value = 320051,
					Num = 68,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 20,
				},
				{
					Value = 320052,
					Num = 14,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 4,
				},
				{
					Value = 320053,
					Num = 2,
				},
			},
		},
	},
	DemandID = 412394,
	DemandGroupList = {
		420010,
		420011,
		420012,
		420013,
		420014,
		420015,
	},
}
DemandConfig[DemandID.Id2402] =
{
	Id = 2402,
	Name = "订购冰块1",
	Desc = "需要一些冰块",
	Value = 321202,
	Active = true,
	Weight = 5100,
	PreGoal = 
	{
		300704,
		300428,
	},
	CloseGoal = 
	{
		300458,
	},
	GoodsId = 131202,
	Num = 31,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 13193,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 113,
				},
				{
					Value = 1,
					Num = 1893,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 105,
				},
				{
					Value = 1,
					Num = 2693,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 22,
				},
				{
					Value = 1,
					Num = 2193,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 21,
				},
				{
					Value = 1,
					Num = 2693,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 4,
				},
				{
					Value = 1,
					Num = 3193,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 4,
				},
				{
					Value = 1,
					Num = 3193,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 94,
				},
				{
					Value = 320051,
					Num = 37,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 18,
				},
				{
					Value = 320052,
					Num = 8,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 3,
				},
				{
					Value = 320053,
					Num = 2,
				},
			},
		},
	},
	DemandID = 412402,
	DemandGroupList = {
		420010,
		420011,
		420012,
		420013,
		420014,
		420015,
	},
}
DemandConfig[DemandID.Id2403] =
{
	Id = 2403,
	Name = "订购冰块1",
	Desc = "需要一些冰块",
	Value = 321202,
	Active = true,
	Weight = 6600,
	PreGoal = 
	{
		300704,
		300466,
	},
	CloseGoal = 
	{
		300804,
	},
	GoodsId = 161202,
	Num = 37,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 15747,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 134,
				},
				{
					Value = 1,
					Num = 2347,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 125,
				},
				{
					Value = 1,
					Num = 3247,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 26,
				},
				{
					Value = 1,
					Num = 2747,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 25,
				},
				{
					Value = 1,
					Num = 3247,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 5,
				},
				{
					Value = 1,
					Num = 3247,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 5,
				},
				{
					Value = 1,
					Num = 3247,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 1,
				},
				{
					Value = 1,
					Num = 3247,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 1,
				},
				{
					Value = 1,
					Num = 3247,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 113,
				},
				{
					Value = 320051,
					Num = 44,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 22,
				},
				{
					Value = 320052,
					Num = 9,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 4,
				},
				{
					Value = 320053,
					Num = 2,
				},
			},
		},
	},
	DemandID = 412403,
	DemandGroupList = {
		420010,
		420011,
		420012,
		420013,
		420014,
		420015,
	},
}
DemandConfig[DemandID.Id2404] =
{
	Id = 2404,
	Name = "订购冰块1",
	Desc = "需要一些冰块",
	Value = 321202,
	Active = true,
	Weight = 8700,
	PreGoal = 
	{
		300704,
		300827,
	},
	CloseGoal = 
	{
		300872,
	},
	GoodsId = 191202,
	Num = 48,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 20428,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 175,
				},
				{
					Value = 1,
					Num = 2928,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 163,
				},
				{
					Value = 1,
					Num = 4128,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 35,
				},
				{
					Value = 1,
					Num = 2928,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 32,
				},
				{
					Value = 1,
					Num = 4428,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 7,
				},
				{
					Value = 1,
					Num = 2928,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 6,
				},
				{
					Value = 1,
					Num = 5428,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 1,
				},
				{
					Value = 1,
					Num = 7928,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 1,
				},
				{
					Value = 1,
					Num = 7928,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 147,
				},
				{
					Value = 320051,
					Num = 57,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 29,
				},
				{
					Value = 320052,
					Num = 11,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 5,
				},
				{
					Value = 320053,
					Num = 3,
				},
			},
		},
	},
	DemandID = 412404,
	DemandGroupList = {
		420010,
		420011,
		420012,
		420013,
		420014,
		420015,
	},
}
DemandConfig[DemandID.Id2412] =
{
	Id = 2412,
	Name = "订购牛奶1",
	Desc = "需要一些牛奶",
	Value = 321203,
	Active = true,
	Weight = 5100,
	PreGoal = 
	{
		300413,
		300428,
	},
	CloseGoal = 
	{
		300458,
	},
	GoodsId = 131203,
	Num = 33,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 11850,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 100,
				},
				{
					Value = 1,
					Num = 1850,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 100,
				},
				{
					Value = 1,
					Num = 1850,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 20,
				},
				{
					Value = 1,
					Num = 1850,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 20,
				},
				{
					Value = 1,
					Num = 1850,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 4,
				},
				{
					Value = 1,
					Num = 1850,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 4,
				},
				{
					Value = 1,
					Num = 1850,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 71,
				},
				{
					Value = 320051,
					Num = 47,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 14,
				},
				{
					Value = 320052,
					Num = 9,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 2,
				},
				{
					Value = 320053,
					Num = 2,
				},
			},
		},
	},
	DemandID = 412412,
	DemandGroupList = {
		420010,
		420011,
		420012,
		420013,
		420014,
		420015,
	},
}
DemandConfig[DemandID.Id2413] =
{
	Id = 2413,
	Name = "订购牛奶1",
	Desc = "需要一些牛奶",
	Value = 321203,
	Active = true,
	Weight = 6600,
	PreGoal = 
	{
		300413,
		300466,
	},
	CloseGoal = 
	{
		300804,
	},
	GoodsId = 161203,
	Num = 40,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 14364,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 122,
				},
				{
					Value = 1,
					Num = 2164,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 122,
				},
				{
					Value = 1,
					Num = 2164,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 24,
				},
				{
					Value = 1,
					Num = 2364,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 24,
				},
				{
					Value = 1,
					Num = 2364,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 4,
				},
				{
					Value = 1,
					Num = 4364,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 4,
				},
				{
					Value = 1,
					Num = 4364,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 86,
				},
				{
					Value = 320051,
					Num = 57,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 17,
				},
				{
					Value = 320052,
					Num = 11,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 3,
				},
				{
					Value = 320053,
					Num = 2,
				},
			},
		},
	},
	DemandID = 412413,
	DemandGroupList = {
		420010,
		420011,
		420012,
		420013,
		420014,
		420015,
	},
}
DemandConfig[DemandID.Id2414] =
{
	Id = 2414,
	Name = "订购牛奶1",
	Desc = "需要一些牛奶",
	Value = 321203,
	Active = true,
	Weight = 8700,
	PreGoal = 
	{
		300413,
		300827,
	},
	CloseGoal = 
	{
		300872,
	},
	GoodsId = 191203,
	Num = 51,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 18314,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 155,
				},
				{
					Value = 1,
					Num = 2814,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 155,
				},
				{
					Value = 1,
					Num = 2814,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 31,
				},
				{
					Value = 1,
					Num = 2814,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 31,
				},
				{
					Value = 1,
					Num = 2814,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 6,
				},
				{
					Value = 1,
					Num = 3314,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 6,
				},
				{
					Value = 1,
					Num = 3314,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 1,
				},
				{
					Value = 1,
					Num = 5814,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 1,
				},
				{
					Value = 1,
					Num = 5814,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 109,
				},
				{
					Value = 320051,
					Num = 74,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 21,
				},
				{
					Value = 320052,
					Num = 15,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 4,
				},
				{
					Value = 320053,
					Num = 3,
				},
			},
		},
	},
	DemandID = 412414,
	DemandGroupList = {
		420010,
		420011,
		420012,
		420013,
		420014,
		420015,
	},
}
DemandConfig[DemandID.Id2422] =
{
	Id = 2422,
	Name = "订购高标蛋1",
	Desc = "需要一些高标蛋",
	Value = 321204,
	Active = true,
	Weight = 6105,
	PreGoal = 
	{
		300424,
		300439,
	},
	CloseGoal = 
	{
		300470,
	},
	GoodsId = 131204,
	Num = 33,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 14747,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 125,
				},
				{
					Value = 1,
					Num = 2247,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 125,
				},
				{
					Value = 1,
					Num = 2247,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 25,
				},
				{
					Value = 1,
					Num = 2247,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 25,
				},
				{
					Value = 1,
					Num = 2247,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 5,
				},
				{
					Value = 1,
					Num = 2247,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 5,
				},
				{
					Value = 1,
					Num = 2247,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 1,
				},
				{
					Value = 1,
					Num = 2247,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 1,
				},
				{
					Value = 1,
					Num = 2247,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 88,
				},
				{
					Value = 320051,
					Num = 59,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 17,
				},
				{
					Value = 320052,
					Num = 12,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 3,
				},
				{
					Value = 320053,
					Num = 2,
				},
			},
		},
	},
	DemandID = 412422,
	DemandGroupList = {
		420010,
		420011,
		420012,
		420013,
		420014,
		420015,
	},
}
DemandConfig[DemandID.Id2423] =
{
	Id = 2423,
	Name = "订购高标蛋1",
	Desc = "需要一些高标蛋",
	Value = 321204,
	Active = true,
	Weight = 7755,
	PreGoal = 
	{
		300424,
		300478,
	},
	CloseGoal = 
	{
		300819,
	},
	GoodsId = 161204,
	Num = 39,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 17428,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 148,
				},
				{
					Value = 1,
					Num = 2628,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 148,
				},
				{
					Value = 1,
					Num = 2628,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 29,
				},
				{
					Value = 1,
					Num = 2928,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 29,
				},
				{
					Value = 1,
					Num = 2928,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 5,
				},
				{
					Value = 1,
					Num = 4928,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 5,
				},
				{
					Value = 1,
					Num = 4928,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 1,
				},
				{
					Value = 1,
					Num = 4928,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 1,
				},
				{
					Value = 1,
					Num = 4928,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 104,
				},
				{
					Value = 320051,
					Num = 70,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 20,
				},
				{
					Value = 320052,
					Num = 14,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 4,
				},
				{
					Value = 320053,
					Num = 2,
				},
			},
		},
	},
	DemandID = 412423,
	DemandGroupList = {
		420010,
		420011,
		420012,
		420013,
		420014,
		420015,
	},
}
DemandConfig[DemandID.Id2424] =
{
	Id = 2424,
	Name = "订购高标蛋1",
	Desc = "需要一些高标蛋",
	Value = 321204,
	Active = true,
	Weight = 10065,
	PreGoal = 
	{
		300424,
		300840,
	},
	CloseGoal = 
	{
		300884,
	},
	GoodsId = 191204,
	Num = 49,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 21897,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 186,
				},
				{
					Value = 1,
					Num = 3297,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 186,
				},
				{
					Value = 1,
					Num = 3297,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 37,
				},
				{
					Value = 1,
					Num = 3397,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 37,
				},
				{
					Value = 1,
					Num = 3397,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 7,
				},
				{
					Value = 1,
					Num = 4397,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 7,
				},
				{
					Value = 1,
					Num = 4397,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 1,
				},
				{
					Value = 1,
					Num = 9397,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 1,
				},
				{
					Value = 1,
					Num = 9397,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 131,
				},
				{
					Value = 320051,
					Num = 87,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 26,
				},
				{
					Value = 320052,
					Num = 17,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 5,
				},
				{
					Value = 320053,
					Num = 3,
				},
			},
		},
	},
	DemandID = 412424,
	DemandGroupList = {
		420010,
		420011,
		420012,
		420013,
		420014,
		420015,
	},
}
DemandConfig[DemandID.Id2432] =
{
	Id = 2432,
	Name = "订购鱼肉1",
	Desc = "需要一些鱼肉",
	Value = 321205,
	Active = true,
	Weight = 7585,
	PreGoal = 
	{
		300722,
		300454,
	},
	CloseGoal = 
	{
		300486,
	},
	GoodsId = 131205,
	Num = 31,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 19334,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 164,
				},
				{
					Value = 1,
					Num = 2934,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 164,
				},
				{
					Value = 1,
					Num = 2934,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 32,
				},
				{
					Value = 1,
					Num = 3334,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 32,
				},
				{
					Value = 1,
					Num = 3334,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 6,
				},
				{
					Value = 1,
					Num = 4334,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 6,
				},
				{
					Value = 1,
					Num = 4334,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 1,
				},
				{
					Value = 1,
					Num = 6834,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 1,
				},
				{
					Value = 1,
					Num = 6834,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 116,
				},
				{
					Value = 320051,
					Num = 77,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 23,
				},
				{
					Value = 320052,
					Num = 15,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 4,
				},
				{
					Value = 320053,
					Num = 3,
				},
			},
		},
	},
	DemandID = 412432,
	DemandGroupList = {
		420010,
		420011,
		420012,
		420013,
		420014,
		420015,
	},
}
DemandConfig[DemandID.Id2433] =
{
	Id = 2433,
	Name = "订购鱼肉1",
	Desc = "需要一些鱼肉",
	Value = 321205,
	Active = true,
	Weight = 9435,
	PreGoal = 
	{
		300722,
		300494,
	},
	CloseGoal = 
	{
		300836,
	},
	GoodsId = 161205,
	Num = 37,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 23076,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 196,
				},
				{
					Value = 1,
					Num = 3476,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 196,
				},
				{
					Value = 1,
					Num = 3476,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 39,
				},
				{
					Value = 1,
					Num = 3576,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 39,
				},
				{
					Value = 1,
					Num = 3576,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 7,
				},
				{
					Value = 1,
					Num = 5576,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 7,
				},
				{
					Value = 1,
					Num = 5576,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 1,
				},
				{
					Value = 1,
					Num = 10576,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 1,
				},
				{
					Value = 1,
					Num = 10576,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 138,
				},
				{
					Value = 320051,
					Num = 92,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 27,
				},
				{
					Value = 320052,
					Num = 19,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 5,
				},
				{
					Value = 320053,
					Num = 4,
				},
			},
		},
	},
	DemandID = 412433,
	DemandGroupList = {
		420010,
		420011,
		420012,
		420013,
		420014,
		420015,
	},
}
DemandConfig[DemandID.Id2434] =
{
	Id = 2434,
	Name = "订购鱼肉1",
	Desc = "需要一些鱼肉",
	Value = 321205,
	Active = true,
	Weight = 12025,
	PreGoal = 
	{
		300722,
		300856,
	},
	CloseGoal = 
	{
		300900,
	},
	GoodsId = 191205,
	Num = 48,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 29937,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 254,
				},
				{
					Value = 1,
					Num = 4537,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 254,
				},
				{
					Value = 1,
					Num = 4537,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 50,
				},
				{
					Value = 1,
					Num = 4937,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 50,
				},
				{
					Value = 1,
					Num = 4937,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 10,
				},
				{
					Value = 1,
					Num = 4937,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 10,
				},
				{
					Value = 1,
					Num = 4937,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 2,
				},
				{
					Value = 1,
					Num = 4937,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 2,
				},
				{
					Value = 1,
					Num = 4937,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 179,
				},
				{
					Value = 320051,
					Num = 120,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 35,
				},
				{
					Value = 320052,
					Num = 24,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 7,
				},
				{
					Value = 320053,
					Num = 4,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 1,
				},
				{
					Value = 320054,
					Num = 1,
				},
			},
		},
	},
	DemandID = 412434,
	DemandGroupList = {
		420010,
		420011,
		420012,
		420013,
		420014,
		420015,
	},
}
DemandConfig[DemandID.Id2442] =
{
	Id = 2442,
	Name = "订购米饭1",
	Desc = "需要一些米饭",
	Value = 321206,
	Active = true,
	Weight = 7980,
	PreGoal = 
	{
		300443,
		300458,
	},
	CloseGoal = 
	{
		300490,
	},
	GoodsId = 131206,
	Num = 33,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 19002,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 179,
				},
				{
					Value = 1,
					Num = 1102,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 179,
				},
				{
					Value = 1,
					Num = 1102,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 35,
				},
				{
					Value = 1,
					Num = 1502,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 35,
				},
				{
					Value = 1,
					Num = 1502,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 7,
				},
				{
					Value = 1,
					Num = 1502,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 7,
				},
				{
					Value = 1,
					Num = 1502,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 1,
				},
				{
					Value = 1,
					Num = 6502,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 1,
				},
				{
					Value = 1,
					Num = 6502,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 114,
				},
				{
					Value = 320051,
					Num = 76,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 22,
				},
				{
					Value = 320052,
					Num = 16,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 4,
				},
				{
					Value = 320053,
					Num = 3,
				},
			},
		},
	},
	DemandID = 412442,
	DemandGroupList = {
		420010,
		420011,
		420012,
		420013,
		420014,
		420015,
	},
}
DemandConfig[DemandID.Id2443] =
{
	Id = 2443,
	Name = "订购米饭1",
	Desc = "需要一些米饭",
	Value = 321206,
	Active = true,
	Weight = 9880,
	PreGoal = 
	{
		300443,
		300499,
	},
	CloseGoal = 
	{
		300840,
	},
	GoodsId = 161206,
	Num = 39,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 22456,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 212,
				},
				{
					Value = 1,
					Num = 1256,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 212,
				},
				{
					Value = 1,
					Num = 1256,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 42,
				},
				{
					Value = 1,
					Num = 1456,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 42,
				},
				{
					Value = 1,
					Num = 1456,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 8,
				},
				{
					Value = 1,
					Num = 2456,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 8,
				},
				{
					Value = 1,
					Num = 2456,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 1,
				},
				{
					Value = 1,
					Num = 9956,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 1,
				},
				{
					Value = 1,
					Num = 9956,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 134,
				},
				{
					Value = 320051,
					Num = 90,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 26,
				},
				{
					Value = 320052,
					Num = 18,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 5,
				},
				{
					Value = 320053,
					Num = 3,
				},
			},
		},
	},
	DemandID = 412443,
	DemandGroupList = {
		420010,
		420011,
		420012,
		420013,
		420014,
		420015,
	},
}
DemandConfig[DemandID.Id2444] =
{
	Id = 2444,
	Name = "订购米饭1",
	Desc = "需要一些米饭",
	Value = 321206,
	Active = true,
	Weight = 12540,
	PreGoal = 
	{
		300443,
		300860,
	},
	CloseGoal = 
	{
		300904,
	},
	GoodsId = 191206,
	Num = 49,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 28215,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 266,
				},
				{
					Value = 1,
					Num = 1615,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 266,
				},
				{
					Value = 1,
					Num = 1615,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 53,
				},
				{
					Value = 1,
					Num = 1715,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 53,
				},
				{
					Value = 1,
					Num = 1715,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 10,
				},
				{
					Value = 1,
					Num = 3215,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 10,
				},
				{
					Value = 1,
					Num = 3215,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 2,
				},
				{
					Value = 1,
					Num = 3215,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 2,
				},
				{
					Value = 1,
					Num = 3215,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 169,
				},
				{
					Value = 320051,
					Num = 113,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 33,
				},
				{
					Value = 320052,
					Num = 23,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 6,
				},
				{
					Value = 320053,
					Num = 5,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 1,
				},
				{
					Value = 320054,
					Num = 1,
				},
			},
		},
	},
	DemandID = 412444,
	DemandGroupList = {
		420010,
		420011,
		420012,
		420013,
		420014,
		420015,
	},
}
DemandConfig[DemandID.Id2452] =
{
	Id = 2452,
	Name = "订购料酒1",
	Desc = "需要一些料酒",
	Value = 321207,
	Active = true,
	Weight = 9660,
	PreGoal = 
	{
		300458,
		300474,
	},
	CloseGoal = 
	{
		300810,
	},
	GoodsId = 131207,
	Num = 33,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 20207,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 171,
				},
				{
					Value = 1,
					Num = 3107,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 171,
				},
				{
					Value = 1,
					Num = 3107,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 34,
				},
				{
					Value = 1,
					Num = 3207,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 34,
				},
				{
					Value = 1,
					Num = 3207,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 6,
				},
				{
					Value = 1,
					Num = 5207,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 6,
				},
				{
					Value = 1,
					Num = 5207,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 1,
				},
				{
					Value = 1,
					Num = 7707,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 1,
				},
				{
					Value = 1,
					Num = 7707,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 121,
				},
				{
					Value = 320051,
					Num = 81,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 24,
				},
				{
					Value = 320052,
					Num = 16,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 4,
				},
				{
					Value = 320053,
					Num = 4,
				},
			},
		},
	},
	DemandID = 412452,
	DemandGroupList = {
		420010,
		420011,
		420012,
		420013,
		420014,
		420015,
	},
}
DemandConfig[DemandID.Id2453] =
{
	Id = 2453,
	Name = "订购料酒1",
	Desc = "需要一些料酒",
	Value = 321207,
	Active = true,
	Weight = 11760,
	PreGoal = 
	{
		300458,
		300819,
	},
	CloseGoal = 
	{
		300856,
	},
	GoodsId = 161207,
	Num = 42,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 25719,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 218,
				},
				{
					Value = 1,
					Num = 3919,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 218,
				},
				{
					Value = 1,
					Num = 3919,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 43,
				},
				{
					Value = 1,
					Num = 4219,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 43,
				},
				{
					Value = 1,
					Num = 4219,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 8,
				},
				{
					Value = 1,
					Num = 5719,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 8,
				},
				{
					Value = 1,
					Num = 5719,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 1,
				},
				{
					Value = 1,
					Num = 13219,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 1,
				},
				{
					Value = 1,
					Num = 13219,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 154,
				},
				{
					Value = 320051,
					Num = 103,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 30,
				},
				{
					Value = 320052,
					Num = 21,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 6,
				},
				{
					Value = 320053,
					Num = 4,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 1,
				},
				{
					Value = 320054,
					Num = 1,
				},
			},
		},
	},
	DemandID = 412453,
	DemandGroupList = {
		420010,
		420011,
		420012,
		420013,
		420014,
		420015,
	},
}
DemandConfig[DemandID.Id2454] =
{
	Id = 2454,
	Name = "订购料酒1",
	Desc = "需要一些料酒",
	Value = 321207,
	Active = true,
	Weight = 14700,
	PreGoal = 
	{
		300458,
		300876,
	},
	CloseGoal = 
	{
		301224,
	},
	GoodsId = 191207,
	Num = 52,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 31842,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 270,
				},
				{
					Value = 1,
					Num = 4842,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 270,
				},
				{
					Value = 1,
					Num = 4842,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 54,
				},
				{
					Value = 1,
					Num = 4842,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 54,
				},
				{
					Value = 1,
					Num = 4842,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 10,
				},
				{
					Value = 1,
					Num = 6842,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 10,
				},
				{
					Value = 1,
					Num = 6842,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 2,
				},
				{
					Value = 1,
					Num = 6842,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 2,
				},
				{
					Value = 1,
					Num = 6842,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 191,
				},
				{
					Value = 320051,
					Num = 127,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 38,
				},
				{
					Value = 320052,
					Num = 25,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 7,
				},
				{
					Value = 320053,
					Num = 5,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 1,
				},
				{
					Value = 320054,
					Num = 1,
				},
			},
		},
	},
	DemandID = 412454,
	DemandGroupList = {
		420010,
		420011,
		420012,
		420013,
		420014,
		420015,
	},
}
DemandConfig[DemandID.Id2462] =
{
	Id = 2462,
	Name = "订购海苔1",
	Desc = "需要一些海苔",
	Value = 321208,
	Active = true,
	Weight = 11025,
	PreGoal = 
	{
		300470,
		300486,
	},
	CloseGoal = 
	{
		300823,
	},
	GoodsId = 131208,
	Num = 33,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 22998,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 183,
				},
				{
					Value = 1,
					Num = 4698,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 197,
				},
				{
					Value = 1,
					Num = 3298,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 36,
				},
				{
					Value = 1,
					Num = 4998,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 39,
				},
				{
					Value = 1,
					Num = 3498,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 7,
				},
				{
					Value = 1,
					Num = 5498,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 7,
				},
				{
					Value = 1,
					Num = 5498,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 1,
				},
				{
					Value = 1,
					Num = 10498,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 1,
				},
				{
					Value = 1,
					Num = 10498,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 110,
				},
				{
					Value = 320051,
					Num = 119,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 22,
				},
				{
					Value = 320052,
					Num = 23,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 4,
				},
				{
					Value = 320053,
					Num = 5,
				},
			},
		},
	},
	DemandID = 412462,
	DemandGroupList = {
		420010,
		420011,
		420012,
		420013,
		420014,
		420015,
	},
}
DemandConfig[DemandID.Id2463] =
{
	Id = 2463,
	Name = "订购海苔1",
	Desc = "需要一些海苔",
	Value = 321208,
	Active = true,
	Weight = 13275,
	PreGoal = 
	{
		300470,
		300832,
	},
	CloseGoal = 
	{
		300868,
	},
	GoodsId = 161208,
	Num = 40,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 27876,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 223,
				},
				{
					Value = 1,
					Num = 5576,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 238,
				},
				{
					Value = 1,
					Num = 4076,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 44,
				},
				{
					Value = 1,
					Num = 5876,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 47,
				},
				{
					Value = 1,
					Num = 4376,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 8,
				},
				{
					Value = 1,
					Num = 7876,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 9,
				},
				{
					Value = 1,
					Num = 5376,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 1,
				},
				{
					Value = 1,
					Num = 15376,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 1,
				},
				{
					Value = 1,
					Num = 15376,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 133,
				},
				{
					Value = 320051,
					Num = 145,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 26,
				},
				{
					Value = 320052,
					Num = 29,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 5,
				},
				{
					Value = 320053,
					Num = 6,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 1,
				},
				{
					Value = 320054,
					Num = 1,
				},
			},
		},
	},
	DemandID = 412463,
	DemandGroupList = {
		420010,
		420011,
		420012,
		420013,
		420014,
		420015,
	},
}
DemandConfig[DemandID.Id2464] =
{
	Id = 2464,
	Name = "订购海苔1",
	Desc = "需要一些海苔",
	Value = 321208,
	Active = true,
	Weight = 16425,
	PreGoal = 
	{
		300470,
		300888,
	},
	CloseGoal = 
	{
		301236,
	},
	GoodsId = 191208,
	Num = 52,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 36239,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 289,
				},
				{
					Value = 1,
					Num = 7339,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 310,
				},
				{
					Value = 1,
					Num = 5239,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 57,
				},
				{
					Value = 1,
					Num = 7739,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 62,
				},
				{
					Value = 1,
					Num = 5239,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 11,
				},
				{
					Value = 1,
					Num = 8739,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 12,
				},
				{
					Value = 1,
					Num = 6239,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 2,
				},
				{
					Value = 1,
					Num = 11239,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 2,
				},
				{
					Value = 1,
					Num = 11239,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 173,
				},
				{
					Value = 320051,
					Num = 189,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 34,
				},
				{
					Value = 320052,
					Num = 38,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 6,
				},
				{
					Value = 320053,
					Num = 8,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 1,
				},
				{
					Value = 320054,
					Num = 1,
				},
			},
		},
	},
	DemandID = 412464,
	DemandGroupList = {
		420010,
		420011,
		420012,
		420013,
		420014,
		420015,
	},
}
DemandConfig[DemandID.Id2472] =
{
	Id = 2472,
	Name = "订购五花肉1",
	Desc = "需要一些五花肉",
	Value = 321209,
	Active = true,
	Weight = 13500,
	PreGoal = 
	{
		300490,
		300810,
	},
	CloseGoal = 
	{
		300844,
	},
	GoodsId = 131209,
	Num = 36,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 28123,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 239,
				},
				{
					Value = 1,
					Num = 4223,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 239,
				},
				{
					Value = 1,
					Num = 4223,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 47,
				},
				{
					Value = 1,
					Num = 4623,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 47,
				},
				{
					Value = 1,
					Num = 4623,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 9,
				},
				{
					Value = 1,
					Num = 5623,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 9,
				},
				{
					Value = 1,
					Num = 5623,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 1,
				},
				{
					Value = 1,
					Num = 15623,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 1,
				},
				{
					Value = 1,
					Num = 15623,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 168,
				},
				{
					Value = 320051,
					Num = 113,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 33,
				},
				{
					Value = 320052,
					Num = 23,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 6,
				},
				{
					Value = 320053,
					Num = 5,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 1,
				},
				{
					Value = 320054,
					Num = 1,
				},
			},
		},
	},
	DemandID = 412472,
	DemandGroupList = {
		420010,
		420011,
		420012,
		420013,
		420014,
		420015,
	},
}
DemandConfig[DemandID.Id2473] =
{
	Id = 2473,
	Name = "订购五花肉1",
	Desc = "需要一些五花肉",
	Value = 321209,
	Active = true,
	Weight = 16000,
	PreGoal = 
	{
		300490,
		300852,
	},
	CloseGoal = 
	{
		300888,
	},
	GoodsId = 161209,
	Num = 42,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 32810,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 278,
				},
				{
					Value = 1,
					Num = 5010,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 278,
				},
				{
					Value = 1,
					Num = 5010,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 55,
				},
				{
					Value = 1,
					Num = 5310,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 55,
				},
				{
					Value = 1,
					Num = 5310,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 11,
				},
				{
					Value = 1,
					Num = 5310,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 11,
				},
				{
					Value = 1,
					Num = 5310,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 2,
				},
				{
					Value = 1,
					Num = 7810,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 2,
				},
				{
					Value = 1,
					Num = 7810,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 196,
				},
				{
					Value = 320051,
					Num = 132,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 39,
				},
				{
					Value = 320052,
					Num = 26,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 7,
				},
				{
					Value = 320053,
					Num = 6,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 1,
				},
				{
					Value = 320054,
					Num = 1,
				},
			},
		},
	},
	DemandID = 412473,
	DemandGroupList = {
		420010,
		420011,
		420012,
		420013,
		420014,
		420015,
	},
}
DemandConfig[DemandID.Id2474] =
{
	Id = 2474,
	Name = "订购五花肉1",
	Desc = "需要一些五花肉",
	Value = 321209,
	Active = true,
	Weight = 19500,
	PreGoal = 
	{
		300490,
		301204,
	},
	CloseGoal = 
	{
		301256,
	},
	GoodsId = 191209,
	Num = 54,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 42184,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 358,
				},
				{
					Value = 1,
					Num = 6384,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 358,
				},
				{
					Value = 1,
					Num = 6384,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 71,
				},
				{
					Value = 1,
					Num = 6684,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 71,
				},
				{
					Value = 1,
					Num = 6684,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 14,
				},
				{
					Value = 1,
					Num = 7184,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 14,
				},
				{
					Value = 1,
					Num = 7184,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 2,
				},
				{
					Value = 1,
					Num = 17184,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 2,
				},
				{
					Value = 1,
					Num = 17184,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 253,
				},
				{
					Value = 320051,
					Num = 168,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 50,
				},
				{
					Value = 320052,
					Num = 34,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 10,
				},
				{
					Value = 320053,
					Num = 6,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 2,
				},
				{
					Value = 320054,
					Num = 1,
				},
			},
		},
	},
	DemandID = 412474,
	DemandGroupList = {
		420010,
		420011,
		420012,
		420013,
		420014,
		420015,
	},
}
DemandConfig[DemandID.Id2482] =
{
	Id = 2482,
	Name = "订购芝士1",
	Desc = "需要一些芝士",
	Value = 321210,
	Active = true,
	Weight = 14025,
	PreGoal = 
	{
		300735,
		300814,
	},
	CloseGoal = 
	{
		300848,
	},
	GoodsId = 131210,
	Num = 31,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 32142,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 273,
				},
				{
					Value = 1,
					Num = 4842,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 273,
				},
				{
					Value = 1,
					Num = 4842,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 54,
				},
				{
					Value = 1,
					Num = 5142,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 54,
				},
				{
					Value = 1,
					Num = 5142,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 10,
				},
				{
					Value = 1,
					Num = 7142,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 10,
				},
				{
					Value = 1,
					Num = 7142,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 2,
				},
				{
					Value = 1,
					Num = 7142,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 2,
				},
				{
					Value = 1,
					Num = 7142,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 192,
				},
				{
					Value = 320051,
					Num = 129,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 38,
				},
				{
					Value = 320052,
					Num = 26,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 7,
				},
				{
					Value = 320053,
					Num = 5,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 1,
				},
				{
					Value = 320054,
					Num = 1,
				},
			},
		},
	},
	DemandID = 412482,
	DemandGroupList = {
		420010,
		420011,
		420012,
		420013,
		420014,
		420015,
	},
}
DemandConfig[DemandID.Id2483] =
{
	Id = 2483,
	Name = "订购芝士1",
	Desc = "需要一些芝士",
	Value = 321210,
	Active = true,
	Weight = 16575,
	PreGoal = 
	{
		300735,
		300856,
	},
	CloseGoal = 
	{
		300892,
	},
	GoodsId = 161210,
	Num = 36,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 37326,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 317,
				},
				{
					Value = 1,
					Num = 5626,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 317,
				},
				{
					Value = 1,
					Num = 5626,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 63,
				},
				{
					Value = 1,
					Num = 5826,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 63,
				},
				{
					Value = 1,
					Num = 5826,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 12,
				},
				{
					Value = 1,
					Num = 7326,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 12,
				},
				{
					Value = 1,
					Num = 7326,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 2,
				},
				{
					Value = 1,
					Num = 12326,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 2,
				},
				{
					Value = 1,
					Num = 12326,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 223,
				},
				{
					Value = 320051,
					Num = 150,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 44,
				},
				{
					Value = 320052,
					Num = 30,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 8,
				},
				{
					Value = 320053,
					Num = 6,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 1,
				},
				{
					Value = 320054,
					Num = 1,
				},
			},
		},
	},
	DemandID = 412483,
	DemandGroupList = {
		420010,
		420011,
		420012,
		420013,
		420014,
		420015,
	},
}
DemandConfig[DemandID.Id2484] =
{
	Id = 2484,
	Name = "订购芝士1",
	Desc = "需要一些芝士",
	Value = 321210,
	Active = true,
	Weight = 20145,
	PreGoal = 
	{
		300735,
		301216,
	},
	CloseGoal = 
	{
		301260,
	},
	GoodsId = 191210,
	Num = 45,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 46657,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 396,
				},
				{
					Value = 1,
					Num = 7057,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 396,
				},
				{
					Value = 1,
					Num = 7057,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 79,
				},
				{
					Value = 1,
					Num = 7157,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 79,
				},
				{
					Value = 1,
					Num = 7157,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 15,
				},
				{
					Value = 1,
					Num = 9157,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 15,
				},
				{
					Value = 1,
					Num = 9157,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 3,
				},
				{
					Value = 1,
					Num = 9157,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 3,
				},
				{
					Value = 1,
					Num = 9157,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 279,
				},
				{
					Value = 320051,
					Num = 187,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 55,
				},
				{
					Value = 320052,
					Num = 38,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 11,
				},
				{
					Value = 320053,
					Num = 7,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 2,
				},
				{
					Value = 320054,
					Num = 1,
				},
			},
		},
	},
	DemandID = 412484,
	DemandGroupList = {
		420010,
		420011,
		420012,
		420013,
		420014,
		420015,
	},
}
DemandConfig[DemandID.Id2492] =
{
	Id = 2492,
	Name = "订购红豆冰1",
	Desc = "需要一些红豆冰",
	Value = 321251,
	Active = true,
	Weight = 3060,
	PreGoal = 
	{
		300740,
		300428,
	},
	CloseGoal = 
	{
		300458,
	},
	GoodsId = 131251,
	Num = 9,
	RewardList = {
		{
			Weight = 0,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 30315,
				},
			},
		},
		{
			Weight = 80,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320001,
					Num = 3,
				},
				{
					Value = 1,
					Num = 4395,
				},
			},
		},
		{
			Weight = 60,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320002,
					Num = 1,
				},
				{
					Value = 1,
					Num = 4395,
				},
			},
		},
	},
	DemandID = 412492,
	DemandGroupList = {
		420010,
		420011,
		420012,
		420013,
		420014,
		420015,
	},
}
DemandConfig[DemandID.Id2493] =
{
	Id = 2493,
	Name = "订购红豆冰1",
	Desc = "需要一些红豆冰",
	Value = 321251,
	Active = true,
	Weight = 3960,
	PreGoal = 
	{
		300740,
		300466,
	},
	CloseGoal = 
	{
		300804,
	},
	GoodsId = 161251,
	Num = 9,
	RewardList = {
		{
			Weight = 0,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 30315,
				},
			},
		},
		{
			Weight = 80,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320001,
					Num = 3,
				},
				{
					Value = 1,
					Num = 4395,
				},
			},
		},
		{
			Weight = 60,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320002,
					Num = 1,
				},
				{
					Value = 1,
					Num = 4395,
				},
			},
		},
	},
	DemandID = 412493,
	DemandGroupList = {
		420010,
		420011,
		420012,
		420013,
		420014,
		420015,
	},
}
DemandConfig[DemandID.Id2494] =
{
	Id = 2494,
	Name = "订购红豆冰1",
	Desc = "需要一些红豆冰",
	Value = 321251,
	Active = true,
	Weight = 5220,
	PreGoal = 
	{
		300740,
		300827,
	},
	CloseGoal = 
	{
		300872,
	},
	GoodsId = 191251,
	Num = 13,
	RewardList = {
		{
			Weight = 0,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 43789,
				},
			},
		},
		{
			Weight = 80,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320001,
					Num = 4,
				},
				{
					Value = 1,
					Num = 9229,
				},
			},
		},
		{
			Weight = 60,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320002,
					Num = 1,
				},
				{
					Value = 1,
					Num = 17869,
				},
			},
		},
	},
	DemandID = 412494,
	DemandGroupList = {
		420010,
		420011,
		420012,
		420013,
		420014,
		420015,
	},
}
DemandConfig[DemandID.Id2502] =
{
	Id = 2502,
	Name = "订购蛋糕1",
	Desc = "需要一些蛋糕",
	Value = 321252,
	Active = true,
	Weight = 3663,
	PreGoal = 
	{
		300741,
		300439,
	},
	CloseGoal = 
	{
		300470,
	},
	GoodsId = 131252,
	Num = 9,
	RewardList = {
		{
			Weight = 0,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 36269,
				},
			},
		},
		{
			Weight = 80,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320001,
					Num = 3,
				},
				{
					Value = 1,
					Num = 10349,
				},
			},
		},
		{
			Weight = 60,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320002,
					Num = 1,
				},
				{
					Value = 1,
					Num = 10349,
				},
			},
		},
	},
	DemandID = 412502,
	DemandGroupList = {
		420010,
		420011,
		420012,
		420013,
		420014,
		420015,
	},
}
DemandConfig[DemandID.Id2503] =
{
	Id = 2503,
	Name = "订购蛋糕1",
	Desc = "需要一些蛋糕",
	Value = 321252,
	Active = true,
	Weight = 4653,
	PreGoal = 
	{
		300741,
		300478,
	},
	CloseGoal = 
	{
		300819,
	},
	GoodsId = 161252,
	Num = 9,
	RewardList = {
		{
			Weight = 0,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 36269,
				},
			},
		},
		{
			Weight = 80,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320001,
					Num = 3,
				},
				{
					Value = 1,
					Num = 10349,
				},
			},
		},
		{
			Weight = 60,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320002,
					Num = 1,
				},
				{
					Value = 1,
					Num = 10349,
				},
			},
		},
	},
	DemandID = 412503,
	DemandGroupList = {
		420010,
		420011,
		420012,
		420013,
		420014,
		420015,
	},
}
DemandConfig[DemandID.Id2504] =
{
	Id = 2504,
	Name = "订购蛋糕1",
	Desc = "需要一些蛋糕",
	Value = 321252,
	Active = true,
	Weight = 6039,
	PreGoal = 
	{
		300741,
		300840,
	},
	CloseGoal = 
	{
		300884,
	},
	GoodsId = 191252,
	Num = 13,
	RewardList = {
		{
			Weight = 0,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 52388,
				},
			},
		},
		{
			Weight = 80,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320001,
					Num = 5,
				},
				{
					Value = 1,
					Num = 9188,
				},
			},
		},
		{
			Weight = 60,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320002,
					Num = 1,
				},
				{
					Value = 1,
					Num = 26468,
				},
			},
		},
	},
	DemandID = 412504,
	DemandGroupList = {
		420010,
		420011,
		420012,
		420013,
		420014,
		420015,
	},
}
DemandConfig[DemandID.Id2512] =
{
	Id = 2512,
	Name = "订购米醋1",
	Desc = "需要一些米醋",
	Value = 321253,
	Active = true,
	Weight = 5796,
	PreGoal = 
	{
		300742,
		300474,
	},
	CloseGoal = 
	{
		300810,
	},
	GoodsId = 131253,
	Num = 9,
	RewardList = {
		{
			Weight = 0,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 47956,
				},
			},
		},
		{
			Weight = 80,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320001,
					Num = 5,
				},
				{
					Value = 1,
					Num = 4756,
				},
			},
		},
		{
			Weight = 60,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320002,
					Num = 1,
				},
				{
					Value = 1,
					Num = 22036,
				},
			},
		},
	},
	DemandID = 412512,
	DemandGroupList = {
		420010,
		420011,
		420012,
		420013,
		420014,
		420015,
	},
}
DemandConfig[DemandID.Id2513] =
{
	Id = 2513,
	Name = "订购米醋1",
	Desc = "需要一些米醋",
	Value = 321253,
	Active = true,
	Weight = 7056,
	PreGoal = 
	{
		300742,
		300819,
	},
	CloseGoal = 
	{
		300856,
	},
	GoodsId = 161253,
	Num = 12,
	RewardList = {
		{
			Weight = 0,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 63942,
				},
			},
		},
		{
			Weight = 80,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320001,
					Num = 6,
				},
				{
					Value = 1,
					Num = 12102,
				},
			},
		},
		{
			Weight = 60,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320002,
					Num = 2,
				},
				{
					Value = 1,
					Num = 12102,
				},
			},
		},
	},
	DemandID = 412513,
	DemandGroupList = {
		420010,
		420011,
		420012,
		420013,
		420014,
		420015,
	},
}
DemandConfig[DemandID.Id2514] =
{
	Id = 2514,
	Name = "订购米醋1",
	Desc = "需要一些米醋",
	Value = 321253,
	Active = true,
	Weight = 8820,
	PreGoal = 
	{
		300742,
		300876,
	},
	CloseGoal = 
	{
		301224,
	},
	GoodsId = 191253,
	Num = 15,
	RewardList = {
		{
			Weight = 0,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 79928,
				},
			},
		},
		{
			Weight = 80,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320001,
					Num = 8,
				},
				{
					Value = 1,
					Num = 10808,
				},
			},
		},
		{
			Weight = 60,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320002,
					Num = 2,
				},
				{
					Value = 1,
					Num = 28088,
				},
			},
		},
	},
	DemandID = 412514,
	DemandGroupList = {
		420010,
		420011,
		420012,
		420013,
		420014,
		420015,
	},
}
DemandConfig[DemandID.Id2522] =
{
	Id = 2522,
	Name = "订购海鲜酱1",
	Desc = "需要一些海鲜酱",
	Value = 321254,
	Active = true,
	Weight = 6615,
	PreGoal = 
	{
		300743,
		300486,
	},
	CloseGoal = 
	{
		300823,
	},
	GoodsId = 131254,
	Num = 9,
	RewardList = {
		{
			Weight = 0,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 59427,
				},
			},
		},
		{
			Weight = 80,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320001,
					Num = 6,
				},
				{
					Value = 1,
					Num = 7587,
				},
			},
		},
		{
			Weight = 60,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320002,
					Num = 2,
				},
				{
					Value = 1,
					Num = 7587,
				},
			},
		},
	},
	DemandID = 412522,
	DemandGroupList = {
		420010,
		420011,
		420012,
		420013,
		420014,
		420015,
	},
}
DemandConfig[DemandID.Id2523] =
{
	Id = 2523,
	Name = "订购海鲜酱1",
	Desc = "需要一些海鲜酱",
	Value = 321254,
	Active = true,
	Weight = 7965,
	PreGoal = 
	{
		300743,
		300832,
	},
	CloseGoal = 
	{
		300868,
	},
	GoodsId = 161254,
	Num = 9,
	RewardList = {
		{
			Weight = 0,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 59427,
				},
			},
		},
		{
			Weight = 80,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320001,
					Num = 6,
				},
				{
					Value = 1,
					Num = 7587,
				},
			},
		},
		{
			Weight = 60,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320002,
					Num = 2,
				},
				{
					Value = 1,
					Num = 7587,
				},
			},
		},
	},
	DemandID = 412523,
	DemandGroupList = {
		420010,
		420011,
		420012,
		420013,
		420014,
		420015,
	},
}
DemandConfig[DemandID.Id2524] =
{
	Id = 2524,
	Name = "订购海鲜酱1",
	Desc = "需要一些海鲜酱",
	Value = 321254,
	Active = true,
	Weight = 9855,
	PreGoal = 
	{
		300743,
		300888,
	},
	CloseGoal = 
	{
		301236,
	},
	GoodsId = 191254,
	Num = 13,
	RewardList = {
		{
			Weight = 0,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 85840,
				},
			},
		},
		{
			Weight = 80,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320001,
					Num = 9,
				},
				{
					Value = 1,
					Num = 8080,
				},
			},
		},
		{
			Weight = 60,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320002,
					Num = 3,
				},
				{
					Value = 1,
					Num = 8080,
				},
			},
		},
	},
	DemandID = 412524,
	DemandGroupList = {
		420010,
		420011,
		420012,
		420013,
		420014,
		420015,
	},
}
DemandConfig[DemandID.Id2532] =
{
	Id = 2532,
	Name = "订购入场券1",
	Desc = "需要一些入场券",
	Value = 321401,
	Active = true,
	Weight = 15105,
	PreGoal = 
	{
		300807,
		300823,
	},
	CloseGoal = 
	{
		300856,
	},
	GoodsId = 131401,
	Num = 37,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 29111,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 247,
				},
				{
					Value = 1,
					Num = 4411,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 247,
				},
				{
					Value = 1,
					Num = 4411,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 49,
				},
				{
					Value = 1,
					Num = 4611,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 49,
				},
				{
					Value = 1,
					Num = 4611,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 9,
				},
				{
					Value = 1,
					Num = 6611,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 9,
				},
				{
					Value = 1,
					Num = 6611,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 1,
				},
				{
					Value = 1,
					Num = 16611,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 1,
				},
				{
					Value = 1,
					Num = 16611,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 174,
				},
				{
					Value = 320051,
					Num = 117,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 34,
				},
				{
					Value = 320052,
					Num = 24,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 6,
				},
				{
					Value = 320053,
					Num = 5,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 1,
				},
				{
					Value = 320054,
					Num = 1,
				},
			},
		},
	},
	DemandID = 412532,
	DemandGroupList = {
		420010,
		420011,
		420012,
		420013,
		420014,
		420015,
	},
}
DemandConfig[DemandID.Id2533] =
{
	Id = 2533,
	Name = "订购入场券1",
	Desc = "需要一些入场券",
	Value = 321401,
	Active = true,
	Weight = 17755,
	PreGoal = 
	{
		300807,
		300864,
	},
	CloseGoal = 
	{
		300900,
	},
	GoodsId = 161401,
	Num = 45,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 35406,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 300,
				},
				{
					Value = 1,
					Num = 5406,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 300,
				},
				{
					Value = 1,
					Num = 5406,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 60,
				},
				{
					Value = 1,
					Num = 5406,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 60,
				},
				{
					Value = 1,
					Num = 5406,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 12,
				},
				{
					Value = 1,
					Num = 5406,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 12,
				},
				{
					Value = 1,
					Num = 5406,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 2,
				},
				{
					Value = 1,
					Num = 10406,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 2,
				},
				{
					Value = 1,
					Num = 10406,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 212,
				},
				{
					Value = 320051,
					Num = 142,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 42,
				},
				{
					Value = 320052,
					Num = 28,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 8,
				},
				{
					Value = 320053,
					Num = 6,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 1,
				},
				{
					Value = 320054,
					Num = 1,
				},
			},
		},
	},
	DemandID = 412533,
	DemandGroupList = {
		420010,
		420011,
		420012,
		420013,
		420014,
		420015,
	},
}
DemandConfig[DemandID.Id2534] =
{
	Id = 2534,
	Name = "订购入场券1",
	Desc = "需要一些入场券",
	Value = 321401,
	Active = true,
	Weight = 21465,
	PreGoal = 
	{
		300807,
		301224,
	},
	CloseGoal = 
	{
		301268,
	},
	GoodsId = 191401,
	Num = 57,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 44847,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 381,
				},
				{
					Value = 1,
					Num = 6747,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 381,
				},
				{
					Value = 1,
					Num = 6747,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 76,
				},
				{
					Value = 1,
					Num = 6847,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 76,
				},
				{
					Value = 1,
					Num = 6847,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 15,
				},
				{
					Value = 1,
					Num = 7347,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 15,
				},
				{
					Value = 1,
					Num = 7347,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 3,
				},
				{
					Value = 1,
					Num = 7347,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 3,
				},
				{
					Value = 1,
					Num = 7347,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 269,
				},
				{
					Value = 320051,
					Num = 179,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 53,
				},
				{
					Value = 320052,
					Num = 36,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 10,
				},
				{
					Value = 320053,
					Num = 7,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 2,
				},
				{
					Value = 320054,
					Num = 1,
				},
			},
		},
	},
	DemandID = 412534,
	DemandGroupList = {
		420010,
		420011,
		420012,
		420013,
		420014,
		420015,
	},
}
DemandConfig[DemandID.Id2542] =
{
	Id = 2542,
	Name = "订购考古刷1",
	Desc = "需要一些考古刷",
	Value = 321402,
	Active = true,
	Weight = 16800,
	PreGoal = 
	{
		300819,
		300836,
	},
	CloseGoal = 
	{
		300868,
	},
	GoodsId = 131402,
	Num = 37,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 31654,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 298,
				},
				{
					Value = 1,
					Num = 1854,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 298,
				},
				{
					Value = 1,
					Num = 1854,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 59,
				},
				{
					Value = 1,
					Num = 2154,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 59,
				},
				{
					Value = 1,
					Num = 2154,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 11,
				},
				{
					Value = 1,
					Num = 4154,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 11,
				},
				{
					Value = 1,
					Num = 4154,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 2,
				},
				{
					Value = 1,
					Num = 6654,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 2,
				},
				{
					Value = 1,
					Num = 6654,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 189,
				},
				{
					Value = 320051,
					Num = 127,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 37,
				},
				{
					Value = 320052,
					Num = 26,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 7,
				},
				{
					Value = 320053,
					Num = 5,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 1,
				},
				{
					Value = 320054,
					Num = 1,
				},
			},
		},
	},
	DemandID = 412542,
	DemandGroupList = {
		420010,
		420011,
		420012,
		420013,
		420014,
		420015,
	},
}
DemandConfig[DemandID.Id2543] =
{
	Id = 2543,
	Name = "订购考古刷1",
	Desc = "需要一些考古刷",
	Value = 321402,
	Active = true,
	Weight = 19600,
	PreGoal = 
	{
		300819,
		300876,
	},
	CloseGoal = 
	{
		301216,
	},
	GoodsId = 161402,
	Num = 42,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 35932,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 339,
				},
				{
					Value = 1,
					Num = 2032,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 339,
				},
				{
					Value = 1,
					Num = 2032,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 67,
				},
				{
					Value = 1,
					Num = 2432,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 67,
				},
				{
					Value = 1,
					Num = 2432,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 13,
				},
				{
					Value = 1,
					Num = 3432,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 13,
				},
				{
					Value = 1,
					Num = 3432,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 2,
				},
				{
					Value = 1,
					Num = 10932,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 2,
				},
				{
					Value = 1,
					Num = 10932,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 215,
				},
				{
					Value = 320051,
					Num = 144,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 43,
				},
				{
					Value = 320052,
					Num = 28,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 8,
				},
				{
					Value = 320053,
					Num = 6,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 1,
				},
				{
					Value = 320054,
					Num = 1,
				},
			},
		},
	},
	DemandID = 412543,
	DemandGroupList = {
		420010,
		420011,
		420012,
		420013,
		420014,
		420015,
	},
}
DemandConfig[DemandID.Id2544] =
{
	Id = 2544,
	Name = "订购考古刷1",
	Desc = "需要一些考古刷",
	Value = 321402,
	Active = true,
	Weight = 23520,
	PreGoal = 
	{
		300819,
		301236,
	},
	CloseGoal = 
	{
		301280,
	},
	GoodsId = 191402,
	Num = 57,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 48765,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 460,
				},
				{
					Value = 1,
					Num = 2765,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 460,
				},
				{
					Value = 1,
					Num = 2765,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 92,
				},
				{
					Value = 1,
					Num = 2765,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 92,
				},
				{
					Value = 1,
					Num = 2765,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 18,
				},
				{
					Value = 1,
					Num = 3765,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 18,
				},
				{
					Value = 1,
					Num = 3765,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 3,
				},
				{
					Value = 1,
					Num = 11265,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 3,
				},
				{
					Value = 1,
					Num = 11265,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 292,
				},
				{
					Value = 320051,
					Num = 195,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 58,
				},
				{
					Value = 320052,
					Num = 39,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 11,
				},
				{
					Value = 320053,
					Num = 8,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 2,
				},
				{
					Value = 320054,
					Num = 1,
				},
			},
		},
	},
	DemandID = 412544,
	DemandGroupList = {
		420010,
		420011,
		420012,
		420013,
		420014,
		420015,
	},
}
DemandConfig[DemandID.Id2552] =
{
	Id = 2552,
	Name = "订购焚香1",
	Desc = "需要一些焚香",
	Value = 321403,
	Active = true,
	Weight = 18585,
	PreGoal = 
	{
		300832,
		300848,
	},
	CloseGoal = 
	{
		300880,
	},
	GoodsId = 131403,
	Num = 39,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 33767,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 287,
				},
				{
					Value = 1,
					Num = 5067,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 287,
				},
				{
					Value = 1,
					Num = 5067,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 57,
				},
				{
					Value = 1,
					Num = 5267,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 57,
				},
				{
					Value = 1,
					Num = 5267,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 11,
				},
				{
					Value = 1,
					Num = 6267,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 11,
				},
				{
					Value = 1,
					Num = 6267,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 2,
				},
				{
					Value = 1,
					Num = 8767,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 2,
				},
				{
					Value = 1,
					Num = 8767,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 202,
				},
				{
					Value = 320051,
					Num = 135,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 40,
				},
				{
					Value = 320052,
					Num = 27,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 8,
				},
				{
					Value = 320053,
					Num = 5,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 1,
				},
				{
					Value = 320054,
					Num = 1,
				},
			},
		},
	},
	DemandID = 412552,
	DemandGroupList = {
		420010,
		420011,
		420012,
		420013,
		420014,
		420015,
	},
}
DemandConfig[DemandID.Id2553] =
{
	Id = 2553,
	Name = "订购焚香1",
	Desc = "需要一些焚香",
	Value = 321403,
	Active = true,
	Weight = 21535,
	PreGoal = 
	{
		300832,
		300888,
	},
	CloseGoal = 
	{
		301228,
	},
	GoodsId = 161403,
	Num = 45,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 38962,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 331,
				},
				{
					Value = 1,
					Num = 5862,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 331,
				},
				{
					Value = 1,
					Num = 5862,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 66,
				},
				{
					Value = 1,
					Num = 5962,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 66,
				},
				{
					Value = 1,
					Num = 5962,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 13,
				},
				{
					Value = 1,
					Num = 6462,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 13,
				},
				{
					Value = 1,
					Num = 6462,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 2,
				},
				{
					Value = 1,
					Num = 13962,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 2,
				},
				{
					Value = 1,
					Num = 13962,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 233,
				},
				{
					Value = 320051,
					Num = 156,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 46,
				},
				{
					Value = 320052,
					Num = 31,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 9,
				},
				{
					Value = 320053,
					Num = 6,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 1,
				},
				{
					Value = 320054,
					Num = 2,
				},
			},
		},
	},
	DemandID = 412553,
	DemandGroupList = {
		420010,
		420011,
		420012,
		420013,
		420014,
		420015,
	},
}
DemandConfig[DemandID.Id2554] =
{
	Id = 2554,
	Name = "订购焚香1",
	Desc = "需要一些焚香",
	Value = 321403,
	Active = true,
	Weight = 25665,
	PreGoal = 
	{
		300832,
		301248,
	},
	CloseGoal = 
	{
		301292,
	},
	GoodsId = 191403,
	Num = 60,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 51949,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 441,
				},
				{
					Value = 1,
					Num = 7849,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 441,
				},
				{
					Value = 1,
					Num = 7849,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 88,
				},
				{
					Value = 1,
					Num = 7949,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 88,
				},
				{
					Value = 1,
					Num = 7949,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 17,
				},
				{
					Value = 1,
					Num = 9449,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 17,
				},
				{
					Value = 1,
					Num = 9449,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 3,
				},
				{
					Value = 1,
					Num = 14449,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 3,
				},
				{
					Value = 1,
					Num = 14449,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 311,
				},
				{
					Value = 320051,
					Num = 208,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 62,
				},
				{
					Value = 320052,
					Num = 41,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 12,
				},
				{
					Value = 320053,
					Num = 8,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 2,
				},
				{
					Value = 320054,
					Num = 2,
				},
			},
		},
	},
	DemandID = 412554,
	DemandGroupList = {
		420010,
		420011,
		420012,
		420013,
		420014,
		420015,
	},
}
DemandConfig[DemandID.Id2562] =
{
	Id = 2562,
	Name = "订购碎瓷片1",
	Desc = "需要一些碎瓷片",
	Value = 321404,
	Active = true,
	Weight = 19825,
	PreGoal = 
	{
		300840,
		300856,
	},
	CloseGoal = 
	{
		300888,
	},
	GoodsId = 131404,
	Num = 36,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 40279,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 342,
				},
				{
					Value = 1,
					Num = 6079,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 342,
				},
				{
					Value = 1,
					Num = 6079,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 68,
				},
				{
					Value = 1,
					Num = 6279,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 68,
				},
				{
					Value = 1,
					Num = 6279,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 13,
				},
				{
					Value = 1,
					Num = 7779,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 13,
				},
				{
					Value = 1,
					Num = 7779,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 2,
				},
				{
					Value = 1,
					Num = 15279,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 2,
				},
				{
					Value = 1,
					Num = 15279,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 241,
				},
				{
					Value = 320051,
					Num = 161,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 48,
				},
				{
					Value = 320052,
					Num = 32,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 9,
				},
				{
					Value = 320053,
					Num = 7,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 1,
				},
				{
					Value = 320054,
					Num = 2,
				},
			},
		},
	},
	DemandID = 412562,
	DemandGroupList = {
		420010,
		420011,
		420012,
		420013,
		420014,
		420015,
	},
}
DemandConfig[DemandID.Id2563] =
{
	Id = 2563,
	Name = "订购碎瓷片1",
	Desc = "需要一些碎瓷片",
	Value = 321404,
	Active = true,
	Weight = 22875,
	PreGoal = 
	{
		300840,
		300896,
	},
	CloseGoal = 
	{
		301236,
	},
	GoodsId = 161404,
	Num = 42,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 46992,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 399,
				},
				{
					Value = 1,
					Num = 7092,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 399,
				},
				{
					Value = 1,
					Num = 7092,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 79,
				},
				{
					Value = 1,
					Num = 7492,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 79,
				},
				{
					Value = 1,
					Num = 7492,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 15,
				},
				{
					Value = 1,
					Num = 9492,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 15,
				},
				{
					Value = 1,
					Num = 9492,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 3,
				},
				{
					Value = 1,
					Num = 9492,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 3,
				},
				{
					Value = 1,
					Num = 9492,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 281,
				},
				{
					Value = 320051,
					Num = 188,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 56,
				},
				{
					Value = 320052,
					Num = 37,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 11,
				},
				{
					Value = 320053,
					Num = 7,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 2,
				},
				{
					Value = 320054,
					Num = 1,
				},
			},
		},
	},
	DemandID = 412563,
	DemandGroupList = {
		420010,
		420011,
		420012,
		420013,
		420014,
		420015,
	},
}
DemandConfig[DemandID.Id2564] =
{
	Id = 2564,
	Name = "订购碎瓷片1",
	Desc = "需要一些碎瓷片",
	Value = 321404,
	Active = true,
	Weight = 27145,
	PreGoal = 
	{
		300840,
		301256,
	},
	CloseGoal = 
	{
		301301,
	},
	GoodsId = 191404,
	Num = 54,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 60419,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 513,
				},
				{
					Value = 1,
					Num = 9119,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 513,
				},
				{
					Value = 1,
					Num = 9119,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 102,
				},
				{
					Value = 1,
					Num = 9419,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 102,
				},
				{
					Value = 1,
					Num = 9419,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 20,
				},
				{
					Value = 1,
					Num = 10419,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 20,
				},
				{
					Value = 1,
					Num = 10419,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 4,
				},
				{
					Value = 1,
					Num = 10419,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 4,
				},
				{
					Value = 1,
					Num = 10419,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 362,
				},
				{
					Value = 320051,
					Num = 242,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 72,
				},
				{
					Value = 320052,
					Num = 48,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 14,
				},
				{
					Value = 320053,
					Num = 10,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 2,
				},
				{
					Value = 320054,
					Num = 2,
				},
			},
		},
	},
	DemandID = 412564,
	DemandGroupList = {
		420010,
		420011,
		420012,
		420013,
		420014,
		420015,
	},
}
DemandConfig[DemandID.Id2572] =
{
	Id = 2572,
	Name = "订购绿蛋壳1",
	Desc = "需要一些绿蛋壳",
	Value = 321405,
	Active = true,
	Weight = 20460,
	PreGoal = 
	{
		300844,
		300860,
	},
	CloseGoal = 
	{
		300892,
	},
	GoodsId = 131405,
	Num = 40,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 37884,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 357,
				},
				{
					Value = 1,
					Num = 2184,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 71,
				},
				{
					Value = 1,
					Num = 2384,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 14,
				},
				{
					Value = 1,
					Num = 2884,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 2,
				},
				{
					Value = 1,
					Num = 12884,
				},
			},
		},
	},
	DemandID = 412572,
	DemandGroupList = {
		420010,
		420011,
		420012,
		420013,
		420014,
		420015,
	},
}
DemandConfig[DemandID.Id2573] =
{
	Id = 2573,
	Name = "订购绿蛋壳1",
	Desc = "需要一些绿蛋壳",
	Value = 321405,
	Active = true,
	Weight = 23560,
	PreGoal = 
	{
		300844,
		300900,
	},
	CloseGoal = 
	{
		301240,
	},
	GoodsId = 161405,
	Num = 48,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 45460,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 429,
				},
				{
					Value = 1,
					Num = 2560,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 85,
				},
				{
					Value = 1,
					Num = 2960,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 17,
				},
				{
					Value = 1,
					Num = 2960,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 3,
				},
				{
					Value = 1,
					Num = 7960,
				},
			},
		},
	},
	DemandID = 412573,
	DemandGroupList = {
		420010,
		420011,
		420012,
		420013,
		420014,
		420015,
	},
}
DemandConfig[DemandID.Id2574] =
{
	Id = 2574,
	Name = "订购绿蛋壳1",
	Desc = "需要一些绿蛋壳",
	Value = 321405,
	Active = true,
	Weight = 27900,
	PreGoal = 
	{
		300844,
		301260,
	},
	CloseGoal = 
	{
		301306,
	},
	GoodsId = 191405,
	Num = 60,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 56826,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 536,
				},
				{
					Value = 1,
					Num = 3226,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 107,
				},
				{
					Value = 1,
					Num = 3326,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 21,
				},
				{
					Value = 1,
					Num = 4326,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 4,
				},
				{
					Value = 1,
					Num = 6826,
				},
			},
		},
	},
	DemandID = 412574,
	DemandGroupList = {
		420010,
		420011,
		420012,
		420013,
		420014,
		420015,
	},
}
DemandConfig[DemandID.Id2582] =
{
	Id = 2582,
	Name = "订购监控录像1",
	Desc = "需要一些监控录像",
	Value = 321406,
	Active = true,
	Weight = 21760,
	PreGoal = 
	{
		300852,
		300868,
	},
	CloseGoal = 
	{
		300900,
	},
	GoodsId = 131406,
	Num = 33,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 41321,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 351,
				},
				{
					Value = 1,
					Num = 6221,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 351,
				},
				{
					Value = 1,
					Num = 6221,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 70,
				},
				{
					Value = 1,
					Num = 6321,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 70,
				},
				{
					Value = 1,
					Num = 6321,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 14,
				},
				{
					Value = 1,
					Num = 6321,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 14,
				},
				{
					Value = 1,
					Num = 6321,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 2,
				},
				{
					Value = 1,
					Num = 16321,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 2,
				},
				{
					Value = 1,
					Num = 16321,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 247,
				},
				{
					Value = 320051,
					Num = 166,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 49,
				},
				{
					Value = 320052,
					Num = 33,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 9,
				},
				{
					Value = 320053,
					Num = 7,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 1,
				},
				{
					Value = 320054,
					Num = 2,
				},
			},
		},
	},
	DemandID = 412582,
	DemandGroupList = {
		420010,
		420011,
		420012,
		420013,
		420014,
		420015,
	},
}
DemandConfig[DemandID.Id2583] =
{
	Id = 2583,
	Name = "订购监控录像1",
	Desc = "需要一些监控录像",
	Value = 321406,
	Active = true,
	Weight = 24960,
	PreGoal = 
	{
		300852,
		301204,
	},
	CloseGoal = 
	{
		301248,
	},
	GoodsId = 161406,
	Num = 40,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 50086,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 425,
				},
				{
					Value = 1,
					Num = 7586,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 425,
				},
				{
					Value = 1,
					Num = 7586,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 85,
				},
				{
					Value = 1,
					Num = 7586,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 85,
				},
				{
					Value = 1,
					Num = 7586,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 17,
				},
				{
					Value = 1,
					Num = 7586,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 17,
				},
				{
					Value = 1,
					Num = 7586,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 3,
				},
				{
					Value = 1,
					Num = 12586,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 3,
				},
				{
					Value = 1,
					Num = 12586,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 300,
				},
				{
					Value = 320051,
					Num = 200,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 60,
				},
				{
					Value = 320052,
					Num = 40,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 12,
				},
				{
					Value = 320053,
					Num = 8,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 2,
				},
				{
					Value = 320054,
					Num = 2,
				},
			},
		},
	},
	DemandID = 412583,
	DemandGroupList = {
		420010,
		420011,
		420012,
		420013,
		420014,
		420015,
	},
}
DemandConfig[DemandID.Id2584] =
{
	Id = 2584,
	Name = "订购监控录像1",
	Desc = "需要一些监控录像",
	Value = 321406,
	Active = true,
	Weight = 29440,
	PreGoal = 
	{
		300852,
		301268,
	},
	CloseGoal = 
	{
		301314,
	},
	GoodsId = 191406,
	Num = 49,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 61355,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 521,
				},
				{
					Value = 1,
					Num = 9255,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 521,
				},
				{
					Value = 1,
					Num = 9255,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 104,
				},
				{
					Value = 1,
					Num = 9355,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 104,
				},
				{
					Value = 1,
					Num = 9355,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 20,
				},
				{
					Value = 1,
					Num = 11355,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 20,
				},
				{
					Value = 1,
					Num = 11355,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 4,
				},
				{
					Value = 1,
					Num = 11355,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 4,
				},
				{
					Value = 1,
					Num = 11355,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 368,
				},
				{
					Value = 320051,
					Num = 245,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 73,
				},
				{
					Value = 320052,
					Num = 49,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 14,
				},
				{
					Value = 320053,
					Num = 10,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 2,
				},
				{
					Value = 320054,
					Num = 2,
				},
			},
		},
	},
	DemandID = 412584,
	DemandGroupList = {
		420010,
		420011,
		420012,
		420013,
		420014,
		420015,
	},
}
DemandConfig[DemandID.Id2592] =
{
	Id = 2592,
	Name = "订购封条1",
	Desc = "需要一些封条",
	Value = 321407,
	Active = true,
	Weight = 23100,
	PreGoal = 
	{
		300860,
		300876,
	},
	CloseGoal = 
	{
		301204,
	},
	GoodsId = 131407,
	Num = 40,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 41151,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 388,
				},
				{
					Value = 1,
					Num = 2351,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 388,
				},
				{
					Value = 1,
					Num = 2351,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 77,
				},
				{
					Value = 1,
					Num = 2651,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 77,
				},
				{
					Value = 1,
					Num = 2651,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 15,
				},
				{
					Value = 1,
					Num = 3651,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 15,
				},
				{
					Value = 1,
					Num = 3651,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 3,
				},
				{
					Value = 1,
					Num = 3651,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 3,
				},
				{
					Value = 1,
					Num = 3651,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 246,
				},
				{
					Value = 320051,
					Num = 165,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 49,
				},
				{
					Value = 320052,
					Num = 33,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 9,
				},
				{
					Value = 320053,
					Num = 7,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 1,
				},
				{
					Value = 320054,
					Num = 2,
				},
			},
		},
	},
	DemandID = 412592,
	DemandGroupList = {
		420010,
		420011,
		420012,
		420013,
		420014,
		420015,
	},
}
DemandConfig[DemandID.Id2593] =
{
	Id = 2593,
	Name = "订购封条1",
	Desc = "需要一些封条",
	Value = 321407,
	Active = true,
	Weight = 26400,
	PreGoal = 
	{
		300860,
		301220,
	},
	CloseGoal = 
	{
		301256,
	},
	GoodsId = 161407,
	Num = 48,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 49381,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 466,
				},
				{
					Value = 1,
					Num = 2781,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 466,
				},
				{
					Value = 1,
					Num = 2781,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 93,
				},
				{
					Value = 1,
					Num = 2881,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 93,
				},
				{
					Value = 1,
					Num = 2881,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 18,
				},
				{
					Value = 1,
					Num = 4381,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 18,
				},
				{
					Value = 1,
					Num = 4381,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 3,
				},
				{
					Value = 1,
					Num = 11881,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 3,
				},
				{
					Value = 1,
					Num = 11881,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 296,
				},
				{
					Value = 320051,
					Num = 197,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 59,
				},
				{
					Value = 320052,
					Num = 39,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 11,
				},
				{
					Value = 320053,
					Num = 8,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 2,
				},
				{
					Value = 320054,
					Num = 1,
				},
			},
		},
	},
	DemandID = 412593,
	DemandGroupList = {
		420010,
		420011,
		420012,
		420013,
		420014,
		420015,
	},
}
