require "FreakPlanet/Design/MiscConfig"
EventConfig ={};
EventID = 
{
	Id001 = 310001,
	Id002 = 310002,
	Id003 = 310003,
	Id004 = 310004,
	Id005 = 310005,
	Id006 = 310006,
	Id007 = 310007,
	Id008 = 310008,
	Id009 = 310009,
	Id010 = 310010,
	Id011 = 310011,
	Id012 = 310012,
	Id013 = 310013,
	Id014 = 310014,
	Id015 = 310015,
	Id016 = 310016,
	Id017 = 310017,
	Id018 = 310018,
	Id019 = 310019,
	Id020 = 310020,
	Id021 = 310021,
	Id022 = 310022,
	Id023 = 310023,
	Id024 = 310024,
	Id025 = 310025,
	Id026 = 310026,
	Id027 = 310027,
	Id028 = 310028,
	Id029 = 310029,
	Id030 = 310030,
	Id031 = 310031,
	Id032 = 310032,
	Id033 = 310033,
	Id034 = 310034,
	Id035 = 310035,
	Id036 = 310036,
	Id037 = 310037,
	Id038 = 310038,
	Id039 = 310039,
	Id040 = 310040,
	Id041 = 310041,
	Id042 = 310042,
	Id043 = 310043,
	Id044 = 310044,
	Id045 = 310045,
	Id200 = 310200,
	Id201 = 310201,
	Id202 = 310202,
	Id203 = 310203,
	Id204 = 310204,
	Id205 = 310205,
	Id206 = 310206,
	Id207 = 310207,
	Id208 = 310208,
	Id209 = 310209,
	Id210 = 310210,
	Id211 = 310211,
	Id212 = 310212,
	Id213 = 310213,
	Id214 = 310214,
	Id215 = 310215,
	Id216 = 310216,
	Id217 = 310217,
	Id218 = 310218,
	Id219 = 310219,
	Id220 = 310220,
	Id221 = 310221,
	Id222 = 310222,
	Id223 = 310223,
	Id224 = 310224,
	Id225 = 310225,
	Id226 = 310226,
	Id227 = 310227,
	Id228 = 310228,
	Id229 = 310229,
	Id230 = 310230,
	Id231 = 310231,
	Id232 = 310232,
	Id233 = 310233,
	Id234 = 310234,
	Id235 = 310235,
	Id236 = 310236,
	Id237 = 310237,
	Id238 = 310238,
	Id239 = 310239,
	Id240 = 310240,
	Id241 = 310241,
	Id242 = 310242,
	Id243 = 310243,
	Id244 = 310244,
	Id245 = 310245,
	Id246 = 310246,
	Id247 = 310247,
	Id248 = 310248,
	Id401 = 310401,
	Id402 = 310402,
	Id403 = 310403,
	Id404 = 310404,
	Id405 = 310405,
	Id406 = 310406,
	Id407 = 310407,
	Id408 = 310408,
	Id409 = 310409,
	Id410 = 310410,
	Id411 = 310411,
	Id412 = 310412,
	Id413 = 310413,
	Id414 = 310414,
	Id415 = 310415,
	Id416 = 310416,
	Id417 = 310417,
	Id418 = 310418,
	Id419 = 310419,
	Id420 = 310420,
	Id421 = 310421,
	Id422 = 310422,
	Id423 = 310423,
	Id424 = 310424,
	Id425 = 310425,
	Id426 = 310426,
	Id427 = 310427,
	Id428 = 310428,
	Id429 = 310429,
	Id430 = 310430,
	Id431 = 310431,
	Id432 = 310432,
	Id433 = 310433,
	Id434 = 310434,
	Id435 = 310435,
	Id436 = 310436,
	Id437 = 310437,
	Id438 = 310438,
	Id439 = 310439,
	Id440 = 310440,
	Id441 = 310441,
	Id442 = 310442,
	Id443 = 310443,
	Id444 = 310444,
	Id445 = 310445,
	Id446 = 310446,
	Id447 = 310447,
	Id448 = 310448,
	Id449 = 310449,
	Id601 = 310601,
	Id602 = 310602,
	Id603 = 310603,
	Id604 = 310604,
	Id605 = 310605,
	Id606 = 310606,
	Id607 = 310607,
	Id608 = 310608,
	Id609 = 310609,
	Id610 = 310610,
	Id611 = 310611,
	Id612 = 310612,
	Id613 = 310613,
	Id614 = 310614,
	Id615 = 310615,
	Id616 = 310616,
	Id617 = 310617,
	Id618 = 310618,
	Id619 = 310619,
	Id620 = 310620,
	Id621 = 310621,
	Id622 = 310622,
	Id623 = 310623,
	Id624 = 310624,
	Id625 = 310625,
	Id626 = 310626,
	Id627 = 310627,
	Id628 = 310628,
	Id629 = 310629,
	Id630 = 310630,
	Id631 = 310631,
	Id632 = 310632,
	Id633 = 310633,
	Id634 = 310634,
	Id635 = 310635,
	Id636 = 310636,
	Id637 = 310637,
	Id638 = 310638,
	Id639 = 310639,
	Id640 = 310640,
	Id641 = 310641,
	Id642 = 310642,
	Id643 = 310643,
	Id644 = 310644,
	Id645 = 310645,
	Id646 = 310646,
	Id647 = 310647,
	Id648 = 310648,
	Id649 = 310649,
	Id650 = 310650,
	Id651 = 310651,
	Id652 = 310652,
	Id653 = 310653,
	Id654 = 310654,
	Id801 = 310801,
	Id802 = 310802,
	Id803 = 310803,
	Id804 = 310804,
	Id805 = 310805,
	Id806 = 310806,
	Id807 = 310807,
	Id808 = 310808,
	Id809 = 310809,
	Id810 = 310810,
	Id811 = 310811,
	Id812 = 310812,
	Id813 = 310813,
	Id814 = 310814,
	Id815 = 310815,
	Id816 = 310816,
	Id817 = 310817,
	Id818 = 310818,
	Id819 = 310819,
	Id820 = 310820,
	Id821 = 310821,
	Id822 = 310822,
	Id823 = 310823,
	Id824 = 310824,
	Id825 = 310825,
	Id826 = 310826,
	Id827 = 310827,
	Id828 = 310828,
	Id829 = 310829,
	Id830 = 310830,
	Id831 = 310831,
	Id832 = 310832,
	Id833 = 310833,
	Id834 = 310834,
	Id835 = 310835,
	Id836 = 310836,
	Id837 = 310837,
	Id838 = 310838,
	Id839 = 310839,
	Id840 = 310840,
	Id841 = 310841,
	Id842 = 310842,
	Id843 = 310843,
	Id844 = 310844,
	Id845 = 310845,
	Id846 = 310846,
	Id847 = 310847,
	Id848 = 310848,
	Id849 = 310849,
	Id850 = 310850,
	Id851 = 310851,
	Id852 = 310852,
	Id853 = 310853,
	Id854 = 310854,
	Id855 = 310855,
	Id856 = 310856,
	Id857 = 310857,
	Id858 = 310858,
	Id859 = 310859,
	Id860 = 310860,
	Id861 = 310861,
	Id862 = 310862,
	Id863 = 310863,
	Id864 = 310864,
}
EventConfig[EventID.Id001] =
{
	Id = 1,
	Name = "宁静的小镇",
	Gallery = 950001,
	Area = 130002,
	LockDesc = "解锁提示\n一次性探索初始城镇1.5分钟\n(需要呜呜、漆漆)",
	Desc = "喵~来到了冒险世界的城镇。闲逛时，自称村长的人向我们热情地介绍，说如果第一次来的话，要记得设置口令喵~",
	Bundle = "packed_event_rpg",
	Atlas = "Event_RPG",
	Icon = "RPG_Event_25",
	TriggerCondition = {
		NeedExploreTime = 90,
		ConditionList = {
			{
				Condition = "TeamCharacterIdAnd",
				Value = 
				{
					220001,
					220002,
				},
			},
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 10,
		},
	},
}
EventConfig[EventID.Id002] =
{
	Id = 2,
	Name = "很香的烤串",
	Gallery = 950001,
	Area = 130002,
	LockDesc = "解锁提示\n一次性探索初始城镇10分钟\n(需要呜呜、漆漆)",
	Desc = "好香的味道啊~是村里的烤串店呢~我们在铺子前看了10分钟噢。不过店主说只有完成冒险者的任务才能领取这个奖励喵，小猫咪不可以接这样的任务……",
	Bundle = "packed_event_rpg",
	Atlas = "Event_RPG",
	Icon = "RPG_Event_26",
	TriggerCondition = {
		NeedExploreTime = 600,
		ConditionList = {
			{
				Condition = "TeamCharacterIdAnd",
				Value = 
				{
					220001,
					220002,
				},
			},
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 5,
		},
	},
}
EventConfig[EventID.Id003] =
{
	Id = 3,
	Name = "沐浴中的仙子",
	Gallery = 950001,
	Area = 130003,
	LockDesc = "解锁提示\n一次性探索村口树林15分钟\n(需要德高望重的男性角色和血气方刚的男性角色)",
	Desc = "喵~村长说带大家去看厉害的东西。是美丽的森林仙子正在湖里洗澡~剑士让村长不要再看了，但是村长说结尾部分最精彩！啊，好像被发现了！！",
	Bundle = "packed_event_rpg",
	Atlas = "Event_RPG",
	Icon = "RPG_Event_27",
	TriggerCondition = {
		NeedExploreTime = 900,
		ConditionList = {
			{
				Condition = "TeamCharacterIdAnd",
				Value = 
				{
					220012,
					220003,
				},
			},
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
EventConfig[EventID.Id004] =
{
	Id = 4,
	Name = "发光蘑菇",
	Gallery = 950001,
	Area = 130003,
	LockDesc = "解锁提示\n一次性探索村口树林15分钟\n(需要裤腰带勒紧的角色)",
	Desc = "在树林深处发现了散发着微弱光芒的树洞。钻过去后发现了成群的发光蘑菇。听说是能给人带来好运气的菌类。",
	Bundle = "packed_event_rpg",
	Atlas = "Event_RPG",
	Icon = "RPG_Event_1",
	TriggerCondition = {
		NeedExploreTime = 900,
		ConditionList = {
			{
				Condition = "TeamCharacterIdAnd",
				Value = 
				{
					220011,
				},
			},
		},
	},
	Reward = {
		{
			Value = 320501,
			Num = 1,
		},
	},
}
EventConfig[EventID.Id005] =
{
	Id = 5,
	Name = "夜不归宿",
	Gallery = 950001,
	Area = 130004,
	LockDesc = "解锁提示\n一次性探索溪谷8小时",
	Desc = "打算回家时已经太晚了，大家一起捡树叶升起了篝火。静静躺在草地上看着星空，天上的月亮像呜呜的脸一样圆……",
	Bundle = "packed_event_rpg",
	Atlas = "Event_RPG",
	Icon = "RPG_Event_6",
	TriggerCondition = {
		NeedExploreTime = 28800,
	},
	Reward = {
		{
			Value = 321001,
			Num = 20,
		},
	},
}
EventConfig[EventID.Id006] =
{
	Id = 6,
	Name = "森林中的会议",
	Gallery = 950001,
	Area = 130004,
	LockDesc = "解锁提示\n一次性探索溪谷1小时",
	Desc = "今天去了森林西部，找到了史莱姆之家。跨过灌木丛时不小心发出了响声，正在开会的史莱姆们受惊后一哄而散，现场只留下了一个开会用的喇叭。",
	Bundle = "packed_event_rpg",
	Atlas = "Event_RPG",
	Icon = "RPG_Event_8",
	TriggerCondition = {
		NeedExploreTime = 3600,
	},
	Reward = {
		{
			Value = 320504,
			Num = 1,
		},
	},
}
EventConfig[EventID.Id007] =
{
	Id = 7,
	Name = "新出生的小鸟",
	Gallery = 950001,
	Area = 130004,
	LockDesc = "解锁提示\n一次性探索溪谷30分钟\n(需要呜呜、漆漆)",
	Desc = "在大树下发现了从窝里掉下来的雏鸟，爬上树将小鸟放回了窝，无意间发现了一枚古代金币。",
	Bundle = "packed_event_rpg",
	Atlas = "Event_RPG",
	Icon = "RPG_Event_7",
	TriggerCondition = {
		NeedExploreTime = 1800,
		ConditionList = {
			{
				Condition = "TeamCharacterIdAnd",
				Value = 
				{
					220001,
					220002,
				},
			},
		},
	},
	Reward = {
		{
			Value = 320502,
			Num = 1,
		},
	},
}
EventConfig[EventID.Id008] =
{
	Id = 8,
	Name = "珍贵药草",
	Gallery = 950001,
	Area = 130004,
	LockDesc = "解锁提示\n一次性探索溪谷20分钟\n(需要游行各地经商的角色)",
	Desc = "在悬崖边发现了罕见的药草，通过叠人梯的方式采到了。游行商人用特别的手法将药草做成了特大装的药水~",
	Bundle = "packed_event_rpg",
	Atlas = "Event_RPG",
	Icon = "RPG_Event_28",
	TriggerCondition = {
		NeedExploreTime = 1200,
		ConditionList = {
			{
				Condition = "TeamCharacterIdAnd",
				Value = 
				{
					220015,
				},
			},
		},
	},
	Reward = {
		{
			Value = 320404,
			Num = 5,
		},
	},
}
EventConfig[EventID.Id009] =
{
	Id = 9,
	Name = "外来的石头",
	Gallery = 950001,
	Area = 130005,
	LockDesc = "解锁提示\n一次性探索魔法平原3小时",
	Desc = "在河边吃饭时，远处有一道火光坠地。赶过去后发现是陨石。石怪们远远围观着，可能因为是外来的石头，所以它们不敢靠近。",
	Bundle = "packed_event_rpg",
	Atlas = "Event_RPG",
	Icon = "RPG_Event_4",
	TriggerCondition = {
		NeedExploreTime = 10800,
	},
	Reward = {
		{
			Value = 320506,
			Num = 1,
		},
	},
}
EventConfig[EventID.Id010] =
{
	Id = 10,
	Name = "大祭典",
	Gallery = 950001,
	Area = 130005,
	LockDesc = "解锁提示\n一次性探索魔法平原1小时\n(需要有看守经验的角色)",
	Desc = "村里打算举行盛大的仪式，不过大祭司的贴身护卫因为吃了彩色蘑菇在厕所里一直出不来。幸好城镇卫兵及时顶上，仪式才顺利举办了下去。所以，彩色的蘑菇不要乱吃噢！",
	Bundle = "packed_event_rpg",
	Atlas = "Event_RPG",
	Icon = "RPG_Event_29",
	TriggerCondition = {
		NeedExploreTime = 3600,
		ConditionList = {
			{
				Condition = "TeamCharacterIdAnd",
				Value = 
				{
					220014,
				},
			},
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 30,
		},
	},
}
EventConfig[EventID.Id011] =
{
	Id = 11,
	Name = "大庆典",
	Gallery = 950001,
	Area = 130005,
	LockDesc = "解锁提示\n一次性探索魔法平原30分钟",
	Desc = "受到当地居民的邀请，参加了盛大的祭祀典礼。庆典晚会结束后，还收到了一份伴手礼。",
	Bundle = "packed_event_rpg",
	Atlas = "Event_RPG",
	Icon = "RPG_Event_10",
	TriggerCondition = {
		NeedExploreTime = 1800,
	},
	Reward = {
		{
			Value = 320505,
			Num = 1,
		},
	},
}
EventConfig[EventID.Id012] =
{
	Id = 12,
	Name = "路边的神龛",
	Gallery = 950001,
	Area = 130005,
	LockDesc = "解锁提示\n一次性探索魔法平原15分钟",
	Desc = "经过古老的神社，在小道旁的神龛前拜了一下当地的神明。不过，这个神像是不是长得有点像呜呜呢？顺便，我们成功阻止了呜呜偷吃贡品……",
	Bundle = "packed_event_rpg",
	Atlas = "Event_RPG",
	Icon = "RPG_Event_2",
	TriggerCondition = {
		NeedExploreTime = 900,
	},
	Reward = {
		{
			Value = 2,
			Num = 30,
		},
	},
}
EventConfig[EventID.Id013] =
{
	Id = 13,
	Name = "古老皇冠",
	Gallery = 950001,
	Area = 130006,
	LockDesc = "解锁提示\n一次性探索古代遗迹4小时\n(需要身手灵敏且行动无声的角色)",
	Desc = "在遗迹深处发现了古老皇宫。中央宝座之上，国王的骷髅戴着闪亮皇冠。大家讨论后决定让刺客取回皇冠。果然，沿途有很多陷阱……",
	Bundle = "packed_event_rpg",
	Atlas = "Event_RPG",
	Icon = "RPG_Event_24",
	TriggerCondition = {
		NeedExploreTime = 14400,
		ConditionList = {
			{
				Condition = "TeamCharacterIdAnd",
				Value = 
				{
					220020,
				},
			},
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
EventConfig[EventID.Id014] =
{
	Id = 14,
	Name = "孤独的骷髅",
	Gallery = 950001,
	Area = 130006,
	LockDesc = "解锁提示\n一次性探索古代遗迹2小时\n(需要精通魔法的角色和懂得不死族语言的角色)",
	Desc = "在石窟里遇到了被巫师主人遗弃的魔法骷髅，虽然看不到表情，但是它似乎希望我们把它带上。下一秒，钟乳石垂下的水滴打在它眼眶上，滑落下来。",
	Bundle = "packed_event_rpg",
	Atlas = "Event_RPG",
	Icon = "RPG_Event_3",
	TriggerCondition = {
		NeedExploreTime = 7200,
		ConditionList = {
			{
				Condition = "TeamCharacterIdAnd",
				Value = 
				{
					220010,
					220006,
				},
			},
		},
	},
	Reward = {
		{
			Value = 320507,
			Num = 1,
		},
	},
}
EventConfig[EventID.Id015] =
{
	Id = 15,
	Name = "点燃火神的柱子",
	Gallery = 950001,
	Area = 130006,
	LockDesc = "解锁提示\n一次性探索古代遗迹1小时\n(需要射术高超的角色)",
	Desc = "发现了遗迹中供奉的火神柱子，足足有5米高，大家试了好几次都没有爬上去，最后弓箭手用火箭点燃了它。",
	Bundle = "packed_event_rpg",
	Atlas = "Event_RPG",
	Icon = "RPG_Event_23",
	TriggerCondition = {
		NeedExploreTime = 3600,
		ConditionList = {
			{
				Condition = "TeamCharacterIdAnd",
				Value = 
				{
					220004,
				},
			},
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 30,
		},
	},
}
EventConfig[EventID.Id016] =
{
	Id = 16,
	Name = "十字路口",
	Gallery = 950001,
	Area = 130006,
	LockDesc = "解锁提示\n一次性探索古代遗迹1小时",
	Desc = "原本探索很顺利，但回家路上被一块路牌误导兜了好几圈。为了后面的人不被误导，我们把路牌拆回来了~",
	Bundle = "packed_event_rpg",
	Atlas = "Event_RPG",
	Icon = "RPG_Event_9",
	TriggerCondition = {
		NeedExploreTime = 3600,
	},
	Reward = {
		{
			Value = 320503,
			Num = 1,
		},
	},
}
EventConfig[EventID.Id017] =
{
	Id = 17,
	Name = "泥潭怪物？",
	Gallery = 950001,
	Area = 130007,
	LockDesc = "解锁提示\n一次性探索大沼泽12小时",
	Desc = "经过一条泥河时，看到河面上露出了一片巨大的背鳍。下面是不是藏着“可怕”的怪物呢？",
	Bundle = "packed_event_rpg",
	Atlas = "Event_RPG",
	Icon = "RPG_Event_13",
	TriggerCondition = {
		NeedExploreTime = 43200,
	},
	Reward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
EventConfig[EventID.Id018] =
{
	Id = 18,
	Name = "漂浮的茶杯",
	Gallery = 950001,
	Area = 130007,
	LockDesc = "解锁提示\n一次性探索大沼泽8小时\n(需解锁事件：泥潭怪物？)",
	Desc = "在可能有怪物出没的泥河上发现了一只茶杯，应该是很爱喝茶的人的物件。杯子的主人是不是被水怪吃掉了呢？",
	Bundle = "packed_event_rpg",
	Atlas = "Event_RPG",
	Icon = "RPG_Event_22",
	TriggerCondition = {
		NeedExploreTime = 28800,
	},
	Reward = {
		{
			Value = 320514,
			Num = 1,
		},
	},
}
EventConfig[EventID.Id019] =
{
	Id = 19,
	Name = "泥潭钓鱼1",
	Gallery = 950001,
	Area = 130007,
	LockDesc = "解锁提示\n一次性探索大沼泽4小时",
	Desc = "在沼泽里发现了一个不错的泥塘，旁边竖着一块禁止钓鱼的告示牌。准备离开的时候，发现了一根被人遗弃的鱼竿，于是带了回来。",
	Bundle = "packed_event_rpg",
	Atlas = "Event_RPG",
	Icon = "RPG_Event_11",
	TriggerCondition = {
		NeedExploreTime = 14400,
	},
	Reward = {
		{
			Value = 320509,
			Num = 1,
		},
	},
}
EventConfig[EventID.Id020] =
{
	Id = 20,
	Name = "泥潭钓鱼2",
	Gallery = 950001,
	Area = 130007,
	LockDesc = "解锁提示\n一次性探索大沼泽4小时",
	Desc = "带着鱼竿去了禁止钓鱼的泥塘。打算钓鱼来吃的时候，被管理鱼塘的小泥怪发现罚了款。对方用泥怪语批评了我们……太丢脸了……",
	Bundle = "packed_event_rpg",
	Atlas = "Event_RPG",
	Icon = "RPG_Event_12",
	TriggerCondition = {
		NeedExploreTime = 14400,
	},
	Reward = {
		{
			Value = 320510,
			Num = 1,
		},
	},
}
EventConfig[EventID.Id021] =
{
	Id = 21,
	Name = "深坑谷名字的由来",
	Gallery = 950001,
	Area = 130008,
	LockDesc = "解锁提示\n一次性探索深坑谷8小时\n(需要对本地地图非常了解的角色和被幸运之神抛弃的特殊角色)",
	Desc = "指路NPC说，这里有一个会移动的大坑，需要有个人来吸引它，才能让全队安全通过。最佳人选是总是不走运的酋长大人。",
	Bundle = "packed_event_rpg",
	Atlas = "Event_RPG",
	Icon = "RPG_Event_30",
	TriggerCondition = {
		NeedExploreTime = 28800,
		ConditionList = {
			{
				Condition = "TeamCharacterIdAnd",
				Value = 
				{
					220007,
					221004,
				},
			},
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
EventConfig[EventID.Id022] =
{
	Id = 22,
	Name = "石中剑",
	Gallery = 950001,
	Area = 130008,
	LockDesc = "解锁提示\n一次性探索深坑谷8小时\n(需要一位能击败龙族的英雄后裔)",
	Desc = "无意间发现了英雄王的坟墓。石块上插着代表勇敢与正义力量的宝剑。因为心心的数量不够所以拔不下来呢~不过龙骑士连着石头把它一起搬回来了~",
	Bundle = "packed_event_rpg",
	Atlas = "Event_RPG",
	Icon = "RPG_Event_5",
	TriggerCondition = {
		NeedExploreTime = 28800,
		ConditionList = {
			{
				Condition = "TeamCharacterIdAnd",
				Value = 
				{
					220026,
				},
			},
		},
	},
	Reward = {
		{
			Value = 320508,
			Num = 1,
		},
	},
}
EventConfig[EventID.Id023] =
{
	Id = 23,
	Name = "没有什么是不能抓的",
	Gallery = 950001,
	Area = 130008,
	LockDesc = "解锁提示\n一次性探索深坑谷6小时\n(需要貌似精通打猎技巧的角色)",
	Desc = "听说很多委托人都想要刺毛怪的钢刺噢~猎人在刺毛怪出没的地点布置了大量独门陷阱，这次可以大赚一笔了呢~",
	Bundle = "packed_event_rpg",
	Atlas = "Event_RPG",
	Icon = "RPG_Event_31",
	TriggerCondition = {
		NeedExploreTime = 21600,
		ConditionList = {
			{
				Condition = "TeamCharacterIdAnd",
				Value = 
				{
					220005,
				},
			},
		},
	},
	Reward = {
		{
			Value = 321007,
			Num = 20,
		},
	},
}
EventConfig[EventID.Id024] =
{
	Id = 24,
	Name = "巨大的精英怪",
	Gallery = 950001,
	Area = 130008,
	LockDesc = "解锁提示\n一次性探索深坑谷6小时",
	Desc = "瞎转悠的时候对着远处的高山眺望，等待浓雾散去之后才发现那并不是高山，而是一只巨大的怪物，红红的眼睛让人喘不过气来。这难道就是传说中的野外精英怪物吗？",
	Bundle = "packed_event_rpg",
	Atlas = "Event_RPG",
	Icon = "RPG_Event_32",
	TriggerCondition = {
		NeedExploreTime = 21600,
	},
	Reward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
EventConfig[EventID.Id025] =
{
	Id = 25,
	Name = "火山深处的宝箱",
	Gallery = 950001,
	Area = 130009,
	LockDesc = "解锁提示\n一次性探索魔王火山8小时\n(需要魔王城堡的负责人)",
	Desc = "小魔王说带我们去找大宝箱！不过找到宝箱打开后才发现，里面的财宝因为放了太久已经变成沙子了……",
	Bundle = "packed_event_rpg",
	Atlas = "Event_RPG",
	Icon = "RPG_Event_35",
	TriggerCondition = {
		NeedExploreTime = 28800,
		ConditionList = {
			{
				Condition = "TeamCharacterIdAnd",
				Value = 
				{
					220009,
				},
			},
		},
	},
	Reward = {
		{
			Value = 321008,
			Num = 50,
		},
	},
}
EventConfig[EventID.Id026] =
{
	Id = 26,
	Name = "最高级的锻造术",
	Gallery = 950001,
	Area = 130009,
	LockDesc = "解锁提示\n一次性探索魔王火山8小时\n(需要精通锻造的角色和随身携带宝剑的角色)",
	Desc = "“用岩浆把武器融化后，就能重新锻造，让武器焕然新生！”铁匠照着师傅的话做了，不过，只搞定了前半句，剑士说今天一定要给他点教训看看。",
	Bundle = "packed_event_rpg",
	Atlas = "Event_RPG",
	Icon = "RPG_Event_36",
	TriggerCondition = {
		NeedExploreTime = 28800,
		ConditionList = {
			{
				Condition = "TeamCharacterIdAnd",
				Value = 
				{
					220008,
					220003,
				},
			},
		},
	},
	Reward = {
		{
			Value = 320041,
			Num = 300,
		},
	},
}
EventConfig[EventID.Id027] =
{
	Id = 27,
	Name = "火山温泉",
	Gallery = 950001,
	Area = 130009,
	LockDesc = "解锁提示\n一次性探索魔王火山8小时",
	Desc = "找到了传说中的火山温泉，只要泡一小会儿就能缓解疲劳。不过泡久了要小心脱水噢。",
	Bundle = "packed_event_rpg",
	Atlas = "Event_RPG",
	Icon = "RPG_Event_34",
	TriggerCondition = {
		NeedExploreTime = 28800,
	},
	Reward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
EventConfig[EventID.Id028] =
{
	Id = 28,
	Name = "火山爆发",
	Gallery = 950001,
	Area = 130009,
	LockDesc = "解锁提示\n一次性探索魔王火山8小时\n(需要被幸运之神抛弃的特殊角色)",
	Desc = "探险的时候听到“轰”的一声，对面的火山爆发了！！岩浆要漫过来了，快逃啊！！",
	Bundle = "packed_event_rpg",
	Atlas = "Event_RPG",
	Icon = "RPG_Event_33",
	TriggerCondition = {
		NeedExploreTime = 28800,
		ConditionList = {
			{
				Condition = "TeamCharacterIdAnd",
				Value = 
				{
					221004,
				},
			},
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
EventConfig[EventID.Id029] =
{
	Id = 29,
	Name = "华丽的衣帽间",
	Gallery = 950001,
	Area = 130010,
	LockDesc = "解锁提示\n一次性探索魔王城堡12小时\n(需要魔王公司的幕后大老板)",
	Desc = "在城堡顶楼探索时，大魔王忽然说要去拿几件衣服。打开暗门后，大家跟着Ta进了一间很华丽的房间，里面的大衣橱里都是好看的衣服。",
	Bundle = "packed_event_rpg",
	Atlas = "Event_RPG",
	Icon = "RPG_Event_20",
	TriggerCondition = {
		NeedExploreTime = 43200,
		ConditionList = {
			{
				Condition = "TeamCharacterIdAnd",
				Value = 
				{
					220029,
				},
			},
		},
	},
	Reward = {
		{
			Value = 320101,
			Num = 5,
		},
	},
}
EventConfig[EventID.Id030] =
{
	Id = 30,
	Name = "失而复得的日记本",
	Gallery = 950001,
	Area = 130010,
	LockDesc = "解锁提示\n一次性探索魔王城堡10小时\n(需要信仰坚定且充满爱心的女性角色)",
	Desc = "无意间走进了魔王的办公室，在抽屉里找到了牧师以前冒险时遗失的日记本，怎么会被魔王藏起来的呢？",
	Bundle = "packed_event_rpg",
	Atlas = "Event_RPG",
	Icon = "RPG_Event_16",
	TriggerCondition = {
		NeedExploreTime = 36000,
		ConditionList = {
			{
				Condition = "TeamCharacterIdAnd",
				Value = 
				{
					220021,
				},
			},
		},
	},
	Reward = {
		{
			Value = 320513,
			Num = 1,
		},
	},
}
EventConfig[EventID.Id031] =
{
	Id = 31,
	Name = "休息一会儿",
	Gallery = 950001,
	Area = 130010,
	LockDesc = "解锁提示\n一次性探索魔王城堡8小时",
	Desc = "在城堡二楼找到了休息室，桌上还放着一副扑克牌。大家玩了各种牌戏，听到外面传来脚步声时，就赶紧带着牌溜走了。",
	Bundle = "packed_event_rpg",
	Atlas = "Event_RPG",
	Icon = "RPG_Event_19",
	TriggerCondition = {
		NeedExploreTime = 28800,
	},
	Reward = {
		{
			Value = 320511,
			Num = 1,
		},
	},
}
EventConfig[EventID.Id032] =
{
	Id = 32,
	Name = "被盗号的冒险者",
	Gallery = 950001,
	Area = 130010,
	LockDesc = "解锁提示\n一次性探索魔王城堡4小时",
	Desc = "看到一个光溜溜的冒险者在副本入口处破口大骂。听说是被人盗号了，昨天还是本地排名第一的剑豪，今天就被红色史莱姆围住了打得鼻青眼肿。",
	Bundle = "packed_event_rpg",
	Atlas = "Event_RPG",
	Icon = "RPG_Event_38",
	TriggerCondition = {
		NeedExploreTime = 14400,
	},
	Reward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
EventConfig[EventID.Id033] =
{
	Id = 33,
	Name = "星球仪",
	Gallery = 950001,
	Area = 130010,
	LockDesc = "解锁提示\n一次性探索魔王城堡2小时",
	Desc = "在入口大厅处，发现了悬浮在空中的星球仪，可以在上面看到冒险小队的GPS定位图。看来行踪已经完全被监视了……",
	Bundle = "packed_event_rpg",
	Atlas = "Event_RPG",
	Icon = "RPG_Event_14",
	TriggerCondition = {
		NeedExploreTime = 7200,
	},
	Reward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
EventConfig[EventID.Id034] =
{
	Id = 34,
	Name = "制作组办公室",
	Gallery = 950001,
	Area = 130011,
	LockDesc = "解锁提示\n一次性探索藏宝库16小时",
	Desc = "在城堡顶楼发现了奇怪的小房间，门口挂着“OFFICE”的牌子。里面空无一人，桌上的电脑屏幕还亮着。",
	Bundle = "packed_event_rpg",
	Atlas = "Event_RPG",
	Icon = "RPG_Event_21",
	TriggerCondition = {
		NeedExploreTime = 57600,
	},
	Reward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
EventConfig[EventID.Id035] =
{
	Id = 35,
	Name = "龙族的特权",
	Gallery = 950001,
	Area = 130011,
	LockDesc = "解锁提示\n一次性探索藏宝库12小时\n(需要流淌着龙族血脉的角色)",
	Desc = "找到了巨龙守护的扭蛋屋，因为是龙族后裔，所以免费得到了一万枚代币，不过扭了9997次后什么都扭不到，最后3枚还是带走留个纪念吧。",
	Bundle = "packed_event_rpg",
	Atlas = "Event_RPG",
	Icon = "RPG_Event_39",
	TriggerCondition = {
		NeedExploreTime = 43200,
		ConditionList = {
			{
				Condition = "TeamCharacterIdAnd",
				Value = 
				{
					220027,
				},
			},
		},
	},
	Reward = {
		{
			Value = 330003,
			Num = 3,
		},
	},
}
EventConfig[EventID.Id036] =
{
	Id = 36,
	Name = "服务器机房",
	Gallery = 950001,
	Area = 130011,
	LockDesc = "解锁提示\n一次性探索藏宝库12小时\n(需要精通程序编写的角色)",
	Desc = "发现了一间摆放着着大量服务器的房间，信号灯不断闪亮着。程序猿熟练地操作后给发了玉璧……不过权限受限只能发100个……",
	Bundle = "packed_event_rpg",
	Atlas = "Event_RPG",
	Icon = "RPG_Event_15",
	TriggerCondition = {
		NeedExploreTime = 43200,
		ConditionList = {
			{
				Condition = "TeamCharacterIdAnd",
				Value = 
				{
					220024,
				},
			},
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 100,
		},
	},
}
EventConfig[EventID.Id037] =
{
	Id = 37,
	Name = "小时候的回忆",
	Gallery = 950001,
	Area = 130011,
	LockDesc = "解锁提示\n一次性探索藏宝库10小时\n(需要在魔王城堡的负责人)",
	Desc = "冒险的时候发现一个小土包，挖开来后，发现竟是小魔王小时候埋在这里的玩具。通过玩偶的破损程度来看，他小时候更喜欢当勇士。",
	Bundle = "packed_event_rpg",
	Atlas = "Event_RPG",
	Icon = "RPG_Event_37",
	TriggerCondition = {
		NeedExploreTime = 36000,
		ConditionList = {
			{
				Condition = "TeamCharacterIdAnd",
				Value = 
				{
					220009,
				},
			},
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
EventConfig[EventID.Id038] =
{
	Id = 38,
	Name = "魔物寝室",
	Gallery = 950001,
	Area = 130011,
	LockDesc = "解锁提示\n一次性探索藏宝库8小时\n(需要精通音效制作的角色)",
	Desc = "路过了火焰巨人的怪物宿舍。房间里播放着配音演员讲故事的录音带，火焰巨人似乎是听着录音带安然入睡的。",
	Bundle = "packed_event_rpg",
	Atlas = "Event_RPG",
	Icon = "RPG_Event_18",
	TriggerCondition = {
		NeedExploreTime = 28800,
		ConditionList = {
			{
				Condition = "TeamCharacterIdAnd",
				Value = 
				{
					220023,
				},
			},
		},
	},
	Reward = {
		{
			Value = 320512,
			Num = 1,
		},
	},
}
EventConfig[EventID.Id039] =
{
	Id = 39,
	Name = "魔王的锅炉房",
	Gallery = 950001,
	Area = 130011,
	LockDesc = "解锁提示\n一次性探索藏宝库8小时",
	Desc = "路过了城堡地下的锅炉房。这里提供着整个城堡的热量。骨头兵们认真地把火精灵一只一只塞进锅炉里。",
	Bundle = "packed_event_rpg",
	Atlas = "Event_RPG",
	Icon = "RPG_Event_17",
	TriggerCondition = {
		NeedExploreTime = 28800,
	},
	Reward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
EventConfig[EventID.Id040] =
{
	Id = 40,
	Name = "牧师的日记1",
	Gallery = 950001,
	Area = 130010,
	LockDesc = "解锁提示\n一次性探索魔王城堡2小时\n(需要受到广大男冒险者欢迎的神职女性)",
	Desc = "今天抵达魔王城堡，果然是很厉害的副本。在第一波怪物那里就差点团灭，在补充魔法药水的时候，有个骨头兵偷袭我们，幸好它走神了，不然就倒霉了。",
	Bundle = "packed_event_rpg",
	Atlas = "Event_RPG",
	Icon = "RPG_EventCP_1",
	TriggerCondition = {
		NeedExploreTime = 7200,
		ConditionList = {
			{
				Condition = "TeamCharacterIdAnd",
				Value = 
				{
					220021,
				},
			},
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
EventConfig[EventID.Id041] =
{
	Id = 41,
	Name = "牧师的日记2",
	Gallery = 950001,
	Area = 130010,
	LockDesc = "解锁提示\n一次性探索魔王城堡2小时\n(需要受到广大男冒险者欢迎的神职女性)",
	Desc = "今天来到了boss战前的陷阱大厅。巨大木槌砸了过来，啊！网络突然卡住了，操作怎么都不响应...重新连上时，自己竟然安然无恙，好险啊。",
	Bundle = "packed_event_rpg",
	Atlas = "Event_RPG",
	Icon = "RPG_EventCP_2",
	TriggerCondition = {
		NeedExploreTime = 7200,
		ConditionList = {
			{
				Condition = "TeamCharacterIdAnd",
				Value = 
				{
					220021,
				},
			},
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
EventConfig[EventID.Id042] =
{
	Id = 42,
	Name = "牧师的日记3",
	Gallery = 950001,
	Area = 130010,
	LockDesc = "解锁提示\n一次性探索魔王城堡2小时\n(需要受到广大男冒险者欢迎的神职女性)",
	Desc = "副本通关，开心~虽然Boss血条很长，而且不停回血，不过还是胜利了。大家拿到了很多想要的装备，背包都放不下了呢。唔……日记本不要了吧。",
	Bundle = "packed_event_rpg",
	Atlas = "Event_RPG",
	Icon = "RPG_EventCP_3",
	TriggerCondition = {
		NeedExploreTime = 7200,
		ConditionList = {
			{
				Condition = "TeamCharacterIdAnd",
				Value = 
				{
					220021,
				},
			},
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 50,
		},
	},
}
EventConfig[EventID.Id043] =
{
	Id = 43,
	Name = "小魔王的回忆1",
	Gallery = 950001,
	Area = 130010,
	LockDesc = "解锁提示\n一次性探索魔王城堡2小时\n(需要魔王集团的总经理)",
	Desc = "来到了魔王城堡时，小魔王想起牧师第一次来魔王城堡时的情景。牧师连见习骨头兵都打不过，只是光顾着回血。哎，敌人挥刀时怎么不先躲开呢……",
	Bundle = "packed_event_rpg",
	Atlas = "Event_RPG",
	Icon = "RPG_EventCP_4",
	TriggerCondition = {
		NeedExploreTime = 7200,
		ConditionList = {
			{
				Condition = "TeamCharacterIdAnd",
				Value = 
				{
					220009,
				},
			},
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
EventConfig[EventID.Id044] =
{
	Id = 44,
	Name = "小魔王的回忆2",
	Gallery = 950001,
	Area = 130010,
	LockDesc = "解锁提示\n一次性探索魔王城堡2小时\n(需要魔王集团的总经理)",
	Desc = "牧师过完这片陷阱区就是最终挑战了，这片策划精心设计的陷阱区还是非常考验动作和操作的。可关键时刻怎么能掉线啊，喂！",
	Bundle = "packed_event_rpg",
	Atlas = "Event_RPG",
	Icon = "RPG_EventCP_5",
	TriggerCondition = {
		NeedExploreTime = 7200,
		ConditionList = {
			{
				Condition = "TeamCharacterIdAnd",
				Value = 
				{
					220009,
				},
			},
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
EventConfig[EventID.Id045] =
{
	Id = 45,
	Name = "小魔王的回忆3",
	Gallery = 950001,
	Area = 130010,
	LockDesc = "解锁提示\n一次性探索魔王城堡2小时\n(需要魔王集团的总经理)",
	Desc = "今天迎来了和牧师正面交锋的日子，为了和她呆着一起的时间久一点，我调长了血条，喝了20多种恢复药水，希望可以多和她待一会儿。这是她第98次通关副本，下次要再见到她不知道是什么时候了。",
	Bundle = "packed_event_rpg",
	Atlas = "Event_RPG",
	Icon = "RPG_EventCP_6",
	TriggerCondition = {
		NeedExploreTime = 7200,
		ConditionList = {
			{
				Condition = "TeamCharacterIdAnd",
				Value = 
				{
					220009,
				},
			},
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 50,
		},
	},
}
EventConfig[EventID.Id200] =
{
	Id = 200,
	Name = "啊，请看下这个~",
	Gallery = 950001,
	Area = 130005,
	LockDesc = "解锁提示\n一次性探索魔法平原5分钟",
	Desc = "来到了魔法平原，一个史莱姆悄悄靠近我们。它拿着一张皱巴巴的纸，让我们务必帮忙填个单子…打算扭头就走时，它很懂事地塞了100玉璧在我们口袋里。",
	Bundle = "packed_event_rpg",
	Atlas = "Event_RPG",
	Icon = "RPG_Event_40",
	TriggerCondition = {
		NeedExploreTime = 300,
	},
	Reward = {
		{
			Value = 2,
			Num = 100,
		},
	},
}
EventConfig[EventID.Id201] =
{
	Id = 201,
	Name = "仙女童装",
	Gallery = 950002,
	Area = 130052,
	LockDesc = "解锁提示\n一次性探索鲷鱼镇6小时\n(需要一对可爱又调皮的姐妹)",
	Desc = "路过了镇上最出名的童装店，橱窗里展示着最新到货的小仙女服装。为了抢新童装，虾条小姐和妙脆角小姐一改往日乖巧的风格，都躺在地上哭闹起来。",
	Bundle = "packed_event_fat",
	Atlas = "Event_FAT",
	Icon = "FAT_Event_21",
	TriggerCondition = {
		NeedExploreTime = 21600,
		ConditionList = {
			{
				Condition = "TeamCharacterIdAnd",
				Value = 
				{
					220117,
					220118,
				},
			},
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
EventConfig[EventID.Id202] =
{
	Id = 202,
	Name = "经营不善的咖啡馆",
	Gallery = 950002,
	Area = 130052,
	LockDesc = "解锁提示\n一次性探索鲷鱼镇6小时\n(需要经常在咖啡店打工的少女)",
	Desc = "经过了镇上唯一的咖啡厅，咖啡小姐表示在这里打工时被拖欠了工资，一定得要回来。不过经营不善的老板只肯赠送盒饭作为补偿。",
	Bundle = "packed_event_fat",
	Atlas = "Event_FAT",
	Icon = "FAT_Event_20",
	TriggerCondition = {
		NeedExploreTime = 21600,
		ConditionList = {
			{
				Condition = "TeamCharacterIdAnd",
				Value = 
				{
					220113,
				},
			},
		},
	},
	Reward = {
		{
			Value = 320410,
			Num = 3,
		},
	},
}
EventConfig[EventID.Id203] =
{
	Id = 203,
	Name = "鲸鱼烧",
	Gallery = 950002,
	Area = 130052,
	LockDesc = "解锁提示\n一次性探索鲷鱼镇6小时",
	Desc = "曾经做出了史上最大鲷鱼烧的点心师，又一次挑战了自己的记录。因为史无前例的尺寸，这次他为创作命名为“鲸鱼烧”！不过……鲸鱼算鱼类吗？",
	Bundle = "packed_event_fat",
	Atlas = "Event_FAT",
	Icon = "FAT_Event_19",
	TriggerCondition = {
		NeedExploreTime = 21600,
	},
	Reward = {
		{
			Value = 321201,
			Num = 20,
		},
	},
}
EventConfig[EventID.Id204] =
{
	Id = 204,
	Name = "鲷鱼冰淇淋",
	Gallery = 950002,
	Area = 130052,
	LockDesc = "解锁提示\n一次性探索鲷鱼镇6小时\n(需要呜呜、漆漆)",
	Desc = "呜呜和漆漆都闹着要吃冰淇淋，大家都没有办法。小店的点心师摸着下巴想了一会儿就去后厨做了两个鲷鱼烧。呜呜和漆漆不情愿地咬了一口，发现里面是冰淇淋，忽然就高兴了起来~",
	Bundle = "packed_event_fat",
	Atlas = "Event_FAT",
	Icon = "FAT_Event_22",
	TriggerCondition = {
		NeedExploreTime = 21600,
	},
	Reward = {
		{
			Value = 321251,
			Num = 3,
		},
	},
}
EventConfig[EventID.Id205] =
{
	Id = 205,
	Name = "浪漫邂逅",
	Gallery = 950002,
	Area = 130053,
	LockDesc = "解锁提示\n一次性探索冰淇淋港16小时\n(需要扎着可爱蝴蝶结的公主)",
	Desc = "在滨海大道上，冰淇淋公主回忆起她在这里和奶茶王子第一次邂逅。王子第一次看见她，就邀请她担任电影《甜腻腻》的女主角。",
	Bundle = "packed_event_fat",
	Atlas = "Event_FAT",
	Icon = "FAT_Event_23",
	TriggerCondition = {
		NeedExploreTime = 57600,
		ConditionList = {
			{
				Condition = "TeamCharacterIdAnd",
				Value = 
				{
					220123,
				},
			},
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 60,
		},
	},
}
EventConfig[EventID.Id206] =
{
	Id = 206,
	Name = "冠军的执念",
	Gallery = 950002,
	Area = 130053,
	LockDesc = "解锁提示\n一次性探索冰淇淋港16小时\n(需要始终在与冰淇淋公主争夺排名的女性)",
	Desc = "港口的超大排行榜上每天都会公布本地区最受欢迎的角色~为了赢过冰淇淋公主，黑巧克力皇后等晚上的时候，偷偷爬到排行榜上把自己变成了第一名。",
	Bundle = "packed_event_fat",
	Atlas = "Event_FAT",
	Icon = "FAT_Event_34",
	TriggerCondition = {
		NeedExploreTime = 57600,
		ConditionList = {
			{
				Condition = "TeamCharacterIdAnd",
				Value = 
				{
					220121,
				},
			},
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
EventConfig[EventID.Id207] =
{
	Id = 207,
	Name = "电影海报",
	Gallery = 950002,
	Area = 130053,
	LockDesc = "解锁提示\n一次性探索冰淇淋港16小时\n(需要代表着醇香丝滑的饮料的王子)",
	Desc = "影院张贴着即将上映的《王子冒险记》海报。导演、摄影、主演、剧本署名都是王子本人。凡是路过的人都能领到3张票，还能得到爆米花可乐套餐。",
	Bundle = "packed_event_fat",
	Atlas = "Event_FAT",
	Icon = "FAT_Event_15",
	TriggerCondition = {
		NeedExploreTime = 57600,
		ConditionList = {
			{
				Condition = "TeamCharacterIdAnd",
				Value = 
				{
					220101,
				},
			},
		},
	},
	Reward = {
		{
			Value = 320516,
			Num = 1,
		},
	},
}
EventConfig[EventID.Id208] =
{
	Id = 208,
	Name = "王子奶茶店",
	Gallery = 950002,
	Area = 130053,
	LockDesc = "解锁提示\n一次性探索冰淇淋港12小时",
	Desc = "来到了著名的王子奶茶店，拿到号时，上面写着“前面还需等待800人”。",
	Bundle = "packed_event_fat",
	Atlas = "Event_FAT",
	Icon = "FAT_Event_1",
	TriggerCondition = {
		NeedExploreTime = 43200,
	},
	Reward = {
		{
			Value = 320515,
			Num = 1,
		},
	},
}
EventConfig[EventID.Id209] =
{
	Id = 209,
	Name = "自行车租赁",
	Gallery = 950002,
	Area = 130053,
	LockDesc = "解锁提示\n一次性探索冰淇淋港12小时",
	Desc = "发现了可在甜品镇内任意取用的四人自行车，五个人勉强挤上了车，但在拐角口时被番茄酱侍卫拦下开了罚单……",
	Bundle = "packed_event_fat",
	Atlas = "Event_FAT",
	Icon = "FAT_Event_12",
	TriggerCondition = {
		NeedExploreTime = 43200,
	},
	Reward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
EventConfig[EventID.Id210] =
{
	Id = 210,
	Name = "放飞的气球",
	Gallery = 950002,
	Area = 130053,
	LockDesc = "解锁提示\n一次性探索冰淇淋港12小时",
	Desc = "正好遇上了镇上举办的气球节，漫天飞舞着五彩缤纷的气球，让大家忘了自己正在冒险呢~",
	Bundle = "packed_event_fat",
	Atlas = "Event_FAT",
	Icon = "FAT_Event_14",
	TriggerCondition = {
		NeedExploreTime = 43200,
	},
	Reward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
EventConfig[EventID.Id211] =
{
	Id = 211,
	Name = "完美的爆炸头！",
	Gallery = 950002,
	Area = 130054,
	LockDesc = "解锁提示\n一次性探索糖果镇16小时\n(需要爆炸头的公主)",
	Desc = "路过小镇上的理发店时，理发店老板热情邀请棉花糖公主为最新的棉花糖机代言，使用这个机器，就能做出完美的爆炸头！",
	Bundle = "packed_event_fat",
	Atlas = "Event_FAT",
	Icon = "FAT_Event_25",
	TriggerCondition = {
		NeedExploreTime = 57600,
		ConditionList = {
			{
				Condition = "TeamCharacterIdAnd",
				Value = 
				{
					220122,
				},
			},
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
EventConfig[EventID.Id212] =
{
	Id = 212,
	Name = "被封锁的豪华公寓",
	Gallery = 950002,
	Area = 130054,
	LockDesc = "解锁提示\n一次性探索糖果镇16小时\n(需要正在为振兴家业而打工的少女)",
	Desc = "走过镇上最豪华的别墅，这里原本是棒棒糖女仆的家，直到她的父亲被捕……如今大门已经被封锁了。",
	Bundle = "packed_event_fat",
	Atlas = "Event_FAT",
	Icon = "FAT_Event_24",
	TriggerCondition = {
		NeedExploreTime = 57600,
		ConditionList = {
			{
				Condition = "TeamCharacterIdAnd",
				Value = 
				{
					220112,
				},
			},
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
EventConfig[EventID.Id213] =
{
	Id = 213,
	Name = "神秘配方！",
	Gallery = 950002,
	Area = 130054,
	LockDesc = "解锁提示\n一次性探索糖果镇12小时",
	Desc = "在工厂探险时，发现了让饮料好喝的秘诀——“没办法就多放糖”。",
	Bundle = "packed_event_fat",
	Atlas = "Event_FAT",
	Icon = "FAT_Event_2",
	TriggerCondition = {
		NeedExploreTime = 43200,
	},
	Reward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
EventConfig[EventID.Id214] =
{
	Id = 214,
	Name = "果酒秘制法",
	Gallery = 950002,
	Area = 130054,
	LockDesc = "解锁提示\n一次性探索糖果镇12小时",
	Desc = "发现了一个泳池，里面装满了啤酒。水果们在里面游泳，等会这里出来的就是果酒了……",
	Bundle = "packed_event_fat",
	Atlas = "Event_FAT",
	Icon = "FAT_Event_3",
	TriggerCondition = {
		NeedExploreTime = 43200,
	},
	Reward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
EventConfig[EventID.Id215] =
{
	Id = 215,
	Name = "辣味饮料",
	Gallery = 950002,
	Area = 130055,
	LockDesc = "解锁提示\n一次性探索甜食工厂1天\n(需要代表着冰凉清爽的饮料的王子)",
	Desc = "汽水王子亲自设计的新式饮料，据说参考了辣翅配甜味饮料的做法，才想出了辣味饮料来配甜食的新思路。在美食星引起了不小的轰动，甚至已有相关机构对其进行学术研究。",
	Bundle = "packed_event_fat",
	Atlas = "Event_FAT",
	Icon = "FAT_Event_7",
	TriggerCondition = {
		NeedExploreTime = 86400,
		ConditionList = {
			{
				Condition = "TeamCharacterIdAnd",
				Value = 
				{
					220102,
				},
			},
		},
	},
	Reward = {
		{
			Value = 320519,
			Num = 1,
		},
	},
}
EventConfig[EventID.Id216] =
{
	Id = 216,
	Name = "可怕的榨汁机",
	Gallery = 950002,
	Area = 130055,
	LockDesc = "解锁提示\n一次性探索甜食工厂1天",
	Desc = "工厂里曾经最可怕的机器，最后被水果们联名停止运行了。现在被当成是艺术品展览，不过水果们走过看到时还是会不自觉地抖一下。",
	Bundle = "packed_event_fat",
	Atlas = "Event_FAT",
	Icon = "FAT_Event_4",
	TriggerCondition = {
		NeedExploreTime = 86400,
	},
	Reward = {
		{
			Value = 320518,
			Num = 1,
		},
	},
}
EventConfig[EventID.Id217] =
{
	Id = 217,
	Name = "瓶子选举大赛",
	Gallery = 950002,
	Area = 130055,
	LockDesc = "解锁提示\n一次性探索甜食工厂1天",
	Desc = "在车间的黑板上，看到画着三个瓶子，下面记录着投票数，应该是在推选下一批次的饮料瓶。不过从投票情况来看，最难拿的瓶子似乎当选了。",
	Bundle = "packed_event_fat",
	Atlas = "Event_FAT",
	Icon = "FAT_Event_5",
	TriggerCondition = {
		NeedExploreTime = 86400,
	},
	Reward = {
		{
			Value = 320307,
			Num = 2,
		},
	},
}
EventConfig[EventID.Id218] =
{
	Id = 218,
	Name = "形象大使",
	Gallery = 950002,
	Area = 130055,
	LockDesc = "解锁提示\n一次性探索甜食工厂1天",
	Desc = "由汽水王子亲自担任形象大使拍摄的宣传海报，还没有进入影印阶段，挂在设计间的墙上。这种形状的下巴一度成为了美食星最流行的审美。",
	Bundle = "packed_event_fat",
	Atlas = "Event_FAT",
	Icon = "FAT_Event_6",
	TriggerCondition = {
		NeedExploreTime = 86400,
	},
	Reward = {
		{
			Value = 320517,
			Num = 1,
		},
	},
}
EventConfig[EventID.Id219] =
{
	Id = 219,
	Name = "太烫了！",
	Gallery = 950002,
	Area = 130056,
	LockDesc = "解锁提示\n一次性探索风味镇1天\n(需要呜呜和漆漆)",
	Desc = "路过一家章鱼小丸子店，店员看见可爱的小猫咪，给了他们一盒章鱼小丸子，正想告诉它们，这个馅料超级烫，要小心时，它们已经一口吞进了嘴里……",
	Bundle = "packed_event_fat",
	Atlas = "Event_FAT",
	Icon = "FAT_Event_26",
	TriggerCondition = {
		NeedExploreTime = 86400,
		ConditionList = {
			{
				Condition = "TeamCharacterIdAnd",
				Value = 
				{
					220001,
					220002,
				},
			},
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
EventConfig[EventID.Id220] =
{
	Id = 220,
	Name = "鱼子盖饭",
	Gallery = 950002,
	Area = 130056,
	LockDesc = "解锁提示\n一次性探索风味镇1天\n(需要呜呜和漆漆)",
	Desc = "去了当地出名的鱼子盖饭店，不喊停的话老板就会一直在饭上加鱼子。大家都适可而止了，不过呜呜和漆漆一直坚持住没有喊停。",
	Bundle = "packed_event_fat",
	Atlas = "Event_FAT",
	Icon = "FAT_Event_27",
	TriggerCondition = {
		NeedExploreTime = 86400,
		ConditionList = {
			{
				Condition = "TeamCharacterIdAnd",
				Value = 
				{
					220001,
					220002,
				},
			},
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
EventConfig[EventID.Id221] =
{
	Id = 221,
	Name = "风水酱料",
	Gallery = 950002,
	Area = 130056,
	LockDesc = "解锁提示\n一次性探索风味镇1天\n(需要一位到了适婚年龄的女性)",
	Desc = "遇到了出来摆摊的有名的风水师傅，听说知道冥冥中的一切。汉堡小姐问了姻缘之后，大师说对象是一个涂黄芥末酱的英俊男性，只要坚持相亲就能遇到。",
	Bundle = "packed_event_fat",
	Atlas = "Event_FAT",
	Icon = "FAT_Event_28",
	TriggerCondition = {
		NeedExploreTime = 86400,
		ConditionList = {
			{
				Condition = "TeamCharacterIdAnd",
				Value = 
				{
					220126,
				},
			},
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
EventConfig[EventID.Id222] =
{
	Id = 222,
	Name = "分子料理",
	Gallery = 950002,
	Area = 130056,
	LockDesc = "解锁提示\n一次性探索风味镇18小时",
	Desc = "在有名的分子料理店吃了下午茶，吃了用肉做成的肉，用巧克力做成的巧克力，还有用汽水做成的汽水~但价格比普通套餐贵了一倍……",
	Bundle = "packed_event_fat",
	Atlas = "Event_FAT",
	Icon = "FAT_Event_29",
	TriggerCondition = {
		NeedExploreTime = 64800,
	},
	Reward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
EventConfig[EventID.Id223] =
{
	Id = 223,
	Name = "古老的传说",
	Gallery = 950002,
	Area = 130057,
	LockDesc = "解锁提示\n一次性探索饭团镇18小时\n(需要三位拥有魔力的仙子)",
	Desc = "听说曾经有位大魔王来到美食星，不过被饭团镇里最强大的饭团师傅使用一个神器封锁了。大师拆迁搬走后，那个封印着大魔王的神器也不知去了哪里。",
	Bundle = "packed_event_fat",
	Atlas = "Event_FAT",
	Icon = "FAT_Event_32",
	TriggerCondition = {
		NeedExploreTime = 64800,
		ConditionList = {
			{
				Condition = "TeamCharacterIdAnd",
				Value = 
				{
					220114,
					220115,
					220116,
				},
			},
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
EventConfig[EventID.Id224] =
{
	Id = 224,
	Name = "仙灵魔法",
	Gallery = 950002,
	Area = 130057,
	LockDesc = "解锁提示\n一次性探索饭团镇18小时\n(需要三位拥有魔力的仙子)",
	Desc = "受到魔力的指引，在镇郊的一口井底发现了一个奇怪的电饭煲。据说电饭煲在用大家听不到的声音和仙子们说话噢！",
	Bundle = "packed_event_fat",
	Atlas = "Event_FAT",
	Icon = "FAT_Event_33",
	TriggerCondition = {
		NeedExploreTime = 64800,
		ConditionList = {
			{
				Condition = "TeamCharacterIdAnd",
				Value = 
				{
					220114,
					220115,
					220116,
				},
			},
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
EventConfig[EventID.Id225] =
{
	Id = 225,
	Name = "饭团雕塑展",
	Gallery = 950002,
	Area = 130057,
	LockDesc = "解锁提示\n一次性探索饭团镇16小时",
	Desc = "遇到了一年一度的饭团雕塑节，各家小店的师傅都拿出了看家本领，制作了非常壮观的饭团雕塑。如果拿到第一名的话，雕像就会被当作饭团镇的象征摆在镇子门口，非常风光。",
	Bundle = "packed_event_fat",
	Atlas = "Event_FAT",
	Icon = "FAT_Event_30",
	TriggerCondition = {
		NeedExploreTime = 57600,
	},
	Reward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
EventConfig[EventID.Id226] =
{
	Id = 226,
	Name = "丢饭团大赛",
	Gallery = 950002,
	Area = 130057,
	LockDesc = "解锁提示\n一次性探索饭团镇14小时",
	Desc = "在饭团镇的丢饭团大战上报了名，双方互相投掷饭团，最后哪边身上粘的饭团少就是赢家。输的人要把粘在身上的饭团都吃光！",
	Bundle = "packed_event_fat",
	Atlas = "Event_FAT",
	Icon = "FAT_Event_31",
	TriggerCondition = {
		NeedExploreTime = 50400,
	},
	Reward = {
		{
			Value = 321206,
			Num = 20,
		},
	},
}
EventConfig[EventID.Id227] =
{
	Id = 227,
	Name = "苦涩的回忆",
	Gallery = 950002,
	Area = 130058,
	LockDesc = "解锁提示\n一次性探索煮物镇18小时\n(需要来自流亡街的黑暗料理界传人)",
	Desc = "走过一个荒废已久的小店时，料理大师说当初他就是在这里卖爆煮榴莲的，虽然生意不好，而且经常接到投诉，但是能够有自己的小店真的很开心。",
	Bundle = "packed_event_fat",
	Atlas = "Event_FAT",
	Icon = "FAT_Event_40",
	TriggerCondition = {
		NeedExploreTime = 64800,
		ConditionList = {
			{
				Condition = "TeamCharacterIdAnd",
				Value = 
				{
					222001,
				},
			},
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
EventConfig[EventID.Id228] =
{
	Id = 228,
	Name = "喝可乐送CD",
	Gallery = 950002,
	Area = 130058,
	LockDesc = "解锁提示\n一次性探索煮物镇18小时\n(需要代表着爽快甜腻的饮料的王子)",
	Desc = "可乐王子带大家去附近的唱片店买了3张他的新曲CD，专辑名叫《一个人的爱情》，CD封面是可乐王子本人的特写。这种叼玫瑰的方式一度成为了美食星最流行的审美。",
	Bundle = "packed_event_fat",
	Atlas = "Event_FAT",
	Icon = "FAT_Event_16",
	TriggerCondition = {
		NeedExploreTime = 64800,
		ConditionList = {
			{
				Condition = "TeamCharacterIdAnd",
				Value = 
				{
					220103,
				},
			},
		},
	},
	Reward = {
		{
			Value = 320520,
			Num = 1,
		},
	},
}
EventConfig[EventID.Id229] =
{
	Id = 229,
	Name = "大型演唱会",
	Gallery = 950002,
	Area = 130058,
	LockDesc = "解锁提示\n一次性探索煮物镇16小时\n(需要守护美食星皇室的卫士)",
	Desc = "王子即将举办今年的第32场演唱会。发现游客和镇民都兴致缺缺。番茄酱侍卫主动为可乐王子进行宣传，希望附近的居民都买10张演唱会门票支持王子。",
	Bundle = "packed_event_fat",
	Atlas = "Event_FAT",
	Icon = "FAT_Event_17",
	TriggerCondition = {
		NeedExploreTime = 57600,
		ConditionList = {
			{
				Condition = "TeamCharacterIdAnd",
				Value = 
				{
					220128,
				},
			},
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
EventConfig[EventID.Id230] =
{
	Id = 230,
	Name = "路边摊",
	Gallery = 950002,
	Area = 130058,
	LockDesc = "解锁提示\n一次性探索煮物镇16小时\n(需要松软可口的公主)",
	Desc = "经过香气四溢的煮物街时，蛋糕公主回忆起和可乐王子在路边摊吃美食的场景。虽然和自己优雅的公主气质不符，但却是一段很难忘的回忆。",
	Bundle = "packed_event_fat",
	Atlas = "Event_FAT",
	Icon = "FAT_Event_38",
	TriggerCondition = {
		NeedExploreTime = 57600,
		ConditionList = {
			{
				Condition = "TeamCharacterIdAnd",
				Value = 
				{
					220124,
				},
			},
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
EventConfig[EventID.Id231] =
{
	Id = 231,
	Name = "篝火晚会",
	Gallery = 950002,
	Area = 130058,
	LockDesc = "解锁提示\n一次性探索煮物镇16小时",
	Desc = "为庆祝煮物镇的美食销量破亿，小镇举办了篝火晚会招待路过的游客。将点燃回收的竹签作为柴禾。",
	Bundle = "packed_event_fat",
	Atlas = "Event_FAT",
	Icon = "FAT_Event_41",
	TriggerCondition = {
		NeedExploreTime = 57600,
	},
	Reward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
EventConfig[EventID.Id232] =
{
	Id = 232,
	Name = "回转摩天轮",
	Gallery = 950002,
	Area = 130059,
	LockDesc = "解锁提示\n一次性探索寿司镇16小时",
	Desc = "为了吸引更多外星游客，寿司店们合资建立了超大的回转摩天轮。食客可以一边享受高空的美景，一边吃轿厢内自动加工成的食物，很方便噢~~",
	Bundle = "packed_event_fat",
	Atlas = "Event_FAT",
	Icon = "FAT_Event_37",
	TriggerCondition = {
		NeedExploreTime = 57600,
	},
	Reward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
EventConfig[EventID.Id233] =
{
	Id = 233,
	Name = "致命芥末",
	Gallery = 950002,
	Area = 130059,
	LockDesc = "解锁提示\n一次性探索寿司镇16小时",
	Desc = "镇上的芥末公司推出了史上最强芥末，已致千名食客紧急送医。美食星王室已派军方介入，将其所属权没收，并列为仅限军方使用。",
	Bundle = "packed_event_fat",
	Atlas = "Event_FAT",
	Icon = "FAT_Event_36",
	TriggerCondition = {
		NeedExploreTime = 57600,
	},
	Reward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
EventConfig[EventID.Id234] =
{
	Id = 234,
	Name = "醋饭马拉松",
	Gallery = 950002,
	Area = 130059,
	LockDesc = "解锁提示\n一次性探索寿司镇14小时",
	Desc = "为了保持居民的健康，镇政府号召所有醋饭一起报名参加马拉松运动。参赛者们身上的酸醋味熏得游客无法呼吸……不过镇政府特地为大家准备了鼻塞。",
	Bundle = "packed_event_fat",
	Atlas = "Event_FAT",
	Icon = "FAT_Event_42",
	TriggerCondition = {
		NeedExploreTime = 50400,
	},
	Reward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
EventConfig[EventID.Id235] =
{
	Id = 235,
	Name = "海鲜展览",
	Gallery = 950002,
	Area = 130059,
	LockDesc = "解锁提示\n一次性探索寿司镇14小时",
	Desc = "寿司镇的水族馆迎来了新的展出品。是由外星冒险者们从他们的母星带来的超大火山巨蟹，怪物强大的气势令游客们叹为观止。",
	Bundle = "packed_event_fat",
	Atlas = "Event_FAT",
	Icon = "FAT_Event_43",
	TriggerCondition = {
		NeedExploreTime = 50400,
	},
	Reward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
EventConfig[EventID.Id236] =
{
	Id = 236,
	Name = "变态辣翅！",
	Gallery = 950002,
	Area = 130060,
	LockDesc = "解锁提示\n一次性探索烤肉镇16小时\n(需要精通鸡翅料理的女性)",
	Desc = "来到快餐街就一定要挑战一下变态辣翅，一口气吃10个即享免单！听说今天已经有60位挑战者被抬走了。政府相关部门已在研究辣椒控制法案的出台。",
	Bundle = "packed_event_fat",
	Atlas = "Event_FAT",
	Icon = "FAT_Event_8",
	TriggerCondition = {
		NeedExploreTime = 57600,
		ConditionList = {
			{
				Condition = "TeamCharacterIdAnd",
				Value = 
				{
					220129,
				},
			},
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
EventConfig[EventID.Id237] =
{
	Id = 237,
	Name = "顶层餐厅",
	Gallery = 950002,
	Area = 130060,
	LockDesc = "解锁提示\n一次性探索烤肉镇16小时\n(需要代表着忘却烦恼的饮料的王子)",
	Desc = "啤酒王子带着大家去了镇上最高级的烤肉餐厅，顶楼只有VVIP才能进入。不过大家都穿着西装，在这里拿着肉叉烤肉，感觉真是奇怪啊……",
	Bundle = "packed_event_fat",
	Atlas = "Event_FAT",
	Icon = "FAT_Event_35",
	TriggerCondition = {
		NeedExploreTime = 57600,
		ConditionList = {
			{
				Condition = "TeamCharacterIdAnd",
				Value = 
				{
					220104,
				},
			},
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
EventConfig[EventID.Id238] =
{
	Id = 238,
	Name = "相亲失败",
	Gallery = 950002,
	Area = 130060,
	LockDesc = "解锁提示\n一次性探索烤肉镇14小时\n(需要一位到了适婚年龄的男性)",
	Desc = "遇到了出来摆摊的有名的算命商人，据说看一眼就能知道一切。热狗先生问了姻缘后，先生说对象是一个喜欢生菜和沙拉酱的美丽女性，只要坚持相亲就能遇到。",
	Bundle = "packed_event_fat",
	Atlas = "Event_FAT",
	Icon = "FAT_Event_46",
	TriggerCondition = {
		NeedExploreTime = 50400,
		ConditionList = {
			{
				Condition = "TeamCharacterIdAnd",
				Value = 
				{
					220127,
				},
			},
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
EventConfig[EventID.Id239] =
{
	Id = 239,
	Name = "进口化妆品",
	Gallery = 950002,
	Area = 130060,
	LockDesc = "解锁提示\n一次性探索烤肉镇14小时\n(需要一位了解五花肉的女巫)",
	Desc = "路过烤肉镇的大型商场时，化妆品专柜的小姐向培根女巫推荐了外星进口的高级化妆品，可以让女巫的皮肤变得非常嫩滑。不过培根女巫一眼认出这个只是“嫩肉粉”！",
	Bundle = "packed_event_fat",
	Atlas = "Event_FAT",
	Icon = "FAT_Event_44",
	TriggerCondition = {
		NeedExploreTime = 50400,
		ConditionList = {
			{
				Condition = "TeamCharacterIdAnd",
				Value = 
				{
					220119,
				},
			},
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
EventConfig[EventID.Id240] =
{
	Id = 240,
	Name = "啤酒喷泉！",
	Gallery = 950002,
	Area = 130060,
	LockDesc = "解锁提示\n一次性探索烤肉镇12小时",
	Desc = "听说著名的啤酒喷泉马上就要开始了，一路狂奔，终于赶上了喷泉喷出的那一刻。现场各品牌啤酒都免费畅饮，大家度过了快乐的夜晚。微醺的主持人还不忘提醒大家回去路上喝车不开酒噢~",
	Bundle = "packed_event_fat",
	Atlas = "Event_FAT",
	Icon = "FAT_Event_13",
	TriggerCondition = {
		NeedExploreTime = 43200,
	},
	Reward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
EventConfig[EventID.Id241] =
{
	Id = 241,
	Name = "话剧大会",
	Gallery = 950002,
	Area = 130060,
	LockDesc = "解锁提示\n一次性探索烤肉镇10小时",
	Desc = "在路上收到了美食城话剧节表演目录。上演的剧目是《我的艺术奋斗》，由啤酒王子连续演出18场，听说本地居民被强制要求参加，但是有工资拿噢~",
	Bundle = "packed_event_fat",
	Atlas = "Event_FAT",
	Icon = "FAT_Event_18",
	TriggerCondition = {
		NeedExploreTime = 36000,
	},
	Reward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
EventConfig[EventID.Id242] =
{
	Id = 242,
	Name = "地下恋情",
	Gallery = 950002,
	Area = 130060,
	LockDesc = "解锁提示\n一次性探索烤肉镇8小时",
	Desc = "蝉联3年“本地人气王子”的啤酒王子日前被目击与蛋糕卷公主相挽逛街。据称，两人神态亲密，举止亲昵。在发现本刊记者偷拍后，慌张地离开了现场。",
	Bundle = "packed_event_fat",
	Atlas = "Event_FAT",
	Icon = "FAT_Event_45",
	TriggerCondition = {
		NeedExploreTime = 28800,
	},
	Reward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
EventConfig[EventID.Id243] =
{
	Id = 243,
	Name = "大胃王比赛",
	Gallery = 950002,
	Area = 130061,
	LockDesc = "解锁提示\n一次性探索香浓镇10小时\n(需要一位喜欢汉堡的男性和一位守护王室荣耀的卫士)",
	Desc = "正好遇见在快餐街举办的大胃王大赛，热狗先生和番茄酱侍卫两人将对决年度冠军，不过都已经吃得翻白眼了……",
	Bundle = "packed_event_fat",
	Atlas = "Event_FAT",
	Icon = "FAT_Event_9",
	TriggerCondition = {
		NeedExploreTime = 36000,
		ConditionList = {
			{
				Condition = "TeamCharacterIdAnd",
				Value = 
				{
					220127,
					220128,
				},
			},
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
EventConfig[EventID.Id244] =
{
	Id = 244,
	Name = "新车发布会",
	Gallery = 950002,
	Area = 130061,
	LockDesc = "解锁提示\n一次性探索香浓镇10小时\n(需要美食星四位名车爱好者)",
	Desc = "一年一度的名车展在香浓镇举办。看到新款超跑的王子们立刻忘记了去宇宙冒险的理想，最后大家只好把他们打晕了带走。",
	Bundle = "packed_event_fat",
	Atlas = "Event_FAT",
	Icon = "FAT_Event_39",
	TriggerCondition = {
		NeedExploreTime = 36000,
		ConditionList = {
			{
				Condition = "TeamCharacterIdAnd",
				Value = 
				{
					220101,
					220102,
					220103,
					220104,
				},
			},
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
EventConfig[EventID.Id245] =
{
	Id = 245,
	Name = "新纪录诞生！",
	Gallery = 950002,
	Area = 130061,
	LockDesc = "解锁提示\n一次性探索香浓镇10小时\n(需要酷爱健身的王室人物)",
	Desc = "全宇宙最硬核的健身节目“星球达人”正在美食星寻找能够举起“史上最重杠铃”的大力士，使用特制金属制成，单片重达1吨。在连续挑战8片、10片后，薯条国王涨红了脸完成了史无前例的12片！",
	Bundle = "packed_event_fat",
	Atlas = "Event_FAT",
	Icon = "FAT_Event_48",
	TriggerCondition = {
		NeedExploreTime = 36000,
		ConditionList = {
			{
				Condition = "TeamCharacterIdAnd",
				Value = 
				{
					220131,
				},
			},
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
EventConfig[EventID.Id246] =
{
	Id = 246,
	Name = "荣归故里",
	Gallery = 950002,
	Area = 130061,
	LockDesc = "解锁提示\n一次性探索香浓镇10小时\n(需要气质优雅，受人欢迎的夫人)",
	Desc = "来到了薯片夫人的故乡~作为前任皇室御用主播，薯片夫人在故乡的人气非同凡响~沿途的小土豆们都围在她身边，要求签名并表示希望也成为薯片。她却摇头谦虚地说时代进步，油炸食品不健康。",
	Bundle = "packed_event_fat",
	Atlas = "Event_FAT",
	Icon = "FAT_Event_47",
	TriggerCondition = {
		NeedExploreTime = 36000,
		ConditionList = {
			{
				Condition = "TeamCharacterIdAnd",
				Value = 
				{
					220120,
				},
			},
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
EventConfig[EventID.Id247] =
{
	Id = 247,
	Name = "烟花盛典",
	Gallery = 950002,
	Area = 130061,
	LockDesc = "解锁提示\n一次性探索香浓镇10小时",
	Desc = "遇上了只在特定日期举办的烟花盛典。缤纷绚烂的烟花，点亮了清澈的夜空，给大家留下了非常难忘的回忆。",
	Bundle = "packed_event_fat",
	Atlas = "Event_FAT",
	Icon = "FAT_Event_11",
	TriggerCondition = {
		NeedExploreTime = 36000,
	},
	Reward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
EventConfig[EventID.Id248] =
{
	Id = 248,
	Name = "国王酒店的大餐",
	Gallery = 950002,
	Area = 130061,
	LockDesc = "解锁提示\n一次性探索香浓镇10小时",
	Desc = "在有名的国王酒店吃了顿大餐，拿到账单以后，决定先悄悄溜走。临走前留下了字条——“费用我们下次会来结清的。”",
	Bundle = "packed_event_fat",
	Atlas = "Event_FAT",
	Icon = "FAT_Event_10",
	TriggerCondition = {
		NeedExploreTime = 36000,
	},
	Reward = {
		{
			Value = 320521,
			Num = 1,
		},
	},
}
EventConfig[EventID.Id401] =
{
	Id = 401,
	Name = "入馆须知 1",
	Gallery = 950003,
	Area = 130102,
	LockDesc = "解锁提示\n一次性探索入口大厅1天\n(需要呜呜和漆漆)",
	Desc = "虽然再三解释，呜呜和漆漆和一般宠物不一样，但是保安还是坚持要把它们装在特制的宠物笼里才能放行。",
	Bundle = "packed_event_mus",
	Atlas = "Event_MUS",
	Icon = "MUS_Event_5",
	TriggerCondition = {
		NeedExploreTime = 86400,
		ConditionList = {
			{
				Condition = "TeamCharacterIdAnd",
				Value = 
				{
					220001,
					220002,
				},
			},
		},
	},
}
EventConfig[EventID.Id402] =
{
	Id = 402,
	Name = "招聘解说人员",
	Gallery = 950003,
	Area = 130102,
	LockDesc = "解锁提示\n一次性探索入口大厅1天",
	Desc = "在游客们的要求下，馆长先生决定招聘一位解说员。经过多轮内部投票，最终驳回了男员工穿女装的方案，决定招聘一名女解说员缓解一下博物馆日常苦闷的气氛。",
	Bundle = "packed_event_mus",
	Atlas = "Event_MUS",
	Icon = "MUS_Event_24",
	TriggerCondition = {
		NeedExploreTime = 86400,
	},
}
EventConfig[EventID.Id403] =
{
	Id = 403,
	Name = "禁止宠物！",
	Gallery = 950003,
	Area = 130102,
	LockDesc = "解锁提示\n一次性探索入口大厅1天",
	Desc = "这是石像们本月第10次联名抗议，有宠物狗在它们身上尿尿！一向好脾气的默艾也要求保安必须严惩带宠物参观的游客！",
	Bundle = "packed_event_mus",
	Atlas = "Event_MUS",
	Icon = "MUS_Event_22",
	TriggerCondition = {
		NeedExploreTime = 86400,
	},
	Reward = {
		{
			Value = 320528,
			Num = 1,
		},
	},
}
EventConfig[EventID.Id404] =
{
	Id = 404,
	Name = "逃票的游客？",
	Gallery = 950003,
	Area = 130102,
	LockDesc = "解锁提示\n一次性探索入口大厅1天\n(需要一位维持博物馆治安的角色)",
	Desc = "遇到三个套着画框的小浣熊，说自己是参展名画。上前查询身份时，他们改口说自己是游客，检查门票时，他们又拿不出来。",
	Bundle = "packed_event_mus",
	Atlas = "Event_MUS",
	Icon = "MUS_Event_10",
	TriggerCondition = {
		NeedExploreTime = 86400,
		ConditionList = {
			{
				Condition = "TeamCharacterIdAnd",
				Value = 
				{
					220201,
				},
			},
		},
	},
}
EventConfig[EventID.Id405] =
{
	Id = 405,
	Name = "怪盗的挑战函",
	Gallery = 950003,
	Area = 130103,
	LockDesc = "解锁提示\n一次性探索中心广场1天\n(需要一位优雅又神秘的男子，或许他就是怪盗？)",
	Desc = "路过中心广场时，魔术师说有点事要去办。回来时，墙上多了挑战函：“在月与日交替之时，我将带走画中的美丽少女。——怪盗27号先生”",
	Bundle = "packed_event_mus",
	Atlas = "Event_MUS",
	Icon = "MUS_Event_1",
	TriggerCondition = {
		NeedExploreTime = 86400,
		ConditionList = {
			{
				Condition = "TeamCharacterIdAnd",
				Value = 
				{
					220227,
				},
			},
		},
	},
}
EventConfig[EventID.Id406] =
{
	Id = 406,
	Name = "成年礼",
	Gallery = 950003,
	Area = 130103,
	LockDesc = "解锁提示\n一次性探索中心广场1天\n(需要最初的人类)",
	Desc = "为庆祝亚当来到博物馆100周年，馆内工作人员为亚当重新量取了身高，并且赠送了特制小礼物——直尺。",
	Bundle = "packed_event_mus",
	Atlas = "Event_MUS",
	Icon = "MUS_Event_11",
	TriggerCondition = {
		NeedExploreTime = 86400,
		ConditionList = {
			{
				Condition = "TeamCharacterIdAnd",
				Value = 
				{
					220210,
				},
			},
		},
	},
	Reward = {
		{
			Value = 320523,
			Num = 1,
		},
	},
}
EventConfig[EventID.Id407] =
{
	Id = 407,
	Name = "入馆须知 2",
	Gallery = 950003,
	Area = 130103,
	LockDesc = "解锁提示\n一次性探索中心广场1天",
	Desc = "告示上写着“请勿触摸”，反而忍不住更想要摸摸看了，不过保安立刻出现并且向我们出示了黄牌警告。",
	Bundle = "packed_event_mus",
	Atlas = "Event_MUS",
	Icon = "MUS_Event_6",
	TriggerCondition = {
		NeedExploreTime = 86400,
	},
}
EventConfig[EventID.Id408] =
{
	Id = 408,
	Name = "圣光",
	Gallery = 950003,
	Area = 130103,
	LockDesc = "解锁提示\n一次性探索中心广场20小时\n(需要一位为世界带来一切的角色)",
	Desc = "博物馆迎来了从遥远星球来的牧师观光团。严肃的牧师们认真地参观着每一件历史名作。当创世神走过他们面前时，他们揉了揉眼睛，立刻唱起了圣歌。",
	Bundle = "packed_event_mus",
	Atlas = "Event_MUS",
	Icon = "MUS_Event_27",
	TriggerCondition = {
		NeedExploreTime = 72000,
		ConditionList = {
			{
				Condition = "TeamCharacterIdAnd",
				Value = 
				{
					220211,
				},
			},
		},
	},
}
EventConfig[EventID.Id409] =
{
	Id = 409,
	Name = "大额捐款",
	Gallery = 950003,
	Area = 130103,
	LockDesc = "解锁提示\n一次性探索中心广场16小时",
	Desc = "每个外星游客都有可能是隐形的超级富豪，一个低调的小浣熊向博物馆捐献了100万金币，希望帮助博物馆文物们改善生活。",
	Bundle = "packed_event_mus",
	Atlas = "Event_MUS",
	Icon = "MUS_Event_25",
	TriggerCondition = {
		NeedExploreTime = 57600,
	},
	Reward = {
		{
			Value = 320529,
			Num = 1,
		},
	},
}
EventConfig[EventID.Id410] =
{
	Id = 410,
	Name = "新的储蓄罐",
	Gallery = 950003,
	Area = 130104,
	LockDesc = "解锁提示\n一次性探索文物厅16小时\n(需要一位擅长捕兽的原始人)",
	Desc = "虽然原始人妈妈查得很严，不过爸爸还是攒下了两罐私房钱。听说文物厅有猪罐出没，原始人爸爸又一次开始了狩猎的旅程，打算物色个新罐子！",
	Bundle = "packed_event_mus",
	Atlas = "Event_MUS",
	Icon = "MUS_Event_28",
	TriggerCondition = {
		NeedExploreTime = 57600,
		ConditionList = {
			{
				Condition = "TeamCharacterIdAnd",
				Value = 
				{
					220214,
				},
			},
		},
	},
}
EventConfig[EventID.Id411] =
{
	Id = 411,
	Name = "编钟合奏",
	Gallery = 950003,
	Area = 130104,
	LockDesc = "解锁提示\n一次性探索文物厅12小时\n(需要呜呜和漆漆)",
	Desc = "深夜的时候，大大小小的编钟们排在一起，按照曲谱演奏着。虽然旋律不如现代乐器那么多变，但有种独特的韵律，连呜呜和漆漆都很安静地听着。",
	Bundle = "packed_event_mus",
	Atlas = "Event_MUS",
	Icon = "MUS_Event_46",
	TriggerCondition = {
		NeedExploreTime = 43200,
		ConditionList = {
			{
				Condition = "TeamCharacterIdAnd",
				Value = 
				{
					220001,
					220002,
				},
			},
		},
	},
}
EventConfig[EventID.Id412] =
{
	Id = 412,
	Name = "奇怪的脚印",
	Gallery = 950003,
	Area = 130104,
	LockDesc = "解锁提示\n一次性探索文物厅12小时\n(需要一位维持博物馆治安的角色)",
	Desc = "每天早上检查博物馆的时候，门口都会发现很多奇怪的脚印，跟着脚印走，发现走廊尽头的杂物间里竟然被挖了一个超级大的洞。",
	Bundle = "packed_event_mus",
	Atlas = "Event_MUS",
	Icon = "MUS_Event_12",
	TriggerCondition = {
		NeedExploreTime = 43200,
		ConditionList = {
			{
				Condition = "TeamCharacterIdAnd",
				Value = 
				{
					220201,
				},
			},
		},
	},
}
EventConfig[EventID.Id413] =
{
	Id = 413,
	Name = "奇怪的文物",
	Gallery = 950003,
	Area = 130104,
	LockDesc = "解锁提示\n一次性探索文物厅8小时",
	Desc = "博物馆新来了一个奇特的瓷瓶，听说使用了十七种釉彩制法。虽然第一眼看有种微妙的不和谐感，不过制作过程确实挑战了瓷器制作的新高度，大概不失为一种技法上的突破。",
	Bundle = "packed_event_mus",
	Atlas = "Event_MUS",
	Icon = "MUS_Event_47",
	TriggerCondition = {
		NeedExploreTime = 28800,
	},
}
EventConfig[EventID.Id414] =
{
	Id = 414,
	Name = "仿制品",
	Gallery = 950003,
	Area = 130105,
	LockDesc = "解锁提示\n一次性探索修复室1天",
	Desc = "得到馆长许可后，名画们被允许外出探险。不在馆内展览期间，修复室的工作人员就必须制作出对应的仿制品，来满足游客观看名画的需要。",
	Bundle = "packed_event_mus",
	Atlas = "Event_MUS",
	Icon = "MUS_Event_48",
	TriggerCondition = {
		NeedExploreTime = 86400,
	},
}
EventConfig[EventID.Id415] =
{
	Id = 415,
	Name = "一级警报",
	Gallery = 950003,
	Area = 130105,
	LockDesc = "解锁提示\n一次性探索修复室1天\n(需要一位经常失窃且魅力无穷的名画角色)",
	Desc = "发现微笑女神又一次失踪后，博物馆拉响了一级警报。警察们接报火速抵达现场，发誓要抓到27号先生。大家都在忙碌时，微笑女神和探险队一起经过了案发现场……",
	Bundle = "packed_event_mus",
	Atlas = "Event_MUS",
	Icon = "MUS_Event_49",
	TriggerCondition = {
		NeedExploreTime = 86400,
		ConditionList = {
			{
				Condition = "TeamCharacterIdAnd",
				Value = 
				{
					220226,
				},
			},
		},
	},
}
EventConfig[EventID.Id416] =
{
	Id = 416,
	Name = "这个怎么回事？",
	Gallery = 950003,
	Area = 130105,
	LockDesc = "解锁提示\n一次性探索修复室1天\n(需要一位只有一只耳朵的名画角色)",
	Desc = "经过修复室时，工作人员叫住了独耳画像。反复检查后，他们也搞不清楚缺掉的耳朵究竟是损坏了，还是原作就是这样。",
	Bundle = "packed_event_mus",
	Atlas = "Event_MUS",
	Icon = "MUS_Event_50",
	TriggerCondition = {
		NeedExploreTime = 86400,
		ConditionList = {
			{
				Condition = "TeamCharacterIdAnd",
				Value = 
				{
					220224,
				},
			},
		},
	},
}
EventConfig[EventID.Id417] =
{
	Id = 417,
	Name = "餐具配对会",
	Gallery = 950003,
	Area = 130105,
	LockDesc = "解锁提示\n一次性探索修复室20小时",
	Desc = "由馆方专门为左半碗和右半碗举办的年度脱单大会。只要双方能严丝合缝地贴起来就意味着找到“另一半”了。",
	Bundle = "packed_event_mus",
	Atlas = "Event_MUS",
	Icon = "MUS_Event_14",
	TriggerCondition = {
		NeedExploreTime = 72000,
	},
	Reward = {
		{
			Value = 320525,
			Num = 1,
		},
	},
}
EventConfig[EventID.Id418] =
{
	Id = 418,
	Name = "事故现场",
	Gallery = 950003,
	Area = 130105,
	LockDesc = "解锁提示\n一次性探索修复室16小时",
	Desc = "走在路上的时候，一个碰碰瓷突然跑出来，一边躺在地上一边喊，还问我们要赔偿。这时候机智的小伙伴拿出了行车记录仪，碰碰瓷立刻灰溜溜的跑了。",
	Bundle = "packed_event_mus",
	Atlas = "Event_MUS",
	Icon = "MUS_Event_13",
	TriggerCondition = {
		NeedExploreTime = 57600,
	},
}
EventConfig[EventID.Id419] =
{
	Id = 419,
	Name = "恐龙？宠物？",
	Gallery = 950003,
	Area = 130106,
	LockDesc = "解锁提示\n一次性探索生态园16小时\n(需要一位喜欢玩耍的原始人)",
	Desc = "在生态园探险时，遇到了从小和原始人儿子一起玩大的恐龙宝宝，如今已经长大了。两个人第一时间认出了对方，开心地打闹在一起。",
	Bundle = "packed_event_mus",
	Atlas = "Event_MUS",
	Icon = "MUS_Event_29",
	TriggerCondition = {
		NeedExploreTime = 57600,
		ConditionList = {
			{
				Condition = "TeamCharacterIdAnd",
				Value = 
				{
					220216,
				},
			},
		},
	},
}
EventConfig[EventID.Id420] =
{
	Id = 420,
	Name = "孵化中的恐龙蛋",
	Gallery = 950003,
	Area = 130106,
	LockDesc = "解锁提示\n一次性探索生态园12小时",
	Desc = "路过孵化室的时候听到里面有声响，透过玻璃罩，发现是一群新的恐龙宝宝孵化出来了。",
	Bundle = "packed_event_mus",
	Atlas = "Event_MUS",
	Icon = "MUS_Event_17",
	TriggerCondition = {
		NeedExploreTime = 43200,
	},
}
EventConfig[EventID.Id421] =
{
	Id = 421,
	Name = "美人鱼？",
	Gallery = 950003,
	Area = 130106,
	LockDesc = "解锁提示\n一次性探索生态园12小时",
	Desc = "路过超大的水族箱的时候，看到好像美人鱼的生物一闪而过，大家都很期待看到她正面的模样呢~",
	Bundle = "packed_event_mus",
	Atlas = "Event_MUS",
	Icon = "MUS_Event_21",
	TriggerCondition = {
		NeedExploreTime = 43200,
	},
}
EventConfig[EventID.Id422] =
{
	Id = 422,
	Name = "超级奶爸",
	Gallery = 950003,
	Area = 130106,
	LockDesc = "解锁提示\n一次性探索生态园8小时\n(需要一位维持博物馆治安的角色)",
	Desc = "大家都很喜欢刚出生的恐龙宝宝，但是它们非常调皮，每个都要保安抱着，保安一个人抱着四个小恐龙。",
	Bundle = "packed_event_mus",
	Atlas = "Event_MUS",
	Icon = "MUS_Event_18",
	TriggerCondition = {
		NeedExploreTime = 28800,
		ConditionList = {
			{
				Condition = "TeamCharacterIdAnd",
				Value = 
				{
					220201,
				},
			},
		},
	},
}
EventConfig[EventID.Id423] =
{
	Id = 423,
	Name = "锁定目标",
	Gallery = 950003,
	Area = 130107,
	LockDesc = "解锁提示\n一次性探索监控室1天12小时\n(需要一位观察力敏锐的女性侦探)",
	Desc = "博物馆又一次收到怪盗27号先生的挑战函，为了锁定目标，特意请侦探小姐帮忙查看监控。根据侦探小姐仔细观察，最后成功锁定了有嫌疑的1355人。",
	Bundle = "packed_event_mus",
	Atlas = "Event_MUS",
	Icon = "MUS_Event_30",
	TriggerCondition = {
		NeedExploreTime = 129600,
		ConditionList = {
			{
				Condition = "TeamCharacterIdAnd",
				Value = 
				{
					220202,
				},
			},
		},
	},
}
EventConfig[EventID.Id424] =
{
	Id = 424,
	Name = "防盗演习",
	Gallery = 950003,
	Area = 130107,
	LockDesc = "解锁提示\n一次性探索监控室1天12小时\n(需要一位身手卓绝的战士)",
	Desc = "为应对随时到来的怪盗先生，馆内从黑市买了一批报废的红外线报警装置。武士受邀来测试警报装置，不过还没有开始，警报器就自己乱响起来……",
	Bundle = "packed_event_mus",
	Atlas = "Event_MUS",
	Icon = "MUS_Event_31",
	TriggerCondition = {
		NeedExploreTime = 129600,
		ConditionList = {
			{
				Condition = "TeamCharacterIdAnd",
				Value = 
				{
					220228,
				},
			},
		},
	},
}
EventConfig[EventID.Id425] =
{
	Id = 425,
	Name = "不得了的发现",
	Gallery = 950003,
	Area = 130107,
	LockDesc = "解锁提示\n一次性探索监控室1天12小时",
	Desc = "翻看监控室的录像时，忽然发现了魔术师向微笑女神表白的录像。本以为看到的是令人心动的一幕，结果下一秒微笑女神就把花丢在地上离开了，原来是令人心碎的一幕。",
	Bundle = "packed_event_mus",
	Atlas = "Event_MUS",
	Icon = "MUS_Event_32",
	TriggerCondition = {
		NeedExploreTime = 129600,
	},
}
EventConfig[EventID.Id426] =
{
	Id = 426,
	Name = "疲劳的保安",
	Gallery = 950003,
	Area = 130107,
	LockDesc = "解锁提示\n一次性探索监控室1天",
	Desc = "打算向保安借手电筒时，发现他和报警装置都在呼呼大睡，于是只好自己悄悄取走了手电筒。",
	Bundle = "packed_event_mus",
	Atlas = "Event_MUS",
	Icon = "MUS_Event_7",
	TriggerCondition = {
		NeedExploreTime = 86400,
	},
	Reward = {
		{
			Value = 320524,
			Num = 1,
		},
	},
}
EventConfig[EventID.Id427] =
{
	Id = 427,
	Name = "尴尬的局面",
	Gallery = 950003,
	Area = 130108,
	LockDesc = "解锁提示\n一次性探索古文明厅1天\n(需要一位风干的角色)",
	Desc = "探索的时候，木乃伊说要去上厕所，出来时绷带被门夹住了，走了好一会儿，觉得屁股上凉飕飕的才发现……",
	Bundle = "packed_event_mus",
	Atlas = "Event_MUS",
	Icon = "MUS_Event_34",
	TriggerCondition = {
		NeedExploreTime = 86400,
		ConditionList = {
			{
				Condition = "TeamCharacterIdAnd",
				Value = 
				{
					220217,
				},
			},
		},
	},
}
EventConfig[EventID.Id428] =
{
	Id = 428,
	Name = "石柱科普",
	Gallery = 950003,
	Area = 130108,
	LockDesc = "解锁提示\n一次性探索古文明厅1天\n(需要一位了解古代石柱的石像角色)",
	Desc = "古文明厅接收了来自遥远星球的新展品——古典石柱。石柱人兴奋地为我们一一介绍，自己是多立克柱，新送来的分别是爱奥尼亚柱，科林斯柱和女郎雕像柱。",
	Bundle = "packed_event_mus",
	Atlas = "Event_MUS",
	Icon = "MUS_Event_33",
	TriggerCondition = {
		NeedExploreTime = 86400,
		ConditionList = {
			{
				Condition = "TeamCharacterIdAnd",
				Value = 
				{
					220208,
				},
			},
		},
	},
}
EventConfig[EventID.Id429] =
{
	Id = 429,
	Name = "故乡的兄弟",
	Gallery = 950003,
	Area = 130108,
	LockDesc = "解锁提示\n一次性探索古文明厅1天\n(需要一位守卫帝王陵寝的石像角色)",
	Desc = "从遥远星球送来了新的照片，宏大的坑道中排列着整齐的兵马俑。看了一会儿，兵马俑说，他想家了。",
	Bundle = "packed_event_mus",
	Atlas = "Event_MUS",
	Icon = "MUS_Event_45",
	TriggerCondition = {
		NeedExploreTime = 86400,
		ConditionList = {
			{
				Condition = "TeamCharacterIdAnd",
				Value = 
				{
					220207,
				},
			},
		},
	},
}
EventConfig[EventID.Id430] =
{
	Id = 430,
	Name = "完整的默艾",
	Gallery = 950003,
	Area = 130108,
	LockDesc = "解锁提示\n一次性探索古文明厅1天\n(需要一位守望在无名小岛上的石像角色)",
	Desc = "博物馆收到了新发掘的复活节岛石像，不过新的石像是跪着的。我们问默艾为什么姿势不一样时，话很少的默艾依然一言不发。",
	Bundle = "packed_event_mus",
	Atlas = "Event_MUS",
	Icon = "MUS_Event_35",
	TriggerCondition = {
		NeedExploreTime = 86400,
		ConditionList = {
			{
				Condition = "TeamCharacterIdAnd",
				Value = 
				{
					220206,
				},
			},
		},
	},
}
EventConfig[EventID.Id431] =
{
	Id = 431,
	Name = "火锅大会",
	Gallery = 950003,
	Area = 130108,
	LockDesc = "解锁提示\n一次性探索古文明厅1天",
	Desc = "调查的时候遇到瓷器们正在吃火锅，央求我们不要告诉保安，还给了我们很多玉璧。说是外星游客推荐的一种新式吃法，无论如何都想用瓷器来试试看。",
	Bundle = "packed_event_mus",
	Atlas = "Event_MUS",
	Icon = "MUS_Event_15",
	TriggerCondition = {
		NeedExploreTime = 86400,
	},
	Reward = {
		{
			Value = 2,
			Num = 200,
		},
	},
}
EventConfig[EventID.Id432] =
{
	Id = 432,
	Name = "决定命运的抓阄",
	Gallery = 950003,
	Area = 130108,
	LockDesc = "解锁提示\n一次性探索古文明厅18小时",
	Desc = "为了体现古文明厅的先进性，文物们决定自己负责打扫工作。关于厕所的包干区引起了争执，大家决定抓到最短签的来负责。对此陶面人表示不满，因为这里面只有他有鼻子。",
	Bundle = "packed_event_mus",
	Atlas = "Event_MUS",
	Icon = "MUS_Event_8",
	TriggerCondition = {
		NeedExploreTime = 64800,
	},
	Reward = {
		{
			Value = 320530,
			Num = 1,
		},
	},
}
EventConfig[EventID.Id433] =
{
	Id = 433,
	Name = "贝壳饰品",
	Gallery = 950003,
	Area = 130109,
	LockDesc = "解锁提示\n一次性探索化石厅1天\n(需要一对原始人夫妻)",
	Desc = "化石厅新增了一个贝壳展柜，形形色色的贝壳让大家目不暇接。看到漂亮的贝壳项链，原始人妈妈想让原始人爸爸买来送她，不过原始人爸爸在旁边扁着嘴一言不发。",
	Bundle = "packed_event_mus",
	Atlas = "Event_MUS",
	Icon = "MUS_Event_36",
	TriggerCondition = {
		NeedExploreTime = 86400,
		ConditionList = {
			{
				Condition = "TeamCharacterIdAnd",
				Value = 
				{
					220214,
					220215,
				},
			},
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
EventConfig[EventID.Id434] =
{
	Id = 434,
	Name = "收集癖",
	Gallery = 950003,
	Area = 130109,
	LockDesc = "解锁提示\n一次性探索化石厅1天\n(需要一个花心又专情的男性角色)",
	Desc = "有收集癖的猪蹄，原本打算为自己每个心爱的女孩送一枚特别的化石，不过收集了一百枚以后，却不舍得送出去了……",
	Bundle = "packed_event_mus",
	Atlas = "Event_MUS",
	Icon = "MUS_Event_37",
	TriggerCondition = {
		NeedExploreTime = 86400,
		ConditionList = {
			{
				Condition = "TeamCharacterIdAnd",
				Value = 
				{
					220219,
				},
			},
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
EventConfig[EventID.Id435] =
{
	Id = 435,
	Name = "警报！",
	Gallery = 950003,
	Area = 130109,
	LockDesc = "解锁提示\n一次性探索化石厅1天",
	Desc = "触发了警报系统，警铃声瞬间在无人的过道里狂响起来……感觉脑袋要爆炸了！大家一致决定剪掉电线……这下安保措施又要维修了。",
	Bundle = "packed_event_mus",
	Atlas = "Event_MUS",
	Icon = "MUS_Event_2",
	TriggerCondition = {
		NeedExploreTime = 86400,
	},
	Reward = {
		{
			Value = 320522,
			Num = 1,
		},
	},
}
EventConfig[EventID.Id436] =
{
	Id = 436,
	Name = "海星饰品",
	Gallery = 950003,
	Area = 130109,
	LockDesc = "解锁提示\n一次性探索化石厅1天\n(需要一位喜爱花卉又特立独行的名画角色)",
	Desc = "虽然弗里达最喜欢的是鲜花，但是化石厅里的古代海星化石也引起了她很大的兴趣，美丽的海星就如同海中的花朵一般。对此珊瑚们表示不满，他们认为海星抢走了自己的称号。",
	Bundle = "packed_event_mus",
	Atlas = "Event_MUS",
	Icon = "MUS_Event_38",
	TriggerCondition = {
		NeedExploreTime = 86400,
		ConditionList = {
			{
				Condition = "TeamCharacterIdAnd",
				Value = 
				{
					220225,
				},
			},
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
EventConfig[EventID.Id437] =
{
	Id = 437,
	Name = "修改碑文",
	Gallery = 950003,
	Area = 130110,
	LockDesc = "解锁提示\n一次性探索泥塑厅12小时\n(需要一位持有纷争匕首的埃及神)",
	Desc = "为了帮助游客更好地认识古埃及神话，馆方在泥塑厅竖起了石碑书写埃及神话故事。看到自己过去不光彩的历史，赛特趁大家不注意，把记录自己恶劣行为的石碑给带走了。",
	Bundle = "packed_event_mus",
	Atlas = "Event_MUS",
	Icon = "MUS_Event_39",
	TriggerCondition = {
		NeedExploreTime = 43200,
		ConditionList = {
			{
				Condition = "TeamCharacterIdAnd",
				Value = 
				{
					220220,
				},
			},
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
EventConfig[EventID.Id438] =
{
	Id = 438,
	Name = "第14块躯干",
	Gallery = 950003,
	Area = 130110,
	LockDesc = "解锁提示\n一次性探索泥塑厅10小时\n(需要一位持有沃斯手杖的埃及神)",
	Desc = "博物馆收到了新的展品，对方要价十亿金币，说是荷鲁斯父亲奥西里斯第14块躯干的泥塑。荷鲁斯非常激动，不过看了之后，他表示这块一定不是！",
	Bundle = "packed_event_mus",
	Atlas = "Event_MUS",
	Icon = "MUS_Event_41",
	TriggerCondition = {
		NeedExploreTime = 36000,
		ConditionList = {
			{
				Condition = "TeamCharacterIdAnd",
				Value = 
				{
					220222,
				},
			},
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
EventConfig[EventID.Id439] =
{
	Id = 439,
	Name = "驯养鳄神",
	Gallery = 950003,
	Area = 130110,
	LockDesc = "解锁提示\n一次性探索泥塑厅10小时\n(需要一位持有元素手杖的埃及神)",
	Desc = "为了还原古埃及的历史图景，博物馆购买了一条超大鳄鱼扮演鳄神。大家看到后都十分害怕，感觉那家伙的嘴巴一口下去可以咬断一切。不过那家伙看到索贝克时就十分温顺。",
	Bundle = "packed_event_mus",
	Atlas = "Event_MUS",
	Icon = "MUS_Event_40",
	TriggerCondition = {
		NeedExploreTime = 36000,
		ConditionList = {
			{
				Condition = "TeamCharacterIdAnd",
				Value = 
				{
					220221,
				},
			},
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
EventConfig[EventID.Id440] =
{
	Id = 440,
	Name = "重现神迹",
	Gallery = 950003,
	Area = 130110,
	LockDesc = "解锁提示\n一次性探索泥塑厅8小时\n(需要一位持有丰饶手杖的埃及神)",
	Desc = "博物馆本周收到5000金币的捐款，馆长让文物们讨论该拨给哪个厅。阿努比斯立刻拿出了沙漠展厅的蓝图，包括一座占地529万平方米的真实比例金字塔。",
	Bundle = "packed_event_mus",
	Atlas = "Event_MUS",
	Icon = "MUS_Event_26",
	TriggerCondition = {
		NeedExploreTime = 28800,
		ConditionList = {
			{
				Condition = "TeamCharacterIdAnd",
				Value = 
				{
					220223,
				},
			},
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
EventConfig[EventID.Id441] =
{
	Id = 441,
	Name = "抽象？",
	Gallery = 950003,
	Area = 130110,
	LockDesc = "解锁提示\n一次性探索泥塑厅8小时\n(需要一位使用抽象几何构成的名画角色)",
	Desc = "艺术的形式多种多样，有些虽然我们无法理解，但却是某些人的心境表达。哭泣的女人看着奇怪的人鱼泥塑，陷入了这样的沉思。",
	Bundle = "packed_event_mus",
	Atlas = "Event_MUS",
	Icon = "MUS_Event_42",
	TriggerCondition = {
		NeedExploreTime = 28800,
		ConditionList = {
			{
				Condition = "TeamCharacterIdAnd",
				Value = 
				{
					220212,
				},
			},
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
EventConfig[EventID.Id442] =
{
	Id = 442,
	Name = "人见人爱",
	Gallery = 950003,
	Area = 130111,
	LockDesc = "解锁提示\n一次性探索恐龙馆1天12小时\n(需要一位美丽动人的少女名画角色)",
	Desc = "人见人爱的珍珠少女即使来到恐龙馆也受到了欢迎。暴躁的恐龙们在珍珠少女身边时变得温顺起来，依偎在她旁边，还会把她丢出去的珍珠捡回来。",
	Bundle = "packed_event_mus",
	Atlas = "Event_MUS",
	Icon = "MUS_Event_43",
	TriggerCondition = {
		NeedExploreTime = 129600,
		ConditionList = {
			{
				Condition = "TeamCharacterIdAnd",
				Value = 
				{
					220218,
				},
			},
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
EventConfig[EventID.Id443] =
{
	Id = 443,
	Name = "恐龙复活啦！！！",
	Gallery = 950003,
	Area = 130111,
	LockDesc = "解锁提示\n一次性探索恐龙馆1天\n(需要一位看到画面就忍不住大声喊出来的名画角色)",
	Desc = "容易情绪激动的呐喊家，看到巨大的恐龙后，忍不住大声地叫喊起来。大家好不容易才让他平复下来。",
	Bundle = "packed_event_mus",
	Atlas = "Event_MUS",
	Icon = "MUS_Event_44",
	TriggerCondition = {
		NeedExploreTime = 86400,
		ConditionList = {
			{
				Condition = "TeamCharacterIdAnd",
				Value = 
				{
					220213,
				},
			},
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
EventConfig[EventID.Id444] =
{
	Id = 444,
	Name = "舒适环境",
	Gallery = 950003,
	Area = 130111,
	LockDesc = "解锁提示\n一次性探索恐龙馆1天",
	Desc = "虽然博物馆为寒带一角龙们配备了恒温器，但是它们还是热得冒汗。趁保安不注意的时候，它们拿起灭火器互相喷了起来。",
	Bundle = "packed_event_mus",
	Atlas = "Event_MUS",
	Icon = "MUS_Event_19",
	TriggerCondition = {
		NeedExploreTime = 86400,
	},
	Reward = {
		{
			Value = 320526,
			Num = 1,
		},
	},
}
EventConfig[EventID.Id445] =
{
	Id = 445,
	Name = "食物链",
	Gallery = 950003,
	Area = 130111,
	LockDesc = "解锁提示\n一次性探索恐龙馆1天",
	Desc = "走过自然厅很受欢迎的一个景点，这里展出着一个巨型恐龙的化石，它的肚子里有一个大型恐龙，大型恐龙肚子里有个中型恐龙，中型恐龙肚子里有个小型恐龙。",
	Bundle = "packed_event_mus",
	Atlas = "Event_MUS",
	Icon = "MUS_Event_16",
	TriggerCondition = {
		NeedExploreTime = 86400,
	},
	Reward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
EventConfig[EventID.Id446] =
{
	Id = 446,
	Name = "博物馆竞速赛",
	Gallery = 950003,
	Area = 130112,
	LockDesc = "解锁提示\n一次性探索出口2天\n(需要一位善于奔跑的石像角色)",
	Desc = "在无人的深夜，博物馆里的闹事分子们展开了无限制竞速赛。沙漠快走龙，快陶鸭，半人马雕像将进行冠军争夺赛。",
	Bundle = "packed_event_mus",
	Atlas = "Event_MUS",
	Icon = "MUS_Event_20",
	TriggerCondition = {
		NeedExploreTime = 172800,
		ConditionList = {
			{
				Condition = "TeamCharacterIdAnd",
				Value = 
				{
					220209,
				},
			},
		},
	},
	Reward = {
		{
			Value = 320527,
			Num = 1,
		},
	},
}
EventConfig[EventID.Id447] =
{
	Id = 447,
	Name = "意见箱",
	Gallery = 950003,
	Area = 130112,
	LockDesc = "解锁提示\n一次性探索出口2天",
	Desc = "为了能够更好地服务游客，馆长在出口处设置了意见箱。只要在旁边填写意见反馈投进去，这个问题说不定什么时候就能解决了哦～听说馆长经常都会躲在一边偷偷把写意见信的游客都记下来。",
	Bundle = "packed_event_mus",
	Atlas = "Event_MUS",
	Icon = "MUS_Event_23",
	TriggerCondition = {
		NeedExploreTime = 172800,
	},
	Reward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
EventConfig[EventID.Id448] =
{
	Id = 448,
	Name = "纪念品商店",
	Gallery = 950003,
	Area = 130112,
	LockDesc = "解锁提示\n一次性探索出口1天12小时",
	Desc = "马上就要离开博物馆了，出口处的纪念品商店有特别的道具售卖噢~还有1:10比例的快陶鸭玩具，真想买一个回去啊~",
	Bundle = "packed_event_mus",
	Atlas = "Event_MUS",
	Icon = "MUS_Event_51",
	TriggerCondition = {
		NeedExploreTime = 129600,
	},
	Reward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
EventConfig[EventID.Id449] =
{
	Id = 449,
	Name = "照片墙",
	Gallery = 950003,
	Area = 130112,
	LockDesc = "解锁提示\n一次性探索出口1天",
	Desc = "博物馆沿途都设置了照相机，拍下了很多旅途中快乐的回忆。不过照片每张售价10万金币……所以，大家还是就在出口自己拍照合影就好了。",
	Bundle = "packed_event_mus",
	Atlas = "Event_MUS",
	Icon = "MUS_Event_52",
	TriggerCondition = {
		NeedExploreTime = 86400,
	},
	Reward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
EventConfig[EventID.Id601] =
{
	Id = 601,
	Name = "谜题贩卖机",
	Gallery = 950004,
	Area = 130152,
	LockDesc = "解锁提示\n一次性探索甜心街1天\n(需要呜呜和漆漆)",
	Desc = "一路上都没有饮料卖，好不容易发现贩卖机，但是贩卖的是侦探谜题。“……皮特出门后，忽然想起一件事，于是他立刻报了警，为什么呢？”",
	Bundle = "packed_event_sus",
	Atlas = "Event_SUS",
	Icon = "SUS_Event_01",
	TriggerCondition = {
		NeedExploreTime = 86400,
		ConditionList = {
			{
				Condition = "TeamCharacterIdAnd",
				Value = 
				{
					220001,
					220002,
				},
			},
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
EventConfig[EventID.Id602] =
{
	Id = 602,
	Name = "先生，请看一下",
	Gallery = 950004,
	Area = 130152,
	LockDesc = "解锁提示\n一次性探索甜心街20小时\n(需要呜呜和漆漆)",
	Desc = "到了每月的传单日，星球上所有事务所都来这里发传单了。得知我们有两只猫，推销人员表示如果他们一起走丢的话。\n只要花五百元，我们就能立刻为您找回两只长得有七成像的猫。",
	Bundle = "packed_event_sus",
	Atlas = "Event_SUS",
	Icon = "SUS_Event_02",
	TriggerCondition = {
		NeedExploreTime = 72000,
		ConditionList = {
			{
				Condition = "TeamCharacterIdAnd",
				Value = 
				{
					220001,
					220002,
				},
			},
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
EventConfig[EventID.Id603] =
{
	Id = 603,
	Name = "小心盗窃",
	Gallery = 950004,
	Area = 130152,
	LockDesc = "解锁提示\n一次性探索甜心街16小时\n(需要呜呜和漆漆)",
	Desc = "热闹的街道上人挤着人，大家把随身财物交给呜呜保管~过马路时，一个戴口罩的外星人靠近了呜呜，不过漆漆反应很快，抓住了那个人伸向呜呜的手！后来才知道，他只是想撸猫……",
	Bundle = "packed_event_sus",
	Atlas = "Event_SUS",
	Icon = "SUS_Event_48",
	TriggerCondition = {
		NeedExploreTime = 57600,
		ConditionList = {
			{
				Condition = "TeamCharacterIdAnd",
				Value = 
				{
					220001,
					220002,
				},
			},
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
EventConfig[EventID.Id604] =
{
	Id = 604,
	Name = "事务所开张",
	Gallery = 950004,
	Area = 130152,
	LockDesc = "解锁提示\n一次性探索甜心街12小时",
	Desc = "星际事务所在悬疑星开设的分部，听说这里的生意比总部好很多，每个月收入大概多出100倍的样子吧。不过每周好像要工作140小时的样子。",
	Bundle = "packed_event_sus",
	Atlas = "Event_SUS",
	Icon = "SUS_Event_49",
	TriggerCondition = {
		NeedExploreTime = 43200,
	},
	Reward = {
		{
			Value = 320317,
			Num = 3,
		},
	},
}
EventConfig[EventID.Id605] =
{
	Id = 605,
	Name = "侦探茶话会",
	Gallery = 950004,
	Area = 130153,
	LockDesc = "解锁提示\n一次性探索咖啡馆1天12小时",
	Desc = "如果是晴天的话，中午就会有侦探们来咖啡馆聚会。他们似乎谈论着非常诡异的案子，比如最近咖啡似乎又涨价了……",
	Bundle = "packed_event_sus",
	Atlas = "Event_SUS",
	Icon = "SUS_Event_05",
	TriggerCondition = {
		NeedExploreTime = 129600,
	},
	Reward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
EventConfig[EventID.Id606] =
{
	Id = 606,
	Name = "奇怪的客人2",
	Gallery = 950004,
	Area = 130153,
	LockDesc = "解锁提示\n一次性探索咖啡馆1天\n(需要一位裁定罪名及量刑的法务人员)",
	Desc = "路过咖啡店时，大家都说要去喝咖啡休息一下~不过法官说什么也不愿意进去，说自己去附近转转，之后在门口集合就好。",
	Bundle = "packed_event_sus",
	Atlas = "Event_SUS",
	Icon = "SUS_Event_50",
	TriggerCondition = {
		NeedExploreTime = 86400,
		ConditionList = {
			{
				Condition = "TeamCharacterIdAnd",
				Value = 
				{
					220319,
				},
			},
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
EventConfig[EventID.Id607] =
{
	Id = 607,
	Name = "奇怪的客人",
	Gallery = 950004,
	Area = 130153,
	LockDesc = "解锁提示\n一次性探索咖啡馆1天\n(需要一位帮助政府提起诉讼的法务人员)",
	Desc = "每次路过咖啡店，检察官都要进来点两杯咖啡，一杯自己喝，一杯放在对面，似乎在等一个老朋友的样子。",
	Bundle = "packed_event_sus",
	Atlas = "Event_SUS",
	Icon = "SUS_Event_06",
	TriggerCondition = {
		NeedExploreTime = 86400,
		ConditionList = {
			{
				Condition = "TeamCharacterIdAnd",
				Value = 
				{
					220318,
				},
			},
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
EventConfig[EventID.Id608] =
{
	Id = 608,
	Name = "悠闲的午后",
	Gallery = 950004,
	Area = 130153,
	LockDesc = "解锁提示\n一次性探索咖啡馆1天\n(需要全队都是女性，且至少3人)",
	Desc = "和姐妹们逛街累了的时候，就坐下来放松一下。在咖啡馆外的露天座位上，点一壶可以无限续杯的咖啡，顺便享受一下和煦的阳光~",
	Bundle = "packed_event_sus",
	Atlas = "Event_SUS",
	Icon = "SUS_Event_07",
	TriggerCondition = {
		NeedExploreTime = 86400,
		ConditionList = {
			{
				Condition = "NeedTagAnd",
				Value = 
				{
					561703,
				},
			},
			{
				Condition = "TeamerCount",
				Value = 
				{
					3,4,5,
				},
			},
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
EventConfig[EventID.Id609] =
{
	Id = 609,
	Name = "炸弹邮件！",
	Gallery = 950004,
	Area = 130154,
	LockDesc = "解锁提示\n一次性探索邮局1天12小时\n(需要一位维持悬疑星治安的执法人员)",
	Desc = "邮局突发事故！收到了传出“滴答滴答”声的可疑包裹，大家都很害怕，豆豆警官小心翼翼地和赶到现场的同事打开包裹后，发现是一个时钟……",
	Bundle = "packed_event_sus",
	Atlas = "Event_SUS",
	Icon = "SUS_Event_09",
	TriggerCondition = {
		NeedExploreTime = 129600,
		ConditionList = {
			{
				Condition = "TeamCharacterIdAnd",
				Value = 
				{
					220316,
				},
			},
		},
	},
	Reward = {
		{
			Value = 320533,
			Num = 1,
		},
	},
}
EventConfig[EventID.Id610] =
{
	Id = 610,
	Name = "纪念邮票！",
	Gallery = 950004,
	Area = 130154,
	LockDesc = "解锁提示\n一次性探索邮局1天12小时",
	Desc = "邮局发售了限量版邮票！是很罕见的烫金彩印，而且图案是悬疑星的明星——大侦探。居民们都很好奇，邮局是怎么说服他拍这套照片的。买就对了！以后一定会升值的！",
	Bundle = "packed_event_sus",
	Atlas = "Event_SUS",
	Icon = "SUS_Event_08",
	TriggerCondition = {
		NeedExploreTime = 129600,
	},
	Reward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
EventConfig[EventID.Id611] =
{
	Id = 611,
	Name = "小道消息",
	Gallery = 950004,
	Area = 130154,
	LockDesc = "解锁提示\n一次性探索邮局1天\n(需要一位说话夸张的推销人员)",
	Desc = "和其他报童聊了一阵后，报童神秘地说道：“听说大富豪M回家路上被绑架了，绑匪要求赎金1兆噢！警方已经全面介入了！”",
	Bundle = "packed_event_sus",
	Atlas = "Event_SUS",
	Icon = "SUS_Event_51",
	TriggerCondition = {
		NeedExploreTime = 86400,
		ConditionList = {
			{
				Condition = "TeamCharacterIdAnd",
				Value = 
				{
					220301,
				},
			},
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
EventConfig[EventID.Id612] =
{
	Id = 612,
	Name = "交给呜呜的信",
	Gallery = 950004,
	Area = 130154,
	LockDesc = "解锁提示\n一次性探索邮局1天",
	Desc = "新上任的邮递员说这封信已经放了很久了，按照规定今天是邮局保管的最后一天。不过当他看到呜呜时，却如释重负地将信件交给了呜呜。",
	Bundle = "packed_event_sus",
	Atlas = "Event_SUS",
	Icon = "SUS_Event_52",
	TriggerCondition = {
		NeedExploreTime = 86400,
	},
	Reward = {
		{
			Value = 320531,
			Num = 1,
		},
	},
}
EventConfig[EventID.Id613] =
{
	Id = 613,
	Name = "阴雨绵绵",
	Gallery = 950004,
	Area = 130155,
	LockDesc = "解锁提示\n一次性探索冷清街16小时\n(需要一位阴气沉沉、走路无声的队员)",
	Desc = "每次和杰克一起出来，天气都会阴沉沉的。不过杰克说，这是他最喜欢的天气，刚说着，就下雨了。大家都淋得湿透了……",
	Bundle = "packed_event_sus",
	Atlas = "Event_SUS",
	Icon = "SUS_Event_53",
	TriggerCondition = {
		NeedExploreTime = 57600,
		ConditionList = {
			{
				Condition = "TeamCharacterIdAnd",
				Value = 
				{
					220321,
				},
			},
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
EventConfig[EventID.Id614] =
{
	Id = 614,
	Name = "小巷枪战",
	Gallery = 950004,
	Area = 130155,
	LockDesc = "解锁提示\n一次性探索冷清街16小时",
	Desc = "冷清街道今天弥漫着独特的气氛，当我们要经过街道时，警官拦住了我们，还来不及向我们解释，就和街对面的黑衣人们爆发了大规模枪战。随后，摄制组人员要求我们尽快离场。",
	Bundle = "packed_event_sus",
	Atlas = "Event_SUS",
	Icon = "SUS_Event_54",
	TriggerCondition = {
		NeedExploreTime = 57600,
	},
	Reward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
EventConfig[EventID.Id615] =
{
	Id = 615,
	Name = "小猫咪",
	Gallery = 950004,
	Area = 130155,
	LockDesc = "解锁提示\n一次性探索冷清街12小时",
	Desc = "卷着寒风的街道垃圾桶旁，蜷着一只戴着侦探帽的小猫咪，似乎很可爱的样子，我们想上前去摸一摸时，被告知它正在查案。",
	Bundle = "packed_event_sus",
	Atlas = "Event_SUS",
	Icon = "SUS_Event_13",
	TriggerCondition = {
		NeedExploreTime = 43200,
	},
	Reward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
EventConfig[EventID.Id616] =
{
	Id = 616,
	Name = "棘手的案子",
	Gallery = 950004,
	Area = 130155,
	LockDesc = "解锁提示\n一次性探索冷清街12小时",
	Desc = "再次路过街道时，戴着侦探帽的可爱小猫还在那里。看来这个案子对它来说有点棘手。",
	Bundle = "packed_event_sus",
	Atlas = "Event_SUS",
	Icon = "SUS_Event_15",
	TriggerCondition = {
		NeedExploreTime = 43200,
	},
	Reward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
EventConfig[EventID.Id617] =
{
	Id = 617,
	Name = "非法交易？",
	Gallery = 950004,
	Area = 130155,
	LockDesc = "解锁提示\n一次性探索冷清街8小时",
	Desc = "可疑的街道拐角处有戴墨镜的男人坐在长椅上。暗中观察后，发现原来是新刷漆的长椅把他粘住了。",
	Bundle = "packed_event_sus",
	Atlas = "Event_SUS",
	Icon = "SUS_Event_14",
	TriggerCondition = {
		NeedExploreTime = 28800,
	},
	Reward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
EventConfig[EventID.Id618] =
{
	Id = 618,
	Name = "壁虎断尾…",
	Gallery = 950004,
	Area = 130155,
	LockDesc = "解锁提示\n一次性探索冷清街8小时",
	Desc = "再次经过长椅的时候，发现原来那个戴墨镜的人不见了，但是长椅上留下了一块裤子的布料",
	Bundle = "packed_event_sus",
	Atlas = "Event_SUS",
	Icon = "SUS_Event_16",
	TriggerCondition = {
		NeedExploreTime = 28800,
	},
	Reward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
EventConfig[EventID.Id619] =
{
	Id = 619,
	Name = "可疑对象",
	Gallery = 950004,
	Area = 130156,
	LockDesc = "解锁提示\n一次性探索现场2天\n(需要一位完全无法辨明身份的队员)",
	Desc = "今天在现场和一个拦路的工地路障打起来了~警官赶到后，放走了所有人，包括先动手的路障，只是针对凶手一人录了一整天的口供……",
	Bundle = "packed_event_sus",
	Atlas = "Event_SUS",
	Icon = "SUS_Event_55",
	TriggerCondition = {
		NeedExploreTime = 172800,
		ConditionList = {
			{
				Condition = "TeamCharacterIdAnd",
				Value = 
				{
					220305,
				},
			},
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
EventConfig[EventID.Id620] =
{
	Id = 620,
	Name = "死前讯息",
	Gallery = 950004,
	Area = 130156,
	LockDesc = "解锁提示\n一次性探索现场2天\n(需要一位经常在现场跑龙套的队员)",
	Desc = "来到了现场，一定要让死者写点什么！大家一边讨论一边让死者咬破手指写出来看看感觉，写了200条后，死者因为失血过多而昏迷了。嗯，就是这感觉！",
	Bundle = "packed_event_sus",
	Atlas = "Event_SUS",
	Icon = "SUS_Event_17",
	TriggerCondition = {
		NeedExploreTime = 172800,
		ConditionList = {
			{
				Condition = "TeamCharacterIdAnd",
				Value = 
				{
					220303,
				},
			},
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
EventConfig[EventID.Id621] =
{
	Id = 621,
	Name = "跟踪！",
	Gallery = 950004,
	Area = 130156,
	LockDesc = "解锁提示\n一次性探索现场1天12小时",
	Desc = "大富豪M先生的助手鬼祟地从银行提取了大量现金。大家一路跟随，发现了一个很大的地下室，富豪M先生正在打造超级战甲。",
	Bundle = "packed_event_sus",
	Atlas = "Event_SUS",
	Icon = "SUS_Event_56",
	TriggerCondition = {
		NeedExploreTime = 129600,
	},
	Reward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
EventConfig[EventID.Id622] =
{
	Id = 622,
	Name = "寻找灵感",
	Gallery = 950004,
	Area = 130156,
	LockDesc = "解锁提示\n一次性探索现场1天\n(需要一位使用文字来演绎推理的队员)",
	Desc = "来到了著名景点——案件现场，阿加莎小姐显得特别兴奋~仔细勘察了残留血迹和附近的烟头后，她立刻掏出笔记本做起记录，大家以为她在整理线索，其实她只是在记录小说灵感。",
	Bundle = "packed_event_sus",
	Atlas = "Event_SUS",
	Icon = "SUS_Event_57",
	TriggerCondition = {
		NeedExploreTime = 86400,
		ConditionList = {
			{
				Condition = "TeamCharacterIdAnd",
				Value = 
				{
					220302,
				},
			},
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
EventConfig[EventID.Id623] =
{
	Id = 623,
	Name = "案件旁听",
	Gallery = 950004,
	Area = 130157,
	LockDesc = "解锁提示\n一次性探索警局2天\n(需要一位能够提供线索的队员)",
	Desc = "路过警长的办公室时，发现警长们正在谈论最近发生的案件。证人假装系鞋带，在门口认真地听了3个小时，打算离开的时候，发现腿完全麻了。",
	Bundle = "packed_event_sus",
	Atlas = "Event_SUS",
	Icon = "SUS_Event_58",
	TriggerCondition = {
		NeedExploreTime = 172800,
		ConditionList = {
			{
				Condition = "TeamCharacterIdAnd",
				Value = 
				{
					220304,
				},
			},
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
EventConfig[EventID.Id624] =
{
	Id = 624,
	Name = "爸爸的收藏1",
	Gallery = 950004,
	Area = 130157,
	LockDesc = "解锁提示\n一次性探索警局2天\n(需要一位悬疑星三姐妹中的大姐)",
	Desc = "今天在警局收集情报~小泪和值班警官聊天时，趁他不注意在警局会议桌下安装了窃听器。通过窃听得知，有一瓶红酒被送到了证物仓库2201室。",
	Bundle = "packed_event_sus",
	Atlas = "Event_SUS",
	Icon = "SUS_Event_59",
	TriggerCondition = {
		NeedExploreTime = 172800,
		ConditionList = {
			{
				Condition = "TeamCharacterIdAnd",
				Value = 
				{
					220306,
				},
			},
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
EventConfig[EventID.Id625] =
{
	Id = 625,
	Name = "被捕的富豪",
	Gallery = 950004,
	Area = 130157,
	LockDesc = "解锁提示\n一次性探索警局1天",
	Desc = "城中富豪M先生因伪造绑架案、非法转移资产及未经许可制造危险设备3项罪名而被捕。面对正义的警方和已经被没收的超级战甲，M先生流下了悔恨的泪水。不知道是因为英雄梦破碎还是因为给警方造成了麻烦。",
	Bundle = "packed_event_sus",
	Atlas = "Event_SUS",
	Icon = "SUS_Event_60",
	TriggerCondition = {
		NeedExploreTime = 86400,
	},
	Reward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
EventConfig[EventID.Id626] =
{
	Id = 626,
	Name = "凶手不是我",
	Gallery = 950004,
	Area = 130157,
	LockDesc = "解锁提示\n一次性探索警局1天",
	Desc = "经过警局时，发现二十个警察押解着一个满脸刀疤的黑衣人，虽然长得真的很像悍匪，但是他一直在强调：“凶手不是我！”",
	Bundle = "packed_event_sus",
	Atlas = "Event_SUS",
	Icon = "SUS_Event_21",
	TriggerCondition = {
		NeedExploreTime = 86400,
	},
	Reward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
EventConfig[EventID.Id627] =
{
	Id = 627,
	Name = "可疑的供词",
	Gallery = 950004,
	Area = 130158,
	LockDesc = "解锁提示\n一次性探索证物仓库2天",
	Desc = "无意间发现了当年的供词，轰动全城的小猫闯红灯案件，因有人目击检察官与法官私下在咖啡馆会面，导致案件无效，违规猫咪被当庭释放，法官发誓再也不进咖啡馆。",
	Bundle = "packed_event_sus",
	Atlas = "Event_SUS",
	Icon = "SUS_Event_61",
	TriggerCondition = {
		NeedExploreTime = 172800,
	},
	Reward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
EventConfig[EventID.Id628] =
{
	Id = 628,
	Name = "爸爸的收藏2",
	Gallery = 950004,
	Area = 130158,
	LockDesc = "解锁提示\n一次性探索证物仓库1天\n(需要悬疑星三姐妹中的二姐)",
	Desc = "2201室的房间门紧锁着，于是小瞳通过伸缩腰带从顶楼垂降溜进了房间，最终在海量证物中，找到了爸爸收藏的红酒瓶。",
	Bundle = "packed_event_sus",
	Atlas = "Event_SUS",
	Icon = "SUS_Event_62",
	TriggerCondition = {
		NeedExploreTime = 86400,
		ConditionList = {
			{
				Condition = "TeamCharacterIdAnd",
				Value = 
				{
					220307,
				},
			},
		},
	},
	Reward = {
		{
			Value = 320532,
			Num = 1,
		},
	},
}
EventConfig[EventID.Id629] =
{
	Id = 629,
	Name = "恐怖录像",
	Gallery = 950004,
	Area = 130158,
	LockDesc = "解锁提示\n一次性探索证物仓库1天",
	Desc = "听说在403号仓库，有一盘可怕的录像带，如果看过的话，就会被恶鬼缠上。\n那个恶鬼会在你看侦探读物时，发短信告诉你凶手和他的作案手法……",
	Bundle = "packed_event_sus",
	Atlas = "Event_SUS",
	Icon = "SUS_Event_25",
	TriggerCondition = {
		NeedExploreTime = 86400,
	},
	Reward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
EventConfig[EventID.Id630] =
{
	Id = 630,
	Name = "强行问话",
	Gallery = 950004,
	Area = 130159,
	LockDesc = "解锁提示\n一次性探索审讯大厅1天\n(需要一位以挑战法律为乐趣的学者)",
	Desc = "在审讯大厅参观时，教授被审讯室的人员逮捕了！！盘问持续了1天才结束。\n“态度严谨，工作认真，环境优美，下次还会再来。”走出审讯室时教授轻松地如是说。",
	Bundle = "packed_event_sus",
	Atlas = "Event_SUS",
	Icon = "SUS_Event_29",
	TriggerCondition = {
		NeedExploreTime = 86400,
		ConditionList = {
			{
				Condition = "TeamCharacterIdAnd",
				Value = 
				{
					220325,
				},
			},
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
EventConfig[EventID.Id631] =
{
	Id = 631,
	Name = "完美分析",
	Gallery = 950004,
	Area = 130159,
	LockDesc = "解锁提示\n一次性探索审讯大厅1天\n(需要一位以解开一切谜题为乐趣的侦探)",
	Desc = "警官们对一言不发的犯人完全没有了办法，见到大侦探经过，于是立刻向他进行求助。大侦探通过犯人的打扮和身体细节，立刻滔滔不绝地说出犯人的职业，经历，行为习惯，性格特征。大侦探还想说的时候，犯人已经默默签了认罪状。",
	Bundle = "packed_event_sus",
	Atlas = "Event_SUS",
	Icon = "SUS_Event_63",
	TriggerCondition = {
		NeedExploreTime = 86400,
		ConditionList = {
			{
				Condition = "TeamCharacterIdAnd",
				Value = 
				{
					220324,
				},
			},
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
EventConfig[EventID.Id632] =
{
	Id = 632,
	Name = "我觉得可能是这样",
	Gallery = 950004,
	Area = 130159,
	LockDesc = "解锁提示\n一次性探索审讯大厅1天\n(需要一位喜欢强行进行推理的普通居民)",
	Desc = "在审讯大厅里，警官们正在询问嫌疑人不在场证明。听了两句后，证人便忍不住上前说起了自己对案件的看法，不过他一边说着，一边就被警官们拖出了审讯室。",
	Bundle = "packed_event_sus",
	Atlas = "Event_SUS",
	Icon = "SUS_Event_64",
	TriggerCondition = {
		NeedExploreTime = 86400,
		ConditionList = {
			{
				Condition = "TeamCharacterIdAnd",
				Value = 
				{
					220304,
				},
			},
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
EventConfig[EventID.Id633] =
{
	Id = 633,
	Name = "无罪辩护",
	Gallery = 950004,
	Area = 130159,
	LockDesc = "解锁提示\n一次性探索审讯大厅20小时\n(需要一位擅长帮助嫌疑人脱罪的律政人员)",
	Desc = "律师到场后，嫌疑人忽然底气足了起来，大声宣布自己无罪，对案件完全不知情，也没有什么要说的！\n什么！你只是路过的，不是我的律师？！警官，口供我再斟酌一下……",
	Bundle = "packed_event_sus",
	Atlas = "Event_SUS",
	Icon = "SUS_Event_65",
	TriggerCondition = {
		NeedExploreTime = 72000,
		ConditionList = {
			{
				Condition = "TeamCharacterIdAnd",
				Value = 
				{
					220312,
				},
			},
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
EventConfig[EventID.Id634] =
{
	Id = 634,
	Name = "字典",
	Gallery = 950004,
	Area = 130159,
	LockDesc = "解锁提示\n一次性探索审讯大厅16小时",
	Desc = "参观刑讯用具时发现一本厚字典也放在橱窗里，警官神秘地告诉我们，知识可以化腐朽为神奇，用字典垫着敲犯人胸口再打，验伤就验不出来了……",
	Bundle = "packed_event_sus",
	Atlas = "Event_SUS",
	Icon = "SUS_Event_31",
	TriggerCondition = {
		NeedExploreTime = 57600,
	},
	Reward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
EventConfig[EventID.Id635] =
{
	Id = 635,
	Name = "爸爸的收藏3",
	Gallery = 950004,
	Area = 130160,
	LockDesc = "解锁提示\n一次性探索失物招领局20小时\n(需要悬疑星三姐妹中的小妹)",
	Desc = "在招领处看到了一个陈旧的酒瓶木塞，小爱从钱包里找到了父亲和酒瓶合影的照片。证明这是父亲的物品后，小爱成功领回了塞子。",
	Bundle = "packed_event_sus",
	Atlas = "Event_SUS",
	Icon = "SUS_Event_66",
	TriggerCondition = {
		NeedExploreTime = 72000,
		ConditionList = {
			{
				Condition = "TeamCharacterIdAnd",
				Value = 
				{
					220308,
				},
			},
		},
	},
	Reward = {
		{
			Value = 320534,
			Num = 1,
		},
	},
}
EventConfig[EventID.Id636] =
{
	Id = 636,
	Name = "这是我的！",
	Gallery = 950004,
	Area = 130160,
	LockDesc = "解锁提示\n一次性探索失物招领局16小时\n(需要一位拥有一发倒地枪的队员)",
	Desc = "发现失物招领墙上挂着一枚和教授衣服上一模一样的骷髅徽章，虽然教授再三说明这个真的是自己的。但是警官说什么也不相信教授。于是教授只好用一发倒地枪射倒了警官，自己拿走了徽章。",
	Bundle = "packed_event_sus",
	Atlas = "Event_SUS",
	Icon = "SUS_Event_67",
	TriggerCondition = {
		NeedExploreTime = 57600,
		ConditionList = {
			{
				Condition = "TeamCharacterIdAnd",
				Value = 
				{
					220325,
				},
			},
		},
	},
	Reward = {
		{
			Value = 320535,
			Num = 1,
		},
	},
}
EventConfig[EventID.Id637] =
{
	Id = 637,
	Name = "你不是失主！",
	Gallery = 950004,
	Area = 130160,
	LockDesc = "解锁提示\n一次性探索失物招领局12小时\n(需要一位推理能力强、逻辑严密的侦探)",
	Desc = "两名宅男都说限量版的玩具是自己的。大侦探认为这种情况下需要使用至少7次心理测验并进行20组行为模型分析才能得出结论时，其中一个宅男忽然拿出了发票……",
	Bundle = "packed_event_sus",
	Atlas = "Event_SUS",
	Icon = "SUS_Event_68",
	TriggerCondition = {
		NeedExploreTime = 43200,
		ConditionList = {
			{
				Condition = "TeamCharacterIdAnd",
				Value = 
				{
					220324,
				},
			},
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
EventConfig[EventID.Id638] =
{
	Id = 638,
	Name = "黑皮箱？",
	Gallery = 950004,
	Area = 130160,
	LockDesc = "解锁提示\n一次性探索失物招领局12小时",
	Desc = "失物招领局一直放着一个黑色皮箱，听说每天都有人来认领，但是到现在也没有人能拨对密码锁打开箱子。",
	Bundle = "packed_event_sus",
	Atlas = "Event_SUS",
	Icon = "SUS_Event_33",
	TriggerCondition = {
		NeedExploreTime = 43200,
	},
	Reward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
EventConfig[EventID.Id639] =
{
	Id = 639,
	Name = "编辑部失火",
	Gallery = 950004,
	Area = 130161,
	LockDesc = "解锁提示\n一次性探索编辑部1天\n(需要一位编辑部的负责人)",
	Desc = "“特大消息！编辑部今年连续100次失火，杂志无法准时送达各位手中，敬请谅解。”\n说起来，会不会是因为无法准时出稿，才“失火”的呢？",
	Bundle = "packed_event_sus",
	Atlas = "Event_SUS",
	Icon = "SUS_Event_37",
	TriggerCondition = {
		NeedExploreTime = 86400,
		ConditionList = {
			{
				Condition = "TeamCharacterIdAnd",
				Value = 
				{
					220309,
				},
			},
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
EventConfig[EventID.Id640] =
{
	Id = 640,
	Name = "完美密室",
	Gallery = 950004,
	Area = 130161,
	LockDesc = "解锁提示\n一次性探索编辑部20小时\n(需要一位悬疑星的畅销女作家)",
	Desc = "著名悬疑作家阿加莎小姐提出了一个完美密室！为了验证手法，编辑们将编辑部大门反锁，然后用绳子取出了钥匙，手法完全成功了~~\n不过怎么再进去呢？",
	Bundle = "packed_event_sus",
	Atlas = "Event_SUS",
	Icon = "SUS_Event_38",
	TriggerCondition = {
		NeedExploreTime = 72000,
		ConditionList = {
			{
				Condition = "TeamCharacterIdAnd",
				Value = 
				{
					220302,
				},
			},
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
EventConfig[EventID.Id641] =
{
	Id = 641,
	Name = "高级借书卡",
	Gallery = 950004,
	Area = 130161,
	LockDesc = "解锁提示\n一次性探索编辑部16小时\n(需要一位阅读爱好者)",
	Desc = "路过编辑部，打算办理新一年的畅享阅读卡时，办理人员说读者今年的借书卡价格要上调200%，因为去年读者阅读数量超过了规定的1200本，而且频繁催更，搞得编辑部的人很烦躁。",
	Bundle = "packed_event_sus",
	Atlas = "Event_SUS",
	Icon = "SUS_Event_69",
	TriggerCondition = {
		NeedExploreTime = 57600,
		ConditionList = {
			{
				Condition = "TeamCharacterIdAnd",
				Value = 
				{
					220310,
				},
			},
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
EventConfig[EventID.Id642] =
{
	Id = 642,
	Name = "编辑部查封",
	Gallery = 950004,
	Area = 130161,
	LockDesc = "解锁提示\n一次性探索编辑部12小时",
	Desc = "因为向读者许诺的周刊竟然演变成半年刊，而且拒不退款，编辑部遭到大量投诉。我们路过的时候，正好遇到编辑部主干人员被相关部门带走接受调查。",
	Bundle = "packed_event_sus",
	Atlas = "Event_SUS",
	Icon = "SUS_Event_39",
	TriggerCondition = {
		NeedExploreTime = 43200,
	},
	Reward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
EventConfig[EventID.Id643] =
{
	Id = 643,
	Name = "最新漫画",
	Gallery = 950004,
	Area = 130161,
	LockDesc = "解锁提示\n一次性探索编辑部8小时\n(需要一位大侦探的左膀右臂)",
	Desc = "已经休刊7年的著名漫画《侦探x侦探》重新连载了，不过听说只限量刊印1000册。助理先生排了一个晚上的队，成功帮大侦探买到了两本~",
	Bundle = "packed_event_sus",
	Atlas = "Event_SUS",
	Icon = "SUS_Event_70",
	TriggerCondition = {
		NeedExploreTime = 28800,
		ConditionList = {
			{
				Condition = "TeamCharacterIdAnd",
				Value = 
				{
					220320,
				},
			},
		},
	},
	Reward = {
		{
			Value = 320536,
			Num = 1,
		},
	},
}
EventConfig[EventID.Id644] =
{
	Id = 644,
	Name = "秘密采访",
	Gallery = 950004,
	Area = 130161,
	LockDesc = "解锁提示\n一次性探索编辑部4小时",
	Desc = "为了将杂志再次推上热点，编辑部针对本市最大黑帮进行了深入调查。复检浴室采访的稿件时，编辑长想起来受采访者提出要保护个人隐私，于是很贴心地打上了马赛克。",
	Bundle = "packed_event_sus",
	Atlas = "Event_SUS",
	Icon = "SUS_Event_71",
	TriggerCondition = {
		NeedExploreTime = 14400,
	},
	Reward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
EventConfig[EventID.Id645] =
{
	Id = 645,
	Name = "超级偶像",
	Gallery = 950004,
	Area = 130162,
	LockDesc = "解锁提示\n一次性探索侦探街1天\n(需要一位悬疑星推理最强的侦探)",
	Desc = "发现大侦探重新回到侦探街，沿街的猫咪都来观看这位被称为全星球最聪敏的人。大侦探和希望成为侦探的猫咪们愉快地合了影。",
	Bundle = "packed_event_sus",
	Atlas = "Event_SUS",
	Icon = "SUS_Event_72",
	TriggerCondition = {
		NeedExploreTime = 86400,
		ConditionList = {
			{
				Condition = "TeamCharacterIdAnd",
				Value = 
				{
					220324,
				},
			},
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
EventConfig[EventID.Id646] =
{
	Id = 646,
	Name = "真实之酒",
	Gallery = 950004,
	Area = 130162,
	LockDesc = "解锁提示\n一次性探索侦探街1天\n(需要一位能调制任何饮料的队员)",
	Desc = "侦探街新开了一间酒吧，听说那里的调酒师可以调制出让人吐露真言的饮料。调酒师前去挑战，不过只喝下一杯，就立刻醉了，没完没了地说自己小时候的糗事。",
	Bundle = "packed_event_sus",
	Atlas = "Event_SUS",
	Icon = "SUS_Event_73",
	TriggerCondition = {
		NeedExploreTime = 86400,
		ConditionList = {
			{
				Condition = "TeamCharacterIdAnd",
				Value = 
				{
					220314,
				},
			},
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
EventConfig[EventID.Id647] =
{
	Id = 647,
	Name = "奇怪的电话亭1",
	Gallery = 950004,
	Area = 130162,
	LockDesc = "解锁提示\n一次性探索侦探街18小时\n(需要呜呜和漆漆)",
	Desc = "今天，看到了一个奇怪的电话亭，铃声一直响着，正在考虑要不要接起来的时候，对方挂断了。",
	Bundle = "packed_event_sus",
	Atlas = "Event_SUS",
	Icon = "SUS_Event_41",
	TriggerCondition = {
		NeedExploreTime = 64800,
		ConditionList = {
			{
				Condition = "TeamCharacterIdAnd",
				Value = 
				{
					220001,
					220002,
				},
			},
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
EventConfig[EventID.Id648] =
{
	Id = 648,
	Name = "奇怪的电话亭2",
	Gallery = 950004,
	Area = 130162,
	LockDesc = "解锁提示\n一次性探索侦探街18小时\n(需要呜呜和漆漆)",
	Desc = "再次路过了电话亭。“又会有人打过来吗？”等了一会儿，电话忽然响了一下，就挂断了。",
	Bundle = "packed_event_sus",
	Atlas = "Event_SUS",
	Icon = "SUS_Event_42",
	TriggerCondition = {
		NeedExploreTime = 64800,
		ConditionList = {
			{
				Condition = "TeamCharacterIdAnd",
				Value = 
				{
					220001,
					220002,
				},
			},
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
EventConfig[EventID.Id649] =
{
	Id = 649,
	Name = "奇怪的电话亭3",
	Gallery = 950004,
	Area = 130162,
	LockDesc = "解锁提示\n一次性探索侦探街18小时\n(需要呜呜和漆漆)",
	Desc = "第三次路过电话亭，上面贴着告示“维修中”。打算看看有没有修理完毕，发现电话换成了信箱，不过要投币才能取件。",
	Bundle = "packed_event_sus",
	Atlas = "Event_SUS",
	Icon = "SUS_Event_43",
	TriggerCondition = {
		NeedExploreTime = 64800,
		ConditionList = {
			{
				Condition = "TeamCharacterIdAnd",
				Value = 
				{
					220001,
					220002,
				},
			},
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
EventConfig[EventID.Id650] =
{
	Id = 650,
	Name = "超时空电话亭",
	Gallery = 950004,
	Area = 130162,
	LockDesc = "解锁提示\n一次性探索侦探街18小时\n(需要呜呜和漆漆)",
	Desc = "再次来到电话亭，将幸运金币放进了投币口。一个包裹掉了出来。物品信息上写着“给呜呜，你最喜欢的玩具。另外，记得好好照顾漆漆。”",
	Bundle = "packed_event_sus",
	Atlas = "Event_SUS",
	Icon = "SUS_Event_44",
	TriggerCondition = {
		NeedExploreTime = 64800,
		ConditionList = {
			{
				Condition = "TeamCharacterIdAnd",
				Value = 
				{
					220001,
					220002,
				},
			},
		},
	},
	Reward = {
		{
			Value = 320537,
			Num = 1,
		},
	},
}
EventConfig[EventID.Id651] =
{
	Id = 651,
	Name = "高科技断案书",
	Gallery = 950004,
	Area = 130163,
	LockDesc = "解锁提示\n一次性探索实验室2天\n(需要一位无论走到哪里都会遇上案件的少年和一位喜欢发明的队员)",
	Desc = "使用了最新智能检测仪生成的化验报告，报告不仅会说明物质分析，还会义正言辞地进行推理分析。\n听说算法是博士和寄住在家里的小学生一起整理出来的。",
	Bundle = "packed_event_sus",
	Atlas = "Event_SUS",
	Icon = "SUS_Event_46",
	TriggerCondition = {
		NeedExploreTime = 172800,
		ConditionList = {
			{
				Condition = "TeamCharacterIdAnd",
				Value = 
				{
					220322,
					220315,
				},
			},
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
EventConfig[EventID.Id652] =
{
	Id = 652,
	Name = "标本不见了！",
	Gallery = 950004,
	Area = 130163,
	LockDesc = "解锁提示\n一次性探索实验室2天\n(需要一位非常容易成为犯罪目标的普通居民)",
	Desc = "每到深夜时，无人的实验室里都会响起脚步声。听保安说，这时候一定要去标本室确认一下，如果标本不见的话，那么他很有可能……突然出现在你背后噢！",
	Bundle = "packed_event_sus",
	Atlas = "Event_SUS",
	Icon = "SUS_Event_47",
	TriggerCondition = {
		NeedExploreTime = 172800,
		ConditionList = {
			{
				Condition = "TeamCharacterIdAnd",
				Value = 
				{
					220311,
				},
			},
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
EventConfig[EventID.Id653] =
{
	Id = 653,
	Name = "真话药水",
	Gallery = 950004,
	Area = 130163,
	LockDesc = "解锁提示\n一次性探索实验室2天",
	Desc = "在神秘的实验室里发现了冒着荧光的药水，上面贴着标签——“真话药”。药水的颜色很清澈，看起来非常好喝的样子，这大概也是故意设计出来的特性。",
	Bundle = "packed_event_sus",
	Atlas = "Event_SUS",
	Icon = "SUS_Event_24",
	TriggerCondition = {
		NeedExploreTime = 172800,
	},
	Reward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
EventConfig[EventID.Id654] =
{
	Id = 654,
	Name = "新人法医",
	Gallery = 950004,
	Area = 130163,
	LockDesc = "解锁提示\n一次性探索实验室1天12小时\n(需要一位经常与尸体打交道的法务人员)",
	Desc = "今天来到了实验室，正巧遇到一批新的法医实习生。新生们都还很胆小，很多人看到瓶中脑，就吓得晕倒了。",
	Bundle = "packed_event_sus",
	Atlas = "Event_SUS",
	Icon = "SUS_Event_74",
	TriggerCondition = {
		NeedExploreTime = 129600,
		ConditionList = {
			{
				Condition = "TeamCharacterIdAnd",
				Value = 
				{
					220317,
				},
			},
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
EventConfig[EventID.Id801] =
{
	Id = 801,
	Name = "重逢之后",
	Gallery = 950005,
	Area = 130202,
	LockDesc = "解锁提示\n一次性探索音乐广场1天\n(需要tea time的两位成员)",
	Desc = "投身直播的美莎回到舞台，与珍一同演出，尽管有人抱怨“保安挡住了我们的视线”，但能再一次看到tea time合体，粉丝还是很开心。",
	Bundle = "packed_event_sea",
	Atlas = "Event_SEA",
	Icon = "SEA_Event_3",
	TriggerCondition = {
		NeedExploreTime = 86400,
		ConditionList = {
			{
				Condition = "TeamCharacterIdAnd",
				Value = 
				{
					220407,
					220408,
				},
			},
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
EventConfig[EventID.Id802] =
{
	Id = 802,
	Name = "黑暗中的天使",
	Gallery = 950005,
	Area = 130202,
	LockDesc = "解锁提示\n一次性探索音乐广场1天\n(需要一位穿着斑点束身服的角色，且队伍中没有TA的队友)",
	Desc = "鲸鲨依伶单独表演时，喜欢把灯光关掉，只留一束聚光灯，粉丝们会自发举起荧光棒，把观众席与舞台照亮。",
	Bundle = "packed_event_sea",
	Atlas = "Event_SEA",
	Icon = "SEA_Event_4",
	TriggerCondition = {
		NeedExploreTime = 86400,
		ConditionList = {
			{
				Condition = "TeamCharacterIdAnd",
				Value = 
				{
					220427,
				},
			},
			{
				Condition = "BanCharacterIdOr",
				Value = 
				{
					220426,
					220430,
				},
			},
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
EventConfig[EventID.Id803] =
{
	Id = 803,
	Name = "警局一日游",
	Gallery = 950005,
	Area = 130202,
	LockDesc = "解锁提示\n一次性探索音乐广场1天\n(需要一位常备专属牙套的角色)",
	Desc = "有居民声称，目击到人气偶像牙牙被海洋警察批评教育，原因是TA咧嘴大笑时露出了自己的牙齿，吓到了小型海游族居民。",
	Bundle = "packed_event_sea",
	Atlas = "Event_SEA",
	Icon = "SEA_Event_5",
	TriggerCondition = {
		NeedExploreTime = 86400,
		ConditionList = {
			{
				Condition = "TeamCharacterIdAnd",
				Value = 
				{
					220426,
				},
			},
		},
	},
	Reward = {
		{
			Value = 320539,
			Num = 1,
		},
		{
			Value = 2,
			Num = 20,
		},
	},
}
EventConfig[EventID.Id804] =
{
	Id = 804,
	Name = "不可思议的声音",
	Gallery = 950005,
	Area = 130202,
	LockDesc = "解锁提示\n一次性探索音乐广场1天\n(需要呜呜和漆漆)",
	Desc = "第一次来到水下世界，漆漆有些害怕，反倒是呜呜非常勇敢，没游多远就听到了动人的歌声。",
	Bundle = "packed_event_sea",
	Atlas = "Event_SEA",
	Icon = "SEA_Event_1",
	TriggerCondition = {
		NeedExploreTime = 86400,
		ConditionList = {
			{
				Condition = "TeamCharacterIdAnd",
				Value = 
				{
					220001,
					220002,
				},
			},
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
EventConfig[EventID.Id805] =
{
	Id = 805,
	Name = "梦想的开始",
	Gallery = 950005,
	Area = 130202,
	LockDesc = "解锁提示\n一次性探索音乐广场1天\n(需要来自偏远小村的角色)",
	Desc = "舞台上歌声响起时，鲎椰子总会停下步伐，目不转睛地盯着台上带着笑容挥洒汗水的偶像们，神情憧憬而落寞。",
	Bundle = "packed_event_sea",
	Atlas = "Event_SEA",
	Icon = "SEA_Event_2",
	TriggerCondition = {
		NeedExploreTime = 86400,
		ConditionList = {
			{
				Condition = "TeamCharacterIdAnd",
				Value = 
				{
					220404,
				},
			},
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
EventConfig[EventID.Id806] =
{
	Id = 806,
	Name = "偶像的假日3",
	Gallery = 950005,
	Area = 130203,
	LockDesc = "解锁提示\n一次性探索浅海沙滩1天12小时\n(需要一位可以控制同族的角色)",
	Desc = "莱斯莉有时会在沙滩上支起太阳伞，吹奏出婉转动听的旋律，往往开始吹奏后，一大批人会浮出海面来到TA身边，大家开心地舞蹈，动作整齐划一。",
	Bundle = "packed_event_sea",
	Atlas = "Event_SEA",
	Icon = "SEA_Event_11",
	TriggerCondition = {
		NeedExploreTime = 129600,
		ConditionList = {
			{
				Condition = "TeamCharacterIdAnd",
				Value = 
				{
					220425,
				},
			},
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
EventConfig[EventID.Id807] =
{
	Id = 807,
	Name = "偶像的假日4",
	Gallery = 950005,
	Area = 130203,
	LockDesc = "解锁提示\n一次性探索浅海沙滩1天\n(需要sharkalaka的所有成员)",
	Desc = "这一天，平静的海滩被一阵吵嚷声打断。原来是Sharkalaka的成员在四处寻找，这瓶防晒霜到底是谁的，但似乎并没有人认领。",
	Bundle = "packed_event_sea",
	Atlas = "Event_SEA",
	Icon = "SEA_Event_12",
	TriggerCondition = {
		NeedExploreTime = 86400,
		ConditionList = {
			{
				Condition = "TeamCharacterIdAnd",
				Value = 
				{
					220426,
					220427,
					220430,
				},
			},
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
EventConfig[EventID.Id808] =
{
	Id = 808,
	Name = "我们好亮啊！",
	Gallery = 950005,
	Area = 130203,
	LockDesc = "解锁提示\n一次性探索浅海沙滩1天\n(需要一位长生不老的角色和一位不能被他人触碰的角色)",
	Desc = "当在晴天来到沙滩上玩耍时，纱纱和丝丝就会变得闪闪发光。",
	Bundle = "packed_event_sea",
	Atlas = "Event_SEA",
	Icon = "SEA_Event_15",
	TriggerCondition = {
		NeedExploreTime = 86400,
		ConditionList = {
			{
				Condition = "TeamCharacterIdAnd",
				Value = 
				{
					220421,
					220422,
				},
			},
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
EventConfig[EventID.Id809] =
{
	Id = 809,
	Name = "偶像的假日1",
	Gallery = 950005,
	Area = 130203,
	LockDesc = "解锁提示\n一次性探索浅海沙滩1天\n(需要一位头上长尖刺的角色和一位可以为自己充气的角色)",
	Desc = "没有演出的时候，这里就是一片普通的度假海滩，一些偶像有时还会走出大海享受阳光。",
	Bundle = "packed_event_sea",
	Atlas = "Event_SEA",
	Icon = "SEA_Event_9",
	TriggerCondition = {
		NeedExploreTime = 86400,
		ConditionList = {
			{
				Condition = "TeamCharacterIdAnd",
				Value = 
				{
					220413,
					220405,
				},
			},
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
EventConfig[EventID.Id810] =
{
	Id = 810,
	Name = "在下面哦",
	Gallery = 950005,
	Area = 130203,
	LockDesc = "解锁提示\n一次性探索浅海沙滩1天\n(需要一位喜爱玩石头剪刀布且是乐队鼓手的角色)",
	Desc = "海洋星的居民有着各种各样的习性，生活在同一个星球的人也不能全部相互理解，这天就有一位小朋友被埋在沙滩里的蟹香菜绊倒了。",
	Bundle = "packed_event_sea",
	Atlas = "Event_SEA",
	Icon = "SEA_Event_16",
	TriggerCondition = {
		NeedExploreTime = 86400,
		ConditionList = {
			{
				Condition = "TeamCharacterIdAnd",
				Value = 
				{
					220409,
				},
			},
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
EventConfig[EventID.Id811] =
{
	Id = 811,
	Name = "偶像的假日2",
	Gallery = 950005,
	Area = 130203,
	LockDesc = "解锁提示\n一次性探索浅海沙滩1天\n(需要一位喜欢给自己立flag的角色)",
	Desc = "作为海洋星稀有的平坦地区，这里有时会举办沙滩车大赛，冠军将获得一枚特制轮胎。鱼不翻也经常参加，TA还是某项越野赛事记录的保持者。",
	Bundle = "packed_event_sea",
	Atlas = "Event_SEA",
	Icon = "SEA_Event_10",
	TriggerCondition = {
		NeedExploreTime = 86400,
		ConditionList = {
			{
				Condition = "TeamCharacterIdAnd",
				Value = 
				{
					220406,
				},
			},
		},
	},
	Reward = {
		{
			Value = 320540,
			Num = 1,
		},
		{
			Value = 2,
			Num = 20,
		},
	},
}
EventConfig[EventID.Id812] =
{
	Id = 812,
	Name = "背后的汗水",
	Gallery = 950005,
	Area = 130204,
	LockDesc = "解锁提示\n一次性探索休息厅1天12小时\n(需要头顶有尖尖的刺的角色)",
	Desc = "休息厅中，大家都在放松闲聊，只有橘还在对着镜子练习。",
	Bundle = "packed_event_sea",
	Atlas = "Event_SEA",
	Icon = "SEA_Event_24",
	TriggerCondition = {
		NeedExploreTime = 129600,
		ConditionList = {
			{
				Condition = "TeamCharacterIdAnd",
				Value = 
				{
					220418,
				},
			},
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
EventConfig[EventID.Id813] =
{
	Id = 813,
	Name = "不愉快的瞬间",
	Gallery = 950005,
	Area = 130204,
	LockDesc = "解锁提示\n一次性探索休息厅1天\n(需要Aquarius中的两位红发成员)",
	Desc = "突然，休息厅传来了激烈的对话声，赶过去才发现是彩雅和希在因为头发造型的问题争执，经纪人赶紧把TA们拉开。",
	Bundle = "packed_event_sea",
	Atlas = "Event_SEA",
	Icon = "SEA_Event_22",
	TriggerCondition = {
		NeedExploreTime = 86400,
		ConditionList = {
			{
				Condition = "TeamCharacterIdAnd",
				Value = 
				{
					220417,
					220416,
				},
			},
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
EventConfig[EventID.Id814] =
{
	Id = 814,
	Name = "气场",
	Gallery = 950005,
	Area = 130204,
	LockDesc = "解锁提示\n一次性探索休息厅1天\n(需要是sharkalaka偶像团体C位的角色)",
	Desc = "虎鲸京突然进入休息厅，大家激动地把现场团团围住，但没有一个人敢上前搭话，搞得京呆在包围圈里很尴尬。",
	Bundle = "packed_event_sea",
	Atlas = "Event_SEA",
	Icon = "SEA_Event_7",
	TriggerCondition = {
		NeedExploreTime = 86400,
		ConditionList = {
			{
				Condition = "TeamCharacterIdAnd",
				Value = 
				{
					220430,
				},
			},
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
EventConfig[EventID.Id815] =
{
	Id = 815,
	Name = "休息一下",
	Gallery = 950005,
	Area = 130204,
	LockDesc = "解锁提示\n一次性探索休息厅1天\n(需要一位来自人气最高偶像团体的C位角色)",
	Desc = "演出完毕，疲惫的京趴在长椅上睡着了。大家因为心疼在舞台上不间断舞蹈4小时的TA，因此默契地没有叫醒京。",
	Bundle = "packed_event_sea",
	Atlas = "Event_SEA",
	Icon = "SEA_Event_20",
	TriggerCondition = {
		NeedExploreTime = 86400,
		ConditionList = {
			{
				Condition = "TeamCharacterIdAnd",
				Value = 
				{
					220430,
				},
			},
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
EventConfig[EventID.Id816] =
{
	Id = 816,
	Name = "可恶的歹徒",
	Gallery = 950005,
	Area = 130204,
	LockDesc = "解锁提示\n一次性探索休息厅1天\n(需要一位热爱珍珠的角色)",
	Desc = "看到珍回到休息厅后，觊觎珍珠的小偷打算下手，没想到珍直接把它拿出来，亮瞎了小偷的眼睛。为了帮助大家看清海底的路，珍把珍珠送给了大家。",
	Bundle = "packed_event_sea",
	Atlas = "Event_SEA",
	Icon = "SEA_Event_17",
	TriggerCondition = {
		NeedExploreTime = 86400,
		ConditionList = {
			{
				Condition = "TeamCharacterIdAnd",
				Value = 
				{
					220407,
				},
			},
		},
	},
	Reward = {
		{
			Value = 320541,
			Num = 1,
		},
		{
			Value = 2,
			Num = 20,
		},
	},
}
EventConfig[EventID.Id817] =
{
	Id = 817,
	Name = "喷水节",
	Gallery = 950005,
	Area = 130205,
	LockDesc = "解锁提示\n一次性探索回溯镇1天12小时\n(需要会喷出墨汁并solo出道的角色)",
	Desc = "今天是回溯镇一年一度的喷水节，大家通过向其他人喷水来表达对自然的尊敬，但是墨被禁止参加这个活动。",
	Bundle = "packed_event_sea",
	Atlas = "Event_SEA",
	Icon = "SEA_Event_47",
	TriggerCondition = {
		NeedExploreTime = 129600,
		ConditionList = {
			{
				Condition = "TeamCharacterIdAnd",
				Value = 
				{
					220402,
				},
			},
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
EventConfig[EventID.Id818] =
{
	Id = 818,
	Name = "同台",
	Gallery = 950005,
	Area = 130205,
	LockDesc = "解锁提示\n一次性探索回溯镇1天\n(需要一位唱歌能把玻璃震碎的角色，以及和TA一起参与过面试的角色)",
	Desc = "听说海豚凛在回溯镇开起了演唱会，映冬本想混在观众之中，没想到被海豚凛发现了，还邀请TA一起在舞台上唱歌。",
	Bundle = "packed_event_sea",
	Atlas = "Event_SEA",
	Icon = "SEA_Event_48",
	TriggerCondition = {
		NeedExploreTime = 86400,
		ConditionList = {
			{
				Condition = "TeamCharacterIdAnd",
				Value = 
				{
					220401,
					220428,
				},
			},
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
EventConfig[EventID.Id819] =
{
	Id = 819,
	Name = "迷路的虎鲸",
	Gallery = 950005,
	Area = 130205,
	LockDesc = "解锁提示\n一次性探索回溯镇1天\n(需要一位来自人气最高女团的C位角色)",
	Desc = "原本要去大舞台演唱的京，因为自己的导航仪丢失而迷路了，晕头转向地跑到了回溯镇来，但看到当地居民非常狂热，就在当地唱了一曲。",
	Bundle = "packed_event_sea",
	Atlas = "Event_SEA",
	Icon = "SEA_Event_50",
	TriggerCondition = {
		NeedExploreTime = 86400,
		ConditionList = {
			{
				Condition = "TeamCharacterIdAnd",
				Value = 
				{
					220430,
				},
			},
		},
	},
	Reward = {
		{
			Value = 320542,
			Num = 1,
		},
		{
			Value = 2,
			Num = 20,
		},
	},
}
EventConfig[EventID.Id820] =
{
	Id = 820,
	Name = "生活中的偶像",
	Gallery = 950005,
	Area = 130205,
	LockDesc = "解锁提示\n一次性探索回溯镇1天\n(需要曾想应聘化妆师的角色)",
	Desc = "橘的家就住在回溯镇，TA有时会去镇子上的市场买菜并习惯讲价，老板也没有因为TA是偶像就乖乖听话，每次买菜都是一次砍价大战。",
	Bundle = "packed_event_sea",
	Atlas = "Event_SEA",
	Icon = "SEA_Event_49",
	TriggerCondition = {
		NeedExploreTime = 86400,
		ConditionList = {
			{
				Condition = "TeamCharacterIdAnd",
				Value = 
				{
					220418,
				},
			},
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
EventConfig[EventID.Id821] =
{
	Id = 821,
	Name = "特色服务",
	Gallery = 950005,
	Area = 130205,
	LockDesc = "解锁提示\n一次性探索回溯镇1天\n(需要喜欢独处的角色)",
	Desc = "回溯镇的推拿技术在海洋星是一绝，这天，小茨在演唱会结束后来到这里按摩，师傅带上了特制手套，连头上的尖刺都被照顾到了，非常舒适。",
	Bundle = "packed_event_sea",
	Atlas = "Event_SEA",
	Icon = "SEA_Event_52",
	TriggerCondition = {
		NeedExploreTime = 86400,
		ConditionList = {
			{
				Condition = "TeamCharacterIdAnd",
				Value = 
				{
					220413,
				},
			},
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
EventConfig[EventID.Id822] =
{
	Id = 822,
	Name = "私下的密会",
	Gallery = 950005,
	Area = 130206,
	LockDesc = "解锁提示\n一次性探索礁石区1天12小时\n(需要两位接触尤为密切的角色)",
	Desc = "鱼乐日报报道，曾有人目击深潜FoRever的遥和Aquarius的彩雅私下共同前往礁石区。但由于被重重礁石阻隔，并不能听清两个人在说些什么。",
	Bundle = "packed_event_sea",
	Atlas = "Event_SEA",
	Icon = "SEA_Event_38",
	TriggerCondition = {
		NeedExploreTime = 129600,
		ConditionList = {
			{
				Condition = "TeamCharacterIdAnd",
				Value = 
				{
					220412,
					220416,
				},
			},
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
EventConfig[EventID.Id823] =
{
	Id = 823,
	Name = "躲猫猫开始啦",
	Gallery = 950005,
	Area = 130206,
	LockDesc = "解锁提示\n一次性探索礁石区1天12小时\n(需要深潜FoRever中会变色的高智商成员)",
	Desc = "海洋星近期拍摄了一期亲子综艺节目，安排偶像陪小朋友们玩耍。这期嘉宾是舞妍，在躲猫猫环节特地变成了和礁石一样的颜色，结果到结束都没人找到TA。",
	Bundle = "packed_event_sea",
	Atlas = "Event_SEA",
	Icon = "SEA_Event_37",
	TriggerCondition = {
		NeedExploreTime = 129600,
		ConditionList = {
			{
				Condition = "TeamCharacterIdAnd",
				Value = 
				{
					220424,
				},
			},
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
EventConfig[EventID.Id824] =
{
	Id = 824,
	Name = "空战",
	Gallery = 950005,
	Area = 130206,
	LockDesc = "解锁提示\n一次性探索礁石区1天12小时\n(需要会给自己充气的角色)",
	Desc = "又到了海鸟泛滥的季节，海洋星的居民都远离水面。但茉白却一点也不怕，TA充了气之后漂浮到半空中，用自己的尖刺狠狠地扎了那些空中强盗，把它们都赶跑了。",
	Bundle = "packed_event_sea",
	Atlas = "Event_SEA",
	Icon = "SEA_Event_40",
	TriggerCondition = {
		NeedExploreTime = 129600,
		ConditionList = {
			{
				Condition = "TeamCharacterIdAnd",
				Value = 
				{
					220405,
				},
			},
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
EventConfig[EventID.Id825] =
{
	Id = 825,
	Name = "优雅的沉思者",
	Gallery = 950005,
	Area = 130206,
	LockDesc = "解锁提示\n一次性探索礁石区1天\n(需要喜欢独坐沉思的角色)",
	Desc = "礁石滩是海洋星为数不多能超过水面的地方，在月圆之夜，寻沙便会坐在岸边的礁石上，一边欣赏月色一边发呆。",
	Bundle = "packed_event_sea",
	Atlas = "Event_SEA",
	Icon = "SEA_Event_36",
	TriggerCondition = {
		NeedExploreTime = 86400,
		ConditionList = {
			{
				Condition = "TeamCharacterIdAnd",
				Value = 
				{
					220423,
				},
			},
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
EventConfig[EventID.Id826] =
{
	Id = 826,
	Name = "礁石的恩惠",
	Gallery = 950005,
	Area = 130206,
	LockDesc = "解锁提示\n一次性探索礁石区1天\n(需要作为Aquarius团体气氛担当的角色)",
	Desc = "有很多构造神秘的石头分布在礁石区，比如一种常年保持着高温的海底矿石，直接触碰会十分危险，但可以在水中烹饪食材。橘就利用了这种石头做了一桌海底烧烤。",
	Bundle = "packed_event_sea",
	Atlas = "Event_SEA",
	Icon = "SEA_Event_35",
	TriggerCondition = {
		NeedExploreTime = 86400,
		ConditionList = {
			{
				Condition = "TeamCharacterIdAnd",
				Value = 
				{
					220418,
				},
			},
		},
	},
	Reward = {
		{
			Value = 320543,
			Num = 1,
		},
		{
			Value = 2,
			Num = 20,
		},
	},
}
EventConfig[EventID.Id827] =
{
	Id = 827,
	Name = "软体操开始啦",
	Gallery = 950005,
	Area = 130206,
	LockDesc = "解锁提示\n一次性探索礁石区1天\n(需要吃海藻就会变色的角色)",
	Desc = "经过电视台安排，第一期偶像近距离接触的节目正式在海洋星开播了。这次的嘉宾是幻然，TA会教给观众海兔一族的健身软体操。",
	Bundle = "packed_event_sea",
	Atlas = "Event_SEA",
	Icon = "SEA_Event_34",
	TriggerCondition = {
		NeedExploreTime = 86400,
		ConditionList = {
			{
				Condition = "TeamCharacterIdAnd",
				Value = 
				{
					220411,
				},
			},
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
EventConfig[EventID.Id828] =
{
	Id = 828,
	Name = "问好",
	Gallery = 950005,
	Area = 130207,
	LockDesc = "解锁提示\n一次性探索星光小道1天12小时\n(需要Aquarius的主唱和sharkalaka的c位)",
	Desc = "阿卡和京两位偶像途经星光小道，面对狂热的粉丝，TA们大方地和大家打招呼问好。",
	Bundle = "packed_event_sea",
	Atlas = "Event_SEA",
	Icon = "SEA_Event_53",
	TriggerCondition = {
		NeedExploreTime = 129600,
		ConditionList = {
			{
				Condition = "TeamCharacterIdAnd",
				Value = 
				{
					220429,
					220430,
				},
			},
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
EventConfig[EventID.Id829] =
{
	Id = 829,
	Name = "星光志愿者",
	Gallery = 950005,
	Area = 130207,
	LockDesc = "解锁提示\n一次性探索星光小道1天12小时\n(需要一位热爱音乐、互动的DJ角色)",
	Desc = "热爱公益事业的彩特意报名，前来星光小道担当交通志愿者，所有的司机，都必须把车速控制在10码以下哦！",
	Bundle = "packed_event_sea",
	Atlas = "Event_SEA",
	Icon = "SEA_Event_57",
	TriggerCondition = {
		NeedExploreTime = 129600,
		ConditionList = {
			{
				Condition = "TeamCharacterIdAnd",
				Value = 
				{
					220420,
				},
			},
		},
	},
	Reward = {
		{
			Value = 320544,
			Num = 1,
		},
		{
			Value = 2,
			Num = 20,
		},
	},
}
EventConfig[EventID.Id830] =
{
	Id = 830,
	Name = "不安分的小鬼",
	Gallery = 950005,
	Area = 130207,
	LockDesc = "解锁提示\n一次性探索星光小道1天12小时\n(需要是一位不管走到哪里都会遇上案件的少年)",
	Desc = "明明答应过听从冒险者们的安排，蓝衣小学生却还是逃离大部队去其它地方玩耍，结果被魔法师用瞬移魔法抓了个正着。",
	Bundle = "packed_event_sea",
	Atlas = "Event_SEA",
	Icon = "SEA_Event_8",
	TriggerCondition = {
		NeedExploreTime = 129600,
		ConditionList = {
			{
				Condition = "TeamCharacterIdAnd",
				Value = 
				{
					220322,
				},
			},
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
EventConfig[EventID.Id831] =
{
	Id = 831,
	Name = "姐妹，加油啊！",
	Gallery = 950005,
	Area = 130207,
	LockDesc = "解锁提示\n一次性探索星光小道1天\n(需要每天醒来都会改变模样的角色)",
	Desc = "演出马上就要开始了，来陪伴朋友参加节目的幻然却非常难过。原来是二人无法打到车，被迫滞留在了星光小道。",
	Bundle = "packed_event_sea",
	Atlas = "Event_SEA",
	Icon = "SEA_Event_55",
	TriggerCondition = {
		NeedExploreTime = 86400,
		ConditionList = {
			{
				Condition = "TeamCharacterIdAnd",
				Value = 
				{
					220411,
				},
			},
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
EventConfig[EventID.Id832] =
{
	Id = 832,
	Name = "秘技：不翻车！",
	Gallery = 950005,
	Area = 130207,
	LockDesc = "解锁提示\n一次性探索星光小道1天\n(需要一位坚信自己绝不翻车的角色)",
	Desc = "据说星光小道里有很多开车的司机，把“绝不能翻车”刻进DNA里的鱼不翻，特意前来学习不翻车的秘技。",
	Bundle = "packed_event_sea",
	Atlas = "Event_SEA",
	Icon = "SEA_Event_56",
	TriggerCondition = {
		NeedExploreTime = 86400,
		ConditionList = {
			{
				Condition = "TeamCharacterIdAnd",
				Value = 
				{
					220406,
				},
			},
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
EventConfig[EventID.Id833] =
{
	Id = 833,
	Name = "潜水的鲨鱼",
	Gallery = 950005,
	Area = 130208,
	LockDesc = "解锁提示\n一次性探索深海区1天12小时\n(需要海洋星人气第一偶像团队中，不是c位的两位成员)",
	Desc = "在依伶的劝说下，牙牙终于同意来深海区进行潜水比赛，锻炼身体。几百回合下来，两个人都气喘吁吁地躺在岸边。",
	Bundle = "packed_event_sea",
	Atlas = "Event_SEA",
	Icon = "SEA_Event_67",
	TriggerCondition = {
		NeedExploreTime = 129600,
		ConditionList = {
			{
				Condition = "TeamCharacterIdAnd",
				Value = 
				{
					220427,
					220426,
				},
			},
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
EventConfig[EventID.Id834] =
{
	Id = 834,
	Name = "神秘的仪式",
	Gallery = 950005,
	Area = 130208,
	LockDesc = "解锁提示\n一次性探索深海区1天12小时\n(需要一位可以长生不老的角色)",
	Desc = "无人光顾的海底，正进行着神秘的仪式，丝丝躺在冰冷的海底蜷缩成一团，TA即将在这里进行长达数个月的长眠，直至完成下一次返老还童。",
	Bundle = "packed_event_sea",
	Atlas = "Event_SEA",
	Icon = "SEA_Event_71",
	TriggerCondition = {
		NeedExploreTime = 129600,
		ConditionList = {
			{
				Condition = "TeamCharacterIdAnd",
				Value = 
				{
					220422,
				},
			},
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
EventConfig[EventID.Id835] =
{
	Id = 835,
	Name = "美丽的心",
	Gallery = 950005,
	Area = 130208,
	LockDesc = "解锁提示\n一次性探索深海区1天12小时\n(需要一位随身携带灯泡的角色)",
	Desc = "因为缺少光源的问题，海底经常会发生交通事故，为了减少类似问题，明在业余时间主动承担起照明的工作，在繁忙的路口点亮前行的路。",
	Bundle = "packed_event_sea",
	Atlas = "Event_SEA",
	Icon = "SEA_Event_74",
	TriggerCondition = {
		NeedExploreTime = 129600,
		ConditionList = {
			{
				Condition = "TeamCharacterIdAnd",
				Value = 
				{
					220419,
				},
			},
		},
	},
	Reward = {
		{
			Value = 320545,
			Num = 1,
		},
		{
			Value = 2,
			Num = 20,
		},
	},
}
EventConfig[EventID.Id836] =
{
	Id = 836,
	Name = "海底明灯",
	Gallery = 950005,
	Area = 130208,
	LockDesc = "解锁提示\n一次性探索深海区1天\n(需要一位发出金黄色亮光的颜色)",
	Desc = "在黑暗之中，纱纱的身上发出了金色的光芒，深海居民情不自禁地朝着光亮处聚集了过去。",
	Bundle = "packed_event_sea",
	Atlas = "Event_SEA",
	Icon = "SEA_Event_42",
	TriggerCondition = {
		NeedExploreTime = 86400,
		ConditionList = {
			{
				Condition = "TeamCharacterIdAnd",
				Value = 
				{
					220421,
				},
			},
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
EventConfig[EventID.Id837] =
{
	Id = 837,
	Name = "深海定位",
	Gallery = 950005,
	Area = 130208,
	LockDesc = "解锁提示\n一次性探索深海区1天\n(需要海豚凛)",
	Desc = "深海区的水道狭长蜿蜒，很容易迷失方向，但海豚凛却能准确辨认出前进的道路。因此，多亏了TA，大家才能成功走出这里。",
	Bundle = "packed_event_sea",
	Atlas = "Event_SEA",
	Icon = "SEA_Event_70",
	TriggerCondition = {
		NeedExploreTime = 86400,
		ConditionList = {
			{
				Condition = "TeamCharacterIdAnd",
				Value = 
				{
					220401,
				},
			},
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
EventConfig[EventID.Id838] =
{
	Id = 838,
	Name = "神秘的交易",
	Gallery = 950005,
	Area = 130209,
	LockDesc = "解锁提示\n一次性探索演播厅1天12小时\n(需要一位作为海蛇好友的角色)",
	Desc = "有记者爆料，曾目击到莱斯莉在演播厅后台，和海蛇进行着某种交易，但这件事很快就被压了下去，任何媒体都没有进行调查报道。",
	Bundle = "packed_event_sea",
	Atlas = "Event_SEA",
	Icon = "SEA_Event_45",
	TriggerCondition = {
		NeedExploreTime = 129600,
		ConditionList = {
			{
				Condition = "TeamCharacterIdAnd",
				Value = 
				{
					220425,
				},
			},
		},
	},
	Reward = {
		{
			Value = 320546,
			Num = 1,
		},
		{
			Value = 2,
			Num = 20,
		},
	},
}
EventConfig[EventID.Id839] =
{
	Id = 839,
	Name = "炎热之下",
	Gallery = 950005,
	Area = 130209,
	LockDesc = "解锁提示\n一次性探索演播厅1天12小时\n(需要作为热情DJ的角色)",
	Desc = "Sealing's Voice的演唱会召开了，粉丝们非常兴奋，现场的气氛也很火热。粉丝们跟着彩的节奏挥舞荧光棒，密密麻麻的光点，让彩快要看晕过去了。",
	Bundle = "packed_event_sea",
	Atlas = "Event_SEA",
	Icon = "SEA_Event_14",
	TriggerCondition = {
		NeedExploreTime = 129600,
		ConditionList = {
			{
				Condition = "TeamCharacterIdAnd",
				Value = 
				{
					220420,
				},
			},
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
EventConfig[EventID.Id840] =
{
	Id = 840,
	Name = "深潜者，上浮啦！",
	Gallery = 950005,
	Area = 130209,
	LockDesc = "解锁提示\n一次性探索演播厅1天12小时\n(需要会发电的角色)",
	Desc = "今天是伊俄来到演播厅演出的日子，但是粉丝们发现，无论是键盘还是话筒，似乎都没有插电。难道是伊俄自己在为爱发电吗？",
	Bundle = "packed_event_sea",
	Atlas = "Event_SEA",
	Icon = "SEA_Event_6",
	TriggerCondition = {
		NeedExploreTime = 129600,
		ConditionList = {
			{
				Condition = "TeamCharacterIdAnd",
				Value = 
				{
					220403,
				},
			},
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
EventConfig[EventID.Id841] =
{
	Id = 841,
	Name = "另一番天地",
	Gallery = 950005,
	Area = 130209,
	LockDesc = "解锁提示\n一次性探索演播厅1天12小时",
	Desc = "穿越星光小道，就能迎来另一番天地，那里宽阔明亮，据说是艺人们彩排和演出的好地方。",
	Bundle = "packed_event_sea",
	Atlas = "Event_SEA",
	Icon = "SEA_Event_46",
	TriggerCondition = {
		NeedExploreTime = 129600,
	},
	Reward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
EventConfig[EventID.Id842] =
{
	Id = 842,
	Name = "新衣服",
	Gallery = 950005,
	Area = 130210,
	LockDesc = "解锁提示\n一次性探索面试舞台1天12小时\n(需要头顶星星的角色)",
	Desc = "面试舞台的后台里，寻沙正在跟经纪人商量，下一次演出，要购买什么颜色的衣服，来搭配自己的海星发夹。",
	Bundle = "packed_event_sea",
	Atlas = "Event_SEA",
	Icon = "SEA_Event_58",
	TriggerCondition = {
		NeedExploreTime = 129600,
		ConditionList = {
			{
				Condition = "TeamCharacterIdAnd",
				Value = 
				{
					220423,
				},
			},
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
EventConfig[EventID.Id843] =
{
	Id = 843,
	Name = "定制新款",
	Gallery = 950005,
	Area = 130210,
	LockDesc = "解锁提示\n一次性探索面试舞台1天12小时\n(需要一位演出时喜欢穿西服皮鞋的角色)",
	Desc = "因为上一次演出的时候跳得太猛烈而撕坏了西服，凉风正在和裁缝商量着设计一款更加结实得演出服。",
	Bundle = "packed_event_sea",
	Atlas = "Event_SEA",
	Icon = "SEA_Event_60",
	TriggerCondition = {
		NeedExploreTime = 129600,
		ConditionList = {
			{
				Condition = "TeamCharacterIdAnd",
				Value = 
				{
					220414,
				},
			},
		},
	},
	Reward = {
		{
			Value = 320547,
			Num = 1,
		},
		{
			Value = 2,
			Num = 20,
		},
	},
}
EventConfig[EventID.Id844] =
{
	Id = 844,
	Name = "意向陈述",
	Gallery = 950005,
	Area = 130210,
	LockDesc = "解锁提示\n一次性探索面试舞台1天12小时",
	Desc = "今天座谈会的上客是小茨和橘，经纪人正在询问TA们有关成年后选择性别的意向。",
	Bundle = "packed_event_sea",
	Atlas = "Event_SEA",
	Icon = "SEA_Event_59",
	TriggerCondition = {
		NeedExploreTime = 129600,
	},
	Reward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
EventConfig[EventID.Id845] =
{
	Id = 845,
	Name = "极限的偶像",
	Gallery = 950005,
	Area = 130210,
	LockDesc = "解锁提示\n一次性探索面试舞台1天\n(需要Aquarius中一位刘海凌乱发型炫酷的角色)",
	Desc = "斗鱼希最初进行经纪公司的面试时，被排在当天最后一位。那时所有评委都昏昏欲睡，而希一边大喊一边冲着大浪踏上舞台，立刻点燃了全场的气氛。",
	Bundle = "packed_event_sea",
	Atlas = "Event_SEA",
	Icon = "SEA_Event_13",
	TriggerCondition = {
		NeedExploreTime = 86400,
		ConditionList = {
			{
				Condition = "TeamCharacterIdAnd",
				Value = 
				{
					220417,
				},
			},
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
EventConfig[EventID.Id846] =
{
	Id = 846,
	Name = "裁缝之心",
	Gallery = 950005,
	Area = 130210,
	LockDesc = "解锁提示\n一次性探索面试舞台1天\n(需要会使用剪刀手的鼓手角色)",
	Desc = "服装间里，香菜正在和老师学习着时装设计，因为能裁剪出非常漂亮的布料，TA被认为很有当裁缝的潜力。",
	Bundle = "packed_event_sea",
	Atlas = "Event_SEA",
	Icon = "SEA_Event_61",
	TriggerCondition = {
		NeedExploreTime = 86400,
		ConditionList = {
			{
				Condition = "TeamCharacterIdAnd",
				Value = 
				{
					220409,
				},
			},
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
EventConfig[EventID.Id847] =
{
	Id = 847,
	Name = "即兴SOLO",
	Gallery = 950005,
	Area = 130211,
	LockDesc = "解锁提示\n一次性探索大舞台1天12小时\n(需要tea time的两位角色)",
	Desc = "在贝壳街tea time演出的时候，美莎突然灵感爆发，用海螺来了一段即兴SOLO。珍也十分配合地跟着伴唱，把气氛炒热到了极点。",
	Bundle = "packed_event_sea",
	Atlas = "Event_SEA",
	Icon = "SEA_Event_64",
	TriggerCondition = {
		NeedExploreTime = 129600,
		ConditionList = {
			{
				Condition = "TeamCharacterIdAnd",
				Value = 
				{
					220407,
					220408,
				},
			},
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
EventConfig[EventID.Id848] =
{
	Id = 848,
	Name = "眼疾手快",
	Gallery = 950005,
	Area = 130211,
	LockDesc = "解锁提示\n一次性探索大舞台1天12小时\n(需要一位拥有触手的高智商角色)",
	Desc = "遥正趴在岩石上，俯视着身下灯光熠熠的大舞台。突然暗流涌动，TA一不小心跌落下去，还好舞妍立刻伸出了一条触手把TA拉了上来。",
	Bundle = "packed_event_sea",
	Atlas = "Event_SEA",
	Icon = "SEA_Event_44",
	TriggerCondition = {
		NeedExploreTime = 129600,
		ConditionList = {
			{
				Condition = "TeamCharacterIdAnd",
				Value = 
				{
					220424,
				},
			},
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
EventConfig[EventID.Id849] =
{
	Id = 849,
	Name = "牙牙的决意",
	Gallery = 950005,
	Area = 130211,
	LockDesc = "解锁提示\n一次性探索大舞台1天12小时",
	Desc = "走上舞台之前，牙牙回忆起这一路走来遇到的各种事，TA深深地吸了一口气，露出自信的笑容走上了舞台。",
	Bundle = "packed_event_sea",
	Atlas = "Event_SEA",
	Icon = "SEA_Event_65",
	TriggerCondition = {
		NeedExploreTime = 129600,
	},
	Reward = {
		{
			Value = 320548,
			Num = 1,
		},
		{
			Value = 2,
			Num = 20,
		},
	},
}
EventConfig[EventID.Id850] =
{
	Id = 850,
	Name = "王者的余裕",
	Gallery = 950005,
	Area = 130211,
	LockDesc = "解锁提示\n一次性探索大舞台1天\n(需要人气最高偶像团体的人气top角色)",
	Desc = "后台中，工作人员和参演的偶像们都有些紧张，唯有京安然地坐在椅子上发呆，看上去一点都不担心马上就要开始的直播表演。",
	Bundle = "packed_event_sea",
	Atlas = "Event_SEA",
	Icon = "SEA_Event_66",
	TriggerCondition = {
		NeedExploreTime = 86400,
		ConditionList = {
			{
				Condition = "TeamCharacterIdAnd",
				Value = 
				{
					220430,
				},
			},
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
EventConfig[EventID.Id851] =
{
	Id = 851,
	Name = "异发族",
	Gallery = 950005,
	Area = 130211,
	LockDesc = "解锁提示\n一次性探索大舞台1天",
	Desc = "演出前，彩雅、希和橘并坐在沙发上闭目养神，从后面看就好像一丛五彩斑斓的灌木。",
	Bundle = "packed_event_sea",
	Atlas = "Event_SEA",
	Icon = "SEA_Event_62",
	TriggerCondition = {
		NeedExploreTime = 86400,
	},
	Reward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
EventConfig[EventID.Id852] =
{
	Id = 852,
	Name = "误会",
	Gallery = 950005,
	Area = 130212,
	LockDesc = "解锁提示\n一次性探索高音剧场2天\n(需要与小丑遥关系匪浅的某位角色)",
	Desc = "彩雅每次到高音剧场时，都会因为发色过于鲜艳被误认为是危险分子，TA不得不出示自己的“安全证明”。",
	Bundle = "packed_event_sea",
	Atlas = "Event_SEA",
	Icon = "SEA_Event_69",
	TriggerCondition = {
		NeedExploreTime = 172800,
		ConditionList = {
			{
				Condition = "TeamCharacterIdAnd",
				Value = 
				{
					220416,
				},
			},
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
EventConfig[EventID.Id853] =
{
	Id = 853,
	Name = "海底探险者",
	Gallery = 950005,
	Area = 130212,
	LockDesc = "解锁提示\n一次性探索高音剧场1天12小时\n(需要呜呜 漆漆)",
	Desc = "在伊俄的带领下，大家第一次来到了海洋星的高音剧场，对于这块鲜有人知的剧场，大家都表示非常好奇。",
	Bundle = "packed_event_sea",
	Atlas = "Event_SEA",
	Icon = "SEA_Event_72",
	TriggerCondition = {
		NeedExploreTime = 129600,
		ConditionList = {
			{
				Condition = "TeamCharacterIdAnd",
				Value = 
				{
					220001,
					220002,
				},
			},
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
EventConfig[EventID.Id854] =
{
	Id = 854,
	Name = "小心行驶",
	Gallery = 950005,
	Area = 130212,
	LockDesc = "解锁提示\n一次性探索高音剧场1天12小时\n(需要族中爸爸孕育孩子的角色)",
	Desc = "希波以TA一贯的速度在奔跑，却被当地警察拦下，并教育TA重读深海区的限速规则，幸亏有经纪人帮忙道歉才没有扩大影响。",
	Bundle = "packed_event_sea",
	Atlas = "Event_SEA",
	Icon = "SEA_Event_68",
	TriggerCondition = {
		NeedExploreTime = 129600,
		ConditionList = {
			{
				Condition = "TeamCharacterIdAnd",
				Value = 
				{
					220415,
				},
			},
		},
	},
	Reward = {
		{
			Value = 320549,
			Num = 1,
		},
		{
			Value = 2,
			Num = 20,
		},
	},
}
EventConfig[EventID.Id855] =
{
	Id = 855,
	Name = "深海少女",
	Gallery = 950005,
	Area = 130212,
	LockDesc = "解锁提示\n一次性探索高音剧场1天\n(需要一位作为全村希望而出道的角色)",
	Desc = "椰子终于完成了自己的第一次演唱会，粉丝们在台下欢呼，鼓励TA带来更棒的表演和作品。",
	Bundle = "packed_event_sea",
	Atlas = "Event_SEA",
	Icon = "SEA_Event_73",
	TriggerCondition = {
		NeedExploreTime = 86400,
		ConditionList = {
			{
				Condition = "TeamCharacterIdAnd",
				Value = 
				{
					220404,
				},
			},
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
EventConfig[EventID.Id856] =
{
	Id = 856,
	Name = "珊瑚家族",
	Gallery = 950005,
	Area = 130213,
	LockDesc = "解锁提示\n一次性探索海底世界2天\n(需要一位家里有矿的角色)",
	Desc = "海洋星最大的报社对阿卡进行了一次采访，但是来采访的记者和摄影师也都是珊瑚，TA们说着说着就很自然地笑了起来……后来才知道，原来报社就是阿卡的家族开的。",
	Bundle = "packed_event_sea",
	Atlas = "Event_SEA",
	Icon = "SEA_Event_19",
	TriggerCondition = {
		NeedExploreTime = 172800,
		ConditionList = {
			{
				Condition = "TeamCharacterIdAnd",
				Value = 
				{
					220429,
				},
			},
		},
	},
	Reward = {
		{
			Value = 320550,
			Num = 1,
		},
		{
			Value = 2,
			Num = 20,
		},
	},
}
EventConfig[EventID.Id857] =
{
	Id = 857,
	Name = "心细的珊瑚",
	Gallery = 950005,
	Area = 130213,
	LockDesc = "解锁提示\n一次性探索海底世界1天12小时\n(需要一位富裕且唱歌天赋极高的角色)",
	Desc = "就在工作人员对人数庞杂的Aquarius资料统计感到迷茫时，阿卡及时出现，从容地把需要的资料内容报给对方。",
	Bundle = "packed_event_sea",
	Atlas = "Event_SEA",
	Icon = "SEA_Event_63",
	TriggerCondition = {
		NeedExploreTime = 129600,
		ConditionList = {
			{
				Condition = "TeamCharacterIdAnd",
				Value = 
				{
					220429,
				},
			},
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
EventConfig[EventID.Id858] =
{
	Id = 858,
	Name = "钢铁与过去",
	Gallery = 950005,
	Area = 130213,
	LockDesc = "解锁提示\n一次性探索海底世界1天12小时\n(需要一位sharkalaka中的老好人)",
	Desc = "偶然间路过面试舞台，发现依伶在和家里人争论着什么，本打算当作没发现悄悄溜走，没想到不一会TA们居然拿着剑打了起来。经过劝解才知道，原来依伶的家庭是剑术世家。",
	Bundle = "packed_event_sea",
	Atlas = "Event_SEA",
	Icon = "SEA_Event_18",
	TriggerCondition = {
		NeedExploreTime = 129600,
		ConditionList = {
			{
				Condition = "TeamCharacterIdAnd",
				Value = 
				{
					220427,
				},
			},
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
EventConfig[EventID.Id859] =
{
	Id = 859,
	Name = "凛凛之花",
	Gallery = 950005,
	Area = 130213,
	LockDesc = "解锁提示\n一次性探索海底世界1天12小时",
	Desc = "在人山人海的海底舞会上，有居民因为过于激动而缺氧，海豚凛主动将TA送去了安全的地方。",
	Bundle = "packed_event_sea",
	Atlas = "Event_SEA",
	Icon = "SEA_Event_31",
	TriggerCondition = {
		NeedExploreTime = 129600,
	},
	Reward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
EventConfig[EventID.Id860] =
{
	Id = 860,
	Name = "危险游戏",
	Gallery = 950005,
	Area = 130214,
	LockDesc = "解锁提示\n一次性探索大漩涡2天\n(需要鱼妄想中的两位成员)",
	Desc = "大漩涡一直都是海洋星居民心目中危险的地方，但也有不少人喜欢来这里挑战刺激。例如今天，凉风和不翻就来到这里，跳进漩涡逆着潮流游泳。",
	Bundle = "packed_event_sea",
	Atlas = "Event_SEA",
	Icon = "SEA_Event_25",
	TriggerCondition = {
		NeedExploreTime = 172800,
		ConditionList = {
			{
				Condition = "TeamCharacterIdAnd",
				Value = 
				{
					220414,
					220406,
				},
			},
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
EventConfig[EventID.Id861] =
{
	Id = 861,
	Name = "随波逐流的偶像",
	Gallery = 950005,
	Area = 130214,
	LockDesc = "解锁提示\n一次性探索大漩涡2天\n(需要作为虎鲸京粉丝的角色)",
	Desc = "在去海底舞会的路上，映冬一不小心跌进了大漩涡，大家都着急地想帮忙，TA却从容地一边转圈一边歌唱。",
	Bundle = "packed_event_sea",
	Atlas = "Event_SEA",
	Icon = "SEA_Event_26",
	TriggerCondition = {
		NeedExploreTime = 172800,
		ConditionList = {
			{
				Condition = "TeamCharacterIdAnd",
				Value = 
				{
					220428,
				},
			},
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
EventConfig[EventID.Id862] =
{
	Id = 862,
	Name = "回家",
	Gallery = 950005,
	Area = 130214,
	LockDesc = "解锁提示\n一次性探索大漩涡1天12小时\n(需要一位作为灯光师的角色)",
	Desc = "虽然大部分居民都很害怕漩涡，但对于深海族来说这里是回家的必经之路。每放年假，鮟鱇明都会从这里回到故乡。",
	Bundle = "packed_event_sea",
	Atlas = "Event_SEA",
	Icon = "SEA_Event_29",
	TriggerCondition = {
		NeedExploreTime = 129600,
		ConditionList = {
			{
				Condition = "TeamCharacterIdAnd",
				Value = 
				{
					220419,
				},
			},
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
EventConfig[EventID.Id863] =
{
	Id = 863,
	Name = "再快一点",
	Gallery = 950005,
	Area = 130214,
	LockDesc = "解锁提示\n一次性探索大漩涡1天12小时\n(需要一位拥有着风一般的绝世舞功的角色)",
	Desc = "这天，大家在大漩涡目睹到了令人震惊的一幕，希波为了挑战极限的速度，在大漩涡旁边飞速转圈奔跑，还把秒表塞给了我们。",
	Bundle = "packed_event_sea",
	Atlas = "Event_SEA",
	Icon = "SEA_Event_28",
	TriggerCondition = {
		NeedExploreTime = 129600,
		ConditionList = {
			{
				Condition = "TeamCharacterIdAnd",
				Value = 
				{
					220415,
				},
			},
		},
	},
	Reward = {
		{
			Value = 320551,
			Num = 1,
		},
		{
			Value = 2,
			Num = 20,
		},
	},
}
EventConfig[EventID.Id864] =
{
	Id = 864,
	Name = "黑旋风",
	Gallery = 950005,
	Area = 130214,
	LockDesc = "解锁提示\n一次性探索大漩涡1天12小时\n(需要一位会喷出墨汁的紫发角色)",
	Desc = "来到大漩涡体验极限运动的墨其实非常害怕，一不小心喷出了很多墨汁，把整个漩涡染成了墨色。",
	Bundle = "packed_event_sea",
	Atlas = "Event_SEA",
	Icon = "SEA_Event_32",
	TriggerCondition = {
		NeedExploreTime = 129600,
		ConditionList = {
			{
				Condition = "TeamCharacterIdAnd",
				Value = 
				{
					220402,
				},
			},
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}

