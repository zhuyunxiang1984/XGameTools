MiniGameStarRewardConfig ={};
MiniGameStarRewardID = 
{
	Id001 = 970001,
	Id002 = 970002,
}
MiniGameStarRewardConfig[MiniGameStarRewardID.Id001] =
{
	Id = 1,
	StarRewardList = {
		{
			NeedStar = 3,
			Id = 327314,
			Num = 20,
			PassCheckId = 327314,
			PassCheckNum = 80,
		},
		{
			NeedStar = 6,
			Id = 327314,
			Num = 25,
			PassCheckId = 327314,
			PassCheckNum = 100,
		},
		{
			NeedStar = 9,
			Id = 1,
			Num = 50000,
			PassCheckId = 232273,
			PassCheckNum = 1,
		},
		{
			NeedStar = 12,
			Id = 327314,
			Num = 25,
			PassCheckId = 327314,
			PassCheckNum = 100,
		},
		{
			NeedStar = 16,
			Id = 330003,
			Num = 5,
			PassCheckId = 2,
			PassCheckNum = 1080,
		},
		{
			NeedStar = 20,
			Id = 327314,
			Num = 40,
			PassCheckId = 327314,
			PassCheckNum = 200,
		},
		{
			NeedStar = 24,
			Id = 327314,
			Num = 40,
			PassCheckId = 327314,
			PassCheckNum = 200,
		},
		{
			NeedStar = 28,
			Id = 1,
			Num = 100000,
			PassCheckId = 232275,
			PassCheckNum = 1,
		},
		{
			NeedStar = 32,
			Id = 327314,
			Num = 40,
			PassCheckId = 327314,
			PassCheckNum = 200,
		},
		{
			NeedStar = 36,
			Id = 2,
			Num = 200,
			PassCheckId = 2,
			PassCheckNum = 1080,
		},
		{
			NeedStar = 40,
			Id = 327314,
			Num = 30,
			PassCheckId = 327314,
			PassCheckNum = 120,
		},
		{
			NeedStar = 45,
			Id = 327314,
			Num = 30,
			PassCheckId = 327314,
			PassCheckNum = 120,
		},
		{
			NeedStar = 50,
			Id = 327314,
			Num = 30,
			PassCheckId = 327314,
			PassCheckNum = 120,
		},
		{
			NeedStar = 55,
			Id = 327314,
			Num = 20,
			PassCheckId = 327314,
			PassCheckNum = 80,
		},
		{
			NeedStar = 60,
			Id = 327314,
			Num = 20,
			PassCheckId = 327314,
			PassCheckNum = 80,
		},
		{
			NeedStar = 70,
			Id = 327314,
			Num = 20,
			PassCheckId = 327314,
			PassCheckNum = 80,
		},
	},
}
MiniGameStarRewardConfig[MiniGameStarRewardID.Id002] =
{
	Id = 2,
	StarRewardList = {
		{
			NeedStar = 3,
			Id = 2,
			Num = 100,
			PassCheckId = 1,
			PassCheckNum = 100,
		},
		{
			NeedStar = 6,
			Id = 2,
			Num = 100,
			PassCheckId = 1,
			PassCheckNum = 100,
		},
	},
}

