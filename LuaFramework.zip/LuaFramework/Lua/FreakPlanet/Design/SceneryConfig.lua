SceneryConfig ={};
SceneryID = 
{
	Id001 = 880001,
	Id002 = 880002,
	Id003 = 880003,
	Id004 = 880004,
	Id005 = 880005,
	Id006 = 880006,
	Id007 = 880007,
	Id008 = 880008,
	Id009 = 880009,
	Id010 = 880010,
	Id011 = 880011,
	Id012 = 880012,
	Id013 = 880013,
}
SceneryConfig[SceneryID.Id001] =
{
	Id = 1,
	Name = "草",
	Type = 2,
	Desc = "一株平平无奇的草。",
	ImageName = "Scenery_Grass_001",
	SizeX = 1,
	SizeY = 1,
}
SceneryConfig[SceneryID.Id002] =
{
	Id = 2,
	Name = "杂草",
	Type = 2,
	Desc = "长得很高的杂草，有的能盖过小孩的头。",
	ImageName = "Scenery_Grass_001",
	SizeX = 1,
	SizeY = 1,
}
SceneryConfig[SceneryID.Id003] =
{
	Id = 3,
	Name = "水草",
	Type = 2,
	Desc = "长在河里的草，这解释很合理。",
	ImageName = "Scenery_Grass_001",
	SizeX = 1,
	SizeY = 1,
}
SceneryConfig[SceneryID.Id004] =
{
	Id = 4,
	Name = "干草",
	Type = 2,
	Desc = "一把就会捏碎的干草，一般生活在沙漠地区。",
	ImageName = "Scenery_Grass_001",
	SizeX = 1,
	SizeY = 1,
}
SceneryConfig[SceneryID.Id005] =
{
	Id = 5,
	Name = "树",
	Type = 2,
	Desc = "一棵平平无奇的树。",
	ImageName = "Scenery_Tree_001",
	SizeX = 1,
	SizeY = 1,
}
SceneryConfig[SceneryID.Id006] =
{
	Id = 6,
	Name = "巨大的树",
	Type = 2,
	Desc = "非常大的数，应该有几百岁了吧。",
	ImageName = "Scenery_Tree_001",
	SizeX = 2,
	SizeY = 2,
}
SceneryConfig[SceneryID.Id007] =
{
	Id = 7,
	Name = "小树苗",
	Type = 2,
	Desc = "小小的树苗，刚刚够得着小朋友的膝盖。",
	ImageName = "Scenery_Tree_001",
	SizeX = 1,
	SizeY = 1,
}
SceneryConfig[SceneryID.Id008] =
{
	Id = 8,
	Name = "地毯",
	Type = 1,
	Desc = "一片平平无奇的地毯。",
	ImageName = "Floor_Carpet_001",
	SizeX = 2,
	SizeY = 1,
}
SceneryConfig[SceneryID.Id009] =
{
	Id = 9,
	Name = "干净的地毯",
	Type = 1,
	Desc = "被打扫得很干净的地毯，一尘不染。",
	ImageName = "Floor_Carpet_001",
	SizeX = 2,
	SizeY = 1,
}
SceneryConfig[SceneryID.Id010] =
{
	Id = 10,
	Name = "起球的地毯",
	Type = 1,
	Desc = "一片地毯，上面已经起球了，但一直没有被打理过。",
	ImageName = "Floor_Carpet_001",
	SizeX = 2,
	SizeY = 1,
}
SceneryConfig[SceneryID.Id011] =
{
	Id = 11,
	Name = "小马驹",
	Type = 2,
	Desc = "刚刚出生的小马驹，对这个世界还很好奇。",
	ImageName = "Scenery_Horse_001",
	SizeX = 1,
	SizeY = 1,
}
SceneryConfig[SceneryID.Id012] =
{
	Id = 12,
	Name = "汗血宝马",
	Type = 2,
	Desc = "大名鼎鼎的汗血宝马，据说一天能跑八百里。",
	ImageName = "Scenery_Horse_001",
	SizeX = 1,
	SizeY = 1,
}
SceneryConfig[SceneryID.Id013] =
{
	Id = 13,
	Name = "驮马",
	Type = 2,
	Desc = "任劳任怨的驮马，因为背负的东西太多，才会直不起腰的吧？",
	ImageName = "Scenery_Horse_001",
	SizeX = 1,
	SizeY = 1,
}
