require "FreakPlanet/Design/MiscConfig"
EquipmentUpgradeConfig ={};
EquipmentUpgradeID = 
{
	Id001 = 930001,
	Id002 = 930002,
	Id003 = 930003,
	Id004 = 930004,
	Id005 = 930005,
	Id006 = 930006,
	Id007 = 930007,
	Id008 = 930008,
	Id009 = 930009,
	Id010 = 930010,
	Id011 = 930011,
	Id012 = 930012,
	Id013 = 930013,
	Id014 = 930014,
	Id015 = 930015,
	Id016 = 930016,
	Id017 = 930017,
	Id018 = 930018,
	Id019 = 930019,
	Id020 = 930020,
	Id021 = 930021,
	Id022 = 930022,
	Id023 = 930023,
	Id024 = 930024,
	Id025 = 930025,
	Id026 = 930026,
	Id027 = 930027,
	Id028 = 930028,
	Id029 = 930029,
	Id030 = 930030,
	Id031 = 930031,
	Id032 = 930032,
	Id033 = 930033,
	Id034 = 930034,
	Id035 = 930035,
	Id036 = 930036,
	Id037 = 930037,
	Id038 = 930038,
	Id039 = 930039,
	Id040 = 930040,
	Id041 = 930041,
	Id042 = 930042,
	Id043 = 930043,
	Id044 = 930044,
	Id045 = 930045,
	Id046 = 930046,
	Id047 = 930047,
	Id048 = 930048,
	Id049 = 930049,
	Id050 = 930050,
	Id051 = 930051,
	Id052 = 930052,
	Id053 = 930053,
	Id054 = 930054,
	Id055 = 930055,
	Id056 = 930056,
	Id057 = 930057,
	Id058 = 930058,
	Id059 = 930059,
	Id060 = 930060,
	Id061 = 930061,
	Id062 = 930062,
	Id063 = 930063,
	Id064 = 930064,
	Id065 = 930065,
	Id066 = 930066,
	Id067 = 930067,
	Id068 = 930068,
	Id069 = 930069,
	Id070 = 930070,
	Id071 = 930071,
	Id072 = 930072,
	Id073 = 930073,
	Id074 = 930074,
	Id075 = 930075,
	Id076 = 930076,
	Id077 = 930077,
	Id078 = 930078,
	Id079 = 930079,
	Id080 = 930080,
	Id081 = 930081,
	Id082 = 930082,
	Id083 = 930083,
	Id084 = 930084,
	Id085 = 930085,
	Id086 = 930086,
	Id087 = 930087,
	Id088 = 930088,
	Id089 = 930089,
	Id090 = 930090,
	Id091 = 930091,
	Id092 = 930092,
	Id093 = 930093,
	Id094 = 930094,
	Id095 = 930095,
	Id096 = 930096,
	Id097 = 930097,
	Id098 = 930098,
	Id099 = 930099,
	Id100 = 930100,
	Id101 = 930101,
	Id102 = 930102,
	Id103 = 930103,
	Id104 = 930104,
	Id105 = 930105,
	Id106 = 930106,
	Id107 = 930107,
	Id108 = 930108,
	Id109 = 930109,
	Id110 = 930110,
	Id111 = 930111,
	Id112 = 930112,
	Id113 = 930113,
	Id114 = 930114,
	Id115 = 930115,
	Id116 = 930116,
	Id117 = 930117,
	Id118 = 930118,
	Id119 = 930119,
	Id120 = 930120,
}
EquipmentUpgradeConfig[EquipmentUpgradeID.Id001] =
{
	LevelList = {
		{
			Level = 1,
			UpgradeCostList = {
				{
					Value = 320041,
					Num = 1,
				},
				{
					Value = 1,
					Num = 10,
				},
			},
		},
		{
			Level = 2,
			UpgradeCostList = {
				{
					Value = 320041,
					Num = 2,
				},
				{
					Value = 1,
					Num = 30,
				},
			},
		},
		{
			Level = 3,
			UpgradeCostList = {
				{
					Value = 320041,
					Num = 6,
				},
				{
					Value = 1,
					Num = 70,
				},
			},
		},
		{
			Level = 4,
			UpgradeCostList = {
				{
					Value = 320041,
					Num = 12,
				},
				{
					Value = 1,
					Num = 150,
				},
			},
		},
		{
			Level = 5,
			UpgradeCostList = {
				{
					Value = 320041,
					Num = 20,
				},
				{
					Value = 1,
					Num = 270,
				},
			},
		},
		{
			Level = 6,
			UpgradeCostList = {
				{
					Value = 320041,
					Num = 35,
				},
				{
					Value = 1,
					Num = 460,
				},
			},
		},
		{
			Level = 7,
			UpgradeCostList = {
				{
					Value = 320042,
					Num = 11,
				},
				{
					Value = 1,
					Num = 720,
				},
			},
		},
		{
			Level = 8,
			UpgradeCostList = {
				{
					Value = 320042,
					Num = 15,
				},
				{
					Value = 1,
					Num = 1000,
				},
			},
		},
		{
			Level = 9,
			UpgradeCostList = {
				{
					Value = 320042,
					Num = 20,
				},
				{
					Value = 1,
					Num = 1400,
				},
			},
		},
	},
}
EquipmentUpgradeConfig[EquipmentUpgradeID.Id002] =
{
	LevelList = {
		{
			Level = 1,
			UpgradeCostList = {
				{
					Value = 320041,
					Num = 1,
				},
				{
					Value = 1,
					Num = 10,
				},
			},
		},
		{
			Level = 2,
			UpgradeCostList = {
				{
					Value = 320041,
					Num = 2,
				},
				{
					Value = 1,
					Num = 30,
				},
			},
		},
		{
			Level = 3,
			UpgradeCostList = {
				{
					Value = 320041,
					Num = 6,
				},
				{
					Value = 1,
					Num = 70,
				},
			},
		},
		{
			Level = 4,
			UpgradeCostList = {
				{
					Value = 320042,
					Num = 2,
				},
				{
					Value = 1,
					Num = 150,
				},
			},
		},
		{
			Level = 5,
			UpgradeCostList = {
				{
					Value = 320042,
					Num = 4,
				},
				{
					Value = 1,
					Num = 270,
				},
			},
		},
		{
			Level = 6,
			UpgradeCostList = {
				{
					Value = 320042,
					Num = 7,
				},
				{
					Value = 1,
					Num = 460,
				},
			},
		},
		{
			Level = 7,
			UpgradeCostList = {
				{
					Value = 320042,
					Num = 11,
				},
				{
					Value = 1,
					Num = 720,
				},
			},
		},
		{
			Level = 8,
			UpgradeCostList = {
				{
					Value = 320042,
					Num = 15,
				},
				{
					Value = 1,
					Num = 1000,
				},
			},
		},
		{
			Level = 9,
			UpgradeCostList = {
				{
					Value = 320042,
					Num = 20,
				},
				{
					Value = 1,
					Num = 1400,
				},
			},
		},
	},
}
EquipmentUpgradeConfig[EquipmentUpgradeID.Id003] =
{
	LevelList = {
		{
			Level = 1,
			UpgradeCostList = {
				{
					Value = 320041,
					Num = 1,
				},
				{
					Value = 1,
					Num = 10,
				},
			},
		},
		{
			Level = 2,
			UpgradeCostList = {
				{
					Value = 320041,
					Num = 2,
				},
				{
					Value = 1,
					Num = 30,
				},
			},
		},
		{
			Level = 3,
			UpgradeCostList = {
				{
					Value = 320041,
					Num = 6,
				},
				{
					Value = 1,
					Num = 70,
				},
			},
		},
		{
			Level = 4,
			UpgradeCostList = {
				{
					Value = 320042,
					Num = 2,
				},
				{
					Value = 1,
					Num = 150,
				},
			},
		},
		{
			Level = 5,
			UpgradeCostList = {
				{
					Value = 320042,
					Num = 4,
				},
				{
					Value = 1,
					Num = 270,
				},
			},
		},
		{
			Level = 6,
			UpgradeCostList = {
				{
					Value = 320042,
					Num = 7,
				},
				{
					Value = 1,
					Num = 460,
				},
			},
		},
		{
			Level = 7,
			UpgradeCostList = {
				{
					Value = 320042,
					Num = 11,
				},
				{
					Value = 1,
					Num = 720,
				},
			},
		},
		{
			Level = 8,
			UpgradeCostList = {
				{
					Value = 320042,
					Num = 15,
				},
				{
					Value = 1,
					Num = 1000,
				},
			},
		},
		{
			Level = 9,
			UpgradeCostList = {
				{
					Value = 320042,
					Num = 20,
				},
				{
					Value = 1,
					Num = 1400,
				},
			},
		},
	},
}
EquipmentUpgradeConfig[EquipmentUpgradeID.Id004] =
{
	LevelList = {
		{
			Level = 1,
			UpgradeCostList = {
				{
					Value = 320041,
					Num = 1,
				},
				{
					Value = 1,
					Num = 10,
				},
			},
		},
		{
			Level = 2,
			UpgradeCostList = {
				{
					Value = 320041,
					Num = 2,
				},
				{
					Value = 1,
					Num = 30,
				},
			},
		},
		{
			Level = 3,
			UpgradeCostList = {
				{
					Value = 320041,
					Num = 6,
				},
				{
					Value = 1,
					Num = 70,
				},
			},
		},
		{
			Level = 4,
			UpgradeCostList = {
				{
					Value = 320042,
					Num = 2,
				},
				{
					Value = 1,
					Num = 150,
				},
			},
		},
		{
			Level = 5,
			UpgradeCostList = {
				{
					Value = 320042,
					Num = 4,
				},
				{
					Value = 1,
					Num = 270,
				},
			},
		},
		{
			Level = 6,
			UpgradeCostList = {
				{
					Value = 320042,
					Num = 7,
				},
				{
					Value = 1,
					Num = 460,
				},
			},
		},
		{
			Level = 7,
			UpgradeCostList = {
				{
					Value = 320042,
					Num = 11,
				},
				{
					Value = 1,
					Num = 720,
				},
			},
		},
		{
			Level = 8,
			UpgradeCostList = {
				{
					Value = 320042,
					Num = 15,
				},
				{
					Value = 1,
					Num = 1000,
				},
			},
		},
		{
			Level = 9,
			UpgradeCostList = {
				{
					Value = 320042,
					Num = 20,
				},
				{
					Value = 1,
					Num = 1400,
				},
			},
		},
	},
}
EquipmentUpgradeConfig[EquipmentUpgradeID.Id005] =
{
	LevelList = {
		{
			Level = 1,
			UpgradeCostList = {
				{
					Value = 320041,
					Num = 2,
				},
				{
					Value = 1,
					Num = 20,
				},
			},
		},
		{
			Level = 2,
			UpgradeCostList = {
				{
					Value = 320041,
					Num = 5,
				},
				{
					Value = 1,
					Num = 60,
				},
			},
		},
		{
			Level = 3,
			UpgradeCostList = {
				{
					Value = 320041,
					Num = 12,
				},
				{
					Value = 1,
					Num = 150,
				},
			},
		},
		{
			Level = 4,
			UpgradeCostList = {
				{
					Value = 320041,
					Num = 20,
				},
				{
					Value = 1,
					Num = 300,
				},
			},
		},
		{
			Level = 5,
			UpgradeCostList = {
				{
					Value = 320041,
					Num = 40,
				},
				{
					Value = 1,
					Num = 550,
				},
			},
		},
		{
			Level = 6,
			UpgradeCostList = {
				{
					Value = 320041,
					Num = 70,
				},
				{
					Value = 1,
					Num = 930,
				},
			},
		},
		{
			Level = 7,
			UpgradeCostList = {
				{
					Value = 320042,
					Num = 20,
				},
				{
					Value = 1,
					Num = 1400,
				},
			},
		},
		{
			Level = 8,
			UpgradeCostList = {
				{
					Value = 320042,
					Num = 30,
				},
				{
					Value = 1,
					Num = 2100,
				},
			},
		},
		{
			Level = 9,
			UpgradeCostList = {
				{
					Value = 320042,
					Num = 45,
				},
				{
					Value = 1,
					Num = 2900,
				},
			},
		},
	},
}
EquipmentUpgradeConfig[EquipmentUpgradeID.Id006] =
{
	LevelList = {
		{
			Level = 1,
			UpgradeCostList = {
				{
					Value = 320041,
					Num = 2,
				},
				{
					Value = 1,
					Num = 20,
				},
			},
		},
		{
			Level = 2,
			UpgradeCostList = {
				{
					Value = 320041,
					Num = 5,
				},
				{
					Value = 1,
					Num = 60,
				},
			},
		},
		{
			Level = 3,
			UpgradeCostList = {
				{
					Value = 320041,
					Num = 12,
				},
				{
					Value = 1,
					Num = 150,
				},
			},
		},
		{
			Level = 4,
			UpgradeCostList = {
				{
					Value = 320042,
					Num = 4,
				},
				{
					Value = 1,
					Num = 300,
				},
			},
		},
		{
			Level = 5,
			UpgradeCostList = {
				{
					Value = 320042,
					Num = 8,
				},
				{
					Value = 1,
					Num = 550,
				},
			},
		},
		{
			Level = 6,
			UpgradeCostList = {
				{
					Value = 320042,
					Num = 14,
				},
				{
					Value = 1,
					Num = 930,
				},
			},
		},
		{
			Level = 7,
			UpgradeCostList = {
				{
					Value = 320043,
					Num = 4,
				},
				{
					Value = 1,
					Num = 1400,
				},
			},
		},
		{
			Level = 8,
			UpgradeCostList = {
				{
					Value = 320043,
					Num = 6,
				},
				{
					Value = 1,
					Num = 2100,
				},
			},
		},
		{
			Level = 9,
			UpgradeCostList = {
				{
					Value = 320043,
					Num = 9,
				},
				{
					Value = 1,
					Num = 2900,
				},
			},
		},
	},
}
EquipmentUpgradeConfig[EquipmentUpgradeID.Id007] =
{
	LevelList = {
		{
			Level = 1,
			UpgradeCostList = {
				{
					Value = 320041,
					Num = 2,
				},
				{
					Value = 1,
					Num = 20,
				},
			},
		},
		{
			Level = 2,
			UpgradeCostList = {
				{
					Value = 320041,
					Num = 5,
				},
				{
					Value = 1,
					Num = 60,
				},
			},
		},
		{
			Level = 3,
			UpgradeCostList = {
				{
					Value = 320041,
					Num = 12,
				},
				{
					Value = 1,
					Num = 150,
				},
			},
		},
		{
			Level = 4,
			UpgradeCostList = {
				{
					Value = 320042,
					Num = 4,
				},
				{
					Value = 1,
					Num = 300,
				},
			},
		},
		{
			Level = 5,
			UpgradeCostList = {
				{
					Value = 320042,
					Num = 8,
				},
				{
					Value = 1,
					Num = 550,
				},
			},
		},
		{
			Level = 6,
			UpgradeCostList = {
				{
					Value = 320042,
					Num = 14,
				},
				{
					Value = 1,
					Num = 930,
				},
			},
		},
		{
			Level = 7,
			UpgradeCostList = {
				{
					Value = 320043,
					Num = 4,
				},
				{
					Value = 1,
					Num = 1400,
				},
			},
		},
		{
			Level = 8,
			UpgradeCostList = {
				{
					Value = 320043,
					Num = 6,
				},
				{
					Value = 1,
					Num = 2100,
				},
			},
		},
		{
			Level = 9,
			UpgradeCostList = {
				{
					Value = 320043,
					Num = 9,
				},
				{
					Value = 1,
					Num = 2900,
				},
			},
		},
	},
}
EquipmentUpgradeConfig[EquipmentUpgradeID.Id008] =
{
	LevelList = {
		{
			Level = 1,
			UpgradeCostList = {
				{
					Value = 320041,
					Num = 2,
				},
				{
					Value = 1,
					Num = 20,
				},
			},
		},
		{
			Level = 2,
			UpgradeCostList = {
				{
					Value = 320041,
					Num = 5,
				},
				{
					Value = 1,
					Num = 60,
				},
			},
		},
		{
			Level = 3,
			UpgradeCostList = {
				{
					Value = 320041,
					Num = 12,
				},
				{
					Value = 1,
					Num = 150,
				},
			},
		},
		{
			Level = 4,
			UpgradeCostList = {
				{
					Value = 320042,
					Num = 4,
				},
				{
					Value = 1,
					Num = 300,
				},
			},
		},
		{
			Level = 5,
			UpgradeCostList = {
				{
					Value = 320042,
					Num = 8,
				},
				{
					Value = 1,
					Num = 550,
				},
			},
		},
		{
			Level = 6,
			UpgradeCostList = {
				{
					Value = 320042,
					Num = 14,
				},
				{
					Value = 1,
					Num = 930,
				},
			},
		},
		{
			Level = 7,
			UpgradeCostList = {
				{
					Value = 320043,
					Num = 4,
				},
				{
					Value = 1,
					Num = 1400,
				},
			},
		},
		{
			Level = 8,
			UpgradeCostList = {
				{
					Value = 320043,
					Num = 6,
				},
				{
					Value = 1,
					Num = 2100,
				},
			},
		},
		{
			Level = 9,
			UpgradeCostList = {
				{
					Value = 320043,
					Num = 9,
				},
				{
					Value = 1,
					Num = 2900,
				},
			},
		},
	},
}
EquipmentUpgradeConfig[EquipmentUpgradeID.Id009] =
{
	LevelList = {
		{
			Level = 1,
			UpgradeCostList = {
				{
					Value = 320041,
					Num = 5,
				},
				{
					Value = 1,
					Num = 80,
				},
			},
		},
		{
			Level = 2,
			UpgradeCostList = {
				{
					Value = 320041,
					Num = 15,
				},
				{
					Value = 1,
					Num = 190,
				},
			},
		},
		{
			Level = 3,
			UpgradeCostList = {
				{
					Value = 320041,
					Num = 35,
				},
				{
					Value = 1,
					Num = 450,
				},
			},
		},
		{
			Level = 4,
			UpgradeCostList = {
				{
					Value = 320041,
					Num = 70,
				},
				{
					Value = 1,
					Num = 920,
				},
			},
		},
		{
			Level = 5,
			UpgradeCostList = {
				{
					Value = 320041,
					Num = 130,
				},
				{
					Value = 1,
					Num = 1600,
				},
			},
		},
		{
			Level = 6,
			UpgradeCostList = {
				{
					Value = 320041,
					Num = 220,
				},
				{
					Value = 1,
					Num = 2800,
				},
			},
		},
		{
			Level = 7,
			UpgradeCostList = {
				{
					Value = 320043,
					Num = 13,
				},
				{
					Value = 1,
					Num = 4300,
				},
			},
		},
		{
			Level = 8,
			UpgradeCostList = {
				{
					Value = 320043,
					Num = 20,
				},
				{
					Value = 1,
					Num = 6300,
				},
			},
		},
		{
			Level = 9,
			UpgradeCostList = {
				{
					Value = 320043,
					Num = 25,
				},
				{
					Value = 1,
					Num = 8800,
				},
			},
		},
	},
}
EquipmentUpgradeConfig[EquipmentUpgradeID.Id010] =
{
	LevelList = {
		{
			Level = 1,
			UpgradeCostList = {
				{
					Value = 320041,
					Num = 5,
				},
				{
					Value = 1,
					Num = 80,
				},
			},
		},
		{
			Level = 2,
			UpgradeCostList = {
				{
					Value = 320041,
					Num = 15,
				},
				{
					Value = 1,
					Num = 190,
				},
			},
		},
		{
			Level = 3,
			UpgradeCostList = {
				{
					Value = 320041,
					Num = 35,
				},
				{
					Value = 1,
					Num = 450,
				},
			},
		},
		{
			Level = 4,
			UpgradeCostList = {
				{
					Value = 320042,
					Num = 14,
				},
				{
					Value = 1,
					Num = 920,
				},
			},
		},
		{
			Level = 5,
			UpgradeCostList = {
				{
					Value = 320042,
					Num = 25,
				},
				{
					Value = 1,
					Num = 1600,
				},
			},
		},
		{
			Level = 6,
			UpgradeCostList = {
				{
					Value = 320042,
					Num = 40,
				},
				{
					Value = 1,
					Num = 2800,
				},
			},
		},
		{
			Level = 7,
			UpgradeCostList = {
				{
					Value = 320043,
					Num = 13,
				},
				{
					Value = 1,
					Num = 4300,
				},
			},
		},
		{
			Level = 8,
			UpgradeCostList = {
				{
					Value = 320043,
					Num = 20,
				},
				{
					Value = 1,
					Num = 6300,
				},
			},
		},
		{
			Level = 9,
			UpgradeCostList = {
				{
					Value = 320043,
					Num = 25,
				},
				{
					Value = 1,
					Num = 8800,
				},
			},
		},
	},
}
EquipmentUpgradeConfig[EquipmentUpgradeID.Id011] =
{
	LevelList = {
		{
			Level = 1,
			UpgradeCostList = {
				{
					Value = 320042,
					Num = 3,
				},
				{
					Value = 1,
					Num = 220,
				},
			},
		},
		{
			Level = 2,
			UpgradeCostList = {
				{
					Value = 320042,
					Num = 11,
				},
				{
					Value = 1,
					Num = 700,
				},
			},
		},
		{
			Level = 3,
			UpgradeCostList = {
				{
					Value = 320042,
					Num = 25,
				},
				{
					Value = 1,
					Num = 1600,
				},
			},
		},
		{
			Level = 4,
			UpgradeCostList = {
				{
					Value = 320043,
					Num = 11,
				},
				{
					Value = 1,
					Num = 3400,
				},
			},
		},
		{
			Level = 5,
			UpgradeCostList = {
				{
					Value = 320043,
					Num = 15,
				},
				{
					Value = 1,
					Num = 6100,
				},
			},
		},
		{
			Level = 6,
			UpgradeCostList = {
				{
					Value = 320043,
					Num = 30,
				},
				{
					Value = 1,
					Num = 10000,
				},
			},
		},
		{
			Level = 7,
			UpgradeCostList = {
				{
					Value = 320044,
					Num = 9,
				},
				{
					Value = 1,
					Num = 15300,
				},
			},
		},
		{
			Level = 8,
			UpgradeCostList = {
				{
					Value = 320044,
					Num = 14,
				},
				{
					Value = 1,
					Num = 22100,
				},
			},
		},
		{
			Level = 9,
			UpgradeCostList = {
				{
					Value = 320044,
					Num = 15,
				},
				{
					Value = 1,
					Num = 30700,
				},
			},
		},
	},
}
EquipmentUpgradeConfig[EquipmentUpgradeID.Id012] =
{
	LevelList = {
		{
			Level = 1,
			UpgradeCostList = {
				{
					Value = 320042,
					Num = 3,
				},
				{
					Value = 1,
					Num = 220,
				},
			},
		},
		{
			Level = 2,
			UpgradeCostList = {
				{
					Value = 320042,
					Num = 11,
				},
				{
					Value = 1,
					Num = 700,
				},
			},
		},
		{
			Level = 3,
			UpgradeCostList = {
				{
					Value = 320042,
					Num = 25,
				},
				{
					Value = 1,
					Num = 1600,
				},
			},
		},
		{
			Level = 4,
			UpgradeCostList = {
				{
					Value = 320043,
					Num = 11,
				},
				{
					Value = 1,
					Num = 3400,
				},
			},
		},
		{
			Level = 5,
			UpgradeCostList = {
				{
					Value = 320043,
					Num = 15,
				},
				{
					Value = 1,
					Num = 6100,
				},
			},
		},
		{
			Level = 6,
			UpgradeCostList = {
				{
					Value = 320043,
					Num = 30,
				},
				{
					Value = 1,
					Num = 10000,
				},
			},
		},
		{
			Level = 7,
			UpgradeCostList = {
				{
					Value = 320044,
					Num = 9,
				},
				{
					Value = 1,
					Num = 15300,
				},
			},
		},
		{
			Level = 8,
			UpgradeCostList = {
				{
					Value = 320044,
					Num = 14,
				},
				{
					Value = 1,
					Num = 22100,
				},
			},
		},
		{
			Level = 9,
			UpgradeCostList = {
				{
					Value = 320044,
					Num = 15,
				},
				{
					Value = 1,
					Num = 30700,
				},
			},
		},
	},
}
EquipmentUpgradeConfig[EquipmentUpgradeID.Id013] =
{
	LevelList = {
		{
			Level = 1,
			UpgradeCostList = {
				{
					Value = 320041,
					Num = 10,
				},
				{
					Value = 1,
					Num = 160,
				},
			},
		},
		{
			Level = 2,
			UpgradeCostList = {
				{
					Value = 320041,
					Num = 30,
				},
				{
					Value = 1,
					Num = 380,
				},
			},
		},
		{
			Level = 3,
			UpgradeCostList = {
				{
					Value = 320041,
					Num = 70,
				},
				{
					Value = 1,
					Num = 900,
				},
			},
		},
		{
			Level = 4,
			UpgradeCostList = {
				{
					Value = 320042,
					Num = 25,
				},
				{
					Value = 1,
					Num = 1800,
				},
			},
		},
		{
			Level = 5,
			UpgradeCostList = {
				{
					Value = 320042,
					Num = 50,
				},
				{
					Value = 1,
					Num = 3300,
				},
			},
		},
		{
			Level = 6,
			UpgradeCostList = {
				{
					Value = 320042,
					Num = 85,
				},
				{
					Value = 1,
					Num = 5600,
				},
			},
		},
		{
			Level = 7,
			UpgradeCostList = {
				{
					Value = 320043,
					Num = 25,
				},
				{
					Value = 1,
					Num = 8600,
				},
			},
		},
		{
			Level = 8,
			UpgradeCostList = {
				{
					Value = 320043,
					Num = 40,
				},
				{
					Value = 1,
					Num = 12600,
				},
			},
		},
		{
			Level = 9,
			UpgradeCostList = {
				{
					Value = 320043,
					Num = 55,
				},
				{
					Value = 1,
					Num = 17700,
				},
			},
		},
	},
}
EquipmentUpgradeConfig[EquipmentUpgradeID.Id014] =
{
	LevelList = {
		{
			Level = 1,
			UpgradeCostList = {
				{
					Value = 320042,
					Num = 2,
				},
				{
					Value = 1,
					Num = 160,
				},
			},
		},
		{
			Level = 2,
			UpgradeCostList = {
				{
					Value = 320042,
					Num = 6,
				},
				{
					Value = 1,
					Num = 380,
				},
			},
		},
		{
			Level = 3,
			UpgradeCostList = {
				{
					Value = 320042,
					Num = 14,
				},
				{
					Value = 1,
					Num = 900,
				},
			},
		},
		{
			Level = 4,
			UpgradeCostList = {
				{
					Value = 320043,
					Num = 5,
				},
				{
					Value = 1,
					Num = 1800,
				},
			},
		},
		{
			Level = 5,
			UpgradeCostList = {
				{
					Value = 320043,
					Num = 10,
				},
				{
					Value = 1,
					Num = 3300,
				},
			},
		},
		{
			Level = 6,
			UpgradeCostList = {
				{
					Value = 320043,
					Num = 15,
				},
				{
					Value = 1,
					Num = 5600,
				},
			},
		},
		{
			Level = 7,
			UpgradeCostList = {
				{
					Value = 320044,
					Num = 5,
				},
				{
					Value = 1,
					Num = 8600,
				},
			},
		},
		{
			Level = 8,
			UpgradeCostList = {
				{
					Value = 320044,
					Num = 8,
				},
				{
					Value = 1,
					Num = 12600,
				},
			},
		},
		{
			Level = 9,
			UpgradeCostList = {
				{
					Value = 320044,
					Num = 11,
				},
				{
					Value = 1,
					Num = 17700,
				},
			},
		},
	},
}
EquipmentUpgradeConfig[EquipmentUpgradeID.Id015] =
{
	LevelList = {
		{
			Level = 1,
			UpgradeCostList = {
				{
					Value = 320043,
					Num = 1,
				},
				{
					Value = 1,
					Num = 440,
				},
			},
		},
		{
			Level = 2,
			UpgradeCostList = {
				{
					Value = 320043,
					Num = 4,
				},
				{
					Value = 1,
					Num = 1400,
				},
			},
		},
		{
			Level = 3,
			UpgradeCostList = {
				{
					Value = 320043,
					Num = 10,
				},
				{
					Value = 1,
					Num = 3300,
				},
			},
		},
		{
			Level = 4,
			UpgradeCostList = {
				{
					Value = 320044,
					Num = 4,
				},
				{
					Value = 1,
					Num = 6900,
				},
			},
		},
		{
			Level = 5,
			UpgradeCostList = {
				{
					Value = 320044,
					Num = 7,
				},
				{
					Value = 1,
					Num = 12300,
				},
			},
		},
		{
			Level = 6,
			UpgradeCostList = {
				{
					Value = 320044,
					Num = 12,
				},
				{
					Value = 1,
					Num = 20100,
				},
			},
		},
		{
			Level = 7,
			UpgradeCostList = {
				{
					Value = 320044,
					Num = 15,
				},
				{
					Value = 1,
					Num = 30600,
				},
			},
		},
		{
			Level = 8,
			UpgradeCostList = {
				{
					Value = 320044,
					Num = 25,
				},
				{
					Value = 1,
					Num = 44300,
				},
			},
		},
		{
			Level = 9,
			UpgradeCostList = {
				{
					Value = 320044,
					Num = 35,
				},
				{
					Value = 1,
					Num = 61500,
				},
			},
		},
	},
}
EquipmentUpgradeConfig[EquipmentUpgradeID.Id016] =
{
	LevelList = {
		{
			Level = 1,
			UpgradeCostList = {
				{
					Value = 320043,
					Num = 1,
				},
				{
					Value = 1,
					Num = 440,
				},
			},
		},
		{
			Level = 2,
			UpgradeCostList = {
				{
					Value = 320043,
					Num = 4,
				},
				{
					Value = 1,
					Num = 1400,
				},
			},
		},
		{
			Level = 3,
			UpgradeCostList = {
				{
					Value = 320043,
					Num = 10,
				},
				{
					Value = 1,
					Num = 3300,
				},
			},
		},
		{
			Level = 4,
			UpgradeCostList = {
				{
					Value = 320044,
					Num = 4,
				},
				{
					Value = 1,
					Num = 6900,
				},
			},
		},
		{
			Level = 5,
			UpgradeCostList = {
				{
					Value = 320044,
					Num = 7,
				},
				{
					Value = 1,
					Num = 12300,
				},
			},
		},
		{
			Level = 6,
			UpgradeCostList = {
				{
					Value = 320044,
					Num = 12,
				},
				{
					Value = 1,
					Num = 20100,
				},
			},
		},
		{
			Level = 7,
			UpgradeCostList = {
				{
					Value = 320044,
					Num = 15,
				},
				{
					Value = 1,
					Num = 30600,
				},
			},
		},
		{
			Level = 8,
			UpgradeCostList = {
				{
					Value = 320044,
					Num = 25,
				},
				{
					Value = 1,
					Num = 44300,
				},
			},
		},
		{
			Level = 9,
			UpgradeCostList = {
				{
					Value = 320044,
					Num = 35,
				},
				{
					Value = 1,
					Num = 61500,
				},
			},
		},
	},
}
EquipmentUpgradeConfig[EquipmentUpgradeID.Id017] =
{
	LevelList = {
		{
			Level = 1,
			UpgradeCostList = {
				{
					Value = 320042,
					Num = 5,
				},
				{
					Value = 1,
					Num = 320,
				},
			},
		},
		{
			Level = 2,
			UpgradeCostList = {
				{
					Value = 320042,
					Num = 12,
				},
				{
					Value = 1,
					Num = 760,
				},
			},
		},
		{
			Level = 3,
			UpgradeCostList = {
				{
					Value = 320042,
					Num = 25,
				},
				{
					Value = 1,
					Num = 1800,
				},
			},
		},
		{
			Level = 4,
			UpgradeCostList = {
				{
					Value = 320042,
					Num = 55,
				},
				{
					Value = 1,
					Num = 3600,
				},
			},
		},
		{
			Level = 5,
			UpgradeCostList = {
				{
					Value = 320042,
					Num = 105,
				},
				{
					Value = 1,
					Num = 6600,
				},
			},
		},
		{
			Level = 6,
			UpgradeCostList = {
				{
					Value = 320042,
					Num = 175,
				},
				{
					Value = 1,
					Num = 11200,
				},
			},
		},
		{
			Level = 7,
			UpgradeCostList = {
				{
					Value = 320044,
					Num = 11,
				},
				{
					Value = 1,
					Num = 17300,
				},
			},
		},
		{
			Level = 8,
			UpgradeCostList = {
				{
					Value = 320044,
					Num = 15,
				},
				{
					Value = 1,
					Num = 25300,
				},
			},
		},
		{
			Level = 9,
			UpgradeCostList = {
				{
					Value = 320044,
					Num = 20,
				},
				{
					Value = 1,
					Num = 35400,
				},
			},
		},
	},
}
EquipmentUpgradeConfig[EquipmentUpgradeID.Id018] =
{
	LevelList = {
		{
			Level = 1,
			UpgradeCostList = {
				{
					Value = 320042,
					Num = 5,
				},
				{
					Value = 1,
					Num = 320,
				},
			},
		},
		{
			Level = 2,
			UpgradeCostList = {
				{
					Value = 320042,
					Num = 12,
				},
				{
					Value = 1,
					Num = 760,
				},
			},
		},
		{
			Level = 3,
			UpgradeCostList = {
				{
					Value = 320042,
					Num = 25,
				},
				{
					Value = 1,
					Num = 1800,
				},
			},
		},
		{
			Level = 4,
			UpgradeCostList = {
				{
					Value = 320042,
					Num = 55,
				},
				{
					Value = 1,
					Num = 3600,
				},
			},
		},
		{
			Level = 5,
			UpgradeCostList = {
				{
					Value = 320042,
					Num = 105,
				},
				{
					Value = 1,
					Num = 6600,
				},
			},
		},
		{
			Level = 6,
			UpgradeCostList = {
				{
					Value = 320042,
					Num = 175,
				},
				{
					Value = 1,
					Num = 11200,
				},
			},
		},
		{
			Level = 7,
			UpgradeCostList = {
				{
					Value = 320044,
					Num = 11,
				},
				{
					Value = 1,
					Num = 17300,
				},
			},
		},
		{
			Level = 8,
			UpgradeCostList = {
				{
					Value = 320044,
					Num = 15,
				},
				{
					Value = 1,
					Num = 25300,
				},
			},
		},
		{
			Level = 9,
			UpgradeCostList = {
				{
					Value = 320044,
					Num = 20,
				},
				{
					Value = 1,
					Num = 35400,
				},
			},
		},
	},
}
EquipmentUpgradeConfig[EquipmentUpgradeID.Id019] =
{
	LevelList = {
		{
			Level = 1,
			UpgradeCostList = {
				{
					Value = 320043,
					Num = 2,
				},
				{
					Value = 1,
					Num = 890,
				},
			},
		},
		{
			Level = 2,
			UpgradeCostList = {
				{
					Value = 320043,
					Num = 8,
				},
				{
					Value = 1,
					Num = 2800,
				},
			},
		},
		{
			Level = 3,
			UpgradeCostList = {
				{
					Value = 320043,
					Num = 20,
				},
				{
					Value = 1,
					Num = 6700,
				},
			},
		},
		{
			Level = 4,
			UpgradeCostList = {
				{
					Value = 320043,
					Num = 40,
				},
				{
					Value = 1,
					Num = 13800,
				},
			},
		},
		{
			Level = 5,
			UpgradeCostList = {
				{
					Value = 320043,
					Num = 75,
				},
				{
					Value = 1,
					Num = 24700,
				},
			},
		},
		{
			Level = 6,
			UpgradeCostList = {
				{
					Value = 320043,
					Num = 125,
				},
				{
					Value = 1,
					Num = 40300,
				},
			},
		},
		{
			Level = 7,
			UpgradeCostList = {
				{
					Value = 320044,
					Num = 35,
				},
				{
					Value = 1,
					Num = 61200,
				},
			},
		},
		{
			Level = 8,
			UpgradeCostList = {
				{
					Value = 320044,
					Num = 55,
				},
				{
					Value = 1,
					Num = 88700,
				},
			},
		},
		{
			Level = 9,
			UpgradeCostList = {
				{
					Value = 320044,
					Num = 75,
				},
				{
					Value = 1,
					Num = 123000,
				},
			},
		},
	},
}
EquipmentUpgradeConfig[EquipmentUpgradeID.Id020] =
{
	LevelList = {
		{
			Level = 1,
			UpgradeCostList = {
				{
					Value = 320043,
					Num = 5,
				},
				{
					Value = 1,
					Num = 2400,
				},
			},
		},
		{
			Level = 2,
			UpgradeCostList = {
				{
					Value = 320043,
					Num = 24,
				},
				{
					Value = 1,
					Num = 7700,
				},
			},
		},
		{
			Level = 3,
			UpgradeCostList = {
				{
					Value = 320043,
					Num = 60,
				},
				{
					Value = 1,
					Num = 18800,
				},
			},
		},
		{
			Level = 4,
			UpgradeCostList = {
				{
					Value = 320044,
					Num = 20,
				},
				{
					Value = 1,
					Num = 37600,
				},
			},
		},
		{
			Level = 5,
			UpgradeCostList = {
				{
					Value = 320044,
					Num = 40,
				},
				{
					Value = 1,
					Num = 66000,
				},
			},
		},
		{
			Level = 6,
			UpgradeCostList = {
				{
					Value = 320044,
					Num = 65,
				},
				{
					Value = 1,
					Num = 106000,
				},
			},
		},
		{
			Level = 7,
			UpgradeCostList = {
				{
					Value = 320044,
					Num = 100,
				},
				{
					Value = 1,
					Num = 160000,
				},
			},
		},
		{
			Level = 8,
			UpgradeCostList = {
				{
					Value = 320044,
					Num = 145,
				},
				{
					Value = 1,
					Num = 230000,
				},
			},
		},
		{
			Level = 9,
			UpgradeCostList = {
				{
					Value = 320044,
					Num = 200,
				},
				{
					Value = 1,
					Num = 317000,
				},
			},
		},
	},
}
EquipmentUpgradeConfig[EquipmentUpgradeID.Id021] =
{
	LevelList = {
		{
			Level = 1,
			UpgradeCostList = {
				{
					Value = 320051,
					Num = 1,
				},
				{
					Value = 1,
					Num = 10,
				},
			},
		},
		{
			Level = 2,
			UpgradeCostList = {
				{
					Value = 320051,
					Num = 2,
				},
				{
					Value = 1,
					Num = 30,
				},
			},
		},
		{
			Level = 3,
			UpgradeCostList = {
				{
					Value = 320051,
					Num = 6,
				},
				{
					Value = 1,
					Num = 70,
				},
			},
		},
		{
			Level = 4,
			UpgradeCostList = {
				{
					Value = 320051,
					Num = 12,
				},
				{
					Value = 1,
					Num = 150,
				},
			},
		},
		{
			Level = 5,
			UpgradeCostList = {
				{
					Value = 320051,
					Num = 20,
				},
				{
					Value = 1,
					Num = 270,
				},
			},
		},
		{
			Level = 6,
			UpgradeCostList = {
				{
					Value = 320051,
					Num = 35,
				},
				{
					Value = 1,
					Num = 460,
				},
			},
		},
		{
			Level = 7,
			UpgradeCostList = {
				{
					Value = 320052,
					Num = 11,
				},
				{
					Value = 1,
					Num = 720,
				},
			},
		},
		{
			Level = 8,
			UpgradeCostList = {
				{
					Value = 320052,
					Num = 15,
				},
				{
					Value = 1,
					Num = 1000,
				},
			},
		},
		{
			Level = 9,
			UpgradeCostList = {
				{
					Value = 320052,
					Num = 20,
				},
				{
					Value = 1,
					Num = 1400,
				},
			},
		},
	},
}
EquipmentUpgradeConfig[EquipmentUpgradeID.Id022] =
{
	LevelList = {
		{
			Level = 1,
			UpgradeCostList = {
				{
					Value = 320051,
					Num = 1,
				},
				{
					Value = 1,
					Num = 10,
				},
			},
		},
		{
			Level = 2,
			UpgradeCostList = {
				{
					Value = 320051,
					Num = 2,
				},
				{
					Value = 1,
					Num = 30,
				},
			},
		},
		{
			Level = 3,
			UpgradeCostList = {
				{
					Value = 320051,
					Num = 6,
				},
				{
					Value = 1,
					Num = 70,
				},
			},
		},
		{
			Level = 4,
			UpgradeCostList = {
				{
					Value = 320052,
					Num = 2,
				},
				{
					Value = 1,
					Num = 150,
				},
			},
		},
		{
			Level = 5,
			UpgradeCostList = {
				{
					Value = 320052,
					Num = 4,
				},
				{
					Value = 1,
					Num = 270,
				},
			},
		},
		{
			Level = 6,
			UpgradeCostList = {
				{
					Value = 320052,
					Num = 7,
				},
				{
					Value = 1,
					Num = 460,
				},
			},
		},
		{
			Level = 7,
			UpgradeCostList = {
				{
					Value = 320052,
					Num = 11,
				},
				{
					Value = 1,
					Num = 720,
				},
			},
		},
		{
			Level = 8,
			UpgradeCostList = {
				{
					Value = 320052,
					Num = 15,
				},
				{
					Value = 1,
					Num = 1000,
				},
			},
		},
		{
			Level = 9,
			UpgradeCostList = {
				{
					Value = 320052,
					Num = 20,
				},
				{
					Value = 1,
					Num = 1400,
				},
			},
		},
	},
}
EquipmentUpgradeConfig[EquipmentUpgradeID.Id023] =
{
	LevelList = {
		{
			Level = 1,
			UpgradeCostList = {
				{
					Value = 320051,
					Num = 1,
				},
				{
					Value = 1,
					Num = 10,
				},
			},
		},
		{
			Level = 2,
			UpgradeCostList = {
				{
					Value = 320051,
					Num = 2,
				},
				{
					Value = 1,
					Num = 30,
				},
			},
		},
		{
			Level = 3,
			UpgradeCostList = {
				{
					Value = 320051,
					Num = 6,
				},
				{
					Value = 1,
					Num = 70,
				},
			},
		},
		{
			Level = 4,
			UpgradeCostList = {
				{
					Value = 320052,
					Num = 2,
				},
				{
					Value = 1,
					Num = 150,
				},
			},
		},
		{
			Level = 5,
			UpgradeCostList = {
				{
					Value = 320052,
					Num = 4,
				},
				{
					Value = 1,
					Num = 270,
				},
			},
		},
		{
			Level = 6,
			UpgradeCostList = {
				{
					Value = 320052,
					Num = 7,
				},
				{
					Value = 1,
					Num = 460,
				},
			},
		},
		{
			Level = 7,
			UpgradeCostList = {
				{
					Value = 320052,
					Num = 11,
				},
				{
					Value = 1,
					Num = 720,
				},
			},
		},
		{
			Level = 8,
			UpgradeCostList = {
				{
					Value = 320052,
					Num = 15,
				},
				{
					Value = 1,
					Num = 1000,
				},
			},
		},
		{
			Level = 9,
			UpgradeCostList = {
				{
					Value = 320052,
					Num = 20,
				},
				{
					Value = 1,
					Num = 1400,
				},
			},
		},
	},
}
EquipmentUpgradeConfig[EquipmentUpgradeID.Id024] =
{
	LevelList = {
		{
			Level = 1,
			UpgradeCostList = {
				{
					Value = 320051,
					Num = 1,
				},
				{
					Value = 1,
					Num = 10,
				},
			},
		},
		{
			Level = 2,
			UpgradeCostList = {
				{
					Value = 320051,
					Num = 2,
				},
				{
					Value = 1,
					Num = 30,
				},
			},
		},
		{
			Level = 3,
			UpgradeCostList = {
				{
					Value = 320051,
					Num = 6,
				},
				{
					Value = 1,
					Num = 70,
				},
			},
		},
		{
			Level = 4,
			UpgradeCostList = {
				{
					Value = 320052,
					Num = 2,
				},
				{
					Value = 1,
					Num = 150,
				},
			},
		},
		{
			Level = 5,
			UpgradeCostList = {
				{
					Value = 320052,
					Num = 4,
				},
				{
					Value = 1,
					Num = 270,
				},
			},
		},
		{
			Level = 6,
			UpgradeCostList = {
				{
					Value = 320052,
					Num = 7,
				},
				{
					Value = 1,
					Num = 460,
				},
			},
		},
		{
			Level = 7,
			UpgradeCostList = {
				{
					Value = 320052,
					Num = 11,
				},
				{
					Value = 1,
					Num = 720,
				},
			},
		},
		{
			Level = 8,
			UpgradeCostList = {
				{
					Value = 320052,
					Num = 15,
				},
				{
					Value = 1,
					Num = 1000,
				},
			},
		},
		{
			Level = 9,
			UpgradeCostList = {
				{
					Value = 320052,
					Num = 20,
				},
				{
					Value = 1,
					Num = 1400,
				},
			},
		},
	},
}
EquipmentUpgradeConfig[EquipmentUpgradeID.Id025] =
{
	LevelList = {
		{
			Level = 1,
			UpgradeCostList = {
				{
					Value = 320051,
					Num = 2,
				},
				{
					Value = 1,
					Num = 20,
				},
			},
		},
		{
			Level = 2,
			UpgradeCostList = {
				{
					Value = 320051,
					Num = 5,
				},
				{
					Value = 1,
					Num = 60,
				},
			},
		},
		{
			Level = 3,
			UpgradeCostList = {
				{
					Value = 320051,
					Num = 12,
				},
				{
					Value = 1,
					Num = 150,
				},
			},
		},
		{
			Level = 4,
			UpgradeCostList = {
				{
					Value = 320051,
					Num = 20,
				},
				{
					Value = 1,
					Num = 300,
				},
			},
		},
		{
			Level = 5,
			UpgradeCostList = {
				{
					Value = 320051,
					Num = 40,
				},
				{
					Value = 1,
					Num = 550,
				},
			},
		},
		{
			Level = 6,
			UpgradeCostList = {
				{
					Value = 320051,
					Num = 70,
				},
				{
					Value = 1,
					Num = 930,
				},
			},
		},
		{
			Level = 7,
			UpgradeCostList = {
				{
					Value = 320052,
					Num = 20,
				},
				{
					Value = 1,
					Num = 1400,
				},
			},
		},
		{
			Level = 8,
			UpgradeCostList = {
				{
					Value = 320052,
					Num = 30,
				},
				{
					Value = 1,
					Num = 2100,
				},
			},
		},
		{
			Level = 9,
			UpgradeCostList = {
				{
					Value = 320052,
					Num = 45,
				},
				{
					Value = 1,
					Num = 2900,
				},
			},
		},
	},
}
EquipmentUpgradeConfig[EquipmentUpgradeID.Id026] =
{
	LevelList = {
		{
			Level = 1,
			UpgradeCostList = {
				{
					Value = 320051,
					Num = 2,
				},
				{
					Value = 1,
					Num = 20,
				},
			},
		},
		{
			Level = 2,
			UpgradeCostList = {
				{
					Value = 320051,
					Num = 5,
				},
				{
					Value = 1,
					Num = 60,
				},
			},
		},
		{
			Level = 3,
			UpgradeCostList = {
				{
					Value = 320051,
					Num = 12,
				},
				{
					Value = 1,
					Num = 150,
				},
			},
		},
		{
			Level = 4,
			UpgradeCostList = {
				{
					Value = 320052,
					Num = 4,
				},
				{
					Value = 1,
					Num = 300,
				},
			},
		},
		{
			Level = 5,
			UpgradeCostList = {
				{
					Value = 320052,
					Num = 8,
				},
				{
					Value = 1,
					Num = 550,
				},
			},
		},
		{
			Level = 6,
			UpgradeCostList = {
				{
					Value = 320052,
					Num = 14,
				},
				{
					Value = 1,
					Num = 930,
				},
			},
		},
		{
			Level = 7,
			UpgradeCostList = {
				{
					Value = 320053,
					Num = 4,
				},
				{
					Value = 1,
					Num = 1400,
				},
			},
		},
		{
			Level = 8,
			UpgradeCostList = {
				{
					Value = 320053,
					Num = 6,
				},
				{
					Value = 1,
					Num = 2100,
				},
			},
		},
		{
			Level = 9,
			UpgradeCostList = {
				{
					Value = 320053,
					Num = 9,
				},
				{
					Value = 1,
					Num = 2900,
				},
			},
		},
	},
}
EquipmentUpgradeConfig[EquipmentUpgradeID.Id027] =
{
	LevelList = {
		{
			Level = 1,
			UpgradeCostList = {
				{
					Value = 320051,
					Num = 2,
				},
				{
					Value = 1,
					Num = 20,
				},
			},
		},
		{
			Level = 2,
			UpgradeCostList = {
				{
					Value = 320051,
					Num = 5,
				},
				{
					Value = 1,
					Num = 60,
				},
			},
		},
		{
			Level = 3,
			UpgradeCostList = {
				{
					Value = 320051,
					Num = 12,
				},
				{
					Value = 1,
					Num = 150,
				},
			},
		},
		{
			Level = 4,
			UpgradeCostList = {
				{
					Value = 320052,
					Num = 4,
				},
				{
					Value = 1,
					Num = 300,
				},
			},
		},
		{
			Level = 5,
			UpgradeCostList = {
				{
					Value = 320052,
					Num = 8,
				},
				{
					Value = 1,
					Num = 550,
				},
			},
		},
		{
			Level = 6,
			UpgradeCostList = {
				{
					Value = 320052,
					Num = 14,
				},
				{
					Value = 1,
					Num = 930,
				},
			},
		},
		{
			Level = 7,
			UpgradeCostList = {
				{
					Value = 320053,
					Num = 4,
				},
				{
					Value = 1,
					Num = 1400,
				},
			},
		},
		{
			Level = 8,
			UpgradeCostList = {
				{
					Value = 320053,
					Num = 6,
				},
				{
					Value = 1,
					Num = 2100,
				},
			},
		},
		{
			Level = 9,
			UpgradeCostList = {
				{
					Value = 320053,
					Num = 9,
				},
				{
					Value = 1,
					Num = 2900,
				},
			},
		},
	},
}
EquipmentUpgradeConfig[EquipmentUpgradeID.Id028] =
{
	LevelList = {
		{
			Level = 1,
			UpgradeCostList = {
				{
					Value = 320051,
					Num = 2,
				},
				{
					Value = 1,
					Num = 20,
				},
			},
		},
		{
			Level = 2,
			UpgradeCostList = {
				{
					Value = 320051,
					Num = 5,
				},
				{
					Value = 1,
					Num = 60,
				},
			},
		},
		{
			Level = 3,
			UpgradeCostList = {
				{
					Value = 320051,
					Num = 12,
				},
				{
					Value = 1,
					Num = 150,
				},
			},
		},
		{
			Level = 4,
			UpgradeCostList = {
				{
					Value = 320052,
					Num = 4,
				},
				{
					Value = 1,
					Num = 300,
				},
			},
		},
		{
			Level = 5,
			UpgradeCostList = {
				{
					Value = 320052,
					Num = 8,
				},
				{
					Value = 1,
					Num = 550,
				},
			},
		},
		{
			Level = 6,
			UpgradeCostList = {
				{
					Value = 320052,
					Num = 14,
				},
				{
					Value = 1,
					Num = 930,
				},
			},
		},
		{
			Level = 7,
			UpgradeCostList = {
				{
					Value = 320053,
					Num = 4,
				},
				{
					Value = 1,
					Num = 1400,
				},
			},
		},
		{
			Level = 8,
			UpgradeCostList = {
				{
					Value = 320053,
					Num = 6,
				},
				{
					Value = 1,
					Num = 2100,
				},
			},
		},
		{
			Level = 9,
			UpgradeCostList = {
				{
					Value = 320053,
					Num = 9,
				},
				{
					Value = 1,
					Num = 2900,
				},
			},
		},
	},
}
EquipmentUpgradeConfig[EquipmentUpgradeID.Id029] =
{
	LevelList = {
		{
			Level = 1,
			UpgradeCostList = {
				{
					Value = 320051,
					Num = 5,
				},
				{
					Value = 1,
					Num = 80,
				},
			},
		},
		{
			Level = 2,
			UpgradeCostList = {
				{
					Value = 320051,
					Num = 15,
				},
				{
					Value = 1,
					Num = 190,
				},
			},
		},
		{
			Level = 3,
			UpgradeCostList = {
				{
					Value = 320051,
					Num = 35,
				},
				{
					Value = 1,
					Num = 450,
				},
			},
		},
		{
			Level = 4,
			UpgradeCostList = {
				{
					Value = 320051,
					Num = 70,
				},
				{
					Value = 1,
					Num = 920,
				},
			},
		},
		{
			Level = 5,
			UpgradeCostList = {
				{
					Value = 320051,
					Num = 130,
				},
				{
					Value = 1,
					Num = 1600,
				},
			},
		},
		{
			Level = 6,
			UpgradeCostList = {
				{
					Value = 320051,
					Num = 220,
				},
				{
					Value = 1,
					Num = 2800,
				},
			},
		},
		{
			Level = 7,
			UpgradeCostList = {
				{
					Value = 320053,
					Num = 13,
				},
				{
					Value = 1,
					Num = 4300,
				},
			},
		},
		{
			Level = 8,
			UpgradeCostList = {
				{
					Value = 320053,
					Num = 20,
				},
				{
					Value = 1,
					Num = 6300,
				},
			},
		},
		{
			Level = 9,
			UpgradeCostList = {
				{
					Value = 320053,
					Num = 25,
				},
				{
					Value = 1,
					Num = 8800,
				},
			},
		},
	},
}
EquipmentUpgradeConfig[EquipmentUpgradeID.Id030] =
{
	LevelList = {
		{
			Level = 1,
			UpgradeCostList = {
				{
					Value = 320051,
					Num = 5,
				},
				{
					Value = 1,
					Num = 80,
				},
			},
		},
		{
			Level = 2,
			UpgradeCostList = {
				{
					Value = 320051,
					Num = 15,
				},
				{
					Value = 1,
					Num = 190,
				},
			},
		},
		{
			Level = 3,
			UpgradeCostList = {
				{
					Value = 320051,
					Num = 35,
				},
				{
					Value = 1,
					Num = 450,
				},
			},
		},
		{
			Level = 4,
			UpgradeCostList = {
				{
					Value = 320052,
					Num = 14,
				},
				{
					Value = 1,
					Num = 920,
				},
			},
		},
		{
			Level = 5,
			UpgradeCostList = {
				{
					Value = 320052,
					Num = 25,
				},
				{
					Value = 1,
					Num = 1600,
				},
			},
		},
		{
			Level = 6,
			UpgradeCostList = {
				{
					Value = 320052,
					Num = 40,
				},
				{
					Value = 1,
					Num = 2800,
				},
			},
		},
		{
			Level = 7,
			UpgradeCostList = {
				{
					Value = 320053,
					Num = 13,
				},
				{
					Value = 1,
					Num = 4300,
				},
			},
		},
		{
			Level = 8,
			UpgradeCostList = {
				{
					Value = 320053,
					Num = 20,
				},
				{
					Value = 1,
					Num = 6300,
				},
			},
		},
		{
			Level = 9,
			UpgradeCostList = {
				{
					Value = 320053,
					Num = 25,
				},
				{
					Value = 1,
					Num = 8800,
				},
			},
		},
	},
}
EquipmentUpgradeConfig[EquipmentUpgradeID.Id031] =
{
	LevelList = {
		{
			Level = 1,
			UpgradeCostList = {
				{
					Value = 320052,
					Num = 3,
				},
				{
					Value = 1,
					Num = 220,
				},
			},
		},
		{
			Level = 2,
			UpgradeCostList = {
				{
					Value = 320052,
					Num = 11,
				},
				{
					Value = 1,
					Num = 700,
				},
			},
		},
		{
			Level = 3,
			UpgradeCostList = {
				{
					Value = 320052,
					Num = 25,
				},
				{
					Value = 1,
					Num = 1600,
				},
			},
		},
		{
			Level = 4,
			UpgradeCostList = {
				{
					Value = 320053,
					Num = 11,
				},
				{
					Value = 1,
					Num = 3400,
				},
			},
		},
		{
			Level = 5,
			UpgradeCostList = {
				{
					Value = 320053,
					Num = 15,
				},
				{
					Value = 1,
					Num = 6100,
				},
			},
		},
		{
			Level = 6,
			UpgradeCostList = {
				{
					Value = 320053,
					Num = 30,
				},
				{
					Value = 1,
					Num = 10000,
				},
			},
		},
		{
			Level = 7,
			UpgradeCostList = {
				{
					Value = 320054,
					Num = 9,
				},
				{
					Value = 1,
					Num = 15300,
				},
			},
		},
		{
			Level = 8,
			UpgradeCostList = {
				{
					Value = 320054,
					Num = 14,
				},
				{
					Value = 1,
					Num = 22100,
				},
			},
		},
		{
			Level = 9,
			UpgradeCostList = {
				{
					Value = 320054,
					Num = 15,
				},
				{
					Value = 1,
					Num = 30700,
				},
			},
		},
	},
}
EquipmentUpgradeConfig[EquipmentUpgradeID.Id032] =
{
	LevelList = {
		{
			Level = 1,
			UpgradeCostList = {
				{
					Value = 320052,
					Num = 3,
				},
				{
					Value = 1,
					Num = 220,
				},
			},
		},
		{
			Level = 2,
			UpgradeCostList = {
				{
					Value = 320052,
					Num = 11,
				},
				{
					Value = 1,
					Num = 700,
				},
			},
		},
		{
			Level = 3,
			UpgradeCostList = {
				{
					Value = 320052,
					Num = 25,
				},
				{
					Value = 1,
					Num = 1600,
				},
			},
		},
		{
			Level = 4,
			UpgradeCostList = {
				{
					Value = 320053,
					Num = 11,
				},
				{
					Value = 1,
					Num = 3400,
				},
			},
		},
		{
			Level = 5,
			UpgradeCostList = {
				{
					Value = 320053,
					Num = 15,
				},
				{
					Value = 1,
					Num = 6100,
				},
			},
		},
		{
			Level = 6,
			UpgradeCostList = {
				{
					Value = 320053,
					Num = 30,
				},
				{
					Value = 1,
					Num = 10000,
				},
			},
		},
		{
			Level = 7,
			UpgradeCostList = {
				{
					Value = 320054,
					Num = 9,
				},
				{
					Value = 1,
					Num = 15300,
				},
			},
		},
		{
			Level = 8,
			UpgradeCostList = {
				{
					Value = 320054,
					Num = 14,
				},
				{
					Value = 1,
					Num = 22100,
				},
			},
		},
		{
			Level = 9,
			UpgradeCostList = {
				{
					Value = 320054,
					Num = 15,
				},
				{
					Value = 1,
					Num = 30700,
				},
			},
		},
	},
}
EquipmentUpgradeConfig[EquipmentUpgradeID.Id033] =
{
	LevelList = {
		{
			Level = 1,
			UpgradeCostList = {
				{
					Value = 320051,
					Num = 10,
				},
				{
					Value = 1,
					Num = 160,
				},
			},
		},
		{
			Level = 2,
			UpgradeCostList = {
				{
					Value = 320051,
					Num = 30,
				},
				{
					Value = 1,
					Num = 380,
				},
			},
		},
		{
			Level = 3,
			UpgradeCostList = {
				{
					Value = 320051,
					Num = 70,
				},
				{
					Value = 1,
					Num = 900,
				},
			},
		},
		{
			Level = 4,
			UpgradeCostList = {
				{
					Value = 320052,
					Num = 25,
				},
				{
					Value = 1,
					Num = 1800,
				},
			},
		},
		{
			Level = 5,
			UpgradeCostList = {
				{
					Value = 320052,
					Num = 50,
				},
				{
					Value = 1,
					Num = 3300,
				},
			},
		},
		{
			Level = 6,
			UpgradeCostList = {
				{
					Value = 320052,
					Num = 85,
				},
				{
					Value = 1,
					Num = 5600,
				},
			},
		},
		{
			Level = 7,
			UpgradeCostList = {
				{
					Value = 320053,
					Num = 25,
				},
				{
					Value = 1,
					Num = 8600,
				},
			},
		},
		{
			Level = 8,
			UpgradeCostList = {
				{
					Value = 320053,
					Num = 40,
				},
				{
					Value = 1,
					Num = 12600,
				},
			},
		},
		{
			Level = 9,
			UpgradeCostList = {
				{
					Value = 320053,
					Num = 55,
				},
				{
					Value = 1,
					Num = 17700,
				},
			},
		},
	},
}
EquipmentUpgradeConfig[EquipmentUpgradeID.Id034] =
{
	LevelList = {
		{
			Level = 1,
			UpgradeCostList = {
				{
					Value = 320052,
					Num = 2,
				},
				{
					Value = 1,
					Num = 160,
				},
			},
		},
		{
			Level = 2,
			UpgradeCostList = {
				{
					Value = 320052,
					Num = 6,
				},
				{
					Value = 1,
					Num = 380,
				},
			},
		},
		{
			Level = 3,
			UpgradeCostList = {
				{
					Value = 320052,
					Num = 14,
				},
				{
					Value = 1,
					Num = 900,
				},
			},
		},
		{
			Level = 4,
			UpgradeCostList = {
				{
					Value = 320053,
					Num = 5,
				},
				{
					Value = 1,
					Num = 1800,
				},
			},
		},
		{
			Level = 5,
			UpgradeCostList = {
				{
					Value = 320053,
					Num = 10,
				},
				{
					Value = 1,
					Num = 3300,
				},
			},
		},
		{
			Level = 6,
			UpgradeCostList = {
				{
					Value = 320053,
					Num = 15,
				},
				{
					Value = 1,
					Num = 5600,
				},
			},
		},
		{
			Level = 7,
			UpgradeCostList = {
				{
					Value = 320054,
					Num = 5,
				},
				{
					Value = 1,
					Num = 8600,
				},
			},
		},
		{
			Level = 8,
			UpgradeCostList = {
				{
					Value = 320054,
					Num = 8,
				},
				{
					Value = 1,
					Num = 12600,
				},
			},
		},
		{
			Level = 9,
			UpgradeCostList = {
				{
					Value = 320054,
					Num = 11,
				},
				{
					Value = 1,
					Num = 17700,
				},
			},
		},
	},
}
EquipmentUpgradeConfig[EquipmentUpgradeID.Id035] =
{
	LevelList = {
		{
			Level = 1,
			UpgradeCostList = {
				{
					Value = 320053,
					Num = 1,
				},
				{
					Value = 1,
					Num = 440,
				},
			},
		},
		{
			Level = 2,
			UpgradeCostList = {
				{
					Value = 320053,
					Num = 4,
				},
				{
					Value = 1,
					Num = 1400,
				},
			},
		},
		{
			Level = 3,
			UpgradeCostList = {
				{
					Value = 320053,
					Num = 10,
				},
				{
					Value = 1,
					Num = 3300,
				},
			},
		},
		{
			Level = 4,
			UpgradeCostList = {
				{
					Value = 320054,
					Num = 4,
				},
				{
					Value = 1,
					Num = 6900,
				},
			},
		},
		{
			Level = 5,
			UpgradeCostList = {
				{
					Value = 320054,
					Num = 7,
				},
				{
					Value = 1,
					Num = 12300,
				},
			},
		},
		{
			Level = 6,
			UpgradeCostList = {
				{
					Value = 320054,
					Num = 12,
				},
				{
					Value = 1,
					Num = 20100,
				},
			},
		},
		{
			Level = 7,
			UpgradeCostList = {
				{
					Value = 320054,
					Num = 15,
				},
				{
					Value = 1,
					Num = 30600,
				},
			},
		},
		{
			Level = 8,
			UpgradeCostList = {
				{
					Value = 320054,
					Num = 25,
				},
				{
					Value = 1,
					Num = 44300,
				},
			},
		},
		{
			Level = 9,
			UpgradeCostList = {
				{
					Value = 320054,
					Num = 35,
				},
				{
					Value = 1,
					Num = 61500,
				},
			},
		},
	},
}
EquipmentUpgradeConfig[EquipmentUpgradeID.Id036] =
{
	LevelList = {
		{
			Level = 1,
			UpgradeCostList = {
				{
					Value = 320053,
					Num = 1,
				},
				{
					Value = 1,
					Num = 440,
				},
			},
		},
		{
			Level = 2,
			UpgradeCostList = {
				{
					Value = 320053,
					Num = 4,
				},
				{
					Value = 1,
					Num = 1400,
				},
			},
		},
		{
			Level = 3,
			UpgradeCostList = {
				{
					Value = 320053,
					Num = 10,
				},
				{
					Value = 1,
					Num = 3300,
				},
			},
		},
		{
			Level = 4,
			UpgradeCostList = {
				{
					Value = 320054,
					Num = 4,
				},
				{
					Value = 1,
					Num = 6900,
				},
			},
		},
		{
			Level = 5,
			UpgradeCostList = {
				{
					Value = 320054,
					Num = 7,
				},
				{
					Value = 1,
					Num = 12300,
				},
			},
		},
		{
			Level = 6,
			UpgradeCostList = {
				{
					Value = 320054,
					Num = 12,
				},
				{
					Value = 1,
					Num = 20100,
				},
			},
		},
		{
			Level = 7,
			UpgradeCostList = {
				{
					Value = 320054,
					Num = 15,
				},
				{
					Value = 1,
					Num = 30600,
				},
			},
		},
		{
			Level = 8,
			UpgradeCostList = {
				{
					Value = 320054,
					Num = 25,
				},
				{
					Value = 1,
					Num = 44300,
				},
			},
		},
		{
			Level = 9,
			UpgradeCostList = {
				{
					Value = 320054,
					Num = 35,
				},
				{
					Value = 1,
					Num = 61500,
				},
			},
		},
	},
}
EquipmentUpgradeConfig[EquipmentUpgradeID.Id037] =
{
	LevelList = {
		{
			Level = 1,
			UpgradeCostList = {
				{
					Value = 320052,
					Num = 5,
				},
				{
					Value = 1,
					Num = 320,
				},
			},
		},
		{
			Level = 2,
			UpgradeCostList = {
				{
					Value = 320052,
					Num = 12,
				},
				{
					Value = 1,
					Num = 760,
				},
			},
		},
		{
			Level = 3,
			UpgradeCostList = {
				{
					Value = 320052,
					Num = 25,
				},
				{
					Value = 1,
					Num = 1800,
				},
			},
		},
		{
			Level = 4,
			UpgradeCostList = {
				{
					Value = 320052,
					Num = 55,
				},
				{
					Value = 1,
					Num = 3600,
				},
			},
		},
		{
			Level = 5,
			UpgradeCostList = {
				{
					Value = 320052,
					Num = 105,
				},
				{
					Value = 1,
					Num = 6600,
				},
			},
		},
		{
			Level = 6,
			UpgradeCostList = {
				{
					Value = 320052,
					Num = 175,
				},
				{
					Value = 1,
					Num = 11200,
				},
			},
		},
		{
			Level = 7,
			UpgradeCostList = {
				{
					Value = 320054,
					Num = 11,
				},
				{
					Value = 1,
					Num = 17300,
				},
			},
		},
		{
			Level = 8,
			UpgradeCostList = {
				{
					Value = 320054,
					Num = 15,
				},
				{
					Value = 1,
					Num = 25300,
				},
			},
		},
		{
			Level = 9,
			UpgradeCostList = {
				{
					Value = 320054,
					Num = 20,
				},
				{
					Value = 1,
					Num = 35400,
				},
			},
		},
	},
}
EquipmentUpgradeConfig[EquipmentUpgradeID.Id038] =
{
	LevelList = {
		{
			Level = 1,
			UpgradeCostList = {
				{
					Value = 320052,
					Num = 5,
				},
				{
					Value = 1,
					Num = 320,
				},
			},
		},
		{
			Level = 2,
			UpgradeCostList = {
				{
					Value = 320052,
					Num = 12,
				},
				{
					Value = 1,
					Num = 760,
				},
			},
		},
		{
			Level = 3,
			UpgradeCostList = {
				{
					Value = 320052,
					Num = 25,
				},
				{
					Value = 1,
					Num = 1800,
				},
			},
		},
		{
			Level = 4,
			UpgradeCostList = {
				{
					Value = 320052,
					Num = 55,
				},
				{
					Value = 1,
					Num = 3600,
				},
			},
		},
		{
			Level = 5,
			UpgradeCostList = {
				{
					Value = 320052,
					Num = 105,
				},
				{
					Value = 1,
					Num = 6600,
				},
			},
		},
		{
			Level = 6,
			UpgradeCostList = {
				{
					Value = 320052,
					Num = 175,
				},
				{
					Value = 1,
					Num = 11200,
				},
			},
		},
		{
			Level = 7,
			UpgradeCostList = {
				{
					Value = 320054,
					Num = 11,
				},
				{
					Value = 1,
					Num = 17300,
				},
			},
		},
		{
			Level = 8,
			UpgradeCostList = {
				{
					Value = 320054,
					Num = 15,
				},
				{
					Value = 1,
					Num = 25300,
				},
			},
		},
		{
			Level = 9,
			UpgradeCostList = {
				{
					Value = 320054,
					Num = 20,
				},
				{
					Value = 1,
					Num = 35400,
				},
			},
		},
	},
}
EquipmentUpgradeConfig[EquipmentUpgradeID.Id039] =
{
	LevelList = {
		{
			Level = 1,
			UpgradeCostList = {
				{
					Value = 320053,
					Num = 2,
				},
				{
					Value = 1,
					Num = 890,
				},
			},
		},
		{
			Level = 2,
			UpgradeCostList = {
				{
					Value = 320053,
					Num = 8,
				},
				{
					Value = 1,
					Num = 2800,
				},
			},
		},
		{
			Level = 3,
			UpgradeCostList = {
				{
					Value = 320053,
					Num = 20,
				},
				{
					Value = 1,
					Num = 6700,
				},
			},
		},
		{
			Level = 4,
			UpgradeCostList = {
				{
					Value = 320053,
					Num = 40,
				},
				{
					Value = 1,
					Num = 13800,
				},
			},
		},
		{
			Level = 5,
			UpgradeCostList = {
				{
					Value = 320053,
					Num = 75,
				},
				{
					Value = 1,
					Num = 24700,
				},
			},
		},
		{
			Level = 6,
			UpgradeCostList = {
				{
					Value = 320053,
					Num = 125,
				},
				{
					Value = 1,
					Num = 40300,
				},
			},
		},
		{
			Level = 7,
			UpgradeCostList = {
				{
					Value = 320054,
					Num = 35,
				},
				{
					Value = 1,
					Num = 61200,
				},
			},
		},
		{
			Level = 8,
			UpgradeCostList = {
				{
					Value = 320054,
					Num = 55,
				},
				{
					Value = 1,
					Num = 88700,
				},
			},
		},
		{
			Level = 9,
			UpgradeCostList = {
				{
					Value = 320054,
					Num = 75,
				},
				{
					Value = 1,
					Num = 123000,
				},
			},
		},
	},
}
EquipmentUpgradeConfig[EquipmentUpgradeID.Id040] =
{
	LevelList = {
		{
			Level = 1,
			UpgradeCostList = {
				{
					Value = 320053,
					Num = 5,
				},
				{
					Value = 1,
					Num = 2400,
				},
			},
		},
		{
			Level = 2,
			UpgradeCostList = {
				{
					Value = 320053,
					Num = 24,
				},
				{
					Value = 1,
					Num = 7700,
				},
			},
		},
		{
			Level = 3,
			UpgradeCostList = {
				{
					Value = 320053,
					Num = 60,
				},
				{
					Value = 1,
					Num = 18800,
				},
			},
		},
		{
			Level = 4,
			UpgradeCostList = {
				{
					Value = 320054,
					Num = 20,
				},
				{
					Value = 1,
					Num = 37600,
				},
			},
		},
		{
			Level = 5,
			UpgradeCostList = {
				{
					Value = 320054,
					Num = 40,
				},
				{
					Value = 1,
					Num = 66000,
				},
			},
		},
		{
			Level = 6,
			UpgradeCostList = {
				{
					Value = 320054,
					Num = 65,
				},
				{
					Value = 1,
					Num = 106000,
				},
			},
		},
		{
			Level = 7,
			UpgradeCostList = {
				{
					Value = 320054,
					Num = 100,
				},
				{
					Value = 1,
					Num = 160000,
				},
			},
		},
		{
			Level = 8,
			UpgradeCostList = {
				{
					Value = 320054,
					Num = 145,
				},
				{
					Value = 1,
					Num = 230000,
				},
			},
		},
		{
			Level = 9,
			UpgradeCostList = {
				{
					Value = 320054,
					Num = 200,
				},
				{
					Value = 1,
					Num = 317000,
				},
			},
		},
	},
}
EquipmentUpgradeConfig[EquipmentUpgradeID.Id041] =
{
	LevelList = {
		{
			Level = 1,
			UpgradeCostList = {
				{
					Value = 320041,
					Num = 1,
				},
				{
					Value = 1,
					Num = 10,
				},
			},
		},
		{
			Level = 2,
			UpgradeCostList = {
				{
					Value = 320041,
					Num = 3,
				},
				{
					Value = 1,
					Num = 30,
				},
			},
		},
		{
			Level = 3,
			UpgradeCostList = {
				{
					Value = 320041,
					Num = 7,
				},
				{
					Value = 1,
					Num = 90,
				},
			},
		},
		{
			Level = 4,
			UpgradeCostList = {
				{
					Value = 320041,
					Num = 14,
				},
				{
					Value = 1,
					Num = 180,
				},
			},
		},
		{
			Level = 5,
			UpgradeCostList = {
				{
					Value = 320041,
					Num = 25,
				},
				{
					Value = 1,
					Num = 330,
				},
			},
		},
		{
			Level = 6,
			UpgradeCostList = {
				{
					Value = 320041,
					Num = 40,
				},
				{
					Value = 1,
					Num = 560,
				},
			},
		},
		{
			Level = 7,
			UpgradeCostList = {
				{
					Value = 320042,
					Num = 13,
				},
				{
					Value = 1,
					Num = 860,
				},
			},
		},
		{
			Level = 8,
			UpgradeCostList = {
				{
					Value = 320042,
					Num = 20,
				},
				{
					Value = 1,
					Num = 1200,
				},
			},
		},
		{
			Level = 9,
			UpgradeCostList = {
				{
					Value = 320042,
					Num = 25,
				},
				{
					Value = 1,
					Num = 1700,
				},
			},
		},
	},
}
EquipmentUpgradeConfig[EquipmentUpgradeID.Id042] =
{
	LevelList = {
		{
			Level = 1,
			UpgradeCostList = {
				{
					Value = 320041,
					Num = 1,
				},
				{
					Value = 1,
					Num = 10,
				},
			},
		},
		{
			Level = 2,
			UpgradeCostList = {
				{
					Value = 320041,
					Num = 3,
				},
				{
					Value = 1,
					Num = 30,
				},
			},
		},
		{
			Level = 3,
			UpgradeCostList = {
				{
					Value = 320041,
					Num = 7,
				},
				{
					Value = 1,
					Num = 90,
				},
			},
		},
		{
			Level = 4,
			UpgradeCostList = {
				{
					Value = 320042,
					Num = 2,
				},
				{
					Value = 1,
					Num = 180,
				},
			},
		},
		{
			Level = 5,
			UpgradeCostList = {
				{
					Value = 320042,
					Num = 5,
				},
				{
					Value = 1,
					Num = 330,
				},
			},
		},
		{
			Level = 6,
			UpgradeCostList = {
				{
					Value = 320042,
					Num = 8,
				},
				{
					Value = 1,
					Num = 560,
				},
			},
		},
		{
			Level = 7,
			UpgradeCostList = {
				{
					Value = 320042,
					Num = 13,
				},
				{
					Value = 1,
					Num = 860,
				},
			},
		},
		{
			Level = 8,
			UpgradeCostList = {
				{
					Value = 320042,
					Num = 20,
				},
				{
					Value = 1,
					Num = 1200,
				},
			},
		},
		{
			Level = 9,
			UpgradeCostList = {
				{
					Value = 320042,
					Num = 25,
				},
				{
					Value = 1,
					Num = 1700,
				},
			},
		},
	},
}
EquipmentUpgradeConfig[EquipmentUpgradeID.Id043] =
{
	LevelList = {
		{
			Level = 1,
			UpgradeCostList = {
				{
					Value = 320041,
					Num = 1,
				},
				{
					Value = 1,
					Num = 10,
				},
			},
		},
		{
			Level = 2,
			UpgradeCostList = {
				{
					Value = 320041,
					Num = 3,
				},
				{
					Value = 1,
					Num = 30,
				},
			},
		},
		{
			Level = 3,
			UpgradeCostList = {
				{
					Value = 320041,
					Num = 7,
				},
				{
					Value = 1,
					Num = 90,
				},
			},
		},
		{
			Level = 4,
			UpgradeCostList = {
				{
					Value = 320042,
					Num = 2,
				},
				{
					Value = 1,
					Num = 180,
				},
			},
		},
		{
			Level = 5,
			UpgradeCostList = {
				{
					Value = 320042,
					Num = 5,
				},
				{
					Value = 1,
					Num = 330,
				},
			},
		},
		{
			Level = 6,
			UpgradeCostList = {
				{
					Value = 320042,
					Num = 8,
				},
				{
					Value = 1,
					Num = 560,
				},
			},
		},
		{
			Level = 7,
			UpgradeCostList = {
				{
					Value = 320042,
					Num = 13,
				},
				{
					Value = 1,
					Num = 860,
				},
			},
		},
		{
			Level = 8,
			UpgradeCostList = {
				{
					Value = 320042,
					Num = 20,
				},
				{
					Value = 1,
					Num = 1200,
				},
			},
		},
		{
			Level = 9,
			UpgradeCostList = {
				{
					Value = 320042,
					Num = 25,
				},
				{
					Value = 1,
					Num = 1700,
				},
			},
		},
	},
}
EquipmentUpgradeConfig[EquipmentUpgradeID.Id044] =
{
	LevelList = {
		{
			Level = 1,
			UpgradeCostList = {
				{
					Value = 320041,
					Num = 1,
				},
				{
					Value = 1,
					Num = 10,
				},
			},
		},
		{
			Level = 2,
			UpgradeCostList = {
				{
					Value = 320041,
					Num = 3,
				},
				{
					Value = 1,
					Num = 30,
				},
			},
		},
		{
			Level = 3,
			UpgradeCostList = {
				{
					Value = 320041,
					Num = 7,
				},
				{
					Value = 1,
					Num = 90,
				},
			},
		},
		{
			Level = 4,
			UpgradeCostList = {
				{
					Value = 320042,
					Num = 2,
				},
				{
					Value = 1,
					Num = 180,
				},
			},
		},
		{
			Level = 5,
			UpgradeCostList = {
				{
					Value = 320042,
					Num = 5,
				},
				{
					Value = 1,
					Num = 330,
				},
			},
		},
		{
			Level = 6,
			UpgradeCostList = {
				{
					Value = 320042,
					Num = 8,
				},
				{
					Value = 1,
					Num = 560,
				},
			},
		},
		{
			Level = 7,
			UpgradeCostList = {
				{
					Value = 320042,
					Num = 13,
				},
				{
					Value = 1,
					Num = 860,
				},
			},
		},
		{
			Level = 8,
			UpgradeCostList = {
				{
					Value = 320042,
					Num = 20,
				},
				{
					Value = 1,
					Num = 1200,
				},
			},
		},
		{
			Level = 9,
			UpgradeCostList = {
				{
					Value = 320042,
					Num = 25,
				},
				{
					Value = 1,
					Num = 1700,
				},
			},
		},
	},
}
EquipmentUpgradeConfig[EquipmentUpgradeID.Id045] =
{
	LevelList = {
		{
			Level = 1,
			UpgradeCostList = {
				{
					Value = 320041,
					Num = 2,
				},
				{
					Value = 1,
					Num = 30,
				},
			},
		},
		{
			Level = 2,
			UpgradeCostList = {
				{
					Value = 320041,
					Num = 6,
				},
				{
					Value = 1,
					Num = 70,
				},
			},
		},
		{
			Level = 3,
			UpgradeCostList = {
				{
					Value = 320041,
					Num = 14,
				},
				{
					Value = 1,
					Num = 180,
				},
			},
		},
		{
			Level = 4,
			UpgradeCostList = {
				{
					Value = 320041,
					Num = 25,
				},
				{
					Value = 1,
					Num = 360,
				},
			},
		},
		{
			Level = 5,
			UpgradeCostList = {
				{
					Value = 320041,
					Num = 50,
				},
				{
					Value = 1,
					Num = 660,
				},
			},
		},
		{
			Level = 6,
			UpgradeCostList = {
				{
					Value = 320041,
					Num = 85,
				},
				{
					Value = 1,
					Num = 1100,
				},
			},
		},
		{
			Level = 7,
			UpgradeCostList = {
				{
					Value = 320042,
					Num = 25,
				},
				{
					Value = 1,
					Num = 1700,
				},
			},
		},
		{
			Level = 8,
			UpgradeCostList = {
				{
					Value = 320042,
					Num = 40,
				},
				{
					Value = 1,
					Num = 2500,
				},
			},
		},
		{
			Level = 9,
			UpgradeCostList = {
				{
					Value = 320042,
					Num = 55,
				},
				{
					Value = 1,
					Num = 3500,
				},
			},
		},
	},
}
EquipmentUpgradeConfig[EquipmentUpgradeID.Id046] =
{
	LevelList = {
		{
			Level = 1,
			UpgradeCostList = {
				{
					Value = 320041,
					Num = 2,
				},
				{
					Value = 1,
					Num = 30,
				},
			},
		},
		{
			Level = 2,
			UpgradeCostList = {
				{
					Value = 320041,
					Num = 6,
				},
				{
					Value = 1,
					Num = 70,
				},
			},
		},
		{
			Level = 3,
			UpgradeCostList = {
				{
					Value = 320041,
					Num = 14,
				},
				{
					Value = 1,
					Num = 180,
				},
			},
		},
		{
			Level = 4,
			UpgradeCostList = {
				{
					Value = 320042,
					Num = 5,
				},
				{
					Value = 1,
					Num = 360,
				},
			},
		},
		{
			Level = 5,
			UpgradeCostList = {
				{
					Value = 320042,
					Num = 10,
				},
				{
					Value = 1,
					Num = 660,
				},
			},
		},
		{
			Level = 6,
			UpgradeCostList = {
				{
					Value = 320042,
					Num = 15,
				},
				{
					Value = 1,
					Num = 1100,
				},
			},
		},
		{
			Level = 7,
			UpgradeCostList = {
				{
					Value = 320043,
					Num = 5,
				},
				{
					Value = 1,
					Num = 1700,
				},
			},
		},
		{
			Level = 8,
			UpgradeCostList = {
				{
					Value = 320043,
					Num = 8,
				},
				{
					Value = 1,
					Num = 2500,
				},
			},
		},
		{
			Level = 9,
			UpgradeCostList = {
				{
					Value = 320043,
					Num = 11,
				},
				{
					Value = 1,
					Num = 3500,
				},
			},
		},
	},
}
EquipmentUpgradeConfig[EquipmentUpgradeID.Id047] =
{
	LevelList = {
		{
			Level = 1,
			UpgradeCostList = {
				{
					Value = 320041,
					Num = 2,
				},
				{
					Value = 1,
					Num = 30,
				},
			},
		},
		{
			Level = 2,
			UpgradeCostList = {
				{
					Value = 320041,
					Num = 6,
				},
				{
					Value = 1,
					Num = 70,
				},
			},
		},
		{
			Level = 3,
			UpgradeCostList = {
				{
					Value = 320041,
					Num = 14,
				},
				{
					Value = 1,
					Num = 180,
				},
			},
		},
		{
			Level = 4,
			UpgradeCostList = {
				{
					Value = 320042,
					Num = 5,
				},
				{
					Value = 1,
					Num = 360,
				},
			},
		},
		{
			Level = 5,
			UpgradeCostList = {
				{
					Value = 320042,
					Num = 10,
				},
				{
					Value = 1,
					Num = 660,
				},
			},
		},
		{
			Level = 6,
			UpgradeCostList = {
				{
					Value = 320042,
					Num = 15,
				},
				{
					Value = 1,
					Num = 1100,
				},
			},
		},
		{
			Level = 7,
			UpgradeCostList = {
				{
					Value = 320043,
					Num = 5,
				},
				{
					Value = 1,
					Num = 1700,
				},
			},
		},
		{
			Level = 8,
			UpgradeCostList = {
				{
					Value = 320043,
					Num = 8,
				},
				{
					Value = 1,
					Num = 2500,
				},
			},
		},
		{
			Level = 9,
			UpgradeCostList = {
				{
					Value = 320043,
					Num = 11,
				},
				{
					Value = 1,
					Num = 3500,
				},
			},
		},
	},
}
EquipmentUpgradeConfig[EquipmentUpgradeID.Id048] =
{
	LevelList = {
		{
			Level = 1,
			UpgradeCostList = {
				{
					Value = 320041,
					Num = 2,
				},
				{
					Value = 1,
					Num = 30,
				},
			},
		},
		{
			Level = 2,
			UpgradeCostList = {
				{
					Value = 320041,
					Num = 6,
				},
				{
					Value = 1,
					Num = 70,
				},
			},
		},
		{
			Level = 3,
			UpgradeCostList = {
				{
					Value = 320041,
					Num = 14,
				},
				{
					Value = 1,
					Num = 180,
				},
			},
		},
		{
			Level = 4,
			UpgradeCostList = {
				{
					Value = 320042,
					Num = 5,
				},
				{
					Value = 1,
					Num = 360,
				},
			},
		},
		{
			Level = 5,
			UpgradeCostList = {
				{
					Value = 320042,
					Num = 10,
				},
				{
					Value = 1,
					Num = 660,
				},
			},
		},
		{
			Level = 6,
			UpgradeCostList = {
				{
					Value = 320042,
					Num = 15,
				},
				{
					Value = 1,
					Num = 1100,
				},
			},
		},
		{
			Level = 7,
			UpgradeCostList = {
				{
					Value = 320043,
					Num = 5,
				},
				{
					Value = 1,
					Num = 1700,
				},
			},
		},
		{
			Level = 8,
			UpgradeCostList = {
				{
					Value = 320043,
					Num = 8,
				},
				{
					Value = 1,
					Num = 2500,
				},
			},
		},
		{
			Level = 9,
			UpgradeCostList = {
				{
					Value = 320043,
					Num = 11,
				},
				{
					Value = 1,
					Num = 3500,
				},
			},
		},
	},
}
EquipmentUpgradeConfig[EquipmentUpgradeID.Id049] =
{
	LevelList = {
		{
			Level = 1,
			UpgradeCostList = {
				{
					Value = 320041,
					Num = 7,
				},
				{
					Value = 1,
					Num = 90,
				},
			},
		},
		{
			Level = 2,
			UpgradeCostList = {
				{
					Value = 320041,
					Num = 15,
				},
				{
					Value = 1,
					Num = 220,
				},
			},
		},
		{
			Level = 3,
			UpgradeCostList = {
				{
					Value = 320041,
					Num = 40,
				},
				{
					Value = 1,
					Num = 540,
				},
			},
		},
		{
			Level = 4,
			UpgradeCostList = {
				{
					Value = 320041,
					Num = 85,
				},
				{
					Value = 1,
					Num = 1100,
				},
			},
		},
		{
			Level = 5,
			UpgradeCostList = {
				{
					Value = 320041,
					Num = 155,
				},
				{
					Value = 1,
					Num = 1900,
				},
			},
		},
		{
			Level = 6,
			UpgradeCostList = {
				{
					Value = 320041,
					Num = 265,
				},
				{
					Value = 1,
					Num = 3300,
				},
			},
		},
		{
			Level = 7,
			UpgradeCostList = {
				{
					Value = 320043,
					Num = 15,
				},
				{
					Value = 1,
					Num = 5200,
				},
			},
		},
		{
			Level = 8,
			UpgradeCostList = {
				{
					Value = 320043,
					Num = 20,
				},
				{
					Value = 1,
					Num = 7500,
				},
			},
		},
		{
			Level = 9,
			UpgradeCostList = {
				{
					Value = 320043,
					Num = 30,
				},
				{
					Value = 1,
					Num = 10600,
				},
			},
		},
	},
}
EquipmentUpgradeConfig[EquipmentUpgradeID.Id050] =
{
	LevelList = {
		{
			Level = 1,
			UpgradeCostList = {
				{
					Value = 320041,
					Num = 7,
				},
				{
					Value = 1,
					Num = 90,
				},
			},
		},
		{
			Level = 2,
			UpgradeCostList = {
				{
					Value = 320041,
					Num = 15,
				},
				{
					Value = 1,
					Num = 220,
				},
			},
		},
		{
			Level = 3,
			UpgradeCostList = {
				{
					Value = 320041,
					Num = 40,
				},
				{
					Value = 1,
					Num = 540,
				},
			},
		},
		{
			Level = 4,
			UpgradeCostList = {
				{
					Value = 320042,
					Num = 15,
				},
				{
					Value = 1,
					Num = 1100,
				},
			},
		},
		{
			Level = 5,
			UpgradeCostList = {
				{
					Value = 320042,
					Num = 30,
				},
				{
					Value = 1,
					Num = 1900,
				},
			},
		},
		{
			Level = 6,
			UpgradeCostList = {
				{
					Value = 320042,
					Num = 50,
				},
				{
					Value = 1,
					Num = 3300,
				},
			},
		},
		{
			Level = 7,
			UpgradeCostList = {
				{
					Value = 320043,
					Num = 15,
				},
				{
					Value = 1,
					Num = 5200,
				},
			},
		},
		{
			Level = 8,
			UpgradeCostList = {
				{
					Value = 320043,
					Num = 20,
				},
				{
					Value = 1,
					Num = 7500,
				},
			},
		},
		{
			Level = 9,
			UpgradeCostList = {
				{
					Value = 320043,
					Num = 30,
				},
				{
					Value = 1,
					Num = 10600,
				},
			},
		},
	},
}
EquipmentUpgradeConfig[EquipmentUpgradeID.Id051] =
{
	LevelList = {
		{
			Level = 1,
			UpgradeCostList = {
				{
					Value = 320042,
					Num = 4,
				},
				{
					Value = 1,
					Num = 260,
				},
			},
		},
		{
			Level = 2,
			UpgradeCostList = {
				{
					Value = 320042,
					Num = 13,
				},
				{
					Value = 1,
					Num = 840,
				},
			},
		},
		{
			Level = 3,
			UpgradeCostList = {
				{
					Value = 320042,
					Num = 30,
				},
				{
					Value = 1,
					Num = 2000,
				},
			},
		},
		{
			Level = 4,
			UpgradeCostList = {
				{
					Value = 320043,
					Num = 13,
				},
				{
					Value = 1,
					Num = 4100,
				},
			},
		},
		{
			Level = 5,
			UpgradeCostList = {
				{
					Value = 320043,
					Num = 20,
				},
				{
					Value = 1,
					Num = 7400,
				},
			},
		},
		{
			Level = 6,
			UpgradeCostList = {
				{
					Value = 320043,
					Num = 35,
				},
				{
					Value = 1,
					Num = 12100,
				},
			},
		},
		{
			Level = 7,
			UpgradeCostList = {
				{
					Value = 320044,
					Num = 11,
				},
				{
					Value = 1,
					Num = 18300,
				},
			},
		},
		{
			Level = 8,
			UpgradeCostList = {
				{
					Value = 320044,
					Num = 15,
				},
				{
					Value = 1,
					Num = 26600,
				},
			},
		},
		{
			Level = 9,
			UpgradeCostList = {
				{
					Value = 320044,
					Num = 20,
				},
				{
					Value = 1,
					Num = 36900,
				},
			},
		},
	},
}
EquipmentUpgradeConfig[EquipmentUpgradeID.Id052] =
{
	LevelList = {
		{
			Level = 1,
			UpgradeCostList = {
				{
					Value = 320042,
					Num = 4,
				},
				{
					Value = 1,
					Num = 260,
				},
			},
		},
		{
			Level = 2,
			UpgradeCostList = {
				{
					Value = 320042,
					Num = 13,
				},
				{
					Value = 1,
					Num = 840,
				},
			},
		},
		{
			Level = 3,
			UpgradeCostList = {
				{
					Value = 320042,
					Num = 30,
				},
				{
					Value = 1,
					Num = 2000,
				},
			},
		},
		{
			Level = 4,
			UpgradeCostList = {
				{
					Value = 320043,
					Num = 13,
				},
				{
					Value = 1,
					Num = 4100,
				},
			},
		},
		{
			Level = 5,
			UpgradeCostList = {
				{
					Value = 320043,
					Num = 20,
				},
				{
					Value = 1,
					Num = 7400,
				},
			},
		},
		{
			Level = 6,
			UpgradeCostList = {
				{
					Value = 320043,
					Num = 35,
				},
				{
					Value = 1,
					Num = 12100,
				},
			},
		},
		{
			Level = 7,
			UpgradeCostList = {
				{
					Value = 320044,
					Num = 11,
				},
				{
					Value = 1,
					Num = 18300,
				},
			},
		},
		{
			Level = 8,
			UpgradeCostList = {
				{
					Value = 320044,
					Num = 15,
				},
				{
					Value = 1,
					Num = 26600,
				},
			},
		},
		{
			Level = 9,
			UpgradeCostList = {
				{
					Value = 320044,
					Num = 20,
				},
				{
					Value = 1,
					Num = 36900,
				},
			},
		},
	},
}
EquipmentUpgradeConfig[EquipmentUpgradeID.Id053] =
{
	LevelList = {
		{
			Level = 1,
			UpgradeCostList = {
				{
					Value = 320041,
					Num = 15,
				},
				{
					Value = 1,
					Num = 190,
				},
			},
		},
		{
			Level = 2,
			UpgradeCostList = {
				{
					Value = 320041,
					Num = 35,
				},
				{
					Value = 1,
					Num = 450,
				},
			},
		},
		{
			Level = 3,
			UpgradeCostList = {
				{
					Value = 320041,
					Num = 85,
				},
				{
					Value = 1,
					Num = 1000,
				},
			},
		},
		{
			Level = 4,
			UpgradeCostList = {
				{
					Value = 320042,
					Num = 35,
				},
				{
					Value = 1,
					Num = 2200,
				},
			},
		},
		{
			Level = 5,
			UpgradeCostList = {
				{
					Value = 320042,
					Num = 60,
				},
				{
					Value = 1,
					Num = 3900,
				},
			},
		},
		{
			Level = 6,
			UpgradeCostList = {
				{
					Value = 320042,
					Num = 105,
				},
				{
					Value = 1,
					Num = 6700,
				},
			},
		},
		{
			Level = 7,
			UpgradeCostList = {
				{
					Value = 320043,
					Num = 30,
				},
				{
					Value = 1,
					Num = 10400,
				},
			},
		},
		{
			Level = 8,
			UpgradeCostList = {
				{
					Value = 320043,
					Num = 45,
				},
				{
					Value = 1,
					Num = 15100,
				},
			},
		},
		{
			Level = 9,
			UpgradeCostList = {
				{
					Value = 320043,
					Num = 65,
				},
				{
					Value = 1,
					Num = 21200,
				},
			},
		},
	},
}
EquipmentUpgradeConfig[EquipmentUpgradeID.Id054] =
{
	LevelList = {
		{
			Level = 1,
			UpgradeCostList = {
				{
					Value = 320042,
					Num = 3,
				},
				{
					Value = 1,
					Num = 190,
				},
			},
		},
		{
			Level = 2,
			UpgradeCostList = {
				{
					Value = 320042,
					Num = 7,
				},
				{
					Value = 1,
					Num = 450,
				},
			},
		},
		{
			Level = 3,
			UpgradeCostList = {
				{
					Value = 320042,
					Num = 15,
				},
				{
					Value = 1,
					Num = 1000,
				},
			},
		},
		{
			Level = 4,
			UpgradeCostList = {
				{
					Value = 320043,
					Num = 7,
				},
				{
					Value = 1,
					Num = 2200,
				},
			},
		},
		{
			Level = 5,
			UpgradeCostList = {
				{
					Value = 320043,
					Num = 12,
				},
				{
					Value = 1,
					Num = 3900,
				},
			},
		},
		{
			Level = 6,
			UpgradeCostList = {
				{
					Value = 320043,
					Num = 20,
				},
				{
					Value = 1,
					Num = 6700,
				},
			},
		},
		{
			Level = 7,
			UpgradeCostList = {
				{
					Value = 320044,
					Num = 6,
				},
				{
					Value = 1,
					Num = 10400,
				},
			},
		},
		{
			Level = 8,
			UpgradeCostList = {
				{
					Value = 320044,
					Num = 9,
				},
				{
					Value = 1,
					Num = 15100,
				},
			},
		},
		{
			Level = 9,
			UpgradeCostList = {
				{
					Value = 320044,
					Num = 13,
				},
				{
					Value = 1,
					Num = 21200,
				},
			},
		},
	},
}
EquipmentUpgradeConfig[EquipmentUpgradeID.Id055] =
{
	LevelList = {
		{
			Level = 1,
			UpgradeCostList = {
				{
					Value = 320043,
					Num = 1,
				},
				{
					Value = 1,
					Num = 530,
				},
			},
		},
		{
			Level = 2,
			UpgradeCostList = {
				{
					Value = 320043,
					Num = 5,
				},
				{
					Value = 1,
					Num = 1600,
				},
			},
		},
		{
			Level = 3,
			UpgradeCostList = {
				{
					Value = 320043,
					Num = 12,
				},
				{
					Value = 1,
					Num = 4000,
				},
			},
		},
		{
			Level = 4,
			UpgradeCostList = {
				{
					Value = 320044,
					Num = 5,
				},
				{
					Value = 1,
					Num = 8300,
				},
			},
		},
		{
			Level = 5,
			UpgradeCostList = {
				{
					Value = 320044,
					Num = 9,
				},
				{
					Value = 1,
					Num = 14800,
				},
			},
		},
		{
			Level = 6,
			UpgradeCostList = {
				{
					Value = 320044,
					Num = 15,
				},
				{
					Value = 1,
					Num = 24200,
				},
			},
		},
		{
			Level = 7,
			UpgradeCostList = {
				{
					Value = 320044,
					Num = 20,
				},
				{
					Value = 1,
					Num = 36700,
				},
			},
		},
		{
			Level = 8,
			UpgradeCostList = {
				{
					Value = 320044,
					Num = 30,
				},
				{
					Value = 1,
					Num = 53200,
				},
			},
		},
		{
			Level = 9,
			UpgradeCostList = {
				{
					Value = 320044,
					Num = 45,
				},
				{
					Value = 1,
					Num = 73800,
				},
			},
		},
	},
}
EquipmentUpgradeConfig[EquipmentUpgradeID.Id056] =
{
	LevelList = {
		{
			Level = 1,
			UpgradeCostList = {
				{
					Value = 320043,
					Num = 1,
				},
				{
					Value = 1,
					Num = 530,
				},
			},
		},
		{
			Level = 2,
			UpgradeCostList = {
				{
					Value = 320043,
					Num = 5,
				},
				{
					Value = 1,
					Num = 1600,
				},
			},
		},
		{
			Level = 3,
			UpgradeCostList = {
				{
					Value = 320043,
					Num = 12,
				},
				{
					Value = 1,
					Num = 4000,
				},
			},
		},
		{
			Level = 4,
			UpgradeCostList = {
				{
					Value = 320044,
					Num = 5,
				},
				{
					Value = 1,
					Num = 8300,
				},
			},
		},
		{
			Level = 5,
			UpgradeCostList = {
				{
					Value = 320044,
					Num = 9,
				},
				{
					Value = 1,
					Num = 14800,
				},
			},
		},
		{
			Level = 6,
			UpgradeCostList = {
				{
					Value = 320044,
					Num = 15,
				},
				{
					Value = 1,
					Num = 24200,
				},
			},
		},
		{
			Level = 7,
			UpgradeCostList = {
				{
					Value = 320044,
					Num = 20,
				},
				{
					Value = 1,
					Num = 36700,
				},
			},
		},
		{
			Level = 8,
			UpgradeCostList = {
				{
					Value = 320044,
					Num = 30,
				},
				{
					Value = 1,
					Num = 53200,
				},
			},
		},
		{
			Level = 9,
			UpgradeCostList = {
				{
					Value = 320044,
					Num = 45,
				},
				{
					Value = 1,
					Num = 73800,
				},
			},
		},
	},
}
EquipmentUpgradeConfig[EquipmentUpgradeID.Id057] =
{
	LevelList = {
		{
			Level = 1,
			UpgradeCostList = {
				{
					Value = 320042,
					Num = 6,
				},
				{
					Value = 1,
					Num = 390,
				},
			},
		},
		{
			Level = 2,
			UpgradeCostList = {
				{
					Value = 320042,
					Num = 14,
				},
				{
					Value = 1,
					Num = 910,
				},
			},
		},
		{
			Level = 3,
			UpgradeCostList = {
				{
					Value = 320042,
					Num = 30,
				},
				{
					Value = 1,
					Num = 2100,
				},
			},
		},
		{
			Level = 4,
			UpgradeCostList = {
				{
					Value = 320042,
					Num = 70,
				},
				{
					Value = 1,
					Num = 4400,
				},
			},
		},
		{
			Level = 5,
			UpgradeCostList = {
				{
					Value = 320042,
					Num = 125,
				},
				{
					Value = 1,
					Num = 7900,
				},
			},
		},
		{
			Level = 6,
			UpgradeCostList = {
				{
					Value = 320042,
					Num = 215,
				},
				{
					Value = 1,
					Num = 13400,
				},
			},
		},
		{
			Level = 7,
			UpgradeCostList = {
				{
					Value = 320044,
					Num = 13,
				},
				{
					Value = 1,
					Num = 20800,
				},
			},
		},
		{
			Level = 8,
			UpgradeCostList = {
				{
					Value = 320044,
					Num = 15,
				},
				{
					Value = 1,
					Num = 30300,
				},
			},
		},
		{
			Level = 9,
			UpgradeCostList = {
				{
					Value = 320044,
					Num = 25,
				},
				{
					Value = 1,
					Num = 42500,
				},
			},
		},
	},
}
EquipmentUpgradeConfig[EquipmentUpgradeID.Id058] =
{
	LevelList = {
		{
			Level = 1,
			UpgradeCostList = {
				{
					Value = 320042,
					Num = 6,
				},
				{
					Value = 1,
					Num = 390,
				},
			},
		},
		{
			Level = 2,
			UpgradeCostList = {
				{
					Value = 320042,
					Num = 14,
				},
				{
					Value = 1,
					Num = 910,
				},
			},
		},
		{
			Level = 3,
			UpgradeCostList = {
				{
					Value = 320042,
					Num = 30,
				},
				{
					Value = 1,
					Num = 2100,
				},
			},
		},
		{
			Level = 4,
			UpgradeCostList = {
				{
					Value = 320042,
					Num = 70,
				},
				{
					Value = 1,
					Num = 4400,
				},
			},
		},
		{
			Level = 5,
			UpgradeCostList = {
				{
					Value = 320042,
					Num = 125,
				},
				{
					Value = 1,
					Num = 7900,
				},
			},
		},
		{
			Level = 6,
			UpgradeCostList = {
				{
					Value = 320042,
					Num = 215,
				},
				{
					Value = 1,
					Num = 13400,
				},
			},
		},
		{
			Level = 7,
			UpgradeCostList = {
				{
					Value = 320044,
					Num = 13,
				},
				{
					Value = 1,
					Num = 20800,
				},
			},
		},
		{
			Level = 8,
			UpgradeCostList = {
				{
					Value = 320044,
					Num = 15,
				},
				{
					Value = 1,
					Num = 30300,
				},
			},
		},
		{
			Level = 9,
			UpgradeCostList = {
				{
					Value = 320044,
					Num = 25,
				},
				{
					Value = 1,
					Num = 42500,
				},
			},
		},
	},
}
EquipmentUpgradeConfig[EquipmentUpgradeID.Id059] =
{
	LevelList = {
		{
			Level = 1,
			UpgradeCostList = {
				{
					Value = 320043,
					Num = 3,
				},
				{
					Value = 1,
					Num = 1000,
				},
			},
		},
		{
			Level = 2,
			UpgradeCostList = {
				{
					Value = 320043,
					Num = 10,
				},
				{
					Value = 1,
					Num = 3300,
				},
			},
		},
		{
			Level = 3,
			UpgradeCostList = {
				{
					Value = 320043,
					Num = 25,
				},
				{
					Value = 1,
					Num = 8000,
				},
			},
		},
		{
			Level = 4,
			UpgradeCostList = {
				{
					Value = 320043,
					Num = 50,
				},
				{
					Value = 1,
					Num = 16600,
				},
			},
		},
		{
			Level = 5,
			UpgradeCostList = {
				{
					Value = 320043,
					Num = 90,
				},
				{
					Value = 1,
					Num = 29600,
				},
			},
		},
		{
			Level = 6,
			UpgradeCostList = {
				{
					Value = 320043,
					Num = 150,
				},
				{
					Value = 1,
					Num = 48400,
				},
			},
		},
		{
			Level = 7,
			UpgradeCostList = {
				{
					Value = 320044,
					Num = 45,
				},
				{
					Value = 1,
					Num = 73500,
				},
			},
		},
		{
			Level = 8,
			UpgradeCostList = {
				{
					Value = 320044,
					Num = 65,
				},
				{
					Value = 1,
					Num = 106000,
				},
			},
		},
		{
			Level = 9,
			UpgradeCostList = {
				{
					Value = 320044,
					Num = 90,
				},
				{
					Value = 1,
					Num = 147000,
				},
			},
		},
	},
}
EquipmentUpgradeConfig[EquipmentUpgradeID.Id060] =
{
	LevelList = {
		{
			Level = 1,
			UpgradeCostList = {
				{
					Value = 320043,
					Num = 9,
				},
				{
					Value = 1,
					Num = 2800,
				},
			},
		},
		{
			Level = 2,
			UpgradeCostList = {
				{
					Value = 320043,
					Num = 25,
				},
				{
					Value = 1,
					Num = 9200,
				},
			},
		},
		{
			Level = 3,
			UpgradeCostList = {
				{
					Value = 320043,
					Num = 70,
				},
				{
					Value = 1,
					Num = 22600,
				},
			},
		},
		{
			Level = 4,
			UpgradeCostList = {
				{
					Value = 320044,
					Num = 25,
				},
				{
					Value = 1,
					Num = 45100,
				},
			},
		},
		{
			Level = 5,
			UpgradeCostList = {
				{
					Value = 320044,
					Num = 50,
				},
				{
					Value = 1,
					Num = 79200,
				},
			},
		},
		{
			Level = 6,
			UpgradeCostList = {
				{
					Value = 320044,
					Num = 80,
				},
				{
					Value = 1,
					Num = 127000,
				},
			},
		},
		{
			Level = 7,
			UpgradeCostList = {
				{
					Value = 320044,
					Num = 120,
				},
				{
					Value = 1,
					Num = 192000,
				},
			},
		},
		{
			Level = 8,
			UpgradeCostList = {
				{
					Value = 320044,
					Num = 175,
				},
				{
					Value = 1,
					Num = 276000,
				},
			},
		},
		{
			Level = 9,
			UpgradeCostList = {
				{
					Value = 320044,
					Num = 240,
				},
				{
					Value = 1,
					Num = 381000,
				},
			},
		},
	},
}
EquipmentUpgradeConfig[EquipmentUpgradeID.Id061] =
{
	LevelList = {
		{
			Level = 1,
			UpgradeCostList = {
				{
					Value = 320051,
					Num = 1,
				},
				{
					Value = 1,
					Num = 10,
				},
			},
		},
		{
			Level = 2,
			UpgradeCostList = {
				{
					Value = 320051,
					Num = 3,
				},
				{
					Value = 1,
					Num = 30,
				},
			},
		},
		{
			Level = 3,
			UpgradeCostList = {
				{
					Value = 320051,
					Num = 7,
				},
				{
					Value = 1,
					Num = 90,
				},
			},
		},
		{
			Level = 4,
			UpgradeCostList = {
				{
					Value = 320051,
					Num = 14,
				},
				{
					Value = 1,
					Num = 180,
				},
			},
		},
		{
			Level = 5,
			UpgradeCostList = {
				{
					Value = 320051,
					Num = 25,
				},
				{
					Value = 1,
					Num = 330,
				},
			},
		},
		{
			Level = 6,
			UpgradeCostList = {
				{
					Value = 320051,
					Num = 40,
				},
				{
					Value = 1,
					Num = 560,
				},
			},
		},
		{
			Level = 7,
			UpgradeCostList = {
				{
					Value = 320052,
					Num = 13,
				},
				{
					Value = 1,
					Num = 860,
				},
			},
		},
		{
			Level = 8,
			UpgradeCostList = {
				{
					Value = 320052,
					Num = 20,
				},
				{
					Value = 1,
					Num = 1200,
				},
			},
		},
		{
			Level = 9,
			UpgradeCostList = {
				{
					Value = 320052,
					Num = 25,
				},
				{
					Value = 1,
					Num = 1700,
				},
			},
		},
	},
}
EquipmentUpgradeConfig[EquipmentUpgradeID.Id062] =
{
	LevelList = {
		{
			Level = 1,
			UpgradeCostList = {
				{
					Value = 320051,
					Num = 1,
				},
				{
					Value = 1,
					Num = 10,
				},
			},
		},
		{
			Level = 2,
			UpgradeCostList = {
				{
					Value = 320051,
					Num = 3,
				},
				{
					Value = 1,
					Num = 30,
				},
			},
		},
		{
			Level = 3,
			UpgradeCostList = {
				{
					Value = 320051,
					Num = 7,
				},
				{
					Value = 1,
					Num = 90,
				},
			},
		},
		{
			Level = 4,
			UpgradeCostList = {
				{
					Value = 320052,
					Num = 2,
				},
				{
					Value = 1,
					Num = 180,
				},
			},
		},
		{
			Level = 5,
			UpgradeCostList = {
				{
					Value = 320052,
					Num = 5,
				},
				{
					Value = 1,
					Num = 330,
				},
			},
		},
		{
			Level = 6,
			UpgradeCostList = {
				{
					Value = 320052,
					Num = 8,
				},
				{
					Value = 1,
					Num = 560,
				},
			},
		},
		{
			Level = 7,
			UpgradeCostList = {
				{
					Value = 320052,
					Num = 13,
				},
				{
					Value = 1,
					Num = 860,
				},
			},
		},
		{
			Level = 8,
			UpgradeCostList = {
				{
					Value = 320052,
					Num = 20,
				},
				{
					Value = 1,
					Num = 1200,
				},
			},
		},
		{
			Level = 9,
			UpgradeCostList = {
				{
					Value = 320052,
					Num = 25,
				},
				{
					Value = 1,
					Num = 1700,
				},
			},
		},
	},
}
EquipmentUpgradeConfig[EquipmentUpgradeID.Id063] =
{
	LevelList = {
		{
			Level = 1,
			UpgradeCostList = {
				{
					Value = 320051,
					Num = 1,
				},
				{
					Value = 1,
					Num = 10,
				},
			},
		},
		{
			Level = 2,
			UpgradeCostList = {
				{
					Value = 320051,
					Num = 3,
				},
				{
					Value = 1,
					Num = 30,
				},
			},
		},
		{
			Level = 3,
			UpgradeCostList = {
				{
					Value = 320051,
					Num = 7,
				},
				{
					Value = 1,
					Num = 90,
				},
			},
		},
		{
			Level = 4,
			UpgradeCostList = {
				{
					Value = 320052,
					Num = 2,
				},
				{
					Value = 1,
					Num = 180,
				},
			},
		},
		{
			Level = 5,
			UpgradeCostList = {
				{
					Value = 320052,
					Num = 5,
				},
				{
					Value = 1,
					Num = 330,
				},
			},
		},
		{
			Level = 6,
			UpgradeCostList = {
				{
					Value = 320052,
					Num = 8,
				},
				{
					Value = 1,
					Num = 560,
				},
			},
		},
		{
			Level = 7,
			UpgradeCostList = {
				{
					Value = 320052,
					Num = 13,
				},
				{
					Value = 1,
					Num = 860,
				},
			},
		},
		{
			Level = 8,
			UpgradeCostList = {
				{
					Value = 320052,
					Num = 20,
				},
				{
					Value = 1,
					Num = 1200,
				},
			},
		},
		{
			Level = 9,
			UpgradeCostList = {
				{
					Value = 320052,
					Num = 25,
				},
				{
					Value = 1,
					Num = 1700,
				},
			},
		},
	},
}
EquipmentUpgradeConfig[EquipmentUpgradeID.Id064] =
{
	LevelList = {
		{
			Level = 1,
			UpgradeCostList = {
				{
					Value = 320051,
					Num = 1,
				},
				{
					Value = 1,
					Num = 10,
				},
			},
		},
		{
			Level = 2,
			UpgradeCostList = {
				{
					Value = 320051,
					Num = 3,
				},
				{
					Value = 1,
					Num = 30,
				},
			},
		},
		{
			Level = 3,
			UpgradeCostList = {
				{
					Value = 320051,
					Num = 7,
				},
				{
					Value = 1,
					Num = 90,
				},
			},
		},
		{
			Level = 4,
			UpgradeCostList = {
				{
					Value = 320052,
					Num = 2,
				},
				{
					Value = 1,
					Num = 180,
				},
			},
		},
		{
			Level = 5,
			UpgradeCostList = {
				{
					Value = 320052,
					Num = 5,
				},
				{
					Value = 1,
					Num = 330,
				},
			},
		},
		{
			Level = 6,
			UpgradeCostList = {
				{
					Value = 320052,
					Num = 8,
				},
				{
					Value = 1,
					Num = 560,
				},
			},
		},
		{
			Level = 7,
			UpgradeCostList = {
				{
					Value = 320052,
					Num = 13,
				},
				{
					Value = 1,
					Num = 860,
				},
			},
		},
		{
			Level = 8,
			UpgradeCostList = {
				{
					Value = 320052,
					Num = 20,
				},
				{
					Value = 1,
					Num = 1200,
				},
			},
		},
		{
			Level = 9,
			UpgradeCostList = {
				{
					Value = 320052,
					Num = 25,
				},
				{
					Value = 1,
					Num = 1700,
				},
			},
		},
	},
}
EquipmentUpgradeConfig[EquipmentUpgradeID.Id065] =
{
	LevelList = {
		{
			Level = 1,
			UpgradeCostList = {
				{
					Value = 320051,
					Num = 2,
				},
				{
					Value = 1,
					Num = 30,
				},
			},
		},
		{
			Level = 2,
			UpgradeCostList = {
				{
					Value = 320051,
					Num = 6,
				},
				{
					Value = 1,
					Num = 70,
				},
			},
		},
		{
			Level = 3,
			UpgradeCostList = {
				{
					Value = 320051,
					Num = 14,
				},
				{
					Value = 1,
					Num = 180,
				},
			},
		},
		{
			Level = 4,
			UpgradeCostList = {
				{
					Value = 320051,
					Num = 25,
				},
				{
					Value = 1,
					Num = 360,
				},
			},
		},
		{
			Level = 5,
			UpgradeCostList = {
				{
					Value = 320051,
					Num = 50,
				},
				{
					Value = 1,
					Num = 660,
				},
			},
		},
		{
			Level = 6,
			UpgradeCostList = {
				{
					Value = 320051,
					Num = 85,
				},
				{
					Value = 1,
					Num = 1100,
				},
			},
		},
		{
			Level = 7,
			UpgradeCostList = {
				{
					Value = 320052,
					Num = 25,
				},
				{
					Value = 1,
					Num = 1700,
				},
			},
		},
		{
			Level = 8,
			UpgradeCostList = {
				{
					Value = 320052,
					Num = 40,
				},
				{
					Value = 1,
					Num = 2500,
				},
			},
		},
		{
			Level = 9,
			UpgradeCostList = {
				{
					Value = 320052,
					Num = 55,
				},
				{
					Value = 1,
					Num = 3500,
				},
			},
		},
	},
}
EquipmentUpgradeConfig[EquipmentUpgradeID.Id066] =
{
	LevelList = {
		{
			Level = 1,
			UpgradeCostList = {
				{
					Value = 320051,
					Num = 2,
				},
				{
					Value = 1,
					Num = 30,
				},
			},
		},
		{
			Level = 2,
			UpgradeCostList = {
				{
					Value = 320051,
					Num = 6,
				},
				{
					Value = 1,
					Num = 70,
				},
			},
		},
		{
			Level = 3,
			UpgradeCostList = {
				{
					Value = 320051,
					Num = 14,
				},
				{
					Value = 1,
					Num = 180,
				},
			},
		},
		{
			Level = 4,
			UpgradeCostList = {
				{
					Value = 320052,
					Num = 5,
				},
				{
					Value = 1,
					Num = 360,
				},
			},
		},
		{
			Level = 5,
			UpgradeCostList = {
				{
					Value = 320052,
					Num = 10,
				},
				{
					Value = 1,
					Num = 660,
				},
			},
		},
		{
			Level = 6,
			UpgradeCostList = {
				{
					Value = 320052,
					Num = 15,
				},
				{
					Value = 1,
					Num = 1100,
				},
			},
		},
		{
			Level = 7,
			UpgradeCostList = {
				{
					Value = 320053,
					Num = 5,
				},
				{
					Value = 1,
					Num = 1700,
				},
			},
		},
		{
			Level = 8,
			UpgradeCostList = {
				{
					Value = 320053,
					Num = 8,
				},
				{
					Value = 1,
					Num = 2500,
				},
			},
		},
		{
			Level = 9,
			UpgradeCostList = {
				{
					Value = 320053,
					Num = 11,
				},
				{
					Value = 1,
					Num = 3500,
				},
			},
		},
	},
}
EquipmentUpgradeConfig[EquipmentUpgradeID.Id067] =
{
	LevelList = {
		{
			Level = 1,
			UpgradeCostList = {
				{
					Value = 320051,
					Num = 2,
				},
				{
					Value = 1,
					Num = 30,
				},
			},
		},
		{
			Level = 2,
			UpgradeCostList = {
				{
					Value = 320051,
					Num = 6,
				},
				{
					Value = 1,
					Num = 70,
				},
			},
		},
		{
			Level = 3,
			UpgradeCostList = {
				{
					Value = 320051,
					Num = 14,
				},
				{
					Value = 1,
					Num = 180,
				},
			},
		},
		{
			Level = 4,
			UpgradeCostList = {
				{
					Value = 320052,
					Num = 5,
				},
				{
					Value = 1,
					Num = 360,
				},
			},
		},
		{
			Level = 5,
			UpgradeCostList = {
				{
					Value = 320052,
					Num = 10,
				},
				{
					Value = 1,
					Num = 660,
				},
			},
		},
		{
			Level = 6,
			UpgradeCostList = {
				{
					Value = 320052,
					Num = 15,
				},
				{
					Value = 1,
					Num = 1100,
				},
			},
		},
		{
			Level = 7,
			UpgradeCostList = {
				{
					Value = 320053,
					Num = 5,
				},
				{
					Value = 1,
					Num = 1700,
				},
			},
		},
		{
			Level = 8,
			UpgradeCostList = {
				{
					Value = 320053,
					Num = 8,
				},
				{
					Value = 1,
					Num = 2500,
				},
			},
		},
		{
			Level = 9,
			UpgradeCostList = {
				{
					Value = 320053,
					Num = 11,
				},
				{
					Value = 1,
					Num = 3500,
				},
			},
		},
	},
}
EquipmentUpgradeConfig[EquipmentUpgradeID.Id068] =
{
	LevelList = {
		{
			Level = 1,
			UpgradeCostList = {
				{
					Value = 320051,
					Num = 2,
				},
				{
					Value = 1,
					Num = 30,
				},
			},
		},
		{
			Level = 2,
			UpgradeCostList = {
				{
					Value = 320051,
					Num = 6,
				},
				{
					Value = 1,
					Num = 70,
				},
			},
		},
		{
			Level = 3,
			UpgradeCostList = {
				{
					Value = 320051,
					Num = 14,
				},
				{
					Value = 1,
					Num = 180,
				},
			},
		},
		{
			Level = 4,
			UpgradeCostList = {
				{
					Value = 320052,
					Num = 5,
				},
				{
					Value = 1,
					Num = 360,
				},
			},
		},
		{
			Level = 5,
			UpgradeCostList = {
				{
					Value = 320052,
					Num = 10,
				},
				{
					Value = 1,
					Num = 660,
				},
			},
		},
		{
			Level = 6,
			UpgradeCostList = {
				{
					Value = 320052,
					Num = 15,
				},
				{
					Value = 1,
					Num = 1100,
				},
			},
		},
		{
			Level = 7,
			UpgradeCostList = {
				{
					Value = 320053,
					Num = 5,
				},
				{
					Value = 1,
					Num = 1700,
				},
			},
		},
		{
			Level = 8,
			UpgradeCostList = {
				{
					Value = 320053,
					Num = 8,
				},
				{
					Value = 1,
					Num = 2500,
				},
			},
		},
		{
			Level = 9,
			UpgradeCostList = {
				{
					Value = 320053,
					Num = 11,
				},
				{
					Value = 1,
					Num = 3500,
				},
			},
		},
	},
}
EquipmentUpgradeConfig[EquipmentUpgradeID.Id069] =
{
	LevelList = {
		{
			Level = 1,
			UpgradeCostList = {
				{
					Value = 320051,
					Num = 7,
				},
				{
					Value = 1,
					Num = 90,
				},
			},
		},
		{
			Level = 2,
			UpgradeCostList = {
				{
					Value = 320051,
					Num = 15,
				},
				{
					Value = 1,
					Num = 220,
				},
			},
		},
		{
			Level = 3,
			UpgradeCostList = {
				{
					Value = 320051,
					Num = 40,
				},
				{
					Value = 1,
					Num = 540,
				},
			},
		},
		{
			Level = 4,
			UpgradeCostList = {
				{
					Value = 320051,
					Num = 85,
				},
				{
					Value = 1,
					Num = 1100,
				},
			},
		},
		{
			Level = 5,
			UpgradeCostList = {
				{
					Value = 320051,
					Num = 155,
				},
				{
					Value = 1,
					Num = 1900,
				},
			},
		},
		{
			Level = 6,
			UpgradeCostList = {
				{
					Value = 320051,
					Num = 265,
				},
				{
					Value = 1,
					Num = 3300,
				},
			},
		},
		{
			Level = 7,
			UpgradeCostList = {
				{
					Value = 320053,
					Num = 15,
				},
				{
					Value = 1,
					Num = 5200,
				},
			},
		},
		{
			Level = 8,
			UpgradeCostList = {
				{
					Value = 320053,
					Num = 20,
				},
				{
					Value = 1,
					Num = 7500,
				},
			},
		},
		{
			Level = 9,
			UpgradeCostList = {
				{
					Value = 320053,
					Num = 30,
				},
				{
					Value = 1,
					Num = 10600,
				},
			},
		},
	},
}
EquipmentUpgradeConfig[EquipmentUpgradeID.Id070] =
{
	LevelList = {
		{
			Level = 1,
			UpgradeCostList = {
				{
					Value = 320051,
					Num = 7,
				},
				{
					Value = 1,
					Num = 90,
				},
			},
		},
		{
			Level = 2,
			UpgradeCostList = {
				{
					Value = 320051,
					Num = 15,
				},
				{
					Value = 1,
					Num = 220,
				},
			},
		},
		{
			Level = 3,
			UpgradeCostList = {
				{
					Value = 320051,
					Num = 40,
				},
				{
					Value = 1,
					Num = 540,
				},
			},
		},
		{
			Level = 4,
			UpgradeCostList = {
				{
					Value = 320052,
					Num = 15,
				},
				{
					Value = 1,
					Num = 1100,
				},
			},
		},
		{
			Level = 5,
			UpgradeCostList = {
				{
					Value = 320052,
					Num = 30,
				},
				{
					Value = 1,
					Num = 1900,
				},
			},
		},
		{
			Level = 6,
			UpgradeCostList = {
				{
					Value = 320052,
					Num = 50,
				},
				{
					Value = 1,
					Num = 3300,
				},
			},
		},
		{
			Level = 7,
			UpgradeCostList = {
				{
					Value = 320053,
					Num = 15,
				},
				{
					Value = 1,
					Num = 5200,
				},
			},
		},
		{
			Level = 8,
			UpgradeCostList = {
				{
					Value = 320053,
					Num = 20,
				},
				{
					Value = 1,
					Num = 7500,
				},
			},
		},
		{
			Level = 9,
			UpgradeCostList = {
				{
					Value = 320053,
					Num = 30,
				},
				{
					Value = 1,
					Num = 10600,
				},
			},
		},
	},
}
EquipmentUpgradeConfig[EquipmentUpgradeID.Id071] =
{
	LevelList = {
		{
			Level = 1,
			UpgradeCostList = {
				{
					Value = 320052,
					Num = 4,
				},
				{
					Value = 1,
					Num = 260,
				},
			},
		},
		{
			Level = 2,
			UpgradeCostList = {
				{
					Value = 320052,
					Num = 13,
				},
				{
					Value = 1,
					Num = 840,
				},
			},
		},
		{
			Level = 3,
			UpgradeCostList = {
				{
					Value = 320052,
					Num = 30,
				},
				{
					Value = 1,
					Num = 2000,
				},
			},
		},
		{
			Level = 4,
			UpgradeCostList = {
				{
					Value = 320053,
					Num = 13,
				},
				{
					Value = 1,
					Num = 4100,
				},
			},
		},
		{
			Level = 5,
			UpgradeCostList = {
				{
					Value = 320053,
					Num = 20,
				},
				{
					Value = 1,
					Num = 7400,
				},
			},
		},
		{
			Level = 6,
			UpgradeCostList = {
				{
					Value = 320053,
					Num = 35,
				},
				{
					Value = 1,
					Num = 12100,
				},
			},
		},
		{
			Level = 7,
			UpgradeCostList = {
				{
					Value = 320054,
					Num = 11,
				},
				{
					Value = 1,
					Num = 18300,
				},
			},
		},
		{
			Level = 8,
			UpgradeCostList = {
				{
					Value = 320054,
					Num = 15,
				},
				{
					Value = 1,
					Num = 26600,
				},
			},
		},
		{
			Level = 9,
			UpgradeCostList = {
				{
					Value = 320054,
					Num = 20,
				},
				{
					Value = 1,
					Num = 36900,
				},
			},
		},
	},
}
EquipmentUpgradeConfig[EquipmentUpgradeID.Id072] =
{
	LevelList = {
		{
			Level = 1,
			UpgradeCostList = {
				{
					Value = 320052,
					Num = 4,
				},
				{
					Value = 1,
					Num = 260,
				},
			},
		},
		{
			Level = 2,
			UpgradeCostList = {
				{
					Value = 320052,
					Num = 13,
				},
				{
					Value = 1,
					Num = 840,
				},
			},
		},
		{
			Level = 3,
			UpgradeCostList = {
				{
					Value = 320052,
					Num = 30,
				},
				{
					Value = 1,
					Num = 2000,
				},
			},
		},
		{
			Level = 4,
			UpgradeCostList = {
				{
					Value = 320053,
					Num = 13,
				},
				{
					Value = 1,
					Num = 4100,
				},
			},
		},
		{
			Level = 5,
			UpgradeCostList = {
				{
					Value = 320053,
					Num = 20,
				},
				{
					Value = 1,
					Num = 7400,
				},
			},
		},
		{
			Level = 6,
			UpgradeCostList = {
				{
					Value = 320053,
					Num = 35,
				},
				{
					Value = 1,
					Num = 12100,
				},
			},
		},
		{
			Level = 7,
			UpgradeCostList = {
				{
					Value = 320054,
					Num = 11,
				},
				{
					Value = 1,
					Num = 18300,
				},
			},
		},
		{
			Level = 8,
			UpgradeCostList = {
				{
					Value = 320054,
					Num = 15,
				},
				{
					Value = 1,
					Num = 26600,
				},
			},
		},
		{
			Level = 9,
			UpgradeCostList = {
				{
					Value = 320054,
					Num = 20,
				},
				{
					Value = 1,
					Num = 36900,
				},
			},
		},
	},
}
EquipmentUpgradeConfig[EquipmentUpgradeID.Id073] =
{
	LevelList = {
		{
			Level = 1,
			UpgradeCostList = {
				{
					Value = 320051,
					Num = 15,
				},
				{
					Value = 1,
					Num = 190,
				},
			},
		},
		{
			Level = 2,
			UpgradeCostList = {
				{
					Value = 320051,
					Num = 35,
				},
				{
					Value = 1,
					Num = 450,
				},
			},
		},
		{
			Level = 3,
			UpgradeCostList = {
				{
					Value = 320051,
					Num = 85,
				},
				{
					Value = 1,
					Num = 1000,
				},
			},
		},
		{
			Level = 4,
			UpgradeCostList = {
				{
					Value = 320052,
					Num = 35,
				},
				{
					Value = 1,
					Num = 2200,
				},
			},
		},
		{
			Level = 5,
			UpgradeCostList = {
				{
					Value = 320052,
					Num = 60,
				},
				{
					Value = 1,
					Num = 3900,
				},
			},
		},
		{
			Level = 6,
			UpgradeCostList = {
				{
					Value = 320052,
					Num = 105,
				},
				{
					Value = 1,
					Num = 6700,
				},
			},
		},
		{
			Level = 7,
			UpgradeCostList = {
				{
					Value = 320053,
					Num = 30,
				},
				{
					Value = 1,
					Num = 10400,
				},
			},
		},
		{
			Level = 8,
			UpgradeCostList = {
				{
					Value = 320053,
					Num = 45,
				},
				{
					Value = 1,
					Num = 15100,
				},
			},
		},
		{
			Level = 9,
			UpgradeCostList = {
				{
					Value = 320053,
					Num = 65,
				},
				{
					Value = 1,
					Num = 21200,
				},
			},
		},
	},
}
EquipmentUpgradeConfig[EquipmentUpgradeID.Id074] =
{
	LevelList = {
		{
			Level = 1,
			UpgradeCostList = {
				{
					Value = 320052,
					Num = 3,
				},
				{
					Value = 1,
					Num = 190,
				},
			},
		},
		{
			Level = 2,
			UpgradeCostList = {
				{
					Value = 320052,
					Num = 7,
				},
				{
					Value = 1,
					Num = 450,
				},
			},
		},
		{
			Level = 3,
			UpgradeCostList = {
				{
					Value = 320052,
					Num = 15,
				},
				{
					Value = 1,
					Num = 1000,
				},
			},
		},
		{
			Level = 4,
			UpgradeCostList = {
				{
					Value = 320053,
					Num = 7,
				},
				{
					Value = 1,
					Num = 2200,
				},
			},
		},
		{
			Level = 5,
			UpgradeCostList = {
				{
					Value = 320053,
					Num = 12,
				},
				{
					Value = 1,
					Num = 3900,
				},
			},
		},
		{
			Level = 6,
			UpgradeCostList = {
				{
					Value = 320053,
					Num = 20,
				},
				{
					Value = 1,
					Num = 6700,
				},
			},
		},
		{
			Level = 7,
			UpgradeCostList = {
				{
					Value = 320054,
					Num = 6,
				},
				{
					Value = 1,
					Num = 10400,
				},
			},
		},
		{
			Level = 8,
			UpgradeCostList = {
				{
					Value = 320054,
					Num = 9,
				},
				{
					Value = 1,
					Num = 15100,
				},
			},
		},
		{
			Level = 9,
			UpgradeCostList = {
				{
					Value = 320054,
					Num = 13,
				},
				{
					Value = 1,
					Num = 21200,
				},
			},
		},
	},
}
EquipmentUpgradeConfig[EquipmentUpgradeID.Id075] =
{
	LevelList = {
		{
			Level = 1,
			UpgradeCostList = {
				{
					Value = 320053,
					Num = 1,
				},
				{
					Value = 1,
					Num = 530,
				},
			},
		},
		{
			Level = 2,
			UpgradeCostList = {
				{
					Value = 320053,
					Num = 5,
				},
				{
					Value = 1,
					Num = 1600,
				},
			},
		},
		{
			Level = 3,
			UpgradeCostList = {
				{
					Value = 320053,
					Num = 12,
				},
				{
					Value = 1,
					Num = 4000,
				},
			},
		},
		{
			Level = 4,
			UpgradeCostList = {
				{
					Value = 320054,
					Num = 5,
				},
				{
					Value = 1,
					Num = 8300,
				},
			},
		},
		{
			Level = 5,
			UpgradeCostList = {
				{
					Value = 320054,
					Num = 9,
				},
				{
					Value = 1,
					Num = 14800,
				},
			},
		},
		{
			Level = 6,
			UpgradeCostList = {
				{
					Value = 320054,
					Num = 15,
				},
				{
					Value = 1,
					Num = 24200,
				},
			},
		},
		{
			Level = 7,
			UpgradeCostList = {
				{
					Value = 320054,
					Num = 20,
				},
				{
					Value = 1,
					Num = 36700,
				},
			},
		},
		{
			Level = 8,
			UpgradeCostList = {
				{
					Value = 320054,
					Num = 30,
				},
				{
					Value = 1,
					Num = 53200,
				},
			},
		},
		{
			Level = 9,
			UpgradeCostList = {
				{
					Value = 320054,
					Num = 45,
				},
				{
					Value = 1,
					Num = 73800,
				},
			},
		},
	},
}
EquipmentUpgradeConfig[EquipmentUpgradeID.Id076] =
{
	LevelList = {
		{
			Level = 1,
			UpgradeCostList = {
				{
					Value = 320053,
					Num = 1,
				},
				{
					Value = 1,
					Num = 530,
				},
			},
		},
		{
			Level = 2,
			UpgradeCostList = {
				{
					Value = 320053,
					Num = 5,
				},
				{
					Value = 1,
					Num = 1600,
				},
			},
		},
		{
			Level = 3,
			UpgradeCostList = {
				{
					Value = 320053,
					Num = 12,
				},
				{
					Value = 1,
					Num = 4000,
				},
			},
		},
		{
			Level = 4,
			UpgradeCostList = {
				{
					Value = 320054,
					Num = 5,
				},
				{
					Value = 1,
					Num = 8300,
				},
			},
		},
		{
			Level = 5,
			UpgradeCostList = {
				{
					Value = 320054,
					Num = 9,
				},
				{
					Value = 1,
					Num = 14800,
				},
			},
		},
		{
			Level = 6,
			UpgradeCostList = {
				{
					Value = 320054,
					Num = 15,
				},
				{
					Value = 1,
					Num = 24200,
				},
			},
		},
		{
			Level = 7,
			UpgradeCostList = {
				{
					Value = 320054,
					Num = 20,
				},
				{
					Value = 1,
					Num = 36700,
				},
			},
		},
		{
			Level = 8,
			UpgradeCostList = {
				{
					Value = 320054,
					Num = 30,
				},
				{
					Value = 1,
					Num = 53200,
				},
			},
		},
		{
			Level = 9,
			UpgradeCostList = {
				{
					Value = 320054,
					Num = 45,
				},
				{
					Value = 1,
					Num = 73800,
				},
			},
		},
	},
}
EquipmentUpgradeConfig[EquipmentUpgradeID.Id077] =
{
	LevelList = {
		{
			Level = 1,
			UpgradeCostList = {
				{
					Value = 320052,
					Num = 6,
				},
				{
					Value = 1,
					Num = 390,
				},
			},
		},
		{
			Level = 2,
			UpgradeCostList = {
				{
					Value = 320052,
					Num = 14,
				},
				{
					Value = 1,
					Num = 910,
				},
			},
		},
		{
			Level = 3,
			UpgradeCostList = {
				{
					Value = 320052,
					Num = 30,
				},
				{
					Value = 1,
					Num = 2100,
				},
			},
		},
		{
			Level = 4,
			UpgradeCostList = {
				{
					Value = 320052,
					Num = 70,
				},
				{
					Value = 1,
					Num = 4400,
				},
			},
		},
		{
			Level = 5,
			UpgradeCostList = {
				{
					Value = 320052,
					Num = 125,
				},
				{
					Value = 1,
					Num = 7900,
				},
			},
		},
		{
			Level = 6,
			UpgradeCostList = {
				{
					Value = 320052,
					Num = 215,
				},
				{
					Value = 1,
					Num = 13400,
				},
			},
		},
		{
			Level = 7,
			UpgradeCostList = {
				{
					Value = 320054,
					Num = 13,
				},
				{
					Value = 1,
					Num = 20800,
				},
			},
		},
		{
			Level = 8,
			UpgradeCostList = {
				{
					Value = 320054,
					Num = 15,
				},
				{
					Value = 1,
					Num = 30300,
				},
			},
		},
		{
			Level = 9,
			UpgradeCostList = {
				{
					Value = 320054,
					Num = 25,
				},
				{
					Value = 1,
					Num = 42500,
				},
			},
		},
	},
}
EquipmentUpgradeConfig[EquipmentUpgradeID.Id078] =
{
	LevelList = {
		{
			Level = 1,
			UpgradeCostList = {
				{
					Value = 320052,
					Num = 6,
				},
				{
					Value = 1,
					Num = 390,
				},
			},
		},
		{
			Level = 2,
			UpgradeCostList = {
				{
					Value = 320052,
					Num = 14,
				},
				{
					Value = 1,
					Num = 910,
				},
			},
		},
		{
			Level = 3,
			UpgradeCostList = {
				{
					Value = 320052,
					Num = 30,
				},
				{
					Value = 1,
					Num = 2100,
				},
			},
		},
		{
			Level = 4,
			UpgradeCostList = {
				{
					Value = 320052,
					Num = 70,
				},
				{
					Value = 1,
					Num = 4400,
				},
			},
		},
		{
			Level = 5,
			UpgradeCostList = {
				{
					Value = 320052,
					Num = 125,
				},
				{
					Value = 1,
					Num = 7900,
				},
			},
		},
		{
			Level = 6,
			UpgradeCostList = {
				{
					Value = 320052,
					Num = 215,
				},
				{
					Value = 1,
					Num = 13400,
				},
			},
		},
		{
			Level = 7,
			UpgradeCostList = {
				{
					Value = 320054,
					Num = 13,
				},
				{
					Value = 1,
					Num = 20800,
				},
			},
		},
		{
			Level = 8,
			UpgradeCostList = {
				{
					Value = 320054,
					Num = 15,
				},
				{
					Value = 1,
					Num = 30300,
				},
			},
		},
		{
			Level = 9,
			UpgradeCostList = {
				{
					Value = 320054,
					Num = 25,
				},
				{
					Value = 1,
					Num = 42500,
				},
			},
		},
	},
}
EquipmentUpgradeConfig[EquipmentUpgradeID.Id079] =
{
	LevelList = {
		{
			Level = 1,
			UpgradeCostList = {
				{
					Value = 320053,
					Num = 3,
				},
				{
					Value = 1,
					Num = 1000,
				},
			},
		},
		{
			Level = 2,
			UpgradeCostList = {
				{
					Value = 320053,
					Num = 10,
				},
				{
					Value = 1,
					Num = 3300,
				},
			},
		},
		{
			Level = 3,
			UpgradeCostList = {
				{
					Value = 320053,
					Num = 25,
				},
				{
					Value = 1,
					Num = 8000,
				},
			},
		},
		{
			Level = 4,
			UpgradeCostList = {
				{
					Value = 320053,
					Num = 50,
				},
				{
					Value = 1,
					Num = 16600,
				},
			},
		},
		{
			Level = 5,
			UpgradeCostList = {
				{
					Value = 320053,
					Num = 90,
				},
				{
					Value = 1,
					Num = 29600,
				},
			},
		},
		{
			Level = 6,
			UpgradeCostList = {
				{
					Value = 320053,
					Num = 150,
				},
				{
					Value = 1,
					Num = 48400,
				},
			},
		},
		{
			Level = 7,
			UpgradeCostList = {
				{
					Value = 320054,
					Num = 45,
				},
				{
					Value = 1,
					Num = 73500,
				},
			},
		},
		{
			Level = 8,
			UpgradeCostList = {
				{
					Value = 320054,
					Num = 65,
				},
				{
					Value = 1,
					Num = 106000,
				},
			},
		},
		{
			Level = 9,
			UpgradeCostList = {
				{
					Value = 320054,
					Num = 90,
				},
				{
					Value = 1,
					Num = 147000,
				},
			},
		},
	},
}
EquipmentUpgradeConfig[EquipmentUpgradeID.Id080] =
{
	LevelList = {
		{
			Level = 1,
			UpgradeCostList = {
				{
					Value = 320053,
					Num = 9,
				},
				{
					Value = 1,
					Num = 2800,
				},
			},
		},
		{
			Level = 2,
			UpgradeCostList = {
				{
					Value = 320053,
					Num = 25,
				},
				{
					Value = 1,
					Num = 9200,
				},
			},
		},
		{
			Level = 3,
			UpgradeCostList = {
				{
					Value = 320053,
					Num = 70,
				},
				{
					Value = 1,
					Num = 22600,
				},
			},
		},
		{
			Level = 4,
			UpgradeCostList = {
				{
					Value = 320054,
					Num = 25,
				},
				{
					Value = 1,
					Num = 45100,
				},
			},
		},
		{
			Level = 5,
			UpgradeCostList = {
				{
					Value = 320054,
					Num = 50,
				},
				{
					Value = 1,
					Num = 79200,
				},
			},
		},
		{
			Level = 6,
			UpgradeCostList = {
				{
					Value = 320054,
					Num = 80,
				},
				{
					Value = 1,
					Num = 127000,
				},
			},
		},
		{
			Level = 7,
			UpgradeCostList = {
				{
					Value = 320054,
					Num = 120,
				},
				{
					Value = 1,
					Num = 192000,
				},
			},
		},
		{
			Level = 8,
			UpgradeCostList = {
				{
					Value = 320054,
					Num = 175,
				},
				{
					Value = 1,
					Num = 276000,
				},
			},
		},
		{
			Level = 9,
			UpgradeCostList = {
				{
					Value = 320054,
					Num = 240,
				},
				{
					Value = 1,
					Num = 381000,
				},
			},
		},
	},
}
EquipmentUpgradeConfig[EquipmentUpgradeID.Id081] =
{
	LevelList = {
		{
			Level = 1,
			UpgradeCostList = {
				{
					Value = 320151,
					Num = 1,
				},
				{
					Value = 1,
					Num = 10,
				},
			},
		},
		{
			Level = 2,
			UpgradeCostList = {
				{
					Value = 320151,
					Num = 1,
				},
				{
					Value = 1,
					Num = 30,
				},
			},
		},
		{
			Level = 3,
			UpgradeCostList = {
				{
					Value = 320151,
					Num = 1,
				},
				{
					Value = 1,
					Num = 90,
				},
			},
		},
		{
			Level = 4,
			UpgradeCostList = {
				{
					Value = 320151,
					Num = 1,
				},
				{
					Value = 1,
					Num = 180,
				},
			},
		},
		{
			Level = 5,
			UpgradeCostList = {
				{
					Value = 320151,
					Num = 1,
				},
				{
					Value = 1,
					Num = 330,
				},
			},
		},
		{
			Level = 6,
			UpgradeCostList = {
				{
					Value = 320151,
					Num = 1,
				},
				{
					Value = 1,
					Num = 560,
				},
			},
		},
		{
			Level = 7,
			UpgradeCostList = {
				{
					Value = 320151,
					Num = 1,
				},
				{
					Value = 1,
					Num = 860,
				},
			},
		},
		{
			Level = 8,
			UpgradeCostList = {
				{
					Value = 320151,
					Num = 1,
				},
				{
					Value = 1,
					Num = 1200,
				},
			},
		},
		{
			Level = 9,
			UpgradeCostList = {
				{
					Value = 320151,
					Num = 1,
				},
				{
					Value = 1,
					Num = 1700,
				},
			},
		},
	},
}
EquipmentUpgradeConfig[EquipmentUpgradeID.Id082] =
{
	LevelList = {
		{
			Level = 1,
			UpgradeCostList = {
				{
					Value = 320151,
					Num = 1,
				},
				{
					Value = 1,
					Num = 10,
				},
			},
		},
		{
			Level = 2,
			UpgradeCostList = {
				{
					Value = 320151,
					Num = 1,
				},
				{
					Value = 1,
					Num = 30,
				},
			},
		},
		{
			Level = 3,
			UpgradeCostList = {
				{
					Value = 320151,
					Num = 1,
				},
				{
					Value = 1,
					Num = 90,
				},
			},
		},
		{
			Level = 4,
			UpgradeCostList = {
				{
					Value = 320151,
					Num = 1,
				},
				{
					Value = 1,
					Num = 180,
				},
			},
		},
		{
			Level = 5,
			UpgradeCostList = {
				{
					Value = 320151,
					Num = 1,
				},
				{
					Value = 1,
					Num = 330,
				},
			},
		},
		{
			Level = 6,
			UpgradeCostList = {
				{
					Value = 320151,
					Num = 1,
				},
				{
					Value = 1,
					Num = 560,
				},
			},
		},
		{
			Level = 7,
			UpgradeCostList = {
				{
					Value = 320151,
					Num = 1,
				},
				{
					Value = 1,
					Num = 860,
				},
			},
		},
		{
			Level = 8,
			UpgradeCostList = {
				{
					Value = 320151,
					Num = 1,
				},
				{
					Value = 1,
					Num = 1200,
				},
			},
		},
		{
			Level = 9,
			UpgradeCostList = {
				{
					Value = 320151,
					Num = 1,
				},
				{
					Value = 1,
					Num = 1700,
				},
			},
		},
	},
}
EquipmentUpgradeConfig[EquipmentUpgradeID.Id083] =
{
	LevelList = {
		{
			Level = 1,
			UpgradeCostList = {
				{
					Value = 320151,
					Num = 1,
				},
				{
					Value = 1,
					Num = 10,
				},
			},
		},
		{
			Level = 2,
			UpgradeCostList = {
				{
					Value = 320151,
					Num = 1,
				},
				{
					Value = 1,
					Num = 30,
				},
			},
		},
		{
			Level = 3,
			UpgradeCostList = {
				{
					Value = 320151,
					Num = 1,
				},
				{
					Value = 1,
					Num = 90,
				},
			},
		},
		{
			Level = 4,
			UpgradeCostList = {
				{
					Value = 320151,
					Num = 1,
				},
				{
					Value = 1,
					Num = 180,
				},
			},
		},
		{
			Level = 5,
			UpgradeCostList = {
				{
					Value = 320151,
					Num = 1,
				},
				{
					Value = 1,
					Num = 330,
				},
			},
		},
		{
			Level = 6,
			UpgradeCostList = {
				{
					Value = 320151,
					Num = 1,
				},
				{
					Value = 1,
					Num = 560,
				},
			},
		},
		{
			Level = 7,
			UpgradeCostList = {
				{
					Value = 320151,
					Num = 1,
				},
				{
					Value = 1,
					Num = 860,
				},
			},
		},
		{
			Level = 8,
			UpgradeCostList = {
				{
					Value = 320151,
					Num = 1,
				},
				{
					Value = 1,
					Num = 1200,
				},
			},
		},
		{
			Level = 9,
			UpgradeCostList = {
				{
					Value = 320151,
					Num = 1,
				},
				{
					Value = 1,
					Num = 1700,
				},
			},
		},
	},
}
EquipmentUpgradeConfig[EquipmentUpgradeID.Id084] =
{
	LevelList = {
		{
			Level = 1,
			UpgradeCostList = {
				{
					Value = 320151,
					Num = 1,
				},
				{
					Value = 1,
					Num = 10,
				},
			},
		},
		{
			Level = 2,
			UpgradeCostList = {
				{
					Value = 320151,
					Num = 1,
				},
				{
					Value = 1,
					Num = 30,
				},
			},
		},
		{
			Level = 3,
			UpgradeCostList = {
				{
					Value = 320151,
					Num = 1,
				},
				{
					Value = 1,
					Num = 90,
				},
			},
		},
		{
			Level = 4,
			UpgradeCostList = {
				{
					Value = 320151,
					Num = 1,
				},
				{
					Value = 1,
					Num = 180,
				},
			},
		},
		{
			Level = 5,
			UpgradeCostList = {
				{
					Value = 320151,
					Num = 1,
				},
				{
					Value = 1,
					Num = 330,
				},
			},
		},
		{
			Level = 6,
			UpgradeCostList = {
				{
					Value = 320151,
					Num = 1,
				},
				{
					Value = 1,
					Num = 560,
				},
			},
		},
		{
			Level = 7,
			UpgradeCostList = {
				{
					Value = 320151,
					Num = 1,
				},
				{
					Value = 1,
					Num = 860,
				},
			},
		},
		{
			Level = 8,
			UpgradeCostList = {
				{
					Value = 320151,
					Num = 1,
				},
				{
					Value = 1,
					Num = 1200,
				},
			},
		},
		{
			Level = 9,
			UpgradeCostList = {
				{
					Value = 320151,
					Num = 1,
				},
				{
					Value = 1,
					Num = 1700,
				},
			},
		},
	},
}
EquipmentUpgradeConfig[EquipmentUpgradeID.Id085] =
{
	LevelList = {
		{
			Level = 1,
			UpgradeCostList = {
				{
					Value = 320151,
					Num = 1,
				},
				{
					Value = 1,
					Num = 30,
				},
			},
		},
		{
			Level = 2,
			UpgradeCostList = {
				{
					Value = 320151,
					Num = 1,
				},
				{
					Value = 1,
					Num = 70,
				},
			},
		},
		{
			Level = 3,
			UpgradeCostList = {
				{
					Value = 320151,
					Num = 1,
				},
				{
					Value = 1,
					Num = 180,
				},
			},
		},
		{
			Level = 4,
			UpgradeCostList = {
				{
					Value = 320151,
					Num = 1,
				},
				{
					Value = 1,
					Num = 360,
				},
			},
		},
		{
			Level = 5,
			UpgradeCostList = {
				{
					Value = 320151,
					Num = 1,
				},
				{
					Value = 1,
					Num = 660,
				},
			},
		},
		{
			Level = 6,
			UpgradeCostList = {
				{
					Value = 320151,
					Num = 1,
				},
				{
					Value = 1,
					Num = 1100,
				},
			},
		},
		{
			Level = 7,
			UpgradeCostList = {
				{
					Value = 320151,
					Num = 1,
				},
				{
					Value = 1,
					Num = 1700,
				},
			},
		},
		{
			Level = 8,
			UpgradeCostList = {
				{
					Value = 320151,
					Num = 1,
				},
				{
					Value = 1,
					Num = 2500,
				},
			},
		},
		{
			Level = 9,
			UpgradeCostList = {
				{
					Value = 320151,
					Num = 1,
				},
				{
					Value = 1,
					Num = 3500,
				},
			},
		},
	},
}
EquipmentUpgradeConfig[EquipmentUpgradeID.Id086] =
{
	LevelList = {
		{
			Level = 1,
			UpgradeCostList = {
				{
					Value = 320151,
					Num = 1,
				},
				{
					Value = 1,
					Num = 30,
				},
			},
		},
		{
			Level = 2,
			UpgradeCostList = {
				{
					Value = 320151,
					Num = 1,
				},
				{
					Value = 1,
					Num = 70,
				},
			},
		},
		{
			Level = 3,
			UpgradeCostList = {
				{
					Value = 320151,
					Num = 1,
				},
				{
					Value = 1,
					Num = 180,
				},
			},
		},
		{
			Level = 4,
			UpgradeCostList = {
				{
					Value = 320151,
					Num = 1,
				},
				{
					Value = 1,
					Num = 360,
				},
			},
		},
		{
			Level = 5,
			UpgradeCostList = {
				{
					Value = 320151,
					Num = 1,
				},
				{
					Value = 1,
					Num = 660,
				},
			},
		},
		{
			Level = 6,
			UpgradeCostList = {
				{
					Value = 320151,
					Num = 1,
				},
				{
					Value = 1,
					Num = 1100,
				},
			},
		},
		{
			Level = 7,
			UpgradeCostList = {
				{
					Value = 320151,
					Num = 1,
				},
				{
					Value = 1,
					Num = 1700,
				},
			},
		},
		{
			Level = 8,
			UpgradeCostList = {
				{
					Value = 320151,
					Num = 1,
				},
				{
					Value = 1,
					Num = 2500,
				},
			},
		},
		{
			Level = 9,
			UpgradeCostList = {
				{
					Value = 320151,
					Num = 1,
				},
				{
					Value = 1,
					Num = 3500,
				},
			},
		},
	},
}
EquipmentUpgradeConfig[EquipmentUpgradeID.Id087] =
{
	LevelList = {
		{
			Level = 1,
			UpgradeCostList = {
				{
					Value = 320151,
					Num = 1,
				},
				{
					Value = 1,
					Num = 30,
				},
			},
		},
		{
			Level = 2,
			UpgradeCostList = {
				{
					Value = 320151,
					Num = 1,
				},
				{
					Value = 1,
					Num = 70,
				},
			},
		},
		{
			Level = 3,
			UpgradeCostList = {
				{
					Value = 320151,
					Num = 1,
				},
				{
					Value = 1,
					Num = 180,
				},
			},
		},
		{
			Level = 4,
			UpgradeCostList = {
				{
					Value = 320151,
					Num = 1,
				},
				{
					Value = 1,
					Num = 360,
				},
			},
		},
		{
			Level = 5,
			UpgradeCostList = {
				{
					Value = 320151,
					Num = 1,
				},
				{
					Value = 1,
					Num = 660,
				},
			},
		},
		{
			Level = 6,
			UpgradeCostList = {
				{
					Value = 320151,
					Num = 1,
				},
				{
					Value = 1,
					Num = 1100,
				},
			},
		},
		{
			Level = 7,
			UpgradeCostList = {
				{
					Value = 320151,
					Num = 1,
				},
				{
					Value = 1,
					Num = 1700,
				},
			},
		},
		{
			Level = 8,
			UpgradeCostList = {
				{
					Value = 320151,
					Num = 1,
				},
				{
					Value = 1,
					Num = 2500,
				},
			},
		},
		{
			Level = 9,
			UpgradeCostList = {
				{
					Value = 320151,
					Num = 1,
				},
				{
					Value = 1,
					Num = 3500,
				},
			},
		},
	},
}
EquipmentUpgradeConfig[EquipmentUpgradeID.Id088] =
{
	LevelList = {
		{
			Level = 1,
			UpgradeCostList = {
				{
					Value = 320151,
					Num = 1,
				},
				{
					Value = 1,
					Num = 30,
				},
			},
		},
		{
			Level = 2,
			UpgradeCostList = {
				{
					Value = 320151,
					Num = 1,
				},
				{
					Value = 1,
					Num = 70,
				},
			},
		},
		{
			Level = 3,
			UpgradeCostList = {
				{
					Value = 320151,
					Num = 1,
				},
				{
					Value = 1,
					Num = 180,
				},
			},
		},
		{
			Level = 4,
			UpgradeCostList = {
				{
					Value = 320151,
					Num = 1,
				},
				{
					Value = 1,
					Num = 360,
				},
			},
		},
		{
			Level = 5,
			UpgradeCostList = {
				{
					Value = 320151,
					Num = 1,
				},
				{
					Value = 1,
					Num = 660,
				},
			},
		},
		{
			Level = 6,
			UpgradeCostList = {
				{
					Value = 320151,
					Num = 1,
				},
				{
					Value = 1,
					Num = 1100,
				},
			},
		},
		{
			Level = 7,
			UpgradeCostList = {
				{
					Value = 320151,
					Num = 1,
				},
				{
					Value = 1,
					Num = 1700,
				},
			},
		},
		{
			Level = 8,
			UpgradeCostList = {
				{
					Value = 320151,
					Num = 1,
				},
				{
					Value = 1,
					Num = 2500,
				},
			},
		},
		{
			Level = 9,
			UpgradeCostList = {
				{
					Value = 320151,
					Num = 1,
				},
				{
					Value = 1,
					Num = 3500,
				},
			},
		},
	},
}
EquipmentUpgradeConfig[EquipmentUpgradeID.Id089] =
{
	LevelList = {
		{
			Level = 1,
			UpgradeCostList = {
				{
					Value = 320151,
					Num = 1,
				},
				{
					Value = 1,
					Num = 90,
				},
			},
		},
		{
			Level = 2,
			UpgradeCostList = {
				{
					Value = 320151,
					Num = 1,
				},
				{
					Value = 1,
					Num = 220,
				},
			},
		},
		{
			Level = 3,
			UpgradeCostList = {
				{
					Value = 320151,
					Num = 1,
				},
				{
					Value = 1,
					Num = 540,
				},
			},
		},
		{
			Level = 4,
			UpgradeCostList = {
				{
					Value = 320151,
					Num = 1,
				},
				{
					Value = 1,
					Num = 1100,
				},
			},
		},
		{
			Level = 5,
			UpgradeCostList = {
				{
					Value = 320151,
					Num = 1,
				},
				{
					Value = 1,
					Num = 1900,
				},
			},
		},
		{
			Level = 6,
			UpgradeCostList = {
				{
					Value = 320151,
					Num = 1,
				},
				{
					Value = 1,
					Num = 3300,
				},
			},
		},
		{
			Level = 7,
			UpgradeCostList = {
				{
					Value = 320151,
					Num = 1,
				},
				{
					Value = 1,
					Num = 5200,
				},
			},
		},
		{
			Level = 8,
			UpgradeCostList = {
				{
					Value = 320151,
					Num = 1,
				},
				{
					Value = 1,
					Num = 7500,
				},
			},
		},
		{
			Level = 9,
			UpgradeCostList = {
				{
					Value = 320151,
					Num = 1,
				},
				{
					Value = 1,
					Num = 10600,
				},
			},
		},
	},
}
EquipmentUpgradeConfig[EquipmentUpgradeID.Id090] =
{
	LevelList = {
		{
			Level = 1,
			UpgradeCostList = {
				{
					Value = 320151,
					Num = 1,
				},
				{
					Value = 1,
					Num = 90,
				},
			},
		},
		{
			Level = 2,
			UpgradeCostList = {
				{
					Value = 320151,
					Num = 1,
				},
				{
					Value = 1,
					Num = 220,
				},
			},
		},
		{
			Level = 3,
			UpgradeCostList = {
				{
					Value = 320151,
					Num = 1,
				},
				{
					Value = 1,
					Num = 540,
				},
			},
		},
		{
			Level = 4,
			UpgradeCostList = {
				{
					Value = 320151,
					Num = 1,
				},
				{
					Value = 1,
					Num = 1100,
				},
			},
		},
		{
			Level = 5,
			UpgradeCostList = {
				{
					Value = 320151,
					Num = 1,
				},
				{
					Value = 1,
					Num = 1900,
				},
			},
		},
		{
			Level = 6,
			UpgradeCostList = {
				{
					Value = 320151,
					Num = 1,
				},
				{
					Value = 1,
					Num = 3300,
				},
			},
		},
		{
			Level = 7,
			UpgradeCostList = {
				{
					Value = 320151,
					Num = 1,
				},
				{
					Value = 1,
					Num = 5200,
				},
			},
		},
		{
			Level = 8,
			UpgradeCostList = {
				{
					Value = 320151,
					Num = 1,
				},
				{
					Value = 1,
					Num = 7500,
				},
			},
		},
		{
			Level = 9,
			UpgradeCostList = {
				{
					Value = 320151,
					Num = 1,
				},
				{
					Value = 1,
					Num = 10600,
				},
			},
		},
	},
}
EquipmentUpgradeConfig[EquipmentUpgradeID.Id091] =
{
	LevelList = {
		{
			Level = 1,
			UpgradeCostList = {
				{
					Value = 320151,
					Num = 1,
				},
				{
					Value = 1,
					Num = 260,
				},
			},
		},
		{
			Level = 2,
			UpgradeCostList = {
				{
					Value = 320151,
					Num = 1,
				},
				{
					Value = 1,
					Num = 840,
				},
			},
		},
		{
			Level = 3,
			UpgradeCostList = {
				{
					Value = 320151,
					Num = 1,
				},
				{
					Value = 1,
					Num = 2000,
				},
			},
		},
		{
			Level = 4,
			UpgradeCostList = {
				{
					Value = 320151,
					Num = 1,
				},
				{
					Value = 1,
					Num = 4100,
				},
			},
		},
		{
			Level = 5,
			UpgradeCostList = {
				{
					Value = 320151,
					Num = 1,
				},
				{
					Value = 1,
					Num = 7400,
				},
			},
		},
		{
			Level = 6,
			UpgradeCostList = {
				{
					Value = 320151,
					Num = 1,
				},
				{
					Value = 1,
					Num = 12100,
				},
			},
		},
		{
			Level = 7,
			UpgradeCostList = {
				{
					Value = 320151,
					Num = 1,
				},
				{
					Value = 1,
					Num = 18300,
				},
			},
		},
		{
			Level = 8,
			UpgradeCostList = {
				{
					Value = 320151,
					Num = 1,
				},
				{
					Value = 1,
					Num = 26600,
				},
			},
		},
		{
			Level = 9,
			UpgradeCostList = {
				{
					Value = 320151,
					Num = 1,
				},
				{
					Value = 1,
					Num = 36900,
				},
			},
		},
	},
}
EquipmentUpgradeConfig[EquipmentUpgradeID.Id092] =
{
	LevelList = {
		{
			Level = 1,
			UpgradeCostList = {
				{
					Value = 320151,
					Num = 1,
				},
				{
					Value = 1,
					Num = 260,
				},
			},
		},
		{
			Level = 2,
			UpgradeCostList = {
				{
					Value = 320151,
					Num = 1,
				},
				{
					Value = 1,
					Num = 840,
				},
			},
		},
		{
			Level = 3,
			UpgradeCostList = {
				{
					Value = 320151,
					Num = 1,
				},
				{
					Value = 1,
					Num = 2000,
				},
			},
		},
		{
			Level = 4,
			UpgradeCostList = {
				{
					Value = 320151,
					Num = 1,
				},
				{
					Value = 1,
					Num = 4100,
				},
			},
		},
		{
			Level = 5,
			UpgradeCostList = {
				{
					Value = 320151,
					Num = 1,
				},
				{
					Value = 1,
					Num = 7400,
				},
			},
		},
		{
			Level = 6,
			UpgradeCostList = {
				{
					Value = 320151,
					Num = 1,
				},
				{
					Value = 1,
					Num = 12100,
				},
			},
		},
		{
			Level = 7,
			UpgradeCostList = {
				{
					Value = 320151,
					Num = 1,
				},
				{
					Value = 1,
					Num = 18300,
				},
			},
		},
		{
			Level = 8,
			UpgradeCostList = {
				{
					Value = 320151,
					Num = 1,
				},
				{
					Value = 1,
					Num = 26600,
				},
			},
		},
		{
			Level = 9,
			UpgradeCostList = {
				{
					Value = 320151,
					Num = 1,
				},
				{
					Value = 1,
					Num = 36900,
				},
			},
		},
	},
}
EquipmentUpgradeConfig[EquipmentUpgradeID.Id093] =
{
	LevelList = {
		{
			Level = 1,
			UpgradeCostList = {
				{
					Value = 320151,
					Num = 1,
				},
				{
					Value = 1,
					Num = 190,
				},
			},
		},
		{
			Level = 2,
			UpgradeCostList = {
				{
					Value = 320151,
					Num = 1,
				},
				{
					Value = 1,
					Num = 450,
				},
			},
		},
		{
			Level = 3,
			UpgradeCostList = {
				{
					Value = 320151,
					Num = 1,
				},
				{
					Value = 1,
					Num = 1000,
				},
			},
		},
		{
			Level = 4,
			UpgradeCostList = {
				{
					Value = 320151,
					Num = 1,
				},
				{
					Value = 1,
					Num = 2200,
				},
			},
		},
		{
			Level = 5,
			UpgradeCostList = {
				{
					Value = 320151,
					Num = 1,
				},
				{
					Value = 1,
					Num = 3900,
				},
			},
		},
		{
			Level = 6,
			UpgradeCostList = {
				{
					Value = 320151,
					Num = 1,
				},
				{
					Value = 1,
					Num = 6700,
				},
			},
		},
		{
			Level = 7,
			UpgradeCostList = {
				{
					Value = 320151,
					Num = 1,
				},
				{
					Value = 1,
					Num = 10400,
				},
			},
		},
		{
			Level = 8,
			UpgradeCostList = {
				{
					Value = 320151,
					Num = 1,
				},
				{
					Value = 1,
					Num = 15100,
				},
			},
		},
		{
			Level = 9,
			UpgradeCostList = {
				{
					Value = 320151,
					Num = 1,
				},
				{
					Value = 1,
					Num = 21200,
				},
			},
		},
	},
}
EquipmentUpgradeConfig[EquipmentUpgradeID.Id094] =
{
	LevelList = {
		{
			Level = 1,
			UpgradeCostList = {
				{
					Value = 320151,
					Num = 1,
				},
				{
					Value = 1,
					Num = 190,
				},
			},
		},
		{
			Level = 2,
			UpgradeCostList = {
				{
					Value = 320151,
					Num = 1,
				},
				{
					Value = 1,
					Num = 450,
				},
			},
		},
		{
			Level = 3,
			UpgradeCostList = {
				{
					Value = 320151,
					Num = 1,
				},
				{
					Value = 1,
					Num = 1000,
				},
			},
		},
		{
			Level = 4,
			UpgradeCostList = {
				{
					Value = 320151,
					Num = 1,
				},
				{
					Value = 1,
					Num = 2200,
				},
			},
		},
		{
			Level = 5,
			UpgradeCostList = {
				{
					Value = 320151,
					Num = 1,
				},
				{
					Value = 1,
					Num = 3900,
				},
			},
		},
		{
			Level = 6,
			UpgradeCostList = {
				{
					Value = 320151,
					Num = 1,
				},
				{
					Value = 1,
					Num = 6700,
				},
			},
		},
		{
			Level = 7,
			UpgradeCostList = {
				{
					Value = 320151,
					Num = 1,
				},
				{
					Value = 1,
					Num = 10400,
				},
			},
		},
		{
			Level = 8,
			UpgradeCostList = {
				{
					Value = 320151,
					Num = 1,
				},
				{
					Value = 1,
					Num = 15100,
				},
			},
		},
		{
			Level = 9,
			UpgradeCostList = {
				{
					Value = 320151,
					Num = 1,
				},
				{
					Value = 1,
					Num = 21200,
				},
			},
		},
	},
}
EquipmentUpgradeConfig[EquipmentUpgradeID.Id095] =
{
	LevelList = {
		{
			Level = 1,
			UpgradeCostList = {
				{
					Value = 320151,
					Num = 1,
				},
				{
					Value = 1,
					Num = 530,
				},
			},
		},
		{
			Level = 2,
			UpgradeCostList = {
				{
					Value = 320151,
					Num = 1,
				},
				{
					Value = 1,
					Num = 1600,
				},
			},
		},
		{
			Level = 3,
			UpgradeCostList = {
				{
					Value = 320151,
					Num = 1,
				},
				{
					Value = 1,
					Num = 4000,
				},
			},
		},
		{
			Level = 4,
			UpgradeCostList = {
				{
					Value = 320151,
					Num = 1,
				},
				{
					Value = 1,
					Num = 8300,
				},
			},
		},
		{
			Level = 5,
			UpgradeCostList = {
				{
					Value = 320151,
					Num = 1,
				},
				{
					Value = 1,
					Num = 14800,
				},
			},
		},
		{
			Level = 6,
			UpgradeCostList = {
				{
					Value = 320151,
					Num = 1,
				},
				{
					Value = 1,
					Num = 24200,
				},
			},
		},
		{
			Level = 7,
			UpgradeCostList = {
				{
					Value = 320151,
					Num = 1,
				},
				{
					Value = 1,
					Num = 36700,
				},
			},
		},
		{
			Level = 8,
			UpgradeCostList = {
				{
					Value = 320151,
					Num = 1,
				},
				{
					Value = 1,
					Num = 53200,
				},
			},
		},
		{
			Level = 9,
			UpgradeCostList = {
				{
					Value = 320151,
					Num = 1,
				},
				{
					Value = 1,
					Num = 73800,
				},
			},
		},
	},
}
EquipmentUpgradeConfig[EquipmentUpgradeID.Id096] =
{
	LevelList = {
		{
			Level = 1,
			UpgradeCostList = {
				{
					Value = 320151,
					Num = 1,
				},
				{
					Value = 1,
					Num = 530,
				},
			},
		},
		{
			Level = 2,
			UpgradeCostList = {
				{
					Value = 320151,
					Num = 1,
				},
				{
					Value = 1,
					Num = 1600,
				},
			},
		},
		{
			Level = 3,
			UpgradeCostList = {
				{
					Value = 320151,
					Num = 1,
				},
				{
					Value = 1,
					Num = 4000,
				},
			},
		},
		{
			Level = 4,
			UpgradeCostList = {
				{
					Value = 320151,
					Num = 1,
				},
				{
					Value = 1,
					Num = 8300,
				},
			},
		},
		{
			Level = 5,
			UpgradeCostList = {
				{
					Value = 320151,
					Num = 1,
				},
				{
					Value = 1,
					Num = 14800,
				},
			},
		},
		{
			Level = 6,
			UpgradeCostList = {
				{
					Value = 320151,
					Num = 1,
				},
				{
					Value = 1,
					Num = 24200,
				},
			},
		},
		{
			Level = 7,
			UpgradeCostList = {
				{
					Value = 320151,
					Num = 1,
				},
				{
					Value = 1,
					Num = 36700,
				},
			},
		},
		{
			Level = 8,
			UpgradeCostList = {
				{
					Value = 320151,
					Num = 1,
				},
				{
					Value = 1,
					Num = 53200,
				},
			},
		},
		{
			Level = 9,
			UpgradeCostList = {
				{
					Value = 320151,
					Num = 1,
				},
				{
					Value = 1,
					Num = 73800,
				},
			},
		},
	},
}
EquipmentUpgradeConfig[EquipmentUpgradeID.Id097] =
{
	LevelList = {
		{
			Level = 1,
			UpgradeCostList = {
				{
					Value = 320151,
					Num = 1,
				},
				{
					Value = 1,
					Num = 390,
				},
			},
		},
		{
			Level = 2,
			UpgradeCostList = {
				{
					Value = 320151,
					Num = 1,
				},
				{
					Value = 1,
					Num = 910,
				},
			},
		},
		{
			Level = 3,
			UpgradeCostList = {
				{
					Value = 320151,
					Num = 1,
				},
				{
					Value = 1,
					Num = 2100,
				},
			},
		},
		{
			Level = 4,
			UpgradeCostList = {
				{
					Value = 320151,
					Num = 1,
				},
				{
					Value = 1,
					Num = 4400,
				},
			},
		},
		{
			Level = 5,
			UpgradeCostList = {
				{
					Value = 320151,
					Num = 1,
				},
				{
					Value = 1,
					Num = 7900,
				},
			},
		},
		{
			Level = 6,
			UpgradeCostList = {
				{
					Value = 320151,
					Num = 1,
				},
				{
					Value = 1,
					Num = 13400,
				},
			},
		},
		{
			Level = 7,
			UpgradeCostList = {
				{
					Value = 320151,
					Num = 1,
				},
				{
					Value = 1,
					Num = 20800,
				},
			},
		},
		{
			Level = 8,
			UpgradeCostList = {
				{
					Value = 320151,
					Num = 1,
				},
				{
					Value = 1,
					Num = 30300,
				},
			},
		},
		{
			Level = 9,
			UpgradeCostList = {
				{
					Value = 320151,
					Num = 1,
				},
				{
					Value = 1,
					Num = 42500,
				},
			},
		},
	},
}
EquipmentUpgradeConfig[EquipmentUpgradeID.Id098] =
{
	LevelList = {
		{
			Level = 1,
			UpgradeCostList = {
				{
					Value = 320151,
					Num = 1,
				},
				{
					Value = 1,
					Num = 390,
				},
			},
		},
		{
			Level = 2,
			UpgradeCostList = {
				{
					Value = 320151,
					Num = 1,
				},
				{
					Value = 1,
					Num = 910,
				},
			},
		},
		{
			Level = 3,
			UpgradeCostList = {
				{
					Value = 320151,
					Num = 1,
				},
				{
					Value = 1,
					Num = 2100,
				},
			},
		},
		{
			Level = 4,
			UpgradeCostList = {
				{
					Value = 320151,
					Num = 1,
				},
				{
					Value = 1,
					Num = 4400,
				},
			},
		},
		{
			Level = 5,
			UpgradeCostList = {
				{
					Value = 320151,
					Num = 1,
				},
				{
					Value = 1,
					Num = 7900,
				},
			},
		},
		{
			Level = 6,
			UpgradeCostList = {
				{
					Value = 320151,
					Num = 1,
				},
				{
					Value = 1,
					Num = 13400,
				},
			},
		},
		{
			Level = 7,
			UpgradeCostList = {
				{
					Value = 320151,
					Num = 1,
				},
				{
					Value = 1,
					Num = 20800,
				},
			},
		},
		{
			Level = 8,
			UpgradeCostList = {
				{
					Value = 320151,
					Num = 1,
				},
				{
					Value = 1,
					Num = 30300,
				},
			},
		},
		{
			Level = 9,
			UpgradeCostList = {
				{
					Value = 320151,
					Num = 1,
				},
				{
					Value = 1,
					Num = 42500,
				},
			},
		},
	},
}
EquipmentUpgradeConfig[EquipmentUpgradeID.Id099] =
{
	LevelList = {
		{
			Level = 1,
			UpgradeCostList = {
				{
					Value = 320151,
					Num = 1,
				},
				{
					Value = 1,
					Num = 1000,
				},
			},
		},
		{
			Level = 2,
			UpgradeCostList = {
				{
					Value = 320151,
					Num = 1,
				},
				{
					Value = 1,
					Num = 3300,
				},
			},
		},
		{
			Level = 3,
			UpgradeCostList = {
				{
					Value = 320151,
					Num = 1,
				},
				{
					Value = 1,
					Num = 8000,
				},
			},
		},
		{
			Level = 4,
			UpgradeCostList = {
				{
					Value = 320151,
					Num = 1,
				},
				{
					Value = 1,
					Num = 16600,
				},
			},
		},
		{
			Level = 5,
			UpgradeCostList = {
				{
					Value = 320151,
					Num = 1,
				},
				{
					Value = 1,
					Num = 29600,
				},
			},
		},
		{
			Level = 6,
			UpgradeCostList = {
				{
					Value = 320151,
					Num = 1,
				},
				{
					Value = 1,
					Num = 48400,
				},
			},
		},
		{
			Level = 7,
			UpgradeCostList = {
				{
					Value = 320151,
					Num = 1,
				},
				{
					Value = 1,
					Num = 73500,
				},
			},
		},
		{
			Level = 8,
			UpgradeCostList = {
				{
					Value = 320151,
					Num = 1,
				},
				{
					Value = 1,
					Num = 106000,
				},
			},
		},
		{
			Level = 9,
			UpgradeCostList = {
				{
					Value = 320151,
					Num = 1,
				},
				{
					Value = 1,
					Num = 147000,
				},
			},
		},
	},
}
EquipmentUpgradeConfig[EquipmentUpgradeID.Id100] =
{
	LevelList = {
		{
			Level = 1,
			UpgradeCostList = {
				{
					Value = 320151,
					Num = 1,
				},
				{
					Value = 1,
					Num = 2800,
				},
			},
		},
		{
			Level = 2,
			UpgradeCostList = {
				{
					Value = 320151,
					Num = 1,
				},
				{
					Value = 1,
					Num = 9200,
				},
			},
		},
		{
			Level = 3,
			UpgradeCostList = {
				{
					Value = 320151,
					Num = 1,
				},
				{
					Value = 1,
					Num = 22600,
				},
			},
		},
		{
			Level = 4,
			UpgradeCostList = {
				{
					Value = 320151,
					Num = 1,
				},
				{
					Value = 1,
					Num = 45100,
				},
			},
		},
		{
			Level = 5,
			UpgradeCostList = {
				{
					Value = 320151,
					Num = 1,
				},
				{
					Value = 1,
					Num = 79200,
				},
			},
		},
		{
			Level = 6,
			UpgradeCostList = {
				{
					Value = 320151,
					Num = 1,
				},
				{
					Value = 1,
					Num = 127000,
				},
			},
		},
		{
			Level = 7,
			UpgradeCostList = {
				{
					Value = 320151,
					Num = 1,
				},
				{
					Value = 1,
					Num = 192000,
				},
			},
		},
		{
			Level = 8,
			UpgradeCostList = {
				{
					Value = 320151,
					Num = 1,
				},
				{
					Value = 1,
					Num = 276000,
				},
			},
		},
		{
			Level = 9,
			UpgradeCostList = {
				{
					Value = 320151,
					Num = 1,
				},
				{
					Value = 1,
					Num = 381000,
				},
			},
		},
	},
}
EquipmentUpgradeConfig[EquipmentUpgradeID.Id101] =
{
	LevelList = {
		{
			Level = 1,
			UpgradeCostList = {
				{
					Value = 320151,
					Num = 1,
				},
				{
					Value = 1,
					Num = 10,
				},
			},
		},
		{
			Level = 2,
			UpgradeCostList = {
				{
					Value = 320151,
					Num = 1,
				},
				{
					Value = 1,
					Num = 30,
				},
			},
		},
		{
			Level = 3,
			UpgradeCostList = {
				{
					Value = 320151,
					Num = 1,
				},
				{
					Value = 1,
					Num = 90,
				},
			},
		},
		{
			Level = 4,
			UpgradeCostList = {
				{
					Value = 320151,
					Num = 1,
				},
				{
					Value = 1,
					Num = 180,
				},
			},
		},
		{
			Level = 5,
			UpgradeCostList = {
				{
					Value = 320151,
					Num = 1,
				},
				{
					Value = 1,
					Num = 330,
				},
			},
		},
		{
			Level = 6,
			UpgradeCostList = {
				{
					Value = 320151,
					Num = 1,
				},
				{
					Value = 1,
					Num = 560,
				},
			},
		},
		{
			Level = 7,
			UpgradeCostList = {
				{
					Value = 320151,
					Num = 1,
				},
				{
					Value = 1,
					Num = 860,
				},
			},
		},
		{
			Level = 8,
			UpgradeCostList = {
				{
					Value = 320151,
					Num = 1,
				},
				{
					Value = 1,
					Num = 1200,
				},
			},
		},
		{
			Level = 9,
			UpgradeCostList = {
				{
					Value = 320151,
					Num = 1,
				},
				{
					Value = 1,
					Num = 1700,
				},
			},
		},
	},
}
EquipmentUpgradeConfig[EquipmentUpgradeID.Id102] =
{
	LevelList = {
		{
			Level = 1,
			UpgradeCostList = {
				{
					Value = 320151,
					Num = 1,
				},
				{
					Value = 1,
					Num = 10,
				},
			},
		},
		{
			Level = 2,
			UpgradeCostList = {
				{
					Value = 320151,
					Num = 1,
				},
				{
					Value = 1,
					Num = 30,
				},
			},
		},
		{
			Level = 3,
			UpgradeCostList = {
				{
					Value = 320151,
					Num = 1,
				},
				{
					Value = 1,
					Num = 90,
				},
			},
		},
		{
			Level = 4,
			UpgradeCostList = {
				{
					Value = 320151,
					Num = 1,
				},
				{
					Value = 1,
					Num = 180,
				},
			},
		},
		{
			Level = 5,
			UpgradeCostList = {
				{
					Value = 320151,
					Num = 1,
				},
				{
					Value = 1,
					Num = 330,
				},
			},
		},
		{
			Level = 6,
			UpgradeCostList = {
				{
					Value = 320151,
					Num = 1,
				},
				{
					Value = 1,
					Num = 560,
				},
			},
		},
		{
			Level = 7,
			UpgradeCostList = {
				{
					Value = 320151,
					Num = 1,
				},
				{
					Value = 1,
					Num = 860,
				},
			},
		},
		{
			Level = 8,
			UpgradeCostList = {
				{
					Value = 320151,
					Num = 1,
				},
				{
					Value = 1,
					Num = 1200,
				},
			},
		},
		{
			Level = 9,
			UpgradeCostList = {
				{
					Value = 320151,
					Num = 1,
				},
				{
					Value = 1,
					Num = 1700,
				},
			},
		},
	},
}
EquipmentUpgradeConfig[EquipmentUpgradeID.Id103] =
{
	LevelList = {
		{
			Level = 1,
			UpgradeCostList = {
				{
					Value = 320151,
					Num = 1,
				},
				{
					Value = 1,
					Num = 10,
				},
			},
		},
		{
			Level = 2,
			UpgradeCostList = {
				{
					Value = 320151,
					Num = 1,
				},
				{
					Value = 1,
					Num = 30,
				},
			},
		},
		{
			Level = 3,
			UpgradeCostList = {
				{
					Value = 320151,
					Num = 1,
				},
				{
					Value = 1,
					Num = 90,
				},
			},
		},
		{
			Level = 4,
			UpgradeCostList = {
				{
					Value = 320151,
					Num = 1,
				},
				{
					Value = 1,
					Num = 180,
				},
			},
		},
		{
			Level = 5,
			UpgradeCostList = {
				{
					Value = 320151,
					Num = 1,
				},
				{
					Value = 1,
					Num = 330,
				},
			},
		},
		{
			Level = 6,
			UpgradeCostList = {
				{
					Value = 320151,
					Num = 1,
				},
				{
					Value = 1,
					Num = 560,
				},
			},
		},
		{
			Level = 7,
			UpgradeCostList = {
				{
					Value = 320151,
					Num = 1,
				},
				{
					Value = 1,
					Num = 860,
				},
			},
		},
		{
			Level = 8,
			UpgradeCostList = {
				{
					Value = 320151,
					Num = 1,
				},
				{
					Value = 1,
					Num = 1200,
				},
			},
		},
		{
			Level = 9,
			UpgradeCostList = {
				{
					Value = 320151,
					Num = 1,
				},
				{
					Value = 1,
					Num = 1700,
				},
			},
		},
	},
}
EquipmentUpgradeConfig[EquipmentUpgradeID.Id104] =
{
	LevelList = {
		{
			Level = 1,
			UpgradeCostList = {
				{
					Value = 320151,
					Num = 1,
				},
				{
					Value = 1,
					Num = 10,
				},
			},
		},
		{
			Level = 2,
			UpgradeCostList = {
				{
					Value = 320151,
					Num = 1,
				},
				{
					Value = 1,
					Num = 30,
				},
			},
		},
		{
			Level = 3,
			UpgradeCostList = {
				{
					Value = 320151,
					Num = 1,
				},
				{
					Value = 1,
					Num = 90,
				},
			},
		},
		{
			Level = 4,
			UpgradeCostList = {
				{
					Value = 320151,
					Num = 1,
				},
				{
					Value = 1,
					Num = 180,
				},
			},
		},
		{
			Level = 5,
			UpgradeCostList = {
				{
					Value = 320151,
					Num = 1,
				},
				{
					Value = 1,
					Num = 330,
				},
			},
		},
		{
			Level = 6,
			UpgradeCostList = {
				{
					Value = 320151,
					Num = 1,
				},
				{
					Value = 1,
					Num = 560,
				},
			},
		},
		{
			Level = 7,
			UpgradeCostList = {
				{
					Value = 320151,
					Num = 1,
				},
				{
					Value = 1,
					Num = 860,
				},
			},
		},
		{
			Level = 8,
			UpgradeCostList = {
				{
					Value = 320151,
					Num = 1,
				},
				{
					Value = 1,
					Num = 1200,
				},
			},
		},
		{
			Level = 9,
			UpgradeCostList = {
				{
					Value = 320151,
					Num = 1,
				},
				{
					Value = 1,
					Num = 1700,
				},
			},
		},
	},
}
EquipmentUpgradeConfig[EquipmentUpgradeID.Id105] =
{
	LevelList = {
		{
			Level = 1,
			UpgradeCostList = {
				{
					Value = 320151,
					Num = 1,
				},
				{
					Value = 1,
					Num = 30,
				},
			},
		},
		{
			Level = 2,
			UpgradeCostList = {
				{
					Value = 320151,
					Num = 1,
				},
				{
					Value = 1,
					Num = 70,
				},
			},
		},
		{
			Level = 3,
			UpgradeCostList = {
				{
					Value = 320151,
					Num = 1,
				},
				{
					Value = 1,
					Num = 180,
				},
			},
		},
		{
			Level = 4,
			UpgradeCostList = {
				{
					Value = 320151,
					Num = 1,
				},
				{
					Value = 1,
					Num = 360,
				},
			},
		},
		{
			Level = 5,
			UpgradeCostList = {
				{
					Value = 320151,
					Num = 1,
				},
				{
					Value = 1,
					Num = 660,
				},
			},
		},
		{
			Level = 6,
			UpgradeCostList = {
				{
					Value = 320151,
					Num = 1,
				},
				{
					Value = 1,
					Num = 1100,
				},
			},
		},
		{
			Level = 7,
			UpgradeCostList = {
				{
					Value = 320151,
					Num = 1,
				},
				{
					Value = 1,
					Num = 1700,
				},
			},
		},
		{
			Level = 8,
			UpgradeCostList = {
				{
					Value = 320151,
					Num = 1,
				},
				{
					Value = 1,
					Num = 2500,
				},
			},
		},
		{
			Level = 9,
			UpgradeCostList = {
				{
					Value = 320151,
					Num = 1,
				},
				{
					Value = 1,
					Num = 3500,
				},
			},
		},
	},
}
EquipmentUpgradeConfig[EquipmentUpgradeID.Id106] =
{
	LevelList = {
		{
			Level = 1,
			UpgradeCostList = {
				{
					Value = 320151,
					Num = 1,
				},
				{
					Value = 1,
					Num = 30,
				},
			},
		},
		{
			Level = 2,
			UpgradeCostList = {
				{
					Value = 320151,
					Num = 1,
				},
				{
					Value = 1,
					Num = 70,
				},
			},
		},
		{
			Level = 3,
			UpgradeCostList = {
				{
					Value = 320151,
					Num = 1,
				},
				{
					Value = 1,
					Num = 180,
				},
			},
		},
		{
			Level = 4,
			UpgradeCostList = {
				{
					Value = 320151,
					Num = 1,
				},
				{
					Value = 1,
					Num = 360,
				},
			},
		},
		{
			Level = 5,
			UpgradeCostList = {
				{
					Value = 320151,
					Num = 1,
				},
				{
					Value = 1,
					Num = 660,
				},
			},
		},
		{
			Level = 6,
			UpgradeCostList = {
				{
					Value = 320151,
					Num = 1,
				},
				{
					Value = 1,
					Num = 1100,
				},
			},
		},
		{
			Level = 7,
			UpgradeCostList = {
				{
					Value = 320151,
					Num = 1,
				},
				{
					Value = 1,
					Num = 1700,
				},
			},
		},
		{
			Level = 8,
			UpgradeCostList = {
				{
					Value = 320151,
					Num = 1,
				},
				{
					Value = 1,
					Num = 2500,
				},
			},
		},
		{
			Level = 9,
			UpgradeCostList = {
				{
					Value = 320151,
					Num = 1,
				},
				{
					Value = 1,
					Num = 3500,
				},
			},
		},
	},
}
EquipmentUpgradeConfig[EquipmentUpgradeID.Id107] =
{
	LevelList = {
		{
			Level = 1,
			UpgradeCostList = {
				{
					Value = 320151,
					Num = 1,
				},
				{
					Value = 1,
					Num = 30,
				},
			},
		},
		{
			Level = 2,
			UpgradeCostList = {
				{
					Value = 320151,
					Num = 1,
				},
				{
					Value = 1,
					Num = 70,
				},
			},
		},
		{
			Level = 3,
			UpgradeCostList = {
				{
					Value = 320151,
					Num = 1,
				},
				{
					Value = 1,
					Num = 180,
				},
			},
		},
		{
			Level = 4,
			UpgradeCostList = {
				{
					Value = 320151,
					Num = 1,
				},
				{
					Value = 1,
					Num = 360,
				},
			},
		},
		{
			Level = 5,
			UpgradeCostList = {
				{
					Value = 320151,
					Num = 1,
				},
				{
					Value = 1,
					Num = 660,
				},
			},
		},
		{
			Level = 6,
			UpgradeCostList = {
				{
					Value = 320151,
					Num = 1,
				},
				{
					Value = 1,
					Num = 1100,
				},
			},
		},
		{
			Level = 7,
			UpgradeCostList = {
				{
					Value = 320151,
					Num = 1,
				},
				{
					Value = 1,
					Num = 1700,
				},
			},
		},
		{
			Level = 8,
			UpgradeCostList = {
				{
					Value = 320151,
					Num = 1,
				},
				{
					Value = 1,
					Num = 2500,
				},
			},
		},
		{
			Level = 9,
			UpgradeCostList = {
				{
					Value = 320151,
					Num = 1,
				},
				{
					Value = 1,
					Num = 3500,
				},
			},
		},
	},
}
EquipmentUpgradeConfig[EquipmentUpgradeID.Id108] =
{
	LevelList = {
		{
			Level = 1,
			UpgradeCostList = {
				{
					Value = 320151,
					Num = 1,
				},
				{
					Value = 1,
					Num = 30,
				},
			},
		},
		{
			Level = 2,
			UpgradeCostList = {
				{
					Value = 320151,
					Num = 1,
				},
				{
					Value = 1,
					Num = 70,
				},
			},
		},
		{
			Level = 3,
			UpgradeCostList = {
				{
					Value = 320151,
					Num = 1,
				},
				{
					Value = 1,
					Num = 180,
				},
			},
		},
		{
			Level = 4,
			UpgradeCostList = {
				{
					Value = 320151,
					Num = 1,
				},
				{
					Value = 1,
					Num = 360,
				},
			},
		},
		{
			Level = 5,
			UpgradeCostList = {
				{
					Value = 320151,
					Num = 1,
				},
				{
					Value = 1,
					Num = 660,
				},
			},
		},
		{
			Level = 6,
			UpgradeCostList = {
				{
					Value = 320151,
					Num = 1,
				},
				{
					Value = 1,
					Num = 1100,
				},
			},
		},
		{
			Level = 7,
			UpgradeCostList = {
				{
					Value = 320151,
					Num = 1,
				},
				{
					Value = 1,
					Num = 1700,
				},
			},
		},
		{
			Level = 8,
			UpgradeCostList = {
				{
					Value = 320151,
					Num = 1,
				},
				{
					Value = 1,
					Num = 2500,
				},
			},
		},
		{
			Level = 9,
			UpgradeCostList = {
				{
					Value = 320151,
					Num = 1,
				},
				{
					Value = 1,
					Num = 3500,
				},
			},
		},
	},
}
EquipmentUpgradeConfig[EquipmentUpgradeID.Id109] =
{
	LevelList = {
		{
			Level = 1,
			UpgradeCostList = {
				{
					Value = 320151,
					Num = 1,
				},
				{
					Value = 1,
					Num = 90,
				},
			},
		},
		{
			Level = 2,
			UpgradeCostList = {
				{
					Value = 320151,
					Num = 1,
				},
				{
					Value = 1,
					Num = 220,
				},
			},
		},
		{
			Level = 3,
			UpgradeCostList = {
				{
					Value = 320151,
					Num = 1,
				},
				{
					Value = 1,
					Num = 540,
				},
			},
		},
		{
			Level = 4,
			UpgradeCostList = {
				{
					Value = 320151,
					Num = 1,
				},
				{
					Value = 1,
					Num = 1100,
				},
			},
		},
		{
			Level = 5,
			UpgradeCostList = {
				{
					Value = 320151,
					Num = 1,
				},
				{
					Value = 1,
					Num = 1900,
				},
			},
		},
		{
			Level = 6,
			UpgradeCostList = {
				{
					Value = 320151,
					Num = 1,
				},
				{
					Value = 1,
					Num = 3300,
				},
			},
		},
		{
			Level = 7,
			UpgradeCostList = {
				{
					Value = 320151,
					Num = 1,
				},
				{
					Value = 1,
					Num = 5200,
				},
			},
		},
		{
			Level = 8,
			UpgradeCostList = {
				{
					Value = 320151,
					Num = 1,
				},
				{
					Value = 1,
					Num = 7500,
				},
			},
		},
		{
			Level = 9,
			UpgradeCostList = {
				{
					Value = 320151,
					Num = 1,
				},
				{
					Value = 1,
					Num = 10600,
				},
			},
		},
	},
}
EquipmentUpgradeConfig[EquipmentUpgradeID.Id110] =
{
	LevelList = {
		{
			Level = 1,
			UpgradeCostList = {
				{
					Value = 320151,
					Num = 1,
				},
				{
					Value = 1,
					Num = 90,
				},
			},
		},
		{
			Level = 2,
			UpgradeCostList = {
				{
					Value = 320151,
					Num = 1,
				},
				{
					Value = 1,
					Num = 220,
				},
			},
		},
		{
			Level = 3,
			UpgradeCostList = {
				{
					Value = 320151,
					Num = 1,
				},
				{
					Value = 1,
					Num = 540,
				},
			},
		},
		{
			Level = 4,
			UpgradeCostList = {
				{
					Value = 320151,
					Num = 1,
				},
				{
					Value = 1,
					Num = 1100,
				},
			},
		},
		{
			Level = 5,
			UpgradeCostList = {
				{
					Value = 320151,
					Num = 1,
				},
				{
					Value = 1,
					Num = 1900,
				},
			},
		},
		{
			Level = 6,
			UpgradeCostList = {
				{
					Value = 320151,
					Num = 1,
				},
				{
					Value = 1,
					Num = 3300,
				},
			},
		},
		{
			Level = 7,
			UpgradeCostList = {
				{
					Value = 320151,
					Num = 1,
				},
				{
					Value = 1,
					Num = 5200,
				},
			},
		},
		{
			Level = 8,
			UpgradeCostList = {
				{
					Value = 320151,
					Num = 1,
				},
				{
					Value = 1,
					Num = 7500,
				},
			},
		},
		{
			Level = 9,
			UpgradeCostList = {
				{
					Value = 320151,
					Num = 1,
				},
				{
					Value = 1,
					Num = 10600,
				},
			},
		},
	},
}
EquipmentUpgradeConfig[EquipmentUpgradeID.Id111] =
{
	LevelList = {
		{
			Level = 1,
			UpgradeCostList = {
				{
					Value = 320151,
					Num = 1,
				},
				{
					Value = 1,
					Num = 260,
				},
			},
		},
		{
			Level = 2,
			UpgradeCostList = {
				{
					Value = 320151,
					Num = 1,
				},
				{
					Value = 1,
					Num = 840,
				},
			},
		},
		{
			Level = 3,
			UpgradeCostList = {
				{
					Value = 320151,
					Num = 1,
				},
				{
					Value = 1,
					Num = 2000,
				},
			},
		},
		{
			Level = 4,
			UpgradeCostList = {
				{
					Value = 320151,
					Num = 1,
				},
				{
					Value = 1,
					Num = 4100,
				},
			},
		},
		{
			Level = 5,
			UpgradeCostList = {
				{
					Value = 320151,
					Num = 1,
				},
				{
					Value = 1,
					Num = 7400,
				},
			},
		},
		{
			Level = 6,
			UpgradeCostList = {
				{
					Value = 320151,
					Num = 1,
				},
				{
					Value = 1,
					Num = 12100,
				},
			},
		},
		{
			Level = 7,
			UpgradeCostList = {
				{
					Value = 320151,
					Num = 1,
				},
				{
					Value = 1,
					Num = 18300,
				},
			},
		},
		{
			Level = 8,
			UpgradeCostList = {
				{
					Value = 320151,
					Num = 1,
				},
				{
					Value = 1,
					Num = 26600,
				},
			},
		},
		{
			Level = 9,
			UpgradeCostList = {
				{
					Value = 320151,
					Num = 1,
				},
				{
					Value = 1,
					Num = 36900,
				},
			},
		},
	},
}
EquipmentUpgradeConfig[EquipmentUpgradeID.Id112] =
{
	LevelList = {
		{
			Level = 1,
			UpgradeCostList = {
				{
					Value = 320151,
					Num = 1,
				},
				{
					Value = 1,
					Num = 260,
				},
			},
		},
		{
			Level = 2,
			UpgradeCostList = {
				{
					Value = 320151,
					Num = 1,
				},
				{
					Value = 1,
					Num = 840,
				},
			},
		},
		{
			Level = 3,
			UpgradeCostList = {
				{
					Value = 320151,
					Num = 1,
				},
				{
					Value = 1,
					Num = 2000,
				},
			},
		},
		{
			Level = 4,
			UpgradeCostList = {
				{
					Value = 320151,
					Num = 1,
				},
				{
					Value = 1,
					Num = 4100,
				},
			},
		},
		{
			Level = 5,
			UpgradeCostList = {
				{
					Value = 320151,
					Num = 1,
				},
				{
					Value = 1,
					Num = 7400,
				},
			},
		},
		{
			Level = 6,
			UpgradeCostList = {
				{
					Value = 320151,
					Num = 1,
				},
				{
					Value = 1,
					Num = 12100,
				},
			},
		},
		{
			Level = 7,
			UpgradeCostList = {
				{
					Value = 320151,
					Num = 1,
				},
				{
					Value = 1,
					Num = 18300,
				},
			},
		},
		{
			Level = 8,
			UpgradeCostList = {
				{
					Value = 320151,
					Num = 1,
				},
				{
					Value = 1,
					Num = 26600,
				},
			},
		},
		{
			Level = 9,
			UpgradeCostList = {
				{
					Value = 320151,
					Num = 1,
				},
				{
					Value = 1,
					Num = 36900,
				},
			},
		},
	},
}
EquipmentUpgradeConfig[EquipmentUpgradeID.Id113] =
{
	LevelList = {
		{
			Level = 1,
			UpgradeCostList = {
				{
					Value = 320151,
					Num = 1,
				},
				{
					Value = 1,
					Num = 190,
				},
			},
		},
		{
			Level = 2,
			UpgradeCostList = {
				{
					Value = 320151,
					Num = 1,
				},
				{
					Value = 1,
					Num = 450,
				},
			},
		},
		{
			Level = 3,
			UpgradeCostList = {
				{
					Value = 320151,
					Num = 1,
				},
				{
					Value = 1,
					Num = 1000,
				},
			},
		},
		{
			Level = 4,
			UpgradeCostList = {
				{
					Value = 320151,
					Num = 1,
				},
				{
					Value = 1,
					Num = 2200,
				},
			},
		},
		{
			Level = 5,
			UpgradeCostList = {
				{
					Value = 320151,
					Num = 1,
				},
				{
					Value = 1,
					Num = 3900,
				},
			},
		},
		{
			Level = 6,
			UpgradeCostList = {
				{
					Value = 320151,
					Num = 1,
				},
				{
					Value = 1,
					Num = 6700,
				},
			},
		},
		{
			Level = 7,
			UpgradeCostList = {
				{
					Value = 320151,
					Num = 1,
				},
				{
					Value = 1,
					Num = 10400,
				},
			},
		},
		{
			Level = 8,
			UpgradeCostList = {
				{
					Value = 320151,
					Num = 1,
				},
				{
					Value = 1,
					Num = 15100,
				},
			},
		},
		{
			Level = 9,
			UpgradeCostList = {
				{
					Value = 320151,
					Num = 1,
				},
				{
					Value = 1,
					Num = 21200,
				},
			},
		},
	},
}
EquipmentUpgradeConfig[EquipmentUpgradeID.Id114] =
{
	LevelList = {
		{
			Level = 1,
			UpgradeCostList = {
				{
					Value = 320151,
					Num = 1,
				},
				{
					Value = 1,
					Num = 190,
				},
			},
		},
		{
			Level = 2,
			UpgradeCostList = {
				{
					Value = 320151,
					Num = 1,
				},
				{
					Value = 1,
					Num = 450,
				},
			},
		},
		{
			Level = 3,
			UpgradeCostList = {
				{
					Value = 320151,
					Num = 1,
				},
				{
					Value = 1,
					Num = 1000,
				},
			},
		},
		{
			Level = 4,
			UpgradeCostList = {
				{
					Value = 320151,
					Num = 1,
				},
				{
					Value = 1,
					Num = 2200,
				},
			},
		},
		{
			Level = 5,
			UpgradeCostList = {
				{
					Value = 320151,
					Num = 1,
				},
				{
					Value = 1,
					Num = 3900,
				},
			},
		},
		{
			Level = 6,
			UpgradeCostList = {
				{
					Value = 320151,
					Num = 1,
				},
				{
					Value = 1,
					Num = 6700,
				},
			},
		},
		{
			Level = 7,
			UpgradeCostList = {
				{
					Value = 320151,
					Num = 1,
				},
				{
					Value = 1,
					Num = 10400,
				},
			},
		},
		{
			Level = 8,
			UpgradeCostList = {
				{
					Value = 320151,
					Num = 1,
				},
				{
					Value = 1,
					Num = 15100,
				},
			},
		},
		{
			Level = 9,
			UpgradeCostList = {
				{
					Value = 320151,
					Num = 1,
				},
				{
					Value = 1,
					Num = 21200,
				},
			},
		},
	},
}
EquipmentUpgradeConfig[EquipmentUpgradeID.Id115] =
{
	LevelList = {
		{
			Level = 1,
			UpgradeCostList = {
				{
					Value = 320151,
					Num = 1,
				},
				{
					Value = 1,
					Num = 530,
				},
			},
		},
		{
			Level = 2,
			UpgradeCostList = {
				{
					Value = 320151,
					Num = 1,
				},
				{
					Value = 1,
					Num = 1600,
				},
			},
		},
		{
			Level = 3,
			UpgradeCostList = {
				{
					Value = 320151,
					Num = 1,
				},
				{
					Value = 1,
					Num = 4000,
				},
			},
		},
		{
			Level = 4,
			UpgradeCostList = {
				{
					Value = 320151,
					Num = 1,
				},
				{
					Value = 1,
					Num = 8300,
				},
			},
		},
		{
			Level = 5,
			UpgradeCostList = {
				{
					Value = 320151,
					Num = 1,
				},
				{
					Value = 1,
					Num = 14800,
				},
			},
		},
		{
			Level = 6,
			UpgradeCostList = {
				{
					Value = 320151,
					Num = 1,
				},
				{
					Value = 1,
					Num = 24200,
				},
			},
		},
		{
			Level = 7,
			UpgradeCostList = {
				{
					Value = 320151,
					Num = 1,
				},
				{
					Value = 1,
					Num = 36700,
				},
			},
		},
		{
			Level = 8,
			UpgradeCostList = {
				{
					Value = 320151,
					Num = 1,
				},
				{
					Value = 1,
					Num = 53200,
				},
			},
		},
		{
			Level = 9,
			UpgradeCostList = {
				{
					Value = 320151,
					Num = 1,
				},
				{
					Value = 1,
					Num = 73800,
				},
			},
		},
	},
}
EquipmentUpgradeConfig[EquipmentUpgradeID.Id116] =
{
	LevelList = {
		{
			Level = 1,
			UpgradeCostList = {
				{
					Value = 320151,
					Num = 1,
				},
				{
					Value = 1,
					Num = 530,
				},
			},
		},
		{
			Level = 2,
			UpgradeCostList = {
				{
					Value = 320151,
					Num = 1,
				},
				{
					Value = 1,
					Num = 1600,
				},
			},
		},
		{
			Level = 3,
			UpgradeCostList = {
				{
					Value = 320151,
					Num = 1,
				},
				{
					Value = 1,
					Num = 4000,
				},
			},
		},
		{
			Level = 4,
			UpgradeCostList = {
				{
					Value = 320151,
					Num = 1,
				},
				{
					Value = 1,
					Num = 8300,
				},
			},
		},
		{
			Level = 5,
			UpgradeCostList = {
				{
					Value = 320151,
					Num = 1,
				},
				{
					Value = 1,
					Num = 14800,
				},
			},
		},
		{
			Level = 6,
			UpgradeCostList = {
				{
					Value = 320151,
					Num = 1,
				},
				{
					Value = 1,
					Num = 24200,
				},
			},
		},
		{
			Level = 7,
			UpgradeCostList = {
				{
					Value = 320151,
					Num = 1,
				},
				{
					Value = 1,
					Num = 36700,
				},
			},
		},
		{
			Level = 8,
			UpgradeCostList = {
				{
					Value = 320151,
					Num = 1,
				},
				{
					Value = 1,
					Num = 53200,
				},
			},
		},
		{
			Level = 9,
			UpgradeCostList = {
				{
					Value = 320151,
					Num = 1,
				},
				{
					Value = 1,
					Num = 73800,
				},
			},
		},
	},
}
EquipmentUpgradeConfig[EquipmentUpgradeID.Id117] =
{
	LevelList = {
		{
			Level = 1,
			UpgradeCostList = {
				{
					Value = 320151,
					Num = 1,
				},
				{
					Value = 1,
					Num = 390,
				},
			},
		},
		{
			Level = 2,
			UpgradeCostList = {
				{
					Value = 320151,
					Num = 1,
				},
				{
					Value = 1,
					Num = 910,
				},
			},
		},
		{
			Level = 3,
			UpgradeCostList = {
				{
					Value = 320151,
					Num = 1,
				},
				{
					Value = 1,
					Num = 2100,
				},
			},
		},
		{
			Level = 4,
			UpgradeCostList = {
				{
					Value = 320151,
					Num = 1,
				},
				{
					Value = 1,
					Num = 4400,
				},
			},
		},
		{
			Level = 5,
			UpgradeCostList = {
				{
					Value = 320151,
					Num = 1,
				},
				{
					Value = 1,
					Num = 7900,
				},
			},
		},
		{
			Level = 6,
			UpgradeCostList = {
				{
					Value = 320151,
					Num = 1,
				},
				{
					Value = 1,
					Num = 13400,
				},
			},
		},
		{
			Level = 7,
			UpgradeCostList = {
				{
					Value = 320151,
					Num = 1,
				},
				{
					Value = 1,
					Num = 20800,
				},
			},
		},
		{
			Level = 8,
			UpgradeCostList = {
				{
					Value = 320151,
					Num = 1,
				},
				{
					Value = 1,
					Num = 30300,
				},
			},
		},
		{
			Level = 9,
			UpgradeCostList = {
				{
					Value = 320151,
					Num = 1,
				},
				{
					Value = 1,
					Num = 42500,
				},
			},
		},
	},
}
EquipmentUpgradeConfig[EquipmentUpgradeID.Id118] =
{
	LevelList = {
		{
			Level = 1,
			UpgradeCostList = {
				{
					Value = 320151,
					Num = 1,
				},
				{
					Value = 1,
					Num = 390,
				},
			},
		},
		{
			Level = 2,
			UpgradeCostList = {
				{
					Value = 320151,
					Num = 1,
				},
				{
					Value = 1,
					Num = 910,
				},
			},
		},
		{
			Level = 3,
			UpgradeCostList = {
				{
					Value = 320151,
					Num = 1,
				},
				{
					Value = 1,
					Num = 2100,
				},
			},
		},
		{
			Level = 4,
			UpgradeCostList = {
				{
					Value = 320151,
					Num = 1,
				},
				{
					Value = 1,
					Num = 4400,
				},
			},
		},
		{
			Level = 5,
			UpgradeCostList = {
				{
					Value = 320151,
					Num = 1,
				},
				{
					Value = 1,
					Num = 7900,
				},
			},
		},
		{
			Level = 6,
			UpgradeCostList = {
				{
					Value = 320151,
					Num = 1,
				},
				{
					Value = 1,
					Num = 13400,
				},
			},
		},
		{
			Level = 7,
			UpgradeCostList = {
				{
					Value = 320151,
					Num = 1,
				},
				{
					Value = 1,
					Num = 20800,
				},
			},
		},
		{
			Level = 8,
			UpgradeCostList = {
				{
					Value = 320151,
					Num = 1,
				},
				{
					Value = 1,
					Num = 30300,
				},
			},
		},
		{
			Level = 9,
			UpgradeCostList = {
				{
					Value = 320151,
					Num = 1,
				},
				{
					Value = 1,
					Num = 42500,
				},
			},
		},
	},
}
EquipmentUpgradeConfig[EquipmentUpgradeID.Id119] =
{
	LevelList = {
		{
			Level = 1,
			UpgradeCostList = {
				{
					Value = 320151,
					Num = 1,
				},
				{
					Value = 1,
					Num = 1000,
				},
			},
		},
		{
			Level = 2,
			UpgradeCostList = {
				{
					Value = 320151,
					Num = 1,
				},
				{
					Value = 1,
					Num = 3300,
				},
			},
		},
		{
			Level = 3,
			UpgradeCostList = {
				{
					Value = 320151,
					Num = 1,
				},
				{
					Value = 1,
					Num = 8000,
				},
			},
		},
		{
			Level = 4,
			UpgradeCostList = {
				{
					Value = 320151,
					Num = 1,
				},
				{
					Value = 1,
					Num = 16600,
				},
			},
		},
		{
			Level = 5,
			UpgradeCostList = {
				{
					Value = 320151,
					Num = 1,
				},
				{
					Value = 1,
					Num = 29600,
				},
			},
		},
		{
			Level = 6,
			UpgradeCostList = {
				{
					Value = 320151,
					Num = 1,
				},
				{
					Value = 1,
					Num = 48400,
				},
			},
		},
		{
			Level = 7,
			UpgradeCostList = {
				{
					Value = 320151,
					Num = 1,
				},
				{
					Value = 1,
					Num = 73500,
				},
			},
		},
		{
			Level = 8,
			UpgradeCostList = {
				{
					Value = 320151,
					Num = 1,
				},
				{
					Value = 1,
					Num = 106000,
				},
			},
		},
		{
			Level = 9,
			UpgradeCostList = {
				{
					Value = 320151,
					Num = 1,
				},
				{
					Value = 1,
					Num = 147000,
				},
			},
		},
	},
}
EquipmentUpgradeConfig[EquipmentUpgradeID.Id120] =
{
	LevelList = {
		{
			Level = 1,
			UpgradeCostList = {
				{
					Value = 320151,
					Num = 1,
				},
				{
					Value = 1,
					Num = 2800,
				},
			},
		},
		{
			Level = 2,
			UpgradeCostList = {
				{
					Value = 320151,
					Num = 1,
				},
				{
					Value = 1,
					Num = 9200,
				},
			},
		},
		{
			Level = 3,
			UpgradeCostList = {
				{
					Value = 320151,
					Num = 1,
				},
				{
					Value = 1,
					Num = 22600,
				},
			},
		},
		{
			Level = 4,
			UpgradeCostList = {
				{
					Value = 320151,
					Num = 1,
				},
				{
					Value = 1,
					Num = 45100,
				},
			},
		},
		{
			Level = 5,
			UpgradeCostList = {
				{
					Value = 320151,
					Num = 1,
				},
				{
					Value = 1,
					Num = 79200,
				},
			},
		},
		{
			Level = 6,
			UpgradeCostList = {
				{
					Value = 320151,
					Num = 1,
				},
				{
					Value = 1,
					Num = 127000,
				},
			},
		},
		{
			Level = 7,
			UpgradeCostList = {
				{
					Value = 320151,
					Num = 1,
				},
				{
					Value = 1,
					Num = 192000,
				},
			},
		},
		{
			Level = 8,
			UpgradeCostList = {
				{
					Value = 320151,
					Num = 1,
				},
				{
					Value = 1,
					Num = 276000,
				},
			},
		},
		{
			Level = 9,
			UpgradeCostList = {
				{
					Value = 320151,
					Num = 1,
				},
				{
					Value = 1,
					Num = 381000,
				},
			},
		},
	},
}

