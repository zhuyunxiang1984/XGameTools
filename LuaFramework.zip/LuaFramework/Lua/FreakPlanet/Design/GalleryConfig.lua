GalleryConfig ={};
GalleryID = 
{
	Id001 = 950001,
	Id002 = 950002,
	Id003 = 950003,
	Id004 = 950004,
	Id005 = 950005,
	Id101 = 950101,
}
GalleryConfig[GalleryID.Id001] =
{
	Id = 1,
	PageText = "01",
	Name = "冒险星",
	Unlock = 120001,
	Icon = "RPG",
	CharacterIcon = "Gallery_RPG_CharacterIcon",
	PetIcon = "Gallery_RPG_PetIcon",
	EventIcon = "Gallery_RPG_EventIcon",
}
GalleryConfig[GalleryID.Id002] =
{
	Id = 2,
	PageText = "02",
	Name = "美食星",
	Unlock = 120002,
	Icon = "FAT",
	CharacterIcon = "Gallery_FAT_CharacterIcon",
	PetIcon = "Gallery_FAT_PetIcon",
	EventIcon = "Gallery_FAT_EventIcon",
}
GalleryConfig[GalleryID.Id003] =
{
	Id = 3,
	PageText = "03",
	Name = "博物馆星",
	Unlock = 120003,
	Icon = "MUS",
	CharacterIcon = "Gallery_MUS_CharacterIcon",
	PetIcon = "Gallery_MUS_PetIcon",
	EventIcon = "Gallery_MUS_EventIcon",
}
GalleryConfig[GalleryID.Id004] =
{
	Id = 4,
	PageText = "04",
	Name = "悬疑星",
	Unlock = 120004,
	Icon = "SUS",
	CharacterIcon = "Gallery_SUS_CharacterIcon",
	PetIcon = "Gallery_SUS_PetIcon",
	EventIcon = "Gallery_SUS_EventIcon",
}
GalleryConfig[GalleryID.Id005] =
{
	Id = 5,
	PageText = "05",
	Name = "海洋星",
	Unlock = 120005,
	Icon = "SEA",
	CharacterIcon = "Gallery_SEA_CharacterIcon",
	PetIcon = "Gallery_SEA_PetIcon",
	EventIcon = "Gallery_SEA_EventIcon",
}
GalleryConfig[GalleryID.Id101] =
{
	Id = 101,
	PageText = "??",
	Name = "星际流民",
	Icon = "PlanetGlobal01",
	CharacterIcon = "Gallery_GLOBAL_CharacterIcon",
	PetIcon = "Gallery_GLOBAL_PetIcon",
	EventIcon = "Gallery_GLOBAL_EventIcon",
}

