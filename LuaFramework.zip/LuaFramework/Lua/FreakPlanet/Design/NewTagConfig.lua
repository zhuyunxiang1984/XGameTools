NewTagConfig ={};
NewTagID = 
{
	Id230003 = 230003,
	Id230004 = 230004,
	Id230005 = 230005,
	Id230006 = 230006,
	Id230007 = 230007,
	Id230008 = 230008,
	Id230009 = 230009,
	Id230010 = 230010,
	Id230011 = 230011,
	Id230012 = 230012,
	Id230013 = 230013,
	Id230014 = 230014,
	Id230015 = 230015,
	Id230016 = 230016,
	Id230017 = 230017,
	Id230018 = 230018,
	Id230019 = 230019,
	Id230020 = 230020,
	Id230021 = 230021,
	Id230022 = 230022,
	Id230023 = 230023,
	Id230024 = 230024,
	Id230025 = 230025,
	Id230026 = 230026,
	Id230027 = 230027,
	Id230028 = 230028,
	Id230029 = 230029,
	Id230194 = 230194,
	Id230195 = 230195,
	Id230196 = 230196,
	Id230197 = 230197,
	Id230198 = 230198,
	Id230199 = 230199,
	Id230251 = 230251,
	Id230252 = 230252,
	Id231003 = 231003,
	Id231004 = 231004,
	Id231005 = 231005,
	Id231006 = 231006,
	Id231007 = 231007,
	Id231008 = 231008,
	Id231009 = 231009,
	Id231010 = 231010,
	Id231011 = 231011,
	Id231012 = 231012,
	Id231013 = 231013,
	Id231014 = 231014,
	Id231015 = 231015,
	Id231016 = 231016,
	Id231017 = 231017,
	Id231018 = 231018,
	Id231019 = 231019,
	Id231020 = 231020,
	Id231021 = 231021,
	Id231022 = 231022,
	Id231023 = 231023,
	Id231024 = 231024,
	Id231025 = 231025,
	Id231026 = 231026,
	Id231027 = 231027,
	Id231028 = 231028,
	Id231029 = 231029,
	Id231194 = 231194,
	Id231195 = 231195,
	Id231196 = 231196,
	Id231197 = 231197,
	Id231198 = 231198,
	Id231199 = 231199,
	Id231251 = 231251,
	Id231252 = 231252,
	Id232003 = 232003,
	Id232004 = 232004,
	Id232005 = 232005,
	Id232006 = 232006,
	Id232007 = 232007,
	Id232008 = 232008,
	Id232009 = 232009,
	Id232010 = 232010,
	Id232011 = 232011,
	Id232012 = 232012,
	Id232013 = 232013,
	Id232014 = 232014,
	Id232015 = 232015,
	Id232016 = 232016,
	Id232017 = 232017,
	Id232018 = 232018,
	Id232019 = 232019,
	Id232020 = 232020,
	Id232021 = 232021,
	Id232022 = 232022,
	Id232023 = 232023,
	Id232024 = 232024,
	Id232025 = 232025,
	Id232026 = 232026,
	Id232027 = 232027,
	Id232028 = 232028,
	Id232029 = 232029,
	Id232030 = 232030,
	Id232031 = 232031,
	Id232032 = 232032,
	Id232033 = 232033,
	Id232034 = 232034,
	Id232035 = 232035,
	Id232036 = 232036,
	Id232037 = 232037,
	Id232038 = 232038,
	Id232157 = 232157,
	Id232158 = 232158,
	Id232159 = 232159,
	Id232160 = 232160,
	Id232161 = 232161,
	Id232162 = 232162,
	Id232236 = 232236,
	Id232237 = 232237,
	Id232238 = 232238,
	Id230001 = 230001,
	Id230002 = 230002,
	Id231001 = 231001,
	Id231002 = 231002,
	Id232001 = 232001,
	Id232002 = 232002,
	Id250001 = 250001,
	Id250002 = 250002,
	Id250003 = 250003,
	Id250004 = 250004,
	Id250005 = 250005,
	Id250006 = 250006,
	Id250007 = 250007,
	Id250008 = 250008,
	Id250009 = 250009,
	Id250010 = 250010,
	Id250011 = 250011,
	Id250012 = 250012,
	Id250013 = 250013,
	Id250014 = 250014,
	Id250015 = 250015,
	Id250016 = 250016,
	Id250017 = 250017,
	Id250018 = 250018,
	Id250019 = 250019,
	Id250020 = 250020,
	Id250021 = 250021,
	Id250022 = 250022,
	Id250023 = 250023,
	Id250024 = 250024,
	Id250025 = 250025,
	Id250026 = 250026,
	Id250027 = 250027,
	Id250501 = 250501,
	Id250502 = 250502,
	Id250503 = 250503,
	Id250510 = 250510,
	Id250511 = 250511,
	Id251001 = 251001,
	Id251002 = 251002,
	Id251003 = 251003,
	Id320501 = 320501,
	Id320502 = 320502,
	Id320503 = 320503,
	Id320504 = 320504,
	Id320505 = 320505,
	Id320506 = 320506,
	Id320507 = 320507,
	Id320508 = 320508,
	Id320509 = 320509,
	Id320510 = 320510,
	Id320511 = 320511,
	Id320512 = 320512,
	Id320513 = 320513,
	Id320514 = 320514,
	Id320611 = 320611,
	Id321001 = 321001,
	Id321002 = 321002,
	Id321003 = 321003,
	Id321004 = 321004,
	Id321005 = 321005,
	Id321006 = 321006,
	Id321007 = 321007,
	Id321008 = 321008,
	Id321009 = 321009,
	Id321010 = 321010,
	Id321051 = 321051,
	Id321052 = 321052,
	Id321053 = 321053,
	Id321054 = 321054,
	Id327301 = 327301,
	Id327302 = 327302,
	Id880001 = 880001,
	Id880002 = 880002,
	Id880003 = 880003,
	Id880004 = 880004,
	Id880005 = 880005,
	Id880006 = 880006,
	Id880007 = 880007,
	Id880008 = 880008,
	Id880009 = 880009,
	Id880010 = 880010,
	Id880011 = 880011,
	Id880012 = 880012,
	Id880013 = 880013,
}
NewTagConfig[NewTagID.Id230003] =
{
	Id = 230003,
	ObjTags = {
		120001,
		566006,
		561702,
		566052,
		566106,
		566151,
		566202,
		210002,
		566251,
	},
	SubjTags = {
		{
			Id = 566303,
			Value = 150,
		},
	},
}
NewTagConfig[NewTagID.Id230004] =
{
	Id = 230004,
	ObjTags = {
		120001,
		566004,
		561703,
		566052,
		566105,
		566151,
		566203,
		210003,
		566251,
	},
	SubjTags = {
		{
			Id = 566303,
			Value = 50,
		},
		{
			Id = 566308,
			Value = 100,
		},
		{
			Id = 566313,
			Value = 40,
		},
	},
}
NewTagConfig[NewTagID.Id230005] =
{
	Id = 230005,
	ObjTags = {
		120001,
		566006,
		561702,
		566055,
		566103,
		566152,
		566202,
		210003,
		566252,
	},
	SubjTags = {
		{
			Id = 566304,
			Value = 100,
		},
	},
}
NewTagConfig[NewTagID.Id230006] =
{
	Id = 230006,
	ObjTags = {
		120001,
		566006,
		561702,
		566056,
		566101,
		566154,
		566203,
		210001,
		566253,
	},
	SubjTags = {
		{
			Id = 566304,
			Value = 220,
		},
	},
}
NewTagConfig[NewTagID.Id230007] =
{
	Id = 230007,
	ObjTags = {
		120001,
		566003,
		561702,
		566053,
		566104,
		566154,
		566201,
		210005,
		566253,
	},
	SubjTags = {
		{
			Id = 566305,
			Value = 100,
		},
		{
			Id = 566307,
			Value = 160,
		},
		{
			Id = 566313,
			Value = 50,
		},
	},
}
NewTagConfig[NewTagID.Id230008] =
{
	Id = 230008,
	ObjTags = {
		120001,
		566006,
		561703,
		566056,
		566103,
		566152,
		566201,
		210005,
		566254,
	},
	SubjTags = {
		{
			Id = 566305,
			Value = 80,
		},
		{
			Id = 566308,
			Value = 80,
		},
	},
}
NewTagConfig[NewTagID.Id230009] =
{
	Id = 230009,
	ObjTags = {
		120001,
		566006,
		561702,
		566056,
		566106,
		566151,
		566201,
		210001,
		566251,
	},
	SubjTags = {
		{
			Id = 566304,
			Value = 250,
		},
	},
}
NewTagConfig[NewTagID.Id230010] =
{
	Id = 230010,
	ObjTags = {
		120001,
		566006,
		561702,
		566056,
		566101,
		566151,
		566203,
		210002,
		566251,
	},
	SubjTags = {
		{
			Id = 566304,
			Value = 160,
		},
		{
			Id = 566310,
			Value = 120,
		},
	},
}
NewTagConfig[NewTagID.Id230011] =
{
	Id = 230011,
	ObjTags = {
		120001,
		566006,
		561703,
		566052,
		566101,
		566151,
		566203,
		210001,
		566252,
	},
	SubjTags = {
		{
			Id = 566304,
			Value = 180,
		},
		{
			Id = 566310,
			Value = 100,
		},
	},
}
NewTagConfig[NewTagID.Id230012] =
{
	Id = 230012,
	ObjTags = {
		120001,
		566001,
		561702,
		566054,
		566153,
		566203,
		210005,
		566251,
	},
	SubjTags = {
		{
			Id = 566302,
			Value = 200,
		},
	},
}
NewTagConfig[NewTagID.Id230013] =
{
	Id = 230013,
	ObjTags = {
		120001,
		566006,
		561702,
		566104,
		566151,
		566203,
		210004,
		566253,
	},
	SubjTags = {
		{
			Id = 566304,
			Value = 60,
		},
	},
}
NewTagConfig[NewTagID.Id230014] =
{
	Id = 230014,
	ObjTags = {
		120001,
		566007,
		561702,
		566152,
		566203,
		210005,
		566252,
	},
	SubjTags = {
		{
			Id = 566307,
			Value = 40,
		},
	},
}
NewTagConfig[NewTagID.Id230015] =
{
	Id = 230015,
	ObjTags = {
		120001,
		566006,
		561702,
		566056,
		566105,
		566151,
		566202,
		210001,
		566253,
	},
	SubjTags = {
		{
			Id = 566304,
			Value = 150,
		},
	},
}
NewTagConfig[NewTagID.Id230016] =
{
	Id = 230016,
	ObjTags = {
		120001,
		566006,
		561702,
		566106,
		566151,
		566203,
		210005,
		566251,
	},
	SubjTags = {
		{
			Id = 566309,
			Value = 150,
		},
	},
}
NewTagConfig[NewTagID.Id230017] =
{
	Id = 230017,
	ObjTags = {
		120001,
		566006,
		561702,
		566056,
		566106,
		566154,
		566203,
		210002,
		566253,
	},
	SubjTags = {
		{
			Id = 566304,
			Value = 140,
		},
	},
}
NewTagConfig[NewTagID.Id230018] =
{
	Id = 230018,
	ObjTags = {
		120001,
		566002,
		561702,
		566056,
		566102,
		566153,
		566203,
		210003,
		566253,
	},
	SubjTags = {
		{
			Id = 566304,
			Value = 150,
		},
		{
			Id = 566312,
			Value = 100,
		},
	},
}
NewTagConfig[NewTagID.Id230019] =
{
	Id = 230019,
	ObjTags = {
		120001,
		566006,
		561703,
		566051,
		566106,
		566151,
		566203,
		210003,
		566252,
	},
	SubjTags = {
		{
			Id = 566309,
			Value = 170,
		},
	},
}
NewTagConfig[NewTagID.Id230020] =
{
	Id = 230020,
	ObjTags = {
		120001,
		566006,
		561702,
		566056,
		566106,
		566151,
		566203,
		210002,
		566251,
	},
	SubjTags = {
		{
			Id = 566305,
			Value = 60,
		},
		{
			Id = 566303,
			Value = 110,
		},
	},
}
NewTagConfig[NewTagID.Id230021] =
{
	Id = 230021,
	ObjTags = {
		120001,
		566006,
		561702,
		566057,
		566101,
		566152,
		566203,
		210003,
		566251,
	},
	SubjTags = {
		{
			Id = 566301,
			Value = 200,
		},
		{
			Id = 566305,
			Value = 40,
		},
	},
}
NewTagConfig[NewTagID.Id230022] =
{
	Id = 230022,
	ObjTags = {
		120001,
		566006,
		561702,
		566054,
		566106,
		566154,
		566203,
		210005,
		566253,
	},
	SubjTags = {
		{
			Id = 566305,
			Value = 50,
		},
		{
			Id = 566302,
			Value = 120,
		},
		{
			Id = 566307,
			Value = 160,
		},
	},
}
NewTagConfig[NewTagID.Id230023] =
{
	Id = 230023,
	ObjTags = {
		120001,
		566006,
		561702,
		566052,
		566102,
		566151,
		566201,
		210003,
		566254,
	},
	SubjTags = {
		{
			Id = 566306,
			Value = 250,
		},
	},
}
NewTagConfig[NewTagID.Id230024] =
{
	Id = 230024,
	ObjTags = {
		120001,
		566006,
		561703,
		566057,
		566102,
		566151,
		566201,
		210003,
		566252,
	},
	SubjTags = {
		{
			Id = 566309,
			Value = 250,
		},
		{
			Id = 566308,
			Value = 150,
		},
	},
}
NewTagConfig[NewTagID.Id230025] =
{
	Id = 230025,
	ObjTags = {
		120001,
		566003,
		561702,
		566054,
		566103,
		566153,
		566203,
		210002,
		566254,
	},
	SubjTags = {
		{
			Id = 566305,
			Value = 300,
		},
		{
			Id = 566308,
			Value = 280,
		},
		{
			Id = 566313,
			Value = 280,
		},
		{
			Id = 566307,
			Value = 320,
		},
	},
}
NewTagConfig[NewTagID.Id230026] =
{
	Id = 230026,
	ObjTags = {
		120001,
		566006,
		561703,
		566056,
		566104,
		566152,
		566201,
		210004,
		566252,
	},
	SubjTags = {
		{
			Id = 566308,
			Value = 120,
		},
		{
			Id = 566311,
			Value = 220,
		},
	},
}
NewTagConfig[NewTagID.Id230027] =
{
	Id = 230027,
	ObjTags = {
		120001,
		566006,
		561703,
		566052,
		566103,
		566151,
		566202,
		210002,
		566253,
	},
	SubjTags = {
		{
			Id = 566305,
			Value = 160,
		},
		{
			Id = 566311,
			Value = 150,
		},
	},
}
NewTagConfig[NewTagID.Id230028] =
{
	Id = 230028,
	ObjTags = {
		120001,
		566005,
		561702,
		566054,
		566101,
		566153,
		566203,
		210005,
		566251,
	},
	SubjTags = {
		{
			Id = 566305,
			Value = 240,
		},
		{
			Id = 566308,
			Value = 230,
		},
		{
			Id = 566307,
			Value = 100,
		},
		{
			Id = 566313,
			Value = 120,
		},
	},
}
NewTagConfig[NewTagID.Id230029] =
{
	Id = 230029,
	ObjTags = {
		120001,
		566006,
		561703,
		566053,
		566106,
		566152,
		566201,
		210001,
		566252,
	},
	SubjTags = {
		{
			Id = 566305,
			Value = 200,
		},
		{
			Id = 566308,
			Value = 300,
		},
		{
			Id = 566313,
			Value = 280,
		},
	},
}
NewTagConfig[NewTagID.Id230194] =
{
	Id = 230194,
	ObjTags = {
		120001,
		566006,
		561702,
		566055,
		566104,
		566152,
		566202,
		210004,
		566253,
	},
	SubjTags = {
		{
			Id = 566305,
			Value = 180,
		},
		{
			Id = 566311,
			Value = 270,
		},
		{
			Id = 566313,
			Value = 150,
		},
	},
}
NewTagConfig[NewTagID.Id230195] =
{
	Id = 230195,
	ObjTags = {
		120001,
		566006,
		561702,
		566056,
		566106,
		566154,
		566203,
		210002,
		566253,
	},
	SubjTags = {
		{
			Id = 566305,
			Value = 100,
		},
	},
}
NewTagConfig[NewTagID.Id230196] =
{
	Id = 230196,
	ObjTags = {
		120001,
		566006,
		561702,
		566052,
		566102,
		566152,
		566203,
		210005,
		566251,
	},
	SubjTags = {
		{
			Id = 566301,
			Value = 250,
		},
	},
}
NewTagConfig[NewTagID.Id230197] =
{
	Id = 230197,
	ObjTags = {
		120001,
		566006,
		561703,
		566052,
		566103,
		566152,
		566201,
		210001,
		566251,
	},
	SubjTags = {
		{
			Id = 566308,
			Value = 270,
		},
	},
}
NewTagConfig[NewTagID.Id230198] =
{
	Id = 230198,
	ObjTags = {
		120001,
		566006,
		561702,
		566056,
		566105,
		566152,
		566201,
		210005,
		566254,
	},
	SubjTags = {
		{
			Id = 566306,
			Value = 260,
		},
	},
}
NewTagConfig[NewTagID.Id230199] =
{
	Id = 230199,
	ObjTags = {
		120001,
		566006,
		561702,
		566057,
		566105,
		566152,
		566201,
		210003,
		566252,
	},
	SubjTags = {
		{
			Id = 566306,
			Value = 150,
		},
	},
}
NewTagConfig[NewTagID.Id230251] =
{
	Id = 230251,
	ObjTags = {
		120001,
		566003,
		561702,
		566054,
		566101,
		566153,
		566201,
		210001,
		566254,
	},
	SubjTags = {
		{
			Id = 566306,
			Value = 170,
		},
		{
			Id = 566307,
			Value = 200,
		},
	},
}
NewTagConfig[NewTagID.Id230252] =
{
	Id = 230252,
	ObjTags = {
		120001,
		566004,
		561703,
		566052,
		566105,
		566152,
		566203,
		210003,
		566252,
	},
	SubjTags = {
		{
			Id = 566306,
			Value = 190,
		},
		{
			Id = 566308,
			Value = 210,
		},
		{
			Id = 566311,
			Value = 240,
		},
	},
}
NewTagConfig[NewTagID.Id231003] =
{
	Id = 231003,
	ObjTags = {
		120001,
		566006,
		561702,
		566052,
		566106,
		566151,
		566202,
		210002,
		566251,
	},
	SubjTags = {
		{
			Id = 566303,
			Value = 210,
		},
	},
}
NewTagConfig[NewTagID.Id231004] =
{
	Id = 231004,
	ObjTags = {
		120001,
		566004,
		561703,
		566053,
		566105,
		566151,
		566203,
		210003,
		566251,
	},
	SubjTags = {
		{
			Id = 566303,
			Value = 110,
		},
		{
			Id = 566308,
			Value = 160,
		},
		{
			Id = 566313,
			Value = 100,
		},
	},
}
NewTagConfig[NewTagID.Id231005] =
{
	Id = 231005,
	ObjTags = {
		120001,
		566006,
		561702,
		566055,
		566103,
		566151,
		566202,
		210003,
		566252,
	},
	SubjTags = {
		{
			Id = 566304,
			Value = 160,
		},
	},
}
NewTagConfig[NewTagID.Id231006] =
{
	Id = 231006,
	ObjTags = {
		120001,
		566006,
		561702,
		566056,
		566101,
		566154,
		566203,
		210001,
		566253,
	},
	SubjTags = {
		{
			Id = 566304,
			Value = 280,
		},
	},
}
NewTagConfig[NewTagID.Id231007] =
{
	Id = 231007,
	ObjTags = {
		120001,
		566003,
		561702,
		566054,
		566104,
		566154,
		566203,
		210005,
		566253,
	},
	SubjTags = {
		{
			Id = 566305,
			Value = 160,
		},
		{
			Id = 566307,
			Value = 220,
		},
		{
			Id = 566313,
			Value = 110,
		},
	},
}
NewTagConfig[NewTagID.Id231008] =
{
	Id = 231008,
	ObjTags = {
		120001,
		566006,
		561703,
		566056,
		566103,
		566152,
		566201,
		210005,
		566254,
	},
	SubjTags = {
		{
			Id = 566305,
			Value = 140,
		},
		{
			Id = 566308,
			Value = 140,
		},
	},
}
NewTagConfig[NewTagID.Id231009] =
{
	Id = 231009,
	ObjTags = {
		120001,
		566006,
		561702,
		566056,
		566106,
		566151,
		566203,
		210001,
		566251,
	},
	SubjTags = {
		{
			Id = 566304,
			Value = 310,
		},
	},
}
NewTagConfig[NewTagID.Id231010] =
{
	Id = 231010,
	ObjTags = {
		120001,
		566006,
		561702,
		566056,
		566101,
		566151,
		566203,
		210002,
		566254,
	},
	SubjTags = {
		{
			Id = 566304,
			Value = 220,
		},
		{
			Id = 566310,
			Value = 180,
		},
	},
}
NewTagConfig[NewTagID.Id231011] =
{
	Id = 231011,
	ObjTags = {
		120001,
		566006,
		561703,
		566052,
		566101,
		566151,
		566203,
		210001,
		566252,
	},
	SubjTags = {
		{
			Id = 566304,
			Value = 240,
		},
		{
			Id = 566310,
			Value = 160,
		},
	},
}
NewTagConfig[NewTagID.Id231012] =
{
	Id = 231012,
	ObjTags = {
		120001,
		566001,
		561702,
		566054,
		566153,
		566203,
		210005,
		566251,
	},
	SubjTags = {
		{
			Id = 566302,
			Value = 260,
		},
	},
}
NewTagConfig[NewTagID.Id231013] =
{
	Id = 231013,
	ObjTags = {
		120001,
		566006,
		561702,
		566104,
		566152,
		566201,
		210004,
		566253,
	},
	SubjTags = {
		{
			Id = 566304,
			Value = 120,
		},
	},
}
NewTagConfig[NewTagID.Id231014] =
{
	Id = 231014,
	ObjTags = {
		120001,
		566007,
		561702,
		566152,
		566203,
		210005,
		566252,
	},
	SubjTags = {
		{
			Id = 566307,
			Value = 100,
		},
	},
}
NewTagConfig[NewTagID.Id231015] =
{
	Id = 231015,
	ObjTags = {
		120001,
		566006,
		561702,
		566055,
		566102,
		566151,
		566202,
		210001,
		566253,
	},
	SubjTags = {
		{
			Id = 566304,
			Value = 210,
		},
	},
}
NewTagConfig[NewTagID.Id231016] =
{
	Id = 231016,
	ObjTags = {
		120001,
		566006,
		561702,
		566052,
		566106,
		566151,
		566201,
		210005,
		566251,
	},
	SubjTags = {
		{
			Id = 566309,
			Value = 210,
		},
	},
}
NewTagConfig[NewTagID.Id231017] =
{
	Id = 231017,
	ObjTags = {
		120001,
		566006,
		561702,
		566056,
		566101,
		566154,
		566203,
		210002,
		566253,
	},
	SubjTags = {
		{
			Id = 566304,
			Value = 200,
		},
	},
}
NewTagConfig[NewTagID.Id231018] =
{
	Id = 231018,
	ObjTags = {
		120001,
		566002,
		561702,
		566056,
		566106,
		566153,
		566203,
		210003,
		566253,
	},
	SubjTags = {
		{
			Id = 566304,
			Value = 210,
		},
		{
			Id = 566312,
			Value = 160,
		},
	},
}
NewTagConfig[NewTagID.Id231019] =
{
	Id = 231019,
	ObjTags = {
		120001,
		566006,
		561703,
		566051,
		566106,
		566152,
		566201,
		210003,
		566252,
	},
	SubjTags = {
		{
			Id = 566309,
			Value = 230,
		},
	},
}
NewTagConfig[NewTagID.Id231020] =
{
	Id = 231020,
	ObjTags = {
		120001,
		566006,
		561702,
		566056,
		566106,
		566152,
		566203,
		210002,
		566251,
	},
	SubjTags = {
		{
			Id = 566305,
			Value = 120,
		},
		{
			Id = 566303,
			Value = 170,
		},
	},
}
NewTagConfig[NewTagID.Id231021] =
{
	Id = 231021,
	ObjTags = {
		120001,
		566006,
		561702,
		566057,
		566101,
		566152,
		566203,
		210003,
		566251,
	},
	SubjTags = {
		{
			Id = 566301,
			Value = 260,
		},
		{
			Id = 566305,
			Value = 100,
		},
	},
}
NewTagConfig[NewTagID.Id231022] =
{
	Id = 231022,
	ObjTags = {
		120001,
		566003,
		561702,
		566054,
		566106,
		566154,
		566203,
		210005,
		566253,
	},
	SubjTags = {
		{
			Id = 566305,
			Value = 110,
		},
		{
			Id = 566302,
			Value = 180,
		},
		{
			Id = 566307,
			Value = 220,
		},
	},
}
NewTagConfig[NewTagID.Id231023] =
{
	Id = 231023,
	ObjTags = {
		120001,
		566006,
		561702,
		566051,
		566102,
		566151,
		566201,
		210003,
		566254,
	},
	SubjTags = {
		{
			Id = 566306,
			Value = 310,
		},
	},
}
NewTagConfig[NewTagID.Id231024] =
{
	Id = 231024,
	ObjTags = {
		120001,
		566006,
		561703,
		566056,
		566102,
		566152,
		566201,
		210003,
		566252,
	},
	SubjTags = {
		{
			Id = 566309,
			Value = 310,
		},
		{
			Id = 566308,
			Value = 210,
		},
	},
}
NewTagConfig[NewTagID.Id231025] =
{
	Id = 231025,
	ObjTags = {
		120001,
		566003,
		561702,
		566054,
		566103,
		566153,
		566203,
		210002,
		566254,
	},
	SubjTags = {
		{
			Id = 566305,
			Value = 360,
		},
		{
			Id = 566308,
			Value = 340,
		},
		{
			Id = 566313,
			Value = 340,
		},
		{
			Id = 566307,
			Value = 380,
		},
	},
}
NewTagConfig[NewTagID.Id231026] =
{
	Id = 231026,
	ObjTags = {
		120001,
		566006,
		561703,
		566104,
		566152,
		566201,
		210004,
		566252,
	},
	SubjTags = {
		{
			Id = 566308,
			Value = 180,
		},
		{
			Id = 566311,
			Value = 280,
		},
	},
}
NewTagConfig[NewTagID.Id231027] =
{
	Id = 231027,
	ObjTags = {
		120001,
		566006,
		561703,
		566103,
		566151,
		566202,
		210002,
		566253,
	},
	SubjTags = {
		{
			Id = 566305,
			Value = 220,
		},
		{
			Id = 566311,
			Value = 210,
		},
	},
}
NewTagConfig[NewTagID.Id231028] =
{
	Id = 231028,
	ObjTags = {
		120001,
		566005,
		561702,
		566054,
		566101,
		566153,
		566203,
		210005,
		566251,
	},
	SubjTags = {
		{
			Id = 566305,
			Value = 300,
		},
		{
			Id = 566308,
			Value = 290,
		},
		{
			Id = 566307,
			Value = 160,
		},
		{
			Id = 566313,
			Value = 180,
		},
	},
}
NewTagConfig[NewTagID.Id231029] =
{
	Id = 231029,
	ObjTags = {
		120001,
		566006,
		561703,
		566053,
		566106,
		566152,
		566201,
		210001,
		566252,
	},
	SubjTags = {
		{
			Id = 566305,
			Value = 260,
		},
		{
			Id = 566308,
			Value = 360,
		},
		{
			Id = 566313,
			Value = 340,
		},
	},
}
NewTagConfig[NewTagID.Id231194] =
{
	Id = 231194,
	ObjTags = {
		120001,
		566006,
		561702,
		566055,
		566104,
		566152,
		566202,
		210004,
		566253,
	},
	SubjTags = {
		{
			Id = 566305,
			Value = 240,
		},
		{
			Id = 566311,
			Value = 330,
		},
		{
			Id = 566313,
			Value = 210,
		},
	},
}
NewTagConfig[NewTagID.Id231195] =
{
	Id = 231195,
	ObjTags = {
		120001,
		566006,
		561702,
		566056,
		566102,
		566151,
		566203,
		210002,
		566253,
	},
	SubjTags = {
		{
			Id = 566305,
			Value = 160,
		},
	},
}
NewTagConfig[NewTagID.Id231196] =
{
	Id = 231196,
	ObjTags = {
		120001,
		566006,
		561702,
		566052,
		566102,
		566152,
		566203,
		210005,
		566251,
	},
	SubjTags = {
		{
			Id = 566301,
			Value = 310,
		},
	},
}
NewTagConfig[NewTagID.Id231197] =
{
	Id = 231197,
	ObjTags = {
		120001,
		566006,
		561703,
		566057,
		566103,
		566152,
		566201,
		210001,
		566251,
	},
	SubjTags = {
		{
			Id = 566308,
			Value = 330,
		},
	},
}
NewTagConfig[NewTagID.Id231198] =
{
	Id = 231198,
	ObjTags = {
		120001,
		566006,
		561702,
		566056,
		566105,
		566152,
		566201,
		210005,
		566254,
	},
	SubjTags = {
		{
			Id = 566306,
			Value = 320,
		},
	},
}
NewTagConfig[NewTagID.Id231199] =
{
	Id = 231199,
	ObjTags = {
		120001,
		566006,
		561702,
		566056,
		566105,
		566152,
		566201,
		210003,
		566252,
	},
	SubjTags = {
		{
			Id = 566306,
			Value = 210,
		},
	},
}
NewTagConfig[NewTagID.Id231251] =
{
	Id = 231251,
	ObjTags = {
		120001,
		566007,
		561702,
		566054,
		566101,
		566153,
		566201,
		210001,
		566254,
	},
	SubjTags = {
		{
			Id = 566306,
			Value = 230,
		},
		{
			Id = 566307,
			Value = 260,
		},
	},
}
NewTagConfig[NewTagID.Id231252] =
{
	Id = 231252,
	ObjTags = {
		120001,
		566004,
		561703,
		566054,
		566105,
		566152,
		566201,
		210003,
		566252,
	},
	SubjTags = {
		{
			Id = 566306,
			Value = 250,
		},
		{
			Id = 566308,
			Value = 270,
		},
		{
			Id = 566311,
			Value = 300,
		},
	},
}
NewTagConfig[NewTagID.Id232003] =
{
	Id = 232003,
	ObjTags = {
		120001,
		566006,
		561702,
		566056,
		566102,
		566151,
		566203,
		210002,
		566251,
	},
	SubjTags = {
		{
			Id = 566303,
			Value = 220,
		},
		{
			Id = 566305,
			Value = 260,
		},
		{
			Id = 566313,
			Value = 300,
		},
	},
}
NewTagConfig[NewTagID.Id232004] =
{
	Id = 232004,
	ObjTags = {
		120001,
		566004,
		561703,
		566052,
		566105,
		566151,
		566203,
		210003,
		566251,
	},
	SubjTags = {
		{
			Id = 566303,
			Value = 210,
		},
		{
			Id = 566308,
			Value = 250,
		},
		{
			Id = 566313,
			Value = 180,
		},
	},
}
NewTagConfig[NewTagID.Id232005] =
{
	Id = 232005,
	ObjTags = {
		120001,
		566006,
		561702,
		566101,
		566151,
		566203,
		210003,
		566252,
	},
	SubjTags = {
		{
			Id = 566305,
			Value = 350,
		},
	},
}
NewTagConfig[NewTagID.Id232006] =
{
	Id = 232006,
	ObjTags = {
		120001,
		566007,
		561702,
		566053,
		566153,
		566202,
		210005,
		566252,
	},
	SubjTags = {
		{
			Id = 566305,
			Value = 290,
		},
		{
			Id = 566307,
			Value = 280,
		},
		{
			Id = 566313,
			Value = 310,
		},
	},
}
NewTagConfig[NewTagID.Id232007] =
{
	Id = 232007,
	ObjTags = {
		120001,
		566006,
		561702,
		566056,
		566102,
		566154,
		566203,
		210001,
		566253,
	},
	SubjTags = {
		{
			Id = 566304,
			Value = 210,
		},
	},
}
NewTagConfig[NewTagID.Id232008] =
{
	Id = 232008,
	ObjTags = {
		120001,
		566006,
		561702,
		566056,
		566102,
		566154,
		566203,
		210002,
		566253,
	},
	SubjTags = {
		{
			Id = 566304,
			Value = 210,
		},
	},
}
NewTagConfig[NewTagID.Id232009] =
{
	Id = 232009,
	ObjTags = {
		120001,
		566003,
		561702,
		566054,
		566104,
		566154,
		566203,
		210005,
		566253,
	},
	SubjTags = {
		{
			Id = 566305,
			Value = 180,
		},
		{
			Id = 566307,
			Value = 250,
		},
		{
			Id = 566313,
			Value = 210,
		},
	},
}
NewTagConfig[NewTagID.Id232010] =
{
	Id = 232010,
	ObjTags = {
		120001,
		566003,
		561702,
		566054,
		566103,
		566154,
		566203,
		210005,
		566253,
	},
	SubjTags = {
		{
			Id = 566305,
			Value = 240,
		},
		{
			Id = 566307,
			Value = 270,
		},
		{
			Id = 566313,
			Value = 170,
		},
	},
}
NewTagConfig[NewTagID.Id232011] =
{
	Id = 232011,
	ObjTags = {
		120001,
		566006,
		561703,
		566056,
		566104,
		566152,
		566201,
		210005,
		566254,
	},
	SubjTags = {
		{
			Id = 566305,
			Value = 140,
		},
		{
			Id = 566308,
			Value = 210,
		},
	},
}
NewTagConfig[NewTagID.Id232012] =
{
	Id = 232012,
	ObjTags = {
		120001,
		566006,
		561702,
		566052,
		566106,
		566151,
		566203,
		210001,
		566251,
	},
	SubjTags = {
		{
			Id = 566304,
			Value = 140,
		},
		{
			Id = 566312,
			Value = 300,
		},
	},
}
NewTagConfig[NewTagID.Id232013] =
{
	Id = 232013,
	ObjTags = {
		120001,
		566006,
		561702,
		566056,
		566101,
		566151,
		566201,
		210002,
		566251,
	},
	SubjTags = {
		{
			Id = 566304,
			Value = 120,
		},
		{
			Id = 566305,
			Value = 80,
		},
		{
			Id = 566310,
			Value = 130,
		},
	},
}
NewTagConfig[NewTagID.Id232014] =
{
	Id = 232014,
	ObjTags = {
		120001,
		566006,
		561703,
		566056,
		566104,
		566151,
		566203,
		210001,
		566252,
	},
	SubjTags = {
		{
			Id = 566304,
			Value = 160,
		},
	},
}
NewTagConfig[NewTagID.Id232015] =
{
	Id = 232015,
	ObjTags = {
		120001,
		566006,
		561702,
		566055,
		566102,
		566151,
		566202,
		210001,
		566253,
	},
	SubjTags = {
		{
			Id = 566305,
			Value = 120,
		},
	},
}
NewTagConfig[NewTagID.Id232016] =
{
	Id = 232016,
	ObjTags = {
		120001,
		566002,
		561702,
		566056,
		566106,
		566154,
		566203,
		210003,
		566253,
	},
	SubjTags = {
		{
			Id = 566304,
			Value = 110,
		},
	},
}
NewTagConfig[NewTagID.Id232017] =
{
	Id = 232017,
	ObjTags = {
		120001,
		566003,
		561702,
		566054,
		566105,
		566153,
		566203,
		210005,
		566253,
	},
	SubjTags = {
		{
			Id = 566302,
			Value = 130,
		},
		{
			Id = 566305,
			Value = 110,
		},
		{
			Id = 566307,
			Value = 70,
		},
	},
}
NewTagConfig[NewTagID.Id232018] =
{
	Id = 232018,
	ObjTags = {
		120001,
		566006,
		561702,
		566102,
		566152,
		566201,
		210004,
		566253,
	},
	SubjTags = {
		{
			Id = 566304,
			Value = 48,
		},
	},
}
NewTagConfig[NewTagID.Id232019] =
{
	Id = 232019,
	ObjTags = {
		120001,
		566001,
		561702,
		566153,
		566203,
		210005,
		566251,
	},
	SubjTags = {
		{
			Id = 566302,
			Value = 230,
		},
		{
			Id = 566307,
			Value = 210,
		},
	},
}
NewTagConfig[NewTagID.Id232020] =
{
	Id = 232020,
	ObjTags = {
		120001,
		566006,
		561702,
		566056,
		566106,
		566151,
		566203,
		210002,
		566251,
	},
	SubjTags = {
		{
			Id = 566305,
			Value = 120,
		},
		{
			Id = 566303,
			Value = 170,
		},
	},
}
NewTagConfig[NewTagID.Id232021] =
{
	Id = 232021,
	ObjTags = {
		120001,
		566006,
		561702,
		566057,
		566105,
		566152,
		566203,
		210003,
		566251,
	},
	SubjTags = {
		{
			Id = 566301,
			Value = 260,
		},
		{
			Id = 566305,
			Value = 30,
		},
	},
}
NewTagConfig[NewTagID.Id232022] =
{
	Id = 232022,
	ObjTags = {
		120001,
		566006,
		561702,
		566057,
		566102,
		566152,
		566203,
		210003,
		566251,
	},
	SubjTags = {
		{
			Id = 566305,
			Value = 110,
		},
		{
			Id = 566301,
			Value = 320,
		},
	},
}
NewTagConfig[NewTagID.Id232023] =
{
	Id = 232023,
	ObjTags = {
		120001,
		566006,
		561703,
		566054,
		566102,
		566152,
		566201,
		210004,
		566252,
	},
	SubjTags = {
		{
			Id = 566308,
			Value = 180,
		},
	},
}
NewTagConfig[NewTagID.Id232024] =
{
	Id = 232024,
	ObjTags = {
		120001,
		566006,
		561703,
		566056,
		566103,
		566152,
		566201,
		210004,
		566252,
	},
	SubjTags = {
		{
			Id = 566308,
			Value = 220,
		},
	},
}
NewTagConfig[NewTagID.Id232025] =
{
	Id = 232025,
	ObjTags = {
		120001,
		566006,
		561702,
		566052,
		566103,
		566151,
		566203,
		210005,
		566251,
	},
	SubjTags = {
		{
			Id = 566309,
			Value = 250,
		},
	},
}
NewTagConfig[NewTagID.Id232026] =
{
	Id = 232026,
	ObjTags = {
		120001,
		566006,
		561703,
		566102,
		566152,
		566203,
		210003,
		566252,
	},
	SubjTags = {
		{
			Id = 566308,
			Value = 290,
		},
	},
}
NewTagConfig[NewTagID.Id232027] =
{
	Id = 232027,
	ObjTags = {
		120001,
		566006,
		561702,
		566051,
		566106,
		566151,
		566201,
		210003,
		566254,
	},
	SubjTags = {
		{
			Id = 566306,
			Value = 260,
		},
		{
			Id = 566311,
			Value = 210,
		},
	},
}
NewTagConfig[NewTagID.Id232028] =
{
	Id = 232028,
	ObjTags = {
		120001,
		566006,
		561703,
		566056,
		566101,
		566152,
		566201,
		210003,
		566252,
	},
	SubjTags = {
		{
			Id = 566308,
			Value = 290,
		},
		{
			Id = 566303,
			Value = 140,
		},
	},
}
NewTagConfig[NewTagID.Id232029] =
{
	Id = 232029,
	ObjTags = {
		120001,
		566006,
		561703,
		566055,
		566102,
		566151,
		566202,
		210002,
		566253,
	},
	SubjTags = {
		{
			Id = 566305,
			Value = 260,
		},
		{
			Id = 566308,
			Value = 110,
		},
		{
			Id = 566313,
			Value = 180,
		},
	},
}
NewTagConfig[NewTagID.Id232030] =
{
	Id = 232030,
	ObjTags = {
		120001,
		566006,
		561702,
		566054,
		566101,
		566151,
		566202,
		210002,
		566253,
	},
	SubjTags = {
		{
			Id = 566305,
			Value = 260,
		},
		{
			Id = 566308,
			Value = 160,
		},
		{
			Id = 566313,
			Value = 220,
		},
	},
}
NewTagConfig[NewTagID.Id232031] =
{
	Id = 232031,
	ObjTags = {
		120001,
		566005,
		561702,
		566054,
		566103,
		566151,
		566203,
		210005,
		566251,
	},
	SubjTags = {
		{
			Id = 566305,
			Value = 250,
		},
		{
			Id = 566308,
			Value = 210,
		},
		{
			Id = 566313,
			Value = 300,
		},
	},
}
NewTagConfig[NewTagID.Id232032] =
{
	Id = 232032,
	ObjTags = {
		120001,
		566005,
		561702,
		566054,
		566101,
		566151,
		566203,
		210005,
		566251,
	},
	SubjTags = {
		{
			Id = 566305,
			Value = 280,
		},
		{
			Id = 566308,
			Value = 230,
		},
		{
			Id = 566313,
			Value = 310,
		},
	},
}
NewTagConfig[NewTagID.Id232033] =
{
	Id = 232033,
	ObjTags = {
		120001,
		566006,
		561703,
		566053,
		566102,
		566152,
		566201,
		210001,
		566252,
	},
	SubjTags = {
		{
			Id = 566305,
			Value = 240,
		},
		{
			Id = 566308,
			Value = 370,
		},
		{
			Id = 566313,
			Value = 320,
		},
	},
}
NewTagConfig[NewTagID.Id232034] =
{
	Id = 232034,
	ObjTags = {
		120001,
		566006,
		561703,
		566053,
		566102,
		566152,
		566201,
		210001,
		566252,
	},
	SubjTags = {
		{
			Id = 566305,
			Value = 245,
		},
		{
			Id = 566308,
			Value = 375,
		},
		{
			Id = 566313,
			Value = 325,
		},
	},
}
NewTagConfig[NewTagID.Id232035] =
{
	Id = 232035,
	ObjTags = {
		120001,
		566006,
		561703,
		566053,
		566101,
		566152,
		566201,
		210001,
		566252,
	},
	SubjTags = {
		{
			Id = 566305,
			Value = 210,
		},
		{
			Id = 566308,
			Value = 410,
		},
		{
			Id = 566313,
			Value = 340,
		},
	},
}
NewTagConfig[NewTagID.Id232036] =
{
	Id = 232036,
	ObjTags = {
		120001,
		566003,
		561703,
		566053,
		566102,
		566153,
		566203,
		210002,
		566254,
	},
	SubjTags = {
		{
			Id = 566305,
			Value = 320,
		},
		{
			Id = 566308,
			Value = 390,
		},
		{
			Id = 566313,
			Value = 330,
		},
		{
			Id = 566307,
			Value = 390,
		},
	},
}
NewTagConfig[NewTagID.Id232037] =
{
	Id = 232037,
	ObjTags = {
		120001,
		566003,
		561702,
		566053,
		566101,
		566153,
		566202,
		210002,
		566254,
	},
	SubjTags = {
		{
			Id = 566305,
			Value = 390,
		},
		{
			Id = 566308,
			Value = 350,
		},
		{
			Id = 566313,
			Value = 290,
		},
		{
			Id = 566307,
			Value = 350,
		},
	},
}
NewTagConfig[NewTagID.Id232038] =
{
	Id = 232038,
	ObjTags = {
		120001,
		566003,
		561702,
		566054,
		566105,
		566153,
		566203,
		210002,
		566254,
	},
	SubjTags = {
		{
			Id = 566305,
			Value = 350,
		},
		{
			Id = 566308,
			Value = 360,
		},
		{
			Id = 566313,
			Value = 310,
		},
		{
			Id = 566307,
			Value = 360,
		},
	},
}
NewTagConfig[NewTagID.Id232157] =
{
	Id = 232157,
	ObjTags = {
		120001,
		566007,
		561702,
		566055,
		566101,
		566152,
		566202,
		210004,
		566253,
	},
	SubjTags = {
		{
			Id = 566305,
			Value = 280,
		},
		{
			Id = 566307,
			Value = 310,
		},
		{
			Id = 566313,
			Value = 270,
		},
	},
}
NewTagConfig[NewTagID.Id232158] =
{
	Id = 232158,
	ObjTags = {
		120001,
		566006,
		561702,
		566056,
		566102,
		566154,
		566203,
		210002,
		566253,
	},
	SubjTags = {
		{
			Id = 566305,
			Value = 150,
		},
	},
}
NewTagConfig[NewTagID.Id232159] =
{
	Id = 232159,
	ObjTags = {
		120001,
		566006,
		561702,
		566056,
		566105,
		566152,
		566203,
		210005,
		566251,
	},
	SubjTags = {
		{
			Id = 566309,
			Value = 280,
		},
	},
}
NewTagConfig[NewTagID.Id232160] =
{
	Id = 232160,
	ObjTags = {
		120001,
		566006,
		561703,
		566052,
		566103,
		566152,
		566201,
		210001,
		566251,
	},
	SubjTags = {
		{
			Id = 566309,
			Value = 180,
		},
		{
			Id = 566308,
			Value = 290,
		},
	},
}
NewTagConfig[NewTagID.Id232161] =
{
	Id = 232161,
	ObjTags = {
		120001,
		566007,
		561702,
		566056,
		566101,
		566152,
		566201,
		210005,
		566254,
	},
	SubjTags = {
		{
			Id = 566305,
		},
		{
			Id = 566307,
			Value = 290,
		},
		{
			Id = 566306,
			Value = 280,
		},
	},
}
NewTagConfig[NewTagID.Id232162] =
{
	Id = 232162,
	ObjTags = {
		120001,
		566006,
		561702,
		566057,
		566106,
		566152,
		566201,
		210003,
		566252,
	},
	SubjTags = {
		{
			Id = 566306,
			Value = 240,
		},
	},
}
NewTagConfig[NewTagID.Id232236] =
{
	Id = 232236,
	ObjTags = {
		120001,
		566006,
		561702,
		566056,
		566102,
		566151,
		566203,
		210002,
		566251,
	},
	SubjTags = {
		{
			Id = 566305,
			Value = 79,
		},
	},
}
NewTagConfig[NewTagID.Id232237] =
{
	Id = 232237,
	ObjTags = {
		120001,
		566003,
		561702,
		566057,
		566103,
		566152,
		566201,
		210001,
		566254,
	},
	SubjTags = {
		{
			Id = 566305,
			Value = 220,
		},
		{
			Id = 566307,
			Value = 210,
		},
		{
			Id = 566306,
			Value = 260,
		},
	},
}
NewTagConfig[NewTagID.Id232238] =
{
	Id = 232238,
	ObjTags = {
		120001,
		566004,
		561703,
		566056,
		566105,
		566152,
		566203,
		210003,
		566252,
	},
	SubjTags = {
		{
			Id = 566306,
			Value = 260,
		},
		{
			Id = 566308,
			Value = 230,
		},
		{
			Id = 566311,
			Value = 320,
		},
	},
}
NewTagConfig[NewTagID.Id230001] =
{
	Id = 230001,
}
NewTagConfig[NewTagID.Id230002] =
{
	Id = 230002,
}
NewTagConfig[NewTagID.Id231001] =
{
	Id = 231001,
}
NewTagConfig[NewTagID.Id231002] =
{
	Id = 231002,
}
NewTagConfig[NewTagID.Id232001] =
{
	Id = 232001,
}
NewTagConfig[NewTagID.Id232002] =
{
	Id = 232002,
}
NewTagConfig[NewTagID.Id250001] =
{
	Id = 250001,
	ObjTags = {
		120001,
	},
	SubjTags = {
		{
			Id = 566502,
			Value = 20,
		},
	},
}
NewTagConfig[NewTagID.Id250002] =
{
	Id = 250002,
	ObjTags = {
		120001,
	},
	SubjTags = {
		{
			Id = 566502,
			Value = 30,
		},
	},
}
NewTagConfig[NewTagID.Id250003] =
{
	Id = 250003,
	ObjTags = {
		120001,
	},
	SubjTags = {
		{
			Id = 566502,
			Value = 40,
		},
	},
}
NewTagConfig[NewTagID.Id250004] =
{
	Id = 250004,
	ObjTags = {
		120001,
	},
	SubjTags = {
		{
			Id = 566502,
			Value = 50,
		},
	},
}
NewTagConfig[NewTagID.Id250005] =
{
	Id = 250005,
	ObjTags = {
		120001,
	},
	SubjTags = {
		{
			Id = 566502,
			Value = 10,
		},
	},
}
NewTagConfig[NewTagID.Id250006] =
{
	Id = 250006,
	ObjTags = {
		120001,
	},
	SubjTags = {
		{
			Id = 566502,
			Value = 15,
		},
	},
}
NewTagConfig[NewTagID.Id250007] =
{
	Id = 250007,
	ObjTags = {
		120001,
	},
	SubjTags = {
		{
			Id = 566502,
			Value = 75,
		},
	},
}
NewTagConfig[NewTagID.Id250008] =
{
	Id = 250008,
	ObjTags = {
		120001,
	},
	SubjTags = {
		{
			Id = 566502,
			Value = 88,
		},
		{
			Id = 566501,
			Value = 23,
		},
	},
}
NewTagConfig[NewTagID.Id250009] =
{
	Id = 250009,
	ObjTags = {
		120001,
	},
	SubjTags = {
		{
			Id = 566502,
			Value = 120,
		},
		{
			Id = 566501,
			Value = 101,
		},
	},
}
NewTagConfig[NewTagID.Id250010] =
{
	Id = 250010,
	ObjTags = {
		120001,
	},
	SubjTags = {
		{
			Id = 566502,
			Value = 260,
		},
		{
			Id = 566501,
			Value = 148,
		},
	},
}
NewTagConfig[NewTagID.Id250011] =
{
	Id = 250011,
	ObjTags = {
		120001,
	},
	SubjTags = {
		{
			Id = 566502,
			Value = 5,
		},
	},
}
NewTagConfig[NewTagID.Id250012] =
{
	Id = 250012,
	ObjTags = {
		120001,
	},
	SubjTags = {
		{
			Id = 566502,
			Value = 34,
		},
	},
}
NewTagConfig[NewTagID.Id250013] =
{
	Id = 250013,
	ObjTags = {
		120001,
	},
	SubjTags = {
		{
			Id = 566502,
			Value = 250,
		},
		{
			Id = 566501,
			Value = 60,
		},
	},
}
NewTagConfig[NewTagID.Id250014] =
{
	Id = 250014,
	ObjTags = {
		120001,
	},
	SubjTags = {
		{
			Id = 566502,
			Value = 2,
		},
	},
}
NewTagConfig[NewTagID.Id250015] =
{
	Id = 250015,
	ObjTags = {
		120001,
	},
	SubjTags = {
		{
			Id = 566502,
			Value = 12,
		},
	},
}
NewTagConfig[NewTagID.Id250016] =
{
	Id = 250016,
	ObjTags = {
		120001,
	},
	SubjTags = {
		{
			Id = 566502,
			Value = 11,
		},
	},
}
NewTagConfig[NewTagID.Id250017] =
{
	Id = 250017,
	ObjTags = {
		120001,
	},
	SubjTags = {
		{
			Id = 566502,
			Value = 20,
		},
	},
}
NewTagConfig[NewTagID.Id250018] =
{
	Id = 250018,
	ObjTags = {
		120001,
	},
	SubjTags = {
		{
			Id = 566502,
			Value = 160,
		},
	},
}
NewTagConfig[NewTagID.Id250019] =
{
	Id = 250019,
	ObjTags = {
		120001,
	},
	SubjTags = {
		{
			Id = 566502,
			Value = 22,
		},
	},
}
NewTagConfig[NewTagID.Id250020] =
{
	Id = 250020,
	ObjTags = {
		120001,
	},
	SubjTags = {
		{
			Id = 566502,
			Value = 88,
		},
		{
			Id = 566501,
			Value = 56,
		},
	},
}
NewTagConfig[NewTagID.Id250021] =
{
	Id = 250021,
	ObjTags = {
		120001,
	},
	SubjTags = {
		{
			Id = 566502,
			Value = 45,
		},
	},
}
NewTagConfig[NewTagID.Id250022] =
{
	Id = 250022,
	ObjTags = {
		120001,
	},
	SubjTags = {
		{
			Id = 566502,
			Value = 55,
		},
	},
}
NewTagConfig[NewTagID.Id250023] =
{
	Id = 250023,
	ObjTags = {
		120001,
	},
	SubjTags = {
		{
			Id = 566502,
			Value = 65,
		},
	},
}
NewTagConfig[NewTagID.Id250024] =
{
	Id = 250024,
	ObjTags = {
		120001,
	},
	SubjTags = {
		{
			Id = 566502,
			Value = 86,
		},
	},
}
NewTagConfig[NewTagID.Id250025] =
{
	Id = 250025,
	ObjTags = {
		120001,
	},
	SubjTags = {
		{
			Id = 566502,
			Value = 123,
		},
	},
}
NewTagConfig[NewTagID.Id250026] =
{
	Id = 250026,
	ObjTags = {
		120001,
	},
	SubjTags = {
		{
			Id = 566502,
			Value = 140,
		},
	},
}
NewTagConfig[NewTagID.Id250027] =
{
	Id = 250027,
	ObjTags = {
		120001,
	},
	SubjTags = {
		{
			Id = 566502,
			Value = 280,
		},
		{
			Id = 566501,
			Value = 77,
		},
	},
}
NewTagConfig[NewTagID.Id250501] =
{
	Id = 250501,
	ObjTags = {
		120001,
	},
	SubjTags = {
		{
			Id = 566502,
			Value = 5,
		},
	},
}
NewTagConfig[NewTagID.Id250502] =
{
	Id = 250502,
	ObjTags = {
		120001,
	},
	SubjTags = {
		{
			Id = 566502,
			Value = 25,
		},
	},
}
NewTagConfig[NewTagID.Id250503] =
{
	Id = 250503,
	ObjTags = {
		120001,
	},
	SubjTags = {
		{
			Id = 566502,
			Value = 45,
		},
	},
}
NewTagConfig[NewTagID.Id250510] =
{
	Id = 250510,
	ObjTags = {
		120001,
	},
	SubjTags = {
		{
			Id = 566502,
			Value = 23,
		},
	},
}
NewTagConfig[NewTagID.Id250511] =
{
	Id = 250511,
	ObjTags = {
		120001,
	},
	SubjTags = {
		{
			Id = 566502,
			Value = 57,
		},
	},
}
NewTagConfig[NewTagID.Id251001] =
{
	Id = 251001,
	ObjTags = {
		120001,
	},
	SubjTags = {
		{
			Id = 566502,
			Value = 180,
		},
		{
			Id = 566501,
			Value = 150,
		},
	},
}
NewTagConfig[NewTagID.Id251002] =
{
	Id = 251002,
	ObjTags = {
		120001,
	},
	SubjTags = {
		{
			Id = 566502,
			Value = 140,
		},
	},
}
NewTagConfig[NewTagID.Id251003] =
{
	Id = 251003,
	ObjTags = {
		120001,
	},
	SubjTags = {
		{
			Id = 566502,
			Value = 210,
		},
	},
}
NewTagConfig[NewTagID.Id320501] =
{
	Id = 320501,
	ObjTags = {
		120001,
	},
}
NewTagConfig[NewTagID.Id320502] =
{
	Id = 320502,
	ObjTags = {
		120001,
	},
	SubjTags = {
		{
			Id = 566401,
			Value = 300,
		},
		{
			Id = 566402,
			Value = 300,
		},
	},
}
NewTagConfig[NewTagID.Id320503] =
{
	Id = 320503,
	ObjTags = {
		120001,
	},
	SubjTags = {
		{
			Id = 566402,
			Value = 120,
		},
	},
}
NewTagConfig[NewTagID.Id320504] =
{
	Id = 320504,
	ObjTags = {
		120001,
	},
	SubjTags = {
		{
			Id = 566402,
			Value = 80,
		},
	},
}
NewTagConfig[NewTagID.Id320505] =
{
	Id = 320505,
	ObjTags = {
		120001,
	},
}
NewTagConfig[NewTagID.Id320506] =
{
	Id = 320506,
	ObjTags = {
		120001,
	},
	SubjTags = {
		{
			Id = 566402,
			Value = 270,
		},
	},
}
NewTagConfig[NewTagID.Id320507] =
{
	Id = 320507,
	ObjTags = {
		120001,
	},
	SubjTags = {
		{
			Id = 566402,
			Value = 180,
		},
	},
}
NewTagConfig[NewTagID.Id320508] =
{
	Id = 320508,
	ObjTags = {
		120001,
	},
	SubjTags = {
		{
			Id = 566402,
			Value = 310,
		},
	},
}
NewTagConfig[NewTagID.Id320509] =
{
	Id = 320509,
	ObjTags = {
		120001,
	},
	SubjTags = {
		{
			Id = 566402,
			Value = 88,
		},
	},
}
NewTagConfig[NewTagID.Id320510] =
{
	Id = 320510,
	ObjTags = {
		120001,
	},
}
NewTagConfig[NewTagID.Id320511] =
{
	Id = 320511,
	ObjTags = {
		120001,
	},
}
NewTagConfig[NewTagID.Id320512] =
{
	Id = 320512,
	ObjTags = {
		120001,
	},
}
NewTagConfig[NewTagID.Id320513] =
{
	Id = 320513,
	ObjTags = {
		120001,
	},
	SubjTags = {
		{
			Id = 566402,
			Value = 90,
		},
	},
}
NewTagConfig[NewTagID.Id320514] =
{
	Id = 320514,
	ObjTags = {
		120001,
	},
	SubjTags = {
		{
			Id = 566401,
			Value = 180,
		},
		{
			Id = 566402,
			Value = 150,
		},
	},
}
NewTagConfig[NewTagID.Id320611] =
{
	Id = 320611,
	ObjTags = {
		120001,
	},
	SubjTags = {
		{
			Id = 566401,
			Value = 260,
		},
		{
			Id = 566402,
			Value = 270,
		},
	},
}
NewTagConfig[NewTagID.Id321001] =
{
	Id = 321001,
	ObjTags = {
		120001,
	},
}
NewTagConfig[NewTagID.Id321002] =
{
	Id = 321002,
	ObjTags = {
		120001,
	},
	SubjTags = {
		{
			Id = 566401,
			Value = 50,
		},
		{
			Id = 566402,
			Value = 180,
		},
	},
}
NewTagConfig[NewTagID.Id321003] =
{
	Id = 321003,
	ObjTags = {
		120001,
	},
	SubjTags = {
		{
			Id = 566401,
			Value = 100,
		},
		{
			Id = 566402,
			Value = 220,
		},
	},
}
NewTagConfig[NewTagID.Id321004] =
{
	Id = 321004,
	ObjTags = {
		120001,
	},
	SubjTags = {
		{
			Id = 566401,
			Value = 220,
		},
		{
			Id = 566402,
			Value = 270,
		},
	},
}
NewTagConfig[NewTagID.Id321005] =
{
	Id = 321005,
	ObjTags = {
		120001,
	},
}
NewTagConfig[NewTagID.Id321006] =
{
	Id = 321006,
	ObjTags = {
		120001,
	},
}
NewTagConfig[NewTagID.Id321007] =
{
	Id = 321007,
	ObjTags = {
		120001,
	},
	SubjTags = {
		{
			Id = 566402,
			Value = 450,
		},
		{
			Id = 566401,
			Value = 260,
		},
	},
}
NewTagConfig[NewTagID.Id321008] =
{
	Id = 321008,
	ObjTags = {
		120001,
	},
}
NewTagConfig[NewTagID.Id321009] =
{
	Id = 321009,
	ObjTags = {
		120001,
	},
	SubjTags = {
		{
			Id = 566401,
			Value = 220,
		},
		{
			Id = 566402,
			Value = 170,
		},
	},
}
NewTagConfig[NewTagID.Id321010] =
{
	Id = 321010,
	ObjTags = {
		120001,
	},
	SubjTags = {
		{
			Id = 566401,
			Value = 280,
		},
		{
			Id = 566402,
			Value = 110,
		},
	},
}
NewTagConfig[NewTagID.Id321051] =
{
	Id = 321051,
	ObjTags = {
		120001,
	},
	SubjTags = {
		{
			Id = 566401,
			Value = 220,
		},
		{
			Id = 566402,
			Value = 240,
		},
	},
}
NewTagConfig[NewTagID.Id321052] =
{
	Id = 321052,
	ObjTags = {
		120001,
	},
}
NewTagConfig[NewTagID.Id321053] =
{
	Id = 321053,
	ObjTags = {
		120001,
	},
	SubjTags = {
		{
			Id = 566402,
			Value = 50,
		},
	},
}
NewTagConfig[NewTagID.Id321054] =
{
	Id = 321054,
	ObjTags = {
		120001,
	},
}
NewTagConfig[NewTagID.Id327301] =
{
	Id = 327301,
	ObjTags = {
		120001,
	},
}
NewTagConfig[NewTagID.Id327302] =
{
	Id = 327302,
	ObjTags = {
		120001,
	},
}
NewTagConfig[NewTagID.Id880001] =
{
	Id = 880001,
	ObjTags = {
		566601,
	},
}
NewTagConfig[NewTagID.Id880002] =
{
	Id = 880002,
	ObjTags = {
		566601,
		566651,
	},
}
NewTagConfig[NewTagID.Id880003] =
{
	Id = 880003,
	ObjTags = {
		566601,
	},
}
NewTagConfig[NewTagID.Id880004] =
{
	Id = 880004,
	ObjTags = {
		566601,
	},
}
NewTagConfig[NewTagID.Id880005] =
{
	Id = 880005,
	ObjTags = {
		566602,
	},
}
NewTagConfig[NewTagID.Id880006] =
{
	Id = 880006,
	ObjTags = {
		566602,
		566652,
	},
}
NewTagConfig[NewTagID.Id880007] =
{
	Id = 880007,
	ObjTags = {
		566602,
		566653,
	},
}
NewTagConfig[NewTagID.Id880008] =
{
	Id = 880008,
	ObjTags = {
		566603,
	},
}
NewTagConfig[NewTagID.Id880009] =
{
	Id = 880009,
	ObjTags = {
		566603,
		566654,
	},
}
NewTagConfig[NewTagID.Id880010] =
{
	Id = 880010,
	ObjTags = {
		566603,
		566655,
	},
}
NewTagConfig[NewTagID.Id880011] =
{
	Id = 880011,
	ObjTags = {
		566604,
	},
}
NewTagConfig[NewTagID.Id880012] =
{
	Id = 880012,
	ObjTags = {
		566604,
		566751,
	},
}
NewTagConfig[NewTagID.Id880013] =
{
	Id = 880013,
	ObjTags = {
		566604,
		566752,
	},
}
