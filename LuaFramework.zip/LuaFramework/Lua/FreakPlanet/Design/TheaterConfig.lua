TheaterConfig ={};
TheaterID = 
{
	Id001 = 890001,
	Id002 = 890002,
}
TheaterConfig[TheaterID.Id001] =
{
	Id = 1,
	Name = "《哈姆雷特王子》第一幕",
	Desc = "王子哈姆雷特在外游历期间，听闻父亲噩耗，连夜骑马赶回城堡。然而，等待王子的不是父亲的葬礼，而是叔叔的登基大典，以及他与母后的婚礼。不知情的王子刚进入会场，立马就被缴械包围，幸好路过的谜之高手和他的宠物及时相助，才能逃脱。谜之高手护送王子到郊外，不料却撞见一位对王子大喊儿子的老者。原来这位老者就是老国王，他并没有死，而是被新国王和皇后下了魔药。知晓真相的哈姆雷特极为震惊，决心要为父亲报仇。",
	SelectTags = {
		566101,
		566056,
		566251,
		566055,
		566202,
		561702,
		561703,
		566053,
		566054,
		566102,
		566201,
		566253,
		566254,
		566203,
	},
	Actors = {
		{
			Name = "哈姆雷特",
			Desc = "没有主角光环的王子，人生充满坎坷。善用轻武器发挥战斗技巧，特别痴迷于一顶滑稽的绿帽子。",
			BestIds = {
				{
					Id = 232003,
					Score = 3900,
				},
				{
					Id = 232236,
					Score = 2000,
				},
			},
			ObjTags = {
				{
					Id = 561702,
					Score = 800,
				},
				{
					Id = 561703,
					Score = -800,
				},
				{
					Id = 200005,
					Score = 1800,
				},
				{
					Id = 566056,
					Score = 600,
				},
			},
			SubjTags = {
				{
					Id = 566313,
					Score = {
						{
							Section = 180,
							Factor = 50,
						},
						{
							Section = 280,
							Factor = 100,
						},
						{
							Section = 320,
							Factor = 200,
						},
					},
				},
				{
					Id = 566305,
					Score = {
						{
							Section = 50,
							Factor = 50,
						},
						{
							Section = 100,
							Factor = 60,
						},
						{
							Section = 160,
							Factor = 70,
						},
						{
							Section = 220,
							Factor = 80,
						},
					},
				},
				{
					Id = 566304,
					Score = {
						{
							Section = 80,
							Factor = -30,
						},
						{
							Section = 160,
							Factor = -50,
						},
						{
							Section = 200,
							Factor = -100,
						},
						{
							Section = 250,
							Factor = -200,
						},
					},
				},
				{
					Id = 566301,
					Score = {
						{
							Section = 50,
							Factor = -30,
						},
						{
							Section = 100,
							Factor = -50,
						},
						{
							Section = 200,
							Factor = -80,
						},
						{
							Section = 280,
							Factor = -100,
						},
					},
				},
			},
		},
		{
			Name = "老国王",
			Desc = "老国王，哈姆雷特的父亲。喝下魔药之后变成了白发苍苍的老者，一眼看上去挺像大魔法师的。",
			BestIds = {
				{
					Id = 231010,
					Score = 4500,
				},
				{
					Id = 230010,
					Score = 2000,
				},
			},
			ObjTags = {
				{
					Id = 561702,
					Score = 800,
				},
				{
					Id = 561703,
					Score = -800,
				},
				{
					Id = 566101,
					Score = 800,
				},
			},
			SubjTags = {
				{
					Id = 566310,
					Score = {
						{
							Section = 50,
							Factor = 50,
						},
						{
							Section = 120,
							Factor = 100,
						},
						{
							Section = 260,
							Factor = 400,
						},
					},
				},
				{
					Id = 566306,
					Score = {
						{
							Section = 50,
							Factor = 100,
						},
						{
							Section = 120,
							Factor = 150,
						},
						{
							Section = 220,
							Factor = 300,
						},
					},
				},
			},
		},
		{
			Name = "叔叔",
			Desc = "老国王的兄弟，曾害死自己的哥哥，夜夜害怕鬼魂索命，因此全身都武装着盔甲。",
			BestIds = {
				{
					Id = 232157,
					Score = 3300,
				},
			},
			ObjTags = {
				{
					Id = 561702,
					Score = 800,
				},
				{
					Id = 561703,
					Score = -800,
				},
				{
					Id = 566055,
					Score = 700,
				},
				{
					Id = 566202,
					Score = 700,
				},
			},
			SubjTags = {
				{
					Id = 566313,
					Score = {
						{
							Section = 120,
							Factor = 50,
						},
						{
							Section = 280,
							Factor = 100,
						},
					},
				},
				{
					Id = 566307,
					Score = {
						{
							Section = 50,
							Factor = 100,
						},
						{
							Section = 160,
							Factor = 100,
						},
						{
							Section = 220,
							Factor = 300,
						},
					},
				},
				{
					Id = 566305,
					Score = {
						{
							Section = 50,
							Factor = 20,
						},
						{
							Section = 120,
							Factor = 50,
						},
						{
							Section = 160,
							Factor = 60,
						},
						{
							Section = 280,
							Factor = 120,
						},
					},
				},
			},
		},
		{
			Name = "皇后",
			Desc = "拥有倾城美貌的皇后，心狠手辣，据说在城堡后院养了一条小花蛇。",
			BestIds = {
				{
					Id = 232036,
					Score = 3100,
				},
				{
					Id = 232033,
					Score = 2000,
				},
			},
			ObjTags = {
				{
					Id = 561703,
					Score = 800,
				},
				{
					Id = 561702,
					Score = -800,
				},
				{
					Id = 566053,
					Score = 1200,
				},
			},
			SubjTags = {
				{
					Id = 566313,
					Score = {
						{
							Section = 180,
							Factor = 50,
						},
						{
							Section = 280,
							Factor = 100,
						},
						{
							Section = 320,
							Factor = 400,
						},
					},
				},
				{
					Id = 566307,
					Score = {
						{
							Section = 50,
							Factor = 50,
						},
						{
							Section = 150,
							Factor = 200,
						},
						{
							Section = 300,
							Factor = 400,
						},
					},
				},
				{
					Id = 566308,
					Score = {
						{
							Section = 150,
							Factor = 100,
						},
						{
							Section = 210,
							Factor = 200,
						},
						{
							Section = 270,
							Factor = 400,
						},
						{
							Section = 300,
							Factor = 600,
						},
					},
				},
			},
		},
		{
			Name = "谜之高手",
			Desc = "武艺高强的中年男子，有着一头飘逸的白发。刚输了牌心情很差，于是顺手把卫兵打跑了。",
			BestIds = {
				{
					Id = 232005,
					Score = 4600,
				},
			},
			ObjTags = {
				{
					Id = 561702,
					Score = 800,
				},
				{
					Id = 561703,
					Score = -800,
				},
				{
					Id = 566101,
					Score = 800,
				},
			},
			SubjTags = {
				{
					Id = 566305,
					Score = {
						{
							Section = 50,
							Factor = 100,
						},
						{
							Section = 120,
							Factor = 200,
						},
						{
							Section = 160,
							Factor = 220,
						},
						{
							Section = 280,
							Factor = 400,
						},
					},
				},
			},
		},
	},
	Items = {
		{
			Name = "投掷利器",
			Desc = "坚硬且体积小的物体，随地可见，情急之下用于投掷。",
			SubjTags = {
				{
					Id = 566401,
					Score = {
						{
							Section = 50,
							Factor = 10,
						},
						{
							Section = 100,
							Factor = 50,
						},
						{
							Section = 160,
							Factor = 80,
						},
						{
							Section = 220,
							Factor = 100,
						},
					},
				},
				{
					Id = 566402,
					Score = {
						{
							Section = 50,
							Factor = 10,
						},
						{
							Section = 100,
							Factor = 50,
						},
						{
							Section = 160,
							Factor = 80,
						},
						{
							Section = 220,
							Factor = 100,
						},
					},
				},
			},
		},
	},
	Pets = {
		{
			Name = "能打的宠物",
			Desc = "谜之高手的宠物，凶狠善战，霸气侧露。",
			SubjTags = {
				{
					Id = 566502,
					Score = {
						{
							Section = 70,
							Factor = 10,
						},
						{
							Section = 140,
							Factor = 250,
						},
						{
							Section = 220,
							Factor = 400,
						},
					},
				},
				{
					Id = 566501,
					Score = {
						{
							Section = 100,
							Factor = 50,
						},
						{
							Section = 160,
							Factor = 150,
						},
						{
							Section = 200,
							Factor = 300,
						},
					},
				},
			},
		},
	},
	Sceneries = {
	},
	Conditions = {
	},
	Dialogs  = {
	},
}
TheaterConfig[TheaterID.Id002] =
{
	Id = 2,
	Name = "《阿力霸霸与一个大盗》",
	Desc = "出身穷苦的阿力霸霸，是个名副其实的手艺人，无意中发现了藏匿在右下角落中，四周都被杂草遮挡住的秘密基地，并靠“芝麻开门”的语音解锁成功。阿力霸霸从秘密基地中运出了许多珍贵的食物和饮品，让自己的生活渐渐好了起来，但却引来哥哥卡西姆的注意。哥哥逼问出了基地地址和语音密码，在其中大快朵颐时，却忘记了出来的暗号，最终被牛角大盗发现……",
	SelectTags = {
		561702,
		561703,
		566154,
		566153,
		566103,
		566101,
		566104,
		566054,
		566052,
		566056,
		566201,
		566203,
	},
	Actors = {
		{
			Name = "阿力霸霸",
			Desc = "出身穷苦的快乐青年，皮肤黝黑，穿着一身破皮衣裳。带哥哥来到秘密基地后，被哥哥勒令离开，但因为担心哥哥的安危，于是躲在杂草旁，暗中观察一切。",
			BestIds = {
				{
					Id = 230017,
					Score = 1200,
				},
			},
			ObjTags = {
				{
					Id = 561702,
					Score = 300,
				},
				{
					Id = 561703,
					Score = -300,
				},
				{
					Id = 566154,
					Score = 400,
				},
				{
					Id = 566203,
					Score = 600,
				},
			},
			SubjTags = {
				{
					Id = 566304,
					Score = {
						{
							Section = 100,
							Factor = 100,
						},
						{
							Section = 120,
							Factor = 200,
						},
						{
							Section = 999,
							Factor = 100,
						},
					},
				},
			},
		},
		{
			Name = "阿力的妻子",
			Desc = "善良美丽的女人，能歌善舞，常常赤脚行走，向上天祈祷自己的丈夫平安健康。丈夫被大哥叫走后，只能和嫂子一起在家等待。或许是因为因为距离丈夫太远，总是惴惴不安。",
			BestIds = {
				{
					Id = 230197,
					Score = 1000,
				},
			},
			ObjTags = {
				{
					Id = 561703,
					Score = 300,
				},
				{
					Id = 561702,
					Score = -300,
				},
				{
					Id = 566103,
					Score = 300,
				},
			},
			SubjTags = {
				{
					Id = 566308,
					Score = {
						{
							Section = 150,
							Factor = 100,
						},
						{
							Section = 250,
							Factor = 200,
						},
						{
							Section = 999,
							Factor = 200,
						},
					},
				},
			},
		},
		{
			Name = "牛角大盗",
			Desc = "把宝贝隐藏在秘密基地中的人，长着尖尖的角，据本人所说，这些宝贝是村民送给TA的礼物。在秘密基地不远处的大树下休息，听到其中传出奇怪的声音……",
			BestIds = {
				{
					Id = 232023,
					Score = 2500,
				},
			},
			ObjTags = {
				{
					Id = 561703,
					Score = 300,
				},
				{
					Id = 561702,
					Score = -300,
				},
				{
					Id = 566054,
					Score = 800,
				},
			},
		},
		{
			Name = "卡西姆",
			Desc = "阿力霸霸的哥哥，为了寻得秘密基地中的宝物，准备好了七匹马，和大大的包裹前往目的地。现在正在秘密基地里，把所有的食物和财宝往包裹里装，而那只马儿，正在草丛边旁等待着他呢。",
			BestIds = {
				{
					Id = 232012,
					Score = 1500,
				},
			},
			ObjTags = {
				{
					Id = 561702,
					Score = 300,
				},
				{
					Id = 561703,
					Score = -300,
				},
				{
					Id = 566052,
					Score = 300,
				},
			},
			SubjTags = {
				{
					Id = 566312,
					Score = {
						{
							Section = 100,
							Factor = 100,
						},
						{
							Section = 300,
							Factor = 200,
						},
						{
							Section = 999,
							Factor = 200,
						},
					},
				},
			},
		},
		{
			Name = "卡西姆的妻子",
			Desc = "精明的女人，对于家务事非常上心，精通各种生活和打扫的小技巧，通过计谋，知晓了他们的秘密。现在和阿力霸霸的妻子一起，踩在房屋前的地毯上来回踱步，家里等待丈夫的归来。",
			BestIds = {
				{
					Id = 232014,
					Score = 1300,
				},
			},
			ObjTags = {
				{
					Id = 561703,
					Score = 300,
				},
				{
					Id = 561702,
					Score = -300,
				},
				{
					Id = 566104,
					Score = 300,
				},
				{
					Id = 566056,
					Score = 200,
				},
			},
			SubjTags = {
				{
					Id = 566304,
					Score = {
						{
							Section = 100,
							Factor = 100,
						},
						{
							Section = 160,
							Factor = 200,
						},
						{
							Section = 999,
							Factor = 100,
						},
					},
				},
			},
		},
	},
	Items = {
	},
	Pets = {
	},
	Sceneries = {
		{
			Name = "杂草",
			ObjTags = {
				{
					Id = 566601,
					Score = 1000,
				},
				{
					Id = 566651,
					Score = 500,
				},
			},
		},
		{
			Name = "巨大的树",
			ObjTags = {
				{
					Id = 566602,
					Score = 1000,
				},
				{
					Id = 566652,
					Score = 500,
				},
			},
		},
		{
			Name = "驮马",
			ObjTags = {
				{
					Id = 566604,
					Score = 1000,
				},
				{
					Id = 566752,
					Score = 500,
				},
			},
		},
		{
			Name = "干净的地毯",
			ObjTags = {
				{
					Id = 566603,
					Score = 1000,
				},
				{
					Id = 566654,
					Score = 500,
				},
			},
		},
	},
	Conditions = {
		{
			BaseScore = 600,
			ConditionType = 1,
			SelfType = 1,
			SelfIndex = 4,
			SelfMinX = 1,
			SelfMaxX = 3,
			SelfMinY = 1,
			SelfMaxY = 3,
			FaceDirection = 0,
		},
		{
			BaseScore = 600,
			ConditionType = 2,
			SelfType = 1,
			SelfIndex = 4,
			DistanceMin = 1,
			DistanceMax = 2,
			SelfFaceType = 0,
			TargetFaceType = 0,
			Position = "0,0,0,0,0,0",
			TargetType = 4,
			TargetIndex = 1,
			TagBonusScore = 100,
			NumMin = 8,
			NumMax = 12,
			NumError = 300,
		},
		{
			BaseScore = 600,
			ConditionType = 2,
			SelfType = 1,
			SelfIndex = 4,
			DistanceMin = 2,
			DistanceMax = 3,
			SelfFaceType = 0,
			TargetFaceType = 0,
			Position = "0,0,0,0,0,0",
			TargetType = 4,
			TargetIndex = 3,
			TagBonusScore = 600,
			NumMin = 1,
			NumMax = 1,
			NumError = 300,
		},
		{
			BaseScore = 600,
			ConditionType = 2,
			SelfType = 1,
			SelfIndex = 3,
			DistanceMin = 1,
			DistanceMax = 1,
			SelfFaceType = 0,
			TargetFaceType = 0,
			Position = "0,0,0,0,0,0",
			TargetType = 4,
			TargetIndex = 2,
			TagBonusScore = 600,
			NumMin = 1,
			NumMax = 1,
			NumError = 300,
		},
		{
			BaseScore = 600,
			ConditionType = 2,
			SelfType = 1,
			SelfIndex = 3,
			DistanceMin = 4,
			DistanceMax = 5,
			SelfFaceType = 0,
			TargetFaceType = 0,
			Position = "0,0,0,0,0,0",
			TargetType = 1,
			TargetIndex = 4,
			TagBonusScore = 600,
			NumMin = 1,
			NumMax = 1,
			NumError = 300,
		},
		{
			BaseScore = 600,
			ConditionType = 2,
			SelfType = 1,
			SelfIndex = 2,
			DistanceMin = 7,
			DistanceMax = 99,
			SelfFaceType = 0,
			TargetFaceType = 0,
			Position = "0,0,0,0,0,0",
			TargetType = 1,
			TargetIndex = 1,
			TagBonusScore = 600,
			NumMin = 1,
			NumMax = 1,
			NumError = 300,
		},
		{
			BaseScore = 600,
			ConditionType = 2,
			SelfType = 1,
			SelfIndex = 5,
			DistanceMin = 1,
			DistanceMax = 1,
			SelfFaceType = 0,
			TargetFaceType = 0,
			Position = "0,0,0,0,0,0",
			TargetType = 1,
			TargetIndex = 2,
			TagBonusScore = 300,
			NumMin = 1,
			NumMax = 1,
			NumError = 300,
		},
		{
			BaseScore = 600,
			ConditionType = 2,
			SelfType = 1,
			SelfIndex = 5,
			DistanceMin = 0,
			DistanceMax = 0,
			SelfFaceType = 0,
			TargetFaceType = 0,
			Position = "0,0,0,0,1,0",
			TargetType = 4,
			TargetIndex = 4,
			TagBonusScore = 400,
			NumMin = 1,
			NumMax = 1,
			NumError = 300,
		},
		{
			BaseScore = 600,
			ConditionType = 2,
			SelfType = 1,
			SelfIndex = 1,
			DistanceMin = 2,
			DistanceMax = 3,
			SelfFaceType = 0,
			TargetFaceType = 0,
			Position = "0,0,0,0,0,0",
			TargetType = 1,
			TargetIndex = 4,
			TagBonusScore = 600,
			NumMin = 1,
			NumMax = 1,
			NumError = 300,
		},
		{
			BaseScore = 600,
			ConditionType = 2,
			SelfType = 1,
			SelfIndex = 1,
			DistanceMin = 1,
			DistanceMax = 1,
			SelfFaceType = 0,
			TargetFaceType = 0,
			Position = "0,0,0,0,0,0",
			TargetType = 4,
			TargetIndex = 1,
			TagBonusScore = 600,
			NumMin = 1,
			NumMax = 99,
			NumError = 300,
		},
	},
	Dialogs  = {
		{
			Type = 1,
			Index = 4,
			Content = {
				{
					Section = 2000,
					Text = "……开头说啥来着？哦哦，这是秘密基地？",
				},
				{
					Section = 3200,
					Text = "到了？",
				},
				{
					Section = 99999,
					Text = "哦，我可爱的老弟，这就是你说的秘密基地？",
				},
			},
		},
		{
			Type = 1,
			Index = 1,
			Content = {
				{
					Section = 1500,
					Text = "是的。",
				},
				{
					Section = 3100,
					Text = "是的，哥哥，我这就输入语音密码。",
				},
				{
					Section = 99999,
					Text = "是的，哥哥，虽然它看起来破旧而普通，但我相信，你很快就会大吃一惊。",
				},
			},
		},
		{
			Type = 1,
			Index = 1,
			Content = {
				{
					Section = 1500,
					Text = "芝麻开门——",
				},
				{
					Section = 3100,
					Text = "芝麻开门——",
				},
				{
					Section = 99999,
					Text = "芝麻开门——",
				},
			},
		},
		{
			Type = 1,
			Index = 4,
			Content = {
				{
					Section = 2000,
					Text = "那个……哎呀，我又忘词了。",
				},
				{
					Section = 3200,
					Text = "好家伙，里面果真别有洞天！",
				},
				{
					Section = 99999,
					Text = "唔，果真是语音控制的，你这小子，还真没骗你哥哥。",
				},
			},
		},
		{
			Type = 1,
			Index = 1,
			Content = {
				{
					Section = 1500,
					Text = "……我也忘了。",
				},
				{
					Section = 3100,
					Text = "……",
				},
				{
					Section = 99999,
					Text = "哥哥，我绝对不会欺骗您的。",
				},
			},
		},
		{
			Type = 1,
			Index = 4,
			Content = {
				{
					Section = 2000,
					Text = "哦对，我马呢？",
				},
				{
					Section = 3200,
					Text = "好了，马在外面吧？",
				},
				{
					Section = 99999,
					Text = "我的小马儿，在外边拴得好好的吧？",
				},
			},
		},
		{
			Type = 1,
			Index = 1,
			Content = {
				{
					Section = 1500,
					Text = "你马没丢。",
				},
				{
					Section = 3100,
					Text = "是的哥哥，你马在呢。",
				},
				{
					Section = 99999,
					Text = "是啊，它正在开心地吃草哩！",
				},
			},
		},
		{
			Type = 1,
			Index = 4,
			Content = {
				{
					Section = 2000,
					Text = "哦，那你走吧。",
				},
				{
					Section = 3200,
					Text = "那没你事儿了，回去吧。",
				},
				{
					Section = 99999,
					Text = "哈，它将驮着我搜寻的宝贝，带领我走向另一条富裕之路……不过，我想你可以回去了。",
				},
			},
		},
		{
			Type = 1,
			Index = 1,
			Content = {
				{
					Section = 1500,
					Text = "1234567……",
				},
				{
					Section = 3100,
					Text = "哥哥，我担心……",
				},
				{
					Section = 99999,
					Text = "回去？还是让我帮您放风吧，如果大盗回来，我担心……",
				},
			},
		},
		{
			Type = 1,
			Index = 4,
			Content = {
				{
					Section = 2000,
					Text = "你在干什么？",
				},
				{
					Section = 3200,
					Text = "不用担心，我会及时离开的，你走吧。",
				},
				{
					Section = 99999,
					Text = "哼，我肯定会在大盗回来之前，离开这个破地方，你先走吧。",
				},
			},
		},
		{
			Type = 1,
			Index = 1,
			Content = {
				{
					Section = 1500,
					Text = "我忘词了，临时凑一下字数。",
				},
				{
					Section = 3100,
					Text = "那你自己小心……",
				},
				{
					Section = 99999,
					Text = "哥哥……唉，算了，",
				},
			},
		},
		{
			Type = 1,
			Index = 1,
			Content = {
				{
					Section = 1500,
					Text = "1234567……",
				},
				{
					Section = 3100,
					Text = "（我还是看着哥哥吧，以免出现意外……）",
				},
				{
					Section = 99999,
					Text = "（放哥哥一个人在这儿真的好吗？我还是藏在门边，静观其变吧。）",
				},
			},
		},
		{
			Type = 1,
			Index = 4,
			Content = {
				{
					Section = 2000,
					Text = "你还挺聪明的。",
				},
				{
					Section = 3200,
					Text = "这些东西，都是我的啦，哈哈哈……",
				},
				{
					Section = 99999,
					Text = "这些食物，宝贝，无穷无尽的财富，从今以后，都是我的啦！",
				},
			},
		},
		{
			Type = 1,
			Index = 2,
			Content = {
				{
					Section = 1200,
					Text = "他们人呢？",
				},
				{
					Section = 2600,
					Text = "他们怎么还不回来？",
				},
				{
					Section = 99999,
					Text = "哦，已经过去很久了，他们怎么还不回来，不会有什么意外吧？",
				},
			},
		},
		{
			Type = 1,
			Index = 5,
			Content = {
				{
					Section = 600,
					Text = "不知道。",
				},
				{
					Section = 1000,
					Text = "真是让人担心，希望他们不会遇到什么意外。",
				},
				{
					Section = 99999,
					Text = "我也很担心，但我的卡西姆总是能想出办法，解决一切难题。",
				},
			},
		},
		{
			Type = 1,
			Index = 4,
			Content = {
				{
					Section = 2000,
					Text = "开始装东西了。",
				},
				{
					Section = 3200,
					Text = "已经装满一个袋子了。",
				},
				{
					Section = 99999,
					Text = "再装满一个袋子，就差不多了，如果太重，我的马儿也驮不动。",
				},
			},
		},
		{
			Type = 1,
			Index = 4,
			Content = {
				{
					Section = 2000,
					Text = "好多东西啊，这道具真重。",
				},
				{
					Section = 3200,
					Text = "再装一个……嘿，这下后半辈子都不用愁啦！",
				},
				{
					Section = 99999,
					Text = "不要一次性装太多，知道节制，之后的财富才能源源不断……",
				},
			},
		},
		{
			Type = 1,
			Index = 5,
			Content = {
				{
					Section = 600,
					Text = "累了，不想说台词了……",
				},
				{
					Section = 1000,
					Text = "唉，要不我去找他吧，你知道那个地方在哪吗？",
				},
				{
					Section = 99999,
					Text = "我真想去找他！也不知道他现在怎么样了……你恐怕不知道，我总有一种不祥的预感。",
				},
			},
		},
		{
			Type = 1,
			Index = 2,
			Content = {
				{
					Section = 1200,
					Text = "我也是。",
				},
				{
					Section = 2600,
					Text = "嫂嫂，那是强盗的窝，我们去不得啊！",
				},
				{
					Section = 99999,
					Text = "我也一样，我是多么担心他们啊，如果可以，我真希望自己能和他们一起去。",
				},
			},
		},
		{
			Type = 1,
			Index = 4,
			Content = {
				{
					Section = 2000,
					Text = "装好了，好耶！回家啦。",
				},
				{
					Section = 3200,
					Text = "今天大概就到这里吧，是时候离开了。",
				},
				{
					Section = 99999,
					Text = "装满这些就好了，准备回家……等等！？密码是什么？",
				},
			},
		},
		{
			Type = 1,
			Index = 4,
			Content = {
				{
					Section = 2000,
					Text = "石头开门。",
				},
				{
					Section = 3200,
					Text = "石头开门！",
				},
				{
					Section = 99999,
					Text = "石头开门——",
				},
			},
		},
		{
			Type = 1,
			Index = 4,
			Content = {
				{
					Section = 2000,
					Text = "大麦开门。",
				},
				{
					Section = 3200,
					Text = "大麦开门！",
				},
				{
					Section = 99999,
					Text = "大麦开门——",
				},
			},
		},
		{
			Type = 1,
			Index = 4,
			Content = {
				{
					Section = 2000,
					Text = "大豆开门。",
				},
				{
					Section = 3200,
					Text = "大豆开门！",
				},
				{
					Section = 99999,
					Text = "大豆开门——",
				},
			},
		},
		{
			Type = 1,
			Index = 4,
			Content = {
				{
					Section = 2000,
					Text = "密码，密码是什么！",
				},
				{
					Section = 3200,
					Text = "……糟糕，我忘记密码了。",
				},
				{
					Section = 99999,
					Text = "……完了！到底密码是什么？！",
				},
			},
		},
		{
			Type = 1,
			Index = 3,
			Content = {
				{
					Section = 700,
					Text = "回家啦，真开心~",
				},
				{
					Section = 1600,
					Text = "今天也收到了村民送来的礼物，真开心呀真开心~",
				},
				{
					Section = 99999,
					Text = "好心的村民又送了许多礼物来，真实辛苦他们了……总之，这次也把这些东西保存起来吧。",
				},
			},
		},
		{
			Type = 1,
			Index = 1,
			Content = {
				{
					Section = 1500,
					Text = "牛角大盗来了！哥哥，我跑了，你断后！",
				},
				{
					Section = 3100,
					Text = "哥哥怎么还不出来？糟糕，牛角大盗过来了！对不起了，哥哥，我先走了。",
				},
				{
					Section = 99999,
					Text = "已经快到晚上了，哥哥怎么还不出来？不行，再过一会儿，牛角大盗就该回来了，我得去把他叫出来……不好，有什么人过来了！",
				},
			},
		},
		{
			Type = 1,
			Index = 3,
			Content = {
				{
					Section = 700,
					Text = "我的基地，有人！我冲了！",
				},
				{
					Section = 1600,
					Text = "诶？我的小基地里好像有什么声音？",
				},
				{
					Section = 99999,
					Text = "嗯，刚刚是什么声音——唔，大概是一阵风飘过了吧？不对，我的秘密基地里也传出了碰撞声。",
				},
			},
		},
		{
			Type = 1,
			Index = 3,
			Content = {
				{
					Section = 700,
					Text = "这是谁的马？不会是强盗吧！",
				},
				{
					Section = 1600,
					Text = "这里还有马，不好，难道是强盗来了？",
				},
				{
					Section = 99999,
					Text = "这里还有一匹马……这是怎么回事？之前，这里的东西也在不断减少，难道，小偷正在里面？",
				},
			},
		},
		{
			Type = 1,
			Index = 3,
			Content = {
				{
					Section = 700,
					Text = "芝麻开门。",
				},
				{
					Section = 1600,
					Text = "芝麻开门——",
				},
				{
					Section = 99999,
					Text = "芝麻开门——！！",
				},
			},
		},
	},
}
