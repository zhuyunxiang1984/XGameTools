
DemandConfig[DemandID.Id401] =
{
	Id = 401,
	Name = "订购豆沙3",
	Desc = "需要超量豆沙",
	Value = 321201,
	Active = true,
	Weight = 8680,
	PreGoal = 
	{
		300406,
		300844,
	},
	CloseGoal = 
	{
		300888,
	},
	GoodsId = 4101201,
	Priority = 1201290,
	Num = 36,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 12549,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 106,
				},
				{
					Value = 1,
					Num = 1949,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 106,
				},
				{
					Value = 1,
					Num = 1949,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 21,
				},
				{
					Value = 1,
					Num = 2049,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 21,
				},
				{
					Value = 1,
					Num = 2049,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 4,
				},
				{
					Value = 1,
					Num = 2549,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 4,
				},
				{
					Value = 1,
					Num = 2549,
				},
			},
		},
	},
	DemandID = 410401,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id402] =
{
	Id = 402,
	Name = "订购冰块1",
	Desc = "需要一些冰块",
	Value = 321202,
	Active = true,
	Weight = 4500,
	PreGoal = 
	{
		300704,
		300413,
	},
	CloseGoal = 
	{
		300439,
	},
	GoodsId = 4201202,
	Priority = 1202301,
	Num = 20,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 8512,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 72,
				},
				{
					Value = 1,
					Num = 1312,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 68,
				},
				{
					Value = 1,
					Num = 1712,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 14,
				},
				{
					Value = 1,
					Num = 1512,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 13,
				},
				{
					Value = 1,
					Num = 2012,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 2,
				},
				{
					Value = 1,
					Num = 3512,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 2,
				},
				{
					Value = 1,
					Num = 3512,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 61,
				},
				{
					Value = 320051,
					Num = 24,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 12,
				},
				{
					Value = 320052,
					Num = 5,
				},
			},
		},
	},
	DemandID = 410402,
	DemandGroupList = {
		420002,
		420004,
		420005,
		420006,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id403] =
{
	Id = 403,
	Name = "订购冰块2",
	Desc = "需要大量冰块",
	Value = 321202,
	Active = true,
	Weight = 4800,
	PreGoal = 
	{
		300704,
		300421,
	},
	CloseGoal = 
	{
		300446,
	},
	GoodsId = 4201202,
	Priority = 1202302,
	Num = 20,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 8512,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 72,
				},
				{
					Value = 1,
					Num = 1312,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 68,
				},
				{
					Value = 1,
					Num = 1712,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 14,
				},
				{
					Value = 1,
					Num = 1512,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 13,
				},
				{
					Value = 1,
					Num = 2012,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 2,
				},
				{
					Value = 1,
					Num = 3512,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 2,
				},
				{
					Value = 1,
					Num = 3512,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 61,
				},
				{
					Value = 320051,
					Num = 24,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 12,
				},
				{
					Value = 320052,
					Num = 5,
				},
			},
		},
	},
	DemandID = 410403,
	DemandGroupList = {
		420002,
		420004,
		420005,
		420006,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id404] =
{
	Id = 404,
	Name = "订购冰块2",
	Desc = "需要超量冰块",
	Value = 321202,
	Active = true,
	Weight = 5100,
	PreGoal = 
	{
		300704,
		300428,
	},
	CloseGoal = 
	{
		300458,
	},
	GoodsId = 4201202,
	Priority = 1202303,
	Num = 21,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 8937,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 76,
				},
				{
					Value = 1,
					Num = 1337,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 71,
				},
				{
					Value = 1,
					Num = 1837,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 15,
				},
				{
					Value = 1,
					Num = 1437,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 14,
				},
				{
					Value = 1,
					Num = 1937,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 3,
				},
				{
					Value = 1,
					Num = 1437,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 2,
				},
				{
					Value = 1,
					Num = 3937,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 64,
				},
				{
					Value = 320051,
					Num = 25,
				},
			},
		},
	},
	DemandID = 410404,
	DemandGroupList = {
		420002,
		420004,
		420005,
		420006,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id405] =
{
	Id = 405,
	Name = "订购冰块1",
	Desc = "需要一些冰块",
	Value = 321202,
	Active = true,
	Weight = 5550,
	PreGoal = 
	{
		300704,
		300439,
	},
	CloseGoal = 
	{
		300470,
	},
	GoodsId = 4201202,
	Priority = 1202304,
	Num = 22,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 9363,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 80,
				},
				{
					Value = 1,
					Num = 1363,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 74,
				},
				{
					Value = 1,
					Num = 1963,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 16,
				},
				{
					Value = 1,
					Num = 1363,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 14,
				},
				{
					Value = 1,
					Num = 2363,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 3,
				},
				{
					Value = 1,
					Num = 1863,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 2,
				},
				{
					Value = 1,
					Num = 4363,
				},
			},
		},
	},
	DemandID = 410405,
	DemandGroupList = {
		420002,
		420004,
		420005,
		420006,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id406] =
{
	Id = 406,
	Name = "订购冰块2",
	Desc = "需要大量冰块",
	Value = 321202,
	Active = true,
	Weight = 6000,
	PreGoal = 
	{
		300704,
		300450,
	},
	CloseGoal = 
	{
		300486,
	},
	GoodsId = 4201202,
	Priority = 1202305,
	Num = 24,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 10214,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 87,
				},
				{
					Value = 1,
					Num = 1514,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 81,
				},
				{
					Value = 1,
					Num = 2114,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 17,
				},
				{
					Value = 1,
					Num = 1714,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 16,
				},
				{
					Value = 1,
					Num = 2214,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 3,
				},
				{
					Value = 1,
					Num = 2714,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 3,
				},
				{
					Value = 1,
					Num = 2714,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 73,
				},
				{
					Value = 320051,
					Num = 29,
				},
			},
		},
	},
	DemandID = 410406,
	DemandGroupList = {
		420002,
		420004,
		420005,
		420006,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id407] =
{
	Id = 407,
	Name = "订购冰块2",
	Desc = "需要超量冰块",
	Value = 321202,
	Active = true,
	Weight = 6600,
	PreGoal = 
	{
		300704,
		300466,
	},
	CloseGoal = 
	{
		300804,
	},
	GoodsId = 4201202,
	Priority = 1202306,
	Num = 25,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 10640,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 91,
				},
				{
					Value = 1,
					Num = 1540,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 85,
				},
				{
					Value = 1,
					Num = 2140,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 18,
				},
				{
					Value = 1,
					Num = 1640,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 17,
				},
				{
					Value = 1,
					Num = 2140,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 3,
				},
				{
					Value = 1,
					Num = 3140,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 3,
				},
				{
					Value = 1,
					Num = 3140,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 76,
				},
				{
					Value = 320051,
					Num = 30,
				},
			},
		},
	},
	DemandID = 410407,
	DemandGroupList = {
		420002,
		420004,
		420005,
		420006,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id408] =
{
	Id = 408,
	Name = "订购冰块1",
	Desc = "需要一些冰块",
	Value = 321202,
	Active = true,
	Weight = 7200,
	PreGoal = 
	{
		300704,
		300482,
	},
	CloseGoal = 
	{
		300827,
	},
	GoodsId = 4201202,
	Priority = 1202307,
	Num = 27,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 11491,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 98,
				},
				{
					Value = 1,
					Num = 1691,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 91,
				},
				{
					Value = 1,
					Num = 2391,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 19,
				},
				{
					Value = 1,
					Num = 1991,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 18,
				},
				{
					Value = 1,
					Num = 2491,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 3,
				},
				{
					Value = 1,
					Num = 3991,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 3,
				},
				{
					Value = 1,
					Num = 3991,
				},
			},
		},
	},
	DemandID = 410408,
	DemandGroupList = {
		420002,
		420004,
		420005,
		420006,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id409] =
{
	Id = 409,
	Name = "订购冰块2",
	Desc = "需要大量冰块",
	Value = 321202,
	Active = true,
	Weight = 7950,
	PreGoal = 
	{
		300704,
		300804,
	},
	CloseGoal = 
	{
		300848,
	},
	GoodsId = 4201202,
	Priority = 1202308,
	Num = 28,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 11916,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 102,
				},
				{
					Value = 1,
					Num = 1716,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 95,
				},
				{
					Value = 1,
					Num = 2416,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 20,
				},
				{
					Value = 1,
					Num = 1916,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 19,
				},
				{
					Value = 1,
					Num = 2416,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 4,
				},
				{
					Value = 1,
					Num = 1916,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 3,
				},
				{
					Value = 1,
					Num = 4416,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 85,
				},
				{
					Value = 320051,
					Num = 34,
				},
			},
		},
	},
	DemandID = 410409,
	DemandGroupList = {
		420002,
		420004,
		420005,
		420006,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id410] =
{
	Id = 410,
	Name = "订购冰块2",
	Desc = "需要超量冰块",
	Value = 321202,
	Active = true,
	Weight = 8700,
	PreGoal = 
	{
		300704,
		300827,
	},
	CloseGoal = 
	{
		300872,
	},
	GoodsId = 4201202,
	Priority = 1202309,
	Num = 32,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 13619,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 116,
				},
				{
					Value = 1,
					Num = 2019,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 108,
				},
				{
					Value = 1,
					Num = 2819,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 23,
				},
				{
					Value = 1,
					Num = 2119,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 21,
				},
				{
					Value = 1,
					Num = 3119,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 4,
				},
				{
					Value = 1,
					Num = 3619,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 4,
				},
				{
					Value = 1,
					Num = 3619,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 98,
				},
				{
					Value = 320051,
					Num = 38,
				},
			},
		},
	},
	DemandID = 410410,
	DemandGroupList = {
		420002,
		420004,
		420005,
		420006,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id411] =
{
	Id = 411,
	Name = "订购冰块2",
	Desc = "需要超量冰块",
	Value = 321202,
	Active = true,
	Weight = 9600,
	PreGoal = 
	{
		300704,
		300852,
	},
	CloseGoal = 
	{
		300896,
	},
	GoodsId = 4201202,
	Priority = 1202310,
	Num = 35,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 14896,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 127,
				},
				{
					Value = 1,
					Num = 2196,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 119,
				},
				{
					Value = 1,
					Num = 2996,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 25,
				},
				{
					Value = 1,
					Num = 2396,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 23,
				},
				{
					Value = 1,
					Num = 3396,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 5,
				},
				{
					Value = 1,
					Num = 2396,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 4,
				},
				{
					Value = 1,
					Num = 4896,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 1,
				},
				{
					Value = 1,
					Num = 2396,
				},
			},
		},
	},
	DemandID = 410411,
	DemandGroupList = {
		420002,
		420004,
		420005,
		420006,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id412] =
{
	Id = 412,
	Name = "订购牛奶1",
	Desc = "需要一些牛奶",
	Value = 321203,
	Active = true,
	Weight = 4500,
	PreGoal = 
	{
		300413,
	},
	CloseGoal = 
	{
		300439,
	},
	GoodsId = 4301203,
	Priority = 1203301,
	Num = 22,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 7900,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 67,
				},
				{
					Value = 1,
					Num = 1200,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 67,
				},
				{
					Value = 1,
					Num = 1200,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 13,
				},
				{
					Value = 1,
					Num = 1400,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 13,
				},
				{
					Value = 1,
					Num = 1400,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 2,
				},
				{
					Value = 1,
					Num = 2900,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 2,
				},
				{
					Value = 1,
					Num = 2900,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 47,
				},
				{
					Value = 320051,
					Num = 32,
				},
			},
		},
	},
	DemandID = 410412,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id413] =
{
	Id = 413,
	Name = "订购牛奶2",
	Desc = "需要大量牛奶",
	Value = 321203,
	Active = true,
	Weight = 4800,
	PreGoal = 
	{
		300413,
		300421,
	},
	CloseGoal = 
	{
		300446,
	},
	GoodsId = 4301203,
	Priority = 1203302,
	Num = 22,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 7900,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 67,
				},
				{
					Value = 1,
					Num = 1200,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 67,
				},
				{
					Value = 1,
					Num = 1200,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 13,
				},
				{
					Value = 1,
					Num = 1400,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 13,
				},
				{
					Value = 1,
					Num = 1400,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 2,
				},
				{
					Value = 1,
					Num = 2900,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 2,
				},
				{
					Value = 1,
					Num = 2900,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 47,
				},
				{
					Value = 320051,
					Num = 32,
				},
			},
		},
	},
	DemandID = 410413,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id414] =
{
	Id = 414,
	Name = "订购牛奶2",
	Desc = "需要超量牛奶",
	Value = 321203,
	Active = true,
	Weight = 5100,
	PreGoal = 
	{
		300413,
		300428,
	},
	CloseGoal = 
	{
		300458,
	},
	GoodsId = 4301203,
	Priority = 1203303,
	Num = 22,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 7900,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 67,
				},
				{
					Value = 1,
					Num = 1200,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 67,
				},
				{
					Value = 1,
					Num = 1200,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 13,
				},
				{
					Value = 1,
					Num = 1400,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 13,
				},
				{
					Value = 1,
					Num = 1400,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 2,
				},
				{
					Value = 1,
					Num = 2900,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 2,
				},
				{
					Value = 1,
					Num = 2900,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 47,
				},
				{
					Value = 320051,
					Num = 32,
				},
			},
		},
	},
	DemandID = 410414,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id415] =
{
	Id = 415,
	Name = "订购牛奶1",
	Desc = "需要一些牛奶",
	Value = 321203,
	Active = true,
	Weight = 5550,
	PreGoal = 
	{
		300413,
		300439,
	},
	CloseGoal = 
	{
		300470,
	},
	GoodsId = 4301203,
	Priority = 1203304,
	Num = 24,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 8618,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 73,
				},
				{
					Value = 1,
					Num = 1318,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 73,
				},
				{
					Value = 1,
					Num = 1318,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 14,
				},
				{
					Value = 1,
					Num = 1618,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 14,
				},
				{
					Value = 1,
					Num = 1618,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 2,
				},
				{
					Value = 1,
					Num = 3618,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 2,
				},
				{
					Value = 1,
					Num = 3618,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 51,
				},
				{
					Value = 320051,
					Num = 35,
				},
			},
		},
	},
	DemandID = 410415,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id416] =
{
	Id = 416,
	Name = "订购牛奶2",
	Desc = "需要大量牛奶",
	Value = 321203,
	Active = true,
	Weight = 6000,
	PreGoal = 
	{
		300413,
		300450,
	},
	CloseGoal = 
	{
		300486,
	},
	GoodsId = 4301203,
	Priority = 1203305,
	Num = 25,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 8977,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 76,
				},
				{
					Value = 1,
					Num = 1377,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 76,
				},
				{
					Value = 1,
					Num = 1377,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 15,
				},
				{
					Value = 1,
					Num = 1477,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 15,
				},
				{
					Value = 1,
					Num = 1477,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 3,
				},
				{
					Value = 1,
					Num = 1477,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 3,
				},
				{
					Value = 1,
					Num = 1477,
				},
			},
		},
	},
	DemandID = 410416,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id417] =
{
	Id = 417,
	Name = "订购牛奶2",
	Desc = "需要超量牛奶",
	Value = 321203,
	Active = true,
	Weight = 6600,
	PreGoal = 
	{
		300413,
		300466,
	},
	CloseGoal = 
	{
		300804,
	},
	GoodsId = 4301203,
	Priority = 1203306,
	Num = 27,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 9695,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 82,
				},
				{
					Value = 1,
					Num = 1495,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 82,
				},
				{
					Value = 1,
					Num = 1495,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 16,
				},
				{
					Value = 1,
					Num = 1695,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 16,
				},
				{
					Value = 1,
					Num = 1695,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 3,
				},
				{
					Value = 1,
					Num = 2195,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 3,
				},
				{
					Value = 1,
					Num = 2195,
				},
			},
		},
	},
	DemandID = 410417,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id418] =
{
	Id = 418,
	Name = "订购牛奶1",
	Desc = "需要一些牛奶",
	Value = 321203,
	Active = true,
	Weight = 7200,
	PreGoal = 
	{
		300413,
		300482,
	},
	CloseGoal = 
	{
		300827,
	},
	GoodsId = 4301203,
	Priority = 1203307,
	Num = 28,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 10054,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 85,
				},
				{
					Value = 1,
					Num = 1554,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 85,
				},
				{
					Value = 1,
					Num = 1554,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 17,
				},
				{
					Value = 1,
					Num = 1554,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 17,
				},
				{
					Value = 1,
					Num = 1554,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 3,
				},
				{
					Value = 1,
					Num = 2554,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 3,
				},
				{
					Value = 1,
					Num = 2554,
				},
			},
		},
	},
	DemandID = 410418,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id419] =
{
	Id = 419,
	Name = "订购牛奶2",
	Desc = "需要大量牛奶",
	Value = 321203,
	Active = true,
	Weight = 7950,
	PreGoal = 
	{
		300413,
		300804,
	},
	CloseGoal = 
	{
		300848,
	},
	GoodsId = 4301203,
	Priority = 1203308,
	Num = 30,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 10773,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 91,
				},
				{
					Value = 1,
					Num = 1673,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 91,
				},
				{
					Value = 1,
					Num = 1673,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 18,
				},
				{
					Value = 1,
					Num = 1773,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 18,
				},
				{
					Value = 1,
					Num = 1773,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 3,
				},
				{
					Value = 1,
					Num = 3273,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 3,
				},
				{
					Value = 1,
					Num = 3273,
				},
			},
		},
	},
	DemandID = 410419,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id420] =
{
	Id = 420,
	Name = "订购牛奶2",
	Desc = "需要超量牛奶",
	Value = 321203,
	Active = true,
	Weight = 8700,
	PreGoal = 
	{
		300413,
		300827,
	},
	CloseGoal = 
	{
		300872,
	},
	GoodsId = 4301203,
	Priority = 1203309,
	Num = 34,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 12209,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 103,
				},
				{
					Value = 1,
					Num = 1909,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 103,
				},
				{
					Value = 1,
					Num = 1909,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 20,
				},
				{
					Value = 1,
					Num = 2209,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 20,
				},
				{
					Value = 1,
					Num = 2209,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 4,
				},
				{
					Value = 1,
					Num = 2209,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 4,
				},
				{
					Value = 1,
					Num = 2209,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 73,
				},
				{
					Value = 320051,
					Num = 49,
				},
			},
		},
	},
	DemandID = 410420,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id421] =
{
	Id = 421,
	Name = "订购牛奶2",
	Desc = "需要超量牛奶",
	Value = 321203,
	Active = true,
	Weight = 9600,
	PreGoal = 
	{
		300413,
		300852,
	},
	CloseGoal = 
	{
		300896,
	},
	GoodsId = 4301203,
	Priority = 1203310,
	Num = 38,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 13645,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 115,
				},
				{
					Value = 1,
					Num = 2145,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 115,
				},
				{
					Value = 1,
					Num = 2145,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 23,
				},
				{
					Value = 1,
					Num = 2145,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 23,
				},
				{
					Value = 1,
					Num = 2145,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 4,
				},
				{
					Value = 1,
					Num = 3645,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 4,
				},
				{
					Value = 1,
					Num = 3645,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 81,
				},
				{
					Value = 320051,
					Num = 55,
				},
			},
		},
	},
	DemandID = 410421,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id422] =
{
	Id = 422,
	Name = "订购高标蛋1",
	Desc = "需要一些高标蛋",
	Value = 321204,
	Active = true,
	Weight = 5445,
	PreGoal = 
	{
		300424,
	},
	CloseGoal = 
	{
		300450,
	},
	GoodsId = 4401204,
	Priority = 1204331,
	Num = 21,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 9384,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 79,
				},
				{
					Value = 1,
					Num = 1484,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 79,
				},
				{
					Value = 1,
					Num = 1484,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 15,
				},
				{
					Value = 1,
					Num = 1884,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 15,
				},
				{
					Value = 1,
					Num = 1884,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 3,
				},
				{
					Value = 1,
					Num = 1884,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 3,
				},
				{
					Value = 1,
					Num = 1884,
				},
			},
		},
	},
	DemandID = 410422,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id423] =
{
	Id = 423,
	Name = "订购高标蛋1",
	Desc = "需要一些高标蛋",
	Value = 321204,
	Active = true,
	Weight = 5775,
	PreGoal = 
	{
		300424,
		300431,
	},
	CloseGoal = 
	{
		300458,
	},
	GoodsId = 4401204,
	Priority = 1204332,
	Num = 22,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 9831,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 83,
				},
				{
					Value = 1,
					Num = 1531,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 83,
				},
				{
					Value = 1,
					Num = 1531,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 16,
				},
				{
					Value = 1,
					Num = 1831,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 16,
				},
				{
					Value = 1,
					Num = 1831,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 3,
				},
				{
					Value = 1,
					Num = 2331,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 3,
				},
				{
					Value = 1,
					Num = 2331,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 58,
				},
				{
					Value = 320051,
					Num = 40,
				},
			},
		},
	},
	DemandID = 410423,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id424] =
{
	Id = 424,
	Name = "订购高标蛋1",
	Desc = "需要一些高标蛋",
	Value = 321204,
	Active = true,
	Weight = 6105,
	PreGoal = 
	{
		300424,
		300439,
	},
	CloseGoal = 
	{
		300470,
	},
	GoodsId = 4401204,
	Priority = 1204333,
	Num = 22,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 9831,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 83,
				},
				{
					Value = 1,
					Num = 1531,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 83,
				},
				{
					Value = 1,
					Num = 1531,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 16,
				},
				{
					Value = 1,
					Num = 1831,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 16,
				},
				{
					Value = 1,
					Num = 1831,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 3,
				},
				{
					Value = 1,
					Num = 2331,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 3,
				},
				{
					Value = 1,
					Num = 2331,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 58,
				},
				{
					Value = 320051,
					Num = 40,
				},
			},
		},
	},
	DemandID = 410424,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id425] =
{
	Id = 425,
	Name = "订购高标蛋1",
	Desc = "需要一些高标蛋",
	Value = 321204,
	Active = true,
	Weight = 6600,
	PreGoal = 
	{
		300424,
		300450,
	},
	CloseGoal = 
	{
		300482,
	},
	GoodsId = 4401204,
	Priority = 1204334,
	Num = 24,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 10725,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 91,
				},
				{
					Value = 1,
					Num = 1625,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 91,
				},
				{
					Value = 1,
					Num = 1625,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 18,
				},
				{
					Value = 1,
					Num = 1725,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 18,
				},
				{
					Value = 1,
					Num = 1725,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 3,
				},
				{
					Value = 1,
					Num = 3225,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 3,
				},
				{
					Value = 1,
					Num = 3225,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 64,
				},
				{
					Value = 320051,
					Num = 43,
				},
			},
		},
	},
	DemandID = 410425,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id426] =
{
	Id = 426,
	Name = "订购高标蛋1",
	Desc = "需要一些高标蛋",
	Value = 321204,
	Active = true,
	Weight = 7095,
	PreGoal = 
	{
		300424,
		300462,
	},
	CloseGoal = 
	{
		300499,
	},
	GoodsId = 4401204,
	Priority = 1204335,
	Num = 25,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 11172,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 94,
				},
				{
					Value = 1,
					Num = 1772,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 94,
				},
				{
					Value = 1,
					Num = 1772,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 18,
				},
				{
					Value = 1,
					Num = 2172,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 18,
				},
				{
					Value = 1,
					Num = 2172,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 3,
				},
				{
					Value = 1,
					Num = 3672,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 3,
				},
				{
					Value = 1,
					Num = 3672,
				},
			},
		},
	},
	DemandID = 410426,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id427] =
{
	Id = 427,
	Name = "订购高标蛋1",
	Desc = "需要一些高标蛋",
	Value = 321204,
	Active = true,
	Weight = 7755,
	PreGoal = 
	{
		300424,
		300478,
	},
	CloseGoal = 
	{
		300819,
	},
	GoodsId = 4401204,
	Priority = 1204336,
	Num = 26,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 11618,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 98,
				},
				{
					Value = 1,
					Num = 1818,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 98,
				},
				{
					Value = 1,
					Num = 1818,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 19,
				},
				{
					Value = 1,
					Num = 2118,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 19,
				},
				{
					Value = 1,
					Num = 2118,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 3,
				},
				{
					Value = 1,
					Num = 4118,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 3,
				},
				{
					Value = 1,
					Num = 4118,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 69,
				},
				{
					Value = 320051,
					Num = 47,
				},
			},
		},
	},
	DemandID = 410427,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id428] =
{
	Id = 428,
	Name = "订购高标蛋1",
	Desc = "需要一些高标蛋",
	Value = 321204,
	Active = true,
	Weight = 8415,
	PreGoal = 
	{
		300424,
		300494,
	},
	CloseGoal = 
	{
		300840,
	},
	GoodsId = 4401204,
	Priority = 1204337,
	Num = 28,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 12512,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 106,
				},
				{
					Value = 1,
					Num = 1912,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 106,
				},
				{
					Value = 1,
					Num = 1912,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 21,
				},
				{
					Value = 1,
					Num = 2012,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 21,
				},
				{
					Value = 1,
					Num = 2012,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 4,
				},
				{
					Value = 1,
					Num = 2512,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 4,
				},
				{
					Value = 1,
					Num = 2512,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 75,
				},
				{
					Value = 320051,
					Num = 50,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 15,
				},
				{
					Value = 320052,
					Num = 10,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 3,
				},
				{
					Value = 320053,
					Num = 2,
				},
			},
		},
	},
	DemandID = 410428,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id429] =
{
	Id = 429,
	Name = "订购高标蛋1",
	Desc = "需要一些高标蛋",
	Value = 321204,
	Active = true,
	Weight = 9240,
	PreGoal = 
	{
		300424,
		300819,
	},
	CloseGoal = 
	{
		300860,
	},
	GoodsId = 4401204,
	Priority = 1204338,
	Num = 30,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 13406,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 113,
				},
				{
					Value = 1,
					Num = 2106,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 113,
				},
				{
					Value = 1,
					Num = 2106,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 22,
				},
				{
					Value = 1,
					Num = 2406,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 22,
				},
				{
					Value = 1,
					Num = 2406,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 4,
				},
				{
					Value = 1,
					Num = 3406,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 4,
				},
				{
					Value = 1,
					Num = 3406,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 80,
				},
				{
					Value = 320051,
					Num = 54,
				},
			},
		},
	},
	DemandID = 410429,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id430] =
{
	Id = 430,
	Name = "订购高标蛋1",
	Desc = "需要一些高标蛋",
	Value = 321204,
	Active = true,
	Weight = 10065,
	PreGoal = 
	{
		300424,
		300840,
	},
	CloseGoal = 
	{
		300884,
	},
	GoodsId = 4401204,
	Priority = 1204339,
	Num = 33,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 14747,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 125,
				},
				{
					Value = 1,
					Num = 2247,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 125,
				},
				{
					Value = 1,
					Num = 2247,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 25,
				},
				{
					Value = 1,
					Num = 2247,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 25,
				},
				{
					Value = 1,
					Num = 2247,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 5,
				},
				{
					Value = 1,
					Num = 2247,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 5,
				},
				{
					Value = 1,
					Num = 2247,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 1,
				},
				{
					Value = 1,
					Num = 2247,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 1,
				},
				{
					Value = 1,
					Num = 2247,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 88,
				},
				{
					Value = 320051,
					Num = 59,
				},
			},
		},
	},
	DemandID = 410430,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id431] =
{
	Id = 431,
	Name = "订购高标蛋1",
	Desc = "需要一些高标蛋",
	Value = 321204,
	Active = true,
	Weight = 11055,
	PreGoal = 
	{
		300424,
		300864,
	},
	CloseGoal = 
	{
		301204,
	},
	GoodsId = 4401204,
	Priority = 1204340,
	Num = 36,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 16087,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 136,
				},
				{
					Value = 1,
					Num = 2487,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 136,
				},
				{
					Value = 1,
					Num = 2487,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 27,
				},
				{
					Value = 1,
					Num = 2587,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 27,
				},
				{
					Value = 1,
					Num = 2587,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 5,
				},
				{
					Value = 1,
					Num = 3587,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 5,
				},
				{
					Value = 1,
					Num = 3587,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 1,
				},
				{
					Value = 1,
					Num = 3587,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 1,
				},
				{
					Value = 1,
					Num = 3587,
				},
			},
		},
	},
	DemandID = 410431,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id432] =
{
	Id = 432,
	Name = "订购鱼肉1",
	Desc = "需要一些鱼肉",
	Value = 321205,
	Active = true,
	Weight = 6845,
	PreGoal = 
	{
		300722,
		300439,
	},
	CloseGoal = 
	{
		300466,
	},
	GoodsId = 4501205,
	Priority = 1205371,
	Num = 20,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 12474,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 106,
				},
				{
					Value = 1,
					Num = 1874,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 106,
				},
				{
					Value = 1,
					Num = 1874,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 21,
				},
				{
					Value = 1,
					Num = 1974,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 21,
				},
				{
					Value = 1,
					Num = 1974,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 4,
				},
				{
					Value = 1,
					Num = 2474,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 4,
				},
				{
					Value = 1,
					Num = 2474,
				},
			},
		},
	},
	DemandID = 410432,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id433] =
{
	Id = 433,
	Name = "订购鱼肉1",
	Desc = "需要一些鱼肉",
	Value = 321205,
	Active = true,
	Weight = 7215,
	PreGoal = 
	{
		300722,
		300446,
	},
	CloseGoal = 
	{
		300474,
	},
	GoodsId = 4501205,
	Priority = 1205372,
	Num = 21,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 13097,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 111,
				},
				{
					Value = 1,
					Num = 1997,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 111,
				},
				{
					Value = 1,
					Num = 1997,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 22,
				},
				{
					Value = 1,
					Num = 2097,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 22,
				},
				{
					Value = 1,
					Num = 2097,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 4,
				},
				{
					Value = 1,
					Num = 3097,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 4,
				},
				{
					Value = 1,
					Num = 3097,
				},
			},
		},
	},
	DemandID = 410433,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id434] =
{
	Id = 434,
	Name = "订购鱼肉1",
	Desc = "需要一些鱼肉",
	Value = 321205,
	Active = true,
	Weight = 7585,
	PreGoal = 
	{
		300722,
		300454,
	},
	CloseGoal = 
	{
		300486,
	},
	GoodsId = 4501205,
	Priority = 1205373,
	Num = 21,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 13097,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 111,
				},
				{
					Value = 1,
					Num = 1997,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 111,
				},
				{
					Value = 1,
					Num = 1997,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 22,
				},
				{
					Value = 1,
					Num = 2097,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 22,
				},
				{
					Value = 1,
					Num = 2097,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 4,
				},
				{
					Value = 1,
					Num = 3097,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 4,
				},
				{
					Value = 1,
					Num = 3097,
				},
			},
		},
	},
	DemandID = 410434,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id435] =
{
	Id = 435,
	Name = "订购鱼肉1",
	Desc = "需要一些鱼肉",
	Value = 321205,
	Active = true,
	Weight = 8140,
	PreGoal = 
	{
		300722,
		300466,
	},
	CloseGoal = 
	{
		300499,
	},
	GoodsId = 4501205,
	Priority = 1205374,
	Num = 22,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 13721,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 116,
				},
				{
					Value = 1,
					Num = 2121,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 116,
				},
				{
					Value = 1,
					Num = 2121,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 23,
				},
				{
					Value = 1,
					Num = 2221,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 23,
				},
				{
					Value = 1,
					Num = 2221,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 4,
				},
				{
					Value = 1,
					Num = 3721,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 4,
				},
				{
					Value = 1,
					Num = 3721,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 82,
				},
				{
					Value = 320051,
					Num = 55,
				},
			},
		},
	},
	DemandID = 410435,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id436] =
{
	Id = 436,
	Name = "订购鱼肉1",
	Desc = "需要一些鱼肉",
	Value = 321205,
	Active = true,
	Weight = 8695,
	PreGoal = 
	{
		300722,
		300478,
	},
	CloseGoal = 
	{
		300819,
	},
	GoodsId = 4501205,
	Priority = 1205375,
	Num = 22,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 13721,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 116,
				},
				{
					Value = 1,
					Num = 2121,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 116,
				},
				{
					Value = 1,
					Num = 2121,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 23,
				},
				{
					Value = 1,
					Num = 2221,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 23,
				},
				{
					Value = 1,
					Num = 2221,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 4,
				},
				{
					Value = 1,
					Num = 3721,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 4,
				},
				{
					Value = 1,
					Num = 3721,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 82,
				},
				{
					Value = 320051,
					Num = 55,
				},
			},
		},
	},
	DemandID = 410436,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id437] =
{
	Id = 437,
	Name = "订购鱼肉1",
	Desc = "需要一些鱼肉",
	Value = 321205,
	Active = true,
	Weight = 9435,
	PreGoal = 
	{
		300722,
		300494,
	},
	CloseGoal = 
	{
		300836,
	},
	GoodsId = 4501205,
	Priority = 1205376,
	Num = 25,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 15592,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 132,
				},
				{
					Value = 1,
					Num = 2392,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 132,
				},
				{
					Value = 1,
					Num = 2392,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 26,
				},
				{
					Value = 1,
					Num = 2592,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 26,
				},
				{
					Value = 1,
					Num = 2592,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 5,
				},
				{
					Value = 1,
					Num = 3092,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 5,
				},
				{
					Value = 1,
					Num = 3092,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 1,
				},
				{
					Value = 1,
					Num = 3092,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 1,
				},
				{
					Value = 1,
					Num = 3092,
				},
			},
		},
	},
	DemandID = 410437,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id438] =
{
	Id = 438,
	Name = "订购鱼肉1",
	Desc = "需要一些鱼肉",
	Value = 321205,
	Active = true,
	Weight = 10175,
	PreGoal = 
	{
		300722,
		300814,
	},
	CloseGoal = 
	{
		300856,
	},
	GoodsId = 4501205,
	Priority = 1205377,
	Num = 27,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 16839,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 143,
				},
				{
					Value = 1,
					Num = 2539,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 143,
				},
				{
					Value = 1,
					Num = 2539,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 28,
				},
				{
					Value = 1,
					Num = 2839,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 28,
				},
				{
					Value = 1,
					Num = 2839,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 5,
				},
				{
					Value = 1,
					Num = 4339,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 5,
				},
				{
					Value = 1,
					Num = 4339,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 1,
				},
				{
					Value = 1,
					Num = 4339,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 1,
				},
				{
					Value = 1,
					Num = 4339,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 101,
				},
				{
					Value = 320051,
					Num = 67,
				},
			},
		},
	},
	DemandID = 410438,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id439] =
{
	Id = 439,
	Name = "订购鱼肉1",
	Desc = "需要一些鱼肉",
	Value = 321205,
	Active = true,
	Weight = 11100,
	PreGoal = 
	{
		300722,
		300836,
	},
	CloseGoal = 
	{
		300876,
	},
	GoodsId = 4501205,
	Priority = 1205378,
	Num = 30,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 18711,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 159,
				},
				{
					Value = 1,
					Num = 2811,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 159,
				},
				{
					Value = 1,
					Num = 2811,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 31,
				},
				{
					Value = 1,
					Num = 3211,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 31,
				},
				{
					Value = 1,
					Num = 3211,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 6,
				},
				{
					Value = 1,
					Num = 3711,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 6,
				},
				{
					Value = 1,
					Num = 3711,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 1,
				},
				{
					Value = 1,
					Num = 6211,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 1,
				},
				{
					Value = 1,
					Num = 6211,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 112,
				},
				{
					Value = 320051,
					Num = 75,
				},
			},
		},
	},
	DemandID = 410439,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id440] =
{
	Id = 440,
	Name = "订购鱼肉1",
	Desc = "需要一些鱼肉",
	Value = 321205,
	Active = true,
	Weight = 12025,
	PreGoal = 
	{
		300722,
		300856,
	},
	CloseGoal = 
	{
		300900,
	},
	GoodsId = 4501205,
	Priority = 1205379,
	Num = 32,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 19958,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 169,
				},
				{
					Value = 1,
					Num = 3058,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 169,
				},
				{
					Value = 1,
					Num = 3058,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 33,
				},
				{
					Value = 1,
					Num = 3458,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 33,
				},
				{
					Value = 1,
					Num = 3458,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 6,
				},
				{
					Value = 1,
					Num = 4958,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 6,
				},
				{
					Value = 1,
					Num = 4958,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 1,
				},
				{
					Value = 1,
					Num = 7458,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 1,
				},
				{
					Value = 1,
					Num = 7458,
				},
			},
		},
	},
	DemandID = 410440,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id441] =
{
	Id = 441,
	Name = "订购鱼肉1",
	Desc = "需要一些鱼肉",
	Value = 321205,
	Active = true,
	Weight = 13135,
	PreGoal = 
	{
		300722,
		300880,
	},
	CloseGoal = 
	{
		301228,
	},
	GoodsId = 4501205,
	Priority = 1205380,
	Num = 36,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 22453,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 190,
				},
				{
					Value = 1,
					Num = 3453,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 190,
				},
				{
					Value = 1,
					Num = 3453,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 38,
				},
				{
					Value = 1,
					Num = 3453,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 38,
				},
				{
					Value = 1,
					Num = 3453,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 7,
				},
				{
					Value = 1,
					Num = 4953,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 7,
				},
				{
					Value = 1,
					Num = 4953,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 1,
				},
				{
					Value = 1,
					Num = 9953,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 1,
				},
				{
					Value = 1,
					Num = 9953,
				},
			},
		},
	},
	DemandID = 410441,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id442] =
{
	Id = 442,
	Name = "订购米饭1",
	Desc = "需要一些米饭",
	Value = 321206,
	Active = true,
	Weight = 7220,
	PreGoal = 
	{
		300443,
	},
	CloseGoal = 
	{
		300470,
	},
	GoodsId = 4601206,
	Priority = 1206381,
	Num = 21,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 12092,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 114,
				},
				{
					Value = 1,
					Num = 692,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 114,
				},
				{
					Value = 1,
					Num = 692,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 22,
				},
				{
					Value = 1,
					Num = 1092,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 22,
				},
				{
					Value = 1,
					Num = 1092,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 4,
				},
				{
					Value = 1,
					Num = 2092,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 4,
				},
				{
					Value = 1,
					Num = 2092,
				},
			},
		},
	},
	DemandID = 410442,
	DemandGroupList = {
		420002,
		420004,
		420005,
		420006,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id443] =
{
	Id = 443,
	Name = "订购米饭1",
	Desc = "需要一些米饭",
	Value = 321206,
	Active = true,
	Weight = 7600,
	PreGoal = 
	{
		300443,
		300450,
	},
	CloseGoal = 
	{
		300478,
	},
	GoodsId = 4601206,
	Priority = 1206382,
	Num = 21,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 12092,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 114,
				},
				{
					Value = 1,
					Num = 692,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 114,
				},
				{
					Value = 1,
					Num = 692,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 22,
				},
				{
					Value = 1,
					Num = 1092,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 22,
				},
				{
					Value = 1,
					Num = 1092,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 4,
				},
				{
					Value = 1,
					Num = 2092,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 4,
				},
				{
					Value = 1,
					Num = 2092,
				},
			},
		},
	},
	DemandID = 410443,
	DemandGroupList = {
		420002,
		420004,
		420005,
		420006,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id444] =
{
	Id = 444,
	Name = "订购米饭1",
	Desc = "需要一些米饭",
	Value = 321206,
	Active = true,
	Weight = 7980,
	PreGoal = 
	{
		300443,
		300458,
	},
	CloseGoal = 
	{
		300490,
	},
	GoodsId = 4601206,
	Priority = 1206383,
	Num = 22,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 12668,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 119,
				},
				{
					Value = 1,
					Num = 768,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 119,
				},
				{
					Value = 1,
					Num = 768,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 23,
				},
				{
					Value = 1,
					Num = 1168,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 23,
				},
				{
					Value = 1,
					Num = 1168,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 4,
				},
				{
					Value = 1,
					Num = 2668,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 4,
				},
				{
					Value = 1,
					Num = 2668,
				},
			},
		},
	},
	DemandID = 410444,
	DemandGroupList = {
		420002,
		420004,
		420005,
		420006,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id445] =
{
	Id = 445,
	Name = "订购米饭1",
	Desc = "需要一些米饭",
	Value = 321206,
	Active = true,
	Weight = 8550,
	PreGoal = 
	{
		300443,
		300470,
	},
	CloseGoal = 
	{
		300804,
	},
	GoodsId = 4601206,
	Priority = 1206384,
	Num = 22,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 12668,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 119,
				},
				{
					Value = 1,
					Num = 768,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 119,
				},
				{
					Value = 1,
					Num = 768,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 23,
				},
				{
					Value = 1,
					Num = 1168,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 23,
				},
				{
					Value = 1,
					Num = 1168,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 4,
				},
				{
					Value = 1,
					Num = 2668,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 4,
				},
				{
					Value = 1,
					Num = 2668,
				},
			},
		},
	},
	DemandID = 410445,
	DemandGroupList = {
		420002,
		420004,
		420005,
		420006,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id446] =
{
	Id = 446,
	Name = "订购米饭1",
	Desc = "需要一些米饭",
	Value = 321206,
	Active = true,
	Weight = 9120,
	PreGoal = 
	{
		300443,
		300482,
	},
	CloseGoal = 
	{
		300823,
	},
	GoodsId = 4601206,
	Priority = 1206385,
	Num = 24,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 13819,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 130,
				},
				{
					Value = 1,
					Num = 819,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 130,
				},
				{
					Value = 1,
					Num = 819,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 26,
				},
				{
					Value = 1,
					Num = 819,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 26,
				},
				{
					Value = 1,
					Num = 819,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 5,
				},
				{
					Value = 1,
					Num = 1319,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 5,
				},
				{
					Value = 1,
					Num = 1319,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 1,
				},
				{
					Value = 1,
					Num = 1319,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 1,
				},
				{
					Value = 1,
					Num = 1319,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 82,
				},
				{
					Value = 320051,
					Num = 56,
				},
			},
		},
	},
	DemandID = 410446,
	DemandGroupList = {
		420002,
		420004,
		420005,
		420006,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id447] =
{
	Id = 447,
	Name = "订购米饭1",
	Desc = "需要一些米饭",
	Value = 321206,
	Active = true,
	Weight = 9880,
	PreGoal = 
	{
		300443,
		300499,
	},
	CloseGoal = 
	{
		300840,
	},
	GoodsId = 4601206,
	Priority = 1206386,
	Num = 26,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 14971,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 141,
				},
				{
					Value = 1,
					Num = 871,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 141,
				},
				{
					Value = 1,
					Num = 871,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 28,
				},
				{
					Value = 1,
					Num = 971,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 28,
				},
				{
					Value = 1,
					Num = 971,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 5,
				},
				{
					Value = 1,
					Num = 2471,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 5,
				},
				{
					Value = 1,
					Num = 2471,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 1,
				},
				{
					Value = 1,
					Num = 2471,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 1,
				},
				{
					Value = 1,
					Num = 2471,
				},
			},
		},
	},
	DemandID = 410447,
	DemandGroupList = {
		420002,
		420004,
		420005,
		420006,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id448] =
{
	Id = 448,
	Name = "订购米饭1",
	Desc = "需要一些米饭",
	Value = 321206,
	Active = true,
	Weight = 10640,
	PreGoal = 
	{
		300443,
		300819,
	},
	CloseGoal = 
	{
		300860,
	},
	GoodsId = 4601206,
	Priority = 1206387,
	Num = 28,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 16122,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 152,
				},
				{
					Value = 1,
					Num = 922,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 152,
				},
				{
					Value = 1,
					Num = 922,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 30,
				},
				{
					Value = 1,
					Num = 1122,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 30,
				},
				{
					Value = 1,
					Num = 1122,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 6,
				},
				{
					Value = 1,
					Num = 1122,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 6,
				},
				{
					Value = 1,
					Num = 1122,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 1,
				},
				{
					Value = 1,
					Num = 3622,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 1,
				},
				{
					Value = 1,
					Num = 3622,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 96,
				},
				{
					Value = 320051,
					Num = 65,
				},
			},
		},
	},
	DemandID = 410448,
	DemandGroupList = {
		420002,
		420004,
		420005,
		420006,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id449] =
{
	Id = 449,
	Name = "订购米饭1",
	Desc = "需要一些米饭",
	Value = 321206,
	Active = true,
	Weight = 11590,
	PreGoal = 
	{
		300443,
		300840,
	},
	CloseGoal = 
	{
		300880,
	},
	GoodsId = 4601206,
	Priority = 1206388,
	Num = 30,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 17274,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 163,
				},
				{
					Value = 1,
					Num = 974,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 163,
				},
				{
					Value = 1,
					Num = 974,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 32,
				},
				{
					Value = 1,
					Num = 1274,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 32,
				},
				{
					Value = 1,
					Num = 1274,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 6,
				},
				{
					Value = 1,
					Num = 2274,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 6,
				},
				{
					Value = 1,
					Num = 2274,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 1,
				},
				{
					Value = 1,
					Num = 4774,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 1,
				},
				{
					Value = 1,
					Num = 4774,
				},
			},
		},
	},
	DemandID = 410449,
	DemandGroupList = {
		420002,
		420004,
		420005,
		420006,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id450] =
{
	Id = 450,
	Name = "订购米饭1",
	Desc = "需要一些米饭",
	Value = 321206,
	Active = true,
	Weight = 12540,
	PreGoal = 
	{
		300443,
		300860,
	},
	CloseGoal = 
	{
		300904,
	},
	GoodsId = 4601206,
	Priority = 1206389,
	Num = 33,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 19002,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 179,
				},
				{
					Value = 1,
					Num = 1102,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 179,
				},
				{
					Value = 1,
					Num = 1102,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 35,
				},
				{
					Value = 1,
					Num = 1502,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 35,
				},
				{
					Value = 1,
					Num = 1502,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 7,
				},
				{
					Value = 1,
					Num = 1502,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 7,
				},
				{
					Value = 1,
					Num = 1502,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 1,
				},
				{
					Value = 1,
					Num = 6502,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 1,
				},
				{
					Value = 1,
					Num = 6502,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 114,
				},
				{
					Value = 320051,
					Num = 76,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 22,
				},
				{
					Value = 320052,
					Num = 16,
				},
			},
		},
	},
	DemandID = 410450,
	DemandGroupList = {
		420002,
		420004,
		420005,
		420006,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id451] =
{
	Id = 451,
	Name = "订购米饭1",
	Desc = "需要一些米饭",
	Value = 321206,
	Active = true,
	Weight = 13680,
	PreGoal = 
	{
		300443,
		300884,
	},
	CloseGoal = 
	{
		301232,
	},
	GoodsId = 4601206,
	Priority = 1206390,
	Num = 36,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 20729,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 195,
				},
				{
					Value = 1,
					Num = 1229,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 195,
				},
				{
					Value = 1,
					Num = 1229,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 39,
				},
				{
					Value = 1,
					Num = 1229,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 39,
				},
				{
					Value = 1,
					Num = 1229,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 7,
				},
				{
					Value = 1,
					Num = 3229,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 7,
				},
				{
					Value = 1,
					Num = 3229,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 1,
				},
				{
					Value = 1,
					Num = 8229,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 1,
				},
				{
					Value = 1,
					Num = 8229,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 124,
				},
				{
					Value = 320051,
					Num = 83,
				},
			},
		},
	},
	DemandID = 410451,
	DemandGroupList = {
		420002,
		420004,
		420005,
		420006,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id452] =
{
	Id = 452,
	Name = "订购料酒1",
	Desc = "需要一些料酒",
	Value = 321207,
	Active = true,
	Weight = 8820,
	PreGoal = 
	{
		300458,
	},
	CloseGoal = 
	{
		300486,
	},
	GoodsId = 4701207,
	Priority = 1207421,
	Num = 22,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 13471,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 114,
				},
				{
					Value = 1,
					Num = 2071,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 114,
				},
				{
					Value = 1,
					Num = 2071,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 22,
				},
				{
					Value = 1,
					Num = 2471,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 22,
				},
				{
					Value = 1,
					Num = 2471,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 4,
				},
				{
					Value = 1,
					Num = 3471,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 4,
				},
				{
					Value = 1,
					Num = 3471,
				},
			},
		},
	},
	DemandID = 410452,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id453] =
{
	Id = 453,
	Name = "订购料酒1",
	Desc = "需要一些料酒",
	Value = 321207,
	Active = true,
	Weight = 9240,
	PreGoal = 
	{
		300458,
		300466,
	},
	CloseGoal = 
	{
		300494,
	},
	GoodsId = 4701207,
	Priority = 1207422,
	Num = 22,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 13471,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 114,
				},
				{
					Value = 1,
					Num = 2071,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 114,
				},
				{
					Value = 1,
					Num = 2071,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 22,
				},
				{
					Value = 1,
					Num = 2471,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 22,
				},
				{
					Value = 1,
					Num = 2471,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 4,
				},
				{
					Value = 1,
					Num = 3471,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 4,
				},
				{
					Value = 1,
					Num = 3471,
				},
			},
		},
	},
	DemandID = 410453,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id454] =
{
	Id = 454,
	Name = "订购料酒1",
	Desc = "需要一些料酒",
	Value = 321207,
	Active = true,
	Weight = 9660,
	PreGoal = 
	{
		300458,
		300474,
	},
	CloseGoal = 
	{
		300810,
	},
	GoodsId = 4701207,
	Priority = 1207423,
	Num = 22,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 13471,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 114,
				},
				{
					Value = 1,
					Num = 2071,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 114,
				},
				{
					Value = 1,
					Num = 2071,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 22,
				},
				{
					Value = 1,
					Num = 2471,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 22,
				},
				{
					Value = 1,
					Num = 2471,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 4,
				},
				{
					Value = 1,
					Num = 3471,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 4,
				},
				{
					Value = 1,
					Num = 3471,
				},
			},
		},
	},
	DemandID = 410454,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id455] =
{
	Id = 455,
	Name = "订购料酒1",
	Desc = "需要一些料酒",
	Value = 321207,
	Active = true,
	Weight = 10290,
	PreGoal = 
	{
		300458,
		300486,
	},
	CloseGoal = 
	{
		300823,
	},
	GoodsId = 4701207,
	Priority = 1207424,
	Num = 25,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 15309,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 130,
				},
				{
					Value = 1,
					Num = 2309,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 130,
				},
				{
					Value = 1,
					Num = 2309,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 26,
				},
				{
					Value = 1,
					Num = 2309,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 26,
				},
				{
					Value = 1,
					Num = 2309,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 5,
				},
				{
					Value = 1,
					Num = 2809,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 5,
				},
				{
					Value = 1,
					Num = 2809,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 1,
				},
				{
					Value = 1,
					Num = 2809,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 1,
				},
				{
					Value = 1,
					Num = 2809,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 91,
				},
				{
					Value = 320051,
					Num = 62,
				},
			},
		},
	},
	DemandID = 410455,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id456] =
{
	Id = 456,
	Name = "订购料酒1",
	Desc = "需要一些料酒",
	Value = 321207,
	Active = true,
	Weight = 10920,
	PreGoal = 
	{
		300458,
		300499,
	},
	CloseGoal = 
	{
		300840,
	},
	GoodsId = 4701207,
	Priority = 1207425,
	Num = 26,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 15921,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 135,
				},
				{
					Value = 1,
					Num = 2421,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 135,
				},
				{
					Value = 1,
					Num = 2421,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 27,
				},
				{
					Value = 1,
					Num = 2421,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 27,
				},
				{
					Value = 1,
					Num = 2421,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 5,
				},
				{
					Value = 1,
					Num = 3421,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 5,
				},
				{
					Value = 1,
					Num = 3421,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 1,
				},
				{
					Value = 1,
					Num = 3421,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 1,
				},
				{
					Value = 1,
					Num = 3421,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 95,
				},
				{
					Value = 320051,
					Num = 64,
				},
			},
		},
	},
	DemandID = 410456,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id457] =
{
	Id = 457,
	Name = "订购料酒1",
	Desc = "需要一些料酒",
	Value = 321207,
	Active = true,
	Weight = 11760,
	PreGoal = 
	{
		300458,
		300819,
	},
	CloseGoal = 
	{
		300856,
	},
	GoodsId = 4701207,
	Priority = 1207426,
	Num = 28,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 17146,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 145,
				},
				{
					Value = 1,
					Num = 2646,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 145,
				},
				{
					Value = 1,
					Num = 2646,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 29,
				},
				{
					Value = 1,
					Num = 2646,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 29,
				},
				{
					Value = 1,
					Num = 2646,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 5,
				},
				{
					Value = 1,
					Num = 4646,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 5,
				},
				{
					Value = 1,
					Num = 4646,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 1,
				},
				{
					Value = 1,
					Num = 4646,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 1,
				},
				{
					Value = 1,
					Num = 4646,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 102,
				},
				{
					Value = 320051,
					Num = 69,
				},
			},
		},
	},
	DemandID = 410457,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id458] =
{
	Id = 458,
	Name = "订购料酒1",
	Desc = "需要一些料酒",
	Value = 321207,
	Active = true,
	Weight = 12600,
	PreGoal = 
	{
		300458,
		300836,
	},
	CloseGoal = 
	{
		300876,
	},
	GoodsId = 4701207,
	Priority = 1207427,
	Num = 30,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 18370,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 156,
				},
				{
					Value = 1,
					Num = 2770,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 156,
				},
				{
					Value = 1,
					Num = 2770,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 31,
				},
				{
					Value = 1,
					Num = 2870,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 31,
				},
				{
					Value = 1,
					Num = 2870,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 6,
				},
				{
					Value = 1,
					Num = 3370,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 6,
				},
				{
					Value = 1,
					Num = 3370,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 1,
				},
				{
					Value = 1,
					Num = 5870,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 1,
				},
				{
					Value = 1,
					Num = 5870,
				},
			},
		},
	},
	DemandID = 410458,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id459] =
{
	Id = 459,
	Name = "订购料酒1",
	Desc = "需要一些料酒",
	Value = 321207,
	Active = true,
	Weight = 13650,
	PreGoal = 
	{
		300458,
		300856,
	},
	CloseGoal = 
	{
		300896,
	},
	GoodsId = 4701207,
	Priority = 1207428,
	Num = 32,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 19595,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 166,
				},
				{
					Value = 1,
					Num = 2995,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 166,
				},
				{
					Value = 1,
					Num = 2995,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 33,
				},
				{
					Value = 1,
					Num = 3095,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 33,
				},
				{
					Value = 1,
					Num = 3095,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 6,
				},
				{
					Value = 1,
					Num = 4595,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 6,
				},
				{
					Value = 1,
					Num = 4595,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 1,
				},
				{
					Value = 1,
					Num = 7095,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 1,
				},
				{
					Value = 1,
					Num = 7095,
				},
			},
		},
	},
	DemandID = 410459,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id460] =
{
	Id = 460,
	Name = "订购料酒1",
	Desc = "需要一些料酒",
	Value = 321207,
	Active = true,
	Weight = 14700,
	PreGoal = 
	{
		300458,
		300876,
	},
	CloseGoal = 
	{
		301224,
	},
	GoodsId = 4701207,
	Priority = 1207429,
	Num = 35,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 21432,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 182,
				},
				{
					Value = 1,
					Num = 3232,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 182,
				},
				{
					Value = 1,
					Num = 3232,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 36,
				},
				{
					Value = 1,
					Num = 3432,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 36,
				},
				{
					Value = 1,
					Num = 3432,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 7,
				},
				{
					Value = 1,
					Num = 3932,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 7,
				},
				{
					Value = 1,
					Num = 3932,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 1,
				},
				{
					Value = 1,
					Num = 8932,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 1,
				},
				{
					Value = 1,
					Num = 8932,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 128,
				},
				{
					Value = 320051,
					Num = 86,
				},
			},
		},
	},
	DemandID = 410460,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id461] =
{
	Id = 461,
	Name = "订购料酒1",
	Desc = "需要一些料酒",
	Value = 321207,
	Active = true,
	Weight = 15960,
	PreGoal = 
	{
		300458,
		300900,
	},
	CloseGoal = 
	{
		301248,
	},
	GoodsId = 4701207,
	Priority = 1207430,
	Num = 39,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 23882,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 202,
				},
				{
					Value = 1,
					Num = 3682,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 202,
				},
				{
					Value = 1,
					Num = 3682,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 40,
				},
				{
					Value = 1,
					Num = 3882,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 40,
				},
				{
					Value = 1,
					Num = 3882,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 8,
				},
				{
					Value = 1,
					Num = 3882,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 8,
				},
				{
					Value = 1,
					Num = 3882,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 1,
				},
				{
					Value = 1,
					Num = 11382,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 1,
				},
				{
					Value = 1,
					Num = 11382,
				},
			},
		},
	},
	DemandID = 410461,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id462] =
{
	Id = 462,
	Name = "订购海苔1",
	Desc = "需要一些海苔",
	Value = 321208,
	Active = true,
	Weight = 10125,
	PreGoal = 
	{
		300470,
	},
	CloseGoal = 
	{
		300499,
	},
	GoodsId = 4801208,
	Priority = 1208451,
	Num = 22,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 15332,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 122,
				},
				{
					Value = 1,
					Num = 3132,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 131,
				},
				{
					Value = 1,
					Num = 2232,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 24,
				},
				{
					Value = 1,
					Num = 3332,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 26,
				},
				{
					Value = 1,
					Num = 2332,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 4,
				},
				{
					Value = 1,
					Num = 5332,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 5,
				},
				{
					Value = 1,
					Num = 2832,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 1,
				},
				{
					Value = 1,
					Num = 2832,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 73,
				},
				{
					Value = 320051,
					Num = 80,
				},
			},
		},
	},
	DemandID = 410462,
	DemandGroupList = {
		420002,
		420004,
		420005,
		420006,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id463] =
{
	Id = 463,
	Name = "订购海苔1",
	Desc = "需要一些海苔",
	Value = 321208,
	Active = true,
	Weight = 10575,
	PreGoal = 
	{
		300470,
		300478,
	},
	CloseGoal = 
	{
		300810,
	},
	GoodsId = 4801208,
	Priority = 1208452,
	Num = 22,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 15332,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 122,
				},
				{
					Value = 1,
					Num = 3132,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 131,
				},
				{
					Value = 1,
					Num = 2232,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 24,
				},
				{
					Value = 1,
					Num = 3332,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 26,
				},
				{
					Value = 1,
					Num = 2332,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 4,
				},
				{
					Value = 1,
					Num = 5332,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 5,
				},
				{
					Value = 1,
					Num = 2832,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 1,
				},
				{
					Value = 1,
					Num = 2832,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 73,
				},
				{
					Value = 320051,
					Num = 80,
				},
			},
		},
	},
	DemandID = 410463,
	DemandGroupList = {
		420002,
		420004,
		420005,
		420006,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id464] =
{
	Id = 464,
	Name = "订购海苔1",
	Desc = "需要一些海苔",
	Value = 321208,
	Active = true,
	Weight = 11025,
	PreGoal = 
	{
		300470,
		300486,
	},
	CloseGoal = 
	{
		300823,
	},
	GoodsId = 4801208,
	Priority = 1208453,
	Num = 22,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 15332,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 122,
				},
				{
					Value = 1,
					Num = 3132,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 131,
				},
				{
					Value = 1,
					Num = 2232,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 24,
				},
				{
					Value = 1,
					Num = 3332,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 26,
				},
				{
					Value = 1,
					Num = 2332,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 4,
				},
				{
					Value = 1,
					Num = 5332,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 5,
				},
				{
					Value = 1,
					Num = 2832,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 1,
				},
				{
					Value = 1,
					Num = 2832,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 73,
				},
				{
					Value = 320051,
					Num = 80,
				},
			},
		},
	},
	DemandID = 410464,
	DemandGroupList = {
		420002,
		420004,
		420005,
		420006,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id465] =
{
	Id = 465,
	Name = "订购海苔1",
	Desc = "需要一些海苔",
	Value = 321208,
	Active = true,
	Weight = 11700,
	PreGoal = 
	{
		300470,
		300499,
	},
	CloseGoal = 
	{
		300836,
	},
	GoodsId = 4801208,
	Priority = 1208454,
	Num = 24,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 16726,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 133,
				},
				{
					Value = 1,
					Num = 3426,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 143,
				},
				{
					Value = 1,
					Num = 2426,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 26,
				},
				{
					Value = 1,
					Num = 3726,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 28,
				},
				{
					Value = 1,
					Num = 2726,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 5,
				},
				{
					Value = 1,
					Num = 4226,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 5,
				},
				{
					Value = 1,
					Num = 4226,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 1,
				},
				{
					Value = 1,
					Num = 4226,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 1,
				},
				{
					Value = 1,
					Num = 4226,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 80,
				},
				{
					Value = 320051,
					Num = 87,
				},
			},
		},
	},
	DemandID = 410465,
	DemandGroupList = {
		420002,
		420004,
		420005,
		420006,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id466] =
{
	Id = 466,
	Name = "订购海苔1",
	Desc = "需要一些海苔",
	Value = 321208,
	Active = true,
	Weight = 12375,
	PreGoal = 
	{
		300470,
		300814,
	},
	CloseGoal = 
	{
		300852,
	},
	GoodsId = 4801208,
	Priority = 1208455,
	Num = 26,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 18119,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 144,
				},
				{
					Value = 1,
					Num = 3719,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 155,
				},
				{
					Value = 1,
					Num = 2619,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 28,
				},
				{
					Value = 1,
					Num = 4119,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 31,
				},
				{
					Value = 1,
					Num = 2619,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 5,
				},
				{
					Value = 1,
					Num = 5619,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 6,
				},
				{
					Value = 1,
					Num = 3119,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 1,
				},
				{
					Value = 1,
					Num = 5619,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 1,
				},
				{
					Value = 1,
					Num = 5619,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 86,
				},
				{
					Value = 320051,
					Num = 95,
				},
			},
		},
	},
	DemandID = 410466,
	DemandGroupList = {
		420002,
		420004,
		420005,
		420006,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id467] =
{
	Id = 467,
	Name = "订购海苔1",
	Desc = "需要一些海苔",
	Value = 321208,
	Active = true,
	Weight = 13275,
	PreGoal = 
	{
		300470,
		300832,
	},
	CloseGoal = 
	{
		300868,
	},
	GoodsId = 4801208,
	Priority = 1208456,
	Num = 27,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 18816,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 150,
				},
				{
					Value = 1,
					Num = 3816,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 161,
				},
				{
					Value = 1,
					Num = 2716,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 30,
				},
				{
					Value = 1,
					Num = 3816,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 32,
				},
				{
					Value = 1,
					Num = 2816,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 6,
				},
				{
					Value = 1,
					Num = 3816,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 6,
				},
				{
					Value = 1,
					Num = 3816,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 1,
				},
				{
					Value = 1,
					Num = 6316,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 1,
				},
				{
					Value = 1,
					Num = 6316,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 90,
				},
				{
					Value = 320051,
					Num = 98,
				},
			},
		},
	},
	DemandID = 410467,
	DemandGroupList = {
		420002,
		420004,
		420005,
		420006,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id468] =
{
	Id = 468,
	Name = "订购海苔1",
	Desc = "需要一些海苔",
	Value = 321208,
	Active = true,
	Weight = 14175,
	PreGoal = 
	{
		300470,
		300848,
	},
	CloseGoal = 
	{
		300888,
	},
	GoodsId = 4801208,
	Priority = 1208457,
	Num = 30,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 20907,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 167,
				},
				{
					Value = 1,
					Num = 4207,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 179,
				},
				{
					Value = 1,
					Num = 3007,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 33,
				},
				{
					Value = 1,
					Num = 4407,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 35,
				},
				{
					Value = 1,
					Num = 3407,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 6,
				},
				{
					Value = 1,
					Num = 5907,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 7,
				},
				{
					Value = 1,
					Num = 3407,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 1,
				},
				{
					Value = 1,
					Num = 8407,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 1,
				},
				{
					Value = 1,
					Num = 8407,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 100,
				},
				{
					Value = 320051,
					Num = 109,
				},
			},
		},
	},
	DemandID = 410468,
	DemandGroupList = {
		420002,
		420004,
		420005,
		420006,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id469] =
{
	Id = 469,
	Name = "订购海苔1",
	Desc = "需要一些海苔",
	Value = 321208,
	Active = true,
	Weight = 15300,
	PreGoal = 
	{
		300470,
		300868,
	},
	CloseGoal = 
	{
		301204,
	},
	GoodsId = 4801208,
	Priority = 1208458,
	Num = 32,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 22301,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 178,
				},
				{
					Value = 1,
					Num = 4501,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 191,
				},
				{
					Value = 1,
					Num = 3201,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 35,
				},
				{
					Value = 1,
					Num = 4801,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 38,
				},
				{
					Value = 1,
					Num = 3301,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 7,
				},
				{
					Value = 1,
					Num = 4801,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 7,
				},
				{
					Value = 1,
					Num = 4801,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 1,
				},
				{
					Value = 1,
					Num = 9801,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 1,
				},
				{
					Value = 1,
					Num = 9801,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 107,
				},
				{
					Value = 320051,
					Num = 116,
				},
			},
		},
	},
	DemandID = 410469,
	DemandGroupList = {
		420002,
		420004,
		420005,
		420006,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id470] =
{
	Id = 470,
	Name = "订购海苔1",
	Desc = "需要一些海苔",
	Value = 321208,
	Active = true,
	Weight = 16425,
	PreGoal = 
	{
		300470,
		300888,
	},
	CloseGoal = 
	{
		301236,
	},
	GoodsId = 4801208,
	Priority = 1208459,
	Num = 35,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 24392,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 195,
				},
				{
					Value = 1,
					Num = 4892,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 209,
				},
				{
					Value = 1,
					Num = 3492,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 39,
				},
				{
					Value = 1,
					Num = 4892,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 41,
				},
				{
					Value = 1,
					Num = 3892,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 7,
				},
				{
					Value = 1,
					Num = 6892,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 8,
				},
				{
					Value = 1,
					Num = 4392,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 1,
				},
				{
					Value = 1,
					Num = 11892,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 1,
				},
				{
					Value = 1,
					Num = 11892,
				},
			},
		},
	},
	DemandID = 410470,
	DemandGroupList = {
		420002,
		420004,
		420005,
		420006,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id471] =
{
	Id = 471,
	Name = "订购海苔1",
	Desc = "需要一些海苔",
	Value = 321208,
	Active = true,
	Weight = 17775,
	PreGoal = 
	{
		300470,
		301216,
	},
	CloseGoal = 
	{
		301260,
	},
	GoodsId = 4801208,
	Priority = 1208460,
	Num = 39,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 27179,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 217,
				},
				{
					Value = 1,
					Num = 5479,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 232,
				},
				{
					Value = 1,
					Num = 3979,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 43,
				},
				{
					Value = 1,
					Num = 5679,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 46,
				},
				{
					Value = 1,
					Num = 4179,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 8,
				},
				{
					Value = 1,
					Num = 7179,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 9,
				},
				{
					Value = 1,
					Num = 4679,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 1,
				},
				{
					Value = 1,
					Num = 14679,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 1,
				},
				{
					Value = 1,
					Num = 14679,
				},
			},
		},
	},
	DemandID = 410471,
	DemandGroupList = {
		420002,
		420004,
		420005,
		420006,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id472] =
{
	Id = 472,
	Name = "订购五花肉1",
	Desc = "需要一些五花肉",
	Value = 321209,
	Active = true,
	Weight = 12500,
	PreGoal = 
	{
		300490,
	},
	CloseGoal = 
	{
		300823,
	},
	GoodsId = 4901209,
	Priority = 1209501,
	Num = 22,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 17186,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 146,
				},
				{
					Value = 1,
					Num = 2586,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 146,
				},
				{
					Value = 1,
					Num = 2586,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 29,
				},
				{
					Value = 1,
					Num = 2686,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 29,
				},
				{
					Value = 1,
					Num = 2686,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 5,
				},
				{
					Value = 1,
					Num = 4686,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 5,
				},
				{
					Value = 1,
					Num = 4686,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 1,
				},
				{
					Value = 1,
					Num = 4686,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 1,
				},
				{
					Value = 1,
					Num = 4686,
				},
			},
		},
	},
	DemandID = 410472,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id473] =
{
	Id = 473,
	Name = "订购五花肉1",
	Desc = "需要一些五花肉",
	Value = 321209,
	Active = true,
	Weight = 13000,
	PreGoal = 
	{
		300490,
		300499,
	},
	CloseGoal = 
	{
		300832,
	},
	GoodsId = 4901209,
	Priority = 1209502,
	Num = 22,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 17186,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 146,
				},
				{
					Value = 1,
					Num = 2586,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 146,
				},
				{
					Value = 1,
					Num = 2586,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 29,
				},
				{
					Value = 1,
					Num = 2686,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 29,
				},
				{
					Value = 1,
					Num = 2686,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 5,
				},
				{
					Value = 1,
					Num = 4686,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 5,
				},
				{
					Value = 1,
					Num = 4686,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 1,
				},
				{
					Value = 1,
					Num = 4686,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 1,
				},
				{
					Value = 1,
					Num = 4686,
				},
			},
		},
	},
	DemandID = 410473,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id474] =
{
	Id = 474,
	Name = "订购五花肉1",
	Desc = "需要一些五花肉",
	Value = 321209,
	Active = true,
	Weight = 13500,
	PreGoal = 
	{
		300490,
		300810,
	},
	CloseGoal = 
	{
		300844,
	},
	GoodsId = 4901209,
	Priority = 1209503,
	Num = 24,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 18748,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 159,
				},
				{
					Value = 1,
					Num = 2848,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 159,
				},
				{
					Value = 1,
					Num = 2848,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 31,
				},
				{
					Value = 1,
					Num = 3248,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 31,
				},
				{
					Value = 1,
					Num = 3248,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 6,
				},
				{
					Value = 1,
					Num = 3748,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 6,
				},
				{
					Value = 1,
					Num = 3748,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 1,
				},
				{
					Value = 1,
					Num = 6248,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 1,
				},
				{
					Value = 1,
					Num = 6248,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 112,
				},
				{
					Value = 320051,
					Num = 75,
				},
			},
		},
	},
	DemandID = 410474,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id475] =
{
	Id = 475,
	Name = "订购五花肉1",
	Desc = "需要一些五花肉",
	Value = 321209,
	Active = true,
	Weight = 14250,
	PreGoal = 
	{
		300490,
		300823,
	},
	CloseGoal = 
	{
		300856,
	},
	GoodsId = 4901209,
	Priority = 1209504,
	Num = 25,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 19530,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 166,
				},
				{
					Value = 1,
					Num = 2930,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 166,
				},
				{
					Value = 1,
					Num = 2930,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 33,
				},
				{
					Value = 1,
					Num = 3030,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 33,
				},
				{
					Value = 1,
					Num = 3030,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 6,
				},
				{
					Value = 1,
					Num = 4530,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 6,
				},
				{
					Value = 1,
					Num = 4530,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 1,
				},
				{
					Value = 1,
					Num = 7030,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 1,
				},
				{
					Value = 1,
					Num = 7030,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 117,
				},
				{
					Value = 320051,
					Num = 78,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 23,
				},
				{
					Value = 320052,
					Num = 16,
				},
			},
		},
	},
	DemandID = 410475,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id476] =
{
	Id = 476,
	Name = "订购五花肉1",
	Desc = "需要一些五花肉",
	Value = 321209,
	Active = true,
	Weight = 15000,
	PreGoal = 
	{
		300490,
		300836,
	},
	CloseGoal = 
	{
		300872,
	},
	GoodsId = 4901209,
	Priority = 1209505,
	Num = 26,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 20311,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 172,
				},
				{
					Value = 1,
					Num = 3111,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 172,
				},
				{
					Value = 1,
					Num = 3111,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 34,
				},
				{
					Value = 1,
					Num = 3311,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 34,
				},
				{
					Value = 1,
					Num = 3311,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 6,
				},
				{
					Value = 1,
					Num = 5311,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 6,
				},
				{
					Value = 1,
					Num = 5311,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 1,
				},
				{
					Value = 1,
					Num = 7811,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 1,
				},
				{
					Value = 1,
					Num = 7811,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 121,
				},
				{
					Value = 320051,
					Num = 82,
				},
			},
		},
	},
	DemandID = 410476,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id477] =
{
	Id = 477,
	Name = "订购五花肉1",
	Desc = "需要一些五花肉",
	Value = 321209,
	Active = true,
	Weight = 16000,
	PreGoal = 
	{
		300490,
		300852,
	},
	CloseGoal = 
	{
		300888,
	},
	GoodsId = 4901209,
	Priority = 1209506,
	Num = 28,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 21873,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 185,
				},
				{
					Value = 1,
					Num = 3373,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 185,
				},
				{
					Value = 1,
					Num = 3373,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 37,
				},
				{
					Value = 1,
					Num = 3373,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 37,
				},
				{
					Value = 1,
					Num = 3373,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 7,
				},
				{
					Value = 1,
					Num = 4373,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 7,
				},
				{
					Value = 1,
					Num = 4373,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 1,
				},
				{
					Value = 1,
					Num = 9373,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 1,
				},
				{
					Value = 1,
					Num = 9373,
				},
			},
		},
	},
	DemandID = 410477,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id478] =
{
	Id = 478,
	Name = "订购五花肉1",
	Desc = "需要一些五花肉",
	Value = 321209,
	Active = true,
	Weight = 17000,
	PreGoal = 
	{
		300490,
		300868,
	},
	CloseGoal = 
	{
		301204,
	},
	GoodsId = 4901209,
	Priority = 1209507,
	Num = 30,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 23436,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 199,
				},
				{
					Value = 1,
					Num = 3536,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 199,
				},
				{
					Value = 1,
					Num = 3536,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 39,
				},
				{
					Value = 1,
					Num = 3936,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 39,
				},
				{
					Value = 1,
					Num = 3936,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 7,
				},
				{
					Value = 1,
					Num = 5936,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 7,
				},
				{
					Value = 1,
					Num = 5936,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 1,
				},
				{
					Value = 1,
					Num = 10936,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 1,
				},
				{
					Value = 1,
					Num = 10936,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 140,
				},
				{
					Value = 320051,
					Num = 94,
				},
			},
		},
	},
	DemandID = 410478,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id479] =
{
	Id = 479,
	Name = "订购五花肉1",
	Desc = "需要一些五花肉",
	Value = 321209,
	Active = true,
	Weight = 18250,
	PreGoal = 
	{
		300490,
		300888,
	},
	CloseGoal = 
	{
		301232,
	},
	GoodsId = 4901209,
	Priority = 1209508,
	Num = 33,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 25779,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 219,
				},
				{
					Value = 1,
					Num = 3879,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 219,
				},
				{
					Value = 1,
					Num = 3879,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 43,
				},
				{
					Value = 1,
					Num = 4279,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 43,
				},
				{
					Value = 1,
					Num = 4279,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 8,
				},
				{
					Value = 1,
					Num = 5779,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 8,
				},
				{
					Value = 1,
					Num = 5779,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 1,
				},
				{
					Value = 1,
					Num = 13279,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 1,
				},
				{
					Value = 1,
					Num = 13279,
				},
			},
		},
	},
	DemandID = 410479,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id480] =
{
	Id = 480,
	Name = "订购五花肉1",
	Desc = "需要一些五花肉",
	Value = 321209,
	Active = true,
	Weight = 19500,
	PreGoal = 
	{
		300490,
		301204,
	},
	CloseGoal = 
	{
		301256,
	},
	GoodsId = 4901209,
	Priority = 1209509,
	Num = 36,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 28123,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 239,
				},
				{
					Value = 1,
					Num = 4223,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 239,
				},
				{
					Value = 1,
					Num = 4223,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 47,
				},
				{
					Value = 1,
					Num = 4623,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 47,
				},
				{
					Value = 1,
					Num = 4623,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 9,
				},
				{
					Value = 1,
					Num = 5623,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 9,
				},
				{
					Value = 1,
					Num = 5623,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 1,
				},
				{
					Value = 1,
					Num = 15623,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 1,
				},
				{
					Value = 1,
					Num = 15623,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 168,
				},
				{
					Value = 320051,
					Num = 113,
				},
			},
		},
	},
	DemandID = 410480,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id481] =
{
	Id = 481,
	Name = "订购五花肉1",
	Desc = "需要一些五花肉",
	Value = 321209,
	Active = true,
	Weight = 21000,
	PreGoal = 
	{
		300490,
		301236,
	},
	CloseGoal = 
	{
		301280,
	},
	GoodsId = 4901209,
	Priority = 1209510,
	Num = 40,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 31248,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 265,
				},
				{
					Value = 1,
					Num = 4748,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 265,
				},
				{
					Value = 1,
					Num = 4748,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 53,
				},
				{
					Value = 1,
					Num = 4748,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 53,
				},
				{
					Value = 1,
					Num = 4748,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 10,
				},
				{
					Value = 1,
					Num = 6248,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 10,
				},
				{
					Value = 1,
					Num = 6248,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 2,
				},
				{
					Value = 1,
					Num = 6248,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 2,
				},
				{
					Value = 1,
					Num = 6248,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 187,
				},
				{
					Value = 320051,
					Num = 125,
				},
			},
		},
	},
	DemandID = 410481,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id482] =
{
	Id = 482,
	Name = "订购芝士1",
	Desc = "需要一些芝士",
	Value = 321210,
	Active = true,
	Weight = 13005,
	PreGoal = 
	{
		300735,
		300494,
	},
	CloseGoal = 
	{
		300827,
	},
	GoodsId = 5001210,
	Priority = 1210511,
	Num = 18,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 18663,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 158,
				},
				{
					Value = 1,
					Num = 2863,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 158,
				},
				{
					Value = 1,
					Num = 2863,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 31,
				},
				{
					Value = 1,
					Num = 3163,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 31,
				},
				{
					Value = 1,
					Num = 3163,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 6,
				},
				{
					Value = 1,
					Num = 3663,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 6,
				},
				{
					Value = 1,
					Num = 3663,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 1,
				},
				{
					Value = 1,
					Num = 6163,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 1,
				},
				{
					Value = 1,
					Num = 6163,
				},
			},
		},
	},
	DemandID = 410482,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id483] =
{
	Id = 483,
	Name = "订购芝士1",
	Desc = "需要一些芝士",
	Value = 321210,
	Active = true,
	Weight = 13515,
	PreGoal = 
	{
		300735,
		300804,
	},
	CloseGoal = 
	{
		300836,
	},
	GoodsId = 5001210,
	Priority = 1210512,
	Num = 20,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 20736,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 176,
				},
				{
					Value = 1,
					Num = 3136,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 176,
				},
				{
					Value = 1,
					Num = 3136,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 35,
				},
				{
					Value = 1,
					Num = 3236,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 35,
				},
				{
					Value = 1,
					Num = 3236,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 7,
				},
				{
					Value = 1,
					Num = 3236,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 7,
				},
				{
					Value = 1,
					Num = 3236,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 1,
				},
				{
					Value = 1,
					Num = 8236,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 1,
				},
				{
					Value = 1,
					Num = 8236,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 124,
				},
				{
					Value = 320051,
					Num = 83,
				},
			},
		},
	},
	DemandID = 410483,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id484] =
{
	Id = 484,
	Name = "订购芝士1",
	Desc = "需要一些芝士",
	Value = 321210,
	Active = true,
	Weight = 14025,
	PreGoal = 
	{
		300735,
		300814,
	},
	CloseGoal = 
	{
		300848,
	},
	GoodsId = 5001210,
	Priority = 1210513,
	Num = 21,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 21773,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 185,
				},
				{
					Value = 1,
					Num = 3273,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 185,
				},
				{
					Value = 1,
					Num = 3273,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 37,
				},
				{
					Value = 1,
					Num = 3273,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 37,
				},
				{
					Value = 1,
					Num = 3273,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 7,
				},
				{
					Value = 1,
					Num = 4273,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 7,
				},
				{
					Value = 1,
					Num = 4273,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 1,
				},
				{
					Value = 1,
					Num = 9273,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 1,
				},
				{
					Value = 1,
					Num = 9273,
				},
			},
		},
	},
	DemandID = 410484,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id485] =
{
	Id = 485,
	Name = "订购芝士1",
	Desc = "需要一些芝士",
	Value = 321210,
	Active = true,
	Weight = 14790,
	PreGoal = 
	{
		300735,
		300827,
	},
	CloseGoal = 
	{
		300860,
	},
	GoodsId = 5001210,
	Priority = 1210514,
	Num = 22,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 22810,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 193,
				},
				{
					Value = 1,
					Num = 3510,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 193,
				},
				{
					Value = 1,
					Num = 3510,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 38,
				},
				{
					Value = 1,
					Num = 3810,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 38,
				},
				{
					Value = 1,
					Num = 3810,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 7,
				},
				{
					Value = 1,
					Num = 5310,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 7,
				},
				{
					Value = 1,
					Num = 5310,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 1,
				},
				{
					Value = 1,
					Num = 10310,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 1,
				},
				{
					Value = 1,
					Num = 10310,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 136,
				},
				{
					Value = 320051,
					Num = 92,
				},
			},
		},
	},
	DemandID = 410485,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id486] =
{
	Id = 486,
	Name = "订购芝士1",
	Desc = "需要一些芝士",
	Value = 321210,
	Active = true,
	Weight = 15555,
	PreGoal = 
	{
		300735,
		300840,
	},
	CloseGoal = 
	{
		300876,
	},
	GoodsId = 5001210,
	Priority = 1210515,
	Num = 22,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 22810,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 193,
				},
				{
					Value = 1,
					Num = 3510,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 193,
				},
				{
					Value = 1,
					Num = 3510,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 38,
				},
				{
					Value = 1,
					Num = 3810,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 38,
				},
				{
					Value = 1,
					Num = 3810,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 7,
				},
				{
					Value = 1,
					Num = 5310,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 7,
				},
				{
					Value = 1,
					Num = 5310,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 1,
				},
				{
					Value = 1,
					Num = 10310,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 1,
				},
				{
					Value = 1,
					Num = 10310,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 136,
				},
				{
					Value = 320051,
					Num = 92,
				},
			},
		},
	},
	DemandID = 410486,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id487] =
{
	Id = 487,
	Name = "订购芝士1",
	Desc = "需要一些芝士",
	Value = 321210,
	Active = true,
	Weight = 16575,
	PreGoal = 
	{
		300735,
		300856,
	},
	CloseGoal = 
	{
		300892,
	},
	GoodsId = 5001210,
	Priority = 1210516,
	Num = 24,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 24884,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 211,
				},
				{
					Value = 1,
					Num = 3784,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 211,
				},
				{
					Value = 1,
					Num = 3784,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 42,
				},
				{
					Value = 1,
					Num = 3884,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 42,
				},
				{
					Value = 1,
					Num = 3884,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 8,
				},
				{
					Value = 1,
					Num = 4884,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 8,
				},
				{
					Value = 1,
					Num = 4884,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 1,
				},
				{
					Value = 1,
					Num = 12384,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 1,
				},
				{
					Value = 1,
					Num = 12384,
				},
			},
		},
	},
	DemandID = 410487,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id488] =
{
	Id = 488,
	Name = "订购芝士1",
	Desc = "需要一些芝士",
	Value = 321210,
	Active = true,
	Weight = 17595,
	PreGoal = 
	{
		300735,
		300872,
	},
	CloseGoal = 
	{
		301216,
	},
	GoodsId = 5001210,
	Priority = 1210517,
	Num = 26,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 26957,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 229,
				},
				{
					Value = 1,
					Num = 4057,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 229,
				},
				{
					Value = 1,
					Num = 4057,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 45,
				},
				{
					Value = 1,
					Num = 4457,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 45,
				},
				{
					Value = 1,
					Num = 4457,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 9,
				},
				{
					Value = 1,
					Num = 4457,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 9,
				},
				{
					Value = 1,
					Num = 4457,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 1,
				},
				{
					Value = 1,
					Num = 14457,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 1,
				},
				{
					Value = 1,
					Num = 14457,
				},
			},
		},
	},
	DemandID = 410488,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id489] =
{
	Id = 489,
	Name = "订购芝士1",
	Desc = "需要一些芝士",
	Value = 321210,
	Active = true,
	Weight = 18870,
	PreGoal = 
	{
		300735,
		300892,
	},
	CloseGoal = 
	{
		301236,
	},
	GoodsId = 5001210,
	Priority = 1210518,
	Num = 28,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 29031,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 246,
				},
				{
					Value = 1,
					Num = 4431,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 246,
				},
				{
					Value = 1,
					Num = 4431,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 49,
				},
				{
					Value = 1,
					Num = 4531,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 49,
				},
				{
					Value = 1,
					Num = 4531,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 9,
				},
				{
					Value = 1,
					Num = 6531,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 9,
				},
				{
					Value = 1,
					Num = 6531,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 1,
				},
				{
					Value = 1,
					Num = 16531,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 1,
				},
				{
					Value = 1,
					Num = 16531,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 174,
				},
				{
					Value = 320051,
					Num = 116,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 34,
				},
				{
					Value = 320052,
					Num = 24,
				},
			},
		},
	},
	DemandID = 410489,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id490] =
{
	Id = 490,
	Name = "订购芝士1",
	Desc = "需要一些芝士",
	Value = 321210,
	Active = true,
	Weight = 20145,
	PreGoal = 
	{
		300735,
		301216,
	},
	CloseGoal = 
	{
		301260,
	},
	GoodsId = 5001210,
	Priority = 1210519,
	Num = 30,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 31105,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 264,
				},
				{
					Value = 1,
					Num = 4705,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 264,
				},
				{
					Value = 1,
					Num = 4705,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 52,
				},
				{
					Value = 1,
					Num = 5105,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 52,
				},
				{
					Value = 1,
					Num = 5105,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 10,
				},
				{
					Value = 1,
					Num = 6105,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 10,
				},
				{
					Value = 1,
					Num = 6105,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 2,
				},
				{
					Value = 1,
					Num = 6105,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 2,
				},
				{
					Value = 1,
					Num = 6105,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 186,
				},
				{
					Value = 320051,
					Num = 125,
				},
			},
		},
	},
	DemandID = 410490,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id491] =
{
	Id = 491,
	Name = "订购芝士1",
	Desc = "需要一些芝士",
	Value = 321210,
	Active = true,
	Weight = 21675,
	PreGoal = 
	{
		300735,
		301240,
	},
	CloseGoal = 
	{
		301284,
	},
	GoodsId = 5001210,
	Priority = 1210520,
	Num = 35,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 36289,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 308,
				},
				{
					Value = 1,
					Num = 5489,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 308,
				},
				{
					Value = 1,
					Num = 5489,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 61,
				},
				{
					Value = 1,
					Num = 5789,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 61,
				},
				{
					Value = 1,
					Num = 5789,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 12,
				},
				{
					Value = 1,
					Num = 6289,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 12,
				},
				{
					Value = 1,
					Num = 6289,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 2,
				},
				{
					Value = 1,
					Num = 11289,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 2,
				},
				{
					Value = 1,
					Num = 11289,
				},
			},
		},
	},
	DemandID = 410491,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id492] =
{
	Id = 492,
	Name = "订购红豆冰1",
	Desc = "需要一些红豆冰",
	Value = 321251,
	Active = true,
	Weight = 2700,
	PreGoal = 
	{
		300740,
		300413,
	},
	CloseGoal = 
	{
		300439,
	},
	GoodsId = 5101251,
	Priority = 1251301,
	Num = 6,
	RewardList = {
		{
			Weight = 0,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 20210,
				},
			},
		},
		{
			Weight = 80,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320001,
					Num = 2,
				},
				{
					Value = 1,
					Num = 2930,
				},
			},
		},
	},
	DemandID = 410492,
	DemandGroupList = {
		420003,
		420008,
		420009,
	},
}
DemandConfig[DemandID.Id493] =
{
	Id = 493,
	Name = "订购红豆冰1",
	Desc = "需要一些红豆冰",
	Value = 321251,
	Active = true,
	Weight = 2880,
	PreGoal = 
	{
		300740,
		300421,
	},
	CloseGoal = 
	{
		300446,
	},
	GoodsId = 5101251,
	Priority = 1251302,
	Num = 6,
	RewardList = {
		{
			Weight = 0,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 20210,
				},
			},
		},
		{
			Weight = 80,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320001,
					Num = 2,
				},
				{
					Value = 1,
					Num = 2930,
				},
			},
		},
	},
	DemandID = 410493,
	DemandGroupList = {
		420003,
		420008,
		420009,
	},
}
DemandConfig[DemandID.Id494] =
{
	Id = 494,
	Name = "订购红豆冰1",
	Desc = "需要一些红豆冰",
	Value = 321251,
	Active = true,
	Weight = 3060,
	PreGoal = 
	{
		300740,
		300428,
	},
	CloseGoal = 
	{
		300458,
	},
	GoodsId = 5101251,
	Priority = 1251303,
	Num = 6,
	RewardList = {
		{
			Weight = 0,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 20210,
				},
			},
		},
		{
			Weight = 80,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320001,
					Num = 2,
				},
				{
					Value = 1,
					Num = 2930,
				},
			},
		},
	},
	DemandID = 410494,
	DemandGroupList = {
		420003,
		420008,
		420009,
	},
}
DemandConfig[DemandID.Id495] =
{
	Id = 495,
	Name = "订购红豆冰1",
	Desc = "需要一些红豆冰",
	Value = 321251,
	Active = true,
	Weight = 3330,
	PreGoal = 
	{
		300740,
		300439,
	},
	CloseGoal = 
	{
		300470,
	},
	GoodsId = 5101251,
	Priority = 1251304,
	Num = 6,
	RewardList = {
		{
			Weight = 0,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 20210,
				},
			},
		},
		{
			Weight = 80,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320001,
					Num = 2,
				},
				{
					Value = 1,
					Num = 2930,
				},
			},
		},
	},
	DemandID = 410495,
	DemandGroupList = {
		420003,
		420008,
		420009,
	},
}
DemandConfig[DemandID.Id496] =
{
	Id = 496,
	Name = "订购红豆冰1",
	Desc = "需要一些红豆冰",
	Value = 321251,
	Active = true,
	Weight = 3600,
	PreGoal = 
	{
		300740,
		300450,
	},
	CloseGoal = 
	{
		300486,
	},
	GoodsId = 5101251,
	Priority = 1251305,
	Num = 6,
	RewardList = {
		{
			Weight = 0,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 20210,
				},
			},
		},
		{
			Weight = 80,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320001,
					Num = 2,
				},
				{
					Value = 1,
					Num = 2930,
				},
			},
		},
	},
	DemandID = 410496,
	DemandGroupList = {
		420003,
		420008,
		420009,
	},
}
DemandConfig[DemandID.Id497] =
{
	Id = 497,
	Name = "订购红豆冰1",
	Desc = "需要一些红豆冰",
	Value = 321251,
	Active = true,
	Weight = 3960,
	PreGoal = 
	{
		300740,
		300466,
	},
	CloseGoal = 
	{
		300804,
	},
	GoodsId = 5101251,
	Priority = 1251306,
	Num = 6,
	RewardList = {
		{
			Weight = 0,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 20210,
				},
			},
		},
		{
			Weight = 80,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320001,
					Num = 2,
				},
				{
					Value = 1,
					Num = 2930,
				},
			},
		},
	},
	DemandID = 410497,
	DemandGroupList = {
		420003,
		420008,
		420009,
	},
}
DemandConfig[DemandID.Id498] =
{
	Id = 498,
	Name = "订购红豆冰1",
	Desc = "需要一些红豆冰",
	Value = 321251,
	Active = true,
	Weight = 4320,
	PreGoal = 
	{
		300740,
		300482,
	},
	CloseGoal = 
	{
		300827,
	},
	GoodsId = 5101251,
	Priority = 1251307,
	Num = 8,
	RewardList = {
		{
			Weight = 0,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 26947,
				},
			},
		},
		{
			Weight = 80,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320001,
					Num = 2,
				},
				{
					Value = 1,
					Num = 9667,
				},
			},
		},
	},
	DemandID = 410498,
	DemandGroupList = {
		420003,
		420008,
		420009,
	},
}
DemandConfig[DemandID.Id499] =
{
	Id = 499,
	Name = "订购红豆冰1",
	Desc = "需要一些红豆冰",
	Value = 321251,
	Active = true,
	Weight = 4770,
	PreGoal = 
	{
		300740,
		300804,
	},
	CloseGoal = 
	{
		300848,
	},
	GoodsId = 5101251,
	Priority = 1251308,
	Num = 8,
	RewardList = {
		{
			Weight = 0,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 26947,
				},
			},
		},
		{
			Weight = 80,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320001,
					Num = 2,
				},
				{
					Value = 1,
					Num = 9667,
				},
			},
		},
	},
	DemandID = 410499,
	DemandGroupList = {
		420003,
		420008,
		420009,
	},
}
DemandConfig[DemandID.Id500] =
{
	Id = 500,
	Name = "订购红豆冰1",
	Desc = "需要一些红豆冰",
	Value = 321251,
	Active = true,
	Weight = 5220,
	PreGoal = 
	{
		300740,
		300827,
	},
	CloseGoal = 
	{
		300872,
	},
	GoodsId = 5101251,
	Priority = 1251309,
	Num = 9,
	RewardList = {
		{
			Weight = 0,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 30315,
				},
			},
		},
		{
			Weight = 80,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320001,
					Num = 3,
				},
				{
					Value = 1,
					Num = 4395,
				},
			},
		},
		{
			Weight = 60,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320002,
					Num = 1,
				},
				{
					Value = 1,
					Num = 4395,
				},
			},
		},
	},
	DemandID = 410500,
	DemandGroupList = {
		420003,
		420008,
		420009,
	},
}
