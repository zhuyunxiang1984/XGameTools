CatchFish_FishPoolConfig ={};
CatchFish_FishPoolID = 
{
	Id001 = 960001,
	Id002 = 960002,
	Id003 = 960003,
	Id004 = 960004,
	Id005 = 960005,
	Id006 = 960006,
	Id007 = 960007,
	Id008 = 960008,
	Id009 = 960009,
	Id010 = 960010,
	Id011 = 960011,
	Id012 = 960012,
	Id013 = 960013,
	Id014 = 960014,
	Id015 = 960015,
	Id016 = 960016,
	Id017 = 960017,
	Id018 = 960018,
	Id019 = 960019,
	Id020 = 960020,
	Id021 = 960021,
	Id022 = 960022,
	Id023 = 960023,
	Id024 = 960024,
	Id025 = 960025,
}
CatchFish_FishPoolConfig[CatchFish_FishPoolID.Id001] =
{
	Id = 1,
	Name = "小鱼塘",
	CostItem = {
		Id = 1,
		Num = 5000,
	},
	PassCheckCostItem = {
		Id = 1,
		Num = 2500,
	},
	BuffList = {
		Desc = "女队员亲和 +{Value1}%",
		Buff = {
			{
				Id = 100700,
				Value = 75,
			},
		},
	},
	Desc = "队员亲和、智力增加能量，最多2人",
	NumCap = 2,
	CatchPoint = 24,
	Type = 1,
	SuppleFish = false,
	RankList = {
		{
			ExtraPoint = 0,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 0,
				},
				{
					Value = 200008,
					Num = 0,
				},
			},
		},
		{
			ExtraPoint = 8,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 80,
				},
				{
					Value = 200008,
					Num = 48,
				},
			},
		},
		{
			ExtraPoint = 16,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 160,
				},
				{
					Value = 200008,
					Num = 96,
				},
			},
		},
		{
			ExtraPoint = 24,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 240,
				},
				{
					Value = 200008,
					Num = 144,
				},
			},
		},
	},
	ObstacleNode = "Obstacle1",
	Score1Star = 50,
	Score2Star = 100,
	Score3Star = 150,
	Data = 
	{
		-1,-1,0,0,0,0,-1,-1,-1,0,0,0,0,0,0,-1,0,0,2,0,0,0,0,0,0,0,0,0,0,2,0,0,0,0,0,0,0,0,0,0,0,0,2,0,0,0,0,0,-1,0,0,0,0,0,0,-1,-1,-1,0,0,0,0,-1,-1,
	},
	CatchQueue = 
	{
		5,
	},
	RewardList = {
		{
			Id = 327314,
			Num = 1,
		},
		{
			Id = 1,
			Num = 7500,
		},
	},
}
CatchFish_FishPoolConfig[CatchFish_FishPoolID.Id002] =
{
	Id = 2,
	Name = "鱼塘-十文字",
	CostItem = {
		Id = 1,
		Num = 7500,
	},
	PassCheckCostItem = {
		Id = 1,
		Num = 3750,
	},
	BuffList = {
		Desc = "男队员力气 +{Value1}%",
		Buff = {
			{
				Id = 100693,
				Value = 75,
			},
		},
	},
	Desc = "队员力气、技巧增加能量，最多2人",
	NumCap = 2,
	CatchPoint = 110,
	Type = 1,
	SuppleFish = false,
	RankList = {
		{
			ExtraPoint = 0,
			NeedAttribute = {
				{
					Value = 200007,
					Num = 0,
				},
				{
					Value = 200005,
					Num = 0,
				},
			},
		},
		{
			ExtraPoint = 8,
			NeedAttribute = {
				{
					Value = 200007,
					Num = 80,
				},
				{
					Value = 200005,
					Num = 48,
				},
			},
		},
		{
			ExtraPoint = 16,
			NeedAttribute = {
				{
					Value = 200007,
					Num = 160,
				},
				{
					Value = 200005,
					Num = 96,
				},
			},
		},
		{
			ExtraPoint = 24,
			NeedAttribute = {
				{
					Value = 200007,
					Num = 240,
				},
				{
					Value = 200005,
					Num = 144,
				},
			},
		},
		{
			ExtraPoint = 30,
			NeedAttribute = {
				{
					Value = 200007,
					Num = 320,
				},
				{
					Value = 200005,
					Num = 192,
				},
			},
		},
		{
			ExtraPoint = 35,
			NeedAttribute = {
				{
					Value = 200007,
					Num = 400,
				},
				{
					Value = 200005,
					Num = 240,
				},
			},
		},
		{
			ExtraPoint = 40,
			NeedAttribute = {
				{
					Value = 200007,
					Num = 500,
				},
				{
					Value = 200005,
					Num = 300,
				},
			},
		},
	},
	ObstacleNode = "Obstacle1",
	Score1Star = 400,
	Score2Star = 625,
	Score3Star = 850,
	Data = 
	{
		-1,-1,0,0,0,0,-1,-1,-1,0,0,2,0,0,0,-1,0,0,0,2,0,0,0,0,0,2,2,2,2,2,2,0,0,0,0,2,0,0,0,0,0,0,0,2,0,0,0,0,-1,0,0,2,0,0,0,-1,-1,-1,0,0,0,0,-1,-1,
	},
	CatchQueue = 
	{
		5,2,3,
	},
	RewardList = {
		{
			Id = 327314,
			Num = 1,
		},
		{
			Id = 1,
			Num = 11250,
		},
	},
}
CatchFish_FishPoolConfig[CatchFish_FishPoolID.Id003] =
{
	Id = 3,
	Name = "星星鱼塘",
	CostItem = {
		Id = 1,
		Num = 10000,
	},
	PassCheckCostItem = {
		Id = 1,
		Num = 5000,
	},
	BuffList = {
		Desc = "女队员亲和 +{Value1}%",
		Buff = {
			{
				Id = 100700,
				Value = 75,
			},
		},
	},
	Desc = "队员亲和、技巧增加能量，最多3人",
	NumCap = 3,
	CatchPoint = 60,
	Type = 1,
	SuppleFish = false,
	RankList = {
		{
			ExtraPoint = 0,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 0,
				},
				{
					Value = 200005,
					Num = 0,
				},
			},
		},
		{
			ExtraPoint = 8,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 80,
				},
				{
					Value = 200005,
					Num = 48,
				},
			},
		},
		{
			ExtraPoint = 16,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 160,
				},
				{
					Value = 200005,
					Num = 96,
				},
			},
		},
		{
			ExtraPoint = 24,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 240,
				},
				{
					Value = 200005,
					Num = 144,
				},
			},
		},
		{
			ExtraPoint = 30,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 320,
				},
				{
					Value = 200005,
					Num = 192,
				},
			},
		},
		{
			ExtraPoint = 35,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 400,
				},
				{
					Value = 200005,
					Num = 240,
				},
			},
		},
		{
			ExtraPoint = 40,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 500,
				},
				{
					Value = 200005,
					Num = 300,
				},
			},
		},
		{
			ExtraPoint = 45,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 600,
				},
				{
					Value = 200005,
					Num = 360,
				},
			},
		},
		{
			ExtraPoint = 50,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 700,
				},
				{
					Value = 200005,
					Num = 420,
				},
			},
		},
		{
			ExtraPoint = 55,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 800,
				},
				{
					Value = 200005,
					Num = 480,
				},
			},
		},
		{
			ExtraPoint = 60,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 900,
				},
				{
					Value = 200005,
					Num = 540,
				},
			},
		},
		{
			ExtraPoint = 65,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 1020,
				},
				{
					Value = 200005,
					Num = 612,
				},
			},
		},
	},
	ObstacleNode = "Obstacle1",
	Score1Star = 450,
	Score2Star = 600,
	Score3Star = 750,
	Data = 
	{
		-1,-1,0,0,0,0,-1,-1,-1,0,2,0,0,0,0,-1,0,2,2,2,0,0,0,0,0,0,2,0,0,0,0,0,0,0,0,0,0,2,0,0,0,0,0,0,2,2,2,0,-1,0,0,0,0,2,0,-1,-1,-1,0,0,0,0,-1,-1,
	},
	CatchQueue = 
	{
		5,4,
	},
	RewardList = {
		{
			Id = 327314,
			Num = 1,
		},
		{
			Id = 1,
			Num = 15000,
		},
	},
}
CatchFish_FishPoolConfig[CatchFish_FishPoolID.Id004] =
{
	Id = 4,
	Name = "密集恐惧症",
	CostItem = {
		Id = 1,
		Num = 12500,
	},
	PassCheckCostItem = {
		Id = 1,
		Num = 6250,
	},
	BuffList = {
		Desc = "女队员技巧 +{Value1}%",
		Buff = {
			{
				Id = 100699,
				Value = 75,
			},
		},
	},
	Desc = "队员技巧、智力增加能量，最多3人",
	NumCap = 3,
	CatchPoint = 110,
	Type = 1,
	SuppleFish = false,
	RankList = {
		{
			ExtraPoint = 0,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 0,
				},
				{
					Value = 200008,
					Num = 0,
				},
			},
		},
		{
			ExtraPoint = 8,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 80,
				},
				{
					Value = 200008,
					Num = 48,
				},
			},
		},
		{
			ExtraPoint = 16,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 160,
				},
				{
					Value = 200008,
					Num = 96,
				},
			},
		},
		{
			ExtraPoint = 24,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 240,
				},
				{
					Value = 200008,
					Num = 144,
				},
			},
		},
		{
			ExtraPoint = 30,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 320,
				},
				{
					Value = 200008,
					Num = 192,
				},
			},
		},
		{
			ExtraPoint = 35,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 400,
				},
				{
					Value = 200008,
					Num = 240,
				},
			},
		},
		{
			ExtraPoint = 40,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 500,
				},
				{
					Value = 200008,
					Num = 300,
				},
			},
		},
		{
			ExtraPoint = 45,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 600,
				},
				{
					Value = 200008,
					Num = 360,
				},
			},
		},
		{
			ExtraPoint = 50,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 700,
				},
				{
					Value = 200008,
					Num = 420,
				},
			},
		},
		{
			ExtraPoint = 55,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 800,
				},
				{
					Value = 200008,
					Num = 480,
				},
			},
		},
		{
			ExtraPoint = 60,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 900,
				},
				{
					Value = 200008,
					Num = 540,
				},
			},
		},
		{
			ExtraPoint = 65,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 1020,
				},
				{
					Value = 200008,
					Num = 612,
				},
			},
		},
	},
	ObstacleNode = "Obstacle1",
	Score1Star = 700,
	Score2Star = 950,
	Score3Star = 1200,
	Data = 
	{
		-1,-1,0,0,2,0,-1,-1,-1,0,2,2,0,0,0,-1,0,0,2,0,2,0,0,0,0,0,2,2,0,0,0,0,0,0,2,0,2,0,0,0,0,0,2,2,0,0,0,0,-1,0,2,0,2,0,0,-1,-1,-1,0,2,0,0,-1,-1,
	},
	CatchQueue = 
	{
		5,3,
	},
	RewardList = {
		{
			Id = 327314,
			Num = 1,
		},
		{
			Id = 1,
			Num = 18750,
		},
	},
}
CatchFish_FishPoolConfig[CatchFish_FishPoolID.Id005] =
{
	Id = 5,
	Name = "请向右走",
	CostItem = {
		Id = 1,
		Num = 15000,
	},
	PassCheckCostItem = {
		Id = 1,
		Num = 7500,
	},
	BuffList = {
		Desc = "男队员智力 +{Value1}%",
		Buff = {
			{
				Id = 100694,
				Value = 75,
			},
		},
	},
	Desc = "队员智力、亲和增加能量，最多4人",
	NumCap = 4,
	CatchPoint = 120,
	Type = 1,
	SuppleFish = false,
	RankList = {
		{
			ExtraPoint = 0,
			NeedAttribute = {
				{
					Value = 200008,
					Num = 0,
				},
				{
					Value = 200006,
					Num = 0,
				},
			},
		},
		{
			ExtraPoint = 8,
			NeedAttribute = {
				{
					Value = 200008,
					Num = 80,
				},
				{
					Value = 200006,
					Num = 48,
				},
			},
		},
		{
			ExtraPoint = 16,
			NeedAttribute = {
				{
					Value = 200008,
					Num = 160,
				},
				{
					Value = 200006,
					Num = 96,
				},
			},
		},
		{
			ExtraPoint = 24,
			NeedAttribute = {
				{
					Value = 200008,
					Num = 240,
				},
				{
					Value = 200006,
					Num = 144,
				},
			},
		},
		{
			ExtraPoint = 30,
			NeedAttribute = {
				{
					Value = 200008,
					Num = 320,
				},
				{
					Value = 200006,
					Num = 192,
				},
			},
		},
		{
			ExtraPoint = 35,
			NeedAttribute = {
				{
					Value = 200008,
					Num = 400,
				},
				{
					Value = 200006,
					Num = 240,
				},
			},
		},
		{
			ExtraPoint = 40,
			NeedAttribute = {
				{
					Value = 200008,
					Num = 500,
				},
				{
					Value = 200006,
					Num = 300,
				},
			},
		},
		{
			ExtraPoint = 45,
			NeedAttribute = {
				{
					Value = 200008,
					Num = 600,
				},
				{
					Value = 200006,
					Num = 360,
				},
			},
		},
		{
			ExtraPoint = 50,
			NeedAttribute = {
				{
					Value = 200008,
					Num = 700,
				},
				{
					Value = 200006,
					Num = 420,
				},
			},
		},
		{
			ExtraPoint = 55,
			NeedAttribute = {
				{
					Value = 200008,
					Num = 800,
				},
				{
					Value = 200006,
					Num = 480,
				},
			},
		},
		{
			ExtraPoint = 60,
			NeedAttribute = {
				{
					Value = 200008,
					Num = 900,
				},
				{
					Value = 200006,
					Num = 540,
				},
			},
		},
		{
			ExtraPoint = 65,
			NeedAttribute = {
				{
					Value = 200008,
					Num = 1020,
				},
				{
					Value = 200006,
					Num = 612,
				},
			},
		},
	},
	ObstacleNode = "Obstacle",
	Score1Star = 400,
	Score2Star = 580,
	Score3Star = 860,
	Data = 
	{
		0,0,0,0,0,0,0,0,0,0,0,0,2,0,0,0,0,0,0,0,2,2,0,0,0,2,2,2,2,2,2,0,0,0,0,0,2,2,0,0,0,0,0,0,2,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
	},
	CatchQueue = 
	{
		5,4,2,3,
	},
	RewardList = {
		{
			Id = 327314,
			Num = 1,
		},
		{
			Id = 1,
			Num = 22500,
		},
	},
}
CatchFish_FishPoolConfig[CatchFish_FishPoolID.Id006] =
{
	Id = 6,
	Name = "超级鱼塘！",
	CostItem = {
		Id = 327312,
		Num = 10,
	},
	PassCheckCostItem = {
		Id = 327312,
		Num = 5,
	},
	BuffList = {
		Desc = "男队员技巧 +{Value1}%",
		Buff = {
			{
				Id = 100691,
				Value = 75,
			},
		},
	},
	Desc = "队员技巧、力气增加能量，最多4人",
	NumCap = 4,
	CatchPoint = 150,
	Type = 1,
	SuppleFish = true,
	RankList = {
		{
			ExtraPoint = 0,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 0,
				},
				{
					Value = 200007,
					Num = 0,
				},
			},
		},
		{
			ExtraPoint = 8,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 80,
				},
				{
					Value = 200007,
					Num = 48,
				},
			},
		},
		{
			ExtraPoint = 16,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 160,
				},
				{
					Value = 200007,
					Num = 96,
				},
			},
		},
		{
			ExtraPoint = 24,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 240,
				},
				{
					Value = 200007,
					Num = 144,
				},
			},
		},
		{
			ExtraPoint = 30,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 320,
				},
				{
					Value = 200007,
					Num = 192,
				},
			},
		},
		{
			ExtraPoint = 35,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 400,
				},
				{
					Value = 200007,
					Num = 240,
				},
			},
		},
		{
			ExtraPoint = 40,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 500,
				},
				{
					Value = 200007,
					Num = 300,
				},
			},
		},
		{
			ExtraPoint = 45,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 600,
				},
				{
					Value = 200007,
					Num = 360,
				},
			},
		},
		{
			ExtraPoint = 50,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 700,
				},
				{
					Value = 200007,
					Num = 420,
				},
			},
		},
		{
			ExtraPoint = 55,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 800,
				},
				{
					Value = 200007,
					Num = 480,
				},
			},
		},
		{
			ExtraPoint = 60,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 900,
				},
				{
					Value = 200007,
					Num = 540,
				},
			},
		},
		{
			ExtraPoint = 65,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 1020,
				},
				{
					Value = 200007,
					Num = 612,
				},
			},
		},
	},
	ObstacleNode = "Obstacle",
	Score1Star = 600,
	Score2Star = 800,
	Score3Star = 1100,
	Data = 
	{
		0,0,0,0,0,0,0,0,0,0,2,2,2,2,0,0,0,0,2,0,0,2,0,0,0,0,0,2,0,0,0,0,0,0,0,0,2,0,0,0,0,0,2,0,0,2,0,0,0,0,2,2,2,2,0,0,0,0,0,0,0,0,0,0,
	},
	CatchQueue = 
	{
		5,4,2,3,
	},
	RewardList = {
		{
			Id = 327314,
			Num = 2,
		},
		{
			Id = 1,
			Num = 25000,
		},
	},
}
CatchFish_FishPoolConfig[CatchFish_FishPoolID.Id007] =
{
	Id = 7,
	Name = "加强型鱼塘",
	CostItem = {
		Id = 327312,
		Num = 10,
	},
	PassCheckCostItem = {
		Id = 327312,
		Num = 5,
	},
	BuffList = {
		Desc = "女队员力气 +{Value1}%",
		Buff = {
			{
				Id = 100701,
				Value = 75,
			},
		},
	},
	Desc = "队员力气、亲和增加能量，最多5人",
	NumCap = 5,
	CatchPoint = 80,
	Type = 1,
	SuppleFish = true,
	RankList = {
		{
			ExtraPoint = 0,
			NeedAttribute = {
				{
					Value = 200007,
					Num = 0,
				},
				{
					Value = 200006,
					Num = 0,
				},
			},
		},
		{
			ExtraPoint = 8,
			NeedAttribute = {
				{
					Value = 200007,
					Num = 80,
				},
				{
					Value = 200006,
					Num = 48,
				},
			},
		},
		{
			ExtraPoint = 16,
			NeedAttribute = {
				{
					Value = 200007,
					Num = 160,
				},
				{
					Value = 200006,
					Num = 96,
				},
			},
		},
		{
			ExtraPoint = 24,
			NeedAttribute = {
				{
					Value = 200007,
					Num = 240,
				},
				{
					Value = 200006,
					Num = 144,
				},
			},
		},
		{
			ExtraPoint = 30,
			NeedAttribute = {
				{
					Value = 200007,
					Num = 320,
				},
				{
					Value = 200006,
					Num = 192,
				},
			},
		},
		{
			ExtraPoint = 35,
			NeedAttribute = {
				{
					Value = 200007,
					Num = 400,
				},
				{
					Value = 200006,
					Num = 240,
				},
			},
		},
		{
			ExtraPoint = 40,
			NeedAttribute = {
				{
					Value = 200007,
					Num = 500,
				},
				{
					Value = 200006,
					Num = 300,
				},
			},
		},
		{
			ExtraPoint = 45,
			NeedAttribute = {
				{
					Value = 200007,
					Num = 600,
				},
				{
					Value = 200006,
					Num = 360,
				},
			},
		},
		{
			ExtraPoint = 50,
			NeedAttribute = {
				{
					Value = 200007,
					Num = 700,
				},
				{
					Value = 200006,
					Num = 420,
				},
			},
		},
		{
			ExtraPoint = 55,
			NeedAttribute = {
				{
					Value = 200007,
					Num = 800,
				},
				{
					Value = 200006,
					Num = 480,
				},
			},
		},
		{
			ExtraPoint = 60,
			NeedAttribute = {
				{
					Value = 200007,
					Num = 900,
				},
				{
					Value = 200006,
					Num = 540,
				},
			},
		},
		{
			ExtraPoint = 65,
			NeedAttribute = {
				{
					Value = 200007,
					Num = 1020,
				},
				{
					Value = 200006,
					Num = 612,
				},
			},
		},
		{
			ExtraPoint = 70,
			NeedAttribute = {
				{
					Value = 200007,
					Num = 1140,
				},
				{
					Value = 200006,
					Num = 684,
				},
			},
		},
		{
			ExtraPoint = 75,
			NeedAttribute = {
				{
					Value = 200007,
					Num = 1260,
				},
				{
					Value = 200006,
					Num = 756,
				},
			},
		},
		{
			ExtraPoint = 80,
			NeedAttribute = {
				{
					Value = 200007,
					Num = 1380,
				},
				{
					Value = 200006,
					Num = 828,
				},
			},
		},
		{
			ExtraPoint = 85,
			NeedAttribute = {
				{
					Value = 200007,
					Num = 1500,
				},
				{
					Value = 200006,
					Num = 900,
				},
			},
		},
		{
			ExtraPoint = 90,
			NeedAttribute = {
				{
					Value = 200007,
					Num = 1640,
				},
				{
					Value = 200006,
					Num = 984,
				},
			},
		},
	},
	ObstacleNode = "Obstacle1",
	Score1Star = 600,
	Score2Star = 800,
	Score3Star = 1000,
	Data = 
	{
		-1,-1,0,0,0,0,-1,-1,-1,0,2,0,0,0,0,-1,0,2,3,2,0,0,0,0,0,0,2,0,0,0,0,0,0,0,0,0,0,2,0,0,0,0,0,0,2,3,2,0,-1,0,0,0,0,2,0,-1,-1,-1,0,0,0,0,-1,-1,
	},
	CatchQueue = 
	{
		5,4,2,3,
	},
	RewardList = {
		{
			Id = 327314,
			Num = 2,
		},
		{
			Id = 1,
			Num = 25000,
		},
	},
}
CatchFish_FishPoolConfig[CatchFish_FishPoolID.Id008] =
{
	Id = 8,
	Name = "鱼鳞阵",
	CostItem = {
		Id = 327312,
		Num = 10,
	},
	PassCheckCostItem = {
		Id = 327312,
		Num = 5,
	},
	BuffList = {
		Desc = "女队员技巧 +{Value1}%",
		Buff = {
			{
				Id = 100699,
				Value = 75,
			},
		},
	},
	Desc = "队员技巧、亲和增加能量，最多5人",
	NumCap = 5,
	CatchPoint = 100,
	Type = 1,
	SuppleFish = true,
	RankList = {
		{
			ExtraPoint = 0,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 0,
				},
				{
					Value = 200006,
					Num = 0,
				},
			},
		},
		{
			ExtraPoint = 8,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 80,
				},
				{
					Value = 200006,
					Num = 48,
				},
			},
		},
		{
			ExtraPoint = 16,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 160,
				},
				{
					Value = 200006,
					Num = 96,
				},
			},
		},
		{
			ExtraPoint = 24,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 240,
				},
				{
					Value = 200006,
					Num = 144,
				},
			},
		},
		{
			ExtraPoint = 30,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 320,
				},
				{
					Value = 200006,
					Num = 192,
				},
			},
		},
		{
			ExtraPoint = 35,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 400,
				},
				{
					Value = 200006,
					Num = 240,
				},
			},
		},
		{
			ExtraPoint = 40,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 500,
				},
				{
					Value = 200006,
					Num = 300,
				},
			},
		},
		{
			ExtraPoint = 45,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 600,
				},
				{
					Value = 200006,
					Num = 360,
				},
			},
		},
		{
			ExtraPoint = 50,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 700,
				},
				{
					Value = 200006,
					Num = 420,
				},
			},
		},
		{
			ExtraPoint = 55,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 800,
				},
				{
					Value = 200006,
					Num = 480,
				},
			},
		},
		{
			ExtraPoint = 60,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 900,
				},
				{
					Value = 200006,
					Num = 540,
				},
			},
		},
		{
			ExtraPoint = 65,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 1020,
				},
				{
					Value = 200006,
					Num = 612,
				},
			},
		},
		{
			ExtraPoint = 70,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 1140,
				},
				{
					Value = 200006,
					Num = 684,
				},
			},
		},
		{
			ExtraPoint = 75,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 1260,
				},
				{
					Value = 200006,
					Num = 756,
				},
			},
		},
		{
			ExtraPoint = 80,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 1380,
				},
				{
					Value = 200006,
					Num = 828,
				},
			},
		},
		{
			ExtraPoint = 85,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 1500,
				},
				{
					Value = 200006,
					Num = 900,
				},
			},
		},
		{
			ExtraPoint = 90,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 1640,
				},
				{
					Value = 200006,
					Num = 984,
				},
			},
		},
	},
	ObstacleNode = "Obstacle",
	Score1Star = 500,
	Score2Star = 800,
	Score3Star = 1100,
	Data = 
	{
		0,0,0,0,0,0,0,0,0,2,0,2,0,0,0,0,0,0,2,0,2,0,0,0,0,2,0,3,0,2,0,0,0,0,2,0,3,0,2,0,0,0,0,2,0,2,0,0,0,0,0,0,2,0,2,0,0,0,0,0,0,0,0,0,
	},
	CatchQueue = 
	{
		5,4,2,3,
	},
	RewardList = {
		{
			Id = 327314,
			Num = 2,
		},
		{
			Id = 1,
			Num = 25000,
		},
	},
}
CatchFish_FishPoolConfig[CatchFish_FishPoolID.Id009] =
{
	Id = 9,
	Name = "古代铜币",
	CostItem = {
		Id = 327312,
		Num = 10,
	},
	PassCheckCostItem = {
		Id = 327312,
		Num = 5,
	},
	BuffList = {
		Desc = "男队员智力 +{Value1}%",
		Buff = {
			{
				Id = 100694,
				Value = 75,
			},
		},
	},
	Desc = "队员智力、技巧增加能量，最多6人",
	NumCap = 6,
	CatchPoint = 130,
	Type = 1,
	SuppleFish = true,
	RankList = {
		{
			ExtraPoint = 0,
			NeedAttribute = {
				{
					Value = 200008,
					Num = 0,
				},
				{
					Value = 200005,
					Num = 0,
				},
			},
		},
		{
			ExtraPoint = 8,
			NeedAttribute = {
				{
					Value = 200008,
					Num = 80,
				},
				{
					Value = 200005,
					Num = 48,
				},
			},
		},
		{
			ExtraPoint = 16,
			NeedAttribute = {
				{
					Value = 200008,
					Num = 160,
				},
				{
					Value = 200005,
					Num = 96,
				},
			},
		},
		{
			ExtraPoint = 24,
			NeedAttribute = {
				{
					Value = 200008,
					Num = 240,
				},
				{
					Value = 200005,
					Num = 144,
				},
			},
		},
		{
			ExtraPoint = 30,
			NeedAttribute = {
				{
					Value = 200008,
					Num = 320,
				},
				{
					Value = 200005,
					Num = 192,
				},
			},
		},
		{
			ExtraPoint = 35,
			NeedAttribute = {
				{
					Value = 200008,
					Num = 400,
				},
				{
					Value = 200005,
					Num = 240,
				},
			},
		},
		{
			ExtraPoint = 40,
			NeedAttribute = {
				{
					Value = 200008,
					Num = 500,
				},
				{
					Value = 200005,
					Num = 300,
				},
			},
		},
		{
			ExtraPoint = 45,
			NeedAttribute = {
				{
					Value = 200008,
					Num = 600,
				},
				{
					Value = 200005,
					Num = 360,
				},
			},
		},
		{
			ExtraPoint = 50,
			NeedAttribute = {
				{
					Value = 200008,
					Num = 700,
				},
				{
					Value = 200005,
					Num = 420,
				},
			},
		},
		{
			ExtraPoint = 55,
			NeedAttribute = {
				{
					Value = 200008,
					Num = 800,
				},
				{
					Value = 200005,
					Num = 480,
				},
			},
		},
		{
			ExtraPoint = 60,
			NeedAttribute = {
				{
					Value = 200008,
					Num = 900,
				},
				{
					Value = 200005,
					Num = 540,
				},
			},
		},
		{
			ExtraPoint = 65,
			NeedAttribute = {
				{
					Value = 200008,
					Num = 1020,
				},
				{
					Value = 200005,
					Num = 612,
				},
			},
		},
		{
			ExtraPoint = 70,
			NeedAttribute = {
				{
					Value = 200008,
					Num = 1140,
				},
				{
					Value = 200005,
					Num = 684,
				},
			},
		},
		{
			ExtraPoint = 75,
			NeedAttribute = {
				{
					Value = 200008,
					Num = 1260,
				},
				{
					Value = 200005,
					Num = 756,
				},
			},
		},
		{
			ExtraPoint = 80,
			NeedAttribute = {
				{
					Value = 200008,
					Num = 1380,
				},
				{
					Value = 200005,
					Num = 828,
				},
			},
		},
		{
			ExtraPoint = 85,
			NeedAttribute = {
				{
					Value = 200008,
					Num = 1500,
				},
				{
					Value = 200005,
					Num = 900,
				},
			},
		},
		{
			ExtraPoint = 90,
			NeedAttribute = {
				{
					Value = 200008,
					Num = 1640,
				},
				{
					Value = 200005,
					Num = 984,
				},
			},
		},
	},
	ObstacleNode = "Obstacle",
	Score1Star = 700,
	Score2Star = 1000,
	Score3Star = 1300,
	Data = 
	{
		0,0,0,0,0,0,0,0,0,2,0,0,0,0,2,0,0,0,2,2,2,2,0,0,0,0,2,0,0,2,0,0,0,0,2,0,0,2,0,0,0,0,2,2,2,2,0,0,0,2,0,0,0,0,2,0,0,0,0,0,0,0,0,0,
	},
	CatchQueue = 
	{
		5,4,2,3,
	},
	RewardList = {
		{
			Id = 327314,
			Num = 2,
		},
		{
			Id = 1,
			Num = 25000,
		},
	},
}
CatchFish_FishPoolConfig[CatchFish_FishPoolID.Id010] =
{
	Id = 10,
	Name = "轰炸机",
	CostItem = {
		Id = 327312,
		Num = 10,
	},
	PassCheckCostItem = {
		Id = 327312,
		Num = 5,
	},
	BuffList = {
		Desc = "男队员智力 +{Value1}%",
		Buff = {
			{
				Id = 100694,
				Value = 75,
			},
		},
	},
	Desc = "队员智力、力气增加能量，最多6人",
	NumCap = 6,
	CatchPoint = 150,
	Type = 1,
	SuppleFish = true,
	RankList = {
		{
			ExtraPoint = 0,
			NeedAttribute = {
				{
					Value = 200008,
					Num = 0,
				},
				{
					Value = 200007,
					Num = 0,
				},
			},
		},
		{
			ExtraPoint = 8,
			NeedAttribute = {
				{
					Value = 200008,
					Num = 80,
				},
				{
					Value = 200007,
					Num = 48,
				},
			},
		},
		{
			ExtraPoint = 16,
			NeedAttribute = {
				{
					Value = 200008,
					Num = 160,
				},
				{
					Value = 200007,
					Num = 96,
				},
			},
		},
		{
			ExtraPoint = 24,
			NeedAttribute = {
				{
					Value = 200008,
					Num = 240,
				},
				{
					Value = 200007,
					Num = 144,
				},
			},
		},
		{
			ExtraPoint = 30,
			NeedAttribute = {
				{
					Value = 200008,
					Num = 320,
				},
				{
					Value = 200007,
					Num = 192,
				},
			},
		},
		{
			ExtraPoint = 35,
			NeedAttribute = {
				{
					Value = 200008,
					Num = 400,
				},
				{
					Value = 200007,
					Num = 240,
				},
			},
		},
		{
			ExtraPoint = 40,
			NeedAttribute = {
				{
					Value = 200008,
					Num = 500,
				},
				{
					Value = 200007,
					Num = 300,
				},
			},
		},
		{
			ExtraPoint = 45,
			NeedAttribute = {
				{
					Value = 200008,
					Num = 600,
				},
				{
					Value = 200007,
					Num = 360,
				},
			},
		},
		{
			ExtraPoint = 50,
			NeedAttribute = {
				{
					Value = 200008,
					Num = 700,
				},
				{
					Value = 200007,
					Num = 420,
				},
			},
		},
		{
			ExtraPoint = 55,
			NeedAttribute = {
				{
					Value = 200008,
					Num = 800,
				},
				{
					Value = 200007,
					Num = 480,
				},
			},
		},
		{
			ExtraPoint = 60,
			NeedAttribute = {
				{
					Value = 200008,
					Num = 900,
				},
				{
					Value = 200007,
					Num = 540,
				},
			},
		},
		{
			ExtraPoint = 65,
			NeedAttribute = {
				{
					Value = 200008,
					Num = 1020,
				},
				{
					Value = 200007,
					Num = 612,
				},
			},
		},
		{
			ExtraPoint = 70,
			NeedAttribute = {
				{
					Value = 200008,
					Num = 1140,
				},
				{
					Value = 200007,
					Num = 684,
				},
			},
		},
		{
			ExtraPoint = 75,
			NeedAttribute = {
				{
					Value = 200008,
					Num = 1260,
				},
				{
					Value = 200007,
					Num = 756,
				},
			},
		},
		{
			ExtraPoint = 80,
			NeedAttribute = {
				{
					Value = 200008,
					Num = 1380,
				},
				{
					Value = 200007,
					Num = 828,
				},
			},
		},
		{
			ExtraPoint = 85,
			NeedAttribute = {
				{
					Value = 200008,
					Num = 1500,
				},
				{
					Value = 200007,
					Num = 900,
				},
			},
		},
		{
			ExtraPoint = 90,
			NeedAttribute = {
				{
					Value = 200008,
					Num = 1640,
				},
				{
					Value = 200007,
					Num = 984,
				},
			},
		},
	},
	ObstacleNode = "Obstacle",
	Score1Star = 800,
	Score2Star = 1100,
	Score3Star = 1400,
	Data = 
	{
		0,0,0,0,0,0,0,0,0,0,0,2,0,0,0,0,0,2,0,2,0,2,0,0,2,2,2,3,2,2,2,0,0,0,0,2,0,0,0,0,0,0,0,2,0,0,0,0,0,0,2,2,2,0,0,0,0,0,0,0,0,0,0,0,
	},
	CatchQueue = 
	{
		5,4,2,3,
	},
	RewardList = {
		{
			Id = 327314,
			Num = 2,
		},
		{
			Id = 1,
			Num = 25000,
		},
	},
}
CatchFish_FishPoolConfig[CatchFish_FishPoolID.Id011] =
{
	Id = 11,
	Name = "GO!GO!GO!",
	CostItem = {
		Id = 327312,
		Num = 10,
	},
	PassCheckCostItem = {
		Id = 327312,
		Num = 5,
	},
	BuffList = {
		Desc = "女队员亲和 +{Value1}%",
		Buff = {
			{
				Id = 100700,
				Value = 75,
			},
		},
	},
	Desc = "队员亲和、力气增加能量，最多6人",
	NumCap = 6,
	CatchPoint = 150,
	Type = 1,
	SuppleFish = true,
	RankList = {
		{
			ExtraPoint = 0,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 0,
				},
				{
					Value = 200007,
					Num = 0,
				},
			},
		},
		{
			ExtraPoint = 8,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 80,
				},
				{
					Value = 200007,
					Num = 48,
				},
			},
		},
		{
			ExtraPoint = 16,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 160,
				},
				{
					Value = 200007,
					Num = 96,
				},
			},
		},
		{
			ExtraPoint = 24,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 240,
				},
				{
					Value = 200007,
					Num = 144,
				},
			},
		},
		{
			ExtraPoint = 30,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 320,
				},
				{
					Value = 200007,
					Num = 192,
				},
			},
		},
		{
			ExtraPoint = 35,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 400,
				},
				{
					Value = 200007,
					Num = 240,
				},
			},
		},
		{
			ExtraPoint = 40,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 500,
				},
				{
					Value = 200007,
					Num = 300,
				},
			},
		},
		{
			ExtraPoint = 45,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 600,
				},
				{
					Value = 200007,
					Num = 360,
				},
			},
		},
		{
			ExtraPoint = 50,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 700,
				},
				{
					Value = 200007,
					Num = 420,
				},
			},
		},
		{
			ExtraPoint = 55,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 800,
				},
				{
					Value = 200007,
					Num = 480,
				},
			},
		},
		{
			ExtraPoint = 60,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 900,
				},
				{
					Value = 200007,
					Num = 540,
				},
			},
		},
		{
			ExtraPoint = 65,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 1020,
				},
				{
					Value = 200007,
					Num = 612,
				},
			},
		},
		{
			ExtraPoint = 70,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 1140,
				},
				{
					Value = 200007,
					Num = 684,
				},
			},
		},
		{
			ExtraPoint = 75,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 1260,
				},
				{
					Value = 200007,
					Num = 756,
				},
			},
		},
		{
			ExtraPoint = 80,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 1380,
				},
				{
					Value = 200007,
					Num = 828,
				},
			},
		},
		{
			ExtraPoint = 85,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 1500,
				},
				{
					Value = 200007,
					Num = 900,
				},
			},
		},
		{
			ExtraPoint = 90,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 1640,
				},
				{
					Value = 200007,
					Num = 984,
				},
			},
		},
		{
			ExtraPoint = 95,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 1780,
				},
				{
					Value = 200007,
					Num = 1068,
				},
			},
		},
		{
			ExtraPoint = 100,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 1920,
				},
				{
					Value = 200007,
					Num = 1152,
				},
			},
		},
		{
			ExtraPoint = 105,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 2060,
				},
				{
					Value = 200007,
					Num = 1236,
				},
			},
		},
		{
			ExtraPoint = 110,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 2200,
				},
				{
					Value = 200007,
					Num = 1320,
				},
			},
		},
		{
			ExtraPoint = 115,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 2360,
				},
				{
					Value = 200007,
					Num = 1416,
				},
			},
		},
	},
	ObstacleNode = "Obstacle",
	Score1Star = 800,
	Score2Star = 1300,
	Score3Star = 1800,
	Data = 
	{
		0,0,0,0,0,0,0,0,0,0,2,2,2,2,0,0,0,0,2,0,0,3,0,0,0,0,2,0,0,0,0,0,0,0,2,0,2,2,0,0,0,0,2,0,0,2,0,0,0,0,2,2,2,2,0,0,0,0,0,0,0,0,0,0,
	},
	CatchQueue = 
	{
		5,4,2,3,
	},
	RewardList = {
		{
			Id = 327314,
			Num = 3,
		},
		{
			Id = 1,
			Num = 25000,
		},
	},
}
CatchFish_FishPoolConfig[CatchFish_FishPoolID.Id012] =
{
	Id = 12,
	Name = "全捞完？",
	CostItem = {
		Id = 327312,
		Num = 10,
	},
	PassCheckCostItem = {
		Id = 327312,
		Num = 5,
	},
	BuffList = {
		Desc = "女队员力气 +{Value1}%",
		Buff = {
			{
				Id = 100701,
				Value = 75,
			},
		},
	},
	Desc = "队员力气、智力增加能量，最多7人",
	NumCap = 7,
	CatchPoint = 150,
	Type = 1,
	SuppleFish = false,
	RankList = {
		{
			ExtraPoint = 0,
			NeedAttribute = {
				{
					Value = 200007,
					Num = 0,
				},
				{
					Value = 200008,
					Num = 0,
				},
			},
		},
		{
			ExtraPoint = 8,
			NeedAttribute = {
				{
					Value = 200007,
					Num = 80,
				},
				{
					Value = 200008,
					Num = 48,
				},
			},
		},
		{
			ExtraPoint = 16,
			NeedAttribute = {
				{
					Value = 200007,
					Num = 160,
				},
				{
					Value = 200008,
					Num = 96,
				},
			},
		},
		{
			ExtraPoint = 24,
			NeedAttribute = {
				{
					Value = 200007,
					Num = 240,
				},
				{
					Value = 200008,
					Num = 144,
				},
			},
		},
		{
			ExtraPoint = 30,
			NeedAttribute = {
				{
					Value = 200007,
					Num = 320,
				},
				{
					Value = 200008,
					Num = 192,
				},
			},
		},
		{
			ExtraPoint = 35,
			NeedAttribute = {
				{
					Value = 200007,
					Num = 400,
				},
				{
					Value = 200008,
					Num = 240,
				},
			},
		},
		{
			ExtraPoint = 40,
			NeedAttribute = {
				{
					Value = 200007,
					Num = 500,
				},
				{
					Value = 200008,
					Num = 300,
				},
			},
		},
		{
			ExtraPoint = 45,
			NeedAttribute = {
				{
					Value = 200007,
					Num = 600,
				},
				{
					Value = 200008,
					Num = 360,
				},
			},
		},
		{
			ExtraPoint = 50,
			NeedAttribute = {
				{
					Value = 200007,
					Num = 700,
				},
				{
					Value = 200008,
					Num = 420,
				},
			},
		},
		{
			ExtraPoint = 55,
			NeedAttribute = {
				{
					Value = 200007,
					Num = 800,
				},
				{
					Value = 200008,
					Num = 480,
				},
			},
		},
		{
			ExtraPoint = 60,
			NeedAttribute = {
				{
					Value = 200007,
					Num = 900,
				},
				{
					Value = 200008,
					Num = 540,
				},
			},
		},
		{
			ExtraPoint = 65,
			NeedAttribute = {
				{
					Value = 200007,
					Num = 1020,
				},
				{
					Value = 200008,
					Num = 612,
				},
			},
		},
		{
			ExtraPoint = 70,
			NeedAttribute = {
				{
					Value = 200007,
					Num = 1140,
				},
				{
					Value = 200008,
					Num = 684,
				},
			},
		},
		{
			ExtraPoint = 75,
			NeedAttribute = {
				{
					Value = 200007,
					Num = 1260,
				},
				{
					Value = 200008,
					Num = 756,
				},
			},
		},
		{
			ExtraPoint = 80,
			NeedAttribute = {
				{
					Value = 200007,
					Num = 1380,
				},
				{
					Value = 200008,
					Num = 828,
				},
			},
		},
		{
			ExtraPoint = 85,
			NeedAttribute = {
				{
					Value = 200007,
					Num = 1500,
				},
				{
					Value = 200008,
					Num = 900,
				},
			},
		},
		{
			ExtraPoint = 90,
			NeedAttribute = {
				{
					Value = 200007,
					Num = 1640,
				},
				{
					Value = 200008,
					Num = 984,
				},
			},
		},
		{
			ExtraPoint = 95,
			NeedAttribute = {
				{
					Value = 200007,
					Num = 1780,
				},
				{
					Value = 200008,
					Num = 1068,
				},
			},
		},
		{
			ExtraPoint = 100,
			NeedAttribute = {
				{
					Value = 200007,
					Num = 1920,
				},
				{
					Value = 200008,
					Num = 1152,
				},
			},
		},
		{
			ExtraPoint = 105,
			NeedAttribute = {
				{
					Value = 200007,
					Num = 2060,
				},
				{
					Value = 200008,
					Num = 1236,
				},
			},
		},
		{
			ExtraPoint = 110,
			NeedAttribute = {
				{
					Value = 200007,
					Num = 2200,
				},
				{
					Value = 200008,
					Num = 1320,
				},
			},
		},
		{
			ExtraPoint = 115,
			NeedAttribute = {
				{
					Value = 200007,
					Num = 2360,
				},
				{
					Value = 200008,
					Num = 1416,
				},
			},
		},
	},
	ObstacleNode = "Obstacle1",
	Score1Star = 1200,
	Score2Star = 1400,
	Score3Star = 1600,
	Data = 
	{
		-1,-1,0,0,0,0,-1,-1,-1,0,0,2,2,0,0,-1,0,0,2,2,2,2,0,0,0,2,2,2,2,2,2,0,0,2,2,2,2,2,2,0,0,0,2,2,2,2,0,0,-1,0,0,2,2,0,0,-1,-1,-1,0,0,0,0,-1,-1,
	},
	CatchQueue = 
	{
		5,4,
	},
	RewardList = {
		{
			Id = 327314,
			Num = 3,
		},
		{
			Id = 1,
			Num = 25000,
		},
	},
}
CatchFish_FishPoolConfig[CatchFish_FishPoolID.Id013] =
{
	Id = 13,
	Name = "哇！蝴蝶",
	CostItem = {
		Id = 327312,
		Num = 10,
	},
	PassCheckCostItem = {
		Id = 327312,
		Num = 5,
	},
	BuffList = {
		Desc = "男队员亲和 +{Value1}%",
		Buff = {
			{
				Id = 100692,
				Value = 75,
			},
		},
	},
	Desc = "队员亲和、技巧增加能量，最多7人",
	NumCap = 7,
	CatchPoint = 130,
	Type = 1,
	SuppleFish = true,
	RankList = {
		{
			ExtraPoint = 0,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 0,
				},
				{
					Value = 200005,
					Num = 0,
				},
			},
		},
		{
			ExtraPoint = 8,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 80,
				},
				{
					Value = 200005,
					Num = 48,
				},
			},
		},
		{
			ExtraPoint = 16,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 160,
				},
				{
					Value = 200005,
					Num = 96,
				},
			},
		},
		{
			ExtraPoint = 24,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 240,
				},
				{
					Value = 200005,
					Num = 144,
				},
			},
		},
		{
			ExtraPoint = 30,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 320,
				},
				{
					Value = 200005,
					Num = 192,
				},
			},
		},
		{
			ExtraPoint = 35,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 400,
				},
				{
					Value = 200005,
					Num = 240,
				},
			},
		},
		{
			ExtraPoint = 40,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 500,
				},
				{
					Value = 200005,
					Num = 300,
				},
			},
		},
		{
			ExtraPoint = 45,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 600,
				},
				{
					Value = 200005,
					Num = 360,
				},
			},
		},
		{
			ExtraPoint = 50,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 700,
				},
				{
					Value = 200005,
					Num = 420,
				},
			},
		},
		{
			ExtraPoint = 55,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 800,
				},
				{
					Value = 200005,
					Num = 480,
				},
			},
		},
		{
			ExtraPoint = 60,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 900,
				},
				{
					Value = 200005,
					Num = 540,
				},
			},
		},
		{
			ExtraPoint = 65,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 1020,
				},
				{
					Value = 200005,
					Num = 612,
				},
			},
		},
		{
			ExtraPoint = 70,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 1140,
				},
				{
					Value = 200005,
					Num = 684,
				},
			},
		},
		{
			ExtraPoint = 75,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 1260,
				},
				{
					Value = 200005,
					Num = 756,
				},
			},
		},
		{
			ExtraPoint = 80,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 1380,
				},
				{
					Value = 200005,
					Num = 828,
				},
			},
		},
		{
			ExtraPoint = 85,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 1500,
				},
				{
					Value = 200005,
					Num = 900,
				},
			},
		},
		{
			ExtraPoint = 90,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 1640,
				},
				{
					Value = 200005,
					Num = 984,
				},
			},
		},
		{
			ExtraPoint = 95,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 1780,
				},
				{
					Value = 200005,
					Num = 1068,
				},
			},
		},
		{
			ExtraPoint = 100,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 1920,
				},
				{
					Value = 200005,
					Num = 1152,
				},
			},
		},
		{
			ExtraPoint = 105,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 2060,
				},
				{
					Value = 200005,
					Num = 1236,
				},
			},
		},
		{
			ExtraPoint = 110,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 2200,
				},
				{
					Value = 200005,
					Num = 1320,
				},
			},
		},
		{
			ExtraPoint = 115,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 2360,
				},
				{
					Value = 200005,
					Num = 1416,
				},
			},
		},
	},
	ObstacleNode = "Obstacle",
	Score1Star = 800,
	Score2Star = 1100,
	Score3Star = 1400,
	Data = 
	{
		0,0,0,0,0,0,0,0,0,0,2,0,0,2,0,0,0,2,2,0,0,2,2,0,0,0,0,2,3,0,0,0,0,0,0,3,2,0,0,0,0,2,2,0,0,2,2,0,0,0,2,0,0,2,0,0,0,0,0,0,0,0,0,0,
	},
	CatchQueue = 
	{
		5,4,2,3,
	},
	RewardList = {
		{
			Id = 327314,
			Num = 3,
		},
		{
			Id = 1,
			Num = 25000,
		},
	},
}
CatchFish_FishPoolConfig[CatchFish_FishPoolID.Id014] =
{
	Id = 14,
	Name = "全境封锁",
	CostItem = {
		Id = 327312,
		Num = 10,
	},
	PassCheckCostItem = {
		Id = 327312,
		Num = 5,
	},
	BuffList = {
		Desc = "男队员技巧 +{Value1}%",
		Buff = {
			{
				Id = 100691,
				Value = 75,
			},
		},
	},
	Desc = "队员技巧、力气增加能量，最多7人",
	NumCap = 7,
	CatchPoint = 200,
	Type = 1,
	SuppleFish = true,
	RankList = {
		{
			ExtraPoint = 0,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 0,
				},
				{
					Value = 200007,
					Num = 0,
				},
			},
		},
		{
			ExtraPoint = 8,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 80,
				},
				{
					Value = 200007,
					Num = 48,
				},
			},
		},
		{
			ExtraPoint = 16,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 160,
				},
				{
					Value = 200007,
					Num = 96,
				},
			},
		},
		{
			ExtraPoint = 24,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 240,
				},
				{
					Value = 200007,
					Num = 144,
				},
			},
		},
		{
			ExtraPoint = 30,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 320,
				},
				{
					Value = 200007,
					Num = 192,
				},
			},
		},
		{
			ExtraPoint = 35,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 400,
				},
				{
					Value = 200007,
					Num = 240,
				},
			},
		},
		{
			ExtraPoint = 40,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 500,
				},
				{
					Value = 200007,
					Num = 300,
				},
			},
		},
		{
			ExtraPoint = 45,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 600,
				},
				{
					Value = 200007,
					Num = 360,
				},
			},
		},
		{
			ExtraPoint = 50,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 700,
				},
				{
					Value = 200007,
					Num = 420,
				},
			},
		},
		{
			ExtraPoint = 55,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 800,
				},
				{
					Value = 200007,
					Num = 480,
				},
			},
		},
		{
			ExtraPoint = 60,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 900,
				},
				{
					Value = 200007,
					Num = 540,
				},
			},
		},
		{
			ExtraPoint = 65,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 1020,
				},
				{
					Value = 200007,
					Num = 612,
				},
			},
		},
		{
			ExtraPoint = 70,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 1140,
				},
				{
					Value = 200007,
					Num = 684,
				},
			},
		},
		{
			ExtraPoint = 75,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 1260,
				},
				{
					Value = 200007,
					Num = 756,
				},
			},
		},
		{
			ExtraPoint = 80,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 1380,
				},
				{
					Value = 200007,
					Num = 828,
				},
			},
		},
		{
			ExtraPoint = 85,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 1500,
				},
				{
					Value = 200007,
					Num = 900,
				},
			},
		},
		{
			ExtraPoint = 90,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 1640,
				},
				{
					Value = 200007,
					Num = 984,
				},
			},
		},
		{
			ExtraPoint = 95,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 1780,
				},
				{
					Value = 200007,
					Num = 1068,
				},
			},
		},
		{
			ExtraPoint = 100,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 1920,
				},
				{
					Value = 200007,
					Num = 1152,
				},
			},
		},
		{
			ExtraPoint = 105,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 2060,
				},
				{
					Value = 200007,
					Num = 1236,
				},
			},
		},
		{
			ExtraPoint = 110,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 2200,
				},
				{
					Value = 200007,
					Num = 1320,
				},
			},
		},
		{
			ExtraPoint = 115,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 2360,
				},
				{
					Value = 200007,
					Num = 1416,
				},
			},
		},
	},
	ObstacleNode = "Obstacle",
	Score1Star = 1500,
	Score2Star = 1750,
	Score3Star = 2000,
	Data = 
	{
		0,0,2,0,0,0,0,0,0,0,3,0,0,0,0,0,2,3,4,3,2,0,0,0,0,0,3,0,0,2,0,0,0,0,2,0,0,3,0,0,0,0,0,2,3,4,3,2,0,0,0,0,0,3,0,0,0,0,0,0,0,2,0,0,
	},
	CatchQueue = 
	{
		5,4,2,3,
	},
	RewardList = {
		{
			Id = 327314,
			Num = 3,
		},
		{
			Id = 1,
			Num = 25000,
		},
	},
}
CatchFish_FishPoolConfig[CatchFish_FishPoolID.Id015] =
{
	Id = 15,
	Name = "综合鱼塘I",
	CostItem = {
		Id = 327313,
		Num = 5,
	},
	PassCheckCostItem = {
		Id = 327313,
		Num = 2,
	},
	BuffList = {
		Desc = "女队员智力 +{Value1}%",
		Buff = {
			{
				Id = 100702,
				Value = 75,
			},
		},
	},
	Desc = "队员智力、亲和增加能量，最多7人",
	NumCap = 7,
	CatchPoint = 130,
	Type = 1,
	SuppleFish = true,
	RankList = {
		{
			ExtraPoint = 0,
			NeedAttribute = {
				{
					Value = 200008,
					Num = 0,
				},
				{
					Value = 200006,
					Num = 0,
				},
			},
		},
		{
			ExtraPoint = 8,
			NeedAttribute = {
				{
					Value = 200008,
					Num = 80,
				},
				{
					Value = 200006,
					Num = 48,
				},
			},
		},
		{
			ExtraPoint = 16,
			NeedAttribute = {
				{
					Value = 200008,
					Num = 160,
				},
				{
					Value = 200006,
					Num = 96,
				},
			},
		},
		{
			ExtraPoint = 24,
			NeedAttribute = {
				{
					Value = 200008,
					Num = 240,
				},
				{
					Value = 200006,
					Num = 144,
				},
			},
		},
		{
			ExtraPoint = 30,
			NeedAttribute = {
				{
					Value = 200008,
					Num = 320,
				},
				{
					Value = 200006,
					Num = 192,
				},
			},
		},
		{
			ExtraPoint = 35,
			NeedAttribute = {
				{
					Value = 200008,
					Num = 400,
				},
				{
					Value = 200006,
					Num = 240,
				},
			},
		},
		{
			ExtraPoint = 40,
			NeedAttribute = {
				{
					Value = 200008,
					Num = 500,
				},
				{
					Value = 200006,
					Num = 300,
				},
			},
		},
		{
			ExtraPoint = 45,
			NeedAttribute = {
				{
					Value = 200008,
					Num = 600,
				},
				{
					Value = 200006,
					Num = 360,
				},
			},
		},
		{
			ExtraPoint = 50,
			NeedAttribute = {
				{
					Value = 200008,
					Num = 700,
				},
				{
					Value = 200006,
					Num = 420,
				},
			},
		},
		{
			ExtraPoint = 55,
			NeedAttribute = {
				{
					Value = 200008,
					Num = 800,
				},
				{
					Value = 200006,
					Num = 480,
				},
			},
		},
		{
			ExtraPoint = 60,
			NeedAttribute = {
				{
					Value = 200008,
					Num = 900,
				},
				{
					Value = 200006,
					Num = 540,
				},
			},
		},
		{
			ExtraPoint = 65,
			NeedAttribute = {
				{
					Value = 200008,
					Num = 1020,
				},
				{
					Value = 200006,
					Num = 612,
				},
			},
		},
		{
			ExtraPoint = 70,
			NeedAttribute = {
				{
					Value = 200008,
					Num = 1140,
				},
				{
					Value = 200006,
					Num = 684,
				},
			},
		},
		{
			ExtraPoint = 75,
			NeedAttribute = {
				{
					Value = 200008,
					Num = 1260,
				},
				{
					Value = 200006,
					Num = 756,
				},
			},
		},
		{
			ExtraPoint = 80,
			NeedAttribute = {
				{
					Value = 200008,
					Num = 1380,
				},
				{
					Value = 200006,
					Num = 828,
				},
			},
		},
		{
			ExtraPoint = 85,
			NeedAttribute = {
				{
					Value = 200008,
					Num = 1500,
				},
				{
					Value = 200006,
					Num = 900,
				},
			},
		},
		{
			ExtraPoint = 90,
			NeedAttribute = {
				{
					Value = 200008,
					Num = 1640,
				},
				{
					Value = 200006,
					Num = 984,
				},
			},
		},
		{
			ExtraPoint = 95,
			NeedAttribute = {
				{
					Value = 200008,
					Num = 1780,
				},
				{
					Value = 200006,
					Num = 1068,
				},
			},
		},
		{
			ExtraPoint = 100,
			NeedAttribute = {
				{
					Value = 200008,
					Num = 1920,
				},
				{
					Value = 200006,
					Num = 1152,
				},
			},
		},
		{
			ExtraPoint = 105,
			NeedAttribute = {
				{
					Value = 200008,
					Num = 2060,
				},
				{
					Value = 200006,
					Num = 1236,
				},
			},
		},
		{
			ExtraPoint = 110,
			NeedAttribute = {
				{
					Value = 200008,
					Num = 2200,
				},
				{
					Value = 200006,
					Num = 1320,
				},
			},
		},
		{
			ExtraPoint = 115,
			NeedAttribute = {
				{
					Value = 200008,
					Num = 2360,
				},
				{
					Value = 200006,
					Num = 1416,
				},
			},
		},
		{
			ExtraPoint = 120,
			NeedAttribute = {
				{
					Value = 200008,
					Num = 2520,
				},
				{
					Value = 200006,
					Num = 1512,
				},
			},
		},
		{
			ExtraPoint = 125,
			NeedAttribute = {
				{
					Value = 200008,
					Num = 2680,
				},
				{
					Value = 200006,
					Num = 1608,
				},
			},
		},
		{
			ExtraPoint = 130,
			NeedAttribute = {
				{
					Value = 200008,
					Num = 2840,
				},
				{
					Value = 200006,
					Num = 1704,
				},
			},
		},
		{
			ExtraPoint = 135,
			NeedAttribute = {
				{
					Value = 200008,
					Num = 3000,
				},
				{
					Value = 200006,
					Num = 1800,
				},
			},
		},
		{
			ExtraPoint = 140,
			NeedAttribute = {
				{
					Value = 200008,
					Num = 3180,
				},
				{
					Value = 200006,
					Num = 1908,
				},
			},
		},
	},
	ObstacleNode = "Obstacle",
	Score1Star = 900,
	Score2Star = 1200,
	Score3Star = 1500,
	Data = 
	{
		0,2,0,2,0,0,3,0,0,0,2,0,0,0,0,0,0,0,2,0,2,0,2,0,2,0,4,0,0,0,0,0,0,0,0,0,0,2,0,2,0,3,0,2,0,0,0,0,2,0,0,0,0,2,0,2,0,0,0,2,0,0,0,0,
	},
	CatchQueue = 
	{
		5,4,2,3,
	},
	RewardList = {
		{
			Id = 327314,
			Num = 3,
		},
		{
			Id = 1,
			Num = 25000,
		},
	},
}
CatchFish_FishPoolConfig[CatchFish_FishPoolID.Id016] =
{
	Id = 16,
	Name = "综合鱼塘II",
	CostItem = {
		Id = 327313,
		Num = 5,
	},
	PassCheckCostItem = {
		Id = 327313,
		Num = 2,
	},
	BuffList = {
		Desc = "女队员力气 +{Value1}%",
		Buff = {
			{
				Id = 100701,
				Value = 75,
			},
		},
	},
	Desc = "队员力气、亲和增加能量，最多7人",
	NumCap = 7,
	CatchPoint = 130,
	Type = 1,
	SuppleFish = true,
	RankList = {
		{
			ExtraPoint = 0,
			NeedAttribute = {
				{
					Value = 200007,
					Num = 0,
				},
				{
					Value = 200006,
					Num = 0,
				},
			},
		},
		{
			ExtraPoint = 8,
			NeedAttribute = {
				{
					Value = 200007,
					Num = 80,
				},
				{
					Value = 200006,
					Num = 48,
				},
			},
		},
		{
			ExtraPoint = 16,
			NeedAttribute = {
				{
					Value = 200007,
					Num = 160,
				},
				{
					Value = 200006,
					Num = 96,
				},
			},
		},
		{
			ExtraPoint = 24,
			NeedAttribute = {
				{
					Value = 200007,
					Num = 240,
				},
				{
					Value = 200006,
					Num = 144,
				},
			},
		},
		{
			ExtraPoint = 30,
			NeedAttribute = {
				{
					Value = 200007,
					Num = 320,
				},
				{
					Value = 200006,
					Num = 192,
				},
			},
		},
		{
			ExtraPoint = 35,
			NeedAttribute = {
				{
					Value = 200007,
					Num = 400,
				},
				{
					Value = 200006,
					Num = 240,
				},
			},
		},
		{
			ExtraPoint = 40,
			NeedAttribute = {
				{
					Value = 200007,
					Num = 500,
				},
				{
					Value = 200006,
					Num = 300,
				},
			},
		},
		{
			ExtraPoint = 45,
			NeedAttribute = {
				{
					Value = 200007,
					Num = 600,
				},
				{
					Value = 200006,
					Num = 360,
				},
			},
		},
		{
			ExtraPoint = 50,
			NeedAttribute = {
				{
					Value = 200007,
					Num = 700,
				},
				{
					Value = 200006,
					Num = 420,
				},
			},
		},
		{
			ExtraPoint = 55,
			NeedAttribute = {
				{
					Value = 200007,
					Num = 800,
				},
				{
					Value = 200006,
					Num = 480,
				},
			},
		},
		{
			ExtraPoint = 60,
			NeedAttribute = {
				{
					Value = 200007,
					Num = 900,
				},
				{
					Value = 200006,
					Num = 540,
				},
			},
		},
		{
			ExtraPoint = 65,
			NeedAttribute = {
				{
					Value = 200007,
					Num = 1020,
				},
				{
					Value = 200006,
					Num = 612,
				},
			},
		},
		{
			ExtraPoint = 70,
			NeedAttribute = {
				{
					Value = 200007,
					Num = 1140,
				},
				{
					Value = 200006,
					Num = 684,
				},
			},
		},
		{
			ExtraPoint = 75,
			NeedAttribute = {
				{
					Value = 200007,
					Num = 1260,
				},
				{
					Value = 200006,
					Num = 756,
				},
			},
		},
		{
			ExtraPoint = 80,
			NeedAttribute = {
				{
					Value = 200007,
					Num = 1380,
				},
				{
					Value = 200006,
					Num = 828,
				},
			},
		},
		{
			ExtraPoint = 85,
			NeedAttribute = {
				{
					Value = 200007,
					Num = 1500,
				},
				{
					Value = 200006,
					Num = 900,
				},
			},
		},
		{
			ExtraPoint = 90,
			NeedAttribute = {
				{
					Value = 200007,
					Num = 1640,
				},
				{
					Value = 200006,
					Num = 984,
				},
			},
		},
		{
			ExtraPoint = 95,
			NeedAttribute = {
				{
					Value = 200007,
					Num = 1780,
				},
				{
					Value = 200006,
					Num = 1068,
				},
			},
		},
		{
			ExtraPoint = 100,
			NeedAttribute = {
				{
					Value = 200007,
					Num = 1920,
				},
				{
					Value = 200006,
					Num = 1152,
				},
			},
		},
		{
			ExtraPoint = 105,
			NeedAttribute = {
				{
					Value = 200007,
					Num = 2060,
				},
				{
					Value = 200006,
					Num = 1236,
				},
			},
		},
		{
			ExtraPoint = 110,
			NeedAttribute = {
				{
					Value = 200007,
					Num = 2200,
				},
				{
					Value = 200006,
					Num = 1320,
				},
			},
		},
		{
			ExtraPoint = 115,
			NeedAttribute = {
				{
					Value = 200007,
					Num = 2360,
				},
				{
					Value = 200006,
					Num = 1416,
				},
			},
		},
		{
			ExtraPoint = 120,
			NeedAttribute = {
				{
					Value = 200007,
					Num = 2520,
				},
				{
					Value = 200006,
					Num = 1512,
				},
			},
		},
		{
			ExtraPoint = 125,
			NeedAttribute = {
				{
					Value = 200007,
					Num = 2680,
				},
				{
					Value = 200006,
					Num = 1608,
				},
			},
		},
		{
			ExtraPoint = 130,
			NeedAttribute = {
				{
					Value = 200007,
					Num = 2840,
				},
				{
					Value = 200006,
					Num = 1704,
				},
			},
		},
		{
			ExtraPoint = 135,
			NeedAttribute = {
				{
					Value = 200007,
					Num = 3000,
				},
				{
					Value = 200006,
					Num = 1800,
				},
			},
		},
		{
			ExtraPoint = 140,
			NeedAttribute = {
				{
					Value = 200007,
					Num = 3180,
				},
				{
					Value = 200006,
					Num = 1908,
				},
			},
		},
	},
	ObstacleNode = "Obstacle",
	Score1Star = 900,
	Score2Star = 1200,
	Score3Star = 1500,
	Data = 
	{
		0,0,0,0,2,0,0,0,0,2,0,4,0,0,2,0,0,0,0,0,0,0,0,0,2,0,2,0,2,0,0,2,0,3,0,0,0,2,0,0,0,0,0,2,0,0,0,2,2,0,0,0,2,0,0,0,0,0,0,3,0,0,0,2,
	},
	CatchQueue = 
	{
		5,4,2,3,
	},
	RewardList = {
		{
			Id = 327314,
			Num = 4,
		},
		{
			Id = 1,
			Num = 25000,
		},
	},
}
CatchFish_FishPoolConfig[CatchFish_FishPoolID.Id017] =
{
	Id = 17,
	Name = "大鱼群",
	CostItem = {
		Id = 327313,
		Num = 5,
	},
	PassCheckCostItem = {
		Id = 327313,
		Num = 2,
	},
	BuffList = {
		Desc = "男队员力气 +{Value1}%",
		Buff = {
			{
				Id = 100693,
				Value = 75,
			},
		},
	},
	Desc = "队员力气、技巧增加能量，最多7人",
	NumCap = 7,
	CatchPoint = 300,
	Type = 1,
	SuppleFish = false,
	RankList = {
		{
			ExtraPoint = 0,
			NeedAttribute = {
				{
					Value = 200007,
					Num = 0,
				},
				{
					Value = 200005,
					Num = 0,
				},
			},
		},
		{
			ExtraPoint = 8,
			NeedAttribute = {
				{
					Value = 200007,
					Num = 80,
				},
				{
					Value = 200005,
					Num = 48,
				},
			},
		},
		{
			ExtraPoint = 16,
			NeedAttribute = {
				{
					Value = 200007,
					Num = 160,
				},
				{
					Value = 200005,
					Num = 96,
				},
			},
		},
		{
			ExtraPoint = 24,
			NeedAttribute = {
				{
					Value = 200007,
					Num = 240,
				},
				{
					Value = 200005,
					Num = 144,
				},
			},
		},
		{
			ExtraPoint = 30,
			NeedAttribute = {
				{
					Value = 200007,
					Num = 320,
				},
				{
					Value = 200005,
					Num = 192,
				},
			},
		},
		{
			ExtraPoint = 35,
			NeedAttribute = {
				{
					Value = 200007,
					Num = 400,
				},
				{
					Value = 200005,
					Num = 240,
				},
			},
		},
		{
			ExtraPoint = 40,
			NeedAttribute = {
				{
					Value = 200007,
					Num = 500,
				},
				{
					Value = 200005,
					Num = 300,
				},
			},
		},
		{
			ExtraPoint = 45,
			NeedAttribute = {
				{
					Value = 200007,
					Num = 600,
				},
				{
					Value = 200005,
					Num = 360,
				},
			},
		},
		{
			ExtraPoint = 50,
			NeedAttribute = {
				{
					Value = 200007,
					Num = 700,
				},
				{
					Value = 200005,
					Num = 420,
				},
			},
		},
		{
			ExtraPoint = 55,
			NeedAttribute = {
				{
					Value = 200007,
					Num = 800,
				},
				{
					Value = 200005,
					Num = 480,
				},
			},
		},
		{
			ExtraPoint = 60,
			NeedAttribute = {
				{
					Value = 200007,
					Num = 900,
				},
				{
					Value = 200005,
					Num = 540,
				},
			},
		},
		{
			ExtraPoint = 65,
			NeedAttribute = {
				{
					Value = 200007,
					Num = 1020,
				},
				{
					Value = 200005,
					Num = 612,
				},
			},
		},
		{
			ExtraPoint = 70,
			NeedAttribute = {
				{
					Value = 200007,
					Num = 1140,
				},
				{
					Value = 200005,
					Num = 684,
				},
			},
		},
		{
			ExtraPoint = 75,
			NeedAttribute = {
				{
					Value = 200007,
					Num = 1260,
				},
				{
					Value = 200005,
					Num = 756,
				},
			},
		},
		{
			ExtraPoint = 80,
			NeedAttribute = {
				{
					Value = 200007,
					Num = 1380,
				},
				{
					Value = 200005,
					Num = 828,
				},
			},
		},
		{
			ExtraPoint = 85,
			NeedAttribute = {
				{
					Value = 200007,
					Num = 1500,
				},
				{
					Value = 200005,
					Num = 900,
				},
			},
		},
		{
			ExtraPoint = 90,
			NeedAttribute = {
				{
					Value = 200007,
					Num = 1640,
				},
				{
					Value = 200005,
					Num = 984,
				},
			},
		},
		{
			ExtraPoint = 95,
			NeedAttribute = {
				{
					Value = 200007,
					Num = 1780,
				},
				{
					Value = 200005,
					Num = 1068,
				},
			},
		},
		{
			ExtraPoint = 100,
			NeedAttribute = {
				{
					Value = 200007,
					Num = 1920,
				},
				{
					Value = 200005,
					Num = 1152,
				},
			},
		},
		{
			ExtraPoint = 105,
			NeedAttribute = {
				{
					Value = 200007,
					Num = 2060,
				},
				{
					Value = 200005,
					Num = 1236,
				},
			},
		},
		{
			ExtraPoint = 110,
			NeedAttribute = {
				{
					Value = 200007,
					Num = 2200,
				},
				{
					Value = 200005,
					Num = 1320,
				},
			},
		},
		{
			ExtraPoint = 115,
			NeedAttribute = {
				{
					Value = 200007,
					Num = 2360,
				},
				{
					Value = 200005,
					Num = 1416,
				},
			},
		},
		{
			ExtraPoint = 120,
			NeedAttribute = {
				{
					Value = 200007,
					Num = 2520,
				},
				{
					Value = 200005,
					Num = 1512,
				},
			},
		},
		{
			ExtraPoint = 125,
			NeedAttribute = {
				{
					Value = 200007,
					Num = 2680,
				},
				{
					Value = 200005,
					Num = 1608,
				},
			},
		},
		{
			ExtraPoint = 130,
			NeedAttribute = {
				{
					Value = 200007,
					Num = 2840,
				},
				{
					Value = 200005,
					Num = 1704,
				},
			},
		},
		{
			ExtraPoint = 135,
			NeedAttribute = {
				{
					Value = 200007,
					Num = 3000,
				},
				{
					Value = 200005,
					Num = 1800,
				},
			},
		},
		{
			ExtraPoint = 140,
			NeedAttribute = {
				{
					Value = 200007,
					Num = 3180,
				},
				{
					Value = 200005,
					Num = 1908,
				},
			},
		},
	},
	ObstacleNode = "Obstacle",
	Score1Star = 2600,
	Score2Star = 3150,
	Score3Star = 3700,
	Data = 
	{
		0,0,2,2,2,2,0,0,0,2,2,2,2,2,2,0,2,2,4,2,2,2,2,2,2,2,2,3,2,2,2,2,2,2,2,2,3,2,2,2,2,2,2,2,2,4,2,2,0,2,2,2,2,2,2,0,0,0,2,2,2,2,0,0,
	},
	CatchQueue = 
	{
		5,4,
	},
	RewardList = {
		{
			Id = 327314,
			Num = 4,
		},
		{
			Id = 1,
			Num = 25000,
		},
	},
}
CatchFish_FishPoolConfig[CatchFish_FishPoolID.Id018] =
{
	Id = 18,
	Name = "烧高香",
	CostItem = {
		Id = 327313,
		Num = 5,
	},
	PassCheckCostItem = {
		Id = 327313,
		Num = 2,
	},
	BuffList = {
		Desc = "男队员亲和 +{Value1}%",
		Buff = {
			{
				Id = 100692,
				Value = 75,
			},
		},
	},
	Desc = "队员亲和、力气增加能量，最多7人",
	NumCap = 7,
	CatchPoint = 150,
	Type = 1,
	SuppleFish = true,
	RankList = {
		{
			ExtraPoint = 0,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 0,
				},
				{
					Value = 200007,
					Num = 0,
				},
			},
		},
		{
			ExtraPoint = 8,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 80,
				},
				{
					Value = 200007,
					Num = 48,
				},
			},
		},
		{
			ExtraPoint = 16,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 160,
				},
				{
					Value = 200007,
					Num = 96,
				},
			},
		},
		{
			ExtraPoint = 24,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 240,
				},
				{
					Value = 200007,
					Num = 144,
				},
			},
		},
		{
			ExtraPoint = 30,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 320,
				},
				{
					Value = 200007,
					Num = 192,
				},
			},
		},
		{
			ExtraPoint = 35,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 400,
				},
				{
					Value = 200007,
					Num = 240,
				},
			},
		},
		{
			ExtraPoint = 40,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 500,
				},
				{
					Value = 200007,
					Num = 300,
				},
			},
		},
		{
			ExtraPoint = 45,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 600,
				},
				{
					Value = 200007,
					Num = 360,
				},
			},
		},
		{
			ExtraPoint = 50,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 700,
				},
				{
					Value = 200007,
					Num = 420,
				},
			},
		},
		{
			ExtraPoint = 55,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 800,
				},
				{
					Value = 200007,
					Num = 480,
				},
			},
		},
		{
			ExtraPoint = 60,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 900,
				},
				{
					Value = 200007,
					Num = 540,
				},
			},
		},
		{
			ExtraPoint = 65,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 1020,
				},
				{
					Value = 200007,
					Num = 612,
				},
			},
		},
		{
			ExtraPoint = 70,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 1140,
				},
				{
					Value = 200007,
					Num = 684,
				},
			},
		},
		{
			ExtraPoint = 75,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 1260,
				},
				{
					Value = 200007,
					Num = 756,
				},
			},
		},
		{
			ExtraPoint = 80,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 1380,
				},
				{
					Value = 200007,
					Num = 828,
				},
			},
		},
		{
			ExtraPoint = 85,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 1500,
				},
				{
					Value = 200007,
					Num = 900,
				},
			},
		},
		{
			ExtraPoint = 90,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 1640,
				},
				{
					Value = 200007,
					Num = 984,
				},
			},
		},
		{
			ExtraPoint = 95,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 1780,
				},
				{
					Value = 200007,
					Num = 1068,
				},
			},
		},
		{
			ExtraPoint = 100,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 1920,
				},
				{
					Value = 200007,
					Num = 1152,
				},
			},
		},
		{
			ExtraPoint = 105,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 2060,
				},
				{
					Value = 200007,
					Num = 1236,
				},
			},
		},
		{
			ExtraPoint = 110,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 2200,
				},
				{
					Value = 200007,
					Num = 1320,
				},
			},
		},
		{
			ExtraPoint = 115,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 2360,
				},
				{
					Value = 200007,
					Num = 1416,
				},
			},
		},
		{
			ExtraPoint = 120,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 2520,
				},
				{
					Value = 200007,
					Num = 1512,
				},
			},
		},
		{
			ExtraPoint = 125,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 2680,
				},
				{
					Value = 200007,
					Num = 1608,
				},
			},
		},
		{
			ExtraPoint = 130,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 2840,
				},
				{
					Value = 200007,
					Num = 1704,
				},
			},
		},
		{
			ExtraPoint = 135,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 3000,
				},
				{
					Value = 200007,
					Num = 1800,
				},
			},
		},
		{
			ExtraPoint = 140,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 3180,
				},
				{
					Value = 200007,
					Num = 1908,
				},
			},
		},
	},
	ObstacleNode = "Obstacle",
	Score1Star = 1200,
	Score2Star = 1800,
	Score3Star = 2400,
	Data = 
	{
		0,0,0,3,0,0,0,0,0,2,0,3,0,0,2,0,0,2,0,3,0,0,2,0,0,0,0,2,5,0,0,0,0,2,0,3,0,0,2,0,0,2,0,3,0,0,2,0,0,2,0,3,0,0,2,0,0,0,0,3,0,0,0,0,
	},
	CatchQueue = 
	{
		5,4,3,
	},
	RewardList = {
		{
			Id = 327314,
			Num = 4,
		},
		{
			Id = 1,
			Num = 25000,
		},
	},
}
CatchFish_FishPoolConfig[CatchFish_FishPoolID.Id019] =
{
	Id = 19,
	Name = "综合鱼塘III",
	CostItem = {
		Id = 327313,
		Num = 5,
	},
	PassCheckCostItem = {
		Id = 327313,
		Num = 2,
	},
	BuffList = {
		Desc = "女队员智力 +{Value1}%",
		Buff = {
			{
				Id = 100702,
				Value = 75,
			},
		},
	},
	Desc = "队员智力、力气增加能量，最多7人",
	NumCap = 7,
	CatchPoint = 150,
	Type = 1,
	SuppleFish = true,
	RankList = {
		{
			ExtraPoint = 0,
			NeedAttribute = {
				{
					Value = 200008,
					Num = 0,
				},
				{
					Value = 200007,
					Num = 0,
				},
			},
		},
		{
			ExtraPoint = 8,
			NeedAttribute = {
				{
					Value = 200008,
					Num = 80,
				},
				{
					Value = 200007,
					Num = 48,
				},
			},
		},
		{
			ExtraPoint = 16,
			NeedAttribute = {
				{
					Value = 200008,
					Num = 160,
				},
				{
					Value = 200007,
					Num = 96,
				},
			},
		},
		{
			ExtraPoint = 24,
			NeedAttribute = {
				{
					Value = 200008,
					Num = 240,
				},
				{
					Value = 200007,
					Num = 144,
				},
			},
		},
		{
			ExtraPoint = 30,
			NeedAttribute = {
				{
					Value = 200008,
					Num = 320,
				},
				{
					Value = 200007,
					Num = 192,
				},
			},
		},
		{
			ExtraPoint = 35,
			NeedAttribute = {
				{
					Value = 200008,
					Num = 400,
				},
				{
					Value = 200007,
					Num = 240,
				},
			},
		},
		{
			ExtraPoint = 40,
			NeedAttribute = {
				{
					Value = 200008,
					Num = 500,
				},
				{
					Value = 200007,
					Num = 300,
				},
			},
		},
		{
			ExtraPoint = 45,
			NeedAttribute = {
				{
					Value = 200008,
					Num = 600,
				},
				{
					Value = 200007,
					Num = 360,
				},
			},
		},
		{
			ExtraPoint = 50,
			NeedAttribute = {
				{
					Value = 200008,
					Num = 700,
				},
				{
					Value = 200007,
					Num = 420,
				},
			},
		},
		{
			ExtraPoint = 55,
			NeedAttribute = {
				{
					Value = 200008,
					Num = 800,
				},
				{
					Value = 200007,
					Num = 480,
				},
			},
		},
		{
			ExtraPoint = 60,
			NeedAttribute = {
				{
					Value = 200008,
					Num = 900,
				},
				{
					Value = 200007,
					Num = 540,
				},
			},
		},
		{
			ExtraPoint = 65,
			NeedAttribute = {
				{
					Value = 200008,
					Num = 1020,
				},
				{
					Value = 200007,
					Num = 612,
				},
			},
		},
		{
			ExtraPoint = 70,
			NeedAttribute = {
				{
					Value = 200008,
					Num = 1140,
				},
				{
					Value = 200007,
					Num = 684,
				},
			},
		},
		{
			ExtraPoint = 75,
			NeedAttribute = {
				{
					Value = 200008,
					Num = 1260,
				},
				{
					Value = 200007,
					Num = 756,
				},
			},
		},
		{
			ExtraPoint = 80,
			NeedAttribute = {
				{
					Value = 200008,
					Num = 1380,
				},
				{
					Value = 200007,
					Num = 828,
				},
			},
		},
		{
			ExtraPoint = 85,
			NeedAttribute = {
				{
					Value = 200008,
					Num = 1500,
				},
				{
					Value = 200007,
					Num = 900,
				},
			},
		},
		{
			ExtraPoint = 90,
			NeedAttribute = {
				{
					Value = 200008,
					Num = 1640,
				},
				{
					Value = 200007,
					Num = 984,
				},
			},
		},
		{
			ExtraPoint = 95,
			NeedAttribute = {
				{
					Value = 200008,
					Num = 1780,
				},
				{
					Value = 200007,
					Num = 1068,
				},
			},
		},
		{
			ExtraPoint = 100,
			NeedAttribute = {
				{
					Value = 200008,
					Num = 1920,
				},
				{
					Value = 200007,
					Num = 1152,
				},
			},
		},
		{
			ExtraPoint = 105,
			NeedAttribute = {
				{
					Value = 200008,
					Num = 2060,
				},
				{
					Value = 200007,
					Num = 1236,
				},
			},
		},
		{
			ExtraPoint = 110,
			NeedAttribute = {
				{
					Value = 200008,
					Num = 2200,
				},
				{
					Value = 200007,
					Num = 1320,
				},
			},
		},
		{
			ExtraPoint = 115,
			NeedAttribute = {
				{
					Value = 200008,
					Num = 2360,
				},
				{
					Value = 200007,
					Num = 1416,
				},
			},
		},
		{
			ExtraPoint = 120,
			NeedAttribute = {
				{
					Value = 200008,
					Num = 2520,
				},
				{
					Value = 200007,
					Num = 1512,
				},
			},
		},
		{
			ExtraPoint = 125,
			NeedAttribute = {
				{
					Value = 200008,
					Num = 2680,
				},
				{
					Value = 200007,
					Num = 1608,
				},
			},
		},
		{
			ExtraPoint = 130,
			NeedAttribute = {
				{
					Value = 200008,
					Num = 2840,
				},
				{
					Value = 200007,
					Num = 1704,
				},
			},
		},
		{
			ExtraPoint = 135,
			NeedAttribute = {
				{
					Value = 200008,
					Num = 3000,
				},
				{
					Value = 200007,
					Num = 1800,
				},
			},
		},
		{
			ExtraPoint = 140,
			NeedAttribute = {
				{
					Value = 200008,
					Num = 3180,
				},
				{
					Value = 200007,
					Num = 1908,
				},
			},
		},
		{
			ExtraPoint = 145,
			NeedAttribute = {
				{
					Value = 200008,
					Num = 3360,
				},
				{
					Value = 200007,
					Num = 2016,
				},
			},
		},
		{
			ExtraPoint = 150,
			NeedAttribute = {
				{
					Value = 200008,
					Num = 3540,
				},
				{
					Value = 200007,
					Num = 2124,
				},
			},
		},
		{
			ExtraPoint = 155,
			NeedAttribute = {
				{
					Value = 200008,
					Num = 3720,
				},
				{
					Value = 200007,
					Num = 2232,
				},
			},
		},
		{
			ExtraPoint = 160,
			NeedAttribute = {
				{
					Value = 200008,
					Num = 3900,
				},
				{
					Value = 200007,
					Num = 2340,
				},
			},
		},
		{
			ExtraPoint = 165,
			NeedAttribute = {
				{
					Value = 200008,
					Num = 4100,
				},
				{
					Value = 200007,
					Num = 2460,
				},
			},
		},
	},
	ObstacleNode = "Obstacle",
	Score1Star = 1250,
	Score2Star = 1500,
	Score3Star = 1750,
	Data = 
	{
		0,0,4,0,2,0,0,0,0,2,0,0,0,0,2,0,0,0,0,2,0,3,0,0,2,0,2,0,5,0,0,2,0,0,0,0,0,2,0,0,0,3,0,2,0,0,0,2,2,0,0,0,0,2,0,0,0,0,0,2,0,0,0,0,
	},
	CatchQueue = 
	{
		5,4,2,3,
	},
	RewardList = {
		{
			Id = 327314,
			Num = 4,
		},
		{
			Id = 1,
			Num = 25000,
		},
	},
}
CatchFish_FishPoolConfig[CatchFish_FishPoolID.Id020] =
{
	Id = 20,
	Name = "小金鱼",
	CostItem = {
		Id = 327313,
		Num = 5,
	},
	PassCheckCostItem = {
		Id = 327313,
		Num = 2,
	},
	BuffList = {
		Desc = "女队员技巧 +{Value1}%",
		Buff = {
			{
				Id = 100699,
				Value = 75,
			},
		},
	},
	Desc = "队员技巧、亲和增加能量，最多7人",
	NumCap = 7,
	CatchPoint = 180,
	Type = 1,
	SuppleFish = true,
	RankList = {
		{
			ExtraPoint = 0,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 0,
				},
				{
					Value = 200006,
					Num = 0,
				},
			},
		},
		{
			ExtraPoint = 8,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 80,
				},
				{
					Value = 200006,
					Num = 48,
				},
			},
		},
		{
			ExtraPoint = 16,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 160,
				},
				{
					Value = 200006,
					Num = 96,
				},
			},
		},
		{
			ExtraPoint = 24,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 240,
				},
				{
					Value = 200006,
					Num = 144,
				},
			},
		},
		{
			ExtraPoint = 30,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 320,
				},
				{
					Value = 200006,
					Num = 192,
				},
			},
		},
		{
			ExtraPoint = 35,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 400,
				},
				{
					Value = 200006,
					Num = 240,
				},
			},
		},
		{
			ExtraPoint = 40,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 500,
				},
				{
					Value = 200006,
					Num = 300,
				},
			},
		},
		{
			ExtraPoint = 45,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 600,
				},
				{
					Value = 200006,
					Num = 360,
				},
			},
		},
		{
			ExtraPoint = 50,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 700,
				},
				{
					Value = 200006,
					Num = 420,
				},
			},
		},
		{
			ExtraPoint = 55,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 800,
				},
				{
					Value = 200006,
					Num = 480,
				},
			},
		},
		{
			ExtraPoint = 60,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 900,
				},
				{
					Value = 200006,
					Num = 540,
				},
			},
		},
		{
			ExtraPoint = 65,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 1020,
				},
				{
					Value = 200006,
					Num = 612,
				},
			},
		},
		{
			ExtraPoint = 70,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 1140,
				},
				{
					Value = 200006,
					Num = 684,
				},
			},
		},
		{
			ExtraPoint = 75,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 1260,
				},
				{
					Value = 200006,
					Num = 756,
				},
			},
		},
		{
			ExtraPoint = 80,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 1380,
				},
				{
					Value = 200006,
					Num = 828,
				},
			},
		},
		{
			ExtraPoint = 85,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 1500,
				},
				{
					Value = 200006,
					Num = 900,
				},
			},
		},
		{
			ExtraPoint = 90,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 1640,
				},
				{
					Value = 200006,
					Num = 984,
				},
			},
		},
		{
			ExtraPoint = 95,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 1780,
				},
				{
					Value = 200006,
					Num = 1068,
				},
			},
		},
		{
			ExtraPoint = 100,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 1920,
				},
				{
					Value = 200006,
					Num = 1152,
				},
			},
		},
		{
			ExtraPoint = 105,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 2060,
				},
				{
					Value = 200006,
					Num = 1236,
				},
			},
		},
		{
			ExtraPoint = 110,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 2200,
				},
				{
					Value = 200006,
					Num = 1320,
				},
			},
		},
		{
			ExtraPoint = 115,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 2360,
				},
				{
					Value = 200006,
					Num = 1416,
				},
			},
		},
		{
			ExtraPoint = 120,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 2520,
				},
				{
					Value = 200006,
					Num = 1512,
				},
			},
		},
		{
			ExtraPoint = 125,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 2680,
				},
				{
					Value = 200006,
					Num = 1608,
				},
			},
		},
		{
			ExtraPoint = 130,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 2840,
				},
				{
					Value = 200006,
					Num = 1704,
				},
			},
		},
		{
			ExtraPoint = 135,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 3000,
				},
				{
					Value = 200006,
					Num = 1800,
				},
			},
		},
		{
			ExtraPoint = 140,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 3180,
				},
				{
					Value = 200006,
					Num = 1908,
				},
			},
		},
		{
			ExtraPoint = 145,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 3360,
				},
				{
					Value = 200006,
					Num = 2016,
				},
			},
		},
		{
			ExtraPoint = 150,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 3540,
				},
				{
					Value = 200006,
					Num = 2124,
				},
			},
		},
		{
			ExtraPoint = 155,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 3720,
				},
				{
					Value = 200006,
					Num = 2232,
				},
			},
		},
		{
			ExtraPoint = 160,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 3900,
				},
				{
					Value = 200006,
					Num = 2340,
				},
			},
		},
		{
			ExtraPoint = 165,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 4100,
				},
				{
					Value = 200006,
					Num = 2460,
				},
			},
		},
	},
	ObstacleNode = "Obstacle",
	Score1Star = 1400,
	Score2Star = 1800,
	Score3Star = 2200,
	Data = 
	{
		0,0,0,0,0,0,0,0,0,0,2,3,0,0,0,0,0,2,2,2,0,2,0,0,0,3,2,5,2,3,0,0,0,0,0,2,2,2,2,0,0,0,2,3,2,2,2,0,0,0,0,0,2,2,4,0,0,0,0,0,0,0,0,0,
	},
	CatchQueue = 
	{
		5,4,2,3,
	},
	RewardList = {
		{
			Id = 327314,
			Num = 4,
		},
		{
			Id = 1,
			Num = 25000,
		},
	},
}
CatchFish_FishPoolConfig[CatchFish_FishPoolID.Id021] =
{
	Id = 21,
	Name = "综合鱼塘IV",
	CostItem = {
		Id = 327313,
		Num = 5,
	},
	PassCheckCostItem = {
		Id = 327313,
		Num = 2,
	},
	BuffList = {
		Desc = "男队员智力 +{Value1}%",
		Buff = {
			{
				Id = 100694,
				Value = 75,
			},
		},
	},
	Desc = "队员智力、技巧增加能量，最多7人",
	NumCap = 7,
	CatchPoint = 150,
	Type = 1,
	SuppleFish = true,
	RankList = {
		{
			ExtraPoint = 0,
			NeedAttribute = {
				{
					Value = 200008,
					Num = 0,
				},
				{
					Value = 200005,
					Num = 0,
				},
			},
		},
		{
			ExtraPoint = 8,
			NeedAttribute = {
				{
					Value = 200008,
					Num = 80,
				},
				{
					Value = 200005,
					Num = 48,
				},
			},
		},
		{
			ExtraPoint = 16,
			NeedAttribute = {
				{
					Value = 200008,
					Num = 160,
				},
				{
					Value = 200005,
					Num = 96,
				},
			},
		},
		{
			ExtraPoint = 24,
			NeedAttribute = {
				{
					Value = 200008,
					Num = 240,
				},
				{
					Value = 200005,
					Num = 144,
				},
			},
		},
		{
			ExtraPoint = 30,
			NeedAttribute = {
				{
					Value = 200008,
					Num = 320,
				},
				{
					Value = 200005,
					Num = 192,
				},
			},
		},
		{
			ExtraPoint = 35,
			NeedAttribute = {
				{
					Value = 200008,
					Num = 400,
				},
				{
					Value = 200005,
					Num = 240,
				},
			},
		},
		{
			ExtraPoint = 40,
			NeedAttribute = {
				{
					Value = 200008,
					Num = 500,
				},
				{
					Value = 200005,
					Num = 300,
				},
			},
		},
		{
			ExtraPoint = 45,
			NeedAttribute = {
				{
					Value = 200008,
					Num = 600,
				},
				{
					Value = 200005,
					Num = 360,
				},
			},
		},
		{
			ExtraPoint = 50,
			NeedAttribute = {
				{
					Value = 200008,
					Num = 700,
				},
				{
					Value = 200005,
					Num = 420,
				},
			},
		},
		{
			ExtraPoint = 55,
			NeedAttribute = {
				{
					Value = 200008,
					Num = 800,
				},
				{
					Value = 200005,
					Num = 480,
				},
			},
		},
		{
			ExtraPoint = 60,
			NeedAttribute = {
				{
					Value = 200008,
					Num = 900,
				},
				{
					Value = 200005,
					Num = 540,
				},
			},
		},
		{
			ExtraPoint = 65,
			NeedAttribute = {
				{
					Value = 200008,
					Num = 1020,
				},
				{
					Value = 200005,
					Num = 612,
				},
			},
		},
		{
			ExtraPoint = 70,
			NeedAttribute = {
				{
					Value = 200008,
					Num = 1140,
				},
				{
					Value = 200005,
					Num = 684,
				},
			},
		},
		{
			ExtraPoint = 75,
			NeedAttribute = {
				{
					Value = 200008,
					Num = 1260,
				},
				{
					Value = 200005,
					Num = 756,
				},
			},
		},
		{
			ExtraPoint = 80,
			NeedAttribute = {
				{
					Value = 200008,
					Num = 1380,
				},
				{
					Value = 200005,
					Num = 828,
				},
			},
		},
		{
			ExtraPoint = 85,
			NeedAttribute = {
				{
					Value = 200008,
					Num = 1500,
				},
				{
					Value = 200005,
					Num = 900,
				},
			},
		},
		{
			ExtraPoint = 90,
			NeedAttribute = {
				{
					Value = 200008,
					Num = 1640,
				},
				{
					Value = 200005,
					Num = 984,
				},
			},
		},
		{
			ExtraPoint = 95,
			NeedAttribute = {
				{
					Value = 200008,
					Num = 1780,
				},
				{
					Value = 200005,
					Num = 1068,
				},
			},
		},
		{
			ExtraPoint = 100,
			NeedAttribute = {
				{
					Value = 200008,
					Num = 1920,
				},
				{
					Value = 200005,
					Num = 1152,
				},
			},
		},
		{
			ExtraPoint = 105,
			NeedAttribute = {
				{
					Value = 200008,
					Num = 2060,
				},
				{
					Value = 200005,
					Num = 1236,
				},
			},
		},
		{
			ExtraPoint = 110,
			NeedAttribute = {
				{
					Value = 200008,
					Num = 2200,
				},
				{
					Value = 200005,
					Num = 1320,
				},
			},
		},
		{
			ExtraPoint = 115,
			NeedAttribute = {
				{
					Value = 200008,
					Num = 2360,
				},
				{
					Value = 200005,
					Num = 1416,
				},
			},
		},
		{
			ExtraPoint = 120,
			NeedAttribute = {
				{
					Value = 200008,
					Num = 2520,
				},
				{
					Value = 200005,
					Num = 1512,
				},
			},
		},
		{
			ExtraPoint = 125,
			NeedAttribute = {
				{
					Value = 200008,
					Num = 2680,
				},
				{
					Value = 200005,
					Num = 1608,
				},
			},
		},
		{
			ExtraPoint = 130,
			NeedAttribute = {
				{
					Value = 200008,
					Num = 2840,
				},
				{
					Value = 200005,
					Num = 1704,
				},
			},
		},
		{
			ExtraPoint = 135,
			NeedAttribute = {
				{
					Value = 200008,
					Num = 3000,
				},
				{
					Value = 200005,
					Num = 1800,
				},
			},
		},
		{
			ExtraPoint = 140,
			NeedAttribute = {
				{
					Value = 200008,
					Num = 3180,
				},
				{
					Value = 200005,
					Num = 1908,
				},
			},
		},
		{
			ExtraPoint = 145,
			NeedAttribute = {
				{
					Value = 200008,
					Num = 3360,
				},
				{
					Value = 200005,
					Num = 2016,
				},
			},
		},
		{
			ExtraPoint = 150,
			NeedAttribute = {
				{
					Value = 200008,
					Num = 3540,
				},
				{
					Value = 200005,
					Num = 2124,
				},
			},
		},
		{
			ExtraPoint = 155,
			NeedAttribute = {
				{
					Value = 200008,
					Num = 3720,
				},
				{
					Value = 200005,
					Num = 2232,
				},
			},
		},
		{
			ExtraPoint = 160,
			NeedAttribute = {
				{
					Value = 200008,
					Num = 3900,
				},
				{
					Value = 200005,
					Num = 2340,
				},
			},
		},
		{
			ExtraPoint = 165,
			NeedAttribute = {
				{
					Value = 200008,
					Num = 4100,
				},
				{
					Value = 200005,
					Num = 2460,
				},
			},
		},
	},
	ObstacleNode = "Obstacle",
	Score1Star = 900,
	Score2Star = 1250,
	Score3Star = 1600,
	Data = 
	{
		0,0,0,0,0,0,0,2,0,2,0,2,0,3,0,0,2,0,0,5,0,2,0,0,0,4,0,0,0,0,2,0,0,0,0,2,0,0,0,2,2,3,2,0,2,0,2,0,0,0,2,0,0,2,0,0,0,0,0,0,0,0,0,0,
	},
	CatchQueue = 
	{
		5,4,2,3,
	},
	RewardList = {
		{
			Id = 327314,
			Num = 5,
		},
		{
			Id = 1,
			Num = 25000,
		},
	},
}
CatchFish_FishPoolConfig[CatchFish_FishPoolID.Id022] =
{
	Id = 22,
	Name = "热带鱼",
	CostItem = {
		Id = 327313,
		Num = 5,
	},
	PassCheckCostItem = {
		Id = 327313,
		Num = 2,
	},
	BuffList = {
		Desc = "男队员亲和 +{Value1}%",
		Buff = {
			{
				Id = 100692,
				Value = 75,
			},
		},
	},
	Desc = "队员亲和、智力增加能量，最多7人",
	NumCap = 7,
	CatchPoint = 180,
	Type = 1,
	SuppleFish = true,
	RankList = {
		{
			ExtraPoint = 0,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 0,
				},
				{
					Value = 200008,
					Num = 0,
				},
			},
		},
		{
			ExtraPoint = 8,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 80,
				},
				{
					Value = 200008,
					Num = 48,
				},
			},
		},
		{
			ExtraPoint = 16,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 160,
				},
				{
					Value = 200008,
					Num = 96,
				},
			},
		},
		{
			ExtraPoint = 24,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 240,
				},
				{
					Value = 200008,
					Num = 144,
				},
			},
		},
		{
			ExtraPoint = 30,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 320,
				},
				{
					Value = 200008,
					Num = 192,
				},
			},
		},
		{
			ExtraPoint = 35,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 400,
				},
				{
					Value = 200008,
					Num = 240,
				},
			},
		},
		{
			ExtraPoint = 40,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 500,
				},
				{
					Value = 200008,
					Num = 300,
				},
			},
		},
		{
			ExtraPoint = 45,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 600,
				},
				{
					Value = 200008,
					Num = 360,
				},
			},
		},
		{
			ExtraPoint = 50,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 700,
				},
				{
					Value = 200008,
					Num = 420,
				},
			},
		},
		{
			ExtraPoint = 55,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 800,
				},
				{
					Value = 200008,
					Num = 480,
				},
			},
		},
		{
			ExtraPoint = 60,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 900,
				},
				{
					Value = 200008,
					Num = 540,
				},
			},
		},
		{
			ExtraPoint = 65,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 1020,
				},
				{
					Value = 200008,
					Num = 612,
				},
			},
		},
		{
			ExtraPoint = 70,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 1140,
				},
				{
					Value = 200008,
					Num = 684,
				},
			},
		},
		{
			ExtraPoint = 75,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 1260,
				},
				{
					Value = 200008,
					Num = 756,
				},
			},
		},
		{
			ExtraPoint = 80,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 1380,
				},
				{
					Value = 200008,
					Num = 828,
				},
			},
		},
		{
			ExtraPoint = 85,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 1500,
				},
				{
					Value = 200008,
					Num = 900,
				},
			},
		},
		{
			ExtraPoint = 90,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 1640,
				},
				{
					Value = 200008,
					Num = 984,
				},
			},
		},
		{
			ExtraPoint = 95,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 1780,
				},
				{
					Value = 200008,
					Num = 1068,
				},
			},
		},
		{
			ExtraPoint = 100,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 1920,
				},
				{
					Value = 200008,
					Num = 1152,
				},
			},
		},
		{
			ExtraPoint = 105,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 2060,
				},
				{
					Value = 200008,
					Num = 1236,
				},
			},
		},
		{
			ExtraPoint = 110,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 2200,
				},
				{
					Value = 200008,
					Num = 1320,
				},
			},
		},
		{
			ExtraPoint = 115,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 2360,
				},
				{
					Value = 200008,
					Num = 1416,
				},
			},
		},
		{
			ExtraPoint = 120,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 2520,
				},
				{
					Value = 200008,
					Num = 1512,
				},
			},
		},
		{
			ExtraPoint = 125,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 2680,
				},
				{
					Value = 200008,
					Num = 1608,
				},
			},
		},
		{
			ExtraPoint = 130,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 2840,
				},
				{
					Value = 200008,
					Num = 1704,
				},
			},
		},
		{
			ExtraPoint = 135,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 3000,
				},
				{
					Value = 200008,
					Num = 1800,
				},
			},
		},
		{
			ExtraPoint = 140,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 3180,
				},
				{
					Value = 200008,
					Num = 1908,
				},
			},
		},
		{
			ExtraPoint = 145,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 3360,
				},
				{
					Value = 200008,
					Num = 2016,
				},
			},
		},
		{
			ExtraPoint = 150,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 3540,
				},
				{
					Value = 200008,
					Num = 2124,
				},
			},
		},
		{
			ExtraPoint = 155,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 3720,
				},
				{
					Value = 200008,
					Num = 2232,
				},
			},
		},
		{
			ExtraPoint = 160,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 3900,
				},
				{
					Value = 200008,
					Num = 2340,
				},
			},
		},
		{
			ExtraPoint = 165,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 4100,
				},
				{
					Value = 200008,
					Num = 2460,
				},
			},
		},
	},
	ObstacleNode = "Obstacle",
	Score1Star = 1400,
	Score2Star = 2100,
	Score3Star = 2800,
	Data = 
	{
		0,0,0,0,2,0,0,0,0,0,0,3,2,0,0,0,0,0,4,2,2,0,2,0,0,2,2,5,2,2,2,0,0,2,2,2,2,2,2,0,0,0,4,2,2,0,2,0,0,0,0,3,2,0,0,0,0,0,0,0,2,0,0,0,
	},
	CatchQueue = 
	{
		5,4,2,3,
	},
	RewardList = {
		{
			Id = 327314,
			Num = 5,
		},
		{
			Id = 1,
			Num = 25000,
		},
	},
}
CatchFish_FishPoolConfig[CatchFish_FishPoolID.Id023] =
{
	Id = 23,
	Name = "手里剑",
	CostItem = {
		Id = 327313,
		Num = 5,
	},
	PassCheckCostItem = {
		Id = 327313,
		Num = 2,
	},
	BuffList = {
		Desc = "女队员技巧 +{Value1}%",
		Buff = {
			{
				Id = 100699,
				Value = 75,
			},
		},
	},
	Desc = "队员技巧、智力增加能量，最多7人",
	NumCap = 7,
	CatchPoint = 150,
	Type = 1,
	SuppleFish = true,
	RankList = {
		{
			ExtraPoint = 0,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 0,
				},
				{
					Value = 200008,
					Num = 0,
				},
			},
		},
		{
			ExtraPoint = 8,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 80,
				},
				{
					Value = 200008,
					Num = 48,
				},
			},
		},
		{
			ExtraPoint = 16,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 160,
				},
				{
					Value = 200008,
					Num = 96,
				},
			},
		},
		{
			ExtraPoint = 24,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 240,
				},
				{
					Value = 200008,
					Num = 144,
				},
			},
		},
		{
			ExtraPoint = 30,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 320,
				},
				{
					Value = 200008,
					Num = 192,
				},
			},
		},
		{
			ExtraPoint = 35,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 400,
				},
				{
					Value = 200008,
					Num = 240,
				},
			},
		},
		{
			ExtraPoint = 40,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 500,
				},
				{
					Value = 200008,
					Num = 300,
				},
			},
		},
		{
			ExtraPoint = 45,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 600,
				},
				{
					Value = 200008,
					Num = 360,
				},
			},
		},
		{
			ExtraPoint = 50,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 700,
				},
				{
					Value = 200008,
					Num = 420,
				},
			},
		},
		{
			ExtraPoint = 55,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 800,
				},
				{
					Value = 200008,
					Num = 480,
				},
			},
		},
		{
			ExtraPoint = 60,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 900,
				},
				{
					Value = 200008,
					Num = 540,
				},
			},
		},
		{
			ExtraPoint = 65,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 1020,
				},
				{
					Value = 200008,
					Num = 612,
				},
			},
		},
		{
			ExtraPoint = 70,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 1140,
				},
				{
					Value = 200008,
					Num = 684,
				},
			},
		},
		{
			ExtraPoint = 75,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 1260,
				},
				{
					Value = 200008,
					Num = 756,
				},
			},
		},
		{
			ExtraPoint = 80,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 1380,
				},
				{
					Value = 200008,
					Num = 828,
				},
			},
		},
		{
			ExtraPoint = 85,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 1500,
				},
				{
					Value = 200008,
					Num = 900,
				},
			},
		},
		{
			ExtraPoint = 90,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 1640,
				},
				{
					Value = 200008,
					Num = 984,
				},
			},
		},
		{
			ExtraPoint = 95,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 1780,
				},
				{
					Value = 200008,
					Num = 1068,
				},
			},
		},
		{
			ExtraPoint = 100,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 1920,
				},
				{
					Value = 200008,
					Num = 1152,
				},
			},
		},
		{
			ExtraPoint = 105,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 2060,
				},
				{
					Value = 200008,
					Num = 1236,
				},
			},
		},
		{
			ExtraPoint = 110,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 2200,
				},
				{
					Value = 200008,
					Num = 1320,
				},
			},
		},
		{
			ExtraPoint = 115,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 2360,
				},
				{
					Value = 200008,
					Num = 1416,
				},
			},
		},
		{
			ExtraPoint = 120,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 2520,
				},
				{
					Value = 200008,
					Num = 1512,
				},
			},
		},
		{
			ExtraPoint = 125,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 2680,
				},
				{
					Value = 200008,
					Num = 1608,
				},
			},
		},
		{
			ExtraPoint = 130,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 2840,
				},
				{
					Value = 200008,
					Num = 1704,
				},
			},
		},
		{
			ExtraPoint = 135,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 3000,
				},
				{
					Value = 200008,
					Num = 1800,
				},
			},
		},
		{
			ExtraPoint = 140,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 3180,
				},
				{
					Value = 200008,
					Num = 1908,
				},
			},
		},
		{
			ExtraPoint = 145,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 3360,
				},
				{
					Value = 200008,
					Num = 2016,
				},
			},
		},
		{
			ExtraPoint = 150,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 3540,
				},
				{
					Value = 200008,
					Num = 2124,
				},
			},
		},
	},
	ObstacleNode = "Obstacle",
	Score1Star = 1000,
	Score2Star = 1500,
	Score3Star = 2000,
	Data = 
	{
		0,0,0,0,0,0,0,0,0,2,2,0,0,0,2,0,0,0,2,2,0,2,2,0,0,0,0,4,3,2,0,0,0,0,2,3,5,0,0,0,0,2,2,0,2,2,0,0,0,2,0,0,0,2,2,0,0,0,0,0,0,0,0,0,
	},
	CatchQueue = 
	{
		5,4,2,3,
	},
	RewardList = {
		{
			Id = 327314,
			Num = 5,
		},
		{
			Id = 1,
			Num = 25000,
		},
	},
}
CatchFish_FishPoolConfig[CatchFish_FishPoolID.Id024] =
{
	Id = 24,
	Name = "天罗地网",
	CostItem = {
		Id = 327313,
		Num = 5,
	},
	PassCheckCostItem = {
		Id = 327313,
		Num = 2,
	},
	BuffList = {
		Desc = "女队员力气 +{Value1}%",
		Buff = {
			{
				Id = 100701,
				Value = 75,
			},
		},
	},
	Desc = "队员力气、智力增加能量，最多7人",
	NumCap = 7,
	CatchPoint = 180,
	Type = 1,
	SuppleFish = true,
	RankList = {
		{
			ExtraPoint = 0,
			NeedAttribute = {
				{
					Value = 200007,
					Num = 0,
				},
				{
					Value = 200008,
					Num = 0,
				},
			},
		},
		{
			ExtraPoint = 8,
			NeedAttribute = {
				{
					Value = 200007,
					Num = 80,
				},
				{
					Value = 200008,
					Num = 48,
				},
			},
		},
		{
			ExtraPoint = 16,
			NeedAttribute = {
				{
					Value = 200007,
					Num = 160,
				},
				{
					Value = 200008,
					Num = 96,
				},
			},
		},
		{
			ExtraPoint = 24,
			NeedAttribute = {
				{
					Value = 200007,
					Num = 240,
				},
				{
					Value = 200008,
					Num = 144,
				},
			},
		},
		{
			ExtraPoint = 30,
			NeedAttribute = {
				{
					Value = 200007,
					Num = 320,
				},
				{
					Value = 200008,
					Num = 192,
				},
			},
		},
		{
			ExtraPoint = 35,
			NeedAttribute = {
				{
					Value = 200007,
					Num = 400,
				},
				{
					Value = 200008,
					Num = 240,
				},
			},
		},
		{
			ExtraPoint = 40,
			NeedAttribute = {
				{
					Value = 200007,
					Num = 500,
				},
				{
					Value = 200008,
					Num = 300,
				},
			},
		},
		{
			ExtraPoint = 45,
			NeedAttribute = {
				{
					Value = 200007,
					Num = 600,
				},
				{
					Value = 200008,
					Num = 360,
				},
			},
		},
		{
			ExtraPoint = 50,
			NeedAttribute = {
				{
					Value = 200007,
					Num = 700,
				},
				{
					Value = 200008,
					Num = 420,
				},
			},
		},
		{
			ExtraPoint = 55,
			NeedAttribute = {
				{
					Value = 200007,
					Num = 800,
				},
				{
					Value = 200008,
					Num = 480,
				},
			},
		},
		{
			ExtraPoint = 60,
			NeedAttribute = {
				{
					Value = 200007,
					Num = 900,
				},
				{
					Value = 200008,
					Num = 540,
				},
			},
		},
		{
			ExtraPoint = 65,
			NeedAttribute = {
				{
					Value = 200007,
					Num = 1020,
				},
				{
					Value = 200008,
					Num = 612,
				},
			},
		},
		{
			ExtraPoint = 70,
			NeedAttribute = {
				{
					Value = 200007,
					Num = 1140,
				},
				{
					Value = 200008,
					Num = 684,
				},
			},
		},
		{
			ExtraPoint = 75,
			NeedAttribute = {
				{
					Value = 200007,
					Num = 1260,
				},
				{
					Value = 200008,
					Num = 756,
				},
			},
		},
		{
			ExtraPoint = 80,
			NeedAttribute = {
				{
					Value = 200007,
					Num = 1380,
				},
				{
					Value = 200008,
					Num = 828,
				},
			},
		},
		{
			ExtraPoint = 85,
			NeedAttribute = {
				{
					Value = 200007,
					Num = 1500,
				},
				{
					Value = 200008,
					Num = 900,
				},
			},
		},
		{
			ExtraPoint = 90,
			NeedAttribute = {
				{
					Value = 200007,
					Num = 1640,
				},
				{
					Value = 200008,
					Num = 984,
				},
			},
		},
		{
			ExtraPoint = 95,
			NeedAttribute = {
				{
					Value = 200007,
					Num = 1780,
				},
				{
					Value = 200008,
					Num = 1068,
				},
			},
		},
		{
			ExtraPoint = 100,
			NeedAttribute = {
				{
					Value = 200007,
					Num = 1920,
				},
				{
					Value = 200008,
					Num = 1152,
				},
			},
		},
		{
			ExtraPoint = 105,
			NeedAttribute = {
				{
					Value = 200007,
					Num = 2060,
				},
				{
					Value = 200008,
					Num = 1236,
				},
			},
		},
		{
			ExtraPoint = 110,
			NeedAttribute = {
				{
					Value = 200007,
					Num = 2200,
				},
				{
					Value = 200008,
					Num = 1320,
				},
			},
		},
		{
			ExtraPoint = 115,
			NeedAttribute = {
				{
					Value = 200007,
					Num = 2360,
				},
				{
					Value = 200008,
					Num = 1416,
				},
			},
		},
		{
			ExtraPoint = 120,
			NeedAttribute = {
				{
					Value = 200007,
					Num = 2520,
				},
				{
					Value = 200008,
					Num = 1512,
				},
			},
		},
		{
			ExtraPoint = 125,
			NeedAttribute = {
				{
					Value = 200007,
					Num = 2680,
				},
				{
					Value = 200008,
					Num = 1608,
				},
			},
		},
		{
			ExtraPoint = 130,
			NeedAttribute = {
				{
					Value = 200007,
					Num = 2840,
				},
				{
					Value = 200008,
					Num = 1704,
				},
			},
		},
		{
			ExtraPoint = 135,
			NeedAttribute = {
				{
					Value = 200007,
					Num = 3000,
				},
				{
					Value = 200008,
					Num = 1800,
				},
			},
		},
		{
			ExtraPoint = 140,
			NeedAttribute = {
				{
					Value = 200007,
					Num = 3180,
				},
				{
					Value = 200008,
					Num = 1908,
				},
			},
		},
		{
			ExtraPoint = 145,
			NeedAttribute = {
				{
					Value = 200007,
					Num = 3360,
				},
				{
					Value = 200008,
					Num = 2016,
				},
			},
		},
		{
			ExtraPoint = 150,
			NeedAttribute = {
				{
					Value = 200007,
					Num = 3540,
				},
				{
					Value = 200008,
					Num = 2124,
				},
			},
		},
	},
	ObstacleNode = "Obstacle",
	Score1Star = 1200,
	Score2Star = 2000,
	Score3Star = 2800,
	Data = 
	{
		0,0,0,0,0,0,0,0,0,5,0,2,0,2,3,0,0,0,2,0,2,0,2,0,0,2,0,4,0,2,0,0,0,0,2,0,4,0,2,0,0,2,0,2,0,2,0,0,0,3,2,0,2,0,5,0,0,0,0,0,0,0,0,0,
	},
	CatchQueue = 
	{
		5,4,2,3,
	},
	RewardList = {
		{
			Id = 327314,
			Num = 5,
		},
		{
			Id = 1,
			Num = 25000,
		},
	},
}
CatchFish_FishPoolConfig[CatchFish_FishPoolID.Id025] =
{
	Id = 25,
	Name = "鱼塘大挑战",
	CostItem = {
		Id = 327313,
		Num = 3,
	},
	PassCheckCostItem = {
		Id = 327313,
		Num = 1,
	},
	BuffList = {
		Desc = "男队员力气 +{Value1}%\n女队员智力 +{Value2}%",
		Buff = {
			{
				Id = 100693,
				Value = 50,
			},
			{
				Id = 100702,
				Value = 50,
			},
		},
	},
	Desc = "队员力气、智力增加能量，最多7人",
	NumCap = 7,
	CatchPoint = 200,
	Type = 2,
	SuppleFish = true,
	RankList = {
		{
			ExtraPoint = 0,
			NeedAttribute = {
				{
					Value = 200007,
					Num = 0,
				},
				{
					Value = 200008,
					Num = 0,
				},
			},
		},
		{
			ExtraPoint = 8,
			NeedAttribute = {
				{
					Value = 200007,
					Num = 80,
				},
				{
					Value = 200008,
					Num = 48,
				},
			},
		},
		{
			ExtraPoint = 16,
			NeedAttribute = {
				{
					Value = 200007,
					Num = 160,
				},
				{
					Value = 200008,
					Num = 96,
				},
			},
		},
		{
			ExtraPoint = 24,
			NeedAttribute = {
				{
					Value = 200007,
					Num = 240,
				},
				{
					Value = 200008,
					Num = 144,
				},
			},
		},
		{
			ExtraPoint = 30,
			NeedAttribute = {
				{
					Value = 200007,
					Num = 320,
				},
				{
					Value = 200008,
					Num = 192,
				},
			},
		},
		{
			ExtraPoint = 35,
			NeedAttribute = {
				{
					Value = 200007,
					Num = 400,
				},
				{
					Value = 200008,
					Num = 240,
				},
			},
		},
		{
			ExtraPoint = 40,
			NeedAttribute = {
				{
					Value = 200007,
					Num = 500,
				},
				{
					Value = 200008,
					Num = 300,
				},
			},
		},
		{
			ExtraPoint = 45,
			NeedAttribute = {
				{
					Value = 200007,
					Num = 600,
				},
				{
					Value = 200008,
					Num = 360,
				},
			},
		},
		{
			ExtraPoint = 50,
			NeedAttribute = {
				{
					Value = 200007,
					Num = 700,
				},
				{
					Value = 200008,
					Num = 420,
				},
			},
		},
		{
			ExtraPoint = 55,
			NeedAttribute = {
				{
					Value = 200007,
					Num = 800,
				},
				{
					Value = 200008,
					Num = 480,
				},
			},
		},
		{
			ExtraPoint = 60,
			NeedAttribute = {
				{
					Value = 200007,
					Num = 900,
				},
				{
					Value = 200008,
					Num = 540,
				},
			},
		},
		{
			ExtraPoint = 65,
			NeedAttribute = {
				{
					Value = 200007,
					Num = 1020,
				},
				{
					Value = 200008,
					Num = 612,
				},
			},
		},
		{
			ExtraPoint = 70,
			NeedAttribute = {
				{
					Value = 200007,
					Num = 1140,
				},
				{
					Value = 200008,
					Num = 684,
				},
			},
		},
		{
			ExtraPoint = 75,
			NeedAttribute = {
				{
					Value = 200007,
					Num = 1260,
				},
				{
					Value = 200008,
					Num = 756,
				},
			},
		},
		{
			ExtraPoint = 80,
			NeedAttribute = {
				{
					Value = 200007,
					Num = 1380,
				},
				{
					Value = 200008,
					Num = 828,
				},
			},
		},
		{
			ExtraPoint = 85,
			NeedAttribute = {
				{
					Value = 200007,
					Num = 1500,
				},
				{
					Value = 200008,
					Num = 900,
				},
			},
		},
		{
			ExtraPoint = 90,
			NeedAttribute = {
				{
					Value = 200007,
					Num = 1640,
				},
				{
					Value = 200008,
					Num = 984,
				},
			},
		},
		{
			ExtraPoint = 95,
			NeedAttribute = {
				{
					Value = 200007,
					Num = 1780,
				},
				{
					Value = 200008,
					Num = 1068,
				},
			},
		},
		{
			ExtraPoint = 100,
			NeedAttribute = {
				{
					Value = 200007,
					Num = 1920,
				},
				{
					Value = 200008,
					Num = 1152,
				},
			},
		},
		{
			ExtraPoint = 105,
			NeedAttribute = {
				{
					Value = 200007,
					Num = 2060,
				},
				{
					Value = 200008,
					Num = 1236,
				},
			},
		},
		{
			ExtraPoint = 110,
			NeedAttribute = {
				{
					Value = 200007,
					Num = 2200,
				},
				{
					Value = 200008,
					Num = 1320,
				},
			},
		},
		{
			ExtraPoint = 115,
			NeedAttribute = {
				{
					Value = 200007,
					Num = 2360,
				},
				{
					Value = 200008,
					Num = 1416,
				},
			},
		},
		{
			ExtraPoint = 120,
			NeedAttribute = {
				{
					Value = 200007,
					Num = 2520,
				},
				{
					Value = 200008,
					Num = 1512,
				},
			},
		},
		{
			ExtraPoint = 125,
			NeedAttribute = {
				{
					Value = 200007,
					Num = 2680,
				},
				{
					Value = 200008,
					Num = 1608,
				},
			},
		},
		{
			ExtraPoint = 130,
			NeedAttribute = {
				{
					Value = 200007,
					Num = 2840,
				},
				{
					Value = 200008,
					Num = 1704,
				},
			},
		},
		{
			ExtraPoint = 135,
			NeedAttribute = {
				{
					Value = 200007,
					Num = 3000,
				},
				{
					Value = 200008,
					Num = 1800,
				},
			},
		},
		{
			ExtraPoint = 140,
			NeedAttribute = {
				{
					Value = 200007,
					Num = 3180,
				},
				{
					Value = 200008,
					Num = 1908,
				},
			},
		},
		{
			ExtraPoint = 145,
			NeedAttribute = {
				{
					Value = 200007,
					Num = 3360,
				},
				{
					Value = 200008,
					Num = 2016,
				},
			},
		},
		{
			ExtraPoint = 150,
			NeedAttribute = {
				{
					Value = 200007,
					Num = 3540,
				},
				{
					Value = 200008,
					Num = 2124,
				},
			},
		},
		{
			ExtraPoint = 155,
			NeedAttribute = {
				{
					Value = 200007,
					Num = 3720,
				},
				{
					Value = 200008,
					Num = 2232,
				},
			},
		},
		{
			ExtraPoint = 160,
			NeedAttribute = {
				{
					Value = 200007,
					Num = 3900,
				},
				{
					Value = 200008,
					Num = 2340,
				},
			},
		},
		{
			ExtraPoint = 165,
			NeedAttribute = {
				{
					Value = 200007,
					Num = 4100,
				},
				{
					Value = 200008,
					Num = 2460,
				},
			},
		},
		{
			ExtraPoint = 170,
			NeedAttribute = {
				{
					Value = 200007,
					Num = 4300,
				},
				{
					Value = 200008,
					Num = 2580,
				},
			},
		},
		{
			ExtraPoint = 175,
			NeedAttribute = {
				{
					Value = 200007,
					Num = 4500,
				},
				{
					Value = 200008,
					Num = 2700,
				},
			},
		},
		{
			ExtraPoint = 180,
			NeedAttribute = {
				{
					Value = 200007,
					Num = 4700,
				},
				{
					Value = 200008,
					Num = 2820,
				},
			},
		},
		{
			ExtraPoint = 185,
			NeedAttribute = {
				{
					Value = 200007,
					Num = 4900,
				},
				{
					Value = 200008,
					Num = 2940,
				},
			},
		},
		{
			ExtraPoint = 190,
			NeedAttribute = {
				{
					Value = 200007,
					Num = 5120,
				},
				{
					Value = 200008,
					Num = 3072,
				},
			},
		},
		{
			ExtraPoint = 195,
			NeedAttribute = {
				{
					Value = 200007,
					Num = 5340,
				},
				{
					Value = 200008,
					Num = 3204,
				},
			},
		},
		{
			ExtraPoint = 200,
			NeedAttribute = {
				{
					Value = 200007,
					Num = 5560,
				},
				{
					Value = 200008,
					Num = 3336,
				},
			},
		},
	},
	ObstacleNode = "Obstacle",
	Score1Star = 700,
	Score2Star = 900,
	Score3Star = 1050,
	Data = 
	{
		4,0,0,2,0,0,0,2,0,0,0,0,0,2,0,0,2,0,0,5,0,2,0,0,0,0,0,0,0,0,0,2,0,0,0,0,0,0,0,2,2,0,2,0,2,0,0,0,0,3,2,0,2,0,0,0,0,0,0,0,0,0,3,0,
	},
	CatchQueue = 
	{
		5,4,2,3,
	},
}

