
GoalConfig[GoalID.Id001] =
{
	Id = 1,
	Name = "主线1 - 初次探索",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130001,
	},
	GoalTrigger = 
	{
		TriggerType.Explore,
	},
	GoalCondition = 
	{
		{
			Name = "上头有令！探索冒险星[FDDE40]着陆点1分30秒[-]",
			Type = ItemType.Time,
			CountType = GoalCountType.StartNow,
			Num = 90,
			Value = 130001,
		},
	},
	CompleteSpeech = 30000101,
	Reward = {
		{
			Value = 320401,
			Num = 4,
		},
		{
			Value = 130002,
			Num = 1,
		},
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id002] =
{
	Id = 2,
	Name = "主线2 - 绿史莱姆的挑战",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130002,
		PreGoal = 
		{
			300001,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Challenge,
	},
	GoalCondition = 
	{
		{
			Name = "打败初始城镇的[FDDE40]史莱姆代表[-]",
			Type = ItemType.Challenge,
			CountType = GoalCountType.Current,
			Num = 1,
			Value = 140001,
		},
	},
	Reward = {
		{
			Value = 320401,
			Num = 4,
		},
		{
			Value = 1,
			Num = 150,
		},
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id003] =
{
	Id = 3,
	Name = "主线3 - 学习升级",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130002,
		PreGoal = 
		{
			300002,
		},
	},
	GoalTrigger = 
	{
		TriggerType.CollectItem,
	},
	GoalCondition = 
	{
		{
			Name = "尝试一下升级操作。\n拥有至少[62E7E7]2级[-][FDDE40]呜呜[-]",
			Type = ItemType.Character,
			CountType = GoalCountType.Current,
			Num = 1,
			Value = 220001,
			Level = 2,
		},
	},
	Reward = {
		{
			Value = 320401,
			Num = 4,
		},
		{
			Value = 1,
			Num = 200,
		},
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id004] =
{
	Id = 4,
	Name = "主线4 - 野花丛的挑战",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130002,
		PreGoal = 
		{
			300003,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Challenge,
	},
	GoalCondition = 
	{
		{
			Name = "打败初始城镇的[FDDE40]野花丛[-]",
			Type = ItemType.Challenge,
			CountType = GoalCountType.Current,
			Num = 1,
			Value = 140002,
		},
	},
	Reward = {
		{
			Value = 320401,
			Num = 4,
		},
		{
			Value = 1,
			Num = 200,
		},
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id005] =
{
	Id = 5,
	Name = "主线5 - 居民的委托",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130002,
		PreGoal = 
		{
			300004,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Explore,
	},
	GoalCondition = 
	{
		{
			Name = "家里附近出现了怪物，请帮帮我！\n探索[FDDE40]冒险星[-]1分钟30秒",
			Type = ItemType.Time,
			CountType = GoalCountType.StartNow,
			Num = 90,
			Value = 120001,
		},
	},
	CompleteSpeech = 30000501,
	Reward = {
		{
			Value = 220011,
			Num = 1,
		},
		{
			Value = 160001,
			Num = 1,
		},
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id006] =
{
	Id = 6,
	Name = "主线6 - 道具店开张",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130002,
		PreGoal = 
		{
			300005,
		},
	},
	GoalTrigger = 
	{
		TriggerType.WorkShop,
	},
	GoalCondition = 
	{
		{
			Name = "道具店开张，让居民NPC去试工看看。\n在道具店打工获得[FDDE40]小血瓶[-]1个",
			Type = ItemType.Goods,
			CountType = GoalCountType.StartNow,
			Num = 1,
			Value = 320402,
		},
	},
	CompleteSpeech = 30000601,
	Reward = {
		{
			Value = 320402,
			Num = 3,
		},
		{
			Value = 1,
			Num = 300,
		},
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id007] =
{
	Id = 7,
	Name = "主线7 - 复习升级",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130002,
		PreGoal = 
		{
			300006,
		},
	},
	GoalTrigger = 
	{
		TriggerType.CollectItem,
	},
	GoalCondition = 
	{
		{
			Name = "再复习一下升级操作，这次直接到5级吧。\n拥有至少[62E7E7]5级[-][FDDE40]呜呜[-]",
			Type = ItemType.Character,
			CountType = GoalCountType.Current,
			Num = 1,
			Value = 220001,
			Level = 5,
		},
	},
	Reward = {
		{
			Value = 1,
			Num = 200,
		},
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id008] =
{
	Id = 8,
	Name = "主线8 - 花球老大的挑战",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130002,
		PreGoal = 
		{
			300007,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Challenge,
	},
	GoalCondition = 
	{
		{
			Name = "打败初始城镇的[FDDE40]花球老大[-]",
			Type = ItemType.Challenge,
			CountType = GoalCountType.Current,
			Num = 1,
			Value = 140003,
		},
	},
	CompleteSpeech = 30000801,
	Reward = {
		{
			Value = 321001,
			Num = 5,
		},
		{
			Value = 1,
			Num = 200,
		},
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id009] =
{
	Id = 9,
	Name = "主线9 - 调查当地素材",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130002,
		PreGoal = 
		{
			300008,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Explore,
	},
	GoalCondition = 
	{
		{
			Name = "打败花丛好像会掉落素材诶~\n探索冒险星[FDDE40]初始城镇[-]1分钟30秒",
			Type = ItemType.Time,
			CountType = GoalCountType.StartNow,
			Num = 90,
			Value = 130002,
		},
	},
	Reward = {
		{
			Value = 1,
			Num = 200,
		},
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id010] =
{
	Id = 10,
	Name = "主线10 - 紧急委托？",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130002,
		PreGoal = 
		{
			300009,
		},
	},
	GoalTrigger = 
	{
		TriggerType.CompleteDemand,
	},
	GoalCondition = 
	{
		{
			Name = "收到了来自神秘人的紧急委托。\n查看并完成[FDDE40]委托[-]1次。",
			Type = ItemType.Demand,
			CountType = GoalCountType.StartNow,
			Num = 1,
			Value = -1,
		},
	},
	Reward = {
		{
			Value = 320051,
			Num = 2,
		},
		{
			Value = 1,
			Num = 200,
		},
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id011] =
{
	Id = 11,
	Name = "主线11 - 升级呜呜装备",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130002,
		PreGoal = 
		{
			300010,
		},
	},
	GoalTrigger = 
	{
		TriggerType.UpgradeEquipment,
	},
	GoalCondition = 
	{
		{
			Name = "强化[FDDE40]项圈[-](呜呜装备)1次",
			Type = ItemType.Equipment,
			CountType = GoalCountType.Current,
			Num = 1,
			Value = 340001,
		},
	},
	CompleteSpeech = 30001101,
	Reward = {
		{
			Value = 1,
			Num = 500,
		},
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id012] =
{
	Id = 12,
	Name = "主线12 - 继续升级漆漆",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130002,
		PreGoal = 
		{
			300011,
		},
	},
	GoalTrigger = 
	{
		TriggerType.CollectItem,
	},
	GoalCondition = 
	{
		{
			Name = "攻击型队员升级后打人更痛！\n拥有至少[62E7E7]5级[-][FDDE40]漆漆[-]",
			Type = ItemType.Character,
			CountType = GoalCountType.Current,
			Num = 1,
			Value = 220002,
			Level = 5,
		},
	},
	Reward = {
		{
			Value = 1,
			Num = 200,
		},
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id013] =
{
	Id = 13,
	Name = "主线13 - 剑士的挑战",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130002,
		PreGoal = 
		{
			300012,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Challenge,
	},
	GoalCondition = 
	{
		{
			Name = "有个冒险者一直偷偷观察我们…\n打败初始城镇的[FDDE40]剑士[-]",
			Type = ItemType.Challenge,
			CountType = GoalCountType.Current,
			Num = 1,
			Value = 140004,
		},
	},
	CompleteSpeech = 30001301,
	Reward = {
		{
			Value = 130003,
			Num = 1,
		},
		{
			Value = 1,
			Num = 200,
		},
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id014] =
{
	Id = 14,
	Name = "主线14 - 探索的准备",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130002,
		PreGoal = 
		{
			300013,
		},
	},
	GoalTrigger = 
	{
		TriggerType.CollectItem,
	},
	GoalCondition = 
	{
		{
			Name = "探索的时候食物要准备充足噢~\n拥有[FDDE40]小血瓶[-]1个",
			Type = ItemType.Goods,
			CountType = GoalCountType.Current,
			Num = 1,
			Value = 320402,
		},
	},
	Reward = {
		{
			Value = 220013,
			Num = 1,
		},
		{
			Value = 1,
			Num = 500,
		},
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id015] =
{
	Id = 15,
	Name = "主线15 - 剑士升级",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130002,
		PreGoal = 
		{
			300014,
		},
	},
	GoalTrigger = 
	{
		TriggerType.CollectItem,
	},
	GoalCondition = 
	{
		{
			Name = "拥有至少[62E7E7]5级[-][FDDE40]剑士[-]",
			Type = ItemType.Character,
			CountType = GoalCountType.Current,
			Num = 1,
			Value = 220003,
			Level = 5,
		},
	},
	Reward = {
		{
			Value = 1,
			Num = 200,
		},
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id016] =
{
	Id = 16,
	Name = "主线16 - 老伴走丢了…",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130002,
		PreGoal = 
		{
			300015,
		},
	},
	GoalTrigger = 
	{
		TriggerType.ExploreCost,
	},
	GoalCondition = 
	{
		{
			Name = "整天说去发布任务，这次去了三天还没回来。\n探索[62E7E7]村口树林[-]消耗[FDDE40]小血瓶[-]1个",
			Type = ItemType.Goods,
			CountType = GoalCountType.StartNow,
			Num = 1,
			Value = 320402,
			Area = 130003,
		},
	},
	CompleteSpeech = 30001601,
	Reward = {
		{
			Value = 220012,
			Num = 1,
		},
		{
			Value = 1,
			Num = 200,
		},
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id017] =
{
	Id = 17,
	Name = "主线17 - 精英大树怪的挑战",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130003,
		PreGoal = 
		{
			300016,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Challenge,
	},
	GoalCondition = 
	{
		{
			Name = "打败村口树林的[FDDE40]精英大树怪[-]",
			Type = ItemType.Challenge,
			CountType = GoalCountType.Current,
			Num = 1,
			Value = 140005,
		},
	},
	CompleteSpeech = 30001701,
	Reward = {
		{
			Value = 1,
			Num = 600,
		},
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id018] =
{
	Id = 18,
	Name = "主线18 - 道具店装修2",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130002,
		PreGoal = 
		{
			300017,
		},
	},
	GoalTrigger = 
	{
		TriggerType.CollectItem,
	},
	GoalCondition = 
	{
		{
			Name = "道具店招商中，有钱请务必投资小店。\n拥有至少[62E7E7]2级[-][FDDE40]道具店[-]",
			Type = ItemType.WorkShop,
			CountType = GoalCountType.Current,
			Num = 1,
			Value = 160001,
			Level = 2,
		},
	},
	CompleteSpeech = 30001801,
	Reward = {
		{
			Value = 1,
			Num = 200,
		},
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id019] =
{
	Id = 19,
	Name = "主线19 - 道具店打工2",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130002,
		PreGoal = 
		{
			300018,
		},
	},
	GoalTrigger = 
	{
		TriggerType.WorkShopRank,
	},
	GoalCondition = 
	{
		{
			Name = "提升[FDDE40]道具店[-]打工评价至[FDDE40]F[-]\n推荐[62E7E7]居民NPC[-]和[62E7E7]村长夫人[-]上场",
			Type = ItemType.WorkShop,
			CountType = GoalCountType.Current,
			Num = 1,
			Value = 160001,
			Rank = 3,
		},
	},
	Reward = {
		{
			Value = 1,
			Num = 200,
		},
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id020] =
{
	Id = 20,
	Name = "主线20 - 树桩猴老大的挑战",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130003,
		PreGoal = 
		{
			300019,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Challenge,
	},
	GoalCondition = 
	{
		{
			Name = "打败村口树林的[FDDE40]树桩猴老大[-]",
			Type = ItemType.Challenge,
			CountType = GoalCountType.Current,
			Num = 1,
			Value = 140006,
		},
	},
	CompleteSpeech = 30002001,
	Reward = {
		{
			Value = 1,
			Num = 200,
		},
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id021] =
{
	Id = 21,
	Name = "主线21 - 村长升级",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130003,
		PreGoal = 
		{
			300020,
		},
	},
	GoalTrigger = 
	{
		TriggerType.CollectItem,
	},
	GoalCondition = 
	{
		{
			Name = "村长说不升级他，他就躺在地上打滚。\n拥有至少[62E7E7]5级[-][FDDE40]村长[-]",
			Type = ItemType.Character,
			CountType = GoalCountType.Current,
			Num = 1,
			Value = 220012,
			Level = 5,
		},
	},
	Reward = {
		{
			Value = 1,
			Num = 200,
		},
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id022] =
{
	Id = 22,
	Name = "主线22 - 非礼勿视",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130003,
		PreGoal = 
		{
			300021,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Explore,
	},
	GoalCondition = 
	{
		{
			Name = "村长说这次带我们去开开眼界~\n派遣[62E7E7]剑士[-]、[62E7E7]村长[-]探索冒险星[FDDE40]村口树林[-]15分钟",
			Type = ItemType.Time,
			CountType = GoalCountType.StartNow,
			Num = 900,
			Character = 
			{
				220003,
				220012,
			},
			Value = 130003,
		},
	},
	Reward = {
		{
			Value = 1,
			Num = 200,
		},
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id023] =
{
	Id = 23,
	Name = "主线23 - 弓箭手的挑战",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130003,
		PreGoal = 
		{
			300022,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Challenge,
	},
	GoalCondition = 
	{
		{
			Name = "打败村口树林的[FDDE40]弓箭手[-]",
			Type = ItemType.Challenge,
			CountType = GoalCountType.Current,
			Num = 1,
			Value = 140007,
		},
	},
	CompleteSpeech = 30002301,
	Reward = {
		{
			Value = 130004,
			Num = 1,
		},
		{
			Value = 330001,
			Num = 1,
		},
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id024] =
{
	Id = 24,
	Name = "主线24 - 初入不夜城",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130003,
		PreGoal = 
		{
			300023,
		},
	},
	GoalTrigger = 
	{
		TriggerType.CollectItem,
	},
	GoalCondition = 
	{
		{
			Name = "在不夜城[FDDE40]初级金币池[-]中抽卡1次",
			Type = ItemType.Character,
			CountType = GoalCountType.Current,
			Num = 1,
			Value = 220010,
		},
	},
	CompleteSpeech = 30002401,
	Reward = {
		{
			Value = 330001,
			Num = 1,
		},
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id025] =
{
	Id = 25,
	Name = "主线25 - 树叶的委托",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130002,
		PreGoal = 
		{
			300024,
		},
	},
	GoalTrigger = 
	{
		TriggerType.DemandCost,
	},
	GoalCondition = 
	{
		{
			Name = "如果只要树叶的话，就去初始城镇吧！\n在委托中提交[FDDE40]树叶[-]10个",
			Type = ItemType.Goods,
			CountType = GoalCountType.StartNow,
			Num = 10,
			Value = 321001,
		},
	},
	Reward = {
		{
			Value = 360001,
			Num = 1,
		},
		{
			Value = 321001,
			Num = 2,
		},
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id026] =
{
	Id = 26,
	Name = "主线26 - 合成食物",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130002,
		PreGoal = 
		{
			300025,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Craft,
	},
	GoalCondition = 
	{
		{
			Name = "在实验室合成获得[FDDE40]简单口粮[-]2个",
			Type = ItemType.Goods,
			CountType = GoalCountType.StartNow,
			Num = 2,
			Value = 320401,
		},
	},
	CompleteSpeech = 30002601,
	Reward = {
		{
			Value = 330001,
			Num = 1,
		},
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id027] =
{
	Id = 27,
	Name = "主线27 - 升级弓箭手",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130002,
		PreGoal = 
		{
			300026,
		},
	},
	GoalTrigger = 
	{
		TriggerType.CollectItem,
	},
	GoalCondition = 
	{
		{
			Name = "拥有至少[62E7E7]5级[-][FDDE40]弓箭手[-]",
			Type = ItemType.Character,
			CountType = GoalCountType.Current,
			Num = 1,
			Value = 220004,
			Level = 5,
		},
	},
	Reward = {
		{
			Value = 330001,
			Num = 1,
		},
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id028] =
{
	Id = 28,
	Name = "主线28 - 侦查溪谷",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130002,
		PreGoal = 
		{
			300027,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Explore,
	},
	GoalCondition = 
	{
		{
			Name = "派遣[62E7E7]剑士[-]、[62E7E7]弓箭手[-]在探索中击败[FDDE40]大树怪[-]2个，建议探索12分钟以上",
			Type = ItemType.Enemy,
			CountType = GoalCountType.StartNow,
			Num = 2,
			Character = 
			{
				220003,
				220004,
			},
			Value = 242007,
		},
	},
	Reward = {
		{
			Value = 330001,
			Num = 1,
		},
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id029] =
{
	Id = 29,
	Name = "主线29 - 升级魔法师",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130002,
		PreGoal = 
		{
			300028,
		},
	},
	GoalTrigger = 
	{
		TriggerType.CollectItem,
	},
	GoalCondition = 
	{
		{
			Name = "紫色品质角色升级更贵，不过成长更高。\n拥有至少[62E7E7]5级[-][FDDE40]魔法师[-]",
			Type = ItemType.Character,
			CountType = GoalCountType.Current,
			Num = 1,
			Value = 220010,
			Level = 5,
		},
	},
	Reward = {
		{
			Value = 330001,
			Num = 1,
		},
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id030] =
{
	Id = 30,
	Name = "主线30 - 野狼队长的挑战",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130004,
		PreGoal = 
		{
			300029,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Challenge,
	},
	GoalCondition = 
	{
		{
			Name = "打不过的话，可以再升级一下队员和装备。\n打败溪谷的[FDDE40]野狼队长[-]",
			Type = ItemType.Challenge,
			CountType = GoalCountType.Current,
			Num = 1,
			Value = 140008,
		},
	},
	CompleteSpeech = 30003001,
	Reward = {
		{
			Value = 330003,
			Num = 1,
		},
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id031] =
{
	Id = 31,
	Name = "主线31 - 组队打怪",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130002,
		PreGoal = 
		{
			300030,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Explore,
	},
	GoalCondition = 
	{
		{
			Name = "派遣[62E7E7]剑士[-]、[62E7E7]弓箭手[-]、[62E7E7]魔法师[-]在探索中击败[FDDE40]野狼[-]2个，建议探索20分钟以上",
			Type = ItemType.Enemy,
			CountType = GoalCountType.StartNow,
			Num = 2,
			Character = 
			{
				220003,
				220004,
				220010,
			},
			Value = 242009,
		},
	},
	Reward = {
		{
			Value = 330001,
			Num = 1,
		},
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id032] =
{
	Id = 32,
	Name = "主线32 - 冒险的旅费1",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130002,
		PreGoal = 
		{
			300031,
		},
	},
	GoalTrigger = 
	{
		TriggerType.DemandReward,
	},
	GoalCondition = 
	{
		{
			Name = "完成[62E7E7]委托[-]获得[FDDE40]金币[-]1000个",
			Type = ItemType.Gold,
			CountType = GoalCountType.StartNow,
			Num = 1000,
			Value = 1,
		},
	},
	Reward = {
		{
			Value = 330001,
			Num = 1,
		},
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id033] =
{
	Id = 33,
	Name = "主线33 - 寻找白狼",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130002,
		PreGoal = 
		{
			300032,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Explore,
	},
	GoalCondition = 
	{
		{
			Name = "[62E7E7]一次性[-]派遣[62E7E7]呜呜[-]、[62E7E7]漆漆[-]探索冒险星[FDDE40]溪谷[-]30分钟",
			Type = ItemType.Time,
			CountType = GoalCountType.OneShot,
			Num = 1800,
			Character = 
			{
				220001,
				220002,
			},
			Value = 130004,
		},
	},
	Reward = {
		{
			Value = 330001,
			Num = 1,
		},
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id034] =
{
	Id = 34,
	Name = "主线34 - 强化装备1",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130002,
		PreGoal = 
		{
			300033,
		},
	},
	GoalTrigger = 
	{
		TriggerType.UpgradeEquipment,
	},
	GoalCondition = 
	{
		{
			Name = "螺丝升级攻击装备，螺母升级防御装备。\n强化[62E7E7]任意[-][FDDE40]装备[-]3次",
			Type = ItemType.Equipment,
			CountType = GoalCountType.Current,
			Num = 3,
			Value = -1,
		},
	},
	Reward = {
		{
			Value = 330001,
			Num = 1,
		},
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id035] =
{
	Id = 35,
	Name = "主线35 - 白狼头领的挑战",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130004,
		PreGoal = 
		{
			300034,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Challenge,
	},
	GoalCondition = 
	{
		{
			Name = "打败溪谷的[FDDE40]白狼头领[-]",
			Type = ItemType.Challenge,
			CountType = GoalCountType.Current,
			Num = 1,
			Value = 140009,
		},
	},
	CompleteSpeech = 30003501,
	Reward = {
		{
			Value = 330003,
			Num = 1,
		},
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id036] =
{
	Id = 36,
	Name = "主线36 - 冒险者的准备",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130002,
		PreGoal = 
		{
			300035,
		},
	},
	GoalTrigger = 
	{
		TriggerType.CollectItem,
	},
	GoalCondition = 
	{
		{
			Name = "可能仓库还有存货，不过还是多准备些吧~\n拥有[FDDE40]小血瓶[-]3个",
			Type = ItemType.Goods,
			CountType = GoalCountType.Current,
			Num = 3,
			Value = 320402,
		},
	},
	Reward = {
		{
			Value = 330001,
			Num = 1,
		},
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id037] =
{
	Id = 37,
	Name = "主线37 - 升级主角光环",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130002,
		PreGoal = 
		{
			300036,
		},
	},
	GoalTrigger = 
	{
		TriggerType.CollectItem,
	},
	GoalCondition = 
	{
		{
			Name = "继续升级将解锁技能，使角色进一步提升。\n拥有至少[62E7E7]3级[-][FDDE40]主角光环[-](剑士装备)",
			Type = ItemType.Equipment,
			CountType = GoalCountType.Current,
			Num = 1,
			Value = 340005,
			Level = 3,
		},
	},
	Reward = {
		{
			Value = 330001,
			Num = 1,
		},
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id038] =
{
	Id = 38,
	Name = "主线38 - 临时冒险组",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130002,
		PreGoal = 
		{
			300037,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Explore,
	},
	GoalCondition = 
	{
		{
			Name = "派遣[62E7E7]剑士[-]、[62E7E7]弓箭手[-]、[62E7E7]魔法师[-]探索冒险星[FDDE40]溪谷[-]30分钟",
			Type = ItemType.Time,
			CountType = GoalCountType.StartNow,
			Num = 1800,
			Character = 
			{
				220003,
				220004,
				220010,
			},
			Value = 130004,
		},
	},
	Reward = {
		{
			Value = 330001,
			Num = 1,
		},
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id039] =
{
	Id = 39,
	Name = "主线39 - 溪谷的王者",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130002,
		PreGoal = 
		{
			300038,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Explore,
	},
	GoalCondition = 
	{
		{
			Name = "紧急！溪谷发生白狼伤人事件，求解决！\n在探索中击败[FDDE40]白狼[-]1个，建议探索47分钟以上",
			Type = ItemType.Enemy,
			CountType = GoalCountType.StartNow,
			Num = 1,
			Value = 242010,
		},
	},
	Reward = {
		{
			Value = 330001,
			Num = 1,
		},
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id040] =
{
	Id = 40,
	Name = "主线40 - 猎人的挑战",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130004,
		PreGoal = 
		{
			300039,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Challenge,
	},
	GoalCondition = 
	{
		{
			Name = "打败溪谷的[FDDE40]猎人[-]",
			Type = ItemType.Challenge,
			CountType = GoalCountType.Current,
			Num = 1,
			Value = 140010,
		},
	},
	CompleteSpeech = 30004001,
	Reward = {
		{
			Value = 130005,
			Num = 1,
		},
		{
			Value = 330003,
			Num = 1,
		},
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id041] =
{
	Id = 41,
	Name = "主线41 - 初见蓝色史莱姆",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130005,
		PreGoal = 
		{
			300040,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Explore,
	},
	GoalCondition = 
	{
		{
			Name = "派遣[62E7E7]呜呜[-]、[62E7E7]漆漆[-]在探索中击败[FDDE40]蓝色史莱姆[-]5个，建议探索37分钟以上",
			Type = ItemType.Enemy,
			CountType = GoalCountType.StartNow,
			Num = 5,
			Character = 
			{
				220001,
				220002,
			},
			Value = 242002,
		},
	},
	Reward = {
		{
			Value = 330001,
			Num = 1,
		},
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id042] =
{
	Id = 42,
	Name = "主线42 - 关于委托",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130005,
		PreGoal = 
		{
			300041,
		},
	},
	GoalTrigger = 
	{
		TriggerType.CompleteDemand,
	},
	GoalCondition = 
	{
		{
			Name = "据可靠情报，委托奖励除了金币，还有零件的。\n完成[62E7E7]任意[-][FDDE40]委托[-]3次",
			Type = ItemType.Demand,
			CountType = GoalCountType.StartNow,
			Num = 3,
			Value = -1,
		},
	},
	Reward = {
		{
			Value = 330001,
			Num = 1,
		},
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id043] =
{
	Id = 43,
	Name = "主线43 - 蓝色史莱姆的挑战",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130005,
		PreGoal = 
		{
			300042,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Challenge,
	},
	GoalCondition = 
	{
		{
			Name = "打败魔法平原的[FDDE40]史莱姆代表[-]",
			Type = ItemType.Challenge,
			CountType = GoalCountType.Current,
			Num = 1,
			Value = 140011,
		},
	},
	CompleteSpeech = 30004301,
	Reward = {
		{
			Value = 330003,
			Num = 1,
		},
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id044] =
{
	Id = 44,
	Name = "主线44 - 魔法研究",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130005,
		PreGoal = 
		{
			300043,
		},
	},
	GoalTrigger = 
	{
		TriggerType.CollectItem,
	},
	GoalCondition = 
	{
		{
			Name = "拥有至少[62E7E7]10级[-][FDDE40]魔法师[-]",
			Type = ItemType.Character,
			CountType = GoalCountType.Current,
			Num = 1,
			Value = 220010,
			Level = 10,
		},
	},
	Reward = {
		{
			Value = 330001,
			Num = 1,
		},
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id045] =
{
	Id = 45,
	Name = "主线45 - 魔法对决",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130005,
		PreGoal = 
		{
			300044,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Explore,
	},
	GoalCondition = 
	{
		{
			Name = "派遣含有[62E7E7]1个[-][62E7E7]暗元素[-]队员(或宠物)的队伍探索冒险星[FDDE40]魔法平原[-]60分钟",
			Type = ItemType.Time,
			CountType = GoalCountType.StartNow,
			Num = 3600,
			TagList = 
			{
				561206,
			},
			CharacterNum = 1,
			Value = 130005,
		},
	},
	Reward = {
		{
			Value = 330001,
			Num = 1,
		},
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id046] =
{
	Id = 46,
	Name = "主线46 - 精英祭祀石的挑战",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130005,
		PreGoal = 
		{
			300045,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Challenge,
	},
	GoalCondition = 
	{
		{
			Name = "打败魔法平原的[FDDE40]精英祭祀石[-]",
			Type = ItemType.Challenge,
			CountType = GoalCountType.Current,
			Num = 1,
			Value = 140012,
		},
	},
	CompleteSpeech = 30004601,
	Reward = {
		{
			Value = 330003,
			Num = 1,
		},
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id047] =
{
	Id = 47,
	Name = "主线47 - 深入平原",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130005,
		PreGoal = 
		{
			300046,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Explore,
	},
	GoalCondition = 
	{
		{
			Name = "[62E7E7]一次性[-]探索冒险星[FDDE40]魔法平原[-]30分钟",
			Type = ItemType.Time,
			CountType = GoalCountType.OneShot,
			Num = 1800,
			Value = 130005,
		},
	},
	Reward = {
		{
			Value = 330001,
			Num = 1,
		},
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id048] =
{
	Id = 48,
	Name = "主线48 - 打破结界",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130005,
		PreGoal = 
		{
			300047,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Explore,
	},
	GoalCondition = 
	{
		{
			Name = "在探索中击败[FDDE40]祭祀石[-]4个，建议探索46分钟以上",
			Type = ItemType.Enemy,
			CountType = GoalCountType.StartNow,
			Num = 4,
			Value = 242011,
		},
	},
	Reward = {
		{
			Value = 330001,
			Num = 1,
		},
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id049] =
{
	Id = 49,
	Name = "主线49 - 矿石研究",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130005,
		PreGoal = 
		{
			300048,
		},
	},
	GoalTrigger = 
	{
		TriggerType.DemandCost,
	},
	GoalCondition = 
	{
		{
			Name = "似乎4号位置的委托更容易获得零件奖励？\n在委托中提交[FDDE40]矿石[-]6个",
			Type = ItemType.Goods,
			CountType = GoalCountType.StartNow,
			Num = 6,
			Value = 321004,
		},
	},
	Reward = {
		{
			Value = 330001,
			Num = 1,
		},
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id050] =
{
	Id = 50,
	Name = "主线50 - 强化装备2",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130005,
		PreGoal = 
		{
			300049,
		},
	},
	GoalTrigger = 
	{
		TriggerType.CollectItem,
	},
	GoalCondition = 
	{
		{
			Name = "拥有至少[62E7E7]3级[-][FDDE40]装备[-]3个",
			Type = ItemType.Equipment,
			CountType = GoalCountType.Current,
			Num = 3,
			Value = -1,
			Level = 3,
		},
	},
	Reward = {
		{
			Value = 330001,
			Num = 1,
		},
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id051] =
{
	Id = 51,
	Name = "主线51 - 石怪老大的挑战",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130005,
		PreGoal = 
		{
			300050,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Challenge,
	},
	GoalCondition = 
	{
		{
			Name = "打败魔法平原的[FDDE40]石怪老大[-]",
			Type = ItemType.Challenge,
			CountType = GoalCountType.Current,
			Num = 1,
			Value = 140013,
		},
	},
	CompleteSpeech = 30005101,
	Reward = {
		{
			Value = 330003,
			Num = 1,
		},
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id052] =
{
	Id = 52,
	Name = "主线52 - 平原的守护者",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130005,
		PreGoal = 
		{
			300051,
		},
	},
	GoalTrigger = 
	{
		TriggerType.CollectItem,
	},
	GoalCondition = 
	{
		{
			Name = "拥有至少[62E7E7]10级[-][62E7E7]光元素[-][FDDE40]角色[-]1个",
			Type = ItemType.Character,
			CountType = GoalCountType.Current,
			Num = 1,
			Value = -1,
			Level = 10,
			Element = 210004,
		},
	},
	Reward = {
		{
			Value = 330001,
			Num = 1,
		},
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id053] =
{
	Id = 53,
	Name = "主线53 - 进入结界",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130005,
		PreGoal = 
		{
			300052,
		},
	},
	GoalTrigger = 
	{
		TriggerType.CollectItem,
	},
	GoalCondition = 
	{
		{
			Name = "拥有至少[62E7E7]3级[-][FDDE40]魔杖[-](魔法师装备)",
			Type = ItemType.Equipment,
			CountType = GoalCountType.Current,
			Num = 1,
			Value = 340020,
			Level = 3,
		},
	},
	Reward = {
		{
			Value = 330001,
			Num = 1,
		},
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id054] =
{
	Id = 54,
	Name = "主线54 - 打倒守卫",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130005,
		PreGoal = 
		{
			300053,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Explore,
	},
	GoalCondition = 
	{
		{
			Name = "在探索中击败[FDDE40]小石怪[-]4个，建议探索2小时以上",
			Type = ItemType.Enemy,
			CountType = GoalCountType.StartNow,
			Num = 4,
			Value = 242012,
		},
	},
	Reward = {
		{
			Value = 330001,
			Num = 1,
		},
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id055] =
{
	Id = 55,
	Name = "主线55 - 平原守护者的挑战",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130005,
		PreGoal = 
		{
			300054,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Challenge,
	},
	GoalCondition = 
	{
		{
			Name = "打败魔法平原的[FDDE40]平原守护者[-]",
			Type = ItemType.Challenge,
			CountType = GoalCountType.Current,
			Num = 1,
			Value = 140014,
		},
	},
	CompleteSpeech = 30005501,
	Reward = {
		{
			Value = 130006,
			Num = 1,
		},
		{
			Value = 330003,
			Num = 1,
		},
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id056] =
{
	Id = 56,
	Name = "主线56 - 探索遗迹",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130006,
		PreGoal = 
		{
			300055,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Explore,
	},
	GoalCondition = 
	{
		{
			Name = "派遣[62E7E7]呜呜[-]、[62E7E7]漆漆[-]探索[62E7E7]古代遗迹[-]击败[FDDE40]树桩猴[-]10个，建议探索2小时以上",
			Type = ItemType.Enemy,
			CountType = GoalCountType.StartNow,
			Num = 10,
			Character = 
			{
				220001,
				220002,
			},
			Value = 242008,
			Area = 130006,
		},
	},
	Reward = {
		{
			Value = 330001,
			Num = 2,
		},
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id057] =
{
	Id = 57,
	Name = "主线57 - 冒险的旅费2",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130006,
		PreGoal = 
		{
			300056,
		},
	},
	GoalTrigger = 
	{
		TriggerType.DemandReward,
	},
	GoalCondition = 
	{
		{
			Name = "完成[62E7E7]委托[-]获得[FDDE40]金币[-]1800个",
			Type = ItemType.Gold,
			CountType = GoalCountType.StartNow,
			Num = 1800,
			Value = 1,
		},
	},
	Reward = {
		{
			Value = 330001,
			Num = 2,
		},
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id058] =
{
	Id = 58,
	Name = "主线58 - 小土包代表的挑战",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130006,
		PreGoal = 
		{
			300057,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Challenge,
	},
	GoalCondition = 
	{
		{
			Name = "打败古代遗迹的[FDDE40]小土包代表[-]",
			Type = ItemType.Challenge,
			CountType = GoalCountType.Current,
			Num = 1,
			Value = 140015,
		},
	},
	CompleteSpeech = 30005801,
	Reward = {
		{
			Value = 330003,
			Num = 1,
		},
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id059] =
{
	Id = 59,
	Name = "主线59 - 道具店打工3",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130006,
		PreGoal = 
		{
			300058,
		},
	},
	GoalTrigger = 
	{
		TriggerType.WorkShopRank,
	},
	GoalCondition = 
	{
		{
			Name = "在[FDDE40]道具店[-]打工获得[FDDE40]D-[-]或更高评价",
			Type = ItemType.WorkShop,
			CountType = GoalCountType.Current,
			Num = 1,
			Value = 160001,
			Rank = 8,
		},
	},
	Reward = {
		{
			Value = 330001,
			Num = 2,
		},
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id060] =
{
	Id = 60,
	Name = "主线60 - 捕捉蓝色史莱姆",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130006,
		PreGoal = 
		{
			300059,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Explore,
	},
	GoalCondition = 
	{
		{
			Name = "捕获宠物[FDDE40]蓝色史莱姆[-]1个(需要道具店的陷阱)",
			Type = ItemType.Pet,
			CountType = GoalCountType.StartNow,
			Num = 1,
			Value = 250002,
		},
	},
	Reward = {
		{
			Value = 330001,
			Num = 2,
		},
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id061] =
{
	Id = 61,
	Name = "主线61 - 克制小土包",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130006,
		PreGoal = 
		{
			300060,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Explore,
	},
	GoalCondition = 
	{
		{
			Name = "携带[62E7E7]蓝色史莱姆[-]在探索中击败[FDDE40]小土包[-]5个，建议探索2小时以上",
			Type = ItemType.Enemy,
			CountType = GoalCountType.StartNow,
			Num = 5,
			Pet = 250002,
			Value = 242014,
		},
	},
	Reward = {
		{
			Value = 330001,
			Num = 2,
		},
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id062] =
{
	Id = 62,
	Name = "主线62 - 地缚灵头目的挑战",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130006,
		PreGoal = 
		{
			300061,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Challenge,
	},
	GoalCondition = 
	{
		{
			Name = "听说晚上附近会有不死生物出来溜达…\n打败古代遗迹的[FDDE40]地缚灵头目[-]",
			Type = ItemType.Challenge,
			CountType = GoalCountType.Current,
			Num = 1,
			Value = 140016,
		},
	},
	CompleteSpeech = 30006201,
	Reward = {
		{
			Value = 330003,
			Num = 1,
		},
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id063] =
{
	Id = 63,
	Name = "主线63 - 主角的证明",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130006,
		PreGoal = 
		{
			300062,
		},
	},
	GoalTrigger = 
	{
		TriggerType.CollectItem,
	},
	GoalCondition = 
	{
		{
			Name = "拥有至少[62E7E7]3级[-][FDDE40]主角光环[-](剑士装备)",
			Type = ItemType.Equipment,
			CountType = GoalCountType.Current,
			Num = 1,
			Value = 340005,
			Level = 3,
		},
	},
	Reward = {
		{
			Value = 330001,
			Num = 2,
		},
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id064] =
{
	Id = 64,
	Name = "主线64 - 沟通的工具",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130006,
		PreGoal = 
		{
			300063,
		},
	},
	GoalTrigger = 
	{
		TriggerType.CollectItem,
	},
	GoalCondition = 
	{
		{
			Name = "拥有[FDDE40]家传宝剑[-](剑士装备)",
			Type = ItemType.Equipment,
			CountType = GoalCountType.Current,
			Num = 1,
			Value = 340006,
		},
	},
	Reward = {
		{
			Value = 330001,
			Num = 2,
		},
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id065] =
{
	Id = 65,
	Name = "主线65 - 遗迹深处",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130006,
		PreGoal = 
		{
			300064,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Explore,
	},
	GoalCondition = 
	{
		{
			Name = "探索[62E7E7]古代遗迹[-]击败[FDDE40]地缚灵[-]10个，建议探索4小时以上",
			Type = ItemType.Enemy,
			CountType = GoalCountType.StartNow,
			Num = 10,
			Value = 242015,
			Area = 130006,
		},
	},
	Reward = {
		{
			Value = 330001,
			Num = 2,
		},
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id066] =
{
	Id = 66,
	Name = "主线66 - 骨头兵的挑战",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130006,
		PreGoal = 
		{
			300065,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Challenge,
	},
	GoalCondition = 
	{
		{
			Name = "发现魔王集团成员！\n打败古代遗迹的[FDDE40]骨头兵[-]",
			Type = ItemType.Challenge,
			CountType = GoalCountType.Current,
			Num = 1,
			Value = 140017,
		},
	},
	CompleteSpeech = 30006601,
	Reward = {
		{
			Value = 130007,
			Num = 1,
		},
		{
			Value = 330003,
			Num = 1,
		},
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id067] =
{
	Id = 67,
	Name = "主线67 - 准备鸡腿",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130007,
		PreGoal = 
		{
			300066,
		},
	},
	GoalTrigger = 
	{
		TriggerType.CollectItem,
	},
	GoalCondition = 
	{
		{
			Name = "拥有[FDDE40]鸡腿[-]5个",
			Type = ItemType.Goods,
			CountType = GoalCountType.Current,
			Num = 5,
			Value = 320406,
		},
	},
	Reward = {
		{
			Value = 330001,
			Num = 2,
		},
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id068] =
{
	Id = 68,
	Name = "主线68 - 探索沼泽地区",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130007,
		PreGoal = 
		{
			300067,
		},
	},
	GoalTrigger = 
	{
		TriggerType.ExploreCost,
	},
	GoalCondition = 
	{
		{
			Name = "探索[62E7E7]大沼泽[-]消耗[FDDE40]鸡腿[-]5个",
			Type = ItemType.Goods,
			CountType = GoalCountType.StartNow,
			Num = 5,
			Value = 320406,
			Area = 130007,
		},
	},
	Reward = {
		{
			Value = 330001,
			Num = 2,
		},
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id069] =
{
	Id = 69,
	Name = "主线69 - 紫色史莱姆的挑战",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130007,
		PreGoal = 
		{
			300068,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Challenge,
	},
	GoalCondition = 
	{
		{
			Name = "打败大沼泽的[FDDE40]史莱姆代表[-]",
			Type = ItemType.Challenge,
			CountType = GoalCountType.Current,
			Num = 1,
			Value = 140018,
		},
	},
	CompleteSpeech = 30006901,
	Reward = {
		{
			Value = 330003,
			Num = 1,
		},
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id070] =
{
	Id = 70,
	Name = "主线70 - 强化装备3",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130007,
		PreGoal = 
		{
			300069,
		},
	},
	GoalTrigger = 
	{
		TriggerType.UpgradeEquipment,
	},
	GoalCondition = 
	{
		{
			Name = "强化[62E7E7]任意[-][FDDE40]装备[-]15次",
			Type = ItemType.Equipment,
			CountType = GoalCountType.Current,
			Num = 15,
			Value = -1,
		},
	},
	Reward = {
		{
			Value = 330001,
			Num = 2,
		},
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id071] =
{
	Id = 71,
	Name = "主线71 - 冒险的旅费3",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130007,
		PreGoal = 
		{
			300070,
		},
	},
	GoalTrigger = 
	{
		TriggerType.DemandReward,
	},
	GoalCondition = 
	{
		{
			Name = "完成[62E7E7]委托[-]获得[FDDE40]金币[-]4800个",
			Type = ItemType.Gold,
			CountType = GoalCountType.StartNow,
			Num = 4800,
			Value = 1,
		},
	},
	Reward = {
		{
			Value = 330001,
			Num = 2,
		},
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id072] =
{
	Id = 72,
	Name = "主线72 - 超深沼泽地的挑战",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130007,
		PreGoal = 
		{
			300071,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Challenge,
	},
	GoalCondition = 
	{
		{
			Name = "打败大沼泽的[FDDE40]超深沼泽地[-]",
			Type = ItemType.Challenge,
			CountType = GoalCountType.Current,
			Num = 1,
			Value = 140019,
		},
	},
	CompleteSpeech = 30007201,
	Reward = {
		{
			Value = 330003,
			Num = 1,
		},
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id073] =
{
	Id = 73,
	Name = "主线73 - 制作大血瓶",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130007,
		PreGoal = 
		{
			300072,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Craft,
	},
	GoalCondition = 
	{
		{
			Name = "在实验室合成获得[FDDE40]大血瓶[-]4个",
			Type = ItemType.Goods,
			CountType = GoalCountType.StartNow,
			Num = 4,
			Value = 320403,
		},
	},
	Reward = {
		{
			Value = 330001,
			Num = 2,
		},
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id074] =
{
	Id = 74,
	Name = "主线74 - 前进的冒险者",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130007,
		PreGoal = 
		{
			300073,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Explore,
	},
	GoalCondition = 
	{
		{
			Name = "[62E7E7]一次性[-]派遣[62E7E7]剑士[-]、[62E7E7]弓箭手[-]、[62E7E7]魔法师[-]探索冒险星[FDDE40]大沼泽[-]4小时",
			Type = ItemType.Time,
			CountType = GoalCountType.OneShot,
			Num = 14400,
			Character = 
			{
				220003,
				220004,
				220010,
			},
			Value = 130007,
		},
	},
	Reward = {
		{
			Value = 330001,
			Num = 2,
		},
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id075] =
{
	Id = 75,
	Name = "主线75 - 泥怪头领的挑战",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130007,
		PreGoal = 
		{
			300074,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Challenge,
	},
	GoalCondition = 
	{
		{
			Name = "打败大沼泽的[FDDE40]泥怪头领[-]",
			Type = ItemType.Challenge,
			CountType = GoalCountType.Current,
			Num = 1,
			Value = 140020,
		},
	},
	CompleteSpeech = 30007501,
	Reward = {
		{
			Value = 330003,
			Num = 1,
		},
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id076] =
{
	Id = 76,
	Name = "主线76 - 超市打工1",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130007,
		PreGoal = 
		{
			300075,
		},
	},
	GoalTrigger = 
	{
		TriggerType.WorkShopRank,
	},
	GoalCondition = 
	{
		{
			Name = "在[FDDE40]超市[-]打工获得[FDDE40]D-[-]或更高评价",
			Type = ItemType.WorkShop,
			CountType = GoalCountType.Current,
			Num = 1,
			Value = 160002,
			Rank = 8,
		},
	},
	Reward = {
		{
			Value = 330001,
			Num = 2,
		},
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id077] =
{
	Id = 77,
	Name = "主线77 - 准备空瓶",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130007,
		PreGoal = 
		{
			300076,
		},
	},
	GoalTrigger = 
	{
		TriggerType.CollectItem,
	},
	GoalCondition = 
	{
		{
			Name = "拥有[FDDE40]脏脏的瓶子[-]2个",
			Type = ItemType.Goods,
			CountType = GoalCountType.Current,
			Num = 2,
			Value = 320305,
		},
	},
	Reward = {
		{
			Value = 330001,
			Num = 2,
		},
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id078] =
{
	Id = 78,
	Name = "主线78 - 捕捉泥怪",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130007,
		PreGoal = 
		{
			300077,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Explore,
	},
	GoalCondition = 
	{
		{
			Name = "用空瓶就能把沼泽或遗迹的泥怪装回家了吧？\n捕获[62E7E7]泥怪类的[-][FDDE40]宠物[-]2个",
			Type = ItemType.Pet,
			CountType = GoalCountType.StartNow,
			Num = 2,
			TagList = 
			{
				561326,
			},
			Value = -1,
		},
	},
	Reward = {
		{
			Value = 330001,
			Num = 2,
		},
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id079] =
{
	Id = 79,
	Name = "主线79 - 和解",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130007,
		PreGoal = 
		{
			300078,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Explore,
	},
	GoalCondition = 
	{
		{
			Name = "派遣[62E7E7]剑士[-]、[62E7E7]魔法师[-]探索冒险星[FDDE40]大沼泽[-]4小时",
			Type = ItemType.Time,
			CountType = GoalCountType.StartNow,
			Num = 14400,
			Character = 
			{
				220003,
				220010,
			},
			Value = 130007,
		},
	},
	CompleteSpeech = 30007901,
	Reward = {
		{
			Value = 330001,
			Num = 2,
		},
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id080] =
{
	Id = 80,
	Name = "主线80 - 树精头领的挑战",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130007,
		PreGoal = 
		{
			300079,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Challenge,
	},
	GoalCondition = 
	{
		{
			Name = "打败大沼泽的[FDDE40]树精头领[-]",
			Type = ItemType.Challenge,
			CountType = GoalCountType.Current,
			Num = 1,
			Value = 140021,
		},
	},
	CompleteSpeech = 30008001,
	Reward = {
		{
			Value = 330003,
			Num = 1,
		},
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id081] =
{
	Id = 81,
	Name = "主线81 - 见面礼",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130007,
		PreGoal = 
		{
			300080,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Explore,
	},
	GoalCondition = 
	{
		{
			Name = "咦！带着小土包去探索会自动获得地图？！\n在探索中获得[FDDE40]地图[-]10个",
			Type = ItemType.Goods,
			CountType = GoalCountType.StartNow,
			Num = 10,
			Value = 321005,
		},
	},
	Reward = {
		{
			Value = 330001,
			Num = 2,
		},
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id082] =
{
	Id = 82,
	Name = "主线82 - 冒险的旅费4",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130002,
		PreGoal = 
		{
			300081,
		},
	},
	GoalTrigger = 
	{
		TriggerType.CompleteDemand,
	},
	GoalCondition = 
	{
		{
			Name = "完成[62E7E7]任意[-][FDDE40]委托[-]3次",
			Type = ItemType.Demand,
			CountType = GoalCountType.StartNow,
			Num = 3,
			Value = -1,
		},
	},
	Reward = {
		{
			Value = 330001,
			Num = 2,
		},
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id083] =
{
	Id = 83,
	Name = "主线83 - 寻找指路NPC",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130007,
		PreGoal = 
		{
			300082,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Explore,
	},
	GoalCondition = 
	{
		{
			Name = "既然是地图的话，就决定是你了，小土包！\n在探索中击败[FDDE40]沼泽树精[-]5个，建议探索5小时以上",
			Type = ItemType.Enemy,
			CountType = GoalCountType.StartNow,
			Num = 5,
			Value = 242018,
		},
	},
	Reward = {
		{
			Value = 330001,
			Num = 2,
		},
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id084] =
{
	Id = 84,
	Name = "主线84 - 指路NPC的挑战",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130007,
		PreGoal = 
		{
			300083,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Challenge,
	},
	GoalCondition = 
	{
		{
			Name = "打败大沼泽的[FDDE40]指路NPC[-]",
			Type = ItemType.Challenge,
			CountType = GoalCountType.Current,
			Num = 1,
			Value = 140022,
		},
	},
	CompleteSpeech = 30008401,
	Reward = {
		{
			Value = 130010,
			Num = 1,
		},
		{
			Value = 330003,
			Num = 1,
		},
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id085] =
{
	Id = 85,
	Name = "主线85 - 适应温度",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130010,
		PreGoal = 
		{
			300084,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Explore,
	},
	GoalCondition = 
	{
		{
			Name = "派遣含有[62E7E7]1个[-][62E7E7]水元素[-]队员(或宠物)的队伍探索冒险星[FDDE40]魔王城堡[-]4小时",
			Type = ItemType.Time,
			CountType = GoalCountType.StartNow,
			Num = 14400,
			TagList = 
			{
				561202,
			},
			CharacterNum = 1,
			Value = 130010,
		},
	},
	Reward = {
		{
			Value = 330001,
			Num = 3,
		},
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id086] =
{
	Id = 86,
	Name = "主线86 - 清理障碍",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130010,
		PreGoal = 
		{
			300085,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Explore,
	},
	GoalCondition = 
	{
		{
			Name = "[62E7E7]一次性[-]在探索中击败[FDDE40]火喷泉[-]15个，建议探索6小时以上",
			Type = ItemType.Enemy,
			CountType = GoalCountType.OneShot,
			Num = 15,
			Value = 242021,
		},
	},
	Reward = {
		{
			Value = 330001,
			Num = 3,
		},
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id087] =
{
	Id = 87,
	Name = "主线87 - 小火球代表的挑战",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130010,
		PreGoal = 
		{
			300086,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Challenge,
	},
	GoalCondition = 
	{
		{
			Name = "打败魔王城堡的[FDDE40]小火球代表[-]",
			Type = ItemType.Challenge,
			CountType = GoalCountType.Current,
			Num = 1,
			Value = 140029,
		},
	},
	CompleteSpeech = 30008701,
	Reward = {
		{
			Value = 330003,
			Num = 1,
		},
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id088] =
{
	Id = 88,
	Name = "主线88 - 熔岩猪的最爱",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130010,
		PreGoal = 
		{
			300087,
		},
	},
	GoalTrigger = 
	{
		TriggerType.SubmitGoods,
	},
	GoalCondition = 
	{
		{
			Name = "提交[FDDE40]炭石[-]5个",
			Type = ItemType.Goods,
			CountType = GoalCountType.Current,
			Num = 5,
			Value = 321009,
		},
	},
	Reward = {
		{
			Value = 330001,
			Num = 3,
		},
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id089] =
{
	Id = 89,
	Name = "主线89 - 工作证件",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130010,
		PreGoal = 
		{
			300088,
		},
	},
	GoalTrigger = 
	{
		TriggerType.CollectItem,
	},
	GoalCondition = 
	{
		{
			Name = "拥有[FDDE40]地城工作证[-](骨头兵装备)",
			Type = ItemType.Equipment,
			CountType = GoalCountType.Current,
			Num = 1,
			Value = 340012,
		},
	},
	Reward = {
		{
			Value = 330001,
			Num = 3,
		},
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id090] =
{
	Id = 90,
	Name = "主线90 - 假装上班",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130010,
		PreGoal = 
		{
			300089,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Explore,
	},
	GoalCondition = 
	{
		{
			Name = "派遣[62E7E7]骨头兵[-]探索冒险星[FDDE40]魔王城堡[-]8小时",
			Type = ItemType.Time,
			CountType = GoalCountType.StartNow,
			Num = 28800,
			Character = 
			{
				220006,
			},
			Value = 130010,
		},
	},
	Reward = {
		{
			Value = 330001,
			Num = 3,
		},
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id091] =
{
	Id = 91,
	Name = "主线91 - 熔岩猪头领的挑战",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130010,
		PreGoal = 
		{
			300090,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Challenge,
	},
	GoalCondition = 
	{
		{
			Name = "打败魔王城堡的[FDDE40]熔岩猪头领[-]",
			Type = ItemType.Challenge,
			CountType = GoalCountType.Current,
			Num = 1,
			Value = 140030,
		},
	},
	CompleteSpeech = 30009101,
	Reward = {
		{
			Value = 330003,
			Num = 1,
		},
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id092] =
{
	Id = 92,
	Name = "主线92 - 点燃火把",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130010,
		PreGoal = 
		{
			300091,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Craft,
	},
	GoalCondition = 
	{
		{
			Name = "在实验室合成获得[FDDE40]火把[-]1个",
			Type = ItemType.Goods,
			CountType = GoalCountType.StartNow,
			Num = 1,
			Value = 321054,
		},
	},
	Reward = {
		{
			Value = 330001,
			Num = 3,
		},
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id093] =
{
	Id = 93,
	Name = "主线93 - 冒险星高级委托",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130010,
		PreGoal = 
		{
			300092,
		},
	},
	GoalTrigger = 
	{
		TriggerType.DemandCost,
	},
	GoalCondition = 
	{
		{
			Name = "怎么说呢，就是那个，在实验室合成的东西！\n在委托中提交[62E7E7]合成的[-]、[62E7E7]冒险星[-]道具1个",
			Type = ItemType.Goods,
			CountType = GoalCountType.StartNow,
			Num = 1,
			TagList = 
			{
				560005,
				560103,
			},
			Value = -1,
		},
	},
	Reward = {
		{
			Value = 330001,
			Num = 3,
		},
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id094] =
{
	Id = 94,
	Name = "主线94 - 自动导航",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130010,
		PreGoal = 
		{
			300093,
		},
	},
	GoalTrigger = 
	{
		TriggerType.CollectItem,
	},
	GoalCondition = 
	{
		{
			Name = "指路NPC说想解锁这个装备来着。\n拥有至少[62E7E7]3级[-][FDDE40]自制路牌[-](指路NPC装备)",
			Type = ItemType.Equipment,
			CountType = GoalCountType.Current,
			Num = 1,
			Value = 340013,
			Level = 3,
		},
	},
	Reward = {
		{
			Value = 330001,
			Num = 3,
		},
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id095] =
{
	Id = 95,
	Name = "主线95 - 潜入城堡",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130010,
		PreGoal = 
		{
			300094,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Explore,
	},
	GoalCondition = 
	{
		{
			Name = "最后似乎是一路打怪打进城堡的…\n派遣[62E7E7]指路NPC[-]在探索中击败[FDDE40]小火球[-]30个，建议探索10小时以上",
			Type = ItemType.Enemy,
			CountType = GoalCountType.StartNow,
			Num = 30,
			Character = 
			{
				220007,
			},
			Value = 242023,
		},
	},
	Reward = {
		{
			Value = 330001,
			Num = 3,
		},
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id096] =
{
	Id = 96,
	Name = "主线96 - 火山巨蟹头领的挑战",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130010,
		PreGoal = 
		{
			300095,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Challenge,
	},
	GoalCondition = 
	{
		{
			Name = "打败魔王城堡的[FDDE40]火山巨蟹头领[-]",
			Type = ItemType.Challenge,
			CountType = GoalCountType.Current,
			Num = 1,
			Value = 140031,
		},
	},
	CompleteSpeech = 30009601,
	Reward = {
		{
			Value = 330003,
			Num = 1,
		},
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id097] =
{
	Id = 97,
	Name = "主线97 - 冒险的旅费5",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130002,
		PreGoal = 
		{
			300096,
		},
	},
	GoalTrigger = 
	{
		TriggerType.DemandReward,
	},
	GoalCondition = 
	{
		{
			Name = "听说好几个探险家通过委托已经财务自由了！\n完成[62E7E7]委托[-]获得[FDDE40]金币[-]10000个",
			Type = ItemType.Gold,
			CountType = GoalCountType.StartNow,
			Num = 10000,
			Value = 1,
		},
	},
	Reward = {
		{
			Value = 330001,
			Num = 3,
		},
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id098] =
{
	Id = 98,
	Name = "主线98 - 魔王讨伐计划1",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130010,
		PreGoal = 
		{
			300097,
		},
	},
	GoalTrigger = 
	{
		TriggerType.CollectItem,
	},
	GoalCondition = 
	{
		{
			Name = "队伍里只有剑士能抵挡魔王的攻击！by剑士\n拥有至少[62E7E7]20级[-][FDDE40]剑士[-]",
			Type = ItemType.Character,
			CountType = GoalCountType.Current,
			Num = 1,
			Value = 220003,
			Level = 20,
		},
	},
	Reward = {
		{
			Value = 330001,
			Num = 3,
		},
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id099] =
{
	Id = 99,
	Name = "主线99 - 魔王讨伐计划2",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130010,
		PreGoal = 
		{
			300098,
		},
	},
	GoalTrigger = 
	{
		TriggerType.CollectItem,
	},
	GoalCondition = 
	{
		{
			Name = "如果可以的话，也让我讨伐魔王吧！By弓箭手\n拥有至少[62E7E7]20级[-][FDDE40]弓箭手[-]",
			Type = ItemType.Character,
			CountType = GoalCountType.Current,
			Num = 1,
			Value = 220004,
			Level = 20,
		},
	},
	Reward = {
		{
			Value = 330001,
			Num = 3,
		},
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id100] =
{
	Id = 100,
	Name = "主线100 - 魔王讨伐计划3",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130010,
		PreGoal = 
		{
			300099,
		},
	},
	GoalTrigger = 
	{
		TriggerType.CollectItem,
	},
	GoalCondition = 
	{
		{
			Name = "虽然元素相克，不过我攻击很高。By魔法师\n拥有至少[62E7E7]20级[-][FDDE40]魔法师[-]",
			Type = ItemType.Character,
			CountType = GoalCountType.Current,
			Num = 1,
			Value = 220010,
			Level = 20,
		},
	},
	Reward = {
		{
			Value = 330001,
			Num = 3,
		},
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id101] =
{
	Id = 101,
	Name = "主线101 - 勇者向前冲",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130010,
		PreGoal = 
		{
			300100,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Explore,
	},
	GoalCondition = 
	{
		{
			Name = "派遣含有[62E7E7]3个[-][62E7E7]经典冒险组[-]队员(或宠物)的队伍探索冒险星[FDDE40]魔王城堡[-]12小时",
			Type = ItemType.Time,
			CountType = GoalCountType.StartNow,
			Num = 43200,
			TagList = 
			{
				562902,
			},
			CharacterNum = 3,
			Value = 130010,
		},
	},
	Reward = {
		{
			Value = 330001,
			Num = 3,
		},
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id102] =
{
	Id = 102,
	Name = "主线102 - 小魔王的挑战",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130010,
		PreGoal = 
		{
			300101,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Challenge,
	},
	GoalCondition = 
	{
		{
			Name = "打败魔王城堡的[FDDE40]小魔王[-]",
			Type = ItemType.Challenge,
			CountType = GoalCountType.Current,
			Num = 1,
			Value = 140032,
		},
	},
	CompleteSpeech = 30010201,
	Reward = {
		{
			Value = 320001,
			Num = 2,
		},
		{
			Value = 330003,
			Num = 1,
		},
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id103] =
{
	Id = 103,
	Name = "主线103 - 下一站，美食星！",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130010,
		PreGoal = 
		{
			300102,
		},
	},
	GoalTrigger = 
	{
		TriggerType.SubmitGoods,
	},
	GoalCondition = 
	{
		{
			Name = "发动引擎，准备起航！\n提交[FDDE40]炭石[-]25个",
			Type = ItemType.Goods,
			CountType = GoalCountType.Current,
			Num = 25,
			Value = 321009,
		},
	},
	CompleteSpeech = 30010301,
	Reward = {
		{
			Value = 130051,
			Num = 1,
		},
		{
			Value = 330001,
			Num = 3,
		},
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id301] =
{
	Id = 301,
	Name = "解锁：深坑谷",
	GoalType = GoalType.Main,
	ShowFirst = false,
	PreCondition = {
		PreArea = 130005,
		PreGoal = 
		{
			300055,
		},
	},
	GoalTrigger = 
	{
		TriggerType.SubmitGoods,
	},
	GoalCondition = 
	{
		{
			Name = "如果要去那个地方的话，这个一定不能少！\n提交[FDDE40]地图[-]5个",
			Type = ItemType.Goods,
			CountType = GoalCountType.Current,
			Num = 5,
			Value = 321005,
		},
	},
	Reward = {
		{
			Value = 130008,
			Num = 1,
		},
		{
			Value = 330001,
			Num = 2,
		},
		{
			Value = 2,
			Num = 30,
		},
	},
}
GoalConfig[GoalID.Id302] =
{
	Id = 302,
	Name = "支线-入谷前的修行",
	GoalType = GoalType.Main,
	ShowFirst = false,
	PreCondition = {
		PreArea = 130005,
		PreGoal = 
		{
			300301,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Explore,
	},
	GoalCondition = 
	{
		{
			Name = "探索[62E7E7]魔法平原[-]击败[FDDE40]石巨人[-]5个，建议探索5小时以上",
			Type = ItemType.Enemy,
			CountType = GoalCountType.StartNow,
			Num = 5,
			Value = 242013,
			Area = 130005,
		},
	},
	Reward = {
		{
			Value = 330001,
			Num = 2,
		},
		{
			Value = 2,
			Num = 30,
		},
	},
}
GoalConfig[GoalID.Id303] =
{
	Id = 303,
	Name = "支线-危险地区的探索",
	GoalType = GoalType.Main,
	ShowFirst = false,
	PreCondition = {
		PreArea = 130008,
		PreGoal = 
		{
			300302,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Explore,
	},
	GoalCondition = 
	{
		{
			Name = "派遣含有[62E7E7]1个[-][62E7E7]紫色及以上品质[-]队员(或宠物)的队伍探索冒险星[FDDE40]深坑谷[-]8小时",
			Type = ItemType.Time,
			CountType = GoalCountType.StartNow,
			Num = 28800,
			TagList = 
			{
				560034,
			},
			CharacterNum = 1,
			Value = 130008,
		},
	},
	Reward = {
		{
			Value = 330001,
			Num = 2,
		},
		{
			Value = 2,
			Num = 30,
		},
	},
}
GoalConfig[GoalID.Id304] =
{
	Id = 304,
	Name = "支线-刺毛怪小队长的挑战",
	GoalType = GoalType.Main,
	ShowFirst = false,
	PreCondition = {
		PreArea = 130008,
		PreGoal = 
		{
			300303,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Challenge,
	},
	GoalCondition = 
	{
		{
			Name = "打败深坑谷的[FDDE40]刺毛怪小队长[-]",
			Type = ItemType.Challenge,
			CountType = GoalCountType.Current,
			Num = 1,
			Value = 140023,
		},
	},
	Reward = {
		{
			Value = 330003,
			Num = 1,
		},
		{
			Value = 2,
			Num = 30,
		},
	},
}
GoalConfig[GoalID.Id305] =
{
	Id = 305,
	Name = "支线-压迫感的气息",
	GoalType = GoalType.Main,
	ShowFirst = false,
	PreCondition = {
		PreArea = 130008,
		PreGoal = 
		{
			300304,
		},
	},
	GoalTrigger = 
	{
		TriggerType.CollectItem,
	},
	GoalCondition = 
	{
		{
			Name = "习惯黑暗之人才能忍受这可怖的气息。\n拥有至少[62E7E7]12级[-][62E7E7]暗元素[-][FDDE40]角色[-]2个",
			Type = ItemType.Character,
			CountType = GoalCountType.Current,
			Num = 2,
			Value = -1,
			Level = 12,
			Element = 210005,
		},
	},
	Reward = {
		{
			Value = 330001,
			Num = 3,
		},
		{
			Value = 2,
			Num = 30,
		},
	},
}
GoalConfig[GoalID.Id306] =
{
	Id = 306,
	Name = "支线-自制捕兽器",
	GoalType = GoalType.Main,
	ShowFirst = false,
	PreCondition = {
		PreArea = 130008,
		PreGoal = 
		{
			300305,
		},
	},
	GoalTrigger = 
	{
		TriggerType.CollectItem,
	},
	GoalCondition = 
	{
		{
			Name = "拥有至少[62E7E7]3级[-][FDDE40]陷阱[-](猎人装备)",
			Type = ItemType.Equipment,
			CountType = GoalCountType.Current,
			Num = 1,
			Value = 340010,
			Level = 3,
		},
	},
	Reward = {
		{
			Value = 330001,
			Num = 3,
		},
		{
			Value = 2,
			Num = 30,
		},
	},
}
GoalConfig[GoalID.Id307] =
{
	Id = 307,
	Name = "支线-集结的刺毛怪",
	GoalType = GoalType.Main,
	ShowFirst = false,
	PreCondition = {
		PreArea = 130008,
		PreGoal = 
		{
			300306,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Explore,
	},
	GoalCondition = 
	{
		{
			Name = "在探索中击败[FDDE40]刺毛怪[-]80个，建议探索21小时以上",
			Type = ItemType.Enemy,
			CountType = GoalCountType.StartNow,
			Num = 80,
			Value = 242019,
		},
	},
	Reward = {
		{
			Value = 330001,
			Num = 3,
		},
		{
			Value = 2,
			Num = 30,
		},
	},
}
GoalConfig[GoalID.Id308] =
{
	Id = 308,
	Name = "支线-光与暗的宿敌",
	GoalType = GoalType.Main,
	ShowFirst = false,
	PreCondition = {
		PreArea = 130008,
		PreGoal = 
		{
			300307,
		},
	},
	GoalTrigger = 
	{
		TriggerType.CollectItem,
	},
	GoalCondition = 
	{
		{
			Name = "累计捕捉宠物[FDDE40]白狼[-]1个(需要道具店的陷阱)",
			Type = ItemType.Pet,
			CountType = GoalCountType.Current,
			Num = 1,
			Value = 250010,
		},
	},
	Reward = {
		{
			Value = 330001,
			Num = 3,
		},
		{
			Value = 2,
			Num = 30,
		},
	},
}
GoalConfig[GoalID.Id309] =
{
	Id = 309,
	Name = "支线-刺毛怪大王的挑战",
	GoalType = GoalType.Main,
	ShowFirst = false,
	PreCondition = {
		PreArea = 130008,
		PreGoal = 
		{
			300308,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Challenge,
	},
	GoalCondition = 
	{
		{
			Name = "打败深坑谷的[FDDE40]刺毛怪大王[-]",
			Type = ItemType.Challenge,
			CountType = GoalCountType.Current,
			Num = 1,
			Value = 140024,
		},
	},
	Reward = {
		{
			Value = 330003,
			Num = 1,
		},
		{
			Value = 2,
			Num = 30,
		},
	},
}
GoalConfig[GoalID.Id310] =
{
	Id = 310,
	Name = "解锁：魔王火山",
	GoalType = GoalType.Main,
	ShowFirst = false,
	PreCondition = {
		PreArea = 130008,
		PreGoal = 
		{
			300309,
		},
	},
	GoalTrigger = 
	{
		TriggerType.CollectItem,
	},
	GoalCondition = 
	{
		{
			Name = "听说那里一旦中暑倒地就会7级烧伤...\n拥有至少[62E7E7]16级[-][62E7E7]水元素[-][FDDE40]角色[-]2个",
			Type = ItemType.Character,
			CountType = GoalCountType.Current,
			Num = 2,
			Value = -1,
			Level = 16,
			Element = 210001,
		},
	},
	Reward = {
		{
			Value = 130009,
			Num = 1,
		},
		{
			Value = 330001,
			Num = 3,
		},
		{
			Value = 2,
			Num = 30,
		},
	},
}
GoalConfig[GoalID.Id311] =
{
	Id = 311,
	Name = "支线-同族的水与火",
	GoalType = GoalType.Main,
	ShowFirst = false,
	PreCondition = {
		PreArea = 130009,
		PreGoal = 
		{
			300310,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Explore,
	},
	GoalCondition = 
	{
		{
			Name = "携带[62E7E7]蓝色史莱姆[-]探索冒险星[FDDE40]魔王火山[-]4小时",
			Type = ItemType.Time,
			CountType = GoalCountType.StartNow,
			Num = 14400,
			Pet = 250002,
			Value = 130009,
		},
	},
	Reward = {
		{
			Value = 330001,
			Num = 3,
		},
		{
			Value = 2,
			Num = 30,
		},
	},
}
GoalConfig[GoalID.Id312] =
{
	Id = 312,
	Name = "支线-红色史莱姆的挑战",
	GoalType = GoalType.Main,
	ShowFirst = false,
	PreCondition = {
		PreArea = 130009,
		PreGoal = 
		{
			300311,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Challenge,
	},
	GoalCondition = 
	{
		{
			Name = "打败魔王火山的[FDDE40]史莱姆代表[-]",
			Type = ItemType.Challenge,
			CountType = GoalCountType.Current,
			Num = 1,
			Value = 140025,
		},
	},
	Reward = {
		{
			Value = 330003,
			Num = 1,
		},
		{
			Value = 2,
			Num = 30,
		},
	},
}
GoalConfig[GoalID.Id313] =
{
	Id = 313,
	Name = "支线-火焰的史莱姆",
	GoalType = GoalType.Main,
	ShowFirst = false,
	PreCondition = {
		PreArea = 130009,
		PreGoal = 
		{
			300312,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Explore,
	},
	GoalCondition = 
	{
		{
			Name = "捕获宠物[FDDE40]红色史莱姆[-]3个(需要道具店的陷阱)",
			Type = ItemType.Pet,
			CountType = GoalCountType.StartNow,
			Num = 3,
			Value = 250004,
		},
	},
	Reward = {
		{
			Value = 330001,
			Num = 3,
		},
		{
			Value = 2,
			Num = 30,
		},
	},
}
GoalConfig[GoalID.Id314] =
{
	Id = 314,
	Name = "支线-抵抗火焰",
	GoalType = GoalType.Main,
	ShowFirst = false,
	PreCondition = {
		PreArea = 130009,
		PreGoal = 
		{
			300313,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Explore,
	},
	GoalCondition = 
	{
		{
			Name = "携带[62E7E7]红色史莱姆[-]探索冒险星[FDDE40]魔王火山[-]4小时",
			Type = ItemType.Time,
			CountType = GoalCountType.StartNow,
			Num = 14400,
			Pet = 250004,
			Value = 130009,
		},
	},
	Reward = {
		{
			Value = 330001,
			Num = 3,
		},
		{
			Value = 2,
			Num = 30,
		},
	},
}
GoalConfig[GoalID.Id315] =
{
	Id = 315,
	Name = "支线-岩浆喷泉的挑战",
	GoalType = GoalType.Main,
	ShowFirst = false,
	PreCondition = {
		PreArea = 130009,
		PreGoal = 
		{
			300314,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Challenge,
	},
	GoalCondition = 
	{
		{
			Name = "打败魔王火山的[FDDE40]岩浆喷泉[-]",
			Type = ItemType.Challenge,
			CountType = GoalCountType.Current,
			Num = 1,
			Value = 140026,
		},
	},
	Reward = {
		{
			Value = 330003,
			Num = 1,
		},
		{
			Value = 2,
			Num = 30,
		},
	},
}
GoalConfig[GoalID.Id316] =
{
	Id = 316,
	Name = "支线-掌握火山的节奏",
	GoalType = GoalType.Main,
	ShowFirst = false,
	PreCondition = {
		PreArea = 130009,
		PreGoal = 
		{
			300315,
		},
	},
	GoalTrigger = 
	{
		TriggerType.CollectItem,
	},
	GoalCondition = 
	{
		{
			Name = "累计拥有[62E7E7]冒险星[-]、[62E7E7]水元素[-][FDDE40]宠物[-]2种",
			Type = ItemType.Pet,
			CountType = GoalCountType.Current,
			Num = 2,
			TagList = 
			{
				560103,
				561202,
			},
			Value = -1,
		},
	},
	Reward = {
		{
			Value = 330001,
			Num = 3,
		},
		{
			Value = 2,
			Num = 30,
		},
	},
}
GoalConfig[GoalID.Id317] =
{
	Id = 317,
	Name = "支线-缓解热浪",
	GoalType = GoalType.Main,
	ShowFirst = false,
	PreCondition = {
		PreArea = 130009,
		PreGoal = 
		{
			300316,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Explore,
	},
	GoalCondition = 
	{
		{
			Name = "派遣含有[62E7E7]1[-][62E7E7]蓝色及以上品质[-]、[62E7E7]水元素[-]队员(或宠物)的队伍在探索中击败[FDDE40]火喷泉[-]20个，建议探索4小时以上",
			Type = ItemType.Enemy,
			CountType = GoalCountType.StartNow,
			Num = 20,
			TagList = 
			{
				560033,
				561202,
			},
			CharacterNum = 1,
			Value = 242021,
		},
	},
	Reward = {
		{
			Value = 330001,
			Num = 3,
		},
		{
			Value = 2,
			Num = 30,
		},
	},
}
GoalConfig[GoalID.Id318] =
{
	Id = 318,
	Name = "支线-火山王的挑战",
	GoalType = GoalType.Main,
	ShowFirst = false,
	PreCondition = {
		PreArea = 130009,
		PreGoal = 
		{
			300317,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Challenge,
	},
	GoalCondition = 
	{
		{
			Name = "打败魔王火山的[FDDE40]火山王[-]",
			Type = ItemType.Challenge,
			CountType = GoalCountType.Current,
			Num = 1,
			Value = 140027,
		},
	},
	Reward = {
		{
			Value = 330003,
			Num = 1,
		},
		{
			Value = 2,
			Num = 30,
		},
	},
}
GoalConfig[GoalID.Id319] =
{
	Id = 319,
	Name = "支线-铁匠的最爱",
	GoalType = GoalType.Main,
	ShowFirst = false,
	PreCondition = {
		PreArea = 130009,
		PreGoal = 
		{
			300318,
		},
	},
	GoalTrigger = 
	{
		TriggerType.CollectItem,
	},
	GoalCondition = 
	{
		{
			Name = "拥有[FDDE40]矿石[-]100个",
			Type = ItemType.Goods,
			CountType = GoalCountType.Current,
			Num = 100,
			Value = 321004,
		},
	},
	Reward = {
		{
			Value = 330001,
			Num = 3,
		},
		{
			Value = 2,
			Num = 30,
		},
	},
}
GoalConfig[GoalID.Id320] =
{
	Id = 320,
	Name = "支线-没有铁匠的世界",
	GoalType = GoalType.Main,
	ShowFirst = false,
	PreCondition = {
		PreArea = 130009,
		PreGoal = 
		{
			300319,
		},
	},
	GoalTrigger = 
	{
		TriggerType.UpgradeEquipment,
	},
	GoalCondition = 
	{
		{
			Name = "没有铁匠时，勇者们成功自学了装备强化。\n强化[62E7E7]任意[-][FDDE40]装备[-]32次",
			Type = ItemType.Equipment,
			CountType = GoalCountType.Current,
			Num = 32,
			Value = -1,
		},
	},
	Reward = {
		{
			Value = 330001,
			Num = 3,
		},
		{
			Value = 2,
			Num = 30,
		},
	},
}
GoalConfig[GoalID.Id321] =
{
	Id = 321,
	Name = "支线-寻找铁匠",
	GoalType = GoalType.Main,
	ShowFirst = false,
	PreCondition = {
		PreArea = 130009,
		PreGoal = 
		{
			300320,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Explore,
	},
	GoalCondition = 
	{
		{
			Name = "听村长说，铁匠为了躲避仇人来到了火山。\n派遣含有[62E7E7]3个[-][62E7E7]经典冒险组[-]队员(或宠物)的队伍探索冒险星[FDDE40]魔王火山[-]12小时",
			Type = ItemType.Time,
			CountType = GoalCountType.StartNow,
			Num = 43200,
			TagList = 
			{
				562902,
			},
			CharacterNum = 3,
			Value = 130009,
		},
	},
	Reward = {
		{
			Value = 330001,
			Num = 3,
		},
		{
			Value = 2,
			Num = 30,
		},
	},
}
GoalConfig[GoalID.Id322] =
{
	Id = 322,
	Name = "支线-铁匠的挑战",
	GoalType = GoalType.Main,
	ShowFirst = false,
	PreCondition = {
		PreArea = 130009,
		PreGoal = 
		{
			300321,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Challenge,
	},
	GoalCondition = 
	{
		{
			Name = "打败魔王火山的[FDDE40]铁匠[-]",
			Type = ItemType.Challenge,
			CountType = GoalCountType.Current,
			Num = 1,
			Value = 140028,
		},
	},
	CompleteSpeech = 30032201,
	Reward = {
		{
			Value = 330003,
			Num = 1,
		},
		{
			Value = 2,
			Num = 30,
		},
	},
}
GoalConfig[GoalID.Id323] =
{
	Id = 323,
	Name = "解锁：藏宝库",
	GoalType = GoalType.Main,
	ShowFirst = false,
	PreCondition = {
		PreArea = 130010,
		PreGoal = 
		{
			300096,
		},
	},
	GoalTrigger = 
	{
		TriggerType.CollectItem,
	},
	GoalCondition = 
	{
		{
			Name = "黑乎乎的无法前进，有合适的光源吗？\n拥有[FDDE40]火把[-]10个",
			Type = ItemType.Goods,
			CountType = GoalCountType.Current,
			Num = 10,
			Value = 321054,
		},
	},
	Reward = {
		{
			Value = 130011,
			Num = 1,
		},
		{
			Value = 330001,
			Num = 4,
		},
		{
			Value = 2,
			Num = 30,
		},
	},
}
GoalConfig[GoalID.Id324] =
{
	Id = 324,
	Name = "支线-嚣张的小火球",
	GoalType = GoalType.Main,
	ShowFirst = false,
	PreCondition = {
		PreArea = 130011,
		PreGoal = 
		{
			300323,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Explore,
	},
	GoalCondition = 
	{
		{
			Name = "探索[62E7E7]藏宝库[-]击败[FDDE40]小火球[-]50个，建议探索10小时以上",
			Type = ItemType.Enemy,
			CountType = GoalCountType.StartNow,
			Num = 50,
			Value = 242023,
			Area = 130011,
		},
	},
	Reward = {
		{
			Value = 330001,
			Num = 4,
		},
		{
			Value = 2,
			Num = 30,
		},
	},
}
GoalConfig[GoalID.Id325] =
{
	Id = 325,
	Name = "支线-研究炭石",
	GoalType = GoalType.Main,
	ShowFirst = false,
	PreCondition = {
		PreArea = 130011,
		PreGoal = 
		{
			300324,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Explore,
	},
	GoalCondition = 
	{
		{
			Name = "在探索中获得[FDDE40]炭石[-]10个",
			Type = ItemType.Goods,
			CountType = GoalCountType.StartNow,
			Num = 10,
			Value = 321009,
		},
	},
	Reward = {
		{
			Value = 330001,
			Num = 4,
		},
		{
			Value = 2,
			Num = 30,
		},
	},
}
GoalConfig[GoalID.Id326] =
{
	Id = 326,
	Name = "支线-火精灵王的挑战",
	GoalType = GoalType.Main,
	ShowFirst = false,
	PreCondition = {
		PreArea = 130011,
		PreGoal = 
		{
			300325,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Challenge,
	},
	GoalCondition = 
	{
		{
			Name = "打败藏宝库的[FDDE40]火精灵王[-]",
			Type = ItemType.Challenge,
			CountType = GoalCountType.Current,
			Num = 1,
			Value = 140033,
		},
	},
	Reward = {
		{
			Value = 330003,
			Num = 1,
		},
		{
			Value = 2,
			Num = 30,
		},
	},
}
GoalConfig[GoalID.Id327] =
{
	Id = 327,
	Name = "支线-恐怖的火焰巨人",
	GoalType = GoalType.Main,
	ShowFirst = false,
	PreCondition = {
		PreArea = 130011,
		PreGoal = 
		{
			300326,
		},
	},
	GoalTrigger = 
	{
		TriggerType.DemandReward,
	},
	GoalCondition = 
	{
		{
			Name = "似乎第8个订单更容易出电池的样子…\n完成[62E7E7]委托[-]获得[62E7E7]电池类的[-]道具2个",
			Type = ItemType.Goods,
			CountType = GoalCountType.StartNow,
			Num = 2,
			TagList = 
			{
				564303,
			},
			Value = -1,
		},
	},
	Reward = {
		{
			Value = 330001,
			Num = 4,
		},
		{
			Value = 2,
			Num = 30,
		},
	},
}
GoalConfig[GoalID.Id328] =
{
	Id = 328,
	Name = "支线-深入宝库",
	GoalType = GoalType.Main,
	ShowFirst = false,
	PreCondition = {
		PreArea = 130011,
		PreGoal = 
		{
			300327,
		},
	},
	GoalTrigger = 
	{
		TriggerType.CollectItem,
	},
	GoalCondition = 
	{
		{
			Name = "拥有至少[62E7E7]2阶[-][FDDE40]角色[-]5个",
			Type = ItemType.Character,
			CountType = GoalCountType.Current,
			Num = 5,
			Value = -1,
			Stage = 2,
		},
	},
	Reward = {
		{
			Value = 330001,
			Num = 4,
		},
		{
			Value = 2,
			Num = 30,
		},
	},
}
GoalConfig[GoalID.Id329] =
{
	Id = 329,
	Name = "支线-歼灭党羽",
	GoalType = GoalType.Main,
	ShowFirst = false,
	PreCondition = {
		PreArea = 130011,
		PreGoal = 
		{
			300328,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Explore,
	},
	GoalCondition = 
	{
		{
			Name = "解锁火焰巨人就要23小时才能完成了喵！\n派遣含有[62E7E7]2[-][62E7E7]紫色及以上品质[-]队员(或宠物)的队伍在探索中击败[FDDE40]火精灵[-]50个，建议探索13小时以上",
			Type = ItemType.Enemy,
			CountType = GoalCountType.StartNow,
			Num = 50,
			TagList = 
			{
				560034,
			},
			CharacterNum = 2,
			Value = 242026,
		},
	},
	Reward = {
		{
			Value = 330001,
			Num = 4,
		},
		{
			Value = 2,
			Num = 30,
		},
	},
}
GoalConfig[GoalID.Id330] =
{
	Id = 330,
	Name = "支线-火焰巨人王的挑战",
	GoalType = GoalType.Main,
	ShowFirst = false,
	PreCondition = {
		PreArea = 130011,
		PreGoal = 
		{
			300329,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Challenge,
	},
	GoalCondition = 
	{
		{
			Name = "打败藏宝库的[FDDE40]火焰巨人王[-]",
			Type = ItemType.Challenge,
			CountType = GoalCountType.Current,
			Num = 1,
			Value = 140034,
		},
	},
	Reward = {
		{
			Value = 330003,
			Num = 1,
		},
		{
			Value = 2,
			Num = 30,
		},
	},
}
GoalConfig[GoalID.Id331] =
{
	Id = 331,
	Name = "新配方：头骨",
	GoalType = GoalType.Main,
	ShowFirst = false,
	PreCondition = {
		PreArea = 130005,
		PreGoal = 
		{
			300046,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Explore,
	},
	GoalCondition = 
	{
		{
			Name = "好的工艺品只用简单素材也能制作出来~\n在探索中获得[FDDE40]矿石[-]10个",
			Type = ItemType.Goods,
			CountType = GoalCountType.StartNow,
			Num = 10,
			Value = 321004,
		},
	},
	Reward = {
		{
			Value = 360201,
			Num = 1,
		},
		{
			Value = 330001,
			Num = 2,
		},
		{
			Value = 2,
			Num = 30,
		},
	},
}
GoalConfig[GoalID.Id332] =
{
	Id = 332,
	Name = "新配方：攻略",
	GoalType = GoalType.Main,
	ShowFirst = false,
	PreCondition = {
		PreArea = 130007,
		PreGoal = 
		{
			300072,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Explore,
	},
	GoalCondition = 
	{
		{
			Name = "将地图装订起来，就变成精致的攻略了~\n在探索中获得[FDDE40]粘液[-]10个",
			Type = ItemType.Goods,
			CountType = GoalCountType.StartNow,
			Num = 10,
			Value = 321006,
		},
	},
	CompleteSpeech = 30033201,
	Reward = {
		{
			Value = 360202,
			Num = 1,
		},
		{
			Value = 330001,
			Num = 3,
		},
		{
			Value = 2,
			Num = 30,
		},
	},
}
GoalConfig[GoalID.Id333] =
{
	Id = 333,
	Name = "新配方：沙漏",
	GoalType = GoalType.Main,
	ShowFirst = false,
	PreCondition = {
		PreArea = 130009,
		PreGoal = 
		{
			300315,
		},
	},
	GoalTrigger = 
	{
		TriggerType.CollectItem,
	},
	GoalCondition = 
	{
		{
			Name = "有高级钟表后，沙漏慢慢变成装饰品了。\n拥有[FDDE40]沙堆[-]10个",
			Type = ItemType.Goods,
			CountType = GoalCountType.Current,
			Num = 10,
			Value = 321008,
		},
	},
	Reward = {
		{
			Value = 360203,
			Num = 1,
		},
		{
			Value = 330001,
			Num = 3,
		},
		{
			Value = 2,
			Num = 30,
		},
	},
}
GoalConfig[GoalID.Id334] =
{
	Id = 334,
	Name = "新配方：火把",
	GoalType = GoalType.Main,
	ShowFirst = false,
	PreCondition = {
		PreArea = 130010,
		PreGoal = 
		{
			300087,
		},
	},
	GoalTrigger = 
	{
		TriggerType.SubmitGoods,
	},
	GoalCondition = 
	{
		{
			Name = "如果要去黑暗的地方，就需要准备这个了！\n提交[FDDE40]炭石[-]10个",
			Type = ItemType.Goods,
			CountType = GoalCountType.Current,
			Num = 10,
			Value = 321009,
		},
	},
	Reward = {
		{
			Value = 360204,
			Num = 1,
		},
		{
			Value = 330001,
			Num = 3,
		},
		{
			Value = 2,
			Num = 30,
		},
	},
}
GoalConfig[GoalID.Id335] =
{
	Id = 335,
	Name = "地图打卡：冒险大厅",
	GoalType = GoalType.Main,
	ShowFirst = false,
	PreCondition = {
		PreArea = 130002,
		PreGoal = 
		{
			300013,
			300011,
		},
	},
	GoalTrigger = 
	{
		TriggerType.CompleteDemand,
	},
	GoalCondition = 
	{
		{
			Name = "地图界面空荡荡的？尝试一下打卡任务吧~\n完成[62E7E7]任意[-][FDDE40]委托[-]2次",
			Type = ItemType.Demand,
			CountType = GoalCountType.StartNow,
			Num = 2,
			Value = -1,
		},
	},
	Reward = {
		{
			Value = 320041,
			Num = 20,
		},
		{
			Value = 320051,
			Num = 20,
		},
		{
			Value = 1,
			Num = 900,
		},
	},
}
GoalConfig[GoalID.Id336] =
{
	Id = 336,
	Name = "地图打卡：树海",
	GoalType = GoalType.Main,
	ShowFirst = false,
	PreCondition = {
		PreArea = 130003,
		PreGoal = 
		{
			300023,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Explore,
	},
	GoalCondition = 
	{
		{
			Name = "虽然就在村口，但是平时很少人去那里…\n[62E7E7]一次性[-]探索冒险星[FDDE40]村口树林[-]60分钟",
			Type = ItemType.Time,
			CountType = GoalCountType.OneShot,
			Num = 3600,
			Value = 130003,
		},
	},
	Reward = {
		{
			Value = 320041,
			Num = 25,
		},
		{
			Value = 320051,
			Num = 25,
		},
		{
			Value = 1,
			Num = 1800,
		},
	},
}
GoalConfig[GoalID.Id337] =
{
	Id = 337,
	Name = "地图打卡：鼹鼠兄弟",
	GoalType = GoalType.Main,
	ShowFirst = false,
	PreCondition = {
		PreArea = 130004,
		PreGoal = 
		{
			300040,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Explore,
	},
	GoalCondition = 
	{
		{
			Name = "附近没有危险时，溪谷鼹鼠就会出现噢~\n在探索中击败[FDDE40]白狼[-]4个，建议探索4小时以上",
			Type = ItemType.Enemy,
			CountType = GoalCountType.StartNow,
			Num = 4,
			Value = 242010,
		},
	},
	Reward = {
		{
			Value = 320041,
			Num = 30,
		},
		{
			Value = 320051,
			Num = 30,
		},
		{
			Value = 1,
			Num = 3600,
		},
	},
}
GoalConfig[GoalID.Id338] =
{
	Id = 338,
	Name = "地图打卡：史莱姆王",
	GoalType = GoalType.Main,
	ShowFirst = false,
	PreCondition = {
		PreArea = 130005,
		PreGoal = 
		{
			300055,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Explore,
	},
	GoalCondition = 
	{
		{
			Name = "得想个办法让史莱姆集合起来！\n[62E7E7]一次性[-]探索[62E7E7]魔法平原[-]击败[FDDE40]蓝色史莱姆[-]30个，建议探索6小时以上",
			Type = ItemType.Enemy,
			CountType = GoalCountType.OneShot,
			Num = 30,
			Value = 242002,
			Area = 130005,
		},
	},
	Reward = {
		{
			Value = 320041,
			Num = 40,
		},
		{
			Value = 320051,
			Num = 40,
		},
		{
			Value = 1,
			Num = 4200,
		},
	},
}
GoalConfig[GoalID.Id339] =
{
	Id = 339,
	Name = "地图打卡：英雄冢",
	GoalType = GoalType.Main,
	ShowFirst = false,
	PreCondition = {
		PreArea = 130006,
		PreGoal = 
		{
			300066,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Explore,
	},
	GoalCondition = 
	{
		{
			Name = "前任英雄的宝剑应该就插在什么地方呢~\n在探索中击败[FDDE40]地缚灵[-]10个，建议探索4小时以上",
			Type = ItemType.Enemy,
			CountType = GoalCountType.StartNow,
			Num = 10,
			Value = 242015,
		},
	},
	Reward = {
		{
			Value = 320041,
			Num = 45,
		},
		{
			Value = 320051,
			Num = 45,
		},
		{
			Value = 1,
			Num = 5300,
		},
	},
}
GoalConfig[GoalID.Id340] =
{
	Id = 340,
	Name = "地图打卡：特别的塔",
	GoalType = GoalType.Main,
	ShowFirst = false,
	PreCondition = {
		PreArea = 130007,
		PreGoal = 
		{
			300084,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Explore,
	},
	GoalCondition = 
	{
		{
			Name = "你见过史莱姆们叠起来组成的塔吗？\n[62E7E7]一次性[-]探索[62E7E7]大沼泽[-]击败[FDDE40]紫色史莱姆[-]45个，建议探索8小时以上",
			Type = ItemType.Enemy,
			CountType = GoalCountType.OneShot,
			Num = 45,
			Value = 242003,
			Area = 130007,
		},
	},
	Reward = {
		{
			Value = 320041,
			Num = 50,
		},
		{
			Value = 320051,
			Num = 50,
		},
		{
			Value = 1,
			Num = 7700,
		},
	},
}
GoalConfig[GoalID.Id341] =
{
	Id = 341,
	Name = "地图打卡：巨大阴影",
	GoalType = GoalType.Main,
	ShowFirst = false,
	PreCondition = {
		PreArea = 130008,
		PreGoal = 
		{
			300309,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Explore,
	},
	GoalCondition = 
	{
		{
			Name = "听说有冒险者在这里看到过超大怪物~\n在探索中击败[FDDE40]钢铁刺毛怪[-]6个，建议探索14小时以上",
			Type = ItemType.Enemy,
			CountType = GoalCountType.StartNow,
			Num = 6,
			Value = 242020,
		},
	},
	Reward = {
		{
			Value = 320041,
			Num = 55,
		},
		{
			Value = 320051,
			Num = 55,
		},
		{
			Value = 1,
			Num = 10100,
		},
	},
}
GoalConfig[GoalID.Id342] =
{
	Id = 342,
	Name = "地图打卡：火山群落",
	GoalType = GoalType.Main,
	ShowFirst = false,
	PreCondition = {
		PreArea = 130009,
		PreGoal = 
		{
			300322,
		},
	},
	GoalTrigger = 
	{
		TriggerType.ExploreCost,
	},
	GoalCondition = 
	{
		{
			Name = "道具店升级就能解锁更高级的血瓶配方\n探索[62E7E7]魔王火山[-]消耗[FDDE40]特大血瓶[-]5个",
			Type = ItemType.Goods,
			CountType = GoalCountType.StartNow,
			Num = 5,
			Value = 320404,
			Area = 130009,
		},
	},
	Reward = {
		{
			Value = 320041,
			Num = 60,
		},
		{
			Value = 320051,
			Num = 60,
		},
		{
			Value = 1,
			Num = 8600,
		},
	},
}
GoalConfig[GoalID.Id343] =
{
	Id = 343,
	Name = "地图打卡：异界传送门",
	GoalType = GoalType.Main,
	ShowFirst = false,
	PreCondition = {
		PreArea = 130010,
		PreGoal = 
		{
			300102,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Explore,
	},
	GoalCondition = 
	{
		{
			Name = "那么多史莱姆，究竟是从哪来的呢？\n[62E7E7]一次性[-]探索[62E7E7]魔王城堡[-]击败[FDDE40]红色史莱姆[-]60个，建议探索13小时以上",
			Type = ItemType.Enemy,
			CountType = GoalCountType.OneShot,
			Num = 60,
			Value = 242004,
			Area = 130010,
		},
	},
	Reward = {
		{
			Value = 320041,
			Num = 65,
		},
		{
			Value = 320051,
			Num = 65,
		},
		{
			Value = 1,
			Num = 11600,
		},
	},
}
GoalConfig[GoalID.Id344] =
{
	Id = 344,
	Name = "地图打卡：魔王城堡",
	GoalType = GoalType.Main,
	ShowFirst = false,
	PreCondition = {
		PreArea = 130010,
		PreGoal = 
		{
			300102,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Explore,
	},
	GoalCondition = 
	{
		{
			Name = "魔王城堡的能量是通过小火球贡献的呢~\n探索[62E7E7]魔王城堡[-]击败[FDDE40]小火球[-]25个，建议探索11小时以上",
			Type = ItemType.Enemy,
			CountType = GoalCountType.StartNow,
			Num = 25,
			Value = 242023,
			Area = 130010,
		},
	},
	Reward = {
		{
			Value = 320041,
			Num = 70,
		},
		{
			Value = 320051,
			Num = 70,
		},
		{
			Value = 1,
			Num = 11600,
		},
	},
}
GoalConfig[GoalID.Id345] =
{
	Id = 345,
	Name = "地图打卡：封印之塔",
	GoalType = GoalType.Main,
	ShowFirst = false,
	PreCondition = {
		PreArea = 130011,
		PreGoal = 
		{
			300330,
			300344,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Explore,
	},
	GoalCondition = 
	{
		{
			Name = "传说中巨龙的栖所，撕开封印就会出现~\n[62E7E7]一次性[-]在探索中击败[FDDE40]火焰巨人[-]5个，建议探索12小时以上",
			Type = ItemType.Enemy,
			CountType = GoalCountType.OneShot,
			Num = 5,
			Value = 242027,
		},
	},
	Reward = {
		{
			Value = 320611,
			Num = 1,
		},
		{
			Value = 330003,
			Num = 10,
		},
	},
}
GoalConfig[GoalID.Id346] =
{
	Id = 346,
	Name = "解锁：外星的观光团",
	GoalType = GoalType.Main,
	ShowFirst = false,
	PreCondition = {
		PreArea = 130003,
		PreGoal = 
		{
			300084,
		},
	},
	GoalTrigger = 
	{
		TriggerType.CollectItem,
	},
	GoalCondition = 
	{
		{
			Name = "请问，飞船上的宠物可以给我们看看嘛？\n累计拥有[FDDE40]7种宠物[-]",
			Type = ItemType.Pet,
			CountType = GoalCountType.Current,
			Num = 7,
			TagList = 
			{
				560032,
			},
			Value = -1,
		},
	},
	Reward = {
		{
			Value = 330001,
			Num = 3,
		},
		{
			Value = 2,
			Num = 30,
		},
	},
}
GoalConfig[GoalID.Id347] =
{
	Id = 347,
	Name = "解锁：流亡者的街区",
	GoalType = GoalType.Main,
	ShowFirst = false,
	PreCondition = {
		PreArea = 130003,
		PreGoal = 
		{
			300102,
		},
	},
	GoalTrigger = 
	{
		TriggerType.CollectItem,
	},
	GoalCondition = 
	{
		{
			Name = "通告：请符合条件的冒险团务必前来报名！\n拥有至少[62E7E7]10级[-][FDDE40]角色[-]15个",
			Type = ItemType.Character,
			CountType = GoalCountType.Current,
			Num = 15,
			Value = -1,
			Level = 10,
		},
	},
	Reward = {
		{
			Value = 330001,
			Num = 4,
		},
		{
			Value = 2,
			Num = 30,
		},
	},
}
GoalConfig[GoalID.Id348] =
{
	Id = 348,
	Name = "支线-收藏家的考验1",
	GoalType = GoalType.Main,
	ShowFirst = false,
	PreCondition = {
		PreArea = 130003,
		PreGoal = 
		{
			300055,
		},
	},
	GoalTrigger = 
	{
		TriggerType.CompleteDemand,
	},
	GoalCondition = 
	{
		{
			Name = "平时经常麻烦阁下，这次送些私人珍藏吧。\n完成[62E7E7]任意[-][FDDE40]委托[-]5次",
			Type = ItemType.Demand,
			CountType = GoalCountType.StartNow,
			Num = 5,
			Value = -1,
		},
	},
	CompleteSpeech = 30034801,
	Reward = {
		{
			Value = 320101,
			Num = 2,
		},
	},
}
GoalConfig[GoalID.Id349] =
{
	Id = 349,
	Name = "支线-收藏家的考验2",
	GoalType = GoalType.Main,
	ShowFirst = false,
	PreCondition = {
		PreArea = 130003,
		PreGoal = 
		{
			300348,
		},
	},
	GoalTrigger = 
	{
		TriggerType.CompleteDemand,
	},
	GoalCondition = 
	{
		{
			Name = "唔，还有些存货，请再次完成我的考验吧！\n完成[62E7E7]任意[-][FDDE40]委托[-]10次",
			Type = ItemType.Demand,
			CountType = GoalCountType.StartNow,
			Num = 10,
			Value = -1,
		},
	},
	CompleteSpeech = 30034901,
	Reward = {
		{
			Value = 320102,
			Num = 2,
		},
	},
}
GoalConfig[GoalID.Id350] =
{
	Id = 350,
	Name = "支线-收藏家的考验3",
	GoalType = GoalType.Main,
	ShowFirst = false,
	PreCondition = {
		PreArea = 130003,
		PreGoal = 
		{
			300349,
		},
	},
	GoalTrigger = 
	{
		TriggerType.CompleteDemand,
	},
	GoalCondition = 
	{
		{
			Name = "这些封存记忆的碎片，怎么用就随你啦~\n完成[62E7E7]任意[-][FDDE40]委托[-]15次",
			Type = ItemType.Demand,
			CountType = GoalCountType.StartNow,
			Num = 15,
			Value = -1,
		},
	},
	CompleteSpeech = 30035001,
	Reward = {
		{
			Value = 320103,
			Num = 2,
		},
	},
}
GoalConfig[GoalID.Id351] =
{
	Id = 351,
	Name = "支线-订单小鸽的请求1",
	GoalType = GoalType.Main,
	ShowFirst = false,
	PreCondition = {
		PreArea = 130003,
		PreGoal = 
		{
			300084,
		},
	},
	GoalTrigger = 
	{
		TriggerType.SubmitGoods,
	},
	GoalCondition = 
	{
		{
			Name = "咕咕…迷路好几天了咕，肚子都饿扁了…\n提交[FDDE40]纷享桶[-]10个",
			Type = ItemType.Goods,
			CountType = GoalCountType.Current,
			Num = 10,
			Value = 320407,
		},
	},
	CompleteSpeech = 30035101,
	Reward = {
		{
			Value = 1,
			Num = 500,
		},
		{
			Value = 2,
			Num = 50,
		},
	},
}
GoalConfig[GoalID.Id352] =
{
	Id = 352,
	Name = "支线-订单小鸽的请求2",
	GoalType = GoalType.Main,
	ShowFirst = false,
	PreCondition = {
		PreArea = 130003,
		PreGoal = 
		{
			300351,
		},
	},
	GoalTrigger = 
	{
		TriggerType.SubmitGoods,
	},
	GoalCondition = 
	{
		{
			Name = "导航器失灵了！好心人还能帮帮我吗？\n提交[FDDE40]固化零件D[-]50个",
			Type = ItemType.Goods,
			CountType = GoalCountType.Current,
			Num = 50,
			Value = 320051,
		},
	},
	CompleteSpeech = 30035201,
	Reward = {
		{
			Value = 1,
			Num = 1000,
		},
		{
			Value = 2,
			Num = 100,
		},
	},
}
GoalConfig[GoalID.Id353] =
{
	Id = 353,
	Name = "支线-订单小鸽的请求3",
	GoalType = GoalType.Main,
	ShowFirst = false,
	PreCondition = {
		PreArea = 130003,
		PreGoal = 
		{
			300352,
		},
	},
	GoalTrigger = 
	{
		TriggerType.SubmitGoods,
	},
	GoalCondition = 
	{
		{
			Name = "咕咕…导航器电量不足，急需2节新电池…\n提交[FDDE40]低量电池[-]2个",
			Type = ItemType.Goods,
			CountType = GoalCountType.Current,
			Num = 2,
			Value = 320001,
		},
	},
	CompleteSpeech = 30035301,
	Reward = {
		{
			Value = 1,
			Num = 1500,
		},
		{
			Value = 2,
			Num = 150,
		},
	},
}
GoalConfig[GoalID.Id354] =
{
	Id = 354,
	Name = "支线-订单小鸽的请求4",
	GoalType = GoalType.Main,
	ShowFirst = false,
	PreCondition = {
		PreArea = 130003,
		PreGoal = 
		{
			300353,
		},
	},
	GoalTrigger = 
	{
		TriggerType.ActivityChallenge,
	},
	GoalCondition = 
	{
		{
			Name = "啊，别烦我啦，我打会游戏再工作啦~\n打败[FDDE40]专员小鸽[-]",
			Type = ItemType.Challenge,
			CountType = GoalCountType.Current,
			Num = 1,
			Value = 147012,
		},
	},
	CompleteSpeech = 30035401,
	Reward = {
		{
			Value = 320001,
			Num = 2,
		},
		{
			Value = 1,
			Num = 2000,
		},
		{
			Value = 2,
			Num = 200,
		},
	},
}
GoalConfig[GoalID.Id355] =
{
	Id = 355,
	Name = "支线-呜呜漆漆的美好夏日1",
	GoalType = GoalType.Main,
	ShowFirst = false,
	PreCondition = {
		PreArea = 130007,
		PreGoal = 
		{
			300069,
		},
	},
	GoalTrigger = 
	{
		TriggerType.DemandReward,
	},
	GoalCondition = 
	{
		{
			Name = "完成[62E7E7]委托[-]获得[FDDE40]金币[-]25000个",
			Type = ItemType.Gold,
			CountType = GoalCountType.StartNow,
			Num = 25000,
			Value = 1,
		},
	},
	CompleteSpeech = 30035501,
	Reward = {
		{
			Value = 330003,
			Num = 1,
		},
	},
}
GoalConfig[GoalID.Id356] =
{
	Id = 356,
	Name = "支线-呜呜漆漆的美好夏日2",
	GoalType = GoalType.Main,
	ShowFirst = false,
	PreCondition = {
		PreArea = 130007,
		PreGoal = 
		{
			300355,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Explore,
	},
	GoalCondition = 
	{
		{
			Name = "派遣[62E7E7]呜呜[-]、[62E7E7]漆漆[-]探索冒险星[FDDE40]溪谷[-]4小时",
			Type = ItemType.Time,
			CountType = GoalCountType.StartNow,
			Num = 14400,
			Character = 
			{
				220001,
				220002,
			},
			Value = 130004,
		},
	},
	CompleteSpeech = 30035601,
	Reward = {
		{
			Value = 330003,
			Num = 1,
		},
	},
}
GoalConfig[GoalID.Id357] =
{
	Id = 357,
	Name = "支线-呜呜漆漆的美好夏日3",
	GoalType = GoalType.Main,
	ShowFirst = false,
	PreCondition = {
		PreArea = 130007,
		PreGoal = 
		{
			300356,
		},
	},
	GoalTrigger = 
	{
		TriggerType.CollectItem,
	},
	GoalCondition = 
	{
		{
			Name = "拥有至少[62E7E7]25级[-][FDDE40]呜呜[-]",
			Type = ItemType.Character,
			CountType = GoalCountType.Current,
			Num = 1,
			Value = 220001,
			Level = 25,
		},
	},
	CompleteSpeech = 30035701,
	Reward = {
		{
			Value = 330003,
			Num = 2,
		},
	},
}
GoalConfig[GoalID.Id358] =
{
	Id = 358,
	Name = "支线-呜呜漆漆的美好夏日4",
	GoalType = GoalType.Main,
	ShowFirst = false,
	PreCondition = {
		PreArea = 130007,
		PreGoal = 
		{
			300357,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Explore,
	},
	GoalCondition = 
	{
		{
			Name = "派遣[62E7E7]呜呜[-]、[62E7E7]漆漆[-]探索冒险星[FDDE40]村口树林[-]6小时",
			Type = ItemType.Time,
			CountType = GoalCountType.StartNow,
			Num = 21600,
			Character = 
			{
				220001,
				220002,
			},
			Value = 130003,
		},
	},
	CompleteSpeech = 30035801,
	Reward = {
		{
			Value = 330003,
			Num = 2,
		},
	},
}
GoalConfig[GoalID.Id359] =
{
	Id = 359,
	Name = "支线-呜呜漆漆的美好夏日5",
	GoalType = GoalType.Main,
	ShowFirst = false,
	PreCondition = {
		PreArea = 130007,
		PreGoal = 
		{
			300358,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Explore,
	},
	GoalCondition = 
	{
		{
			Name = "派遣[62E7E7]呜呜[-]、[62E7E7]漆漆[-]探索[62E7E7]大沼泽[-]击败[FDDE40]沼泽地[-]20个，建议探索8小时以上",
			Type = ItemType.Enemy,
			CountType = GoalCountType.StartNow,
			Num = 20,
			Character = 
			{
				220001,
				220002,
			},
			Value = 242016,
			Area = 130007,
		},
	},
	CompleteSpeech = 30035901,
	Reward = {
		{
			Value = 330003,
			Num = 3,
		},
	},
}
GoalConfig[GoalID.Id360] =
{
	Id = 360,
	Name = "支线-呜呜漆漆的美好夏日6",
	GoalType = GoalType.Main,
	ShowFirst = false,
	PreCondition = {
		PreArea = 130010,
		PreGoal = 
		{
			300359,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Explore,
	},
	GoalCondition = 
	{
		{
			Name = "派遣[62E7E7]呜呜[-]、[62E7E7]漆漆[-]探索冒险星[FDDE40]魔王城堡[-]10小时",
			Type = ItemType.Time,
			CountType = GoalCountType.StartNow,
			Num = 36000,
			Character = 
			{
				220001,
				220002,
			},
			Value = 130010,
		},
	},
	CompleteSpeech = 30036001,
	Reward = {
		{
			Value = 330003,
			Num = 3,
		},
	},
}
GoalConfig[GoalID.Id361] =
{
	Id = 361,
	Name = "支线-呜呜漆漆的美好夏日7",
	GoalType = GoalType.Main,
	ShowFirst = false,
	PreCondition = {
		PreArea = 130010,
		PreGoal = 
		{
			300360,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Explore,
	},
	GoalCondition = 
	{
		{
			Name = "千万别忘了带绿色史莱姆哦！\n派遣[62E7E7]呜呜[-]、[62E7E7]漆漆[-]携带[62E7E7]绿色史莱姆[-]探索冒险星[FDDE40]溪谷[-]12小时",
			Type = ItemType.Time,
			CountType = GoalCountType.StartNow,
			Num = 43200,
			Character = 
			{
				220001,
				220002,
			},
			Pet = 250001,
			Value = 130004,
		},
	},
	CompleteSpeech = 30036101,
	Reward = {
		{
			Value = 330003,
			Num = 4,
		},
	},
}
GoalConfig[GoalID.Id362] =
{
	Id = 362,
	Name = "支线-呜呜漆漆的美好夏日8",
	GoalType = GoalType.Main,
	ShowFirst = false,
	PreCondition = {
		PreArea = 130010,
		PreGoal = 
		{
			300361,
		},
	},
	GoalTrigger = 
	{
		TriggerType.CollectItem,
	},
	GoalCondition = 
	{
		{
			Name = "拥有[FDDE40]攻略[-]10个",
			Type = ItemType.Goods,
			CountType = GoalCountType.Current,
			Num = 10,
			Value = 321052,
		},
	},
	CompleteSpeech = 30036201,
	Reward = {
		{
			Value = 330003,
			Num = 4,
		},
	},
}
GoalConfig[GoalID.Id363] =
{
	Id = 363,
	Name = "支线-呜呜漆漆的美好夏日9",
	GoalType = GoalType.Main,
	ShowFirst = false,
	PreCondition = {
		PreArea = 130010,
		PreGoal = 
		{
			300362,
		},
	},
	GoalTrigger = 
	{
		TriggerType.SubmitGoods,
	},
	GoalCondition = 
	{
		{
			Name = "提交[FDDE40]木材[-]30个",
			Type = ItemType.Goods,
			CountType = GoalCountType.Current,
			Num = 30,
			Value = 321002,
		},
	},
	CompleteSpeech = 30036301,
	Reward = {
		{
			Value = 320106,
			Num = 1,
		},
		{
			Value = 320107,
			Num = 1,
		},
		{
			Value = 330003,
			Num = 5,
		},
	},
}
