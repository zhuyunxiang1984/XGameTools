
EnemyConfig[EnemyID.Id001] =
{
	Id = 1,
	Name = "史莱姆代表",
	Rarity = 1,
	Element = 210003,
	Style = "Dps",
	AttackType = "Melee",
	Area = 
	{
		130002,
	},
	Desc = "体内带有大量绿色素的小精灵，喜欢捡冒险者丢掉的东西，被它碰到的东西就会被染成绿色，不要丢下帽子。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	IconName = "RPG_Slime_green",
	PrefabBundle = "character_enemy",
	PrefabName = "RPG_Slime_green",
	PrefabScale = 50,
	HPBarHeight = 69,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 156, Gain = 32},
		{Value = 200002, Base = 26, Gain = 6},
		{Value = 200003, Base = 0, Gain = 0},
		{Value = 200004, Base = 0, Gain = 0},
	},
	Drop = {
	},
	Tags = {
		560202,
		560103,
		560204,
		560205,
		560206,
		560207,
		560209,
		560210,
		560211,
		561204,
		561305,
		561323,
		563102,
		563203,
	},
}
EnemyConfig[EnemyID.Id002] =
{
	Id = 2,
	Name = "野花丛",
	Rarity = 2,
	Element = 210003,
	Style = "Dps",
	AttackType = "Melee",
	Area = 
	{
		130002,
	},
	Desc = "潜伏在路边的小花丛，以绊倒路人取乐，让对方只能忍气吞声。\n拜托，你不会是想对一朵花发火吧？",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	IconName = "RPG_huacong",
	PrefabBundle = "character_enemy",
	PrefabName = "RPG_huacong",
	PrefabScale = 50,
	HPBarHeight = 76,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 148, Gain = 30},
		{Value = 200002, Base = 25, Gain = 5},
		{Value = 200003, Base = 10, Gain = 0},
		{Value = 200004, Base = 0, Gain = 0},
	},
	Drop = {
	},
	Tags = {
		560202,
		560103,
		560204,
		560205,
		560206,
		560207,
		560209,
		560210,
		560211,
		561204,
		561320,
		563102,
		563203,
	},
}
EnemyConfig[EnemyID.Id003] =
{
	Id = 3,
	Name = "花球老大",
	Rarity = 2,
	Element = 210003,
	Style = "Dps",
	AttackType = "Melee",
	Area = 
	{
		130002,
	},
	Desc = "活泼好动的小花球，有时候会溜进人类的城镇里探险。不喜欢自己的名字，正在努力减肥，希望能被人叫做小花干。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	IconName = "RPG_xiaohuaqiu",
	PrefabBundle = "character_enemy",
	PrefabName = "RPG_xiaohuaqiu",
	PrefabScale = 50,
	HPBarHeight = 76,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 148, Gain = 30},
		{Value = 200002, Base = 24, Gain = 5},
		{Value = 200003, Base = 10, Gain = 0},
		{Value = 200004, Base = 0, Gain = 0},
	},
	Drop = {
	},
	Tags = {
		560202,
		560103,
		560204,
		560205,
		560206,
		560207,
		560209,
		560210,
		560211,
		561204,
		561320,
		563102,
		563203,
	},
}
EnemyConfig[EnemyID.Id004] =
{
	Id = 4,
	Name = "剑士",
	Rarity = 2,
	Element = 210002,
	Style = "Dps",
	AttackType = "Melee",
	Area = 
	{
		130002,
	},
	Desc = "自称为冒险星的主角，身负打败魔王以及为世界带来和平的重任。虽然帮助村民不求回报，但缺物资时，会以正义之名进入NPC家中取走合用的财物。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	IconName = "Rpg_05_jianshi",
	PrefabBundle = "character_rpg",
	PrefabName = "Rpg_05_jianshi",
	SkinName = "1",
	PrefabScale = 50,
	HPBarHeight = 105,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 307, Gain = 62},
		{Value = 200002, Base = 22, Gain = 5},
		{Value = 200003, Base = 10, Gain = 0},
		{Value = 200004, Base = 0, Gain = 0},
	},
	Drop = {
	},
	SkillList = {
		Desc = "生命 +15%\n攻击 +15%",
		Skill = {
			{
				Id = 105001,
				Value = 15,
			},
			{
				Id = 105002,
				Value = 15,
			},
		},
	},
	Tags = {
		564561,
	},
}
EnemyConfig[EnemyID.Id005] =
{
	Id = 5,
	Name = "精英大树怪",
	Rarity = 2,
	Element = 210003,
	Style = "Dps",
	AttackType = "Melee",
	Area = 
	{
		130003,
	},
	Desc = "憨直的大树怪，结出的果实美味可口，听说还帮助科学家发现了万有引力。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	IconName = "RPG_dashu",
	PrefabBundle = "character_enemy",
	PrefabName = "RPG_dashu",
	PrefabScale = 50,
	HPBarHeight = 141,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 322, Gain = 65},
		{Value = 200002, Base = 24, Gain = 5},
		{Value = 200003, Base = 0, Gain = 0},
		{Value = 200004, Base = 0, Gain = 0},
	},
	Drop = {
	},
	SkillList = {
		Desc = "生命 +20%",
		Skill = {
			{
				Id = 105001,
				Value = 20,
			},
		},
	},
	Tags = {
		560202,
		560103,
		560204,
		560205,
		560206,
		560207,
		560209,
		560210,
		560211,
		561204,
		561320,
		563102,
		563202,
		564561,
	},
}
EnemyConfig[EnemyID.Id006] =
{
	Id = 6,
	Name = "树桩猴老大",
	Rarity = 2,
	Element = 210003,
	Style = "Dps",
	AttackType = "Melee",
	Area = 
	{
		130003,
	},
	Desc = "生命力旺盛的树桩猴，扎在土里能长成大树，但是非常好动，根本坐不住，经常把自己连根拔起。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	IconName = "RPG_shuzhuangguai",
	PrefabBundle = "character_enemy",
	PrefabName = "RPG_shuzhuangguai",
	PrefabScale = 50,
	HPBarHeight = 69,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 322, Gain = 65},
		{Value = 200002, Base = 23, Gain = 5},
		{Value = 200003, Base = 0, Gain = 0},
		{Value = 200004, Base = 0, Gain = 0},
	},
	Drop = {
	},
	SkillList = {
		Desc = "有15%概率额外攻击1次",
		Skill = {
			{
				Id = 105023,
				Value = 15,
			},
		},
	},
	Tags = {
		560202,
		560103,
		560204,
		560205,
		560206,
		560207,
		560209,
		560210,
		560211,
		561204,
		561320,
		563102,
		563205,
		564558,
	},
}
EnemyConfig[EnemyID.Id007] =
{
	Id = 7,
	Name = "弓箭手",
	Rarity = 2,
	Element = 210003,
	Style = "Dps",
	AttackType = "Melee",
	Area = 
	{
		130003,
	},
	Desc = "精灵国的美丽公主，目前正独自外出历练。拥有举世无双的射术，但遇到可怕的怪物便会立刻陷入战斗不能状态。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	IconName = "Rpg_24_gongjianshou",
	PrefabBundle = "character_rpg",
	PrefabName = "Rpg_24_gongjianshou",
	SkinName = "1",
	PrefabScale = 50,
	HPBarHeight = 105,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 300, Gain = 60},
		{Value = 200002, Base = 23, Gain = 5},
		{Value = 200003, Base = 15, Gain = 0},
		{Value = 200004, Base = 0, Gain = 0},
	},
	Drop = {
	},
	SkillList = {
		Desc = "攻击 +45%",
		Skill = {
			{
				Id = 105002,
				Value = 45,
			},
		},
	},
	Tags = {
		564561,
	},
}
EnemyConfig[EnemyID.Id008] =
{
	Id = 8,
	Name = "野狼队长",
	Rarity = 2,
	Element = 210001,
	Style = "Dps",
	AttackType = "Melee",
	Area = 
	{
		130004,
	},
	Desc = "经常成群袭击路人的野兽，非常凶猛，可以用骨头引开它的注意力。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	IconName = "RPG_Wolf",
	PrefabBundle = "character_enemy",
	PrefabName = "RPG_Wolf",
	PrefabScale = 50,
	HPBarHeight = 89,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 823, Gain = 165},
		{Value = 200002, Base = 26, Gain = 6},
		{Value = 200003, Base = 0, Gain = 0},
		{Value = 200004, Base = 0, Gain = 0},
	},
	Drop = {
	},
	SkillList = {
		Desc = "20%概率闪避攻击",
		Skill = {
			{
				Id = 105026,
				Value = 20,
			},
		},
	},
	Tags = {
		560202,
		560103,
		560204,
		560205,
		560206,
		560207,
		560209,
		560210,
		560211,
		561202,
		561303,
		561349,
		563102,
		563205,
		564557,
	},
}
EnemyConfig[EnemyID.Id009] =
{
	Id = 9,
	Name = "白狼头领",
	Rarity = 3,
	Element = 210004,
	Style = "Dps",
	AttackType = "Melee",
	Area = 
	{
		130004,
	},
	Desc = "狼群的领袖，与众不同的颜色给人以强烈的压迫感。比较挑食，只接受带肉的骨头。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	IconName = "RPG_WhiteWolf",
	PrefabBundle = "character_enemy",
	PrefabName = "RPG_WhiteWolf",
	PrefabScale = 50,
	HPBarHeight = 102,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 806, Gain = 162},
		{Value = 200002, Base = 26, Gain = 6},
		{Value = 200003, Base = 0, Gain = 0},
		{Value = 200004, Base = 0, Gain = 0},
	},
	Drop = {
	},
	SkillList = {
		Desc = "生命 +25%\n30%概率闪避攻击",
		Skill = {
			{
				Id = 105001,
				Value = 25,
			},
			{
				Id = 105026,
				Value = 30,
			},
		},
	},
	Tags = {
		560202,
		560103,
		560204,
		560205,
		560206,
		560207,
		560209,
		560210,
		560211,
		561205,
		561303,
		561349,
		563102,
		563205,
		564557,
		564561,
	},
}
EnemyConfig[EnemyID.Id010] =
{
	Id = 10,
	Name = "猎人",
	Rarity = 2,
	Element = 210003,
	Style = "Dps",
	AttackType = "Melee",
	Area = 
	{
		130004,
	},
	Desc = "胆小又不认路的猎人，天生体弱多病。妈妈非常宠他，但爸爸却很严厉。被爸爸强制送往冒险夏令营后，独自在野外修炼。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	IconName = "Rpg_16_lieren",
	PrefabBundle = "character_rpg",
	PrefabName = "Rpg_16_lieren",
	SkinName = "1",
	PrefabScale = 50,
	HPBarHeight = 115,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 876, Gain = 176},
		{Value = 200002, Base = 30, Gain = 6},
		{Value = 200003, Base = 0, Gain = 0},
		{Value = 200004, Base = 50, Gain = 0},
	},
	Drop = {
	},
	SkillList = {
		Desc = "5回合后，回血 50%",
		Skill = {
			{
				Id = 105013,
				Value = 50,
			},
		},
	},
	Tags = {
		564560,
	},
}
EnemyConfig[EnemyID.Id011] =
{
	Id = 11,
	Name = "史莱姆代表",
	Rarity = 1,
	Element = 210001,
	Style = "Dps",
	AttackType = "Melee",
	Area = 
	{
		130005,
	},
	Desc = "体内带有大量蓝色素的小精灵，喜欢捡冒险者丢掉的东西，被它碰到的东西就会被染成蓝色。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	IconName = "RPG_Slime_blue",
	PrefabBundle = "character_enemy",
	PrefabName = "RPG_Slime_blue",
	PrefabScale = 50,
	HPBarHeight = 69,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 1166, Gain = 234},
		{Value = 200002, Base = 38, Gain = 8},
		{Value = 200003, Base = 10, Gain = 0},
		{Value = 200004, Base = 0, Gain = 0},
	},
	Drop = {
	},
	Tags = {
		560202,
		560103,
		560204,
		560205,
		560206,
		560207,
		560209,
		560210,
		560211,
		561202,
		561305,
		561323,
		563102,
		563203,
	},
}
EnemyConfig[EnemyID.Id012] =
{
	Id = 12,
	Name = "精英祭祀石",
	Rarity = 2,
	Element = 210004,
	Style = "Dps",
	AttackType = "Melee",
	Area = 
	{
		130005,
	},
	Desc = "古代神庙祭祀用的大石头，能够驱邪，家里如果闹鬼，可以搬一块回家。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	IconName = "RPG_dashitou",
	PrefabBundle = "character_enemy",
	PrefabName = "RPG_dashitou",
	PrefabScale = 50,
	HPBarHeight = 102,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 1322, Gain = 265},
		{Value = 200002, Base = 32, Gain = 7},
		{Value = 200003, Base = 10, Gain = 0},
		{Value = 200004, Base = 0, Gain = 0},
	},
	Drop = {
	},
	SkillList = {
		Desc = "受光元素敌人伤害 -50%",
		Skill = {
			{
				Id = 105036,
				Value = -50,
			},
		},
	},
	Tags = {
		560202,
		560103,
		560204,
		560205,
		560206,
		560207,
		560209,
		560210,
		560211,
		561205,
		561321,
		561325,
		563102,
		563202,
	},
}
EnemyConfig[EnemyID.Id013] =
{
	Id = 13,
	Name = "石怪老大",
	Rarity = 2,
	Element = 210004,
	Style = "Dps",
	AttackType = "Melee",
	Area = 
	{
		130005,
	},
	Desc = "出没在山地的石怪，喜欢躲在暗处听冒险者讲传奇故事，被发现的话就会害羞得装成石头。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	IconName = "RPG_xiaoshiguai",
	PrefabBundle = "character_enemy",
	PrefabName = "RPG_xiaoshiguai",
	PrefabScale = 50,
	HPBarHeight = 76,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 1244, Gain = 249},
		{Value = 200002, Base = 32, Gain = 7},
		{Value = 200003, Base = 10, Gain = 0},
		{Value = 200004, Base = 35, Gain = 0},
	},
	Drop = {
	},
	SkillList = {
		Desc = "有15%概率额外攻击1次",
		Skill = {
			{
				Id = 105023,
				Value = 15,
			},
		},
	},
	Tags = {
		560202,
		560103,
		560204,
		560205,
		560206,
		560207,
		560209,
		560210,
		560211,
		561205,
		561321,
		561325,
		563102,
		563203,
		564558,
	},
}
EnemyConfig[EnemyID.Id014] =
{
	Id = 14,
	Name = "平原守护者",
	Rarity = 3,
	Element = 210004,
	Style = "Dps",
	AttackType = "Melee",
	Area = 
	{
		130005,
	},
	Desc = "平原的守护者，对其他生物很不友好。其实是个慢性子，说话结巴，最大的梦想是有人能听完它的自我介绍。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	IconName = "RPG_Stoneman",
	PrefabBundle = "character_enemy",
	PrefabName = "RPG_Stoneman",
	PrefabScale = 50,
	HPBarHeight = 114,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 1393, Gain = 279},
		{Value = 200002, Base = 31, Gain = 7},
		{Value = 200003, Base = 10, Gain = 0},
		{Value = 200004, Base = 0, Gain = 0},
	},
	Drop = {
	},
	SkillList = {
		Desc = "每3回合回血 10%，最多5次",
		Skill = {
			{
				Id = 105009,
				Value = 10,
			},
		},
	},
	Tags = {
		560202,
		560103,
		560204,
		560205,
		560206,
		560207,
		560209,
		560210,
		560211,
		561205,
		561321,
		561325,
		563102,
		563202,
		564560,
	},
}
EnemyConfig[EnemyID.Id015] =
{
	Id = 15,
	Name = "小土包代表",
	Rarity = 2,
	Element = 210003,
	Style = "Dps",
	AttackType = "Melee",
	Area = 
	{
		130006,
	},
	Desc = "最恨人说烂泥扶不上墙，一旦听到就会发飙。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	IconName = "RPG_ruannidui",
	PrefabBundle = "character_enemy",
	PrefabName = "RPG_ruannidui",
	PrefabScale = 50,
	HPBarHeight = 76,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 875, Gain = 175},
		{Value = 200002, Base = 28, Gain = 6},
		{Value = 200003, Base = 10, Gain = 0},
		{Value = 200004, Base = 0, Gain = 0},
	},
	Drop = {
	},
	Tags = {
		560202,
		560103,
		560204,
		560205,
		560206,
		560207,
		560209,
		560210,
		560211,
		561204,
		561321,
		561326,
		563103,
		563203,
	},
}
EnemyConfig[EnemyID.Id016] =
{
	Id = 16,
	Name = "地缚灵头目",
	Rarity = 2,
	Element = 210005,
	Style = "Dps",
	AttackType = "Melee",
	Area = 
	{
		130006,
	},
	Desc = "出没在遗迹附近的精灵，以死去之人残存的气息为食，如果惹到了它，它会偷偷跟在你后面，找机会绊你一跤。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	IconName = "RPG_chouniguai",
	PrefabBundle = "character_enemy",
	PrefabName = "RPG_chouniguai",
	PrefabScale = 50,
	HPBarHeight = 76,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 817, Gain = 164},
		{Value = 200002, Base = 28, Gain = 6},
		{Value = 200003, Base = 10, Gain = 0},
		{Value = 200004, Base = 0, Gain = 0},
	},
	Drop = {
	},
	SkillList = {
		Desc = "33%概率闪避攻击",
		Skill = {
			{
				Id = 105026,
				Value = 33,
			},
		},
	},
	Tags = {
		560202,
		560103,
		560204,
		560205,
		560206,
		560207,
		560209,
		560210,
		560211,
		561206,
		561305,
		561326,
		563103,
		563203,
		564557,
	},
}
EnemyConfig[EnemyID.Id017] =
{
	Id = 17,
	Name = "骨头兵",
	Rarity = 2,
	Element = 210005,
	Style = "Dps",
	AttackType = "Melee",
	Area = 
	{
		130006,
	},
	Desc = "魔王有限公司临时雇员，即使被拆散了也能很快拼回去，是地城副本中很重要的成员。\n不过偶尔会发生重新拼装时，多出一些骨头的问题。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	IconName = "Rpg_30_kulou",
	PrefabBundle = "character_rpg",
	PrefabName = "Rpg_30_kulou",
	SkinName = "1",
	PrefabScale = 50,
	HPBarHeight = 105,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 875, Gain = 175},
		{Value = 200002, Base = 28, Gain = 6},
		{Value = 200003, Base = 10, Gain = 0},
		{Value = 200004, Base = 0, Gain = 0},
	},
	Drop = {
	},
	SkillList = {
		Desc = "受水元素敌人伤害 -33%\n受火元素敌人伤害 -33%\n受风元素敌人伤害 -33%",
		Skill = {
			{
				Id = 105033,
				Value = -33,
			},
			{
				Id = 105034,
				Value = -33,
			},
			{
				Id = 105035,
				Value = -33,
			},
		},
	},
}
EnemyConfig[EnemyID.Id018] =
{
	Id = 18,
	Name = "史莱姆代表",
	Rarity = 1,
	Element = 210005,
	Style = "Dps",
	AttackType = "Melee",
	Area = 
	{
		130007,
	},
	Desc = "体内带有大量紫色素的小精灵，喜欢捡冒险者丢掉的东西，被它碰到的东西就会被染成紫色。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	IconName = "RPG_Slime_purple",
	PrefabBundle = "character_enemy",
	PrefabName = "RPG_Slime_purple",
	PrefabScale = 50,
	HPBarHeight = 69,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 875, Gain = 175},
		{Value = 200002, Base = 28, Gain = 6},
		{Value = 200003, Base = 10, Gain = 0},
		{Value = 200004, Base = 0, Gain = 0},
	},
	Drop = {
	},
	Tags = {
		560202,
		560103,
		560204,
		560205,
		560206,
		560207,
		560209,
		560210,
		560211,
		561206,
		561305,
		561323,
		563102,
		563203,
	},
}
EnemyConfig[EnemyID.Id019] =
{
	Id = 19,
	Name = "超深沼泽地",
	Rarity = 2,
	Element = 210001,
	Style = "Dps",
	AttackType = "Melee",
	Area = 
	{
		130007,
	},
	Desc = "躲在沼泽地区不起眼的怪物，只顾看攻略没看路的冒险者踩上去后会被快速吞没。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	IconName = "RPG_zhaozedi",
	PrefabBundle = "character_enemy",
	PrefabName = "RPG_zhaozedi",
	PrefabScale = 50,
	HPBarHeight = 54,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 1244, Gain = 249},
		{Value = 200002, Base = 29, Gain = 6},
		{Value = 200003, Base = 10, Gain = 0},
		{Value = 200004, Base = 35, Gain = 0},
	},
	Drop = {
	},
	SkillList = {
		Desc = "受暗元素敌人伤害 -33%",
		Skill = {
			{
				Id = 105037,
				Value = -33,
			},
		},
	},
	Tags = {
		560202,
		560103,
		560204,
		560205,
		560206,
		560207,
		560209,
		560210,
		560211,
		561202,
		561321,
		561326,
		563103,
		563203,
	},
}
EnemyConfig[EnemyID.Id020] =
{
	Id = 20,
	Name = "泥怪头领",
	Rarity = 2,
	Element = 210001,
	Style = "Dps",
	AttackType = "Melee",
	Area = 
	{
		130007,
	},
	Desc = "拥有很强粘性的魔物，即使是凶猛的野兽，如果被它困住，最后也难逃厄运。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	IconName = "RPG_niannianguai",
	PrefabBundle = "character_enemy",
	PrefabName = "RPG_niannianguai",
	PrefabScale = 50,
	HPBarHeight = 81,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 1244, Gain = 249},
		{Value = 200002, Base = 34, Gain = 7},
		{Value = 200003, Base = 10, Gain = 0},
		{Value = 200004, Base = 0, Gain = 0},
	},
	Drop = {
	},
	SkillList = {
		Desc = "受暗元素敌人伤害 -33%",
		Skill = {
			{
				Id = 105037,
				Value = -33,
			},
		},
	},
	Tags = {
		560202,
		560103,
		560204,
		560205,
		560206,
		560207,
		560209,
		560210,
		560211,
		561202,
		561321,
		561326,
		563103,
		563203,
	},
}
EnemyConfig[EnemyID.Id021] =
{
	Id = 21,
	Name = "树精头领",
	Rarity = 3,
	Element = 210003,
	Style = "Dps",
	AttackType = "Melee",
	Area = 
	{
		130007,
	},
	Desc = "吸取树木精华为生的精灵，说不清是植物还是精灵，负责净化沼泽地区的空气质量。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	IconName = "RPG_xiaoshuyang",
	PrefabBundle = "character_enemy",
	PrefabName = "RPG_xiaoshuyang",
	PrefabScale = 60,
	HPBarHeight = 85,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 1225, Gain = 245},
		{Value = 200002, Base = 33, Gain = 7},
		{Value = 200003, Base = 10, Gain = 0},
		{Value = 200004, Base = 0, Gain = 0},
	},
	Drop = {
	},
	SkillList = {
		Desc = "每回合有50%概率自身回血 8%，最多5次\n每回合攻击 +5%，最多5次",
		Skill = {
			{
				Id = 105017,
				Value = 8,
			},
			{
				Id = 105006,
				Value = 5,
			},
		},
	},
	Tags = {
		560202,
		560103,
		560204,
		560205,
		560206,
		560207,
		560209,
		560210,
		560211,
		561204,
		561320,
		561305,
		563102,
		563203,
		564560,
		564561,
	},
}
EnemyConfig[EnemyID.Id022] =
{
	Id = 22,
	Name = "指路NPC",
	Rarity = 2,
	Element = 210001,
	Style = "Dps",
	AttackType = "Melee",
	Area = 
	{
		130007,
	},
	Desc = "热心的冒险星原住民，和宠物猪一起居住在沼泽深处。专门给来自世界各地的冒险者指路。说话时会用最近学会的口音，以至于大部分人都听不懂他的话。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	IconName = "Rpg_10_buluolaoda",
	PrefabBundle = "character_rpg",
	PrefabName = "Rpg_10_buluolaoda",
	SkinName = "1",
	PrefabScale = 50,
	HPBarHeight = 115,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 1300, Gain = 260},
		{Value = 200002, Base = 36, Gain = 8},
		{Value = 200003, Base = 0, Gain = 0},
		{Value = 200004, Base = 0, Gain = 0},
	},
	Drop = {
	},
	SkillList = {
		Desc = "每3回合回血 10%，最多5次",
		Skill = {
			{
				Id = 105009,
				Value = 10,
			},
		},
	},
	Tags = {
		564560,
	},
}
EnemyConfig[EnemyID.Id023] =
{
	Id = 23,
	Name = "刺毛怪小队长",
	Rarity = 2,
	Element = 210005,
	Style = "Dps",
	AttackType = "Melee",
	Area = 
	{
		130008,
	},
	Desc = "在任何地区都能悠闲漫步的魔物。遇到危险时，就会竖起身上的钢针进行抵御。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	IconName = "RPG_SeaUrchin",
	PrefabBundle = "character_enemy",
	PrefabName = "RPG_SeaUrchin",
	PrefabScale = 50,
	HPBarHeight = 76,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 793, Gain = 159},
		{Value = 200002, Base = 22, Gain = 5},
		{Value = 200003, Base = 10, Gain = 0},
		{Value = 200004, Base = 0, Gain = 0},
	},
	Drop = {
	},
	SkillList = {
		Desc = "每回合对前2个队员造成100%攻击伤害",
		Skill = {
			{
				Id = 105040,
				Value = 100,
			},
		},
	},
	Tags = {
		560202,
		560103,
		560204,
		560205,
		560206,
		560207,
		560209,
		560210,
		560211,
		561206,
		561303,
		561327,
		563102,
		563203,
	},
}
EnemyConfig[EnemyID.Id024] =
{
	Id = 24,
	Name = "刺毛怪大王",
	Rarity = 4,
	Element = 210005,
	Style = "Dps",
	AttackType = "Melee",
	Area = 
	{
		130008,
	},
	Desc = "年龄超过两百岁的超级刺毛怪，身上的钢针带有令人麻痹的毒液，是令人无法靠近的存在。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	IconName = "RPG_BigSeaUrchin",
	PrefabBundle = "character_enemy",
	PrefabName = "RPG_BigSeaUrchin",
	PrefabScale = 50,
	HPBarHeight = 102,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 793, Gain = 159},
		{Value = 200002, Base = 20, Gain = 4},
		{Value = 200003, Base = 10, Gain = 0},
		{Value = 200004, Base = 0, Gain = 0},
	},
	Drop = {
	},
	SkillList = {
		Desc = "每回合对前3个队员造成100%攻击伤害",
		Skill = {
			{
				Id = 105041,
				Value = 100,
			},
		},
	},
	Tags = {
		560202,
		560103,
		560204,
		560205,
		560206,
		560207,
		560209,
		560210,
		560211,
		561206,
		561303,
		561327,
		563102,
		563203,
	},
}
EnemyConfig[EnemyID.Id025] =
{
	Id = 25,
	Name = "史莱姆代表",
	Rarity = 1,
	Element = 210002,
	Style = "Dps",
	AttackType = "Melee",
	Area = 
	{
		130009,
	},
	Desc = "体内带有大量红色素的小精灵，喜欢捡冒险者丢掉的东西，被它碰到的东西就会被染成红色，但如果碰到蓝色史莱姆就会染成紫色。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	IconName = "RPG_Slime_red",
	PrefabBundle = "character_enemy",
	PrefabName = "RPG_Slime_red",
	PrefabScale = 50,
	HPBarHeight = 69,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 992, Gain = 199},
		{Value = 200002, Base = 26, Gain = 6},
		{Value = 200003, Base = 10, Gain = 0},
		{Value = 200004, Base = 0, Gain = 0},
	},
	Drop = {
	},
	Tags = {
		560202,
		560103,
		560204,
		560205,
		560206,
		560207,
		560209,
		560210,
		560211,
		561203,
		561305,
		561323,
		563102,
		563203,
	},
}
EnemyConfig[EnemyID.Id026] =
{
	Id = 26,
	Name = "岩浆喷泉",
	Rarity = 2,
	Element = 210002,
	Style = "Dps",
	AttackType = "Melee",
	Area = 
	{
		130009,
	},
	Desc = "无论快乐或悲伤，都会通过喷发岩浆来宣泄情绪。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	IconName = "RPG_FireFountain",
	PrefabBundle = "character_enemy",
	PrefabName = "RPG_FireFountain",
	PrefabScale = 50,
	HPBarHeight = 54,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 992, Gain = 199},
		{Value = 200002, Base = 26, Gain = 6},
		{Value = 200003, Base = 10, Gain = 0},
		{Value = 200004, Base = 0, Gain = 0},
	},
	Drop = {
	},
	Tags = {
		560202,
		560103,
		560204,
		560205,
		560206,
		560207,
		560209,
		560210,
		560211,
		561203,
		561321,
		561351,
		561326,
		563103,
		563203,
	},
}
EnemyConfig[EnemyID.Id027] =
{
	Id = 27,
	Name = "火山王",
	Rarity = 2,
	Element = 210004,
	Style = "Dps",
	AttackType = "Melee",
	Area = 
	{
		130009,
	},
	Desc = "只想做一个安静美男子的景观类魔物，火山口的熔岩刘海经常引来300%的回头率。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	IconName = "RPG_Volcano",
	PrefabBundle = "character_enemy",
	PrefabName = "RPG_Volcano",
	PrefabScale = 50,
	HPBarHeight = 81,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 954, Gain = 191},
		{Value = 200002, Base = 18, Gain = 4},
		{Value = 200003, Base = 10, Gain = 0},
		{Value = 200004, Base = 0, Gain = 0},
	},
	Drop = {
	},
	SkillList = {
		Desc = "每3回合对所有队员造成75%攻击伤害",
		Skill = {
			{
				Id = 105063,
				Value = 75,
			},
		},
	},
	Tags = {
		560202,
		560103,
		560204,
		560205,
		560206,
		560207,
		560209,
		560210,
		560211,
		561205,
		561321,
		561351,
		563103,
		563203,
	},
}
EnemyConfig[EnemyID.Id028] =
{
	Id = 28,
	Name = "铁匠",
	Rarity = 2,
	Element = 210002,
	Style = "Dps",
	AttackType = "Melee",
	Area = 
	{
		130009,
	},
	Desc = "冒险星人气NPC，提供装备买卖、修理、强化等服务，是勇者不可或缺的好帮手。\n“哎呀，手一滑装备爆炸了，阁下运气不太好噢~”",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	IconName = "Rpg_31_tiejiang",
	PrefabBundle = "character_rpg",
	PrefabName = "Rpg_31_tiejiang",
	SkinName = "1",
	PrefabScale = 50,
	HPBarHeight = 115,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 992, Gain = 199},
		{Value = 200002, Base = 26, Gain = 6},
		{Value = 200003, Base = 10, Gain = 0},
		{Value = 200004, Base = 0, Gain = 0},
	},
	Drop = {
	},
	SkillList = {
		Desc = "每回合攻击 +10%，最多5次\n每回合忍耐 +10，最多5次",
		Skill = {
			{
				Id = 105006,
				Value = 10,
			},
			{
				Id = 105007,
				Value = 10,
			},
		},
	},
	Tags = {
		564561,
	},
}
EnemyConfig[EnemyID.Id029] =
{
	Id = 29,
	Name = "小火球代表",
	Rarity = 2,
	Element = 210002,
	Style = "Dps",
	AttackType = "Melee",
	Area = 
	{
		130010,
	},
	Desc = "数据证明，百分之九十九的冒险家无法分清不同的小火球。\n它从岩浆里跳了起来，它掉了下去。\n它的兄弟从岩浆里跳了起来。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	IconName = "RPG_Fireball",
	PrefabBundle = "character_enemy",
	PrefabName = "RPG_Fireball",
	PrefabScale = 50,
	HPBarHeight = 76,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 992, Gain = 199},
		{Value = 200002, Base = 26, Gain = 6},
		{Value = 200003, Base = 10, Gain = 0},
		{Value = 200004, Base = 0, Gain = 0},
	},
	Drop = {
	},
	Tags = {
		560202,
		560103,
		560204,
		560205,
		560206,
		560207,
		560209,
		560210,
		560211,
		561203,
		561305,
		561351,
		563103,
		563205,
	},
}
EnemyConfig[EnemyID.Id030] =
{
	Id = 30,
	Name = "熔岩猪头领",
	Rarity = 2,
	Element = 210002,
	Style = "Dps",
	AttackType = "Melee",
	Area = 
	{
		130010,
	},
	Desc = "被魔王收养的宠物猪，在高热的情况下会发出肉香，用来诱惑来到火山地区的冒险家分泌口水，使其加速脱水而失去战斗能力。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	IconName = "RPG_LavaPig",
	PrefabBundle = "character_enemy",
	PrefabName = "RPG_LavaPig",
	PrefabScale = 50,
	HPBarHeight = 76,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 899, Gain = 180},
		{Value = 200002, Base = 20, Gain = 4},
		{Value = 200003, Base = 10, Gain = 0},
		{Value = 200004, Base = 0, Gain = 0},
	},
	Drop = {
	},
	SkillList = {
		Desc = "每3回合对前3个队员造成150%攻击伤害\n每回合回血 5%，最多5次",
		Skill = {
			{
				Id = 105057,
				Value = 150,
			},
			{
				Id = 105005,
				Value = 5,
			},
		},
	},
	Tags = {
		560202,
		560103,
		560204,
		560205,
		560206,
		560207,
		560209,
		560210,
		560211,
		561203,
		561303,
		561351,
		561329,
		563102,
		563204,
		564560,
	},
}
EnemyConfig[EnemyID.Id031] =
{
	Id = 31,
	Name = "火山巨蟹头领",
	Rarity = 3,
	Element = 210004,
	Style = "Dps",
	AttackType = "Melee",
	Area = 
	{
		130010,
	},
	Desc = "挥舞着两只强力巨钳的高级魔物，不过更出名的是其鲜美的肉质，是美食家们梦寐以求的高级海鲜。常与熔岩猪一起出马，加速冒险家的脱水危机。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	IconName = "RPG_Firecrab",
	PrefabBundle = "character_enemy",
	PrefabName = "RPG_Firecrab",
	PrefabScale = 50,
	HPBarHeight = 76,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 1180, Gain = 236},
		{Value = 200002, Base = 28, Gain = 6},
		{Value = 200003, Base = 10, Gain = 0},
		{Value = 200004, Base = 0, Gain = 0},
	},
	Drop = {
	},
	SkillList = {
		Desc = "每3回合对前2个队员造成200%攻击伤害",
		Skill = {
			{
				Id = 105056,
				Value = 200,
			},
		},
	},
	Tags = {
		560202,
		560103,
		560204,
		560205,
		560206,
		560207,
		560209,
		560210,
		560211,
		561205,
		561303,
		561351,
		561330,
		563102,
		563203,
	},
}
EnemyConfig[EnemyID.Id032] =
{
	Id = 32,
	Name = "小魔王",
	Rarity = 3,
	Element = 210005,
	Style = "Dps",
	AttackType = "Melee",
	Area = 
	{
		130010,
	},
	Desc = "魔王公司负责人，坐镇魔王城堡。对于管理员工和设计副本很有两把刷子。最喜欢在顶楼办公室的超大落地窗前，思考下个月怎么再干掉一百个勇者。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	IconName = "Rpg_12_xiaomowang",
	PrefabBundle = "character_rpg",
	PrefabName = "Rpg_12_xiaomowang",
	SkinName = "1",
	PrefabScale = 50,
	HPBarHeight = 105,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 1245, Gain = 249},
		{Value = 200002, Base = 14, Gain = 3},
		{Value = 200003, Base = 10, Gain = 0},
		{Value = 200004, Base = 160, Gain = 0},
	},
	Drop = {
	},
	SkillList = {
		Desc = "每3回合对所有队员造成100%攻击伤害\n暴击伤害 -50%",
		Skill = {
			{
				Id = 105063,
				Value = 100,
			},
			{
				Id = 105038,
				Value = -50,
			},
		},
	},
}
EnemyConfig[EnemyID.Id033] =
{
	Id = 33,
	Name = "火精灵王",
	Rarity = 2,
	Element = 210002,
	Style = "Dps",
	AttackType = "Melee",
	Area = 
	{
		130011,
	},
	Desc = "以矿石为食的精灵，体内有大量燃烧结晶。吃矿石的时候喜欢放凉再吃，它怕烫。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	IconName = "RPG_Salamander",
	PrefabBundle = "character_enemy",
	PrefabName = "RPG_Salamander",
	PrefabScale = 50,
	HPBarHeight = 81,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 1342, Gain = 269},
		{Value = 200002, Base = 21, Gain = 5},
		{Value = 200003, Base = 10, Gain = 0},
		{Value = 200004, Base = 0, Gain = 0},
	},
	Drop = {
	},
	SkillList = {
		Desc = "5回合后，攻击 +100%",
		Skill = {
			{
				Id = 105014,
				Value = 100,
			},
		},
	},
	Tags = {
		560202,
		560103,
		560204,
		560205,
		560206,
		560207,
		560209,
		560210,
		560211,
		561203,
		561305,
		561351,
		563103,
		563205,
		564561,
	},
}
EnemyConfig[EnemyID.Id034] =
{
	Id = 34,
	Name = "火焰巨人王",
	Rarity = 4,
	Element = 210002,
	Style = "Dps",
	AttackType = "Melee",
	Area = 
	{
		130011,
	},
	Desc = "火山的可怕魔物，喷吐的烈焰可以融化矿石，是魔王城堡当之无愧的强者。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	IconName = "RPG_GiantFire",
	PrefabBundle = "character_enemy",
	PrefabName = "RPG_GiantFire",
	PrefabScale = 50,
	HPBarHeight = 114,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 1409, Gain = 282},
		{Value = 200002, Base = 15, Gain = 3},
		{Value = 200003, Base = 10, Gain = 0},
		{Value = 200004, Base = 100, Gain = 0},
	},
	Drop = {
	},
	SkillList = {
		Desc = "每回合对前3个队员造成100%攻击伤害\n5回合后，攻击 +50%",
		Skill = {
			{
				Id = 105041,
				Value = 100,
			},
			{
				Id = 105014,
				Value = 50,
			},
		},
	},
	Tags = {
		560202,
		560103,
		560204,
		560205,
		560206,
		560207,
		560209,
		560210,
		560211,
		561203,
		561305,
		561351,
		563103,
		563203,
		564561,
	},
}
EnemyConfig[EnemyID.Id035] =
{
	Id = 35,
	Name = "草莓推销员",
	Rarity = 1,
	Element = 210003,
	Style = "Dps",
	AttackType = "Melee",
	Area = 
	{
		130051,
	},
	Desc = "味道酸甜清爽的草莓，经常作为甜点的装饰品出现。因为大部分冒险家不想弄一手黏黏的汁水，所以某些程度上也是个棘手的敌人。",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "FAT",
	IconName = "FAT_Strawberry",
	PrefabBundle = "character_enemy",
	PrefabName = "FAT_Strawberry",
	PrefabScale = 50,
	HPBarHeight = 69,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 1418, Gain = 284},
		{Value = 200002, Base = 26, Gain = 6},
		{Value = 200003, Base = 25, Gain = 1},
		{Value = 200004, Base = 25, Gain = 1},
	},
	Drop = {
	},
	Tags = {
		560202,
		560203,
		560104,
		560205,
		560206,
		560207,
		560209,
		560210,
		560211,
		561204,
		561320,
		561331,
		563103,
		563203,
	},
}
EnemyConfig[EnemyID.Id036] =
{
	Id = 36,
	Name = "鱼头老板",
	Rarity = 2,
	Element = 210002,
	Style = "Dps",
	AttackType = "Melee",
	Area = 
	{
		130052,
	},
	Desc = "非常可口的甜点，整份很难吃完，所以头部会切下来单卖。但总有客人抱怨头部的馅料太少了。",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "FAT",
	IconName = "FAT_FishHead",
	PrefabBundle = "character_enemy",
	PrefabName = "FAT_FishHead",
	PrefabScale = 50,
	HPBarHeight = 82,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 1608, Gain = 322},
		{Value = 200002, Base = 26, Gain = 6},
		{Value = 200003, Base = 25, Gain = 1},
		{Value = 200004, Base = 25, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "5回合后，攻击 +100%",
		Skill = {
			{
				Id = 105014,
				Value = 100,
			},
		},
	},
	Tags = {
		560202,
		560203,
		560104,
		560205,
		560206,
		560207,
		560209,
		560210,
		560211,
		561203,
		561306,
		561332,
		563104,
		563203,
		564561,
	},
}
EnemyConfig[EnemyID.Id037] =
{
	Id = 37,
	Name = "鱼尾老板",
	Rarity = 2,
	Element = 210002,
	Style = "Dps",
	AttackType = "Melee",
	Area = 
	{
		130052,
	},
	Desc = "非常可口的甜点，整份很难吃完，所以尾巴会切下来单卖。但总有客人抱怨尾部的馅料太少了。",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "FAT",
	IconName = "FAT_FishTail",
	PrefabBundle = "character_enemy",
	PrefabName = "FAT_FishTail",
	PrefabScale = 50,
	HPBarHeight = 82,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 1344, Gain = 269},
		{Value = 200002, Base = 26, Gain = 6},
		{Value = 200003, Base = 25, Gain = 1},
		{Value = 200004, Base = 25, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "5回合后，回血 50%",
		Skill = {
			{
				Id = 105013,
				Value = 50,
			},
		},
	},
	Tags = {
		560202,
		560203,
		560104,
		560205,
		560206,
		560207,
		560209,
		560210,
		560211,
		561203,
		561306,
		561332,
		563104,
		563203,
		564560,
	},
}
EnemyConfig[EnemyID.Id038] =
{
	Id = 38,
	Name = "超浓克林姆",
	Rarity = 2,
	Element = 210001,
	Style = "Dps",
	AttackType = "Melee",
	Area = 
	{
		130053,
	},
	Desc = "香草味的冰淇淋，加入了牛奶和香草粉制作而成，即使化开来味道也依然很好。性格热情开朗，一直渴望着一份火热的爱情。",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "FAT",
	IconName = "FAT_IceCream",
	PrefabBundle = "character_enemy",
	PrefabName = "FAT_IceCream",
	PrefabScale = 50,
	HPBarHeight = 89,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 1349, Gain = 270},
		{Value = 200002, Base = 25, Gain = 5},
		{Value = 200003, Base = 25, Gain = 1},
		{Value = 200004, Base = 25, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "受水元素敌人伤害 -50%",
		Skill = {
			{
				Id = 105033,
				Value = -50,
			},
		},
	},
	Tags = {
		560202,
		560203,
		560104,
		560205,
		560206,
		560207,
		560209,
		560210,
		560211,
		561202,
		561306,
		561334,
		563103,
		563203,
	},
}
EnemyConfig[EnemyID.Id039] =
{
	Id = 39,
	Name = "超浓茶克林姆",
	Rarity = 2,
	Element = 210001,
	Style = "Dps",
	AttackType = "Melee",
	Area = 
	{
		130053,
	},
	Desc = "抹茶味的冰淇淋，加入了牛奶和抹茶粉制作而成，即使化开来味道也依然很好。性格温文尔雅，最喜欢的是原谅别人。",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "FAT",
	IconName = "FAT_GreenTeaIceCream",
	PrefabBundle = "character_enemy",
	PrefabName = "FAT_GreenTeaIceCream",
	PrefabScale = 50,
	HPBarHeight = 89,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 1326, Gain = 266},
		{Value = 200002, Base = 25, Gain = 5},
		{Value = 200003, Base = 25, Gain = 1},
		{Value = 200004, Base = 25, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "受风元素敌人伤害 -50%",
		Skill = {
			{
				Id = 105035,
				Value = -50,
			},
		},
	},
	Tags = {
		560202,
		560203,
		560104,
		560205,
		560206,
		560207,
		560209,
		560210,
		560211,
		561202,
		561306,
		561334,
		563103,
		563203,
	},
}
EnemyConfig[EnemyID.Id040] =
{
	Id = 40,
	Name = "超浓巧克林姆",
	Rarity = 2,
	Element = 210001,
	Style = "Dps",
	AttackType = "Melee",
	Area = 
	{
		130053,
	},
	Desc = "巧克力味的冰淇淋，加入了牛奶和可可粉制作而成，即使化开来味道也依然很好。性格冷酷孤僻，最讨厌傻白甜。",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "FAT",
	IconName = "FAT_ChocolateIceCream",
	PrefabBundle = "character_enemy",
	PrefabName = "FAT_ChocolateIceCream",
	PrefabScale = 50,
	HPBarHeight = 89,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 1449, Gain = 290},
		{Value = 200002, Base = 28, Gain = 6},
		{Value = 200003, Base = 25, Gain = 1},
		{Value = 200004, Base = 25, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "受暗元素敌人伤害 -50%",
		Skill = {
			{
				Id = 105037,
				Value = -50,
			},
		},
	},
	Tags = {
		560202,
		560203,
		560104,
		560205,
		560206,
		560207,
		560209,
		560210,
		560211,
		561202,
		561306,
		561334,
		563103,
		563203,
	},
}
EnemyConfig[EnemyID.Id041] =
{
	Id = 41,
	Name = "奶茶王子",
	Rarity = 3,
	Element = 210003,
	Style = "Dps",
	AttackType = "Melee",
	Area = 
	{
		130053,
	},
	Desc = "超人气王子，王子影业董事长。自导自演了超过200部电影作品，IMBD最高评分4.6分（百分制），不过依然对演艺事业充满热情。",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	IconName = "Fat_10_naicha",
	PrefabBundle = "character_fat",
	PrefabName = "Fat_10_naicha",
	SkinName = "1",
	PrefabScale = 50,
	HPBarHeight = 106,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 1385, Gain = 277},
		{Value = 200002, Base = 27, Gain = 6},
		{Value = 200003, Base = 25, Gain = 1},
		{Value = 200004, Base = 25, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "受火元素敌人伤害 -50%\n5回合后，回血 50%",
		Skill = {
			{
				Id = 105034,
				Value = -50,
			},
			{
				Id = 105013,
				Value = 50,
			},
		},
	},
	Tags = {
		564560,
	},
}
EnemyConfig[EnemyID.Id042] =
{
	Id = 42,
	Name = "水果糖新秀",
	Rarity = 2,
	Element = 210003,
	Style = "Dps",
	AttackType = "Melee",
	Area = 
	{
		130054,
	},
	Desc = "用可食薄膜包裹的硬糖，含在嘴里可以长时间感受到酸酸甜甜的果味。对喜欢咬碎吃糖的人总是很鄙夷。",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "FAT",
	IconName = "FAT_LaffyTaffy",
	PrefabBundle = "character_enemy",
	PrefabName = "FAT_LaffyTaffy",
	PrefabScale = 50,
	HPBarHeight = 54,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 1332, Gain = 267},
		{Value = 200002, Base = 25, Gain = 5},
		{Value = 200003, Base = 25, Gain = 1},
		{Value = 200004, Base = 25, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "有15%概率额外攻击1次\n20%概率闪避攻击",
		Skill = {
			{
				Id = 105023,
				Value = 15,
			},
			{
				Id = 105026,
				Value = 20,
			},
		},
	},
	Tags = {
		560202,
		560203,
		560104,
		560205,
		560206,
		560207,
		560209,
		560210,
		560211,
		561204,
		561306,
		561333,
		563103,
		563203,
		564557,
		564558,
	},
}
EnemyConfig[EnemyID.Id043] =
{
	Id = 43,
	Name = "奶糖新秀",
	Rarity = 3,
	Element = 210003,
	Style = "Dps",
	AttackType = "Melee",
	Area = 
	{
		130054,
	},
	Desc = "用可食薄膜包裹的奶糖，有非常浓郁的奶香，不过含糖量非常高。自称含奶量高达百分之八十，其实是骗人的。",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "FAT",
	IconName = "FAT_Toffee",
	PrefabBundle = "character_enemy",
	PrefabName = "FAT_Toffee",
	PrefabScale = 50,
	HPBarHeight = 54,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 1269, Gain = 254},
		{Value = 200002, Base = 23, Gain = 5},
		{Value = 200003, Base = 25, Gain = 1},
		{Value = 200004, Base = 25, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "有50%概率额外攻击1次\n33%概率闪避攻击",
		Skill = {
			{
				Id = 105023,
				Value = 50,
			},
			{
				Id = 105026,
				Value = 33,
			},
		},
	},
	Tags = {
		560202,
		560203,
		560104,
		560205,
		560206,
		560207,
		560209,
		560210,
		560211,
		561204,
		561306,
		561333,
		563103,
		563203,
		564557,
		564558,
	},
}
EnemyConfig[EnemyID.Id044] =
{
	Id = 44,
	Name = "小红",
	Rarity = 1,
	Element = 210002,
	Style = "Dps",
	AttackType = "Melee",
	Area = 
	{
		130054,
	},
	Desc = "苹果味糖豆，最自豪的事是曾在公主庆典上，扮演超大冰淇淋雕像上的苹果。",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	IconName = "Fat_12_xiaohong",
	PrefabBundle = "character_fat",
	PrefabName = "Fat_12_xiaohong",
	SkinName = "1",
	PrefabScale = 50,
	HPBarHeight = 106,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 1349, Gain = 270},
		{Value = 200002, Base = 25, Gain = 5},
		{Value = 200003, Base = 25, Gain = 1},
		{Value = 200004, Base = 25, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "每回合攻击 +10%，最多5次",
		Skill = {
			{
				Id = 105006,
				Value = 10,
			},
		},
	},
	Tags = {
		564561,
	},
}
EnemyConfig[EnemyID.Id045] =
{
	Id = 45,
	Name = "冠军芒果滋",
	Rarity = 2,
	Element = 210005,
	Style = "Dps",
	AttackType = "Melee",
	Area = 
	{
		130055,
	},
	Desc = "浇上了调味芒果浓浆的甜甜圈，撒有饼干脆片，咬下去的第一口就会在嘴里绽放出恶魔般的甜度。",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "FAT",
	IconName = "FAT_MangoDoughnut",
	PrefabBundle = "character_enemy",
	PrefabName = "FAT_MangoDoughnut",
	PrefabScale = 50,
	HPBarHeight = 88,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 1131, Gain = 227},
		{Value = 200002, Base = 20, Gain = 4},
		{Value = 200003, Base = 25, Gain = 1},
		{Value = 200004, Base = 25, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "每回合对前2个队员造成100%攻击伤害",
		Skill = {
			{
				Id = 105040,
				Value = 100,
			},
		},
	},
	Tags = {
		560202,
		560203,
		560104,
		560205,
		560206,
		560207,
		560209,
		560210,
		560211,
		561206,
		561306,
		561332,
		563104,
		563205,
	},
}
EnemyConfig[EnemyID.Id046] =
{
	Id = 46,
	Name = "冠军多拿滋",
	Rarity = 2,
	Element = 210005,
	Style = "Dps",
	AttackType = "Melee",
	Area = 
	{
		130055,
	},
	Desc = "非常甜腻的甜甜圈，撒有饼干脆片。瞧不起芒果滋，认为借用果味力量的甜腻是异端，糖浆才是最正宗的力量。",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "FAT",
	IconName = "FAT_Doughnut",
	PrefabBundle = "character_enemy",
	PrefabName = "FAT_Doughnut",
	PrefabScale = 50,
	HPBarHeight = 88,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 1196, Gain = 240},
		{Value = 200002, Base = 21, Gain = 5},
		{Value = 200003, Base = 25, Gain = 1},
		{Value = 200004, Base = 25, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "每回合对前2个队员造成120%攻击伤害",
		Skill = {
			{
				Id = 105040,
				Value = 120,
			},
		},
	},
	Tags = {
		560202,
		560203,
		560104,
		560205,
		560206,
		560207,
		560209,
		560210,
		560211,
		561206,
		561306,
		561332,
		563104,
		563206,
	},
}
EnemyConfig[EnemyID.Id047] =
{
	Id = 47,
	Name = "超Q布丁呆",
	Rarity = 3,
	Element = 210004,
	Style = "Dps",
	AttackType = "Melee",
	Area = 
	{
		130055,
	},
	Desc = "撒上了特制焦糖的布丁，走过的地方都会有布丁的香气。在此地居住的居民需要常备胰岛素。",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "FAT",
	IconName = "FAT_Pudding",
	PrefabBundle = "character_enemy",
	PrefabName = "FAT_Pudding",
	PrefabScale = 50,
	HPBarHeight = 89,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 1430, Gain = 286},
		{Value = 200002, Base = 27, Gain = 6},
		{Value = 200003, Base = 25, Gain = 1},
		{Value = 200004, Base = 25, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "受到的暴击伤害 -50%\n受暗元素敌人伤害 -50%\n生命 +20%",
		Skill = {
			{
				Id = 105039,
				Value = -50,
			},
			{
				Id = 105037,
				Value = -50,
			},
			{
				Id = 105001,
				Value = 20,
			},
		},
	},
	Tags = {
		560202,
		560203,
		560104,
		560205,
		560206,
		560207,
		560209,
		560210,
		560211,
		561205,
		561306,
		561332,
		563104,
		563203,
		564561,
	},
}
EnemyConfig[EnemyID.Id048] =
{
	Id = 48,
	Name = "番茄酱侍卫",
	Rarity = 3,
	Element = 210001,
	Style = "Dps",
	AttackType = "Melee",
	Area = 
	{
		130055,
	},
	Desc = "国王御用侍卫，从小陪伴薯条国王长大。能根据薯条国王的状态，时刻调整自己的甜度，深得薯条国王信赖。每次战后他都会在第一时间被送往医院，尽管大部分时候只是包装袋破了。",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	IconName = "Fat_31_fanqiejiang",
	PrefabBundle = "character_fat",
	PrefabName = "Fat_31_fanqiejiang",
	SkinName = "1",
	PrefabScale = 50,
	HPBarHeight = 106,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 1542, Gain = 309},
		{Value = 200002, Base = 13, Gain = 3},
		{Value = 200003, Base = 25, Gain = 1},
		{Value = 200004, Base = 25, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id049] =
{
	Id = 49,
	Name = "汽水王子",
	Rarity = 3,
	Element = 210001,
	Style = "Dps",
	AttackType = "Melee",
	Area = 
	{
		130055,
	},
	Desc = "超人气王子，王子传媒董事长。代言了超过100种饮料产品，每张海报都有强大的修图团队精心处理，力求在所有人面前保持完美形象，但有时会不小心把背景修歪。",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	IconName = "Fat_08_xuebi",
	PrefabBundle = "character_fat",
	PrefabName = "Fat_08_xuebi",
	SkinName = "1",
	PrefabScale = 50,
	HPBarHeight = 117,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 1346, Gain = 270},
		{Value = 200002, Base = 27, Gain = 6},
		{Value = 200003, Base = 25, Gain = 1},
		{Value = 200004, Base = 25, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "受风元素敌人伤害 -50%\n5回合后，暴击 +400%",
		Skill = {
			{
				Id = 105035,
				Value = -50,
			},
			{
				Id = 105016,
				Value = 400,
			},
		},
	},
	Tags = {
		564561,
	},
}
EnemyConfig[EnemyID.Id050] =
{
	Id = 50,
	Name = "梨几推销员",
	Rarity = 1,
	Element = 210003,
	Style = "Dps",
	AttackType = "Melee",
	Area = 
	{
		130056,
	},
	Desc = "口感爽脆的梨几，身上长着大量雀斑，但是水分充足，十分解渴。有人听到它的名字后会误认成肉类魔物。",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "FAT",
	IconName = "FAT_Pear",
	PrefabBundle = "character_enemy",
	PrefabName = "FAT_Pear",
	PrefabScale = 50,
	HPBarHeight = 112,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 1430, Gain = 286},
		{Value = 200002, Base = 27, Gain = 6},
		{Value = 200003, Base = 25, Gain = 1},
		{Value = 200004, Base = 25, Gain = 1},
	},
	Drop = {
	},
	Tags = {
		560202,
		560203,
		560104,
		560205,
		560206,
		560207,
		560209,
		560210,
		560211,
		561204,
		561320,
		561331,
		563103,
		563203,
	},
}
EnemyConfig[EnemyID.Id051] =
{
	Id = 51,
	Name = "黑脸鱼子母舰",
	Rarity = 2,
	Element = 210005,
	Style = "Dps",
	AttackType = "Melee",
	Area = 
	{
		130056,
	},
	Desc = "分量十足的主食，用海苔包裹了全身，头上顶着新鲜饱满的鱼子，那也是它的假发。",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "FAT",
	IconName = "FAT_FishRoeWarshipSushi",
	PrefabBundle = "character_enemy",
	PrefabName = "FAT_FishRoeWarshipSushi",
	PrefabScale = 50,
	HPBarHeight = 75,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 1384, Gain = 277},
		{Value = 200002, Base = 25, Gain = 5},
		{Value = 200003, Base = 25, Gain = 1},
		{Value = 200004, Base = 25, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "有50%概率额外攻击1次",
		Skill = {
			{
				Id = 105023,
				Value = 50,
			},
		},
	},
	Tags = {
		560202,
		560203,
		560104,
		560205,
		560206,
		560207,
		560209,
		560210,
		560211,
		561206,
		561306,
		561319,
		563102,
		563203,
		564558,
	},
}
EnemyConfig[EnemyID.Id052] =
{
	Id = 52,
	Name = "超烫塔可桑",
	Rarity = 4,
	Element = 210004,
	Style = "Dps",
	AttackType = "Melee",
	Area = 
	{
		130056,
	},
	Desc = "每个塔可桑中都包裹了一块鲜美的鱿鱼块，拥有海洋的气味，对于喜欢鱿鱼的人来说是莫大的惊喜，但对于海鲜过敏的人来说则是噩梦。",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "FAT",
	IconName = "FAT_Takesan",
	PrefabBundle = "character_enemy",
	PrefabName = "FAT_Takesan",
	PrefabScale = 50,
	HPBarHeight = 82,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 1234, Gain = 247},
		{Value = 200002, Base = 26, Gain = 6},
		{Value = 200003, Base = 50, Gain = 1},
		{Value = 200004, Base = 50, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "每回合回血 5%，最多5次\n每回合攻击 +5%，最多5次",
		Skill = {
			{
				Id = 105005,
				Value = 5,
			},
			{
				Id = 105006,
				Value = 5,
			},
		},
	},
	Tags = {
		560202,
		560203,
		560104,
		560205,
		560206,
		560207,
		560209,
		560210,
		560211,
		561205,
		561306,
		561332,
		563104,
		563203,
		564560,
		564561,
	},
}
EnemyConfig[EnemyID.Id053] =
{
	Id = 53,
	Name = "小黄",
	Rarity = 1,
	Element = 210002,
	Style = "Dps",
	AttackType = "Melee",
	Area = 
	{
		130056,
	},
	Desc = "柠檬味糖豆，最自豪的事是公主昏倒时，从头上挤出了柠檬汁，酸醒了公主。",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	IconName = "Fat_14_xiaohuang",
	PrefabBundle = "character_fat",
	PrefabName = "Fat_14_xiaohuang",
	SkinName = "1",
	PrefabScale = 50,
	HPBarHeight = 106,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 1350, Gain = 270},
		{Value = 200002, Base = 27, Gain = 6},
		{Value = 200003, Base = 25, Gain = 1},
		{Value = 200004, Base = 25, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "每回合忍耐 +10，最多5次",
		Skill = {
			{
				Id = 105007,
				Value = 10,
			},
		},
	},
	Tags = {
		564561,
	},
}
EnemyConfig[EnemyID.Id054] =
{
	Id = 54,
	Name = "桃几推销员",
	Rarity = 1,
	Element = 210003,
	Style = "Dps",
	AttackType = "Melee",
	Area = 
	{
		130057,
	},
	Desc = "水分充足的蜜桃，虽然身上长着细细的绒毛，但是依然十分讨人喜爱。外表看上去软软的，其实内在是个硬汉。",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "FAT",
	IconName = "FAT_Peach",
	PrefabBundle = "character_enemy",
	PrefabName = "FAT_Peach",
	PrefabScale = 50,
	HPBarHeight = 97,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 1469, Gain = 294},
		{Value = 200002, Base = 28, Gain = 6},
		{Value = 200003, Base = 25, Gain = 1},
		{Value = 200004, Base = 25, Gain = 1},
	},
	Drop = {
	},
	Tags = {
		560202,
		560203,
		560104,
		560205,
		560206,
		560207,
		560209,
		560210,
		560211,
		561204,
		561320,
		561331,
		563103,
		563203,
	},
}
EnemyConfig[EnemyID.Id055] =
{
	Id = 55,
	Name = "和音饭团",
	Rarity = 2,
	Element = 210005,
	Style = "Dps",
	AttackType = "Melee",
	Area = 
	{
		130057,
	},
	Desc = "分量充足的主食，采用白米制作，且撒上了黑芝麻丰富口感，需要配合芥末食用。\n嘿，那是抹茶酱！",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "FAT",
	IconName = "FAT_RiceBall",
	PrefabBundle = "character_enemy",
	PrefabName = "FAT_RiceBall",
	PrefabScale = 50,
	HPBarHeight = 82,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 1421, Gain = 285},
		{Value = 200002, Base = 27, Gain = 6},
		{Value = 200003, Base = 25, Gain = 1},
		{Value = 200004, Base = 25, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "生命 +15%",
		Skill = {
			{
				Id = 105001,
				Value = 15,
			},
		},
	},
	Tags = {
		560202,
		560203,
		560104,
		560205,
		560206,
		560207,
		560209,
		560210,
		560211,
		561206,
		561306,
		561319,
		561357,
		563104,
		563203,
		564561,
	},
}
EnemyConfig[EnemyID.Id056] =
{
	Id = 56,
	Name = "和音黑米团",
	Rarity = 2,
	Element = 210005,
	Style = "Dps",
	AttackType = "Melee",
	Area = 
	{
		130057,
	},
	Desc = "分量充足的主食，采用血糯米制作，口感非常筋道。\n不，不是巧克力味的，别想了。",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "FAT",
	IconName = "FAT_BlackRiceBall",
	PrefabBundle = "character_enemy",
	PrefabName = "FAT_BlackRiceBall",
	PrefabScale = 50,
	HPBarHeight = 82,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 1402, Gain = 281},
		{Value = 200002, Base = 27, Gain = 6},
		{Value = 200003, Base = 25, Gain = 1},
		{Value = 200004, Base = 25, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "生命 +15%",
		Skill = {
			{
				Id = 105001,
				Value = 15,
			},
		},
	},
	Tags = {
		560202,
		560203,
		560104,
		560205,
		560206,
		560207,
		560209,
		560210,
		560211,
		561206,
		561306,
		561319,
		561357,
		563104,
		563203,
		564561,
	},
}
EnemyConfig[EnemyID.Id057] =
{
	Id = 57,
	Name = "和音泡菜团",
	Rarity = 2,
	Element = 210005,
	Style = "Dps",
	AttackType = "Melee",
	Area = 
	{
		130057,
	},
	Desc = "分量充足的主食，对于想要吃清淡食物的食客具有开胃效果。\n明明是辣的，怎么会清淡呢？",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "FAT",
	IconName = "FAT_CabbageRiceBall",
	PrefabBundle = "character_enemy",
	PrefabName = "FAT_CabbageRiceBall",
	PrefabScale = 50,
	HPBarHeight = 82,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 1384, Gain = 277},
		{Value = 200002, Base = 27, Gain = 6},
		{Value = 200003, Base = 25, Gain = 1},
		{Value = 200004, Base = 25, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "生命 +15%",
		Skill = {
			{
				Id = 105001,
				Value = 15,
			},
		},
	},
	Tags = {
		560202,
		560203,
		560104,
		560205,
		560206,
		560207,
		560209,
		560210,
		560211,
		561206,
		561306,
		561319,
		561357,
		563104,
		563203,
		564561,
	},
}
EnemyConfig[EnemyID.Id058] =
{
	Id = 58,
	Name = "小橙",
	Rarity = 1,
	Element = 210002,
	Style = "Dps",
	AttackType = "Melee",
	Area = 
	{
		130057,
	},
	Desc = "橙子味糖豆，最自豪的事是被公主抱起来时，夸奖说味道闻起来很清爽。",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	IconName = "Fat_13_xiaocheng",
	PrefabBundle = "character_fat",
	PrefabName = "Fat_13_xiaocheng",
	SkinName = "1",
	PrefabScale = 50,
	HPBarHeight = 106,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 1375, Gain = 275},
		{Value = 200002, Base = 27, Gain = 6},
		{Value = 200003, Base = 25, Gain = 1},
		{Value = 200004, Base = 25, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "每回合暴击 +40，最多5次",
		Skill = {
			{
				Id = 105008,
				Value = 40,
			},
		},
	},
	Tags = {
		564561,
	},
}
EnemyConfig[EnemyID.Id059] =
{
	Id = 59,
	Name = "超Q夹心肉球",
	Rarity = 2,
	Element = 210002,
	Style = "Dps",
	AttackType = "Melee",
	Area = 
	{
		130058,
	},
	Desc = "不添加任何面粉的纯肉丸子，内部有特制的肉馅作为馅料，温度很高，很容易烫伤食客们。对此它毫无自觉，总是劝大家趁热吃。",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "FAT",
	IconName = "FAT_MeatBalls",
	PrefabBundle = "character_enemy",
	PrefabName = "FAT_MeatBalls",
	PrefabScale = 50,
	HPBarHeight = 69,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 1254, Gain = 251},
		{Value = 200002, Base = 27, Gain = 6},
		{Value = 200003, Base = 25, Gain = 1},
		{Value = 200004, Base = 25, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "50%概率闪避攻击",
		Skill = {
			{
				Id = 105026,
				Value = 50,
			},
		},
	},
	Tags = {
		560202,
		560203,
		560104,
		560205,
		560206,
		560207,
		560209,
		560210,
		560211,
		561203,
		561306,
		561312,
		563103,
		563203,
		564557,
	},
}
EnemyConfig[EnemyID.Id060] =
{
	Id = 60,
	Name = "超烫铛噗灵",
	Rarity = 3,
	Element = 210001,
	Style = "Dps",
	AttackType = "Melee",
	Area = 
	{
		130058,
	},
	Desc = "薄薄的皮料包裹着各种食材的主食，搭配调料后，会在嘴中爆发出难以言喻的美味。\n经过星际翻译法的协调，现在统一规定叫饺子。",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "FAT",
	IconName = "FAT_Dumplings",
	PrefabBundle = "character_enemy",
	PrefabName = "FAT_Dumplings",
	PrefabScale = 50,
	HPBarHeight = 75,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 1367, Gain = 274},
		{Value = 200002, Base = 25, Gain = 5},
		{Value = 200003, Base = 25, Gain = 1},
		{Value = 200004, Base = 25, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "有50%概率额外攻击1次",
		Skill = {
			{
				Id = 105023,
				Value = 50,
			},
		},
	},
	Tags = {
		560202,
		560203,
		560104,
		560205,
		560206,
		560207,
		560209,
		560210,
		560211,
		561202,
		561306,
		561319,
		563104,
		563203,
		564558,
	},
}
EnemyConfig[EnemyID.Id061] =
{
	Id = 61,
	Name = "番茄酱侍卫",
	Rarity = 3,
	Element = 210001,
	Style = "Dps",
	AttackType = "Melee",
	Area = 
	{
		130058,
	},
	Desc = "国王御用侍卫，从小陪伴薯条国王长大。能根据薯条国王的状态，时刻调整自己的甜度，深得薯条国王信赖。每次战后他都会在第一时间被送往医院，尽管大部分时候只是包装袋破了。",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	IconName = "Fat_31_fanqiejiang",
	PrefabBundle = "character_fat",
	PrefabName = "Fat_31_fanqiejiang",
	SkinName = "1",
	PrefabScale = 50,
	HPBarHeight = 106,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 1475, Gain = 295},
		{Value = 200002, Base = 13, Gain = 3},
		{Value = 200003, Base = 25, Gain = 1},
		{Value = 200004, Base = 25, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id062] =
{
	Id = 62,
	Name = "可乐王子",
	Rarity = 3,
	Element = 210005,
	Style = "Dps",
	AttackType = "Melee",
	Area = 
	{
		130058,
	},
	Desc = "超人气王子，王子唱片董事长。每年都会开办36场演唱会，出18张专辑。不过唱片销量要靠常年打折外加赠送超值礼品才能维持。",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	IconName = "Fat_07_kele",
	PrefabBundle = "character_fat",
	PrefabName = "Fat_07_kele",
	SkinName = "1",
	PrefabScale = 50,
	HPBarHeight = 114,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 925, Gain = 185},
		{Value = 200002, Base = 27, Gain = 6},
		{Value = 200003, Base = 25, Gain = 1},
		{Value = 200004, Base = 25, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "受光元素敌人伤害 -25%\n5回合后，攻击 +100%",
		Skill = {
			{
				Id = 105036,
				Value = -25,
			},
			{
				Id = 105014,
				Value = 100,
			},
		},
	},
	Tags = {
		564561,
	},
}
EnemyConfig[EnemyID.Id063] =
{
	Id = 63,
	Name = "金牌玉子龟龟",
	Rarity = 2,
	Element = 210004,
	Style = "Dps",
	AttackType = "Melee",
	Area = 
	{
		130059,
	},
	Desc = "使用顶级匠人烹制的超美味蛋料理作为食材的寿司精灵，日常散步时经常让路人产生吃它的冲动。\n龟龟，这不就是鸡蛋吗？",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "FAT",
	IconName = "FAT_EggSushi",
	PrefabBundle = "character_enemy",
	PrefabName = "FAT_EggSushi",
	PrefabScale = 50,
	HPBarHeight = 75,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 1358, Gain = 272},
		{Value = 200002, Base = 27, Gain = 6},
		{Value = 200003, Base = 25, Gain = 1},
		{Value = 200004, Base = 25, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "忍耐 +20",
		Skill = {
			{
				Id = 105003,
				Value = 20,
			},
		},
	},
	Tags = {
		560202,
		560203,
		560104,
		560205,
		560206,
		560207,
		560209,
		560210,
		560211,
		561205,
		561306,
		561319,
		563102,
		563203,
		564561,
	},
}
EnemyConfig[EnemyID.Id064] =
{
	Id = 64,
	Name = "金牌寿司龟龟",
	Rarity = 2,
	Element = 210004,
	Style = "Dps",
	AttackType = "Melee",
	Area = 
	{
		130059,
	},
	Desc = "采用了最高级的鱼背肉部位作为食材的寿司精灵，日常散步时经常让路人产生吃它的冲动。\n龟龟，这不就是米饭吗？",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "FAT",
	IconName = "FAT_SalmonSushi",
	PrefabBundle = "character_enemy",
	PrefabName = "FAT_SalmonSushi",
	PrefabScale = 50,
	HPBarHeight = 75,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 1341, Gain = 269},
		{Value = 200002, Base = 27, Gain = 6},
		{Value = 200003, Base = 25, Gain = 1},
		{Value = 200004, Base = 25, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "忍耐 +20",
		Skill = {
			{
				Id = 105003,
				Value = 20,
			},
		},
	},
	Tags = {
		560202,
		560203,
		560104,
		560205,
		560206,
		560207,
		560209,
		560210,
		560211,
		561205,
		561306,
		561319,
		563102,
		563203,
		564561,
	},
}
EnemyConfig[EnemyID.Id065] =
{
	Id = 65,
	Name = "金牌甜虾龟龟",
	Rarity = 2,
	Element = 210004,
	Style = "Dps",
	AttackType = "Melee",
	Area = 
	{
		130059,
	},
	Desc = "采用了鲜甜肥美的深海大虾作为食材的寿司，日常散步时经常让路人产生吃它的冲动。\n龟龟，这哪大了？",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "FAT",
	IconName = "FAT_ShrimpSushi",
	PrefabBundle = "character_enemy",
	PrefabName = "FAT_ShrimpSushi",
	PrefabScale = 50,
	HPBarHeight = 75,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 1325, Gain = 265},
		{Value = 200002, Base = 26, Gain = 6},
		{Value = 200003, Base = 25, Gain = 1},
		{Value = 200004, Base = 25, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "忍耐 +20",
		Skill = {
			{
				Id = 105003,
				Value = 20,
			},
		},
	},
	Tags = {
		560202,
		560203,
		560104,
		560205,
		560206,
		560207,
		560209,
		560210,
		560211,
		561205,
		561306,
		561319,
		563102,
		563203,
		564561,
	},
}
EnemyConfig[EnemyID.Id066] =
{
	Id = 66,
	Name = "小绿",
	Rarity = 1,
	Element = 210003,
	Style = "Dps",
	AttackType = "Melee",
	Area = 
	{
		130059,
	},
	Desc = "奇异果味糖豆，最自豪的事是被公主抱起来时，夸奖颜色看起来很健康。",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	IconName = "Fat_15_xiaolv",
	PrefabBundle = "character_fat",
	PrefabName = "Fat_15_xiaolv",
	SkinName = "1",
	PrefabScale = 50,
	HPBarHeight = 106,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 1264, Gain = 253},
		{Value = 200002, Base = 26, Gain = 6},
		{Value = 200003, Base = 25, Gain = 1},
		{Value = 200004, Base = 25, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "每回合回血 10%，最多5次",
		Skill = {
			{
				Id = 105005,
				Value = 10,
			},
		},
	},
	Tags = {
		564560,
	},
}
EnemyConfig[EnemyID.Id067] =
{
	Id = 67,
	Name = "苹狗推销员",
	Rarity = 1,
	Element = 210003,
	Style = "Dps",
	AttackType = "Melee",
	Area = 
	{
		130060,
	},
	Desc = "营养丰富的苹狗，身体是健康的红色。最大的梦想是进化成传说中的物种——芒狗。",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "FAT",
	IconName = "FAT_Apple",
	PrefabBundle = "character_enemy",
	PrefabName = "FAT_Apple",
	PrefabScale = 50,
	HPBarHeight = 97,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 1350, Gain = 270},
		{Value = 200002, Base = 27, Gain = 6},
		{Value = 200003, Base = 25, Gain = 1},
		{Value = 200004, Base = 25, Gain = 1},
	},
	Drop = {
	},
	Tags = {
		560202,
		560203,
		560104,
		560205,
		560206,
		560207,
		560209,
		560210,
		560211,
		561204,
		561320,
		561331,
		563103,
		563203,
	},
}
EnemyConfig[EnemyID.Id068] =
{
	Id = 68,
	Name = "冠军培根",
	Rarity = 2,
	Element = 210002,
	Style = "Dps",
	AttackType = "Melee",
	Area = 
	{
		130060,
	},
	Desc = "星际著名的哲学家、科学家，在诸多学科都有很大贡献，为星际居民所敬仰……然而这跟我培根有什么关系呢？",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "FAT",
	IconName = "FAT_Bacon",
	PrefabBundle = "character_enemy",
	PrefabName = "FAT_Bacon",
	PrefabScale = 50,
	HPBarHeight = 71,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 1325, Gain = 265},
		{Value = 200002, Base = 26, Gain = 6},
		{Value = 200003, Base = 25, Gain = 1},
		{Value = 200004, Base = 25, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "受到的暴击伤害 -50%",
		Skill = {
			{
				Id = 105039,
				Value = -50,
			},
		},
	},
	Tags = {
		560202,
		560203,
		560104,
		560205,
		560206,
		560207,
		560209,
		560210,
		560211,
		561203,
		561306,
		561312,
		563104,
		563203,
	},
}
EnemyConfig[EnemyID.Id069] =
{
	Id = 69,
	Name = "冠军火腿猪",
	Rarity = 3,
	Element = 210002,
	Style = "Dps",
	AttackType = "Melee",
	Area = 
	{
		130060,
	},
	Desc = "美食星特有的豚类，会定时产出美味的腌制火腿，很受烤肉店欢迎，至于产出过程……",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "FAT",
	IconName = "FAT_HamPig",
	PrefabBundle = "character_enemy",
	PrefabName = "FAT_HamPig",
	PrefabScale = 50,
	HPBarHeight = 110,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 1073, Gain = 215},
		{Value = 200002, Base = 18, Gain = 4},
		{Value = 200003, Base = 25, Gain = 1},
		{Value = 200004, Base = 25, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "每回合对前3个队员造成120%攻击伤害",
		Skill = {
			{
				Id = 105041,
				Value = 120,
			},
		},
	},
	Tags = {
		560202,
		560203,
		560104,
		560205,
		560206,
		560207,
		560209,
		560210,
		560211,
		561203,
		561306,
		561312,
		563102,
		563203,
	},
}
EnemyConfig[EnemyID.Id070] =
{
	Id = 70,
	Name = "番茄酱侍卫",
	Rarity = 3,
	Element = 210001,
	Style = "Dps",
	AttackType = "Melee",
	Area = 
	{
		130060,
	},
	Desc = "国王御用侍卫，从小陪伴薯条国王长大。能根据薯条国王的状态，时刻调整自己的甜度，深得薯条国王信赖。每次战后他都会在第一时间被送往医院，尽管大部分时候只是包装袋破了。",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	IconName = "Fat_31_fanqiejiang",
	PrefabBundle = "character_fat",
	PrefabName = "Fat_31_fanqiejiang",
	SkinName = "1",
	PrefabScale = 50,
	HPBarHeight = 106,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 1414, Gain = 283},
		{Value = 200002, Base = 13, Gain = 3},
		{Value = 200003, Base = 25, Gain = 1},
		{Value = 200004, Base = 25, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id071] =
{
	Id = 71,
	Name = "啤酒王子",
	Rarity = 3,
	Element = 210004,
	Style = "Dps",
	AttackType = "Melee",
	Area = 
	{
		130060,
	},
	Desc = "超人气王子，王子乐团总指挥。每次音乐演奏会都会独自负责弦乐、管乐、打击乐三个部分，奔放的演出方式经常让观众怀疑表演者是不是喝醉了。",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	IconName = "Fat_09_pijiu",
	PrefabBundle = "character_fat",
	PrefabName = "Fat_09_pijiu",
	SkinName = "1",
	PrefabScale = 50,
	HPBarHeight = 113,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 825, Gain = 165},
		{Value = 200002, Base = 26, Gain = 6},
		{Value = 200003, Base = 50, Gain = 1},
		{Value = 200004, Base = 25, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "受暗元素敌人伤害 -50%\n5回合后，忍耐 +100",
		Skill = {
			{
				Id = 105037,
				Value = -50,
			},
			{
				Id = 105015,
				Value = 100,
			},
		},
	},
	Tags = {
		564561,
	},
}
EnemyConfig[EnemyID.Id072] =
{
	Id = 72,
	Name = "招牌芝士软泥",
	Rarity = 2,
	Element = 210002,
	Style = "Dps",
	AttackType = "Melee",
	Area = 
	{
		130061,
	},
	Desc = "用精品土豆研磨而成的细滑豆泥，拌入芝士后味道将更加浓郁。\n没加泥。",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "FAT",
	IconName = "FAT_Cheese",
	PrefabBundle = "character_enemy",
	PrefabName = "FAT_Cheese",
	PrefabScale = 50,
	HPBarHeight = 75,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 1155, Gain = 231},
		{Value = 200002, Base = 25, Gain = 5},
		{Value = 200003, Base = 25, Gain = 1},
		{Value = 200004, Base = 25, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "每回合回血 8%，最多5次\n受到的暴击伤害 -50%",
		Skill = {
			{
				Id = 105005,
				Value = 8,
			},
			{
				Id = 105039,
				Value = -50,
			},
		},
	},
	Tags = {
		560202,
		560203,
		560104,
		560205,
		560206,
		560207,
		560209,
		560210,
		560211,
		561203,
		561306,
		561332,
		563103,
		563203,
		564560,
	},
}
EnemyConfig[EnemyID.Id073] =
{
	Id = 73,
	Name = "金牌比撒",
	Rarity = 4,
	Element = 210002,
	Style = "Dps",
	AttackType = "Melee",
	Area = 
	{
		130061,
	},
	Desc = "包裹了香浓芝士的披萨，表面挂着各种食材，无论是作为点心或是正餐都是很棒的选择。\n没在骂人。",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "FAT",
	IconName = "FAT_Pizza",
	PrefabBundle = "character_enemy",
	PrefabName = "FAT_Pizza",
	PrefabScale = 50,
	HPBarHeight = 100,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 1124, Gain = 225},
		{Value = 200002, Base = 25, Gain = 5},
		{Value = 200003, Base = 25, Gain = 1},
		{Value = 200004, Base = 25, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "每回合回血 8%，最多5次\n每3回合回血 10%，最多5次",
		Skill = {
			{
				Id = 105005,
				Value = 8,
			},
			{
				Id = 105009,
				Value = 10,
			},
		},
	},
	Tags = {
		560202,
		560203,
		560104,
		560205,
		560206,
		560207,
		560209,
		560210,
		560211,
		561203,
		561306,
		561319,
		563104,
		563203,
		564560,
	},
}
EnemyConfig[EnemyID.Id074] =
{
	Id = 74,
	Name = "左半碗代表",
	Rarity = 1,
	Element = 210001,
	Style = "Dps",
	AttackType = "Melee",
	Area = 
	{
		130101,
	},
	Desc = "活跃在博物馆各大角落的碎瓷，出自某朝左姓大官家中，大官家道中落后也遭遇事故碎成两半，目前流落民间，以左为姓。",
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "MUS",
	IconName = "MUS_GreenBowlLeft",
	PrefabBundle = "character_enemy",
	PrefabName = "MUS_GreenBowlLeft",
	PrefabScale = 50,
	HPBarHeight = 100,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 1333, Gain = 267},
		{Value = 200002, Base = 27, Gain = 6},
		{Value = 200003, Base = 25, Gain = 1},
		{Value = 200004, Base = 25, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "暴击 +80",
		Skill = {
			{
				Id = 105004,
				Value = 80,
			},
		},
	},
	Tags = {
		560202,
		560203,
		560204,
		560105,
		560206,
		560207,
		560209,
		560210,
		560211,
		561202,
		561321,
		561336,
		561339,
		563106,
		563203,
		564561,
	},
}
EnemyConfig[EnemyID.Id075] =
{
	Id = 75,
	Name = "入口队长",
	Rarity = 2,
	Element = 210004,
	Style = "Dps",
	AttackType = "Melee",
	Area = 
	{
		130102,
	},
	Desc = "指引游客进入博物馆的工作人员，如果游客固执地想从入口出去，它会很认真地阻止对方。",
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "MUS",
	IconName = "MUS_Entrance",
	PrefabBundle = "character_enemy",
	PrefabName = "MUS_Enter",
	PrefabScale = 50,
	HPBarHeight = 100,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 1317, Gain = 264},
		{Value = 200002, Base = 26, Gain = 6},
		{Value = 200003, Base = 25, Gain = 1},
		{Value = 200004, Base = 25, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "生命 +10%\n忍耐 +50",
		Skill = {
			{
				Id = 105001,
				Value = 10,
			},
			{
				Id = 105003,
				Value = 50,
			},
		},
	},
	Tags = {
		560202,
		560203,
		560204,
		560105,
		560206,
		560207,
		560209,
		560210,
		560211,
		561205,
		561321,
		561335,
		563105,
		563203,
		564561,
	},
}
EnemyConfig[EnemyID.Id076] =
{
	Id = 76,
	Name = "红外线探测",
	Rarity = 2,
	Element = 210004,
	Style = "Dps",
	AttackType = "Melee",
	Area = 
	{
		130102,
	},
	Desc = "躲在暗处监视走道情况的机械设备，如果有人入侵会用红外线照对方眼睛。",
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "MUS",
	IconName = "MUS_InfraredDetector",
	PrefabBundle = "character_enemy",
	PrefabName = "MUS_InfraredDetector",
	PrefabScale = 50,
	HPBarHeight = 120,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 1093, Gain = 219},
		{Value = 200002, Base = 26, Gain = 6},
		{Value = 200003, Base = 25, Gain = 1},
		{Value = 200004, Base = 25, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "33%概率闪避攻击\n50%概率无视敌人闪避",
		Skill = {
			{
				Id = 105026,
				Value = 33,
			},
			{
				Id = 105027,
				Value = 50,
			},
		},
	},
	Tags = {
		560202,
		560203,
		560204,
		560105,
		560206,
		560207,
		560209,
		560210,
		560211,
		561205,
		561321,
		561353,
		561322,
		563105,
		563203,
		564557,
		564559,
	},
}
EnemyConfig[EnemyID.Id077] =
{
	Id = 77,
	Name = "保安",
	Rarity = 3,
	Element = 210001,
	Style = "Dps",
	AttackType = "Melee",
	Area = 
	{
		130102,
	},
	Desc = "博物馆星新任保安，人生处于低谷时来到博物馆散心，无意间拿起保安招聘启事后便被馆长强行留了下来。",
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "Mus",
	IconName = "MUS_27_baoan",
	PrefabBundle = "character_mus",
	PrefabName = "MUS_27_baoan",
	SkinName = "1",
	PrefabScale = 50,
	HPBarHeight = 115,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 1258, Gain = 252},
		{Value = 200002, Base = 26, Gain = 6},
		{Value = 200003, Base = 25, Gain = 1},
		{Value = 200004, Base = 25, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "受到的暴击伤害 -50%\n每3回合回血 30%，最多5次\n每回合忍耐 +10，最多5次",
		Skill = {
			{
				Id = 105039,
				Value = -50,
			},
			{
				Id = 105009,
				Value = 30,
			},
			{
				Id = 105007,
				Value = 10,
			},
		},
	},
	Tags = {
		564560,
		564561,
	},
}
EnemyConfig[EnemyID.Id078] =
{
	Id = 78,
	Name = "太古围观陶",
	Rarity = 2,
	Element = 210002,
	Style = "Dps",
	AttackType = "Melee",
	Area = 
	{
		130103,
	},
	Desc = "整天无所事事的文物，到处瞎逛看热闹，爱占小便宜，喜欢碰瓷，因为瓷没它硬。",
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "MUS",
	IconName = "MUS_Pottery",
	PrefabBundle = "character_enemy",
	PrefabName = "MUS_Pottery",
	PrefabScale = 50,
	HPBarHeight = 100,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 1117, Gain = 224},
		{Value = 200002, Base = 26, Gain = 6},
		{Value = 200003, Base = 50, Gain = 1},
		{Value = 200004, Base = 25, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "33%概率闪避攻击",
		Skill = {
			{
				Id = 105026,
				Value = 33,
			},
		},
	},
	Tags = {
		560202,
		560203,
		560204,
		560105,
		560206,
		560207,
		560209,
		560210,
		560211,
		561203,
		561321,
		561336,
		563106,
		563203,
		564557,
	},
}
EnemyConfig[EnemyID.Id079] =
{
	Id = 79,
	Name = "陶老大",
	Rarity = 3,
	Element = 210005,
	Style = "Dps",
	AttackType = "Melee",
	Area = 
	{
		130103,
	},
	Desc = "神秘的古代陶土工艺品，脸上写着难以言喻的表情，不太受人欢迎。",
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "MUS",
	IconName = "MUS_QuestionMark",
	PrefabBundle = "character_enemy",
	PrefabName = "MUS_QuestionMark",
	PrefabScale = 50,
	HPBarHeight = 110,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 1086, Gain = 218},
		{Value = 200002, Base = 12, Gain = 3},
		{Value = 200003, Base = 25, Gain = 1},
		{Value = 200004, Base = 25, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "每回合对所有队员造成100%攻击伤害\n对光元素敌人伤害 +50%\n对暗元素敌人伤害 +100%",
		Skill = {
			{
				Id = 105047,
				Value = 100,
			},
			{
				Id = 105031,
				Value = 50,
			},
			{
				Id = 105032,
				Value = 100,
			},
		},
	},
	Tags = {
		560202,
		560203,
		560204,
		560105,
		560206,
		560207,
		560209,
		560210,
		560211,
		561206,
		561321,
		561336,
		563103,
		563203,
	},
}
EnemyConfig[EnemyID.Id080] =
{
	Id = 80,
	Name = "浣熊小弟",
	Rarity = 3,
	Element = 210004,
	Style = "Dps",
	AttackType = "Melee",
	Area = 
	{
		130103,
	},
	Desc = "总是跟着两个哥哥去参观博物馆的小浣熊，但每次都会因为没买票被拦在门外。他对此很气愤，因为自己并没有钱买票。",
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "Mus",
	IconName = "MUS_15_xiaodi",
	PrefabBundle = "character_mus",
	PrefabName = "MUS_15_xiaodi",
	SkinName = "1",
	PrefabScale = 50,
	HPBarHeight = 105,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 1172, Gain = 235},
		{Value = 200002, Base = 26, Gain = 6},
		{Value = 200003, Base = 25, Gain = 1},
		{Value = 200004, Base = 25, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "33%概率闪避攻击\n受到的暴击伤害 -50%\n每回合攻击 +10%，最多5次",
		Skill = {
			{
				Id = 105026,
				Value = 33,
			},
			{
				Id = 105039,
				Value = -50,
			},
			{
				Id = 105006,
				Value = 10,
			},
		},
	},
	Tags = {
		564557,
		564561,
	},
}
EnemyConfig[EnemyID.Id081] =
{
	Id = 81,
	Name = "王朝编钟",
	Rarity = 2,
	Element = 210003,
	Style = "Dps",
	AttackType = "Melee",
	Area = 
	{
		130104,
	},
	Desc = "古代的乐器，能够敲击出悠扬空灵的声响，喜欢说大话，经常炫耀自己见多识广，对此大家总是表示“你就编吧”。",
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "MUS",
	IconName = "MUS_Chimes",
	PrefabBundle = "character_enemy",
	PrefabName = "MUS_Chimes",
	PrefabScale = 50,
	HPBarHeight = 120,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 1083, Gain = 217},
		{Value = 200002, Base = 21, Gain = 5},
		{Value = 200003, Base = 25, Gain = 1},
		{Value = 200004, Base = 25, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "每回合对前2个队员造成100%攻击伤害",
		Skill = {
			{
				Id = 105040,
				Value = 100,
			},
		},
	},
	Tags = {
		560202,
		560203,
		560204,
		560105,
		560206,
		560207,
		560209,
		560210,
		560211,
		561204,
		561321,
		561336,
		563106,
		563203,
	},
}
EnemyConfig[EnemyID.Id082] =
{
	Id = 82,
	Name = "太古兽面鼎",
	Rarity = 2,
	Element = 210005,
	Style = "Dps",
	AttackType = "Melee",
	Area = 
	{
		130104,
	},
	Desc = "在古代祭祀典礼上经常出现的器皿，用来插仪式用的焚香，因为样貌有些吓人，有时会吓到前来祭祀的人。",
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "MUS",
	IconName = "MUS_BeastFaceTripod",
	PrefabBundle = "character_enemy",
	PrefabName = "MUS_BeastFaceTripod",
	PrefabScale = 50,
	HPBarHeight = 100,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 1259, Gain = 252},
		{Value = 200002, Base = 25, Gain = 5},
		{Value = 200003, Base = 25, Gain = 1},
		{Value = 200004, Base = 25, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "有15%概率额外攻击2次",
		Skill = {
			{
				Id = 105024,
				Value = 15,
			},
		},
	},
	Tags = {
		560202,
		560203,
		560204,
		560105,
		560206,
		560207,
		560209,
		560210,
		560211,
		561206,
		561321,
		561336,
		563102,
		563203,
		564558,
	},
}
EnemyConfig[EnemyID.Id083] =
{
	Id = 83,
	Name = "远古猪罐",
	Rarity = 3,
	Element = 210002,
	Style = "Dps",
	AttackType = "Melee",
	Area = 
	{
		130104,
	},
	Desc = "从遗迹里挖出来的猪形瓷罐，上方的小孔刚好够塞进去一枚铜币，但里面却是空的。",
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "MUS",
	IconName = "MUS_PigJar",
	PrefabBundle = "character_enemy",
	PrefabName = "MUS_PigJar",
	PrefabScale = 50,
	HPBarHeight = 100,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 1244, Gain = 249},
		{Value = 200002, Base = 26, Gain = 6},
		{Value = 200003, Base = 25, Gain = 1},
		{Value = 200004, Base = 25, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "生命 +100%",
		Skill = {
			{
				Id = 105001,
				Value = 100,
			},
		},
	},
	Tags = {
		560202,
		560203,
		560204,
		560105,
		560206,
		560207,
		560209,
		560210,
		560211,
		561203,
		561321,
		561336,
		561329,
		563102,
		563203,
		564561,
	},
}
EnemyConfig[EnemyID.Id084] =
{
	Id = 84,
	Name = "左半瓷代表",
	Rarity = 2,
	Element = 210003,
	Style = "Dps",
	AttackType = "Melee",
	Area = 
	{
		130105,
	},
	Desc = "活跃在博物馆各大角落的碎瓷片，过去是在皇宫里当差的，碎了以后就回到了民间，因为碎裂的关系已经认不出右半瓷了。",
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "MUS",
	IconName = "MUS_BlueBowlLeft",
	PrefabBundle = "character_enemy",
	PrefabName = "MUS_BlueBowlLeft",
	PrefabScale = 50,
	HPBarHeight = 100,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 1164, Gain = 233},
		{Value = 200002, Base = 25, Gain = 5},
		{Value = 200003, Base = 25, Gain = 1},
		{Value = 200004, Base = 25, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "暴击 +40",
		Skill = {
			{
				Id = 105004,
				Value = 40,
			},
		},
	},
	Tags = {
		560202,
		560203,
		560204,
		560105,
		560206,
		560207,
		560209,
		560210,
		560211,
		561204,
		561321,
		561336,
		561339,
		563106,
		563203,
		564561,
	},
}
EnemyConfig[EnemyID.Id085] =
{
	Id = 85,
	Name = "右半瓷代表",
	Rarity = 2,
	Element = 210003,
	Style = "Dps",
	AttackType = "Melee",
	Area = 
	{
		130105,
	},
	Desc = "活跃在博物馆各大角落的碎瓷片，过去是在皇宫里当差的，碎了以后就回到了民间，还记得左半瓷但是老是装不认识。",
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "MUS",
	IconName = "MUS_BlueBowlRight",
	PrefabBundle = "character_enemy",
	PrefabName = "MUS_BlueBowlRight",
	PrefabScale = 50,
	HPBarHeight = 100,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 1158, Gain = 232},
		{Value = 200002, Base = 25, Gain = 5},
		{Value = 200003, Base = 25, Gain = 1},
		{Value = 200004, Base = 25, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "暴击 +40",
		Skill = {
			{
				Id = 105004,
				Value = 40,
			},
		},
	},
	Tags = {
		560202,
		560203,
		560204,
		560105,
		560206,
		560207,
		560209,
		560210,
		560211,
		561204,
		561321,
		561336,
		561339,
		563106,
		563203,
		564561,
	},
}
EnemyConfig[EnemyID.Id086] =
{
	Id = 86,
	Name = "碰瓷王",
	Rarity = 2,
	Element = 210004,
	Style = "Dps",
	AttackType = "Melee",
	Area = 
	{
		130105,
	},
	Desc = "毫无节操的前文物，会在游客密集的地方突然躺倒，向附近的游客索要巨额赔偿。天敌是围观陶，因为碰不过。",
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "MUS",
	IconName = "MUS_Porcelain",
	PrefabBundle = "character_enemy",
	PrefabName = "MUS_Porcelain",
	PrefabScale = 50,
	HPBarHeight = 110,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 1034, Gain = 207},
		{Value = 200002, Base = 25, Gain = 5},
		{Value = 200003, Base = 25, Gain = 1},
		{Value = 200004, Base = 25, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "50%概率闪避攻击\n对光元素敌人伤害 +100%",
		Skill = {
			{
				Id = 105026,
				Value = 50,
			},
			{
				Id = 105031,
				Value = 100,
			},
		},
	},
	Tags = {
		560202,
		560203,
		560204,
		560105,
		560206,
		560207,
		560209,
		560210,
		560211,
		561205,
		561321,
		561336,
		561339,
		563106,
		563203,
		564557,
	},
}
EnemyConfig[EnemyID.Id087] =
{
	Id = 87,
	Name = "警戒线队长",
	Rarity = 3,
	Element = 210005,
	Style = "Dps",
	AttackType = "Melee",
	Area = 
	{
		130105,
	},
	Desc = "经常被无视的保安设备，有人想穿过去时，它就会一直盯着对方。",
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "MUS",
	IconName = "MUS_Cordon",
	PrefabBundle = "character_enemy",
	PrefabName = "MUS_Cordon",
	PrefabScale = 50,
	HPBarHeight = 110,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 1139, Gain = 228},
		{Value = 200002, Base = 25, Gain = 5},
		{Value = 200003, Base = 25, Gain = 1},
		{Value = 200004, Base = 25, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "每回合攻击 +20%，最多5次\n每回合忍耐 +20，最多5次",
		Skill = {
			{
				Id = 105006,
				Value = 20,
			},
			{
				Id = 105007,
				Value = 20,
			},
		},
	},
	Tags = {
		560202,
		560203,
		560204,
		560105,
		560206,
		560207,
		560209,
		560210,
		560211,
		561206,
		561321,
		561337,
		563105,
		563203,
		564561,
	},
}
EnemyConfig[EnemyID.Id088] =
{
	Id = 88,
	Name = "木乃伊",
	Rarity = 2,
	Element = 210003,
	Style = "Dps",
	AttackType = "Melee",
	Area = 
	{
		130105,
	},
	Desc = "睡了上千年的木乃伊，已经忘了自己原本的身份。虽然外表看起来可怕，但是性格温和，很快和博物馆里的其他居民打成了一片。",
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "Mus",
	IconName = "MUS_05_munaiyi",
	PrefabBundle = "character_mus",
	PrefabName = "MUS_05_munaiyi",
	SkinName = "1",
	PrefabScale = 50,
	HPBarHeight = 115,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 1372, Gain = 275},
		{Value = 200002, Base = 26, Gain = 6},
		{Value = 200003, Base = 25, Gain = 1},
		{Value = 200004, Base = 25, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "5回合后，攻击 +100%\n5回合后，回血 50%\n受火元素敌人伤害 -33%",
		Skill = {
			{
				Id = 105014,
				Value = 100,
			},
			{
				Id = 105013,
				Value = 50,
			},
			{
				Id = 105034,
				Value = -33,
			},
		},
	},
	Tags = {
		564560,
		564561,
	},
}
EnemyConfig[EnemyID.Id089] =
{
	Id = 89,
	Name = "精英雨林龙",
	Rarity = 2,
	Element = 210003,
	Style = "Dps",
	AttackType = "Melee",
	Area = 
	{
		130106,
	},
	Desc = "第二世代时生活在雨林地区的双足龙，走起来速度十分惊人，但是因为名字而不能奔跑。",
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "MUS",
	IconName = "MUS_DinosaurEgg",
	PrefabBundle = "character_enemy",
	PrefabName = "MUS_DinosaurEgg",
	PrefabScale = 50,
	HPBarHeight = 110,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 1194, Gain = 239},
		{Value = 200002, Base = 26, Gain = 6},
		{Value = 200003, Base = 25, Gain = 1},
		{Value = 200004, Base = 25, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "受火元素敌人伤害 -50%\n每回合回血 8%，最多5次",
		Skill = {
			{
				Id = 105034,
				Value = -50,
			},
			{
				Id = 105005,
				Value = 8,
			},
		},
	},
	Tags = {
		560202,
		560203,
		560204,
		560105,
		560206,
		560207,
		560209,
		560210,
		560211,
		561204,
		561303,
		561340,
		561338,
		563102,
		563205,
		564560,
	},
}
EnemyConfig[EnemyID.Id090] =
{
	Id = 90,
	Name = "精英沙漠龙",
	Rarity = 2,
	Element = 210002,
	Style = "Dps",
	AttackType = "Melee",
	Area = 
	{
		130106,
	},
	Desc = "虽然和雨林快走龙很像，却是来自第三世代的生物。叫这个名字并不是因为走得快，而是为了纪念它在危难之中保护了自己的朋友沙漠。\n沙漠快走！！！！",
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "MUS",
	IconName = "MUS_GoldenDinosaurEgg",
	PrefabBundle = "character_enemy",
	PrefabName = "MUS_GoldenDinosaurEgg",
	PrefabScale = 50,
	HPBarHeight = 130,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 1220, Gain = 244},
		{Value = 200002, Base = 25, Gain = 5},
		{Value = 200003, Base = 25, Gain = 1},
		{Value = 200004, Base = 25, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "受水元素敌人伤害 -50%\n每回合攻击 +20%，最多5次",
		Skill = {
			{
				Id = 105033,
				Value = -50,
			},
			{
				Id = 105006,
				Value = 20,
			},
		},
	},
	Tags = {
		560202,
		560203,
		560204,
		560105,
		560206,
		560207,
		560209,
		560210,
		560211,
		561203,
		561303,
		561340,
		561338,
		563102,
		563205,
		564561,
	},
}
EnemyConfig[EnemyID.Id091] =
{
	Id = 91,
	Name = "上古恐龙化石",
	Rarity = 3,
	Element = 210005,
	Style = "Dps",
	AttackType = "Melee",
	Area = 
	{
		130106,
	},
	Desc = "通过基因技术复活的恐龙化石，复活后却成了博物馆有名的捣蛋鬼。\n你不能因为自己没有蛋就捣别人的啊。",
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "MUS",
	IconName = "MUS_DinosaurFossils",
	PrefabBundle = "character_enemy",
	PrefabName = "MUS_DinosaurFossils",
	PrefabScale = 50,
	HPBarHeight = 120,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 1206, Gain = 242},
		{Value = 200002, Base = 24, Gain = 5},
		{Value = 200003, Base = 25, Gain = 1},
		{Value = 200004, Base = 25, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "有15%概率额外攻击2次\n受光元素敌人伤害 -100%",
		Skill = {
			{
				Id = 105024,
				Value = 15,
			},
			{
				Id = 105036,
				Value = -100,
			},
		},
	},
	Tags = {
		560202,
		560203,
		560204,
		560105,
		560206,
		560207,
		560209,
		560210,
		560211,
		561206,
		561303,
		561340,
		561338,
		563106,
		563204,
		564558,
	},
}
EnemyConfig[EnemyID.Id092] =
{
	Id = 92,
	Name = "右半碗代表",
	Rarity = 1,
	Element = 210001,
	Style = "Dps",
	AttackType = "Melee",
	Area = 
	{
		130108,
	},
	Desc = "活跃在博物馆各大角落的碎瓷，出自某朝右姓豪族家中，大官家道中落后也遭遇事故碎成两半，目前流落民间，以右为姓。",
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "MUS",
	IconName = "MUS_GreenBowlRight",
	PrefabBundle = "character_enemy",
	PrefabName = "MUS_GreenBowlRight",
	PrefabScale = 50,
	HPBarHeight = 100,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 1220, Gain = 244},
		{Value = 200002, Base = 25, Gain = 5},
		{Value = 200003, Base = 25, Gain = 1},
		{Value = 200004, Base = 25, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "暴击 +40",
		Skill = {
			{
				Id = 105004,
				Value = 40,
			},
		},
	},
	Tags = {
		560202,
		560203,
		560204,
		560105,
		560206,
		560207,
		560209,
		560210,
		560211,
		561202,
		561321,
		561336,
		561339,
		563106,
		563203,
		564561,
	},
}
EnemyConfig[EnemyID.Id093] =
{
	Id = 93,
	Name = "摄像头队长",
	Rarity = 2,
	Element = 210005,
	Style = "Dps",
	AttackType = "Melee",
	Area = 
	{
		130107,
	},
	Desc = "配合保安负责安保工作的机械设备，只记录画面，不记录声音，因此他们又在旁边配了一台录音机。",
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "MUS",
	IconName = "MUS_BlackCamera",
	PrefabBundle = "character_enemy",
	PrefabName = "MUS_BlackCamera",
	PrefabScale = 50,
	HPBarHeight = 110,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 860, Gain = 172},
		{Value = 200002, Base = 20, Gain = 4},
		{Value = 200003, Base = 25, Gain = 1},
		{Value = 200004, Base = 25, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "每回合对前2个队员造成100%攻击伤害\n50%概率无视敌人闪避",
		Skill = {
			{
				Id = 105040,
				Value = 100,
			},
			{
				Id = 105027,
				Value = 50,
			},
		},
	},
	Tags = {
		560202,
		560203,
		560204,
		560105,
		560206,
		560207,
		560209,
		560210,
		560211,
		561206,
		561321,
		561322,
		563105,
		563203,
		564559,
	},
}
EnemyConfig[EnemyID.Id094] =
{
	Id = 94,
	Name = "高清摄像头队长",
	Rarity = 4,
	Element = 210004,
	Style = "Dps",
	AttackType = "Melee",
	Area = 
	{
		130107,
	},
	Desc = "能够把路人脸上的毛孔都拍得一清二楚的高级摄像头，可他们又忘了加麦克风。",
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "MUS",
	IconName = "MUS_Camera",
	PrefabBundle = "character_enemy",
	PrefabName = "MUS_Camera",
	PrefabScale = 50,
	HPBarHeight = 110,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 792, Gain = 159},
		{Value = 200002, Base = 18, Gain = 4},
		{Value = 200003, Base = 25, Gain = 1},
		{Value = 200004, Base = 25, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "每回合对前3个队员造成100%攻击伤害\n80%概率无视敌人闪避",
		Skill = {
			{
				Id = 105041,
				Value = 100,
			},
			{
				Id = 105027,
				Value = 80,
			},
		},
	},
	Tags = {
		560202,
		560203,
		560204,
		560105,
		560206,
		560207,
		560209,
		560210,
		560211,
		561205,
		561321,
		561322,
		563105,
		563203,
		564559,
	},
}
EnemyConfig[EnemyID.Id095] =
{
	Id = 95,
	Name = "侦探小姐",
	Rarity = 3,
	Element = 210004,
	Style = "Dps",
	AttackType = "Melee",
	Area = 
	{
		130107,
	},
	Desc = "活跃在博物馆星的人气角色，擅长速写，仅凭描述就能画出嫌疑人。听说最近常用摄像机对着星空。莫非发现了怪盗的踪迹吗？",
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "Mus",
	IconName = "MUS_17_zhentanxiaojie",
	PrefabBundle = "character_mus",
	PrefabName = "MUS_17_zhentanxiaojie",
	SkinName = "1",
	PrefabScale = 50,
	HPBarHeight = 115,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 1223, Gain = 245},
		{Value = 200002, Base = 26, Gain = 6},
		{Value = 200003, Base = 25, Gain = 1},
		{Value = 200004, Base = 25, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "暴击 +40\n暴击伤害 +100%",
		Skill = {
			{
				Id = 105004,
				Value = 40,
			},
			{
				Id = 105038,
				Value = 100,
			},
		},
	},
	Tags = {
		564561,
	},
}
EnemyConfig[EnemyID.Id096] =
{
	Id = 96,
	Name = "祭司鸮卣",
	Rarity = 2,
	Element = 210003,
	Style = "Dps",
	AttackType = "Melee",
	Area = 
	{
		130108,
	},
	Desc = "大型青铜鼎，上面贴着古代大法师施咒的封条，里面可能藏着不得了的妖怪。\n你才是号卤！",
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "MUS",
	IconName = "MUS_WineJar",
	PrefabBundle = "character_enemy",
	PrefabName = "MUS_WineJar",
	PrefabScale = 50,
	HPBarHeight = 144,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 1187, Gain = 238},
		{Value = 200002, Base = 25, Gain = 5},
		{Value = 200003, Base = 25, Gain = 1},
		{Value = 200004, Base = 25, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "忍耐 +100\n每3回合回血 20%，最多5次",
		Skill = {
			{
				Id = 105003,
				Value = 100,
			},
			{
				Id = 105009,
				Value = 20,
			},
		},
	},
	Tags = {
		560202,
		560203,
		560204,
		560105,
		560206,
		560207,
		560209,
		560210,
		560211,
		561204,
		561321,
		561336,
		563106,
		563203,
		564560,
		564561,
	},
}
EnemyConfig[EnemyID.Id097] =
{
	Id = 97,
	Name = "祭典金鸮卣",
	Rarity = 4,
	Element = 210004,
	Style = "Dps",
	AttackType = "Melee",
	Area = 
	{
		130108,
	},
	Desc = "使用贵重的黄金制成的大鼎，只是靠近都能感到鼎内散发出不祥的气息。\n你才是金鸟回！",
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "MUS",
	IconName = "MUS_GoldenWineJar",
	PrefabBundle = "character_enemy",
	PrefabName = "MUS_GoldenWineJar",
	PrefabScale = 50,
	HPBarHeight = 120,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 1168, Gain = 234},
		{Value = 200002, Base = 25, Gain = 5},
		{Value = 200003, Base = 25, Gain = 1},
		{Value = 200004, Base = 25, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "忍耐 +100\n每3回合回血 30%，最多5次",
		Skill = {
			{
				Id = 105003,
				Value = 100,
			},
			{
				Id = 105009,
				Value = 30,
			},
		},
	},
	Tags = {
		560202,
		560203,
		560204,
		560105,
		560206,
		560207,
		560209,
		560210,
		560211,
		561205,
		561321,
		561336,
		563106,
		563203,
		564560,
		564561,
	},
}
EnemyConfig[EnemyID.Id098] =
{
	Id = 98,
	Name = "浣熊二哥",
	Rarity = 3,
	Element = 210003,
	Style = "Dps",
	AttackType = "Melee",
	Area = 
	{
		130108,
	},
	Desc = "喜欢跟着哥哥去参观博物馆的小浣熊，但每次都会因为没买票被拦在门外。他对此很气愤，因为自己并没有一米二，根本不需要买票",
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "Mus",
	IconName = "MUS_14_erge",
	PrefabBundle = "character_mus",
	PrefabName = "MUS_14_erge",
	SkinName = "1",
	PrefabScale = 50,
	HPBarHeight = 115,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 1335, Gain = 267},
		{Value = 200002, Base = 24, Gain = 5},
		{Value = 200003, Base = 25, Gain = 1},
		{Value = 200004, Base = 25, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "有15%概率额外攻击2次\n5回合后，攻击 +100%",
		Skill = {
			{
				Id = 105024,
				Value = 15,
			},
			{
				Id = 105014,
				Value = 100,
			},
		},
	},
	Tags = {
		564558,
		564561,
	},
}
EnemyConfig[EnemyID.Id099] =
{
	Id = 99,
	Name = "完整鱼化石",
	Rarity = 2,
	Element = 210001,
	Style = "Dps",
	AttackType = "Melee",
	Area = 
	{
		130109,
	},
	Desc = "来自海洋的古代鱼化石，关于上面的鱼是什么品种生物学家们至今也没有定论，所以仍然不知道到底能不能吃。",
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "MUS",
	IconName = "MUS_FishboneFossils",
	PrefabBundle = "character_enemy",
	PrefabName = "MUS_FishboneFossils",
	PrefabScale = 50,
	HPBarHeight = 100,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 1170, Gain = 234},
		{Value = 200002, Base = 25, Gain = 5},
		{Value = 200003, Base = 25, Gain = 1},
		{Value = 200004, Base = 25, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "受风元素敌人伤害 -50%\n忍耐 +100",
		Skill = {
			{
				Id = 105035,
				Value = -50,
			},
			{
				Id = 105003,
				Value = 100,
			},
		},
	},
	Tags = {
		560202,
		560203,
		560204,
		560105,
		560206,
		560207,
		560209,
		560210,
		560211,
		561202,
		561321,
		561340,
		561341,
		563103,
		563203,
		564561,
	},
}
EnemyConfig[EnemyID.Id100] =
{
	Id = 100,
	Name = "完整乌龟化石",
	Rarity = 2,
	Element = 210001,
	Style = "Dps",
	AttackType = "Melee",
	Area = 
	{
		130109,
	},
	Desc = "来自海洋的古代乌龟化石，关于它的真实年龄，科学家们至今也没有定论。",
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "MUS",
	IconName = "MUS_TortoiseFossils",
	PrefabBundle = "character_enemy",
	PrefabName = "MUS_TortoiseFossils",
	PrefabScale = 50,
	HPBarHeight = 100,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 1158, Gain = 232},
		{Value = 200002, Base = 25, Gain = 5},
		{Value = 200003, Base = 25, Gain = 1},
		{Value = 200004, Base = 25, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "受风元素敌人伤害 -50%\n忍耐 +100",
		Skill = {
			{
				Id = 105035,
				Value = -50,
			},
			{
				Id = 105003,
				Value = 100,
			},
		},
	},
	Tags = {
		560202,
		560203,
		560204,
		560105,
		560206,
		560207,
		560209,
		560210,
		560211,
		561202,
		561321,
		561340,
		561341,
		563103,
		563203,
		564561,
	},
}
EnemyConfig[EnemyID.Id101] =
{
	Id = 101,
	Name = "猪蹄古董",
	Rarity = 3,
	Element = 210003,
	Style = "Dps",
	AttackType = "Melee",
	Area = 
	{
		130109,
	},
	Desc = "好几千年以前的一只猪蹄，被考古学家找到的时候，皮肤还有弹性，可是保存技术有限，没多久就氧化了。\n因社交能力出众，目前担任博物馆宣传部长。",
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "Mus",
	IconName = "MUS_20_zhutigudong",
	PrefabBundle = "character_mus",
	PrefabName = "MUS_20_zhutigudong",
	SkinName = "1",
	PrefabScale = 50,
	HPBarHeight = 115,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 1052, Gain = 211},
		{Value = 200002, Base = 15, Gain = 3},
		{Value = 200003, Base = 25, Gain = 1},
		{Value = 200004, Base = 25, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "每3回合对所有队员造成100%攻击伤害\n每回合回血 5%，最多5次",
		Skill = {
			{
				Id = 105063,
				Value = 100,
			},
			{
				Id = 105005,
				Value = 5,
			},
		},
	},
	Tags = {
		564560,
	},
}
EnemyConfig[EnemyID.Id102] =
{
	Id = 102,
	Name = "太古碧鱬",
	Rarity = 2,
	Element = 210001,
	Style = "Dps",
	AttackType = "Melee",
	Area = 
	{
		130110,
	},
	Desc = "古代艺术家按照某种古生物的外形制作的泥塑，听老一辈说，这种生物有时候会被误认为是美人鱼，看见的人会连续一周发生与水有关的灾祸。",
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "MUS",
	IconName = "MUS_GreenMermaid",
	PrefabBundle = "character_enemy",
	PrefabName = "MUS_GreenMermaid",
	PrefabScale = 50,
	HPBarHeight = 100,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 1161, Gain = 233},
		{Value = 200002, Base = 25, Gain = 5},
		{Value = 200003, Base = 25, Gain = 1},
		{Value = 200004, Base = 25, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "对风元素敌人伤害 +100%\n对光元素敌人伤害 +100%\n对暗元素敌人伤害 +100%",
		Skill = {
			{
				Id = 105030,
				Value = 100,
			},
			{
				Id = 105031,
				Value = 100,
			},
			{
				Id = 105032,
				Value = 100,
			},
		},
	},
	Tags = {
		560202,
		560203,
		560204,
		560105,
		560206,
		560207,
		560209,
		560210,
		560211,
		561202,
		561321,
		561340,
		561342,
		563103,
		563203,
	},
}
EnemyConfig[EnemyID.Id103] =
{
	Id = 103,
	Name = "太古赤鱬",
	Rarity = 2,
	Element = 210002,
	Style = "Dps",
	AttackType = "Melee",
	Area = 
	{
		130110,
	},
	Desc = "古代艺术家按照某种古生物的外形制作的泥塑，听老一辈说，这种生物是生活在极深的海底的，看见的人一旦出海就会遇到风暴。",
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "MUS",
	IconName = "MUS_RedMermaid",
	PrefabBundle = "character_enemy",
	PrefabName = "MUS_RedMermaid",
	PrefabScale = 50,
	HPBarHeight = 100,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 1148, Gain = 230},
		{Value = 200002, Base = 25, Gain = 5},
		{Value = 200003, Base = 25, Gain = 1},
		{Value = 200004, Base = 25, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "对水元素敌人伤害 +100%\n对光元素敌人伤害 +100%\n对暗元素敌人伤害 +100%",
		Skill = {
			{
				Id = 105028,
				Value = 100,
			},
			{
				Id = 105031,
				Value = 100,
			},
			{
				Id = 105032,
				Value = 100,
			},
		},
	},
	Tags = {
		560202,
		560203,
		560204,
		560105,
		560206,
		560207,
		560209,
		560210,
		560211,
		561203,
		561321,
		561340,
		561342,
		563103,
		563203,
	},
}
EnemyConfig[EnemyID.Id104] =
{
	Id = 104,
	Name = "精英寒带龙",
	Rarity = 2,
	Element = 210001,
	Style = "Dps",
	AttackType = "Melee",
	Area = 
	{
		130111,
	},
	Desc = "拥有厚实的皮层，不畏严寒的杂食性恐龙，愤怒时会喷吐寒流冻结目标。胃寒，不能喝冷饮。",
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "MUS",
	IconName = "MUS_BlueDinosaur",
	PrefabBundle = "character_enemy",
	PrefabName = "MUS_BlueDinosaur",
	PrefabScale = 50,
	HPBarHeight = 100,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 1040, Gain = 208},
		{Value = 200002, Base = 21, Gain = 5},
		{Value = 200003, Base = 25, Gain = 1},
		{Value = 200004, Base = 25, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "每3回合对前2个队员造成150%攻击伤害\n每回合忍耐 +10，最多5次",
		Skill = {
			{
				Id = 105056,
				Value = 150,
			},
			{
				Id = 105007,
				Value = 10,
			},
		},
	},
	Tags = {
		560202,
		560203,
		560204,
		560105,
		560206,
		560207,
		560209,
		560210,
		560211,
		561202,
		561303,
		561340,
		561338,
		563102,
		563203,
		564561,
	},
}
EnemyConfig[EnemyID.Id105] =
{
	Id = 105,
	Name = "精英热带龙",
	Rarity = 3,
	Element = 210002,
	Style = "Dps",
	AttackType = "Melee",
	Area = 
	{
		130111,
	},
	Desc = "拥有厚实的皮层，不畏高温的肉食性恐龙，愤怒时会喷吐岩浆融化目标。上火，不能吃辣的。",
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "MUS",
	IconName = "MUS_RedDinosaur",
	PrefabBundle = "character_enemy",
	PrefabName = "MUS_RedDinosaur",
	PrefabScale = 50,
	HPBarHeight = 100,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 996, Gain = 200},
		{Value = 200002, Base = 20, Gain = 4},
		{Value = 200003, Base = 25, Gain = 1},
		{Value = 200004, Base = 25, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "每3回合对前2个队员造成200%攻击伤害\n每回合攻击 +15%，最多5次",
		Skill = {
			{
				Id = 105056,
				Value = 200,
			},
			{
				Id = 105006,
				Value = 15,
			},
		},
	},
	Tags = {
		560202,
		560203,
		560204,
		560105,
		560206,
		560207,
		560209,
		560210,
		560211,
		561203,
		561303,
		561340,
		561338,
		563102,
		563203,
		564561,
	},
}
EnemyConfig[EnemyID.Id106] =
{
	Id = 106,
	Name = "浣熊大哥",
	Rarity = 3,
	Element = 210002,
	Style = "Dps",
	AttackType = "Melee",
	Area = 
	{
		130111,
	},
	Desc = "特别喜欢参观博物馆的小浣熊，但每次都会因为没买票被拦在门外。他对此很气愤，因为自己有学生证，根本不需要买票。",
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "Mus",
	IconName = "MUS_13_dage",
	PrefabBundle = "character_mus",
	PrefabName = "MUS_13_dage",
	SkinName = "1",
	PrefabScale = 50,
	HPBarHeight = 115,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 1085, Gain = 217},
		{Value = 200002, Base = 24, Gain = 5},
		{Value = 200003, Base = 25, Gain = 1},
		{Value = 200004, Base = 25, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "忍耐 +100\n暴击伤害 +100%",
		Skill = {
			{
				Id = 105003,
				Value = 100,
			},
			{
				Id = 105038,
				Value = 100,
			},
		},
	},
	Tags = {
		564561,
	},
}
EnemyConfig[EnemyID.Id107] =
{
	Id = 107,
	Name = "出口队长",
	Rarity = 2,
	Element = 210005,
	Style = "Dps",
	AttackType = "Melee",
	Area = 
	{
		130112,
	},
	Desc = "指引游客离开博物馆的工作人员，什么叫安全呢？就是这个怪比较菜，新手也能打过。",
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "MUS",
	IconName = "MUS_Exit",
	PrefabBundle = "character_enemy",
	PrefabName = "MUS_Exit",
	PrefabScale = 50,
	HPBarHeight = 100,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 1113, Gain = 223},
		{Value = 200002, Base = 25, Gain = 5},
		{Value = 200003, Base = 25, Gain = 1},
		{Value = 200004, Base = 25, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "生命 +10%\n忍耐 +50",
		Skill = {
			{
				Id = 105001,
				Value = 10,
			},
			{
				Id = 105003,
				Value = 50,
			},
		},
	},
	Tags = {
		560202,
		560203,
		560204,
		560105,
		560206,
		560207,
		560209,
		560210,
		560211,
		561206,
		561321,
		561335,
		563105,
		563203,
		564561,
	},
}
EnemyConfig[EnemyID.Id108] =
{
	Id = 108,
	Name = "快陶鸭！",
	Rarity = 4,
	Element = 210003,
	Style = "Dps",
	AttackType = "Melee",
	Area = 
	{
		130112,
	},
	Desc = "速度超快的陶土鸭，只要发现情况不妙，就会立刻逃跑，非常难捕捉。",
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "MUS",
	IconName = "MUS_WoodenDuck",
	PrefabBundle = "character_enemy",
	PrefabName = "MUS_WoodenDuck",
	PrefabScale = 50,
	HPBarHeight = 120,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 916, Gain = 184},
		{Value = 200002, Base = 24, Gain = 5},
		{Value = 200003, Base = 25, Gain = 1},
		{Value = 200004, Base = 25, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "80%概率闪避攻击\n有15%概率额外攻击1次",
		Skill = {
			{
				Id = 105026,
				Value = 80,
			},
			{
				Id = 105023,
				Value = 15,
			},
		},
	},
	Tags = {
		560202,
		560203,
		560204,
		560105,
		560206,
		560207,
		560209,
		560210,
		560211,
		561204,
		561303,
		561340,
		563106,
		563206,
		564557,
		564558,
	},
}
EnemyConfig[EnemyID.Id109] =
{
	Id = 109,
	Name = "独耳画像",
	Rarity = 4,
	Element = 210003,
	Style = "Dps",
	AttackType = "Melee",
	Area = 
	{
		130112,
	},
	Desc = "来自博物馆星的独耳画家，是用充满生命力的创作激情点燃了一整个时代的优秀画家。笔下的每一件事物都仿佛被注入了生命一般。",
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "Mus",
	IconName = "MUS_08_fangao",
	PrefabBundle = "character_mus",
	PrefabName = "MUS_08_fangao",
	SkinName = "1",
	PrefabScale = 50,
	HPBarHeight = 115,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 1048, Gain = 210},
		{Value = 200002, Base = 24, Gain = 5},
		{Value = 200003, Base = 25, Gain = 1},
		{Value = 200004, Base = 25, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "每3回合回血 30%，最多5次\n每回合攻击 +15%，最多5次",
		Skill = {
			{
				Id = 105009,
				Value = 30,
			},
			{
				Id = 105006,
				Value = 15,
			},
		},
	},
	Tags = {
		564560,
		564561,
	},
}
EnemyConfig[EnemyID.Id110] =
{
	Id = 110,
	Name = "流浪三花猫",
	Rarity = 1,
	Element = 210003,
	Style = "Dps",
	AttackType = "Melee",
	Area = 
	{
		130151,
	},
	Desc = "活跃在悬疑星的花猫，喜欢在安全的地方散步，如果路上发生状况，就会蹲在一边舔着舌头看热闹。\n它的舌头并没有三种花色。",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "SUS",
	IconName = "SUS_ColorfulCat",
	PrefabBundle = "character_enemy",
	PrefabName = "SUS_ColourfulCat",
	PrefabScale = 50,
	HPBarHeight = 100,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 1303, Gain = 261},
		{Value = 200002, Base = 30, Gain = 6},
		{Value = 200003, Base = 25, Gain = 1},
		{Value = 200004, Base = 25, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "33%概率闪避攻击\n有15%概率额外攻击1次",
		Skill = {
			{
				Id = 105026,
				Value = 33,
			},
			{
				Id = 105023,
				Value = 15,
			},
		},
	},
	Tags = {
		560202,
		560203,
		560204,
		560205,
		560106,
		560207,
		560209,
		560210,
		560211,
		561204,
		561303,
		561346,
		563106,
		563205,
		564557,
		564558,
	},
}
EnemyConfig[EnemyID.Id111] =
{
	Id = 111,
	Name = "告白情书",
	Rarity = 2,
	Element = 210003,
	Style = "Dps",
	AttackType = "Melee",
	Area = 
	{
		130152,
	},
	Desc = "为人们传递情意的信件，读的时候会起一身的鸡皮疙瘩，因此很棘手。",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "SUS",
	IconName = "SUS_LoveLetter",
	PrefabBundle = "character_enemy",
	PrefabName = "SUS_LoveLetter",
	PrefabScale = 50,
	HPBarHeight = 100,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 1384, Gain = 277},
		{Value = 200002, Base = 31, Gain = 7},
		{Value = 200003, Base = 25, Gain = 1},
		{Value = 200004, Base = 25, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "暴击 +40",
		Skill = {
			{
				Id = 105004,
				Value = 40,
			},
		},
	},
	Tags = {
		560202,
		560203,
		560204,
		560205,
		560106,
		560207,
		560209,
		560210,
		560211,
		561204,
		561321,
		561343,
		563103,
		563203,
		564561,
	},
}
EnemyConfig[EnemyID.Id112] =
{
	Id = 112,
	Name = "粉红女士",
	Rarity = 2,
	Element = 210001,
	Style = "Dps",
	AttackType = "Melee",
	Area = 
	{
		130152,
	},
	Desc = "喜欢下午和好朋友一起去逛街的帽子小姐，经常会卷入案件中。",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "SUS",
	IconName = "SUS_PinkHat",
	PrefabBundle = "character_enemy",
	PrefabName = "SUS_PinkHat",
	PrefabScale = 50,
	HPBarHeight = 100,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 1370, Gain = 274},
		{Value = 200002, Base = 31, Gain = 7},
		{Value = 200003, Base = 25, Gain = 1},
		{Value = 200004, Base = 25, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "暴击 +40\n暴击伤害 +50%",
		Skill = {
			{
				Id = 105004,
				Value = 40,
			},
			{
				Id = 105038,
				Value = 50,
			},
		},
	},
	Tags = {
		560202,
		560203,
		560204,
		560205,
		560106,
		560207,
		560209,
		560210,
		560211,
		561202,
		561344,
		561345,
		561703,
		563104,
		563203,
		564561,
	},
}
EnemyConfig[EnemyID.Id113] =
{
	Id = 113,
	Name = "网红邮筒",
	Rarity = 3,
	Element = 210002,
	Style = "Dps",
	AttackType = "Melee",
	Area = 
	{
		130152,
	},
	Desc = "帮助附近居民寄出邮件的重要设施，最讨厌被人骂邮筒腰。",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "SUS",
	IconName = "SUS_MailBox",
	PrefabBundle = "character_enemy",
	PrefabName = "SUS_MailBox",
	PrefabScale = 50,
	HPBarHeight = 130,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 1370, Gain = 274},
		{Value = 200002, Base = 31, Gain = 7},
		{Value = 200003, Base = 25, Gain = 1},
		{Value = 200004, Base = 25, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "生命 +50%\n攻击 +25%",
		Skill = {
			{
				Id = 105001,
				Value = 50,
			},
			{
				Id = 105002,
				Value = 25,
			},
		},
	},
	Tags = {
		560202,
		560203,
		560204,
		560205,
		560106,
		560207,
		560209,
		560210,
		560211,
		561203,
		561344,
		561345,
		563105,
		563203,
		564561,
	},
}
EnemyConfig[EnemyID.Id114] =
{
	Id = 114,
	Name = "报童",
	Rarity = 1,
	Element = 210002,
	Style = "Dps",
	AttackType = "Melee",
	Area = 
	{
		130152,
	},
	Desc = "在悬疑星各大街道活动的报童，拥有大量未经证实的惊天消息。比如动物园老虎逃出笼子，且27人已遇害。\n事实是房东太太的猫散步时，被27人围着撸。",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	IconName = "Sus_17_baotong",
	PrefabBundle = "character_sus",
	PrefabName = "Sus_17_baotong",
	SkinName = "1",
	PrefabScale = 50,
	HPBarHeight = 112,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 1209, Gain = 242},
		{Value = 200002, Base = 30, Gain = 6},
		{Value = 200003, Base = 25, Gain = 1},
		{Value = 200004, Base = 25, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "50%概率闪避攻击\n受到的暴击伤害 -50%",
		Skill = {
			{
				Id = 105026,
				Value = 50,
			},
			{
				Id = 105039,
				Value = -50,
			},
		},
	},
	Tags = {
		564557,
	},
}
EnemyConfig[EnemyID.Id115] =
{
	Id = 115,
	Name = "重磅新闻",
	Rarity = 2,
	Element = 210003,
	Style = "Dps",
	AttackType = "Melee",
	Area = 
	{
		130153,
	},
	Desc = "常驻咖啡馆的报纸先生，会把今天的新闻登在身上，让别人阅读。\n有没有人提醒一下，他拿反了。",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "SUS",
	IconName = "SUS_Newspaper",
	PrefabBundle = "character_enemy",
	PrefabName = "SUS_Newspaper",
	PrefabScale = 50,
	HPBarHeight = 100,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 1311, Gain = 263},
		{Value = 200002, Base = 30, Gain = 6},
		{Value = 200003, Base = 25, Gain = 1},
		{Value = 200004, Base = 25, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "暴击伤害 +200%\n受到的暴击伤害 -50%",
		Skill = {
			{
				Id = 105038,
				Value = 200,
			},
			{
				Id = 105039,
				Value = -50,
			},
		},
	},
	Tags = {
		560202,
		560203,
		560204,
		560205,
		560106,
		560207,
		560209,
		560210,
		560211,
		561204,
		561321,
		561343,
		563103,
		563203,
	},
}
EnemyConfig[EnemyID.Id116] =
{
	Id = 116,
	Name = "帽子绅士",
	Rarity = 3,
	Element = 210001,
	Style = "Dps",
	AttackType = "Melee",
	Area = 
	{
		130153,
	},
	Desc = "喜欢下午独自一人去咖啡店的帽子先生，非常绅士，会替女性遮挡阳光。",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "SUS",
	IconName = "SUS_BlackHat",
	PrefabBundle = "character_enemy",
	PrefabName = "SUS_BlackHat",
	PrefabScale = 50,
	HPBarHeight = 100,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 1298, Gain = 260},
		{Value = 200002, Base = 30, Gain = 6},
		{Value = 200003, Base = 25, Gain = 1},
		{Value = 200004, Base = 25, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "受风元素敌人伤害 -50%\n受暗元素敌人伤害 -50%",
		Skill = {
			{
				Id = 105035,
				Value = -50,
			},
			{
				Id = 105037,
				Value = -50,
			},
		},
	},
	Tags = {
		560202,
		560203,
		560204,
		560205,
		560106,
		560207,
		560209,
		560210,
		560211,
		561202,
		561344,
		561345,
		561702,
		563104,
		563203,
	},
}
EnemyConfig[EnemyID.Id117] =
{
	Id = 117,
	Name = "阿加莎",
	Rarity = 3,
	Element = 210001,
	Style = "Dps",
	AttackType = "Melee",
	Area = 
	{
		130153,
	},
	Desc = "悬疑星当红的推理女王，严谨的侦探小说家，每天都在构思新点子。如果想到新颖的作案手法，会自己先尝试一下。",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	IconName = "Sus_30_ajiasha",
	PrefabBundle = "character_sus",
	PrefabName = "Sus_30_ajiasha",
	SkinName = "1",
	PrefabScale = 50,
	HPBarHeight = 112,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 1229, Gain = 246},
		{Value = 200002, Base = 26, Gain = 6},
		{Value = 200003, Base = 25, Gain = 1},
		{Value = 200004, Base = 25, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "攻击 +33%\n每3回合对前3个队员造成75%攻击伤害",
		Skill = {
			{
				Id = 105002,
				Value = 33,
			},
			{
				Id = 105057,
				Value = 75,
			},
		},
	},
	Tags = {
		564561,
	},
}
EnemyConfig[EnemyID.Id118] =
{
	Id = 118,
	Name = "进口羽毛笔",
	Rarity = 2,
	Element = 210003,
	Style = "Dps",
	AttackType = "Melee",
	Area = 
	{
		130154,
	},
	Desc = "羽毛笔很喜欢现在的工作，在从鸟身上掉下来之前，它并没有想到自己的人生还能有第二春。",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "SUS",
	IconName = "SUS_FeatherPen",
	PrefabBundle = "character_enemy",
	PrefabName = "SUS_FeatherPen",
	PrefabScale = 50,
	HPBarHeight = 110,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 1360, Gain = 272},
		{Value = 200002, Base = 29, Gain = 6},
		{Value = 200003, Base = 25, Gain = 1},
		{Value = 200004, Base = 25, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "有15%概率额外攻击2次",
		Skill = {
			{
				Id = 105024,
				Value = 15,
			},
		},
	},
	Tags = {
		560202,
		560203,
		560204,
		560205,
		560106,
		560207,
		560209,
		560210,
		560211,
		561204,
		561321,
		561348,
		563104,
		563203,
		564558,
	},
}
EnemyConfig[EnemyID.Id119] =
{
	Id = 119,
	Name = "纪念邮票",
	Rarity = 2,
	Element = 210001,
	Style = "Dps",
	AttackType = "Melee",
	Area = 
	{
		130154,
	},
	Desc = "性格强硬，坚持把每一个舔它的人都以性骚扰的罪名告上了法庭。",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "SUS",
	IconName = "SUS_Stamp",
	PrefabBundle = "character_enemy",
	PrefabName = "SUS_Stamp",
	PrefabScale = 50,
	HPBarHeight = 100,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 1254, Gain = 251},
		{Value = 200002, Base = 30, Gain = 6},
		{Value = 200003, Base = 25, Gain = 1},
		{Value = 200004, Base = 25, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "33%概率闪避攻击",
		Skill = {
			{
				Id = 105026,
				Value = 33,
			},
		},
	},
	Tags = {
		560202,
		560203,
		560204,
		560205,
		560106,
		560207,
		560209,
		560210,
		560211,
		561202,
		561321,
		561343,
		563104,
		563203,
		564557,
	},
}
EnemyConfig[EnemyID.Id120] =
{
	Id = 120,
	Name = "精致信封",
	Rarity = 3,
	Element = 210003,
	Style = "Dps",
	AttackType = "Melee",
	Area = 
	{
		130154,
	},
	Desc = "性格有些古怪，经常自言自语，会被周围的人所害怕。\n哦，想出来吗？哈哈！真可惜啊，你是绝对不可能突破我的封锁的！信！",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "SUS",
	IconName = "SUS_Letter",
	PrefabBundle = "character_enemy",
	PrefabName = "SUS_Letter",
	PrefabScale = 50,
	HPBarHeight = 100,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 1343, Gain = 269},
		{Value = 200002, Base = 30, Gain = 6},
		{Value = 200003, Base = 25, Gain = 1},
		{Value = 200004, Base = 25, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "每回合忍耐 +20，最多5次\n每回合暴击 +40，最多5次",
		Skill = {
			{
				Id = 105007,
				Value = 20,
			},
			{
				Id = 105008,
				Value = 40,
			},
		},
	},
	Tags = {
		560202,
		560203,
		560204,
		560205,
		560106,
		560207,
		560209,
		560210,
		560211,
		561204,
		561321,
		561343,
		563103,
		563203,
		564561,
	},
}
EnemyConfig[EnemyID.Id121] =
{
	Id = 121,
	Name = "侦探助理",
	Rarity = 3,
	Element = 210003,
	Style = "Dps",
	AttackType = "Melee",
	Area = 
	{
		130154,
	},
	Desc = "大侦探不可或缺的好伙伴，总是能够在合适的时机提出观众心中的疑问，让大侦探顺理成章地讲解案情。会在事件发生第一时间询问大侦探的看法。",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	IconName = "Sus_02_huasheng",
	PrefabBundle = "character_sus",
	PrefabName = "Sus_02_huasheng",
	SkinName = "1",
	PrefabScale = 50,
	HPBarHeight = 112,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 1264, Gain = 253},
		{Value = 200002, Base = 30, Gain = 6},
		{Value = 200003, Base = 25, Gain = 1},
		{Value = 200004, Base = 25, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "生命 +50%\n每回合回血 10%，最多5次",
		Skill = {
			{
				Id = 105001,
				Value = 50,
			},
			{
				Id = 105005,
				Value = 10,
			},
		},
	},
	Tags = {
		564560,
		564561,
	},
}
EnemyConfig[EnemyID.Id122] =
{
	Id = 122,
	Name = "可疑门牌",
	Rarity = 2,
	Element = 210003,
	Style = "Dps",
	AttackType = "Melee",
	Area = 
	{
		130155,
	},
	Desc = "经常溜到案件现场看热闹的门牌先生，有时候会发表自己的高见,由于顶着自己的住址而总是会泄露个人信息。",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "SUS",
	IconName = "SUS_NumberPlate",
	PrefabBundle = "character_enemy",
	PrefabName = "SUS_NumberPlate",
	PrefabScale = 50,
	HPBarHeight = 100,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 1327, Gain = 266},
		{Value = 200002, Base = 30, Gain = 6},
		{Value = 200003, Base = 25, Gain = 1},
		{Value = 200004, Base = 25, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "生命 +10%\n忍耐 +50",
		Skill = {
			{
				Id = 105001,
				Value = 10,
			},
			{
				Id = 105003,
				Value = 50,
			},
		},
	},
	Tags = {
		560202,
		560203,
		560204,
		560205,
		560106,
		560207,
		560209,
		560210,
		560211,
		561204,
		561321,
		561335,
		563105,
		563203,
		564561,
	},
}
EnemyConfig[EnemyID.Id123] =
{
	Id = 123,
	Name = "可疑路障",
	Rarity = 2,
	Element = 210005,
	Style = "Dps",
	AttackType = "Melee",
	Area = 
	{
		130155,
	},
	Desc = "经常被放置在工地使用的黄黑警用路障，因为颜色本身就比较脏的关系，所以很耐脏。",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "SUS",
	IconName = "SUS_YellowBarrier",
	PrefabBundle = "character_enemy",
	PrefabName = "SUS_YellowBarrier",
	PrefabScale = 50,
	HPBarHeight = 110,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 1311, Gain = 263},
		{Value = 200002, Base = 30, Gain = 6},
		{Value = 200003, Base = 25, Gain = 1},
		{Value = 200004, Base = 25, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "受光元素敌人伤害 -50%\n对暗元素敌人伤害 +100%",
		Skill = {
			{
				Id = 105036,
				Value = -50,
			},
			{
				Id = 105032,
				Value = 100,
			},
		},
	},
	Tags = {
		560202,
		560203,
		560204,
		560205,
		560106,
		560207,
		560209,
		560210,
		560211,
		561206,
		561321,
		561337,
		563106,
		563203,
	},
}
EnemyConfig[EnemyID.Id124] =
{
	Id = 124,
	Name = "流浪白猫",
	Rarity = 3,
	Element = 210004,
	Style = "Dps",
	AttackType = "Melee",
	Area = 
	{
		130155,
	},
	Desc = "行动非常敏捷的白色猫咪，经常在悬疑星各大咖啡馆出没，偶尔也会出现在无人的街道上。",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "SUS",
	IconName = "SUS_WhiteCat",
	PrefabBundle = "character_enemy",
	PrefabName = "SUS_WhiteCat",
	PrefabScale = 50,
	HPBarHeight = 100,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 1049, Gain = 210},
		{Value = 200002, Base = 29, Gain = 6},
		{Value = 200003, Base = 25, Gain = 1},
		{Value = 200004, Base = 25, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "50%概率闪避攻击\n有15%概率额外攻击1次\n50%概率无视敌人闪避",
		Skill = {
			{
				Id = 105026,
				Value = 50,
			},
			{
				Id = 105023,
				Value = 15,
			},
			{
				Id = 105027,
				Value = 50,
			},
		},
	},
	Tags = {
		560202,
		560203,
		560204,
		560205,
		560106,
		560207,
		560209,
		560210,
		560211,
		561205,
		561303,
		561346,
		563106,
		563206,
		564557,
		564558,
		564559,
	},
}
EnemyConfig[EnemyID.Id125] =
{
	Id = 125,
	Name = "可疑煤气灯",
	Rarity = 3,
	Element = 210002,
	Style = "Dps",
	AttackType = "Melee",
	Area = 
	{
		130155,
	},
	Desc = "安装在大街上提供行人照明的设施，性格火爆，一点就炸。\n然后就没有然后了。",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "SUS",
	IconName = "SUS_StreetLamp",
	PrefabBundle = "character_enemy",
	PrefabName = "SUS_StreetLamp",
	PrefabScale = 50,
	HPBarHeight = 140,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 1088, Gain = 218},
		{Value = 200002, Base = 14, Gain = 3},
		{Value = 200003, Base = 25, Gain = 1},
		{Value = 200004, Base = 25, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "每回合对所有队员造成100%攻击伤害\n对暗元素敌人伤害 +100%",
		Skill = {
			{
				Id = 105047,
				Value = 100,
			},
			{
				Id = 105032,
				Value = 100,
			},
		},
	},
	Tags = {
		560202,
		560203,
		560204,
		560205,
		560106,
		560207,
		560209,
		560210,
		560211,
		561203,
		561321,
		561353,
		561322,
		563105,
		563203,
	},
}
EnemyConfig[EnemyID.Id126] =
{
	Id = 126,
	Name = "窨井守卫者",
	Rarity = 2,
	Element = 210005,
	Style = "Dps",
	AttackType = "Melee",
	Area = 
	{
		130156,
	},
	Desc = "勤恳踏实的底层员工，最大的梦想是有朝一日不被人踩在脸上。",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "SUS",
	IconName = "SUS_ManholeCover",
	PrefabBundle = "character_enemy",
	PrefabName = "SUS_ManholeCover",
	PrefabScale = 50,
	HPBarHeight = 100,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 1170, Gain = 234},
		{Value = 200002, Base = 23, Gain = 5},
		{Value = 200003, Base = 25, Gain = 1},
		{Value = 200004, Base = 25, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "受水元素敌人伤害 -50%\n每3回合对前3个队员造成150%攻击伤害",
		Skill = {
			{
				Id = 105033,
				Value = -50,
			},
			{
				Id = 105057,
				Value = 150,
			},
		},
	},
	Tags = {
		560202,
		560203,
		560204,
		560205,
		560106,
		560207,
		560209,
		560210,
		560211,
		561206,
		561321,
		561354,
		563105,
		563205,
	},
}
EnemyConfig[EnemyID.Id127] =
{
	Id = 127,
	Name = "路障队长",
	Rarity = 3,
	Element = 210002,
	Style = "Dps",
	AttackType = "Melee",
	Area = 
	{
		130156,
	},
	Desc = "警方设置在禁行区的路障，有时会被不知从何处来的僵尸偷走。",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "SUS",
	IconName = "SUS_RedBarrier",
	PrefabBundle = "character_enemy",
	PrefabName = "SUS_RedBarrier",
	PrefabScale = 50,
	HPBarHeight = 110,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 1265, Gain = 253},
		{Value = 200002, Base = 30, Gain = 6},
		{Value = 200003, Base = 25, Gain = 1},
		{Value = 200004, Base = 25, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "受水元素敌人伤害 -50%\n受光元素敌人伤害 -50%\n受暗元素敌人伤害 -50%",
		Skill = {
			{
				Id = 105033,
				Value = -50,
			},
			{
				Id = 105036,
				Value = -50,
			},
			{
				Id = 105037,
				Value = -50,
			},
		},
	},
	Tags = {
		560202,
		560203,
		560204,
		560205,
		560106,
		560207,
		560209,
		560210,
		560211,
		561203,
		561321,
		561337,
		563106,
		563203,
	},
}
EnemyConfig[EnemyID.Id128] =
{
	Id = 128,
	Name = "消防队长",
	Rarity = 4,
	Element = 210001,
	Style = "Dps",
	AttackType = "Melee",
	Area = 
	{
		130156,
	},
	Desc = "只要简单操作就能为外接设备持续供水的设施，是街道消防必不可少的好伙伴。",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "SUS",
	IconName = "SUS_Hydrant",
	PrefabBundle = "character_enemy",
	PrefabName = "SUS_Hydrant",
	PrefabScale = 50,
	HPBarHeight = 120,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 1138, Gain = 228},
		{Value = 200002, Base = 24, Gain = 5},
		{Value = 200003, Base = 25, Gain = 1},
		{Value = 200004, Base = 25, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "每3回合对前2个队员造成200%攻击伤害\n每回合攻击 +10%，最多5次",
		Skill = {
			{
				Id = 105056,
				Value = 200,
			},
			{
				Id = 105006,
				Value = 10,
			},
		},
	},
	Tags = {
		560202,
		560203,
		560204,
		560205,
		560106,
		560207,
		560209,
		560210,
		560211,
		561202,
		561321,
		561337,
		561322,
		563105,
		563203,
		564561,
	},
}
EnemyConfig[EnemyID.Id129] =
{
	Id = 129,
	Name = "死者",
	Rarity = 3,
	Element = 210001,
	Style = "Dps",
	AttackType = "Melee",
	Area = 
	{
		130156,
	},
	Desc = "往往第一个被排除嫌疑的角色，但是世事无绝对。如果所有出场的嫌疑人都遇害了，那么一定要再重新检查一遍死者。",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	IconName = "Sus_12_sizhe",
	PrefabBundle = "character_sus",
	PrefabName = "Sus_12_sizhe",
	SkinName = "1",
	PrefabScale = 50,
	HPBarHeight = 129,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 1194, Gain = 239},
		{Value = 200002, Base = 30, Gain = 6},
		{Value = 200003, Base = 25, Gain = 1},
		{Value = 200004, Base = 25, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "每回合回血 5%，最多5次\n每3回合回血 15%，最多5次\n忍耐 +50",
		Skill = {
			{
				Id = 105005,
				Value = 5,
			},
			{
				Id = 105009,
				Value = 15,
			},
			{
				Id = 105003,
				Value = 50,
			},
		},
	},
	Tags = {
		564560,
		564561,
	},
}
EnemyConfig[EnemyID.Id130] =
{
	Id = 130,
	Name = "超硬烟灰缸",
	Rarity = 2,
	Element = 210003,
	Style = "Dps",
	AttackType = "Melee",
	Area = 
	{
		130157,
	},
	Desc = "城市的治安有多大压力，烟灰缸中就有多少烟头。在这座城市的警局中，烟灰缸也用自己的方式维持着治安。",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "SUS",
	IconName = "SUS_Ashtray",
	PrefabBundle = "character_enemy",
	PrefabName = "SUS_Ashtray",
	PrefabScale = 50,
	HPBarHeight = 100,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 1256, Gain = 252},
		{Value = 200002, Base = 30, Gain = 6},
		{Value = 200003, Base = 25, Gain = 1},
		{Value = 200004, Base = 25, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "受火元素敌人伤害 -100%",
		Skill = {
			{
				Id = 105034,
				Value = -100,
			},
		},
	},
	Tags = {
		560202,
		560203,
		560204,
		560205,
		560106,
		560207,
		560209,
		560210,
		560211,
		561204,
		561321,
		561348,
		563106,
		563203,
	},
}
EnemyConfig[EnemyID.Id131] =
{
	Id = 131,
	Name = "超合金手铐",
	Rarity = 2,
	Element = 210004,
	Style = "Dps",
	AttackType = "Melee",
	Area = 
	{
		130157,
	},
	Desc = "对于一名罪犯来说，手腕粗得铐不住是一件很丢脸的事。",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "SUS",
	IconName = "SUS_Handcuffs",
	PrefabBundle = "character_enemy",
	PrefabName = "SUS_Handcuffs",
	PrefabScale = 50,
	HPBarHeight = 110,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 1130, Gain = 226},
		{Value = 200002, Base = 24, Gain = 5},
		{Value = 200003, Base = 25, Gain = 1},
		{Value = 200004, Base = 25, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "每3回合对前2个队员造成200%攻击伤害\n对暗元素敌人伤害 +100%",
		Skill = {
			{
				Id = 105056,
				Value = 200,
			},
			{
				Id = 105032,
				Value = 100,
			},
		},
	},
	Tags = {
		560202,
		560203,
		560204,
		560205,
		560106,
		560207,
		560209,
		560210,
		560211,
		561205,
		561321,
		561348,
		563106,
		563203,
	},
}
EnemyConfig[EnemyID.Id132] =
{
	Id = 132,
	Name = "手工打火机",
	Rarity = 3,
	Element = 210002,
	Style = "Dps",
	AttackType = "Melee",
	Area = 
	{
		130157,
	},
	Desc = "成功取代了火柴的新型点火装置，是烟草爱好者必不可少的道具。经常被设计成各种形状，枪械、钟表、乐器，还有香烟。",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "SUS",
	IconName = "SUS_CigaretteLighter",
	PrefabBundle = "character_enemy",
	PrefabName = "SUS_CigaretteLighter",
	PrefabScale = 50,
	HPBarHeight = 100,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 1206, Gain = 242},
		{Value = 200002, Base = 30, Gain = 6},
		{Value = 200003, Base = 25, Gain = 1},
		{Value = 200004, Base = 25, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "每回合回血 10%，最多5次\n每回合攻击 +10%，最多5次",
		Skill = {
			{
				Id = 105005,
				Value = 10,
			},
			{
				Id = 105006,
				Value = 10,
			},
		},
	},
	Tags = {
		560202,
		560203,
		560204,
		560205,
		560106,
		560207,
		560209,
		560210,
		560211,
		561203,
		561321,
		561348,
		563106,
		563203,
		564560,
		564561,
	},
}
EnemyConfig[EnemyID.Id133] =
{
	Id = 133,
	Name = "蓝衣小学生",
	Rarity = 4,
	Element = 210001,
	Style = "Dps",
	AttackType = "Melee",
	Area = 
	{
		130157,
	},
	Desc = "蓝星著名的高中生侦探的远房表弟，本来是初中生，因意外变成小学生。这个意外听上去是那么得不可思议，但不知为何大家都是以一幅理解的表情表示释然。",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	IconName = "Sus_20_lanyixiaoxuesheng",
	PrefabBundle = "character_sus",
	PrefabName = "Sus_20_lanyixiaoxuesheng",
	SkinName = "1",
	PrefabScale = 50,
	HPBarHeight = 112,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 1233, Gain = 247},
		{Value = 200002, Base = 30, Gain = 6},
		{Value = 200003, Base = 25, Gain = 1},
		{Value = 200004, Base = 25, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "暴击 +80\n暴击伤害 +150%",
		Skill = {
			{
				Id = 105004,
				Value = 80,
			},
			{
				Id = 105038,
				Value = 150,
			},
		},
	},
	Tags = {
		564561,
	},
}
EnemyConfig[EnemyID.Id134] =
{
	Id = 134,
	Name = "超清相片",
	Rarity = 2,
	Element = 210003,
	Style = "Dps",
	AttackType = "Melee",
	Area = 
	{
		130158,
	},
	Desc = "只是用来记录某一时刻湖面的相片，在悬疑星却往往能将深藏多年的某段关系揭示出来。",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "SUS",
	IconName = "SUS_Photo",
	PrefabBundle = "character_enemy",
	PrefabName = "SUS_Photo",
	PrefabScale = 50,
	HPBarHeight = 100,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 1250, Gain = 250},
		{Value = 200002, Base = 30, Gain = 6},
		{Value = 200003, Base = 25, Gain = 1},
		{Value = 200004, Base = 25, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "生命 +50%\n对暗元素敌人伤害 +100%",
		Skill = {
			{
				Id = 105001,
				Value = 50,
			},
			{
				Id = 105032,
				Value = 100,
			},
		},
	},
	Tags = {
		560202,
		560203,
		560204,
		560205,
		560106,
		560207,
		560209,
		560210,
		560211,
		561204,
		561321,
		561343,
		563104,
		563203,
		564561,
	},
}
EnemyConfig[EnemyID.Id135] =
{
	Id = 135,
	Name = "超分贝报警器",
	Rarity = 2,
	Element = 210004,
	Style = "Dps",
	AttackType = "Melee",
	Area = 
	{
		130158,
	},
	Desc = "警笛鸣起时，治安官们将迅速通过拥挤路段，直达罪案发生的所在，而鸣响的正义之音也将使罪恶无所遁形。",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "SUS",
	IconName = "SUS_Alarm",
	PrefabBundle = "character_enemy",
	PrefabName = "SUS_Alarm",
	PrefabScale = 50,
	HPBarHeight = 100,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 1200, Gain = 240},
		{Value = 200002, Base = 21, Gain = 5},
		{Value = 200003, Base = 25, Gain = 1},
		{Value = 200004, Base = 25, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "每回合对前3个队员造成100%攻击伤害\n5回合后，攻击 +100%",
		Skill = {
			{
				Id = 105041,
				Value = 100,
			},
			{
				Id = 105014,
				Value = 100,
			},
		},
	},
	Tags = {
		560202,
		560203,
		560204,
		560205,
		560106,
		560207,
		560209,
		560210,
		560211,
		561205,
		561321,
		561322,
		561348,
		563106,
		563203,
		564561,
	},
}
EnemyConfig[EnemyID.Id136] =
{
	Id = 136,
	Name = "死者手机",
	Rarity = 3,
	Element = 210005,
	Style = "Dps",
	AttackType = "Melee",
	Area = 
	{
		130158,
	},
	Desc = "犯罪现场遗留下来的手机，被害人还来不及翻开盖子就遇害了。这个教训告诉我们要买智能机。",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "SUS",
	IconName = "SUS_MobilePhone",
	PrefabBundle = "character_enemy",
	PrefabName = "SUS_MobilePhone",
	PrefabScale = 50,
	HPBarHeight = 100,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 1145, Gain = 229},
		{Value = 200002, Base = 25, Gain = 5},
		{Value = 200003, Base = 25, Gain = 1},
		{Value = 200004, Base = 25, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "每3回合对后2个队员造成100%攻击伤害",
		Skill = {
			{
				Id = 105060,
				Value = 100,
			},
		},
	},
	Tags = {
		560202,
		560203,
		560204,
		560205,
		560106,
		560207,
		560209,
		560210,
		560211,
		561206,
		561321,
		561322,
		561348,
		563106,
		563203,
	},
}
EnemyConfig[EnemyID.Id137] =
{
	Id = 137,
	Name = "天价勒索信",
	Rarity = 4,
	Element = 210005,
	Style = "Dps",
	AttackType = "Melee",
	Area = 
	{
		130158,
	},
	Desc = "当这封充满恶意的信件出现在家里时，往往说明你珍爱的某件东西可能落到别人手中。",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "SUS",
	IconName = "SUS_ExtortionMail",
	PrefabBundle = "character_enemy",
	PrefabName = "SUS_ExtortionMail",
	PrefabScale = 50,
	HPBarHeight = 100,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 1169, Gain = 234},
		{Value = 200002, Base = 29, Gain = 6},
		{Value = 200003, Base = 25, Gain = 1},
		{Value = 200004, Base = 25, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "生命 +100%\n暴击伤害 +200%",
		Skill = {
			{
				Id = 105001,
				Value = 100,
			},
			{
				Id = 105038,
				Value = 200,
			},
		},
	},
	Tags = {
		560202,
		560203,
		560204,
		560205,
		560106,
		560207,
		560209,
		560210,
		560211,
		561206,
		561321,
		561343,
		563103,
		563203,
		564561,
	},
}
EnemyConfig[EnemyID.Id138] =
{
	Id = 138,
	Name = "进口蓝墨水",
	Rarity = 2,
	Element = 210001,
	Style = "Dps",
	AttackType = "Melee",
	Area = 
	{
		130159,
	},
	Desc = "使用贝壳和藻类制成的蓝色液体，通常用来记录信息类的文字，对海鲜过敏的人请务必谨慎使用。",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "SUS",
	IconName = "SUS_BlueInk",
	PrefabBundle = "character_enemy",
	PrefabName = "SUS_BlueInk",
	PrefabScale = 50,
	HPBarHeight = 100,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 898, Gain = 180},
		{Value = 200002, Base = 24, Gain = 5},
		{Value = 200003, Base = 25, Gain = 1},
		{Value = 200004, Base = 25, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "100%概率无视敌人闪避\n每3回合对前3个队员造成100%攻击伤害",
		Skill = {
			{
				Id = 105027,
				Value = 100,
			},
			{
				Id = 105057,
				Value = 100,
			},
		},
	},
	Tags = {
		560202,
		560203,
		560204,
		560205,
		560106,
		560207,
		560209,
		560210,
		560211,
		561202,
		561321,
		561350,
		561347,
		563103,
		563203,
		564559,
	},
}
EnemyConfig[EnemyID.Id139] =
{
	Id = 139,
	Name = "进口红墨水",
	Rarity = 3,
	Element = 210001,
	Style = "Dps",
	AttackType = "Melee",
	Area = 
	{
		130159,
	},
	Desc = "使用花卉和矿石制成的红色液体，通常用来书写警示类的文字，有时会在杀手游戏中被当作鲜血道具使用。",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "SUS",
	IconName = "SUS_RedInk",
	PrefabBundle = "character_enemy",
	PrefabName = "SUS_RedInk",
	PrefabScale = 50,
	HPBarHeight = 100,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 889, Gain = 178},
		{Value = 200002, Base = 17, Gain = 4},
		{Value = 200003, Base = 25, Gain = 1},
		{Value = 200004, Base = 25, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "100%概率无视敌人闪避\n每3回合对所有队员造成100%攻击伤害",
		Skill = {
			{
				Id = 105027,
				Value = 100,
			},
			{
				Id = 105063,
				Value = 100,
			},
		},
	},
	Tags = {
		560202,
		560203,
		560204,
		560205,
		560106,
		560207,
		560209,
		560210,
		560211,
		561202,
		561321,
		561350,
		561347,
		563103,
		563203,
		564559,
	},
}
EnemyConfig[EnemyID.Id140] =
{
	Id = 140,
	Name = "证人",
	Rarity = 3,
	Element = 210002,
	Style = "Dps",
	AttackType = "Melee",
	Area = 
	{
		130159,
	},
	Desc = "热衷于推理的居民，梦想成为侦探，拥有过目不忘的本领。不过每次应询去警局录口供时，都会从警察嘴里套出案情，想要自己破案。",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	IconName = "Sus_08_zhenren",
	PrefabBundle = "character_sus",
	PrefabName = "Sus_08_zhenren",
	SkinName = "1",
	PrefabScale = 50,
	HPBarHeight = 123,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 1149, Gain = 230},
		{Value = 200002, Base = 29, Gain = 6},
		{Value = 200003, Base = 25, Gain = 1},
		{Value = 200004, Base = 25, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "每回合忍耐 +100，最多5次\n每回合暴击 +40，最多5次\n暴击伤害 +100%",
		Skill = {
			{
				Id = 105007,
				Value = 100,
			},
			{
				Id = 105008,
				Value = 40,
			},
			{
				Id = 105038,
				Value = 100,
			},
		},
	},
	Tags = {
		564561,
	},
}
EnemyConfig[EnemyID.Id141] =
{
	Id = 141,
	Name = "可疑手铐",
	Rarity = 2,
	Element = 210005,
	Style = "Dps",
	AttackType = "Melee",
	Area = 
	{
		130160,
	},
	Desc = "本来是逮捕罪犯的工具，但是它却经常出现在莫名其妙的地方……\n我们这是全年龄向游戏。",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "SUS",
	IconName = "SUS_PatternHandcuffs",
	PrefabBundle = "character_enemy",
	PrefabName = "SUS_PatternHandcuffs",
	PrefabScale = 50,
	HPBarHeight = 110,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 1030, Gain = 206},
		{Value = 200002, Base = 23, Gain = 5},
		{Value = 200003, Base = 25, Gain = 1},
		{Value = 200004, Base = 25, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "每3回合对前2个队员造成200%攻击伤害\n对光元素敌人伤害 +100%",
		Skill = {
			{
				Id = 105056,
				Value = 200,
			},
			{
				Id = 105031,
				Value = 100,
			},
		},
	},
	Tags = {
		560202,
		560203,
		560204,
		560205,
		560106,
		560207,
		560209,
		560210,
		560211,
		561206,
		561321,
		561348,
		563106,
		563203,
	},
}
EnemyConfig[EnemyID.Id142] =
{
	Id = 142,
	Name = "可疑行李车",
	Rarity = 4,
	Element = 210002,
	Style = "Dps",
	AttackType = "Melee",
	Area = 
	{
		130160,
	},
	Desc = "旅店运送行李的工具，这辆车本身并不是行李。",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "SUS",
	IconName = "SUS_Luggage",
	PrefabBundle = "character_enemy",
	PrefabName = "SUS_Luggage",
	PrefabScale = 50,
	HPBarHeight = 130,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 1133, Gain = 227},
		{Value = 200002, Base = 29, Gain = 6},
		{Value = 200003, Base = 25, Gain = 1},
		{Value = 200004, Base = 25, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "生命 +50%\n攻击 +25%",
		Skill = {
			{
				Id = 105001,
				Value = 50,
			},
			{
				Id = 105002,
				Value = 25,
			},
		},
	},
	Tags = {
		560202,
		560203,
		560204,
		560205,
		560106,
		560207,
		560209,
		560210,
		560211,
		561203,
		561321,
		561348,
		563105,
		563205,
		564561,
	},
}
EnemyConfig[EnemyID.Id143] =
{
	Id = 143,
	Name = "精装水果笔记",
	Rarity = 2,
	Element = 210003,
	Style = "Dps",
	AttackType = "Melee",
	Area = 
	{
		130161,
	},
	Desc = "记录着大量水果资料的笔记本，不知道打算用来做什么用。",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "SUS",
	IconName = "SUS_BrownNoteBook",
	PrefabBundle = "character_enemy",
	PrefabName = "SUS_BrownNoteBook",
	PrefabScale = 50,
	HPBarHeight = 100,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 1164, Gain = 233},
		{Value = 200002, Base = 29, Gain = 6},
		{Value = 200003, Base = 25, Gain = 1},
		{Value = 200004, Base = 25, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "受光元素敌人伤害 -50%\n受暗元素敌人伤害 -50%",
		Skill = {
			{
				Id = 105036,
				Value = -50,
			},
			{
				Id = 105037,
				Value = -50,
			},
		},
	},
	Tags = {
		560202,
		560203,
		560204,
		560205,
		560106,
		560207,
		560209,
		560210,
		560211,
		561204,
		561321,
		561343,
		563106,
		563203,
	},
}
EnemyConfig[EnemyID.Id144] =
{
	Id = 144,
	Name = "精装蔬菜笔记",
	Rarity = 3,
	Element = 210002,
	Style = "Dps",
	AttackType = "Melee",
	Area = 
	{
		130161,
	},
	Desc = "记录着大量蔬菜资料的笔记本，不知道打算用来做什么用。",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "SUS",
	IconName = "SUS_RedNotebook",
	PrefabBundle = "character_enemy",
	PrefabName = "SUS_RedNotebook",
	PrefabScale = 50,
	HPBarHeight = 100,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 1149, Gain = 230},
		{Value = 200002, Base = 29, Gain = 6},
		{Value = 200003, Base = 25, Gain = 1},
		{Value = 200004, Base = 25, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "受水元素敌人伤害 -50%\n受火元素敌人伤害 -50%\n受风元素敌人伤害 -50%",
		Skill = {
			{
				Id = 105033,
				Value = -50,
			},
			{
				Id = 105034,
				Value = -50,
			},
			{
				Id = 105035,
				Value = -50,
			},
		},
	},
	Tags = {
		560202,
		560203,
		560204,
		560205,
		560106,
		560207,
		560209,
		560210,
		560211,
		561203,
		561321,
		561343,
		563106,
		563203,
	},
}
EnemyConfig[EnemyID.Id145] =
{
	Id = 145,
	Name = "编辑长",
	Rarity = 2,
	Element = 210002,
	Style = "Dps",
	AttackType = "Melee",
	Area = 
	{
		130161,
	},
	Desc = "认真负责的编辑长，为了不辜负读者，每天都在兢兢业业地工作。每5分钟都会联系约稿作家，防止对方放水。",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	IconName = "Sus_22_bianji",
	PrefabBundle = "character_sus",
	PrefabName = "Sus_22_bianji",
	SkinName = "1",
	PrefabScale = 50,
	HPBarHeight = 112,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 1185, Gain = 237},
		{Value = 200002, Base = 29, Gain = 6},
		{Value = 200003, Base = 25, Gain = 1},
		{Value = 200004, Base = 25, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "5回合后，回血 50%\n5回合后，攻击 +50%",
		Skill = {
			{
				Id = 105013,
				Value = 50,
			},
			{
				Id = 105014,
				Value = 50,
			},
		},
	},
	Tags = {
		564560,
		564561,
	},
}
EnemyConfig[EnemyID.Id146] =
{
	Id = 146,
	Name = "高倍放大镜",
	Rarity = 2,
	Element = 210004,
	Style = "Dps",
	AttackType = "Melee",
	Area = 
	{
		130162,
	},
	Desc = "侦探们的好朋友，有时候没什么用，但是拿出来会让人觉得很有侦探的派头。",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "SUS",
	IconName = "SUS_Magnifier",
	PrefabBundle = "character_enemy",
	PrefabName = "SUS_Magnifier",
	PrefabScale = 50,
	HPBarHeight = 110,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 1145, Gain = 229},
		{Value = 200002, Base = 29, Gain = 6},
		{Value = 200003, Base = 25, Gain = 1},
		{Value = 200004, Base = 25, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "每回合攻击 +10%，最多5次",
		Skill = {
			{
				Id = 105006,
				Value = 10,
			},
		},
	},
	Tags = {
		560202,
		560203,
		560204,
		560205,
		560106,
		560207,
		560209,
		560210,
		560211,
		561205,
		561321,
		561353,
		561348,
		563106,
		563203,
		564561,
	},
}
EnemyConfig[EnemyID.Id147] =
{
	Id = 147,
	Name = "祖传怀表",
	Rarity = 2,
	Element = 210003,
	Style = "Dps",
	AttackType = "Melee",
	Area = 
	{
		130162,
	},
	Desc = "很有绅士风度的怀表，对时间的准头很讲究，具有催眠效果，可以让老板觉得自己没有迟到。",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "SUS",
	IconName = "SUS_PocketWatch",
	PrefabBundle = "character_enemy",
	PrefabName = "SUS_PocketWatch",
	PrefabScale = 50,
	HPBarHeight = 100,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 1107, Gain = 222},
		{Value = 200002, Base = 28, Gain = 6},
		{Value = 200003, Base = 25, Gain = 1},
		{Value = 200004, Base = 25, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "5回合后，回血 50%\n有15%概率额外攻击1次",
		Skill = {
			{
				Id = 105013,
				Value = 50,
			},
			{
				Id = 105023,
				Value = 15,
			},
		},
	},
	Tags = {
		560202,
		560203,
		560204,
		560205,
		560106,
		560207,
		560209,
		560210,
		560211,
		561204,
		561321,
		561348,
		561322,
		563106,
		563203,
		564558,
		564560,
	},
}
EnemyConfig[EnemyID.Id148] =
{
	Id = 148,
	Name = "祖传烟斗",
	Rarity = 3,
	Element = 210002,
	Style = "Dps",
	AttackType = "Melee",
	Area = 
	{
		130162,
	},
	Desc = "很喜欢和路人聊天攀谈的烟斗，如果聊天对象是侦探们的话，会开心得冒起烟来。",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "SUS",
	IconName = "SUS_Pipe",
	PrefabBundle = "character_enemy",
	PrefabName = "SUS_Pipe",
	PrefabScale = 50,
	HPBarHeight = 100,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 1081, Gain = 217},
		{Value = 200002, Base = 29, Gain = 6},
		{Value = 200003, Base = 25, Gain = 1},
		{Value = 200004, Base = 25, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "每回合攻击 +10%，最多5次\n20%概率闪避攻击",
		Skill = {
			{
				Id = 105006,
				Value = 10,
			},
			{
				Id = 105026,
				Value = 20,
			},
		},
	},
	Tags = {
		560202,
		560203,
		560204,
		560205,
		560106,
		560207,
		560209,
		560210,
		560211,
		561203,
		561321,
		561348,
		563106,
		563203,
		564557,
		564561,
	},
}
EnemyConfig[EnemyID.Id149] =
{
	Id = 149,
	Name = "凶手",
	Rarity = 3,
	Element = 210005,
	Style = "Dps",
	AttackType = "Melee",
	Area = 
	{
		130162,
	},
	Desc = "令人闻风丧胆的凶手，没人知道ta的身份。只要ta出现，大家就会放弃抵抗落荒而逃，然后露出破绽，被他轻易击杀。",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	IconName = "Sus_28_heiyiren",
	PrefabBundle = "character_sus",
	PrefabName = "Sus_28_heiyiren",
	SkinName = "1",
	PrefabScale = 50,
	HPBarHeight = 112,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 997, Gain = 200},
		{Value = 200002, Base = 29, Gain = 6},
		{Value = 200003, Base = 25, Gain = 1},
		{Value = 200004, Base = 25, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "33%概率闪避攻击\n暴击 +40\n20%概率无视敌人闪避",
		Skill = {
			{
				Id = 105026,
				Value = 33,
			},
			{
				Id = 105004,
				Value = 40,
			},
			{
				Id = 105027,
				Value = 20,
			},
		},
	},
	Tags = {
		564557,
		564559,
		564561,
	},
}
EnemyConfig[EnemyID.Id150] =
{
	Id = 150,
	Name = "现场血迹",
	Rarity = 2,
	Element = 210005,
	Style = "Dps",
	AttackType = "Melee",
	Area = 
	{
		130163,
	},
	Desc = "生物身体中必不可少的关键液体，不过有些生物个体看到它时会不自觉地晕倒。",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "SUS",
	IconName = "SUS_Blood",
	PrefabBundle = "character_enemy",
	PrefabName = "SUS_Blood",
	PrefabScale = 50,
	HPBarHeight = 100,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 1066, Gain = 214},
		{Value = 200002, Base = 29, Gain = 6},
		{Value = 200003, Base = 25, Gain = 1},
		{Value = 200004, Base = 25, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "生命 +30%\n每回合回血 5%，最多5次",
		Skill = {
			{
				Id = 105001,
				Value = 30,
			},
			{
				Id = 105005,
				Value = 5,
			},
		},
	},
	Tags = {
		560202,
		560203,
		560204,
		560205,
		560106,
		560207,
		560209,
		560210,
		560211,
		561206,
		561321,
		561340,
		563103,
		563203,
		564560,
		564561,
	},
}
EnemyConfig[EnemyID.Id151] =
{
	Id = 151,
	Name = "恐怖黑猫",
	Rarity = 3,
	Element = 210005,
	Style = "Dps",
	AttackType = "Melee",
	Area = 
	{
		130163,
	},
	Desc = "神秘的黑色猫咪，经常出现在事故现场，会不会是死神的凡间化身呢？",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "SUS",
	IconName = "SUS_BlackCat",
	PrefabBundle = "character_enemy",
	PrefabName = "SUS_BlackCat",
	PrefabScale = 50,
	HPBarHeight = 100,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 863, Gain = 173},
		{Value = 200002, Base = 28, Gain = 6},
		{Value = 200003, Base = 25, Gain = 1},
		{Value = 200004, Base = 25, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "50%概率闪避攻击\n有15%概率额外攻击1次\n50%概率无视敌人闪避",
		Skill = {
			{
				Id = 105026,
				Value = 50,
			},
			{
				Id = 105023,
				Value = 15,
			},
			{
				Id = 105027,
				Value = 50,
			},
		},
	},
	Tags = {
		560202,
		560203,
		560204,
		560205,
		560106,
		560207,
		560209,
		560210,
		560211,
		561206,
		561303,
		561346,
		563106,
		563205,
		564557,
		564558,
		564559,
	},
}
EnemyConfig[EnemyID.Id152] =
{
	Id = 152,
	Name = "最强大脑",
	Rarity = 4,
	Element = 210001,
	Style = "Dps",
	AttackType = "Melee",
	Area = 
	{
		130163,
	},
	Desc = "实验室特别存保存下来的生物大脑，其中存储着大量重要的信息。",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "SUS",
	IconName = "SUS_Brain",
	PrefabBundle = "character_enemy",
	PrefabName = "SUS_Brain",
	PrefabScale = 50,
	HPBarHeight = 120,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 1027, Gain = 206},
		{Value = 200002, Base = 28, Gain = 6},
		{Value = 200003, Base = 25, Gain = 1},
		{Value = 200004, Base = 25, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "每3回合回血 20%，最多5次\n生命 +50%\n暴击 +40",
		Skill = {
			{
				Id = 105009,
				Value = 20,
			},
			{
				Id = 105001,
				Value = 50,
			},
			{
				Id = 105004,
				Value = 40,
			},
		},
	},
	Tags = {
		560202,
		560203,
		560204,
		560205,
		560106,
		560207,
		560209,
		560210,
		560211,
		561202,
		561321,
		561350,
		561340,
		563106,
		563203,
		564560,
		564561,
	},
}
EnemyConfig[EnemyID.Id153] =
{
	Id = 153,
	Name = "迈克罗夫特",
	Rarity = 4,
	Element = 210001,
	Style = "Dps",
	AttackType = "Melee",
	Area = 
	{
		130163,
	},
	Desc = "可能是这个世界上智商最高的人，对推理没有什么兴趣。时间都花在了保护爱闯祸的弟弟身上。",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	IconName = "Sus_19_maikaofu",
	PrefabBundle = "character_sus",
	PrefabName = "Sus_19_maikaofu",
	SkinName = "1",
	PrefabScale = 50,
	HPBarHeight = 112,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 961, Gain = 193},
		{Value = 200002, Base = 24, Gain = 5},
		{Value = 200003, Base = 25, Gain = 1},
		{Value = 200004, Base = 25, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "每3回合对后2个队员造成100%攻击伤害\n30%概率闪避攻击\n5回合后，攻击 +25%",
		Skill = {
			{
				Id = 105060,
				Value = 100,
			},
			{
				Id = 105026,
				Value = 30,
			},
			{
				Id = 105014,
				Value = 25,
			},
		},
	},
	Tags = {
		564557,
		564561,
	},
}
EnemyConfig[EnemyID.Id154] =
{
	Id = 154,
	Name = "绿草草",
	Rarity = 1,
	Element = 210003,
	Style = "Dps",
	AttackType = "Melee",
	Area = 
	{
		130201,
	},
	Desc = "完全没有一点主见的绿色海草，别人说什么就是什么，因此常常被其他鱼吐槽“绿草草，随风倒”。",
	IconBundle = "atlas_charactericon_sea",
	IconAtlas = "Sea",
	IconName = "SEA_Laminria1",
	PrefabBundle = "character_enemy",
	PrefabName = "SEA_Laminria1",
	PrefabScale = 50,
	HPBarHeight = 100,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 903, Gain = 181},
		{Value = 200002, Base = 29, Gain = 6},
		{Value = 200003, Base = 25, Gain = 1},
		{Value = 200004, Base = 25, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "50%概率闪避攻击\n每2回合对末位队员造成120%攻击伤害",
		Skill = {
			{
				Id = 105026,
				Value = 50,
			},
			{
				Id = 105051,
				Value = 120,
			},
		},
	},
	Tags = {
		560202,
		560203,
		560204,
		560205,
		560206,
		560107,
		560209,
		560210,
		560211,
		561204,
		561355,
		561358,
		563102,
		563203,
		564557,
	},
}
EnemyConfig[EnemyID.Id155] =
{
	Id = 155,
	Name = "海豚凛",
	Rarity = 3,
	Element = 210001,
	Style = "Dps",
	AttackType = "Melee",
	Area = 
	{
		130201,
	},
	Desc = "具有超高的唱歌天赋，温驯海族，能唱出直击心灵的歌曲，希望能凭借努力成为闪闪发光的偶像。然而，偶像的道路并不会一帆风顺……",
	IconBundle = "atlas_charactericon_sea",
	IconAtlas = "Sea",
	IconName = "Sea_17_haitun",
	PrefabBundle = "character_sea",
	PrefabName = "Sea_17_haitun",
	SkinName = "1",
	PrefabScale = 50,
	HPBarHeight = 112,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 743, Gain = 149},
		{Value = 200002, Base = 22, Gain = 5},
		{Value = 200003, Base = 25, Gain = 1},
		{Value = 200004, Base = 25, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "100%概率无视敌人闪避\n每回合对前3个队员造成80%攻击伤害\n每回合回血 5%，最多5次",
		Skill = {
			{
				Id = 105027,
				Value = 100,
			},
			{
				Id = 105041,
				Value = 80,
			},
			{
				Id = 105005,
				Value = 5,
			},
		},
	},
	Tags = {
		564559,
		564560,
	},
}
EnemyConfig[EnemyID.Id156] =
{
	Id = 156,
	Name = "梅子紫",
	Rarity = 2,
	Element = 210001,
	Style = "Dps",
	AttackType = "Melee",
	Area = 
	{
		130202,
	},
	Desc = "海底自助化妆师，珊瑚红的同事，不过TA带来的是梅子紫系的全套妆容，一次150海洋币。",
	IconBundle = "atlas_charactericon_sea",
	IconAtlas = "Sea",
	IconName = "SEA_Coral1",
	PrefabBundle = "character_enemy",
	PrefabName = "SEA_Coral1",
	PrefabScale = 50,
	HPBarHeight = 100,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 1064, Gain = 213},
		{Value = 200002, Base = 29, Gain = 6},
		{Value = 200003, Base = 25, Gain = 1},
		{Value = 200004, Base = 25, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "回合中，每次受击，攻击 +1%\n回合中，每次受击，忍耐 +5",
		Skill = {
			{
				Id = 105170,
				Value = 1,
			},
			{
				Id = 105171,
				Value = 5,
			},
		},
	},
	Tags = {
		560202,
		560203,
		560204,
		560205,
		560206,
		560107,
		560209,
		560210,
		560211,
		561202,
		561355,
		561359,
		563104,
		563202,
		564561,
	},
}
EnemyConfig[EnemyID.Id157] =
{
	Id = 157,
	Name = "珊瑚红",
	Rarity = 2,
	Element = 210002,
	Style = "Dps",
	AttackType = "Melee",
	Area = 
	{
		130202,
	},
	Desc = "海底自助化妆师，只要摸摸TA的头，TA就会突然窜出来，并迅速完成一套珊瑚红系的完美妆容，一次只要100海洋币。",
	IconBundle = "atlas_charactericon_sea",
	IconAtlas = "Sea",
	IconName = "SEA_Coral2",
	PrefabBundle = "character_enemy",
	PrefabName = "SEA_Coral2",
	PrefabScale = 50,
	HPBarHeight = 100,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 1048, Gain = 210},
		{Value = 200002, Base = 29, Gain = 6},
		{Value = 200003, Base = 25, Gain = 1},
		{Value = 200004, Base = 25, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "回合中，每次受击，攻击 +1%\n每回合回血 8%，最多5次\n暴击伤害 +50%",
		Skill = {
			{
				Id = 105170,
				Value = 1,
			},
			{
				Id = 105005,
				Value = 8,
			},
			{
				Id = 105038,
				Value = 50,
			},
		},
	},
	Tags = {
		560202,
		560203,
		560204,
		560205,
		560206,
		560107,
		560209,
		560210,
		560211,
		561203,
		561355,
		561359,
		563104,
		563202,
		564560,
		564561,
	},
}
EnemyConfig[EnemyID.Id158] =
{
	Id = 158,
	Name = "红贝壳",
	Rarity = 2,
	Element = 210002,
	Style = "Dps",
	AttackType = "Melee",
	Area = 
	{
		130203,
	},
	Desc = "据说是海底世界的百事通，被评价为“海里的全知道，海外的知道一半”，不过，这真的是客观评价吗？",
	IconBundle = "atlas_charactericon_sea",
	IconAtlas = "Sea",
	IconName = "SEA_Pectinid2",
	PrefabBundle = "character_enemy",
	PrefabName = "SEA_Pectinid2",
	PrefabScale = 50,
	HPBarHeight = 130,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 1068, Gain = 214},
		{Value = 200002, Base = 28, Gain = 6},
		{Value = 200003, Base = 25, Gain = 1},
		{Value = 200004, Base = 25, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "生命 +100%\n每回合攻击 +10%，最多5次",
		Skill = {
			{
				Id = 105001,
				Value = 100,
			},
			{
				Id = 105006,
				Value = 10,
			},
		},
	},
	Tags = {
		560202,
		560203,
		560204,
		560205,
		560206,
		560107,
		560209,
		560210,
		560211,
		561203,
		561355,
		561360,
		563104,
		563202,
		564561,
	},
}
EnemyConfig[EnemyID.Id159] =
{
	Id = 159,
	Name = "黄贝壳",
	Rarity = 3,
	Element = 210004,
	Style = "Dps",
	AttackType = "Melee",
	Area = 
	{
		130203,
	},
	Desc = "红贝壳的好友，当红贝壳的坑蒙拐骗被拆穿时，TA就负责出来收拾残局。",
	IconBundle = "atlas_charactericon_sea",
	IconAtlas = "Sea",
	IconName = "SEA_Pectinid1",
	PrefabBundle = "character_enemy",
	PrefabName = "SEA_Pectinid1",
	PrefabScale = 50,
	HPBarHeight = 100,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 1060, Gain = 212},
		{Value = 200002, Base = 28, Gain = 6},
		{Value = 200003, Base = 25, Gain = 1},
		{Value = 200004, Base = 25, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "忍耐 +150\n每回合攻击 +10%，最多5次",
		Skill = {
			{
				Id = 105003,
				Value = 150,
			},
			{
				Id = 105006,
				Value = 10,
			},
		},
	},
	Tags = {
		560202,
		560203,
		560204,
		560205,
		560206,
		560107,
		560209,
		560210,
		560211,
		561205,
		561355,
		561360,
		563104,
		563202,
		564561,
	},
}
EnemyConfig[EnemyID.Id160] =
{
	Id = 160,
	Name = "鱿鱼",
	Rarity = 2,
	Element = 210001,
	Style = "Dps",
	AttackType = "Melee",
	Area = 
	{
		130204,
	},
	Desc = "具有八条长腿，能狠狠吸住休息厅的地毯，谁都不能把TA拖走。",
	IconBundle = "atlas_charactericon_sea",
	IconAtlas = "Sea",
	IconName = "SEA_Inkfish",
	PrefabBundle = "character_enemy",
	PrefabName = "SEA_Inkfish",
	PrefabScale = 50,
	HPBarHeight = 100,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 957, Gain = 192},
		{Value = 200002, Base = 21, Gain = 5},
		{Value = 200003, Base = 25, Gain = 1},
		{Value = 200004, Base = 25, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "每回合对前2个队员造成60%攻击伤害\n有100%概率额外攻击1次",
		Skill = {
			{
				Id = 105040,
				Value = 60,
			},
			{
				Id = 105023,
				Value = 100,
			},
		},
	},
	Tags = {
		560202,
		560203,
		560204,
		560205,
		560206,
		560107,
		560209,
		560210,
		560211,
		561202,
		561356,
		561361,
		563102,
		563204,
		564558,
	},
}
EnemyConfig[EnemyID.Id161] =
{
	Id = 161,
	Name = "章鱼",
	Rarity = 4,
	Element = 210005,
	Style = "Dps",
	AttackType = "Melee",
	Area = 
	{
		130204,
	},
	Desc = "精通伪装，不仅可以伪装自己的形态，还能把别人的声音模仿得惟妙惟肖。",
	IconBundle = "atlas_charactericon_sea",
	IconAtlas = "Sea",
	IconName = "SEA_Octupas1",
	PrefabBundle = "character_enemy",
	PrefabName = "SEA_Octupas1",
	PrefabScale = 50,
	HPBarHeight = 100,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 936, Gain = 188},
		{Value = 200002, Base = 17, Gain = 4},
		{Value = 200003, Base = 25, Gain = 1},
		{Value = 200004, Base = 25, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "每回合对前3个队员造成50%攻击伤害\n有100%概率额外攻击2次",
		Skill = {
			{
				Id = 105041,
				Value = 50,
			},
			{
				Id = 105024,
				Value = 100,
			},
		},
	},
	Tags = {
		560202,
		560203,
		560204,
		560205,
		560206,
		560107,
		560209,
		560210,
		560211,
		561206,
		561356,
		561361,
		563102,
		563204,
		564558,
	},
}
EnemyConfig[EnemyID.Id162] =
{
	Id = 162,
	Name = "刺豚茉白",
	Rarity = 3,
	Element = 210004,
	Style = "Dps",
	AttackType = "Melee",
	Area = 
	{
		130204,
	},
	Desc = "过去是深潜FoRever成员，温驯海族，不开心的时候会无法控制地在腮帮子里吹气，整个身体也会变得膨胀。因此，现在还在努力学习如何控制情绪中。",
	IconBundle = "atlas_charactericon_sea",
	IconAtlas = "Sea",
	IconName = "Sea_27_hetun",
	PrefabBundle = "character_sea",
	PrefabName = "Sea_27_hetun",
	SkinName = "1",
	PrefabScale = 50,
	HPBarHeight = 112,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 970, Gain = 194},
		{Value = 200002, Base = 28, Gain = 6},
		{Value = 200003, Base = 25, Gain = 1},
		{Value = 200004, Base = 25, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "受到的暴击伤害 -50%\n回合中，每次受击，攻击 +4%\n每3回合回血 25%，最多5次",
		Skill = {
			{
				Id = 105039,
				Value = -50,
			},
			{
				Id = 105170,
				Value = 4,
			},
			{
				Id = 105009,
				Value = 25,
			},
		},
	},
	Tags = {
		564560,
		564561,
	},
}
EnemyConfig[EnemyID.Id163] =
{
	Id = 163,
	Name = "红草草",
	Rarity = 1,
	Element = 210002,
	Style = "Dps",
	AttackType = "Melee",
	Area = 
	{
		130205,
	},
	Desc = "一颗毫无主见的红色海草，随波飘摇，虽然没有依据，但很多人坚信TA和绿草草是一家人。",
	IconBundle = "atlas_charactericon_sea",
	IconAtlas = "Sea",
	IconName = "SEA_Laminria2",
	PrefabBundle = "character_enemy",
	PrefabName = "SEA_Laminria2",
	PrefabScale = 50,
	HPBarHeight = 100,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 830, Gain = 166},
		{Value = 200002, Base = 28, Gain = 6},
		{Value = 200003, Base = 25, Gain = 1},
		{Value = 200004, Base = 25, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "66%概率闪避攻击\n每2回合对末位队员造成120%攻击伤害",
		Skill = {
			{
				Id = 105026,
				Value = 66,
			},
			{
				Id = 105051,
				Value = 120,
			},
		},
	},
	Tags = {
		560202,
		560203,
		560204,
		560205,
		560206,
		560107,
		560209,
		560210,
		560211,
		561203,
		561355,
		561358,
		563102,
		563203,
		564557,
	},
}
EnemyConfig[EnemyID.Id164] =
{
	Id = 164,
	Name = "海参",
	Rarity = 2,
	Element = 210001,
	Style = "Dps",
	AttackType = "Melee",
	Area = 
	{
		130205,
	},
	Desc = "热爱和同伴玩喷水游戏，但总是会喷出一些奇怪的东西。",
	IconBundle = "atlas_charactericon_sea",
	IconAtlas = "Sea",
	IconName = "SEA_SeaCucumber1",
	PrefabBundle = "character_enemy",
	PrefabName = "SEA_SeaCucumber1",
	PrefabScale = 50,
	HPBarHeight = 110,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 1022, Gain = 205},
		{Value = 200002, Base = 28, Gain = 6},
		{Value = 200003, Base = 25, Gain = 1},
		{Value = 200004, Base = 25, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "生命 +100%\n每回合回血 5%，最多5次",
		Skill = {
			{
				Id = 105001,
				Value = 100,
			},
			{
				Id = 105005,
				Value = 5,
			},
		},
	},
	Tags = {
		560202,
		560203,
		560204,
		560205,
		560206,
		560107,
		560209,
		560210,
		560211,
		561202,
		561355,
		561361,
		563102,
		563202,
		564560,
		564561,
	},
}
EnemyConfig[EnemyID.Id165] =
{
	Id = 165,
	Name = "火山海参",
	Rarity = 3,
	Element = 210002,
	Style = "Dps",
	AttackType = "Melee",
	Area = 
	{
		130205,
	},
	Desc = "是海参中的奇异物种，紧张或过于兴奋时会喷射出岩浆，一到冬天，许多鱼都会慕名过来取暖。",
	IconBundle = "atlas_charactericon_sea",
	IconAtlas = "Sea",
	IconName = "SEA_SeaCucumber2",
	PrefabBundle = "character_enemy",
	PrefabName = "SEA_SeaCucumber2",
	PrefabScale = 50,
	HPBarHeight = 120,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 1015, Gain = 203},
		{Value = 200002, Base = 28, Gain = 6},
		{Value = 200003, Base = 25, Gain = 1},
		{Value = 200004, Base = 25, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "生命 +120%\n每回合回血 5%，最多5次\n每回合攻击 +10%，最多5次",
		Skill = {
			{
				Id = 105001,
				Value = 120,
			},
			{
				Id = 105005,
				Value = 5,
			},
			{
				Id = 105006,
				Value = 10,
			},
		},
	},
	Tags = {
		560202,
		560203,
		560204,
		560205,
		560206,
		560107,
		560209,
		560210,
		560211,
		561203,
		561355,
		561361,
		563102,
		563202,
		564560,
		564561,
	},
}
EnemyConfig[EnemyID.Id166] =
{
	Id = 166,
	Name = "乌贼墨",
	Rarity = 3,
	Element = 210005,
	Style = "Dps",
	AttackType = "Melee",
	Area = 
	{
		130205,
	},
	Desc = "Aquarius中的一员，凶猛海族，拥有制造墨色雾气舞台效果的绝技，因此收获了众多粉丝的喜爱。热爱吃瓜，对于鱼乐圈的八卦了如指掌。",
	IconBundle = "atlas_charactericon_sea",
	IconAtlas = "Sea",
	IconName = "Sea_03_moyu",
	PrefabBundle = "character_sea",
	PrefabName = "Sea_03_moyu",
	SkinName = "1",
	PrefabScale = 50,
	HPBarHeight = 112,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 898, Gain = 180},
		{Value = 200002, Base = 24, Gain = 5},
		{Value = 200003, Base = 25, Gain = 1},
		{Value = 200004, Base = 25, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "受到的暴击伤害 -50%\n每3回合，100%概率闪避攻击\n每回合对前2个队员造成75%攻击伤害",
		Skill = {
			{
				Id = 105039,
				Value = -50,
			},
			{
				Id = 105140,
				Value = 100,
			},
			{
				Id = 105040,
				Value = 75,
			},
		},
	},
	Tags = {
		564557,
	},
}
EnemyConfig[EnemyID.Id167] =
{
	Id = 167,
	Name = "绿礁保安",
	Rarity = 2,
	Element = 210003,
	Style = "Dps",
	AttackType = "Melee",
	Area = 
	{
		130206,
	},
	Desc = "穿着绿色制服的保安，保卫礁石区一方平安，会对危害公共安全的危险分子，会毫不留情发射藤壶。",
	IconBundle = "atlas_charactericon_sea",
	IconAtlas = "Sea",
	IconName = "SEA_Ston1",
	PrefabBundle = "character_enemy",
	PrefabName = "SEA_Stone1",
	PrefabScale = 50,
	HPBarHeight = 100,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 950, Gain = 190},
		{Value = 200002, Base = 28, Gain = 6},
		{Value = 200003, Base = 25, Gain = 1},
		{Value = 200004, Base = 25, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "忍耐 +150\n每2回合对末位队员造成100%攻击伤害",
		Skill = {
			{
				Id = 105003,
				Value = 150,
			},
			{
				Id = 105051,
				Value = 100,
			},
		},
	},
	Tags = {
		560202,
		560203,
		560204,
		560205,
		560206,
		560107,
		560209,
		560210,
		560211,
		561204,
		561356,
		561325,
		563105,
		563202,
		564561,
	},
}
EnemyConfig[EnemyID.Id168] =
{
	Id = 168,
	Name = "蓝礁保安",
	Rarity = 3,
	Element = 210001,
	Style = "Dps",
	AttackType = "Melee",
	Area = 
	{
		130206,
	},
	Desc = "穿着蓝色制服的保安，比起发射远程武器，更喜欢用喇叭大喊大叫，用声波击退敌人。",
	IconBundle = "atlas_charactericon_sea",
	IconAtlas = "Sea",
	IconName = "SEA_Stone2",
	PrefabBundle = "character_enemy",
	PrefabName = "SEA_Stone2",
	PrefabScale = 50,
	HPBarHeight = 100,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 1020, Gain = 204},
		{Value = 200002, Base = 27, Gain = 6},
		{Value = 200003, Base = 25, Gain = 1},
		{Value = 200004, Base = 25, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "忍耐 +150\n有33%概率额外攻击1次",
		Skill = {
			{
				Id = 105003,
				Value = 150,
			},
			{
				Id = 105023,
				Value = 33,
			},
		},
	},
	Tags = {
		560202,
		560203,
		560204,
		560205,
		560206,
		560107,
		560209,
		560210,
		560211,
		561202,
		561356,
		561325,
		563105,
		563202,
		564558,
		564561,
	},
}
EnemyConfig[EnemyID.Id169] =
{
	Id = 169,
	Name = "比目司机",
	Rarity = 2,
	Element = 210003,
	Style = "Dps",
	AttackType = "Melee",
	Area = 
	{
		130207,
	},
	Desc = "常年行驶在星光小道的司机，因为两只眼睛都长在左边，所以只能看到左边的路。",
	IconBundle = "atlas_charactericon_sea",
	IconAtlas = "Sea",
	IconName = "SEA_Flatfish",
	PrefabBundle = "character_enemy",
	PrefabName = "SEA_Flatfish",
	PrefabScale = 50,
	HPBarHeight = 100,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 1012, Gain = 203},
		{Value = 200002, Base = 26, Gain = 6},
		{Value = 200003, Base = 25, Gain = 1},
		{Value = 200004, Base = 25, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "有50%概率额外攻击1次\n暴击 +150",
		Skill = {
			{
				Id = 105023,
				Value = 50,
			},
			{
				Id = 105004,
				Value = 150,
			},
		},
	},
	Tags = {
		560202,
		560203,
		560204,
		560205,
		560206,
		560107,
		560209,
		560210,
		560211,
		561204,
		561355,
		561328,
		563104,
		563205,
		564558,
		564561,
	},
}
EnemyConfig[EnemyID.Id170] =
{
	Id = 170,
	Name = "小丑司机",
	Rarity = 3,
	Element = 210001,
	Style = "Dps",
	AttackType = "Melee",
	Area = 
	{
		130207,
	},
	Desc = "星光小道的司机，有时候无法控制自己的行动，会下意识把乘客带去海葵的区域。",
	IconBundle = "atlas_charactericon_sea",
	IconAtlas = "Sea",
	IconName = "SEA_Nemo",
	PrefabBundle = "character_enemy",
	PrefabName = "SEA_Nemo",
	PrefabScale = 50,
	HPBarHeight = 110,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 938, Gain = 188},
		{Value = 200002, Base = 26, Gain = 6},
		{Value = 200003, Base = 25, Gain = 1},
		{Value = 200004, Base = 25, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "有50%概率额外攻击1次\n33%概率闪避攻击",
		Skill = {
			{
				Id = 105023,
				Value = 50,
			},
			{
				Id = 105026,
				Value = 33,
			},
		},
	},
	Tags = {
		560202,
		560203,
		560204,
		560205,
		560206,
		560107,
		560209,
		560210,
		560211,
		561202,
		561355,
		561328,
		563104,
		563205,
		564557,
		564558,
	},
}
EnemyConfig[EnemyID.Id171] =
{
	Id = 171,
	Name = "神仙司机",
	Rarity = 4,
	Element = 210004,
	Style = "Dps",
	AttackType = "Melee",
	Area = 
	{
		130207,
	},
	Desc = "星光小道的神仙司机，能把准确地把乘客带去目的地，但是要坐上TA的车，并不是一件容易的事。",
	IconBundle = "atlas_charactericon_sea",
	IconAtlas = "Sea",
	IconName = "SEA_TropicalFish",
	PrefabBundle = "character_enemy",
	PrefabName = "SEA_TropicalFish",
	PrefabScale = 50,
	HPBarHeight = 100,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 997, Gain = 200},
		{Value = 200002, Base = 23, Gain = 5},
		{Value = 200003, Base = 25, Gain = 1},
		{Value = 200004, Base = 25, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "有33%概率额外攻击2次\n有66%概率额外攻击1次\n暴击伤害 +100%",
		Skill = {
			{
				Id = 105024,
				Value = 33,
			},
			{
				Id = 105023,
				Value = 66,
			},
			{
				Id = 105038,
				Value = 100,
			},
		},
	},
	Tags = {
		560202,
		560203,
		560204,
		560205,
		560206,
		560107,
		560209,
		560210,
		560211,
		561205,
		561355,
		561328,
		563104,
		563205,
		564558,
	},
}
EnemyConfig[EnemyID.Id172] =
{
	Id = 172,
	Name = "蓝记水母",
	Rarity = 2,
	Element = 210001,
	Style = "Dps",
	AttackType = "Melee",
	Area = 
	{
		130208,
	},
	Desc = "鱼乐日报记者，又名皮埃斯，擅长图片编辑，有伪造图片被艺人告上法庭的经历。",
	IconBundle = "atlas_charactericon_sea",
	IconAtlas = "Sea",
	IconName = "SEA_Jellyfish1",
	PrefabBundle = "character_enemy",
	PrefabName = "SEA_Jellyfish1",
	PrefabScale = 50,
	HPBarHeight = 100,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 943, Gain = 189},
		{Value = 200002, Base = 28, Gain = 6},
		{Value = 200003, Base = 25, Gain = 1},
		{Value = 200004, Base = 25, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "每回合回血 10%，最多5次\n20%概率闪避攻击",
		Skill = {
			{
				Id = 105005,
				Value = 10,
			},
			{
				Id = 105026,
				Value = 20,
			},
		},
	},
	Tags = {
		560202,
		560203,
		560204,
		560205,
		560206,
		560107,
		560209,
		560210,
		560211,
		561202,
		561355,
		561362,
		563103,
		563203,
		564557,
		564560,
	},
}
EnemyConfig[EnemyID.Id173] =
{
	Id = 173,
	Name = "紫记水母",
	Rarity = 3,
	Element = 210005,
	Style = "Dps",
	AttackType = "Melee",
	Area = 
	{
		130208,
	},
	Desc = "鱼乐日报记者，公认的标题党，因为标题过于猎奇，在读者中已经失去了可信度。",
	IconBundle = "atlas_charactericon_sea",
	IconAtlas = "Sea",
	IconName = "SEA_Jellyfish3",
	PrefabBundle = "character_enemy",
	PrefabName = "SEA_Jellyfish3",
	PrefabScale = 50,
	HPBarHeight = 100,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 926, Gain = 186},
		{Value = 200002, Base = 28, Gain = 6},
		{Value = 200003, Base = 25, Gain = 1},
		{Value = 200004, Base = 25, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "回合中，每次受击，回血2%\n生命 +50%\n33%概率闪避攻击",
		Skill = {
			{
				Id = 105186,
				Value = 2,
			},
			{
				Id = 105001,
				Value = 50,
			},
			{
				Id = 105026,
				Value = 33,
			},
		},
	},
	Tags = {
		560202,
		560203,
		560204,
		560205,
		560206,
		560107,
		560209,
		560210,
		560211,
		561206,
		561355,
		561362,
		563103,
		563203,
		564557,
		564560,
		564561,
	},
}
EnemyConfig[EnemyID.Id174] =
{
	Id = 174,
	Name = "黄记水母",
	Rarity = 4,
	Element = 210004,
	Style = "Dps",
	AttackType = "Melee",
	Area = 
	{
		130208,
	},
	Desc = "鱼乐日报记者，常用黄色的纸笔，写下带颜色的文章，迄今为止已收到了2356份律师函。",
	IconBundle = "atlas_charactericon_sea",
	IconAtlas = "Sea",
	IconName = "SEA_Jellyfish2",
	PrefabBundle = "character_enemy",
	PrefabName = "SEA_Jellyfish2",
	PrefabScale = 50,
	HPBarHeight = 100,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 878, Gain = 176},
		{Value = 200002, Base = 28, Gain = 6},
		{Value = 200003, Base = 25, Gain = 1},
		{Value = 200004, Base = 25, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "每3回合回血 30%，最多5次\n生命 +100%\n40%概率闪避攻击",
		Skill = {
			{
				Id = 105009,
				Value = 30,
			},
			{
				Id = 105001,
				Value = 100,
			},
			{
				Id = 105026,
				Value = 40,
			},
		},
	},
	Tags = {
		560202,
		560203,
		560204,
		560205,
		560206,
		560107,
		560209,
		560210,
		560211,
		561205,
		561355,
		561362,
		563103,
		563203,
		564557,
		564560,
		564561,
	},
}
EnemyConfig[EnemyID.Id175] =
{
	Id = 175,
	Name = "海蛇",
	Rarity = 2,
	Element = 210003,
	Style = "Dps",
	AttackType = "Melee",
	Area = 
	{
		130209,
	},
	Desc = "地下乐队的组织者，死亡重金属爱好者，据说曾是海蛇莱斯莉的队友。",
	IconBundle = "atlas_charactericon_sea",
	IconAtlas = "Sea",
	IconName = "SEA_Snake1",
	PrefabBundle = "character_enemy",
	PrefabName = "SEA_Snake1",
	PrefabScale = 50,
	HPBarHeight = 100,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 990, Gain = 198},
		{Value = 200002, Base = 20, Gain = 4},
		{Value = 200003, Base = 25, Gain = 1},
		{Value = 200004, Base = 25, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "攻击时无视敌人75%忍耐\n有33%概率额外攻击1次",
		Skill = {
			{
				Id = 105168,
				Value = 75,
			},
			{
				Id = 105023,
				Value = 33,
			},
		},
	},
	Tags = {
		560202,
		560203,
		560204,
		560205,
		560206,
		560107,
		560209,
		560210,
		560211,
		561204,
		561356,
		561363,
		563103,
		563205,
		564558,
		564563,
	},
}
EnemyConfig[EnemyID.Id176] =
{
	Id = 176,
	Name = "闪电海蛇",
	Rarity = 4,
	Element = 210003,
	Style = "Dps",
	AttackType = "Melee",
	Area = 
	{
		130209,
	},
	Desc = "曾是海蛇莱斯莉的队友，产出了许多重金属风格的demo，最近在尝试新的音乐风格。",
	IconBundle = "atlas_charactericon_sea",
	IconAtlas = "Sea",
	IconName = "SEA_Snake2",
	PrefabBundle = "character_enemy",
	PrefabName = "SEA_Snake2",
	PrefabScale = 50,
	HPBarHeight = 100,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 983, Gain = 197},
		{Value = 200002, Base = 18, Gain = 4},
		{Value = 200003, Base = 25, Gain = 1},
		{Value = 200004, Base = 25, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "攻击时无视敌人100%忍耐\n有50%概率额外攻击1次",
		Skill = {
			{
				Id = 105168,
				Value = 100,
			},
			{
				Id = 105023,
				Value = 50,
			},
		},
	},
	Tags = {
		560202,
		560203,
		560204,
		560205,
		560206,
		560107,
		560209,
		560210,
		560211,
		561204,
		561356,
		561363,
		563103,
		563205,
		564558,
		564563,
	},
}
EnemyConfig[EnemyID.Id177] =
{
	Id = 177,
	Name = "电鳗伊俄",
	Rarity = 4,
	Element = 210003,
	Style = "Dps",
	AttackType = "Melee",
	Area = 
	{
		130209,
	},
	Desc = "solo出道的摇滚歌手，凶猛海族，迄今为止已经开了很多场演唱会。在台上嗨到极致的时候会放电，经常吓到工作人员。",
	IconBundle = "atlas_charactericon_sea",
	IconAtlas = "Sea",
	IconName = "Sea_24_haiman",
	PrefabBundle = "character_sea",
	PrefabName = "Sea_24_haiman",
	SkinName = "1",
	PrefabScale = 50,
	HPBarHeight = 112,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 919, Gain = 184},
		{Value = 200002, Base = 16, Gain = 4},
		{Value = 200003, Base = 25, Gain = 1},
		{Value = 200004, Base = 25, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "攻击时无视敌人100%忍耐\n每2回合对前3个队员造成60%攻击伤害\n有25%概率额外攻击1次",
		Skill = {
			{
				Id = 105168,
				Value = 100,
			},
			{
				Id = 105049,
				Value = 60,
			},
			{
				Id = 105023,
				Value = 25,
			},
		},
	},
	Tags = {
		564558,
		564563,
	},
}
EnemyConfig[EnemyID.Id178] =
{
	Id = 178,
	Name = "海星星",
	Rarity = 2,
	Element = 210001,
	Style = "Dps",
	AttackType = "Melee",
	Area = 
	{
		130210,
	},
	Desc = "天鱼公司的初级经纪，主要负责面试艺人，在工作中兢兢业业，希望通过自己的努力升职加薪。",
	IconBundle = "atlas_charactericon_sea",
	IconAtlas = "Sea",
	IconName = "SEA_SeaStar",
	PrefabBundle = "character_enemy",
	PrefabName = "SEA_SeaStar",
	PrefabScale = 50,
	HPBarHeight = 140,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 962, Gain = 193},
		{Value = 200002, Base = 28, Gain = 6},
		{Value = 200003, Base = 25, Gain = 1},
		{Value = 200004, Base = 25, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "受光元素敌人伤害 -50%\n受暗元素敌人伤害 -50%",
		Skill = {
			{
				Id = 105036,
				Value = -50,
			},
			{
				Id = 105037,
				Value = -50,
			},
		},
	},
	Tags = {
		560202,
		560203,
		560204,
		560205,
		560206,
		560107,
		560209,
		560210,
		560211,
		561202,
		561356,
		561364,
		563102,
		563203,
	},
}
EnemyConfig[EnemyID.Id179] =
{
	Id = 179,
	Name = "皇冠星探",
	Rarity = 4,
	Element = 210001,
	Style = "Dps",
	AttackType = "Melee",
	Area = 
	{
		130210,
	},
	Desc = "天鱼公司的高级经纪，业务能力了得，就连公司boss帝王蟹老板也非常尊敬TA。",
	IconBundle = "atlas_charactericon_sea",
	IconAtlas = "Sea",
	IconName = "SEA_KingSeaStar",
	PrefabBundle = "character_enemy",
	PrefabName = "SEA_KingSeaStar",
	PrefabScale = 50,
	HPBarHeight = 110,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 955, Gain = 191},
		{Value = 200002, Base = 28, Gain = 6},
		{Value = 200003, Base = 25, Gain = 1},
		{Value = 200004, Base = 25, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "受光元素敌人伤害 -75%\n受暗元素敌人伤害 -75%",
		Skill = {
			{
				Id = 105036,
				Value = -75,
			},
			{
				Id = 105037,
				Value = -75,
			},
		},
	},
	Tags = {
		560202,
		560203,
		560204,
		560205,
		560206,
		560107,
		560209,
		560210,
		560211,
		561202,
		561356,
		561364,
		563102,
		563203,
	},
}
EnemyConfig[EnemyID.Id180] =
{
	Id = 180,
	Name = "水熊虫",
	Rarity = 1,
	Element = 210001,
	Style = "Dps",
	AttackType = "Melee",
	Area = 
	{
		130211,
	},
	Desc = "海底世界的厕所管理员，对于那些想进入未成年厕所的家伙，一定要仔细检查TA们的身体。",
	IconBundle = "atlas_charactericon_sea",
	IconAtlas = "Sea",
	IconName = "SEA_WaterBear",
	PrefabBundle = "character_enemy",
	PrefabName = "SEA_WaterBear",
	PrefabScale = 50,
	HPBarHeight = 100,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 951, Gain = 191},
		{Value = 200002, Base = 28, Gain = 6},
		{Value = 200003, Base = 25, Gain = 1},
		{Value = 200004, Base = 25, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "受到的暴击伤害 -50%\n忍耐 +100\n5回合后，回血 50%",
		Skill = {
			{
				Id = 105039,
				Value = -50,
			},
			{
				Id = 105003,
				Value = 100,
			},
			{
				Id = 105013,
				Value = 50,
			},
		},
	},
	Tags = {
		560202,
		560203,
		560204,
		560205,
		560206,
		560107,
		560209,
		560210,
		560211,
		561202,
		561355,
		561365,
		563103,
		563203,
		564560,
		564561,
	},
}
EnemyConfig[EnemyID.Id181] =
{
	Id = 181,
	Name = "绿绵宝宝",
	Rarity = 2,
	Element = 210003,
	Style = "Dps",
	AttackType = "Melee",
	Area = 
	{
		130211,
	},
	Desc = "蟹老板雇来抹黑海豚凛的水军，给钱就办事，非常好说话。",
	IconBundle = "atlas_charactericon_sea",
	IconAtlas = "Sea",
	IconName = "SEA_CoralReef2",
	PrefabBundle = "character_enemy",
	PrefabName = "SEA_CoralReef2",
	PrefabScale = 50,
	HPBarHeight = 100,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 965, Gain = 193},
		{Value = 200002, Base = 28, Gain = 6},
		{Value = 200003, Base = 25, Gain = 1},
		{Value = 200004, Base = 25, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "对光元素敌人伤害 +50%\n对暗元素敌人伤害 +50%\n回合中，每次受击，攻击 +2%",
		Skill = {
			{
				Id = 105031,
				Value = 50,
			},
			{
				Id = 105032,
				Value = 50,
			},
			{
				Id = 105170,
				Value = 2,
			},
		},
	},
	Tags = {
		560202,
		560203,
		560204,
		560205,
		560206,
		560107,
		560209,
		560210,
		560211,
		561204,
		561355,
		561325,
		563104,
		563203,
		564561,
	},
}
EnemyConfig[EnemyID.Id182] =
{
	Id = 182,
	Name = "红绵宝宝",
	Rarity = 3,
	Element = 210002,
	Style = "Dps",
	AttackType = "Melee",
	Area = 
	{
		130211,
	},
	Desc = "蟹老板雇来抹黑海豚凛的水军，什么？除了现场闹事，还要去其他地方散播要钱？可以，但得加钱。",
	IconBundle = "atlas_charactericon_sea",
	IconAtlas = "Sea",
	IconName = "SEA_CoralReef1",
	PrefabBundle = "character_enemy",
	PrefabName = "SEA_CoralReef1",
	PrefabScale = 50,
	HPBarHeight = 100,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 956, Gain = 192},
		{Value = 200002, Base = 28, Gain = 6},
		{Value = 200003, Base = 25, Gain = 1},
		{Value = 200004, Base = 25, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "对光元素敌人伤害 +75%\n对暗元素敌人伤害 +75%\n回合中，每次受击，攻击 +3%",
		Skill = {
			{
				Id = 105031,
				Value = 75,
			},
			{
				Id = 105032,
				Value = 75,
			},
			{
				Id = 105170,
				Value = 3,
			},
		},
	},
	Tags = {
		560202,
		560203,
		560204,
		560205,
		560206,
		560107,
		560209,
		560210,
		560211,
		561203,
		561355,
		561325,
		563104,
		563203,
		564561,
	},
}
EnemyConfig[EnemyID.Id183] =
{
	Id = 183,
	Name = "红海葵",
	Rarity = 2,
	Element = 210002,
	Style = "Dps",
	AttackType = "Melee",
	Area = 
	{
		130212,
	},
	Desc = "天鱼公司的星探之一，曾哄骗许多艺人签下不公平合同，在鱼乐圈中臭名昭著，但总会骗到一些初入圈子的小白。",
	IconBundle = "atlas_charactericon_sea",
	IconAtlas = "Sea",
	IconName = "SEA_Actinian2",
	PrefabBundle = "character_enemy",
	PrefabName = "SEA_Actinian2",
	PrefabScale = 50,
	HPBarHeight = 100,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 831, Gain = 167},
		{Value = 200002, Base = 22, Gain = 5},
		{Value = 200003, Base = 25, Gain = 1},
		{Value = 200004, Base = 25, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "每回合对前3个队员造成80%攻击伤害\n回合中，每次受击，回血2%",
		Skill = {
			{
				Id = 105041,
				Value = 80,
			},
			{
				Id = 105186,
				Value = 2,
			},
		},
	},
	Tags = {
		560202,
		560203,
		560204,
		560205,
		560206,
		560107,
		560209,
		560210,
		560211,
		561203,
		561355,
		561366,
		563106,
		563202,
		564560,
	},
}
EnemyConfig[EnemyID.Id184] =
{
	Id = 184,
	Name = "蓝海葵",
	Rarity = 2,
	Element = 210001,
	Style = "Dps",
	AttackType = "Melee",
	Area = 
	{
		130212,
	},
	Desc = "天鱼公司的星探之一，除了小丑鱼，不会考虑和其他种族的任何艺人签约，因此业绩一直平平。",
	IconBundle = "atlas_charactericon_sea",
	IconAtlas = "Sea",
	IconName = "SEA_Actinian1",
	PrefabBundle = "character_enemy",
	PrefabName = "SEA_Actinian1",
	PrefabScale = 50,
	HPBarHeight = 100,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 837, Gain = 168},
		{Value = 200002, Base = 21, Gain = 5},
		{Value = 200003, Base = 25, Gain = 1},
		{Value = 200004, Base = 25, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "每回合对前4个队员造成80%攻击伤害\n回合中，每次受击，回血2%",
		Skill = {
			{
				Id = 105042,
				Value = 80,
			},
			{
				Id = 105186,
				Value = 2,
			},
		},
	},
	Tags = {
		560202,
		560203,
		560204,
		560205,
		560206,
		560107,
		560209,
		560210,
		560211,
		561202,
		561355,
		561366,
		563106,
		563202,
		564560,
	},
}
EnemyConfig[EnemyID.Id185] =
{
	Id = 185,
	Name = "鲎椰子",
	Rarity = 3,
	Element = 210005,
	Style = "Dps",
	AttackType = "Melee",
	Area = 
	{
		130212,
	},
	Desc = "来自偏远贫穷的小村落，温驯海族，自称是全村的希望，有些胆小自卑，因此并不被经纪公司看好，但TA的天真和努力，打动了许多粉丝。",
	IconBundle = "atlas_charactericon_sea",
	IconAtlas = "Sea",
	IconName = "Sea_29_hou",
	PrefabBundle = "character_sea",
	PrefabName = "Sea_29_hou",
	SkinName = "1",
	PrefabScale = 50,
	HPBarHeight = 112,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 790, Gain = 158},
		{Value = 200002, Base = 28, Gain = 6},
		{Value = 200003, Base = 25, Gain = 1},
		{Value = 200004, Base = 25, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "受到的暴击伤害 -50%\n每3回合，100%概率闪避攻击\n75%概率无视敌人闪避",
		Skill = {
			{
				Id = 105039,
				Value = -50,
			},
			{
				Id = 105140,
				Value = 100,
			},
			{
				Id = 105027,
				Value = 75,
			},
		},
	},
	Tags = {
		564557,
		564559,
	},
}
EnemyConfig[EnemyID.Id186] =
{
	Id = 186,
	Name = "蟹经理",
	Rarity = 3,
	Element = 210003,
	Style = "Dps",
	AttackType = "Melee",
	Area = 
	{
		130213,
	},
	Desc = "天鱼公司总经理，唯董事长马首是瞻。",
	IconBundle = "atlas_charactericon_sea",
	IconAtlas = "Sea",
	IconName = "SEA_Crab",
	PrefabBundle = "character_enemy",
	PrefabName = "SEA_Crab",
	PrefabScale = 50,
	HPBarHeight = 130,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 942, Gain = 189},
		{Value = 200002, Base = 28, Gain = 6},
		{Value = 200003, Base = 25, Gain = 1},
		{Value = 200004, Base = 25, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "暴击 +200\n暴击伤害 +100%\n生命 +50%",
		Skill = {
			{
				Id = 105004,
				Value = 200,
			},
			{
				Id = 105038,
				Value = 100,
			},
			{
				Id = 105001,
				Value = 50,
			},
		},
	},
	Tags = {
		560202,
		560203,
		560204,
		560205,
		560206,
		560107,
		560209,
		560210,
		560211,
		561204,
		561356,
		561367,
		563105,
		563204,
		564561,
	},
}
EnemyConfig[EnemyID.Id187] =
{
	Id = 187,
	Name = "蟹董事",
	Rarity = 4,
	Element = 210002,
	Style = "Dps",
	AttackType = "Melee",
	Area = 
	{
		130213,
	},
	Desc = "天鱼公司董事长，被别人称为蟹老板，然而TA对此表示非常不满，并要求大家称呼自己为“帝王蟹董事”。",
	IconBundle = "atlas_charactericon_sea",
	IconAtlas = "Sea",
	IconName = "SEA_KingCrab",
	PrefabBundle = "character_enemy",
	PrefabName = "SEA_KingCrab",
	PrefabScale = 50,
	HPBarHeight = 130,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 929, Gain = 186},
		{Value = 200002, Base = 28, Gain = 6},
		{Value = 200003, Base = 25, Gain = 1},
		{Value = 200004, Base = 25, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "暴击 +200\n暴击伤害 +150%\n生命 +75%",
		Skill = {
			{
				Id = 105004,
				Value = 200,
			},
			{
				Id = 105038,
				Value = 150,
			},
			{
				Id = 105001,
				Value = 75,
			},
		},
	},
	Tags = {
		560202,
		560203,
		560204,
		560205,
		560206,
		560107,
		560209,
		560210,
		560211,
		561203,
		561356,
		561367,
		563105,
		563204,
		564561,
	},
}
EnemyConfig[EnemyID.Id188] =
{
	Id = 188,
	Name = "绵羊海兔",
	Rarity = 2,
	Element = 210003,
	Style = "Dps",
	AttackType = "Melee",
	Area = 
	{
		130214,
	},
	Desc = "绿色的海兔，每天除了吃喝玩乐，就是吃喝玩乐。",
	IconBundle = "atlas_charactericon_sea",
	IconAtlas = "Sea",
	IconName = "SEA_Aplysia3",
	PrefabBundle = "character_enemy",
	PrefabName = "SEA_Aplysia3",
	PrefabScale = 50,
	HPBarHeight = 100,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 866, Gain = 174},
		{Value = 200002, Base = 27, Gain = 6},
		{Value = 200003, Base = 25, Gain = 1},
		{Value = 200004, Base = 25, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "每回合回血 5%，最多5次\n回合中，每次受击，回血1%\n20%概率闪避攻击",
		Skill = {
			{
				Id = 105005,
				Value = 5,
			},
			{
				Id = 105186,
				Value = 1,
			},
			{
				Id = 105026,
				Value = 20,
			},
		},
	},
	Tags = {
		560202,
		560203,
		560204,
		560205,
		560206,
		560107,
		560209,
		560210,
		560211,
		561204,
		561355,
		561368,
		563106,
		563203,
		564557,
		564560,
	},
}
EnemyConfig[EnemyID.Id189] =
{
	Id = 189,
	Name = "粉红海兔",
	Rarity = 3,
	Element = 210002,
	Style = "Dps",
	AttackType = "Melee",
	Area = 
	{
		130214,
	},
	Desc = "粉红色的海兔，玩“叠罗汉”的时候，最喜欢在中间的位置。",
	IconBundle = "atlas_charactericon_sea",
	IconAtlas = "Sea",
	IconName = "SEA_Aplysia1",
	PrefabBundle = "character_enemy",
	PrefabName = "SEA_Aplysia1",
	PrefabScale = 50,
	HPBarHeight = 110,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 839, Gain = 168},
		{Value = 200002, Base = 27, Gain = 6},
		{Value = 200003, Base = 25, Gain = 1},
		{Value = 200004, Base = 25, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "每回合回血 8%，最多5次\n每3回合回血 8%，最多5次\n25%概率闪避攻击",
		Skill = {
			{
				Id = 105005,
				Value = 8,
			},
			{
				Id = 105009,
				Value = 8,
			},
			{
				Id = 105026,
				Value = 25,
			},
		},
	},
	Tags = {
		560202,
		560203,
		560204,
		560205,
		560206,
		560107,
		560209,
		560210,
		560211,
		561203,
		561355,
		561368,
		563106,
		563203,
		564557,
		564560,
	},
}
EnemyConfig[EnemyID.Id190] =
{
	Id = 190,
	Name = "蓝海兔",
	Rarity = 4,
	Element = 210001,
	Style = "Dps",
	AttackType = "Melee",
	Area = 
	{
		130214,
	},
	Desc = "蓝色海兔，生命中只有吃饭、睡觉、叠兔兔。",
	IconBundle = "atlas_charactericon_sea",
	IconAtlas = "Sea",
	IconName = "SEA_Aplysia2",
	PrefabBundle = "character_enemy",
	PrefabName = "SEA_Aplysia2",
	PrefabScale = 50,
	HPBarHeight = 100,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 796, Gain = 160},
		{Value = 200002, Base = 27, Gain = 6},
		{Value = 200003, Base = 25, Gain = 1},
		{Value = 200004, Base = 25, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "每回合回血 10%，最多5次\n5回合后，回血 50%\n33%概率闪避攻击",
		Skill = {
			{
				Id = 105005,
				Value = 10,
			},
			{
				Id = 105013,
				Value = 50,
			},
			{
				Id = 105026,
				Value = 33,
			},
		},
	},
	Tags = {
		560202,
		560203,
		560204,
		560205,
		560206,
		560107,
		560209,
		560210,
		560211,
		561202,
		561355,
		561368,
		563106,
		563203,
		564557,
		564560,
	},
}
EnemyConfig[EnemyID.Id191] =
{
	Id = 191,
	Name = "鱼不翻",
	Rarity = 3,
	Element = 210001,
	Style = "Dps",
	AttackType = "Melee",
	Area = 
	{
		130214,
	},
	Desc = "偶像团体鱼妄想中的一员，温驯海族，口号是“翻车鱼的演出永不翻车！”。明明是个木讷的人，但有时又让人觉得聪明机警。",
	IconBundle = "atlas_charactericon_sea",
	IconAtlas = "Sea",
	IconName = "Sea_28_fancheyu",
	PrefabBundle = "character_sea",
	PrefabName = "Sea_28_fancheyu",
	SkinName = "1",
	PrefabScale = 50,
	HPBarHeight = 112,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 662, Gain = 133},
		{Value = 200002, Base = 23, Gain = 5},
		{Value = 200003, Base = 25, Gain = 1},
		{Value = 200004, Base = 25, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "受到的暴击伤害 -50%\n每2回合对前3个队员造成80%攻击伤害\n100%概率无视敌人闪避",
		Skill = {
			{
				Id = 105039,
				Value = -50,
			},
			{
				Id = 105049,
				Value = 80,
			},
			{
				Id = 105027,
				Value = 100,
			},
		},
	},
	Tags = {
		564559,
	},
}
EnemyConfig[EnemyID.Id192] =
{
	Id = 192,
	Name = "警戒草",
	Rarity = 1,
	Element = 210003,
	Style = "Dps",
	AttackType = "Melee",
	Area = 
	{
		130251,
	},
	Desc = "虽然看上去是个很狂热的粉丝，但其实是墙头草，每过一段时间就会换个人单推。",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "SUS",
	IconName = "SUS_ColorfulCat",
	PrefabBundle = "character_enemy",
	PrefabName = "SUS_ColourfulCat",
	PrefabScale = 50,
	HPBarHeight = 100,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 1093, Gain = 219},
		{Value = 200002, Base = 25, Gain = 5},
		{Value = 200003, Base = 25, Gain = 1},
		{Value = 200004, Base = 25, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "每3回合对后2个队员造成100%攻击伤害\n30%概率闪避攻击\n5回合后，攻击 +25%",
		Skill = {
			{
				Id = 105060,
				Value = 100,
			},
			{
				Id = 105026,
				Value = 30,
			},
			{
				Id = 105014,
				Value = 25,
			},
		},
	},
	Tags = {
		564557,
		564561,
	},
}
EnemyConfig[EnemyID.Id193] =
{
	Id = 193,
	Name = "蠕虫骑手",
	Rarity = 2,
	Element = 210004,
	Style = "Dps",
	AttackType = "Melee",
	Area = 
	{
		130251,
	},
	Desc = "星球知名狗仔记者，依靠完美伪装多次拍摄到名人出轨照片并爆出，因此臭名昭著，经常出没于海草密集区。",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "SUS",
	IconName = "SUS_WhiteCat",
	PrefabBundle = "character_enemy",
	PrefabName = "SUS_WhiteCat",
	PrefabScale = 50,
	HPBarHeight = 100,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 1056, Gain = 212},
		{Value = 200002, Base = 25, Gain = 5},
		{Value = 200003, Base = 25, Gain = 1},
		{Value = 200004, Base = 25, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "每3回合对后2个队员造成100%攻击伤害\n30%概率闪避攻击\n5回合后，攻击 +25%",
		Skill = {
			{
				Id = 105060,
				Value = 100,
			},
			{
				Id = 105026,
				Value = 30,
			},
			{
				Id = 105014,
				Value = 25,
			},
		},
	},
	Tags = {
		564557,
		564561,
	},
}
EnemyConfig[EnemyID.Id194] =
{
	Id = 194,
	Name = "紫弦月",
	Rarity = 3,
	Element = 210001,
	Style = "Dps",
	AttackType = "Melee",
	Area = 
	{
		130251,
	},
	Desc = "海洋星的超人气美少女新人偶像，长相可爱，歌声动听，一经出道便引发粉丝的沸腾，被认为是Sharkalaka的下一任候选人。但本人性格有些天然，对于成为偶像这件事并没有什么自觉，有些害怕Sharkalaka的C位虎鲸。",
	IconBundle = "atlas_charactericon_sea",
	IconAtlas = "Sea",
	IconName = "Sea_13_shayu",
	PrefabBundle = "character_sea",
	PrefabName = "Sea_13_shayu",
	SkinName = "1",
	PrefabScale = 50,
	HPBarHeight = 112,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 1074, Gain = 215},
		{Value = 200002, Base = 25, Gain = 5},
		{Value = 200003, Base = 25, Gain = 1},
		{Value = 200004, Base = 25, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "每3回合对后2个队员造成100%攻击伤害\n30%概率闪避攻击\n5回合后，攻击 +25%",
		Skill = {
			{
				Id = 105060,
				Value = 100,
			},
			{
				Id = 105026,
				Value = 30,
			},
			{
				Id = 105014,
				Value = 25,
			},
		},
	},
	Tags = {
		564557,
		564561,
	},
}
EnemyConfig[EnemyID.Id195] =
{
	Id = 195,
	Name = "独角仙",
	Rarity = 1,
	Element = 210004,
	Style = "Dps",
	AttackType = "Melee",
	Area = 
	{
		130252,
	},
	Desc = "星球知名狗仔记者，依靠完美伪装多次拍摄到名人出轨照片并爆出，因此臭名昭著，经常出没于海草密集区。",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "SUS",
	IconName = "SUS_WhiteCat",
	PrefabBundle = "character_enemy",
	PrefabName = "SUS_WhiteCat",
	PrefabScale = 50,
	HPBarHeight = 100,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 1065, Gain = 213},
		{Value = 200002, Base = 25, Gain = 5},
		{Value = 200003, Base = 25, Gain = 1},
		{Value = 200004, Base = 25, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "每3回合对后2个队员造成100%攻击伤害\n30%概率闪避攻击\n5回合后，攻击 +25%",
		Skill = {
			{
				Id = 105060,
				Value = 100,
			},
			{
				Id = 105026,
				Value = 30,
			},
			{
				Id = 105014,
				Value = 25,
			},
		},
	},
	Tags = {
		564557,
		564561,
	},
}
EnemyConfig[EnemyID.Id196] =
{
	Id = 196,
	Name = "沙漠掠匪",
	Rarity = 2,
	Element = 210003,
	Style = "Dps",
	AttackType = "Melee",
	Area = 
	{
		130252,
	},
	Desc = "热衷偶像的狂热粉丝，最疯狂时，每天都会守在偶像宿舍附近，一旦发现偶像就会冲上去强吻，遭到通缉后逃窜到大漩涡地区。",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "SUS",
	IconName = "SUS_FeatherPen",
	PrefabBundle = "character_enemy",
	PrefabName = "SUS_FeatherPen",
	PrefabScale = 50,
	HPBarHeight = 110,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 1056, Gain = 212},
		{Value = 200002, Base = 25, Gain = 5},
		{Value = 200003, Base = 25, Gain = 1},
		{Value = 200004, Base = 25, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "每3回合对后2个队员造成100%攻击伤害\n30%概率闪避攻击\n5回合后，攻击 +25%",
		Skill = {
			{
				Id = 105060,
				Value = 100,
			},
			{
				Id = 105026,
				Value = 30,
			},
			{
				Id = 105014,
				Value = 25,
			},
		},
	},
	Tags = {
		564557,
		564561,
	},
}
EnemyConfig[EnemyID.Id197] =
{
	Id = 197,
	Name = "红蝎",
	Rarity = 2,
	Element = 210003,
	Style = "Dps",
	AttackType = "Melee",
	Area = 
	{
		130252,
	},
	Desc = "热衷偶像的狂热粉丝，最疯狂时，每天都会守在偶像宿舍附近，一旦发现偶像就会冲上去强吻，遭到通缉后逃窜到大漩涡地区。",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "SUS",
	IconName = "SUS_FeatherPen",
	PrefabBundle = "character_enemy",
	PrefabName = "SUS_FeatherPen",
	PrefabScale = 50,
	HPBarHeight = 110,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 1056, Gain = 212},
		{Value = 200002, Base = 25, Gain = 5},
		{Value = 200003, Base = 25, Gain = 1},
		{Value = 200004, Base = 25, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "每3回合对后2个队员造成100%攻击伤害\n30%概率闪避攻击\n5回合后，攻击 +25%",
		Skill = {
			{
				Id = 105060,
				Value = 100,
			},
			{
				Id = 105026,
				Value = 30,
			},
			{
				Id = 105014,
				Value = 25,
			},
		},
	},
	Tags = {
		564557,
		564561,
	},
}
EnemyConfig[EnemyID.Id198] =
{
	Id = 198,
	Name = "黑蝎",
	Rarity = 2,
	Element = 210005,
	Style = "Dps",
	AttackType = "Melee",
	Area = 
	{
		130252,
	},
	Desc = "星球知名狗仔记者，依靠完美伪装多次拍摄到偶像地下恋情的照片并爆出，因此臭名昭著，经常出没于蓝藻密集区。",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "SUS",
	IconName = "SUS_BlackCat",
	PrefabBundle = "character_enemy",
	PrefabName = "SUS_BlackCat",
	PrefabScale = 50,
	HPBarHeight = 100,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 1056, Gain = 212},
		{Value = 200002, Base = 25, Gain = 5},
		{Value = 200003, Base = 25, Gain = 1},
		{Value = 200004, Base = 25, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "每3回合对后2个队员造成100%攻击伤害\n30%概率闪避攻击\n5回合后，攻击 +25%",
		Skill = {
			{
				Id = 105060,
				Value = 100,
			},
			{
				Id = 105026,
				Value = 30,
			},
			{
				Id = 105014,
				Value = 25,
			},
		},
	},
	Tags = {
		564557,
		564561,
	},
}
EnemyConfig[EnemyID.Id199] =
{
	Id = 199,
	Name = "囚人",
	Rarity = 2,
	Element = 210003,
	Style = "Dps",
	AttackType = "Melee",
	Area = 
	{
		130253,
	},
	Desc = "海豚乙女的狂热粉丝，自认为是海豚的三千辈后代，有族谱为证，并能清楚地指认出是哪一位祖先被海豚误食。",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "SUS",
	IconName = "SUS_LoveLetter",
	PrefabBundle = "character_enemy",
	PrefabName = "SUS_LoveLetter",
	PrefabScale = 50,
	HPBarHeight = 100,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 1047, Gain = 210},
		{Value = 200002, Base = 24, Gain = 5},
		{Value = 200003, Base = 25, Gain = 1},
		{Value = 200004, Base = 25, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "每3回合对后2个队员造成100%攻击伤害\n30%概率闪避攻击\n5回合后，攻击 +25%",
		Skill = {
			{
				Id = 105060,
				Value = 100,
			},
			{
				Id = 105026,
				Value = 30,
			},
			{
				Id = 105014,
				Value = 25,
			},
		},
	},
	Tags = {
		564557,
		564561,
	},
}
EnemyConfig[EnemyID.Id200] =
{
	Id = 200,
	Name = "警卫",
	Rarity = 2,
	Element = 210001,
	Style = "Dps",
	AttackType = "Melee",
	Area = 
	{
		130253,
	},
	Desc = "Aquarius的狂热粉丝，自认为是水瓶座的化身，有出生年月为证，并发誓要找一个水瓶座的女朋友。",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "SUS",
	IconName = "SUS_PinkHat",
	PrefabBundle = "character_enemy",
	PrefabName = "SUS_PinkHat",
	PrefabScale = 50,
	HPBarHeight = 100,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 1039, Gain = 208},
		{Value = 200002, Base = 24, Gain = 5},
		{Value = 200003, Base = 25, Gain = 1},
		{Value = 200004, Base = 25, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "每3回合对后2个队员造成100%攻击伤害\n30%概率闪避攻击\n5回合后，攻击 +25%",
		Skill = {
			{
				Id = 105060,
				Value = 100,
			},
			{
				Id = 105026,
				Value = 30,
			},
			{
				Id = 105014,
				Value = 25,
			},
		},
	},
	Tags = {
		564557,
		564561,
	},
}
EnemyConfig[EnemyID.Id201] =
{
	Id = 201,
	Name = "琉璃兜",
	Rarity = 4,
	Element = 210001,
	Style = "Dps",
	AttackType = "Melee",
	Area = 
	{
		130253,
	},
	Desc = "虎鲸的头号狂热粉丝，为了追星进入了偶像公司。成功成为Sharkalaka的队员候选之后，依伶一如既往地保持着对虎鲸的崇拜，并对任何想要和她争抢这个位置的人怀有强烈敌意。",
	IconBundle = "atlas_charactericon_sea",
	IconAtlas = "Sea",
	IconName = "Sea_12_jingsha",
	PrefabBundle = "character_sea",
	PrefabName = "Sea_17_haitun",
	SkinName = "1",
	PrefabScale = 50,
	HPBarHeight = 112,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 1022, Gain = 205},
		{Value = 200002, Base = 24, Gain = 5},
		{Value = 200003, Base = 25, Gain = 1},
		{Value = 200004, Base = 25, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "每3回合对后2个队员造成100%攻击伤害\n30%概率闪避攻击\n5回合后，攻击 +25%",
		Skill = {
			{
				Id = 105060,
				Value = 100,
			},
			{
				Id = 105026,
				Value = 30,
			},
			{
				Id = 105014,
				Value = 25,
			},
		},
	},
	Tags = {
		564557,
		564561,
	},
}
EnemyConfig[EnemyID.Id202] =
{
	Id = 202,
	Name = "机械引擎",
	Rarity = 2,
	Element = 210002,
	Style = "Dps",
	AttackType = "Melee",
	Area = 
	{
		130254,
	},
	Desc = "狂热得有些扭曲的粉丝，喜欢潜入到休息室进行偷窥，因脸皮有厚重的贝壳保护而无所畏惧。",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "SUS",
	IconName = "SUS_MailBox",
	PrefabBundle = "character_enemy",
	PrefabName = "SUS_MailBox",
	PrefabScale = 50,
	HPBarHeight = 130,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 1005, Gain = 201},
		{Value = 200002, Base = 24, Gain = 5},
		{Value = 200003, Base = 25, Gain = 1},
		{Value = 200004, Base = 25, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "每3回合对后2个队员造成100%攻击伤害\n30%概率闪避攻击\n5回合后，攻击 +25%",
		Skill = {
			{
				Id = 105060,
				Value = 100,
			},
			{
				Id = 105026,
				Value = 30,
			},
			{
				Id = 105014,
				Value = 25,
			},
		},
	},
	Tags = {
		564557,
		564561,
	},
}
EnemyConfig[EnemyID.Id203] =
{
	Id = 203,
	Name = "报废的机器头部",
	Rarity = 2,
	Element = 210003,
	Style = "Dps",
	AttackType = "Melee",
	Area = 
	{
		130254,
	},
	Desc = "热衷偶像的狂热粉丝，最疯狂时，每天都会守在偶像宿舍附近，一旦发现偶像就会冲上去强吻，遭到通缉后逃窜到大漩涡地区。",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "SUS",
	IconName = "SUS_FeatherPen",
	PrefabBundle = "character_enemy",
	PrefabName = "SUS_FeatherPen",
	PrefabScale = 50,
	HPBarHeight = 110,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 997, Gain = 200},
		{Value = 200002, Base = 24, Gain = 5},
		{Value = 200003, Base = 25, Gain = 1},
		{Value = 200004, Base = 25, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "每3回合对后2个队员造成100%攻击伤害\n30%概率闪避攻击\n5回合后，攻击 +25%",
		Skill = {
			{
				Id = 105060,
				Value = 100,
			},
			{
				Id = 105026,
				Value = 30,
			},
			{
				Id = 105014,
				Value = 25,
			},
		},
	},
	Tags = {
		564557,
		564561,
	},
}
EnemyConfig[EnemyID.Id204] =
{
	Id = 204,
	Name = "老旧机器人",
	Rarity = 3,
	Element = 210003,
	Style = "Dps",
	AttackType = "Melee",
	Area = 
	{
		130254,
	},
	Desc = "专注于挖掘偶像黑料的黑粉，喜欢潜入到休息室进行偷窥，因为三观歪成圆圈而无所畏惧。",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "SUS",
	IconName = "SUS_Newspaper",
	PrefabBundle = "character_enemy",
	PrefabName = "SUS_Newspaper",
	PrefabScale = 50,
	HPBarHeight = 100,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 997, Gain = 200},
		{Value = 200002, Base = 24, Gain = 5},
		{Value = 200003, Base = 25, Gain = 1},
		{Value = 200004, Base = 25, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "每3回合对后2个队员造成100%攻击伤害\n30%概率闪避攻击\n5回合后，攻击 +25%",
		Skill = {
			{
				Id = 105060,
				Value = 100,
			},
			{
				Id = 105026,
				Value = 30,
			},
			{
				Id = 105014,
				Value = 25,
			},
		},
	},
	Tags = {
		564557,
		564561,
	},
}
EnemyConfig[EnemyID.Id205] =
{
	Id = 205,
	Name = "珍珠吊兰",
	Rarity = 4,
	Element = 210003,
	Style = "Dps",
	AttackType = "Melee",
	Area = 
	{
		130254,
	},
	Desc = "海洋星偶像团体海豚乙女的成员，擅长婉转动听的乡村小调。实为来自乡下的居民，为了实现成为偶像的梦想背井离乡，性格质朴，和同团的映冬关系非常好。",
	IconBundle = "atlas_charactericon_sea",
	IconAtlas = "Sea",
	IconName = "Sea_17_haitun",
	PrefabBundle = "character_sea",
	PrefabName = "Sea_19_shanbei",
	SkinName = "1",
	PrefabScale = 50,
	HPBarHeight = 112,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 982, Gain = 197},
		{Value = 200002, Base = 24, Gain = 5},
		{Value = 200003, Base = 25, Gain = 1},
		{Value = 200004, Base = 25, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "每3回合对后2个队员造成100%攻击伤害\n30%概率闪避攻击\n5回合后，攻击 +25%",
		Skill = {
			{
				Id = 105060,
				Value = 100,
			},
			{
				Id = 105026,
				Value = 30,
			},
			{
				Id = 105014,
				Value = 25,
			},
		},
	},
	Tags = {
		564557,
		564561,
	},
}
EnemyConfig[EnemyID.Id206] =
{
	Id = 206,
	Name = "砂鱼",
	Rarity = 2,
	Element = 210001,
	Style = "Dps",
	AttackType = "Melee",
	Area = 
	{
		130255,
	},
	Desc = "出身贫寒却疯狂地迷恋偶像，为追星散尽家财，最后不得不偷窃贝壳卖钱，最近为躲避高利贷追杀正藏身于大漩涡地区。",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "SUS",
	IconName = "SUS_BlackHat",
	PrefabBundle = "character_enemy",
	PrefabName = "SUS_BlackHat",
	PrefabScale = 50,
	HPBarHeight = 100,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 1022, Gain = 205},
		{Value = 200002, Base = 24, Gain = 5},
		{Value = 200003, Base = 25, Gain = 1},
		{Value = 200004, Base = 25, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "每3回合对后2个队员造成100%攻击伤害\n30%概率闪避攻击\n5回合后，攻击 +25%",
		Skill = {
			{
				Id = 105060,
				Value = 100,
			},
			{
				Id = 105026,
				Value = 30,
			},
			{
				Id = 105014,
				Value = 25,
			},
		},
	},
	Tags = {
		564557,
		564561,
	},
}
EnemyConfig[EnemyID.Id207] =
{
	Id = 207,
	Name = "黄砂鱼",
	Rarity = 2,
	Element = 210003,
	Style = "Dps",
	AttackType = "Melee",
	Area = 
	{
		130255,
	},
	Desc = "热衷偶像的狂热粉丝，最疯狂时，每天都会守在偶像宿舍附近，一旦发现偶像就会冲上去强吻，遭到通缉后逃窜到大漩涡地区。",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "SUS",
	IconName = "SUS_FeatherPen",
	PrefabBundle = "character_enemy",
	PrefabName = "SUS_FeatherPen",
	PrefabScale = 50,
	HPBarHeight = 110,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 1013, Gain = 203},
		{Value = 200002, Base = 24, Gain = 5},
		{Value = 200003, Base = 25, Gain = 1},
		{Value = 200004, Base = 25, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "每3回合对后2个队员造成100%攻击伤害\n30%概率闪避攻击\n5回合后，攻击 +25%",
		Skill = {
			{
				Id = 105060,
				Value = 100,
			},
			{
				Id = 105026,
				Value = 30,
			},
			{
				Id = 105014,
				Value = 25,
			},
		},
	},
	Tags = {
		564557,
		564561,
	},
}
EnemyConfig[EnemyID.Id208] =
{
	Id = 208,
	Name = "陆鳄",
	Rarity = 3,
	Element = 210001,
	Style = "Dps",
	AttackType = "Melee",
	Area = 
	{
		130255,
	},
	Desc = "曾参加过星光小道的海选，距离成为偶像只有一步之遥的时候因为在演出前吃大蒜而被刷掉，从此扭曲了精神，对偶像怀恨在心。",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "SUS",
	IconName = "SUS_Stamp",
	PrefabBundle = "character_enemy",
	PrefabName = "SUS_Stamp",
	PrefabScale = 50,
	HPBarHeight = 100,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 1056, Gain = 212},
		{Value = 200002, Base = 25, Gain = 5},
		{Value = 200003, Base = 25, Gain = 1},
		{Value = 200004, Base = 25, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "每3回合对后2个队员造成100%攻击伤害\n30%概率闪避攻击\n5回合后，攻击 +25%",
		Skill = {
			{
				Id = 105060,
				Value = 100,
			},
			{
				Id = 105026,
				Value = 30,
			},
			{
				Id = 105014,
				Value = 25,
			},
		},
	},
	Tags = {
		564557,
		564561,
	},
}
EnemyConfig[EnemyID.Id209] =
{
	Id = 209,
	Name = "喷壶虫",
	Rarity = 2,
	Element = 210003,
	Style = "Dps",
	AttackType = "Melee",
	Area = 
	{
		130256,
	},
	Desc = "生活在礁石区的小混混，梦想是成为人人害怕的大坏蛋，成天潜伏在沙土下面，有人路过就会突然窜出来吓人一跳，不过对方开骂就会立刻道歉。",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "SUS",
	IconName = "SUS_Letter",
	PrefabBundle = "character_enemy",
	PrefabName = "SUS_Letter",
	PrefabScale = 50,
	HPBarHeight = 100,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 1005, Gain = 201},
		{Value = 200002, Base = 24, Gain = 5},
		{Value = 200003, Base = 25, Gain = 1},
		{Value = 200004, Base = 25, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "每3回合对后2个队员造成100%攻击伤害\n30%概率闪避攻击\n5回合后，攻击 +25%",
		Skill = {
			{
				Id = 105060,
				Value = 100,
			},
			{
				Id = 105026,
				Value = 30,
			},
			{
				Id = 105014,
				Value = 25,
			},
		},
	},
	Tags = {
		564557,
		564561,
	},
}
EnemyConfig[EnemyID.Id210] =
{
	Id = 210,
	Name = "黄蜂",
	Rarity = 2,
	Element = 210003,
	Style = "Dps",
	AttackType = "Melee",
	Area = 
	{
		130256,
	},
	Desc = "热衷偶像的狂热粉丝，最疯狂时，每天都会守在偶像宿舍附近，一旦发现偶像就会冲上去强吻，遭到通缉后逃窜到大漩涡地区。",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "SUS",
	IconName = "SUS_FeatherPen",
	PrefabBundle = "character_enemy",
	PrefabName = "SUS_FeatherPen",
	PrefabScale = 50,
	HPBarHeight = 110,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 1056, Gain = 212},
		{Value = 200002, Base = 25, Gain = 5},
		{Value = 200003, Base = 25, Gain = 1},
		{Value = 200004, Base = 25, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "每3回合对后2个队员造成100%攻击伤害\n30%概率闪避攻击\n5回合后，攻击 +25%",
		Skill = {
			{
				Id = 105060,
				Value = 100,
			},
			{
				Id = 105026,
				Value = 30,
			},
			{
				Id = 105014,
				Value = 25,
			},
		},
	},
	Tags = {
		564557,
		564561,
	},
}
EnemyConfig[EnemyID.Id211] =
{
	Id = 211,
	Name = "蜂后",
	Rarity = 3,
	Element = 210003,
	Style = "Dps",
	AttackType = "Melee",
	Area = 
	{
		130256,
	},
	Desc = "热衷偶像的狂热粉丝，最疯狂时，每天都会守在偶像宿舍附近，一旦发现偶像就会冲上去强吻，遭到通缉后逃窜到大漩涡地区。",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "SUS",
	IconName = "SUS_FeatherPen",
	PrefabBundle = "character_enemy",
	PrefabName = "SUS_FeatherPen",
	PrefabScale = 50,
	HPBarHeight = 110,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 1056, Gain = 212},
		{Value = 200002, Base = 25, Gain = 5},
		{Value = 200003, Base = 25, Gain = 1},
		{Value = 200004, Base = 25, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "每3回合对后2个队员造成100%攻击伤害\n30%概率闪避攻击\n5回合后，攻击 +25%",
		Skill = {
			{
				Id = 105060,
				Value = 100,
			},
			{
				Id = 105026,
				Value = 30,
			},
			{
				Id = 105014,
				Value = 25,
			},
		},
	},
	Tags = {
		564557,
		564561,
	},
}
EnemyConfig[EnemyID.Id212] =
{
	Id = 212,
	Name = "地城守卫",
	Rarity = 3,
	Element = 210003,
	Style = "Dps",
	AttackType = "Melee",
	Area = 
	{
		130256,
	},
	Desc = "礁石区的小混混头目，从小就开始混社会，见惯大风大浪，背后还有战斗留下的疤痕，其实是小时候和小朋友抢棒棒糖时留下的。",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "SUS",
	IconName = "SUS_NumberPlate",
	PrefabBundle = "character_enemy",
	PrefabName = "SUS_NumberPlate",
	PrefabScale = 50,
	HPBarHeight = 100,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 997, Gain = 200},
		{Value = 200002, Base = 24, Gain = 5},
		{Value = 200003, Base = 25, Gain = 1},
		{Value = 200004, Base = 25, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "每3回合对后2个队员造成100%攻击伤害\n30%概率闪避攻击\n5回合后，攻击 +25%",
		Skill = {
			{
				Id = 105060,
				Value = 100,
			},
			{
				Id = 105026,
				Value = 30,
			},
			{
				Id = 105014,
				Value = 25,
			},
		},
	},
	Tags = {
		564557,
		564561,
	},
}
EnemyConfig[EnemyID.Id213] =
{
	Id = 213,
	Name = "矿山暴徒",
	Rarity = 2,
	Element = 210003,
	Style = "Dps",
	AttackType = "Melee",
	Area = 
	{
		130257,
	},
	Desc = "生活在礁石区的小混混，梦想是成为人人害怕的大坏蛋，成天潜伏在沙土下面，有人路过就会突然窜出来吓人一跳，不过对方开骂就会立刻道歉。",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "SUS",
	IconName = "SUS_Letter",
	PrefabBundle = "character_enemy",
	PrefabName = "SUS_Letter",
	PrefabScale = 50,
	HPBarHeight = 100,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 959, Gain = 192},
		{Value = 200002, Base = 24, Gain = 5},
		{Value = 200003, Base = 25, Gain = 1},
		{Value = 200004, Base = 25, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "每3回合对后2个队员造成100%攻击伤害\n30%概率闪避攻击\n5回合后，攻击 +25%",
		Skill = {
			{
				Id = 105060,
				Value = 100,
			},
			{
				Id = 105026,
				Value = 30,
			},
			{
				Id = 105014,
				Value = 25,
			},
		},
	},
	Tags = {
		564557,
		564561,
	},
}
EnemyConfig[EnemyID.Id214] =
{
	Id = 214,
	Name = "暴徒头目",
	Rarity = 3,
	Element = 210003,
	Style = "Dps",
	AttackType = "Melee",
	Area = 
	{
		130257,
	},
	Desc = "热衷偶像的狂热粉丝，最疯狂时，每天都会守在偶像宿舍附近，一旦发现偶像就会冲上去强吻，遭到通缉后逃窜到大漩涡地区。",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "SUS",
	IconName = "SUS_FeatherPen",
	PrefabBundle = "character_enemy",
	PrefabName = "SUS_FeatherPen",
	PrefabScale = 50,
	HPBarHeight = 110,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 952, Gain = 191},
		{Value = 200002, Base = 24, Gain = 5},
		{Value = 200003, Base = 25, Gain = 1},
		{Value = 200004, Base = 25, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "每3回合对后2个队员造成100%攻击伤害\n30%概率闪避攻击\n5回合后，攻击 +25%",
		Skill = {
			{
				Id = 105060,
				Value = 100,
			},
			{
				Id = 105026,
				Value = 30,
			},
			{
				Id = 105014,
				Value = 25,
			},
		},
	},
	Tags = {
		564557,
		564561,
	},
}
EnemyConfig[EnemyID.Id215] =
{
	Id = 215,
	Name = "矿甲虫",
	Rarity = 3,
	Element = 210003,
	Style = "Dps",
	AttackType = "Melee",
	Area = 
	{
		130257,
	},
	Desc = "热衷偶像的狂热粉丝，最疯狂时，每天都会守在偶像宿舍附近，一旦发现偶像就会冲上去强吻，遭到通缉后逃窜到大漩涡地区。",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "SUS",
	IconName = "SUS_FeatherPen",
	PrefabBundle = "character_enemy",
	PrefabName = "SUS_FeatherPen",
	PrefabScale = 50,
	HPBarHeight = 110,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 952, Gain = 191},
		{Value = 200002, Base = 24, Gain = 5},
		{Value = 200003, Base = 25, Gain = 1},
		{Value = 200004, Base = 25, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "每3回合对后2个队员造成100%攻击伤害\n30%概率闪避攻击\n5回合后，攻击 +25%",
		Skill = {
			{
				Id = 105060,
				Value = 100,
			},
			{
				Id = 105026,
				Value = 30,
			},
			{
				Id = 105014,
				Value = 25,
			},
		},
	},
	Tags = {
		564557,
		564561,
	},
}
EnemyConfig[EnemyID.Id216] =
{
	Id = 216,
	Name = "金甲虫",
	Rarity = 4,
	Element = 210003,
	Style = "Dps",
	AttackType = "Melee",
	Area = 
	{
		130257,
	},
	Desc = "礁石区的小混混头目，从小就开始混社会，见惯大风大浪，背后还有战斗留下的疤痕，其实是小时候和小朋友抢棒棒糖时留下的。",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "SUS",
	IconName = "SUS_NumberPlate",
	PrefabBundle = "character_enemy",
	PrefabName = "SUS_NumberPlate",
	PrefabScale = 50,
	HPBarHeight = 100,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 997, Gain = 200},
		{Value = 200002, Base = 24, Gain = 5},
		{Value = 200003, Base = 25, Gain = 1},
		{Value = 200004, Base = 25, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "每3回合对后2个队员造成100%攻击伤害\n30%概率闪避攻击\n5回合后，攻击 +25%",
		Skill = {
			{
				Id = 105060,
				Value = 100,
			},
			{
				Id = 105026,
				Value = 30,
			},
			{
				Id = 105014,
				Value = 25,
			},
		},
	},
	Tags = {
		564557,
		564561,
	},
}
EnemyConfig[EnemyID.Id217] =
{
	Id = 217,
	Name = "鼹鼠帮",
	Rarity = 2,
	Element = 210003,
	Style = "Dps",
	AttackType = "Melee",
	Area = 
	{
		130258,
	},
	Desc = "生活在礁石区的小混混，梦想是成为人人害怕的大坏蛋，成天潜伏在沙土下面，有人路过就会突然窜出来吓人一跳，不过对方开骂就会立刻道歉。",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "SUS",
	IconName = "SUS_Letter",
	PrefabBundle = "character_enemy",
	PrefabName = "SUS_Letter",
	PrefabScale = 50,
	HPBarHeight = 100,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 989, Gain = 198},
		{Value = 200002, Base = 24, Gain = 5},
		{Value = 200003, Base = 25, Gain = 1},
		{Value = 200004, Base = 25, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "每3回合对后2个队员造成100%攻击伤害\n30%概率闪避攻击\n5回合后，攻击 +25%",
		Skill = {
			{
				Id = 105060,
				Value = 100,
			},
			{
				Id = 105026,
				Value = 30,
			},
			{
				Id = 105014,
				Value = 25,
			},
		},
	},
	Tags = {
		564557,
		564561,
	},
}
EnemyConfig[EnemyID.Id218] =
{
	Id = 218,
	Name = "鼹鼠头头",
	Rarity = 3,
	Element = 210003,
	Style = "Dps",
	AttackType = "Melee",
	Area = 
	{
		130258,
	},
	Desc = "热衷偶像的狂热粉丝，最疯狂时，每天都会守在偶像宿舍附近，一旦发现偶像就会冲上去强吻，遭到通缉后逃窜到大漩涡地区。",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "SUS",
	IconName = "SUS_FeatherPen",
	PrefabBundle = "character_enemy",
	PrefabName = "SUS_FeatherPen",
	PrefabScale = 50,
	HPBarHeight = 110,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 982, Gain = 197},
		{Value = 200002, Base = 24, Gain = 5},
		{Value = 200003, Base = 25, Gain = 1},
		{Value = 200004, Base = 25, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "每3回合对后2个队员造成100%攻击伤害\n30%概率闪避攻击\n5回合后，攻击 +25%",
		Skill = {
			{
				Id = 105060,
				Value = 100,
			},
			{
				Id = 105026,
				Value = 30,
			},
			{
				Id = 105014,
				Value = 25,
			},
		},
	},
	Tags = {
		564557,
		564561,
	},
}
EnemyConfig[EnemyID.Id219] =
{
	Id = 219,
	Name = "蠕虫特工",
	Rarity = 3,
	Element = 210003,
	Style = "Dps",
	AttackType = "Melee",
	Area = 
	{
		130258,
	},
	Desc = "热衷偶像的狂热粉丝，最疯狂时，每天都会守在偶像宿舍附近，一旦发现偶像就会冲上去强吻，遭到通缉后逃窜到大漩涡地区。",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "SUS",
	IconName = "SUS_FeatherPen",
	PrefabBundle = "character_enemy",
	PrefabName = "SUS_FeatherPen",
	PrefabScale = 50,
	HPBarHeight = 110,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 974, Gain = 195},
		{Value = 200002, Base = 24, Gain = 5},
		{Value = 200003, Base = 25, Gain = 1},
		{Value = 200004, Base = 25, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "每3回合对后2个队员造成100%攻击伤害\n30%概率闪避攻击\n5回合后，攻击 +25%",
		Skill = {
			{
				Id = 105060,
				Value = 100,
			},
			{
				Id = 105026,
				Value = 30,
			},
			{
				Id = 105014,
				Value = 25,
			},
		},
	},
	Tags = {
		564557,
		564561,
	},
}
EnemyConfig[EnemyID.Id220] =
{
	Id = 220,
	Name = "谜之机械",
	Rarity = 4,
	Element = 210003,
	Style = "Dps",
	AttackType = "Melee",
	Area = 
	{
		130258,
	},
	Desc = "礁石区的小混混头目，从小就开始混社会，见惯大风大浪，背后还有战斗留下的疤痕，其实是小时候和小朋友抢棒棒糖时留下的。",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "SUS",
	IconName = "SUS_NumberPlate",
	PrefabBundle = "character_enemy",
	PrefabName = "SUS_NumberPlate",
	PrefabScale = 50,
	HPBarHeight = 100,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 997, Gain = 200},
		{Value = 200002, Base = 24, Gain = 5},
		{Value = 200003, Base = 25, Gain = 1},
		{Value = 200004, Base = 25, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "每3回合对后2个队员造成100%攻击伤害\n30%概率闪避攻击\n5回合后，攻击 +25%",
		Skill = {
			{
				Id = 105060,
				Value = 100,
			},
			{
				Id = 105026,
				Value = 30,
			},
			{
				Id = 105014,
				Value = 25,
			},
		},
	},
	Tags = {
		564557,
		564561,
	},
}
EnemyConfig[EnemyID.Id221] =
{
	Id = 221,
	Name = "机械臂",
	Rarity = 3,
	Element = 210005,
	Style = "Dps",
	AttackType = "Melee",
	Area = 
	{
		130259,
	},
	Desc = "对待每件事情都非常认真的偏执型海洋生物，平时会不停地打扫自己的螺壳，看演出时，会努力说服附近的观众挥舞荧光棒时和它的频率保持一致。",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "SUS",
	IconName = "SUS_YellowBarrier",
	PrefabBundle = "character_enemy",
	PrefabName = "SUS_YellowBarrier",
	PrefabScale = 50,
	HPBarHeight = 110,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 959, Gain = 192},
		{Value = 200002, Base = 24, Gain = 5},
		{Value = 200003, Base = 25, Gain = 1},
		{Value = 200004, Base = 25, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "每3回合对后2个队员造成100%攻击伤害\n30%概率闪避攻击\n5回合后，攻击 +25%",
		Skill = {
			{
				Id = 105060,
				Value = 100,
			},
			{
				Id = 105026,
				Value = 30,
			},
			{
				Id = 105014,
				Value = 25,
			},
		},
	},
	Tags = {
		564557,
		564561,
	},
}
EnemyConfig[EnemyID.Id222] =
{
	Id = 222,
	Name = "机器员工",
	Rarity = 3,
	Element = 210003,
	Style = "Dps",
	AttackType = "Melee",
	Area = 
	{
		130259,
	},
	Desc = "热衷偶像的狂热粉丝，最疯狂时，每天都会守在偶像宿舍附近，一旦发现偶像就会冲上去强吻，遭到通缉后逃窜到大漩涡地区。",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "SUS",
	IconName = "SUS_FeatherPen",
	PrefabBundle = "character_enemy",
	PrefabName = "SUS_FeatherPen",
	PrefabScale = 50,
	HPBarHeight = 110,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 952, Gain = 191},
		{Value = 200002, Base = 24, Gain = 5},
		{Value = 200003, Base = 25, Gain = 1},
		{Value = 200004, Base = 25, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "每3回合对后2个队员造成100%攻击伤害\n30%概率闪避攻击\n5回合后，攻击 +25%",
		Skill = {
			{
				Id = 105060,
				Value = 100,
			},
			{
				Id = 105026,
				Value = 30,
			},
			{
				Id = 105014,
				Value = 25,
			},
		},
	},
	Tags = {
		564557,
		564561,
	},
}
EnemyConfig[EnemyID.Id223] =
{
	Id = 223,
	Name = "机器工头",
	Rarity = 3,
	Element = 210002,
	Style = "Dps",
	AttackType = "Melee",
	Area = 
	{
		130259,
	},
	Desc = "斤斤计较的小气鬼，最喜欢AA制，哪怕是一分钱都要分个清楚，讨厌被别人占便宜。",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "SUS",
	IconName = "SUS_StreetLamp",
	PrefabBundle = "character_enemy",
	PrefabName = "SUS_StreetLamp",
	PrefabScale = 50,
	HPBarHeight = 140,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 945, Gain = 189},
		{Value = 200002, Base = 24, Gain = 5},
		{Value = 200003, Base = 25, Gain = 1},
		{Value = 200004, Base = 25, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "每3回合对后2个队员造成100%攻击伤害\n30%概率闪避攻击\n5回合后，攻击 +25%",
		Skill = {
			{
				Id = 105060,
				Value = 100,
			},
			{
				Id = 105026,
				Value = 30,
			},
			{
				Id = 105014,
				Value = 25,
			},
		},
	},
	Tags = {
		564557,
		564561,
	},
}
EnemyConfig[EnemyID.Id224] =
{
	Id = 224,
	Name = "失控的零件",
	Rarity = 3,
	Element = 210005,
	Style = "Dps",
	AttackType = "Melee",
	Area = 
	{
		130260,
	},
	Desc = "Aquarius的粉丝头，经常组织粉丝们打榜冲票，在大选期间会展现出领导人一般的组织力和行动力。",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "SUS",
	IconName = "SUS_ManholeCover",
	PrefabBundle = "character_enemy",
	PrefabName = "SUS_ManholeCover",
	PrefabScale = 50,
	HPBarHeight = 100,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 938, Gain = 188},
		{Value = 200002, Base = 24, Gain = 5},
		{Value = 200003, Base = 25, Gain = 1},
		{Value = 200004, Base = 25, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "每3回合对后2个队员造成100%攻击伤害\n30%概率闪避攻击\n5回合后，攻击 +25%",
		Skill = {
			{
				Id = 105060,
				Value = 100,
			},
			{
				Id = 105026,
				Value = 30,
			},
			{
				Id = 105014,
				Value = 25,
			},
		},
	},
	Tags = {
		564557,
		564561,
	},
}
EnemyConfig[EnemyID.Id225] =
{
	Id = 225,
	Name = "纯净能量体",
	Rarity = 3,
	Element = 210002,
	Style = "Dps",
	AttackType = "Melee",
	Area = 
	{
		130260,
	},
	Desc = "因为喜欢的偶像团体在数据榜上被超越而心怀怨念，久而久之成为了Sharkalaka的黑粉，专注于造谣，认为自己在做正确的事情。",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "SUS",
	IconName = "SUS_RedBarrier",
	PrefabBundle = "character_enemy",
	PrefabName = "SUS_RedBarrier",
	PrefabScale = 50,
	HPBarHeight = 110,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 952, Gain = 191},
		{Value = 200002, Base = 24, Gain = 5},
		{Value = 200003, Base = 25, Gain = 1},
		{Value = 200004, Base = 25, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "每3回合对后2个队员造成100%攻击伤害\n30%概率闪避攻击\n5回合后，攻击 +25%",
		Skill = {
			{
				Id = 105060,
				Value = 100,
			},
			{
				Id = 105026,
				Value = 30,
			},
			{
				Id = 105014,
				Value = 25,
			},
		},
	},
	Tags = {
		564557,
		564561,
	},
}
EnemyConfig[EnemyID.Id226] =
{
	Id = 226,
	Name = "人工智能G-0X",
	Rarity = 4,
	Element = 210001,
	Style = "Dps",
	AttackType = "Melee",
	Area = 
	{
		130260,
	},
	Desc = "Sharkalaka的粉丝，牙牙的个人粉。声称是牙牙最大的支持者，收集了她的各种偷拍照片，并从网上下载了每一张专辑的盗版资源。",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "SUS",
	IconName = "SUS_Hydrant",
	PrefabBundle = "character_enemy",
	PrefabName = "SUS_Hydrant",
	PrefabScale = 50,
	HPBarHeight = 120,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 952, Gain = 191},
		{Value = 200002, Base = 24, Gain = 5},
		{Value = 200003, Base = 25, Gain = 1},
		{Value = 200004, Base = 25, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "每3回合对后2个队员造成100%攻击伤害\n30%概率闪避攻击\n5回合后，攻击 +25%",
		Skill = {
			{
				Id = 105060,
				Value = 100,
			},
			{
				Id = 105026,
				Value = 30,
			},
			{
				Id = 105014,
				Value = 25,
			},
		},
	},
	Tags = {
		564557,
		564561,
	},
}
EnemyConfig[EnemyID.Id227] =
{
	Id = 227,
	Name = "高砂之翁",
	Rarity = 3,
	Element = 210002,
	Style = "Dps",
	AttackType = "Melee",
	Area = 
	{
		130260,
	},
	Desc = "贝壳街tea time成员，非常擅长乐器，演唱至高潮时会把头上的海螺拿下来即兴solo。",
	IconBundle = "atlas_charactericon_sea",
	IconAtlas = "Sea",
	IconName = "Sea_18_hailuo",
	PrefabBundle = "character_sea",
	PrefabName = "Sea_16_jingyu",
	SkinName = "1",
	PrefabScale = 50,
	HPBarHeight = 112,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 885, Gain = 177},
		{Value = 200002, Base = 23, Gain = 5},
		{Value = 200003, Base = 25, Gain = 1},
		{Value = 200004, Base = 25, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "每3回合对后2个队员造成100%攻击伤害\n30%概率闪避攻击\n5回合后，攻击 +25%",
		Skill = {
			{
				Id = 105060,
				Value = 100,
			},
			{
				Id = 105026,
				Value = 30,
			},
			{
				Id = 105014,
				Value = 25,
			},
		},
	},
	Tags = {
		564557,
		564561,
	},
}
EnemyConfig[EnemyID.Id228] =
{
	Id = 228,
	Name = "报警机器人",
	Rarity = 3,
	Element = 210003,
	Style = "Dps",
	AttackType = "Melee",
	Area = 
	{
		130261,
	},
	Desc = "广泛分部于各大海域的鱼类，对环境适应力很强，咸水或淡水下都能生活，主要喜好是时事评论，每天醒来第一件事就是看当天热搜，然后在评论区陈述己见。",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "SUS",
	IconName = "SUS_Ashtray",
	PrefabBundle = "character_enemy",
	PrefabName = "SUS_Ashtray",
	PrefabScale = 50,
	HPBarHeight = 100,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 931, Gain = 187},
		{Value = 200002, Base = 24, Gain = 5},
		{Value = 200003, Base = 25, Gain = 1},
		{Value = 200004, Base = 25, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "每3回合对后2个队员造成100%攻击伤害\n30%概率闪避攻击\n5回合后，攻击 +25%",
		Skill = {
			{
				Id = 105060,
				Value = 100,
			},
			{
				Id = 105026,
				Value = 30,
			},
			{
				Id = 105014,
				Value = 25,
			},
		},
	},
	Tags = {
		564557,
		564561,
	},
}
EnemyConfig[EnemyID.Id229] =
{
	Id = 229,
	Name = "王都警卫",
	Rarity = 3,
	Element = 210004,
	Style = "Dps",
	AttackType = "Melee",
	Area = 
	{
		130261,
	},
	Desc = "脸颊上长有白色斑纹的可爱小鱼，童年时期常被星探发现进入偶像培训班，不过往往因天赋问题只能成为后台工作人员。把全部希望寄托于偶像，当偶像做出了不符合自己想法的事，他就会大呼上当而一转变成黑粉。",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "SUS",
	IconName = "SUS_Handcuffs",
	PrefabBundle = "character_enemy",
	PrefabName = "SUS_Handcuffs",
	PrefabScale = 50,
	HPBarHeight = 110,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 924, Gain = 185},
		{Value = 200002, Base = 24, Gain = 5},
		{Value = 200003, Base = 25, Gain = 1},
		{Value = 200004, Base = 25, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "每3回合对后2个队员造成100%攻击伤害\n30%概率闪避攻击\n5回合后，攻击 +25%",
		Skill = {
			{
				Id = 105060,
				Value = 100,
			},
			{
				Id = 105026,
				Value = 30,
			},
			{
				Id = 105014,
				Value = 25,
			},
		},
	},
	Tags = {
		564557,
		564561,
	},
}
EnemyConfig[EnemyID.Id230] =
{
	Id = 230,
	Name = "王都队长",
	Rarity = 4,
	Element = 210002,
	Style = "Dps",
	AttackType = "Melee",
	Area = 
	{
		130261,
	},
	Desc = "从小就接受专业的偶像训练，有着良好的嗓音条件和外表，被无数人称赞是天生的苗子，在这一届星光小道举办之前就已经被内定为优胜者。",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "SUS",
	IconName = "SUS_CigaretteLighter",
	PrefabBundle = "character_enemy",
	PrefabName = "SUS_CigaretteLighter",
	PrefabScale = 50,
	HPBarHeight = 100,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 917, Gain = 184},
		{Value = 200002, Base = 24, Gain = 5},
		{Value = 200003, Base = 25, Gain = 1},
		{Value = 200004, Base = 25, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "每3回合对后2个队员造成100%攻击伤害\n30%概率闪避攻击\n5回合后，攻击 +25%",
		Skill = {
			{
				Id = 105060,
				Value = 100,
			},
			{
				Id = 105026,
				Value = 30,
			},
			{
				Id = 105014,
				Value = 25,
			},
		},
	},
	Tags = {
		564557,
		564561,
	},
}
EnemyConfig[EnemyID.Id231] =
{
	Id = 231,
	Name = "左旗护卫",
	Rarity = 3,
	Element = 210003,
	Style = "Dps",
	AttackType = "Melee",
	Area = 
	{
		130262,
	},
	Desc = "闪亮海星经纪公司干部，原本只是一个普通的员工，因为挖掘了牙牙而在公司内地位飙升，不过最近公司不景气正面临着失业的危机。",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "SUS",
	IconName = "SUS_Photo",
	PrefabBundle = "character_enemy",
	PrefabName = "SUS_Photo",
	PrefabScale = 50,
	HPBarHeight = 100,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 911, Gain = 183},
		{Value = 200002, Base = 24, Gain = 5},
		{Value = 200003, Base = 25, Gain = 1},
		{Value = 200004, Base = 25, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "每3回合对后2个队员造成100%攻击伤害\n30%概率闪避攻击\n5回合后，攻击 +25%",
		Skill = {
			{
				Id = 105060,
				Value = 100,
			},
			{
				Id = 105026,
				Value = 30,
			},
			{
				Id = 105014,
				Value = 25,
			},
		},
	},
	Tags = {
		564557,
		564561,
	},
}
EnemyConfig[EnemyID.Id232] =
{
	Id = 232,
	Name = "右旗护卫",
	Rarity = 3,
	Element = 210004,
	Style = "Dps",
	AttackType = "Melee",
	Area = 
	{
		130262,
	},
	Desc = "闪亮海星经纪公司的参谋，负责旗下艺人的公关问题，擅长使用各种社交媒体，用转移矛盾的方式引导舆论。",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "SUS",
	IconName = "SUS_Alarm",
	PrefabBundle = "character_enemy",
	PrefabName = "SUS_Alarm",
	PrefabScale = 50,
	HPBarHeight = 100,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 1056, Gain = 212},
		{Value = 200002, Base = 25, Gain = 5},
		{Value = 200003, Base = 25, Gain = 1},
		{Value = 200004, Base = 25, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "每3回合对后2个队员造成100%攻击伤害\n30%概率闪避攻击\n5回合后，攻击 +25%",
		Skill = {
			{
				Id = 105060,
				Value = 100,
			},
			{
				Id = 105026,
				Value = 30,
			},
			{
				Id = 105014,
				Value = 25,
			},
		},
	},
	Tags = {
		564557,
		564561,
	},
}
EnemyConfig[EnemyID.Id233] =
{
	Id = 233,
	Name = "爱之蔓",
	Rarity = 4,
	Element = 210002,
	Style = "Dps",
	AttackType = "Melee",
	Area = 
	{
		130262,
	},
	Desc = "贝壳街tea time成员，当聚光灯打下来的时候就把自己的珍珠亮出来，总是闪瞎台下观众的眼睛。",
	IconBundle = "atlas_charactericon_sea",
	IconAtlas = "Sea",
	IconName = "Sea_19_shanbei",
	PrefabBundle = "character_sea",
	PrefabName = "Sea_18_hailuo",
	SkinName = "1",
	PrefabScale = 50,
	HPBarHeight = 112,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 998, Gain = 200},
		{Value = 200002, Base = 11, Gain = 3},
		{Value = 200003, Base = 25, Gain = 1},
		{Value = 200004, Base = 25, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id234] =
{
	Id = 234,
	Name = "守门机器人",
	Rarity = 3,
	Element = 210003,
	Style = "Dps",
	AttackType = "Melee",
	Area = 
	{
		130263,
	},
	Desc = "海洋星罪犯，为了逃避抓捕而藏在了海底，会对来抓他的人喷墨。自认为逃跑技术天下无敌，其实是因为他的涉案金额没达到立案标准。",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "SUS",
	IconName = "SUS_PocketWatch",
	PrefabBundle = "character_enemy",
	PrefabName = "SUS_PocketWatch",
	PrefabScale = 50,
	HPBarHeight = 100,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 861, Gain = 173},
		{Value = 200002, Base = 23, Gain = 5},
		{Value = 200003, Base = 25, Gain = 1},
		{Value = 200004, Base = 25, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "每3回合对后2个队员造成100%攻击伤害\n30%概率闪避攻击\n5回合后，攻击 +25%",
		Skill = {
			{
				Id = 105060,
				Value = 100,
			},
			{
				Id = 105026,
				Value = 30,
			},
			{
				Id = 105014,
				Value = 25,
			},
		},
	},
	Tags = {
		564557,
		564561,
	},
}
EnemyConfig[EnemyID.Id235] =
{
	Id = 235,
	Name = "武装鼹鼠",
	Rarity = 4,
	Element = 210004,
	Style = "Dps",
	AttackType = "Melee",
	Area = 
	{
		130263,
	},
	Desc = "脸颊上长有白色斑纹的可爱小鱼，童年时期常被星探发现进入偶像培训班，不过往往因天赋问题只能成为后台工作人员。把全部希望寄托于偶像，当偶像做出了不符合自己想法的事，他就会大呼上当而一转变成黑粉。",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "SUS",
	IconName = "SUS_Handcuffs",
	PrefabBundle = "character_enemy",
	PrefabName = "SUS_Handcuffs",
	PrefabScale = 50,
	HPBarHeight = 110,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 855, Gain = 171},
		{Value = 200002, Base = 23, Gain = 5},
		{Value = 200003, Base = 25, Gain = 1},
		{Value = 200004, Base = 25, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "每3回合对后2个队员造成100%攻击伤害\n30%概率闪避攻击\n5回合后，攻击 +25%",
		Skill = {
			{
				Id = 105060,
				Value = 100,
			},
			{
				Id = 105026,
				Value = 30,
			},
			{
				Id = 105014,
				Value = 25,
			},
		},
	},
	Tags = {
		564557,
		564561,
	},
}
EnemyConfig[EnemyID.Id236] =
{
	Id = 236,
	Name = "毒蝎",
	Rarity = 4,
	Element = 210002,
	Style = "Dps",
	AttackType = "Melee",
	Area = 
	{
		130263,
	},
	Desc = "隐藏在星球底部的传说中的生物，攻击性极强，会对着靠近他的人伸出触手，但其实只是因为他看不见。",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "SUS",
	IconName = "SUS_Pipe",
	PrefabBundle = "character_enemy",
	PrefabName = "SUS_Pipe",
	PrefabScale = 50,
	HPBarHeight = 100,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 855, Gain = 171},
		{Value = 200002, Base = 23, Gain = 5},
		{Value = 200003, Base = 25, Gain = 1},
		{Value = 200004, Base = 25, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "每3回合对后2个队员造成100%攻击伤害\n30%概率闪避攻击\n5回合后，攻击 +25%",
		Skill = {
			{
				Id = 105060,
				Value = 100,
			},
			{
				Id = 105026,
				Value = 30,
			},
			{
				Id = 105014,
				Value = 25,
			},
		},
	},
	Tags = {
		564557,
		564561,
	},
}
EnemyConfig[EnemyID.Id237] =
{
	Id = 237,
	Name = "爱之蔓",
	Rarity = 4,
	Element = 210002,
	Style = "Dps",
	AttackType = "Melee",
	Area = 
	{
		130263,
	},
	Desc = "贝壳街tea time成员，当聚光灯打下来的时候就把自己的珍珠亮出来，总是闪瞎台下观众的眼睛。",
	IconBundle = "atlas_charactericon_sea",
	IconAtlas = "Sea",
	IconName = "Sea_19_shanbei",
	PrefabBundle = "character_sea",
	PrefabName = "Sea_18_hailuo",
	SkinName = "1",
	PrefabScale = 50,
	HPBarHeight = 112,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 849, Gain = 170},
		{Value = 200002, Base = 23, Gain = 5},
		{Value = 200003, Base = 25, Gain = 1},
		{Value = 200004, Base = 25, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "每3回合对后2个队员造成100%攻击伤害\n30%概率闪避攻击\n5回合后，攻击 +25%",
		Skill = {
			{
				Id = 105060,
				Value = 100,
			},
			{
				Id = 105026,
				Value = 30,
			},
			{
				Id = 105014,
				Value = 25,
			},
		},
	},
	Tags = {
		564557,
		564561,
	},
}
EnemyConfig[EnemyID.Id801] =
{
	Id = 801,
	Name = "黑暗料理师",
	Rarity = 4,
	Element = 210002,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "与光明料理会不共戴天的料理者。被美食星驱逐后，成为了流亡街的居民。目前处于无照经营摊贩的状态，会推着料理小车，制作出让人无法拒绝的邪恶美食。",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	IconName = "Pir_01_DarkCooker",
	PrefabBundle = "character_boss",
	PrefabName = "Pir_01_DarkCooker",
	SkinName = "1",
	PrefabScale = 50,
	HPBarHeight = 125,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_3",
		RangeAttackEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 5350, Gain = 1070},
		{Value = 200002, Base = 37, Gain = 8},
		{Value = 200003, Base = 25, Gain = 1},
		{Value = 200004, Base = 25, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "诱人香味：攻击时无视敌人50%忍耐\n秘制浓浆：每3回合对前3个队员造成100%攻击伤害\n独家调料：每回合有50%概率自身回血 5%，最多5次\n愤怒的榴莲：回合中，每次受击，攻击 +3%",
		Skill = {
			{
				Id = 105168,
				Value = 50,
			},
			{
				Id = 105057,
				Value = 100,
			},
			{
				Id = 105017,
				Value = 5,
			},
			{
				Id = 105170,
				Value = 3,
			},
		},
	},
	Tags = {
		564560,
		564561,
		564563,
	},
}
EnemyConfig[EnemyID.Id802] =
{
	Id = 802,
	Name = "飙车高手",
	Rarity = 4,
	Element = 210003,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "任何载具都能驾驭自如的星际飙车王，从独轮车到摩托车、小型飞机、快艇、星河战舰，只要是能驾驶的都能飙。但是不知道为什么，他经常在互联网上被禁言。",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	IconName = "Pir_03_RacingDriver",
	PrefabBundle = "character_boss",
	PrefabName = "Pir_03_RacingDriver",
	SkinName = "1",
	PrefabScale = 50,
	HPBarHeight = 125,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1",
		},
		CritAttackAnim = "Attack_2",
		BattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_3",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 3259, Gain = 652},
		{Value = 200002, Base = 13, Gain = 3},
		{Value = 200003, Base = 25, Gain = 1},
		{Value = 200004, Base = 25, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "1段冲刺：2~3回合对前2个队员造成100%攻击伤害\n2段冲刺：4~5回合对前3个队员造成100%攻击伤害\n3段冲刺6回合后对前4个队员造成100%攻击伤害\n引擎启动：每2回合攻击 +100%，最多5次",
		Skill = {
			{
				Id = 105175,
				Value = 100,
			},
			{
				Id = 105176,
				Value = 100,
			},
			{
				Id = 105177,
				Value = 100,
			},
			{
				Id = 105178,
				Value = 100,
			},
		},
	},
	Tags = {
		564561,
	},
}
EnemyConfig[EnemyID.Id803] =
{
	Id = 803,
	Name = "术士",
	Rarity = 4,
	Element = 210001,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "来自喧嚣之城的异族术士，以全A成绩进入魔法学院。然而即使在学术氛围浓郁的魔法学院里，仍因头上的奇怪犄角而遭人排挤。值得一提的是，术士在异世界语方面似乎极具天赋。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	IconName = "RPG_108_Warlock",
	PrefabBundle = "character_rpg",
	PrefabName = "RPG_108_Warlock",
	SkinName = "1",
	PrefabScale = 50,
	HPBarHeight = 125,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 8905, Gain = 1273},
		{Value = 200002, Base = 49, Gain = 7},
		{Value = 200003, Base = 25, Gain = 1},
		{Value = 200004, Base = 25, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "恶魔亲和：受暗元素敌人伤害 -75%\n扭曲之力：攻击时无视敌人100%忍耐\n恶魔之血每回合回血 7%，最多5次",
		Skill = {
			{
				Id = 105037,
				Value = -75,
			},
			{
				Id = 105168,
				Value = 100,
			},
			{
				Id = 105005,
				Value = 7,
			},
		},
	},
	Tags = {
		564560,
		564563,
	},
}
EnemyConfig[EnemyID.Id804] =
{
	Id = 804,
	Name = "另一个呜呜",
	Rarity = 2,
	Element = 210004,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "可爱的橘色小猫，很受周围人的疼爱，十分调皮但也十分善良。虽然胆小，但是当同伴陷入危险时是绝对不会后退的。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	IconName = "All_wuwu",
	PrefabBundle = "character_rpg",
	PrefabName = "All_wuwu",
	SkinName = "1",
	PrefabScale = 50,
	HPBarHeight = 105,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 6848, Gain = 979},
		{Value = 200002, Base = 70, Gain = 10},
		{Value = 200003, Base = 25, Gain = 1},
		{Value = 200004, Base = 25, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "猫猫恢复术：每回合回血 20%，最多5次",
		Skill = {
			{
				Id = 105005,
				Value = 20,
			},
		},
	},
	Tags = {
		564560,
	},
}
EnemyConfig[EnemyID.Id805] =
{
	Id = 805,
	Name = "另一个漆漆",
	Rarity = 3,
	Element = 210005,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "流浪的黑色小猫，是呜呜最重要的伙伴，警觉性和战斗力都很优秀。如果呜呜被欺负，就一定会挺身而出。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	IconName = "All_gugu",
	PrefabBundle = "character_rpg",
	PrefabName = "All_gugu",
	SkinName = "1",
	PrefabScale = 50,
	HPBarHeight = 105,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 7346, Gain = 1050},
		{Value = 200002, Base = 66, Gain = 10},
		{Value = 200003, Base = 25, Gain = 1},
		{Value = 200004, Base = 25, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "猫猫连击术：有20%概率额外攻击2次",
		Skill = {
			{
				Id = 105024,
				Value = 20,
			},
		},
	},
	Tags = {
		564558,
	},
}
EnemyConfig[EnemyID.Id806] =
{
	Id = 806,
	Name = "另一个爷爷",
	Rarity = 3,
	Element = 210003,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "老年男性，享受着安详的退休生活，但是偶尔也会有发火的时候。",
	IconBundle = "atlas_charactericon_npc",
	IconAtlas = "NPC",
	IconName = "NPC_oldmen1",
	PrefabBundle = "character_npc",
	PrefabName = "NPC_oldmen1",
	SkinName = "1",
	PrefabScale = 50,
	HPBarHeight = 100,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 6958, Gain = 994},
		{Value = 200002, Base = 69, Gain = 10},
		{Value = 200003, Base = 25, Gain = 1},
		{Value = 200004, Base = 25, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "铁脸皮：受到的暴击伤害 -60%\n灵动身法：20%概率闪避攻击",
		Skill = {
			{
				Id = 105039,
				Value = -60,
			},
			{
				Id = 105026,
				Value = 20,
			},
		},
	},
	Tags = {
		564557,
	},
}
EnemyConfig[EnemyID.Id807] =
{
	Id = 807,
	Name = "百变怪客",
	Rarity = 5,
	Element = 210005,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "是来自遥远星球的百变怪人。因马戏团长克扣工资而逃走，凭借出色的变身能力潜入流亡街。根据记录，很少人见过他的本体，而他能够变身成任何形象，且快速学习并模仿对象的言行举止。",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	IconName = "Pir_04_ChangeableMan",
	PrefabBundle = "character_boss",
	PrefabName = "Pir_04_ChangeableMan",
	SkinName = "1",
	PrefabScale = 50,
	HPBarHeight = 125,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 7092, Gain = 1014},
		{Value = 200002, Base = 54, Gain = 8},
		{Value = 200003, Base = 25, Gain = 1},
		{Value = 200004, Base = 25, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "危险礼品：奇数回合有50%概率对末位队员造成90%攻击伤害\n爆炸礼物：每2回合有50%概率对前2个队员造成100%攻击伤害\n百变怪形：5回合后，自身元素变为随机元素\n幻影手法：每2回合，本回合100%概率额外攻击1次",
		Skill = {
			{
				Id = 105179,
				Value = 90,
			},
			{
				Id = 105088,
				Value = 100,
			},
			{
				Id = 105161,
				Value = -1,
			},
			{
				Id = 105131,
				Value = 100,
			},
		},
	},
	Tags = {
		564558,
	},
}
EnemyConfig[EnemyID.Id808] =
{
	Id = 808,
	Name = "订单小鸽",
	Rarity = 5,
	Element = 210003,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "非常喜欢结伴出游的鸟类，不过到了约定当天总是会接到Ta的各种表示无法如约的电话。",
	IconBundle = "atlas_charactericon_npc",
	IconAtlas = "NPC",
	IconName = "NPC_gugu1",
	PrefabBundle = "character_npc",
	PrefabName = "NPC_gugu1",
	SkinName = "1",
	PrefabScale = 50,
	HPBarHeight = 100,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 6320, Gain = 903},
		{Value = 200002, Base = 69, Gain = 10},
		{Value = 200003, Base = 25, Gain = 1},
		{Value = 200004, Base = 25, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "不接电话：受到的暴击伤害 -50%\n拼命奶：每3回合回血 20%，最多5次\n玩什么，带我个：每2回合对所有队员造成33%攻击伤害",
		Skill = {
			{
				Id = 105039,
				Value = -50,
			},
			{
				Id = 105009,
				Value = 20,
			},
			{
				Id = 105055,
				Value = 33,
			},
		},
	},
	Tags = {
		564560,
	},
}
EnemyConfig[EnemyID.Id809] =
{
	Id = 809,
	Name = "“伯爵”",
	Rarity = 5,
	Element = 210005,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "代号“伯爵”的犯罪分子，相传出身自高贵的家族。因为追求极致的艺术品，“伯爵”变得越来越孤僻。终日远离人群，独自钻研着赋予艺术品生命的方法。",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	IconName = "Pir_09_DarkCount",
	PrefabBundle = "character_boss",
	PrefabName = "Pir_09_DarkCount",
	SkinName = "1",
	PrefabScale = 50,
	HPBarHeight = 125,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 7625, Gain = 1090},
		{Value = 200002, Base = 69, Gain = 10},
		{Value = 200003, Base = 25, Gain = 1},
		{Value = 200004, Base = 25, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "冰冷气息：奇数回合，降低敌人75%回血效果\n蝙蝠掠翼：每3回合对后2个队员造成120%攻击伤害\n贵族之姿：每3回合，100%概率闪避攻击\n鲜血仪式：每3回合回血 20%，最多5次",
		Skill = {
			{
				Id = 105207,
				Value = 75,
			},
			{
				Id = 105060,
				Value = 120,
			},
			{
				Id = 105140,
				Value = 100,
			},
			{
				Id = 105009,
				Value = 20,
			},
		},
	},
	Tags = {
		564557,
		564560,
		564564,
	},
}
EnemyConfig[EnemyID.Id810] =
{
	Id = 810,
	Name = "凶手",
	Rarity = 5,
	Element = 210005,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "令人闻风丧胆的凶手，没人知道ta的身份。只要ta出现，大家就会放弃抵抗落荒而逃，然后露出破绽，被他轻易击杀。",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	IconName = "Sus_28_heiyiren",
	PrefabBundle = "character_sus",
	PrefabName = "Sus_28_heiyiren",
	SkinName = "1",
	PrefabScale = 50,
	HPBarHeight = 112,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 7702, Gain = 1101},
		{Value = 200002, Base = 47, Gain = 7},
		{Value = 200003, Base = 25, Gain = 1},
		{Value = 200004, Base = 25, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "完美演技：每回合将自身元素变为随机元素\n再来三次：有80%概率额外攻击3次\n幕后角色：对光元素敌人伤害 +60%\n绝妙手法：每回合对后3个队员造成40%攻击伤害",
		Skill = {
			{
				Id = 105162,
				Value = -1,
			},
			{
				Id = 105025,
				Value = 80,
			},
			{
				Id = 105031,
				Value = 60,
			},
			{
				Id = 105045,
				Value = 40,
			},
		},
	},
	Tags = {
		564558,
	},
}
EnemyConfig[EnemyID.Id811] =
{
	Id = 811,
	Name = "“波罗”",
	Rarity = 5,
	Element = 210005,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "痴迷侦探小说的危险分子，本身也是著名侦探，在一次与正牌波罗的推理比赛中彻底败北，从此一面羡慕着波罗的一切，一面又对他恨之入骨，最终加入了海贼团，成为了真正的犯罪分子。",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	IconName = "Pir_06_DarkPolo",
	PrefabBundle = "character_boss",
	PrefabName = "Pir_06_DarkPolo",
	SkinName = "1",
	PrefabScale = 50,
	HPBarHeight = 125,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 8144, Gain = 1164},
		{Value = 200002, Base = 87, Gain = 13},
		{Value = 200003, Base = 25, Gain = 1},
		{Value = 200004, Base = 25, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "骄傲：降低100%等级减少效果\n嫉妒：每回合攻击 +10%，最多5次\n坚韧不拔：回合中，每次受击，回血3%\n粗心大意：受暗元素敌人伤害 +75%",
		Skill = {
			{
				Id = 105173,
				Value = 100,
			},
			{
				Id = 105006,
				Value = 10,
			},
			{
				Id = 105186,
				Value = 3,
			},
			{
				Id = 105221,
				Value = 75,
			},
		},
	},
	Tags = {
		564560,
		564561,
		564564,
	},
}
EnemyConfig[EnemyID.Id1001] =
{
	Id = 1001,
	Name = "临时敌人",
	Rarity = 1,
	Element = 210003,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "体内带有大量绿色素的小精灵，喜欢捡冒险者丢掉的东西，被它碰到的东西就会被染成绿色，不要丢下帽子。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	IconName = "RPG_Slime_green",
	PrefabBundle = "character_enemy",
	PrefabName = "RPG_Slime_green",
	PrefabScale = 50,
	HPBarHeight = 69,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 2234, Gain = 447},
		{Value = 200002, Base = 45, Gain = 9},
		{Value = 200003, Base = 25, Gain = 1},
		{Value = 200004, Base = 25, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "15%概率闪避攻击\n攻击 +15%",
		Skill = {
			{
				Id = 105026,
				Value = 15,
			},
			{
				Id = 105002,
				Value = 15,
			},
		},
	},
	Tags = {
		562933,
		564557,
		564561,
	},
}
EnemyConfig[EnemyID.Id1002] =
{
	Id = 1002,
	Name = "临时敌人",
	Rarity = 1,
	Element = 210003,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "体内带有大量绿色素的小精灵，喜欢捡冒险者丢掉的东西，被它碰到的东西就会被染成绿色，不要丢下帽子。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	IconName = "RPG_Slime_green",
	PrefabBundle = "character_enemy",
	PrefabName = "RPG_Slime_green",
	PrefabScale = 50,
	HPBarHeight = 69,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 1842, Gain = 369},
		{Value = 200002, Base = 45, Gain = 9},
		{Value = 200003, Base = 25, Gain = 1},
		{Value = 200004, Base = 25, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "100%概率无视敌人闪避\n受到的暴击伤害 -50%",
		Skill = {
			{
				Id = 105027,
				Value = 100,
			},
			{
				Id = 105039,
				Value = -50,
			},
		},
	},
	Tags = {
		562933,
		564559,
	},
}
EnemyConfig[EnemyID.Id1003] =
{
	Id = 1003,
	Name = "临时敌人",
	Rarity = 1,
	Element = 210003,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "体内带有大量绿色素的小精灵，喜欢捡冒险者丢掉的东西，被它碰到的东西就会被染成绿色，不要丢下帽子。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	IconName = "RPG_Slime_green",
	PrefabBundle = "character_enemy",
	PrefabName = "RPG_Slime_green",
	PrefabScale = 50,
	HPBarHeight = 69,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 2304, Gain = 461},
		{Value = 200002, Base = 45, Gain = 9},
		{Value = 200003, Base = 25, Gain = 1},
		{Value = 200004, Base = 25, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "暴击伤害 +200%",
		Skill = {
			{
				Id = 105038,
				Value = 200,
			},
		},
	},
	Tags = {
		562933,
	},
}
EnemyConfig[EnemyID.Id1004] =
{
	Id = 1004,
	Name = "临时敌人",
	Rarity = 1,
	Element = 210003,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "体内带有大量绿色素的小精灵，喜欢捡冒险者丢掉的东西，被它碰到的东西就会被染成绿色，不要丢下帽子。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	IconName = "RPG_Slime_green",
	PrefabBundle = "character_enemy",
	PrefabName = "RPG_Slime_green",
	PrefabScale = 50,
	HPBarHeight = 69,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 2304, Gain = 461},
		{Value = 200002, Base = 45, Gain = 9},
		{Value = 200003, Base = 25, Gain = 1},
		{Value = 200004, Base = 25, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "暴击伤害 +200%",
		Skill = {
			{
				Id = 105038,
				Value = 200,
			},
		},
	},
	Tags = {
		562933,
	},
}
EnemyConfig[EnemyID.Id1005] =
{
	Id = 1005,
	Name = "协会的同伴",
	Rarity = 3,
	Element = 210003,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "虽然不能保证公主不被绑架，但是能保证第一时间出发救援！\n“欸！小绿帽上的羽毛在抖动，公主有危险！”",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	IconName = "Rpg_05_jianshi_cos10",
	PrefabBundle = "character_rpg",
	PrefabName = "Rpg_05_jianshi",
	SkinName = "2",
	PrefabScale = 50,
	HPBarHeight = 150,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 3133, Gain = 627},
		{Value = 200002, Base = 58, Gain = 12},
		{Value = 200003, Base = 25, Gain = 1},
		{Value = 200004, Base = 25, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "15%概率闪避攻击\n攻击 +15%",
		Skill = {
			{
				Id = 105026,
				Value = 15,
			},
			{
				Id = 105002,
				Value = 15,
			},
		},
	},
	Tags = {
		562933,
		564557,
		564561,
	},
}
EnemyConfig[EnemyID.Id1006] =
{
	Id = 1006,
	Name = "剑术大师",
	Rarity = 3,
	Element = 210003,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "冒险世界中神秘又强大的组织，猎魔人以消灭企图摧毁世界的恶魔为己任，无论敌人多么强大，他们都不会后退一步，除非朋友们约他先打一局昆特牌。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	IconName = "Rpg_16_lieren_cos10",
	PrefabBundle = "character_rpg",
	PrefabName = "Rpg_16_lieren",
	SkinName = "2",
	PrefabScale = 50,
	HPBarHeight = 140,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 2531, Gain = 507},
		{Value = 200002, Base = 57, Gain = 12},
		{Value = 200003, Base = 25, Gain = 1},
		{Value = 200004, Base = 25, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "100%概率无视敌人闪避\n受到的暴击伤害 -50%",
		Skill = {
			{
				Id = 105027,
				Value = 100,
			},
			{
				Id = 105039,
				Value = -50,
			},
		},
	},
	Tags = {
		562933,
		564559,
	},
}
EnemyConfig[EnemyID.Id1007] =
{
	Id = 1007,
	Name = "黑奖池商人",
	Rarity = 3,
	Element = 210005,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "初级金币池收集度100%的冒险者才能获得的特殊角色。遇到什么都会“啊呜”一口吞到肚子里的史莱姆大王，身体里面有大量不知道从哪里捡来的东西，似乎也有不少人员情报。",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	IconName = "SPDraw_01_SlimeKing",
	PrefabBundle = "character_sp",
	PrefabName = "SPDraw_01_SlimeKing",
	SkinName = "1",
	PrefabScale = 50,
	HPBarHeight = 125,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 3080, Gain = 616},
		{Value = 200002, Base = 57, Gain = 12},
		{Value = 200003, Base = 25, Gain = 1},
		{Value = 200004, Base = 25, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "暴击伤害 +200%",
		Skill = {
			{
				Id = 105038,
				Value = 200,
			},
		},
	},
	Tags = {
		562933,
	},
}
EnemyConfig[EnemyID.Id1008] =
{
	Id = 1008,
	Name = "磨叽的村长",
	Rarity = 1,
	Element = 210002,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "守候在村子里德高望重的角色，同时担负着向冒险者发布主线任务及发放奖励的重要责任。不过会私下吞掉任务奖励的回扣，并瞒着妻子偷偷藏下私房钱。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	IconName = "Rpg_20_laoyeye",
	PrefabBundle = "character_rpg",
	PrefabName = "Rpg_20_laoyeye",
	SkinName = "1",
	PrefabScale = 50,
	HPBarHeight = 115,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 2981, Gain = 597},
		{Value = 200002, Base = 57, Gain = 12},
		{Value = 200003, Base = 25, Gain = 1},
		{Value = 200004, Base = 25, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "每回合回血 5%，最多5次\n5回合后，回血 25%",
		Skill = {
			{
				Id = 105005,
				Value = 5,
			},
			{
				Id = 105013,
				Value = 25,
			},
		},
	},
	Tags = {
		562933,
		564560,
	},
}
EnemyConfig[EnemyID.Id1009] =
{
	Id = 1009,
	Name = "拦路的树怪",
	Rarity = 2,
	Element = 210003,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "憨直的大树怪，结出的果实美味可口，听说还帮助科学家发现了万有引力。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	IconName = "RPG_dashu",
	PrefabBundle = "character_enemy",
	PrefabName = "RPG_dashu",
	PrefabScale = 50,
	HPBarHeight = 141,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 2991, Gain = 599},
		{Value = 200002, Base = 56, Gain = 12},
		{Value = 200003, Base = 25, Gain = 1},
		{Value = 200004, Base = 25, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "忍耐 +100",
		Skill = {
			{
				Id = 105003,
				Value = 100,
			},
		},
	},
	Tags = {
		562933,
		564561,
	},
}
EnemyConfig[EnemyID.Id1010] =
{
	Id = 1010,
	Name = "路人地精",
	Rarity = 2,
	Element = 210003,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "冒险星人气NPC，拥有没人见过的非凡实力。卖出去1000块的道具，下一秒就是100块的回收价，却没有谁敢和他们吵架。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	IconName = "Rpg_14_lvxingshangren",
	PrefabBundle = "character_rpg",
	PrefabName = "Rpg_14_lvxingshangren",
	SkinName = "1",
	PrefabScale = 50,
	HPBarHeight = 105,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 3797, Gain = 760},
		{Value = 200002, Base = 60, Gain = 12},
		{Value = 200003, Base = 25, Gain = 1},
		{Value = 200004, Base = 25, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "有33%概率额外攻击1次",
		Skill = {
			{
				Id = 105023,
				Value = 33,
			},
		},
	},
	Tags = {
		562933,
		564558,
	},
}
EnemyConfig[EnemyID.Id1011] =
{
	Id = 1011,
	Name = "路人魔族",
	Rarity = 2,
	Element = 210005,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "魔王公司中层干部，平时会带着低级雇员们在路上堵截低级勇者搞业绩。不过因为掉落物不错，所以也常被高级勇者蹲点刷。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	IconName = "Rpg_13_dashouxiaodi",
	PrefabBundle = "character_rpg",
	PrefabName = "Rpg_13_dashouxiaodi",
	SkinName = "1",
	PrefabScale = 50,
	HPBarHeight = 105,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 3797, Gain = 760},
		{Value = 200002, Base = 63, Gain = 13},
		{Value = 200003, Base = 25, Gain = 1},
		{Value = 200004, Base = 25, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "每回合忍耐 +20，最多5次",
		Skill = {
			{
				Id = 105007,
				Value = 20,
			},
		},
	},
	Tags = {
		562933,
		564561,
	},
}
EnemyConfig[EnemyID.Id1012] =
{
	Id = 1012,
	Name = "协会的同伴",
	Rarity = 3,
	Element = 210002,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "虽然不能保证公主不被绑架，但是能保证第一时间出发救援！\n“欸！小绿帽上的羽毛在抖动，公主有危险！”",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	IconName = "Rpg_05_jianshi_cos10",
	PrefabBundle = "character_rpg",
	PrefabName = "Rpg_05_jianshi",
	SkinName = "2",
	PrefabScale = 50,
	HPBarHeight = 150,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 3395, Gain = 679},
		{Value = 200002, Base = 61, Gain = 13},
		{Value = 200003, Base = 25, Gain = 1},
		{Value = 200004, Base = 25, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "20%概率闪避攻击\n攻击 +20%",
		Skill = {
			{
				Id = 105026,
				Value = 20,
			},
			{
				Id = 105002,
				Value = 20,
			},
		},
	},
	Tags = {
		562933,
		564557,
		564561,
	},
}
EnemyConfig[EnemyID.Id1013] =
{
	Id = 1013,
	Name = "某步堂",
	Rarity = 2,
	Element = 210003,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "背负着被告所有希望的悬疑星上班族，根据表面上的证据往往能得出不同结论，帮助被告脱罪，顺带把证人席上的某人定罪。\n“上了证人席，你还想跑？”",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	IconName = "Sus_13_lvshi",
	PrefabBundle = "character_sus",
	PrefabName = "Sus_13_lvshi",
	SkinName = "1",
	PrefabScale = 50,
	HPBarHeight = 112,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 2829, Gain = 566},
		{Value = 200002, Base = 61, Gain = 13},
		{Value = 200003, Base = 25, Gain = 1},
		{Value = 200004, Base = 25, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "100%概率无视敌人闪避\n暴击伤害 +150%",
		Skill = {
			{
				Id = 105027,
				Value = 100,
			},
			{
				Id = 105038,
				Value = 150,
			},
		},
	},
	Tags = {
		562933,
		564559,
	},
}
EnemyConfig[EnemyID.Id1014] =
{
	Id = 1014,
	Name = "搞事情的手机",
	Rarity = 3,
	Element = 210005,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "犯罪现场遗留下来的手机，被害人还来不及翻开盖子就遇害了。这个教训告诉我们要买智能机。",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "SUS",
	IconName = "SUS_MobilePhone",
	PrefabBundle = "character_enemy",
	PrefabName = "SUS_MobilePhone",
	PrefabScale = 50,
	HPBarHeight = 100,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 2960, Gain = 592},
		{Value = 200002, Base = 48, Gain = 10},
		{Value = 200003, Base = 25, Gain = 1},
		{Value = 200004, Base = 25, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "每回合对前2个队员造成100%攻击伤害\n每回合攻击 +15%，最多5次",
		Skill = {
			{
				Id = 105040,
				Value = 100,
			},
			{
				Id = 105006,
				Value = 15,
			},
		},
	},
	Tags = {
		562933,
		564561,
	},
}
EnemyConfig[EnemyID.Id1015] =
{
	Id = 1015,
	Name = "可怕的虫子",
	Rarity = 2,
	Element = 210005,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "藏在暗处的异生物，随星球创造而生。内部有严格的等级制度，普通霸格偶尔被看到也会被无视，高危霸格反而每天都要担心被除虫者干掉。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	IconName = "Rpg_28_bug",
	PrefabBundle = "character_rpg",
	PrefabName = "Rpg_28_bug",
	SkinName = "1",
	PrefabScale = 50,
	HPBarHeight = 105,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 3795, Gain = 759},
		{Value = 200002, Base = 63, Gain = 13},
		{Value = 200003, Base = 25, Gain = 1},
		{Value = 200004, Base = 25, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "33%概率闪避攻击\n有15%概率额外攻击2次",
		Skill = {
			{
				Id = 105026,
				Value = 33,
			},
			{
				Id = 105024,
				Value = 15,
			},
		},
	},
	Tags = {
		562933,
		564557,
		564558,
	},
}
EnemyConfig[EnemyID.Id1016] =
{
	Id = 1016,
	Name = "噪音制造者",
	Rarity = 2,
	Element = 210003,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "很久很久以前，一位画家为想要呐喊之人而作的画。流传至今变成了一个流行的表情。",
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "Mus",
	IconName = "MUS_19_nahan",
	PrefabBundle = "character_mus",
	PrefabName = "MUS_19_nahan",
	SkinName = "1",
	PrefabScale = 50,
	HPBarHeight = 115,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 3522, Gain = 705},
		{Value = 200002, Base = 39, Gain = 8},
		{Value = 200003, Base = 25, Gain = 1},
		{Value = 200004, Base = 25, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "每回合对所有队员造成80%攻击伤害",
		Skill = {
			{
				Id = 105047,
				Value = 80,
			},
		},
	},
	Tags = {
		562933,
	},
}
EnemyConfig[EnemyID.Id1017] =
{
	Id = 1017,
	Name = "七姑",
	Rarity = 5,
	Element = 210001,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "老年女性，享受着安详的退休生活，但是偶尔也会有发火的时候。",
	IconBundle = "atlas_charactericon_npc",
	IconAtlas = "NPC",
	IconName = "NPC_oldwomen1",
	PrefabBundle = "character_npc",
	PrefabName = "NPC_oldwomen1",
	SkinName = "1",
	PrefabScale = 50,
	HPBarHeight = 100,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 1429, Gain = 286},
		{Value = 200002, Base = 65, Gain = 13},
		{Value = 200003, Base = 25, Gain = 1},
		{Value = 200004, Base = 25, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "受火元素敌人伤害 -100%\n受风元素敌人伤害 -100%\n受光元素敌人伤害 -100%\n受暗元素敌人伤害 -100%",
		Skill = {
			{
				Id = 105034,
				Value = -100,
			},
			{
				Id = 105035,
				Value = -100,
			},
			{
				Id = 105036,
				Value = -100,
			},
			{
				Id = 105037,
				Value = -100,
			},
		},
	},
	Tags = {
		562933,
	},
}
EnemyConfig[EnemyID.Id1018] =
{
	Id = 1018,
	Name = "八姨",
	Rarity = 5,
	Element = 210001,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "染了亮丽蓝发的女性，过着精致的生活，平时最喜欢和姐妹们聊些八卦新闻。",
	IconBundle = "atlas_charactericon_npc",
	IconAtlas = "NPC",
	IconName = "NPC_women1",
	PrefabBundle = "character_npc",
	PrefabName = "NPC_women1",
	SkinName = "1",
	PrefabScale = 50,
	HPBarHeight = 100,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 1408, Gain = 282},
		{Value = 200002, Base = 65, Gain = 13},
		{Value = 200003, Base = 25, Gain = 1},
		{Value = 200004, Base = 25, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "受火元素敌人伤害 -100%\n受风元素敌人伤害 -100%\n受光元素敌人伤害 -100%\n受暗元素敌人伤害 -100%",
		Skill = {
			{
				Id = 105034,
				Value = -100,
			},
			{
				Id = 105035,
				Value = -100,
			},
			{
				Id = 105036,
				Value = -100,
			},
			{
				Id = 105037,
				Value = -100,
			},
		},
	},
	Tags = {
		562933,
	},
}
EnemyConfig[EnemyID.Id1019] =
{
	Id = 1019,
	Name = "辣坨坨",
	Rarity = 3,
	Element = 210002,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：在接吻时往男朋友嘴里灌辣椒油。",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	IconName = "Arena_FAT_Pudding",
	PrefabBundle = "character_arenaenemy",
	PrefabName = "Arena_FAT_Pudding",
	PrefabScale = 50,
	HPBarHeight = 120,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 4506, Gain = 902},
		{Value = 200002, Base = 70, Gain = 14},
		{Value = 200003, Base = 25, Gain = 1},
		{Value = 200004, Base = 25, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "每回合攻击 +20%，最多5次",
		Skill = {
			{
				Id = 105006,
				Value = 20,
			},
		},
	},
	Tags = {
		562933,
		564561,
	},
}
EnemyConfig[EnemyID.Id1020] =
{
	Id = 1020,
	Name = "火",
	Rarity = 2,
	Element = 210002,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "数据证明，百分之九十九的冒险家无法分清不同的小火球。\n它从岩浆里跳了起来，它掉了下去。\n它的兄弟从岩浆里跳了起来。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	IconName = "RPG_Fireball",
	PrefabBundle = "character_enemy",
	PrefabName = "RPG_Fireball",
	PrefabScale = 50,
	HPBarHeight = 76,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 4439, Gain = 888},
		{Value = 200002, Base = 70, Gain = 14},
		{Value = 200003, Base = 25, Gain = 1},
		{Value = 200004, Base = 25, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "受火元素敌人伤害 -100%\n暴击 +150",
		Skill = {
			{
				Id = 105034,
				Value = -100,
			},
			{
				Id = 105004,
				Value = 150,
			},
		},
	},
	Tags = {
		562933,
		564561,
	},
}
EnemyConfig[EnemyID.Id1021] =
{
	Id = 1021,
	Name = "雪精灵",
	Rarity = 2,
	Element = 210001,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：打喷嚏的时候故意打到别人脸上。",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	IconName = "Arena_RPG_Salamander",
	PrefabBundle = "character_arenaenemy",
	PrefabName = "Arena_RPG_Salamander",
	PrefabScale = 50,
	HPBarHeight = 81,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 4261, Gain = 853},
		{Value = 200002, Base = 47, Gain = 10},
		{Value = 200003, Base = 25, Gain = 1},
		{Value = 200004, Base = 25, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "降低50%等级减少效果\n每3回合对前3个队员造成80%攻击伤害",
		Skill = {
			{
				Id = 105173,
				Value = 50,
			},
			{
				Id = 105057,
				Value = 80,
			},
		},
	},
	Tags = {
		562933,
		564564,
	},
}
EnemyConfig[EnemyID.Id1022] =
{
	Id = 1022,
	Name = "放鞭炮的小孩",
	Rarity = 1,
	Element = 210002,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "在悬疑星各大街道活动的报童，拥有大量未经证实的惊天消息。比如动物园老虎逃出笼子，且27人已遇害。\n事实是房东太太的猫散步时，被27人围着撸。",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	IconName = "Sus_17_baotong",
	PrefabBundle = "character_sus",
	PrefabName = "Sus_17_baotong",
	SkinName = "1",
	PrefabScale = 50,
	HPBarHeight = 112,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 4084, Gain = 817},
		{Value = 200002, Base = 69, Gain = 14},
		{Value = 200003, Base = 25, Gain = 1},
		{Value = 200004, Base = 25, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "降低50%等级减少效果\n33%概率闪避攻击\n暴击 +150",
		Skill = {
			{
				Id = 105173,
				Value = 50,
			},
			{
				Id = 105026,
				Value = 33,
			},
			{
				Id = 105004,
				Value = 150,
			},
		},
	},
	Tags = {
		562933,
		564557,
		564561,
		564564,
	},
}
EnemyConfig[EnemyID.Id1023] =
{
	Id = 1023,
	Name = "假酒",
	Rarity = 2,
	Element = 210001,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：状态不稳定，容易爆炸。",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	IconName = "Arena_SUS_Blood",
	PrefabBundle = "character_arenaenemy",
	PrefabName = "Arena_SUS_Blood",
	PrefabScale = 50,
	HPBarHeight = 125,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 4084, Gain = 817},
		{Value = 200002, Base = 53, Gain = 11},
		{Value = 200003, Base = 25, Gain = 1},
		{Value = 200004, Base = 25, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "降低50%等级减少效果\n攻击时无视敌人80%忍耐\n33%概率闪避攻击",
		Skill = {
			{
				Id = 105173,
				Value = 50,
			},
			{
				Id = 105168,
				Value = 80,
			},
			{
				Id = 105026,
				Value = 33,
			},
		},
	},
	Tags = {
		562933,
		564557,
		564563,
		564564,
	},
}
EnemyConfig[EnemyID.Id1024] =
{
	Id = 1024,
	Name = "混沌的大脑",
	Rarity = 4,
	Element = 210001,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：智力低下，拖慢科研进度。",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	IconName = "Arena_SUS_Brain",
	PrefabBundle = "character_arenaenemy",
	PrefabName = "Arena_SUS_Brain",
	PrefabScale = 50,
	HPBarHeight = 120,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 5386, Gain = 1078},
		{Value = 200002, Base = 80, Gain = 16},
		{Value = 200003, Base = 25, Gain = 1},
		{Value = 200004, Base = 25, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "降低50%等级减少效果\n每回合将自身元素变为随机元素",
		Skill = {
			{
				Id = 105173,
				Value = 50,
			},
			{
				Id = 105162,
				Value = -1,
			},
		},
	},
	Tags = {
		562933,
		564564,
	},
}
EnemyConfig[EnemyID.Id1025] =
{
	Id = 1025,
	Name = "后悔之灵",
	Rarity = 3,
	Element = 210004,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：拒不配合房屋拆迁工作，还大肆破坏公共财产。",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	IconName = "Arena_RPG_Stoneman",
	PrefabBundle = "character_arenaenemy",
	PrefabName = "Arena_RPG_Stoneman",
	PrefabScale = 50,
	HPBarHeight = 114,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 5353, Gain = 1071},
		{Value = 200002, Base = 80, Gain = 16},
		{Value = 200003, Base = 25, Gain = 1},
		{Value = 200004, Base = 25, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "降低50%等级减少效果\n忍耐 +100\n回合中，每次受击，攻击 +3%",
		Skill = {
			{
				Id = 105173,
				Value = 50,
			},
			{
				Id = 105003,
				Value = 100,
			},
			{
				Id = 105170,
				Value = 3,
			},
		},
	},
	Tags = {
		562933,
		564561,
		564564,
	},
}
EnemyConfig[EnemyID.Id1026] =
{
	Id = 1026,
	Name = "过去的自己",
	Rarity = 2,
	Element = 210002,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "自称为冒险星的主角，身负打败魔王以及为世界带来和平的重任。虽然帮助村民不求回报，但缺物资时，会以正义之名进入NPC家中取走合用的财物。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	IconName = "Rpg_05_jianshi",
	PrefabBundle = "character_rpg",
	PrefabName = "Rpg_05_jianshi",
	SkinName = "1",
	PrefabScale = 50,
	HPBarHeight = 105,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 4811, Gain = 963},
		{Value = 200002, Base = 67, Gain = 14},
		{Value = 200003, Base = 25, Gain = 1},
		{Value = 200004, Base = 25, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "降低50%等级减少效果\n每回合攻击 +10%，最多5次\n每回合回血 5%，最多5次\n每3回合对前2个队员造成150%攻击伤害",
		Skill = {
			{
				Id = 105173,
				Value = 50,
			},
			{
				Id = 105006,
				Value = 10,
			},
			{
				Id = 105005,
				Value = 5,
			},
			{
				Id = 105056,
				Value = 150,
			},
		},
	},
	Tags = {
		562933,
		564560,
		564561,
		564564,
	},
}
EnemyConfig[EnemyID.Id1027] =
{
	Id = 1027,
	Name = "山谷商人",
	Rarity = 2,
	Element = 210003,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "冒险星人气NPC，拥有没人见过的非凡实力。卖出去1000块的道具，下一秒就是100块的回收价，却没有谁敢和他们吵架。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	IconName = "Rpg_14_lvxingshangren",
	PrefabBundle = "character_rpg",
	PrefabName = "Rpg_14_lvxingshangren",
	SkinName = "1",
	PrefabScale = 50,
	HPBarHeight = 105,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 3363, Gain = 673},
		{Value = 200002, Base = 64, Gain = 13},
		{Value = 200003, Base = 25, Gain = 1},
		{Value = 200004, Base = 25, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "100%概率无视敌人闪避",
		Skill = {
			{
				Id = 105027,
				Value = 100,
			},
		},
	},
	Tags = {
		564559,
	},
}
EnemyConfig[EnemyID.Id1028] =
{
	Id = 1028,
	Name = "叶姬",
	Rarity = 2,
	Element = 210003,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "仿佛是来自异空间的厨师，制作的料理很有特色，听说食材都是自家地里种出来的。",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	IconName = "SPBUS_01_yeji",
	PrefabBundle = "character_sp",
	PrefabName = "SPBUS_01_yeji",
	SkinName = "1",
	PrefabScale = 50,
	HPBarHeight = 125,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 4453, Gain = 891},
		{Value = 200002, Base = 64, Gain = 13},
		{Value = 200003, Base = 25, Gain = 1},
		{Value = 200004, Base = 25, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "每回合回血 5%，最多5次",
		Skill = {
			{
				Id = 105005,
				Value = 5,
			},
		},
	},
	Tags = {
		564560,
	},
}
EnemyConfig[EnemyID.Id1029] =
{
	Id = 1029,
	Name = "木制宝箱怪",
	Rarity = 2,
	Element = 210003,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "活跃于野外地区的初级宝箱，通过其极具迷惑性的外表引诱冒险者靠近，然后“啊呜”一口吃掉。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	IconName = "RPG_NormalChest",
	PrefabBundle = "character_enemy",
	PrefabName = "RPG_NormalChest",
	PrefabScale = 50,
	HPBarHeight = 100,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 4522, Gain = 905},
		{Value = 200002, Base = 64, Gain = 13},
		{Value = 200003, Base = 25, Gain = 1},
		{Value = 200004, Base = 25, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "暴击 +100\n暴击伤害 +100%",
		Skill = {
			{
				Id = 105004,
				Value = 100,
			},
			{
				Id = 105038,
				Value = 100,
			},
		},
	},
	Tags = {
		564561,
	},
}
EnemyConfig[EnemyID.Id1030] =
{
	Id = 1030,
	Name = "协会工作人员",
	Rarity = 5,
	Element = 210003,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "可爱的小女孩，不过偶尔也会让人非常头疼。",
	IconBundle = "atlas_charactericon_npc",
	IconAtlas = "NPC",
	IconName = "NPC_girl1",
	PrefabBundle = "character_npc",
	PrefabName = "NPC_girl1",
	SkinName = "1",
	PrefabScale = 50,
	HPBarHeight = 100,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 4802, Gain = 961},
		{Value = 200002, Base = 64, Gain = 13},
		{Value = 200003, Base = 25, Gain = 1},
		{Value = 200004, Base = 25, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "每回合攻击 +5%，最多5次\n每回合忍耐 +5，最多5次",
		Skill = {
			{
				Id = 105006,
				Value = 5,
			},
			{
				Id = 105007,
				Value = 5,
			},
		},
	},
	Tags = {
		564561,
	},
}
EnemyConfig[EnemyID.Id1031] =
{
	Id = 1031,
	Name = "粉色史莱姆",
	Rarity = 1,
	Element = 210001,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "史莱姆家族中的小妹，幼年女性成员，酷爱甜食。平时受到哥哥们的保护，很少去危险地区，主要在宝箱谷地区活动。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	IconName = "RPG_Slime_Pink",
	PrefabBundle = "character_enemy",
	PrefabName = "RPG_Slime_Pink",
	PrefabScale = 50,
	HPBarHeight = 100,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 4652, Gain = 931},
		{Value = 200002, Base = 63, Gain = 13},
		{Value = 200003, Base = 25, Gain = 1},
		{Value = 200004, Base = 25, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "每回合回血 5%，最多5次\n受水元素敌人伤害 -100%",
		Skill = {
			{
				Id = 105005,
				Value = 5,
			},
			{
				Id = 105033,
				Value = -100,
			},
		},
	},
	Tags = {
		564560,
	},
}
EnemyConfig[EnemyID.Id1032] =
{
	Id = 1032,
	Name = "稀有宝箱怪",
	Rarity = 3,
	Element = 210005,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "活跃于危险地区的中级宝箱，金色的光芒会让老练的冒险者忘乎所以地靠近，在他打开宝箱的一刹那，就把对方吃掉。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	IconName = "RPG_RareChest",
	PrefabBundle = "character_enemy",
	PrefabName = "RPG_RareChest",
	PrefabScale = 50,
	HPBarHeight = 100,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 3838, Gain = 768},
		{Value = 200002, Base = 63, Gain = 13},
		{Value = 200003, Base = 25, Gain = 1},
		{Value = 200004, Base = 25, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "100%概率无视敌人闪避\n20%概率闪避攻击",
		Skill = {
			{
				Id = 105027,
				Value = 100,
			},
			{
				Id = 105026,
				Value = 20,
			},
		},
	},
	Tags = {
		564557,
		564559,
	},
}
EnemyConfig[EnemyID.Id1033] =
{
	Id = 1033,
	Name = "金色史莱姆",
	Rarity = 3,
	Element = 210004,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "史莱姆一族中的稀有品种，对自我的定位是「金英怪」或「黄金史莱姆」。一旦听到有人喊它「黄色史莱姆」，就会陷入无法抑制的狂暴状态。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	IconName = "RPG_Slime_Gold",
	PrefabBundle = "character_enemy",
	PrefabName = "RPG_Slime_Gold",
	PrefabScale = 50,
	HPBarHeight = 100,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 4929, Gain = 986},
		{Value = 200002, Base = 43, Gain = 9},
		{Value = 200003, Base = 25, Gain = 1},
		{Value = 200004, Base = 25, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "攻击时无视敌人100%忍耐\n每回合攻击 +5%，最多5次",
		Skill = {
			{
				Id = 105168,
				Value = 100,
			},
			{
				Id = 105006,
				Value = 5,
			},
		},
	},
	Tags = {
		564561,
		564563,
	},
}
EnemyConfig[EnemyID.Id1034] =
{
	Id = 1034,
	Name = "绿色史莱姆",
	Rarity = 1,
	Element = 210003,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "体内带有大量绿色素的小精灵，喜欢捡冒险者丢掉的东西，被它碰到的东西就会被染成绿色，不要丢下帽子。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	IconName = "RPG_Slime_green",
	PrefabBundle = "character_enemy",
	PrefabName = "RPG_Slime_green",
	PrefabScale = 50,
	HPBarHeight = 69,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 1966, Gain = 394},
		{Value = 200002, Base = 52, Gain = 11},
		{Value = 200003, Base = 25, Gain = 1},
		{Value = 200004, Base = 25, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "每回合回血 5%，最多5次\n回合中，每次受击，攻击 +3%\n每3回合对前3个队员造成100%攻击伤害",
		Skill = {
			{
				Id = 105005,
				Value = 5,
			},
			{
				Id = 105170,
				Value = 3,
			},
			{
				Id = 105057,
				Value = 100,
			},
		},
	},
	Tags = {
		564560,
		564561,
	},
}
EnemyConfig[EnemyID.Id1035] =
{
	Id = 1035,
	Name = "红色史莱姆",
	Rarity = 1,
	Element = 210002,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "体内带有大量红色素的小精灵，喜欢捡冒险者丢掉的东西，被它碰到的东西就会被染成红色，但如果碰到蓝色史莱姆就会染成紫色。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	IconName = "RPG_Slime_red",
	PrefabBundle = "character_enemy",
	PrefabName = "RPG_Slime_red",
	PrefabScale = 50,
	HPBarHeight = 69,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 1966, Gain = 394},
		{Value = 200002, Base = 52, Gain = 11},
		{Value = 200003, Base = 25, Gain = 1},
		{Value = 200004, Base = 25, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "每回合回血 5%，最多5次\n回合中，每次受击，攻击 +3%\n每3回合对前3个队员造成100%攻击伤害",
		Skill = {
			{
				Id = 105005,
				Value = 5,
			},
			{
				Id = 105170,
				Value = 3,
			},
			{
				Id = 105057,
				Value = 100,
			},
		},
	},
	Tags = {
		564560,
		564561,
	},
}
EnemyConfig[EnemyID.Id1036] =
{
	Id = 1036,
	Name = "蓝色史莱姆",
	Rarity = 1,
	Element = 210001,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "体内带有大量蓝色素的小精灵，喜欢捡冒险者丢掉的东西，被它碰到的东西就会被染成蓝色。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	IconName = "RPG_Slime_blue",
	PrefabBundle = "character_enemy",
	PrefabName = "RPG_Slime_blue",
	PrefabScale = 50,
	HPBarHeight = 69,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 1966, Gain = 394},
		{Value = 200002, Base = 52, Gain = 11},
		{Value = 200003, Base = 25, Gain = 1},
		{Value = 200004, Base = 25, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "每回合回血 5%，最多5次\n回合中，每次受击，攻击 +3%\n每3回合对前3个队员造成100%攻击伤害",
		Skill = {
			{
				Id = 105005,
				Value = 5,
			},
			{
				Id = 105170,
				Value = 3,
			},
			{
				Id = 105057,
				Value = 100,
			},
		},
	},
	Tags = {
		564560,
		564561,
	},
}
EnemyConfig[EnemyID.Id1037] =
{
	Id = 1037,
	Name = "传奇宝箱怪",
	Rarity = 4,
	Element = 210004,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "深藏于顶级副本的史诗宝箱，再警惕的冒险者也无法抗拒他的璀璨光辉。而那些靠近的冒险者就再也回不来了。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	IconName = "RPG_EpicChest",
	PrefabBundle = "character_enemy",
	PrefabName = "RPG_EpicChest",
	PrefabScale = 50,
	HPBarHeight = 110,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 3661, Gain = 733},
		{Value = 200002, Base = 49, Gain = 10},
		{Value = 200003, Base = 25, Gain = 1},
		{Value = 200004, Base = 25, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "100%概率无视敌人闪避\n每回合对前2个队员造成100%攻击伤害\n受暗元素敌人伤害 -50%",
		Skill = {
			{
				Id = 105027,
				Value = 100,
			},
			{
				Id = 105040,
				Value = 100,
			},
			{
				Id = 105037,
				Value = -50,
			},
		},
	},
	Tags = {
		564559,
	},
}
EnemyConfig[EnemyID.Id1038] =
{
	Id = 1038,
	Name = "协会助理",
	Rarity = 3,
	Element = 210003,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "法庭上人见人怕的律政界女王，据说以前还是学校选美冠军之一呢~",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	IconName = "Sus_13_lvshi_cos10",
	PrefabBundle = "character_sus",
	PrefabName = "Sus_13_lvshi",
	SkinName = "2",
	PrefabScale = 50,
	HPBarHeight = 140,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 5658, Gain = 1132},
		{Value = 200002, Base = 69, Gain = 14},
		{Value = 200003, Base = 25, Gain = 1},
		{Value = 200004, Base = 25, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "有25%概率额外攻击1次\n20%概率闪避攻击\n受到的暴击伤害 -50%",
		Skill = {
			{
				Id = 105023,
				Value = 25,
			},
			{
				Id = 105026,
				Value = 20,
			},
			{
				Id = 105039,
				Value = -50,
			},
		},
	},
	Tags = {
		564557,
		564558,
	},
}
EnemyConfig[EnemyID.Id1039] =
{
	Id = 1039,
	Name = "番茄酱侍卫",
	Rarity = 3,
	Element = 210001,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "国王御用侍卫，从小陪伴薯条国王长大。能根据薯条国王的状态，时刻调整自己的甜度，深得薯条国王信赖。每次战后他都会在第一时间被送往医院，尽管大部分时候只是包装袋破了。",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	IconName = "Fat_31_fanqiejiang",
	PrefabBundle = "character_fat",
	PrefabName = "Fat_31_fanqiejiang",
	SkinName = "1",
	PrefabScale = 50,
	HPBarHeight = 106,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 3363, Gain = 673},
		{Value = 200002, Base = 64, Gain = 13},
		{Value = 200003, Base = 25, Gain = 1},
		{Value = 200004, Base = 25, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "100%概率无视敌人闪避",
		Skill = {
			{
				Id = 105027,
				Value = 100,
			},
		},
	},
	Tags = {
		564559,
	},
}
EnemyConfig[EnemyID.Id1040] =
{
	Id = 1040,
	Name = "竞争对手",
	Rarity = 2,
	Element = 210005,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "魔王公司中层干部，平时会带着低级雇员们在路上堵截低级勇者搞业绩。不过因为掉落物不错，所以也常被高级勇者蹲点刷。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	IconName = "Rpg_13_dashouxiaodi",
	PrefabBundle = "character_rpg",
	PrefabName = "Rpg_13_dashouxiaodi",
	SkinName = "1",
	PrefabScale = 50,
	HPBarHeight = 105,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 4453, Gain = 891},
		{Value = 200002, Base = 64, Gain = 13},
		{Value = 200003, Base = 25, Gain = 1},
		{Value = 200004, Base = 25, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "每回合回血 5%，最多5次",
		Skill = {
			{
				Id = 105005,
				Value = 5,
			},
		},
	},
	Tags = {
		564560,
	},
}
EnemyConfig[EnemyID.Id1041] =
{
	Id = 1041,
	Name = "板蓝根泡面",
	Rarity = 3,
	Element = 210003,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "出生于养生世家，对药物有异于寻常的热爱。吃泡面时，会用板蓝根来取代调料包，此刻，即便是无甚营养的泡面也有了增强体质的功能。",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	IconName = "Fat_104_IsatisNoodle",
	PrefabBundle = "character_fat",
	PrefabName = "Fat_104_IsatisNoodle",
	SkinName = "1",
	PrefabScale = 50,
	HPBarHeight = 125,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 4522, Gain = 905},
		{Value = 200002, Base = 64, Gain = 13},
		{Value = 200003, Base = 25, Gain = 1},
		{Value = 200004, Base = 25, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "暴击 +100\n暴击伤害 +100%",
		Skill = {
			{
				Id = 105004,
				Value = 100,
			},
			{
				Id = 105038,
				Value = 100,
			},
		},
	},
	Tags = {
		564561,
	},
}
EnemyConfig[EnemyID.Id1042] =
{
	Id = 1042,
	Name = "臭小白",
	Rarity = 2,
	Element = 210004,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "软软的白色豆腐，梦想是可以移民美食星，就算被拒绝了近100次，也仍然没有放弃。",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "FAT",
	IconName = "FAT_StinkyTofuWhite",
	PrefabBundle = "character_enemy",
	PrefabName = "FAT_StinkyTofuWhite",
	PrefabScale = 50,
	HPBarHeight = 100,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 2561, Gain = 513},
		{Value = 200002, Base = 64, Gain = 13},
		{Value = 200003, Base = 25, Gain = 1},
		{Value = 200004, Base = 25, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "每回合攻击 +5%，最多5次\n每回合忍耐 +5，最多5次",
		Skill = {
			{
				Id = 105006,
				Value = 5,
			},
			{
				Id = 105007,
				Value = 5,
			},
		},
	},
	Tags = {
		564561,
	},
}
EnemyConfig[EnemyID.Id1043] =
{
	Id = 1043,
	Name = "臭小黑",
	Rarity = 2,
	Element = 210005,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "软软的黑色豆腐，梦想是可以移民美食星，对于美食星近100次的拒绝，表示非常气愤，并多次联系星球媒体寻求帮助。",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "FAT",
	IconName = "FAT_StinkyTofuBlack",
	PrefabBundle = "character_enemy",
	PrefabName = "FAT_StinkyTofuBlack",
	PrefabScale = 50,
	HPBarHeight = 100,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 2561, Gain = 513},
		{Value = 200002, Base = 64, Gain = 13},
		{Value = 200003, Base = 25, Gain = 1},
		{Value = 200004, Base = 25, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "每回合攻击 +5%，最多5次\n每回合忍耐 +5，最多5次",
		Skill = {
			{
				Id = 105006,
				Value = 5,
			},
			{
				Id = 105007,
				Value = 5,
			},
		},
	},
	Tags = {
		564561,
	},
}
EnemyConfig[EnemyID.Id1044] =
{
	Id = 1044,
	Name = "钢化大列巴",
	Rarity = 4,
	Element = 210002,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "乍看之下非常可爱的小面包，然而拥有钢铁一般坚硬的躯壳，让那些想要拥抱它的人都望而却步。",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "FAT",
	IconName = "FAT_GreatLeba",
	PrefabBundle = "character_enemy",
	PrefabName = "FAT_GreatLeba",
	PrefabScale = 50,
	HPBarHeight = 110,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 4652, Gain = 931},
		{Value = 200002, Base = 63, Gain = 13},
		{Value = 200003, Base = 25, Gain = 1},
		{Value = 200004, Base = 25, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "每回合回血 5%，最多5次\n受水元素敌人伤害 -100%",
		Skill = {
			{
				Id = 105005,
				Value = 5,
			},
			{
				Id = 105033,
				Value = -100,
			},
		},
	},
	Tags = {
		564560,
	},
}
EnemyConfig[EnemyID.Id1045] =
{
	Id = 1045,
	Name = "鲱鱼饭团",
	Rarity = 4,
	Element = 210003,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "强迫症患者，玩游戏时如果控制的角色血量不满会相当焦虑。得知鲱鱼拥有丰富的补血元素后，毫不犹豫走上了做鲱鱼饭团的路。",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	IconName = "Fat_105_HerringRiceBall",
	PrefabBundle = "character_fat",
	PrefabName = "Fat_105_HerringRiceBall",
	SkinName = "1",
	PrefabScale = 50,
	HPBarHeight = 135,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 3838, Gain = 768},
		{Value = 200002, Base = 63, Gain = 13},
		{Value = 200003, Base = 25, Gain = 1},
		{Value = 200004, Base = 25, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "100%概率无视敌人闪避\n20%概率闪避攻击",
		Skill = {
			{
				Id = 105027,
				Value = 100,
			},
			{
				Id = 105026,
				Value = 20,
			},
		},
	},
	Tags = {
		564557,
		564559,
	},
}
EnemyConfig[EnemyID.Id1046] =
{
	Id = 1046,
	Name = "史卡",
	Rarity = 4,
	Element = 210005,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "常常戴着猫耳，打扮成可爱样子的咖啡师，喜欢诱惑小动物吃特制咖啡豆，然后跟在小动物后面捡粑粑拿回家去制作绝味咖啡。",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	IconName = "Fat_102_KopiLuwak",
	PrefabBundle = "character_fat",
	PrefabName = "Fat_102_KopiLuwak",
	SkinName = "1",
	PrefabScale = 50,
	HPBarHeight = 135,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 4929, Gain = 986},
		{Value = 200002, Base = 43, Gain = 9},
		{Value = 200003, Base = 25, Gain = 1},
		{Value = 200004, Base = 25, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "攻击时无视敌人100%忍耐\n每回合攻击 +5%，最多5次",
		Skill = {
			{
				Id = 105168,
				Value = 100,
			},
			{
				Id = 105006,
				Value = 5,
			},
		},
	},
	Tags = {
		564561,
		564563,
	},
}
EnemyConfig[EnemyID.Id1047] =
{
	Id = 1047,
	Name = "辣辣子",
	Rarity = 3,
	Element = 210002,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "辣味大师，只要和她拥抱一下，就能让你全身火热。她常常会对顾客说“请问你想要微重辣，中重辣，还是重重辣。”",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	IconName = "Fat_103_GhostChili",
	PrefabBundle = "character_fat",
	PrefabName = "Fat_103_GhostChili",
	SkinName = "1",
	PrefabScale = 50,
	HPBarHeight = 135,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 1966, Gain = 394},
		{Value = 200002, Base = 52, Gain = 11},
		{Value = 200003, Base = 25, Gain = 1},
		{Value = 200004, Base = 25, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "每回合回血 5%，最多5次\n回合中，每次受击，攻击 +3%\n每3回合对前3个队员造成100%攻击伤害",
		Skill = {
			{
				Id = 105005,
				Value = 5,
			},
			{
				Id = 105170,
				Value = 3,
			},
			{
				Id = 105057,
				Value = 100,
			},
		},
	},
	Tags = {
		564560,
		564561,
	},
}
EnemyConfig[EnemyID.Id1048] =
{
	Id = 1048,
	Name = "仰望星空",
	Rarity = 3,
	Element = 210001,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "脑袋上有三只望向天空的鱼，因此拥有了一个诗意的名字，然而见到它的人，时常被鱼的模样吓跑，这不禁让它非常苦恼。",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "FAT",
	IconName = "FAT_BreadFish",
	PrefabBundle = "character_enemy",
	PrefabName = "FAT_BreadFish",
	PrefabScale = 50,
	HPBarHeight = 110,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 3661, Gain = 733},
		{Value = 200002, Base = 49, Gain = 10},
		{Value = 200003, Base = 25, Gain = 1},
		{Value = 200004, Base = 25, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "100%概率无视敌人闪避\n每回合对前2个队员造成100%攻击伤害\n受暗元素敌人伤害 -50%",
		Skill = {
			{
				Id = 105027,
				Value = 100,
			},
			{
				Id = 105040,
				Value = 100,
			},
			{
				Id = 105037,
				Value = -50,
			},
		},
	},
	Tags = {
		564559,
	},
}
EnemyConfig[EnemyID.Id1049] =
{
	Id = 1049,
	Name = "麻醉花椒",
	Rarity = 1,
	Element = 210003,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "花椒中的稀有品种，凡是接触到它的人，都会出现短暂的麻痹现象。",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "FAT",
	IconName = "FAT_SichuanPepper",
	PrefabBundle = "character_enemy",
	PrefabName = "FAT_SichuanPepper",
	PrefabScale = 50,
	HPBarHeight = 100,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 5658, Gain = 1132},
		{Value = 200002, Base = 69, Gain = 14},
		{Value = 200003, Base = 25, Gain = 1},
		{Value = 200004, Base = 25, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "有25%概率额外攻击1次\n20%概率闪避攻击\n受到的暴击伤害 -50%",
		Skill = {
			{
				Id = 105023,
				Value = 25,
			},
			{
				Id = 105026,
				Value = 20,
			},
			{
				Id = 105039,
				Value = -50,
			},
		},
	},
	Tags = {
		564557,
		564558,
	},
}
EnemyConfig[EnemyID.Id1050] =
{
	Id = 1050,
	Name = "忠心的小队长",
	Rarity = 2,
	Element = 210005,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "魔王公司中层干部，平时会带着低级雇员们在路上堵截低级勇者搞业绩。不过因为掉落物不错，所以也常被高级勇者蹲点刷。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	IconName = "Rpg_13_dashouxiaodi",
	PrefabBundle = "character_rpg",
	PrefabName = "Rpg_13_dashouxiaodi",
	SkinName = "1",
	PrefabScale = 50,
	HPBarHeight = 105,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 3234, Gain = 647},
		{Value = 200002, Base = 58, Gain = 12},
		{Value = 200003, Base = 25, Gain = 1},
		{Value = 200004, Base = 25, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "忍耐 +25\n攻击 +15%",
		Skill = {
			{
				Id = 105003,
				Value = 25,
			},
			{
				Id = 105002,
				Value = 15,
			},
		},
	},
	Tags = {
		564561,
	},
}
EnemyConfig[EnemyID.Id1051] =
{
	Id = 1051,
	Name = "骷髅杰克",
	Rarity = 2,
	Element = 210005,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "魔王有限公司临时雇员，即使被拆散了也能很快拼回去，是地城副本中很重要的成员。\n不过偶尔会发生重新拼装时，多出一些骨头的问题。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	IconName = "Rpg_30_kulou",
	PrefabBundle = "character_rpg",
	PrefabName = "Rpg_30_kulou",
	SkinName = "1",
	PrefabScale = 50,
	HPBarHeight = 105,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 3051, Gain = 611},
		{Value = 200002, Base = 58, Gain = 12},
		{Value = 200003, Base = 25, Gain = 1},
		{Value = 200004, Base = 25, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "每回合回血 15%，最多5次\n受到的暴击伤害 -50%",
		Skill = {
			{
				Id = 105005,
				Value = 15,
			},
			{
				Id = 105039,
				Value = -50,
			},
		},
	},
	Tags = {
		564560,
	},
}
EnemyConfig[EnemyID.Id1052] =
{
	Id = 1052,
	Name = "瞌睡",
	Rarity = 3,
	Element = 210001,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "博物馆星新任保安，人生处于低谷时来到博物馆散心，无意间拿起保安招聘启事后便被馆长强行留了下来。",
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "Mus",
	IconName = "MUS_27_baoan",
	PrefabBundle = "character_mus",
	PrefabName = "MUS_27_baoan",
	SkinName = "1",
	PrefabScale = 50,
	HPBarHeight = 115,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 3190, Gain = 638},
		{Value = 200002, Base = 58, Gain = 12},
		{Value = 200003, Base = 25, Gain = 1},
		{Value = 200004, Base = 25, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "每3回合回血 25%，最多5次",
		Skill = {
			{
				Id = 105009,
				Value = 25,
			},
		},
	},
	Tags = {
		564560,
	},
}
EnemyConfig[EnemyID.Id1053] =
{
	Id = 1053,
	Name = "木块",
	Rarity = 3,
	Element = 210005,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "神秘的古代陶土工艺品，脸上写着难以言喻的表情，不太受人欢迎。",
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "MUS",
	IconName = "MUS_QuestionMark",
	PrefabBundle = "character_enemy",
	PrefabName = "MUS_QuestionMark",
	PrefabScale = 50,
	HPBarHeight = 110,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 3201, Gain = 641},
		{Value = 200002, Base = 58, Gain = 12},
		{Value = 200003, Base = 25, Gain = 1},
		{Value = 200004, Base = 25, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "受水元素敌人伤害 -100%\n受火元素敌人伤害 -100%",
		Skill = {
			{
				Id = 105033,
				Value = -100,
			},
			{
				Id = 105034,
				Value = -100,
			},
		},
	},
}
EnemyConfig[EnemyID.Id1054] =
{
	Id = 1054,
	Name = "指路NPC",
	Rarity = 2,
	Element = 210001,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "热心的冒险星原住民，和宠物猪一起居住在沼泽深处。专门给来自世界各地的冒险者指路。说话时会用最近学会的口音，以至于大部分人都听不懂他的话。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	IconName = "Rpg_10_buluolaoda",
	PrefabBundle = "character_rpg",
	PrefabName = "Rpg_10_buluolaoda",
	SkinName = "1",
	PrefabScale = 50,
	HPBarHeight = 115,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 2531, Gain = 507},
		{Value = 200002, Base = 56, Gain = 12},
		{Value = 200003, Base = 25, Gain = 1},
		{Value = 200004, Base = 25, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "100%概率无视敌人闪避\n有20%概率额外攻击1次",
		Skill = {
			{
				Id = 105027,
				Value = 100,
			},
			{
				Id = 105023,
				Value = 20,
			},
		},
	},
	Tags = {
		564558,
		564559,
	},
}
EnemyConfig[EnemyID.Id1055] =
{
	Id = 1055,
	Name = "雄黄酒",
	Rarity = 3,
	Element = 210001,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "粽子家族的好友，据说只要掀开他的帽子，就能体会到他自己所谓的“内在美”。",
	IconBundle = "atlas_activity_1",
	IconAtlas = "ActivityCharacterIcon",
	IconName = "All_XiongHuangJiu",
	PrefabBundle = "character_enemy",
	PrefabName = "All_XiongHuangJiu",
	PrefabScale = 50,
	HPBarHeight = 120,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 3467, Gain = 694},
		{Value = 200002, Base = 50, Gain = 10},
		{Value = 200003, Base = 25, Gain = 1},
		{Value = 200004, Base = 25, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "受水元素敌人伤害 33%\n每2回合对前3个队员造成100%攻击伤害",
		Skill = {
			{
				Id = 105033,
				Value = 33,
			},
			{
				Id = 105049,
				Value = 100,
			},
		},
	},
}
EnemyConfig[EnemyID.Id1056] =
{
	Id = 1056,
	Name = "歌唱的王子",
	Rarity = 3,
	Element = 210005,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "超人气王子，王子唱片董事长。每年都会开办36场演唱会，出18张专辑。不过唱片销量要靠常年打折外加赠送超值礼品才能维持。",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	IconName = "Fat_07_kele",
	PrefabBundle = "character_fat",
	PrefabName = "Fat_07_kele",
	SkinName = "1",
	PrefabScale = 50,
	HPBarHeight = 114,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 2957, Gain = 592},
		{Value = 200002, Base = 59, Gain = 12},
		{Value = 200003, Base = 25, Gain = 1},
		{Value = 200004, Base = 25, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "有33%概率额外攻击1次\n100%概率无视敌人闪避",
		Skill = {
			{
				Id = 105023,
				Value = 33,
			},
			{
				Id = 105027,
				Value = 100,
			},
		},
	},
	Tags = {
		564558,
		564559,
	},
}
EnemyConfig[EnemyID.Id1057] =
{
	Id = 1057,
	Name = "不服的下属",
	Rarity = 2,
	Element = 210005,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "魔王有限公司临时雇员，即使被拆散了也能很快拼回去，是地城副本中很重要的成员。\n不过偶尔会发生重新拼装时，多出一些骨头的问题。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	IconName = "Rpg_30_kulou",
	PrefabBundle = "character_rpg",
	PrefabName = "Rpg_30_kulou",
	SkinName = "1",
	PrefabScale = 50,
	HPBarHeight = 105,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 3425, Gain = 685},
		{Value = 200002, Base = 62, Gain = 13},
		{Value = 200003, Base = 25, Gain = 1},
		{Value = 200004, Base = 25, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "每回合回血 15%，最多5次\n受到的暴击伤害 -50%",
		Skill = {
			{
				Id = 105005,
				Value = 15,
			},
			{
				Id = 105039,
				Value = -50,
			},
		},
	},
	Tags = {
		564560,
	},
}
EnemyConfig[EnemyID.Id1058] =
{
	Id = 1058,
	Name = "裁判长",
	Rarity = 3,
	Element = 210002,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "历代勇者的专用服装，每次穿上前会播放近1分钟的特效，如果遇到不讲规矩的敌人，那么变身过程中就会被揍得鼻青脸肿。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	IconName = "Rpg_20_laoyeye_cos10",
	PrefabBundle = "character_rpg",
	PrefabName = "Rpg_20_laoyeye",
	SkinName = "2",
	PrefabScale = 50,
	HPBarHeight = 150,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 2656, Gain = 532},
		{Value = 200002, Base = 49, Gain = 10},
		{Value = 200003, Base = 25, Gain = 1},
		{Value = 200004, Base = 25, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "100%概率无视敌人闪避\n每2回合对后2个队员造成100%攻击伤害",
		Skill = {
			{
				Id = 105027,
				Value = 100,
			},
			{
				Id = 105052,
				Value = 100,
			},
		},
	},
	Tags = {
		564559,
	},
}
EnemyConfig[EnemyID.Id1059] =
{
	Id = 1059,
	Name = "挑衅的村长",
	Rarity = 1,
	Element = 210002,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "守候在村子里德高望重的角色，同时担负着向冒险者发布主线任务及发放奖励的重要责任。不过会私下吞掉任务奖励的回扣，并瞒着妻子偷偷藏下私房钱。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	IconName = "Rpg_20_laoyeye",
	PrefabBundle = "character_rpg",
	PrefabName = "Rpg_20_laoyeye",
	SkinName = "1",
	PrefabScale = 50,
	HPBarHeight = 115,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 4126, Gain = 826},
		{Value = 200002, Base = 66, Gain = 14},
		{Value = 200003, Base = 25, Gain = 1},
		{Value = 200004, Base = 25, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "忍耐 +100\n生命 +100%\n降低100%等级减少效果",
		Skill = {
			{
				Id = 105003,
				Value = 100,
			},
			{
				Id = 105001,
				Value = 100,
			},
			{
				Id = 105173,
				Value = 100,
			},
		},
	},
	Tags = {
		564561,
		564564,
	},
}
EnemyConfig[EnemyID.Id1060] =
{
	Id = 1060,
	Name = "铁匠",
	Rarity = 2,
	Element = 210002,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "冒险星人气NPC，提供装备买卖、修理、强化等服务，是勇者不可或缺的好帮手。\n“哎呀，手一滑装备爆炸了，阁下运气不太好噢~”",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	IconName = "Rpg_31_tiejiang",
	PrefabBundle = "character_rpg",
	PrefabName = "Rpg_31_tiejiang",
	SkinName = "1",
	PrefabScale = 50,
	HPBarHeight = 115,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 3234, Gain = 647},
		{Value = 200002, Base = 58, Gain = 12},
		{Value = 200003, Base = 25, Gain = 1},
		{Value = 200004, Base = 25, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "忍耐 +25\n攻击 +15%",
		Skill = {
			{
				Id = 105003,
				Value = 25,
			},
			{
				Id = 105002,
				Value = 15,
			},
		},
	},
	Tags = {
		564561,
	},
}
EnemyConfig[EnemyID.Id1061] =
{
	Id = 1061,
	Name = "飙车王",
	Rarity = 4,
	Element = 210003,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "任何载具都能驾驭自如的星际飙车王，从独轮车到摩托车、小型飞机、快艇、星河战舰，只要是能驾驶的都能飙。但是不知道为什么，他经常在互联网上被禁言。",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	IconName = "Pir_03_RacingDriver",
	PrefabBundle = "character_boss",
	PrefabName = "Pir_03_RacingDriver",
	SkinName = "1",
	PrefabScale = 50,
	HPBarHeight = 125,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 3051, Gain = 611},
		{Value = 200002, Base = 58, Gain = 12},
		{Value = 200003, Base = 25, Gain = 1},
		{Value = 200004, Base = 25, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "每回合回血 15%，最多5次\n受到的暴击伤害 -50%",
		Skill = {
			{
				Id = 105005,
				Value = 15,
			},
			{
				Id = 105039,
				Value = -50,
			},
		},
	},
	Tags = {
		564560,
	},
}
EnemyConfig[EnemyID.Id1062] =
{
	Id = 1062,
	Name = "金鱼",
	Rarity = 3,
	Element = 210001,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "星光小道的司机，有时候无法控制自己的行动，会下意识把乘客带去海葵的区域。",
	IconBundle = "atlas_charactericon_sea",
	IconAtlas = "Sea",
	IconName = "SEA_Nemo",
	PrefabBundle = "character_enemy",
	PrefabName = "SEA_Nemo",
	PrefabScale = 50,
	HPBarHeight = 110,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 3190, Gain = 638},
		{Value = 200002, Base = 58, Gain = 12},
		{Value = 200003, Base = 25, Gain = 1},
		{Value = 200004, Base = 25, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "每3回合回血 25%，最多5次",
		Skill = {
			{
				Id = 105009,
				Value = 25,
			},
		},
	},
	Tags = {
		564560,
	},
}
EnemyConfig[EnemyID.Id1063] =
{
	Id = 1063,
	Name = "占位路障",
	Rarity = 2,
	Element = 210004,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：影响他人正常通行。",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	IconName = "Arena_SUS_YellowBarrier",
	PrefabBundle = "character_arenaenemy",
	PrefabName = "Arena_SUS_YellowBarrier",
	PrefabScale = 50,
	HPBarHeight = 110,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 3201, Gain = 641},
		{Value = 200002, Base = 58, Gain = 12},
		{Value = 200003, Base = 25, Gain = 1},
		{Value = 200004, Base = 25, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "受水元素敌人伤害 -100%\n受火元素敌人伤害 -100%",
		Skill = {
			{
				Id = 105033,
				Value = -100,
			},
			{
				Id = 105034,
				Value = -100,
			},
		},
	},
}
EnemyConfig[EnemyID.Id1064] =
{
	Id = 1064,
	Name = "牵牛",
	Rarity = 3,
	Element = 210001,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "勤工俭学的男孩，在服装店里负责采购、收银等多项工作，有时还替老板养牛。在庙会上，不经意间和某位女生目光交汇，于是有了一瞬间的心动。",
	IconBundle = "atlas_activity_1",
	IconAtlas = "ActivityCharacterIcon",
	IconName = "SPBUS_13_QianNiu",
	PrefabBundle = "character_sp",
	PrefabName = "SPBUS_13_QianNiu",
	SkinName = "1",
	PrefabScale = 50,
	HPBarHeight = 125,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 2531, Gain = 507},
		{Value = 200002, Base = 56, Gain = 12},
		{Value = 200003, Base = 25, Gain = 1},
		{Value = 200004, Base = 25, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "100%概率无视敌人闪避\n有20%概率额外攻击1次",
		Skill = {
			{
				Id = 105027,
				Value = 100,
			},
			{
				Id = 105023,
				Value = 20,
			},
		},
	},
	Tags = {
		564558,
		564559,
	},
}
EnemyConfig[EnemyID.Id1065] =
{
	Id = 1065,
	Name = "鬼影树",
	Rarity = 2,
	Element = 210003,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：有人在树下躲雨时，故意让人淋湿感冒。",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	IconName = "Arena_RPG_dashu",
	PrefabBundle = "character_arenaenemy",
	PrefabName = "Arena_RPG_dashu",
	PrefabScale = 50,
	HPBarHeight = 141,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 3467, Gain = 694},
		{Value = 200002, Base = 50, Gain = 10},
		{Value = 200003, Base = 25, Gain = 1},
		{Value = 200004, Base = 25, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "受水元素敌人伤害 33%\n每2回合对前3个队员造成100%攻击伤害",
		Skill = {
			{
				Id = 105033,
				Value = 33,
			},
			{
				Id = 105049,
				Value = 100,
			},
		},
	},
}
EnemyConfig[EnemyID.Id1066] =
{
	Id = 1066,
	Name = "吵架石",
	Rarity = 2,
	Element = 210004,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：动不动就会和别人吵起来，还会动手动脚。",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	IconName = "Arena_RPG_xiaoshiguai",
	PrefabBundle = "character_arenaenemy",
	PrefabName = "Arena_RPG_xiaoshiguai",
	PrefabScale = 50,
	HPBarHeight = 76,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 2957, Gain = 592},
		{Value = 200002, Base = 59, Gain = 12},
		{Value = 200003, Base = 25, Gain = 1},
		{Value = 200004, Base = 25, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "有33%概率额外攻击1次\n100%概率无视敌人闪避",
		Skill = {
			{
				Id = 105023,
				Value = 33,
			},
			{
				Id = 105027,
				Value = 100,
			},
		},
	},
	Tags = {
		564558,
		564559,
	},
}
EnemyConfig[EnemyID.Id1067] =
{
	Id = 1067,
	Name = "三花猫",
	Rarity = 1,
	Element = 210003,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "活跃在悬疑星的花猫，喜欢在安全的地方散步，如果路上发生状况，就会蹲在一边舔着舌头看热闹。\n它的舌头并没有三种花色。",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "SUS",
	IconName = "SUS_ColorfulCat",
	PrefabBundle = "character_enemy",
	PrefabName = "SUS_ColourfulCat",
	PrefabScale = 50,
	HPBarHeight = 100,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 3425, Gain = 685},
		{Value = 200002, Base = 62, Gain = 13},
		{Value = 200003, Base = 25, Gain = 1},
		{Value = 200004, Base = 25, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "每回合回血 15%，最多5次\n受到的暴击伤害 -50%",
		Skill = {
			{
				Id = 105005,
				Value = 15,
			},
			{
				Id = 105039,
				Value = -50,
			},
		},
	},
	Tags = {
		564560,
	},
}
EnemyConfig[EnemyID.Id1068] =
{
	Id = 1068,
	Name = "黑衣人",
	Rarity = 3,
	Element = 210005,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "令人闻风丧胆的凶手，没人知道ta的身份。只要ta出现，大家就会放弃抵抗落荒而逃，然后露出破绽，被他轻易击杀。",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	IconName = "Sus_28_heiyiren",
	PrefabBundle = "character_sus",
	PrefabName = "Sus_28_heiyiren",
	SkinName = "1",
	PrefabScale = 50,
	HPBarHeight = 112,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 2656, Gain = 532},
		{Value = 200002, Base = 49, Gain = 10},
		{Value = 200003, Base = 25, Gain = 1},
		{Value = 200004, Base = 25, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "100%概率无视敌人闪避\n每2回合对后2个队员造成100%攻击伤害",
		Skill = {
			{
				Id = 105027,
				Value = 100,
			},
			{
				Id = 105052,
				Value = 100,
			},
		},
	},
	Tags = {
		564559,
	},
}
EnemyConfig[EnemyID.Id1069] =
{
	Id = 1069,
	Name = "月佬",
	Rarity = 5,
	Element = 210004,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "人称“牛头大佬”，因为一些前尘往事，被逐出天上人间婚介所，至今仍为无业游民，在流亡街上摆摊算命。虽然小摊无人光顾，但大家都很好奇，沉重的面具下，是一张什么样的脸呢？",
	IconBundle = "atlas_activity_1",
	IconAtlas = "ActivityCharacterIcon",
	IconName = "SPBUS_21_YueLao",
	PrefabBundle = "character_sp",
	PrefabName = "SPBUS_21_YueLao",
	SkinName = "1",
	PrefabScale = 50,
	HPBarHeight = 125,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 4126, Gain = 826},
		{Value = 200002, Base = 66, Gain = 14},
		{Value = 200003, Base = 25, Gain = 1},
		{Value = 200004, Base = 25, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "忍耐 +100\n生命 +100%\n降低100%等级减少效果",
		Skill = {
			{
				Id = 105003,
				Value = 100,
			},
			{
				Id = 105001,
				Value = 100,
			},
			{
				Id = 105173,
				Value = 100,
			},
		},
	},
	Tags = {
		564561,
		564564,
	},
}
EnemyConfig[EnemyID.Id1070] =
{
	Id = 1070,
	Name = "雪中猎人",
	Rarity = 4,
	Element = 210003,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "只有在冬天才会外出打猎的猎人，对雪地有某种特殊的执念。完好地装备着厚实的雪地靴、冬帽、猎枪、望远镜等道具，身边还有一只灵活又凶猛的猎犬。",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	IconName = "SPBUS_29_XueZhongLieRen",
	PrefabBundle = "character_sp",
	PrefabName = "SPBUS_29_XueZhongLieRen",
	SkinName = "1",
	PrefabScale = 50,
	HPBarHeight = 125,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 3234, Gain = 647},
		{Value = 200002, Base = 58, Gain = 12},
		{Value = 200003, Base = 25, Gain = 1},
		{Value = 200004, Base = 25, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "忍耐 +25\n攻击 +15%",
		Skill = {
			{
				Id = 105003,
				Value = 25,
			},
			{
				Id = 105002,
				Value = 15,
			},
		},
	},
	Tags = {
		564561,
	},
}
EnemyConfig[EnemyID.Id1071] =
{
	Id = 1071,
	Name = "健身教练",
	Rarity = 4,
	Element = 210002,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "长着八块腹肌，肌肉坚硬得刀枪不入的健身教练，同时也是一位带娃的奶爸。与自己的儿子形影不离，对这位三岁小孩抱有极大的希望和期待。",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	IconName = "SPBUS_27_JianShenJiaoLian",
	PrefabBundle = "character_sp",
	PrefabName = "SPBUS_27_JianShenJiaoLian",
	SkinName = "1",
	PrefabScale = 50,
	HPBarHeight = 125,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 3234, Gain = 647},
		{Value = 200002, Base = 58, Gain = 12},
		{Value = 200003, Base = 25, Gain = 1},
		{Value = 200004, Base = 25, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "忍耐 +25\n攻击 +15%",
		Skill = {
			{
				Id = 105003,
				Value = 25,
			},
			{
				Id = 105002,
				Value = 15,
			},
		},
	},
	Tags = {
		564561,
	},
}
EnemyConfig[EnemyID.Id1072] =
{
	Id = 1072,
	Name = "白幽灵",
	Rarity = 3,
	Element = 210005,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "宇宙间的幽灵，对于生前的记忆已经模糊了。死后的身体变得轻飘飘的，更适合自由地游历世界。\n因此他表示，对现状还挺满意的。",
	IconBundle = "atlas_activity_1",
	IconAtlas = "ActivityCharacterIcon",
	IconName = "All_Ghost",
	PrefabBundle = "character_enemy",
	PrefabName = "ALL_Ghost",
	PrefabScale = 50,
	HPBarHeight = 120,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 3051, Gain = 611},
		{Value = 200002, Base = 58, Gain = 12},
		{Value = 200003, Base = 25, Gain = 1},
		{Value = 200004, Base = 25, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "每回合回血 15%，最多5次\n受到的暴击伤害 -50%",
		Skill = {
			{
				Id = 105005,
				Value = 15,
			},
			{
				Id = 105039,
				Value = -50,
			},
		},
	},
	Tags = {
		564560,
	},
}
EnemyConfig[EnemyID.Id1073] =
{
	Id = 1073,
	Name = "药剂包",
	Rarity = 3,
	Element = 210003,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "在温泉别墅中打工的药剂包，姓药，昵称包包，也是一位勤勤恳恳的打工人。有人对他的味道欲罢不能，但也有人对这味道嗤之以鼻。",
	IconBundle = "atlas_activity_1",
	IconAtlas = "ActivityCharacterIcon",
	IconName = "All_YaoJiBao",
	PrefabBundle = "character_enemy",
	PrefabName = "All_YaoJiBao",
	PrefabScale = 50,
	HPBarHeight = 120,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 3190, Gain = 638},
		{Value = 200002, Base = 58, Gain = 12},
		{Value = 200003, Base = 25, Gain = 1},
		{Value = 200004, Base = 25, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "每3回合回血 25%，最多5次",
		Skill = {
			{
				Id = 105009,
				Value = 25,
			},
		},
	},
	Tags = {
		564560,
	},
}
EnemyConfig[EnemyID.Id1074] =
{
	Id = 1074,
	Name = "门牌",
	Rarity = 2,
	Element = 210003,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "经常溜到案件现场看热闹的门牌先生，有时候会发表自己的高见,由于顶着自己的住址而总是会泄露个人信息。",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "SUS",
	IconName = "SUS_NumberPlate",
	PrefabBundle = "character_enemy",
	PrefabName = "SUS_NumberPlate",
	PrefabScale = 50,
	HPBarHeight = 100,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 3201, Gain = 641},
		{Value = 200002, Base = 58, Gain = 12},
		{Value = 200003, Base = 25, Gain = 1},
		{Value = 200004, Base = 25, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "受水元素敌人伤害 -100%\n受火元素敌人伤害 -100%",
		Skill = {
			{
				Id = 105033,
				Value = -100,
			},
			{
				Id = 105034,
				Value = -100,
			},
		},
	},
}
EnemyConfig[EnemyID.Id1075] =
{
	Id = 1075,
	Name = "黑衣人",
	Rarity = 3,
	Element = 210005,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "令人闻风丧胆的凶手，没人知道ta的身份。只要ta出现，大家就会放弃抵抗落荒而逃，然后露出破绽，被他轻易击杀。",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	IconName = "Sus_28_heiyiren",
	PrefabBundle = "character_sus",
	PrefabName = "Sus_28_heiyiren",
	SkinName = "1",
	PrefabScale = 50,
	HPBarHeight = 112,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 2531, Gain = 507},
		{Value = 200002, Base = 56, Gain = 12},
		{Value = 200003, Base = 25, Gain = 1},
		{Value = 200004, Base = 25, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "100%概率无视敌人闪避\n有20%概率额外攻击1次",
		Skill = {
			{
				Id = 105027,
				Value = 100,
			},
			{
				Id = 105023,
				Value = 20,
			},
		},
	},
	Tags = {
		564558,
		564559,
	},
}
EnemyConfig[EnemyID.Id1076] =
{
	Id = 1076,
	Name = "冰冰杆",
	Rarity = 3,
	Element = 210001,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "在风吹日晒下伫立一根栏杆，从不旷工缺席，但每到冬季就会冬眠，冰雪是她的保护层。\n听说她的表面是甜的，但用舌头去舔的话，会发生非常不好的事情。",
	IconBundle = "atlas_activity_1",
	IconAtlas = "ActivityCharacterIcon",
	IconName = "All_BingBingGang",
	PrefabBundle = "character_enemy",
	PrefabName = "All_BingBingGang",
	PrefabScale = 50,
	HPBarHeight = 120,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 3467, Gain = 694},
		{Value = 200002, Base = 50, Gain = 10},
		{Value = 200003, Base = 25, Gain = 1},
		{Value = 200004, Base = 25, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "受水元素敌人伤害 33%\n每2回合对前3个队员造成100%攻击伤害",
		Skill = {
			{
				Id = 105033,
				Value = 33,
			},
			{
				Id = 105049,
				Value = 100,
			},
		},
	},
}
EnemyConfig[EnemyID.Id1077] =
{
	Id = 1077,
	Name = "思诺曼",
	Rarity = 3,
	Element = 210001,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "断耳熊的朋友，依靠寒冷与冰雪生存，冬季时会来到山底和朋友玩耍，在其他季节只能孤独地呆在山顶。在断耳熊的陪伴下，二人一起度过了许多美好的夜晚。",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	IconName = "SPBUS_31_SiNuoMan",
	PrefabBundle = "character_sp",
	PrefabName = "SPBUS_31_SiNuoMan",
	SkinName = "1",
	PrefabScale = 50,
	HPBarHeight = 125,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 2957, Gain = 592},
		{Value = 200002, Base = 59, Gain = 12},
		{Value = 200003, Base = 25, Gain = 1},
		{Value = 200004, Base = 25, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "有33%概率额外攻击1次\n100%概率无视敌人闪避",
		Skill = {
			{
				Id = 105023,
				Value = 33,
			},
			{
				Id = 105027,
				Value = 100,
			},
		},
	},
	Tags = {
		564558,
		564559,
	},
}
EnemyConfig[EnemyID.Id1078] =
{
	Id = 1078,
	Name = "猫眼厨娘",
	Rarity = 5,
	Element = 210002,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "温泉别墅的老板，几年前依靠“网红+餐饮”的经营模式走上了致富之路。有一双猫一般的眼睛，喜欢温泉、美食、旅行和聊天。",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	IconName = "SPBUS_25_MaoYanChuNiang",
	PrefabBundle = "character_sp",
	PrefabName = "SPBUS_25_MaoYanChuNiang",
	SkinName = "1",
	PrefabScale = 50,
	HPBarHeight = 125,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 3425, Gain = 685},
		{Value = 200002, Base = 62, Gain = 13},
		{Value = 200003, Base = 25, Gain = 1},
		{Value = 200004, Base = 25, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "每回合回血 15%，最多5次\n受到的暴击伤害 -50%",
		Skill = {
			{
				Id = 105005,
				Value = 15,
			},
			{
				Id = 105039,
				Value = -50,
			},
		},
	},
	Tags = {
		564560,
	},
}
EnemyConfig[EnemyID.Id1079] =
{
	Id = 1079,
	Name = "雪神",
	Rarity = 5,
	Element = 210001,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "居住在山间的奇怪少女，为了不让登山客靠近，会伪装成僵尸模样恐吓他们。她总是祈祷，“雪中僵尸”的谣言，再传播得更猛烈一些。",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	IconName = "SPBUS_24_XueShen",
	PrefabBundle = "character_sp",
	PrefabName = "SPBUS_24_XueShen",
	SkinName = "1",
	PrefabScale = 50,
	HPBarHeight = 125,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 2656, Gain = 532},
		{Value = 200002, Base = 49, Gain = 10},
		{Value = 200003, Base = 25, Gain = 1},
		{Value = 200004, Base = 25, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "100%概率无视敌人闪避\n每2回合对后2个队员造成100%攻击伤害",
		Skill = {
			{
				Id = 105027,
				Value = 100,
			},
			{
				Id = 105052,
				Value = 100,
			},
		},
	},
	Tags = {
		564559,
	},
}
EnemyConfig[EnemyID.Id1080] =
{
	Id = 1080,
	Name = "大侦探",
	Rarity = 5,
	Element = 210004,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "前任大侦探老福的孙子，继承了爷爷的意志，经常帮助警局侦办悬疑案件。既是警局救星，也是警局克星。",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	IconName = "Sus_01_fuermosi",
	PrefabBundle = "character_sus",
	PrefabName = "Sus_01_fuermosi",
	SkinName = "1",
	PrefabScale = 50,
	HPBarHeight = 112,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 4126, Gain = 826},
		{Value = 200002, Base = 66, Gain = 14},
		{Value = 200003, Base = 25, Gain = 1},
		{Value = 200004, Base = 25, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "忍耐 +100\n生命 +100%\n降低100%等级减少效果",
		Skill = {
			{
				Id = 105003,
				Value = 100,
			},
			{
				Id = 105001,
				Value = 100,
			},
			{
				Id = 105173,
				Value = 100,
			},
		},
	},
	Tags = {
		564561,
		564564,
	},
}
