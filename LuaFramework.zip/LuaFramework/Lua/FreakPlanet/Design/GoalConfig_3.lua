
GoalConfig[GoalID.Id801] =
{
	Id = 801,
	Name = "主线204 - 探索博物馆星",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130101,
	},
	GoalTrigger = 
	{
		TriggerType.Explore,
	},
	GoalCondition = 
	{
		{
			Name = "派遣[62E7E7]呜呜[-]、[62E7E7]漆漆[-]探索博物馆星[FDDE40]着陆点[-]4小时",
			Type = ItemType.Time,
			CountType = GoalCountType.StartNow,
			Num = 14400,
			Character = 
			{
				220001,
				220002,
			},
			Value = 130101,
		},
	},
	Reward = {
		{
			Value = 330001,
			Num = 7,
		},
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id802] =
{
	Id = 802,
	Name = "主线205 - 探险家的日常1",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130101,
		PreGoal = 
		{
			300801,
		},
	},
	GoalTrigger = 
	{
		TriggerType.CompleteDemand,
	},
	GoalCondition = 
	{
		{
			Name = "完成[62E7E7]任意[-][FDDE40]委托[-]5次",
			Type = ItemType.Demand,
			CountType = GoalCountType.StartNow,
			Num = 5,
			Value = -1,
		},
	},
	Reward = {
		{
			Value = 330001,
			Num = 7,
		},
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id803] =
{
	Id = 803,
	Name = "主线206 - 强化装备6",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130101,
		PreGoal = 
		{
			300802,
		},
	},
	GoalTrigger = 
	{
		TriggerType.UpgradeEquipment,
	},
	GoalCondition = 
	{
		{
			Name = "强化[62E7E7]任意[-][FDDE40]装备[-]80次",
			Type = ItemType.Equipment,
			CountType = GoalCountType.Current,
			Num = 80,
			Value = -1,
		},
	},
	Reward = {
		{
			Value = 330001,
			Num = 7,
		},
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id804] =
{
	Id = 804,
	Name = "主线207 - 左半碗代表的挑战",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130101,
		PreGoal = 
		{
			300803,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Challenge,
	},
	GoalCondition = 
	{
		{
			Name = "打败着陆点的[FDDE40]左半碗代表[-]",
			Type = ItemType.Challenge,
			CountType = GoalCountType.Current,
			Num = 1,
			Value = 140401,
		},
	},
	CompleteSpeech = 30080401,
	Reward = {
		{
			Value = 130102,
			Num = 1,
		},
		{
			Value = 330003,
			Num = 1,
		},
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id805] =
{
	Id = 805,
	Name = "主线208 - 准备工作",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130102,
		PreGoal = 
		{
			300804,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Craft,
	},
	GoalCondition = 
	{
		{
			Name = "在实验室合成获得[FDDE40]大便当[-]3个",
			Type = ItemType.Goods,
			CountType = GoalCountType.StartNow,
			Num = 3,
			Value = 320411,
		},
	},
	Reward = {
		{
			Value = 330001,
			Num = 7,
		},
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id806] =
{
	Id = 806,
	Name = "主线209 - 排队入馆",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130102,
		PreGoal = 
		{
			300805,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Explore,
	},
	GoalCondition = 
	{
		{
			Name = "排长队的话尽量不要中途退出啊！\n[62E7E7]一次性[-]探索博物馆星[FDDE40]入口大厅[-]12小时",
			Type = ItemType.Time,
			CountType = GoalCountType.OneShot,
			Num = 43200,
			Value = 130102,
		},
	},
	Reward = {
		{
			Value = 330001,
			Num = 7,
		},
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id807] =
{
	Id = 807,
	Name = "主线210 - 入口队长的挑战",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130102,
		PreGoal = 
		{
			300806,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Challenge,
	},
	GoalCondition = 
	{
		{
			Name = "打败入口大厅的[FDDE40]入口队长[-]",
			Type = ItemType.Challenge,
			CountType = GoalCountType.Current,
			Num = 1,
			Value = 140402,
		},
	},
	CompleteSpeech = 30080701,
	Reward = {
		{
			Value = 330003,
			Num = 1,
		},
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id808] =
{
	Id = 808,
	Name = "主线211 - 安检流程",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130102,
		PreGoal = 
		{
			300807,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Explore,
	},
	GoalCondition = 
	{
		{
			Name = "危险人员填表候查，其他人员排队入场。\n派遣含有[62E7E7]5个[-][62E7E7]非冒险星[-]队员(或宠物)的队伍探索博物馆星[FDDE40]入口大厅[-]12小时",
			Type = ItemType.Time,
			CountType = GoalCountType.StartNow,
			Num = 43200,
			TagList = 
			{
				560203,
			},
			CharacterNum = 5,
			Value = 130102,
		},
	},
	Reward = {
		{
			Value = 330001,
			Num = 7,
		},
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id809] =
{
	Id = 809,
	Name = "主线212 - 没收食物",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130102,
		PreGoal = 
		{
			300808,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Explore,
	},
	GoalCondition = 
	{
		{
			Name = "馆内禁止味道浓烈的食物！\n派遣含有[62E7E7]5个[-][62E7E7]非美食星[-]队员(或宠物)的队伍探索博物馆星[FDDE40]入口大厅[-]12小时",
			Type = ItemType.Time,
			CountType = GoalCountType.StartNow,
			Num = 43200,
			TagList = 
			{
				560204,
			},
			CharacterNum = 5,
			Value = 130102,
		},
	},
	Reward = {
		{
			Value = 330001,
			Num = 7,
		},
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id810] =
{
	Id = 810,
	Name = "主线213 - 红外线探测的挑战",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130102,
		PreGoal = 
		{
			300809,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Challenge,
	},
	GoalCondition = 
	{
		{
			Name = "打败入口大厅的[FDDE40]红外线探测[-]",
			Type = ItemType.Challenge,
			CountType = GoalCountType.Current,
			Num = 1,
			Value = 140403,
		},
	},
	CompleteSpeech = 30081001,
	Reward = {
		{
			Value = 330003,
			Num = 1,
		},
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id811] =
{
	Id = 811,
	Name = "主线214 - 入馆的资格",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130102,
		PreGoal = 
		{
			300810,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Explore,
	},
	GoalCondition = 
	{
		{
			Name = "在探索中获得[FDDE40]入场券[-]50个",
			Type = ItemType.Goods,
			CountType = GoalCountType.StartNow,
			Num = 50,
			Value = 321401,
		},
	},
	Reward = {
		{
			Value = 330001,
			Num = 7,
		},
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id812] =
{
	Id = 812,
	Name = "主线215 - 冒险的旅费6",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130102,
		PreGoal = 
		{
			300811,
		},
	},
	GoalTrigger = 
	{
		TriggerType.DemandReward,
	},
	GoalCondition = 
	{
		{
			Name = "完成[62E7E7]委托[-]获得[FDDE40]金币[-]60000个",
			Type = ItemType.Gold,
			CountType = GoalCountType.StartNow,
			Num = 60000,
			Value = 1,
		},
	},
	Reward = {
		{
			Value = 330001,
			Num = 7,
		},
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id813] =
{
	Id = 813,
	Name = "主线216 - 进入保安室",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130102,
		PreGoal = 
		{
			300812,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Explore,
	},
	GoalCondition = 
	{
		{
			Name = "在探索中击败[FDDE40]红外线探测[-]40个，建议探索8小时以上",
			Type = ItemType.Enemy,
			CountType = GoalCountType.StartNow,
			Num = 40,
			Value = 242059,
		},
	},
	Reward = {
		{
			Value = 330001,
			Num = 7,
		},
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id814] =
{
	Id = 814,
	Name = "主线217 - 保安的挑战",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130102,
		PreGoal = 
		{
			300813,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Challenge,
	},
	GoalCondition = 
	{
		{
			Name = "打败入口大厅的[FDDE40]保安[-]",
			Type = ItemType.Challenge,
			CountType = GoalCountType.Current,
			Num = 1,
			Value = 140404,
		},
	},
	CompleteSpeech = 30081401,
	Reward = {
		{
			Value = 130103,
			Num = 1,
		},
		{
			Value = 330003,
			Num = 1,
		},
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id815] =
{
	Id = 815,
	Name = "主线218 - 这次主角是保安！",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130103,
		PreGoal = 
		{
			300814,
		},
	},
	GoalTrigger = 
	{
		TriggerType.CollectItem,
	},
	GoalCondition = 
	{
		{
			Name = "拥有至少[62E7E7]2阶[-][FDDE40]保安[-]",
			Type = ItemType.Character,
			CountType = GoalCountType.Current,
			Num = 1,
			Value = 220201,
			Stage = 2,
		},
	},
	Reward = {
		{
			Value = 330001,
			Num = 7,
		},
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id816] =
{
	Id = 816,
	Name = "主线219 - 保持通话",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130103,
		PreGoal = 
		{
			300815,
		},
	},
	GoalTrigger = 
	{
		TriggerType.CollectItem,
	},
	GoalCondition = 
	{
		{
			Name = "拥有至少[62E7E7]5级[-][FDDE40]对讲机[-](保安装备)",
			Type = ItemType.Equipment,
			CountType = GoalCountType.Current,
			Num = 1,
			Value = 340153,
			Level = 5,
		},
	},
	Reward = {
		{
			Value = 330001,
			Num = 7,
		},
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id817] =
{
	Id = 817,
	Name = "主线220 - 巡逻路线",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130103,
		PreGoal = 
		{
			300816,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Explore,
	},
	GoalCondition = 
	{
		{
			Name = "派遣[62E7E7]保安[-]在探索中击败[FDDE40]左半碗[-]120个，建议探索8小时以上",
			Type = ItemType.Enemy,
			CountType = GoalCountType.StartNow,
			Num = 120,
			Character = 
			{
				220201,
			},
			Value = 242056,
		},
	},
	Reward = {
		{
			Value = 330001,
			Num = 7,
		},
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id818] =
{
	Id = 818,
	Name = "主线221 - 道具店打工4",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130103,
		PreGoal = 
		{
			300817,
		},
	},
	GoalTrigger = 
	{
		TriggerType.WorkShopRank,
	},
	GoalCondition = 
	{
		{
			Name = "在[FDDE40]道具店[-]打工获得[FDDE40]S-[-]或更高评价",
			Type = ItemType.WorkShop,
			CountType = GoalCountType.Current,
			Num = 1,
			Value = 160001,
			Rank = 20,
		},
	},
	Reward = {
		{
			Value = 330001,
			Num = 7,
		},
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id819] =
{
	Id = 819,
	Name = "主线222 - 太古围观陶的挑战",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130103,
		PreGoal = 
		{
			300818,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Challenge,
	},
	GoalCondition = 
	{
		{
			Name = "打败中心广场的[FDDE40]太古围观陶[-]",
			Type = ItemType.Challenge,
			CountType = GoalCountType.Current,
			Num = 1,
			Value = 140405,
		},
	},
	Reward = {
		{
			Value = 330003,
			Num = 1,
		},
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id820] =
{
	Id = 820,
	Name = "主线223 - 入口的无理要求",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130103,
		PreGoal = 
		{
			300819,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Explore,
	},
	GoalCondition = 
	{
		{
			Name = "这里的入口，每个都会问游客收一次门票钱。\n探索[62E7E7]中心广场[-]击败[FDDE40]入口[-]50个，建议探索10小时以上",
			Type = ItemType.Enemy,
			CountType = GoalCountType.StartNow,
			Num = 50,
			Value = 242058,
			Area = 130103,
		},
	},
	Reward = {
		{
			Value = 330001,
			Num = 7,
		},
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id821] =
{
	Id = 821,
	Name = "主线224 - 博物馆聚餐",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130103,
		PreGoal = 
		{
			300820,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Craft,
	},
	GoalCondition = 
	{
		{
			Name = "在实验室合成获得[FDDE40]全家桶[-]4个",
			Type = ItemType.Goods,
			CountType = GoalCountType.StartNow,
			Num = 4,
			Value = 320408,
		},
	},
	Reward = {
		{
			Value = 330001,
			Num = 7,
		},
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id822] =
{
	Id = 822,
	Name = "主线225 - 陶面人的问题",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130103,
		PreGoal = 
		{
			300821,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Explore,
	},
	GoalCondition = 
	{
		{
			Name = "派遣含有[62E7E7]2个[-][62E7E7]紫色及以上品质[-]、[62E7E7]风元素[-]队员(或宠物)的队伍探索博物馆星[FDDE40]中心广场[-]24小时",
			Type = ItemType.Time,
			CountType = GoalCountType.StartNow,
			Num = 86400,
			TagList = 
			{
				560034,
				561204,
			},
			CharacterNum = 2,
			Value = 130103,
		},
	},
	Reward = {
		{
			Value = 330001,
			Num = 7,
		},
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id823] =
{
	Id = 823,
	Name = "主线226 - 陶老大的挑战",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130103,
		PreGoal = 
		{
			300822,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Challenge,
	},
	GoalCondition = 
	{
		{
			Name = "打败中心广场的[FDDE40]陶老大[-]",
			Type = ItemType.Challenge,
			CountType = GoalCountType.Current,
			Num = 1,
			Value = 140406,
		},
	},
	CompleteSpeech = 30082301,
	Reward = {
		{
			Value = 330003,
			Num = 1,
		},
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id824] =
{
	Id = 824,
	Name = "主线227 - 洗洗更卫生",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130103,
		PreGoal = 
		{
			300823,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Explore,
	},
	GoalCondition = 
	{
		{
			Name = "派遣含有[62E7E7]3个[-][62E7E7]水元素[-]队员(或宠物)的队伍探索博物馆星[FDDE40]中心广场[-]20小时",
			Type = ItemType.Time,
			CountType = GoalCountType.StartNow,
			Num = 72000,
			TagList = 
			{
				561202,
			},
			CharacterNum = 3,
			Value = 130103,
		},
	},
	Reward = {
		{
			Value = 330001,
			Num = 7,
		},
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id825] =
{
	Id = 825,
	Name = "主线228 - 新鲜水果",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130103,
		PreGoal = 
		{
			300824,
		},
	},
	GoalTrigger = 
	{
		TriggerType.CollectItem,
	},
	GoalCondition = 
	{
		{
			Name = "累计拥有[62E7E7]水果类的[-][FDDE40]宠物[-]4种",
			Type = ItemType.Pet,
			CountType = GoalCountType.Current,
			Num = 4,
			TagList = 
			{
				561331,
			},
			Value = -1,
		},
	},
	Reward = {
		{
			Value = 330001,
			Num = 7,
		},
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id826] =
{
	Id = 826,
	Name = "主线229 - 围堵小浣熊",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130103,
		PreGoal = 
		{
			300825,
		},
	},
	GoalTrigger = 
	{
		TriggerType.CollectItem,
	},
	GoalCondition = 
	{
		{
			Name = "拥有至少[62E7E7]30级[-][62E7E7]紫色及以上品质[-][FDDE40]角色[-]5个",
			Type = ItemType.Character,
			CountType = GoalCountType.Current,
			Num = 5,
			Value = -1,
			Rarity = 3,
			Level = 30,
		},
	},
	Reward = {
		{
			Value = 330001,
			Num = 7,
		},
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id827] =
{
	Id = 827,
	Name = "主线230 - 浣熊小弟的挑战",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130103,
		PreGoal = 
		{
			300826,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Challenge,
	},
	GoalCondition = 
	{
		{
			Name = "打败中心广场的[FDDE40]浣熊小弟[-]",
			Type = ItemType.Challenge,
			CountType = GoalCountType.Current,
			Num = 1,
			Value = 140407,
		},
	},
	CompleteSpeech = 30082701,
	Reward = {
		{
			Value = 130104,
			Num = 1,
		},
		{
			Value = 330003,
			Num = 1,
		},
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id828] =
{
	Id = 828,
	Name = "主线231 - 优待俘虏",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130104,
		PreGoal = 
		{
			300827,
		},
	},
	GoalTrigger = 
	{
		TriggerType.CollectItem,
	},
	GoalCondition = 
	{
		{
			Name = "拥有至少[62E7E7]20级[-][FDDE40]浣熊小弟[-]",
			Type = ItemType.Character,
			CountType = GoalCountType.Current,
			Num = 1,
			Value = 220205,
			Level = 20,
		},
	},
	Reward = {
		{
			Value = 330001,
			Num = 7,
		},
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id829] =
{
	Id = 829,
	Name = "主线232 - 联手协作",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130104,
		PreGoal = 
		{
			300828,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Explore,
	},
	GoalCondition = 
	{
		{
			Name = "派遣[62E7E7]保安[-]、[62E7E7]浣熊小弟[-]探索博物馆星[FDDE40]文物厅[-]12小时",
			Type = ItemType.Time,
			CountType = GoalCountType.StartNow,
			Num = 43200,
			Character = 
			{
				220201,
				220205,
			},
			Value = 130104,
		},
	},
	Reward = {
		{
			Value = 330001,
			Num = 7,
		},
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id830] =
{
	Id = 830,
	Name = "主线233 - 事务所打工1",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130104,
		PreGoal = 
		{
			300829,
		},
	},
	GoalTrigger = 
	{
		TriggerType.WorkShopRank,
	},
	GoalCondition = 
	{
		{
			Name = "在[FDDE40]事务所[-]打工获得[FDDE40]F[-]或更高评价",
			Type = ItemType.WorkShop,
			CountType = GoalCountType.Current,
			Num = 1,
			Value = 160004,
			Rank = 3,
		},
	},
	Reward = {
		{
			Value = 330001,
			Num = 7,
		},
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id831] =
{
	Id = 831,
	Name = "主线234 - 驱散围观陶",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130104,
		PreGoal = 
		{
			300830,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Explore,
	},
	GoalCondition = 
	{
		{
			Name = "探索[62E7E7]文物厅[-]击败[FDDE40]围观陶[-]90个，建议探索12小时以上",
			Type = ItemType.Enemy,
			CountType = GoalCountType.StartNow,
			Num = 90,
			Value = 242060,
			Area = 130104,
		},
	},
	Reward = {
		{
			Value = 330001,
			Num = 7,
		},
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id832] =
{
	Id = 832,
	Name = "主线235 - 王朝编钟的挑战",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130104,
		PreGoal = 
		{
			300831,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Challenge,
	},
	GoalCondition = 
	{
		{
			Name = "打败文物厅的[FDDE40]王朝编钟[-]",
			Type = ItemType.Challenge,
			CountType = GoalCountType.Current,
			Num = 1,
			Value = 140408,
		},
	},
	Reward = {
		{
			Value = 330003,
			Num = 1,
		},
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id833] =
{
	Id = 833,
	Name = "主线236 - 隐身的小浣熊",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130104,
		PreGoal = 
		{
			300832,
		},
	},
	GoalTrigger = 
	{
		TriggerType.CollectItem,
	},
	GoalCondition = 
	{
		{
			Name = "拥有至少[62E7E7]5级[-][FDDE40]隐身叶片[-](浣熊小弟装备)",
			Type = ItemType.Equipment,
			CountType = GoalCountType.Current,
			Num = 1,
			Value = 340166,
			Level = 5,
		},
	},
	Reward = {
		{
			Value = 330001,
			Num = 7,
		},
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id834] =
{
	Id = 834,
	Name = "主线237 - 停止演奏",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130104,
		PreGoal = 
		{
			300833,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Explore,
	},
	GoalCondition = 
	{
		{
			Name = "在探索中击败[FDDE40]编钟[-]25个，建议探索5小时以上",
			Type = ItemType.Enemy,
			CountType = GoalCountType.StartNow,
			Num = 25,
			Value = 242062,
		},
	},
	Reward = {
		{
			Value = 330001,
			Num = 7,
		},
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id835] =
{
	Id = 835,
	Name = "主线238 - 古老的乐器",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130104,
		PreGoal = 
		{
			300834,
		},
	},
	GoalTrigger = 
	{
		TriggerType.CollectItem,
	},
	GoalCondition = 
	{
		{
			Name = "累计捕捉宠物[FDDE40]编钟[-]3个(需要事务所的纸板箱)",
			Type = ItemType.Pet,
			CountType = GoalCountType.Current,
			Num = 3,
			Value = 250062,
		},
	},
	Reward = {
		{
			Value = 330001,
			Num = 7,
		},
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id836] =
{
	Id = 836,
	Name = "主线239 - 太古兽面鼎的挑战",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130104,
		PreGoal = 
		{
			300835,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Challenge,
	},
	GoalCondition = 
	{
		{
			Name = "打败文物厅的[FDDE40]太古兽面鼎[-]",
			Type = ItemType.Challenge,
			CountType = GoalCountType.Current,
			Num = 1,
			Value = 140409,
		},
	},
	Reward = {
		{
			Value = 330003,
			Num = 1,
		},
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id837] =
{
	Id = 837,
	Name = "主线240 - 保安的伙食",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130104,
		PreGoal = 
		{
			300836,
		},
	},
	GoalTrigger = 
	{
		TriggerType.ExploreCost,
	},
	GoalCondition = 
	{
		{
			Name = "探索[62E7E7]文物厅[-]消耗[FDDE40]大便当[-]5个",
			Type = ItemType.Goods,
			CountType = GoalCountType.StartNow,
			Num = 5,
			Value = 320411,
			Area = 130104,
		},
	},
	Reward = {
		{
			Value = 330001,
			Num = 7,
		},
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id838] =
{
	Id = 838,
	Name = "主线241 - 捕捉铜兽",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130104,
		PreGoal = 
		{
			300837,
		},
	},
	GoalTrigger = 
	{
		TriggerType.CollectItem,
	},
	GoalCondition = 
	{
		{
			Name = "累计捕捉宠物[FDDE40]兽面鼎[-]5个(需要道具店的陷阱)",
			Type = ItemType.Pet,
			CountType = GoalCountType.Current,
			Num = 5,
			Value = 250063,
		},
	},
	Reward = {
		{
			Value = 330001,
			Num = 7,
		},
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id839] =
{
	Id = 839,
	Name = "主线242 - 青烟缭绕",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130104,
		PreGoal = 
		{
			300838,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Explore,
	},
	GoalCondition = 
	{
		{
			Name = "在探索中获得[FDDE40]焚香[-]100个",
			Type = ItemType.Goods,
			CountType = GoalCountType.StartNow,
			Num = 100,
			Value = 321403,
		},
	},
	Reward = {
		{
			Value = 330001,
			Num = 7,
		},
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id840] =
{
	Id = 840,
	Name = "主线243 - 远古猪罐的挑战",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130104,
		PreGoal = 
		{
			300839,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Challenge,
	},
	GoalCondition = 
	{
		{
			Name = "打败文物厅的[FDDE40]远古猪罐[-]",
			Type = ItemType.Challenge,
			CountType = GoalCountType.Current,
			Num = 1,
			Value = 140410,
		},
	},
	CompleteSpeech = 30084001,
	Reward = {
		{
			Value = 130106,
			Num = 1,
		},
		{
			Value = 330003,
			Num = 1,
		},
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id841] =
{
	Id = 841,
	Name = "主线244 - 雨林的冒险家",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130106,
		PreGoal = 
		{
			300840,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Explore,
	},
	GoalCondition = 
	{
		{
			Name = "派遣含有[62E7E7]1个[-][62E7E7]紫色及以上品质[-]、[62E7E7]水元素[-]队员(或宠物)的队伍探索博物馆星[FDDE40]生态园[-]12小时",
			Type = ItemType.Time,
			CountType = GoalCountType.StartNow,
			Num = 43200,
			TagList = 
			{
				560034,
				561202,
			},
			CharacterNum = 1,
			Value = 130106,
		},
	},
	Reward = {
		{
			Value = 330002,
			Num = 1,
		},
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id842] =
{
	Id = 842,
	Name = "主线245 - 收集零件4",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130106,
		PreGoal = 
		{
			300841,
		},
	},
	GoalTrigger = 
	{
		TriggerType.DemandReward,
	},
	GoalCondition = 
	{
		{
			Name = "完成[62E7E7]委托[-]获得[62E7E7]B级及以上零件[-]道具40个",
			Type = ItemType.Goods,
			CountType = GoalCountType.StartNow,
			Num = 40,
			TagList = 
			{
				564364,
			},
			Value = -1,
		},
	},
	Reward = {
		{
			Value = 330002,
			Num = 1,
		},
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id843] =
{
	Id = 843,
	Name = "主线246 - 强化装备7",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130106,
		PreGoal = 
		{
			300842,
		},
	},
	GoalTrigger = 
	{
		TriggerType.UpgradeEquipment,
	},
	GoalCondition = 
	{
		{
			Name = "强化[62E7E7]任意[-][FDDE40]装备[-]90次",
			Type = ItemType.Equipment,
			CountType = GoalCountType.Current,
			Num = 90,
			Value = -1,
		},
	},
	Reward = {
		{
			Value = 330002,
			Num = 1,
		},
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id844] =
{
	Id = 844,
	Name = "主线247 - 精英雨林龙的挑战",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130106,
		PreGoal = 
		{
			300843,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Challenge,
	},
	GoalCondition = 
	{
		{
			Name = "打败生态园的[FDDE40]精英雨林龙[-]",
			Type = ItemType.Challenge,
			CountType = GoalCountType.Current,
			Num = 1,
			Value = 140416,
		},
	},
	Reward = {
		{
			Value = 330003,
			Num = 1,
		},
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id845] =
{
	Id = 845,
	Name = "主线248 - 提防恐龙",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130106,
		PreGoal = 
		{
			300844,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Explore,
	},
	GoalCondition = 
	{
		{
			Name = "在探索中击败[FDDE40]雨林快走龙[-]50个，建议探索10小时以上",
			Type = ItemType.Enemy,
			CountType = GoalCountType.StartNow,
			Num = 50,
			Value = 242069,
		},
	},
	Reward = {
		{
			Value = 330002,
			Num = 1,
		},
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id846] =
{
	Id = 846,
	Name = "主线249 - 生态园的小家伙",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130106,
		PreGoal = 
		{
			300845,
		},
	},
	GoalTrigger = 
	{
		TriggerType.CollectItem,
	},
	GoalCondition = 
	{
		{
			Name = "累计捕捉宠物[FDDE40]雨林快走龙[-]5个(需要道具店的陷阱)",
			Type = ItemType.Pet,
			CountType = GoalCountType.Current,
			Num = 5,
			Value = 250069,
		},
	},
	Reward = {
		{
			Value = 330002,
			Num = 1,
		},
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id847] =
{
	Id = 847,
	Name = "主线250 - 沙漠冒险家",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130106,
		PreGoal = 
		{
			300846,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Explore,
	},
	GoalCondition = 
	{
		{
			Name = "携带[62E7E7]雨林快走龙[-]探索博物馆星[FDDE40]生态园[-]12小时",
			Type = ItemType.Time,
			CountType = GoalCountType.StartNow,
			Num = 43200,
			Pet = 250069,
			Value = 130106,
		},
	},
	Reward = {
		{
			Value = 330002,
			Num = 1,
		},
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id848] =
{
	Id = 848,
	Name = "主线251 - 精英沙漠龙的挑战",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130106,
		PreGoal = 
		{
			300847,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Challenge,
	},
	GoalCondition = 
	{
		{
			Name = "打败生态园的[FDDE40]精英沙漠龙[-]",
			Type = ItemType.Challenge,
			CountType = GoalCountType.Current,
			Num = 1,
			Value = 140417,
		},
	},
	Reward = {
		{
			Value = 330003,
			Num = 1,
		},
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id849] =
{
	Id = 849,
	Name = "主线252 - 奇怪的恐龙宝宝",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130106,
		PreGoal = 
		{
			300848,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Explore,
	},
	GoalCondition = 
	{
		{
			Name = "在探索中获得[FDDE40]绿蛋壳[-]50个",
			Type = ItemType.Goods,
			CountType = GoalCountType.StartNow,
			Num = 50,
			Value = 321405,
		},
	},
	Reward = {
		{
			Value = 330002,
			Num = 1,
		},
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id850] =
{
	Id = 850,
	Name = "主线253 - 收藏家的委托",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130106,
		PreGoal = 
		{
			300849,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Craft,
	},
	GoalCondition = 
	{
		{
			Name = "在实验室合成获得[FDDE40]黄蛋壳[-]10个",
			Type = ItemType.Goods,
			CountType = GoalCountType.StartNow,
			Num = 10,
			Value = 321451,
		},
	},
	Reward = {
		{
			Value = 330002,
			Num = 1,
		},
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id851] =
{
	Id = 851,
	Name = "主线254 - 淘气的沙漠龙",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130106,
		PreGoal = 
		{
			300850,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Explore,
	},
	GoalCondition = 
	{
		{
			Name = "派遣[62E7E7]保安[-]在探索中击败[FDDE40]沙漠快走龙[-]50个，建议探索13小时以上",
			Type = ItemType.Enemy,
			CountType = GoalCountType.StartNow,
			Num = 50,
			Character = 
			{
				220201,
			},
			Value = 242070,
		},
	},
	Reward = {
		{
			Value = 330002,
			Num = 1,
		},
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id852] =
{
	Id = 852,
	Name = "主线255 - 上古恐龙化石的挑战",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130106,
		PreGoal = 
		{
			300851,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Challenge,
	},
	GoalCondition = 
	{
		{
			Name = "打败生态园的[FDDE40]上古恐龙化石[-]",
			Type = ItemType.Challenge,
			CountType = GoalCountType.Current,
			Num = 1,
			Value = 140418,
		},
	},
	CompleteSpeech = 30085201,
	Reward = {
		{
			Value = 130108,
			Num = 1,
		},
		{
			Value = 330003,
			Num = 1,
		},
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id853] =
{
	Id = 853,
	Name = "主线256 - 收集样本",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130108,
		PreGoal = 
		{
			300852,
		},
	},
	GoalTrigger = 
	{
		TriggerType.CollectItem,
	},
	GoalCondition = 
	{
		{
			Name = "累计捕捉宠物[FDDE40]左半碗[-]10个(需要事务所的纸板箱)",
			Type = ItemType.Pet,
			CountType = GoalCountType.Current,
			Num = 10,
			Value = 250056,
		},
	},
	Reward = {
		{
			Value = 330002,
			Num = 1,
		},
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id854] =
{
	Id = 854,
	Name = "主线257 - 寻找另一半",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130108,
		PreGoal = 
		{
			300853,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Explore,
	},
	GoalCondition = 
	{
		{
			Name = "携带[62E7E7]左半碗[-]探索博物馆星[FDDE40]古文明厅[-]20小时",
			Type = ItemType.Time,
			CountType = GoalCountType.StartNow,
			Num = 72000,
			Pet = 250056,
			Value = 130108,
		},
	},
	Reward = {
		{
			Value = 330002,
			Num = 1,
		},
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id855] =
{
	Id = 855,
	Name = "主线258 - 初步配对",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130108,
		PreGoal = 
		{
			300854,
		},
	},
	GoalTrigger = 
	{
		TriggerType.CollectItem,
	},
	GoalCondition = 
	{
		{
			Name = "累计捕捉宠物[FDDE40]右半碗[-]1个(需要事务所的纸板箱)",
			Type = ItemType.Pet,
			CountType = GoalCountType.Current,
			Num = 1,
			Value = 250057,
		},
	},
	Reward = {
		{
			Value = 330002,
			Num = 1,
		},
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id856] =
{
	Id = 856,
	Name = "主线259 - 右半碗代表的挑战",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130108,
		PreGoal = 
		{
			300855,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Challenge,
	},
	GoalCondition = 
	{
		{
			Name = "打败古文明厅的[FDDE40]右半碗代表[-]",
			Type = ItemType.Challenge,
			CountType = GoalCountType.Current,
			Num = 1,
			Value = 140422,
		},
	},
	Reward = {
		{
			Value = 330003,
			Num = 1,
		},
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id857] =
{
	Id = 857,
	Name = "主线260 - 鸮(xiao)卣(you)",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130108,
		PreGoal = 
		{
			300856,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Explore,
	},
	GoalCondition = 
	{
		{
			Name = "派遣含有[62E7E7]2个[-][62E7E7]紫色及以上品质[-]、[62E7E7]暗元素[-]队员(或宠物)的队伍探索博物馆星[FDDE40]古文明厅[-]12小时",
			Type = ItemType.Time,
			CountType = GoalCountType.StartNow,
			Num = 43200,
			TagList = 
			{
				560034,
				561206,
			},
			CharacterNum = 2,
			Value = 130108,
		},
	},
	Reward = {
		{
			Value = 330002,
			Num = 1,
		},
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id858] =
{
	Id = 858,
	Name = "主线261 - 能量涌动",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130108,
		PreGoal = 
		{
			300857,
		},
	},
	GoalTrigger = 
	{
		TriggerType.DemandReward,
	},
	GoalCondition = 
	{
		{
			Name = "完成[62E7E7]委托[-]获得[62E7E7]电池类的[-]道具5个",
			Type = ItemType.Goods,
			CountType = GoalCountType.StartNow,
			Num = 5,
			TagList = 
			{
				564303,
			},
			Value = -1,
		},
	},
	Reward = {
		{
			Value = 330002,
			Num = 1,
		},
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id859] =
{
	Id = 859,
	Name = "主线262 - 兽鼎法阵",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130108,
		PreGoal = 
		{
			300858,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Explore,
	},
	GoalCondition = 
	{
		{
			Name = "在探索中击败[FDDE40]兽面鼎[-]40个，建议探索8小时以上",
			Type = ItemType.Enemy,
			CountType = GoalCountType.StartNow,
			Num = 40,
			Value = 242063,
		},
	},
	Reward = {
		{
			Value = 330002,
			Num = 1,
		},
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id860] =
{
	Id = 860,
	Name = "主线263 - 祭司鸮卣的挑战",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130108,
		PreGoal = 
		{
			300859,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Challenge,
	},
	GoalCondition = 
	{
		{
			Name = "打败古文明厅的[FDDE40]祭司鸮卣[-]",
			Type = ItemType.Challenge,
			CountType = GoalCountType.Current,
			Num = 1,
			Value = 140423,
		},
	},
	Reward = {
		{
			Value = 330003,
			Num = 1,
		},
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id861] =
{
	Id = 861,
	Name = "主线264 - 研究法器1",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130108,
		PreGoal = 
		{
			300860,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Explore,
	},
	GoalCondition = 
	{
		{
			Name = "派遣含有[62E7E7]3个[-][62E7E7]博物馆星[-]队员(或宠物)的队伍探索博物馆星[FDDE40]古文明厅[-]12小时",
			Type = ItemType.Time,
			CountType = GoalCountType.StartNow,
			Num = 43200,
			TagList = 
			{
				560105,
			},
			CharacterNum = 3,
			Value = 130108,
		},
	},
	Reward = {
		{
			Value = 330002,
			Num = 1,
		},
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id862] =
{
	Id = 862,
	Name = "主线265 - 冒险的旅费7",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130108,
		PreGoal = 
		{
			300861,
		},
	},
	GoalTrigger = 
	{
		TriggerType.DemandReward,
	},
	GoalCondition = 
	{
		{
			Name = "完成[62E7E7]委托[-]获得[FDDE40]金币[-]150000个",
			Type = ItemType.Gold,
			CountType = GoalCountType.StartNow,
			Num = 150000,
			Value = 1,
		},
	},
	Reward = {
		{
			Value = 330002,
			Num = 1,
		},
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id863] =
{
	Id = 863,
	Name = "主线266 - 古代封印",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130108,
		PreGoal = 
		{
			300862,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Explore,
	},
	GoalCondition = 
	{
		{
			Name = "在探索中获得[FDDE40]封条[-]30个",
			Type = ItemType.Goods,
			CountType = GoalCountType.StartNow,
			Num = 30,
			Value = 321407,
		},
	},
	Reward = {
		{
			Value = 330002,
			Num = 1,
		},
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id864] =
{
	Id = 864,
	Name = "主线267 - 祭典金鸮卣的挑战",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130108,
		PreGoal = 
		{
			300863,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Challenge,
	},
	GoalCondition = 
	{
		{
			Name = "打败古文明厅的[FDDE40]祭典金鸮卣[-]",
			Type = ItemType.Challenge,
			CountType = GoalCountType.Current,
			Num = 1,
			Value = 140424,
		},
	},
	CompleteSpeech = 30086401,
	Reward = {
		{
			Value = 330003,
			Num = 1,
		},
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id865] =
{
	Id = 865,
	Name = "主线268 - 破坏法器",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130108,
		PreGoal = 
		{
			300864,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Explore,
	},
	GoalCondition = 
	{
		{
			Name = "在探索中击败[FDDE40]金鸮卣[-]8个，建议探索23小时以上",
			Type = ItemType.Enemy,
			CountType = GoalCountType.StartNow,
			Num = 8,
			Value = 242075,
		},
	},
	Reward = {
		{
			Value = 330002,
			Num = 1,
		},
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id866] =
{
	Id = 866,
	Name = "主线269 - 研究法器2",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130108,
		PreGoal = 
		{
			300865,
		},
	},
	GoalTrigger = 
	{
		TriggerType.CollectItem,
	},
	GoalCondition = 
	{
		{
			Name = "累计捕捉宠物[FDDE40]鸮卣[-]5个(需要事务所的纸板箱)",
			Type = ItemType.Pet,
			CountType = GoalCountType.Current,
			Num = 5,
			Value = 250074,
		},
	},
	Reward = {
		{
			Value = 330002,
			Num = 1,
		},
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id867] =
{
	Id = 867,
	Name = "主线270 - 寻找哥哥",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130108,
		PreGoal = 
		{
			300866,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Explore,
	},
	GoalCondition = 
	{
		{
			Name = "派遣[62E7E7]浣熊小弟[-]探索博物馆星[FDDE40]古文明厅[-]23小时",
			Type = ItemType.Time,
			CountType = GoalCountType.StartNow,
			Num = 82800,
			Character = 
			{
				220205,
			},
			Value = 130108,
		},
	},
	Reward = {
		{
			Value = 330002,
			Num = 1,
		},
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id868] =
{
	Id = 868,
	Name = "主线271 - 浣熊二哥的挑战",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130108,
		PreGoal = 
		{
			300867,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Challenge,
	},
	GoalCondition = 
	{
		{
			Name = "打败古文明厅的[FDDE40]浣熊二哥[-]",
			Type = ItemType.Challenge,
			CountType = GoalCountType.Current,
			Num = 1,
			Value = 140425,
		},
	},
	CompleteSpeech = 30086801,
	Reward = {
		{
			Value = 130109,
			Num = 1,
		},
		{
			Value = 330003,
			Num = 1,
		},
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id869] =
{
	Id = 869,
	Name = "主线272 - 警局打工3",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130109,
		PreGoal = 
		{
			300868,
		},
	},
	GoalTrigger = 
	{
		TriggerType.WorkShopRank,
	},
	GoalCondition = 
	{
		{
			Name = "在[FDDE40]警察局[-]打工获得[FDDE40]C-[-]或更高评价",
			Type = ItemType.WorkShop,
			CountType = GoalCountType.Current,
			Num = 1,
			Value = 160003,
			Rank = 11,
		},
	},
	Reward = {
		{
			Value = 330002,
			Num = 1,
		},
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id870] =
{
	Id = 870,
	Name = "主线273 - 大海的遗物",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130109,
		PreGoal = 
		{
			300869,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Explore,
	},
	GoalCondition = 
	{
		{
			Name = "派遣含有[62E7E7]2个[-][62E7E7]紫色及以上品质[-]、[62E7E7]水元素[-]队员(或宠物)的队伍探索博物馆星[FDDE40]化石厅[-]23小时",
			Type = ItemType.Time,
			CountType = GoalCountType.StartNow,
			Num = 82800,
			TagList = 
			{
				560034,
				561202,
			},
			CharacterNum = 2,
			Value = 130109,
		},
	},
	Reward = {
		{
			Value = 330002,
			Num = 1,
		},
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id871] =
{
	Id = 871,
	Name = "主线274 - 水之声",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130109,
		PreGoal = 
		{
			300870,
		},
	},
	GoalTrigger = 
	{
		TriggerType.CollectItem,
	},
	GoalCondition = 
	{
		{
			Name = "累计拥有[62E7E7]水元素[-][FDDE40]宠物[-]10种",
			Type = ItemType.Pet,
			CountType = GoalCountType.Current,
			Num = 10,
			TagList = 
			{
				561202,
			},
			Value = -1,
		},
	},
	Reward = {
		{
			Value = 330002,
			Num = 1,
		},
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id872] =
{
	Id = 872,
	Name = "主线275 - 完整鱼化石的挑战",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130109,
		PreGoal = 
		{
			300871,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Challenge,
	},
	GoalCondition = 
	{
		{
			Name = "打败化石厅的[FDDE40]完整鱼化石[-]",
			Type = ItemType.Challenge,
			CountType = GoalCountType.Current,
			Num = 1,
			Value = 140426,
		},
	},
	Reward = {
		{
			Value = 330003,
			Num = 1,
		},
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id873] =
{
	Id = 873,
	Name = "主线276 - 海中的堡垒",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130109,
		PreGoal = 
		{
			300872,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Explore,
	},
	GoalCondition = 
	{
		{
			Name = "派遣含有[62E7E7]2个[-][62E7E7]紫色及以上品质[-]、[62E7E7]风元素[-]队员(或宠物)的队伍探索博物馆星[FDDE40]化石厅[-]12小时",
			Type = ItemType.Time,
			CountType = GoalCountType.StartNow,
			Num = 43200,
			TagList = 
			{
				560034,
				561204,
			},
			CharacterNum = 2,
			Value = 130109,
		},
	},
	Reward = {
		{
			Value = 330002,
			Num = 1,
		},
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id874] =
{
	Id = 874,
	Name = "主线277 - 强化装备8",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130109,
		PreGoal = 
		{
			300873,
		},
	},
	GoalTrigger = 
	{
		TriggerType.UpgradeEquipment,
	},
	GoalCondition = 
	{
		{
			Name = "强化[62E7E7]任意[-][FDDE40]装备[-]100次",
			Type = ItemType.Equipment,
			CountType = GoalCountType.Current,
			Num = 100,
			Value = -1,
		},
	},
	Reward = {
		{
			Value = 330002,
			Num = 1,
		},
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id875] =
{
	Id = 875,
	Name = "主线278 - 水之形",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130109,
		PreGoal = 
		{
			300874,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Explore,
	},
	GoalCondition = 
	{
		{
			Name = "捕获宠物[FDDE40]鱼化石[-]5个(需要超市的空瓶)",
			Type = ItemType.Pet,
			CountType = GoalCountType.StartNow,
			Num = 5,
			Value = 250076,
		},
	},
	Reward = {
		{
			Value = 330002,
			Num = 1,
		},
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id876] =
{
	Id = 876,
	Name = "主线279 - 完整乌龟化石的挑战",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130109,
		PreGoal = 
		{
			300875,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Challenge,
	},
	GoalCondition = 
	{
		{
			Name = "打败化石厅的[FDDE40]完整乌龟化石[-]",
			Type = ItemType.Challenge,
			CountType = GoalCountType.Current,
			Num = 1,
			Value = 140427,
		},
	},
	CompleteSpeech = 30087601,
	Reward = {
		{
			Value = 330003,
			Num = 1,
		},
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id877] =
{
	Id = 877,
	Name = "主线280 - 三宫六院",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130109,
		PreGoal = 
		{
			300876,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Explore,
	},
	GoalCondition = 
	{
		{
			Name = "派遣含有[62E7E7]5个[-][62E7E7]女性[-]队员(或宠物)的队伍探索博物馆星[FDDE40]化石厅[-]23小时",
			Type = ItemType.Time,
			CountType = GoalCountType.StartNow,
			Num = 82800,
			TagList = 
			{
				561703,
			},
			CharacterNum = 5,
			Value = 130109,
		},
	},
	Reward = {
		{
			Value = 330002,
			Num = 1,
		},
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id878] =
{
	Id = 878,
	Name = "主线281 - 女友的礼物",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130109,
		PreGoal = 
		{
			300877,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Explore,
	},
	GoalCondition = 
	{
		{
			Name = "在探索中获得[FDDE40]海洋化石[-]40个",
			Type = ItemType.Goods,
			CountType = GoalCountType.StartNow,
			Num = 40,
			Value = 321408,
		},
	},
	Reward = {
		{
			Value = 330002,
			Num = 1,
		},
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id879] =
{
	Id = 879,
	Name = "主线282 - 强化小队",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130109,
		PreGoal = 
		{
			300878,
		},
	},
	GoalTrigger = 
	{
		TriggerType.CollectItem,
	},
	GoalCondition = 
	{
		{
			Name = "拥有至少[62E7E7]40级[-][62E7E7]紫色及以上品质[-][FDDE40]角色[-]5个",
			Type = ItemType.Character,
			CountType = GoalCountType.Current,
			Num = 5,
			Value = -1,
			Rarity = 3,
			Level = 40,
		},
	},
	Reward = {
		{
			Value = 330002,
			Num = 1,
		},
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id880] =
{
	Id = 880,
	Name = "主线283 - 猪蹄古董的挑战",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130109,
		PreGoal = 
		{
			300879,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Challenge,
	},
	GoalCondition = 
	{
		{
			Name = "打败化石厅的[FDDE40]猪蹄古董[-]",
			Type = ItemType.Challenge,
			CountType = GoalCountType.Current,
			Num = 1,
			Value = 140428,
		},
	},
	Reward = {
		{
			Value = 130110,
			Num = 1,
		},
		{
			Value = 330003,
			Num = 1,
		},
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id881] =
{
	Id = 881,
	Name = "主线284 - 奇怪的泥塑",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130110,
		PreGoal = 
		{
			300880,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Explore,
	},
	GoalCondition = 
	{
		{
			Name = "探索博物馆星[FDDE40]泥塑厅[-]18小时",
			Type = ItemType.Time,
			CountType = GoalCountType.StartNow,
			Num = 64800,
			Value = 130110,
		},
	},
	Reward = {
		{
			Value = 330002,
			Num = 1,
		},
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id882] =
{
	Id = 882,
	Name = "主线285 - 高级委托1",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130110,
		PreGoal = 
		{
			300881,
		},
	},
	GoalTrigger = 
	{
		TriggerType.DemandCost,
	},
	GoalCondition = 
	{
		{
			Name = "在委托中提交[62E7E7]合成的[-]道具10个",
			Type = ItemType.Goods,
			CountType = GoalCountType.StartNow,
			Num = 10,
			TagList = 
			{
				560005,
			},
			Value = -1,
		},
	},
	Reward = {
		{
			Value = 330002,
			Num = 1,
		},
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id883] =
{
	Id = 883,
	Name = "主线286 - 调取监控",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130110,
		PreGoal = 
		{
			300882,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Explore,
	},
	GoalCondition = 
	{
		{
			Name = "在探索中获得[FDDE40]海洋化石[-]20个",
			Type = ItemType.Goods,
			CountType = GoalCountType.StartNow,
			Num = 20,
			Value = 321408,
		},
	},
	Reward = {
		{
			Value = 330002,
			Num = 1,
		},
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id884] =
{
	Id = 884,
	Name = "主线287 - 太古碧鱬的挑战",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130110,
		PreGoal = 
		{
			300883,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Challenge,
	},
	GoalCondition = 
	{
		{
			Name = "打败泥塑厅的[FDDE40]太古碧鱬[-]",
			Type = ItemType.Challenge,
			CountType = GoalCountType.Current,
			Num = 1,
			Value = 140429,
		},
	},
	Reward = {
		{
			Value = 330003,
			Num = 1,
		},
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id885] =
{
	Id = 885,
	Name = "主线288 - 海中的掠影",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130110,
		PreGoal = 
		{
			300884,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Explore,
	},
	GoalCondition = 
	{
		{
			Name = "在探索中击败[FDDE40]碧鱬[-]60个，建议探索16小时以上",
			Type = ItemType.Enemy,
			CountType = GoalCountType.StartNow,
			Num = 60,
			Value = 242078,
		},
	},
	Reward = {
		{
			Value = 330002,
			Num = 1,
		},
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id886] =
{
	Id = 886,
	Name = "主线289 - 古怪的面具",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130110,
		PreGoal = 
		{
			300885,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Explore,
	},
	GoalCondition = 
	{
		{
			Name = "在探索中获得[FDDE40]青面具[-]20个",
			Type = ItemType.Goods,
			CountType = GoalCountType.StartNow,
			Num = 20,
			Value = 321409,
		},
	},
	Reward = {
		{
			Value = 330002,
			Num = 1,
		},
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id887] =
{
	Id = 887,
	Name = "主线290 - 寻找赤鱬",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130110,
		PreGoal = 
		{
			300886,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Craft,
	},
	GoalCondition = 
	{
		{
			Name = "在实验室合成获得[FDDE40]黄面具[-]5个",
			Type = ItemType.Goods,
			CountType = GoalCountType.StartNow,
			Num = 5,
			Value = 321452,
		},
	},
	Reward = {
		{
			Value = 330002,
			Num = 1,
		},
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id888] =
{
	Id = 888,
	Name = "主线291 - 太古赤鱬的挑战",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130110,
		PreGoal = 
		{
			300887,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Challenge,
	},
	GoalCondition = 
	{
		{
			Name = "打败泥塑厅的[FDDE40]太古赤鱬[-]",
			Type = ItemType.Challenge,
			CountType = GoalCountType.Current,
			Num = 1,
			Value = 140430,
		},
	},
	CompleteSpeech = 30088801,
	Reward = {
		{
			Value = 130111,
			Num = 1,
		},
		{
			Value = 330003,
			Num = 1,
		},
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id889] =
{
	Id = 889,
	Name = "主线292 - 寻找寒带一角龙",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130111,
		PreGoal = 
		{
			300888,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Explore,
	},
	GoalCondition = 
	{
		{
			Name = "派遣含有[62E7E7]2个[-][62E7E7]紫色及以上品质[-]、[62E7E7]水元素[-]队员(或宠物)的队伍探索博物馆星[FDDE40]恐龙馆[-]18小时",
			Type = ItemType.Time,
			CountType = GoalCountType.StartNow,
			Num = 64800,
			TagList = 
			{
				560034,
				561202,
			},
			CharacterNum = 2,
			Value = 130111,
		},
	},
	Reward = {
		{
			Value = 330002,
			Num = 1,
		},
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id890] =
{
	Id = 890,
	Name = "主线293 - 深入研究",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130111,
		PreGoal = 
		{
			300889,
		},
	},
	GoalTrigger = 
	{
		TriggerType.DemandCost,
	},
	GoalCondition = 
	{
		{
			Name = "在委托中提交[62E7E7]博物馆星[-]道具120个",
			Type = ItemType.Goods,
			CountType = GoalCountType.StartNow,
			Num = 120,
			TagList = 
			{
				560105,
			},
			Value = -1,
		},
	},
	Reward = {
		{
			Value = 330002,
			Num = 1,
		},
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id891] =
{
	Id = 891,
	Name = "主线294 - 寒带恐龙",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130111,
		PreGoal = 
		{
			300890,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Explore,
	},
	GoalCondition = 
	{
		{
			Name = "携带[62E7E7]雨林快走龙[-]探索博物馆星[FDDE40]恐龙馆[-]18小时",
			Type = ItemType.Time,
			CountType = GoalCountType.StartNow,
			Num = 64800,
			Pet = 250069,
			Value = 130111,
		},
	},
	Reward = {
		{
			Value = 330002,
			Num = 1,
		},
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id892] =
{
	Id = 892,
	Name = "主线295 - 精英寒带龙的挑战",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130111,
		PreGoal = 
		{
			300891,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Challenge,
	},
	GoalCondition = 
	{
		{
			Name = "打败恐龙馆的[FDDE40]精英寒带龙[-]",
			Type = ItemType.Challenge,
			CountType = GoalCountType.Current,
			Num = 1,
			Value = 140431,
		},
	},
	Reward = {
		{
			Value = 330003,
			Num = 1,
		},
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id893] =
{
	Id = 893,
	Name = "主线296 - 寻找热带一角龙",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130111,
		PreGoal = 
		{
			300892,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Explore,
	},
	GoalCondition = 
	{
		{
			Name = "派遣含有[62E7E7]2个[-][62E7E7]紫色及以上品质[-]、[62E7E7]火元素[-]队员(或宠物)的队伍探索博物馆星[FDDE40]恐龙馆[-]18小时",
			Type = ItemType.Time,
			CountType = GoalCountType.StartNow,
			Num = 64800,
			TagList = 
			{
				560034,
				561203,
			},
			CharacterNum = 2,
			Value = 130111,
		},
	},
	Reward = {
		{
			Value = 330002,
			Num = 1,
		},
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id894] =
{
	Id = 894,
	Name = "主线297 - 热带恐龙",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130111,
		PreGoal = 
		{
			300893,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Explore,
	},
	GoalCondition = 
	{
		{
			Name = "携带[62E7E7]沙漠快走龙[-]探索博物馆星[FDDE40]恐龙馆[-]18小时",
			Type = ItemType.Time,
			CountType = GoalCountType.StartNow,
			Num = 64800,
			Pet = 250070,
			Value = 130111,
		},
	},
	Reward = {
		{
			Value = 330002,
			Num = 1,
		},
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id895] =
{
	Id = 895,
	Name = "主线298 - 击败寒带一角龙",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130111,
		PreGoal = 
		{
			300894,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Explore,
	},
	GoalCondition = 
	{
		{
			Name = "在探索中击败[FDDE40]寒带一角龙[-]70个，建议探索18小时以上",
			Type = ItemType.Enemy,
			CountType = GoalCountType.StartNow,
			Num = 70,
			Value = 242080,
		},
	},
	Reward = {
		{
			Value = 330002,
			Num = 1,
		},
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id896] =
{
	Id = 896,
	Name = "主线299 - 精英热带龙的挑战",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130111,
		PreGoal = 
		{
			300895,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Challenge,
	},
	GoalCondition = 
	{
		{
			Name = "打败恐龙馆的[FDDE40]精英热带龙[-]",
			Type = ItemType.Challenge,
			CountType = GoalCountType.Current,
			Num = 1,
			Value = 140432,
		},
	},
	CompleteSpeech = 30089601,
	Reward = {
		{
			Value = 330003,
			Num = 1,
		},
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id897] =
{
	Id = 897,
	Name = "主线300 - 能干的二哥",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130111,
		PreGoal = 
		{
			300896,
		},
	},
	GoalTrigger = 
	{
		TriggerType.CollectItem,
	},
	GoalCondition = 
	{
		{
			Name = "拥有至少[62E7E7]35级[-][FDDE40]浣熊二哥[-]",
			Type = ItemType.Character,
			CountType = GoalCountType.Current,
			Num = 1,
			Value = 220204,
			Level = 35,
		},
	},
	Reward = {
		{
			Value = 330002,
			Num = 1,
		},
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id898] =
{
	Id = 898,
	Name = "主线301 - 懂事的小弟",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130111,
		PreGoal = 
		{
			300897,
		},
	},
	GoalTrigger = 
	{
		TriggerType.CollectItem,
	},
	GoalCondition = 
	{
		{
			Name = "拥有至少[62E7E7]35级[-][FDDE40]浣熊小弟[-]",
			Type = ItemType.Character,
			CountType = GoalCountType.Current,
			Num = 1,
			Value = 220205,
			Level = 35,
		},
	},
	Reward = {
		{
			Value = 330002,
			Num = 1,
		},
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id899] =
{
	Id = 899,
	Name = "主线302 - 寻找大哥",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130111,
		PreGoal = 
		{
			300898,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Explore,
	},
	GoalCondition = 
	{
		{
			Name = "派遣[62E7E7]浣熊二哥[-]、[62E7E7]浣熊小弟[-]探索博物馆星[FDDE40]恐龙馆[-]23小时",
			Type = ItemType.Time,
			CountType = GoalCountType.StartNow,
			Num = 82800,
			Character = 
			{
				220204,
				220205,
			},
			Value = 130111,
		},
	},
	Reward = {
		{
			Value = 330002,
			Num = 1,
		},
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id900] =
{
	Id = 900,
	Name = "主线303 - 浣熊大哥的挑战",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130111,
		PreGoal = 
		{
			300899,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Challenge,
	},
	GoalCondition = 
	{
		{
			Name = "打败恐龙馆的[FDDE40]浣熊大哥[-]",
			Type = ItemType.Challenge,
			CountType = GoalCountType.Current,
			Num = 1,
			Value = 140433,
		},
	},
	CompleteSpeech = 30090001,
	Reward = {
		{
			Value = 130112,
			Num = 1,
		},
		{
			Value = 330003,
			Num = 1,
		},
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id901] =
{
	Id = 901,
	Name = "主线304 - 出入平安",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130112,
		PreGoal = 
		{
			300900,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Explore,
	},
	GoalCondition = 
	{
		{
			Name = "携带[62E7E7]入口[-]探索博物馆星[FDDE40]出口[-]12小时",
			Type = ItemType.Time,
			CountType = GoalCountType.StartNow,
			Num = 43200,
			Pet = 250058,
			Value = 130112,
		},
	},
	Reward = {
		{
			Value = 330002,
			Num = 1,
		},
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id902] =
{
	Id = 902,
	Name = "主线305 - 收集路牌",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130112,
		PreGoal = 
		{
			300901,
		},
	},
	GoalTrigger = 
	{
		TriggerType.CollectItem,
	},
	GoalCondition = 
	{
		{
			Name = "累计捕捉宠物[FDDE40]入口[-]10个(需要事务所的工具箱)",
			Type = ItemType.Pet,
			CountType = GoalCountType.Current,
			Num = 10,
			Value = 250058,
		},
	},
	Reward = {
		{
			Value = 330002,
			Num = 1,
		},
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id903] =
{
	Id = 903,
	Name = "主线306 - 博物馆星高级委托",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130112,
		PreGoal = 
		{
			300902,
		},
	},
	GoalTrigger = 
	{
		TriggerType.DemandCost,
	},
	GoalCondition = 
	{
		{
			Name = "在委托中提交[62E7E7]合成的[-]、[62E7E7]博物馆星[-]道具5个",
			Type = ItemType.Goods,
			CountType = GoalCountType.StartNow,
			Num = 5,
			TagList = 
			{
				560005,
				560105,
			},
			Value = -1,
		},
	},
	Reward = {
		{
			Value = 330002,
			Num = 1,
		},
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id904] =
{
	Id = 904,
	Name = "主线307 - 出口队长的挑战",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130112,
		PreGoal = 
		{
			300903,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Challenge,
	},
	GoalCondition = 
	{
		{
			Name = "打败出口的[FDDE40]出口队长[-]",
			Type = ItemType.Challenge,
			CountType = GoalCountType.Current,
			Num = 1,
			Value = 140434,
		},
	},
	CompleteSpeech = 30090401,
	Reward = {
		{
			Value = 330003,
			Num = 1,
		},
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id905] =
{
	Id = 905,
	Name = "主线308 - 下一站，悬疑星！",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130112,
		PreGoal = 
		{
			300904,
		},
	},
	GoalTrigger = 
	{
		TriggerType.SubmitGoods,
	},
	GoalCondition = 
	{
		{
			Name = "导航系统，启动！路线生成中…\n提交[FDDE40]箭头[-]20个",
			Type = ItemType.Goods,
			CountType = GoalCountType.Current,
			Num = 20,
			Value = 321411,
		},
	},
	CompleteSpeech = 30090501,
	Reward = {
		{
			Value = 130151,
			Num = 1,
		},
		{
			Value = 330002,
			Num = 1,
		},
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id1101] =
{
	Id = 1101,
	Name = "解锁：修复室",
	GoalType = GoalType.Main,
	ShowFirst = false,
	PreCondition = {
		PreArea = 130104,
		PreGoal = 
		{
			300840,
		},
	},
	GoalTrigger = 
	{
		TriggerType.SubmitGoods,
	},
	GoalCondition = 
	{
		{
			Name = "工作地区，进入者请携带对应工具。\n提交[FDDE40]考古刷[-]30个",
			Type = ItemType.Goods,
			CountType = GoalCountType.Current,
			Num = 30,
			Value = 321402,
		},
	},
	Reward = {
		{
			Value = 130105,
			Num = 1,
		},
		{
			Value = 330002,
			Num = 2,
		},
		{
			Value = 2,
			Num = 30,
		},
	},
}
GoalConfig[GoalID.Id1102] =
{
	Id = 1102,
	Name = "支线-博物馆的队员",
	GoalType = GoalType.Main,
	ShowFirst = false,
	PreCondition = {
		PreArea = 130105,
		PreGoal = 
		{
			301101,
		},
	},
	GoalTrigger = 
	{
		TriggerType.CollectItem,
	},
	GoalCondition = 
	{
		{
			Name = "拥有至少[62E7E7]20级[-][62E7E7]博物馆星[-][FDDE40]角色[-]2个",
			Type = ItemType.Character,
			CountType = GoalCountType.Current,
			Num = 2,
			TagList = 
			{
				560105,
			},
			Value = -1,
			Level = 20,
		},
	},
	Reward = {
		{
			Value = 330002,
			Num = 2,
		},
		{
			Value = 2,
			Num = 30,
		},
	},
}
GoalConfig[GoalID.Id1103] =
{
	Id = 1103,
	Name = "支线-进入许可",
	GoalType = GoalType.Main,
	ShowFirst = false,
	PreCondition = {
		PreArea = 130105,
		PreGoal = 
		{
			301102,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Explore,
	},
	GoalCondition = 
	{
		{
			Name = "派遣含有[62E7E7]2个[-][62E7E7]博物馆星[-]队员(或宠物)的队伍探索博物馆星[FDDE40]修复室[-]23小时",
			Type = ItemType.Time,
			CountType = GoalCountType.StartNow,
			Num = 82800,
			TagList = 
			{
				560105,
			},
			CharacterNum = 2,
			Value = 130105,
		},
	},
	Reward = {
		{
			Value = 330002,
			Num = 2,
		},
		{
			Value = 2,
			Num = 30,
		},
	},
}
GoalConfig[GoalID.Id1104] =
{
	Id = 1104,
	Name = "支线-特别的电池",
	GoalType = GoalType.Main,
	ShowFirst = false,
	PreCondition = {
		PreArea = 130105,
		PreGoal = 
		{
			301103,
		},
	},
	GoalTrigger = 
	{
		TriggerType.DemandReward,
	},
	GoalCondition = 
	{
		{
			Name = "完成[62E7E7]委托[-]获得[62E7E7]高能及以上电池[-]道具1个",
			Type = ItemType.Goods,
			CountType = GoalCountType.StartNow,
			Num = 1,
			TagList = 
			{
				564393,
			},
			Value = -1,
		},
	},
	Reward = {
		{
			Value = 330002,
			Num = 2,
		},
		{
			Value = 2,
			Num = 30,
		},
	},
}
GoalConfig[GoalID.Id1105] =
{
	Id = 1105,
	Name = "支线-左半瓷代表的挑战",
	GoalType = GoalType.Main,
	ShowFirst = false,
	PreCondition = {
		PreArea = 130105,
		PreGoal = 
		{
			301104,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Challenge,
	},
	GoalCondition = 
	{
		{
			Name = "打败修复室的[FDDE40]左半瓷代表[-]",
			Type = ItemType.Challenge,
			CountType = GoalCountType.Current,
			Num = 1,
			Value = 140411,
		},
	},
	Reward = {
		{
			Value = 330003,
			Num = 1,
		},
		{
			Value = 2,
			Num = 30,
		},
	},
}
GoalConfig[GoalID.Id1106] =
{
	Id = 1106,
	Name = "支线-碎裂的瓷器",
	GoalType = GoalType.Main,
	ShowFirst = false,
	PreCondition = {
		PreArea = 130105,
		PreGoal = 
		{
			301105,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Explore,
	},
	GoalCondition = 
	{
		{
			Name = "探索[62E7E7]修复室[-]击败[FDDE40]左半瓷[-]180个，建议探索12小时以上",
			Type = ItemType.Enemy,
			CountType = GoalCountType.StartNow,
			Num = 180,
			Value = 242065,
			Area = 130105,
		},
	},
	Reward = {
		{
			Value = 330002,
			Num = 2,
		},
		{
			Value = 2,
			Num = 30,
		},
	},
}
GoalConfig[GoalID.Id1107] =
{
	Id = 1107,
	Name = "支线-探险家的日常2",
	GoalType = GoalType.Main,
	ShowFirst = false,
	PreCondition = {
		PreArea = 130105,
		PreGoal = 
		{
			301106,
		},
	},
	GoalTrigger = 
	{
		TriggerType.CompleteDemand,
	},
	GoalCondition = 
	{
		{
			Name = "完成[62E7E7]任意[-][FDDE40]委托[-]10次",
			Type = ItemType.Demand,
			CountType = GoalCountType.StartNow,
			Num = 10,
			Value = -1,
		},
	},
	Reward = {
		{
			Value = 330002,
			Num = 2,
		},
		{
			Value = 2,
			Num = 30,
		},
	},
}
GoalConfig[GoalID.Id1108] =
{
	Id = 1108,
	Name = "支线-拼接瓷器1",
	GoalType = GoalType.Main,
	ShowFirst = false,
	PreCondition = {
		PreArea = 130105,
		PreGoal = 
		{
			301107,
		},
	},
	GoalTrigger = 
	{
		TriggerType.CollectItem,
	},
	GoalCondition = 
	{
		{
			Name = "累计捕捉宠物[FDDE40]左半瓷[-]3个(需要事务所的纸板箱)",
			Type = ItemType.Pet,
			CountType = GoalCountType.Current,
			Num = 3,
			Value = 250065,
		},
	},
	Reward = {
		{
			Value = 330002,
			Num = 2,
		},
		{
			Value = 2,
			Num = 30,
		},
	},
}
GoalConfig[GoalID.Id1109] =
{
	Id = 1109,
	Name = "支线-右半瓷代表的挑战",
	GoalType = GoalType.Main,
	ShowFirst = false,
	PreCondition = {
		PreArea = 130105,
		PreGoal = 
		{
			301108,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Challenge,
	},
	GoalCondition = 
	{
		{
			Name = "打败修复室的[FDDE40]右半瓷代表[-]",
			Type = ItemType.Challenge,
			CountType = GoalCountType.Current,
			Num = 1,
			Value = 140412,
		},
	},
	Reward = {
		{
			Value = 330003,
			Num = 1,
		},
		{
			Value = 2,
			Num = 30,
		},
	},
}
GoalConfig[GoalID.Id1110] =
{
	Id = 1110,
	Name = "支线-事故现场",
	GoalType = GoalType.Main,
	ShowFirst = false,
	PreCondition = {
		PreArea = 130105,
		PreGoal = 
		{
			301109,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Explore,
	},
	GoalCondition = 
	{
		{
			Name = "在探索中获得[FDDE40]碎瓷片[-]80个",
			Type = ItemType.Goods,
			CountType = GoalCountType.StartNow,
			Num = 80,
			Value = 321404,
		},
	},
	Reward = {
		{
			Value = 330002,
			Num = 2,
		},
		{
			Value = 2,
			Num = 30,
		},
	},
}
GoalConfig[GoalID.Id1111] =
{
	Id = 1111,
	Name = "支线-修复工具",
	GoalType = GoalType.Main,
	ShowFirst = false,
	PreCondition = {
		PreArea = 130105,
		PreGoal = 
		{
			301110,
		},
	},
	GoalTrigger = 
	{
		TriggerType.SubmitGoods,
	},
	GoalCondition = 
	{
		{
			Name = "提交[FDDE40]考古刷[-]20个",
			Type = ItemType.Goods,
			CountType = GoalCountType.Current,
			Num = 20,
			Value = 321402,
		},
	},
	Reward = {
		{
			Value = 330002,
			Num = 2,
		},
		{
			Value = 2,
			Num = 30,
		},
	},
}
GoalConfig[GoalID.Id1112] =
{
	Id = 1112,
	Name = "支线-拼接瓷器2",
	GoalType = GoalType.Main,
	ShowFirst = false,
	PreCondition = {
		PreArea = 130105,
		PreGoal = 
		{
			301111,
		},
	},
	GoalTrigger = 
	{
		TriggerType.CollectItem,
	},
	GoalCondition = 
	{
		{
			Name = "累计捕捉宠物[FDDE40]右半瓷[-]3个(需要事务所的纸板箱)",
			Type = ItemType.Pet,
			CountType = GoalCountType.Current,
			Num = 3,
			Value = 250066,
		},
	},
	Reward = {
		{
			Value = 330002,
			Num = 2,
		},
		{
			Value = 2,
			Num = 30,
		},
	},
}
GoalConfig[GoalID.Id1113] =
{
	Id = 1113,
	Name = "支线-碰瓷王的挑战",
	GoalType = GoalType.Main,
	ShowFirst = false,
	PreCondition = {
		PreArea = 130105,
		PreGoal = 
		{
			301112,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Challenge,
	},
	GoalCondition = 
	{
		{
			Name = "打败修复室的[FDDE40]碰瓷王[-]",
			Type = ItemType.Challenge,
			CountType = GoalCountType.Current,
			Num = 1,
			Value = 140413,
		},
	},
	Reward = {
		{
			Value = 330003,
			Num = 1,
		},
		{
			Value = 2,
			Num = 30,
		},
	},
}
GoalConfig[GoalID.Id1114] =
{
	Id = 1114,
	Name = "支线-跨越障碍",
	GoalType = GoalType.Main,
	ShowFirst = false,
	PreCondition = {
		PreArea = 130105,
		PreGoal = 
		{
			301113,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Explore,
	},
	GoalCondition = 
	{
		{
			Name = "派遣含有[62E7E7]2个[-][62E7E7]风元素[-]队员(或宠物)的队伍探索博物馆星[FDDE40]修复室[-]18小时",
			Type = ItemType.Time,
			CountType = GoalCountType.StartNow,
			Num = 64800,
			TagList = 
			{
				561204,
			},
			CharacterNum = 2,
			Value = 130105,
		},
	},
	Reward = {
		{
			Value = 330002,
			Num = 2,
		},
		{
			Value = 2,
			Num = 30,
		},
	},
}
GoalConfig[GoalID.Id1115] =
{
	Id = 1115,
	Name = "支线-教训碰碰瓷",
	GoalType = GoalType.Main,
	ShowFirst = false,
	PreCondition = {
		PreArea = 130105,
		PreGoal = 
		{
			301114,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Explore,
	},
	GoalCondition = 
	{
		{
			Name = "在探索中击败[FDDE40]碰碰瓷[-]70个，建议探索14小时以上",
			Type = ItemType.Enemy,
			CountType = GoalCountType.StartNow,
			Num = 70,
			Value = 242067,
		},
	},
	Reward = {
		{
			Value = 330002,
			Num = 2,
		},
		{
			Value = 2,
			Num = 30,
		},
	},
}
GoalConfig[GoalID.Id1116] =
{
	Id = 1116,
	Name = "支线-逮捕碰瓷犯",
	GoalType = GoalType.Main,
	ShowFirst = false,
	PreCondition = {
		PreArea = 130105,
		PreGoal = 
		{
			301115,
		},
	},
	GoalTrigger = 
	{
		TriggerType.CollectItem,
	},
	GoalCondition = 
	{
		{
			Name = "累计捕捉宠物[FDDE40]碰碰瓷[-]5个(需要事务所的纸板箱)",
			Type = ItemType.Pet,
			CountType = GoalCountType.Current,
			Num = 5,
			Value = 250067,
		},
	},
	Reward = {
		{
			Value = 330002,
			Num = 2,
		},
		{
			Value = 2,
			Num = 30,
		},
	},
}
GoalConfig[GoalID.Id1117] =
{
	Id = 1117,
	Name = "支线-警戒线队长的挑战",
	GoalType = GoalType.Main,
	ShowFirst = false,
	PreCondition = {
		PreArea = 130105,
		PreGoal = 
		{
			301116,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Challenge,
	},
	GoalCondition = 
	{
		{
			Name = "打败修复室的[FDDE40]警戒线队长[-]",
			Type = ItemType.Challenge,
			CountType = GoalCountType.Current,
			Num = 1,
			Value = 140414,
		},
	},
	Reward = {
		{
			Value = 330003,
			Num = 1,
		},
		{
			Value = 2,
			Num = 30,
		},
	},
}
GoalConfig[GoalID.Id1118] =
{
	Id = 1118,
	Name = "支线-解除封锁",
	GoalType = GoalType.Main,
	ShowFirst = false,
	PreCondition = {
		PreArea = 130105,
		PreGoal = 
		{
			301117,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Explore,
	},
	GoalCondition = 
	{
		{
			Name = "在探索中击败[FDDE40]警戒线[-]25个，建议探索19小时以上",
			Type = ItemType.Enemy,
			CountType = GoalCountType.StartNow,
			Num = 25,
			Value = 242068,
		},
	},
	Reward = {
		{
			Value = 330002,
			Num = 2,
		},
		{
			Value = 2,
			Num = 30,
		},
	},
}
GoalConfig[GoalID.Id1119] =
{
	Id = 1119,
	Name = "支线-艺术之息",
	GoalType = GoalType.Main,
	ShowFirst = false,
	PreCondition = {
		PreArea = 130105,
		PreGoal = 
		{
			301118,
		},
	},
	GoalTrigger = 
	{
		TriggerType.CollectItem,
	},
	GoalCondition = 
	{
		{
			Name = "拥有至少[62E7E7]30级[-][62E7E7]风元素[-][FDDE40]角色[-]5个",
			Type = ItemType.Character,
			CountType = GoalCountType.Current,
			Num = 5,
			Value = -1,
			Level = 30,
			Element = 210003,
		},
	},
	Reward = {
		{
			Value = 330002,
			Num = 2,
		},
		{
			Value = 2,
			Num = 30,
		},
	},
}
GoalConfig[GoalID.Id1120] =
{
	Id = 1120,
	Name = "支线-被困的木乃伊",
	GoalType = GoalType.Main,
	ShowFirst = false,
	PreCondition = {
		PreArea = 130105,
		PreGoal = 
		{
			301119,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Explore,
	},
	GoalCondition = 
	{
		{
			Name = "派遣含有[62E7E7]5个[-][62E7E7]紫色及以上品质[-]队员(或宠物)的队伍探索博物馆星[FDDE40]修复室[-]23小时",
			Type = ItemType.Time,
			CountType = GoalCountType.StartNow,
			Num = 82800,
			TagList = 
			{
				560034,
			},
			CharacterNum = 5,
			Value = 130105,
		},
	},
	Reward = {
		{
			Value = 330002,
			Num = 2,
		},
		{
			Value = 2,
			Num = 30,
		},
	},
}
GoalConfig[GoalID.Id1121] =
{
	Id = 1121,
	Name = "支线-木乃伊的挑战",
	GoalType = GoalType.Main,
	ShowFirst = false,
	PreCondition = {
		PreArea = 130105,
		PreGoal = 
		{
			301120,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Challenge,
	},
	GoalCondition = 
	{
		{
			Name = "打败修复室的[FDDE40]木乃伊[-]",
			Type = ItemType.Challenge,
			CountType = GoalCountType.Current,
			Num = 1,
			Value = 140415,
		},
	},
	Reward = {
		{
			Value = 330003,
			Num = 1,
		},
		{
			Value = 2,
			Num = 30,
		},
	},
}
GoalConfig[GoalID.Id1122] =
{
	Id = 1122,
	Name = "解锁：监控室",
	GoalType = GoalType.Main,
	ShowFirst = false,
	PreCondition = {
		PreArea = 130106,
		PreGoal = 
		{
			300852,
		},
	},
	GoalTrigger = 
	{
		TriggerType.CollectItem,
	},
	GoalCondition = 
	{
		{
			Name = "每次进入这里就昏昏欲睡，带杯开水再去吧~\n拥有至少[62E7E7]5级[-][FDDE40]保温杯[-](保安装备)",
			Type = ItemType.Equipment,
			CountType = GoalCountType.Current,
			Num = 1,
			Value = 340155,
			Level = 5,
		},
	},
	Reward = {
		{
			Value = 130107,
			Num = 1,
		},
		{
			Value = 330002,
			Num = 2,
		},
		{
			Value = 2,
			Num = 30,
		},
	},
}
GoalConfig[GoalID.Id1123] =
{
	Id = 1123,
	Name = "支线-躲避摄像头",
	GoalType = GoalType.Main,
	ShowFirst = false,
	PreCondition = {
		PreArea = 130107,
		PreGoal = 
		{
			301122,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Explore,
	},
	GoalCondition = 
	{
		{
			Name = "派遣含有[62E7E7]1个[-][62E7E7]紫色及以上品质[-]、[62E7E7]暗元素[-]队员(或宠物)的队伍探索博物馆星[FDDE40]监控室[-]23小时",
			Type = ItemType.Time,
			CountType = GoalCountType.StartNow,
			Num = 82800,
			TagList = 
			{
				560034,
				561206,
			},
			CharacterNum = 1,
			Value = 130107,
		},
	},
	Reward = {
		{
			Value = 330002,
			Num = 2,
		},
		{
			Value = 2,
			Num = 30,
		},
	},
}
GoalConfig[GoalID.Id1124] =
{
	Id = 1124,
	Name = "支线-准备工具箱",
	GoalType = GoalType.Main,
	ShowFirst = false,
	PreCondition = {
		PreArea = 130107,
		PreGoal = 
		{
			301123,
		},
	},
	GoalTrigger = 
	{
		TriggerType.CollectItem,
	},
	GoalCondition = 
	{
		{
			Name = "拥有[FDDE40]简易工具箱[-]12个",
			Type = ItemType.Goods,
			CountType = GoalCountType.Current,
			Num = 12,
			Value = 320313,
		},
	},
	Reward = {
		{
			Value = 330002,
			Num = 2,
		},
		{
			Value = 2,
			Num = 30,
		},
	},
}
GoalConfig[GoalID.Id1125] =
{
	Id = 1125,
	Name = "支线-工具箱捕捉",
	GoalType = GoalType.Main,
	ShowFirst = false,
	PreCondition = {
		PreArea = 130107,
		PreGoal = 
		{
			301124,
		},
	},
	GoalTrigger = 
	{
		TriggerType.CollectItem,
	},
	GoalCondition = 
	{
		{
			Name = "累计拥有[62E7E7]工具箱捕捉的[-][FDDE40]宠物[-]3种",
			Type = ItemType.Pet,
			CountType = GoalCountType.Current,
			Num = 3,
			TagList = 
			{
				563105,
			},
			Value = -1,
		},
	},
	Reward = {
		{
			Value = 330002,
			Num = 2,
		},
		{
			Value = 2,
			Num = 30,
		},
	},
}
GoalConfig[GoalID.Id1126] =
{
	Id = 1126,
	Name = "支线-摄像头队长的挑战",
	GoalType = GoalType.Main,
	ShowFirst = false,
	PreCondition = {
		PreArea = 130107,
		PreGoal = 
		{
			301125,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Challenge,
	},
	GoalCondition = 
	{
		{
			Name = "打败监控室的[FDDE40]摄像头队长[-]",
			Type = ItemType.Challenge,
			CountType = GoalCountType.Current,
			Num = 1,
			Value = 140419,
		},
	},
	Reward = {
		{
			Value = 330003,
			Num = 1,
		},
		{
			Value = 2,
			Num = 30,
		},
	},
}
GoalConfig[GoalID.Id1127] =
{
	Id = 1127,
	Name = "支线-白屏",
	GoalType = GoalType.Main,
	ShowFirst = false,
	PreCondition = {
		PreArea = 130107,
		PreGoal = 
		{
			301126,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Explore,
	},
	GoalCondition = 
	{
		{
			Name = "派遣含有[62E7E7]2个[-][62E7E7]紫色及以上品质[-]、[62E7E7]光元素[-]队员(或宠物)的队伍探索博物馆星[FDDE40]监控室[-]23小时",
			Type = ItemType.Time,
			CountType = GoalCountType.StartNow,
			Num = 82800,
			TagList = 
			{
				560034,
				561205,
			},
			CharacterNum = 2,
			Value = 130107,
		},
	},
	Reward = {
		{
			Value = 330002,
			Num = 2,
		},
		{
			Value = 2,
			Num = 30,
		},
	},
}
GoalConfig[GoalID.Id1128] =
{
	Id = 1128,
	Name = "支线-高级工具箱",
	GoalType = GoalType.Main,
	ShowFirst = false,
	PreCondition = {
		PreArea = 130107,
		PreGoal = 
		{
			301127,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Craft,
	},
	GoalCondition = 
	{
		{
			Name = "在实验室合成获得[FDDE40]标准工具箱[-]6个",
			Type = ItemType.Goods,
			CountType = GoalCountType.StartNow,
			Num = 6,
			Value = 320314,
		},
	},
	Reward = {
		{
			Value = 330002,
			Num = 2,
		},
		{
			Value = 2,
			Num = 30,
		},
	},
}
GoalConfig[GoalID.Id1129] =
{
	Id = 1129,
	Name = "支线-设备升级",
	GoalType = GoalType.Main,
	ShowFirst = false,
	PreCondition = {
		PreArea = 130107,
		PreGoal = 
		{
			301128,
		},
	},
	GoalTrigger = 
	{
		TriggerType.CollectItem,
	},
	GoalCondition = 
	{
		{
			Name = "累计捕捉宠物[FDDE40]摄像头[-]5个(需要事务所的工具箱)",
			Type = ItemType.Pet,
			CountType = GoalCountType.Current,
			Num = 5,
			Value = 250072,
		},
	},
	Reward = {
		{
			Value = 330002,
			Num = 2,
		},
		{
			Value = 2,
			Num = 30,
		},
	},
}
GoalConfig[GoalID.Id1130] =
{
	Id = 1130,
	Name = "支线-高清摄像头队长的挑战",
	GoalType = GoalType.Main,
	ShowFirst = false,
	PreCondition = {
		PreArea = 130107,
		PreGoal = 
		{
			301129,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Challenge,
	},
	GoalCondition = 
	{
		{
			Name = "打败监控室的[FDDE40]高清摄像头队长[-]",
			Type = ItemType.Challenge,
			CountType = GoalCountType.Current,
			Num = 1,
			Value = 140420,
		},
	},
	Reward = {
		{
			Value = 330003,
			Num = 1,
		},
		{
			Value = 2,
			Num = 30,
		},
	},
}
GoalConfig[GoalID.Id1131] =
{
	Id = 1131,
	Name = "支线-破坏摄像机1",
	GoalType = GoalType.Main,
	ShowFirst = false,
	PreCondition = {
		PreArea = 130107,
		PreGoal = 
		{
			301130,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Explore,
	},
	GoalCondition = 
	{
		{
			Name = "在探索中击败[FDDE40]摄像头[-]40个，建议探索19小时以上",
			Type = ItemType.Enemy,
			CountType = GoalCountType.StartNow,
			Num = 40,
			Value = 242072,
		},
	},
	Reward = {
		{
			Value = 330002,
			Num = 2,
		},
		{
			Value = 2,
			Num = 30,
		},
	},
}
GoalConfig[GoalID.Id1132] =
{
	Id = 1132,
	Name = "支线-推理比赛",
	GoalType = GoalType.Main,
	ShowFirst = false,
	PreCondition = {
		PreArea = 130107,
		PreGoal = 
		{
			301131,
		},
	},
	GoalTrigger = 
	{
		TriggerType.CollectItem,
	},
	GoalCondition = 
	{
		{
			Name = "拥有至少[62E7E7]30级[-][62E7E7]光元素[-][FDDE40]角色[-]3个",
			Type = ItemType.Character,
			CountType = GoalCountType.Current,
			Num = 3,
			Value = -1,
			Level = 30,
			Element = 210004,
		},
	},
	Reward = {
		{
			Value = 330002,
			Num = 2,
		},
		{
			Value = 2,
			Num = 30,
		},
	},
}
GoalConfig[GoalID.Id1133] =
{
	Id = 1133,
	Name = "支线-破坏摄像机2",
	GoalType = GoalType.Main,
	ShowFirst = false,
	PreCondition = {
		PreArea = 130107,
		PreGoal = 
		{
			301132,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Explore,
	},
	GoalCondition = 
	{
		{
			Name = "在探索中击败[FDDE40]高清摄像头[-]10个，建议探索23小时以上",
			Type = ItemType.Enemy,
			CountType = GoalCountType.StartNow,
			Num = 10,
			Value = 242073,
		},
	},
	Reward = {
		{
			Value = 330002,
			Num = 2,
		},
		{
			Value = 2,
			Num = 30,
		},
	},
}
GoalConfig[GoalID.Id1134] =
{
	Id = 1134,
	Name = "支线-侦探小姐的挑战",
	GoalType = GoalType.Main,
	ShowFirst = false,
	PreCondition = {
		PreArea = 130107,
		PreGoal = 
		{
			301133,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Challenge,
	},
	GoalCondition = 
	{
		{
			Name = "打败监控室的[FDDE40]侦探小姐[-]",
			Type = ItemType.Challenge,
			CountType = GoalCountType.Current,
			Num = 1,
			Value = 140421,
		},
	},
	Reward = {
		{
			Value = 330003,
			Num = 1,
		},
		{
			Value = 2,
			Num = 30,
		},
	},
}
GoalConfig[GoalID.Id1135] =
{
	Id = 1135,
	Name = "支线-别逃鸭！！",
	GoalType = GoalType.Main,
	ShowFirst = false,
	PreCondition = {
		PreArea = 130112,
		PreGoal = 
		{
			300807,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Explore,
	},
	GoalCondition = 
	{
		{
			Name = "派遣含有[62E7E7]3个[-][62E7E7]风元素[-]队员(或宠物)的队伍探索博物馆星[FDDE40]出口[-]23小时",
			Type = ItemType.Time,
			CountType = GoalCountType.StartNow,
			Num = 82800,
			TagList = 
			{
				561204,
			},
			CharacterNum = 3,
			Value = 130112,
		},
	},
	Reward = {
		{
			Value = 330002,
			Num = 2,
		},
		{
			Value = 2,
			Num = 30,
		},
	},
}
GoalConfig[GoalID.Id1136] =
{
	Id = 1136,
	Name = "支线-收集箭头",
	GoalType = GoalType.Main,
	ShowFirst = false,
	PreCondition = {
		PreArea = 130112,
		PreGoal = 
		{
			301135,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Explore,
	},
	GoalCondition = 
	{
		{
			Name = "在探索中获得[FDDE40]箭头[-]40个",
			Type = ItemType.Goods,
			CountType = GoalCountType.StartNow,
			Num = 40,
			Value = 321411,
		},
	},
	Reward = {
		{
			Value = 330002,
			Num = 2,
		},
		{
			Value = 2,
			Num = 30,
		},
	},
}
GoalConfig[GoalID.Id1137] =
{
	Id = 1137,
	Name = "支线-收集入场券",
	GoalType = GoalType.Main,
	ShowFirst = false,
	PreCondition = {
		PreArea = 130112,
		PreGoal = 
		{
			301136,
		},
	},
	GoalTrigger = 
	{
		TriggerType.SubmitGoods,
	},
	GoalCondition = 
	{
		{
			Name = "提交[FDDE40]入场券[-]50个",
			Type = ItemType.Goods,
			CountType = GoalCountType.Current,
			Num = 50,
			Value = 321401,
		},
	},
	Reward = {
		{
			Value = 330002,
			Num = 2,
		},
		{
			Value = 2,
			Num = 30,
		},
	},
}
GoalConfig[GoalID.Id1138] =
{
	Id = 1138,
	Name = "支线-快陶鸭！的挑战",
	GoalType = GoalType.Main,
	ShowFirst = false,
	PreCondition = {
		PreArea = 130112,
		PreGoal = 
		{
			301137,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Challenge,
	},
	GoalCondition = 
	{
		{
			Name = "打败出口的[FDDE40]快陶鸭！[-]",
			Type = ItemType.Challenge,
			CountType = GoalCountType.Current,
			Num = 1,
			Value = 140435,
		},
	},
	Reward = {
		{
			Value = 330003,
			Num = 1,
		},
		{
			Value = 2,
			Num = 30,
		},
	},
}
GoalConfig[GoalID.Id1139] =
{
	Id = 1139,
	Name = "支线-博物馆导览图",
	GoalType = GoalType.Main,
	ShowFirst = false,
	PreCondition = {
		PreArea = 130112,
		PreGoal = 
		{
			301138,
		},
	},
	GoalTrigger = 
	{
		TriggerType.SubmitGoods,
	},
	GoalCondition = 
	{
		{
			Name = "提交[FDDE40]导览图[-]10个",
			Type = ItemType.Goods,
			CountType = GoalCountType.Current,
			Num = 10,
			Value = 321454,
		},
	},
	Reward = {
		{
			Value = 330002,
			Num = 2,
		},
		{
			Value = 2,
			Num = 30,
		},
	},
}
GoalConfig[GoalID.Id1140] =
{
	Id = 1140,
	Name = "支线-自画像1",
	GoalType = GoalType.Main,
	ShowFirst = false,
	PreCondition = {
		PreArea = 130112,
		PreGoal = 
		{
			301139,
		},
	},
	GoalTrigger = 
	{
		TriggerType.CollectItem,
	},
	GoalCondition = 
	{
		{
			Name = "拥有至少[62E7E7]40级[-][62E7E7]蓝色及以上品质[-]、[62E7E7]博物馆星[-][FDDE40]角色[-]5个",
			Type = ItemType.Character,
			CountType = GoalCountType.Current,
			Num = 5,
			TagList = 
			{
				560033,
				560105,
			},
			Value = -1,
			Level = 40,
		},
	},
	Reward = {
		{
			Value = 330002,
			Num = 2,
		},
		{
			Value = 2,
			Num = 30,
		},
	},
}
GoalConfig[GoalID.Id1141] =
{
	Id = 1141,
	Name = "支线-自画像2",
	GoalType = GoalType.Main,
	ShowFirst = false,
	PreCondition = {
		PreArea = 130112,
		PreGoal = 
		{
			301140,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Explore,
	},
	GoalCondition = 
	{
		{
			Name = "派遣含有[62E7E7]5个[-][62E7E7]博物馆星[-]队员(或宠物)的队伍探索博物馆星[FDDE40]出口[-]23小时",
			Type = ItemType.Time,
			CountType = GoalCountType.StartNow,
			Num = 82800,
			TagList = 
			{
				560105,
			},
			CharacterNum = 5,
			Value = 130112,
		},
	},
	Reward = {
		{
			Value = 330002,
			Num = 2,
		},
		{
			Value = 2,
			Num = 30,
		},
	},
}
GoalConfig[GoalID.Id1142] =
{
	Id = 1142,
	Name = "支线-独耳画像的挑战",
	GoalType = GoalType.Main,
	ShowFirst = false,
	PreCondition = {
		PreArea = 130112,
		PreGoal = 
		{
			301141,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Challenge,
	},
	GoalCondition = 
	{
		{
			Name = "打败出口的[FDDE40]独耳画像[-]",
			Type = ItemType.Challenge,
			CountType = GoalCountType.Current,
			Num = 1,
			Value = 140436,
		},
	},
	Reward = {
		{
			Value = 330003,
			Num = 1,
		},
		{
			Value = 2,
			Num = 30,
		},
	},
}
GoalConfig[GoalID.Id1143] =
{
	Id = 1143,
	Name = "新配方：黄蛋壳",
	GoalType = GoalType.Main,
	ShowFirst = false,
	PreCondition = {
		PreArea = 130106,
		PreGoal = 
		{
			300844,
		},
	},
	GoalTrigger = 
	{
		TriggerType.SubmitGoods,
	},
	GoalCondition = 
	{
		{
			Name = "处理文物时请务必小心。\n提交[FDDE40]绿蛋壳[-]20个",
			Type = ItemType.Goods,
			CountType = GoalCountType.Current,
			Num = 20,
			Value = 321405,
		},
	},
	Reward = {
		{
			Value = 360301,
			Num = 1,
		},
		{
			Value = 330002,
			Num = 2,
		},
		{
			Value = 2,
			Num = 30,
		},
	},
}
GoalConfig[GoalID.Id1144] =
{
	Id = 1144,
	Name = "新配方：黄面具",
	GoalType = GoalType.Main,
	ShowFirst = false,
	PreCondition = {
		PreArea = 130110,
		PreGoal = 
		{
			300884,
		},
	},
	GoalTrigger = 
	{
		TriggerType.SubmitGoods,
	},
	GoalCondition = 
	{
		{
			Name = "传说是附有法力的素材呢。\n提交[FDDE40]青面具[-]20个",
			Type = ItemType.Goods,
			CountType = GoalCountType.Current,
			Num = 20,
			Value = 321409,
		},
	},
	Reward = {
		{
			Value = 360302,
			Num = 1,
		},
		{
			Value = 330002,
			Num = 2,
		},
		{
			Value = 2,
			Num = 30,
		},
	},
}
GoalConfig[GoalID.Id1145] =
{
	Id = 1145,
	Name = "新配方：化石骨",
	GoalType = GoalType.Main,
	ShowFirst = false,
	PreCondition = {
		PreArea = 130111,
		PreGoal = 
		{
			300892,
		},
	},
	GoalTrigger = 
	{
		TriggerType.SubmitGoods,
	},
	GoalCondition = 
	{
		{
			Name = "来猜猜看这会是哪个部位呢？\n提交[FDDE40]龙角[-]20个",
			Type = ItemType.Goods,
			CountType = GoalCountType.Current,
			Num = 20,
			Value = 321410,
		},
	},
	Reward = {
		{
			Value = 360303,
			Num = 1,
		},
		{
			Value = 330002,
			Num = 2,
		},
		{
			Value = 2,
			Num = 30,
		},
	},
}
GoalConfig[GoalID.Id1146] =
{
	Id = 1146,
	Name = "新配方：导览图",
	GoalType = GoalType.Main,
	ShowFirst = false,
	PreCondition = {
		PreArea = 130112,
		PreGoal = 
		{
			300904,
		},
	},
	GoalTrigger = 
	{
		TriggerType.SubmitGoods,
	},
	GoalCondition = 
	{
		{
			Name = "如果迷路的时候，可以根据导览图查询位置。\n提交[FDDE40]箭头[-]20个",
			Type = ItemType.Goods,
			CountType = GoalCountType.Current,
			Num = 20,
			Value = 321411,
		},
	},
	Reward = {
		{
			Value = 360304,
			Num = 1,
		},
		{
			Value = 330002,
			Num = 2,
		},
		{
			Value = 2,
			Num = 30,
		},
	},
}
GoalConfig[GoalID.Id1147] =
{
	Id = 1147,
	Name = "地图打卡：安检大门",
	GoalType = GoalType.Main,
	ShowFirst = false,
	PreCondition = {
		PreArea = 130102,
		PreGoal = 
		{
			300814,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Explore,
	},
	GoalCondition = 
	{
		{
			Name = "据说每天都有游客想带着武器通过大门…\n探索[62E7E7]入口大厅[-]击败[FDDE40]红外线探测[-]80个，建议探索16小时以上",
			Type = ItemType.Enemy,
			CountType = GoalCountType.StartNow,
			Num = 80,
			Value = 242059,
			Area = 130102,
		},
	},
	Reward = {
		{
			Value = 320043,
			Num = 20,
		},
		{
			Value = 320053,
			Num = 20,
		},
		{
			Value = 1,
			Num = 34300,
		},
	},
}
GoalConfig[GoalID.Id1148] =
{
	Id = 1148,
	Name = "地图打卡：导航看板",
	GoalType = GoalType.Main,
	ShowFirst = false,
	PreCondition = {
		PreArea = 130103,
		PreGoal = 
		{
			300827,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Explore,
	},
	GoalCondition = 
	{
		{
			Name = "迷宫般的博物馆，要找到导航板也需要先问路。\n[62E7E7]一次性[-]探索[62E7E7]中心广场[-]击败[FDDE40]陶面人[-]25个，建议探索19小时以上",
			Type = ItemType.Enemy,
			CountType = GoalCountType.OneShot,
			Num = 25,
			Value = 242061,
			Area = 130103,
		},
	},
	Reward = {
		{
			Value = 320043,
			Num = 30,
		},
		{
			Value = 320053,
			Num = 30,
		},
		{
			Value = 1,
			Num = 41000,
		},
	},
}
GoalConfig[GoalID.Id1149] =
{
	Id = 1149,
	Name = "地图打卡：青铜大钟",
	GoalType = GoalType.Main,
	ShowFirst = false,
	PreCondition = {
		PreArea = 130104,
		PreGoal = 
		{
			300840,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Explore,
	},
	GoalCondition = 
	{
		{
			Name = "叮叮~镗镗~咚咚~铛铛~咣咣~\n[62E7E7]一次性[-]探索[62E7E7]文物厅[-]击败[FDDE40]编钟[-]60个，建议探索22小时以上",
			Type = ItemType.Enemy,
			CountType = GoalCountType.OneShot,
			Num = 60,
			Value = 242062,
			Area = 130104,
		},
	},
	Reward = {
		{
			Value = 320043,
			Num = 40,
		},
		{
			Value = 320053,
			Num = 40,
		},
		{
			Value = 1,
			Num = 42500,
		},
	},
}
GoalConfig[GoalID.Id1150] =
{
	Id = 1150,
	Name = "地图打卡：修理工作台",
	GoalType = GoalType.Main,
	ShowFirst = false,
	PreCondition = {
		PreArea = 130105,
		PreGoal = 
		{
			301121,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Explore,
	},
	GoalCondition = 
	{
		{
			Name = "警告：碰碰瓷出没，为避免损失，请小心诈骗~\n[62E7E7]一次性[-]探索[62E7E7]修复室[-]击败[FDDE40]碰碰瓷[-]70个，建议探索21小时以上",
			Type = ItemType.Enemy,
			CountType = GoalCountType.OneShot,
			Num = 70,
			Value = 242067,
			Area = 130105,
		},
	},
	Reward = {
		{
			Value = 320043,
			Num = 50,
		},
		{
			Value = 320053,
			Num = 50,
		},
		{
			Value = 1,
			Num = 59400,
		},
	},
}
GoalConfig[GoalID.Id1151] =
{
	Id = 1151,
	Name = "地图打卡：孵化池",
	GoalType = GoalType.Main,
	ShowFirst = false,
	PreCondition = {
		PreArea = 130106,
		PreGoal = 
		{
			300852,
		},
	},
	GoalTrigger = 
	{
		TriggerType.CollectItem,
	},
	GoalCondition = 
	{
		{
			Name = "哇，好像有小恐龙快要孵化出来了~~\n累计拥有[62E7E7]紫色及以上品质[-]、[62E7E7]火元素[-][FDDE40]宠物[-]3种",
			Type = ItemType.Pet,
			CountType = GoalCountType.Current,
			Num = 3,
			TagList = 
			{
				560034,
				561203,
			},
			Value = -1,
		},
	},
	Reward = {
		{
			Value = 320043,
			Num = 60,
		},
		{
			Value = 320053,
			Num = 60,
		},
		{
			Value = 1,
			Num = 51800,
		},
	},
}
GoalConfig[GoalID.Id1152] =
{
	Id = 1152,
	Name = "地图打卡：监控机组",
	GoalType = GoalType.Main,
	ShowFirst = false,
	PreCondition = {
		PreArea = 130107,
		PreGoal = 
		{
			301134,
		},
	},
	GoalTrigger = 
	{
		TriggerType.CollectItem,
	},
	GoalCondition = 
	{
		{
			Name = "因经费紧张，摄像头每天只开3小时-_-||\n累计捕捉宠物[FDDE40]高清摄像头[-]3个(需要事务所的工具箱)",
			Type = ItemType.Pet,
			CountType = GoalCountType.Current,
			Num = 3,
			Value = 250073,
		},
	},
	Reward = {
		{
			Value = 320043,
			Num = 70,
		},
		{
			Value = 320053,
			Num = 70,
		},
		{
			Value = 1,
			Num = 83600,
		},
	},
}
GoalConfig[GoalID.Id1153] =
{
	Id = 1153,
	Name = "地图打卡：文物展柜",
	GoalType = GoalType.Main,
	ShowFirst = false,
	PreCondition = {
		PreArea = 130108,
		PreGoal = 
		{
			300868,
		},
	},
	GoalTrigger = 
	{
		TriggerType.CollectItem,
	},
	GoalCondition = 
	{
		{
			Name = "文物出逃，请各位游客自带展品。\n累计拥有[62E7E7]博物馆星[-]、[62E7E7]工具箱捕捉的[-][FDDE40]宠物[-]3种",
			Type = ItemType.Pet,
			CountType = GoalCountType.Current,
			Num = 3,
			TagList = 
			{
				560105,
				563105,
			},
			Value = -1,
		},
	},
	Reward = {
		{
			Value = 320043,
			Num = 80,
		},
		{
			Value = 320053,
			Num = 80,
		},
		{
			Value = 1,
			Num = 68100,
		},
	},
}
GoalConfig[GoalID.Id1154] =
{
	Id = 1154,
	Name = "地图打卡：化石展柜",
	GoalType = GoalType.Main,
	ShowFirst = false,
	PreCondition = {
		PreArea = 130109,
		PreGoal = 
		{
			300880,
		},
	},
	GoalTrigger = 
	{
		TriggerType.CollectItem,
	},
	GoalCondition = 
	{
		{
			Name = "请欣赏大型自然表演，化石走光了~\n累计拥有[62E7E7]紫色及以上品质[-]、[62E7E7]非博物馆星[-][FDDE40]宠物[-]10种",
			Type = ItemType.Pet,
			CountType = GoalCountType.Current,
			Num = 10,
			TagList = 
			{
				560034,
				560205,
			},
			Value = -1,
		},
	},
	Reward = {
		{
			Value = 320043,
			Num = 90,
		},
		{
			Value = 320053,
			Num = 90,
		},
		{
			Value = 1,
			Num = 53600,
		},
	},
}
GoalConfig[GoalID.Id1155] =
{
	Id = 1155,
	Name = "地图打卡：祭祀台",
	GoalType = GoalType.Main,
	ShowFirst = false,
	PreCondition = {
		PreArea = 130110,
		PreGoal = 
		{
			300888,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Explore,
	},
	GoalCondition = 
	{
		{
			Name = "这世间真的存在我们所无法理解的存在吗？\n[62E7E7]一次性[-]探索[62E7E7]泥塑厅[-]击败[FDDE40]赤鱬[-]70个，建议探索23小时以上",
			Type = ItemType.Enemy,
			CountType = GoalCountType.OneShot,
			Num = 70,
			Value = 242079,
			Area = 130110,
		},
	},
	Reward = {
		{
			Value = 320043,
			Num = 100,
		},
		{
			Value = 320053,
			Num = 100,
		},
		{
			Value = 1,
			Num = 54000,
		},
	},
}
GoalConfig[GoalID.Id1156] =
{
	Id = 1156,
	Name = "地图打卡：恐龙骨架",
	GoalType = GoalType.Main,
	ShowFirst = false,
	PreCondition = {
		PreArea = 130111,
		PreGoal = 
		{
			300900,
		},
	},
	GoalTrigger = 
	{
		TriggerType.CollectItem,
	},
	GoalCondition = 
	{
		{
			Name = "漆漆快看！大恐龙！\n累计拥有[62E7E7]恐龙类的[-][FDDE40]宠物[-]5种",
			Type = ItemType.Pet,
			CountType = GoalCountType.Current,
			Num = 5,
			TagList = 
			{
				561338,
			},
			Value = -1,
		},
	},
	Reward = {
		{
			Value = 320043,
			Num = 110,
		},
		{
			Value = 320053,
			Num = 110,
		},
		{
			Value = 1,
			Num = 65100,
		},
	},
}
GoalConfig[GoalID.Id1157] =
{
	Id = 1157,
	Name = "地图打卡：出口通道",
	GoalType = GoalType.Main,
	ShowFirst = false,
	PreCondition = {
		PreArea = 130112,
		PreGoal = 
		{
			301142,
		},
	},
	GoalTrigger = 
	{
		TriggerType.CollectItem,
	},
	GoalCondition = 
	{
		{
			Name = "感谢参观，为资源复用，请交还您的导览图。\n累计捕捉宠物[FDDE40]安全出口[-]50个(需要事务所的工具箱)",
			Type = ItemType.Pet,
			CountType = GoalCountType.Current,
			Num = 50,
			Value = 250082,
		},
	},
	Reward = {
		{
			Value = 320613,
			Num = 1,
		},
		{
			Value = 330003,
			Num = 10,
		},
		{
			Value = 1,
			Num = 95500,
		},
	},
}
GoalConfig[GoalID.Id1158] =
{
	Id = 1158,
	Name = "支线-博物馆迷踪1",
	GoalType = GoalType.Main,
	ShowFirst = false,
	PreCondition = {
		PreArea = 130106,
		PreGoal = 
		{
			301126,
			300758,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Explore,
	},
	GoalCondition = 
	{
		{
			Name = "请务必让保安队长去调查一下！\n穿着[62E7E7]保安队长[-](保安皮肤)探索[FDDE40]博物馆星[-]24小时",
			Type = ItemType.Time,
			CountType = GoalCountType.StartNow,
			Num = 86400,
			Skin = 
			{
				232084,
			},
			Value = 120003,
		},
	},
	CompleteSpeech = 30115801,
	Reward = {
		{
			Value = 320104,
			Num = 1,
		},
		{
			Value = 2,
			Num = 30,
		},
	},
}
GoalConfig[GoalID.Id1159] =
{
	Id = 1159,
	Name = "支线-博物馆迷踪2",
	GoalType = GoalType.Main,
	ShowFirst = false,
	PreCondition = {
		PreArea = 130106,
		PreGoal = 
		{
			301158,
		},
	},
	GoalTrigger = 
	{
		TriggerType.SubmitGoods,
	},
	GoalCondition = 
	{
		{
			Name = "提交[FDDE40]监控录像[-]100个",
			Type = ItemType.Goods,
			CountType = GoalCountType.Current,
			Num = 100,
			Value = 321406,
		},
	},
	CompleteSpeech = 30115901,
	Reward = {
		{
			Value = 1,
			Num = 150000,
		},
		{
			Value = 2,
			Num = 30,
		},
	},
}
GoalConfig[GoalID.Id1160] =
{
	Id = 1160,
	Name = "支线-博物馆迷踪3",
	GoalType = GoalType.Main,
	ShowFirst = false,
	PreCondition = {
		PreArea = 130106,
		PreGoal = 
		{
			301159,
			300900,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Explore,
	},
	GoalCondition = 
	{
		{
			Name = "相信动物们凭借嗅觉，就能找到对方的！\n派遣[62E7E7]浣熊大哥[-]、[62E7E7]浣熊二哥[-]、[62E7E7]浣熊小弟[-]探索[FDDE40]博物馆星[-]36小时",
			Type = ItemType.Time,
			CountType = GoalCountType.StartNow,
			Num = 129600,
			Character = 
			{
				220203,
				220204,
				220205,
			},
			Value = 120003,
		},
	},
	CompleteSpeech = 30116001,
	Reward = {
		{
			Value = 330003,
			Num = 2,
		},
		{
			Value = 2,
			Num = 30,
		},
	},
}
GoalConfig[GoalID.Id1161] =
{
	Id = 1161,
	Name = "支线-紧急！飙车王来袭！",
	GoalType = GoalType.Main,
	ShowFirst = false,
	PreCondition = {
		PreArea = 130106,
		PreGoal = 
		{
			301160,
		},
	},
	GoalTrigger = 
	{
		TriggerType.ActivityChallenge,
	},
	GoalCondition = 
	{
		{
			Name = "打败[FDDE40]飙车王[-]",
			Type = ItemType.Challenge,
			CountType = GoalCountType.Current,
			Num = 1,
			Value = 147006,
		},
	},
	CompleteSpeech = 30116101,
	Reward = {
		{
			Value = 320201,
			Num = 500,
		},
		{
			Value = 330003,
			Num = 5,
		},
	},
}
GoalConfig[GoalID.Id1162] =
{
	Id = 1162,
	Name = "支线-收藏家的考验7",
	GoalType = GoalType.Main,
	ShowFirst = false,
	PreCondition = {
		PreArea = 130106,
		PreGoal = 
		{
			301161,
			300758,
		},
	},
	GoalTrigger = 
	{
		TriggerType.CollectItem,
	},
	GoalCondition = 
	{
		{
			Name = "家里遭到了盗贼，请求帮助！\n累计捕捉宠物[FDDE40]摄像头[-]75个",
			Type = ItemType.Pet,
			CountType = GoalCountType.Current,
			Num = 75,
			Value = 250072,
		},
	},
	CompleteSpeech = 30116201,
	Reward = {
		{
			Value = 330003,
			Num = 2,
		},
		{
			Value = 2,
			Num = 30,
		},
	},
}
GoalConfig[GoalID.Id1163] =
{
	Id = 1163,
	Name = "支线-另一个呜呜？",
	GoalType = GoalType.Main,
	ShowFirst = false,
	PreCondition = {
		PreArea = 130106,
		PreGoal = 
		{
			301162,
		},
	},
	GoalTrigger = 
	{
		TriggerType.ActivityChallenge,
	},
	GoalCondition = 
	{
		{
			Name = "只要埋伏在现场，就能逮到犯人了喵~\n打败[FDDE40]另一个呜呜[-]",
			Type = ItemType.Challenge,
			CountType = GoalCountType.Current,
			Num = 1,
			Value = 147008,
		},
	},
	CompleteSpeech = 30116301,
	Reward = {
		{
			Value = 330003,
			Num = 2,
		},
		{
			Value = 2,
			Num = 30,
		},
	},
}
GoalConfig[GoalID.Id1164] =
{
	Id = 1164,
	Name = "支线-收藏家的考验8",
	GoalType = GoalType.Main,
	ShowFirst = false,
	PreCondition = {
		PreArea = 130106,
		PreGoal = 
		{
			301163,
		},
	},
	GoalTrigger = 
	{
		TriggerType.CollectItem,
	},
	GoalCondition = 
	{
		{
			Name = "无论如何，还是想再用高清摄像头试一次！\n累计捕捉宠物[FDDE40]高清摄像头[-]20个",
			Type = ItemType.Pet,
			CountType = GoalCountType.Current,
			Num = 20,
			Value = 250073,
		},
	},
	CompleteSpeech = 30116401,
	Reward = {
		{
			Value = 330003,
			Num = 2,
		},
		{
			Value = 2,
			Num = 30,
		},
	},
}
GoalConfig[GoalID.Id1165] =
{
	Id = 1165,
	Name = "支线-另一个漆漆？",
	GoalType = GoalType.Main,
	ShowFirst = false,
	PreCondition = {
		PreArea = 130106,
		PreGoal = 
		{
			301164,
		},
	},
	GoalTrigger = 
	{
		TriggerType.ActivityChallenge,
	},
	GoalCondition = 
	{
		{
			Name = "犯人这次还会出现喵？\n打败[FDDE40]另一个漆漆[-]",
			Type = ItemType.Challenge,
			CountType = GoalCountType.Current,
			Num = 1,
			Value = 147009,
		},
	},
	CompleteSpeech = 30116501,
	Reward = {
		{
			Value = 330003,
			Num = 2,
		},
		{
			Value = 2,
			Num = 30,
		},
	},
}
GoalConfig[GoalID.Id1166] =
{
	Id = 1166,
	Name = "支线-收藏家的考验9",
	GoalType = GoalType.Main,
	ShowFirst = false,
	PreCondition = {
		PreArea = 130106,
		PreGoal = 
		{
			301165,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Explore,
	},
	GoalCondition = 
	{
		{
			Name = "请务必抓到那个偷走我藏品的人！\n派遣[62E7E7]呜呜[-]、[62E7E7]漆漆[-]探索[FDDE40]博物馆星[-]36小时",
			Type = ItemType.Time,
			CountType = GoalCountType.StartNow,
			Num = 129600,
			Character = 
			{
				220001,
				220002,
			},
			Value = 120003,
		},
	},
	CompleteSpeech = 30116601,
	Reward = {
		{
			Value = 330003,
			Num = 2,
		},
		{
			Value = 2,
			Num = 30,
		},
	},
}
GoalConfig[GoalID.Id1167] =
{
	Id = 1167,
	Name = "支线-另一个爷爷？",
	GoalType = GoalType.Main,
	ShowFirst = false,
	PreCondition = {
		PreArea = 130106,
		PreGoal = 
		{
			301166,
		},
	},
	GoalTrigger = 
	{
		TriggerType.ActivityChallenge,
	},
	GoalCondition = 
	{
		{
			Name = "打败[FDDE40]另一个收藏家[-]",
			Type = ItemType.Challenge,
			CountType = GoalCountType.Current,
			Num = 1,
			Value = 147010,
		},
	},
	CompleteSpeech = 30116701,
	Reward = {
		{
			Value = 330003,
			Num = 2,
		},
		{
			Value = 2,
			Num = 30,
		},
	},
}
GoalConfig[GoalID.Id1168] =
{
	Id = 1168,
	Name = "支线-小心！狡猾的怪人！",
	GoalType = GoalType.Main,
	ShowFirst = false,
	PreCondition = {
		PreArea = 130106,
		PreGoal = 
		{
			301167,
		},
	},
	GoalTrigger = 
	{
		TriggerType.ActivityChallenge,
	},
	GoalCondition = 
	{
		{
			Name = "即将与会变形的坏人展开最后较量！\n打败[FDDE40]百变怪客[-]",
			Type = ItemType.Challenge,
			CountType = GoalCountType.Current,
			Num = 1,
			Value = 147011,
		},
	},
	CompleteSpeech = 30116801,
	Reward = {
		{
			Value = 320201,
			Num = 500,
		},
		{
			Value = 330003,
			Num = 5,
		},
	},
}
GoalConfig[GoalID.Id1169] =
{
	Id = 1169,
	Name = "支线-奇怪的支票",
	GoalType = GoalType.Main,
	ShowFirst = false,
	PreCondition = {
		PreArea = 130112,
		PreGoal = 
		{
			301168,
		},
	},
	GoalTrigger = 
	{
		TriggerType.CollectItem,
	},
	GoalCondition = 
	{
		{
			Name = "完成某个中心广场的事件就能获得喵~\n拥有[FDDE40]支票收据[-]1个（需在未使用状态下）",
			Type = ItemType.Goods,
			CountType = GoalCountType.Current,
			Num = 1,
			Value = 320529,
		},
	},
	CompleteSpeech = 30116901,
	Reward = {
		{
			Value = 330003,
			Num = 2,
		},
		{
			Value = 2,
			Num = 30,
		},
	},
}
GoalConfig[GoalID.Id1170] =
{
	Id = 1170,
	Name = "支线-最完美的藏品1",
	GoalType = GoalType.Main,
	ShowFirst = false,
	PreCondition = {
		PreArea = 130112,
		PreGoal = 
		{
			301169,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Explore,
	},
	GoalCondition = 
	{
		{
			Name = "为了心爱的人，无论走多久都愿意吧？\n派遣[62E7E7]微笑女神[-]、[62E7E7]魔术师[-]探索[FDDE40]博物馆星[-]48小时",
			Type = ItemType.Time,
			CountType = GoalCountType.StartNow,
			Num = 172800,
			Character = 
			{
				220226,
				220227,
			},
			Value = 120003,
		},
	},
	CompleteSpeech = 30117001,
	Reward = {
		{
			Value = 330003,
			Num = 2,
		},
		{
			Value = 2,
			Num = 30,
		},
	},
}
GoalConfig[GoalID.Id1171] =
{
	Id = 1171,
	Name = "支线-最完美的藏品2",
	GoalType = GoalType.Main,
	ShowFirst = false,
	PreCondition = {
		PreArea = 130112,
		PreGoal = 
		{
			301170,
		},
	},
	GoalTrigger = 
	{
		TriggerType.CollectItem,
	},
	GoalCondition = 
	{
		{
			Name = "要打动那位少女的话，就必须是这位了！\n拥有至少[62E7E7]50级[-][FDDE40]魔术师[-]",
			Type = ItemType.Character,
			CountType = GoalCountType.Current,
			Num = 1,
			Value = 220227,
			Level = 50,
		},
	},
	CompleteSpeech = 30117101,
	Reward = {
		{
			Value = 330003,
			Num = 2,
		},
		{
			Value = 2,
			Num = 30,
		},
	},
}
GoalConfig[GoalID.Id1172] =
{
	Id = 1172,
	Name = "支线-最完美的藏品3",
	GoalType = GoalType.Main,
	ShowFirst = false,
	PreCondition = {
		PreArea = 130112,
		PreGoal = 
		{
			301171,
		},
	},
	GoalTrigger = 
	{
		TriggerType.CollectItem,
	},
	GoalCondition = 
	{
		{
			Name = "哇，只是微微一笑，世界仿佛灿烂起来了！\n拥有至少[62E7E7]50级[-][FDDE40]微笑女神[-]",
			Type = ItemType.Character,
			CountType = GoalCountType.Current,
			Num = 1,
			Value = 220226,
			Level = 50,
		},
	},
	CompleteSpeech = 30117201,
	Reward = {
		{
			Value = 330003,
			Num = 2,
		},
		{
			Value = 2,
			Num = 30,
		},
	},
}
GoalConfig[GoalID.Id1173] =
{
	Id = 1173,
	Name = "支线-最完美的藏品4",
	GoalType = GoalType.Main,
	ShowFirst = false,
	PreCondition = {
		PreArea = 130112,
		PreGoal = 
		{
			301172,
		},
	},
	GoalTrigger = 
	{
		TriggerType.CollectItem,
	},
	GoalCondition = 
	{
		{
			Name = "完成某个监控室的事件就能获得喵~\n拥有[FDDE40]手电筒[-]1个（需在未使用状态下）\n拥有[FDDE40]手电筒[-]1个",
			Type = ItemType.Goods,
			CountType = GoalCountType.Current,
			Num = 1,
			Value = 320524,
		},
	},
	CompleteSpeech = 30117301,
	Reward = {
		{
			Value = 330003,
			Num = 2,
		},
		{
			Value = 2,
			Num = 30,
		},
	},
}
GoalConfig[GoalID.Id1174] =
{
	Id = 1174,
	Name = "支线-紧急！降临的贵族！",
	GoalType = GoalType.Main,
	ShowFirst = false,
	PreCondition = {
		PreArea = 130112,
		PreGoal = 
		{
			301173,
		},
	},
	GoalTrigger = 
	{
		TriggerType.ActivityChallenge,
	},
	GoalCondition = 
	{
		{
			Name = "对方似乎很害怕光的样子，赶紧打败他！\n打败[FDDE40]“伯爵”[-]",
			Type = ItemType.Challenge,
			CountType = GoalCountType.Current,
			Num = 1,
			Value = 147013,
		},
	},
	CompleteSpeech = 30117401,
	Reward = {
		{
			Value = 320201,
			Num = 500,
		},
		{
			Value = 330003,
			Num = 5,
		},
	},
}
