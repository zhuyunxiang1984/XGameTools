RoomPieceConfig ={};
RoomPieceID = 
{
	Id001 = 440001,
	Id002 = 440002,
	Id003 = 440003,
	Id004 = 440004,
	Id005 = 440005,
	Id006 = 440006,
	Id007 = 440007,
	Id008 = 440008,
	Id009 = 440009,
	Id010 = 440010,
	Id011 = 440011,
	Id021 = 440021,
	Id022 = 440022,
	Id023 = 440023,
	Id024 = 440024,
	Id025 = 440025,
	Id026 = 440026,
	Id027 = 440027,
	Id028 = 440028,
	Id029 = 440029,
	Id030 = 440030,
	Id031 = 440031,
	Id041 = 440041,
	Id042 = 440042,
	Id043 = 440043,
	Id044 = 440044,
	Id045 = 440045,
	Id046 = 440046,
	Id047 = 440047,
	Id048 = 440048,
	Id049 = 440049,
	Id050 = 440050,
	Id051 = 440051,
	Id061 = 440061,
	Id062 = 440062,
	Id063 = 440063,
	Id064 = 440064,
	Id065 = 440065,
	Id066 = 440066,
	Id067 = 440067,
	Id068 = 440068,
	Id069 = 440069,
	Id070 = 440070,
	Id071 = 440071,
	Id081 = 440081,
	Id082 = 440082,
	Id083 = 440083,
	Id084 = 440084,
	Id085 = 440085,
	Id086 = 440086,
	Id087 = 440087,
	Id088 = 440088,
	Id089 = 440089,
	Id090 = 440090,
	Id091 = 440091,
	Id101 = 440101,
	Id102 = 440102,
	Id103 = 440103,
	Id104 = 440104,
	Id105 = 440105,
	Id106 = 440106,
	Id107 = 440107,
	Id108 = 440108,
	Id109 = 440109,
	Id110 = 440110,
	Id111 = 440111,
	Id121 = 440121,
	Id122 = 440122,
	Id123 = 440123,
	Id124 = 440124,
	Id125 = 440125,
	Id126 = 440126,
	Id127 = 440127,
	Id128 = 440128,
	Id129 = 440129,
	Id130 = 440130,
	Id131 = 440131,
	Id141 = 440141,
	Id142 = 440142,
	Id143 = 440143,
	Id144 = 440144,
	Id145 = 440145,
	Id146 = 440146,
	Id147 = 440147,
	Id148 = 440148,
	Id149 = 440149,
	Id150 = 440150,
	Id151 = 440151,
	Id161 = 440161,
	Id162 = 440162,
	Id163 = 440163,
	Id164 = 440164,
	Id165 = 440165,
	Id166 = 440166,
	Id167 = 440167,
	Id168 = 440168,
	Id169 = 440169,
	Id170 = 440170,
	Id171 = 440171,
	Id181 = 440181,
	Id182 = 440182,
	Id183 = 440183,
	Id184 = 440184,
	Id185 = 440185,
	Id186 = 440186,
	Id187 = 440187,
	Id188 = 440188,
	Id189 = 440189,
	Id190 = 440190,
	Id191 = 440191,
	Id201 = 440201,
	Id202 = 440202,
	Id203 = 440203,
	Id204 = 440204,
	Id205 = 440205,
	Id206 = 440206,
	Id207 = 440207,
	Id208 = 440208,
	Id209 = 440209,
	Id210 = 440210,
	Id211 = 440211,
	Id221 = 440221,
	Id222 = 440222,
	Id223 = 440223,
	Id224 = 440224,
	Id225 = 440225,
	Id226 = 440226,
	Id227 = 440227,
	Id228 = 440228,
	Id229 = 440229,
	Id230 = 440230,
	Id231 = 440231,
	Id241 = 440241,
	Id242 = 440242,
	Id243 = 440243,
	Id244 = 440244,
	Id245 = 440245,
	Id246 = 440246,
	Id247 = 440247,
	Id248 = 440248,
	Id249 = 440249,
	Id250 = 440250,
	Id251 = 440251,
	Id261 = 440261,
	Id262 = 440262,
	Id263 = 440263,
	Id264 = 440264,
	Id265 = 440265,
	Id266 = 440266,
	Id267 = 440267,
	Id268 = 440268,
	Id269 = 440269,
	Id270 = 440270,
	Id271 = 440271,
	Id281 = 440281,
	Id282 = 440282,
	Id283 = 440283,
	Id284 = 440284,
	Id285 = 440285,
	Id286 = 440286,
	Id287 = 440287,
	Id288 = 440288,
	Id289 = 440289,
	Id290 = 440290,
	Id291 = 440291,
	Id301 = 440301,
	Id302 = 440302,
	Id303 = 440303,
	Id304 = 440304,
	Id305 = 440305,
	Id306 = 440306,
	Id307 = 440307,
	Id308 = 440308,
	Id309 = 440309,
	Id310 = 440310,
	Id311 = 440311,
}
RoomPieceConfig[RoomPieceID.Id001] =
{
	Id = 1,
	Name = "魔王的壁纸",
	Gallery = 950001,
	Character = 220029,
	Rarity = 4,
	Icon = "Room_Rpg_11_damowang_Wallpaper",
	Node = "Wallpaper",
	Desc = "从顶级的家具商那里定制的手工壁纸，颜色和上面的花纹都是大魔王亲自挑选的。",
	Ability = {
		{
			Value = 200001,
			Num = 25,
		},
	},
}
RoomPieceConfig[RoomPieceID.Id002] =
{
	Id = 2,
	Name = "地狱花吊灯",
	Gallery = 950001,
	Character = 220029,
	Rarity = 4,
	Icon = "Room_Rpg_11_damowang_Light",
	Node = "Light",
	Desc = "使用666片地狱花瓣制作而成的吊灯，是只有顶级艺术家才懂得欣赏的杰作。",
	Ability = {
		{
			Value = 200002,
			Num = 25,
		},
	},
}
RoomPieceConfig[RoomPieceID.Id003] =
{
	Id = 3,
	Name = "魔王的宝座",
	Gallery = 950001,
	Character = 220029,
	Rarity = 4,
	Icon = "Room_Rpg_11_damowang_Sofa",
	Node = "Sofa",
	Desc = "魔王集团代代相传的宝座，某段时间因为集团经营不善，而被抵押给了玉璧女王。",
	Ability = {
		{
			Value = 200001,
			Num = 25,
		},
	},
}
RoomPieceConfig[RoomPieceID.Id004] =
{
	Id = 4,
	Name = "白骨置物架",
	Gallery = 950001,
	Character = 220029,
	Rarity = 4,
	Icon = "Room_Rpg_11_damowang_Shelves",
	Node = "Shelves",
	Desc = "使用地狱火龙的脊椎骨制作的置物架，粉白的骨头中透露着炎热的气息。",
	Ability = {
		{
			Value = 200002,
			Num = 25,
		},
	},
}
RoomPieceConfig[RoomPieceID.Id005] =
{
	Id = 5,
	Name = "魔王的长柜",
	Gallery = 950001,
	Character = 220029,
	Rarity = 4,
	Icon = "Room_Rpg_11_damowang_Cabinet",
	Node = "Cabinet",
	Desc = "从顶级的家具商那里定制的手工长柜，里面摆放了大魔王从宇宙各地收集的黑胶唱片。",
	Ability = {
		{
			Value = 200002,
			Num = 25,
		},
	},
}
RoomPieceConfig[RoomPieceID.Id006] =
{
	Id = 6,
	Name = "手下的礼物",
	Gallery = 950001,
	Character = 220029,
	Rarity = 4,
	Icon = "Room_Rpg_11_damowang_Ornament_1",
	Node = "Ornament_1",
	Desc = "大魔王正式成为魔王集团董事长那天，集团的小兵们赠送的礼物，不过目前为止还没有拆开。",
	Ability = {
		{
			Value = 200001,
			Num = 25,
		},
	},
}
RoomPieceConfig[RoomPieceID.Id007] =
{
	Id = 7,
	Name = "魔王郁金香",
	Gallery = 950001,
	Character = 220029,
	Rarity = 4,
	Icon = "Room_Rpg_11_damowang_Ornament_2",
	Node = "Ornament_2",
	Desc = "来自里世界的奇异花朵，散发着淡雅的清香。据说每一年只会绽放一次，如果对着盛开的花朵许愿，那么愿望就一定能达成。",
	Ability = {
		{
			Value = 200001,
			Num = 25,
		},
	},
}
RoomPieceConfig[RoomPieceID.Id008] =
{
	Id = 8,
	Name = "魔王水手服",
	Gallery = 950001,
	Character = 220029,
	Rarity = 4,
	Icon = "Room_Rpg_11_damowang_Ornament_3",
	Node = "Ornament_3",
	Desc = "话剧《月丝丝少女》中的现场道具，目前在黑市已经拍到1000万的高价，不过最终成为了大魔王的收藏。",
	Ability = {
		{
			Value = 200002,
			Num = 25,
		},
	},
}
RoomPieceConfig[RoomPieceID.Id009] =
{
	Id = 9,
	Name = "魔王的兰花",
	Gallery = 950001,
	Character = 220029,
	Rarity = 4,
	Icon = "Room_Rpg_11_damowang_Ornament_4",
	Node = "Ornament_4",
	Desc = "由魔界的顶级花匠耗费数百年交配而成的异色兰花，花语是“我的生命将为艺术而奉献”。",
	Ability = {
		{
			Value = 200001,
			Num = 25,
		},
	},
}
RoomPieceConfig[RoomPieceID.Id010] =
{
	Id = 10,
	Name = "模特骷髅",
	Gallery = 950001,
	Character = 220029,
	Rarity = 4,
	Icon = "Room_Rpg_11_damowang_Ornament_5",
	Node = "Ornament_5",
	Desc = "大魔王练习话剧台词时专用的模特。遇到棘手问题时，大魔王会一边梳她的头发一边想。",
	Ability = {
		{
			Value = 200001,
			Num = 25,
		},
	},
}
RoomPieceConfig[RoomPieceID.Id011] =
{
	Id = 11,
	Name = "罗夏测试图",
	Gallery = 950001,
	Character = 220029,
	Rarity = 4,
	Icon = "Room_Rpg_11_damowang_Ornament_6",
	Node = "Ornament_6",
	Desc = "一位异世界的游客为大魔王进行的心理评估，不过听说游客看到大魔王检测结果的那一刻，就发誓绝不对任何人提起此事。",
	Ability = {
		{
			Value = 200002,
			Num = 25,
		},
		{
			Value = 200008,
			Num = 100,
		},
	},
}
RoomPieceConfig[RoomPieceID.Id021] =
{
	Id = 21,
	Name = "健身的壁纸",
	Gallery = 950002,
	Character = 220131,
	Rarity = 4,
	Icon = "Room_Fat_30_shutiao_Wallpaper",
	Node = "Wallpaper",
	Desc = "充满力量感的宫廷壁纸，上面的花纹是按照薯条国王心目中最理想的体型制作的。",
	Ability = {
		{
			Value = 200001,
			Num = 25,
		},
	},
}
RoomPieceConfig[RoomPieceID.Id022] =
{
	Id = 22,
	Name = "宫廷吊灯",
	Gallery = 950002,
	Character = 220131,
	Rarity = 4,
	Icon = "Room_Fat_30_shutiao_Light",
	Node = "Light",
	Desc = "镀上了食用黄金的华丽吊灯，完美展示了美食星王室华丽而夸张的风格。",
	Ability = {
		{
			Value = 200001,
			Num = 25,
		},
	},
}
RoomPieceConfig[RoomPieceID.Id023] =
{
	Id = 23,
	Name = "方正王座",
	Gallery = 950002,
	Character = 220131,
	Rarity = 4,
	Icon = "Room_Fat_30_shutiao_Sofa",
	Node = "Sofa",
	Desc = "历代美食星国王的宝座，坐在这张椅子上的人要担负起为整个宇宙带去美食的重任。",
	Ability = {
		{
			Value = 200001,
			Num = 25,
		},
	},
}
RoomPieceConfig[RoomPieceID.Id024] =
{
	Id = 24,
	Name = "宫廷置物架",
	Gallery = 950002,
	Character = 220131,
	Rarity = 4,
	Icon = "Room_Fat_30_shutiao_Shelves",
	Node = "Shelves",
	Desc = "摆放了国王最珍贵的宝物的置物架，由美食星顶级食物雕刻师制作。",
	Ability = {
		{
			Value = 200001,
			Num = 25,
		},
	},
}
RoomPieceConfig[RoomPieceID.Id025] =
{
	Id = 25,
	Name = "王室长柜",
	Gallery = 950002,
	Character = 220131,
	Rarity = 4,
	Icon = "Room_Fat_30_shutiao_Cabinet",
	Node = "Cabinet",
	Desc = "使用实木制成的宫廷长柜，不过柜子沉重的真正原因是里面放着120个健身用的铁饼。",
	Ability = {
		{
			Value = 200002,
			Num = 25,
		},
	},
}
RoomPieceConfig[RoomPieceID.Id026] =
{
	Id = 26,
	Name = "镀金哑铃",
	Gallery = 950002,
	Character = 220131,
	Rarity = 4,
	Icon = "Room_Fat_30_shutiao_Ornament_1",
	Node = "Ornament_1",
	Desc = "镀上了食用黄金的超重哑铃，即使是薯条国王要单手举起有些困难，不过每天只要举两下就能顶10小时的锻炼量。",
	Ability = {
		{
			Value = 200007,
			Num = 100,
		},
	},
}
RoomPieceConfig[RoomPieceID.Id027] =
{
	Id = 27,
	Name = "沙包与拳套",
	Gallery = 950002,
	Character = 220131,
	Rarity = 4,
	Icon = "Room_Fat_30_shutiao_Ornament_2",
	Node = "Ornament_2",
	Desc = "番茄酱侍卫自费为薯条国王购买的健身器材，说是因为担心国王一直举重拉伤肌肉。",
	Ability = {
		{
			Value = 200002,
			Num = 25,
		},
	},
}
RoomPieceConfig[RoomPieceID.Id028] =
{
	Id = 28,
	Name = "冠军奖杯",
	Gallery = 950002,
	Character = 220131,
	Rarity = 4,
	Icon = "Room_Fat_30_shutiao_Ornament_3",
	Node = "Ornament_3",
	Desc = "宇宙举重大赛冠军的奖杯，不过事实上那一年薯条国王只是亚军，这个奖杯是薯条国王花钱找同一家工厂重制的。",
	Ability = {
		{
			Value = 200002,
			Num = 25,
		},
	},
}
RoomPieceConfig[RoomPieceID.Id029] =
{
	Id = 29,
	Name = "宫廷的花饰",
	Gallery = 950002,
	Character = 220131,
	Rarity = 4,
	Icon = "Room_Fat_30_shutiao_Ornament_4",
	Node = "Ornament_4",
	Desc = "只摆放在国王房间的罕见花卉，必须使用特制营养液才能存活下去。听说可以代谢出对健身的人很有帮助的气体。",
	Ability = {
		{
			Value = 200001,
			Num = 25,
		},
	},
}
RoomPieceConfig[RoomPieceID.Id030] =
{
	Id = 30,
	Name = "冠军纪念照",
	Gallery = 950002,
	Character = 220131,
	Rarity = 4,
	Icon = "Room_Fat_30_shutiao_Ornament_5",
	Node = "Ornament_5",
	Desc = "记录了薯条国王在宇宙举重比赛上得到亚军的照片。虽然与冠军失之交臂未免可惜，不过薯条国王还是很珍惜这份荣誉。",
	Ability = {
		{
			Value = 200007,
			Num = 100,
		},
	},
}
RoomPieceConfig[RoomPieceID.Id031] =
{
	Id = 31,
	Name = "宫廷的绿植",
	Gallery = 950002,
	Character = 220131,
	Rarity = 4,
	Icon = "Room_Fat_30_shutiao_Ornament_6",
	Node = "Ornament_6",
	Desc = "生活在热带地区的蕨类植物，虽然不是名贵的植物，不过其顽强的生存意志很得到国王本人的欣赏。",
	Ability = {
		{
			Value = 200001,
			Num = 25,
		},
	},
}
RoomPieceConfig[RoomPieceID.Id041] =
{
	Id = 41,
	Name = "指挥室壁纸",
	Gallery = 950003,
	Character = 220229,
	Rarity = 4,
	Icon = "Room_MUS_30_Napoleon_Wallpaper",
	Node = "Wallpaper",
	Desc = "样式简约但不失帝国风范的壁纸，是博物馆长为了展现名人蜡像尊贵身份专门请人定制的。",
	Ability = {
		{
			Value = 200002,
			Num = 25,
		},
	},
}
RoomPieceConfig[RoomPieceID.Id042] =
{
	Id = 42,
	Name = "领袖的帷幕",
	Gallery = 950003,
	Character = 220229,
	Rarity = 4,
	Icon = "Room_MUS_30_Napoleon_Light",
	Node = "Light",
	Desc = "充满了帝国元帅气息的帷幕，虽然使用了很便宜的材料，但是是博物馆星大家一起制作的，饱含着大家对名人蜡像的敬意。",
	Ability = {
		{
			Value = 200001,
			Num = 25,
		},
	},
}
RoomPieceConfig[RoomPieceID.Id043] =
{
	Id = 43,
	Name = "领袖之座",
	Gallery = 950003,
	Character = 220229,
	Rarity = 4,
	Icon = "Room_MUS_30_Napoleon_Sofa",
	Node = "Sofa",
	Desc = "非常罕见的上等成色二手皮沙发，靠背部分已经磨损，不过在博物馆众人的努力下已经修复好了。",
	Ability = {
		{
			Value = 200002,
			Num = 25,
		},
	},
}
RoomPieceConfig[RoomPieceID.Id044] =
{
	Id = 44,
	Name = "领袖置物架",
	Gallery = 950003,
	Character = 220229,
	Rarity = 4,
	Icon = "Room_MUS_30_Napoleon_Shelves",
	Node = "Shelves",
	Desc = "使用老旧铁架作为基础，配合新缝制的皮套组合而成的置物架。名人蜡像将自己最喜欢的玩具都放在了上面。",
	Ability = {
		{
			Value = 200001,
			Num = 25,
		},
	},
}
RoomPieceConfig[RoomPieceID.Id045] =
{
	Id = 45,
	Name = "鎏金长柜",
	Gallery = 950003,
	Character = 220229,
	Rarity = 4,
	Icon = "Room_MUS_30_Napoleon_Cabinet",
	Node = "Cabinet",
	Desc = "名人蜡像房间中最值钱的家具，以前真的是鎏金的噢~不过时间长了刮擦得非常厉害……但是经过保安重新喷涂了金色油漆后又像新的一样了。",
	Ability = {
		{
			Value = 200001,
			Num = 25,
		},
	},
}
RoomPieceConfig[RoomPieceID.Id046] =
{
	Id = 46,
	Name = "指挥室台灯",
	Gallery = 950003,
	Character = 220229,
	Rarity = 4,
	Icon = "Room_MUS_30_Napoleon_Ornament_1",
	Node = "Ornament_1",
	Desc = "馆长购买鎏金长柜时硬问家具商拿的小赠品，虽然是免费的，但是摆在桌上很像那么一回事。",
	Ability = {
		{
			Value = 200005,
			Num = 100,
		},
	},
}
RoomPieceConfig[RoomPieceID.Id047] =
{
	Id = 47,
	Name = "指挥室壁炉",
	Gallery = 950003,
	Character = 220229,
	Rarity = 4,
	Icon = "Room_MUS_30_Napoleon_Ornament_2",
	Node = "Ornament_2",
	Desc = "博物馆的石像们帮忙搭建的石质壁炉，不过因为名人蜡像遇热会有些融化，所以从来都不用~",
	Ability = {
		{
			Value = 200001,
			Num = 25,
		},
	},
}
RoomPieceConfig[RoomPieceID.Id048] =
{
	Id = 48,
	Name = "领袖的点心",
	Gallery = 950003,
	Character = 220229,
	Rarity = 4,
	Icon = "Room_MUS_30_Napoleon_Ornament_3",
	Node = "Ornament_3",
	Desc = "仅供摆设的模型食物，是为了重现元帅生活品味专门制作的道具。",
	Ability = {
		{
			Value = 200007,
			Num = 100,
		},
	},
}
RoomPieceConfig[RoomPieceID.Id049] =
{
	Id = 49,
	Name = "立式烛台",
	Gallery = 950003,
	Character = 220229,
	Rarity = 4,
	Icon = "Room_MUS_30_Napoleon_Ornament_4",
	Node = "Ornament_4",
	Desc = "看起来很气派，但是实际上价格非常实惠的宫廷样式烛台。馆长在二手市场逛了一下午才淘到的。",
	Ability = {
		{
			Value = 200001,
			Num = 25,
		},
	},
}
RoomPieceConfig[RoomPieceID.Id050] =
{
	Id = 50,
	Name = "爱马的相片",
	Gallery = 950003,
	Character = 220229,
	Rarity = 4,
	Icon = "Room_MUS_30_Napoleon_Ornament_5",
	Node = "Ornament_5",
	Desc = "名人蜡像战马的照片，因为多出了一个相框又不想浪费才专门挂上的。",
	Ability = {
		{
			Value = 200001,
			Num = 25,
		},
	},
}
RoomPieceConfig[RoomPieceID.Id051] =
{
	Id = 51,
	Name = "领袖的矮柜",
	Gallery = 950003,
	Character = 220229,
	Rarity = 4,
	Icon = "Room_MUS_30_Napoleon_Ornament_6",
	Node = "Ornament_6",
	Desc = "存放了大量作战用文件的木制矮柜，这些文件都是珍贵的历史资料。",
	Ability = {
		{
			Value = 200005,
			Num = 100,
		},
	},
}
RoomPieceConfig[RoomPieceID.Id061] =
{
	Id = 61,
	Name = "简洁的壁纸",
	Gallery = 950004,
	Character = 220324,
	Rarity = 4,
	Icon = "Room_Sus_01_fuermosi_Wallpaper",
	Node = "Wallpaper",
	Desc = "对于一般人而言样式简洁的壁纸，对于大侦探而言，却是他记忆宫殿的线索。",
	Ability = {
		{
			Value = 200001,
			Num = 25,
		},
	},
}
RoomPieceConfig[RoomPieceID.Id062] =
{
	Id = 62,
	Name = "温暖的吊灯",
	Gallery = 950004,
	Character = 220324,
	Rarity = 4,
	Icon = "Room_Sus_01_fuermosi_Light",
	Node = "Light",
	Desc = "房东太太按照大侦探的要求专门为其购买的吊灯，灯光明亮又不失柔和。",
	Ability = {
		{
			Value = 200002,
			Num = 25,
		},
	},
}
RoomPieceConfig[RoomPieceID.Id063] =
{
	Id = 63,
	Name = "松软沙发",
	Gallery = 950004,
	Character = 220324,
	Rarity = 4,
	Icon = "Room_Sus_01_fuermosi_Sofa",
	Node = "Sofa",
	Desc = "对于经常需要坐在家中与助手及警方讨论案情的大侦探而言非常重要的道具，其舒适度直接影响了大侦探推理时的顺畅度。",
	Ability = {
		{
			Value = 200001,
			Num = 25,
		},
	},
}
RoomPieceConfig[RoomPieceID.Id064] =
{
	Id = 64,
	Name = "实木置物架",
	Gallery = 950004,
	Character = 220324,
	Rarity = 4,
	Icon = "Room_Sus_01_fuermosi_Shelves",
	Node = "Shelves",
	Desc = "从廉价商场购买的实木置物架，不过尺寸及色调非常符合大侦探的心意。",
	Ability = {
		{
			Value = 200002,
			Num = 25,
		},
	},
}
RoomPieceConfig[RoomPieceID.Id065] =
{
	Id = 65,
	Name = "杂乱长柜",
	Gallery = 950004,
	Character = 220324,
	Rarity = 4,
	Icon = "Room_Sus_01_fuermosi_Cabinet",
	Node = "Cabinet",
	Desc = "收藏了大量案卷及笔记的杂乱长柜。每个抽屉打开来都有98.7%的概率关不上，不过有客人拜访时，大侦探会快速收拾一下。",
	Ability = {
		{
			Value = 200002,
			Num = 25,
		},
	},
}
RoomPieceConfig[RoomPieceID.Id066] =
{
	Id = 66,
	Name = "文件收纳箱",
	Gallery = 950004,
	Character = 220324,
	Rarity = 4,
	Icon = "Room_Sus_01_fuermosi_Ornament_1",
	Node = "Ornament_1",
	Desc = "存放着大量图卷的文件收纳箱，为了防止产生摺痕，大侦探将它们都卷起来直接插在了箱子上。",
	Ability = {
		{
			Value = 200001,
			Num = 25,
		},
	},
}
RoomPieceConfig[RoomPieceID.Id067] =
{
	Id = 67,
	Name = "实木书柜",
	Gallery = 950004,
	Character = 220324,
	Rarity = 4,
	Icon = "Room_Sus_01_fuermosi_Ornament_2",
	Node = "Ornament_2",
	Desc = "与置物架一并购入的大书柜，不过上面堆满了各种物件，包括正在等待反应的试剂、不常用的工具书及一些小饰品。",
	Ability = {
		{
			Value = 200008,
			Num = 100,
		},
	},
}
RoomPieceConfig[RoomPieceID.Id068] =
{
	Id = 68,
	Name = "关键的笔记",
	Gallery = 950004,
	Character = 220324,
	Rarity = 4,
	Icon = "Room_Sus_01_fuermosi_Ornament_3",
	Node = "Ornament_3",
	Desc = "大侦探随身的案件笔记，记录了对案件至关重要的线索。一旦有新的灵感时，大侦探就会立刻将灵感记录下来。",
	Ability = {
		{
			Value = 200001,
			Num = 25,
		},
	},
}
RoomPieceConfig[RoomPieceID.Id069] =
{
	Id = 69,
	Name = "常用的参考书",
	Gallery = 950004,
	Character = 220324,
	Rarity = 4,
	Icon = "Room_Sus_01_fuermosi_Ornament_4",
	Node = "Ornament_4",
	Desc = "堆砌着常用的身理书籍、化学书籍、剪报及当地风俗书籍的书堆。",
	Ability = {
		{
			Value = 200002,
			Num = 25,
		},
	},
}
RoomPieceConfig[RoomPieceID.Id070] =
{
	Id = 70,
	Name = "随性的绿植",
	Gallery = 950004,
	Character = 220324,
	Rarity = 4,
	Icon = "Room_Sus_01_fuermosi_Ornament_5",
	Node = "Ornament_5",
	Desc = "一位好朋友送给大侦探的盆栽，当房间没有其他人时，大侦探会对着它诉说案情。",
	Ability = {
		{
			Value = 200002,
			Num = 25,
		},
	},
}
RoomPieceConfig[RoomPieceID.Id071] =
{
	Id = 71,
	Name = "奇怪的照片",
	Gallery = 950004,
	Character = 220324,
	Rarity = 4,
	Icon = "Room_Sus_01_fuermosi_Ornament_6",
	Node = "Ornament_6",
	Desc = "大侦探刚搬来时就带着的相框。似乎是侦探街的流浪猫，不过不知道大侦探为什么要挂着它的照片。",
	Ability = {
		{
			Value = 200002,
			Num = 25,
		},
	},
}
RoomPieceConfig[RoomPieceID.Id081] =
{
	Id = 81,
	Name = "实验室墙壁",
	Gallery = 950004,
	Character = 220325,
	Rarity = 4,
	Icon = "Room_Sus_03_moliyadi_Wallpaper",
	Node = "Wallpaper",
	Desc = "实验室专用墙体，有着防化防毒防火防爆等特殊功能，无论是什么样的对手都很难轻易突破。",
	Ability = {
		{
			Value = 200001,
			Num = 25,
		},
	},
}
RoomPieceConfig[RoomPieceID.Id082] =
{
	Id = 82,
	Name = "无影灯",
	Gallery = 950004,
	Character = 220325,
	Rarity = 4,
	Icon = "Room_Sus_03_moliyadi_Light",
	Node = "Light",
	Desc = "手术专用的无影灯，对于需要在房间内进行精密实验操作的博士而言非常有用。",
	Ability = {
		{
			Value = 200001,
			Num = 25,
		},
	},
}
RoomPieceConfig[RoomPieceID.Id083] =
{
	Id = 83,
	Name = "工作椅",
	Gallery = 950004,
	Character = 220325,
	Rarity = 4,
	Icon = "Room_Sus_03_moliyadi_Sofa",
	Node = "Sofa",
	Desc = "内置了喷气弹射装置的工作椅，当实验室遭人包围时，教授可以按下紧急按钮，弹射逃离实验室。",
	Ability = {
		{
			Value = 200002,
			Num = 25,
		},
	},
}
RoomPieceConfig[RoomPieceID.Id084] =
{
	Id = 84,
	Name = "危险的置物架",
	Gallery = 950004,
	Character = 220325,
	Rarity = 4,
	Icon = "Room_Sus_03_moliyadi_Shelves",
	Node = "Shelves",
	Desc = "摆放了教授喜欢的玩具的置物架，上面贴着的黄黑条纹暗示参观者不要轻易触摸。",
	Ability = {
		{
			Value = 200002,
			Num = 25,
		},
	},
}
RoomPieceConfig[RoomPieceID.Id085] =
{
	Id = 85,
	Name = "实验工作台",
	Gallery = 950004,
	Character = 220325,
	Rarity = 4,
	Icon = "Room_Sus_03_moliyadi_Cabinet",
	Node = "Cabinet",
	Desc = "实验室专用的工作台，台面使用复合材料制成，可以快速中和各种泄露的化学试剂。",
	Ability = {
		{
			Value = 200001,
			Num = 25,
		},
	},
}
RoomPieceConfig[RoomPieceID.Id086] =
{
	Id = 86,
	Name = "试剂储藏柜",
	Gallery = 950004,
	Character = 220325,
	Rarity = 4,
	Icon = "Room_Sus_03_moliyadi_Ornament_1",
	Node = "Ornament_1",
	Desc = "存放着教授正在调配的试剂的储藏柜，试剂散发出浓烈的刺鼻气味。",
	Ability = {
		{
			Value = 200002,
			Num = 25,
		},
	},
}
RoomPieceConfig[RoomPieceID.Id087] =
{
	Id = 87,
	Name = "灵感的黑板",
	Gallery = 950004,
	Character = 220325,
	Rarity = 4,
	Icon = "Room_Sus_03_moliyadi_Ornament_2",
	Node = "Ornament_2",
	Desc = "记录临时信息的灵感黑板，实验过程中，如果突然想到了天才的捣蛋点子，教授会立刻记下来。",
	Ability = {
		{
			Value = 200008,
			Num = 100,
		},
	},
}
RoomPieceConfig[RoomPieceID.Id088] =
{
	Id = 88,
	Name = "超级显微镜",
	Gallery = 950004,
	Character = 220325,
	Rarity = 4,
	Icon = "Room_Sus_03_moliyadi_Ornament_3",
	Node = "Ornament_3",
	Desc = "全宇宙仅一台的超倍率显微镜，目前教授正在调校其光线透射率，希望找到新的物质。",
	Ability = {
		{
			Value = 200002,
			Num = 25,
		},
	},
}
RoomPieceConfig[RoomPieceID.Id089] =
{
	Id = 89,
	Name = "危险试验品",
	Gallery = 950004,
	Character = 220325,
	Rarity = 4,
	Icon = "Room_Sus_03_moliyadi_Ornament_4",
	Node = "Ornament_4",
	Desc = "人造生物的标本，因为暂时无法完全操控它，因此被教授泡在了营养剂当中，目前处于休眠状态。",
	Ability = {
		{
			Value = 200002,
			Num = 25,
		},
	},
}
RoomPieceConfig[RoomPieceID.Id090] =
{
	Id = 90,
	Name = "窗外的化工厂",
	Gallery = 950004,
	Character = 220325,
	Rarity = 4,
	Icon = "Room_Sus_03_moliyadi_Ornament_5",
	Node = "Ornament_5",
	Desc = "对于一般人而言没有任何好感的景色，但是教授每次缺乏灵感时，只要看着窗外就会有新点子。",
	Ability = {
		{
			Value = 200008,
			Num = 100,
		},
	},
}
RoomPieceConfig[RoomPieceID.Id091] =
{
	Id = 91,
	Name = "骨架模型",
	Gallery = 950004,
	Character = 220325,
	Rarity = 4,
	Icon = "Room_Sus_03_moliyadi_Ornament_6",
	Node = "Ornament_6",
	Desc = "某个人的骨架，是教授的父亲留给他的藏品。不过骨架戴着的帽子是不是能说明其生前也是一名侦探呢？",
	Ability = {
		{
			Value = 200002,
			Num = 25,
		},
	},
}
RoomPieceConfig[RoomPieceID.Id101] =
{
	Id = 101,
	Name = "夜缤纷壁纸",
	Character = 221003,
	Rarity = 4,
	Icon = "Room_SPDraw_03_DiamondQueen_Wallpaper",
	Node = "Wallpaper",
	Desc = "散发出粉色光芒的特制壁纸，流彩的光辉能够激发人们心中想要抽奖的欲望。",
}
RoomPieceConfig[RoomPieceID.Id102] =
{
	Id = 102,
	Name = "霓虹彩灯",
	Character = 221003,
	Rarity = 4,
	Icon = "Room_SPDraw_03_DiamondQueen_Light",
	Node = "Light",
	Desc = "闪耀着欢快活泼的气氛的霓虹灯牌，跟着霓虹灯牌就能找到藏有这个宇宙大量秘密的玉璧卡池。",
}
RoomPieceConfig[RoomPieceID.Id103] =
{
	Id = 103,
	Name = "主控室座椅",
	Character = 221003,
	Rarity = 4,
	Icon = "Room_SPDraw_03_DiamondQueen_Sofa",
	Node = "Sofa",
	Desc = "连接着玉璧箱的操控座椅。如果抽奖人员运气太差，女王会偷偷拨动开关，给予对方一件保底奖励。",
}
RoomPieceConfig[RoomPieceID.Id104] =
{
	Id = 104,
	Name = "礼品架",
	Character = 221003,
	Rarity = 4,
	Icon = "Room_SPDraw_03_DiamondQueen_Shelves",
	Node = "Shelves",
	Desc = "和不夜城同款的礼品架，不过被玉璧女王带回家后，专门用来摆放她的玩具。",
}
RoomPieceConfig[RoomPieceID.Id105] =
{
	Id = 105,
	Name = "控制编码台",
	Character = 221003,
	Rarity = 4,
	Icon = "Room_SPDraw_03_DiamondQueen_Cabinet",
	Node = "Cabinet",
	Desc = "坚固的特制长柜，柜子里藏着玉璧箱抽奖数据的服务器。一旦数据出现问题，就需要停止服务器进行维护。",
}
RoomPieceConfig[RoomPieceID.Id106] =
{
	Id = 106,
	Name = "超大块玉璧",
	Character = 221003,
	Rarity = 4,
	Icon = "Room_SPDraw_03_DiamondQueen_Ornament_1",
	Node = "Ornament_1",
	Desc = "凝结了玉璧女王迄今为止所有赚到的玉璧的超大块玉璧，由超级铁匠使用高温焊枪融合制作而成。",
}
RoomPieceConfig[RoomPieceID.Id107] =
{
	Id = 107,
	Name = "好运拉霸机",
	Character = 221003,
	Rarity = 4,
	Icon = "Room_SPDraw_03_DiamondQueen_Ornament_2",
	Node = "Ornament_2",
	Desc = "玉璧女王从神秘的猫猫星弄来的超级拉霸机，只要屏幕上所有灯都亮起，拉霸机中就会掉出不属于这个世界的奖品。",
}
RoomPieceConfig[RoomPieceID.Id108] =
{
	Id = 108,
	Name = "乐透下注站",
	Character = 221003,
	Rarity = 4,
	Icon = "Room_SPDraw_03_DiamondQueen_Ornament_3",
	Node = "Ornament_3",
	Desc = "连接着宇宙乐透中心官方网站的高速终端，使用这台机器进行下注是没有任何延迟的。",
}
RoomPieceConfig[RoomPieceID.Id109] =
{
	Id = 109,
	Name = "圆梦扭蛋机",
	Character = 221003,
	Rarity = 4,
	Icon = "Room_SPDraw_03_DiamondQueen_Ornament_4",
	Node = "Ornament_4",
	Desc = "由玉璧女王反复调控抓力的扭蛋机。女王一直声称，无论抓多少次，只要抓出一块她就把超大块玉璧送给你。",
}
RoomPieceConfig[RoomPieceID.Id110] =
{
	Id = 110,
	Name = "赢家的饮品",
	Character = 221003,
	Rarity = 4,
	Icon = "Room_SPDraw_03_DiamondQueen_Ornament_5",
	Node = "Ornament_5",
	Desc = "玉璧女王非常喜欢的饮料，散发出一股说不清道不明的清香气味，似乎是不属于这个世界的水果的果汁。",
}
RoomPieceConfig[RoomPieceID.Id111] =
{
	Id = 111,
	Name = "彩灯告示牌",
	Character = 221003,
	Rarity = 4,
	Icon = "Room_SPDraw_03_DiamondQueen_Ornament_6",
	Node = "Ornament_6",
	Desc = "与霓虹彩灯一起订购的彩灯告示牌，不过要打出什么样的广告语，玉璧女王目前还没有想好。",
}
RoomPieceConfig[RoomPieceID.Id121] =
{
	Id = 121,
	Name = "呜呜的温暖小屋",
	Character = 220001,
	Rarity = 4,
	Icon = "Room_All_wuwu",
	Node = "Wallpaper",
	Desc = "呜呜从小居住的房间，摆放着各式各样呜呜喜欢的玩具。虽然呜呜经常把房间弄得乱哄哄的，不过似乎有神秘人会定期帮忙清理。",
}
RoomPieceConfig[RoomPieceID.Id122] =
{
	Id = 122,
	Name = "铃铛灯",
	Character = 220001,
	Rarity = 4,
	Icon = 0,
	Node = "Light",
	Desc = "铃铛灯",
}
RoomPieceConfig[RoomPieceID.Id123] =
{
	Id = 123,
	Name = "软垫",
	Character = 220001,
	Rarity = 4,
	Icon = 0,
	Node = "Sofa",
	Desc = "软垫",
}
RoomPieceConfig[RoomPieceID.Id124] =
{
	Id = 124,
	Name = "玩具架",
	Character = 220001,
	Rarity = 4,
	Icon = 0,
	Node = "Shelves",
	Desc = "玩具架",
}
RoomPieceConfig[RoomPieceID.Id125] =
{
	Id = 125,
	Name = "零食柜",
	Character = 220001,
	Rarity = 4,
	Icon = 0,
	Node = "Cabinet",
	Desc = "零食柜",
}
RoomPieceConfig[RoomPieceID.Id126] =
{
	Id = 126,
	Name = "猫爬架",
	Character = 220001,
	Rarity = 4,
	Icon = 0,
	Node = "Ornament_1",
	Desc = "猫爬架",
}
RoomPieceConfig[RoomPieceID.Id127] =
{
	Id = 127,
	Name = "绒毛球",
	Character = 220001,
	Rarity = 4,
	Icon = 0,
	Node = "Ornament_2",
	Desc = "绒毛球",
}
RoomPieceConfig[RoomPieceID.Id128] =
{
	Id = 128,
	Name = "漆漆的礼物",
	Character = 220001,
	Rarity = 4,
	Icon = 0,
	Node = "Ornament_3",
	Desc = "漆漆的礼物",
}
RoomPieceConfig[RoomPieceID.Id129] =
{
	Id = 129,
	Name = "薄荷草",
	Character = 220001,
	Rarity = 4,
	Icon = 0,
	Node = "Ornament_4",
	Desc = "薄荷草",
}
RoomPieceConfig[RoomPieceID.Id130] =
{
	Id = 130,
	Name = "小窗",
	Character = 220001,
	Rarity = 4,
	Icon = 0,
	Node = "Ornament_5",
	Desc = "小窗",
}
RoomPieceConfig[RoomPieceID.Id131] =
{
	Id = 131,
	Name = "太空服",
	Character = 220001,
	Rarity = 4,
	Icon = 0,
	Node = "Ornament_6",
	Desc = "太空服",
}
RoomPieceConfig[RoomPieceID.Id141] =
{
	Id = 141,
	Name = "漆漆的温暖小屋",
	Character = 220002,
	Rarity = 4,
	Icon = "Room_All_gugu",
	Node = "Wallpaper",
	Desc = "漆漆居住的小房间，和呜呜的房间使用了相同的装饰风格。不过漆漆会很认真地打扫房间，保证房间的整洁。",
}
RoomPieceConfig[RoomPieceID.Id142] =
{
	Id = 142,
	Name = "铃铛灯",
	Character = 220002,
	Rarity = 4,
	Icon = 0,
	Node = "Light",
	Desc = "铃铛灯",
}
RoomPieceConfig[RoomPieceID.Id143] =
{
	Id = 143,
	Name = "小窝",
	Character = 220002,
	Rarity = 4,
	Icon = 0,
	Node = "Sofa",
	Desc = "小窝",
}
RoomPieceConfig[RoomPieceID.Id144] =
{
	Id = 144,
	Name = "玩具架",
	Character = 220002,
	Rarity = 4,
	Icon = 0,
	Node = "Shelves",
	Desc = "玩具架",
}
RoomPieceConfig[RoomPieceID.Id145] =
{
	Id = 145,
	Name = "零食柜",
	Character = 220002,
	Rarity = 4,
	Icon = 0,
	Node = "Cabinet",
	Desc = "零食柜",
}
RoomPieceConfig[RoomPieceID.Id146] =
{
	Id = 146,
	Name = "猫爬架",
	Character = 220002,
	Rarity = 4,
	Icon = 0,
	Node = "Ornament_1",
	Desc = "猫爬架",
}
RoomPieceConfig[RoomPieceID.Id147] =
{
	Id = 147,
	Name = "绒毛球",
	Character = 220002,
	Rarity = 4,
	Icon = 0,
	Node = "Ornament_2",
	Desc = "绒毛球",
}
RoomPieceConfig[RoomPieceID.Id148] =
{
	Id = 148,
	Name = "呜呜的礼物",
	Character = 220002,
	Rarity = 4,
	Icon = 0,
	Node = "Ornament_3",
	Desc = "呜呜的礼物",
}
RoomPieceConfig[RoomPieceID.Id149] =
{
	Id = 149,
	Name = "薄荷草",
	Character = 220002,
	Rarity = 4,
	Icon = 0,
	Node = "Ornament_4",
	Desc = "薄荷草",
}
RoomPieceConfig[RoomPieceID.Id150] =
{
	Id = 150,
	Name = "小窗",
	Character = 220002,
	Rarity = 4,
	Icon = 0,
	Node = "Ornament_5",
	Desc = "小窗",
}
RoomPieceConfig[RoomPieceID.Id151] =
{
	Id = 151,
	Name = "太空服",
	Character = 220002,
	Rarity = 4,
	Icon = 0,
	Node = "Ornament_6",
	Desc = "太空服",
}
RoomPieceConfig[RoomPieceID.Id161] =
{
	Id = 161,
	Name = "传统壁纸",
	Gallery = 950101,
	Character = 223067,
	Rarity = 4,
	Icon = "Room_All_NewYearBeast_Wallpaper",
	Node = "Wallpaper",
	Desc = "喜气洋洋的节日壁纸，听说借鉴了蓝星传统的设计风格。暖暖的色调虽然少了点华丽的感觉，但是会让人有种家的温馨感。",
	Ability = {
		{
			Value = 200001,
			Num = 25,
		},
	},
}
RoomPieceConfig[RoomPieceID.Id162] =
{
	Id = 162,
	Name = "腊肉与火腿",
	Gallery = 950101,
	Character = 223067,
	Rarity = 4,
	Icon = "Room_All_NewYearBeast_Light",
	Node = "Light",
	Desc = "风干了一整年的腊肉和火腿，等年大人这次闹完年会来，就要煲着汤来喝的。",
	Ability = {
		{
			Value = 200001,
			Num = 25,
		},
	},
}
RoomPieceConfig[RoomPieceID.Id163] =
{
	Id = 163,
	Name = "太师椅",
	Gallery = 950101,
	Character = 223067,
	Rarity = 4,
	Icon = "Room_All_NewYearBeast_Sofa",
	Node = "Sofa",
	Desc = "多年前去蓝星闹新年时，从一个大型家具店里抢来的实木座椅，坐在上面的年大人看起来特别有威严。",
	Ability = {
		{
			Value = 200002,
			Num = 25,
		},
	},
}
RoomPieceConfig[RoomPieceID.Id164] =
{
	Id = 164,
	Name = "置物架",
	Gallery = 950101,
	Character = 223067,
	Rarity = 4,
	Icon = "Room_All_NewYearBeast_Shelves",
	Node = "Shelves",
	Desc = "铺上了充满年味的布帘的置物架，一下子让整个房间的气氛喜庆了起来。",
	Ability = {
		{
			Value = 200001,
			Num = 25,
		},
	},
}
RoomPieceConfig[RoomPieceID.Id165] =
{
	Id = 165,
	Name = "组合矮脚柜",
	Gallery = 950101,
	Character = 223067,
	Rarity = 4,
	Icon = "Room_All_NewYearBeast_Cabinet",
	Node = "Cabinet",
	Desc = "从蓝星抢回来的组合式矮脚柜，年大人看着说明书装了整整一个礼拜才装起来。不过完成的那一刻，他觉得充满了成就感。",
	Ability = {
		{
			Value = 200001,
			Num = 25,
		},
	},
}
RoomPieceConfig[RoomPieceID.Id166] =
{
	Id = 166,
	Name = "布偶虎",
	Gallery = 950101,
	Character = 223067,
	Rarity = 4,
	Icon = "Room_All_NewYearBeast_Ornament_1",
	Node = "Ornament_1",
	Desc = "小时候爷爷送给年大人的玩具，那时候还摸着年大人的头说，要他以后像老虎一样厉害。不过爷爷后来又说，厉不厉害都是我最宝贝的孙子。",
	Ability = {
		{
			Value = 200002,
			Num = 25,
		},
	},
}
RoomPieceConfig[RoomPieceID.Id167] =
{
	Id = 167,
	Name = "花鼓",
	Gallery = 950101,
	Character = 223067,
	Rarity = 4,
	Icon = "Room_All_NewYearBeast_Ornament_2",
	Node = "Ornament_2",
	Desc = "做工精致的花鼓，是年大人去其他星球闹新年后抢回来的收藏之一，敲击后发出的声音清脆又饱满。",
	Ability = {
		{
			Value = 200002,
			Num = 25,
		},
	},
}
RoomPieceConfig[RoomPieceID.Id168] =
{
	Id = 168,
	Name = "吉祥的点心",
	Gallery = 950101,
	Character = 223067,
	Rarity = 4,
	Icon = "Room_All_NewYearBeast_Ornament_3",
	Node = "Ornament_3",
	Desc = "用敲了三天三夜的糯米团子做成的美味点心，口感很有嚼劲，而且又蕴含着糯米独有的香甜。",
	Ability = {
		{
			Value = 200002,
			Num = 25,
		},
	},
}
RoomPieceConfig[RoomPieceID.Id169] =
{
	Id = 169,
	Name = "腊梅礼盒",
	Gallery = 950101,
	Character = 223067,
	Rarity = 4,
	Icon = "Room_All_NewYearBeast_Ornament_4",
	Node = "Ornament_4",
	Desc = "必须提前一个月预订才能买到的新年鲜花礼盒，使用了长势正盛的梅花制作而成。摆在家里的那一刻，会瞬间给家里满上浓浓的年味。",
	Ability = {
		{
			Value = 200002,
			Num = 25,
		},
	},
}
RoomPieceConfig[RoomPieceID.Id170] =
{
	Id = 170,
	Name = "良辰美景",
	Gallery = 950101,
	Character = 223067,
	Rarity = 4,
	Icon = "Room_All_NewYearBeast_Ornament_5",
	Node = "Ornament_5",
	Desc = "虽然嘴上说着讨厌过年，但是依然偷偷找装修师傅开凿的观景窗。推开古色古香的木窗户，就能看到街上的人山人海和吉祥灯笼。",
	Ability = {
		{
			Value = 200002,
			Num = 25,
		},
	},
}
RoomPieceConfig[RoomPieceID.Id171] =
{
	Id = 171,
	Name = "绣球",
	Gallery = 950101,
	Character = 223067,
	Rarity = 4,
	Icon = "Room_All_NewYearBeast_Ornament_6",
	Node = "Ornament_6",
	Desc = "从蓝星舞狮大会上抢来的绣球，听说拿到的人今年会运气很好，做什么事情都会很顺。",
	Ability = {
		{
			Value = 200002,
			Num = 25,
		},
	},
}
RoomPieceConfig[RoomPieceID.Id181] =
{
	Id = 181,
	Name = "酒窖壁纸",
	Gallery = 950002,
	Character = 223108,
	Rarity = 4,
	Icon = "Room_Fat_101_Brandy_Wallpaper",
	Node = "Wallpaper",
	Desc = "风格高雅且具有复古感的壁纸，与整个酒窖相得益彰，是由拜兰帝亲自挑选的。",
	Ability = {
		{
			Value = 200001,
			Num = 25,
		},
	},
}
RoomPieceConfig[RoomPieceID.Id182] =
{
	Id = 182,
	Name = "琉璃灯",
	Gallery = 950002,
	Character = 223108,
	Rarity = 4,
	Icon = "Room_Fat_101_Brandy_Light",
	Node = "Light",
	Desc = "五光十色的琉璃灯，可以随意调节灯光，但似乎只是装饰品，使用率非常低。",
	Ability = {
		{
			Value = 200002,
			Num = 25,
		},
	},
}
RoomPieceConfig[RoomPieceID.Id183] =
{
	Id = 183,
	Name = "复古椅",
	Gallery = 950002,
	Character = 223108,
	Rarity = 4,
	Icon = "Room_Fat_101_Brandy_Sofa",
	Node = "Sofa",
	Desc = "当拜兰帝品酒时，一定要坐在这把由红木制成的椅子上，才能进入美酒鉴赏家的最好状态。",
	Ability = {
		{
			Value = 200001,
			Num = 25,
		},
	},
}
RoomPieceConfig[RoomPieceID.Id184] =
{
	Id = 184,
	Name = "红木置物架",
	Gallery = 950002,
	Character = 223108,
	Rarity = 4,
	Icon = "Room_Fat_101_Brandy_Shelves",
	Node = "Shelves",
	Desc = "由红木做成的置物架，但为了美观，上面什么也没有放。",
	Ability = {
		{
			Value = 200001,
			Num = 25,
		},
	},
}
RoomPieceConfig[RoomPieceID.Id185] =
{
	Id = 185,
	Name = "酒桶柜",
	Gallery = 950002,
	Character = 223108,
	Rarity = 4,
	Icon = "Room_Fat_101_Brandy_Cabinet",
	Node = "Cabinet",
	Desc = "巨大的柜子，其中放置着许多橡木桶，桶里装着不知多少瓶红酒。",
	Ability = {
		{
			Value = 200001,
			Num = 25,
		},
	},
}
RoomPieceConfig[RoomPieceID.Id186] =
{
	Id = 186,
	Name = "冷藏柜",
	Gallery = 950002,
	Character = 223108,
	Rarity = 4,
	Icon = "Room_Fat_101_Brandy_Ornament_1",
	Node = "Ornament_1",
	Desc = "据说冷藏后的红酒口味更佳，但拜兰帝坚持，一次只能放置四瓶在其中。",
	Ability = {
		{
			Value = 200002,
			Num = 25,
		},
	},
}
RoomPieceConfig[RoomPieceID.Id187] =
{
	Id = 187,
	Name = "橡木桶",
	Gallery = 950002,
	Character = 223108,
	Rarity = 4,
	Icon = "Room_Fat_101_Brandy_Ornament_2",
	Node = "Ornament_2",
	Desc = "拜兰帝最喜欢的藏酒器具，花费重金从海外空运到自己庄园，不仅具有实用性，收藏价值也非常高。",
	Ability = {
		{
			Value = 200002,
			Num = 25,
		},
	},
}
RoomPieceConfig[RoomPieceID.Id188] =
{
	Id = 188,
	Name = "木制酒架",
	Gallery = 950002,
	Character = 223108,
	Rarity = 4,
	Icon = "Room_Fat_101_Brandy_Ornament_3",
	Node = "Ornament_3",
	Desc = "拜兰帝拥有木制、黄金、钻石等多种材质的酒架，在多番衡量之下，最终选择将木制酒架摆放出来。",
	Ability = {
		{
			Value = 200001,
			Num = 25,
		},
	},
}
RoomPieceConfig[RoomPieceID.Id189] =
{
	Id = 189,
	Name = "蒸酒器",
	Gallery = 950002,
	Character = 223108,
	Rarity = 4,
	Icon = "Room_Fat_101_Brandy_Ornament_4",
	Node = "Ornament_4",
	Desc = "价值不菲的蒸酒器，拜兰帝相信，只有通过自己的手酿造出来的酒，才是真正的好酒。",
	Ability = {
		{
			Value = 200001,
			Num = 25,
		},
	},
}
RoomPieceConfig[RoomPieceID.Id190] =
{
	Id = 190,
	Name = "彩绘玻璃",
	Gallery = 950002,
	Character = 223108,
	Rarity = 4,
	Icon = "Room_Fat_101_Brandy_Ornament_6",
	Node = "Ornament_5",
	Desc = "色彩斑斓的玻璃，上面刻着美丽的图像，虽然看起来像玻璃，但其实是拜兰帝最心爱的装饰品。",
	Ability = {
		{
			Value = 200002,
			Num = 25,
		},
	},
}
RoomPieceConfig[RoomPieceID.Id191] =
{
	Id = 191,
	Name = "木制酒箱",
	Gallery = 950002,
	Character = 223108,
	Rarity = 4,
	Icon = "Room_Fat_101_Brandy_Ornament_5",
	Node = "Ornament_6",
	Desc = "用价值不菲的沉香木制成的酒箱，散发出古典的香味。",
	Ability = {
		{
			Value = 200002,
			Num = 25,
		},
	},
}
RoomPieceConfig[RoomPieceID.Id201] =
{
	Id = 201,
	Name = "和风壁纸",
	Gallery = 950005,
	Character = 220429,
	Rarity = 4,
	Icon = "Room_Sea_20_shanhu_Wallpaper",
	Node = "Wallpaper",
	Desc = "和风风格的壁纸，是珊瑚阿卡目前最喜欢的风格。",
	Ability = {
		{
			Value = 200001,
			Num = 40,
		},
	},
}
RoomPieceConfig[RoomPieceID.Id202] =
{
	Id = 202,
	Name = "实木吊灯",
	Gallery = 950005,
	Character = 220429,
	Rarity = 4,
	Icon = "Room_Sea_20_shanhu_Light",
	Node = "Light",
	Desc = "以樟子松制成，发出温馨的暖色光芒，因为做工精巧，称其为艺术品也不为过。",
	Ability = {
		{
			Value = 200002,
			Num = 25,
		},
	},
}
RoomPieceConfig[RoomPieceID.Id203] =
{
	Id = 203,
	Name = "和室椅",
	Gallery = 950005,
	Character = 220429,
	Rarity = 4,
	Icon = "Room_Sea_20_shanhu_Sofa",
	Node = "Sofa",
	Desc = "颇具和风特色的无腿椅，因为阿卡非常喜欢，即便只能跪坐也很享受。",
	Ability = {
		{
			Value = 200002,
			Num = 40,
		},
	},
}
RoomPieceConfig[RoomPieceID.Id204] =
{
	Id = 204,
	Name = "和风置物架",
	Gallery = 950005,
	Character = 220429,
	Rarity = 4,
	Icon = "Room_Sea_20_shanhu_Shelves",
	Node = "Shelves",
	Desc = "昂贵的木材做成的置物架，据说要三个壮汉才能抬动。",
	Ability = {
		{
			Value = 200001,
			Num = 25,
		},
	},
}
RoomPieceConfig[RoomPieceID.Id205] =
{
	Id = 205,
	Name = "榻榻米茶桌",
	Gallery = 950005,
	Character = 220429,
	Rarity = 4,
	Icon = "Room_Sea_20_shanhu_Cabinet",
	Node = "Cabinet",
	Desc = "由阿卡亲自挑选的茶桌，在这里饮茶，别有一番风味。",
	Ability = {
		{
			Value = 200001,
			Num = 25,
		},
	},
}
RoomPieceConfig[RoomPieceID.Id206] =
{
	Id = 206,
	Name = "坐垫",
	Gallery = 950005,
	Character = 220429,
	Rarity = 4,
	Icon = "Room_Sea_20_shanhu_Ornament_1",
	Node = "Ornament_1",
	Desc = "客人专属的榻榻米坐垫，但因为要跪着，并不能给客人很好的做客体验。",
	Ability = {
		{
			Value = 200001,
			Num = 40,
		},
	},
}
RoomPieceConfig[RoomPieceID.Id207] =
{
	Id = 207,
	Name = "木制展览柜",
	Gallery = 950005,
	Character = 220429,
	Rarity = 4,
	Icon = "Room_Sea_20_shanhu_Ornament_2",
	Node = "Ornament_2",
	Desc = "红木制成的展览柜，上面摆放着许多珍品，每一件都价值不菲。",
	Ability = {
		{
			Value = 200002,
			Num = 25,
		},
	},
}
RoomPieceConfig[RoomPieceID.Id208] =
{
	Id = 208,
	Name = "茶具",
	Gallery = 950005,
	Character = 220429,
	Rarity = 4,
	Icon = "Room_Sea_20_shanhu_Ornament_3",
	Node = "Ornament_3",
	Desc = "茶桌上摆放的茶具，需要小心触碰，有被烫伤的风险。",
	Ability = {
		{
			Value = 200002,
			Num = 25,
		},
	},
}
RoomPieceConfig[RoomPieceID.Id209] =
{
	Id = 209,
	Name = "富士山屏风",
	Gallery = 950005,
	Character = 220429,
	Rarity = 4,
	Icon = "Room_Sea_20_shanhu_Ornament_4",
	Node = "Ornament_4",
	Desc = "画着富士山的屏风，具有浓厚的和风气息，仿佛真的生活下富士山下。",
	Ability = {
		{
			Value = 200002,
			Num = 25,
		},
	},
}
RoomPieceConfig[RoomPieceID.Id210] =
{
	Id = 210,
	Name = "珊瑚雕塑",
	Gallery = 950005,
	Character = 220429,
	Rarity = 4,
	Icon = "Room_Sea_20_shanhu_Ornament_5",
	Node = "Ornament_5",
	Desc = "白色的珊瑚状雕塑，据说是阿卡的父亲花费重金，请某位海洋艺术家雕刻而成的。",
	Ability = {
		{
			Value = 200002,
			Num = 40,
		},
	},
}
RoomPieceConfig[RoomPieceID.Id211] =
{
	Id = 211,
	Name = "腰付障子",
	Gallery = 950005,
	Character = 220429,
	Rarity = 4,
	Icon = "Room_Sea_20_shanhu_Ornament_6",
	Node = "Ornament_6",
	Desc = "因为是纸糊窗户，所以很难看清外面的景色，不过倒是省去了被狗仔偷拍的烦恼。",
	Ability = {
		{
			Value = 200002,
			Num = 25,
		},
	},
}
RoomPieceConfig[RoomPieceID.Id221] =
{
	Id = 221,
	Name = "海洋壁纸",
	Gallery = 950005,
	Character = 220430,
	Rarity = 4,
	Icon = "Room_Sea_14_hujing_Wallpaper",
	Node = "Wallpaper",
	Desc = "充满海洋气息的蓝白色壁纸，能从落地窗前看到海底风景。",
	Ability = {
		{
			Value = 200001,
			Num = 25,
		},
	},
}
RoomPieceConfig[RoomPieceID.Id222] =
{
	Id = 222,
	Name = "飞机模型",
	Gallery = 950005,
	Character = 220430,
	Rarity = 4,
	Icon = "Room_Sea_14_hujing_Light",
	Node = "Light",
	Desc = "京小时候，爸爸送给自己的玩具，虽然从小到大都没有碰过几次。",
	Ability = {
		{
			Value = 200002,
			Num = 40,
		},
	},
}
RoomPieceConfig[RoomPieceID.Id223] =
{
	Id = 223,
	Name = "真皮沙发",
	Gallery = 950005,
	Character = 220430,
	Rarity = 4,
	Icon = "Room_Sea_14_hujing_Sofa",
	Node = "Sofa",
	Desc = "点缀着黄色花朵的蓝色沙发，坐上去非常舒适。",
	Ability = {
		{
			Value = 200001,
			Num = 40,
		},
	},
}
RoomPieceConfig[RoomPieceID.Id224] =
{
	Id = 224,
	Name = "白瓷置物架",
	Gallery = 950005,
	Character = 220430,
	Rarity = 4,
	Icon = "Room_Sea_14_hujing_Shelves",
	Node = "Shelves",
	Desc = "用白瓷制成了置物架，珍贵且易碎，上面放着京心爱的物件。",
	Ability = {
		{
			Value = 200001,
			Num = 25,
		},
	},
}
RoomPieceConfig[RoomPieceID.Id225] =
{
	Id = 225,
	Name = "矮柜",
	Gallery = 950005,
	Character = 220430,
	Rarity = 4,
	Icon = "Room_Sea_14_hujing_Cabinet",
	Node = "Cabinet",
	Desc = "低矮狭长的柜子，其中放着京的书籍和纪念册。",
	Ability = {
		{
			Value = 200001,
			Num = 25,
		},
	},
}
RoomPieceConfig[RoomPieceID.Id226] =
{
	Id = 226,
	Name = "荣誉墙",
	Gallery = 950005,
	Character = 220430,
	Rarity = 4,
	Icon = "Room_Sea_14_hujing_Ornament_1",
	Node = "Ornament_1",
	Desc = "京的父亲曾获得了许多奖章，为了让孩子感受到这份荣誉，直接把荣誉墙搬到了TA的房间。",
	Ability = {
		{
			Value = 200002,
			Num = 25,
		},
	},
}
RoomPieceConfig[RoomPieceID.Id227] =
{
	Id = 227,
	Name = "向日葵",
	Gallery = 950005,
	Character = 220430,
	Rarity = 4,
	Icon = "Room_Sea_14_hujing_Ornament_2",
	Node = "Ornament_2",
	Desc = "盛开的向日葵，花语是太阳、光明和沉默的爱。",
	Ability = {
		{
			Value = 200002,
			Num = 25,
		},
	},
}
RoomPieceConfig[RoomPieceID.Id228] =
{
	Id = 228,
	Name = "黄蝉花",
	Gallery = 950005,
	Character = 220430,
	Rarity = 4,
	Icon = "Room_Sea_14_hujing_Ornament_3",
	Node = "Ornament_3",
	Desc = "美丽的黄蝉花，是京特意选购的，但据说要明亮的光照才能生存，京正为此正不断努力。",
	Ability = {
		{
			Value = 200001,
			Num = 25,
		},
	},
}
RoomPieceConfig[RoomPieceID.Id229] =
{
	Id = 229,
	Name = "书本",
	Gallery = 950005,
	Character = 220430,
	Rarity = 4,
	Icon = "Room_Sea_14_hujing_Ornament_4",
	Node = "Ornament_4",
	Desc = "封面写着《偶像的自我修养》，书页已经泛黄，似乎翻阅了很多次。",
	Ability = {
		{
			Value = 200001,
			Num = 25,
		},
	},
}
RoomPieceConfig[RoomPieceID.Id230] =
{
	Id = 230,
	Name = "落地灯",
	Gallery = 950005,
	Character = 220430,
	Rarity = 4,
	Icon = "Room_Sea_14_hujing_Ornament_5",
	Node = "Ornament_5",
	Desc = "蓝色的落地灯，发出美丽的柔和的光芒，让房间的氛围感瞬间提升。",
	Ability = {
		{
			Value = 200001,
			Num = 25,
		},
	},
}
RoomPieceConfig[RoomPieceID.Id231] =
{
	Id = 231,
	Name = "旧照片",
	Gallery = 950005,
	Character = 220430,
	Rarity = 4,
	Icon = "Room_Sea_14_hujing_Ornament_6",
	Node = "Ornament_6",
	Desc = "sharkalaka的照片，照片上的场景，是京最喜欢的一次演出。",
	Ability = {
		{
			Value = 200001,
			Num = 20,
		},
		{
			Value = 200002,
			Num = 20,
		},
	},
}
RoomPieceConfig[RoomPieceID.Id241] =
{
	Id = 241,
	Name = "酒窖壁纸",
	Character = 220431,
	Rarity = 4,
	Icon = "Room_Sea_31_meirenyu_Wallpaper",
	Node = "Wallpaper",
	Desc = "风格高雅且具有复古感的壁纸，与整个酒窖相得益彰，是由人鱼清音亲自挑选的。",
	Ability = {
		{
			Value = 200001,
			Num = 25,
		},
	},
}
RoomPieceConfig[RoomPieceID.Id242] =
{
	Id = 242,
	Name = "琉璃灯",
	Character = 220431,
	Rarity = 4,
	Icon = "Room_Sea_31_meirenyu_Light",
	Node = "Light",
	Desc = "五光十色的琉璃灯，可以随意调节灯光，但似乎只是装饰品，使用率非常低。",
	Ability = {
		{
			Value = 200002,
			Num = 25,
		},
	},
}
RoomPieceConfig[RoomPieceID.Id243] =
{
	Id = 243,
	Name = "复古椅",
	Character = 220431,
	Rarity = 4,
	Icon = "Room_Sea_31_meirenyu_Sofa",
	Node = "Sofa",
	Desc = "当人鱼清音品酒时，一定要坐在这把由红木制成的椅子上，才能进入美酒鉴赏家的最好状态。",
	Ability = {
		{
			Value = 200001,
			Num = 25,
		},
	},
}
RoomPieceConfig[RoomPieceID.Id244] =
{
	Id = 244,
	Name = "红木置物架",
	Character = 220431,
	Rarity = 4,
	Icon = "Room_Sea_31_meirenyu_Shelves",
	Node = "Shelves",
	Desc = "由红木做成的置物架，但为了美观，上面什么也没有放。",
	Ability = {
		{
			Value = 200001,
			Num = 25,
		},
	},
}
RoomPieceConfig[RoomPieceID.Id245] =
{
	Id = 245,
	Name = "酒桶柜",
	Character = 220431,
	Rarity = 4,
	Icon = "Room_Sea_31_meirenyu_Cabinet",
	Node = "Cabinet",
	Desc = "巨大的柜子，其中放置着许多橡木桶，桶里装着不知多少瓶红酒。",
	Ability = {
		{
			Value = 200001,
			Num = 25,
		},
	},
}
RoomPieceConfig[RoomPieceID.Id246] =
{
	Id = 246,
	Name = "冷藏柜",
	Character = 220431,
	Rarity = 4,
	Icon = "Room_Sea_31_meirenyu_Ornament_1",
	Node = "Ornament_1",
	Desc = "据说冷藏后的红酒口味更佳，但人鱼清音坚持，一次只能放置四瓶在其中。",
	Ability = {
		{
			Value = 200002,
			Num = 25,
		},
	},
}
RoomPieceConfig[RoomPieceID.Id247] =
{
	Id = 247,
	Name = "橡木桶",
	Character = 220431,
	Rarity = 4,
	Icon = "Room_Sea_31_meirenyu_Ornament_2",
	Node = "Ornament_2",
	Desc = "人鱼清音最喜欢的藏酒器具，花费重金从海外空运到自己庄园，不仅具有实用性，收藏价值也非常高。",
	Ability = {
		{
			Value = 200002,
			Num = 25,
		},
	},
}
RoomPieceConfig[RoomPieceID.Id248] =
{
	Id = 248,
	Name = "木制酒架",
	Character = 220431,
	Rarity = 4,
	Icon = "Room_Sea_31_meirenyu_Ornament_3",
	Node = "Ornament_3",
	Desc = "人鱼清音拥有木制、黄金、钻石等多种材质的酒架，在多番衡量之下，最终选择将木制酒架摆放出来。",
	Ability = {
		{
			Value = 200001,
			Num = 25,
		},
	},
}
RoomPieceConfig[RoomPieceID.Id249] =
{
	Id = 249,
	Name = "蒸酒器",
	Character = 220431,
	Rarity = 4,
	Icon = "Room_Sea_31_meirenyu_Ornament_4",
	Node = "Ornament_4",
	Desc = "价值不菲的蒸酒器，人鱼清音相信，只有通过自己的手酿造出来的酒，才是真正的好酒。",
	Ability = {
		{
			Value = 200001,
			Num = 25,
		},
	},
}
RoomPieceConfig[RoomPieceID.Id250] =
{
	Id = 250,
	Name = "彩绘玻璃",
	Character = 220431,
	Rarity = 4,
	Icon = "Room_Sea_31_meirenyu_Ornament_5",
	Node = "Ornament_5",
	Desc = "色彩斑斓的玻璃，上面刻着美丽的图像，虽然看起来像玻璃，但其实是人鱼清音最心爱的装饰品。",
	Ability = {
		{
			Value = 200002,
			Num = 25,
		},
	},
}
RoomPieceConfig[RoomPieceID.Id251] =
{
	Id = 251,
	Name = "木制酒箱",
	Character = 220431,
	Rarity = 4,
	Icon = "Room_Sea_31_meirenyu_Ornament_6",
	Node = "Ornament_6",
	Desc = "用价值不菲的沉香木制成的酒箱，散发出古典的香味。",
	Ability = {
		{
			Value = 200002,
			Num = 25,
		},
	},
}
RoomPieceConfig[RoomPieceID.Id261] =
{
	Id = 261,
	Name = "雕花壁纸",
	Gallery = 950101,
	Character = 223124,
	Rarity = 4,
	Icon = "Room_SPBUS_07_quyuan_Wallpaper",
	Node = "Wallpaper",
	Desc = "墨绿色的窗户上刻满了雕花格子，阳光透过窗户照进来时，也被分成大小不一的形状碎片。",
	Ability = {
		{
			Value = 200002,
			Num = 25,
		},
	},
}
RoomPieceConfig[RoomPieceID.Id262] =
{
	Id = 262,
	Name = "竹制青灯",
	Gallery = 950101,
	Character = 223124,
	Rarity = 4,
	Icon = "Room_SPBUS_07_quyuan_Light",
	Node = "Light",
	Desc = "表面是竹子一样翠绿的颜色，打开后会在灵均的头顶发出绿绿的亮光。",
	Ability = {
		{
			Value = 200002,
			Num = 25,
		},
	},
}
RoomPieceConfig[RoomPieceID.Id263] =
{
	Id = 263,
	Name = "鼓式座椅",
	Gallery = 950101,
	Character = 223124,
	Rarity = 4,
	Icon = "Room_SPBUS_07_quyuan_Sofa",
	Node = "Sofa",
	Desc = "远远看去是一只大鼓，凑近了看才知道，原来是一把椅子。",
	Ability = {
		{
			Value = 200001,
			Num = 25,
		},
	},
}
RoomPieceConfig[RoomPieceID.Id264] =
{
	Id = 264,
	Name = "竹制置物架",
	Gallery = 950101,
	Character = 223124,
	Rarity = 4,
	Icon = "Room_SPBUS_07_quyuan_Shelves",
	Node = "Shelves",
	Desc = "用竹子做成的置物架，上面印着点点斑痕，轻轻敲上去，还能听到清脆的叮咚声。",
	Ability = {
		{
			Value = 200001,
			Num = 25,
		},
	},
}
RoomPieceConfig[RoomPieceID.Id265] =
{
	Id = 265,
	Name = "定制龙舟",
	Gallery = 950101,
	Character = 223124,
	Rarity = 4,
	Icon = "Room_SPBUS_07_quyuan_Cabinet",
	Node = "Cabinet",
	Desc = "好友送给灵均的定制龙舟，龙头可以作为装饰，龙身可以作为置物柜，一举两得。",
	Ability = {
		{
			Value = 200001,
			Num = 25,
		},
		{
			Value = 200002,
			Num = 25,
		},
	},
}
RoomPieceConfig[RoomPieceID.Id266] =
{
	Id = 266,
	Name = "特制船桨",
	Gallery = 950101,
	Character = 223124,
	Rarity = 4,
	Icon = "Room_SPBUS_07_quyuan_Ornament_4",
	Node = "Ornament_4",
	Desc = "白竹制成的船桨，和特制龙舟本是一套，现在放在房间中积灰。",
	Ability = {
		{
			Value = 200002,
			Num = 25,
		},
	},
}
RoomPieceConfig[RoomPieceID.Id267] =
{
	Id = 267,
	Name = "荷叶荷花",
	Gallery = 950101,
	Character = 223124,
	Rarity = 4,
	Icon = "Room_SPBUS_07_quyuan_Ornament_1",
	Node = "Ornament_1",
	Desc = "插在波浪地毯中的荷叶与荷花，材质未知，但仿佛能闻到花的清香。",
	Ability = {
		{
			Value = 200002,
			Num = 25,
		},
	},
}
RoomPieceConfig[RoomPieceID.Id268] =
{
	Id = 268,
	Name = "粽子盆",
	Gallery = 950101,
	Character = 223124,
	Rarity = 4,
	Icon = "Room_SPBUS_07_quyuan_Ornament_3",
	Node = "Ornament_3",
	Desc = "装满粽子的盆子，每个粽子都包裹得严严实实的，据说拆起来还有点麻烦。",
	Ability = {
		{
			Value = 200001,
			Num = 25,
		},
	},
}
RoomPieceConfig[RoomPieceID.Id269] =
{
	Id = 269,
	Name = "雄黄酒坛",
	Gallery = 950101,
	Character = 223124,
	Rarity = 4,
	Icon = "Room_SPBUS_07_quyuan_Ornament_2",
	Node = "Ornament_2",
	Desc = "堆在一起的酒坛，里面装着雄黄酒，每当朋友问灵均，什么时候让兄弟们尝尝好酒的时候，他总会说“下次一定”。",
	Ability = {
		{
			Value = 200001,
			Num = 25,
		},
		{
			Value = 200002,
			Num = 25,
		},
	},
}
RoomPieceConfig[RoomPieceID.Id270] =
{
	Id = 270,
	Name = "离骚挂画",
	Gallery = 950101,
	Character = 223124,
	Rarity = 4,
	Icon = "Room_SPBUS_07_quyuan_Ornament_6",
	Node = "Ornament_6",
	Desc = "墙上的挂画，上面似乎少了一个字，但前来房间参观的客人，竟然都觉得很合理。",
	Ability = {
		{
			Value = 200002,
			Num = 25,
		},
	},
}
RoomPieceConfig[RoomPieceID.Id271] =
{
	Id = 271,
	Name = "兰花",
	Gallery = 950101,
	Character = 223124,
	Rarity = 4,
	Icon = "Room_SPBUS_07_quyuan_Ornament_5",
	Node = "Ornament_5",
	Desc = "挂在墙上的兰花，是灵均最喜欢的花草之一。",
	Ability = {
		{
			Value = 200002,
			Num = 25,
		},
	},
}
RoomPieceConfig[RoomPieceID.Id281] =
{
	Id = 281,
	Name = "雪花墙纸",
	Character = 223141,
	Rarity = 4,
	Icon = "Room_SPBUS_24_XueShen_Wallpaper",
	Node = "Wallpaper",
	Desc = "深蓝色的墙纸，上面印着雪花形状的暗纹。",
}
RoomPieceConfig[RoomPieceID.Id282] =
{
	Id = 282,
	Name = "冰雕灯",
	Character = 223141,
	Rarity = 4,
	Icon = "Room_SPBUS_24_XueShen_Light",
	Node = "Light",
	Desc = "雪花形态的冰雕灯，光线遇到冰发生折射现象，远远看去，一片五彩斑斓。",
}
RoomPieceConfig[RoomPieceID.Id283] =
{
	Id = 283,
	Name = "冰之王座",
	Character = 223141,
	Rarity = 4,
	Icon = "Room_SPBUS_24_XueShen_Sofa",
	Node = "Sofa",
	Desc = "高贵的椅子，名字叫“冰之王座”——真是个中二的名字啊。",
}
RoomPieceConfig[RoomPieceID.Id284] =
{
	Id = 284,
	Name = "冰棱置物架",
	Character = 223141,
	Rarity = 4,
	Icon = "Room_SPBUS_24_XueShen_Shelves",
	Node = "Shelves",
	Desc = "放重要物品的置物架，由终年不化的冰雪制成，底部还有锋利的冰棱，可以当做武器。",
}
RoomPieceConfig[RoomPieceID.Id285] =
{
	Id = 285,
	Name = "雪色茶几",
	Character = 223141,
	Rarity = 4,
	Icon = "Room_SPBUS_24_XueShen_Cabinet",
	Node = "Cabinet",
	Desc = "一张优雅美丽的茶几，上面摆放着烛台和小鸭子装饰品。\n烛台燃烧着可以降温的冰火。",
}
RoomPieceConfig[RoomPieceID.Id286] =
{
	Id = 286,
	Name = "小精灵",
	Character = 223141,
	Rarity = 4,
	Icon = "Room_SPBUS_24_XueShen_Ornament_1",
	Node = "Ornament_1",
	Desc = "雪景中的小精灵，散发出微弱的光芒。被雪神抓来，和她一起生活在房间中。",
}
RoomPieceConfig[RoomPieceID.Id287] =
{
	Id = 287,
	Name = "一只雪狐",
	Character = 223141,
	Rarity = 4,
	Icon = "Room_SPBUS_24_XueShen_Ornament_2",
	Node = "Ornament_2",
	Desc = "毛茸茸的雪狐，惬意地趴在暖和的窝里，当他觉得热的时候，会主动到雪神身边蹭蹭。",
}
RoomPieceConfig[RoomPieceID.Id288] =
{
	Id = 288,
	Name = "毛绒冰珊瑚",
	Character = 223141,
	Rarity = 4,
	Icon = "Room_SPBUS_24_XueShen_Ornament_3",
	Node = "Ornament_3",
	Desc = "冰蓝色的珊瑚装饰物，上面挂着一些毛球，这样看起来更有冬天的感觉。",
}
RoomPieceConfig[RoomPieceID.Id289] =
{
	Id = 289,
	Name = "旋转楼梯",
	Character = 223141,
	Rarity = 4,
	Icon = "Room_SPBUS_24_XueShen_Ornament_4",
	Node = "Ornament_4",
	Desc = "铺满雪的旋转楼梯，曾有客人以为楼梯上涂着冰淇淋，好奇一舔，舌头就黏在了楼梯栏杆上。",
}
RoomPieceConfig[RoomPieceID.Id290] =
{
	Id = 290,
	Name = "夜的窗户",
	Character = 223141,
	Rarity = 4,
	Icon = "Room_SPBUS_24_XueShen_Ornament_5",
	Node = "Ornament_5",
	Desc = "一扇极暗的窗，从房间里，能窥见窗外如墨一般浓郁的夜空。",
}
RoomPieceConfig[RoomPieceID.Id291] =
{
	Id = 291,
	Name = "蓝色毛地毯",
	Character = 223141,
	Rarity = 4,
	Icon = "Room_SPBUS_24_XueShen_Ornament_6",
	Node = "Ornament_6",
	Desc = "蓝色的毛地毯，虽然它的质地和以“冰”为主题的房间不太搭配，但雪神喜欢走在松软的地上，做足心理建设后毅然选择了它。",
}
RoomPieceConfig[RoomPieceID.Id301] =
{
	Id = 301,
	Name = "后厨墙纸",
	Gallery = 950101,
	Character = 223142,
	Rarity = 4,
	Icon = "Room_SPBUS_25_MaoYanChuNiang_Wallpaper",
	Node = "Wallpaper",
	Desc = "淡黄的墙纸，下方印上了砖块纹理，据说这种墙纸对于油污有强烈的抵御能力。",
	Ability = {
		{
			Value = 200002,
			Num = 25,
		},
	},
}
RoomPieceConfig[RoomPieceID.Id302] =
{
	Id = 302,
	Name = "吊兰灯",
	Gallery = 950101,
	Character = 223142,
	Rarity = 4,
	Icon = "Room_SPBUS_25_MaoYanChuNiang_Light",
	Node = "Light",
	Desc = "与旁边的吊兰完美搭配的吊灯，发出暖黄色的光芒，不过吊兰叶子偶尔也会爬上灯，需要小厨娘亲自修剪。",
	Ability = {
		{
			Value = 200002,
			Num = 25,
		},
	},
}
RoomPieceConfig[RoomPieceID.Id303] =
{
	Id = 303,
	Name = "红丝绒餐椅",
	Gallery = 950101,
	Character = 223142,
	Rarity = 4,
	Icon = "Room_SPBUS_25_MaoYanChuNiang_Sofa",
	Node = "Sofa",
	Desc = "丝绒质地的红色餐椅，上面还放着一块靠枕……只是看着，就想上去坐一坐了。",
	Ability = {
		{
			Value = 200002,
			Num = 25,
		},
	},
}
RoomPieceConfig[RoomPieceID.Id304] =
{
	Id = 304,
	Name = "后厨置物柜",
	Gallery = 950101,
	Character = 223142,
	Rarity = 4,
	Icon = "Room_SPBUS_25_MaoYanChuNiang_Shelves",
	Node = "Shelves",
	Desc = "放各种物件的置物柜，因为柜内的空间被一些奇怪的装备占据了，只好把各类锅铲菜板挂在柜子下方。",
	Ability = {
		{
			Value = 200001,
			Num = 25,
		},
		{
			Value = 200002,
			Num = 25,
		},
	},
}
RoomPieceConfig[RoomPieceID.Id305] =
{
	Id = 305,
	Name = "甜品台橱柜",
	Gallery = 950101,
	Character = 223142,
	Rarity = 4,
	Icon = "Room_SPBUS_25_MaoYanChuNiang_Cabinet",
	Node = "Cabinet",
	Desc = "既是放置物品的橱柜，也是猫眼厨娘的专属梦幻甜品台，在这里她完成过很多次成功的甜品创造实验。",
	Ability = {
		{
			Value = 200001,
			Num = 25,
		},
	},
}
RoomPieceConfig[RoomPieceID.Id306] =
{
	Id = 306,
	Name = "防滑地毯",
	Gallery = 950101,
	Character = 223142,
	Rarity = 4,
	Icon = "Room_SPBUS_25_MaoYanChuNiang_Ornament_1",
	Node = "Ornament_1",
	Desc = "在猫眼厨娘的餐厅中被广泛运用的防滑减震地毯，即便真的摔倒了，也不会觉得疼。",
	Ability = {
		{
			Value = 200002,
			Num = 25,
		},
	},
}
RoomPieceConfig[RoomPieceID.Id307] =
{
	Id = 307,
	Name = "卷帘窗",
	Gallery = 950101,
	Character = 223142,
	Rarity = 4,
	Icon = "Room_SPBUS_25_MaoYanChuNiang_Ornament_2",
	Node = "Ornament_2",
	Desc = "一扇卷帘窗，把窗帘拉上去，可以看到屋外的宁静山色。在黄昏下做一道美味的菜，就是小厨娘最开心的事情。",
	Ability = {
		{
			Value = 200001,
			Num = 25,
		},
		{
			Value = 200002,
			Num = 25,
		},
	},
}
RoomPieceConfig[RoomPieceID.Id308] =
{
	Id = 308,
	Name = "挂钩架",
	Gallery = 950101,
	Character = 223142,
	Rarity = 4,
	Icon = "Room_SPBUS_25_MaoYanChuNiang_Ornament_3",
	Node = "Ornament_3",
	Desc = "用于收纳的挂钩架，无论是袋子还是围裙，只要是可以挂的东西，都会出现在这上面。",
	Ability = {
		{
			Value = 200001,
			Num = 25,
		},
	},
}
RoomPieceConfig[RoomPieceID.Id309] =
{
	Id = 309,
	Name = "碗碟橱柜",
	Gallery = 950101,
	Character = 223142,
	Rarity = 4,
	Icon = "Room_SPBUS_25_MaoYanChuNiang_Ornament_4",
	Node = "Ornament_4",
	Desc = "存放碗碟和各色调料的橱柜，猫眼厨娘会不会也把糖和盐弄混过呢？",
	Ability = {
		{
			Value = 200001,
			Num = 25,
		},
	},
}
RoomPieceConfig[RoomPieceID.Id310] =
{
	Id = 310,
	Name = "多功能灶台",
	Gallery = 950101,
	Character = 223142,
	Rarity = 4,
	Icon = "Room_SPBUS_25_MaoYanChuNiang_Ornament_5",
	Node = "Ornament_5",
	Desc = "上面是做菜烧水的灶台，下面是烤箱，虽然占据面具不大，但也算得上五脏俱全。",
	Ability = {
		{
			Value = 200001,
			Num = 25,
		},
		{
			Value = 200002,
			Num = 25,
		},
	},
}
RoomPieceConfig[RoomPieceID.Id311] =
{
	Id = 311,
	Name = "冰箱",
	Gallery = 950101,
	Character = 223142,
	Rarity = 4,
	Icon = "Room_SPBUS_25_MaoYanChuNiang_Ornament_6",
	Node = "Ornament_6",
	Desc = "装饰着贴纸的小冰箱，据说其中食物的存放期限最多不超过三天。",
	Ability = {
		{
			Value = 200002,
			Num = 25,
		},
	},
}

