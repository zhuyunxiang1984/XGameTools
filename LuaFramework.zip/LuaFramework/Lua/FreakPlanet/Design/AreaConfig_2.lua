
AreaConfig[AreaID.Id051] =
{
	Id = 51,
	Name = "着陆点",
	Planet = 120002,
	Level = 25,
	AreaElement = 210003,
	NumCap = 5,
	Map = "FAT_map_01",
	LevelIcon = "Icon_FATBG02",
	LevelBG = "FATBG02",
	LevelAtlas = "EventBG",
	LevelBundle = "packed_eventbg",
	StartScene = "FAT_StartScene",
	LevelEnemy = {
		{
			NeedChallenge = 140201,
			Enemy = {
				{
					Value = 242028,
					Level = 50,
					Weight = 1000,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 100,
					FightPower = 3500,
				},
			},
		},
		{
			Enemy = {
				{
					Value = 242028,
					Level = 50,
					Weight = 1000,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 200,
					FightPower = 3500,
				},
			},
		},
	},
	Challenge = {
		140201,
	},
}
AreaConfig[AreaID.Id052] =
{
	Id = 52,
	Name = "鲷鱼镇",
	Planet = 120002,
	Level = 27,
	AreaElement = 210001,
	NumCap = 5,
	Map = "FAT_map_02",
	LevelIcon = "Icon_FATBG04",
	LevelBG = "FATBG04",
	LevelAtlas = "EventBG",
	LevelBundle = "packed_eventbg",
	StartScene = "FAT_StartScene",
	LevelEnemy = {
		{
			NeedChallenge = 140203,
			Enemy = {
				{
					Value = 242028,
					Level = 50,
					Weight = 294,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 200,
					FightPower = 3500,
				},
				{
					Value = 242032,
					Level = 54,
					Weight = 352,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 240,
					FightPower = 4700,
					NeedElementList = {
						{
							Element = 210002,
							Count = 1,
						},
					},
				},
				{
					Value = 242033,
					Level = 58,
					Weight = 352,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 240,
					FightPower = 5000,
					NeedElementList = {
						{
							Element = 210001,
							Count = 1,
						},
					},
				},
			},
		},
		{
			NeedChallenge = 140202,
			Enemy = {
				{
					Value = 242028,
					Level = 50,
					Weight = 294,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 200,
					FightPower = 3500,
				},
				{
					Value = 242032,
					Level = 54,
					Weight = 352,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 240,
					FightPower = 4700,
					NeedElementList = {
						{
							Element = 210002,
							Count = 1,
						},
					},
				},
			},
		},
		{
			Enemy = {
				{
					Value = 242028,
					Level = 50,
					Weight = 294,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 200,
					FightPower = 3500,
				},
			},
		},
	},
	Challenge = {
		140202,
		140203,
	},
	EventList = {
		310201,
		310202,
		310203,
		310204,
	},
}
AreaConfig[AreaID.Id053] =
{
	Id = 53,
	Name = "冰淇淋港",
	Planet = 120002,
	Level = 33,
	AreaElement = 210001,
	NumCap = 5,
	Map = "FAT_map_03",
	LevelIcon = "Icon_FATBG03",
	LevelBG = "FATBG03",
	LevelAtlas = "EventBG",
	LevelBundle = "packed_eventbg",
	StartScene = "FAT_StartScene",
	LevelEnemy = {
		{
			NeedChallenge = 140207,
			Enemy = {
				{
					Value = 242028,
					Level = 55,
					Weight = 172,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 100,
					FightPower = 3500,
				},
				{
					Value = 242032,
					Level = 59,
					Weight = 206,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 240,
					FightPower = 4700,
					NeedElementList = {
						{
							Element = 210002,
							Count = 1,
						},
					},
				},
				{
					Value = 242034,
					Level = 64,
					Weight = 206,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 240,
					FightPower = 5500,
					NeedElementList = {
						{
							Element = 210002,
							Count = 1,
						},
						{
							Element = 210004,
							Count = 1,
						},
					},
				},
				{
					Value = 242035,
					Level = 69,
					Weight = 206,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 240,
					FightPower = 5900,
					NeedElementList = {
						{
							Element = 210002,
							Count = 1,
						},
						{
							Element = 210003,
							Count = 1,
						},
					},
				},
				{
					Value = 242036,
					Level = 74,
					Weight = 206,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 240,
					FightPower = 6300,
					NeedElementList = {
						{
							Element = 210002,
							Count = 1,
						},
						{
							Element = 210005,
							Count = 1,
						},
					},
				},
			},
		},
		{
			NeedChallenge = 140206,
			Enemy = {
				{
					Value = 242028,
					Level = 55,
					Weight = 172,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 100,
					FightPower = 3500,
				},
				{
					Value = 242032,
					Level = 59,
					Weight = 206,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 240,
					FightPower = 4700,
					NeedElementList = {
						{
							Element = 210002,
							Count = 1,
						},
					},
				},
				{
					Value = 242034,
					Level = 64,
					Weight = 206,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 240,
					FightPower = 5500,
					NeedElementList = {
						{
							Element = 210002,
							Count = 1,
						},
						{
							Element = 210004,
							Count = 1,
						},
					},
				},
				{
					Value = 242035,
					Level = 69,
					Weight = 206,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 240,
					FightPower = 5900,
					NeedElementList = {
						{
							Element = 210002,
							Count = 1,
						},
						{
							Element = 210003,
							Count = 1,
						},
					},
				},
				{
					Value = 242036,
					Level = 74,
					Weight = 206,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 240,
					FightPower = 6300,
					NeedElementList = {
						{
							Element = 210002,
							Count = 1,
						},
						{
							Element = 210005,
							Count = 1,
						},
					},
				},
			},
		},
		{
			NeedChallenge = 140205,
			Enemy = {
				{
					Value = 242028,
					Level = 55,
					Weight = 172,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 100,
					FightPower = 3500,
				},
				{
					Value = 242032,
					Level = 59,
					Weight = 206,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 240,
					FightPower = 4700,
					NeedElementList = {
						{
							Element = 210002,
							Count = 1,
						},
					},
				},
				{
					Value = 242034,
					Level = 64,
					Weight = 206,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 240,
					FightPower = 5500,
					NeedElementList = {
						{
							Element = 210002,
							Count = 1,
						},
						{
							Element = 210004,
							Count = 1,
						},
					},
				},
				{
					Value = 242035,
					Level = 69,
					Weight = 206,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 240,
					FightPower = 5900,
					NeedElementList = {
						{
							Element = 210002,
							Count = 1,
						},
						{
							Element = 210003,
							Count = 1,
						},
					},
				},
			},
		},
		{
			NeedChallenge = 140204,
			Enemy = {
				{
					Value = 242028,
					Level = 55,
					Weight = 172,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 100,
					FightPower = 3500,
				},
				{
					Value = 242032,
					Level = 59,
					Weight = 206,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 240,
					FightPower = 4700,
					NeedElementList = {
						{
							Element = 210002,
							Count = 1,
						},
					},
				},
				{
					Value = 242034,
					Level = 64,
					Weight = 206,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 240,
					FightPower = 5500,
					NeedElementList = {
						{
							Element = 210002,
							Count = 1,
						},
						{
							Element = 210004,
							Count = 1,
						},
					},
				},
			},
		},
		{
			Enemy = {
				{
					Value = 242028,
					Level = 55,
					Weight = 172,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 100,
					FightPower = 3500,
				},
				{
					Value = 242032,
					Level = 59,
					Weight = 206,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 240,
					FightPower = 4700,
					NeedElementList = {
						{
							Element = 210002,
							Count = 1,
						},
					},
				},
			},
		},
	},
	Challenge = {
		140204,
		140205,
		140206,
		140207,
	},
	EventList = {
		310205,
		310206,
		310207,
		310208,
		310209,
		310210,
	},
}
AreaConfig[AreaID.Id054] =
{
	Id = 54,
	Name = "糖果镇",
	Planet = 120002,
	Level = 28,
	AreaElement = 210001,
	NumCap = 5,
	Map = "FAT_map_04",
	LevelIcon = "Icon_FATBG03",
	LevelBG = "FATBG03",
	LevelAtlas = "EventBG",
	LevelBundle = "packed_eventbg",
	StartScene = "FAT_StartScene",
	LevelEnemy = {
		{
			NeedChallenge = 140210,
			Enemy = {
				{
					Value = 242028,
					Level = 50,
					Weight = 192,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 100,
					FightPower = 3500,
				},
				{
					Value = 242032,
					Level = 54,
					Weight = 230,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 240,
					FightPower = 4700,
					NeedElementList = {
						{
							Element = 210002,
							Count = 1,
						},
					},
				},
				{
					Value = 242037,
					Level = 56,
					Weight = 230,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 240,
					FightPower = 4900,
					NeedElementList = {
						{
							Element = 210003,
							Count = 1,
						},
					},
				},
				{
					Value = 242038,
					Level = 62,
					Weight = 346,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 900,
					FightPower = 6200,
					NeedElementList = {
						{
							Element = 210004,
							Count = 1,
						},
					},
				},
			},
		},
		{
			NeedChallenge = 140209,
			Enemy = {
				{
					Value = 242028,
					Level = 50,
					Weight = 192,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 100,
					FightPower = 3500,
				},
				{
					Value = 242032,
					Level = 54,
					Weight = 230,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 240,
					FightPower = 4700,
					NeedElementList = {
						{
							Element = 210002,
							Count = 1,
						},
					},
				},
				{
					Value = 242037,
					Level = 56,
					Weight = 230,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 240,
					FightPower = 4900,
					NeedElementList = {
						{
							Element = 210003,
							Count = 1,
						},
					},
				},
				{
					Value = 242038,
					Level = 62,
					Weight = 346,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 900,
					FightPower = 6200,
					NeedElementList = {
						{
							Element = 210004,
							Count = 1,
						},
					},
				},
			},
		},
		{
			NeedChallenge = 140208,
			Enemy = {
				{
					Value = 242028,
					Level = 50,
					Weight = 192,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 200,
					FightPower = 3500,
				},
				{
					Value = 242032,
					Level = 54,
					Weight = 230,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 480,
					FightPower = 4700,
					NeedElementList = {
						{
							Element = 210002,
							Count = 1,
						},
					},
				},
				{
					Value = 242037,
					Level = 56,
					Weight = 230,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 240,
					FightPower = 4900,
					NeedElementList = {
						{
							Element = 210003,
							Count = 1,
						},
					},
				},
			},
		},
		{
			Enemy = {
				{
					Value = 242028,
					Level = 50,
					Weight = 192,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 200,
					FightPower = 3500,
				},
				{
					Value = 242032,
					Level = 54,
					Weight = 230,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 480,
					FightPower = 4700,
					NeedElementList = {
						{
							Element = 210002,
							Count = 1,
						},
					},
				},
			},
		},
	},
	Challenge = {
		140208,
		140209,
		140210,
	},
	EventList = {
		310211,
		310212,
		310213,
		310214,
	},
}
AreaConfig[AreaID.Id055] =
{
	Id = 55,
	Name = "甜食工厂",
	Planet = 120002,
	Level = 35,
	AreaElement = 210001,
	NumCap = 5,
	Map = "FAT_map_05",
	LevelIcon = "Icon_FATBG01",
	LevelBG = "FATBG01",
	LevelAtlas = "EventBG",
	LevelBundle = "packed_eventbg",
	StartScene = "FAT_StartScene",
	LevelEnemy = {
		{
			NeedChallenge = 140214,
			Enemy = {
				{
					Value = 242028,
					Level = 60,
					Weight = 156,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 100,
					FightPower = 3500,
				},
				{
					Value = 242037,
					Level = 64,
					Weight = 187,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 240,
					FightPower = 4900,
					NeedElementList = {
						{
							Element = 210003,
							Count = 1,
						},
					},
				},
				{
					Value = 242039,
					Level = 68,
					Weight = 187,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 240,
					FightPower = 5800,
					NeedElementList = {
						{
							Element = 210003,
							Count = 1,
						},
					},
				},
				{
					Value = 242040,
					Level = 72,
					Weight = 187,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 240,
					FightPower = 6200,
					NeedElementList = {
						{
							Element = 210003,
							Count = 2,
						},
					},
				},
				{
					Value = 242041,
					Level = 78,
					Weight = 281,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 900,
					FightPower = 7600,
					NeedElementList = {
						{
							Element = 210005,
							Count = 1,
						},
					},
				},
			},
		},
		{
			NeedChallenge = 140213,
			Enemy = {
				{
					Value = 242028,
					Level = 60,
					Weight = 156,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 100,
					FightPower = 3500,
				},
				{
					Value = 242037,
					Level = 64,
					Weight = 187,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 240,
					FightPower = 4900,
					NeedElementList = {
						{
							Element = 210003,
							Count = 1,
						},
					},
				},
				{
					Value = 242039,
					Level = 68,
					Weight = 187,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 240,
					FightPower = 5800,
					NeedElementList = {
						{
							Element = 210003,
							Count = 1,
						},
					},
				},
				{
					Value = 242040,
					Level = 72,
					Weight = 187,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 240,
					FightPower = 6200,
					NeedElementList = {
						{
							Element = 210003,
							Count = 2,
						},
					},
				},
				{
					Value = 242041,
					Level = 78,
					Weight = 281,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 900,
					FightPower = 7600,
					NeedElementList = {
						{
							Element = 210005,
							Count = 1,
						},
					},
				},
			},
		},
		{
			NeedChallenge = 140212,
			Enemy = {
				{
					Value = 242028,
					Level = 60,
					Weight = 156,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 100,
					FightPower = 3500,
				},
				{
					Value = 242037,
					Level = 64,
					Weight = 187,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 240,
					FightPower = 4900,
					NeedElementList = {
						{
							Element = 210003,
							Count = 1,
						},
					},
				},
				{
					Value = 242039,
					Level = 68,
					Weight = 187,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 240,
					FightPower = 5800,
					NeedElementList = {
						{
							Element = 210003,
							Count = 1,
						},
					},
				},
				{
					Value = 242040,
					Level = 72,
					Weight = 187,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 240,
					FightPower = 6200,
					NeedElementList = {
						{
							Element = 210003,
							Count = 2,
						},
					},
				},
			},
		},
		{
			NeedChallenge = 140211,
			Enemy = {
				{
					Value = 242028,
					Level = 60,
					Weight = 156,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 100,
					FightPower = 3500,
				},
				{
					Value = 242037,
					Level = 64,
					Weight = 187,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 240,
					FightPower = 4900,
					NeedElementList = {
						{
							Element = 210003,
							Count = 1,
						},
					},
				},
				{
					Value = 242039,
					Level = 68,
					Weight = 187,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 240,
					FightPower = 5800,
					NeedElementList = {
						{
							Element = 210003,
							Count = 1,
						},
					},
				},
			},
		},
		{
			Enemy = {
				{
					Value = 242028,
					Level = 60,
					Weight = 156,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 100,
					FightPower = 3500,
				},
				{
					Value = 242037,
					Level = 64,
					Weight = 187,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 240,
					FightPower = 4900,
					NeedElementList = {
						{
							Element = 210003,
							Count = 1,
						},
					},
				},
			},
		},
	},
	Challenge = {
		140211,
		140212,
		140213,
		140214,
	},
	EventList = {
		310215,
		310216,
		310217,
		310218,
	},
}
AreaConfig[AreaID.Id056] =
{
	Id = 56,
	Name = "风味镇",
	Planet = 120002,
	Level = 43,
	AreaElement = 210001,
	NumCap = 5,
	Map = "FAT_map_06",
	LevelIcon = "Icon_FATBG02",
	LevelBG = "FATBG02",
	LevelAtlas = "EventBG",
	LevelBundle = "packed_eventbg",
	StartScene = "FAT_StartScene",
	LevelEnemy = {
		{
			NeedChallenge = 140218,
			Enemy = {
				{
					Value = 242029,
					Level = 78,
					Weight = 140,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 100,
					FightPower = 5300,
				},
				{
					Value = 242035,
					Level = 80,
					Weight = 168,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 240,
					FightPower = 5900,
					NeedElementList = {
						{
							Element = 210002,
							Count = 1,
						},
						{
							Element = 210003,
							Count = 1,
						},
					},
				},
				{
					Value = 242040,
					Level = 84,
					Weight = 168,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 240,
					FightPower = 6200,
					NeedElementList = {
						{
							Element = 210003,
							Count = 2,
						},
					},
				},
				{
					Value = 242042,
					Level = 88,
					Weight = 168,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 240,
					FightPower = 7400,
					NeedElementList = {
						{
							Element = 210001,
							Count = 1,
						},
					},
				},
				{
					Value = 242043,
					Level = 94,
					Weight = 353,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 3600,
					FightPower = 10300,
					NeedElementList = {
						{
							Element = 210002,
							Count = 1,
						},
						{
							Element = 210004,
							Count = 1,
						},
					},
				},
			},
		},
		{
			NeedChallenge = 140217,
			Enemy = {
				{
					Value = 242029,
					Level = 78,
					Weight = 140,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 100,
					FightPower = 5300,
				},
				{
					Value = 242035,
					Level = 80,
					Weight = 168,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 240,
					FightPower = 5900,
					NeedElementList = {
						{
							Element = 210002,
							Count = 1,
						},
						{
							Element = 210003,
							Count = 1,
						},
					},
				},
				{
					Value = 242040,
					Level = 84,
					Weight = 168,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 240,
					FightPower = 6200,
					NeedElementList = {
						{
							Element = 210003,
							Count = 2,
						},
					},
				},
				{
					Value = 242042,
					Level = 88,
					Weight = 168,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 240,
					FightPower = 7400,
					NeedElementList = {
						{
							Element = 210001,
							Count = 1,
						},
					},
				},
				{
					Value = 242043,
					Level = 94,
					Weight = 353,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 3600,
					FightPower = 10300,
					NeedElementList = {
						{
							Element = 210002,
							Count = 1,
						},
						{
							Element = 210004,
							Count = 1,
						},
					},
				},
			},
		},
		{
			NeedChallenge = 140216,
			Enemy = {
				{
					Value = 242029,
					Level = 78,
					Weight = 140,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 100,
					FightPower = 5300,
				},
				{
					Value = 242035,
					Level = 80,
					Weight = 168,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 240,
					FightPower = 5900,
					NeedElementList = {
						{
							Element = 210002,
							Count = 1,
						},
						{
							Element = 210003,
							Count = 1,
						},
					},
				},
				{
					Value = 242040,
					Level = 84,
					Weight = 168,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 240,
					FightPower = 6200,
					NeedElementList = {
						{
							Element = 210003,
							Count = 2,
						},
					},
				},
				{
					Value = 242042,
					Level = 88,
					Weight = 168,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 240,
					FightPower = 7400,
					NeedElementList = {
						{
							Element = 210001,
							Count = 1,
						},
					},
				},
			},
		},
		{
			NeedChallenge = 140215,
			Enemy = {
				{
					Value = 242029,
					Level = 78,
					Weight = 140,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 100,
					FightPower = 5300,
				},
				{
					Value = 242035,
					Level = 80,
					Weight = 168,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 240,
					FightPower = 5900,
					NeedElementList = {
						{
							Element = 210002,
							Count = 1,
						},
						{
							Element = 210003,
							Count = 1,
						},
					},
				},
				{
					Value = 242040,
					Level = 84,
					Weight = 168,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 240,
					FightPower = 6200,
					NeedElementList = {
						{
							Element = 210003,
							Count = 2,
						},
					},
				},
			},
		},
		{
			Enemy = {
				{
					Value = 242029,
					Level = 78,
					Weight = 140,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 200,
					FightPower = 5300,
				},
				{
					Value = 242035,
					Level = 80,
					Weight = 168,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 240,
					FightPower = 5900,
					NeedElementList = {
						{
							Element = 210002,
							Count = 1,
						},
						{
							Element = 210003,
							Count = 1,
						},
					},
				},
				{
					Value = 242040,
					Level = 84,
					Weight = 168,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 240,
					FightPower = 6200,
					NeedElementList = {
						{
							Element = 210003,
							Count = 2,
						},
					},
				},
			},
		},
	},
	Challenge = {
		140215,
		140216,
		140217,
		140218,
	},
	EventList = {
		310219,
		310220,
		310221,
		310222,
	},
}
AreaConfig[AreaID.Id057] =
{
	Id = 57,
	Name = "饭团镇",
	Planet = 120002,
	Level = 40,
	AreaElement = 210001,
	NumCap = 5,
	Map = "FAT_map_07",
	LevelIcon = "Icon_FATBG02",
	LevelBG = "FATBG02",
	LevelAtlas = "EventBG",
	LevelBundle = "packed_eventbg",
	StartScene = "FAT_StartScene",
	LevelEnemy = {
		{
			NeedChallenge = 140223,
			Enemy = {
				{
					Value = 242030,
					Level = 70,
					Weight = 172,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 100,
					FightPower = 4800,
				},
				{
					Value = 242039,
					Level = 75,
					Weight = 206,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 240,
					FightPower = 5800,
					NeedElementList = {
						{
							Element = 210003,
							Count = 1,
						},
					},
				},
				{
					Value = 242044,
					Level = 80,
					Weight = 206,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 240,
					FightPower = 6800,
					NeedElementList = {
						{
							Element = 210004,
							Count = 1,
						},
					},
				},
				{
					Value = 242045,
					Level = 84,
					Weight = 206,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 240,
					FightPower = 7100,
					NeedElementList = {
						{
							Element = 210005,
							Count = 1,
						},
					},
				},
				{
					Value = 242046,
					Level = 88,
					Weight = 206,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 240,
					FightPower = 7400,
					NeedElementList = {
						{
							Element = 210001,
							Count = 1,
						},
					},
				},
			},
		},
		{
			NeedChallenge = 140222,
			Enemy = {
				{
					Value = 242030,
					Level = 70,
					Weight = 172,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 100,
					FightPower = 4800,
				},
				{
					Value = 242039,
					Level = 75,
					Weight = 206,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 240,
					FightPower = 5800,
					NeedElementList = {
						{
							Element = 210003,
							Count = 1,
						},
					},
				},
				{
					Value = 242044,
					Level = 80,
					Weight = 206,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 240,
					FightPower = 6800,
					NeedElementList = {
						{
							Element = 210004,
							Count = 1,
						},
					},
				},
				{
					Value = 242045,
					Level = 84,
					Weight = 206,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 240,
					FightPower = 7100,
					NeedElementList = {
						{
							Element = 210005,
							Count = 1,
						},
					},
				},
				{
					Value = 242046,
					Level = 88,
					Weight = 206,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 240,
					FightPower = 7400,
					NeedElementList = {
						{
							Element = 210001,
							Count = 1,
						},
					},
				},
			},
		},
		{
			NeedChallenge = 140221,
			Enemy = {
				{
					Value = 242030,
					Level = 70,
					Weight = 172,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 100,
					FightPower = 4800,
				},
				{
					Value = 242039,
					Level = 75,
					Weight = 206,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 240,
					FightPower = 5800,
					NeedElementList = {
						{
							Element = 210003,
							Count = 1,
						},
					},
				},
				{
					Value = 242044,
					Level = 80,
					Weight = 206,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 240,
					FightPower = 6800,
					NeedElementList = {
						{
							Element = 210004,
							Count = 1,
						},
					},
				},
				{
					Value = 242045,
					Level = 84,
					Weight = 206,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 240,
					FightPower = 7100,
					NeedElementList = {
						{
							Element = 210005,
							Count = 1,
						},
					},
				},
			},
		},
		{
			NeedChallenge = 140220,
			Enemy = {
				{
					Value = 242030,
					Level = 70,
					Weight = 172,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 100,
					FightPower = 4800,
				},
				{
					Value = 242039,
					Level = 75,
					Weight = 206,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 240,
					FightPower = 5800,
					NeedElementList = {
						{
							Element = 210003,
							Count = 1,
						},
					},
				},
				{
					Value = 242044,
					Level = 80,
					Weight = 206,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 240,
					FightPower = 6800,
					NeedElementList = {
						{
							Element = 210004,
							Count = 1,
						},
					},
				},
			},
		},
		{
			NeedChallenge = 140219,
			Enemy = {
				{
					Value = 242030,
					Level = 70,
					Weight = 172,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 100,
					FightPower = 4800,
				},
				{
					Value = 242039,
					Level = 75,
					Weight = 206,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 240,
					FightPower = 5800,
					NeedElementList = {
						{
							Element = 210003,
							Count = 1,
						},
					},
				},
			},
		},
		{
			Enemy = {
				{
					Value = 242030,
					Level = 70,
					Weight = 172,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 200,
					FightPower = 4800,
				},
				{
					Value = 242039,
					Level = 75,
					Weight = 206,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 240,
					FightPower = 5800,
					NeedElementList = {
						{
							Element = 210003,
							Count = 1,
						},
					},
				},
			},
		},
	},
	Challenge = {
		140219,
		140220,
		140221,
		140222,
		140223,
	},
	EventList = {
		310223,
		310224,
		310225,
		310226,
	},
}
AreaConfig[AreaID.Id058] =
{
	Id = 58,
	Name = "煮物镇",
	Planet = 120002,
	Level = 43,
	AreaElement = 210001,
	NumCap = 5,
	Map = "FAT_map_08",
	LevelIcon = "Icon_FATBG04",
	LevelBG = "FATBG04",
	LevelAtlas = "EventBG",
	LevelBundle = "packed_eventbg",
	StartScene = "FAT_StartScene",
	LevelEnemy = {
		{
			NeedChallenge = 140226,
			Enemy = {
				{
					Value = 242030,
					Level = 80,
					Weight = 156,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 100,
					FightPower = 4800,
				},
				{
					Value = 242044,
					Level = 82,
					Weight = 187,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 240,
					FightPower = 6800,
					NeedElementList = {
						{
							Element = 210004,
							Count = 1,
						},
					},
				},
				{
					Value = 242042,
					Level = 84,
					Weight = 187,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 240,
					FightPower = 7400,
					NeedElementList = {
						{
							Element = 210001,
							Count = 1,
						},
					},
				},
				{
					Value = 242047,
					Level = 86,
					Weight = 187,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 240,
					FightPower = 7300,
					NeedElementList = {
						{
							Element = 210001,
							Count = 1,
						},
					},
				},
				{
					Value = 242048,
					Level = 92,
					Weight = 281,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 900,
					FightPower = 8900,
					NeedElementList = {
						{
							Element = 210001,
							Count = 1,
						},
						{
							Element = 210002,
							Count = 1,
						},
					},
				},
			},
		},
		{
			NeedChallenge = 140225,
			Enemy = {
				{
					Value = 242030,
					Level = 80,
					Weight = 156,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 100,
					FightPower = 4800,
				},
				{
					Value = 242044,
					Level = 82,
					Weight = 187,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 240,
					FightPower = 6800,
					NeedElementList = {
						{
							Element = 210004,
							Count = 1,
						},
					},
				},
				{
					Value = 242042,
					Level = 84,
					Weight = 187,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 240,
					FightPower = 7400,
					NeedElementList = {
						{
							Element = 210001,
							Count = 1,
						},
					},
				},
				{
					Value = 242047,
					Level = 86,
					Weight = 187,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 240,
					FightPower = 7300,
					NeedElementList = {
						{
							Element = 210001,
							Count = 1,
						},
					},
				},
				{
					Value = 242048,
					Level = 92,
					Weight = 281,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 900,
					FightPower = 8900,
					NeedElementList = {
						{
							Element = 210001,
							Count = 1,
						},
						{
							Element = 210002,
							Count = 1,
						},
					},
				},
			},
		},
		{
			NeedChallenge = 140224,
			Enemy = {
				{
					Value = 242030,
					Level = 80,
					Weight = 156,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 100,
					FightPower = 4800,
				},
				{
					Value = 242044,
					Level = 82,
					Weight = 187,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 240,
					FightPower = 6800,
					NeedElementList = {
						{
							Element = 210004,
							Count = 1,
						},
					},
				},
				{
					Value = 242042,
					Level = 84,
					Weight = 187,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 240,
					FightPower = 7400,
					NeedElementList = {
						{
							Element = 210001,
							Count = 1,
						},
					},
				},
				{
					Value = 242047,
					Level = 86,
					Weight = 187,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 240,
					FightPower = 7300,
					NeedElementList = {
						{
							Element = 210001,
							Count = 1,
						},
					},
				},
			},
		},
		{
			Enemy = {
				{
					Value = 242030,
					Level = 80,
					Weight = 156,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 100,
					FightPower = 4800,
				},
				{
					Value = 242044,
					Level = 82,
					Weight = 187,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 240,
					FightPower = 6800,
					NeedElementList = {
						{
							Element = 210004,
							Count = 1,
						},
					},
				},
				{
					Value = 242042,
					Level = 84,
					Weight = 187,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 240,
					FightPower = 7400,
					NeedElementList = {
						{
							Element = 210001,
							Count = 1,
						},
					},
				},
			},
		},
	},
	Challenge = {
		140224,
		140225,
		140226,
	},
	EventList = {
		310227,
		310228,
		310229,
		310230,
		310231,
	},
}
AreaConfig[AreaID.Id059] =
{
	Id = 59,
	Name = "寿司镇",
	Planet = 120002,
	Level = 47,
	AreaElement = 210001,
	NumCap = 5,
	Map = "FAT_map_09",
	LevelIcon = "Icon_FATBG04",
	LevelBG = "FATBG04",
	LevelAtlas = "EventBG",
	LevelBundle = "packed_eventbg",
	StartScene = "FAT_StartScene",
	LevelEnemy = {
		{
			NeedChallenge = 140230,
			Enemy = {
				{
					Value = 242030,
					Level = 88,
					Weight = 142,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 100,
					FightPower = 4800,
				},
				{
					Value = 242045,
					Level = 90,
					Weight = 171,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 240,
					FightPower = 7100,
					NeedElementList = {
						{
							Element = 210005,
							Count = 1,
						},
					},
				},
				{
					Value = 242042,
					Level = 92,
					Weight = 171,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 240,
					FightPower = 7400,
					NeedElementList = {
						{
							Element = 210001,
							Count = 1,
						},
					},
				},
				{
					Value = 242049,
					Level = 94,
					Weight = 171,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 240,
					FightPower = 7900,
					NeedElementList = {
						{
							Element = 210004,
							Count = 2,
						},
					},
				},
				{
					Value = 242050,
					Level = 98,
					Weight = 171,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 240,
					FightPower = 8200,
					NeedElementList = {
						{
							Element = 210004,
							Count = 2,
						},
					},
				},
				{
					Value = 242051,
					Level = 102,
					Weight = 171,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 240,
					FightPower = 8600,
					NeedElementList = {
						{
							Element = 210004,
							Count = 2,
						},
					},
				},
			},
		},
		{
			NeedChallenge = 140229,
			Enemy = {
				{
					Value = 242030,
					Level = 88,
					Weight = 142,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 100,
					FightPower = 4800,
				},
				{
					Value = 242045,
					Level = 90,
					Weight = 171,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 240,
					FightPower = 7100,
					NeedElementList = {
						{
							Element = 210005,
							Count = 1,
						},
					},
				},
				{
					Value = 242042,
					Level = 92,
					Weight = 171,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 240,
					FightPower = 7400,
					NeedElementList = {
						{
							Element = 210001,
							Count = 1,
						},
					},
				},
				{
					Value = 242049,
					Level = 94,
					Weight = 171,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 240,
					FightPower = 7900,
					NeedElementList = {
						{
							Element = 210004,
							Count = 2,
						},
					},
				},
				{
					Value = 242050,
					Level = 98,
					Weight = 171,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 240,
					FightPower = 8200,
					NeedElementList = {
						{
							Element = 210004,
							Count = 2,
						},
					},
				},
				{
					Value = 242051,
					Level = 102,
					Weight = 171,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 240,
					FightPower = 8600,
					NeedElementList = {
						{
							Element = 210004,
							Count = 2,
						},
					},
				},
			},
		},
		{
			NeedChallenge = 140228,
			Enemy = {
				{
					Value = 242030,
					Level = 88,
					Weight = 142,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 100,
					FightPower = 4800,
				},
				{
					Value = 242045,
					Level = 90,
					Weight = 171,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 240,
					FightPower = 7100,
					NeedElementList = {
						{
							Element = 210005,
							Count = 1,
						},
					},
				},
				{
					Value = 242042,
					Level = 92,
					Weight = 171,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 240,
					FightPower = 7400,
					NeedElementList = {
						{
							Element = 210001,
							Count = 1,
						},
					},
				},
				{
					Value = 242049,
					Level = 94,
					Weight = 171,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 240,
					FightPower = 7900,
					NeedElementList = {
						{
							Element = 210004,
							Count = 2,
						},
					},
				},
				{
					Value = 242050,
					Level = 98,
					Weight = 171,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 240,
					FightPower = 8200,
					NeedElementList = {
						{
							Element = 210004,
							Count = 2,
						},
					},
				},
			},
		},
		{
			NeedChallenge = 140227,
			Enemy = {
				{
					Value = 242030,
					Level = 88,
					Weight = 142,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 100,
					FightPower = 4800,
				},
				{
					Value = 242045,
					Level = 90,
					Weight = 171,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 240,
					FightPower = 7100,
					NeedElementList = {
						{
							Element = 210005,
							Count = 1,
						},
					},
				},
				{
					Value = 242042,
					Level = 92,
					Weight = 171,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 240,
					FightPower = 7400,
					NeedElementList = {
						{
							Element = 210001,
							Count = 1,
						},
					},
				},
				{
					Value = 242049,
					Level = 94,
					Weight = 171,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 240,
					FightPower = 7900,
					NeedElementList = {
						{
							Element = 210004,
							Count = 2,
						},
					},
				},
			},
		},
		{
			Enemy = {
				{
					Value = 242030,
					Level = 88,
					Weight = 142,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 100,
					FightPower = 4800,
				},
				{
					Value = 242045,
					Level = 90,
					Weight = 171,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 240,
					FightPower = 7100,
					NeedElementList = {
						{
							Element = 210005,
							Count = 1,
						},
					},
				},
				{
					Value = 242042,
					Level = 92,
					Weight = 171,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 240,
					FightPower = 7400,
					NeedElementList = {
						{
							Element = 210001,
							Count = 1,
						},
					},
				},
			},
		},
	},
	Challenge = {
		140227,
		140228,
		140229,
		140230,
	},
	EventList = {
		310232,
		310233,
		310234,
		310235,
	},
}
AreaConfig[AreaID.Id060] =
{
	Id = 60,
	Name = "烤肉镇",
	Planet = 120002,
	Level = 51,
	AreaElement = 210001,
	NumCap = 5,
	Map = "FAT_map_10",
	LevelIcon = "Icon_FATBG02",
	LevelBG = "FATBG02",
	LevelAtlas = "EventBG",
	LevelBundle = "packed_eventbg",
	StartScene = "FAT_StartScene",
	LevelEnemy = {
		{
			NeedChallenge = 140234,
			Enemy = {
				{
					Value = 242031,
					Level = 96,
					Weight = 156,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 100,
					FightPower = 6500,
				},
				{
					Value = 242047,
					Level = 98,
					Weight = 187,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 240,
					FightPower = 7300,
					NeedElementList = {
						{
							Element = 210001,
							Count = 1,
						},
					},
				},
				{
					Value = 242049,
					Level = 100,
					Weight = 187,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 240,
					FightPower = 7900,
					NeedElementList = {
						{
							Element = 210004,
							Count = 2,
						},
					},
				},
				{
					Value = 242052,
					Level = 102,
					Weight = 187,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 240,
					FightPower = 8600,
					NeedElementList = {
						{
							Element = 210002,
							Count = 1,
						},
					},
				},
				{
					Value = 242053,
					Level = 106,
					Weight = 281,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 900,
					FightPower = 10200,
					NeedElementList = {
						{
							Element = 210002,
							Count = 2,
						},
					},
				},
			},
		},
		{
			NeedChallenge = 140233,
			Enemy = {
				{
					Value = 242031,
					Level = 96,
					Weight = 156,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 100,
					FightPower = 6500,
				},
				{
					Value = 242047,
					Level = 98,
					Weight = 187,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 240,
					FightPower = 7300,
					NeedElementList = {
						{
							Element = 210001,
							Count = 1,
						},
					},
				},
				{
					Value = 242049,
					Level = 100,
					Weight = 187,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 240,
					FightPower = 7900,
					NeedElementList = {
						{
							Element = 210004,
							Count = 2,
						},
					},
				},
				{
					Value = 242052,
					Level = 102,
					Weight = 187,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 240,
					FightPower = 8600,
					NeedElementList = {
						{
							Element = 210002,
							Count = 1,
						},
					},
				},
				{
					Value = 242053,
					Level = 106,
					Weight = 281,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 900,
					FightPower = 10200,
					NeedElementList = {
						{
							Element = 210002,
							Count = 2,
						},
					},
				},
			},
		},
		{
			NeedChallenge = 140232,
			Enemy = {
				{
					Value = 242031,
					Level = 96,
					Weight = 156,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 100,
					FightPower = 6500,
				},
				{
					Value = 242047,
					Level = 98,
					Weight = 187,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 240,
					FightPower = 7300,
					NeedElementList = {
						{
							Element = 210001,
							Count = 1,
						},
					},
				},
				{
					Value = 242049,
					Level = 100,
					Weight = 187,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 240,
					FightPower = 7900,
					NeedElementList = {
						{
							Element = 210004,
							Count = 2,
						},
					},
				},
				{
					Value = 242052,
					Level = 102,
					Weight = 187,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 240,
					FightPower = 8600,
					NeedElementList = {
						{
							Element = 210002,
							Count = 1,
						},
					},
				},
			},
		},
		{
			NeedChallenge = 140231,
			Enemy = {
				{
					Value = 242031,
					Level = 96,
					Weight = 156,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 100,
					FightPower = 6500,
				},
				{
					Value = 242047,
					Level = 98,
					Weight = 187,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 240,
					FightPower = 7300,
					NeedElementList = {
						{
							Element = 210001,
							Count = 1,
						},
					},
				},
				{
					Value = 242049,
					Level = 100,
					Weight = 187,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 240,
					FightPower = 7900,
					NeedElementList = {
						{
							Element = 210004,
							Count = 2,
						},
					},
				},
			},
		},
		{
			Enemy = {
				{
					Value = 242031,
					Level = 96,
					Weight = 156,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 200,
					FightPower = 6500,
				},
				{
					Value = 242047,
					Level = 98,
					Weight = 187,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 240,
					FightPower = 7300,
					NeedElementList = {
						{
							Element = 210001,
							Count = 1,
						},
					},
				},
				{
					Value = 242049,
					Level = 100,
					Weight = 187,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 240,
					FightPower = 7900,
					NeedElementList = {
						{
							Element = 210004,
							Count = 2,
						},
					},
				},
			},
		},
	},
	Challenge = {
		140231,
		140232,
		140233,
		140234,
	},
	EventList = {
		310236,
		310237,
		310238,
		310239,
		310240,
		310241,
		310242,
	},
}
AreaConfig[AreaID.Id061] =
{
	Id = 61,
	Name = "香浓镇",
	Planet = 120002,
	Level = 65,
	AreaElement = 210001,
	NumCap = 5,
	Map = "FAT_map_11",
	LevelIcon = "Icon_FATBG03",
	LevelBG = "FATBG03",
	LevelAtlas = "EventBG",
	LevelBundle = "packed_eventbg",
	StartScene = "FAT_StartScene",
	LevelEnemy = {
		{
			NeedChallenge = 140236,
			Enemy = {
				{
					Value = 242031,
					Level = 120,
					Weight = 140,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 100,
					FightPower = 6500,
				},
				{
					Value = 242050,
					Level = 124,
					Weight = 168,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 240,
					FightPower = 8200,
					NeedElementList = {
						{
							Element = 210004,
							Count = 2,
						},
					},
				},
				{
					Value = 242052,
					Level = 128,
					Weight = 168,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 240,
					FightPower = 8600,
					NeedElementList = {
						{
							Element = 210002,
							Count = 1,
						},
					},
				},
				{
					Value = 242054,
					Level = 138,
					Weight = 168,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 240,
					FightPower = 11400,
					NeedElementList = {
						{
							Element = 210003,
							Count = 1,
						},
						{
							Element = 210004,
							Count = 1,
						},
					},
				},
				{
					Value = 242055,
					Level = 146,
					Weight = 353,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 3600,
					FightPower = 15700,
					NeedElementList = {
						{
							Element = 210002,
							Count = 2,
						},
						{
							Element = 210004,
							Count = 1,
						},
					},
				},
			},
		},
		{
			NeedChallenge = 140235,
			Enemy = {
				{
					Value = 242031,
					Level = 120,
					Weight = 140,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 100,
					FightPower = 6500,
				},
				{
					Value = 242050,
					Level = 124,
					Weight = 168,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 240,
					FightPower = 8200,
					NeedElementList = {
						{
							Element = 210004,
							Count = 2,
						},
					},
				},
				{
					Value = 242052,
					Level = 128,
					Weight = 168,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 240,
					FightPower = 8600,
					NeedElementList = {
						{
							Element = 210002,
							Count = 1,
						},
					},
				},
				{
					Value = 242054,
					Level = 138,
					Weight = 168,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 240,
					FightPower = 11400,
					NeedElementList = {
						{
							Element = 210003,
							Count = 1,
						},
						{
							Element = 210004,
							Count = 1,
						},
					},
				},
			},
		},
		{
			Enemy = {
				{
					Value = 242031,
					Level = 120,
					Weight = 140,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 100,
					FightPower = 6500,
				},
				{
					Value = 242050,
					Level = 124,
					Weight = 168,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 240,
					FightPower = 8200,
					NeedElementList = {
						{
							Element = 210004,
							Count = 2,
						},
					},
				},
				{
					Value = 242052,
					Level = 128,
					Weight = 168,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 240,
					FightPower = 8600,
					NeedElementList = {
						{
							Element = 210002,
							Count = 1,
						},
					},
				},
			},
		},
	},
	Challenge = {
		140235,
		140236,
	},
	EventList = {
		310243,
		310244,
		310245,
		310246,
		310247,
		310248,
	},
}
