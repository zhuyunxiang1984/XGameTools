ModulesUnlockConfig ={};
ModulesUnlockID = 
{
	Id001 = 570001,
	Id002 = 570002,
	Id003 = 570003,
	Id004 = 570004,
	Id005 = 570005,
	Id006 = 570006,
	Id007 = 570007,
	Id008 = 570008,
	Id009 = 570009,
	Id010 = 570010,
	Id011 = 570011,
	Id012 = 570012,
	Id013 = 570013,
	Id014 = 570014,
	Id015 = 570015,
	Id016 = 570016,
	Id017 = 570017,
	Id018 = 570018,
	Id019 = 570019,
	Id020 = 570020,
	Id021 = 570021,
	Id022 = 570022,
	Id023 = 570023,
	Id024 = 570024,
	Id025 = 570025,
	Id026 = 570026,
	Id027 = 570027,
	Id028 = 570028,
	Id029 = 570029,
	Id030 = 570030,
	Id031 = 570031,
}
ModulesUnlockConfig[ModulesUnlockID.Id001] =
{
	Id = 1,
	Name = "Explore",
	Unlock = -1,
	IsApp = false,
	IsInternal = 0,
	Text = "解锁探索",
	ShowUnlock = false,
}
ModulesUnlockConfig[ModulesUnlockID.Id002] =
{
	Id = 2,
	Name = "Lab",
	Unlock = 300025,
	IsApp = true,
	AppName = "合成",
	SortId = 95,
	IconAtlas = "HomeUI",
	Icon = "Home_Bth_icon5",
	IsInternal = 0,
	Text = "解锁实验室",
	ShowUnlock = true,
}
ModulesUnlockConfig[ModulesUnlockID.Id003] =
{
	Id = 3,
	Name = "Upgrade",
	Unlock = -1,
	IsApp = false,
	IsInternal = 0,
	Text = "解锁角色升级",
	ShowUnlock = false,
}
ModulesUnlockConfig[ModulesUnlockID.Id004] =
{
	Id = 4,
	Name = "CharacterList",
	Unlock = -1,
	IsApp = true,
	AppName = "角色列表",
	SortId = 98,
	IconAtlas = "HomeUI",
	Icon = "Home_Bth_icon2",
	IsInternal = 0,
	Text = "解锁角色列表",
	ShowUnlock = false,
}
ModulesUnlockConfig[ModulesUnlockID.Id005] =
{
	Id = 5,
	Name = "Warehouse",
	Unlock = 300003,
	IsApp = true,
	AppName = "仓库",
	SortId = 97,
	IconAtlas = "HomeUI",
	Icon = "Home_Bth_icon3",
	IsInternal = 0,
	Text = "解锁仓库",
	ShowUnlock = false,
}
ModulesUnlockConfig[ModulesUnlockID.Id006] =
{
	Id = 6,
	Name = "Mission",
	Unlock = -1,
	IsApp = true,
	AppName = "任务",
	SortId = 99,
	IconAtlas = "HomeUI",
	Icon = "Home_Bth_icon1",
	IsInternal = 0,
	Text = "解锁任务列表",
	ShowUnlock = false,
}
ModulesUnlockConfig[ModulesUnlockID.Id007] =
{
	Id = 7,
	Name = "Summon",
	Unlock = 300023,
	IsApp = false,
	IsInternal = 0,
	Text = "解锁不夜城",
	ShowUnlock = true,
}
ModulesUnlockConfig[ModulesUnlockID.Id008] =
{
	Id = 8,
	Name = "Gallery",
	Unlock = -1,
	IsApp = true,
	AppName = "图鉴",
	SortId = 96,
	IconAtlas = "HomeUI",
	Icon = "Home_Bth_icon4",
	IsInternal = 0,
	Text = "解锁图鉴",
	ShowUnlock = true,
}
ModulesUnlockConfig[ModulesUnlockID.Id009] =
{
	Id = 9,
	Name = "Arena",
	Unlock = 300347,
	IsApp = false,
	IsInternal = 0,
	Text = "解锁流亡街",
	ShowUnlock = true,
}
ModulesUnlockConfig[ModulesUnlockID.Id010] =
{
	Id = 10,
	Name = "WorkShop",
	Unlock = 300005,
	IsApp = false,
	IsInternal = 0,
	Text = "打工",
	ShowUnlock = true,
}
ModulesUnlockConfig[ModulesUnlockID.Id011] =
{
	Id = 11,
	Name = "WorkShopUpgrade",
	Unlock = 300017,
	IsApp = false,
	IsInternal = 0,
	Text = "打工升级",
	ShowUnlock = false,
}
ModulesUnlockConfig[ModulesUnlockID.Id012] =
{
	Id = 12,
	Name = "BattleFast",
	Unlock = -1,
	IsApp = false,
	IsInternal = 0,
	Text = "战斗快进",
	ShowUnlock = false,
}
ModulesUnlockConfig[ModulesUnlockID.Id013] =
{
	Id = 13,
	Name = "BattleQuit",
	Unlock = 300002,
	IsApp = false,
	IsInternal = 0,
	Text = "战斗退出",
	ShowUnlock = false,
}
ModulesUnlockConfig[ModulesUnlockID.Id014] =
{
	Id = 14,
	Name = "Tourist",
	Unlock = 300346,
	IsApp = false,
	IsInternal = 0,
	Text = "观光团",
	ShowUnlock = true,
}
ModulesUnlockConfig[ModulesUnlockID.Id015] =
{
	Id = 15,
	Name = "Demand",
	Unlock = 300009,
	IsApp = false,
	IsInternal = 0,
	Text = "委托",
	ShowUnlock = true,
}
ModulesUnlockConfig[ModulesUnlockID.Id016] =
{
	Id = 16,
	Name = "Activity",
	Unlock = 300040,
	IsApp = false,
	IsInternal = 0,
	Text = "活动",
	ShowUnlock = false,
}
ModulesUnlockConfig[ModulesUnlockID.Id017] =
{
	Id = 17,
	Name = "SpaceTravel",
	Unlock = -1,
	IsApp = false,
	IsInternal = 0,
	Text = "星际航行",
	ShowUnlock = true,
}
ModulesUnlockConfig[ModulesUnlockID.Id018] =
{
	Id = 18,
	Name = "Newbie",
	Unlock = 300004,
	IsApp = false,
	IsInternal = 0,
	Text = "新手指南",
	ShowUnlock = true,
}
ModulesUnlockConfig[ModulesUnlockID.Id019] =
{
	Id = 19,
	Name = "CharacterSkin",
	Unlock = 300027,
	IsApp = false,
	IsInternal = 0,
	Text = "皮肤挑战",
	ShowUnlock = true,
}
ModulesUnlockConfig[ModulesUnlockID.Id020] =
{
	Id = 20,
	Name = "ExploreCancel",
	Unlock = 300023,
	IsApp = false,
	IsInternal = 0,
	Text = "探索撤回",
	ShowUnlock = false,
}
ModulesUnlockConfig[ModulesUnlockID.Id021] =
{
	Id = 21,
	Name = "CustomDemand",
	Unlock = 300354,
	IsApp = false,
	IsInternal = 0,
	Text = "定制订单",
	ShowUnlock = true,
}
ModulesUnlockConfig[ModulesUnlockID.Id022] =
{
	Id = 22,
	Name = "HideSeek",
	Unlock = -1,
	IsApp = false,
	IsInternal = 0,
	Text = "捉迷藏",
	ShowUnlock = false,
}
ModulesUnlockConfig[ModulesUnlockID.Id023] =
{
	Id = 23,
	Name = "Setting",
	Unlock = -1,
	IsApp = true,
	AppName = "设置",
	SortId = 199,
	IconAtlas = "HomeUI",
	Icon = "Home_Bth_icon6",
	IsInternal = 0,
	ShowUnlock = false,
}
ModulesUnlockConfig[ModulesUnlockID.Id024] =
{
	Id = 24,
	Name = "Signin",
	Unlock = -1,
	IsApp = true,
	AppName = "签到",
	IconAtlas = "HomeUI",
	Icon = "Home_Bth_icon7",
	IsInternal = 0,
	ShowUnlock = false,
}
ModulesUnlockConfig[ModulesUnlockID.Id025] =
{
	Id = 25,
	Name = "Notice",
	Unlock = -1,
	IsApp = true,
	AppName = "公告",
	SortId = 198,
	IconAtlas = "HomeUI",
	Icon = "Home_Bth_icon8",
	IsInternal = 0,
	ShowUnlock = false,
}
ModulesUnlockConfig[ModulesUnlockID.Id026] =
{
	Id = 26,
	Name = "Mail",
	Unlock = -1,
	IsApp = true,
	AppName = "邮件",
	SortId = 197,
	IconAtlas = "HomeUI",
	Icon = "Home_Bth_icon9",
	IsInternal = 0,
	ShowUnlock = false,
}
ModulesUnlockConfig[ModulesUnlockID.Id027] =
{
	Id = 27,
	Name = "Newspaper",
	Unlock = -1,
	IsApp = true,
	AppName = "周报",
	SortId = 196,
	IconAtlas = "HomeUI",
	Icon = "Home_Bth_icon10",
	IsInternal = 0,
	ShowUnlock = false,
}
ModulesUnlockConfig[ModulesUnlockID.Id028] =
{
	Id = 28,
	Name = "IAP",
	Unlock = -1,
	IsApp = true,
	AppName = "商城",
	SortId = 79,
	IconAtlas = "HomeUI",
	Icon = "Home_Bth_icon11",
	IsInternal = 0,
	ShowUnlock = false,
}
ModulesUnlockConfig[ModulesUnlockID.Id029] =
{
	Id = 29,
	Name = "HomeFurnitureShop",
	Unlock = -1,
	IsApp = true,
	AppName = "家具淘",
	SortId = 88,
	IconAtlas = "HomeUI",
	Icon = "Home_Bth_icon12",
	IsInternal = 0,
	ShowUnlock = false,
}
ModulesUnlockConfig[ModulesUnlockID.Id030] =
{
	Id = 30,
	Name = "Weekly",
	Unlock = -1,
	IsApp = true,
	AppName = "每周计划",
	SortId = 89,
	IconAtlas = "HomeUI",
	Icon = "Home_Bth_icon13",
	IsInternal = 0,
	ShowUnlock = false,
}
ModulesUnlockConfig[ModulesUnlockID.Id031] =
{
	Id = 31,
	Name = "HomeAchievement",
	Unlock = -1,
	IsApp = true,
	AppName = "家园之星",
	SortId = 87,
	IconAtlas = "HomeUI",
	Icon = "Home_Bth_icon14",
	IsInternal = 0,
	ShowUnlock = false,
}

