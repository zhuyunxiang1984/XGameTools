
GoalConfig[GoalID.Id9001] =
{
	Id = 9001,
	Name = "钢铁的友谊",
	GoalType = GoalType.Achievement,
	ShowFirst = false,
	GoalTrigger = 
	{
		TriggerType.Explore,
	},
	GoalCondition = 
	{
		{
			Name = "派遣[62E7E7]呜呜[-]、[62E7E7]漆漆[-]探索[FDDE40]冒险星[-]24小时",
			Type = ItemType.Time,
			CountType = GoalCountType.StartNow,
			Num = 86400,
			Character = 
			{
				220001,
				220002,
			},
			Value = 120001,
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 100,
		},
	},
	Postcard = 370001,
}
GoalConfig[GoalID.Id9002] =
{
	Id = 9002,
	Name = "黄金的友谊",
	GoalType = GoalType.Achievement,
	ShowFirst = false,
	GoalTrigger = 
	{
		TriggerType.Explore,
	},
	GoalCondition = 
	{
		{
			Name = "派遣[62E7E7]呜呜[-]、[62E7E7]漆漆[-]探索[FDDE40]美食星[-]24小时",
			Type = ItemType.Time,
			CountType = GoalCountType.StartNow,
			Num = 86400,
			Character = 
			{
				220001,
				220002,
			},
			Value = 120002,
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 100,
		},
	},
	Postcard = 370002,
}
GoalConfig[GoalID.Id9003] =
{
	Id = 9003,
	Name = "白金的友谊",
	GoalType = GoalType.Achievement,
	ShowFirst = false,
	GoalTrigger = 
	{
		TriggerType.Explore,
	},
	GoalCondition = 
	{
		{
			Name = "派遣[62E7E7]呜呜[-]、[62E7E7]漆漆[-]探索[FDDE40]博物馆星[-]24小时",
			Type = ItemType.Time,
			CountType = GoalCountType.StartNow,
			Num = 86400,
			Character = 
			{
				220001,
				220002,
			},
			Value = 120003,
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 100,
		},
	},
	Postcard = 370003,
}
GoalConfig[GoalID.Id9004] =
{
	Id = 9004,
	Name = "一起成为冒险家",
	GoalType = GoalType.Achievement,
	ShowFirst = false,
	GoalTrigger = 
	{
		TriggerType.CollectItem,
	},
	GoalCondition = 
	{
		{
			Name = "拥有探险家呜呜(呜呜皮肤)和探险家漆漆(漆漆皮肤)",
			Type = ItemType.Skin,
			CountType = GoalCountType.Current,
			Num = 1,
			Value = 232001,
		},
		
		{
			Name = "拥有探险家呜呜(呜呜皮肤)和探险家漆漆(漆漆皮肤)",
			Type = ItemType.Skin,
			CountType = GoalCountType.Current,
			Num = 1,
			Value = 232002,
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 100,
		},
	},
	Postcard = 370004,
}
GoalConfig[GoalID.Id9005] =
{
	Id = 9005,
	Name = "勇者去冒险",
	GoalType = GoalType.Achievement,
	ShowFirst = false,
	GoalTrigger = 
	{
		TriggerType.Explore,
	},
	GoalCondition = 
	{
		{
			Name = "派遣[62E7E7]剑士[-]、[62E7E7]弓箭手[-]、[62E7E7]魔法师[-]、[62E7E7]刺客[-]、[62E7E7]牧师[-]探索[FDDE40]冒险星[-]24小时",
			Type = ItemType.Time,
			CountType = GoalCountType.StartNow,
			Num = 86400,
			Character = 
			{
				220003,
				220004,
				220010,
				220020,
				220021,
			},
			Value = 120001,
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 100,
		},
	},
	Postcard = 370005,
}
GoalConfig[GoalID.Id9006] =
{
	Id = 9006,
	Name = "人虫大战",
	GoalType = GoalType.Achievement,
	ShowFirst = false,
	GoalTrigger = 
	{
		TriggerType.CollectItem,
	},
	GoalCondition = 
	{
		{
			Name = "拥有雷普利(除虫者皮肤)和异形(异虫霸格皮肤)",
			Type = ItemType.Skin,
			CountType = GoalCountType.Current,
			Num = 1,
			Value = 232018,
		},
		
		{
			Name = "拥有雷普利(除虫者皮肤)和异形(异虫霸格皮肤)",
			Type = ItemType.Skin,
			CountType = GoalCountType.Current,
			Num = 1,
			Value = 232019,
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 100,
		},
	},
	Postcard = 370006,
}
GoalConfig[GoalID.Id9007] =
{
	Id = 9007,
	Name = "魔王的衣橱",
	GoalType = GoalType.Achievement,
	ShowFirst = false,
	GoalTrigger = 
	{
		TriggerType.CollectItem,
	},
	GoalCondition = 
	{
		{
			Name = "完成大魔王所有皮肤挑战",
			Type = ItemType.Skin,
			CountType = GoalCountType.Current,
			Num = 1,
			Value = 232036,
		},
		
		{
			Name = "完成大魔王所有皮肤挑战",
			Type = ItemType.Skin,
			CountType = GoalCountType.Current,
			Num = 1,
			Value = 232037,
		},
		
		{
			Name = "完成大魔王所有皮肤挑战",
			Type = ItemType.Skin,
			CountType = GoalCountType.Current,
			Num = 1,
			Value = 232038,
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 100,
		},
	},
	Postcard = 370007,
}
GoalConfig[GoalID.Id9008] =
{
	Id = 9008,
	Name = "困难的制作组",
	GoalType = GoalType.Achievement,
	ShowFirst = false,
	GoalTrigger = 
	{
		TriggerType.CollectItem,
	},
	GoalCondition = 
	{
		{
			Name = "拥有美术妹子和程序猿",
			Type = ItemType.Character,
			CountType = GoalCountType.Current,
			Num = 1,
			Value = 220025,
		},
		
		{
			Name = "拥有美术妹子和程序猿",
			Type = ItemType.Character,
			CountType = GoalCountType.Current,
			Num = 1,
			Value = 220024,
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 100,
		},
	},
	Postcard = 370008,
}
GoalConfig[GoalID.Id9009] =
{
	Id = 9009,
	Name = "豪华的制作组",
	GoalType = GoalType.Achievement,
	ShowFirst = false,
	GoalTrigger = 
	{
		TriggerType.CollectItem,
	},
	GoalCondition = 
	{
		{
			Name = "拥有美术妹子、程序猿、动画师和配音演员",
			Type = ItemType.Character,
			CountType = GoalCountType.Current,
			Num = 1,
			Value = 220025,
		},
		
		{
			Name = "拥有美术妹子、程序猿、动画师和配音演员",
			Type = ItemType.Character,
			CountType = GoalCountType.Current,
			Num = 1,
			Value = 220024,
		},
		
		{
			Name = "拥有美术妹子、程序猿、动画师和配音演员",
			Type = ItemType.Character,
			CountType = GoalCountType.Current,
			Num = 1,
			Value = 220023,
		},
		
		{
			Name = "拥有美术妹子、程序猿、动画师和配音演员",
			Type = ItemType.Character,
			CountType = GoalCountType.Current,
			Num = 1,
			Value = 220022,
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 100,
		},
	},
	Postcard = 370009,
}
GoalConfig[GoalID.Id9010] =
{
	Id = 9010,
	Name = "民居里的宝箱",
	GoalType = GoalType.Achievement,
	ShowFirst = false,
	GoalTrigger = 
	{
		TriggerType.Explore,
	},
	GoalCondition = 
	{
		{
			Name = "派遣[62E7E7]剑士[-]、[62E7E7]居民NPC[-]探索[FDDE40]冒险星[-]24小时",
			Type = ItemType.Time,
			CountType = GoalCountType.StartNow,
			Num = 86400,
			Character = 
			{
				220003,
				220011,
			},
			Value = 120001,
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 100,
		},
	},
	Postcard = 370010,
}
GoalConfig[GoalID.Id9051] =
{
	Id = 9051,
	Name = "七个小矮糖",
	GoalType = GoalType.Achievement,
	ShowFirst = false,
	GoalTrigger = 
	{
		TriggerType.CollectItem,
	},
	GoalCondition = 
	{
		{
			Name = "拥有小红、小橙、小黄、小绿、小青、小蓝和小紫",
			Type = ItemType.Character,
			CountType = GoalCountType.Current,
			Num = 1,
			Value = 220105,
		},
		
		{
			Name = "拥有小红、小橙、小黄、小绿、小青、小蓝和小紫",
			Type = ItemType.Character,
			CountType = GoalCountType.Current,
			Num = 1,
			Value = 220106,
		},
		
		{
			Name = "拥有小红、小橙、小黄、小绿、小青、小蓝和小紫",
			Type = ItemType.Character,
			CountType = GoalCountType.Current,
			Num = 1,
			Value = 220107,
		},
		
		{
			Name = "拥有小红、小橙、小黄、小绿、小青、小蓝和小紫",
			Type = ItemType.Character,
			CountType = GoalCountType.Current,
			Num = 1,
			Value = 220108,
		},
		
		{
			Name = "拥有小红、小橙、小黄、小绿、小青、小蓝和小紫",
			Type = ItemType.Character,
			CountType = GoalCountType.Current,
			Num = 1,
			Value = 220109,
		},
		
		{
			Name = "拥有小红、小橙、小黄、小绿、小青、小蓝和小紫",
			Type = ItemType.Character,
			CountType = GoalCountType.Current,
			Num = 1,
			Value = 220110,
		},
		
		{
			Name = "拥有小红、小橙、小黄、小绿、小青、小蓝和小紫",
			Type = ItemType.Character,
			CountType = GoalCountType.Current,
			Num = 1,
			Value = 220111,
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 100,
		},
	},
	Postcard = 370101,
}
GoalConfig[GoalID.Id9052] =
{
	Id = 9052,
	Name = "公主和七个小矮糖",
	GoalType = GoalType.Achievement,
	ShowFirst = false,
	GoalTrigger = 
	{
		TriggerType.CollectItem,
	},
	GoalCondition = 
	{
		{
			Name = "拥有小红、小橙、小黄、小绿、小青、小蓝、小紫和冰淇淋公主",
			Type = ItemType.Character,
			CountType = GoalCountType.Current,
			Num = 1,
			Value = 220105,
		},
		
		{
			Name = "拥有小红、小橙、小黄、小绿、小青、小蓝、小紫和冰淇淋公主",
			Type = ItemType.Character,
			CountType = GoalCountType.Current,
			Num = 1,
			Value = 220106,
		},
		
		{
			Name = "拥有小红、小橙、小黄、小绿、小青、小蓝、小紫和冰淇淋公主",
			Type = ItemType.Character,
			CountType = GoalCountType.Current,
			Num = 1,
			Value = 220107,
		},
		
		{
			Name = "拥有小红、小橙、小黄、小绿、小青、小蓝、小紫和冰淇淋公主",
			Type = ItemType.Character,
			CountType = GoalCountType.Current,
			Num = 1,
			Value = 220108,
		},
		
		{
			Name = "拥有小红、小橙、小黄、小绿、小青、小蓝、小紫和冰淇淋公主",
			Type = ItemType.Character,
			CountType = GoalCountType.Current,
			Num = 1,
			Value = 220109,
		},
		
		{
			Name = "拥有小红、小橙、小黄、小绿、小青、小蓝、小紫和冰淇淋公主",
			Type = ItemType.Character,
			CountType = GoalCountType.Current,
			Num = 1,
			Value = 220110,
		},
		
		{
			Name = "拥有小红、小橙、小黄、小绿、小青、小蓝、小紫和冰淇淋公主",
			Type = ItemType.Character,
			CountType = GoalCountType.Current,
			Num = 1,
			Value = 220111,
		},
		
		{
			Name = "拥有小红、小橙、小黄、小绿、小青、小蓝、小紫和冰淇淋公主",
			Type = ItemType.Character,
			CountType = GoalCountType.Current,
			Num = 1,
			Value = 220123,
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 100,
		},
	},
	Postcard = 370102,
}
GoalConfig[GoalID.Id9053] =
{
	Id = 9053,
	Name = "问答游戏",
	GoalType = GoalType.Achievement,
	ShowFirst = false,
	GoalTrigger = 
	{
		TriggerType.CollectItem,
	},
	GoalCondition = 
	{
		{
			Name = "拥有黑巧克力皇后和冰淇淋公主",
			Type = ItemType.Character,
			CountType = GoalCountType.Current,
			Num = 1,
			Value = 220121,
		},
		
		{
			Name = "拥有黑巧克力皇后和冰淇淋公主",
			Type = ItemType.Character,
			CountType = GoalCountType.Current,
			Num = 1,
			Value = 220123,
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 100,
		},
	},
	Postcard = 370103,
}
GoalConfig[GoalID.Id9054] =
{
	Id = 9054,
	Name = "绝望主妇",
	GoalType = GoalType.Achievement,
	ShowFirst = false,
	GoalTrigger = 
	{
		TriggerType.Explore,
	},
	GoalCondition = 
	{
		{
			Name = "派遣[62E7E7]棉花糖公主[-]、[62E7E7]冰淇淋公主[-]、[62E7E7]蛋糕卷公主[-]、[62E7E7]栗子蛋糕公主[-]探索[FDDE40]冒险星[-]48小时",
			Type = ItemType.Time,
			CountType = GoalCountType.StartNow,
			Num = 172800,
			Character = 
			{
				220122,
				220123,
				220124,
				220125,
			},
			Value = 120001,
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 100,
		},
	},
	Postcard = 370104,
}
GoalConfig[GoalID.Id9055] =
{
	Id = 9055,
	Name = "沉睡魔咒舞台剧",
	GoalType = GoalType.Achievement,
	ShowFirst = false,
	GoalTrigger = 
	{
		TriggerType.CollectItem,
	},
	GoalCondition = 
	{
		{
			Name = "拥有炸鸡魔后、松饼仙子、华夫饼仙子、布丁仙子和棉花糖公主",
			Type = ItemType.Character,
			CountType = GoalCountType.Current,
			Num = 1,
			Value = 220129,
		},
		
		{
			Name = "拥有炸鸡魔后、松饼仙子、华夫饼仙子、布丁仙子和棉花糖公主",
			Type = ItemType.Character,
			CountType = GoalCountType.Current,
			Num = 1,
			Value = 220115,
		},
		
		{
			Name = "拥有炸鸡魔后、松饼仙子、华夫饼仙子、布丁仙子和棉花糖公主",
			Type = ItemType.Character,
			CountType = GoalCountType.Current,
			Num = 1,
			Value = 220114,
		},
		
		{
			Name = "拥有炸鸡魔后、松饼仙子、华夫饼仙子、布丁仙子和棉花糖公主",
			Type = ItemType.Character,
			CountType = GoalCountType.Current,
			Num = 1,
			Value = 220116,
		},
		
		{
			Name = "拥有炸鸡魔后、松饼仙子、华夫饼仙子、布丁仙子和棉花糖公主",
			Type = ItemType.Character,
			CountType = GoalCountType.Current,
			Num = 1,
			Value = 220122,
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 100,
		},
	},
	Postcard = 370105,
}
GoalConfig[GoalID.Id9056] =
{
	Id = 9056,
	Name = "快餐联谊",
	GoalType = GoalType.Achievement,
	ShowFirst = false,
	GoalTrigger = 
	{
		TriggerType.CollectItem,
	},
	GoalCondition = 
	{
		{
			Name = "拥有角色热狗先生、汉堡小姐、番茄酱侍卫和薯条国王",
			Type = ItemType.Character,
			CountType = GoalCountType.Current,
			Num = 1,
			Value = 220127,
		},
		
		{
			Name = "拥有角色热狗先生、汉堡小姐、番茄酱侍卫和薯条国王",
			Type = ItemType.Character,
			CountType = GoalCountType.Current,
			Num = 1,
			Value = 220126,
		},
		
		{
			Name = "拥有角色热狗先生、汉堡小姐、番茄酱侍卫和薯条国王",
			Type = ItemType.Character,
			CountType = GoalCountType.Current,
			Num = 1,
			Value = 220128,
		},
		
		{
			Name = "拥有角色热狗先生、汉堡小姐、番茄酱侍卫和薯条国王",
			Type = ItemType.Character,
			CountType = GoalCountType.Current,
			Num = 1,
			Value = 220131,
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 100,
		},
	},
	Postcard = 370106,
}
GoalConfig[GoalID.Id9057] =
{
	Id = 9057,
	Name = "牵手成功",
	GoalType = GoalType.Achievement,
	ShowFirst = false,
	GoalTrigger = 
	{
		TriggerType.Explore,
	},
	GoalCondition = 
	{
		{
			Name = "派遣[62E7E7]汉堡小姐[-]、[62E7E7]热狗先生[-]探索[FDDE40]美食星[-]24小时",
			Type = ItemType.Time,
			CountType = GoalCountType.StartNow,
			Num = 86400,
			Character = 
			{
				220126,
				220127,
			},
			Value = 120002,
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 100,
		},
	},
	Postcard = 370107,
}
GoalConfig[GoalID.Id9058] =
{
	Id = 9058,
	Name = "灰姑娘现场",
	GoalType = GoalType.Achievement,
	ShowFirst = false,
	GoalTrigger = 
	{
		TriggerType.CollectItem,
	},
	GoalCondition = 
	{
		{
			Name = "拥有蛋糕卷公主、薯片夫人、妙脆角小姐和虾条小姐",
			Type = ItemType.Character,
			CountType = GoalCountType.Current,
			Num = 1,
			Value = 220124,
		},
		
		{
			Name = "拥有蛋糕卷公主、薯片夫人、妙脆角小姐和虾条小姐",
			Type = ItemType.Character,
			CountType = GoalCountType.Current,
			Num = 1,
			Value = 220120,
		},
		
		{
			Name = "拥有蛋糕卷公主、薯片夫人、妙脆角小姐和虾条小姐",
			Type = ItemType.Character,
			CountType = GoalCountType.Current,
			Num = 1,
			Value = 220118,
		},
		
		{
			Name = "拥有蛋糕卷公主、薯片夫人、妙脆角小姐和虾条小姐",
			Type = ItemType.Character,
			CountType = GoalCountType.Current,
			Num = 1,
			Value = 220117,
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 100,
		},
	},
	Postcard = 370108,
}
GoalConfig[GoalID.Id9059] =
{
	Id = 9059,
	Name = "一见钟情？",
	GoalType = GoalType.Achievement,
	ShowFirst = false,
	GoalTrigger = 
	{
		TriggerType.CollectItem,
	},
	GoalCondition = 
	{
		{
			Name = "拥有可乐王子和爆米花女王",
			Type = ItemType.Character,
			CountType = GoalCountType.Current,
			Num = 1,
			Value = 220103,
		},
		
		{
			Name = "拥有可乐王子和爆米花女王",
			Type = ItemType.Character,
			CountType = GoalCountType.Current,
			Num = 1,
			Value = 220130,
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 100,
		},
	},
	Postcard = 370109,
}
GoalConfig[GoalID.Id9060] =
{
	Id = 9060,
	Name = "秘密的约会",
	GoalType = GoalType.Achievement,
	ShowFirst = false,
	GoalTrigger = 
	{
		TriggerType.Explore,
	},
	GoalCondition = 
	{
		{
			Name = "派遣[62E7E7]可乐王子[-]、[62E7E7]爆米花女王[-]探索[FDDE40]悬疑星[-]24小时",
			Type = ItemType.Time,
			CountType = GoalCountType.StartNow,
			Num = 86400,
			Character = 
			{
				220103,
				220130,
			},
			Value = 120004,
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 100,
		},
	},
	Postcard = 370110,
}
GoalConfig[GoalID.Id9061] =
{
	Id = 9061,
	Name = "男人的周末",
	GoalType = GoalType.Achievement,
	ShowFirst = false,
	GoalTrigger = 
	{
		TriggerType.Explore,
	},
	GoalCondition = 
	{
		{
			Name = "派遣[62E7E7]奶茶王子[-]、[62E7E7]汽水王子[-]、[62E7E7]可乐王子[-]、[62E7E7]啤酒王子[-]探索[FDDE40]美食星[-]48小时",
			Type = ItemType.Time,
			CountType = GoalCountType.StartNow,
			Num = 172800,
			Character = 
			{
				220101,
				220102,
				220103,
				220104,
			},
			Value = 120002,
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 100,
		},
	},
	Postcard = 370111,
}
GoalConfig[GoalID.Id9101] =
{
	Id = 9101,
	Name = "创世界",
	GoalType = GoalType.Achievement,
	ShowFirst = false,
	GoalTrigger = 
	{
		TriggerType.Explore,
	},
	GoalCondition = 
	{
		{
			Name = "派遣创造之神和亚当探索博物馆星24小时",
			Type = ItemType.Time,
			CountType = GoalCountType.StartNow,
			Num = 86400,
			Character = 
			{
				220210,
				220211,
			},
			Value = 120003,
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 100,
		},
	},
	Postcard = 370201,
}
GoalConfig[GoalID.Id9102] =
{
	Id = 9102,
	Name = "四神壁画",
	GoalType = GoalType.Achievement,
	ShowFirst = false,
	GoalTrigger = 
	{
		TriggerType.Explore,
	},
	GoalCondition = 
	{
		{
			Name = "派遣赛特、荷鲁斯、阿努比斯和索贝克探索博物馆星24小时",
			Type = ItemType.Time,
			CountType = GoalCountType.StartNow,
			Num = 86400,
			Character = 
			{
				220220,
				220221,
				220222,
				220223,
			},
			Value = 120003,
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 100,
		},
	},
	Postcard = 370202,
}
GoalConfig[GoalID.Id9103] =
{
	Id = 9103,
	Name = "浣熊三人组",
	GoalType = GoalType.Achievement,
	ShowFirst = false,
	GoalTrigger = 
	{
		TriggerType.CollectItem,
	},
	GoalCondition = 
	{
		{
			Name = "拥有角色浣熊大哥、浣熊二哥和浣熊小弟",
			Type = ItemType.Character,
			CountType = GoalCountType.Current,
			Num = 1,
			Value = 220203,
		},
		
		{
			Name = "拥有角色浣熊大哥、浣熊二哥和浣熊小弟",
			Type = ItemType.Character,
			CountType = GoalCountType.Current,
			Num = 1,
			Value = 220204,
		},
		
		{
			Name = "拥有角色浣熊大哥、浣熊二哥和浣熊小弟",
			Type = ItemType.Character,
			CountType = GoalCountType.Current,
			Num = 1,
			Value = 220205,
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 100,
		},
	},
	Postcard = 370203,
}
GoalConfig[GoalID.Id9104] =
{
	Id = 9104,
	Name = "这次发财了！",
	GoalType = GoalType.Achievement,
	ShowFirst = false,
	GoalTrigger = 
	{
		TriggerType.Explore,
	},
	GoalCondition = 
	{
		{
			Name = "派遣[62E7E7]浣熊大哥[-]、[62E7E7]浣熊二哥[-]、[62E7E7]浣熊小弟[-]探索[FDDE40]博物馆星[-]24小时",
			Type = ItemType.Time,
			CountType = GoalCountType.StartNow,
			Num = 86400,
			Character = 
			{
				220203,
				220204,
				220205,
			},
			Value = 120003,
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 100,
		},
	},
	Postcard = 370204,
}
GoalConfig[GoalID.Id9105] =
{
	Id = 9105,
	Name = "孤独的画像",
	GoalType = GoalType.Achievement,
	ShowFirst = false,
	GoalTrigger = 
	{
		TriggerType.CollectItem,
	},
	GoalCondition = 
	{
		{
			Name = "拥有大病初愈(独耳画像皮肤)和点彩画法(独耳画像皮肤)",
			Type = ItemType.Skin,
			CountType = GoalCountType.Current,
			Num = 1,
			Value = 232103,
		},
		
		{
			Name = "拥有大病初愈(独耳画像皮肤)和点彩画法(独耳画像皮肤)",
			Type = ItemType.Skin,
			CountType = GoalCountType.Current,
			Num = 1,
			Value = 232104,
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 100,
		},
	},
	Postcard = 370205,
}
GoalConfig[GoalID.Id9106] =
{
	Id = 9106,
	Name = "怪盗与公爵夫人",
	GoalType = GoalType.Achievement,
	ShowFirst = false,
	GoalTrigger = 
	{
		TriggerType.Explore,
	},
	GoalCondition = 
	{
		{
			Name = "派遣[62E7E7]微笑女神[-]、[62E7E7]魔术师[-]探索[FDDE40]博物馆星[-]24小时",
			Type = ItemType.Time,
			CountType = GoalCountType.StartNow,
			Num = 86400,
			Character = 
			{
				220226,
				220227,
			},
			Value = 120003,
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 100,
		},
	},
	Postcard = 370206,
}
GoalConfig[GoalID.Id9107] =
{
	Id = 9107,
	Name = "重见天日",
	GoalType = GoalType.Achievement,
	ShowFirst = false,
	GoalTrigger = 
	{
		TriggerType.Explore,
	},
	GoalCondition = 
	{
		{
			Name = "派遣半人马石像、兵马俑、默艾和石柱人探索博物馆星24小时",
			Type = ItemType.Time,
			CountType = GoalCountType.StartNow,
			Num = 86400,
			Character = 
			{
				220206,
				220207,
				220208,
				220209,
			},
			Value = 120003,
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 100,
		},
	},
	Postcard = 370207,
}
GoalConfig[GoalID.Id9108] =
{
	Id = 9108,
	Name = "疯狂原始人",
	GoalType = GoalType.Achievement,
	ShowFirst = false,
	GoalTrigger = 
	{
		TriggerType.Explore,
	},
	GoalCondition = 
	{
		{
			Name = "派遣原始人爸爸、原始人妈妈和原始人儿子探索博物馆星24小时",
			Type = ItemType.Time,
			CountType = GoalCountType.StartNow,
			Num = 86400,
			Character = 
			{
				220214,
				220215,
				220216,
			},
			Value = 120003,
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 100,
		},
	},
	Postcard = 370208,
}
GoalConfig[GoalID.Id9109] =
{
	Id = 9109,
	Name = "我爱我自己",
	GoalType = GoalType.Achievement,
	ShowFirst = false,
	GoalTrigger = 
	{
		TriggerType.CollectItem,
	},
	GoalCondition = 
	{
		{
			Name = "拥有春花与秋实(弗里达皮肤)和苦难与辉煌(弗里达皮肤)",
			Type = ItemType.Skin,
			CountType = GoalCountType.Current,
			Num = 1,
			Value = 232105,
		},
		
		{
			Name = "拥有春花与秋实(弗里达皮肤)和苦难与辉煌(弗里达皮肤)",
			Type = ItemType.Skin,
			CountType = GoalCountType.Current,
			Num = 1,
			Value = 232106,
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 100,
		},
	},
	Postcard = 370209,
}
GoalConfig[GoalID.Id9110] =
{
	Id = 9110,
	Name = "艺术的冲击",
	GoalType = GoalType.Achievement,
	ShowFirst = false,
	GoalTrigger = 
	{
		TriggerType.CollectItem,
	},
	GoalCondition = 
	{
		{
			Name = "拥有呐喊家和哭泣的女人",
			Type = ItemType.Character,
			CountType = GoalCountType.Current,
			Num = 1,
			Value = 220213,
		},
		
		{
			Name = "拥有呐喊家和哭泣的女人",
			Type = ItemType.Character,
			CountType = GoalCountType.Current,
			Num = 1,
			Value = 220212,
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 100,
		},
	},
	Postcard = 370210,
}
GoalConfig[GoalID.Id9151] =
{
	Id = 9151,
	Name = "猫耳三姐妹",
	GoalType = GoalType.Achievement,
	ShowFirst = false,
	GoalTrigger = 
	{
		TriggerType.Explore,
	},
	GoalCondition = 
	{
		{
			Name = "派遣[62E7E7]小泪[-]、[62E7E7]小瞳[-]、[62E7E7]小爱[-]探索[FDDE40]博物馆星[-]24小时",
			Type = ItemType.Time,
			CountType = GoalCountType.StartNow,
			Num = 86400,
			Character = 
			{
				220306,
				220307,
				220308,
			},
			Value = 120003,
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 100,
		},
	},
	Postcard = 370301,
}
GoalConfig[GoalID.Id9152] =
{
	Id = 9152,
	Name = "案件重演",
	GoalType = GoalType.Achievement,
	ShowFirst = false,
	GoalTrigger = 
	{
		TriggerType.Explore,
	},
	GoalCondition = 
	{
		{
			Name = "派遣大作家（蓝衣小学生皮肤）、阿加莎探索悬疑星现场 24小时",
			Type = ItemType.Time,
			CountType = GoalCountType.StartNow,
			Num = 86400,
			Character = 
			{
				220302,
			},
			Skin = 
			{
				232142,
			},
			Value = 130156,
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 100,
		},
	},
	Postcard = 370302,
}
GoalConfig[GoalID.Id9153] =
{
	Id = 9153,
	Name = "IQ 100,000,000",
	GoalType = GoalType.Achievement,
	ShowFirst = false,
	GoalTrigger = 
	{
		TriggerType.CollectItem,
	},
	GoalCondition = 
	{
		{
			Name = "拥有角色检察官、博士、迈克罗夫特和蓝衣小学生",
			Type = ItemType.Character,
			CountType = GoalCountType.Current,
			Num = 1,
			Value = 220318,
		},
		
		{
			Name = "拥有角色检察官、博士、迈克罗夫特和蓝衣小学生",
			Type = ItemType.Character,
			CountType = GoalCountType.Current,
			Num = 1,
			Value = 220315,
		},
		
		{
			Name = "拥有角色检察官、博士、迈克罗夫特和蓝衣小学生",
			Type = ItemType.Character,
			CountType = GoalCountType.Current,
			Num = 1,
			Value = 220323,
		},
		
		{
			Name = "拥有角色检察官、博士、迈克罗夫特和蓝衣小学生",
			Type = ItemType.Character,
			CountType = GoalCountType.Current,
			Num = 1,
			Value = 220322,
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 100,
		},
	},
	Postcard = 370303,
}
GoalConfig[GoalID.Id9154] =
{
	Id = 9154,
	Name = "有生之年",
	GoalType = GoalType.Achievement,
	ShowFirst = false,
	GoalTrigger = 
	{
		TriggerType.CollectItem,
	},
	GoalCondition = 
	{
		{
			Name = "拥有读者、编辑长和大作家(蓝衣小学生皮肤)",
			Type = ItemType.Character,
			CountType = GoalCountType.Current,
			Num = 1,
			Value = 220310,
		},
		
		{
			Name = "拥有读者、编辑长和大作家(蓝衣小学生皮肤)",
			Type = ItemType.Character,
			CountType = GoalCountType.Current,
			Num = 1,
			Value = 220309,
		},
		
		{
			Name = "拥有读者、编辑长和大作家(蓝衣小学生皮肤)",
			Type = ItemType.Skin,
			CountType = GoalCountType.Current,
			Num = 1,
			Value = 232142,
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 100,
		},
	},
	Postcard = 370304,
}
GoalConfig[GoalID.Id9155] =
{
	Id = 9155,
	Name = "睡衣派对",
	GoalType = GoalType.Achievement,
	ShowFirst = false,
	GoalTrigger = 
	{
		TriggerType.CollectItem,
	},
	GoalCondition = 
	{
		{
			Name = "拥有睡衣侦探（大侦探皮肤）、睡衣助理（侦探助理皮肤）和睡衣教授（教授皮肤）",
			Type = ItemType.Skin,
			CountType = GoalCountType.Current,
			Num = 1,
			Value = 232145,
		},
		
		{
			Name = "拥有睡衣侦探（大侦探皮肤）、睡衣助理（侦探助理皮肤）和睡衣教授（教授皮肤）",
			Type = ItemType.Skin,
			CountType = GoalCountType.Current,
			Num = 1,
			Value = 232140,
		},
		
		{
			Name = "拥有睡衣侦探（大侦探皮肤）、睡衣助理（侦探助理皮肤）和睡衣教授（教授皮肤）",
			Type = ItemType.Skin,
			CountType = GoalCountType.Current,
			Num = 1,
			Value = 232149,
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 100,
		},
	},
	Postcard = 370305,
}
GoalConfig[GoalID.Id9156] =
{
	Id = 9156,
	Name = "坏蛋联盟",
	GoalType = GoalType.Achievement,
	ShowFirst = false,
	GoalTrigger = 
	{
		TriggerType.CollectItem,
	},
	GoalCondition = 
	{
		{
			Name = "拥有黑警长（豆豆警官皮肤）、黑法医（法医皮肤）和剪刀手杰克（杰克瑞波皮肤）",
			Type = ItemType.Skin,
			CountType = GoalCountType.Current,
			Num = 1,
			Value = 232134,
		},
		
		{
			Name = "拥有黑警长（豆豆警官皮肤）、黑法医（法医皮肤）和剪刀手杰克（杰克瑞波皮肤）",
			Type = ItemType.Skin,
			CountType = GoalCountType.Current,
			Num = 1,
			Value = 232135,
		},
		
		{
			Name = "拥有黑警长（豆豆警官皮肤）、黑法医（法医皮肤）和剪刀手杰克（杰克瑞波皮肤）",
			Type = ItemType.Skin,
			CountType = GoalCountType.Current,
			Num = 1,
			Value = 232141,
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 100,
		},
	},
	Postcard = 370306,
}
GoalConfig[GoalID.Id9157] =
{
	Id = 9157,
	Name = "宿命对决",
	GoalType = GoalType.Achievement,
	ShowFirst = false,
	GoalTrigger = 
	{
		TriggerType.CollectItem,
	},
	GoalCondition = 
	{
		{
			Name = "拥有50级大侦探及50级教授",
			Type = ItemType.Character,
			CountType = GoalCountType.Current,
			Num = 1,
			Value = 220324,
			Level = 50,
		},
		
		{
			Name = "拥有50级大侦探及50级教授",
			Type = ItemType.Character,
			CountType = GoalCountType.Current,
			Num = 1,
			Value = 220325,
			Level = 50,
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 100,
		},
	},
	Postcard = 370307,
}
GoalConfig[GoalID.Id9158] =
{
	Id = 9158,
	Name = "最佳拍档",
	GoalType = GoalType.Achievement,
	ShowFirst = false,
	GoalTrigger = 
	{
		TriggerType.Explore,
	},
	GoalCondition = 
	{
		{
			Name = "派遣[62E7E7]侦探助理[-]、[62E7E7]大侦探[-]探索悬疑星[FDDE40]邮局[-]24小时",
			Type = ItemType.Time,
			CountType = GoalCountType.StartNow,
			Num = 86400,
			Character = 
			{
				220320,
				220324,
			},
			Value = 130154,
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 100,
		},
	},
	Postcard = 370308,
}
GoalConfig[GoalID.Id9159] =
{
	Id = 9159,
	Name = "真相大白",
	GoalType = GoalType.Achievement,
	ShowFirst = false,
	GoalTrigger = 
	{
		TriggerType.Explore,
	},
	GoalCondition = 
	{
		{
			Name = "派遣[62E7E7]侦探助理[-]、[62E7E7]大侦探[-]探索悬疑星[FDDE40]编辑部[-]24小时",
			Type = ItemType.Time,
			CountType = GoalCountType.StartNow,
			Num = 86400,
			Character = 
			{
				220320,
				220324,
			},
			Value = 130161,
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 100,
		},
	},
	Postcard = 370309,
}
GoalConfig[GoalID.Id9160] =
{
	Id = 9160,
	Name = "现场采证",
	GoalType = GoalType.Achievement,
	ShowFirst = false,
	GoalTrigger = 
	{
		TriggerType.CollectItem,
	},
	GoalCondition = 
	{
		{
			Name = "拥有角色豆豆警官、法医、证人、受害者和死者",
			Type = ItemType.Character,
			CountType = GoalCountType.Current,
			Num = 1,
			Value = 220311,
		},
		
		{
			Name = "拥有角色豆豆警官、法医、证人、受害者和死者",
			Type = ItemType.Character,
			CountType = GoalCountType.Current,
			Num = 1,
			Value = 220317,
		},
		
		{
			Name = "拥有角色豆豆警官、法医、证人、受害者和死者",
			Type = ItemType.Character,
			CountType = GoalCountType.Current,
			Num = 1,
			Value = 220316,
		},
		
		{
			Name = "拥有角色豆豆警官、法医、证人、受害者和死者",
			Type = ItemType.Character,
			CountType = GoalCountType.Current,
			Num = 1,
			Value = 220304,
		},
		
		{
			Name = "拥有角色豆豆警官、法医、证人、受害者和死者",
			Type = ItemType.Character,
			CountType = GoalCountType.Current,
			Num = 1,
			Value = 220303,
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 100,
		},
	},
	Postcard = 370310,
}
GoalConfig[GoalID.Id9201] =
{
	Id = 9201,
	Name = "最棒的演出",
	GoalType = GoalType.Achievement,
	ShowFirst = false,
	GoalTrigger = 
	{
		TriggerType.Explore,
	},
	GoalCondition = 
	{
		{
			Name = "派遣[62E7E7]白鲨牙牙[-]、[62E7E7]鲸鲨依伶[-]、[62E7E7]虎鲸京[-]探索[FDDE40]海洋星[-]48小时",
			Type = ItemType.Time,
			CountType = GoalCountType.StartNow,
			Num = 172800,
			Character = 
			{
				220426,
				220427,
				220430,
			},
			Value = 120005,
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 100,
		},
	},
	Postcard = 370401,
}
GoalConfig[GoalID.Id9202] =
{
	Id = 9202,
	Name = "水母的友情",
	GoalType = GoalType.Achievement,
	ShowFirst = false,
	GoalTrigger = 
	{
		TriggerType.Explore,
	},
	GoalCondition = 
	{
		{
			Name = "派遣[62E7E7]黄金纱纱[-]、[62E7E7]灯塔丝丝[-]探索海洋星[FDDE40]深海区[-]48小时",
			Type = ItemType.Time,
			CountType = GoalCountType.StartNow,
			Num = 172800,
			Character = 
			{
				220421,
				220422,
			},
			Value = 130208,
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 100,
		},
	},
	Postcard = 370402,
}
GoalConfig[GoalID.Id9203] =
{
	Id = 9203,
	Name = "和服写真",
	GoalType = GoalType.Achievement,
	ShowFirst = false,
	GoalTrigger = 
	{
		TriggerType.Explore,
	},
	GoalCondition = 
	{
		{
			Name = "派遣[62E7E7]鮟鱇明[-]、[62E7E7]灯塔丝丝[-]、[62E7E7]珊瑚阿卡[-]、[62E7E7]虎鲸京[-]探索海洋星[FDDE40]音乐广场[-]48小时",
			Type = ItemType.Time,
			CountType = GoalCountType.StartNow,
			Num = 172800,
			Character = 
			{
				220419,
				220422,
				220429,
				220430,
			},
			Value = 130202,
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 100,
		},
	},
	Postcard = 370403,
}
GoalConfig[GoalID.Id9204] =
{
	Id = 9204,
	Name = "live house与魔术",
	GoalType = GoalType.Achievement,
	ShowFirst = false,
	GoalTrigger = 
	{
		TriggerType.Explore,
	},
	GoalCondition = 
	{
		{
			Name = "派遣[62E7E7]海星寻沙[-]、[62E7E7]海蛇莱斯莉[-]探索海洋星[FDDE40]演播厅[-]48小时",
			Type = ItemType.Time,
			CountType = GoalCountType.StartNow,
			Num = 172800,
			Character = 
			{
				220423,
				220425,
			},
			Value = 130209,
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 100,
		},
	},
	Postcard = 370404,
}
GoalConfig[GoalID.Id9205] =
{
	Id = 9205,
	Name = "遗落的相片",
	GoalType = GoalType.Achievement,
	ShowFirst = false,
	GoalTrigger = 
	{
		TriggerType.CollectItem,
	},
	GoalCondition = 
	{
		{
			Name = "拥有海胆小茨、海葵彩雅、斗鱼希、乌贼墨、海参橘、鮟鱇明、海蛇莱斯莉和珊瑚阿卡",
			Type = ItemType.Character,
			CountType = GoalCountType.Current,
			Num = 1,
			Value = 220413,
		},
		
		{
			Name = "拥有海胆小茨、海葵彩雅、斗鱼希、乌贼墨、海参橘、鮟鱇明、海蛇莱斯莉和珊瑚阿卡",
			Type = ItemType.Character,
			CountType = GoalCountType.Current,
			Num = 1,
			Value = 220416,
		},
		
		{
			Name = "拥有海胆小茨、海葵彩雅、斗鱼希、乌贼墨、海参橘、鮟鱇明、海蛇莱斯莉和珊瑚阿卡",
			Type = ItemType.Character,
			CountType = GoalCountType.Current,
			Num = 1,
			Value = 220417,
		},
		
		{
			Name = "拥有海胆小茨、海葵彩雅、斗鱼希、乌贼墨、海参橘、鮟鱇明、海蛇莱斯莉和珊瑚阿卡",
			Type = ItemType.Character,
			CountType = GoalCountType.Current,
			Num = 1,
			Value = 220402,
		},
		
		{
			Name = "拥有海胆小茨、海葵彩雅、斗鱼希、乌贼墨、海参橘、鮟鱇明、海蛇莱斯莉和珊瑚阿卡",
			Type = ItemType.Character,
			CountType = GoalCountType.Current,
			Num = 1,
			Value = 220418,
		},
		
		{
			Name = "拥有海胆小茨、海葵彩雅、斗鱼希、乌贼墨、海参橘、鮟鱇明、海蛇莱斯莉和珊瑚阿卡",
			Type = ItemType.Character,
			CountType = GoalCountType.Current,
			Num = 1,
			Value = 220419,
		},
		
		{
			Name = "拥有海胆小茨、海葵彩雅、斗鱼希、乌贼墨、海参橘、鮟鱇明、海蛇莱斯莉和珊瑚阿卡",
			Type = ItemType.Character,
			CountType = GoalCountType.Current,
			Num = 1,
			Value = 220425,
		},
		
		{
			Name = "拥有海胆小茨、海葵彩雅、斗鱼希、乌贼墨、海参橘、鮟鱇明、海蛇莱斯莉和珊瑚阿卡",
			Type = ItemType.Character,
			CountType = GoalCountType.Current,
			Num = 1,
			Value = 220429,
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 100,
		},
	},
	Postcard = 370405,
}
GoalConfig[GoalID.Id9206] =
{
	Id = 9206,
	Name = "秘密",
	GoalType = GoalType.Achievement,
	ShowFirst = false,
	GoalTrigger = 
	{
		TriggerType.CollectItem,
	},
	GoalCondition = 
	{
		{
			Name = "解锁[FDDE40]双生翻[-](鱼不翻皮肤)",
			Type = ItemType.Skin,
			CountType = GoalCountType.Current,
			Num = 1,
			Value = 232168,
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 100,
		},
	},
	Postcard = 370406,
}
GoalConfig[GoalID.Id9207] =
{
	Id = 9207,
	Name = "灵异现象",
	GoalType = GoalType.Achievement,
	ShowFirst = false,
	GoalTrigger = 
	{
		TriggerType.CollectItem,
	},
	GoalCondition = 
	{
		{
			Name = "解锁[FDDE40]人气主播[-](海螺美莎皮肤)",
			Type = ItemType.Skin,
			CountType = GoalCountType.Current,
			Num = 1,
			Value = 232170,
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 100,
		},
	},
	Postcard = 370407,
}
GoalConfig[GoalID.Id9208] =
{
	Id = 9208,
	Name = "倒影",
	GoalType = GoalType.Achievement,
	ShowFirst = false,
	GoalTrigger = 
	{
		TriggerType.CollectItem,
	},
	GoalCondition = 
	{
		{
			Name = "解锁[FDDE40]欧皇彩[-](海豹彩皮肤)",
			Type = ItemType.Skin,
			CountType = GoalCountType.Current,
			Num = 1,
			Value = 232182,
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 100,
		},
	},
	Postcard = 370408,
}
GoalConfig[GoalID.Id9209] =
{
	Id = 9209,
	Name = "剪刀石头布",
	GoalType = GoalType.Achievement,
	ShowFirst = false,
	GoalTrigger = 
	{
		TriggerType.Explore,
	},
	GoalCondition = 
	{
		{
			Name = "派遣[62E7E7]蟹香菜[-]、[62E7E7]虾伊洛[-]探索海洋星[FDDE40]海底世界[-]48小时",
			Type = ItemType.Time,
			CountType = GoalCountType.StartNow,
			Num = 172800,
			Character = 
			{
				220409,
				220410,
			},
			Value = 130213,
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 100,
		},
	},
	Postcard = 370409,
}
GoalConfig[GoalID.Id9210] =
{
	Id = 9210,
	Name = "神奇的海兔",
	GoalType = GoalType.Achievement,
	ShowFirst = false,
	GoalTrigger = 
	{
		TriggerType.CollectItem,
	},
	GoalCondition = 
	{
		{
			Name = "解锁[FDDE40]翌日的幻然[-](海兔幻然皮肤)",
			Type = ItemType.Skin,
			CountType = GoalCountType.Current,
			Num = 1,
			Value = 232173,
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 100,
		},
	},
	Postcard = 370410,
}
GoalConfig[GoalID.Id9801] =
{
	Id = 9801,
	Name = "家园成就1-1",
	GoalType = GoalType.HomeAchievement,
	ShowFirst = false,
	PreCondition = {
		PreArea = 130001,
	},
	GoalTrigger = 
	{
		TriggerType.ClearObstacle,
	},
	GoalCondition = 
	{
		{
			Name = "清理[62E7E7]冒险星[-]障碍[FDDE40]3个[-]",
			Type = ItemType.Obstacle,
			CountType = GoalCountType.StartNow,
			Num = 3,
			TagList = 
			{
				560103,
			},
			Value = -1,
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 45,
		},
	},
}
GoalConfig[GoalID.Id9802] =
{
	Id = 9802,
	Name = "家园成就1-2",
	GoalType = GoalType.HomeAchievement,
	ShowFirst = false,
	PreCondition = {
		PreArea = 130001,
		PreGoal = 
		{
			309801,
		},
	},
	GoalTrigger = 
	{
		TriggerType.ClearObstacle,
	},
	GoalCondition = 
	{
		{
			Name = "[62E7E7]累计[-]清理[62E7E7]冒险星[-]障碍[FDDE40]4个[-]",
			Type = ItemType.Obstacle,
			CountType = GoalCountType.Current,
			Num = 4,
			TagList = 
			{
				560103,
			},
			Value = -1,
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 45,
		},
	},
}
GoalConfig[GoalID.Id9803] =
{
	Id = 9803,
	Name = "家园成就1-3",
	GoalType = GoalType.HomeAchievement,
	ShowFirst = false,
	PreCondition = {
		PreArea = 130001,
		PreGoal = 
		{
			309802,
		},
	},
	GoalTrigger = 
	{
		TriggerType.ClearObstacle,
	},
	GoalCondition = 
	{
		{
			Name = "[62E7E7]累计[-]清理[62E7E7]冒险星[-]障碍[FDDE40]5个[-]",
			Type = ItemType.Obstacle,
			CountType = GoalCountType.Current,
			Num = 5,
			TagList = 
			{
				560103,
			},
			Value = -1,
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 45,
		},
	},
}
GoalConfig[GoalID.Id9804] =
{
	Id = 9804,
	Name = "家园成就1-4",
	GoalType = GoalType.HomeAchievement,
	ShowFirst = false,
	PreCondition = {
		PreArea = 130001,
		PreGoal = 
		{
			309803,
		},
	},
	GoalTrigger = 
	{
		TriggerType.ClearObstacle,
	},
	GoalCondition = 
	{
		{
			Name = "[62E7E7]累计[-]清理[62E7E7]冒险星[-]障碍[FDDE40]6个[-]",
			Type = ItemType.Obstacle,
			CountType = GoalCountType.Current,
			Num = 6,
			TagList = 
			{
				560103,
			},
			Value = -1,
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 45,
		},
	},
}
GoalConfig[GoalID.Id9805] =
{
	Id = 9805,
	Name = "家园成就1-5",
	GoalType = GoalType.HomeAchievement,
	ShowFirst = false,
	PreCondition = {
		PreArea = 130001,
		PreGoal = 
		{
			309804,
		},
	},
	GoalTrigger = 
	{
		TriggerType.ClearObstacle,
	},
	GoalCondition = 
	{
		{
			Name = "[62E7E7]累计[-]清理[62E7E7]冒险星[-]障碍[FDDE40]7个[-]",
			Type = ItemType.Obstacle,
			CountType = GoalCountType.Current,
			Num = 7,
			TagList = 
			{
				560103,
			},
			Value = -1,
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 45,
		},
	},
}
GoalConfig[GoalID.Id9806] =
{
	Id = 9806,
	Name = "家园成就2-1",
	GoalType = GoalType.HomeAchievement,
	ShowFirst = false,
	PreCondition = {
		PreArea = 130001,
	},
	GoalTrigger = 
	{
		TriggerType.CollectItem,
	},
	GoalCondition = 
	{
		{
			Name = "拥有[62E7E7]冒险星[-]家具3个",
			Type = ItemType.HomeFurniture,
			CountType = GoalCountType.Current,
			Num = 3,
			TagList = 
			{
				560103,
			},
			Value = -1,
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 45,
		},
	},
}
GoalConfig[GoalID.Id9807] =
{
	Id = 9807,
	Name = "家园成就2-2",
	GoalType = GoalType.HomeAchievement,
	ShowFirst = false,
	PreCondition = {
		PreArea = 130001,
		PreGoal = 
		{
			309806,
		},
	},
	GoalTrigger = 
	{
		TriggerType.CollectItem,
	},
	GoalCondition = 
	{
		{
			Name = "拥有[62E7E7]冒险星[-]家具4个",
			Type = ItemType.HomeFurniture,
			CountType = GoalCountType.Current,
			Num = 4,
			TagList = 
			{
				560103,
			},
			Value = -1,
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 45,
		},
	},
}
GoalConfig[GoalID.Id9808] =
{
	Id = 9808,
	Name = "家园成就2-3",
	GoalType = GoalType.HomeAchievement,
	ShowFirst = false,
	PreCondition = {
		PreArea = 130001,
		PreGoal = 
		{
			309807,
		},
	},
	GoalTrigger = 
	{
		TriggerType.CollectItem,
	},
	GoalCondition = 
	{
		{
			Name = "拥有[62E7E7]冒险星[-]家具5个",
			Type = ItemType.HomeFurniture,
			CountType = GoalCountType.Current,
			Num = 5,
			TagList = 
			{
				560103,
			},
			Value = -1,
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 100,
		},
	},
}
GoalConfig[GoalID.Id9809] =
{
	Id = 9809,
	Name = "家园成就3-1",
	GoalType = GoalType.HomeAchievement,
	ShowFirst = false,
	PreCondition = {
		PreArea = 130001,
	},
	GoalTrigger = 
	{
		TriggerType.CollectItem,
	},
	GoalCondition = 
	{
		{
			Name = "拥有[62E7E7]冒险星[-]家具3种",
			Type = ItemType.HomeFurniture,
			CountType = GoalCountType.Current,
			IsUniqueId = true,
			Num = 3,
			TagList = 
			{
				560103,
			},
			Value = -1,
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 45,
		},
	},
}
GoalConfig[GoalID.Id9810] =
{
	Id = 9810,
	Name = "家园成就3-2",
	GoalType = GoalType.HomeAchievement,
	ShowFirst = false,
	PreCondition = {
		PreArea = 130001,
		PreGoal = 
		{
			309809,
		},
	},
	GoalTrigger = 
	{
		TriggerType.CollectItem,
	},
	GoalCondition = 
	{
		{
			Name = "拥有[62E7E7]冒险星[-]家具4种",
			Type = ItemType.HomeFurniture,
			CountType = GoalCountType.Current,
			IsUniqueId = true,
			Num = 4,
			TagList = 
			{
				560103,
			},
			Value = -1,
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 45,
		},
	},
}
GoalConfig[GoalID.Id9811] =
{
	Id = 9811,
	Name = "家园成就3-3",
	GoalType = GoalType.HomeAchievement,
	ShowFirst = false,
	PreCondition = {
		PreArea = 130001,
		PreGoal = 
		{
			309810,
		},
	},
	GoalTrigger = 
	{
		TriggerType.CollectItem,
	},
	GoalCondition = 
	{
		{
			Name = "拥有[62E7E7]冒险星[-]家具5种",
			Type = ItemType.HomeFurniture,
			CountType = GoalCountType.Current,
			IsUniqueId = true,
			Num = 5,
			TagList = 
			{
				560103,
			},
			Value = -1,
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 100,
		},
	},
}
GoalConfig[GoalID.Id9812] =
{
	Id = 9812,
	Name = "家园成就4-1",
	GoalType = GoalType.HomeAchievement,
	ShowFirst = false,
	PreCondition = {
		PreArea = 130001,
	},
	GoalTrigger = 
	{
		TriggerType.ArrangeHomeFurniture,
	},
	GoalCondition = 
	{
		{
			Name = "在房间中布置[62E7E7]冒险星[-]家具3个",
			Type = ItemType.HomeFurniture,
			CountType = GoalCountType.Current,
			Num = 3,
			TagList = 
			{
				560103,
			},
			Value = -1,
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 45,
		},
	},
}
GoalConfig[GoalID.Id9813] =
{
	Id = 9813,
	Name = "家园成就5-1",
	GoalType = GoalType.HomeAchievement,
	ShowFirst = false,
	PreCondition = {
		PreArea = 130001,
	},
	GoalTrigger = 
	{
		TriggerType.ArrangeHomeFurniture,
	},
	GoalCondition = 
	{
		{
			Name = "在房间中布置[62E7E7]冒险星[-]家具3种",
			Type = ItemType.HomeFurniture,
			CountType = GoalCountType.Current,
			IsUniqueId = true,
			Num = 3,
			TagList = 
			{
				560103,
			},
			Value = -1,
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 45,
		},
	},
}
GoalConfig[GoalID.Id9814] =
{
	Id = 9814,
	Name = "家园成就5-2",
	GoalType = GoalType.HomeAchievement,
	ShowFirst = false,
	PreCondition = {
		PreArea = 130001,
		PreGoal = 
		{
			309813,
		},
	},
	GoalTrigger = 
	{
		TriggerType.ArrangeHomeFurniture,
	},
	GoalCondition = 
	{
		{
			Name = "在房间中布置[62E7E7]冒险星[-]家具4种",
			Type = ItemType.HomeFurniture,
			CountType = GoalCountType.Current,
			IsUniqueId = true,
			Num = 4,
			TagList = 
			{
				560103,
			},
			Value = -1,
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 45,
		},
	},
}
GoalConfig[GoalID.Id9815] =
{
	Id = 9815,
	Name = "家园成就5-3",
	GoalType = GoalType.HomeAchievement,
	ShowFirst = false,
	PreCondition = {
		PreArea = 130001,
		PreGoal = 
		{
			309814,
		},
	},
	GoalTrigger = 
	{
		TriggerType.ArrangeHomeFurniture,
	},
	GoalCondition = 
	{
		{
			Name = "在房间中布置[62E7E7]冒险星[-]家具5种",
			Type = ItemType.HomeFurniture,
			CountType = GoalCountType.Current,
			IsUniqueId = true,
			Num = 5,
			TagList = 
			{
				560103,
			},
			Value = -1,
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 100,
		},
	},
}
GoalConfig[GoalID.Id9816] =
{
	Id = 9816,
	Name = "家园成就6-1",
	GoalType = GoalType.HomeAchievement,
	ShowFirst = false,
	PreCondition = {
		PreArea = 130001,
	},
	GoalTrigger = 
	{
		TriggerType.HomeFurnitureSell,
	},
	GoalCondition = 
	{
		{
			Name = "在家具店购买[62E7E7]冒险星[-]家具[FDDE40]3个[-]",
			Type = ItemType.HomeFurniture,
			CountType = GoalCountType.StartNow,
			Num = 3,
			TagList = 
			{
				560103,
			},
			Value = -1,
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 45,
		},
	},
}
GoalConfig[GoalID.Id9817] =
{
	Id = 9817,
	Name = "家园成就6-2",
	GoalType = GoalType.HomeAchievement,
	ShowFirst = false,
	PreCondition = {
		PreArea = 130001,
		PreGoal = 
		{
			309816,
		},
	},
	GoalTrigger = 
	{
		TriggerType.HomeFurnitureSell,
	},
	GoalCondition = 
	{
		{
			Name = "[62E7E7]累计[-]在家具店购买[62E7E7]冒险星[-]家具[FDDE40]4个[-]",
			Type = ItemType.HomeFurniture,
			CountType = GoalCountType.Current,
			Num = 4,
			TagList = 
			{
				560103,
			},
			Value = -1,
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 45,
		},
	},
}
GoalConfig[GoalID.Id9818] =
{
	Id = 9818,
	Name = "家园成就6-3",
	GoalType = GoalType.HomeAchievement,
	ShowFirst = false,
	PreCondition = {
		PreArea = 130001,
		PreGoal = 
		{
			309817,
		},
	},
	GoalTrigger = 
	{
		TriggerType.HomeFurnitureSell,
	},
	GoalCondition = 
	{
		{
			Name = "[62E7E7]累计[-]在家具店购买[62E7E7]冒险星[-]家具[FDDE40]5个[-]",
			Type = ItemType.HomeFurniture,
			CountType = GoalCountType.Current,
			Num = 5,
			TagList = 
			{
				560103,
			},
			Value = -1,
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 100,
		},
	},
}
GoalConfig[GoalID.Id9819] =
{
	Id = 9819,
	Name = "家园成就7-1",
	GoalType = GoalType.HomeAchievement,
	ShowFirst = false,
	PreCondition = {
		PreArea = 130001,
	},
	GoalTrigger = 
	{
		TriggerType.HomeFurnitureSellCost,
	},
	GoalCondition = 
	{
		{
			Name = "在家具店购买家具消耗[62E7E7]冒险星[-]道具[FDDE40]3个[-]",
			Type = ItemType.Goods,
			CountType = GoalCountType.StartNow,
			Num = 3,
			TagList = 
			{
				560103,
			},
			Value = -1,
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 45,
		},
	},
}
GoalConfig[GoalID.Id9820] =
{
	Id = 9820,
	Name = "家园成就7-2",
	GoalType = GoalType.HomeAchievement,
	ShowFirst = false,
	PreCondition = {
		PreArea = 130001,
		PreGoal = 
		{
			309819,
		},
	},
	GoalTrigger = 
	{
		TriggerType.HomeFurnitureSellCost,
	},
	GoalCondition = 
	{
		{
			Name = "[62E7E7]累计[-]在家具店购买家具消耗[62E7E7]冒险星[-]道具[FDDE40]4个[-]",
			Type = ItemType.Goods,
			CountType = GoalCountType.Current,
			Num = 4,
			TagList = 
			{
				560103,
			},
			Value = -1,
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 45,
		},
	},
}
GoalConfig[GoalID.Id9821] =
{
	Id = 9821,
	Name = "家园成就8-1",
	GoalType = GoalType.HomeAchievement,
	ShowFirst = false,
	PreCondition = {
		PreArea = 130001,
	},
	GoalTrigger = 
	{
		TriggerType.HomeFurnitureGashapon,
	},
	GoalCondition = 
	{
		{
			Name = "在家具淘中进行[62E7E7]冒险星[-]幸运淘3次",
			Type = ItemType.HomeFurnitureGashapon,
			CountType = GoalCountType.Current,
			Num = 3,
			TagList = 
			{
				560103,
			},
			Value = -1,
		},
	},
	Reward = {
		{
			Value = 320001,
			Num = 2,
		},
	},
}
GoalConfig[GoalID.Id9822] =
{
	Id = 9822,
	Name = "家园成就8-2",
	GoalType = GoalType.HomeAchievement,
	ShowFirst = false,
	PreCondition = {
		PreArea = 130001,
		PreGoal = 
		{
			309821,
		},
	},
	GoalTrigger = 
	{
		TriggerType.HomeFurnitureGashapon,
	},
	GoalCondition = 
	{
		{
			Name = "在家具淘中进行[62E7E7]冒险星[-]幸运淘4次",
			Type = ItemType.HomeFurnitureGashapon,
			CountType = GoalCountType.Current,
			Num = 4,
			TagList = 
			{
				560103,
			},
			Value = -1,
		},
	},
	Reward = {
		{
			Value = 320102,
			Num = 1,
		},
	},
}
GoalConfig[GoalID.Id9823] =
{
	Id = 9823,
	Name = "家园成就8-3",
	GoalType = GoalType.HomeAchievement,
	ShowFirst = false,
	PreCondition = {
		PreArea = 130001,
		PreGoal = 
		{
			309822,
		},
	},
	GoalTrigger = 
	{
		TriggerType.HomeFurnitureGashapon,
	},
	GoalCondition = 
	{
		{
			Name = "在家具淘中进行[62E7E7]冒险星[-]幸运淘5次",
			Type = ItemType.HomeFurnitureGashapon,
			CountType = GoalCountType.Current,
			Num = 5,
			TagList = 
			{
				560103,
			},
			Value = -1,
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 100,
		},
	},
}
GoalConfig[GoalID.Id9824] =
{
	Id = 9824,
	Name = "家园成就9-1",
	GoalType = GoalType.HomeAchievement,
	ShowFirst = false,
	PreCondition = {
		PreArea = 130001,
	},
	GoalTrigger = 
	{
		TriggerType.CraftUse,
	},
	GoalCondition = 
	{
		{
			Name = "在实验室合成消耗[62E7E7]冒险星[-]家具3个",
			Type = ItemType.HomeFurniture,
			CountType = GoalCountType.StartNow,
			Num = 3,
			TagList = 
			{
				560103,
			},
			Value = -1,
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 100,
		},
	},
}
