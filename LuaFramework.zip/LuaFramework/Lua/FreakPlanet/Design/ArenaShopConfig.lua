ArenaShopConfig ={};
ArenaShopID = 
{
	Id001 = 400001,
	Id002 = 400002,
	Id003 = 400003,
	Id004 = 400004,
	Id005 = 400005,
	Id006 = 400006,
	Id007 = 400007,
	Id1001 = 401001,
	Id1002 = 401002,
	Id1003 = 401003,
	Id1004 = 401004,
	Id1005 = 401005,
	Id1006 = 401006,
	Id1007 = 401007,
	Id1008 = 401008,
	Id1009 = 401009,
	Id1010 = 401010,
	Id1011 = 401011,
	Id1012 = 401012,
	Id1013 = 401013,
	Id1014 = 401014,
	Id1015 = 401015,
	Id2001 = 402001,
	Id2002 = 402002,
	Id2003 = 402003,
	Id2004 = 402004,
	Id2005 = 402005,
	Id2006 = 402006,
	Id2007 = 402007,
	Id2008 = 402008,
	Id2009 = 402009,
	Id2010 = 402010,
	Id2011 = 402011,
	Id2012 = 402012,
	Id3001 = 403001,
	Id3002 = 403002,
	Id3003 = 403003,
	Id3004 = 403004,
	Id3005 = 403005,
	Id3006 = 403006,
	Id3007 = 403007,
	Id3008 = 403008,
	Id3009 = 403009,
	Id3010 = 403010,
	Id3011 = 403011,
	Id3012 = 403012,
}
ArenaShopConfig[ArenaShopID.Id001] =
{
	Id = 1,
	Name = "低量电池×1",
	Type = "Normal",
	Active = true,
	WeeklyRefresh = false,
	Limit = 0,
	CostItem = {
		Value = 320201,
		Num = 120,
	},
	ItemList = {
		{
			Active = true,
			Value = 320001,
			Num = 1,
			Weight = 100,
		},
	},
}
ArenaShopConfig[ArenaShopID.Id002] =
{
	Id = 2,
	Name = "高能电池×1",
	Type = "Normal",
	Active = true,
	WeeklyRefresh = false,
	Limit = 0,
	CostItem = {
		Value = 320201,
		Num = 360,
	},
	ItemList = {
		{
			Active = true,
			Value = 320002,
			Num = 1,
			Weight = 100,
		},
	},
}
ArenaShopConfig[ArenaShopID.Id003] =
{
	Id = 3,
	Name = "合金陷阱×1",
	Type = "Normal",
	Active = true,
	WeeklyRefresh = false,
	Limit = 0,
	CostItem = {
		Value = 320201,
		Num = 54,
	},
	ItemList = {
		{
			Active = true,
			Value = 320303,
			Num = 1,
			Weight = 100,
		},
	},
}
ArenaShopConfig[ArenaShopID.Id004] =
{
	Id = 4,
	Name = "精灵瓶×1",
	Type = "Normal",
	Active = true,
	WeeklyRefresh = false,
	Limit = 0,
	CostItem = {
		Value = 320201,
		Num = 54,
	},
	ItemList = {
		{
			Active = true,
			Value = 320307,
			Num = 1,
			Weight = 100,
		},
	},
}
ArenaShopConfig[ArenaShopID.Id005] =
{
	Id = 5,
	Name = "恒温纸袋×1",
	Type = "Normal",
	Active = true,
	WeeklyRefresh = false,
	Limit = 0,
	CostItem = {
		Value = 320201,
		Num = 66,
	},
	ItemList = {
		{
			Active = true,
			Value = 320311,
			Num = 1,
			Weight = 100,
		},
	},
}
ArenaShopConfig[ArenaShopID.Id006] =
{
	Id = 6,
	Name = "专业工具箱×1",
	Type = "Normal",
	Active = true,
	WeeklyRefresh = false,
	Limit = 0,
	CostItem = {
		Value = 320201,
		Num = 132,
	},
	ItemList = {
		{
			Active = true,
			Value = 320315,
			Num = 1,
			Weight = 100,
		},
	},
}
ArenaShopConfig[ArenaShopID.Id007] =
{
	Id = 7,
	Name = "加固纸板箱×1",
	Type = "Normal",
	Active = true,
	WeeklyRefresh = false,
	Limit = 0,
	CostItem = {
		Value = 320201,
		Num = 132,
	},
	ItemList = {
		{
			Active = true,
			Value = 320319,
			Num = 1,
			Weight = 100,
		},
	},
}
ArenaShopConfig[ArenaShopID.Id1001] =
{
	Id = 1001,
	Name = "超能电池×1",
	Type = "Normal",
	Active = false,
	WeeklyRefresh = true,
	Limit = 5,
	CostItem = {
		Value = 320201,
		Num = 1200,
	},
	ItemList = {
		{
			Active = true,
			Value = 320003,
			Num = 1,
			Weight = 100,
		},
	},
}
ArenaShopConfig[ArenaShopID.Id1002] =
{
	Id = 1002,
	Name = "危险电池×1",
	Type = "Normal",
	Active = true,
	WeeklyRefresh = true,
	Limit = 10,
	CostItem = {
		Value = 320201,
		Num = 1200,
	},
	ItemList = {
		{
			Active = true,
			Value = 320021,
			Num = 1,
			Weight = 100,
		},
	},
}
ArenaShopConfig[ArenaShopID.Id1003] =
{
	Id = 1003,
	Name = "日记页-超小×1",
	Type = "Normal",
	Active = false,
	WeeklyRefresh = true,
	Limit = 5,
	CostItem = {
		Value = 320201,
		Num = 1250,
	},
	ItemList = {
		{
			Active = true,
			Value = 320101,
			Num = 1,
			Weight = 100,
		},
	},
}
ArenaShopConfig[ArenaShopID.Id1004] =
{
	Id = 1004,
	Name = "日记页-小×1",
	Type = "Normal",
	Active = true,
	WeeklyRefresh = true,
	Limit = 5,
	CostItem = {
		Value = 320201,
		Num = 2500,
	},
	ItemList = {
		{
			Active = true,
			Value = 320102,
			Num = 1,
			Weight = 100,
		},
	},
}
ArenaShopConfig[ArenaShopID.Id1005] =
{
	Id = 1005,
	Name = "日记页-中×1",
	Type = "Normal",
	Active = false,
	WeeklyRefresh = true,
	Limit = 5,
	CostItem = {
		Value = 320201,
		Num = 5000,
	},
	ItemList = {
		{
			Active = true,
			Value = 320103,
			Num = 1,
			Weight = 100,
		},
	},
}
ArenaShopConfig[ArenaShopID.Id1006] =
{
	Id = 1006,
	Name = "日记页-大×1",
	Type = "Normal",
	Active = false,
	WeeklyRefresh = true,
	Limit = 5,
	CostItem = {
		Value = 320201,
		Num = 7500,
	},
	ItemList = {
		{
			Active = true,
			Value = 320104,
			Num = 1,
			Weight = 100,
		},
	},
}
ArenaShopConfig[ArenaShopID.Id1007] =
{
	Id = 1007,
	Name = "日记页-完整×1",
	Type = "Normal",
	Active = false,
	WeeklyRefresh = true,
	Limit = 5,
	CostItem = {
		Value = 320201,
		Num = 10000,
	},
	ItemList = {
		{
			Active = true,
			Value = 320105,
			Num = 1,
			Weight = 100,
		},
	},
}
ArenaShopConfig[ArenaShopID.Id1008] =
{
	Id = 1008,
	Name = "强化零件D×25",
	Type = "Normal",
	Active = false,
	WeeklyRefresh = true,
	Limit = 8,
	CostItem = {
		Value = 1,
		Num = 3000,
	},
	ItemList = {
		{
			Active = true,
			Value = 320041,
			Num = 25,
			Weight = 100,
		},
	},
}
ArenaShopConfig[ArenaShopID.Id1009] =
{
	Id = 1009,
	Name = "强化零件C×10",
	Type = "Normal",
	Active = false,
	WeeklyRefresh = true,
	Limit = 8,
	CostItem = {
		Value = 1,
		Num = 6000,
	},
	ItemList = {
		{
			Active = true,
			Value = 320042,
			Num = 10,
			Weight = 100,
		},
	},
}
ArenaShopConfig[ArenaShopID.Id1010] =
{
	Id = 1010,
	Name = "强化零件B×5",
	Type = "Normal",
	Active = true,
	WeeklyRefresh = true,
	Limit = 8,
	CostItem = {
		Value = 1,
		Num = 15000,
	},
	ItemList = {
		{
			Active = true,
			Value = 320043,
			Num = 5,
			Weight = 100,
		},
	},
}
ArenaShopConfig[ArenaShopID.Id1011] =
{
	Id = 1011,
	Name = "强化零件A×1",
	Type = "Normal",
	Active = false,
	WeeklyRefresh = true,
	Limit = 8,
	CostItem = {
		Value = 1,
		Num = 18750,
	},
	ItemList = {
		{
			Active = true,
			Value = 320044,
			Num = 1,
			Weight = 100,
		},
	},
}
ArenaShopConfig[ArenaShopID.Id1012] =
{
	Id = 1012,
	Name = "固化零件D×25",
	Type = "Normal",
	Active = false,
	WeeklyRefresh = true,
	Limit = 8,
	CostItem = {
		Value = 1,
		Num = 3000,
	},
	ItemList = {
		{
			Active = true,
			Value = 320051,
			Num = 25,
			Weight = 100,
		},
	},
}
ArenaShopConfig[ArenaShopID.Id1013] =
{
	Id = 1013,
	Name = "固化零件C×10",
	Type = "Normal",
	Active = false,
	WeeklyRefresh = true,
	Limit = 8,
	CostItem = {
		Value = 1,
		Num = 6000,
	},
	ItemList = {
		{
			Active = true,
			Value = 320052,
			Num = 10,
			Weight = 100,
		},
	},
}
ArenaShopConfig[ArenaShopID.Id1014] =
{
	Id = 1014,
	Name = "固化零件B×5",
	Type = "Normal",
	Active = true,
	WeeklyRefresh = true,
	Limit = 8,
	CostItem = {
		Value = 1,
		Num = 15000,
	},
	ItemList = {
		{
			Active = true,
			Value = 320053,
			Num = 5,
			Weight = 100,
		},
	},
}
ArenaShopConfig[ArenaShopID.Id1015] =
{
	Id = 1015,
	Name = "固化零件A×1",
	Type = "Normal",
	Active = false,
	WeeklyRefresh = true,
	Limit = 8,
	CostItem = {
		Value = 1,
		Num = 18750,
	},
	ItemList = {
		{
			Active = true,
			Value = 320054,
			Num = 1,
			Weight = 100,
		},
	},
}
ArenaShopConfig[ArenaShopID.Id2001] =
{
	Id = 2001,
	Name = "3星角色盲盒",
	Type = "Character",
	Icon = "icon_blindbox_rairty3_1",
	BlindBoxSprite = "icon_blindbox_rairty3_2",
	Active = true,
	WeeklyRefresh = false,
	Limit = 4,
	CostItem = {
		Value = 320201,
		Num = 2500,
	},
	ItemList = {
		{
			Active = true,
			Value = 223025,
			Num = 1,
			Weight = 100,
		},
		{
			Active = true,
			Value = 223028,
			Num = 1,
			Weight = 100,
		},
		{
			Active = true,
			Value = 223027,
			Num = 1,
			Weight = 100,
		},
		{
			Active = true,
			Value = 223026,
			Num = 1,
			Weight = 100,
		},
	},
}
ArenaShopConfig[ArenaShopID.Id2002] =
{
	Id = 2002,
	Name = "4星角色盲盒",
	Type = "Character",
	Icon = "icon_blindbox_rairty4_1",
	BlindBoxSprite = "icon_blindbox_rairty4_2",
	Active = true,
	WeeklyRefresh = false,
	Limit = 9,
	CostItem = {
		Value = 320201,
		Num = 6000,
	},
	ItemList = {
		{
			Active = true,
			Value = 222001,
			Num = 1,
			Weight = 100,
		},
		{
			Active = true,
			Value = 222021,
			Num = 1,
			Weight = 100,
		},
		{
			Active = true,
			Value = 223021,
			Num = 1,
			Weight = 100,
		},
		{
			Active = true,
			Value = 223022,
			Num = 1,
			Weight = 100,
		},
		{
			Active = true,
			Value = 223023,
			Num = 1,
			Weight = 100,
		},
		{
			Active = true,
			Value = 223024,
			Num = 1,
			Weight = 100,
		},
		{
			Active = true,
			Value = 222041,
			Num = 1,
			Weight = 100,
		},
		{
			Active = true,
			Value = 222042,
			Num = 1,
			Weight = 100,
		},
		{
			Active = true,
			Value = 222047,
			Num = 1,
			Weight = 100,
		},
	},
}
ArenaShopConfig[ArenaShopID.Id2003] =
{
	Id = 2003,
	Name = "临时盲盒",
	Type = "Character",
	Active = false,
	WeeklyRefresh = false,
	Limit = 1,
	CostItem = {
		Value = 320201,
		Num = 7500,
	},
	ItemList = {
		{
			Active = true,
			Value = 220001,
			Num = 1,
			Weight = 100,
		},
	},
}
ArenaShopConfig[ArenaShopID.Id2004] =
{
	Id = 2004,
	Name = "临时盲盒",
	Type = "Character",
	Active = false,
	WeeklyRefresh = false,
	Limit = 1,
	CostItem = {
		Value = 320201,
		Num = 7500,
	},
	ItemList = {
		{
			Active = true,
			Value = 220001,
			Num = 1,
			Weight = 100,
		},
	},
}
ArenaShopConfig[ArenaShopID.Id2005] =
{
	Id = 2005,
	Name = "临时盲盒",
	Type = "Character",
	Active = false,
	WeeklyRefresh = false,
	Limit = 1,
	CostItem = {
		Value = 320201,
		Num = 7500,
	},
	ItemList = {
		{
			Active = true,
			Value = 220001,
			Num = 1,
			Weight = 100,
		},
	},
}
ArenaShopConfig[ArenaShopID.Id2006] =
{
	Id = 2006,
	Name = "临时盲盒",
	Type = "Character",
	Active = false,
	WeeklyRefresh = false,
	Limit = 1,
	CostItem = {
		Value = 320201,
		Num = 7500,
	},
	ItemList = {
		{
			Active = true,
			Value = 220001,
			Num = 1,
			Weight = 100,
		},
	},
}
ArenaShopConfig[ArenaShopID.Id2007] =
{
	Id = 2007,
	Name = "临时盲盒",
	Type = "Character",
	Active = false,
	WeeklyRefresh = false,
	Limit = 1,
	CostItem = {
		Value = 320201,
		Num = 7500,
	},
	ItemList = {
		{
			Active = true,
			Value = 220001,
			Num = 1,
			Weight = 100,
		},
	},
}
ArenaShopConfig[ArenaShopID.Id2008] =
{
	Id = 2008,
	Name = "临时盲盒",
	Type = "Character",
	Active = false,
	WeeklyRefresh = false,
	Limit = 1,
	CostItem = {
		Value = 320201,
		Num = 7500,
	},
	ItemList = {
		{
			Active = true,
			Value = 220001,
			Num = 1,
			Weight = 100,
		},
	},
}
ArenaShopConfig[ArenaShopID.Id2009] =
{
	Id = 2009,
	Name = "临时盲盒",
	Type = "Character",
	Active = false,
	WeeklyRefresh = false,
	Limit = 1,
	CostItem = {
		Value = 320201,
		Num = 7500,
	},
	ItemList = {
		{
			Active = true,
			Value = 220001,
			Num = 1,
			Weight = 100,
		},
	},
}
ArenaShopConfig[ArenaShopID.Id2010] =
{
	Id = 2010,
	Name = "临时盲盒",
	Type = "Character",
	Active = false,
	WeeklyRefresh = false,
	Limit = 1,
	CostItem = {
		Value = 320201,
		Num = 7500,
	},
	ItemList = {
		{
			Active = true,
			Value = 220001,
			Num = 1,
			Weight = 100,
		},
	},
}
ArenaShopConfig[ArenaShopID.Id2011] =
{
	Id = 2011,
	Name = "临时盲盒",
	Type = "Character",
	Active = false,
	WeeklyRefresh = false,
	Limit = 1,
	CostItem = {
		Value = 320201,
		Num = 10000,
	},
	ItemList = {
		{
			Active = true,
			Value = 220001,
			Num = 1,
			Weight = 100,
		},
	},
}
ArenaShopConfig[ArenaShopID.Id2012] =
{
	Id = 2012,
	Name = "临时盲盒",
	Type = "Character",
	Active = false,
	WeeklyRefresh = false,
	Limit = 1,
	CostItem = {
		Value = 320201,
		Num = 10000,
	},
	ItemList = {
		{
			Active = true,
			Value = 220001,
			Num = 1,
			Weight = 100,
		},
	},
}
ArenaShopConfig[ArenaShopID.Id3001] =
{
	Id = 3001,
	Name = "2021春节盲盒",
	Type = "Character",
	Icon = "icon_blindbox_rairty3_1",
	BlindBoxSprite = "icon_blindbox_rairty3_2",
	Active = true,
	WeeklyRefresh = false,
	Limit = 6,
	PoolId = 610002,
	CostItem = {
		Value = 327306,
		Num = 1000,
	},
	ItemList = {
		{
			Active = true,
			Value = 223066,
			Num = 1,
			Weight = 100,
		},
		{
			Active = true,
			Value = 223061,
			Num = 1,
			Weight = 100,
		},
		{
			Active = true,
			Value = 223062,
			Num = 1,
			Weight = 100,
		},
		{
			Active = true,
			Value = 223063,
			Num = 1,
			Weight = 100,
		},
		{
			Active = true,
			Value = 223064,
			Num = 1,
			Weight = 100,
		},
		{
			Active = true,
			Value = 223065,
			Num = 1,
			Weight = 100,
		},
	},
}
ArenaShopConfig[ArenaShopID.Id3002] =
{
	Id = 3002,
	Name = "2021春节盲盒",
	Type = "Character",
	Icon = "icon_blindbox_rairty3_1",
	BlindBoxSprite = "icon_blindbox_rairty3_2",
	Active = true,
	WeeklyRefresh = false,
	Limit = 6,
	PoolId = 610003,
	CostItem = {
		Value = 327306,
		Num = 1000,
	},
	ItemList = {
		{
			Active = true,
			Value = 223066,
			Num = 1,
			Weight = 100,
		},
		{
			Active = true,
			Value = 223061,
			Num = 1,
			Weight = 100,
		},
		{
			Active = true,
			Value = 223062,
			Num = 1,
			Weight = 100,
		},
		{
			Active = true,
			Value = 223063,
			Num = 1,
			Weight = 100,
		},
		{
			Active = true,
			Value = 223064,
			Num = 1,
			Weight = 100,
		},
		{
			Active = true,
			Value = 223065,
			Num = 1,
			Weight = 100,
		},
	},
}
ArenaShopConfig[ArenaShopID.Id3003] =
{
	Id = 3003,
	Name = "2021春节盲盒",
	Type = "Character",
	Icon = "icon_blindbox_rairty3_1",
	BlindBoxSprite = "icon_blindbox_rairty3_2",
	Active = true,
	WeeklyRefresh = false,
	Limit = 6,
	PoolId = 610004,
	CostItem = {
		Value = 327306,
		Num = 1000,
	},
	ItemList = {
		{
			Active = true,
			Value = 223066,
			Num = 1,
			Weight = 100,
		},
		{
			Active = true,
			Value = 223061,
			Num = 1,
			Weight = 100,
		},
		{
			Active = true,
			Value = 223062,
			Num = 1,
			Weight = 100,
		},
		{
			Active = true,
			Value = 223063,
			Num = 1,
			Weight = 100,
		},
		{
			Active = true,
			Value = 223064,
			Num = 1,
			Weight = 100,
		},
		{
			Active = true,
			Value = 223065,
			Num = 1,
			Weight = 100,
		},
	},
}
ArenaShopConfig[ArenaShopID.Id3004] =
{
	Id = 3004,
	Name = "2021春节盲盒",
	Type = "Character",
	Icon = "icon_blindbox_rairty3_1",
	BlindBoxSprite = "icon_blindbox_rairty3_2",
	Active = true,
	WeeklyRefresh = false,
	Limit = 6,
	PoolId = 610005,
	CostItem = {
		Value = 327306,
		Num = 1000,
	},
	ItemList = {
		{
			Active = true,
			Value = 223066,
			Num = 1,
			Weight = 100,
		},
		{
			Active = true,
			Value = 223061,
			Num = 1,
			Weight = 100,
		},
		{
			Active = true,
			Value = 223062,
			Num = 1,
			Weight = 100,
		},
		{
			Active = true,
			Value = 223063,
			Num = 1,
			Weight = 100,
		},
		{
			Active = true,
			Value = 223064,
			Num = 1,
			Weight = 100,
		},
		{
			Active = true,
			Value = 223065,
			Num = 1,
			Weight = 100,
		},
	},
}
ArenaShopConfig[ArenaShopID.Id3005] =
{
	Id = 3005,
	Name = "2021春节盲盒",
	Type = "Character",
	Icon = "icon_blindbox_rairty3_1",
	BlindBoxSprite = "icon_blindbox_rairty3_2",
	Active = true,
	WeeklyRefresh = false,
	Limit = 6,
	PoolId = 610006,
	CostItem = {
		Value = 327306,
		Num = 1000,
	},
	ItemList = {
		{
			Active = true,
			Value = 223066,
			Num = 1,
			Weight = 100,
		},
		{
			Active = true,
			Value = 223061,
			Num = 1,
			Weight = 100,
		},
		{
			Active = true,
			Value = 223062,
			Num = 1,
			Weight = 100,
		},
		{
			Active = true,
			Value = 223063,
			Num = 1,
			Weight = 100,
		},
		{
			Active = true,
			Value = 223064,
			Num = 1,
			Weight = 100,
		},
		{
			Active = true,
			Value = 223065,
			Num = 1,
			Weight = 100,
		},
	},
}
ArenaShopConfig[ArenaShopID.Id3006] =
{
	Id = 3006,
	Name = "2021春节盲盒",
	Type = "Character",
	Icon = "icon_blindbox_rairty3_1",
	BlindBoxSprite = "icon_blindbox_rairty3_2",
	Active = true,
	WeeklyRefresh = false,
	Limit = 6,
	PoolId = 610007,
	CostItem = {
		Value = 327306,
		Num = 1000,
	},
	ItemList = {
		{
			Active = true,
			Value = 223066,
			Num = 1,
			Weight = 100,
		},
		{
			Active = true,
			Value = 223061,
			Num = 1,
			Weight = 100,
		},
		{
			Active = true,
			Value = 223062,
			Num = 1,
			Weight = 100,
		},
		{
			Active = true,
			Value = 223063,
			Num = 1,
			Weight = 100,
		},
		{
			Active = true,
			Value = 223064,
			Num = 1,
			Weight = 100,
		},
		{
			Active = true,
			Value = 223065,
			Num = 1,
			Weight = 100,
		},
	},
}
ArenaShopConfig[ArenaShopID.Id3007] =
{
	Id = 3007,
	Name = "2021端午节盲盒",
	Type = "Character",
	Icon = "icon_blindbox_rairty3_1",
	BlindBoxSprite = "icon_blindbox_rairty3_2",
	Active = true,
	WeeklyRefresh = false,
	Limit = 5,
	PoolId = 610020,
	CostItem = {
		Value = 327311,
		Num = 1000,
	},
	ItemList = {
		{
			Active = true,
			Value = 223125,
			Num = 1,
			Weight = 100,
		},
		{
			Active = true,
			Value = 223126,
			Num = 1,
			Weight = 100,
		},
		{
			Active = true,
			Value = 223127,
			Num = 1,
			Weight = 100,
		},
		{
			Active = true,
			Value = 223128,
			Num = 1,
			Weight = 100,
		},
		{
			Active = true,
			Value = 223129,
			Num = 1,
			Weight = 100,
		},
	},
}
ArenaShopConfig[ArenaShopID.Id3008] =
{
	Id = 3008,
	Name = "2021端午节盲盒",
	Type = "Character",
	Icon = "icon_blindbox_rairty3_1",
	BlindBoxSprite = "icon_blindbox_rairty3_2",
	Active = true,
	WeeklyRefresh = false,
	Limit = 5,
	PoolId = 610021,
	CostItem = {
		Value = 327311,
		Num = 1000,
	},
	ItemList = {
		{
			Active = true,
			Value = 223125,
			Num = 1,
			Weight = 100,
		},
		{
			Active = true,
			Value = 223126,
			Num = 1,
			Weight = 100,
		},
		{
			Active = true,
			Value = 223127,
			Num = 1,
			Weight = 100,
		},
		{
			Active = true,
			Value = 223128,
			Num = 1,
			Weight = 100,
		},
		{
			Active = true,
			Value = 223129,
			Num = 1,
			Weight = 100,
		},
	},
}
ArenaShopConfig[ArenaShopID.Id3009] =
{
	Id = 3009,
	Name = "2021端午节盲盒",
	Type = "Character",
	Icon = "icon_blindbox_rairty3_1",
	BlindBoxSprite = "icon_blindbox_rairty3_2",
	Active = true,
	WeeklyRefresh = false,
	Limit = 5,
	PoolId = 610022,
	CostItem = {
		Value = 327311,
		Num = 1000,
	},
	ItemList = {
		{
			Active = true,
			Value = 223125,
			Num = 1,
			Weight = 100,
		},
		{
			Active = true,
			Value = 223126,
			Num = 1,
			Weight = 100,
		},
		{
			Active = true,
			Value = 223127,
			Num = 1,
			Weight = 100,
		},
		{
			Active = true,
			Value = 223128,
			Num = 1,
			Weight = 100,
		},
		{
			Active = true,
			Value = 223129,
			Num = 1,
			Weight = 100,
		},
	},
}
ArenaShopConfig[ArenaShopID.Id3010] =
{
	Id = 3010,
	Name = "2021端午节盲盒",
	Type = "Character",
	Icon = "icon_blindbox_rairty3_1",
	BlindBoxSprite = "icon_blindbox_rairty3_2",
	Active = true,
	WeeklyRefresh = false,
	Limit = 5,
	PoolId = 610023,
	CostItem = {
		Value = 327311,
		Num = 1000,
	},
	ItemList = {
		{
			Active = true,
			Value = 223125,
			Num = 1,
			Weight = 100,
		},
		{
			Active = true,
			Value = 223126,
			Num = 1,
			Weight = 100,
		},
		{
			Active = true,
			Value = 223127,
			Num = 1,
			Weight = 100,
		},
		{
			Active = true,
			Value = 223128,
			Num = 1,
			Weight = 100,
		},
		{
			Active = true,
			Value = 223129,
			Num = 1,
			Weight = 100,
		},
	},
}
ArenaShopConfig[ArenaShopID.Id3011] =
{
	Id = 3011,
	Name = "2021端午节盲盒",
	Type = "Character",
	Icon = "icon_blindbox_rairty3_1",
	BlindBoxSprite = "icon_blindbox_rairty3_2",
	Active = true,
	WeeklyRefresh = false,
	Limit = 5,
	PoolId = 610024,
	CostItem = {
		Value = 327311,
		Num = 1000,
	},
	ItemList = {
		{
			Active = true,
			Value = 223125,
			Num = 1,
			Weight = 100,
		},
		{
			Active = true,
			Value = 223126,
			Num = 1,
			Weight = 100,
		},
		{
			Active = true,
			Value = 223127,
			Num = 1,
			Weight = 100,
		},
		{
			Active = true,
			Value = 223128,
			Num = 1,
			Weight = 100,
		},
		{
			Active = true,
			Value = 223129,
			Num = 1,
			Weight = 100,
		},
	},
}
ArenaShopConfig[ArenaShopID.Id3012] =
{
	Id = 3012,
	Name = "2021端午节盲盒",
	Type = "Character",
	Icon = "icon_blindbox_rairty3_1",
	BlindBoxSprite = "icon_blindbox_rairty3_2",
	Active = true,
	WeeklyRefresh = false,
	Limit = 5,
	PoolId = 610025,
	CostItem = {
		Value = 327311,
		Num = 1000,
	},
	ItemList = {
		{
			Active = true,
			Value = 223125,
			Num = 1,
			Weight = 100,
		},
		{
			Active = true,
			Value = 223126,
			Num = 1,
			Weight = 100,
		},
		{
			Active = true,
			Value = 223127,
			Num = 1,
			Weight = 100,
		},
		{
			Active = true,
			Value = 223128,
			Num = 1,
			Weight = 100,
		},
		{
			Active = true,
			Value = 223129,
			Num = 1,
			Weight = 100,
		},
	},
}

