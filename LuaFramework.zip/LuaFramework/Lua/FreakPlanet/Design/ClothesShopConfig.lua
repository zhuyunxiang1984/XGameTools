ClothesShopConfig ={};
ClothesShopID = 
{
	Id001 = 650001,
	Id1001 = 651001,
	Id2001 = 652001,
}
ClothesShopConfig[ClothesShopID.Id001] =
{
	Id = 1,
	Name = "服装柜",
	Type = 1,
	ItemList = {
		{
			Value = 640001,
		},
		{
			Value = 640002,
		},
		{
			Value = 640003,
		},
		{
			Value = 640004,
		},
		{
			Value = 640005,
		},
		{
			Value = 640006,
		},
		{
			Value = 640007,
		},
		{
			Value = 640008,
		},
		{
			Value = 640009,
		},
		{
			Value = 640010,
		},
		{
			Value = 640011,
		},
		{
			Value = 640012,
		},
		{
			Value = 640013,
		},
		{
			Value = 640014,
		},
		{
			Value = 640015,
		},
		{
			Value = 640016,
		},
		{
			Value = 640017,
		},
		{
			Value = 640018,
		},
		{
			Value = 640019,
		},
		{
			Value = 640020,
		},
		{
			Value = 640021,
		},
		{
			Value = 640022,
		},
		{
			Value = 640023,
		},
		{
			Value = 640024,
		},
		{
			Value = 640025,
		},
		{
			Value = 640026,
		},
		{
			Value = 640027,
		},
		{
			Value = 640028,
		},
		{
			Value = 640029,
		},
		{
			Value = 640030,
		},
		{
			Value = 640031,
		},
		{
			Value = 640032,
		},
		{
			Value = 640033,
		},
		{
			Value = 640034,
		},
		{
			Value = 640035,
		},
		{
			Value = 640036,
		},
		{
			Value = 640037,
		},
		{
			Value = 640038,
		},
	},
}
ClothesShopConfig[ClothesShopID.Id1001] =
{
	Id = 1001,
	Name = "服装柜",
	Type = 1,
	ItemList = {
		{
			Value = 640001,
			CostItem = {
				Id = 327314,
				Num = 150,
			},
		},
		{
			Value = 640002,
			CostItem = {
				Id = 327314,
				Num = 100,
			},
		},
		{
			Value = 640003,
			CostItem = {
				Id = 327314,
				Num = 150,
			},
		},
		{
			Value = 640004,
			CostItem = {
				Id = 327314,
				Num = 150,
			},
		},
		{
			Value = 640005,
			CostItem = {
				Id = 327314,
				Num = 100,
			},
		},
		{
			Value = 640006,
			CostItem = {
				Id = 327314,
				Num = 100,
			},
		},
		{
			Value = 640007,
			CostItem = {
				Id = 327314,
				Num = 150,
			},
		},
		{
			Value = 640008,
			CostItem = {
				Id = 327314,
				Num = 150,
			},
		},
		{
			Value = 640009,
			CostItem = {
				Id = 327314,
				Num = 150,
			},
		},
		{
			Value = 640010,
			CostItem = {
				Id = 327314,
				Num = 150,
			},
		},
		{
			Value = 640011,
			CostItem = {
				Id = 327314,
				Num = 150,
			},
		},
		{
			Value = 640012,
			CostItem = {
				Id = 327314,
				Num = 150,
			},
		},
		{
			Value = 640013,
			CostItem = {
				Id = 327314,
				Num = 150,
			},
		},
		{
			Value = 640014,
			CostItem = {
				Id = 327314,
				Num = 150,
			},
		},
		{
			Value = 640015,
			CostItem = {
				Id = 327314,
				Num = 150,
			},
		},
		{
			Value = 640016,
			CostItem = {
				Id = 327314,
				Num = 150,
			},
		},
		{
			Value = 640017,
			CostItem = {
				Id = 327314,
				Num = 100,
			},
		},
		{
			Value = 640018,
			CostItem = {
				Id = 327314,
				Num = 100,
			},
		},
		{
			Value = 640019,
			CostItem = {
				Id = 327314,
				Num = 200,
			},
		},
		{
			Value = 640020,
			CostItem = {
				Id = 327314,
				Num = 150,
			},
		},
		{
			Value = 640021,
			CostItem = {
				Id = 327314,
				Num = 100,
			},
		},
		{
			Value = 640022,
			CostItem = {
				Id = 327314,
				Num = 200,
			},
		},
		{
			Value = 640023,
			CostItem = {
				Id = 327314,
				Num = 150,
			},
		},
		{
			Value = 640024,
			CostItem = {
				Id = 327314,
				Num = 200,
			},
		},
		{
			Value = 640025,
			CostItem = {
				Id = 327314,
				Num = 150,
			},
		},
		{
			Value = 640026,
			CostItem = {
				Id = 327314,
				Num = 100,
			},
		},
		{
			Value = 640027,
			CostItem = {
				Id = 327314,
				Num = 100,
			},
		},
		{
			Value = 640028,
			CostItem = {
				Id = 327314,
				Num = 100,
			},
		},
		{
			Value = 640029,
			CostItem = {
				Id = 327314,
				Num = 200,
			},
		},
		{
			Value = 640030,
			CostItem = {
				Id = 327314,
				Num = 150,
			},
		},
		{
			Value = 640031,
			CostItem = {
				Id = 327314,
				Num = 200,
			},
		},
		{
			Value = 640032,
			CostItem = {
				Id = 327314,
				Num = 200,
			},
		},
		{
			Value = 640033,
			CostItem = {
				Id = 327314,
				Num = 300,
			},
		},
		{
			Value = 640034,
			CostItem = {
				Id = 327314,
				Num = 300,
			},
		},
		{
			Value = 640035,
			CostItem = {
				Id = 327314,
				Num = 150,
			},
		},
		{
			Value = 640036,
			CostItem = {
				Id = 327314,
				Num = 200,
			},
		},
		{
			Value = 640037,
			CostItem = {
				Id = 327314,
				Num = 200,
			},
		},
		{
			Value = 640038,
			CostItem = {
				Id = 327314,
				Num = 200,
			},
		},
	},
}
ClothesShopConfig[ClothesShopID.Id2001] =
{
	Id = 2001,
	Name = "礼品柜",
	Type = 2,
	ItemList = {
		{
			Value = 641001,
			CostItem = {
				Id = 327314,
				Num = 20,
			},
		},
		{
			Value = 641002,
			CostItem = {
				Id = 327314,
				Num = 12,
			},
		},
		{
			Value = 641003,
			CostItem = {
				Id = 327314,
				Num = 12,
			},
		},
		{
			Value = 641004,
			CostItem = {
				Id = 327314,
				Num = 85,
			},
		},
		{
			Value = 641005,
			CostItem = {
				Id = 327314,
				Num = 8,
			},
		},
		{
			Value = 641006,
			CostItem = {
				Id = 327314,
				Num = 25,
			},
		},
		{
			Value = 641007,
			CostItem = {
				Id = 327314,
				Num = 85,
			},
		},
	},
}

