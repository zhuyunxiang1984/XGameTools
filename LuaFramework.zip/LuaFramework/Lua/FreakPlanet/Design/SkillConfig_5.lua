
SkillConfig[SkillID.Id6001] =
{
	Id = 6001,
	Name = "男性队员生命+",
	Desc = "男性队员生命 +{Value}%",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Team,
		Tag = 
		{
			561702,
		},
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200001,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id6002] =
{
	Id = 6002,
	Name = "男性队员攻击+",
	Desc = "男性队员攻击 +{Value}%",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Team,
		Tag = 
		{
			561702,
		},
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200002,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id6003] =
{
	Id = 6003,
	Name = "男性队员忍耐+",
	Desc = "男性队员忍耐 +{Value}%",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Team,
		Tag = 
		{
			561702,
		},
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200003,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id6004] =
{
	Id = 6004,
	Name = "男性队员暴击+",
	Desc = "男性队员暴击 +{Value}%",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Team,
		Tag = 
		{
			561702,
		},
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200004,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id6005] =
{
	Id = 6005,
	Name = "女性队员生命+",
	Desc = "女性队员生命 +{Value}%",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Team,
		Tag = 
		{
			561703,
		},
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200001,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id6006] =
{
	Id = 6006,
	Name = "女性队员攻击+",
	Desc = "女性队员攻击 +{Value}%",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Team,
		Tag = 
		{
			561703,
		},
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200002,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id6007] =
{
	Id = 6007,
	Name = "女性队员忍耐+",
	Desc = "女性队员忍耐 +{Value}%",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Team,
		Tag = 
		{
			561703,
		},
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200003,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id6008] =
{
	Id = 6008,
	Name = "女性队员暴击+",
	Desc = "女性队员暴击 +{Value}%",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Team,
		Tag = 
		{
			561703,
		},
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200004,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id6009] =
{
	Id = 6009,
	Name = "冒险星队员生命+",
	Desc = "冒险星队员生命 +{Value}%",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Team,
		Tag = 
		{
			560103,
		},
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200001,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id6010] =
{
	Id = 6010,
	Name = "冒险星队员攻击+",
	Desc = "冒险星队员攻击 +{Value}%",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Team,
		Tag = 
		{
			560103,
		},
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200002,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id6011] =
{
	Id = 6011,
	Name = "冒险星队员忍耐+",
	Desc = "冒险星队员忍耐 +{Value}%",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Team,
		Tag = 
		{
			560103,
		},
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200003,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id6012] =
{
	Id = 6012,
	Name = "冒险星队员暴击+",
	Desc = "冒险星队员暴击 +{Value}%",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Team,
		Tag = 
		{
			560103,
		},
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200004,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id6013] =
{
	Id = 6013,
	Name = "美食星队员生命+",
	Desc = "美食星队员生命 +{Value}%",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Team,
		Tag = 
		{
			560104,
		},
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200001,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id6014] =
{
	Id = 6014,
	Name = "美食星队员攻击+",
	Desc = "美食星队员攻击 +{Value}%",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Team,
		Tag = 
		{
			560104,
		},
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200002,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id6015] =
{
	Id = 6015,
	Name = "美食星队员忍耐+",
	Desc = "美食星队员忍耐 +{Value}%",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Team,
		Tag = 
		{
			560104,
		},
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200003,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id6016] =
{
	Id = 6016,
	Name = "美食星队员暴击+",
	Desc = "美食星队员暴击 +{Value}%",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Team,
		Tag = 
		{
			560104,
		},
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200004,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id6017] =
{
	Id = 6017,
	Name = "博物馆星队员生命+",
	Desc = "博物馆星队员生命 +{Value}%",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Team,
		Tag = 
		{
			560105,
		},
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200001,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id6018] =
{
	Id = 6018,
	Name = "博物馆星队员攻击+",
	Desc = "博物馆星队员攻击 +{Value}%",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Team,
		Tag = 
		{
			560105,
		},
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200002,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id6019] =
{
	Id = 6019,
	Name = "博物馆星队员忍耐+",
	Desc = "博物馆星队员忍耐 +{Value}%",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Team,
		Tag = 
		{
			560105,
		},
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200003,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id6020] =
{
	Id = 6020,
	Name = "博物馆星队员暴击+",
	Desc = "博物馆星队员暴击 +{Value}%",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Team,
		Tag = 
		{
			560105,
		},
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200004,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id6021] =
{
	Id = 6021,
	Name = "悬疑星队员生命+",
	Desc = "悬疑星队员生命 +{Value}%",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Team,
		Tag = 
		{
			560106,
		},
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200001,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id6022] =
{
	Id = 6022,
	Name = "悬疑星队员攻击+",
	Desc = "悬疑星队员攻击 +{Value}%",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Team,
		Tag = 
		{
			560106,
		},
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200002,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id6023] =
{
	Id = 6023,
	Name = "悬疑星队员忍耐+",
	Desc = "悬疑星队员忍耐 +{Value}%",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Team,
		Tag = 
		{
			560106,
		},
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200003,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id6024] =
{
	Id = 6024,
	Name = "悬疑星队员暴击+",
	Desc = "悬疑星队员暴击 +{Value}%",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Team,
		Tag = 
		{
			560106,
		},
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200004,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id6025] =
{
	Id = 6025,
	Name = "海洋星队员生命+",
	Desc = "海洋星队员生命 +{Value}%",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Team,
		Tag = 
		{
			560107,
		},
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200001,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id6026] =
{
	Id = 6026,
	Name = "海洋星队员攻击+",
	Desc = "海洋星队员攻击 +{Value}%",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Team,
		Tag = 
		{
			560107,
		},
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200002,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id6027] =
{
	Id = 6027,
	Name = "海洋星队员忍耐+",
	Desc = "海洋星队员忍耐 +{Value}%",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Team,
		Tag = 
		{
			560107,
		},
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200003,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id6028] =
{
	Id = 6028,
	Name = "海洋星队员暴击+",
	Desc = "海洋星队员暴击 +{Value}%",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Team,
		Tag = 
		{
			560107,
		},
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200004,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id6029] =
{
	Id = 6029,
	Name = "星际流民队员生命+",
	Desc = "星际流民队员生命 +{Value}%",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Team,
		Tag = 
		{
			560110,
		},
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200001,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id6030] =
{
	Id = 6030,
	Name = "星际流民队员攻击+",
	Desc = "星际流民队员攻击 +{Value}%",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Team,
		Tag = 
		{
			560110,
		},
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200002,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id6031] =
{
	Id = 6031,
	Name = "星际流民队员忍耐+",
	Desc = "星际流民队员忍耐 +{Value}%",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Team,
		Tag = 
		{
			560110,
		},
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200003,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id6032] =
{
	Id = 6032,
	Name = "星际流民队员暴击+",
	Desc = "星际流民队员暴击 +{Value}%",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Team,
		Tag = 
		{
			560110,
		},
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200004,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id6033] =
{
	Id = 6033,
	Name = "每个3星队员使全队生命+",
	Desc = "每个3星队员使全队生命 +{Value}%",
	EffectModule = EffectModule.BuildTeam,
	MultiCount = true,
	EffectCondition = {
		Rarity = 4,
		RarityOp = 1,
	},
	EffectRange = {
		EffectScope = EffectScope.Team,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200001,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id6034] =
{
	Id = 6034,
	Name = "3星队员攻击+",
	Desc = "3星队员攻击 +{Value}%",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Team,
		Rarity = 4,
		RarityOp = 1,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200002,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id6035] =
{
	Id = 6035,
	Name = "每3回合全队恢复",
	Desc = "每3回合，全队回血{Value}%",
	EffectModule = EffectModule.Battle,
	BattleParameter = {
		StartRound = 3,
		IntervalRound = 3,
		Limited = 233,
	},
	EffectRange = {
		EffectScope = EffectScope.Team,
	},
	Effect = {
		EffectAttribute = "Recovery",
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id6036] =
{
	Id = 6036,
	Name = "星际流民队员每3回合单次闪避",
	Desc = "星际流民队员每3回合{Value}%闪避攻击",
	EffectModule = EffectModule.Battle,
	BattleParameter = {
		StartRound = 2,
		IntervalRound = 3,
		Limited = 233,
	},
	EffectRange = {
		EffectScope = EffectScope.Team,
		Tag = 
		{
			560110,
		},
	},
	Effect = {
		EffectAttribute = "DodgeOnce",
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id6037] =
{
	Id = 6037,
	Name = "星际流民队员每3回合单次暴伤+",
	Desc = "星际流民队员每3回合本回合暴击伤害 +{Value}%",
	EffectModule = EffectModule.Battle,
	BattleParameter = {
		StartRound = 2,
		IntervalRound = 3,
		Limited = 233,
	},
	EffectRange = {
		EffectScope = EffectScope.Team,
		Tag = 
		{
			560110,
		},
	},
	Effect = {
		EffectAttribute = "CritDamageOnce",
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id6038] =
{
	Id = 6038,
	Name = "庙会角色攻击+",
	Desc = "庙会角色队员攻击 +{Value}%",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Team,
		Tag = 
		{
			562935,
		},
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200002,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id6039] =
{
	Id = 6039,
	Name = "庙会角色生命+",
	Desc = "庙会角色队员生命 +{Value}%",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Team,
		Tag = 
		{
			562935,
		},
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200001,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id6040] =
{
	Id = 6040,
	Name = "冬日温泉组攻击+",
	Desc = "冬日温泉组攻击+{Value}%",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Team,
		Tag = 
		{
			562935,
		},
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200002,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id6041] =
{
	Id = 6041,
	Name = "冬日温泉组生命+",
	Desc = "冬日温泉组生命+{Value}%",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Team,
		Tag = 
		{
			562935,
		},
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200001,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id7001] =
{
	Id = 7001,
	Name = "探索时间+",
	Desc = "探索等待时间 -{Value}%",
	EffectModule = EffectModule.ExploreTime,
	EffectRange = {
		EffectScope = EffectScope.Team,
		Characters = 
		{
			220001,
		},
	},
	Effect = {
		EffectAttribute = "ExploreTime",
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id7002] =
{
	Id = 7002,
	Name = "水元素敌人生命-",
	Desc = "水元素敌人生命 -{Value}%",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Team,
		Characters = 
		{
			220025,
		},
	},
	Effect = {
		EffectAttribute = "SpecificEnemyAbility",
		EffectValue = 200001,
		Element = 210001,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id7003] =
{
	Id = 7003,
	Name = "压制敌人等级",
	Desc = "敌人等级 -{Value}",
	Dialog = "臣服吧！",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Team,
		Characters = 
		{
			220028,
		},
	},
	Effect = {
		EffectAttribute = "EnemyLevel",
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id7004] =
{
	Id = 7004,
	Name = "全队暴击+",
	Desc = "全队暴击 +{Value}",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Team,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200004,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id7005] =
{
	Id = 7005,
	Name = "全队忍耐+",
	Desc = "全队忍耐 +{Value}",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Team,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200003,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id7006] =
{
	Id = 7006,
	Name = "全队大恢复",
	Desc = "3回合后，每回合全队回血 {Value}，最多5次",
	EffectModule = EffectModule.Battle,
	BattleParameter = {
		StartRound = 3,
		IntervalRound = 1,
		Limited = 5,
	},
	EffectRange = {
		EffectScope = EffectScope.Team,
	},
	Effect = {
		EffectAttribute = "Recovery",
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id7007] =
{
	Id = 7007,
	Name = "全队生命+",
	Desc = "全队生命 +{Value}",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Team,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200001,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id7008] =
{
	Id = 7008,
	Name = "光元素队员生命+",
	Desc = "光元素队员生命 +{Value}",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Team,
		Element = 210004,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200001,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id7009] =
{
	Id = 7009,
	Name = "光元素队员攻击+",
	Desc = "光元素队员攻击 +{Value}",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Team,
		Element = 210004,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200002,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id7010] =
{
	Id = 7010,
	Name = "冒险星敌人掉落概率+",
	Desc = "冒险星敌人道具掉落率 +{Value}%",
	EffectModule = EffectModule.ExploreDrop,
	EffectRange = {
		EffectScope = EffectScope.Team,
		Characters = 
		{
			220003,
		},
	},
	Effect = {
		EffectAttribute = "EnemyDropChance",
		Tag = 
		{
			560103,
		},
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id7011] =
{
	Id = 7011,
	Name = "男性队员生命+",
	Desc = "男性队员生命 +{Value}",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Team,
		Tag = 
		{
			561702,
		},
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200001,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id7012] =
{
	Id = 7012,
	Name = "女性队员攻击+",
	Desc = "女性队员攻击 +{Value}",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Team,
		Tag = 
		{
			561703,
		},
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200002,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id7013] =
{
	Id = 7013,
	Name = "全队战力+",
	Desc = "探索中，全队战力 +{Value}",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Team,
	},
	Effect = {
		EffectAttribute = "FightPower",
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id7014] =
{
	Id = 7014,
	Name = "探索金币+",
	Desc = "探索金币数量 +{Value}%",
	EffectModule = EffectModule.ExploreDrop,
	EffectRange = {
		EffectScope = EffectScope.Team,
		Characters = 
		{
			220011,
		},
	},
	Effect = {
		EffectAttribute = "GoodsDropNumber",
		EffectValue = 1,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id7015] =
{
	Id = 7015,
	Name = "全队光元素打击",
	Desc = "全队对光元素敌人伤害 +{Value}%",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Team,
	},
	Effect = {
		EffectAttribute = "DamageToElement",
		EffectValue = 210004,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id7016] =
{
	Id = 7016,
	Name = "全队光元素免伤",
	Desc = "全队受光元素敌人伤害 -{Value}%",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Team,
	},
	Effect = {
		EffectAttribute = "DamageFromElement",
		EffectValue = 210004,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id7017] =
{
	Id = 7017,
	Name = "全队生命+",
	Desc = "全队生命 +{Value}",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Team,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200001,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id7018] =
{
	Id = 7018,
	Name = "全队亲和+",
	Desc = "全队亲和 +{Value}",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Team,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200006,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id7019] =
{
	Id = 7019,
	Name = "女王大人受到暴伤+",
	Desc = "女王大人受到的暴击伤害 -{Value}%",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Team,
		Characters = 
		{
			220028,
		},
	},
	Effect = {
		EffectAttribute = "DamageFromCritDamage",
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id7020] =
{
	Id = 7020,
	Name = "城镇卫兵忍耐+",
	Desc = "城镇卫兵忍耐 +{Value}",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Team,
		Characters = 
		{
			220014,
		},
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200003,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id7021] =
{
	Id = 7021,
	Name = "躲避强敌",
	Desc = "打不过的怪物出现概率 -{Value}%",
	EffectModule = EffectModule.ExploreEnemy,
	EffectRange = {
		EffectScope = EffectScope.Team,
		Characters = 
		{
			220011,
		},
	},
	Effect = {
		EffectAttribute = "EnemyWeight",
		Chance = 100,
		EnemyWeightCondition = {
			CompareWin = 2,
		},
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id7022] =
{
	Id = 7022,
	Name = "敌人暴击-",
	Desc = "敌人暴击 -{Value}",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Team,
		Characters = 
		{
			220026,
		},
	},
	Effect = {
		EffectAttribute = "SpecificEnemyAbility",
		EffectValue = 200004,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id7023] =
{
	Id = 7023,
	Name = "3回合后，全队攻击+",
	Desc = "3回合后，全队攻击 +{Value}，最多5次",
	EffectModule = EffectModule.Battle,
	BattleParameter = {
		StartRound = 3,
		IntervalRound = 1,
		Limited = 5,
	},
	EffectRange = {
		EffectScope = EffectScope.Team,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200002,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id7024] =
{
	Id = 7024,
	Name = "头目招来",
	Desc = "金色及以上品质敌人出现概率 +{Value}%",
	EffectModule = EffectModule.ExploreEnemy,
	EffectRange = {
		EffectScope = EffectScope.Team,
		Characters = 
		{
			220019,
		},
	},
	Effect = {
		EffectAttribute = "EnemyWeight",
		Rarity = 4,
		RarityOp = 0,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id7025] =
{
	Id = 7025,
	Name = "每回合全队攻击+",
	Desc = "每回合全队攻击 +{Value}，最多5次",
	EffectModule = EffectModule.Battle,
	BattleParameter = {
		StartRound = 1,
		IntervalRound = 1,
		Limited = 5,
	},
	EffectRange = {
		EffectScope = EffectScope.Team,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200002,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id7026] =
{
	Id = 7026,
	Name = "每回合全队恢复",
	Desc = "每回合全队回血 {Value}，最多5次",
	EffectModule = EffectModule.Battle,
	BattleParameter = {
		StartRound = 1,
		IntervalRound = 1,
		Limited = 5,
	},
	EffectRange = {
		EffectScope = EffectScope.Team,
	},
	Effect = {
		EffectAttribute = "Recovery",
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id7027] =
{
	Id = 7027,
	Name = "道具掉落率+",
	Desc = "道具掉落率 +{Value}%",
	EffectModule = EffectModule.ExploreDrop,
	EffectRange = {
		EffectScope = EffectScope.Team,
		Characters = 
		{
			220101,
		},
	},
	Effect = {
		EffectAttribute = "GoodsDropChance",
		Tag = 
		{
			564305,
		},
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id7028] =
{
	Id = 7028,
	Name = "探索金币+",
	Desc = "探索金币数量 +{Value}%",
	EffectModule = EffectModule.ExploreDrop,
	EffectRange = {
		EffectScope = EffectScope.Team,
		Characters = 
		{
			220101,
		},
	},
	Effect = {
		EffectAttribute = "GoodsDropNumber",
		EffectValue = 1,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id7029] =
{
	Id = 7029,
	Name = "男队员生命+",
	Desc = "生命 +{Value}%",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Team,
		Tag = 
		{
			561702,
		},
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200001,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id7030] =
{
	Id = 7030,
	Name = "男队员攻击+",
	Desc = "攻击 +{Value}%",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Team,
		Tag = 
		{
			561702,
		},
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200002,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id7031] =
{
	Id = 7031,
	Name = "男队员忍耐+",
	Desc = "忍耐 +{Value}%",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Team,
		Tag = 
		{
			561702,
		},
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200003,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id7032] =
{
	Id = 7032,
	Name = "男队员暴击+",
	Desc = "暴击 +{Value}%",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Team,
		Tag = 
		{
			561702,
		},
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200004,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id7033] =
{
	Id = 7033,
	Name = "男队员技巧+",
	Desc = "技巧 +{Value}%",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Team,
		Tag = 
		{
			561702,
		},
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200005,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id7034] =
{
	Id = 7034,
	Name = "男队员亲和+",
	Desc = "亲和 +{Value}%",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Team,
		Tag = 
		{
			561702,
		},
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200006,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id7035] =
{
	Id = 7035,
	Name = "男队员力气+",
	Desc = "力气 +{Value}%",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Team,
		Tag = 
		{
			561702,
		},
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200007,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id7036] =
{
	Id = 7036,
	Name = "男队员智力+",
	Desc = "智力 +{Value}%",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Team,
		Tag = 
		{
			561702,
		},
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200008,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id7037] =
{
	Id = 7037,
	Name = "打工工时+",
	Desc = "打工中，最大工时 +{Value}%",
	EffectModule = EffectModule.WorkShop,
	EffectRange = {
		EffectScope = EffectScope.Team,
		Characters = 
		{
			220105,
		},
	},
	Effect = {
		EffectAttribute = "WorkShopMaxWorkTime",
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id7038] =
{
	Id = 7038,
	Name = "打工金币+",
	Desc = "打工金币数量 +{Value}%",
	EffectModule = EffectModule.WorkShop,
	EffectRange = {
		EffectScope = EffectScope.Team,
		Characters = 
		{
			220113,
		},
	},
	Effect = {
		EffectAttribute = "WorkShopGoodsNumber",
		EffectValue = 1,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id7039] =
{
	Id = 7039,
	Name = "每回合美食星队员恢复",
	Desc = "每回合回血 {Value}，最多5次",
	EffectModule = EffectModule.Battle,
	BattleParameter = {
		StartRound = 1,
		IntervalRound = 1,
		Limited = 5,
	},
	EffectRange = {
		EffectScope = EffectScope.Team,
		Tag = 
		{
			560104,
		},
	},
	Effect = {
		EffectAttribute = "Recovery",
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id7040] =
{
	Id = 7040,
	Name = "压制风元素敌人暴击",
	Desc = "敌人暴击 -{Value}",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Team,
		Characters = 
		{
			220118,
		},
	},
	Effect = {
		EffectAttribute = "SpecificEnemyAbility",
		EffectValue = 200004,
		Element = 210003,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id7041] =
{
	Id = 7041,
	Name = "全队暴击伤害+",
	Desc = "暴击伤害 +{Value}%",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Team,
	},
	Effect = {
		EffectAttribute = "CritDamage",
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id7042] =
{
	Id = 7042,
	Name = "汉堡小姐热狗先生大恢复",
	Desc = "每回合全队回血 {Value}，最多5次",
	EffectModule = EffectModule.Battle,
	BattleParameter = {
		StartRound = 1,
		IntervalRound = 1,
		Limited = 5,
	},
	EffectRange = {
		EffectScope = EffectScope.Team,
		Characters = 
		{
			220126,
			220127,
		},
	},
	Effect = {
		EffectAttribute = "Recovery",
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id7043] =
{
	Id = 7043,
	Name = "全队暴击+",
	Desc = "全队暴击 +{Value}",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Team,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200004,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id7044] =
{
	Id = 7044,
	Name = "薯条国王攻击+",
	Desc = "攻击 +{Value}",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Team,
		Characters = 
		{
			220131,
		},
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200002,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id7045] =
{
	Id = 7045,
	Name = "番茄酱侍卫忍耐+",
	Desc = "番茄酱侍卫忍耐 +{Value}",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Team,
		Characters = 
		{
			220128,
		},
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200003,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id7046] =
{
	Id = 7046,
	Name = "全队战力+",
	Desc = "探索中，全队战力 +{Value}%",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Team,
	},
	Effect = {
		EffectAttribute = "FightPower",
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id7047] =
{
	Id = 7047,
	Name = "敌人捕捉率+",
	Desc = "敌人捕捉成功率 +{Value}%",
	EffectModule = EffectModule.ExploreCatch,
	EffectRange = {
		EffectScope = EffectScope.Team,
		Characters = 
		{
			220201,
		},
	},
	Effect = {
		EffectAttribute = "PetCatchSuccessChance",
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id7048] =
{
	Id = 7048,
	Name = "全队智力+",
	Desc = "全队智力 +{Value}",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Team,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200008,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id7049] =
{
	Id = 7049,
	Name = "打工工时+",
	Desc = "打工中，最大工时 +{Value}%",
	EffectModule = EffectModule.WorkShop,
	EffectRange = {
		EffectScope = EffectScope.Team,
		Characters = 
		{
			220206,
		},
	},
	Effect = {
		EffectAttribute = "WorkShopMaxWorkTime",
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id7050] =
{
	Id = 7050,
	Name = "全队亲和+",
	Desc = "全队亲和 +{Value}",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Team,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200006,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id7051] =
{
	Id = 7051,
	Name = "打工工时+",
	Desc = "打工中，最大工时 +{Value}%",
	EffectModule = EffectModule.WorkShop,
	EffectRange = {
		EffectScope = EffectScope.Team,
		Characters = 
		{
			220210,
		},
	},
	Effect = {
		EffectAttribute = "WorkShopMaxWorkTime",
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id7052] =
{
	Id = 7052,
	Name = "压制敌人生命",
	Desc = "敌人生命 -{Value}%",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Team,
		Characters = 
		{
			220212,
		},
	},
	Effect = {
		EffectAttribute = "SpecificEnemyAbility",
		EffectValue = 200001,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id7053] =
{
	Id = 7053,
	Name = "敌人捕捉率+",
	Desc = "敌人捕捉成功率 +{Value}%",
	EffectModule = EffectModule.ExploreCatch,
	EffectRange = {
		EffectScope = EffectScope.Team,
		Characters = 
		{
			220214,
		},
	},
	Effect = {
		EffectAttribute = "PetCatchSuccessChance",
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id7054] =
{
	Id = 7054,
	Name = "探索金币+",
	Desc = "探索金币数量 +{Value}%",
	EffectModule = EffectModule.ExploreDrop,
	EffectRange = {
		EffectScope = EffectScope.Team,
		Characters = 
		{
			220203,
		},
	},
	Effect = {
		EffectAttribute = "GoodsDropNumber",
		EffectValue = 1,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id7055] =
{
	Id = 7055,
	Name = "道具掉落率+",
	Desc = "道具掉落率 +{Value}%",
	EffectModule = EffectModule.ExploreDrop,
	EffectRange = {
		EffectScope = EffectScope.Team,
		Characters = 
		{
			220223,
		},
	},
	Effect = {
		EffectAttribute = "GoodsDropChance",
		Tag = 
		{
			564305,
		},
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id7056] =
{
	Id = 7056,
	Name = "每3回合，魔术师概率无视目标闪避",
	Desc = "每3回合，{Value}%概率无视敌人闪避",
	EffectModule = EffectModule.Battle,
	BattleParameter = {
		StartRound = 2,
		IntervalRound = 3,
		Limited = 233,
	},
	EffectRange = {
		EffectScope = EffectScope.Team,
		Characters = 
		{
			220227,
		},
	},
	Effect = {
		EffectAttribute = "DodgeIgnoreOnce",
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id7057] =
{
	Id = 7057,
	Name = "每3回合，微笑女神本回合闪避率",
	Desc = "每3回合，{Value}%概率闪避攻击",
	EffectModule = EffectModule.Battle,
	BattleParameter = {
		StartRound = 2,
		IntervalRound = 3,
		Limited = 233,
	},
	EffectRange = {
		EffectScope = EffectScope.Team,
		Characters = 
		{
			220226,
		},
	},
	Effect = {
		EffectAttribute = "DodgeOnce",
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id7058] =
{
	Id = 7058,
	Name = "全队水元素打击",
	Desc = "全队对水元素敌人伤害 +{Value}%",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Team,
	},
	Effect = {
		EffectAttribute = "DamageToElement",
		EffectValue = 210001,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id7059] =
{
	Id = 7059,
	Name = "全队火元素打击",
	Desc = "全队对火元素敌人伤害 +{Value}%",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Team,
	},
	Effect = {
		EffectAttribute = "DamageToElement",
		EffectValue = 210002,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id7060] =
{
	Id = 7060,
	Name = "全队风元素打击",
	Desc = "全队对风元素敌人伤害 +{Value}%",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Team,
	},
	Effect = {
		EffectAttribute = "DamageToElement",
		EffectValue = 210003,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id7061] =
{
	Id = 7061,
	Name = "打工食物+",
	Desc = "打工食物数量 +{Value}%",
	EffectModule = EffectModule.WorkShop,
	EffectRange = {
		EffectScope = EffectScope.Team,
		Characters = 
		{
			220301,
		},
	},
	Effect = {
		EffectAttribute = "WorkShopGoodsNumber",
		Tag = 
		{
			564306,
		},
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id7062] =
{
	Id = 7062,
	Name = "全队暗元素打击",
	Desc = "全队对暗元素敌人伤害 +{Value}%",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Team,
	},
	Effect = {
		EffectAttribute = "DamageToElement",
		EffectValue = 210005,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id7063] =
{
	Id = 7063,
	Name = "全队暗元素免伤",
	Desc = "全队受暗元素敌人伤害 -{Value}%",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Team,
	},
	Effect = {
		EffectAttribute = "DamageFromElement",
		EffectValue = 210005,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id7064] =
{
	Id = 7064,
	Name = "道具掉落率+",
	Desc = "道具掉落率 +{Value}%",
	EffectModule = EffectModule.ExploreDrop,
	EffectRange = {
		EffectScope = EffectScope.Team,
		Characters = 
		{
			220306,
		},
	},
	Effect = {
		EffectAttribute = "GoodsDropChance",
		Tag = 
		{
			564305,
		},
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id7065] =
{
	Id = 7065,
	Name = "全队技巧+",
	Desc = "全队技巧 +{Value}",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Team,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200005,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id7066] =
{
	Id = 7066,
	Name = "打工工时+",
	Desc = "打工中，最大工时 +{Value}%",
	EffectModule = EffectModule.WorkShop,
	EffectRange = {
		EffectScope = EffectScope.Team,
		Characters = 
		{
			220309,
		},
	},
	Effect = {
		EffectAttribute = "WorkShopMaxWorkTime",
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id7067] =
{
	Id = 7067,
	Name = "全队攻击+",
	Desc = "攻击 +{Value}",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Team,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200002,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id7068] =
{
	Id = 7068,
	Name = "压制暗元素敌人忍耐",
	Desc = "敌人忍耐 -{Value}",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Team,
		Characters = 
		{
			220320,
		},
	},
	Effect = {
		EffectAttribute = "SpecificEnemyAbility",
		EffectValue = 200003,
		Element = 210005,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id7069] =
{
	Id = 7069,
	Name = "每3回合全队单次必中+",
	Desc = "每3回合，全队{Value}%概率无视敌人闪避",
	EffectModule = EffectModule.Battle,
	BattleParameter = {
		StartRound = 2,
		IntervalRound = 3,
		Limited = 233,
	},
	EffectRange = {
		EffectScope = EffectScope.Team,
	},
	Effect = {
		EffectAttribute = "DodgeIgnoreOnce",
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id7070] =
{
	Id = 7070,
	Name = "回合中，黑警长与黑法医每次受击，攻击+",
	Desc = "回合中，黑警长与黑法医每次受击，攻击 +{Value}",
	EffectModule = EffectModule.Battle,
	BattleParameter = {
		StartRound = 1,
		IntervalRound = 1,
		Limited = 233,
	},
	EffectRange = {
		EffectScope = EffectScope.Team,
		Characters = 
		{
			220316,
			220317,
		},
	},
	Effect = {
		EffectAttribute = "AttributeWithHurt",
		EffectValue = 200002,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id7071] =
{
	Id = 7071,
	Name = "每3回合全队单次暴率+",
	Desc = "每3回合，全队本回合暴率 +{Value}%",
	EffectModule = EffectModule.Battle,
	BattleParameter = {
		StartRound = 2,
		IntervalRound = 3,
		Limited = 233,
	},
	EffectRange = {
		EffectScope = EffectScope.Team,
	},
	Effect = {
		EffectAttribute = "CritChanceOnce",
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id7072] =
{
	Id = 7072,
	Name = "全队大恢复",
	Desc = "3回合后，每回合全队回血 {Value}%，最多5次",
	EffectModule = EffectModule.Battle,
	BattleParameter = {
		StartRound = 3,
		IntervalRound = 1,
		Limited = 5,
	},
	EffectRange = {
		EffectScope = EffectScope.Team,
	},
	Effect = {
		EffectAttribute = "Recovery",
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id7073] =
{
	Id = 7073,
	Name = "暗元素暴击伤害+",
	Desc = "暗元素队员暴击伤害 +{Value}%",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Team,
		Element = 210005,
	},
	Effect = {
		EffectAttribute = "CritDamage",
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id7074] =
{
	Id = 7074,
	Name = "暗元素受到暴伤+",
	Desc = "暗元素队员受到暴击伤害 +{Value}%",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Team,
		Element = 210005,
	},
	Effect = {
		EffectAttribute = "DamageFromCritDamage",
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id7075] =
{
	Id = 7075,
	Name = "情缘组暴击+",
	Desc = "教授、杰克瑞波、凶手暴击 +{Value}",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Team,
		Characters = 
		{
			220325,
			220321,
			220305,
		},
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200004,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id7076] =
{
	Id = 7076,
	Name = "情缘组忍耐+",
	Desc = "教授、杰克瑞波、凶手忍耐 -{Value}",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Team,
		Characters = 
		{
			220325,
			220321,
			220305,
		},
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200003,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id7077] =
{
	Id = 7077,
	Name = "探索金币+",
	Desc = "探索金币数量 +{Value}",
	EffectModule = EffectModule.ExploreDrop,
	EffectRange = {
		EffectScope = EffectScope.Team,
		Characters = 
		{
			223061,
		},
	},
	Effect = {
		EffectAttribute = "GoodsDropNumber",
		EffectValue = 1,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id7078] =
{
	Id = 7078,
	Name = "道具掉落率+",
	Desc = "道具掉落率 +{Value}",
	EffectModule = EffectModule.ExploreDrop,
	EffectRange = {
		EffectScope = EffectScope.Team,
		Characters = 
		{
			223061,
		},
	},
	Effect = {
		EffectAttribute = "GoodsDropChance",
		Tag = 
		{
			564305,
		},
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id7079] =
{
	Id = 7079,
	Name = "情缘组无视忍耐攻击%",
	Desc = "魔法师及术士攻击时无视敌人{Value}%忍耐",
	EffectModule = EffectModule.Battle,
	BattleParameter = {
		StartRound = 1,
		IntervalRound = 1,
		Limited = 233,
	},
	EffectRange = {
		EffectScope = EffectScope.Team,
		Characters = 
		{
			220010,
			223007,
		},
	},
	Effect = {
		EffectAttribute = "DefendIgnoreOnce",
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id7080] =
{
	Id = 7080,
	Name = "打工捕捉道具+",
	Desc = "打工捕捉道具数量 +{Value}%",
	EffectModule = EffectModule.WorkShop,
	EffectRange = {
		EffectScope = EffectScope.Team,
		Characters = 
		{
			223106,
		},
	},
	Effect = {
		EffectAttribute = "WorkShopGoodsNumber",
		Tag = 
		{
			564307,
		},
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id7081] =
{
	Id = 7081,
	Name = "道具掉落率+",
	Desc = "道具掉落率 +{Value}%",
	EffectModule = EffectModule.ExploreDrop,
	EffectRange = {
		EffectScope = EffectScope.Team,
		Characters = 
		{
			223105,
		},
	},
	Effect = {
		EffectAttribute = "GoodsDropChance",
		Tag = 
		{
			564305,
		},
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id7082] =
{
	Id = 7082,
	Name = "探索金币+",
	Desc = "探索金币数量 +{Value}%",
	EffectModule = EffectModule.ExploreDrop,
	EffectRange = {
		EffectScope = EffectScope.Team,
	},
	Effect = {
		EffectAttribute = "GoodsDropNumber",
		EffectValue = 1,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id7083] =
{
	Id = 7083,
	Name = "海洋星敌人掉落概率+",
	Desc = "海洋星敌人道具掉落率 +{Value}%",
	EffectModule = EffectModule.ExploreDrop,
	EffectRange = {
		EffectScope = EffectScope.Team,
		Characters = 
		{
			220426,
		},
	},
	Effect = {
		EffectAttribute = "EnemyDropChance",
		Tag = 
		{
			560107,
		},
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id7084] =
{
	Id = 7084,
	Name = "海洋星的敌人捕捉率+",
	Desc = "海洋星敌人捕捉成功率 +{Value}%",
	EffectModule = EffectModule.ExploreCatch,
	EffectRange = {
		EffectScope = EffectScope.Team,
		Characters = 
		{
			220426,
		},
	},
	Effect = {
		EffectAttribute = "PetCatchSuccessChance",
		Tag = 
		{
			560107,
		},
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id7085] =
{
	Id = 7085,
	Name = "每3回合全队恢复",
	Desc = "每3回合全队回血 {Value}，最多3次",
	EffectModule = EffectModule.Battle,
	BattleParameter = {
		StartRound = 3,
		IntervalRound = 3,
		Limited = 3,
	},
	EffectRange = {
		EffectScope = EffectScope.Team,
	},
	Effect = {
		EffectAttribute = "Recovery",
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id7086] =
{
	Id = 7086,
	Name = "每回合全队暴击+",
	Desc = "每回合全队暴击 +{Value}，最多5次",
	EffectModule = EffectModule.Battle,
	BattleParameter = {
		StartRound = 1,
		IntervalRound = 1,
		Limited = 5,
	},
	EffectRange = {
		EffectScope = EffectScope.Team,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200004,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id7087] =
{
	Id = 7087,
	Name = "每回合全队忍耐+",
	Desc = "每回合全队忍耐 +{Value}，最多5次",
	EffectModule = EffectModule.Battle,
	BattleParameter = {
		StartRound = 1,
		IntervalRound = 1,
		Limited = 5,
	},
	EffectRange = {
		EffectScope = EffectScope.Team,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200003,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id7088] =
{
	Id = 7088,
	Name = "敌人捕捉率+",
	Desc = "敌人捕捉成功率 +{Value}%",
	EffectModule = EffectModule.ExploreCatch,
	EffectRange = {
		EffectScope = EffectScope.Team,
		Characters = 
		{
			220409,
		},
	},
	Effect = {
		EffectAttribute = "PetCatchSuccessChance",
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id7089] =
{
	Id = 7089,
	Name = "躲避强敌",
	Desc = "打不过的怪物出现概率 -{Value}%",
	EffectModule = EffectModule.ExploreEnemy,
	EffectRange = {
		EffectScope = EffectScope.Team,
		Characters = 
		{
			220412,
		},
	},
	Effect = {
		EffectAttribute = "EnemyWeight",
		Chance = 100,
		CompareFightPower = 1,
		EnemyWeightCondition = {
			CompareWin = 2,
		},
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id7090] =
{
	Id = 7090,
	Name = "探索金币+",
	Desc = "探索金币数量 +{Value}%",
	EffectModule = EffectModule.ExploreDrop,
	EffectRange = {
		EffectScope = EffectScope.Team,
		Characters = 
		{
			220412,
		},
	},
	Effect = {
		EffectAttribute = "GoodsDropNumber",
		EffectValue = 1,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id7091] =
{
	Id = 7091,
	Name = "全队技巧+",
	Desc = "全队技巧 +{Value}",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Team,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200005,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id7092] =
{
	Id = 7092,
	Name = "全队亲和+",
	Desc = "全队亲和 +{Value}",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Team,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200006,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id7093] =
{
	Id = 7093,
	Name = "全队力气+",
	Desc = "全队力气 +{Value}",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Team,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200007,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id7094] =
{
	Id = 7094,
	Name = "全队智力+",
	Desc = "全队智力 +{Value}",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Team,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200008,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id7095] =
{
	Id = 7095,
	Name = "躲避强敌",
	Desc = "打不过的怪物出现概率 -{Value}%",
	EffectModule = EffectModule.ExploreEnemy,
	EffectRange = {
		EffectScope = EffectScope.Team,
		Characters = 
		{
			220406,
		},
	},
	Effect = {
		EffectAttribute = "EnemyWeight",
		Chance = 100,
		CompareFightPower = 1,
		EnemyWeightCondition = {
			CompareWin = 2,
		},
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id7096] =
{
	Id = 7096,
	Name = "道具掉落率+",
	Desc = "道具掉落率 +{Value}%",
	EffectModule = EffectModule.ExploreDrop,
	EffectRange = {
		EffectScope = EffectScope.Team,
		Characters = 
		{
			220415,
		},
	},
	Effect = {
		EffectAttribute = "GoodsDropChance",
		Tag = 
		{
			564305,
		},
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id7097] =
{
	Id = 7097,
	Name = "每3回合全队受击恢复",
	Desc = "每3回合全队每次受击回血 {Value}，最多3次",
	EffectModule = EffectModule.Battle,
	BattleParameter = {
		StartRound = 3,
		IntervalRound = 3,
		Limited = 3,
	},
	EffectRange = {
		EffectScope = EffectScope.Team,
	},
	Effect = {
		EffectAttribute = "RecoveryWithHurt",
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id7098] =
{
	Id = 7098,
	Name = "探索时间+",
	Desc = "探索等待时间 -{Value}%",
	EffectModule = EffectModule.ExploreTime,
	EffectRange = {
		EffectScope = EffectScope.Team,
		Characters = 
		{
			223125,
		},
	},
	Effect = {
		EffectAttribute = "ExploreTime",
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id7099] =
{
	Id = 7099,
	Name = "躲避强敌",
	Desc = "打不过的怪物出现概率 -{Value}%",
	EffectModule = EffectModule.ExploreEnemy,
	EffectRange = {
		EffectScope = EffectScope.Team,
		Characters = 
		{
			223125,
		},
	},
	Effect = {
		EffectAttribute = "EnemyWeight",
		Chance = 100,
		EnemyWeightCondition = {
			CompareWin = 2,
		},
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id7100] =
{
	Id = 7100,
	Name = "探索时间+",
	Desc = "探索等待时间 -{Value}%",
	EffectModule = EffectModule.ExploreTime,
	EffectRange = {
		EffectScope = EffectScope.Team,
		Characters = 
		{
			220001,
		},
	},
	Effect = {
		EffectAttribute = "ExploreTime",
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id7101] =
{
	Id = 7101,
	Name = "打工食物+",
	Desc = "打工食物数量 +{Value}%",
	EffectModule = EffectModule.WorkShop,
	EffectRange = {
		EffectScope = EffectScope.Team,
		Characters = 
		{
			223130,
		},
	},
	Effect = {
		EffectAttribute = "WorkShopGoodsNumber",
		Tag = 
		{
			564306,
		},
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id7102] =
{
	Id = 7102,
	Name = "活动探索中，紫色品质及以下敌人捕捉率+",
	Desc = "活动探索中，紫色品质敌人捕捉率 +{Value}%",
	EffectModule = EffectModule.ExploreCatch,
	EffectRange = {
		EffectScope = EffectScope.Team,
		Characters = 
		{
			220009,
		},
	},
	Effect = {
		EffectAttribute = "PetCatchSuccessChance",
		Tag = 
		{
			564553,
			560024,
		},
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id7103] =
{
	Id = 7103,
	Name = "探索时间+",
	Desc = "探索等待时间 -{Value}%",
	EffectModule = EffectModule.ExploreTime,
	EffectRange = {
		EffectScope = EffectScope.Team,
		Characters = 
		{
			220001,
		},
	},
	Effect = {
		EffectAttribute = "ExploreTime",
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id7104] =
{
	Id = 7104,
	Name = "打工金币+",
	Desc = "思诺曼打工获得金币+{Value}%",
	EffectModule = EffectModule.WorkShop,
	EffectRange = {
		EffectScope = EffectScope.Team,
		Characters = 
		{
			223148,
		},
	},
	Effect = {
		EffectAttribute = "WorkShopGoodsNumber",
		EffectValue = 1,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id7105] =
{
	Id = 7105,
	Name = "全队水元素队员亲和+",
	Desc = "水元素队员亲和 +{Value}%",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Team,
		Element = 210001,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200006,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id7106] =
{
	Id = 7106,
	Name = "前三队员偶数回合恢复+",
	Desc = "每2回合，队伍前3位的队员回血{Value}，最多3次",
	EffectModule = EffectModule.Battle,
	BattleParameter = {
		StartRound = 2,
		IntervalRound = 2,
		Limited = 3,
	},
	EffectRange = {
		EffectScope = EffectScope.FixPosition,
		PositionValue = 
		{
			1,2,3,
		},
	},
	Effect = {
		EffectAttribute = "Recovery",
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id7107] =
{
	Id = 7107,
	Name = "后三队员奇数回合攻击+",
	Desc = "第1、3、5回合，队伍后3位的队员攻击 +{Value}",
	EffectModule = EffectModule.Battle,
	BattleParameter = {
		StartRound = 1,
		IntervalRound = 2,
		Limited = 3,
	},
	EffectRange = {
		EffectScope = EffectScope.FixPosition,
		PositionValue = 
		{
			-1,-2,-3,
		},
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200002,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
