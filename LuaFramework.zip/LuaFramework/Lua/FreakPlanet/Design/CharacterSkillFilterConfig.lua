CharacterSkillFilterConfig = {}
--------------------------------------------------------------
CharacterSkillFilterConfig["ExploreTime"] = {
    Name = "探索时间",
    EffectAttributes = {"ExploreTime"},
}

CharacterSkillFilterConfig["EnemyDropChance"] = {
    Name = "敌人掉落概率",
    EffectAttributes = {"EnemyDropChance"},
}

CharacterSkillFilterConfig["GoodsDropChance"] = {
    Name = "道具掉落概率",
    EffectAttributes = {"GoodsDropChance"},
}

CharacterSkillFilterConfig["GoodsDropNumber"] = {
    Name = "金币掉落数量",
    EffectAttributes = {"GoodsDropNumber"},
}

CharacterSkillFilterConfig["ExploreGetGoods"] = {
    Name = "探索获得道具",
    EffectAttributes = {"ExploreGetGoods"},
}

CharacterSkillFilterConfig["EnemyWeight"] = {
    Name = "敌人出现权重",
    EffectAttributes = {"EnemyWeight"},
}

CharacterSkillFilterConfig["EnemyFightPower"] = {
    Name = "敌人战力",
    EffectAttributes = {"EnemyFightPower"},
}

CharacterSkillFilterConfig["FightPower"] = {
    Name = "队伍战力",
    EffectAttributes = {"FightPower"},
}

CharacterSkillFilterConfig["ExploreAbility"] = {
    Name = "能力",
    EffectAttributes = {"Ability"},
}

CharacterSkillFilterConfig["PetCatchSuccessChance"] = {
    Name = "宠物捕捉概率",
    EffectAttributes = {"PetCatchSuccessChance"},
}

CharacterSkillFilterConfig["GoodsCatchSuccessChance"] = {
    Name = "道具捕捉概率",
    EffectAttributes = {"GoodsCatchSuccessChance"},
}
--------------------------------------------------------------
CharacterSkillFilterConfig["ChallengeAbility"] = {
    Name = "能力提升",
    EffectAttributes = {"Ability"},
}
CharacterSkillFilterConfig["AttributeWithHurt"] = {
    Name = "受击能力提升",
    EffectAttributes = {"AttributeWithHurt"},
}
CharacterSkillFilterConfig["CritChance"] = {
    Name = "暴率",
    EffectAttributes = {"CritChance", "CritChanceOnce"},
}
CharacterSkillFilterConfig["CritDamage"] = {
    Name = "暴伤",
    EffectAttributes = {"CritDamage", "CritDamageOnce"},
}
CharacterSkillFilterConfig["ExtraAttack"] = {
    Name = "连击",
    EffectAttributes = {"ExtraAttack", "ExtraAttackOnce"},
}
CharacterSkillFilterConfig["DodgeIgnore"] = {
    Name = "无视闪避",
    EffectAttributes = {"DodgeIgnore", "DodgeIgnoreOnce"},
}
CharacterSkillFilterConfig["HpAttackOnce"] = {
    Name = "舍命攻击",
    EffectAttributes = {"HpAttackOnce"},
}
CharacterSkillFilterConfig["DefendIgnoreOnce"] = {
    Name = "破甲攻击",
    EffectAttributes = {"DefendIgnoreOnce"},
}
CharacterSkillFilterConfig["DamageFromCritDamage"] = {
    Name = "受到暴伤",
    EffectAttributes = {"DamageFromCritDamage", "DamageFromCritDamageOnce"},
}
CharacterSkillFilterConfig["Dodge"] = {
    Name = "闪避",
    EffectAttributes = {"Dodge", "DodgeOnce"},
}
CharacterSkillFilterConfig["DamageToElement"] = {
    Name = "对元素伤害",
    EffectAttributes = {"DamageToElement"},
}
CharacterSkillFilterConfig["DamageFromElement"] = {
    Name = "受元素伤害",
    EffectAttributes = {"DamageFromElement"},
}
CharacterSkillFilterConfig["Recovery"] = {
    Name = "恢复",
    EffectAttributes = {"Recovery", "RecoveryWithAtk "},
}
CharacterSkillFilterConfig["RecoveryWithHurt"] = {
    Name = "受击恢复",
    EffectAttributes = {"RecoveryWithHurt"},
}
CharacterSkillFilterConfig["EnemyLevel"] = {
    Name = "敌人等级削弱",
    EffectAttributes = {"EnemyLevel"},
}
CharacterSkillFilterConfig["EnemyAbility"] = {
    Name = "敌人能力削弱",
    EffectAttributes = {"EnemyAbility", "SpecificEnemyAbility"},
}
--------------------------------------------------------------
CharacterSkillFilterConfig["WorkShopAbility"] = {
    Name = "打工能力",
    EffectAttributes = {"Ability"},
}
CharacterSkillFilterConfig["WorkShopGoodsNumber"] = {
    Name = "打工获得道具",
    EffectAttributes = {"WorkShopGoodsNumber"},
}
CharacterSkillFilterConfig["WorkShopGoldNumber"] = {
    Name = "打工获得金币",
    EffectAttributes = {"WorkShopGoodsNumber"},
}
CharacterSkillFilterConfig["WorkShopMaxWorkTime"] = {
    Name = "打工最大工时",
    EffectAttributes = {"WorkShopMaxWorkTime"},
}