
DemandConfig[DemandID.Id301] =
{
	Id = 301,
	Name = "星球图集",
	Desc = "有更多地图就可以做星球图集了~~",
	Value = 321005,
	Active = true,
	Weight = 3675,
	PreGoal = 
	{
		300058,
		300486,
	},
	CloseGoal = 
	{
		300836,
	},
	GoodsId = 3101005,
	Priority = 1005160,
	Num = 36,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 5987,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 29,
				},
				{
					Value = 1,
					Num = 3087,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 29,
				},
				{
					Value = 1,
					Num = 3087,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 5,
				},
				{
					Value = 1,
					Num = 3487,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 5,
				},
				{
					Value = 1,
					Num = 3487,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 1,
				},
				{
					Value = 1,
					Num = 3487,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 1,
				},
				{
					Value = 1,
					Num = 3487,
				},
			},
		},
	},
	DemandID = 410301,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id302] =
{
	Id = 302,
	Name = "制作地图集",
	Desc = "上次制作的地图集卖了个好价钱~",
	Value = 321006,
	Active = true,
	Weight = 980,
	PreGoal = 
	{
		300055,
	},
	CloseGoal = 
	{
		300080,
	},
	GoodsId = 3211006,
	Priority = 1006141,
	Num = 6,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 1233,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 10,
				},
				{
					Value = 1,
					Num = 233,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 10,
				},
				{
					Value = 1,
					Num = 233,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 2,
				},
				{
					Value = 1,
					Num = 233,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 2,
				},
				{
					Value = 1,
					Num = 233,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 7,
				},
				{
					Value = 320051,
					Num = 5,
				},
			},
		},
	},
	DemandID = 410302,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id303] =
{
	Id = 303,
	Name = "小广告",
	Desc = "打算贴点小广告，缺少胶水…",
	Value = 321006,
	Active = true,
	Weight = 1120,
	PreGoal = 
	{
		300055,
		300062,
	},
	CloseGoal = 
	{
		300087,
	},
	GoodsId = 3221006,
	Priority = 1006142,
	Num = 8,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 1645,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 13,
				},
				{
					Value = 1,
					Num = 345,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 13,
				},
				{
					Value = 1,
					Num = 345,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 2,
				},
				{
					Value = 1,
					Num = 645,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 2,
				},
				{
					Value = 1,
					Num = 645,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 9,
				},
				{
					Value = 320051,
					Num = 7,
				},
			},
		},
	},
	DemandID = 410303,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id304] =
{
	Id = 304,
	Name = "修理工委托",
	Desc = "工具箱里没有强力胶成何体统？",
	Value = 321006,
	Active = true,
	Weight = 1260,
	PreGoal = 
	{
		300055,
		300069,
	},
	CloseGoal = 
	{
		300102,
	},
	GoodsId = 3231006,
	Priority = 1006143,
	Num = 9,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 1850,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 15,
				},
				{
					Value = 1,
					Num = 350,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 15,
				},
				{
					Value = 1,
					Num = 350,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 3,
				},
				{
					Value = 1,
					Num = 350,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 3,
				},
				{
					Value = 1,
					Num = 350,
				},
			},
		},
	},
	DemandID = 410304,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id305] =
{
	Id = 305,
	Name = "胶水店委托",
	Desc = "需要优质的原料制作强力胶。",
	Value = 321006,
	Active = true,
	Weight = 1470,
	PreGoal = 
	{
		300055,
		300080,
	},
	CloseGoal = 
	{
		300410,
	},
	GoodsId = 3241006,
	Priority = 1006144,
	Num = 12,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 2467,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 20,
				},
				{
					Value = 1,
					Num = 467,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 20,
				},
				{
					Value = 1,
					Num = 467,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 4,
				},
				{
					Value = 1,
					Num = 467,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 4,
				},
				{
					Value = 1,
					Num = 467,
				},
			},
		},
	},
	DemandID = 410305,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id306] =
{
	Id = 306,
	Name = "修复飞船",
	Desc = "飞船裂开了，用这个沾起来还能用吗？",
	Value = 321006,
	Active = true,
	Weight = 1680,
	PreGoal = 
	{
		300055,
		300091,
	},
	CloseGoal = 
	{
		300424,
	},
	GoodsId = 3251006,
	Priority = 1006145,
	Num = 18,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 3701,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 31,
				},
				{
					Value = 1,
					Num = 601,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 31,
				},
				{
					Value = 1,
					Num = 601,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 6,
				},
				{
					Value = 1,
					Num = 701,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 6,
				},
				{
					Value = 1,
					Num = 701,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 1,
				},
				{
					Value = 1,
					Num = 1201,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 1,
				},
				{
					Value = 1,
					Num = 1201,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 22,
				},
				{
					Value = 320051,
					Num = 15,
				},
			},
		},
	},
	DemandID = 410306,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id307] =
{
	Id = 307,
	Name = "制作地图集",
	Desc = "上次制作的地图集卖了个好价钱~",
	Value = 321006,
	Active = true,
	Weight = 1960,
	PreGoal = 
	{
		300055,
		300406,
	},
	CloseGoal = 
	{
		300439,
	},
	GoodsId = 3201006,
	Priority = 1006146,
	Num = 25,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 5141,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 43,
				},
				{
					Value = 1,
					Num = 841,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 43,
				},
				{
					Value = 1,
					Num = 841,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 8,
				},
				{
					Value = 1,
					Num = 1141,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 8,
				},
				{
					Value = 1,
					Num = 1141,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 1,
				},
				{
					Value = 1,
					Num = 2641,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 1,
				},
				{
					Value = 1,
					Num = 2641,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 30,
				},
				{
					Value = 320051,
					Num = 21,
				},
			},
		},
	},
	DemandID = 410307,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id308] =
{
	Id = 308,
	Name = "小广告",
	Desc = "打算贴点小广告，缺少胶水…",
	Value = 321006,
	Active = true,
	Weight = 2240,
	PreGoal = 
	{
		300055,
		300421,
	},
	CloseGoal = 
	{
		300458,
	},
	GoodsId = 3201006,
	Priority = 1006147,
	Num = 25,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 5141,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 43,
				},
				{
					Value = 1,
					Num = 841,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 43,
				},
				{
					Value = 1,
					Num = 841,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 8,
				},
				{
					Value = 1,
					Num = 1141,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 8,
				},
				{
					Value = 1,
					Num = 1141,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 1,
				},
				{
					Value = 1,
					Num = 2641,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 1,
				},
				{
					Value = 1,
					Num = 2641,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 30,
				},
				{
					Value = 320051,
					Num = 21,
				},
			},
		},
	},
	DemandID = 410308,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id309] =
{
	Id = 309,
	Name = "修理工委托",
	Desc = "工具箱里没有强力胶成何体统？",
	Value = 321006,
	Active = true,
	Weight = 2590,
	PreGoal = 
	{
		300055,
		300439,
	},
	CloseGoal = 
	{
		300478,
	},
	GoodsId = 3201006,
	Priority = 1006148,
	Num = 28,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 5758,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 48,
				},
				{
					Value = 1,
					Num = 958,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 48,
				},
				{
					Value = 1,
					Num = 958,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 9,
				},
				{
					Value = 1,
					Num = 1258,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 9,
				},
				{
					Value = 1,
					Num = 1258,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 1,
				},
				{
					Value = 1,
					Num = 3258,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 1,
				},
				{
					Value = 1,
					Num = 3258,
				},
			},
		},
	},
	DemandID = 410309,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id310] =
{
	Id = 310,
	Name = "胶水店委托",
	Desc = "需要优质的原料制作强力胶。",
	Value = 321006,
	Active = true,
	Weight = 2940,
	PreGoal = 
	{
		300055,
		300458,
	},
	CloseGoal = 
	{
		300804,
	},
	GoodsId = 3201006,
	Priority = 1006149,
	Num = 30,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 6169,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 52,
				},
				{
					Value = 1,
					Num = 969,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 52,
				},
				{
					Value = 1,
					Num = 969,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 10,
				},
				{
					Value = 1,
					Num = 1169,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 10,
				},
				{
					Value = 1,
					Num = 1169,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 2,
				},
				{
					Value = 1,
					Num = 1169,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 2,
				},
				{
					Value = 1,
					Num = 1169,
				},
			},
		},
	},
	DemandID = 410310,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id311] =
{
	Id = 311,
	Name = "修复飞船",
	Desc = "飞船裂开了，用这个沾起来还能用吗？",
	Value = 321006,
	Active = true,
	Weight = 3360,
	PreGoal = 
	{
		300055,
		300482,
	},
	CloseGoal = 
	{
		300832,
	},
	GoodsId = 3201006,
	Priority = 1006150,
	Num = 33,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 6786,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 57,
				},
				{
					Value = 1,
					Num = 1086,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 57,
				},
				{
					Value = 1,
					Num = 1086,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 11,
				},
				{
					Value = 1,
					Num = 1286,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 11,
				},
				{
					Value = 1,
					Num = 1286,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 2,
				},
				{
					Value = 1,
					Num = 1786,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 2,
				},
				{
					Value = 1,
					Num = 1786,
				},
			},
		},
	},
	DemandID = 410311,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id312] =
{
	Id = 312,
	Name = "标本制作",
	Desc = "需要一些尖刺来制作野兽标本。",
	Value = 321007,
	Active = true,
	Weight = 1125,
	PreGoal = 
	{
		300304,
		300058,
	},
	CloseGoal = 
	{
		300084,
	},
	GoodsId = 3311007,
	Priority = 1007151,
	Num = 21,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 4777,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 40,
				},
				{
					Value = 1,
					Num = 777,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 38,
				},
				{
					Value = 1,
					Num = 977,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 8,
				},
				{
					Value = 1,
					Num = 777,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 7,
				},
				{
					Value = 1,
					Num = 1277,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 1,
				},
				{
					Value = 1,
					Num = 2277,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 1,
				},
				{
					Value = 1,
					Num = 2277,
				},
			},
		},
	},
	DemandID = 410312,
	DemandGroupList = {
		420002,
		420004,
		420005,
		420006,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id313] =
{
	Id = 313,
	Name = "标本制作",
	Desc = "需要一些尖刺来制作野兽标本。",
	Value = 321007,
	Active = true,
	Weight = 1275,
	PreGoal = 
	{
		300304,
		300066,
	},
	CloseGoal = 
	{
		300091,
	},
	GoodsId = 3321007,
	Priority = 1007152,
	Num = 27,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 6142,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 52,
				},
				{
					Value = 1,
					Num = 942,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 49,
				},
				{
					Value = 1,
					Num = 1242,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 10,
				},
				{
					Value = 1,
					Num = 1142,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 9,
				},
				{
					Value = 1,
					Num = 1642,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 2,
				},
				{
					Value = 1,
					Num = 1142,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 1,
				},
				{
					Value = 1,
					Num = 3642,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 51,
				},
				{
					Value = 320051,
					Num = 10,
				},
			},
		},
	},
	DemandID = 410313,
	DemandGroupList = {
		420002,
		420004,
		420005,
		420006,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id314] =
{
	Id = 314,
	Name = "标本制作",
	Desc = "需要一些尖刺来制作野兽标本。",
	Value = 321007,
	Active = true,
	Weight = 1425,
	PreGoal = 
	{
		300304,
		300072,
	},
	CloseGoal = 
	{
		300403,
	},
	GoodsId = 3331007,
	Priority = 1007153,
	Num = 32,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 7280,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 62,
				},
				{
					Value = 1,
					Num = 1080,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 58,
				},
				{
					Value = 1,
					Num = 1480,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 12,
				},
				{
					Value = 1,
					Num = 1280,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 11,
				},
				{
					Value = 1,
					Num = 1780,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 2,
				},
				{
					Value = 1,
					Num = 2280,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 2,
				},
				{
					Value = 1,
					Num = 2280,
				},
			},
		},
	},
	DemandID = 410314,
	DemandGroupList = {
		420002,
		420004,
		420005,
		420006,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id315] =
{
	Id = 315,
	Name = "扎气球大赛",
	Desc = "上次比赛准备不足，这次一定会全力以赴地准备物料！",
	Value = 321007,
	Active = true,
	Weight = 1650,
	PreGoal = 
	{
		300304,
		300084,
	},
	CloseGoal = 
	{
		300413,
	},
	GoodsId = 3341007,
	Priority = 1007154,
	Num = 44,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 10010,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 85,
				},
				{
					Value = 1,
					Num = 1510,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 80,
				},
				{
					Value = 1,
					Num = 2010,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 17,
				},
				{
					Value = 1,
					Num = 1510,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 16,
				},
				{
					Value = 1,
					Num = 2010,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 3,
				},
				{
					Value = 1,
					Num = 2510,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 3,
				},
				{
					Value = 1,
					Num = 2510,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 84,
				},
				{
					Value = 320051,
					Num = 16,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 16,
				},
				{
					Value = 320052,
					Num = 4,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 3,
				},
				{
					Value = 320053,
					Num = 1,
				},
			},
		},
	},
	DemandID = 410315,
	DemandGroupList = {
		420002,
		420004,
		420005,
		420006,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id316] =
{
	Id = 316,
	Name = "扎气球大赛",
	Desc = "上次比赛准备不足，这次一定会全力以赴地准备物料！",
	Value = 321007,
	Active = true,
	Weight = 1875,
	PreGoal = 
	{
		300304,
		300096,
	},
	CloseGoal = 
	{
		300428,
	},
	GoodsId = 3351007,
	Priority = 1007155,
	Num = 57,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 12967,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 111,
				},
				{
					Value = 1,
					Num = 1867,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 103,
				},
				{
					Value = 1,
					Num = 2667,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 22,
				},
				{
					Value = 1,
					Num = 1967,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 20,
				},
				{
					Value = 1,
					Num = 2967,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 4,
				},
				{
					Value = 1,
					Num = 2967,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 4,
				},
				{
					Value = 1,
					Num = 2967,
				},
			},
		},
	},
	DemandID = 410316,
	DemandGroupList = {
		420002,
		420004,
		420005,
		420006,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id317] =
{
	Id = 317,
	Name = "扎气球大赛",
	Desc = "上次比赛准备不足，这次一定会全力以赴地准备物料！",
	Value = 321007,
	Active = true,
	Weight = 2175,
	PreGoal = 
	{
		300304,
		300410,
	},
	CloseGoal = 
	{
		300443,
	},
	GoodsId = 3301007,
	Priority = 1007156,
	Num = 74,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 16835,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 144,
				},
				{
					Value = 1,
					Num = 2435,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 134,
				},
				{
					Value = 1,
					Num = 3435,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 28,
				},
				{
					Value = 1,
					Num = 2835,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 26,
				},
				{
					Value = 1,
					Num = 3835,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 5,
				},
				{
					Value = 1,
					Num = 4335,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 5,
				},
				{
					Value = 1,
					Num = 4335,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 1,
				},
				{
					Value = 1,
					Num = 4335,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 1,
				},
				{
					Value = 1,
					Num = 4335,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 141,
				},
				{
					Value = 320051,
					Num = 27,
				},
			},
		},
	},
	DemandID = 410317,
	DemandGroupList = {
		420002,
		420004,
		420005,
		420006,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id318] =
{
	Id = 318,
	Name = "铁匠的请求",
	Desc = "接了魔族订单，要做好多狼牙棒。",
	Value = 321007,
	Active = true,
	Weight = 2475,
	PreGoal = 
	{
		300304,
		300424,
	},
	CloseGoal = 
	{
		300462,
	},
	GoodsId = 3301007,
	Priority = 1007157,
	Num = 78,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 17745,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 152,
				},
				{
					Value = 1,
					Num = 2545,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 141,
				},
				{
					Value = 1,
					Num = 3645,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 30,
				},
				{
					Value = 1,
					Num = 2745,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 28,
				},
				{
					Value = 1,
					Num = 3745,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 6,
				},
				{
					Value = 1,
					Num = 2745,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 5,
				},
				{
					Value = 1,
					Num = 5245,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 1,
				},
				{
					Value = 1,
					Num = 5245,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 1,
				},
				{
					Value = 1,
					Num = 5245,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 149,
				},
				{
					Value = 320051,
					Num = 28,
				},
			},
		},
	},
	DemandID = 410318,
	DemandGroupList = {
		420002,
		420004,
		420005,
		420006,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id319] =
{
	Id = 319,
	Name = "铁匠的请求",
	Desc = "接了魔族订单，要做好多狼牙棒。",
	Value = 321007,
	Active = true,
	Weight = 2850,
	PreGoal = 
	{
		300304,
		300443,
	},
	CloseGoal = 
	{
		300482,
	},
	GoodsId = 3301007,
	Priority = 1007158,
	Num = 86,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 19565,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 167,
				},
				{
					Value = 1,
					Num = 2865,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 156,
				},
				{
					Value = 1,
					Num = 3965,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 33,
				},
				{
					Value = 1,
					Num = 3065,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 31,
				},
				{
					Value = 1,
					Num = 4065,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 6,
				},
				{
					Value = 1,
					Num = 4565,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 6,
				},
				{
					Value = 1,
					Num = 4565,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 1,
				},
				{
					Value = 1,
					Num = 7065,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 1,
				},
				{
					Value = 1,
					Num = 7065,
				},
			},
		},
	},
	DemandID = 410319,
	DemandGroupList = {
		420002,
		420004,
		420005,
		420006,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id320] =
{
	Id = 320,
	Name = "铁匠的请求",
	Desc = "接了魔族订单，要做好多狼牙棒。",
	Value = 321007,
	Active = true,
	Weight = 3225,
	PreGoal = 
	{
		300304,
		300462,
	},
	CloseGoal = 
	{
		300810,
	},
	GoodsId = 3301007,
	Priority = 1007159,
	Num = 92,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 20930,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 179,
				},
				{
					Value = 1,
					Num = 3030,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 167,
				},
				{
					Value = 1,
					Num = 4230,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 35,
				},
				{
					Value = 1,
					Num = 3430,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 33,
				},
				{
					Value = 1,
					Num = 4430,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 7,
				},
				{
					Value = 1,
					Num = 3430,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 6,
				},
				{
					Value = 1,
					Num = 5930,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 1,
				},
				{
					Value = 1,
					Num = 8430,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 1,
				},
				{
					Value = 1,
					Num = 8430,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 175,
				},
				{
					Value = 320051,
					Num = 34,
				},
			},
		},
	},
	DemandID = 410320,
	DemandGroupList = {
		420002,
		420004,
		420005,
		420006,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id321] =
{
	Id = 321,
	Name = "铁匠的请求",
	Desc = "接了魔族订单，要做好多狼牙棒。",
	Value = 321007,
	Active = true,
	Weight = 3675,
	PreGoal = 
	{
		300304,
		300486,
	},
	CloseGoal = 
	{
		300836,
	},
	GoodsId = 3301007,
	Priority = 1007160,
	Num = 102,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 23205,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 198,
				},
				{
					Value = 1,
					Num = 3405,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 185,
				},
				{
					Value = 1,
					Num = 4705,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 39,
				},
				{
					Value = 1,
					Num = 3705,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 37,
				},
				{
					Value = 1,
					Num = 4705,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 7,
				},
				{
					Value = 1,
					Num = 5705,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 7,
				},
				{
					Value = 1,
					Num = 5705,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 1,
				},
				{
					Value = 1,
					Num = 10705,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 1,
				},
				{
					Value = 1,
					Num = 10705,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 194,
				},
				{
					Value = 320051,
					Num = 38,
				},
			},
		},
	},
	DemandID = 410321,
	DemandGroupList = {
		420002,
		420004,
		420005,
		420006,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id322] =
{
	Id = 322,
	Name = "纪念品",
	Desc = "找不到合适的星沙，用这个代替吧。",
	Value = 321008,
	Active = true,
	Weight = 1620,
	PreGoal = 
	{
		300315,
		300069,
	},
	CloseGoal = 
	{
		300096,
	},
	GoodsId = 3411008,
	Priority = 1008181,
	Num = 9,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 2416,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 12,
				},
				{
					Value = 1,
					Num = 1216,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 12,
				},
				{
					Value = 1,
					Num = 1216,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 2,
				},
				{
					Value = 1,
					Num = 1416,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 2,
				},
				{
					Value = 1,
					Num = 1416,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 14,
				},
				{
					Value = 320051,
					Num = 10,
				},
			},
		},
	},
	DemandID = 410322,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id323] =
{
	Id = 323,
	Name = "超大沙漏",
	Desc = "打算在村子里造一个大型沙漏。",
	Value = 321008,
	Active = true,
	Weight = 1800,
	PreGoal = 
	{
		300315,
		300075,
	},
	CloseGoal = 
	{
		300403,
	},
	GoodsId = 3421008,
	Priority = 1008182,
	Num = 10,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 2685,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 13,
				},
				{
					Value = 1,
					Num = 1385,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 13,
				},
				{
					Value = 1,
					Num = 1385,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 2,
				},
				{
					Value = 1,
					Num = 1685,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 2,
				},
				{
					Value = 1,
					Num = 1685,
				},
			},
		},
	},
	DemandID = 410323,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id324] =
{
	Id = 324,
	Name = "建筑工地",
	Desc = "昨天一阵风把沙子吹走了…",
	Value = 321008,
	Active = true,
	Weight = 1980,
	PreGoal = 
	{
		300315,
		300084,
	},
	CloseGoal = 
	{
		300413,
	},
	GoodsId = 3431008,
	Priority = 1008183,
	Num = 14,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 3759,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 18,
				},
				{
					Value = 1,
					Num = 1959,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 18,
				},
				{
					Value = 1,
					Num = 1959,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 3,
				},
				{
					Value = 1,
					Num = 2259,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 3,
				},
				{
					Value = 1,
					Num = 2259,
				},
			},
		},
	},
	DemandID = 410324,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id325] =
{
	Id = 325,
	Name = "沙滩翻新",
	Desc = "为迎接新游客，需要翻新沙滩。",
	Value = 321008,
	Active = true,
	Weight = 2250,
	PreGoal = 
	{
		300315,
		300096,
	},
	CloseGoal = 
	{
		300424,
	},
	GoodsId = 3441008,
	Priority = 1008184,
	Num = 18,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 4833,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 24,
				},
				{
					Value = 1,
					Num = 2433,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 24,
				},
				{
					Value = 1,
					Num = 2433,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 4,
				},
				{
					Value = 1,
					Num = 2833,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 4,
				},
				{
					Value = 1,
					Num = 2833,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 29,
				},
				{
					Value = 320051,
					Num = 19,
				},
			},
		},
	},
	DemandID = 410325,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id326] =
{
	Id = 326,
	Name = "纪念品",
	Desc = "找不到合适的星沙，用这个代替吧。",
	Value = 321008,
	Active = true,
	Weight = 2520,
	PreGoal = 
	{
		300315,
		300406,
	},
	CloseGoal = 
	{
		300439,
	},
	GoodsId = 3401008,
	Priority = 1008185,
	Num = 22,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 5907,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 29,
				},
				{
					Value = 1,
					Num = 3007,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 29,
				},
				{
					Value = 1,
					Num = 3007,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 5,
				},
				{
					Value = 1,
					Num = 3407,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 5,
				},
				{
					Value = 1,
					Num = 3407,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 1,
				},
				{
					Value = 1,
					Num = 3407,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 1,
				},
				{
					Value = 1,
					Num = 3407,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 35,
				},
				{
					Value = 320051,
					Num = 24,
				},
			},
		},
	},
	DemandID = 410326,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id327] =
{
	Id = 327,
	Name = "超大沙漏",
	Desc = "打算在村子里造一个大型沙漏。",
	Value = 321008,
	Active = true,
	Weight = 2880,
	PreGoal = 
	{
		300315,
		300421,
	},
	CloseGoal = 
	{
		300454,
	},
	GoodsId = 3401008,
	Priority = 1008186,
	Num = 22,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 5907,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 29,
				},
				{
					Value = 1,
					Num = 3007,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 29,
				},
				{
					Value = 1,
					Num = 3007,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 5,
				},
				{
					Value = 1,
					Num = 3407,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 5,
				},
				{
					Value = 1,
					Num = 3407,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 1,
				},
				{
					Value = 1,
					Num = 3407,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 1,
				},
				{
					Value = 1,
					Num = 3407,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 35,
				},
				{
					Value = 320051,
					Num = 24,
				},
			},
		},
	},
	DemandID = 410327,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id328] =
{
	Id = 328,
	Name = "建筑工地",
	Desc = "昨天一阵风把沙子吹走了…",
	Value = 321008,
	Active = true,
	Weight = 3240,
	PreGoal = 
	{
		300315,
		300436,
	},
	CloseGoal = 
	{
		300474,
	},
	GoodsId = 3401008,
	Priority = 1008187,
	Num = 26,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 6981,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 34,
				},
				{
					Value = 1,
					Num = 3581,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 34,
				},
				{
					Value = 1,
					Num = 3581,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 6,
				},
				{
					Value = 1,
					Num = 3981,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 6,
				},
				{
					Value = 1,
					Num = 3981,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 1,
				},
				{
					Value = 1,
					Num = 4481,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 1,
				},
				{
					Value = 1,
					Num = 4481,
				},
			},
		},
	},
	DemandID = 410328,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id329] =
{
	Id = 329,
	Name = "沙滩翻新",
	Desc = "为迎接新游客，需要翻新沙滩。",
	Value = 321008,
	Active = true,
	Weight = 3690,
	PreGoal = 
	{
		300315,
		300454,
	},
	CloseGoal = 
	{
		300494,
	},
	GoodsId = 3401008,
	Priority = 1008188,
	Num = 27,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 7250,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 36,
				},
				{
					Value = 1,
					Num = 3650,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 36,
				},
				{
					Value = 1,
					Num = 3650,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 7,
				},
				{
					Value = 1,
					Num = 3750,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 7,
				},
				{
					Value = 1,
					Num = 3750,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 1,
				},
				{
					Value = 1,
					Num = 4750,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 1,
				},
				{
					Value = 1,
					Num = 4750,
				},
			},
		},
	},
	DemandID = 410329,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id330] =
{
	Id = 330,
	Name = "建筑工地",
	Desc = "昨天一阵风把沙子吹走了…",
	Value = 321008,
	Active = true,
	Weight = 4140,
	PreGoal = 
	{
		300315,
		300474,
	},
	CloseGoal = 
	{
		300823,
	},
	GoodsId = 3401008,
	Priority = 1008189,
	Num = 30,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 8055,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 40,
				},
				{
					Value = 1,
					Num = 4055,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 40,
				},
				{
					Value = 1,
					Num = 4055,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 8,
				},
				{
					Value = 1,
					Num = 4055,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 8,
				},
				{
					Value = 1,
					Num = 4055,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 1,
				},
				{
					Value = 1,
					Num = 5555,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 1,
				},
				{
					Value = 1,
					Num = 5555,
				},
			},
		},
	},
	DemandID = 410330,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id331] =
{
	Id = 331,
	Name = "沙滩翻新",
	Desc = "为迎接新游客，需要翻新沙滩。",
	Value = 321008,
	Active = true,
	Weight = 4680,
	PreGoal = 
	{
		300315,
		300499,
	},
	CloseGoal = 
	{
		300848,
	},
	GoodsId = 3401008,
	Priority = 1008190,
	Num = 33,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 8861,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 44,
				},
				{
					Value = 1,
					Num = 4461,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 44,
				},
				{
					Value = 1,
					Num = 4461,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 8,
				},
				{
					Value = 1,
					Num = 4861,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 8,
				},
				{
					Value = 1,
					Num = 4861,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 1,
				},
				{
					Value = 1,
					Num = 6361,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 1,
				},
				{
					Value = 1,
					Num = 6361,
				},
			},
		},
	},
	DemandID = 410331,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id332] =
{
	Id = 332,
	Name = "危险魔术",
	Desc = "老是丢保龄球瓶也挺无聊的…",
	Value = 321009,
	Active = true,
	Weight = 2645,
	PreGoal = 
	{
		300087,
	},
	CloseGoal = 
	{
		300413,
	},
	GoodsId = 3511009,
	Priority = 1009231,
	Num = 15,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 4174,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 34,
				},
				{
					Value = 1,
					Num = 774,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 34,
				},
				{
					Value = 1,
					Num = 774,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 6,
				},
				{
					Value = 1,
					Num = 1174,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 6,
				},
				{
					Value = 1,
					Num = 1174,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 1,
				},
				{
					Value = 1,
					Num = 1674,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 1,
				},
				{
					Value = 1,
					Num = 1674,
				},
			},
		},
	},
	DemandID = 410332,
	DemandGroupList = {
		420002,
		420004,
		420005,
		420006,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id333] =
{
	Id = 333,
	Name = "燃烧的矿石",
	Desc = "北方的居民需要热乎乎的矿石。",
	Value = 321009,
	Active = true,
	Weight = 2875,
	PreGoal = 
	{
		300087,
		300096,
	},
	CloseGoal = 
	{
		300421,
	},
	GoodsId = 3521009,
	Priority = 1009232,
	Num = 18,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 5009,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 41,
				},
				{
					Value = 1,
					Num = 909,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 41,
				},
				{
					Value = 1,
					Num = 909,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 8,
				},
				{
					Value = 1,
					Num = 1009,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 8,
				},
				{
					Value = 1,
					Num = 1009,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 1,
				},
				{
					Value = 1,
					Num = 2509,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 1,
				},
				{
					Value = 1,
					Num = 2509,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 30,
				},
				{
					Value = 320051,
					Num = 20,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 6,
				},
				{
					Value = 320052,
					Num = 4,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 1,
				},
				{
					Value = 320053,
					Num = 1,
				},
			},
		},
	},
	DemandID = 410333,
	DemandGroupList = {
		420002,
		420004,
		420005,
		420006,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id334] =
{
	Id = 334,
	Name = "新能源",
	Desc = "打算用炭石作为新能源。",
	Value = 321009,
	Active = true,
	Weight = 3105,
	PreGoal = 
	{
		300087,
		300403,
	},
	CloseGoal = 
	{
		300431,
	},
	GoodsId = 3531009,
	Priority = 1009233,
	Num = 22,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 6123,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 51,
				},
				{
					Value = 1,
					Num = 1023,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 51,
				},
				{
					Value = 1,
					Num = 1023,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 10,
				},
				{
					Value = 1,
					Num = 1123,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 10,
				},
				{
					Value = 1,
					Num = 1123,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 2,
				},
				{
					Value = 1,
					Num = 1123,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 2,
				},
				{
					Value = 1,
					Num = 1123,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 36,
				},
				{
					Value = 320051,
					Num = 25,
				},
			},
		},
	},
	DemandID = 410334,
	DemandGroupList = {
		420002,
		420004,
		420005,
		420006,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id335] =
{
	Id = 335,
	Name = "危险魔术",
	Desc = "老是丢保龄球瓶也挺无聊的…",
	Value = 321009,
	Active = true,
	Weight = 3450,
	PreGoal = 
	{
		300087,
		300413,
	},
	CloseGoal = 
	{
		300443,
	},
	GoodsId = 3501009,
	Priority = 1009234,
	Num = 22,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 6123,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 51,
				},
				{
					Value = 1,
					Num = 1023,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 51,
				},
				{
					Value = 1,
					Num = 1023,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 10,
				},
				{
					Value = 1,
					Num = 1123,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 10,
				},
				{
					Value = 1,
					Num = 1123,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 2,
				},
				{
					Value = 1,
					Num = 1123,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 2,
				},
				{
					Value = 1,
					Num = 1123,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 36,
				},
				{
					Value = 320051,
					Num = 25,
				},
			},
		},
	},
	DemandID = 410335,
	DemandGroupList = {
		420002,
		420004,
		420005,
		420006,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id336] =
{
	Id = 336,
	Name = "燃烧的矿石",
	Desc = "北方的居民需要热乎乎的矿石。",
	Value = 321009,
	Active = true,
	Weight = 3795,
	PreGoal = 
	{
		300087,
		300424,
	},
	CloseGoal = 
	{
		300458,
	},
	GoodsId = 3501009,
	Priority = 1009235,
	Num = 24,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 6679,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 55,
				},
				{
					Value = 1,
					Num = 1179,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 55,
				},
				{
					Value = 1,
					Num = 1179,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 11,
				},
				{
					Value = 1,
					Num = 1179,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 11,
				},
				{
					Value = 1,
					Num = 1179,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 2,
				},
				{
					Value = 1,
					Num = 1679,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 2,
				},
				{
					Value = 1,
					Num = 1679,
				},
			},
		},
	},
	DemandID = 410336,
	DemandGroupList = {
		420002,
		420004,
		420005,
		420006,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id337] =
{
	Id = 337,
	Name = "新能源",
	Desc = "或许可以用炭石作为新能源吧。",
	Value = 321009,
	Active = true,
	Weight = 4255,
	PreGoal = 
	{
		300087,
		300439,
	},
	CloseGoal = 
	{
		300474,
	},
	GoodsId = 3501009,
	Priority = 1009236,
	Num = 26,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 7236,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 60,
				},
				{
					Value = 1,
					Num = 1236,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 60,
				},
				{
					Value = 1,
					Num = 1236,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 12,
				},
				{
					Value = 1,
					Num = 1236,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 12,
				},
				{
					Value = 1,
					Num = 1236,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 2,
				},
				{
					Value = 1,
					Num = 2236,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 2,
				},
				{
					Value = 1,
					Num = 2236,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 43,
				},
				{
					Value = 320051,
					Num = 29,
				},
			},
		},
	},
	DemandID = 410337,
	DemandGroupList = {
		420002,
		420004,
		420005,
		420006,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id338] =
{
	Id = 338,
	Name = "危险魔术",
	Desc = "老是丢保龄球瓶也挺无聊的…",
	Value = 321009,
	Active = true,
	Weight = 4715,
	PreGoal = 
	{
		300087,
		300454,
	},
	CloseGoal = 
	{
		300494,
	},
	GoodsId = 3501009,
	Priority = 1009237,
	Num = 27,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 7514,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 62,
				},
				{
					Value = 1,
					Num = 1314,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 62,
				},
				{
					Value = 1,
					Num = 1314,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 12,
				},
				{
					Value = 1,
					Num = 1514,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 12,
				},
				{
					Value = 1,
					Num = 1514,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 2,
				},
				{
					Value = 1,
					Num = 2514,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 2,
				},
				{
					Value = 1,
					Num = 2514,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 45,
				},
				{
					Value = 320051,
					Num = 30,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 9,
				},
				{
					Value = 320052,
					Num = 6,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 1,
				},
				{
					Value = 320053,
					Num = 2,
				},
			},
		},
	},
	DemandID = 410338,
	DemandGroupList = {
		420002,
		420004,
		420005,
		420006,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id339] =
{
	Id = 339,
	Name = "燃烧的矿石",
	Desc = "北方的居民需要热乎乎的矿石。",
	Value = 321009,
	Active = true,
	Weight = 5290,
	PreGoal = 
	{
		300087,
		300474,
	},
	CloseGoal = 
	{
		300819,
	},
	GoodsId = 3501009,
	Priority = 1009238,
	Num = 30,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 8349,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 69,
				},
				{
					Value = 1,
					Num = 1449,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 69,
				},
				{
					Value = 1,
					Num = 1449,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 13,
				},
				{
					Value = 1,
					Num = 1849,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 13,
				},
				{
					Value = 1,
					Num = 1849,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 2,
				},
				{
					Value = 1,
					Num = 3349,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 2,
				},
				{
					Value = 1,
					Num = 3349,
				},
			},
		},
	},
	DemandID = 410339,
	DemandGroupList = {
		420002,
		420004,
		420005,
		420006,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id340] =
{
	Id = 340,
	Name = "新能源",
	Desc = "或许可以用炭石作为新能源吧。",
	Value = 321009,
	Active = true,
	Weight = 5865,
	PreGoal = 
	{
		300087,
		300494,
	},
	CloseGoal = 
	{
		300844,
	},
	GoodsId = 3501009,
	Priority = 1009239,
	Num = 32,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 8906,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 74,
				},
				{
					Value = 1,
					Num = 1506,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 74,
				},
				{
					Value = 1,
					Num = 1506,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 14,
				},
				{
					Value = 1,
					Num = 1906,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 14,
				},
				{
					Value = 1,
					Num = 1906,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 2,
				},
				{
					Value = 1,
					Num = 3906,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 2,
				},
				{
					Value = 1,
					Num = 3906,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 53,
				},
				{
					Value = 320051,
					Num = 36,
				},
			},
		},
	},
	DemandID = 410340,
	DemandGroupList = {
		420002,
		420004,
		420005,
		420006,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id341] =
{
	Id = 341,
	Name = "新能源",
	Desc = "或许可以用炭石作为新能源吧。",
	Value = 321009,
	Active = true,
	Weight = 6555,
	PreGoal = 
	{
		300087,
		300823,
	},
	CloseGoal = 
	{
		300868,
	},
	GoodsId = 3501009,
	Priority = 1009240,
	Num = 35,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 9741,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 81,
				},
				{
					Value = 1,
					Num = 1641,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 81,
				},
				{
					Value = 1,
					Num = 1641,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 16,
				},
				{
					Value = 1,
					Num = 1741,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 16,
				},
				{
					Value = 1,
					Num = 1741,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 3,
				},
				{
					Value = 1,
					Num = 2241,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 3,
				},
				{
					Value = 1,
					Num = 2241,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 58,
				},
				{
					Value = 320051,
					Num = 39,
				},
			},
		},
	},
	DemandID = 410341,
	DemandGroupList = {
		420002,
		420004,
		420005,
		420006,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id342] =
{
	Id = 342,
	Name = "勇敢的证明",
	Desc = "需要道具证明我去过魔王城堡。",
	Value = 321010,
	Active = true,
	Weight = 3125,
	PreGoal = 
	{
		300326,
		300096,
	},
	CloseGoal = 
	{
		300421,
	},
	GoodsId = 3611010,
	Priority = 1010251,
	Num = 15,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 7461,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 63,
				},
				{
					Value = 1,
					Num = 1161,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 63,
				},
				{
					Value = 1,
					Num = 1161,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 12,
				},
				{
					Value = 1,
					Num = 1461,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 12,
				},
				{
					Value = 1,
					Num = 1461,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 2,
				},
				{
					Value = 1,
					Num = 2461,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 2,
				},
				{
					Value = 1,
					Num = 2461,
				},
			},
		},
	},
	DemandID = 410342,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id343] =
{
	Id = 343,
	Name = "高级饰品",
	Desc = "只有使用魔王的素材才能制作。",
	Value = 321010,
	Active = true,
	Weight = 3375,
	PreGoal = 
	{
		300326,
		300403,
	},
	CloseGoal = 
	{
		300428,
	},
	GoodsId = 3621010,
	Priority = 1010252,
	Num = 18,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 8953,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 76,
				},
				{
					Value = 1,
					Num = 1353,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 76,
				},
				{
					Value = 1,
					Num = 1353,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 15,
				},
				{
					Value = 1,
					Num = 1453,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 15,
				},
				{
					Value = 1,
					Num = 1453,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 3,
				},
				{
					Value = 1,
					Num = 1453,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 3,
				},
				{
					Value = 1,
					Num = 1453,
				},
			},
		},
	},
	DemandID = 410343,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id344] =
{
	Id = 344,
	Name = "超高温",
	Desc = "用高温进行新实验会有不错的收获吧？",
	Value = 321010,
	Active = true,
	Weight = 3625,
	PreGoal = 
	{
		300326,
		300410,
	},
	CloseGoal = 
	{
		300439,
	},
	GoodsId = 3601010,
	Priority = 1010253,
	Num = 18,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 8953,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 76,
				},
				{
					Value = 1,
					Num = 1353,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 76,
				},
				{
					Value = 1,
					Num = 1353,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 15,
				},
				{
					Value = 1,
					Num = 1453,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 15,
				},
				{
					Value = 1,
					Num = 1453,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 3,
				},
				{
					Value = 1,
					Num = 1453,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 3,
				},
				{
					Value = 1,
					Num = 1453,
				},
			},
		},
	},
	DemandID = 410344,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id345] =
{
	Id = 345,
	Name = "勇敢的证明",
	Desc = "需要道具证明我去过魔王城堡。",
	Value = 321010,
	Active = true,
	Weight = 4000,
	PreGoal = 
	{
		300326,
		300421,
	},
	CloseGoal = 
	{
		300450,
	},
	GoodsId = 3601010,
	Priority = 1010254,
	Num = 18,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 8953,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 76,
				},
				{
					Value = 1,
					Num = 1353,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 76,
				},
				{
					Value = 1,
					Num = 1353,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 15,
				},
				{
					Value = 1,
					Num = 1453,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 15,
				},
				{
					Value = 1,
					Num = 1453,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 3,
				},
				{
					Value = 1,
					Num = 1453,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 3,
				},
				{
					Value = 1,
					Num = 1453,
				},
			},
		},
	},
	DemandID = 410345,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id346] =
{
	Id = 346,
	Name = "高级饰品",
	Desc = "只有使用魔王的素材才能制作。",
	Value = 321010,
	Active = true,
	Weight = 4375,
	PreGoal = 
	{
		300326,
		300431,
	},
	CloseGoal = 
	{
		300466,
	},
	GoodsId = 3601010,
	Priority = 1010255,
	Num = 21,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 10445,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 88,
				},
				{
					Value = 1,
					Num = 1645,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 88,
				},
				{
					Value = 1,
					Num = 1645,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 17,
				},
				{
					Value = 1,
					Num = 1945,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 17,
				},
				{
					Value = 1,
					Num = 1945,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 3,
				},
				{
					Value = 1,
					Num = 2945,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 3,
				},
				{
					Value = 1,
					Num = 2945,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 62,
				},
				{
					Value = 320051,
					Num = 42,
				},
			},
		},
	},
	DemandID = 410346,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id347] =
{
	Id = 347,
	Name = "超高温",
	Desc = "用高温进行新实验会有不错的收获吧？",
	Value = 321010,
	Active = true,
	Weight = 4875,
	PreGoal = 
	{
		300326,
		300446,
	},
	CloseGoal = 
	{
		300482,
	},
	GoodsId = 3601010,
	Priority = 1010256,
	Num = 22,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 10943,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 93,
				},
				{
					Value = 1,
					Num = 1643,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 93,
				},
				{
					Value = 1,
					Num = 1643,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 18,
				},
				{
					Value = 1,
					Num = 1943,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 18,
				},
				{
					Value = 1,
					Num = 1943,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 3,
				},
				{
					Value = 1,
					Num = 3443,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 3,
				},
				{
					Value = 1,
					Num = 3443,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 65,
				},
				{
					Value = 320051,
					Num = 44,
				},
			},
		},
	},
	DemandID = 410347,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id348] =
{
	Id = 348,
	Name = "勇敢的证明",
	Desc = "需要道具证明我去过魔王城堡。",
	Value = 321010,
	Active = true,
	Weight = 5375,
	PreGoal = 
	{
		300326,
		300462,
	},
	CloseGoal = 
	{
		300804,
	},
	GoodsId = 3601010,
	Priority = 1010257,
	Num = 24,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 11938,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 101,
				},
				{
					Value = 1,
					Num = 1838,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 101,
				},
				{
					Value = 1,
					Num = 1838,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 20,
				},
				{
					Value = 1,
					Num = 1938,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 20,
				},
				{
					Value = 1,
					Num = 1938,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 4,
				},
				{
					Value = 1,
					Num = 1938,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 4,
				},
				{
					Value = 1,
					Num = 1938,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 71,
				},
				{
					Value = 320051,
					Num = 48,
				},
			},
		},
	},
	DemandID = 410348,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id349] =
{
	Id = 349,
	Name = "高级饰品",
	Desc = "只有使用魔王的素材才能制作。",
	Value = 321010,
	Active = true,
	Weight = 6000,
	PreGoal = 
	{
		300326,
		300482,
	},
	CloseGoal = 
	{
		300827,
	},
	GoodsId = 3601010,
	Priority = 1010258,
	Num = 25,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 12435,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 105,
				},
				{
					Value = 1,
					Num = 1935,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 105,
				},
				{
					Value = 1,
					Num = 1935,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 21,
				},
				{
					Value = 1,
					Num = 1935,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 21,
				},
				{
					Value = 1,
					Num = 1935,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 4,
				},
				{
					Value = 1,
					Num = 2435,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 4,
				},
				{
					Value = 1,
					Num = 2435,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 74,
				},
				{
					Value = 320051,
					Num = 50,
				},
			},
		},
	},
	DemandID = 410349,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id350] =
{
	Id = 350,
	Name = "超高温",
	Desc = "用高温进行新实验会有不错的收获吧？",
	Value = 321010,
	Active = true,
	Weight = 6625,
	PreGoal = 
	{
		300326,
		300804,
	},
	CloseGoal = 
	{
		300852,
	},
	GoodsId = 3601010,
	Priority = 1010259,
	Num = 28,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 13927,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 118,
				},
				{
					Value = 1,
					Num = 2127,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 118,
				},
				{
					Value = 1,
					Num = 2127,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 23,
				},
				{
					Value = 1,
					Num = 2427,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 23,
				},
				{
					Value = 1,
					Num = 2427,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 4,
				},
				{
					Value = 1,
					Num = 3927,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 4,
				},
				{
					Value = 1,
					Num = 3927,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 83,
				},
				{
					Value = 320051,
					Num = 56,
				},
			},
		},
	},
	DemandID = 410350,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id351] =
{
	Id = 351,
	Name = "超高温",
	Desc = "用高温进行新实验会有不错的收获吧？",
	Value = 321010,
	Active = true,
	Weight = 7375,
	PreGoal = 
	{
		300326,
		300832,
	},
	CloseGoal = 
	{
		300876,
	},
	GoodsId = 3601010,
	Priority = 1010260,
	Num = 30,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 14922,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 126,
				},
				{
					Value = 1,
					Num = 2322,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 126,
				},
				{
					Value = 1,
					Num = 2322,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 25,
				},
				{
					Value = 1,
					Num = 2422,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 25,
				},
				{
					Value = 1,
					Num = 2422,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 5,
				},
				{
					Value = 1,
					Num = 2422,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 5,
				},
				{
					Value = 1,
					Num = 2422,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 1,
				},
				{
					Value = 1,
					Num = 2422,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 1,
				},
				{
					Value = 1,
					Num = 2422,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 89,
				},
				{
					Value = 320051,
					Num = 60,
				},
			},
		},
	},
	DemandID = 410351,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id352] =
{
	Id = 352,
	Name = "黑巫师委托",
	Desc = "需要很多头骨才能完成节阵。",
	Value = 321051,
	Active = true,
	Weight = 432,
	PreGoal = 
	{
		300331,
		300046,
	},
	CloseGoal = 
	{
		300072,
	},
	GoodsId = 3711051,
	Priority = 1051121,
	Num = 1,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 1151,
				},
			},
		},
	},
	DemandID = 410352,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id353] =
{
	Id = 353,
	Name = "黑巫师委托",
	Desc = "需要很多头骨才能完成节阵。",
	Value = 321051,
	Active = true,
	Weight = 504,
	PreGoal = 
	{
		300331,
		300055,
	},
	CloseGoal = 
	{
		300080,
	},
	GoodsId = 3721051,
	Priority = 1051122,
	Num = 2,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 2302,
				},
			},
		},
	},
	DemandID = 410353,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id354] =
{
	Id = 354,
	Name = "黑巫师委托",
	Desc = "需要很多头骨才能完成节阵。",
	Value = 321051,
	Active = true,
	Weight = 576,
	PreGoal = 
	{
		300331,
		300062,
	},
	CloseGoal = 
	{
		300091,
	},
	GoodsId = 3731051,
	Priority = 1051123,
	Num = 2,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 2302,
				},
			},
		},
	},
	DemandID = 410354,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id355] =
{
	Id = 355,
	Name = "黑巫师委托",
	Desc = "需要很多头骨才能完成节阵。",
	Value = 321051,
	Active = true,
	Weight = 684,
	PreGoal = 
	{
		300331,
		300072,
	},
	CloseGoal = 
	{
		300403,
	},
	GoodsId = 3741051,
	Priority = 1051124,
	Num = 3,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 3453,
				},
			},
		},
	},
	DemandID = 410355,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id356] =
{
	Id = 356,
	Name = "黑巫师委托",
	Desc = "需要很多头骨才能完成节阵。",
	Value = 321051,
	Active = true,
	Weight = 792,
	PreGoal = 
	{
		300331,
		300084,
	},
	CloseGoal = 
	{
		300417,
	},
	GoodsId = 3751051,
	Priority = 1051125,
	Num = 3,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 3453,
				},
			},
		},
	},
	DemandID = 410356,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id357] =
{
	Id = 357,
	Name = "黑巫师委托",
	Desc = "需要很多头骨才能完成节阵。",
	Value = 321051,
	Active = true,
	Weight = 936,
	PreGoal = 
	{
		300331,
		300084,
	},
	CloseGoal = 
	{
		300431,
	},
	GoodsId = 3761051,
	Priority = 1051126,
	Num = 8,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 9209,
				},
			},
		},
	},
	DemandID = 410357,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id358] =
{
	Id = 358,
	Name = "黑巫师委托",
	Desc = "需要很多头骨才能完成节阵。",
	Value = 321051,
	Active = true,
	Weight = 1080,
	PreGoal = 
	{
		300331,
		300084,
	},
	CloseGoal = 
	{
		300450,
	},
	GoodsId = 3701051,
	Priority = 1051127,
	Num = 9,
	RewardList = {
		{
			Weight = 0,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 10360,
				},
			},
		},
		{
			Weight = 80,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320001,
					Num = 1,
				},
				{
					Value = 1,
					Num = 1720,
				},
			},
		},
	},
	DemandID = 410358,
	DemandGroupList = {
		420003,
		420008,
		420009,
	},
}
DemandConfig[DemandID.Id359] =
{
	Id = 359,
	Name = "黑巫师委托",
	Desc = "需要很多头骨才能完成节阵。",
	Value = 321051,
	Active = true,
	Weight = 1260,
	PreGoal = 
	{
		300331,
		300431,
	},
	CloseGoal = 
	{
		300470,
	},
	GoodsId = 3701051,
	Priority = 1051128,
	Num = 10,
	RewardList = {
		{
			Weight = 0,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 11511,
				},
			},
		},
		{
			Weight = 80,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320001,
					Num = 1,
				},
				{
					Value = 1,
					Num = 2871,
				},
			},
		},
	},
	DemandID = 410359,
	DemandGroupList = {
		420003,
		420008,
		420009,
	},
}
DemandConfig[DemandID.Id360] =
{
	Id = 360,
	Name = "黑巫师委托",
	Desc = "需要很多头骨才能完成节阵。",
	Value = 321051,
	Active = true,
	Weight = 1440,
	PreGoal = 
	{
		300331,
		300450,
	},
	CloseGoal = 
	{
		300494,
	},
	GoodsId = 3701051,
	Priority = 1051129,
	Num = 10,
	RewardList = {
		{
			Weight = 0,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 11511,
				},
			},
		},
		{
			Weight = 80,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320001,
					Num = 1,
				},
				{
					Value = 1,
					Num = 2871,
				},
			},
		},
	},
	DemandID = 410360,
	DemandGroupList = {
		420003,
		420008,
		420009,
	},
}
DemandConfig[DemandID.Id361] =
{
	Id = 361,
	Name = "黑巫师委托",
	Desc = "需要很多头骨才能完成节阵。",
	Value = 321051,
	Active = true,
	Weight = 1656,
	PreGoal = 
	{
		300331,
		300474,
	},
	CloseGoal = 
	{
		300823,
	},
	GoodsId = 3701051,
	Priority = 1051130,
	Num = 10,
	RewardList = {
		{
			Weight = 0,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 11511,
				},
			},
		},
		{
			Weight = 80,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320001,
					Num = 1,
				},
				{
					Value = 1,
					Num = 2871,
				},
			},
		},
	},
	DemandID = 410361,
	DemandGroupList = {
		420003,
		420008,
		420009,
	},
}
DemandConfig[DemandID.Id362] =
{
	Id = 362,
	Name = "游戏攻略网",
	Desc = "有偿征集游戏攻略，欢迎投稿。",
	Value = 321052,
	Active = true,
	Weight = 1083,
	PreGoal = 
	{
		300332,
		300072,
	},
	CloseGoal = 
	{
		300102,
	},
	GoodsId = 3811052,
	Priority = 1052191,
	Num = 2,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 3719,
				},
			},
		},
	},
	DemandID = 410362,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id363] =
{
	Id = 363,
	Name = "游戏攻略网",
	Desc = "有偿征集游戏攻略，欢迎投稿。",
	Value = 321052,
	Active = true,
	Weight = 1197,
	PreGoal = 
	{
		300332,
		300080,
	},
	CloseGoal = 
	{
		300406,
	},
	GoodsId = 3821052,
	Priority = 1052192,
	Num = 3,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 5579,
				},
			},
		},
	},
	DemandID = 410363,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id364] =
{
	Id = 364,
	Name = "游戏攻略网",
	Desc = "有偿征集游戏攻略，欢迎投稿。",
	Value = 321052,
	Active = true,
	Weight = 1311,
	PreGoal = 
	{
		300332,
		300087,
	},
	CloseGoal = 
	{
		300417,
	},
	GoodsId = 3831052,
	Priority = 1052193,
	Num = 3,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 5579,
				},
			},
		},
	},
	DemandID = 410364,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id365] =
{
	Id = 365,
	Name = "游戏攻略网",
	Desc = "有偿征集游戏攻略，欢迎投稿。",
	Value = 321052,
	Active = true,
	Weight = 1482,
	PreGoal = 
	{
		300332,
		300087,
	},
	CloseGoal = 
	{
		300428,
	},
	GoodsId = 3841052,
	Priority = 1052194,
	Num = 6,
	RewardList = {
		{
			Weight = 0,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 11159,
				},
			},
		},
		{
			Weight = 80,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320001,
					Num = 1,
				},
				{
					Value = 1,
					Num = 2519,
				},
			},
		},
	},
	DemandID = 410365,
	DemandGroupList = {
		420003,
		420008,
		420009,
	},
}
DemandConfig[DemandID.Id366] =
{
	Id = 366,
	Name = "游戏攻略网",
	Desc = "有偿征集游戏攻略，欢迎投稿。",
	Value = 321052,
	Active = true,
	Weight = 1653,
	PreGoal = 
	{
		300332,
		300410,
	},
	CloseGoal = 
	{
		300443,
	},
	GoodsId = 3801052,
	Priority = 1052195,
	Num = 8,
	RewardList = {
		{
			Weight = 0,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 14879,
				},
			},
		},
		{
			Weight = 80,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320001,
					Num = 1,
				},
				{
					Value = 1,
					Num = 6239,
				},
			},
		},
	},
	DemandID = 410366,
	DemandGroupList = {
		420003,
		420008,
		420009,
	},
}
DemandConfig[DemandID.Id367] =
{
	Id = 367,
	Name = "游戏攻略网",
	Desc = "有偿征集游戏攻略，欢迎投稿。",
	Value = 321052,
	Active = true,
	Weight = 1881,
	PreGoal = 
	{
		300332,
		300424,
	},
	CloseGoal = 
	{
		300458,
	},
	GoodsId = 3801052,
	Priority = 1052196,
	Num = 8,
	RewardList = {
		{
			Weight = 0,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 14879,
				},
			},
		},
		{
			Weight = 80,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320001,
					Num = 1,
				},
				{
					Value = 1,
					Num = 6239,
				},
			},
		},
	},
	DemandID = 410367,
	DemandGroupList = {
		420003,
		420008,
		420009,
	},
}
DemandConfig[DemandID.Id368] =
{
	Id = 368,
	Name = "游戏攻略网",
	Desc = "有偿征集游戏攻略，欢迎投稿。",
	Value = 321052,
	Active = true,
	Weight = 2109,
	PreGoal = 
	{
		300332,
		300439,
	},
	CloseGoal = 
	{
		300478,
	},
	GoodsId = 3801052,
	Priority = 1052197,
	Num = 9,
	RewardList = {
		{
			Weight = 0,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 16739,
				},
			},
		},
		{
			Weight = 80,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320001,
					Num = 1,
				},
				{
					Value = 1,
					Num = 8099,
				},
			},
		},
	},
	DemandID = 410368,
	DemandGroupList = {
		420003,
		420008,
		420009,
	},
}
DemandConfig[DemandID.Id369] =
{
	Id = 369,
	Name = "游戏攻略网",
	Desc = "有偿征集游戏攻略，欢迎投稿。",
	Value = 321052,
	Active = true,
	Weight = 2394,
	PreGoal = 
	{
		300332,
		300458,
	},
	CloseGoal = 
	{
		300499,
	},
	GoodsId = 3801052,
	Priority = 1052198,
	Num = 9,
	RewardList = {
		{
			Weight = 0,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 16739,
				},
			},
		},
		{
			Weight = 80,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320001,
					Num = 1,
				},
				{
					Value = 1,
					Num = 8099,
				},
			},
		},
	},
	DemandID = 410369,
	DemandGroupList = {
		420003,
		420008,
		420009,
	},
}
DemandConfig[DemandID.Id370] =
{
	Id = 370,
	Name = "游戏攻略网",
	Desc = "有偿征集游戏攻略，欢迎投稿。",
	Value = 321052,
	Active = true,
	Weight = 2679,
	PreGoal = 
	{
		300332,
		300478,
	},
	CloseGoal = 
	{
		300827,
	},
	GoodsId = 3801052,
	Priority = 1052199,
	Num = 10,
	RewardList = {
		{
			Weight = 0,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 18599,
				},
			},
		},
		{
			Weight = 80,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320001,
					Num = 1,
				},
				{
					Value = 1,
					Num = 9959,
				},
			},
		},
	},
	DemandID = 410370,
	DemandGroupList = {
		420003,
		420008,
		420009,
	},
}
DemandConfig[DemandID.Id371] =
{
	Id = 371,
	Name = "游戏攻略网",
	Desc = "有偿征集游戏攻略，欢迎投稿。",
	Value = 321052,
	Active = true,
	Weight = 3021,
	PreGoal = 
	{
		300332,
		300804,
	},
	CloseGoal = 
	{
		300852,
	},
	GoodsId = 3801052,
	Priority = 1052200,
	Num = 10,
	RewardList = {
		{
			Weight = 0,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 18599,
				},
			},
		},
		{
			Weight = 80,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320001,
					Num = 1,
				},
				{
					Value = 1,
					Num = 9959,
				},
			},
		},
	},
	DemandID = 410371,
	DemandGroupList = {
		420003,
		420008,
		420009,
	},
}
DemandConfig[DemandID.Id372] =
{
	Id = 372,
	Name = "魔法实验室",
	Desc = "需要符合法师们品味的计时器。",
	Value = 321053,
	Active = true,
	Weight = 972,
	PreGoal = 
	{
		300333,
		300069,
	},
	CloseGoal = 
	{
		300096,
	},
	GoodsId = 3911053,
	Priority = 1053181,
	Num = 1,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 2033,
				},
			},
		},
	},
	DemandID = 410372,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id373] =
{
	Id = 373,
	Name = "魔法实验室",
	Desc = "需要符合法师们品味的计时器。",
	Value = 321053,
	Active = true,
	Weight = 1080,
	PreGoal = 
	{
		300333,
		300075,
	},
	CloseGoal = 
	{
		300403,
	},
	GoodsId = 3921053,
	Priority = 1053182,
	Num = 1,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 2033,
				},
			},
		},
	},
	DemandID = 410373,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id374] =
{
	Id = 374,
	Name = "魔法实验室",
	Desc = "需要符合法师们品味的计时器。",
	Value = 321053,
	Active = true,
	Weight = 1188,
	PreGoal = 
	{
		300333,
		300084,
	},
	CloseGoal = 
	{
		300413,
	},
	GoodsId = 3931053,
	Priority = 1053183,
	Num = 1,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 2033,
				},
			},
		},
	},
	DemandID = 410374,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id375] =
{
	Id = 375,
	Name = "魔法实验室",
	Desc = "需要符合法师们品味的计时器。",
	Value = 321053,
	Active = true,
	Weight = 1350,
	PreGoal = 
	{
		300333,
		300096,
	},
	CloseGoal = 
	{
		300424,
	},
	GoodsId = 3941053,
	Priority = 1053184,
	Num = 2,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 4066,
				},
			},
		},
	},
	DemandID = 410375,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id376] =
{
	Id = 376,
	Name = "魔法实验室",
	Desc = "需要符合法师们品味的计时器。",
	Value = 321053,
	Active = true,
	Weight = 1512,
	PreGoal = 
	{
		300333,
		300406,
	},
	CloseGoal = 
	{
		300439,
	},
	GoodsId = 3901053,
	Priority = 1053185,
	Num = 3,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 6100,
				},
			},
		},
	},
	DemandID = 410376,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id377] =
{
	Id = 377,
	Name = "魔法实验室",
	Desc = "需要符合法师们品味的计时器。",
	Value = 321053,
	Active = true,
	Weight = 1728,
	PreGoal = 
	{
		300333,
		300421,
	},
	CloseGoal = 
	{
		300454,
	},
	GoodsId = 3901053,
	Priority = 1053186,
	Num = 4,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 8133,
				},
			},
		},
	},
	DemandID = 410377,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id378] =
{
	Id = 378,
	Name = "魔法实验室",
	Desc = "需要符合法师们品味的计时器。",
	Value = 321053,
	Active = true,
	Weight = 1944,
	PreGoal = 
	{
		300333,
		300436,
	},
	CloseGoal = 
	{
		300474,
	},
	GoodsId = 3901053,
	Priority = 1053187,
	Num = 4,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 8133,
				},
			},
		},
	},
	DemandID = 410378,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id379] =
{
	Id = 379,
	Name = "魔法实验室",
	Desc = "需要符合法师们品味的计时器。",
	Value = 321053,
	Active = true,
	Weight = 2214,
	PreGoal = 
	{
		300333,
		300454,
	},
	CloseGoal = 
	{
		300494,
	},
	GoodsId = 3901053,
	Priority = 1053188,
	Num = 4,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 8133,
				},
			},
		},
	},
	DemandID = 410379,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id380] =
{
	Id = 380,
	Name = "魔法实验室",
	Desc = "需要符合法师们品味的计时器。",
	Value = 321053,
	Active = true,
	Weight = 2484,
	PreGoal = 
	{
		300333,
		300474,
	},
	CloseGoal = 
	{
		300823,
	},
	GoodsId = 3901053,
	Priority = 1053189,
	Num = 4,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 8133,
				},
			},
		},
	},
	DemandID = 410380,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id381] =
{
	Id = 381,
	Name = "魔法实验室",
	Desc = "需要符合法师们品味的计时器。",
	Value = 321053,
	Active = true,
	Weight = 2808,
	PreGoal = 
	{
		300333,
		300499,
	},
	CloseGoal = 
	{
		300848,
	},
	GoodsId = 3901053,
	Priority = 1053190,
	Num = 5,
	RewardList = {
		{
			Weight = 0,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 10167,
				},
			},
		},
		{
			Weight = 80,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320001,
					Num = 1,
				},
				{
					Value = 1,
					Num = 1527,
				},
			},
		},
	},
	DemandID = 410381,
	DemandGroupList = {
		420003,
		420008,
		420009,
	},
}
DemandConfig[DemandID.Id382] =
{
	Id = 382,
	Name = "洞穴探险队",
	Desc = "前往黑暗的地方必须要这些！",
	Value = 321054,
	Active = true,
	Weight = 1587,
	PreGoal = 
	{
		300334,
		300087,
	},
	CloseGoal = 
	{
		300413,
	},
	GoodsId = 4011054,
	Priority = 1054231,
	Num = 3,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 7145,
				},
			},
		},
	},
	DemandID = 410382,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id383] =
{
	Id = 383,
	Name = "洞穴探险队",
	Desc = "前往黑暗的地方必须要这些！",
	Value = 321054,
	Active = true,
	Weight = 1725,
	PreGoal = 
	{
		300334,
		300096,
	},
	CloseGoal = 
	{
		300421,
	},
	GoodsId = 4021054,
	Priority = 1054232,
	Num = 4,
	RewardList = {
		{
			Weight = 0,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 9527,
				},
			},
		},
		{
			Weight = 80,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320001,
					Num = 1,
				},
				{
					Value = 1,
					Num = 887,
				},
			},
		},
	},
	DemandID = 410383,
	DemandGroupList = {
		420003,
		420008,
		420009,
	},
}
DemandConfig[DemandID.Id384] =
{
	Id = 384,
	Name = "洞穴探险队",
	Desc = "前往黑暗的地方必须要这些！",
	Value = 321054,
	Active = true,
	Weight = 1863,
	PreGoal = 
	{
		300334,
		300403,
	},
	CloseGoal = 
	{
		300431,
	},
	GoodsId = 4031054,
	Priority = 1054233,
	Num = 5,
	RewardList = {
		{
			Weight = 0,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 11909,
				},
			},
		},
		{
			Weight = 80,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320001,
					Num = 1,
				},
				{
					Value = 1,
					Num = 3269,
				},
			},
		},
	},
	DemandID = 410384,
	DemandGroupList = {
		420003,
		420008,
		420009,
	},
}
DemandConfig[DemandID.Id385] =
{
	Id = 385,
	Name = "洞穴探险队",
	Desc = "前往黑暗的地方必须要这些！",
	Value = 321054,
	Active = true,
	Weight = 2070,
	PreGoal = 
	{
		300334,
		300413,
	},
	CloseGoal = 
	{
		300443,
	},
	GoodsId = 4001054,
	Priority = 1054234,
	Num = 5,
	RewardList = {
		{
			Weight = 0,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 11909,
				},
			},
		},
		{
			Weight = 80,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320001,
					Num = 1,
				},
				{
					Value = 1,
					Num = 3269,
				},
			},
		},
	},
	DemandID = 410385,
	DemandGroupList = {
		420003,
		420008,
		420009,
	},
}
DemandConfig[DemandID.Id386] =
{
	Id = 386,
	Name = "洞穴探险队",
	Desc = "前往黑暗的地方必须要这些！",
	Value = 321054,
	Active = true,
	Weight = 2277,
	PreGoal = 
	{
		300334,
		300424,
	},
	CloseGoal = 
	{
		300458,
	},
	GoodsId = 4001054,
	Priority = 1054235,
	Num = 5,
	RewardList = {
		{
			Weight = 0,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 11909,
				},
			},
		},
		{
			Weight = 80,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320001,
					Num = 1,
				},
				{
					Value = 1,
					Num = 3269,
				},
			},
		},
	},
	DemandID = 410386,
	DemandGroupList = {
		420003,
		420008,
		420009,
	},
}
DemandConfig[DemandID.Id387] =
{
	Id = 387,
	Name = "洞穴探险队",
	Desc = "前往黑暗的地方必须要这些！",
	Value = 321054,
	Active = true,
	Weight = 2553,
	PreGoal = 
	{
		300334,
		300439,
	},
	CloseGoal = 
	{
		300474,
	},
	GoodsId = 4001054,
	Priority = 1054236,
	Num = 5,
	RewardList = {
		{
			Weight = 0,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 11909,
				},
			},
		},
		{
			Weight = 80,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320001,
					Num = 1,
				},
				{
					Value = 1,
					Num = 3269,
				},
			},
		},
	},
	DemandID = 410387,
	DemandGroupList = {
		420003,
		420008,
		420009,
	},
}
DemandConfig[DemandID.Id388] =
{
	Id = 388,
	Name = "洞穴探险队",
	Desc = "前往黑暗的地方必须要这些！",
	Value = 321054,
	Active = true,
	Weight = 2829,
	PreGoal = 
	{
		300334,
		300454,
	},
	CloseGoal = 
	{
		300494,
	},
	GoodsId = 4001054,
	Priority = 1054237,
	Num = 6,
	RewardList = {
		{
			Weight = 0,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 14291,
				},
			},
		},
		{
			Weight = 80,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320001,
					Num = 1,
				},
				{
					Value = 1,
					Num = 5651,
				},
			},
		},
	},
	DemandID = 410388,
	DemandGroupList = {
		420003,
		420008,
		420009,
	},
}
DemandConfig[DemandID.Id389] =
{
	Id = 389,
	Name = "洞穴探险队",
	Desc = "前往黑暗的地方必须要这些！",
	Value = 321054,
	Active = true,
	Weight = 3174,
	PreGoal = 
	{
		300334,
		300474,
	},
	CloseGoal = 
	{
		300819,
	},
	GoodsId = 4001054,
	Priority = 1054238,
	Num = 6,
	RewardList = {
		{
			Weight = 0,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 14291,
				},
			},
		},
		{
			Weight = 80,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320001,
					Num = 1,
				},
				{
					Value = 1,
					Num = 5651,
				},
			},
		},
	},
	DemandID = 410389,
	DemandGroupList = {
		420003,
		420008,
		420009,
	},
}
DemandConfig[DemandID.Id390] =
{
	Id = 390,
	Name = "洞穴探险队",
	Desc = "前往黑暗的地方必须要这些！",
	Value = 321054,
	Active = true,
	Weight = 3519,
	PreGoal = 
	{
		300334,
		300494,
	},
	CloseGoal = 
	{
		300844,
	},
	GoodsId = 4001054,
	Priority = 1054239,
	Num = 6,
	RewardList = {
		{
			Weight = 0,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 14291,
				},
			},
		},
		{
			Weight = 80,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320001,
					Num = 1,
				},
				{
					Value = 1,
					Num = 5651,
				},
			},
		},
	},
	DemandID = 410390,
	DemandGroupList = {
		420003,
		420008,
		420009,
	},
}
DemandConfig[DemandID.Id391] =
{
	Id = 391,
	Name = "洞穴探险队",
	Desc = "前往黑暗的地方必须要这些！",
	Value = 321054,
	Active = true,
	Weight = 3933,
	PreGoal = 
	{
		300334,
		300823,
	},
	CloseGoal = 
	{
		300868,
	},
	GoodsId = 4001054,
	Priority = 1054240,
	Num = 8,
	RewardList = {
		{
			Weight = 0,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 19055,
				},
			},
		},
		{
			Weight = 80,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320001,
					Num = 2,
				},
				{
					Value = 1,
					Num = 1775,
				},
			},
		},
	},
	DemandID = 410391,
	DemandGroupList = {
		420003,
		420008,
		420009,
	},
}
DemandConfig[DemandID.Id392] =
{
	Id = 392,
	Name = "订购豆沙1",
	Desc = "需要一些豆沙",
	Value = 321201,
	Active = true,
	Weight = 3920,
	PreGoal = 
	{
		300406,
	},
	CloseGoal = 
	{
		300431,
	},
	GoodsId = 4101201,
	Priority = 1201281,
	Num = 21,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 7320,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 62,
				},
				{
					Value = 1,
					Num = 1120,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 62,
				},
				{
					Value = 1,
					Num = 1120,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 12,
				},
				{
					Value = 1,
					Num = 1320,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 12,
				},
				{
					Value = 1,
					Num = 1320,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 2,
				},
				{
					Value = 1,
					Num = 2320,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 2,
				},
				{
					Value = 1,
					Num = 2320,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 43,
				},
				{
					Value = 320051,
					Num = 30,
				},
			},
		},
	},
	DemandID = 410392,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id393] =
{
	Id = 393,
	Name = "订购豆沙2",
	Desc = "需要大量豆沙",
	Value = 321201,
	Active = true,
	Weight = 4200,
	PreGoal = 
	{
		300406,
		300413,
	},
	CloseGoal = 
	{
		300439,
	},
	GoodsId = 4101201,
	Priority = 1201282,
	Num = 22,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 7669,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 65,
				},
				{
					Value = 1,
					Num = 1169,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 65,
				},
				{
					Value = 1,
					Num = 1169,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 13,
				},
				{
					Value = 1,
					Num = 1169,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 13,
				},
				{
					Value = 1,
					Num = 1169,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 2,
				},
				{
					Value = 1,
					Num = 2669,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 2,
				},
				{
					Value = 1,
					Num = 2669,
				},
			},
		},
	},
	DemandID = 410393,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id394] =
{
	Id = 394,
	Name = "订购豆沙3",
	Desc = "需要超量豆沙",
	Value = 321201,
	Active = true,
	Weight = 4480,
	PreGoal = 
	{
		300406,
		300421,
	},
	CloseGoal = 
	{
		300450,
	},
	GoodsId = 4101201,
	Priority = 1201283,
	Num = 22,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 7669,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 65,
				},
				{
					Value = 1,
					Num = 1169,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 65,
				},
				{
					Value = 1,
					Num = 1169,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 13,
				},
				{
					Value = 1,
					Num = 1169,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 13,
				},
				{
					Value = 1,
					Num = 1169,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 2,
				},
				{
					Value = 1,
					Num = 2669,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 2,
				},
				{
					Value = 1,
					Num = 2669,
				},
			},
		},
	},
	DemandID = 410394,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id395] =
{
	Id = 395,
	Name = "订购豆沙1",
	Desc = "需要一些豆沙",
	Value = 321201,
	Active = true,
	Weight = 4900,
	PreGoal = 
	{
		300406,
		300431,
	},
	CloseGoal = 
	{
		300462,
	},
	GoodsId = 4101201,
	Priority = 1201284,
	Num = 22,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 7669,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 65,
				},
				{
					Value = 1,
					Num = 1169,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 65,
				},
				{
					Value = 1,
					Num = 1169,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 13,
				},
				{
					Value = 1,
					Num = 1169,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 13,
				},
				{
					Value = 1,
					Num = 1169,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 2,
				},
				{
					Value = 1,
					Num = 2669,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 2,
				},
				{
					Value = 1,
					Num = 2669,
				},
			},
		},
	},
	DemandID = 410395,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id396] =
{
	Id = 396,
	Name = "订购豆沙2",
	Desc = "需要大量豆沙",
	Value = 321201,
	Active = true,
	Weight = 5320,
	PreGoal = 
	{
		300406,
		300443,
	},
	CloseGoal = 
	{
		300478,
	},
	GoodsId = 4101201,
	Priority = 1201285,
	Num = 25,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 8715,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 74,
				},
				{
					Value = 1,
					Num = 1315,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 74,
				},
				{
					Value = 1,
					Num = 1315,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 14,
				},
				{
					Value = 1,
					Num = 1715,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 14,
				},
				{
					Value = 1,
					Num = 1715,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 2,
				},
				{
					Value = 1,
					Num = 3715,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 2,
				},
				{
					Value = 1,
					Num = 3715,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 52,
				},
				{
					Value = 320051,
					Num = 35,
				},
			},
		},
	},
	DemandID = 410396,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id397] =
{
	Id = 397,
	Name = "订购豆沙3",
	Desc = "需要超量豆沙",
	Value = 321201,
	Active = true,
	Weight = 5880,
	PreGoal = 
	{
		300406,
		300458,
	},
	CloseGoal = 
	{
		300494,
	},
	GoodsId = 4101201,
	Priority = 1201286,
	Num = 26,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 9063,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 77,
				},
				{
					Value = 1,
					Num = 1363,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 77,
				},
				{
					Value = 1,
					Num = 1363,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 15,
				},
				{
					Value = 1,
					Num = 1563,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 15,
				},
				{
					Value = 1,
					Num = 1563,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 3,
				},
				{
					Value = 1,
					Num = 1563,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 3,
				},
				{
					Value = 1,
					Num = 1563,
				},
			},
		},
	},
	DemandID = 410397,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id398] =
{
	Id = 398,
	Name = "订购豆沙1",
	Desc = "需要一些豆沙",
	Value = 321201,
	Active = true,
	Weight = 6440,
	PreGoal = 
	{
		300406,
		300474,
	},
	CloseGoal = 
	{
		300819,
	},
	GoodsId = 4101201,
	Priority = 1201287,
	Num = 28,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 9760,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 82,
				},
				{
					Value = 1,
					Num = 1560,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 82,
				},
				{
					Value = 1,
					Num = 1560,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 16,
				},
				{
					Value = 1,
					Num = 1760,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 16,
				},
				{
					Value = 1,
					Num = 1760,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 3,
				},
				{
					Value = 1,
					Num = 2260,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 3,
				},
				{
					Value = 1,
					Num = 2260,
				},
			},
		},
	},
	DemandID = 410398,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id399] =
{
	Id = 399,
	Name = "订购豆沙2",
	Desc = "需要大量豆沙",
	Value = 321201,
	Active = true,
	Weight = 7140,
	PreGoal = 
	{
		300406,
		300494,
	},
	CloseGoal = 
	{
		300840,
	},
	GoodsId = 4101201,
	Priority = 1201288,
	Num = 30,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 10458,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 88,
				},
				{
					Value = 1,
					Num = 1658,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 88,
				},
				{
					Value = 1,
					Num = 1658,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 17,
				},
				{
					Value = 1,
					Num = 1958,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 17,
				},
				{
					Value = 1,
					Num = 1958,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 3,
				},
				{
					Value = 1,
					Num = 2958,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 3,
				},
				{
					Value = 1,
					Num = 2958,
				},
			},
		},
	},
	DemandID = 410399,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id400] =
{
	Id = 400,
	Name = "订购豆沙3",
	Desc = "需要超量豆沙",
	Value = 321201,
	Active = true,
	Weight = 7840,
	PreGoal = 
	{
		300406,
		300819,
	},
	CloseGoal = 
	{
		300864,
	},
	GoodsId = 4101201,
	Priority = 1201289,
	Num = 33,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 11503,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 97,
				},
				{
					Value = 1,
					Num = 1803,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 97,
				},
				{
					Value = 1,
					Num = 1803,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 19,
				},
				{
					Value = 1,
					Num = 2003,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 19,
				},
				{
					Value = 1,
					Num = 2003,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 3,
				},
				{
					Value = 1,
					Num = 4003,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 3,
				},
				{
					Value = 1,
					Num = 4003,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 69,
				},
				{
					Value = 320051,
					Num = 46,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 13,
				},
				{
					Value = 320052,
					Num = 10,
				},
			},
		},
	},
	DemandID = 410400,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
