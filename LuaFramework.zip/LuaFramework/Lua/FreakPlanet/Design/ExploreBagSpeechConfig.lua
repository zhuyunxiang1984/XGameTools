ExploreBagSpeechConfig ={};
ExploreBagSpeechID = 
{
	Id50001 = 50001,
	Id50002 = 50002,
	Id50003 = 50003,
	Id50004 = 50004,
	Id50005 = 50005,
	Id50006 = 50006,
	Id50007 = 50007,
	Id50008 = 50008,
	Id50009 = 50009,
	Id50010 = 50010,
	Id50011 = 50011,
	Id50012 = 50012,
	Id50013 = 50013,
	Id50014 = 50014,
	Id50015 = 50015,
	Id50016 = 50016,
	Id50017 = 50017,
	Id50018 = 50018,
	Id50019 = 50019,
	Id50020 = 50020,
	Id50021 = 50021,
	Id50022 = 50022,
	Id50023 = 50023,
	Id50024 = 50024,
	Id50025 = 50025,
	Id50026 = 50026,
	Id50027 = 50027,
	Id50028 = 50028,
	Id50029 = 50029,
	Id50030 = 50030,
	Id50031 = 50031,
	Id50032 = 50032,
}
ExploreBagSpeechConfig[ExploreBagSpeechID.Id50001] =
{
	Id = 50001,
	Position = 1,
	NextID = 50002,
	Text = "喵~这次要去多久喵？",
	IsFirst = true,
}
ExploreBagSpeechConfig[ExploreBagSpeechID.Id50002] =
{
	Id = 50002,
	Position = 2,
	NextID = 50003,
	Text = "探险队会根据食物数量决定的喵。",
}
ExploreBagSpeechConfig[ExploreBagSpeechID.Id50003] =
{
	Id = 50003,
	Position = 1,
	NextID = 50004,
	Text = "那万一是不爱吃的呢？",
}
ExploreBagSpeechConfig[ExploreBagSpeechID.Id50004] =
{
	Id = 50004,
	Position = 2,
	Text = "系统会强制大家探索到指定时间的喵~",
}
ExploreBagSpeechConfig[ExploreBagSpeechID.Id50005] =
{
	Id = 50005,
	Position = 1,
	NextID = 50006,
	Text = "喵~可以带玩具去探索喵？",
	IsFirst = true,
	ConditionList = {
		{
			Condition = "StorgeGoodsTag",
			Value = 
			{
				564308,
			},
		},
	},
}
ExploreBagSpeechConfig[ExploreBagSpeechID.Id50006] =
{
	Id = 50006,
	Position = 2,
	NextID = 50007,
	Text = "除了食物，还可以带捕捉道具喵~",
}
ExploreBagSpeechConfig[ExploreBagSpeechID.Id50007] =
{
	Id = 50007,
	Position = 1,
	NextID = 50008,
	Text = "喵？捕捉被打败的敌人？",
}
ExploreBagSpeechConfig[ExploreBagSpeechID.Id50008] =
{
	Id = 50008,
	Position = 2,
	Text = "对的喵~呜呜厉害喵~",
}
ExploreBagSpeechConfig[ExploreBagSpeechID.Id50009] =
{
	Id = 50009,
	Position = 1,
	NextID = 50010,
	Text = "有些怪物似乎遇不到喵？",
	IsFirst = true,
}
ExploreBagSpeechConfig[ExploreBagSpeechID.Id50010] =
{
	Id = 50010,
	Position = 2,
	NextID = 50011,
	Text = "如果没有挑战过，似乎就不会出现呢。",
}
ExploreBagSpeechConfig[ExploreBagSpeechID.Id50011] =
{
	Id = 50011,
	Position = 1,
	NextID = 50012,
	Text = "但是有些挑战了也没有出现。",
}
ExploreBagSpeechConfig[ExploreBagSpeechID.Id50012] =
{
	Id = 50012,
	Position = 2,
	Text = "喵~可以长按怪物图标看出现时间喵~",
}
ExploreBagSpeechConfig[ExploreBagSpeechID.Id50013] =
{
	Id = 50013,
	Position = 1,
	NextID = 50014,
	Text = "仓库有三个页签喵~",
	IsFirst = true,
	ConditionList = {
		{
			Condition = "StorgeGoodsTag",
			Value = 
			{
				564308,
			},
		},
		{
			Condition = "StorgeGoodsTag",
			Value = 
			{
				564307,
			},
		},
	},
}
ExploreBagSpeechConfig[ExploreBagSpeechID.Id50014] =
{
	Id = 50014,
	Position = 2,
	NextID = 50015,
	Text = "是区分食物、捕捉道具和特别道具的。",
}
ExploreBagSpeechConfig[ExploreBagSpeechID.Id50015] =
{
	Id = 50015,
	Position = 1,
	NextID = 50016,
	Text = "喵，特别道具是什么喵？",
}
ExploreBagSpeechConfig[ExploreBagSpeechID.Id50016] =
{
	Id = 50016,
	Position = 2,
	Text = "是奇怪的东西喵，长按可以查看用途喵~",
}
ExploreBagSpeechConfig[ExploreBagSpeechID.Id50017] =
{
	Id = 50017,
	Position = 1,
	NextID = 50018,
	Text = "漆漆，怎么才能在背包塞更多吃的喵？",
	IsFirst = true,
	ConditionList = {
		{
			Condition = "ExploreBagNum",
			Value = 
			{
				1,5,
			},
		},
	},
}
ExploreBagSpeechConfig[ExploreBagSpeechID.Id50018] =
{
	Id = 50018,
	Position = 2,
	NextID = 50019,
	Text = "每个队员不升阶的话就只能带1个道具喵…",
}
ExploreBagSpeechConfig[ExploreBagSpeechID.Id50019] =
{
	Id = 50019,
	Position = 1,
	NextID = 50020,
	Text = "喵~那为什么不给队员升阶喵？",
}
ExploreBagSpeechConfig[ExploreBagSpeechID.Id50020] =
{
	Id = 50020,
	Position = 2,
	Text = "队员要20级后使用电池才能升阶呢…",
}
ExploreBagSpeechConfig[ExploreBagSpeechID.Id50021] =
{
	Id = 50021,
	Position = 1,
	NextID = 50022,
	Text = "漆漆~战力不足可以打败怪物喵？",
	IsFirst = true,
}
ExploreBagSpeechConfig[ExploreBagSpeechID.Id50022] =
{
	Id = 50022,
	Position = 2,
	NextID = 50023,
	Text = "喵？虽然会战败，不过并没有其他惩罚呢~",
}
ExploreBagSpeechConfig[ExploreBagSpeechID.Id50023] =
{
	Id = 50023,
	Position = 1,
	NextID = 50024,
	Text = "哇，那我就放心了。",
}
ExploreBagSpeechConfig[ExploreBagSpeechID.Id50024] =
{
	Id = 50024,
	Position = 2,
	Text = "呜呜厉害~",
}
ExploreBagSpeechConfig[ExploreBagSpeechID.Id50025] =
{
	Id = 50025,
	Position = 1,
	NextID = 50026,
	Text = "漆漆，那个蓝色的瓶子标签是什么喵？",
	IsFirst = true,
	ConditionList = {
		{
			Condition = "CompleteGoal",
			Value = 
			{
				308001,
			},
		},
	},
}
ExploreBagSpeechConfig[ExploreBagSpeechID.Id50026] =
{
	Id = 50026,
	Position = 2,
	NextID = 50027,
	Text = "喵？我也不知道喵，点点看？",
}
ExploreBagSpeechConfig[ExploreBagSpeechID.Id50027] =
{
	Id = 50027,
	Position = 1,
	NextID = 50028,
	Text = "啊，算啦，肯定不是重要的东西喵~",
}
ExploreBagSpeechConfig[ExploreBagSpeechID.Id50028] =
{
	Id = 50028,
	Position = 2,
	Text = "嗯，嗯，先不管啦~",
}
ExploreBagSpeechConfig[ExploreBagSpeechID.Id50029] =
{
	Id = 50029,
	Position = 1,
	NextID = 50030,
	Text = "漆漆，我要把这次探险的事情都记下来！",
	IsFirst = true,
}
ExploreBagSpeechConfig[ExploreBagSpeechID.Id50030] =
{
	Id = 50030,
	Position = 2,
	NextID = 50031,
	Text = "喵！呜呜认识这么多字的喵？",
}
ExploreBagSpeechConfig[ExploreBagSpeechID.Id50031] =
{
	Id = 50031,
	Position = 1,
	NextID = 50032,
	Text = "写不来的字画个×就好了嘛~",
}
ExploreBagSpeechConfig[ExploreBagSpeechID.Id50032] =
{
	Id = 50032,
	Position = 2,
	Text = "那到时候也要给我看喵~",
}

