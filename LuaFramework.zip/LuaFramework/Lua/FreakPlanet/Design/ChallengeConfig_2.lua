
ChallengeConfig[ChallengeID.Id4001] =
{
	Id = 4001,
	Name = "挑战：冒险家呜呜",
	UnlockCostList = {
		{
			Value = 320102,
			Num = 1,
		},
	},
	Character = 220001,
	AcceptSpeech = 14400101,
	Desc = "未来某天，呜呜会成为很优秀的冒险家。很多地方都留下了它的足迹。",
	RewardUnlock = 232001,
	ResultText = "冒险家呜呜解锁了",
	NumCap = 2,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG01",
	StartScene = "ARENA_StartScene",
	TeamCondition = {
		{
			Condition = "TeamCharacterIdAnd",
			Value = 
			{
				220001,
				220002,
			},
			Desc = "队伍中必须有呜呜,漆漆",
			Hint = "队伍中必须有呜呜,漆漆",
		},
	},
	Enemy = {
		{
			Value = 244001,
			Level = 50,
		},
		{
			Value = 244002,
			Level = 50,
		},
		{
			Value = 244003,
			Level = 50,
		},
	},
}
ChallengeConfig[ChallengeID.Id4002] =
{
	Id = 4002,
	Name = "挑战：冒险家漆漆",
	UnlockCostList = {
		{
			Value = 320102,
			Num = 1,
		},
	},
	Character = 220002,
	AcceptSpeech = 14400201,
	Desc = "无论呜呜去哪里，漆漆都会陪在呜呜身边，如果敌人太强，那么漆漆也会努力变更强。",
	RewardUnlock = 232002,
	ResultText = "冒险家漆漆解锁了",
	NumCap = 2,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG05",
	StartScene = "ARENA_StartScene",
	TeamCondition = {
		{
			Condition = "TeamCharacterIdAnd",
			Value = 
			{
				220001,
				220002,
			},
			Desc = "队伍中必须有呜呜,漆漆",
			Hint = "队伍中必须有呜呜,漆漆",
		},
	},
	Enemy = {
		{
			Value = 244004,
			Level = 50,
		},
	},
}
ChallengeConfig[ChallengeID.Id4003] =
{
	Id = 4003,
	Name = "挑战：假林克",
	UnlockCostList = {
		{
			Value = 320102,
			Num = 1,
		},
	},
	Character = 220003,
	AcceptSpeech = 14400301,
	Desc = "虽然不能保证公主不被绑架，但是能保证第一时间出发救援！\n“欸！小绿帽上的羽毛在抖动，公主有危险！”",
	RewardUnlock = 232003,
	ResultText = "假林克解锁了",
	NumCap = 5,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG04",
	StartScene = "RPG_StartScene",
	TeamCondition = {
		{
			Condition = "TeamCharacterIdOr",
			Value = 
			{
				220003,
			},
			Desc = "队伍中必须有剑士",
			Hint = "队伍中必须有剑士",
		},
		{
			Condition = "NeedTagAnd",
			Value = 
			{
				562902,
			},
			Desc = "必须是经典冒险组的队员",
			Hint = "必须是经典冒险组的队员",
		},
	},
	Enemy = {
		{
			Value = 244005,
			Level = 35,
		},
	},
}
ChallengeConfig[ChallengeID.Id4004] =
{
	Id = 4004,
	Name = "挑战：神射手",
	UnlockCostList = {
		{
			Value = 320102,
			Num = 1,
		},
	},
	Character = 220004,
	AcceptSpeech = 14400401,
	Desc = "专门为冒险星的神射手准备的弓道服，穿上她以后，每一箭都自动瞄着敌人最痛的部位飞去了。",
	RewardUnlock = 232004,
	ResultText = "神射手解锁了",
	NumCap = 1,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG01",
	StartScene = "RPG_StartScene",
	TeamCondition = {
		{
			Condition = "TeamCharacterIdOr",
			Value = 
			{
				220004,
			},
			Desc = "队伍中必须有弓箭手",
			Hint = "队伍中必须有弓箭手",
		},
	},
	Enemy = {
		{
			Value = 244006,
			Level = 35,
		},
	},
}
ChallengeConfig[ChallengeID.Id4005] =
{
	Id = 4005,
	Name = "挑战：猎魔人",
	UnlockCostList = {
		{
			Value = 320102,
			Num = 1,
		},
	},
	Character = 220005,
	AcceptSpeech = 14400501,
	Desc = "冒险世界中神秘又强大的组织，猎魔人以消灭企图摧毁世界的恶魔为己任，无论敌人多么强大，他们都不会后退一步，除非朋友们约他先打一局昆特牌。",
	RewardUnlock = 232005,
	ResultText = "猎魔人解锁了",
	NumCap = 5,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG02",
	StartScene = "RPG_StartScene",
	TeamCondition = {
		{
			Condition = "TeamCharacterIdOr",
			Value = 
			{
				220005,
			},
			Desc = "队伍中必须有猎人",
			Hint = "队伍中必须有猎人",
		},
	},
	Enemy = {
		{
			Value = 244007,
			Level = 35,
		},
	},
}
ChallengeConfig[ChallengeID.Id4006] =
{
	Id = 4006,
	Name = "挑战：骷髅王",
	UnlockCostList = {
		{
			Value = 320102,
			Num = 1,
		},
	},
	Character = 220006,
	AcceptSpeech = 14400601,
	Desc = "小小的骨头兵，在当地的怪物大选上，凭借极微弱的身高优势，当选为了骷髅王。",
	RewardUnlock = 232006,
	ResultText = "骷髅王解锁了",
	NumCap = 5,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG02",
	StartScene = "RPG_StartScene",
	TeamCondition = {
		{
			Condition = "TeamCharacterIdOr",
			Value = 
			{
				220006,
			},
			Desc = "队伍中必须有骨头兵",
			Hint = "队伍中必须有骨头兵",
		},
	},
	Enemy = {
		{
			Value = 244008,
			Level = 50,
		},
		{
			Value = 244009,
			Level = 50,
		},
		{
			Value = 244010,
			Level = 50,
		},
	},
}
ChallengeConfig[ChallengeID.Id4007] =
{
	Id = 4007,
	Name = "挑战：带路NPC",
	UnlockCostList = {
		{
			Value = 320101,
			Num = 1,
		},
	},
	Character = 220007,
	AcceptSpeech = 14400701,
	Desc = "指路NPC的工作成天风吹日晒，获得勇者赠送的狼头帽子，冬暖夏凉",
	RewardUnlock = 232007,
	ResultText = "带路NPC解锁了",
	NumCap = 5,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG03",
	StartScene = "RPG_StartScene",
	TeamCondition = {
		{
			Condition = "TeamCharacterIdOr",
			Value = 
			{
				220007,
			},
			Desc = "队伍中必须有指路NPC",
			Hint = "队伍中必须有指路NPC",
		},
	},
	Enemy = {
		{
			Value = 244011,
			Level = 25,
		},
	},
}
ChallengeConfig[ChallengeID.Id4008] =
{
	Id = 4008,
	Name = "挑战：顺鹿快送",
	UnlockCostList = {
		{
			Value = 320102,
			Num = 1,
		},
	},
	Character = 220008,
	AcceptSpeech = 14400801,
	Desc = "铁匠打出的铁无可挑剔，唯一的问题就是没有运输工具。为此铁匠学会了套鹿的技能。套了100头鹿后，铁匠创立了顺鹿快递拉货公司。",
	RewardUnlock = 232008,
	ResultText = "顺鹿快送解锁了",
	NumCap = 5,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG03",
	StartScene = "RPG_StartScene",
	TeamCondition = {
		{
			Condition = "TeamCharacterIdOr",
			Value = 
			{
				220008,
			},
			Desc = "队伍中必须有铁匠",
			Hint = "队伍中必须有铁匠",
		},
	},
	Enemy = {
		{
			Value = 244012,
			Level = 35,
		},
	},
}
ChallengeConfig[ChallengeID.Id4009] =
{
	Id = 4009,
	Name = "挑战：魔王的晚宴",
	UnlockCostList = {
		{
			Value = 320104,
			Num = 1,
		},
	},
	Character = 220009,
	AcceptSpeech = 14400901,
	Desc = "威风凛凛的魔王礼服，只有在出席正式场合时，小魔王才会穿噢~",
	RewardUnlock = 232009,
	ResultText = "魔王的晚宴解锁了",
	NumCap = 5,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG04",
	StartScene = "RPG_StartScene",
	TeamCondition = {
		{
			Condition = "TeamCharacterIdOr",
			Value = 
			{
				220009,
			},
			Desc = "队伍中必须有小魔王",
			Hint = "队伍中必须有小魔王",
		},
	},
	Enemy = {
		{
			Value = 244013,
			Level = 50,
		},
	},
}
ChallengeConfig[ChallengeID.Id4010] =
{
	Id = 4010,
	Name = "挑战：暗夜魔王",
	UnlockCostList = {
		{
			Value = 320104,
			Num = 1,
		},
	},
	Character = 220009,
	AcceptSpeech = 14401001,
	Desc = "由冒险星的高级裁缝制作的暗夜礼服，能够帮助穿戴者遮挡80%的紫外线，并且十分灵活透气。",
	RewardUnlock = 232010,
	ResultText = "暗夜魔王解锁了",
	NumCap = 5,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG04",
	StartScene = "RPG_StartScene",
	TeamCondition = {
		{
			Condition = "TeamCharacterIdOr",
			Value = 
			{
				220009,
			},
			Desc = "队伍中必须有小魔王",
			Hint = "队伍中必须有小魔王",
		},
	},
	Enemy = {
		{
			Value = 244014,
			Level = 50,
		},
	},
}
ChallengeConfig[ChallengeID.Id4011] =
{
	Id = 4011,
	Name = "挑战：小魔仙",
	UnlockCostList = {
		{
			Value = 320104,
			Num = 1,
		},
	},
	Character = 220010,
	AcceptSpeech = 14401101,
	Desc = "凝聚了自然与魔法力量的仙子法袍，仿佛具有生命一般，能够保护穿戴者。",
	RewardUnlock = 232011,
	ResultText = "小魔仙解锁了",
	NumCap = 5,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG01",
	StartScene = "RPG_StartScene",
	TeamCondition = {
		{
			Condition = "TeamCharacterIdOr",
			Value = 
			{
				220010,
			},
			Desc = "队伍中必须有魔法师",
			Hint = "队伍中必须有魔法师",
		},
	},
	Enemy = {
		{
			Value = 244015,
			Level = 75,
		},
	},
}
ChallengeConfig[ChallengeID.Id4012] =
{
	Id = 4012,
	Name = "挑战：寻宝者",
	UnlockCostList = {
		{
			Value = 320101,
			Num = 1,
		},
	},
	Character = 220011,
	AcceptSpeech = 14401201,
	Desc = "成天被勇者掳走家里的东西，终于决定自己成为一名勇者出去掠夺别人。",
	RewardUnlock = 232012,
	ResultText = "寻宝者解锁了",
	NumCap = 5,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG01",
	StartScene = "RPG_StartScene",
	TeamCondition = {
		{
			Condition = "TeamCharacterIdOr",
			Value = 
			{
				220011,
			},
			Desc = "队伍中必须有居民NPC",
			Hint = "队伍中必须有居民NPC",
		},
	},
	Enemy = {
		{
			Value = 244016,
			Level = 35,
		},
	},
}
ChallengeConfig[ChallengeID.Id4013] =
{
	Id = 4013,
	Name = "挑战：前任勇者",
	UnlockCostList = {
		{
			Value = 320101,
			Num = 1,
		},
	},
	Character = 220012,
	AcceptSpeech = 14401301,
	Desc = "历代勇者的专用服装，每次穿上前会播放近1分钟的特效，如果遇到不讲规矩的敌人，那么变身过程中就会被揍得鼻青脸肿。",
	RewardUnlock = 232013,
	ResultText = "前任勇者解锁了",
	NumCap = 5,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG01",
	StartScene = "RPG_StartScene",
	TeamCondition = {
		{
			Condition = "TeamCharacterIdOr",
			Value = 
			{
				220012,
			},
			Desc = "队伍中必须有村长",
			Hint = "队伍中必须有村长",
		},
	},
	Enemy = {
		{
			Value = 244017,
			Level = 35,
		},
	},
}
ChallengeConfig[ChallengeID.Id4014] =
{
	Id = 4014,
	Name = "挑战：管家",
	UnlockCostList = {
		{
			Value = 320101,
			Num = 1,
		},
	},
	Character = 220013,
	AcceptSpeech = 14401401,
	Desc = "村子里每天都会有各色怪物来拜访，每次脏脏的怪物来村长家做客后，村长夫人都会穿上特别的扫除服装，立刻将家里打扫干净。",
	RewardUnlock = 232014,
	ResultText = "管家解锁了",
	NumCap = 5,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG01",
	StartScene = "RPG_StartScene",
	TeamCondition = {
		{
			Condition = "TeamCharacterIdOr",
			Value = 
			{
				220013,
			},
			Desc = "队伍中必须有村长夫人",
			Hint = "队伍中必须有村长夫人",
		},
	},
	Enemy = {
		{
			Value = 244018,
			Level = 25,
		},
	},
}
ChallengeConfig[ChallengeID.Id4015] =
{
	Id = 4015,
	Name = "挑战：皇家卫兵",
	UnlockCostList = {
		{
			Value = 320102,
			Num = 1,
		},
	},
	Character = 220014,
	AcceptSpeech = 14401501,
	Desc = "每个皇家卫兵都是万中选一的城镇卫兵，不要在他的视线范围内PK。因为你看他永远是？？等级，打赢也没有掉落，而且刷新速度快得不讲道理。",
	RewardUnlock = 232015,
	ResultText = "皇家卫兵解锁了",
	NumCap = 5,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG01",
	StartScene = "RPG_StartScene",
	TeamCondition = {
		{
			Condition = "TeamCharacterIdOr",
			Value = 
			{
				220014,
			},
			Desc = "队伍中必须有城镇卫兵",
			Hint = "队伍中必须有城镇卫兵",
		},
	},
	Enemy = {
		{
			Value = 244019,
			Level = 35,
		},
	},
}
ChallengeConfig[ChallengeID.Id4016] =
{
	Id = 4016,
	Name = "挑战：算命商人",
	UnlockCostList = {
		{
			Value = 320101,
			Num = 1,
		},
	},
	Character = 220015,
	AcceptSpeech = 14401601,
	Desc = "每当旅行商人没钱进货的时候，他就会拿出这套装备，从事那些无本买卖，比如：看相鉴运，风水命理，趋吉避凶，祈福除祸，还能算五行，算八卦，算中宫，测仕途，测财行，测爱情，定紫微，定北斗等等等等。",
	RewardUnlock = 232016,
	ResultText = "算命商人解锁了",
	NumCap = 5,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG01",
	StartScene = "RPG_StartScene",
	TeamCondition = {
		{
			Condition = "TeamCharacterIdOr",
			Value = 
			{
				220015,
			},
			Desc = "队伍中必须有旅行商人",
			Hint = "队伍中必须有旅行商人",
		},
	},
	Enemy = {
		{
			Value = 244020,
			Level = 25,
		},
	},
}
ChallengeConfig[ChallengeID.Id4017] =
{
	Id = 4017,
	Name = "挑战：两栖小妖",
	UnlockCostList = {
		{
			Value = 320101,
			Num = 1,
		},
	},
	Character = 220016,
	AcceptSpeech = 14401701,
	Desc = "为了尽快带领怪物们开展湿地副本的业务，小队长带头换上的两栖套装，虽然粘乎乎的很不舒服，但是可以很好地防止在泥地滑倒，而且湿湿滑滑的材料似乎有助于回血。",
	RewardUnlock = 232017,
	ResultText = "两栖小妖解锁了",
	NumCap = 5,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG03",
	StartScene = "RPG_StartScene",
	TeamCondition = {
		{
			Condition = "TeamCharacterIdOr",
			Value = 
			{
				220016,
			},
			Desc = "队伍中必须有小队长",
			Hint = "队伍中必须有小队长",
		},
	},
	Enemy = {
		{
			Value = 244021,
			Level = 25,
		},
	},
}
ChallengeConfig[ChallengeID.Id4018] =
{
	Id = 4018,
	Name = "挑战：雷普利",
	UnlockCostList = {
		{
			Value = 320102,
			Num = 1,
		},
	},
	Character = 220017,
	AcceptSpeech = 14401801,
	Desc = "经历过严重飞船事故的传奇英雄，雷普利在面对可怕的事物时展现出了非凡的勇气和毅力。",
	RewardUnlock = 232018,
	ResultText = "雷普利解锁了",
	NumCap = 5,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "STBG03",
	StartScene = "RPG_StartScene",
	TeamCondition = {
		{
			Condition = "TeamCharacterIdOr",
			Value = 
			{
				220017,
			},
			Desc = "队伍中必须有除虫者",
			Hint = "队伍中必须有除虫者",
		},
	},
	Enemy = {
		{
			Value = 244022,
			Level = 35,
		},
	},
}
ChallengeConfig[ChallengeID.Id4019] =
{
	Id = 4019,
	Name = "挑战：异形",
	UnlockCostList = {
		{
			Value = 320102,
			Num = 1,
		},
	},
	Character = 220018,
	AcceptSpeech = 14401901,
	Desc = "在实验室被制造出来的神秘生物，融入了多种生物的DNA，无论是速度或是杀伤力都是一流水准。",
	RewardUnlock = 232019,
	ResultText = "异形解锁了",
	NumCap = 5,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "STBG03",
	StartScene = "RPG_StartScene",
	TeamCondition = {
		{
			Condition = "TeamCharacterIdOr",
			Value = 
			{
				220018,
			},
			Desc = "队伍中必须有异虫霸格",
			Hint = "队伍中必须有异虫霸格",
		},
	},
	Enemy = {
		{
			Value = 244023,
			Level = 50,
		},
	},
}
ChallengeConfig[ChallengeID.Id4020] =
{
	Id = 4020,
	Name = "挑战：西部大镖客",
	UnlockCostList = {
		{
			Value = 320103,
			Num = 1,
		},
	},
	Character = 220019,
	AcceptSpeech = 14402001,
	Desc = "遥远世界的传奇枪手。在那个混乱的年代，他用他的正义与善良惩戒了邪恶，维护了正义。胆敢在他面前放肆的人，就要有身上多出几个窟窿的觉悟。",
	RewardUnlock = 232020,
	ResultText = "西部大镖客解锁了",
	NumCap = 5,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "SUSBG03",
	StartScene = "RPG_StartScene",
	TeamCondition = {
		{
			Condition = "TeamCharacterIdOr",
			Value = 
			{
				220019,
			},
			Desc = "队伍中必须有火枪手",
			Hint = "队伍中必须有火枪手",
		},
	},
	Enemy = {
		{
			Value = 244024,
			Level = 35,
		},
	},
}
ChallengeConfig[ChallengeID.Id4021] =
{
	Id = 4021,
	Name = "挑战：犬寻忍者",
	UnlockCostList = {
		{
			Value = 320104,
			Num = 1,
		},
	},
	Character = 220020,
	AcceptSpeech = 14402101,
	Desc = "忍者组织“犬寻组”的战斗服，只有流有狼族之血的少年才能加入。平时不从事战斗任务，主要活动内容是帮贵族们寻找仆人遛狗时走丢的宠物犬。",
	RewardUnlock = 232021,
	ResultText = "犬寻忍者解锁了",
	NumCap = 5,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG02",
	StartScene = "RPG_StartScene",
	TeamCondition = {
		{
			Condition = "TeamCharacterIdOr",
			Value = 
			{
				220020,
			},
			Desc = "队伍中必须有刺客",
			Hint = "队伍中必须有刺客",
		},
	},
	Enemy = {
		{
			Value = 244025,
			Level = 50,
		},
	},
}
ChallengeConfig[ChallengeID.Id4022] =
{
	Id = 4022,
	Name = "挑战：影刺客",
	UnlockCostList = {
		{
			Value = 320103,
			Num = 1,
		},
	},
	Character = 220020,
	AcceptSpeech = 14402201,
	Desc = "能够与黑暗完美融合的顶级战斗服，由暗影大师亲自缝制而成，兜帽处贴心地为刺客剪出了两个露耳朵的孔洞。",
	RewardUnlock = 232022,
	ResultText = "影刺客解锁了",
	NumCap = 5,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "SUSBG01",
	StartScene = "RPG_StartScene",
	TeamCondition = {
		{
			Condition = "TeamCharacterIdOr",
			Value = 
			{
				220020,
			},
			Desc = "队伍中必须有刺客",
			Hint = "队伍中必须有刺客",
		},
	},
	Enemy = {
		{
			Value = 244026,
			Level = 35,
		},
	},
}
ChallengeConfig[ChallengeID.Id4023] =
{
	Id = 4023,
	Name = "挑战：小奶牛",
	UnlockCostList = {
		{
			Value = 320103,
			Num = 1,
		},
	},
	Character = 220021,
	AcceptSpeech = 14402301,
	Desc = "农场特制的奶牛装，用以感谢牧师帮助牧场破获了特大牛奶浪费事件。当地的居民也因为之后及时补充了钙质，骨折好得更快了。",
	RewardUnlock = 232023,
	ResultText = "小奶牛解锁了",
	NumCap = 5,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG01",
	StartScene = "RPG_StartScene",
	TeamCondition = {
		{
			Condition = "TeamCharacterIdOr",
			Value = 
			{
				220021,
			},
			Desc = "队伍中必须有牧师",
			Hint = "队伍中必须有牧师",
		},
	},
	Enemy = {
		{
			Value = 244027,
			Level = 35,
		},
		{
			Value = 244028,
			Level = 35,
		},
		{
			Value = 244029,
			Level = 35,
		},
	},
}
ChallengeConfig[ChallengeID.Id4024] =
{
	Id = 4024,
	Name = "挑战：小护士",
	UnlockCostList = {
		{
			Value = 320103,
			Num = 1,
		},
	},
	Character = 220021,
	AcceptSpeech = 14402401,
	Desc = "整洁卫生的护士装，给人眼前一亮的感觉。同时取现代医学与古老奇迹之长处，将补血工作发挥到了极致。",
	RewardUnlock = 232024,
	ResultText = "小护士解锁了",
	NumCap = 5,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG01",
	StartScene = "RPG_StartScene",
	TeamCondition = {
		{
			Condition = "TeamCharacterIdOr",
			Value = 
			{
				220021,
			},
			Desc = "队伍中必须有牧师",
			Hint = "队伍中必须有牧师",
		},
	},
	Enemy = {
		{
			Value = 244030,
			Level = 35,
		},
	},
}
ChallengeConfig[ChallengeID.Id4025] =
{
	Id = 4025,
	Name = "挑战：鬼话面具",
	UnlockCostList = {
		{
			Value = 320103,
			Num = 1,
		},
	},
	Character = 220022,
	AcceptSpeech = 14402501,
	Desc = "鬼怪星特产的妖怪面具，动画师一直宣称是为了换个心情才买来的，其实是为了遮掩长长的鼻子。",
	RewardUnlock = 232025,
	ResultText = "鬼话面具解锁了",
	NumCap = 5,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG05",
	StartScene = "RPG_StartScene",
	TeamCondition = {
		{
			Condition = "TeamCharacterIdOr",
			Value = 
			{
				220022,
			},
			Desc = "队伍中必须有动画师",
			Hint = "队伍中必须有动画师",
		},
	},
	Enemy = {
		{
			Value = 244031,
			Level = 35,
		},
		{
			Value = 244032,
			Level = 35,
		},
		{
			Value = 244033,
			Level = 35,
		},
	},
}
ChallengeConfig[ChallengeID.Id4026] =
{
	Id = 4026,
	Name = "挑战：偶像歌手",
	UnlockCostList = {
		{
			Value = 320102,
			Num = 1,
		},
	},
	Character = 220023,
	AcceptSpeech = 14402601,
	Desc = "元气十足的偶像团表演服，用这个为村里的NPC们表演，会让大家更有活力噢~",
	RewardUnlock = 232026,
	ResultText = "偶像歌手解锁了",
	NumCap = 5,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG02",
	StartScene = "RPG_StartScene",
	TeamCondition = {
		{
			Condition = "TeamCharacterIdOr",
			Value = 
			{
				220023,
			},
			Desc = "队伍中必须有配音演员",
			Hint = "队伍中必须有配音演员",
		},
	},
	Enemy = {
		{
			Value = 244034,
			Level = 25,
		},
	},
}
ChallengeConfig[ChallengeID.Id4027] =
{
	Id = 4027,
	Name = "挑战：外派程序猿",
	UnlockCostList = {
		{
			Value = 320103,
			Num = 1,
		},
	},
	Character = 220024,
	AcceptSpeech = 14402701,
	Desc = "无论是战争地区还是极端环境，只要对方有需求，外派程序猿就会火速抵达。",
	RewardUnlock = 232027,
	ResultText = "外派程序猿解锁了",
	NumCap = 5,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "SUSBG04",
	StartScene = "RPG_StartScene",
	TeamCondition = {
		{
			Condition = "TeamCharacterIdOr",
			Value = 
			{
				220024,
			},
			Desc = "队伍中必须有程序猿",
			Hint = "队伍中必须有程序猿",
		},
	},
	Enemy = {
		{
			Value = 244035,
			Level = 35,
		},
		{
			Value = 244036,
			Level = 35,
		},
		{
			Value = 244037,
			Level = 35,
		},
	},
}
ChallengeConfig[ChallengeID.Id4028] =
{
	Id = 4028,
	Name = "挑战：潜水高手",
	UnlockCostList = {
		{
			Value = 320103,
			Num = 1,
		},
	},
	Character = 220025,
	AcceptSpeech = 14402801,
	Desc = "使用高档鲨鱼皮制作的潜水衣，在水里的速度接近音速，达到音速时还会瞬间产生音爆。",
	RewardUnlock = 232028,
	ResultText = "潜水高手解锁了",
	NumCap = 5,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG01",
	StartScene = "RPG_StartScene",
	TeamCondition = {
		{
			Condition = "TeamCharacterIdOr",
			Value = 
			{
				220025,
			},
			Desc = "队伍中必须有美术妹子",
			Hint = "队伍中必须有美术妹子",
		},
	},
	Enemy = {
		{
			Value = 244038,
			Level = 35,
		},
	},
}
ChallengeConfig[ChallengeID.Id4029] =
{
	Id = 4029,
	Name = "挑战：美杜莎",
	UnlockCostList = {
		{
			Value = 320105,
			Num = 1,
		},
	},
	Character = 220029,
	AcceptSpeech = 14402901,
	Desc = "制作考究的华丽长袍，只要穿上它就能再现古老神话中的美杜莎形象，连围脖处的蛇头都栩栩如生，吐着信子，逼视着对手噢~",
	RewardUnlock = 232036,
	ResultText = "美杜莎解锁了",
	NumCap = 5,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG04",
	StartScene = "RPG_StartScene",
	TeamCondition = {
		{
			Condition = "TeamCharacterIdOr",
			Value = 
			{
				220029,
			},
			Desc = "队伍中必须有大魔王",
			Hint = "队伍中必须有大魔王",
		},
	},
	Enemy = {
		{
			Value = 244039,
			Level = 50,
		},
	},
}
ChallengeConfig[ChallengeID.Id4030] =
{
	Id = 4030,
	Name = "挑战：末日大魔王",
	UnlockCostList = {
		{
			Value = 320105,
			Num = 1,
		},
	},
	Character = 220029,
	AcceptSpeech = 14403001,
	Desc = "名为“末日”的魔族战甲，相传是魔族最强宝具，在魔族与龙族的战争中遗失，至今下落不明。不过在大魔王不懈的努力下， 终于复归魔王集团。穿上末日战甲的大魔王实力也更上了一个台阶。",
	RewardUnlock = 232037,
	ResultText = "末日大魔王解锁了",
	NumCap = 5,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG04",
	StartScene = "RPG_StartScene",
	TeamCondition = {
		{
			Condition = "TeamCharacterIdOr",
			Value = 
			{
				220029,
			},
			Desc = "队伍中必须有大魔王",
			Hint = "队伍中必须有大魔王",
		},
	},
	Enemy = {
		{
			Value = 244040,
			Level = 75,
		},
	},
}
ChallengeConfig[ChallengeID.Id4031] =
{
	Id = 4031,
	Name = "挑战：董事长的威严",
	UnlockCostList = {
		{
			Value = 320105,
			Num = 1,
		},
	},
	Character = 220029,
	AcceptSpeech = 14403101,
	Desc = "大魔王每次出席集团会议时的标准服装，看似藏起了强大的气场，不过实际上让会议上的气氛更紧张了。",
	RewardUnlock = 232038,
	ResultText = "董事长的威严解锁了",
	NumCap = 5,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG04",
	StartScene = "RPG_StartScene",
	TeamCondition = {
		{
			Condition = "TeamCharacterIdOr",
			Value = 
			{
				220029,
			},
			Desc = "队伍中必须有大魔王",
			Hint = "队伍中必须有大魔王",
		},
	},
	Enemy = {
		{
			Value = 244041,
			Level = 50,
		},
	},
}
ChallengeConfig[ChallengeID.Id4032] =
{
	Id = 4032,
	Name = "挑战：驯龙高手",
	UnlockCostList = {
		{
			Value = 320104,
			Num = 1,
		},
	},
	Character = 220026,
	AcceptSpeech = 14403201,
	Desc = "据说北境的末日火山每过三十年都会重新活动，火之恶龙也将浴火重生。龙骑士凭借着出色的斩龙技术，消灭了那一年重生的火龙之王。也因此，北境长老将这套使用龙火淬炼而成的驯龙战甲赠予了她，并封她为“驯龙高手”。",
	RewardUnlock = 232029,
	ResultText = "驯龙高手解锁了",
	NumCap = 5,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG05",
	StartScene = "RPG_StartScene",
	TeamCondition = {
		{
			Condition = "TeamCharacterIdOr",
			Value = 
			{
				220026,
			},
			Desc = "队伍中必须有龙骑士",
			Hint = "队伍中必须有龙骑士",
		},
	},
	Enemy = {
		{
			Value = 244042,
			Level = 50,
		},
	},
}
ChallengeConfig[ChallengeID.Id4033] =
{
	Id = 4033,
	Name = "挑战：麒麟天装",
	UnlockCostList = {
		{
			Value = 320105,
			Num = 1,
		},
	},
	Character = 220026,
	AcceptSpeech = 14403301,
	Desc = "使用罕见的麒麟素材制作完成的天级战斗套装，能够大幅提升穿戴者的战斗力。身上迸发的闪电火花，就如同雷神降临一般。",
	RewardUnlock = 232030,
	ResultText = "麒麟天装解锁了",
	NumCap = 5,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG01",
	StartScene = "RPG_StartScene",
	TeamCondition = {
		{
			Condition = "TeamCharacterIdOr",
			Value = 
			{
				220026,
			},
			Desc = "队伍中必须有龙骑士",
			Hint = "队伍中必须有龙骑士",
		},
	},
	Enemy = {
		{
			Value = 244043,
			Level = 75,
		},
	},
}
ChallengeConfig[ChallengeID.Id4034] =
{
	Id = 4034,
	Name = "挑战：龙太子",
	UnlockCostList = {
		{
			Value = 320104,
			Num = 1,
		},
	},
	Character = 220027,
	AcceptSpeech = 14403401,
	Desc = "是根据《哪吒闹海》中的经典角色形象制作的服装。黑龙王子很为三太子的命运感到唏嘘。",
	RewardUnlock = 232031,
	ResultText = "龙太子解锁了",
	NumCap = 5,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG01",
	StartScene = "RPG_StartScene",
	TeamCondition = {
		{
			Condition = "TeamCharacterIdOr",
			Value = 
			{
				220027,
			},
			Desc = "队伍中必须有黑龙王子",
			Hint = "队伍中必须有黑龙王子",
		},
	},
	Enemy = {
		{
			Value = 244044,
			Level = 50,
		},
	},
}
ChallengeConfig[ChallengeID.Id4035] =
{
	Id = 4035,
	Name = "挑战：海龙王",
	UnlockCostList = {
		{
			Value = 320104,
			Num = 1,
		},
	},
	Character = 220027,
	AcceptSpeech = 14403501,
	Desc = "拥有地方布雨权的海龙王，是黑龙王子的前世。因为与人打赌，最后遭天庭惩罚。一千年后，一位算命商人将他前世的回忆及法力交还了他。",
	RewardUnlock = 232032,
	ResultText = "海龙王解锁了",
	NumCap = 5,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG01",
	StartScene = "RPG_StartScene",
	TeamCondition = {
		{
			Condition = "TeamCharacterIdOr",
			Value = 
			{
				220027,
			},
			Desc = "队伍中必须有黑龙王子",
			Hint = "队伍中必须有黑龙王子",
		},
	},
	Enemy = {
		{
			Value = 244045,
			Level = 50,
		},
	},
}
ChallengeConfig[ChallengeID.Id4036] =
{
	Id = 4036,
	Name = "挑战：黑暗女王",
	UnlockCostList = {
		{
			Value = 320104,
			Num = 1,
		},
	},
	Character = 220028,
	AcceptSpeech = 14403601,
	Desc = "被黑夜祝福的礼服套装，来福和旺财也有对应的装扮噢~换上这身装备，就可以在黑夜中行动自如了。",
	RewardUnlock = 232033,
	ResultText = "黑暗女王解锁了",
	NumCap = 5,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG01",
	StartScene = "RPG_StartScene",
	TeamCondition = {
		{
			Condition = "TeamCharacterIdOr",
			Value = 
			{
				220028,
			},
			Desc = "队伍中必须有女王大人",
			Hint = "队伍中必须有女王大人",
		},
	},
	Enemy = {
		{
			Value = 244046,
			Level = 50,
		},
	},
}
ChallengeConfig[ChallengeID.Id4037] =
{
	Id = 4037,
	Name = "挑战：光之女王",
	UnlockCostList = {
		{
			Value = 320104,
			Num = 1,
		},
	},
	Character = 220028,
	AcceptSpeech = 14403701,
	Desc = "被光明祝福的礼服套装，来福和旺财也有对应的装扮噢~换上这身装备，就可以在晃眼的日光下行动自如了。",
	RewardUnlock = 232034,
	ResultText = "光之女王解锁了",
	NumCap = 5,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG01",
	StartScene = "RPG_StartScene",
	TeamCondition = {
		{
			Condition = "TeamCharacterIdOr",
			Value = 
			{
				220028,
			},
			Desc = "队伍中必须有女王大人",
			Hint = "队伍中必须有女王大人",
		},
	},
	Enemy = {
		{
			Value = 244047,
			Level = 50,
		},
	},
}
ChallengeConfig[ChallengeID.Id4038] =
{
	Id = 4038,
	Name = "挑战：女王登基",
	UnlockCostList = {
		{
			Value = 320105,
			Num = 1,
		},
	},
	Character = 220028,
	AcceptSpeech = 14403801,
	Desc = "女王登基仪式上用到的王权礼服，经历过登基仪式后，女王大人将正式得到城堡的管理权，同时能够提议修改法典，从此，女王就能随意出行，而不必担心被魔王集团绑架，以及被大小勇者带回城堡了。",
	RewardUnlock = 232035,
	ResultText = "女王登基解锁了",
	NumCap = 5,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG01",
	StartScene = "RPG_StartScene",
	TeamCondition = {
		{
			Condition = "TeamCharacterIdOr",
			Value = 
			{
				220028,
			},
			Desc = "队伍中必须有女王大人",
			Hint = "队伍中必须有女王大人",
		},
	},
	Enemy = {
		{
			Value = 244048,
			Level = 75,
		},
	},
}
ChallengeConfig[ChallengeID.Id4039] =
{
	Id = 4039,
	Name = "挑战：抹茶王子",
	UnlockCostList = {
		{
			Value = 320102,
			Num = 1,
		},
	},
	Character = 220101,
	AcceptSpeech = 14403901,
	Desc = "健康的抹茶加入奶茶，奶茶也就变得健康了起来，对吧。\n那么，是不是可以放心喝了呢~",
	RewardUnlock = 232039,
	ResultText = "抹茶王子解锁了",
	NumCap = 5,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "FATBG03",
	StartScene = "FAT_StartScene",
	TeamCondition = {
		{
			Condition = "TeamCharacterIdOr",
			Value = 
			{
				220101,
			},
			Desc = "队伍中必须有奶茶王子",
			Hint = "队伍中必须有奶茶王子",
		},
	},
	Enemy = {
		{
			Value = 244049,
			Level = 25,
		},
	},
}
ChallengeConfig[ChallengeID.Id4040] =
{
	Id = 4040,
	Name = "挑战：柠檬雪碧王子",
	UnlockCostList = {
		{
			Value = 320102,
			Num = 1,
		},
	},
	Character = 220102,
	AcceptSpeech = 14404001,
	Desc = "加入整颗鲜柠檬的酸味汽水，没有防备的话一口喝下去绝对会酸得把整张脸拧在一块儿。",
	RewardUnlock = 232040,
	ResultText = "柠檬雪碧王子解锁了",
	NumCap = 5,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG01",
	StartScene = "FAT_StartScene",
	TeamCondition = {
		{
			Condition = "TeamCharacterIdOr",
			Value = 
			{
				220102,
			},
			Desc = "队伍中必须有汽水王子",
			Hint = "队伍中必须有汽水王子",
		},
	},
	Enemy = {
		{
			Value = 244050,
			Level = 25,
		},
	},
}
ChallengeConfig[ChallengeID.Id4041] =
{
	Id = 4041,
	Name = "挑战：红蓝王子",
	UnlockCostList = {
		{
			Value = 320103,
			Num = 1,
		},
	},
	Character = 220103,
	AcceptSpeech = 14404101,
	Desc = "迈向国际化的第一步，可乐的外套也不一定就非要穿红色的对吧，对吧？",
	RewardUnlock = 232041,
	ResultText = "红蓝王子解锁了",
	NumCap = 5,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG01",
	StartScene = "FAT_StartScene",
	TeamCondition = {
		{
			Condition = "TeamCharacterIdOr",
			Value = 
			{
				220103,
			},
			Desc = "队伍中必须有可乐王子",
			Hint = "队伍中必须有可乐王子",
		},
	},
	Enemy = {
		{
			Value = 244051,
			Level = 35,
		},
	},
}
ChallengeConfig[ChallengeID.Id4042] =
{
	Id = 4042,
	Name = "挑战：樱花王子",
	UnlockCostList = {
		{
			Value = 320102,
			Num = 1,
		},
	},
	Character = 220103,
	AcceptSpeech = 14404201,
	Desc = "充满异域风情的樱花礼服，使得王子原本的汽水口味也变得淡雅起来。",
	RewardUnlock = 232042,
	ResultText = "樱花王子解锁了",
	NumCap = 5,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG01",
	StartScene = "FAT_StartScene",
	TeamCondition = {
		{
			Condition = "TeamCharacterIdOr",
			Value = 
			{
				220103,
			},
			Desc = "队伍中必须有可乐王子",
			Hint = "队伍中必须有可乐王子",
		},
	},
	Enemy = {
		{
			Value = 244052,
			Level = 25,
		},
	},
}
ChallengeConfig[ChallengeID.Id4043] =
{
	Id = 4043,
	Name = "挑战：零度王子",
	UnlockCostList = {
		{
			Value = 320102,
			Num = 1,
		},
	},
	Character = 220103,
	AcceptSpeech = 14404301,
	Desc = "保留经典口味的同时，给予了消费者无糖无热量的体验。希望同时享受美味和健康吗？这可能是一个非常好的选择~",
	RewardUnlock = 232043,
	ResultText = "零度王子解锁了",
	NumCap = 5,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG01",
	StartScene = "FAT_StartScene",
	TeamCondition = {
		{
			Condition = "TeamCharacterIdOr",
			Value = 
			{
				220103,
			},
			Desc = "队伍中必须有可乐王子",
			Hint = "队伍中必须有可乐王子",
		},
	},
	Enemy = {
		{
			Value = 244053,
			Level = 25,
		},
	},
}
ChallengeConfig[ChallengeID.Id4044] =
{
	Id = 4044,
	Name = "挑战：鸡尾酒王子",
	UnlockCostList = {
		{
			Value = 320102,
			Num = 1,
		},
	},
	Character = 220104,
	AcceptSpeech = 14404401,
	Desc = "这变幻莫测的魔力颜色，究竟是本来的颜色，还是醉了之后心中的幻想呢？",
	RewardUnlock = 232044,
	ResultText = "鸡尾酒王子解锁了",
	NumCap = 5,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG01",
	StartScene = "FAT_StartScene",
	TeamCondition = {
		{
			Condition = "TeamCharacterIdOr",
			Value = 
			{
				220104,
			},
			Desc = "队伍中必须有啤酒王子",
			Hint = "队伍中必须有啤酒王子",
		},
	},
	Enemy = {
		{
			Value = 244054,
			Level = 25,
		},
	},
}
ChallengeConfig[ChallengeID.Id4045] =
{
	Id = 4045,
	Name = "挑战：草莓果冻",
	UnlockCostList = {
		{
			Value = 320101,
			Num = 1,
		},
	},
	Character = 220105,
	AcceptSpeech = 14404501,
	Desc = "草莓味的果冻装，一口一个小草莓",
	RewardUnlock = 232045,
	ResultText = "草莓果冻解锁了",
	NumCap = 5,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG01",
	StartScene = "FAT_StartScene",
	TeamCondition = {
		{
			Condition = "TeamCharacterIdOr",
			Value = 
			{
				220105,
			},
			Desc = "队伍中必须有小红",
			Hint = "队伍中必须有小红",
		},
		{
			Condition = "NeedTagAnd",
			Value = 
			{
				562909,
			},
			Desc = "必须是糖豆组的队员",
			Hint = "必须是糖豆组的队员",
		},
	},
	Enemy = {
		{
			Value = 244055,
			Level = 15,
		},
	},
}
ChallengeConfig[ChallengeID.Id4046] =
{
	Id = 4046,
	Name = "挑战：桔子果冻",
	UnlockCostList = {
		{
			Value = 320101,
			Num = 1,
		},
	},
	Character = 220106,
	AcceptSpeech = 14404601,
	Desc = "橘子味的果冻装，一口吸不够",
	RewardUnlock = 232046,
	ResultText = "桔子果冻解锁了",
	NumCap = 5,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG01",
	StartScene = "FAT_StartScene",
	TeamCondition = {
		{
			Condition = "TeamCharacterIdOr",
			Value = 
			{
				220106,
			},
			Desc = "队伍中必须有小橙",
			Hint = "队伍中必须有小橙",
		},
		{
			Condition = "NeedTagAnd",
			Value = 
			{
				562909,
			},
			Desc = "必须是糖豆组的队员",
			Hint = "必须是糖豆组的队员",
		},
	},
	Enemy = {
		{
			Value = 244056,
			Level = 15,
		},
	},
}
ChallengeConfig[ChallengeID.Id4047] =
{
	Id = 4047,
	Name = "挑战：柠檬果冻",
	UnlockCostList = {
		{
			Value = 320101,
			Num = 1,
		},
	},
	Character = 220107,
	AcceptSpeech = 14404701,
	Desc = "柠檬味的果冻装，一口下去有点酸",
	RewardUnlock = 232047,
	ResultText = "柠檬果冻解锁了",
	NumCap = 5,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG01",
	StartScene = "FAT_StartScene",
	TeamCondition = {
		{
			Condition = "TeamCharacterIdOr",
			Value = 
			{
				220107,
			},
			Desc = "队伍中必须有小黄",
			Hint = "队伍中必须有小黄",
		},
		{
			Condition = "NeedTagAnd",
			Value = 
			{
				562909,
			},
			Desc = "必须是糖豆组的队员",
			Hint = "必须是糖豆组的队员",
		},
	},
	Enemy = {
		{
			Value = 244057,
			Level = 15,
		},
	},
}
ChallengeConfig[ChallengeID.Id4048] =
{
	Id = 4048,
	Name = "挑战：芥末果冻",
	UnlockCostList = {
		{
			Value = 320101,
			Num = 1,
		},
	},
	Character = 220108,
	AcceptSpeech = 14404801,
	Desc = "芥末味的果冻装，一口下去有点冲",
	RewardUnlock = 232048,
	ResultText = "芥末果冻解锁了",
	NumCap = 5,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG01",
	StartScene = "FAT_StartScene",
	TeamCondition = {
		{
			Condition = "TeamCharacterIdOr",
			Value = 
			{
				220108,
			},
			Desc = "队伍中必须有小绿",
			Hint = "队伍中必须有小绿",
		},
		{
			Condition = "NeedTagAnd",
			Value = 
			{
				562909,
			},
			Desc = "必须是糖豆组的队员",
			Hint = "必须是糖豆组的队员",
		},
	},
	Enemy = {
		{
			Value = 244058,
			Level = 15,
		},
	},
}
ChallengeConfig[ChallengeID.Id4049] =
{
	Id = 4049,
	Name = "挑战：牛油果果冻",
	UnlockCostList = {
		{
			Value = 320101,
			Num = 1,
		},
	},
	Character = 220109,
	AcceptSpeech = 14404901,
	Desc = "牛油果味的果冻装，一口怕腻先舔舔",
	RewardUnlock = 232049,
	ResultText = "牛油果果冻解锁了",
	NumCap = 5,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG01",
	StartScene = "FAT_StartScene",
	TeamCondition = {
		{
			Condition = "TeamCharacterIdOr",
			Value = 
			{
				220109,
			},
			Desc = "队伍中必须有小青",
			Hint = "队伍中必须有小青",
		},
		{
			Condition = "NeedTagAnd",
			Value = 
			{
				562909,
			},
			Desc = "必须是糖豆组的队员",
			Hint = "必须是糖豆组的队员",
		},
	},
	Enemy = {
		{
			Value = 244059,
			Level = 15,
		},
	},
}
ChallengeConfig[ChallengeID.Id4050] =
{
	Id = 4050,
	Name = "挑战：薄荷果冻",
	UnlockCostList = {
		{
			Value = 320101,
			Num = 1,
		},
	},
	Character = 220110,
	AcceptSpeech = 14405001,
	Desc = "薄荷味的果冻装，一口吸到最深处",
	RewardUnlock = 232050,
	ResultText = "薄荷果冻解锁了",
	NumCap = 5,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG01",
	StartScene = "FAT_StartScene",
	TeamCondition = {
		{
			Condition = "TeamCharacterIdOr",
			Value = 
			{
				220110,
			},
			Desc = "队伍中必须有小蓝",
			Hint = "队伍中必须有小蓝",
		},
		{
			Condition = "NeedTagAnd",
			Value = 
			{
				562909,
			},
			Desc = "必须是糖豆组的队员",
			Hint = "必须是糖豆组的队员",
		},
	},
	Enemy = {
		{
			Value = 244060,
			Level = 15,
		},
	},
}
ChallengeConfig[ChallengeID.Id4051] =
{
	Id = 4051,
	Name = "挑战：葡萄果冻",
	UnlockCostList = {
		{
			Value = 320101,
			Num = 1,
		},
	},
	Character = 220111,
	AcceptSpeech = 14405101,
	Desc = "葡萄味的果冻装，一口一个小甜蜜",
	RewardUnlock = 232051,
	ResultText = "葡萄果冻解锁了",
	NumCap = 5,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG01",
	StartScene = "FAT_StartScene",
	TeamCondition = {
		{
			Condition = "TeamCharacterIdOr",
			Value = 
			{
				220111,
			},
			Desc = "队伍中必须有小紫",
			Hint = "队伍中必须有小紫",
		},
		{
			Condition = "NeedTagAnd",
			Value = 
			{
				562909,
			},
			Desc = "必须是糖豆组的队员",
			Hint = "必须是糖豆组的队员",
		},
	},
	Enemy = {
		{
			Value = 244061,
			Level = 15,
		},
	},
}
ChallengeConfig[ChallengeID.Id4052] =
{
	Id = 4052,
	Name = "挑战：糖果代言人",
	UnlockCostList = {
		{
			Value = 320101,
			Num = 1,
		},
	},
	Character = 220112,
	AcceptSpeech = 14405201,
	Desc = "糖果公司的代理人套装，需要经过重重考验才能选拔通过。穿上这套衣服，就能开始糖果公司代言人的工作，也让棒棒糖女仆离振兴家业又更近了一步。",
	RewardUnlock = 232052,
	ResultText = "糖果代言人解锁了",
	NumCap = 5,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "FATBG03",
	StartScene = "FAT_StartScene",
	TeamCondition = {
		{
			Condition = "TeamCharacterIdOr",
			Value = 
			{
				220112,
			},
			Desc = "队伍中必须有棒棒糖女仆",
			Hint = "队伍中必须有棒棒糖女仆",
		},
	},
	Enemy = {
		{
			Value = 244062,
			Level = 25,
		},
	},
}
ChallengeConfig[ChallengeID.Id4053] =
{
	Id = 4053,
	Name = "挑战：橙味咖啡女仆",
	UnlockCostList = {
		{
			Value = 320101,
			Num = 1,
		},
	},
	Character = 220113,
	AcceptSpeech = 14405301,
	Desc = "感觉是有点黑暗料理的全新饮品，由KCF不怕死开发组诚意推出。",
	RewardUnlock = 232053,
	ResultText = "橙味咖啡女仆解锁了",
	NumCap = 5,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG01",
	StartScene = "FAT_StartScene",
	TeamCondition = {
		{
			Condition = "TeamCharacterIdOr",
			Value = 
			{
				220113,
			},
			Desc = "队伍中必须有咖啡女仆",
			Hint = "队伍中必须有咖啡女仆",
		},
	},
	Enemy = {
		{
			Value = 244063,
			Level = 25,
		},
	},
}
ChallengeConfig[ChallengeID.Id4054] =
{
	Id = 4054,
	Name = "挑战：软糖仙子",
	UnlockCostList = {
		{
			Value = 320101,
			Num = 1,
		},
	},
	Character = 220114,
	AcceptSpeech = 14405401,
	Desc = "限量贩售的仙子服，每颗软糖都是来自糖果镇的高级工厂，色泽和软度都是一流的。穿上它以后，华夫饼仙子感觉更有活力了呢~",
	RewardUnlock = 232054,
	ResultText = "软糖仙子解锁了",
	NumCap = 5,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG01",
	StartScene = "FAT_StartScene",
	TeamCondition = {
		{
			Condition = "TeamCharacterIdOr",
			Value = 
			{
				220114,
			},
			Desc = "队伍中必须有华夫饼仙子",
			Hint = "队伍中必须有华夫饼仙子",
		},
	},
	Enemy = {
		{
			Value = 244064,
			Level = 25,
		},
	},
}
ChallengeConfig[ChallengeID.Id4055] =
{
	Id = 4055,
	Name = "挑战：舒芙蕾仙子",
	UnlockCostList = {
		{
			Value = 320101,
			Num = 1,
		},
	},
	Character = 220115,
	AcceptSpeech = 14405501,
	Desc = "松饼仙子在舒芙蕾的发源地得到的最高级换装，是甜品界公认最难制作的衣服，可能没有之一，极具收藏价值。",
	RewardUnlock = 232055,
	ResultText = "舒芙蕾仙子解锁了",
	NumCap = 5,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG01",
	StartScene = "FAT_StartScene",
	TeamCondition = {
		{
			Condition = "TeamCharacterIdOr",
			Value = 
			{
				220115,
			},
			Desc = "队伍中必须有松饼仙子",
			Hint = "队伍中必须有松饼仙子",
		},
	},
	Enemy = {
		{
			Value = 244065,
			Level = 25,
		},
	},
}
ChallengeConfig[ChallengeID.Id4056] =
{
	Id = 4056,
	Name = "挑战：樱花布丁仙子",
	UnlockCostList = {
		{
			Value = 320101,
			Num = 1,
		},
	},
	Character = 220116,
	AcceptSpeech = 14405601,
	Desc = "仙子礼服店推出的季节限定套装，裙摆处点缀了大量的樱花花瓣。清风吹过时，还会有伴着一阵清幽的花香噢~",
	RewardUnlock = 232056,
	ResultText = "樱花布丁仙子解锁了",
	NumCap = 5,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG01",
	StartScene = "FAT_StartScene",
	TeamCondition = {
		{
			Condition = "TeamCharacterIdOr",
			Value = 
			{
				220116,
			},
			Desc = "队伍中必须有布丁仙子",
			Hint = "队伍中必须有布丁仙子",
		},
	},
	Enemy = {
		{
			Value = 244066,
			Level = 25,
		},
	},
}
ChallengeConfig[ChallengeID.Id4057] =
{
	Id = 4057,
	Name = "挑战：麻花小姐",
	UnlockCostList = {
		{
			Value = 320101,
			Num = 1,
		},
	},
	Character = 220117,
	AcceptSpeech = 14405701,
	Desc = "虾条小姐尝遍美食之后，体重慢慢的发生了变化，为了穿上以前的衣服，只能悄悄改变一下体型。",
	RewardUnlock = 232057,
	ResultText = "麻花小姐解锁了",
	NumCap = 5,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG01",
	StartScene = "FAT_StartScene",
	TeamCondition = {
		{
			Condition = "TeamCharacterIdOr",
			Value = 
			{
				220117,
			},
			Desc = "队伍中必须有虾条小姐",
			Hint = "队伍中必须有虾条小姐",
		},
	},
	Enemy = {
		{
			Value = 244067,
			Level = 25,
		},
	},
}
ChallengeConfig[ChallengeID.Id4058] =
{
	Id = 4058,
	Name = "挑战：洋葱圈小姐",
	UnlockCostList = {
		{
			Value = 320101,
			Num = 1,
		},
	},
	Character = 220118,
	AcceptSpeech = 14405801,
	Desc = "对温度需求比较高的洋葱圈服装，很多时候都是限定出场，不像妙脆角可以随便乱走。",
	RewardUnlock = 232058,
	ResultText = "洋葱圈小姐解锁了",
	NumCap = 5,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG01",
	StartScene = "FAT_StartScene",
	TeamCondition = {
		{
			Condition = "TeamCharacterIdOr",
			Value = 
			{
				220118,
			},
			Desc = "队伍中必须有妙脆角小姐",
			Hint = "队伍中必须有妙脆角小姐",
		},
	},
	Enemy = {
		{
			Value = 244068,
			Level = 25,
		},
	},
}
ChallengeConfig[ChallengeID.Id4059] =
{
	Id = 4059,
	Name = "挑战：烟熏三文鱼",
	UnlockCostList = {
		{
			Value = 320103,
			Num = 1,
		},
	},
	Character = 220119,
	AcceptSpeech = 14405901,
	Desc = "来自深海的优雅礼服，穿在培根女巫身上时，展现出了独特的异国风情。不过，明明三文鱼也有很多脂肪，为什么和培根比却是健康食品呢？",
	RewardUnlock = 232059,
	ResultText = "烟熏三文鱼解锁了",
	NumCap = 5,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "FATBG04",
	StartScene = "FAT_StartScene",
	TeamCondition = {
		{
			Condition = "TeamCharacterIdOr",
			Value = 
			{
				220119,
			},
			Desc = "队伍中必须有培根女巫",
			Hint = "队伍中必须有培根女巫",
		},
	},
	Enemy = {
		{
			Value = 244069,
			Level = 35,
		},
	},
}
ChallengeConfig[ChallengeID.Id4060] =
{
	Id = 4060,
	Name = "挑战：黄瓜片夫人",
	UnlockCostList = {
		{
			Value = 320103,
			Num = 1,
		},
	},
	Character = 220120,
	AcceptSpeech = 14406001,
	Desc = "不只是黄瓜味的薯片，是真正的黄瓜片，给你从头到底的清凉感受。而且不管怎么吃都不会胖。",
	RewardUnlock = 232060,
	ResultText = "黄瓜片夫人解锁了",
	NumCap = 5,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "SUSBG04",
	StartScene = "FAT_StartScene",
	TeamCondition = {
		{
			Condition = "TeamCharacterIdOr",
			Value = 
			{
				220120,
			},
			Desc = "队伍中必须有薯片夫人",
			Hint = "队伍中必须有薯片夫人",
		},
	},
	Enemy = {
		{
			Value = 244070,
			Level = 35,
		},
	},
}
ChallengeConfig[ChallengeID.Id4061] =
{
	Id = 4061,
	Name = "挑战：薄荷甜筒",
	UnlockCostList = {
		{
			Value = 320103,
			Num = 1,
		},
	},
	Character = 220121,
	AcceptSpeech = 14406101,
	Desc = "在被甜品包围的人群中，清新的薄荷之气一下子就能让自己成为人群焦点。",
	RewardUnlock = 232061,
	ResultText = "薄荷甜筒解锁了",
	NumCap = 5,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG01",
	StartScene = "FAT_StartScene",
	TeamCondition = {
		{
			Condition = "TeamCharacterIdOr",
			Value = 
			{
				220121,
			},
			Desc = "队伍中必须有黑巧克力皇后",
			Hint = "队伍中必须有黑巧克力皇后",
		},
	},
	Enemy = {
		{
			Value = 244071,
			Level = 35,
		},
	},
}
ChallengeConfig[ChallengeID.Id4062] =
{
	Id = 4062,
	Name = "挑战：烤棉花糖公主",
	UnlockCostList = {
		{
			Value = 320103,
			Num = 1,
		},
	},
	Character = 220122,
	AcceptSpeech = 14406201,
	Desc = "使用了魔法火焰烘烤之后，颜色更丰富，质感也更蓬松了，还有星星点点的装饰在周围转圈圈。",
	RewardUnlock = 232062,
	ResultText = "烤棉花糖公主解锁了",
	NumCap = 5,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG04",
	StartScene = "FAT_StartScene",
	TeamCondition = {
		{
			Condition = "TeamCharacterIdOr",
			Value = 
			{
				220122,
			},
			Desc = "队伍中必须有棉花糖公主",
			Hint = "队伍中必须有棉花糖公主",
		},
	},
	Enemy = {
		{
			Value = 244072,
			Level = 35,
		},
	},
}
ChallengeConfig[ChallengeID.Id4063] =
{
	Id = 4063,
	Name = "挑战：圣代公主",
	UnlockCostList = {
		{
			Value = 320103,
			Num = 1,
		},
	},
	Character = 220123,
	AcceptSpeech = 14406301,
	Desc = "又称为新地，最早只在星期日才允许能见到这华丽的公主衣裳，现在到处都能吃到了。",
	RewardUnlock = 232063,
	ResultText = "圣代公主解锁了",
	NumCap = 5,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG01",
	StartScene = "FAT_StartScene",
	TeamCondition = {
		{
			Condition = "NeedTagAnd",
			Value = 
			{
				562909,
			},
			Desc = "必须是糖豆组的队员",
			Hint = "必须是糖豆组的队员",
		},
	},
	Enemy = {
		{
			Value = 244073,
			Level = 35,
		},
	},
}
ChallengeConfig[ChallengeID.Id4064] =
{
	Id = 4064,
	Name = "挑战：寿司卷公主",
	UnlockCostList = {
		{
			Value = 320103,
			Num = 1,
		},
	},
	Character = 220124,
	AcceptSpeech = 14406401,
	Desc = "对蛋糕卷公主而言是一次特别的尝试，就好像甜的吃多了大家也会想换个口味。这件礼服是由寿司师傅们合力完成的，其中的醋饭都经过了多道调味工序，可以保证大家吃饱又吃不腻。",
	RewardUnlock = 232064,
	ResultText = "寿司卷公主解锁了",
	NumCap = 5,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "FATBG04",
	StartScene = "FAT_StartScene",
	TeamCondition = {
		{
			Condition = "TeamCharacterIdOr",
			Value = 
			{
				220124,
			},
			Desc = "队伍中必须有蛋糕卷公主",
			Hint = "队伍中必须有蛋糕卷公主",
		},
	},
	Enemy = {
		{
			Value = 244074,
			Level = 35,
		},
		{
			Value = 244075,
			Level = 35,
		},
		{
			Value = 244076,
			Level = 35,
		},
	},
}
ChallengeConfig[ChallengeID.Id4065] =
{
	Id = 4065,
	Name = "挑战：玫瑰蛋糕公主",
	UnlockCostList = {
		{
			Value = 320103,
			Num = 1,
		},
	},
	Character = 220125,
	AcceptSpeech = 14406501,
	Desc = "娇艳欲滴的玫瑰遮住了公主那一头美丽温柔的秀发，淡雅的玫瑰花香也隐蔽了公主那颗顶级栗子的香气。穿着这身华服，公主就可以随心所欲地去城市里游玩了~",
	RewardUnlock = 232065,
	ResultText = "玫瑰蛋糕公主解锁了",
	NumCap = 5,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG01",
	StartScene = "FAT_StartScene",
	TeamCondition = {
		{
			Condition = "TeamCharacterIdOr",
			Value = 
			{
				220125,
			},
			Desc = "队伍中必须有栗子蛋糕公主",
			Hint = "队伍中必须有栗子蛋糕公主",
		},
	},
	Enemy = {
		{
			Value = 244077,
			Level = 35,
		},
	},
}
ChallengeConfig[ChallengeID.Id4066] =
{
	Id = 4066,
	Name = "挑战：马卡龙小姐",
	UnlockCostList = {
		{
			Value = 320103,
			Num = 1,
		},
	},
	Character = 220126,
	AcceptSpeech = 14406601,
	Desc = "体型一下子减少了很多，但是热量可丝毫不容小觑。有人说马卡龙太甜了，其实按照正统吃法慢慢来的话会有很好的体验啦~",
	RewardUnlock = 232066,
	ResultText = "马卡龙小姐解锁了",
	NumCap = 5,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "SUSBG02",
	StartScene = "FAT_StartScene",
	TeamCondition = {
		{
			Condition = "TeamCharacterIdOr",
			Value = 
			{
				220126,
			},
			Desc = "队伍中必须有汉堡小姐",
			Hint = "队伍中必须有汉堡小姐",
		},
	},
	Enemy = {
		{
			Value = 244078,
			Level = 35,
		},
	},
}
ChallengeConfig[ChallengeID.Id4067] =
{
	Id = 4067,
	Name = "挑战：鸡肉卷先生",
	UnlockCostList = {
		{
			Value = 320103,
			Num = 1,
		},
	},
	Character = 220127,
	AcceptSpeech = 14406701,
	Desc = "在某个神秘的东方国家，宇宙无敌偶像的热狗先生遭遇了滑铁卢，取而代之的是年轻的鸡肉卷小弟。嗯，毕竟有脆脆的炸鸡呢！",
	RewardUnlock = 232067,
	ResultText = "鸡肉卷先生解锁了",
	NumCap = 5,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG01",
	StartScene = "FAT_StartScene",
	TeamCondition = {
		{
			Condition = "TeamCharacterIdOr",
			Value = 
			{
				220127,
			},
			Desc = "队伍中必须有热狗先生",
			Hint = "队伍中必须有热狗先生",
		},
	},
	Enemy = {
		{
			Value = 244079,
			Level = 35,
		},
	},
}
ChallengeConfig[ChallengeID.Id4068] =
{
	Id = 4068,
	Name = "挑战：豆豉辣酱侍卫",
	UnlockCostList = {
		{
			Value = 320103,
			Num = 1,
		},
	},
	Character = 220128,
	AcceptSpeech = 14406801,
	Desc = "薯条国王亲赐的卫士服，女神级别的套装。\n远远就能感受到酱香与干辣混合的气味，让人忍不住……想要再来三份饺子。",
	RewardUnlock = 232068,
	ResultText = "豆豉辣酱侍卫解锁了",
	NumCap = 5,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG01",
	StartScene = "FAT_StartScene",
	TeamCondition = {
		{
			Condition = "TeamCharacterIdOr",
			Value = 
			{
				220128,
			},
			Desc = "队伍中必须有番茄酱侍卫",
			Hint = "队伍中必须有番茄酱侍卫",
		},
		{
			Condition = "NeedTagAnd",
			Value = 
			{
				561702,
			},
			Desc = "必须是男的队员",
			Hint = "必须是男的队员",
		},
	},
	Enemy = {
		{
			Value = 244080,
			Level = 35,
		},
	},
}
ChallengeConfig[ChallengeID.Id4069] =
{
	Id = 4069,
	Name = "挑战：沙拉酱侍卫",
	UnlockCostList = {
		{
			Value = 320103,
			Num = 1,
		},
	},
	Character = 220128,
	AcceptSpeech = 14406901,
	Desc = "薯条国王亲赐的卫士服，健康而又适合调味的高级酱料。\n远远就能感受到酸甜的气息与浓郁的醇香，让人忍不住……就想要再来三份生菜。",
	RewardUnlock = 232069,
	ResultText = "沙拉酱侍卫解锁了",
	NumCap = 5,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG01",
	StartScene = "FAT_StartScene",
	TeamCondition = {
		{
			Condition = "TeamCharacterIdOr",
			Value = 
			{
				220128,
			},
			Desc = "队伍中必须有番茄酱侍卫",
			Hint = "队伍中必须有番茄酱侍卫",
		},
		{
			Condition = "NeedTagAnd",
			Value = 
			{
				561702,
			},
			Desc = "必须是男的队员",
			Hint = "必须是男的队员",
		},
	},
	Enemy = {
		{
			Value = 244081,
			Level = 35,
		},
	},
}
ChallengeConfig[ChallengeID.Id4070] =
{
	Id = 4070,
	Name = "挑战：巧克力酱侍卫",
	UnlockCostList = {
		{
			Value = 320103,
			Num = 1,
		},
	},
	Character = 220128,
	AcceptSpeech = 14407001,
	Desc = "薯条国王亲赐的卫士服，丝滑又香浓的套装。\n醇厚的可可豆香味，让人忍不住……就想要再来三份小饼干条。",
	RewardUnlock = 232070,
	ResultText = "巧克力酱侍卫解锁了",
	NumCap = 5,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG01",
	StartScene = "FAT_StartScene",
	TeamCondition = {
		{
			Condition = "TeamCharacterIdOr",
			Value = 
			{
				220128,
			},
			Desc = "队伍中必须有番茄酱侍卫",
			Hint = "队伍中必须有番茄酱侍卫",
		},
		{
			Condition = "NeedTagAnd",
			Value = 
			{
				561702,
			},
			Desc = "必须是男的队员",
			Hint = "必须是男的队员",
		},
	},
	Enemy = {
		{
			Value = 244082,
			Level = 35,
		},
	},
}
ChallengeConfig[ChallengeID.Id4071] =
{
	Id = 4071,
	Name = "挑战：辣条酋长",
	UnlockCostList = {
		{
			Value = 320105,
			Num = 1,
		},
	},
	Character = 220131,
	AcceptSpeech = 14407101,
	Desc = "来自遥远星球的神秘服装，对于穿戴者锻炼肌肉极有裨益，薯条国王穿上时，还展现出了非凡的野性气息。",
	RewardUnlock = 232077,
	ResultText = "辣条酋长解锁了",
	NumCap = 5,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG01",
	StartScene = "FAT_StartScene",
	TeamCondition = {
		{
			Condition = "TeamCharacterIdOr",
			Value = 
			{
				220131,
			},
			Desc = "队伍中必须有薯条国王",
			Hint = "队伍中必须有薯条国王",
		},
	},
	Enemy = {
		{
			Value = 244083,
			Level = 50,
		},
	},
}
ChallengeConfig[ChallengeID.Id4072] =
{
	Id = 4072,
	Name = "挑战：巧克力饼干条",
	UnlockCostList = {
		{
			Value = 320105,
			Num = 1,
		},
	},
	Character = 220131,
	AcceptSpeech = 14407201,
	Desc = "使用巧克力饼干制作的健身服，能够使穿戴者充满活力，薯条国王穿上时，让人觉得特别的和蔼可亲。",
	RewardUnlock = 232078,
	ResultText = "巧克力饼干条解锁了",
	NumCap = 5,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG01",
	StartScene = "FAT_StartScene",
	TeamCondition = {
		{
			Condition = "TeamCharacterIdOr",
			Value = 
			{
				220131,
			},
			Desc = "队伍中必须有薯条国王",
			Hint = "队伍中必须有薯条国王",
		},
	},
	Enemy = {
		{
			Value = 244084,
			Level = 75,
		},
	},
}
ChallengeConfig[ChallengeID.Id4073] =
{
	Id = 4073,
	Name = "挑战：旋风薯条国王",
	UnlockCostList = {
		{
			Value = 320105,
			Num = 1,
		},
	},
	Character = 220131,
	AcceptSpeech = 14407301,
	Desc = "由特制模具制成的高档健身服装，能够使穿戴者的头发自然卷曲起来，给人如同风暴降临的感觉。",
	RewardUnlock = 232079,
	ResultText = "旋风薯条国王解锁了",
	NumCap = 5,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG01",
	StartScene = "FAT_StartScene",
	TeamCondition = {
		{
			Condition = "TeamCharacterIdOr",
			Value = 
			{
				220131,
			},
			Desc = "队伍中必须有薯条国王",
			Hint = "队伍中必须有薯条国王",
		},
	},
	Enemy = {
		{
			Value = 244085,
			Level = 50,
		},
	},
}
ChallengeConfig[ChallengeID.Id4074] =
{
	Id = 4074,
	Name = "挑战：羊角魔后",
	UnlockCostList = {
		{
			Value = 320104,
			Num = 1,
		},
	},
	Character = 220129,
	AcceptSpeech = 14407401,
	Desc = "拥有草原风格的套装，羊角头饰尤其惹眼，让人忍不住想摸一下。炸鸡魔后穿上后整个人的气质也变得更温婉了。",
	RewardUnlock = 232071,
	ResultText = "羊角魔后解锁了",
	NumCap = 5,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG01",
	StartScene = "FAT_StartScene",
	TeamCondition = {
		{
			Condition = "TeamCharacterIdOr",
			Value = 
			{
				220129,
			},
			Desc = "队伍中必须有炸鸡魔后",
			Hint = "队伍中必须有炸鸡魔后",
		},
	},
	Enemy = {
		{
			Value = 244086,
			Level = 50,
		},
	},
}
ChallengeConfig[ChallengeID.Id4075] =
{
	Id = 4075,
	Name = "挑战：小龙包",
	UnlockCostList = {
		{
			Value = 320105,
			Num = 1,
		},
	},
	Character = 220129,
	AcceptSpeech = 14407501,
	Desc = "拥有武侠风格的套装，白衣飘飘，翩翩如仙，不过别致的头饰部分又让这身装扮层次变得更丰富，仿佛是在探讨古代侠士们的伙食问题。",
	RewardUnlock = 232072,
	ResultText = "小龙包解锁了",
	NumCap = 5,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG01",
	StartScene = "FAT_StartScene",
	TeamCondition = {
		{
			Condition = "TeamCharacterIdOr",
			Value = 
			{
				220129,
			},
			Desc = "队伍中必须有炸鸡魔后",
			Hint = "队伍中必须有炸鸡魔后",
		},
	},
	Enemy = {
		{
			Value = 244087,
			Level = 75,
		},
	},
}
ChallengeConfig[ChallengeID.Id4076] =
{
	Id = 4076,
	Name = "挑战：甜甜圈皇后",
	UnlockCostList = {
		{
			Value = 320104,
			Num = 1,
		},
	},
	Character = 220129,
	AcceptSpeech = 14407601,
	Desc = "热情又具有童话风格的套装，形状饱满的甜甜圈洋溢着甜腻的气味，吸引着沿途的小朋友和小蜜蜂噢~",
	RewardUnlock = 232073,
	ResultText = "甜甜圈皇后解锁了",
	NumCap = 5,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG01",
	StartScene = "FAT_StartScene",
	TeamCondition = {
		{
			Condition = "TeamCharacterIdOr",
			Value = 
			{
				220129,
			},
			Desc = "队伍中必须有炸鸡魔后",
			Hint = "队伍中必须有炸鸡魔后",
		},
	},
	Enemy = {
		{
			Value = 244088,
			Level = 50,
		},
	},
}
ChallengeConfig[ChallengeID.Id4077] =
{
	Id = 4077,
	Name = "挑战：五彩爆米花",
	UnlockCostList = {
		{
			Value = 320104,
			Num = 1,
		},
	},
	Character = 220130,
	AcceptSpeech = 14407701,
	Desc = "为了巩固各大院线的垄断地位，爆米花女王再次推出新品爆米花。看剧情片时，希望有更特别的零食？那你一定要尝试一下这款五彩爆米花，跌宕起伏的情节，就需要缤纷绚烂的爆米花。",
	RewardUnlock = 232074,
	ResultText = "五彩爆米花解锁了",
	NumCap = 5,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG01",
	StartScene = "FAT_StartScene",
	TeamCondition = {
		{
			Condition = "TeamCharacterIdOr",
			Value = 
			{
				220130,
			},
			Desc = "队伍中必须有爆米花女王",
			Hint = "队伍中必须有爆米花女王",
		},
	},
	Enemy = {
		{
			Value = 244089,
			Level = 50,
		},
	},
}
ChallengeConfig[ChallengeID.Id4078] =
{
	Id = 4078,
	Name = "挑战：焦糖爆米花",
	UnlockCostList = {
		{
			Value = 320104,
			Num = 1,
		},
	},
	Character = 220130,
	AcceptSpeech = 14407801,
	Desc = "为了巩固各大院线的垄断地位，爆米花女王再次推出新品爆米花。看喜剧时，希望有更特别的零食？那你一定要尝试一下这款焦糖爆米花，使用特定温度烧制的糖浆，包裹着松脆的爆米花，让你的欢笑更加甜蜜。",
	RewardUnlock = 232075,
	ResultText = "焦糖爆米花解锁了",
	NumCap = 5,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG05",
	StartScene = "FAT_StartScene",
	TeamCondition = {
		{
			Condition = "TeamCharacterIdOr",
			Value = 
			{
				220130,
			},
			Desc = "队伍中必须有爆米花女王",
			Hint = "队伍中必须有爆米花女王",
		},
	},
	Enemy = {
		{
			Value = 244090,
			Level = 50,
		},
	},
}
ChallengeConfig[ChallengeID.Id4079] =
{
	Id = 4079,
	Name = "挑战：白松露爆米花",
	UnlockCostList = {
		{
			Value = 320105,
			Num = 1,
		},
	},
	Character = 220130,
	AcceptSpeech = 14407901,
	Desc = "为了巩固各大院线的垄断地位，爆米花女王再次推出新品爆米花。看歌剧时，希望有更特别的零食？那你一定要尝试一下这款白松露爆米花，加入了有食材黄金之称的白松露，一旦进入口中，就融化为无形，同时你的存款也融化为无形。",
	RewardUnlock = 232076,
	ResultText = "白松露爆米花解锁了",
	NumCap = 5,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG02",
	StartScene = "FAT_StartScene",
	TeamCondition = {
		{
			Condition = "TeamCharacterIdOr",
			Value = 
			{
				220130,
			},
			Desc = "队伍中必须有爆米花女王",
			Hint = "队伍中必须有爆米花女王",
		},
	},
	Enemy = {
		{
			Value = 244091,
			Level = 75,
		},
	},
}
ChallengeConfig[ChallengeID.Id4080] =
{
	Id = 4080,
	Name = "挑战：保安队长",
	UnlockCostList = {
		{
			Value = 320104,
			Num = 1,
		},
	},
	Character = 220201,
	AcceptSpeech = 14408001,
	Desc = "工作三年后，保安终于晋升队长职级，不过除了工作内容大幅加剧外，其他一切，包括工资，都没有变化噢~",
	RewardUnlock = 232084,
	ResultText = "保安队长解锁了",
	NumCap = 5,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG01",
	StartScene = "MUS_StartScene",
	TeamCondition = {
		{
			Condition = "TeamCharacterIdOr",
			Value = 
			{
				220201,
			},
			Desc = "队伍中必须有保安",
			Hint = "队伍中必须有保安",
		},
	},
	Enemy = {
		{
			Value = 244092,
			Level = 50,
		},
	},
}
ChallengeConfig[ChallengeID.Id4081] =
{
	Id = 4081,
	Name = "挑战：明日子",
	UnlockCostList = {
		{
			Value = 320103,
			Num = 1,
		},
	},
	Character = 220202,
	AcceptSpeech = 14408101,
	Desc = "来自未来的超级侦探装备，能够大幅提升脑力开发度，不过副作用是一天以后就会彻底虚脱，而且脱下装备之时，大脑高强度运作时产生的记忆都会消失。",
	RewardUnlock = 232080,
	ResultText = "明日子解锁了",
	NumCap = 5,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG01",
	StartScene = "MUS_StartScene",
	TeamCondition = {
		{
			Condition = "TeamCharacterIdOr",
			Value = 
			{
				220202,
			},
			Desc = "队伍中必须有侦探小姐",
			Hint = "队伍中必须有侦探小姐",
		},
	},
	Enemy = {
		{
			Value = 244093,
			Level = 35,
		},
	},
}
ChallengeConfig[ChallengeID.Id4082] =
{
	Id = 4082,
	Name = "挑战：火焰熊猫",
	UnlockCostList = {
		{
			Value = 320104,
			Num = 1,
		},
	},
	Character = 220203,
	AcceptSpeech = 14408201,
	Desc = "获得了自然界火之力的火焰小浣熊，除了点燃自己灼烧敌人，还可以让同伴们都觉得暖洋洋的。~",
	RewardUnlock = 232081,
	ResultText = "火焰熊猫解锁了",
	NumCap = 3,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG05",
	StartScene = "MUS_StartScene",
	TeamCondition = {
		{
			Condition = "TeamCharacterIdOr",
			Value = 
			{
				220203,
			},
			Desc = "队伍中必须有浣熊大哥",
			Hint = "队伍中必须有浣熊大哥",
		},
		{
			Condition = "NeedTagAnd",
			Value = 
			{
				562915,
			},
			Desc = "必须是浣熊组的队员",
			Hint = "必须是浣熊组的队员",
		},
	},
	Enemy = {
		{
			Value = 244094,
			Level = 50,
		},
	},
}
ChallengeConfig[ChallengeID.Id4083] =
{
	Id = 4083,
	Name = "挑战：风暴熊猫",
	UnlockCostList = {
		{
			Value = 320104,
			Num = 1,
		},
	},
	Character = 220204,
	AcceptSpeech = 14408301,
	Desc = "获得了自然界风之力的风暴小浣熊，除了召唤龙卷风把敌人吹起来，还可以让同伴觉得空气很清新。~",
	RewardUnlock = 232082,
	ResultText = "风暴熊猫解锁了",
	NumCap = 3,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG03",
	StartScene = "MUS_StartScene",
	TeamCondition = {
		{
			Condition = "TeamCharacterIdOr",
			Value = 
			{
				220204,
			},
			Desc = "队伍中必须有浣熊二哥",
			Hint = "队伍中必须有浣熊二哥",
		},
		{
			Condition = "NeedTagAnd",
			Value = 
			{
				562915,
			},
			Desc = "必须是浣熊组的队员",
			Hint = "必须是浣熊组的队员",
		},
	},
	Enemy = {
		{
			Value = 244095,
			Level = 50,
		},
	},
}
ChallengeConfig[ChallengeID.Id4084] =
{
	Id = 4084,
	Name = "挑战：大地熊猫",
	UnlockCostList = {
		{
			Value = 320104,
			Num = 1,
		},
	},
	Character = 220205,
	AcceptSpeech = 14408401,
	Desc = "获得了自然界土之力的大地小浣熊，除了丢出石头晕住敌人2秒，还可以给同伴安全感。~",
	RewardUnlock = 232083,
	ResultText = "大地熊猫解锁了",
	NumCap = 3,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG02",
	StartScene = "MUS_StartScene",
	TeamCondition = {
		{
			Condition = "TeamCharacterIdOr",
			Value = 
			{
				220205,
			},
			Desc = "队伍中必须有浣熊小弟",
			Hint = "队伍中必须有浣熊小弟",
		},
		{
			Condition = "NeedTagAnd",
			Value = 
			{
				562915,
			},
			Desc = "必须是浣熊组的队员",
			Hint = "必须是浣熊组的队员",
		},
	},
	Enemy = {
		{
			Value = 244096,
			Level = 50,
		},
	},
}
ChallengeConfig[ChallengeID.Id4085] =
{
	Id = 4085,
	Name = "挑战：佛头",
	UnlockCostList = {
		{
			Value = 320101,
			Num = 1,
		},
	},
	Character = 220206,
	AcceptSpeech = 14408501,
	Desc = "换上佛头后，寡言的默艾经常说我们听不懂的东西……\n“舍利子，色不异空，空不异色，色即是空，空即是色……舍利子，是诸法空相，不生不灭，不垢不净……”",
	RewardUnlock = 232085,
	ResultText = "佛头解锁了",
	NumCap = 4,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG01",
	StartScene = "MUS_StartScene",
	TeamCondition = {
		{
			Condition = "TeamCharacterIdOr",
			Value = 
			{
				220206,
			},
			Desc = "队伍中必须有默艾",
			Hint = "队伍中必须有默艾",
		},
		{
			Condition = "NeedTagAnd",
			Value = 
			{
				562912,
			},
			Desc = "必须是石像组的队员",
			Hint = "必须是石像组的队员",
		},
	},
	Enemy = {
		{
			Value = 244097,
			Level = 35,
		},
	},
}
ChallengeConfig[ChallengeID.Id4086] =
{
	Id = 4086,
	Name = "挑战：智慧女神",
	UnlockCostList = {
		{
			Value = 320101,
			Num = 1,
		},
	},
	Character = 220207,
	AcceptSpeech = 14408601,
	Desc = "穿上智慧的外衣后，兵马俑说话时变得富有哲理起来。\n“凡世间的一切有其本质规律及凡人希望理解的规律。其本质或并无一定规律，而凡人所理解之规律却需要是可呈轨迹，为其了解过去并预测未来之用的规律。”",
	RewardUnlock = 232086,
	ResultText = "智慧女神解锁了",
	NumCap = 4,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG01",
	StartScene = "MUS_StartScene",
	TeamCondition = {
		{
			Condition = "TeamCharacterIdOr",
			Value = 
			{
				220207,
			},
			Desc = "队伍中必须有兵马俑",
			Hint = "队伍中必须有兵马俑",
		},
		{
			Condition = "NeedTagAnd",
			Value = 
			{
				562912,
			},
			Desc = "必须是石像组的队员",
			Hint = "必须是石像组的队员",
		},
	},
	Enemy = {
		{
			Value = 244098,
			Level = 35,
		},
	},
}
ChallengeConfig[ChallengeID.Id4087] =
{
	Id = 4087,
	Name = "挑战：玛雅石柱人",
	UnlockCostList = {
		{
			Value = 320101,
			Num = 1,
		},
	},
	Character = 220208,
	AcceptSpeech = 14408701,
	Desc = "扮成玛雅石柱人之后，石柱人时时刻刻都在做着了不起的记录。\n“啊，今天是20年以来β星群构成形状最接近正三角形的一天，这必须记录一下。”",
	RewardUnlock = 232087,
	ResultText = "玛雅石柱人解锁了",
	NumCap = 4,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG01",
	StartScene = "MUS_StartScene",
	TeamCondition = {
		{
			Condition = "TeamCharacterIdOr",
			Value = 
			{
				220208,
			},
			Desc = "队伍中必须有石柱人",
			Hint = "队伍中必须有石柱人",
		},
		{
			Condition = "NeedTagAnd",
			Value = 
			{
				562912,
			},
			Desc = "必须是石像组的队员",
			Hint = "必须是石像组的队员",
		},
	},
	Enemy = {
		{
			Value = 244099,
			Level = 35,
		},
	},
}
ChallengeConfig[ChallengeID.Id4088] =
{
	Id = 4088,
	Name = "挑战：独角兽",
	UnlockCostList = {
		{
			Value = 320101,
			Num = 1,
		},
	},
	Character = 220209,
	AcceptSpeech = 14408801,
	Desc = "插上独角后，喜欢自由和奔驰的半人马石像每天都要耐着性子和小朋友们拍照，就算被小朋友吊住脖子，也要微笑着看着镜头……",
	RewardUnlock = 232088,
	ResultText = "独角兽解锁了",
	NumCap = 4,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG01",
	StartScene = "MUS_StartScene",
	TeamCondition = {
		{
			Condition = "TeamCharacterIdOr",
			Value = 
			{
				220209,
			},
			Desc = "队伍中必须有半人马石像",
			Hint = "队伍中必须有半人马石像",
		},
		{
			Condition = "NeedTagAnd",
			Value = 
			{
				562912,
			},
			Desc = "必须是石像组的队员",
			Hint = "必须是石像组的队员",
		},
	},
	Enemy = {
		{
			Value = 244100,
			Level = 35,
		},
	},
}
ChallengeConfig[ChallengeID.Id4089] =
{
	Id = 4089,
	Name = "挑战：正装亚当",
	UnlockCostList = {
		{
			Value = 320102,
			Num = 1,
		},
	},
	Character = 220210,
	AcceptSpeech = 14408901,
	Desc = "在风纪委员会的帮助下换上正装的亚当。穿上这套衣服后，好像把平时用的小树叶藏在裤袋里了。不过，一本正经的样子还是非常讨人喜欢的~",
	RewardUnlock = 232089,
	ResultText = "正装亚当解锁了",
	NumCap = 5,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG01",
	StartScene = "MUS_StartScene",
	Enemy = {
		{
			Value = 244101,
			Level = 35,
		},
	},
}
ChallengeConfig[ChallengeID.Id4090] =
{
	Id = 4090,
	Name = "挑战：天国之光",
	UnlockCostList = {
		{
			Value = 320102,
			Num = 1,
		},
	},
	Character = 220211,
	AcceptSpeech = 14409001,
	Desc = "充满了神性气息的装束，当创造之神穿着这一身来到大家面前时，人们耳边仿佛响起了圣歌。",
	RewardUnlock = 232090,
	ResultText = "天国之光解锁了",
	NumCap = 5,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG01",
	StartScene = "MUS_StartScene",
	TeamCondition = {
		{
			Condition = "TeamCharacterIdOr",
			Value = 
			{
				220211,
			},
			Desc = "队伍中必须有创造之神",
			Hint = "队伍中必须有创造之神",
		},
	},
	Enemy = {
		{
			Value = 244102,
			Level = 35,
		},
	},
}
ChallengeConfig[ChallengeID.Id4091] =
{
	Id = 4091,
	Name = "挑战：梦",
	UnlockCostList = {
		{
			Value = 320101,
			Num = 1,
		},
	},
	Character = 220212,
	AcceptSpeech = 14409101,
	Desc = "和哭泣的女人同样风格的作品。破碎的几何拼凑出不连续的图案，听说只有理解作者之人或有相同心境之人才能看懂。",
	RewardUnlock = 232091,
	ResultText = "梦解锁了",
	NumCap = 5,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG01",
	StartScene = "MUS_StartScene",
	TeamCondition = {
		{
			Condition = "TeamCharacterIdOr",
			Value = 
			{
				220212,
			},
			Desc = "队伍中必须有哭泣的女人",
			Hint = "队伍中必须有哭泣的女人",
		},
	},
	Enemy = {
		{
			Value = 244103,
			Level = 25,
		},
	},
}
ChallengeConfig[ChallengeID.Id4092] =
{
	Id = 4092,
	Name = "挑战：/捂脸",
	UnlockCostList = {
		{
			Value = 320101,
			Num = 1,
		},
	},
	Character = 220213,
	AcceptSpeech = 14409201,
	Desc = "该表情常见于各类哭笑不得的场景之中，表情的主人眼中虽然流下了泪水，但是嘴角却洋溢着无法抑制的微笑。是目前工作场合中经常出现的用以调节气氛的表情。",
	RewardUnlock = 232092,
	ResultText = "/捂脸解锁了",
	NumCap = 5,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG01",
	StartScene = "MUS_StartScene",
	TeamCondition = {
		{
			Condition = "TeamCharacterIdOr",
			Value = 
			{
				220213,
			},
			Desc = "队伍中必须有呐喊家",
			Hint = "队伍中必须有呐喊家",
		},
	},
	Enemy = {
		{
			Value = 244104,
			Level = 25,
		},
	},
}
ChallengeConfig[ChallengeID.Id4093] =
{
	Id = 4093,
	Name = "挑战：酋长爸爸",
	UnlockCostList = {
		{
			Value = 320102,
			Num = 1,
		},
	},
	Character = 220214,
	AcceptSpeech = 14409301,
	Desc = "通过正常手段获得的某位外星酋长的服装，头上的三根稀有鸟类的羽毛象征着其与自然融为一体的超然地位。",
	RewardUnlock = 232093,
	ResultText = "酋长爸爸解锁了",
	NumCap = 5,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG01",
	StartScene = "MUS_StartScene",
	TeamCondition = {
		{
			Condition = "TeamCharacterIdOr",
			Value = 
			{
				220214,
			},
			Desc = "队伍中必须有原始人爸爸",
			Hint = "队伍中必须有原始人爸爸",
		},
	},
	Enemy = {
		{
			Value = 244105,
			Level = 50,
		},
	},
}
ChallengeConfig[ChallengeID.Id4094] =
{
	Id = 4094,
	Name = "挑战：酋长妈妈",
	UnlockCostList = {
		{
			Value = 320102,
			Num = 1,
		},
	},
	Character = 220215,
	AcceptSpeech = 14409401,
	Desc = "通过正常手段获得的某位外星酋长的服装，头上的两根羽毛象征着母仪天下的超然地位。",
	RewardUnlock = 232094,
	ResultText = "酋长妈妈解锁了",
	NumCap = 5,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG01",
	StartScene = "MUS_StartScene",
	TeamCondition = {
		{
			Condition = "TeamCharacterIdOr",
			Value = 
			{
				220215,
			},
			Desc = "队伍中必须有原始人妈妈",
			Hint = "队伍中必须有原始人妈妈",
		},
	},
	Enemy = {
		{
			Value = 244106,
			Level = 50,
		},
	},
}
ChallengeConfig[ChallengeID.Id4095] =
{
	Id = 4095,
	Name = "挑战：酋长继承人",
	UnlockCostList = {
		{
			Value = 320102,
			Num = 1,
		},
	},
	Character = 220216,
	AcceptSpeech = 14409501,
	Desc = "通过正常手段获得的某位外星酋长的服装，头上的一根羽毛象征着其在未来必将成为部落领袖的超然地位。",
	RewardUnlock = 232095,
	ResultText = "酋长继承人解锁了",
	NumCap = 5,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG01",
	StartScene = "MUS_StartScene",
	TeamCondition = {
		{
			Condition = "TeamCharacterIdOr",
			Value = 
			{
				220216,
			},
			Desc = "队伍中必须有原始人儿子",
			Hint = "队伍中必须有原始人儿子",
		},
	},
	Enemy = {
		{
			Value = 244107,
			Level = 50,
		},
	},
}
ChallengeConfig[ChallengeID.Id4096] =
{
	Id = 4096,
	Name = "挑战：东方木乃伊",
	UnlockCostList = {
		{
			Value = 320102,
			Num = 1,
		},
	},
	Character = 220217,
	AcceptSpeech = 14409601,
	Desc = "木乃伊复活失败变化而来的衍生形态，为了封印其凶性。大家手忙脚乱地帮他穿上了古代王朝大官的衣服，额前也贴上了封印力量的黄符。",
	RewardUnlock = 232096,
	ResultText = "东方木乃伊解锁了",
	NumCap = 5,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG01",
	StartScene = "MUS_StartScene",
	Enemy = {
		{
			Value = 244108,
			Level = 50,
		},
	},
}
ChallengeConfig[ChallengeID.Id4097] =
{
	Id = 4097,
	Name = "挑战：带翡翠的少女",
	UnlockCostList = {
		{
			Value = 320103,
			Num = 1,
		},
	},
	Character = 220218,
	AcceptSpeech = 14409701,
	Desc = "不开心的时候换个配饰，就能把坏心情一起换走啦~",
	RewardUnlock = 232097,
	ResultText = "带翡翠的少女解锁了",
	NumCap = 5,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "SUSBG02",
	StartScene = "MUS_StartScene",
	TeamCondition = {
		{
			Condition = "TeamCharacterIdOr",
			Value = 
			{
				220218,
				220219,
			},
			Desc = "队伍中必须有带珍珠的少女或猪蹄古董",
			Hint = "队伍中必须有带珍珠的少女或猪蹄古董",
		},
	},
	Enemy = {
		{
			Value = 244109,
			Level = 35,
		},
	},
}
ChallengeConfig[ChallengeID.Id4098] =
{
	Id = 4098,
	Name = "挑战：传国玉玺",
	UnlockCostList = {
		{
			Value = 320103,
			Num = 1,
		},
	},
	Character = 220219,
	AcceptSpeech = 14409801,
	Desc = "相传得到后，即可平定诸侯，君临天下的传国之宝。猪蹄古董拿到之后，就戴在头上随身保管了。如果没有他的允许，很难弄下来。",
	RewardUnlock = 232098,
	ResultText = "传国玉玺解锁了",
	NumCap = 5,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG01",
	StartScene = "MUS_StartScene",
	TeamCondition = {
		{
			Condition = "TeamCharacterIdOr",
			Value = 
			{
				220219,
			},
			Desc = "队伍中必须有猪蹄古董",
			Hint = "队伍中必须有猪蹄古董",
		},
	},
	Enemy = {
		{
			Value = 244110,
			Level = 35,
		},
	},
}
ChallengeConfig[ChallengeID.Id4099] =
{
	Id = 4099,
	Name = "挑战：春游赛特",
	UnlockCostList = {
		{
			Value = 320103,
			Num = 1,
		},
	},
	Character = 220220,
	AcceptSpeech = 14409901,
	Desc = "在这春暖花开的日子，赛特决定去东边进行一次愉快的春游",
	RewardUnlock = 232099,
	ResultText = "春游赛特解锁了",
	NumCap = 5,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "SUSBG02",
	StartScene = "MUS_StartScene",
	TeamCondition = {
		{
			Condition = "TeamCharacterIdOr",
			Value = 
			{
				220220,
			},
			Desc = "队伍中必须有赛特",
			Hint = "队伍中必须有赛特",
		},
	},
	Enemy = {
		{
			Value = 244111,
			Level = 35,
		},
	},
}
ChallengeConfig[ChallengeID.Id4100] =
{
	Id = 4100,
	Name = "挑战：春游索贝克",
	UnlockCostList = {
		{
			Value = 320103,
			Num = 1,
		},
	},
	Character = 220221,
	AcceptSpeech = 14410001,
	Desc = "在这春暖花开的日子，索贝克决定去东边进行一次愉快的春游",
	RewardUnlock = 232100,
	ResultText = "春游索贝克解锁了",
	NumCap = 5,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "SUSBG02",
	StartScene = "MUS_StartScene",
	TeamCondition = {
		{
			Condition = "TeamCharacterIdOr",
			Value = 
			{
				220221,
			},
			Desc = "队伍中必须有索贝克",
			Hint = "队伍中必须有索贝克",
		},
	},
	Enemy = {
		{
			Value = 244112,
			Level = 35,
		},
	},
}
ChallengeConfig[ChallengeID.Id4101] =
{
	Id = 4101,
	Name = "挑战：春游荷鲁斯",
	UnlockCostList = {
		{
			Value = 320103,
			Num = 1,
		},
	},
	Character = 220222,
	AcceptSpeech = 14410101,
	Desc = "在这春暖花开的日子，荷鲁斯决定去东边进行一次愉快的春游",
	RewardUnlock = 232101,
	ResultText = "春游荷鲁斯解锁了",
	NumCap = 5,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "SUSBG02",
	StartScene = "MUS_StartScene",
	TeamCondition = {
		{
			Condition = "TeamCharacterIdOr",
			Value = 
			{
				220222,
			},
			Desc = "队伍中必须有荷鲁斯",
			Hint = "队伍中必须有荷鲁斯",
		},
	},
	Enemy = {
		{
			Value = 244113,
			Level = 35,
		},
	},
}
ChallengeConfig[ChallengeID.Id4102] =
{
	Id = 4102,
	Name = "挑战：春游阿努比斯",
	UnlockCostList = {
		{
			Value = 320103,
			Num = 1,
		},
	},
	Character = 220223,
	AcceptSpeech = 14410201,
	Desc = "在这春暖花开的日子，阿努比斯决定去东边进行一次愉快的春游",
	RewardUnlock = 232102,
	ResultText = "春游阿努比斯解锁了",
	NumCap = 5,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "SUSBG02",
	StartScene = "MUS_StartScene",
	TeamCondition = {
		{
			Condition = "TeamCharacterIdOr",
			Value = 
			{
				220223,
			},
			Desc = "队伍中必须有阿努比斯",
			Hint = "队伍中必须有阿努比斯",
		},
	},
	Enemy = {
		{
			Value = 244114,
			Level = 35,
		},
	},
}
ChallengeConfig[ChallengeID.Id4103] =
{
	Id = 4103,
	Name = "挑战：早期作品",
	UnlockCostList = {
		{
			Value = 320104,
			Num = 1,
		},
	},
	Character = 220224,
	AcceptSpeech = 14410301,
	Desc = "独耳画像在人生的失意时刻也不曾放弃过自己的坚持，他始终在与生命做斗争，在与迫使他放弃自己理想的一切做斗争。最终，他的作品赢得了世人们的认可。",
	RewardUnlock = 232103,
	ResultText = "早期作品解锁了",
	NumCap = 5,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG01",
	StartScene = "MUS_StartScene",
	TeamCondition = {
		{
			Condition = "TeamCharacterIdOr",
			Value = 
			{
				220224,
			},
			Desc = "队伍中必须有独耳画像",
			Hint = "队伍中必须有独耳画像",
		},
	},
	Enemy = {
		{
			Value = 244115,
			Level = 35,
		},
	},
}
ChallengeConfig[ChallengeID.Id4104] =
{
	Id = 4104,
	Name = "挑战：点彩画法",
	UnlockCostList = {
		{
			Value = 320104,
			Num = 1,
		},
	},
	Character = 220224,
	AcceptSpeech = 14410401,
	Desc = "这是独耳先生身在时尚之城时做成的自画像。明朗自由的艺术氛围使独耳先生的艺术之树结出了丰硕的成果。他以新发现的独特技法创作了新的杰作。不过点彩之下的忧郁与身心所受的疲累又有多少人知道呢?",
	RewardUnlock = 232104,
	ResultText = "点彩画法解锁了",
	NumCap = 5,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG01",
	StartScene = "MUS_StartScene",
	TeamCondition = {
		{
			Condition = "TeamCharacterIdOr",
			Value = 
			{
				220224,
			},
			Desc = "队伍中必须有独耳画像",
			Hint = "队伍中必须有独耳画像",
		},
	},
	Enemy = {
		{
			Value = 244116,
			Level = 35,
		},
	},
}
ChallengeConfig[ChallengeID.Id4105] =
{
	Id = 4105,
	Name = "挑战：苦难与辉煌",
	UnlockCostList = {
		{
			Value = 320104,
			Num = 1,
		},
	},
	Character = 220225,
	AcceptSpeech = 14410501,
	Desc = "似乎有一位名人说过，世上真正的勇士只有一种，那就是明知生活苦难依然抱有勇气之人。那么，这位饱尝生活艰辛的女士似乎正是这样的一位勇士。而她热爱的花朵，就是她勇气的桂冠。",
	RewardUnlock = 232105,
	ResultText = "苦难与辉煌解锁了",
	NumCap = 5,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG01",
	StartScene = "MUS_StartScene",
	TeamCondition = {
		{
			Condition = "TeamCharacterIdOr",
			Value = 
			{
				220225,
			},
			Desc = "队伍中必须有弗里达",
			Hint = "队伍中必须有弗里达",
		},
	},
	Enemy = {
		{
			Value = 244117,
			Level = 35,
		},
	},
}
ChallengeConfig[ChallengeID.Id4106] =
{
	Id = 4106,
	Name = "挑战：春花与秋实",
	UnlockCostList = {
		{
			Value = 320104,
			Num = 1,
		},
	},
	Character = 220225,
	AcceptSpeech = 14410601,
	Desc = "平等对待每一种生命，才能豁然地面对生活中的苦难。虽然春花此生都很难在秋风中盛放，秋实也无法在春光中结果，但是它们依然会勇敢地生长下去。",
	RewardUnlock = 232106,
	ResultText = "春花与秋实解锁了",
	NumCap = 5,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG01",
	StartScene = "MUS_StartScene",
	TeamCondition = {
		{
			Condition = "TeamCharacterIdOr",
			Value = 
			{
				220225,
			},
			Desc = "队伍中必须有弗里达",
			Hint = "队伍中必须有弗里达",
		},
	},
	Enemy = {
		{
			Value = 244118,
			Level = 35,
		},
	},
}
ChallengeConfig[ChallengeID.Id4107] =
{
	Id = 4107,
	Name = "挑战：红发女神",
	UnlockCostList = {
		{
			Value = 320104,
			Num = 1,
		},
	},
	Character = 220226,
	AcceptSpeech = 14410701,
	Desc = "微笑女神的百变造型之一，充满勇气与热情的火红秀发，照亮了背后的天空，也照亮了画框外的世界。",
	RewardUnlock = 232107,
	ResultText = "红发女神解锁了",
	NumCap = 5,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "SUSBG04",
	StartScene = "MUS_StartScene",
	TeamCondition = {
		{
			Condition = "TeamCharacterIdOr",
			Value = 
			{
				220226,
			},
			Desc = "队伍中必须有微笑女神",
			Hint = "队伍中必须有微笑女神",
		},
	},
	Enemy = {
		{
			Value = 244119,
			Level = 35,
		},
	},
}
ChallengeConfig[ChallengeID.Id4108] =
{
	Id = 4108,
	Name = "挑战：黑发女神",
	UnlockCostList = {
		{
			Value = 320104,
			Num = 1,
		},
	},
	Character = 220226,
	AcceptSpeech = 14410801,
	Desc = "微笑女神的百变造型之一，充满安静祥和气息的乌黑秀发，让天空中的繁星变得更为璀璨，也让画框外的世界显得静谧起来。",
	RewardUnlock = 232108,
	ResultText = "黑发女神解锁了",
	NumCap = 5,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "SUSBG04",
	StartScene = "MUS_StartScene",
	TeamCondition = {
		{
			Condition = "TeamCharacterIdOr",
			Value = 
			{
				220226,
			},
			Desc = "队伍中必须有微笑女神",
			Hint = "队伍中必须有微笑女神",
		},
	},
	Enemy = {
		{
			Value = 244120,
			Level = 35,
		},
	},
}
ChallengeConfig[ChallengeID.Id4109] =
{
	Id = 4109,
	Name = "挑战：绅士假面",
	UnlockCostList = {
		{
			Value = 320104,
			Num = 1,
		},
	},
	Character = 220227,
	AcceptSpeech = 14410901,
	Desc = "以怪盗83号之名活跃在博物馆星的大窃贼。每次出现时总是在漆黑的月夜登场，行为如最彬彬有礼的绅士一般优雅，即使是把宝石、名画、瓷器用泡沫纸包起来打包带走的动作也比浣熊盗贼团们潇洒一些。",
	RewardUnlock = 232109,
	ResultText = "绅士假面解锁了",
	NumCap = 5,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG01",
	StartScene = "MUS_StartScene",
	TeamCondition = {
		{
			Condition = "TeamCharacterIdOr",
			Value = 
			{
				220227,
			},
			Desc = "队伍中必须有魔术师",
			Hint = "队伍中必须有魔术师",
		},
	},
	Enemy = {
		{
			Value = 244121,
			Level = 35,
		},
	},
}
ChallengeConfig[ChallengeID.Id4110] =
{
	Id = 4110,
	Name = "挑战：银发假面",
	UnlockCostList = {
		{
			Value = 320104,
			Num = 1,
		},
	},
	Character = 220227,
	AcceptSpeech = 14411001,
	Desc = "由博士开发的高速型怪盗服装，朴实无华的布料下隐藏了大量喷口。引擎全开时前进速度接近光速。",
	RewardUnlock = 232110,
	ResultText = "银发假面解锁了",
	NumCap = 5,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG01",
	StartScene = "MUS_StartScene",
	TeamCondition = {
		{
			Condition = "TeamCharacterIdOr",
			Value = 
			{
				220227,
			},
			Desc = "队伍中必须有魔术师",
			Hint = "队伍中必须有魔术师",
		},
	},
	Enemy = {
		{
			Value = 244122,
			Level = 35,
		},
	},
}
ChallengeConfig[ChallengeID.Id4111] =
{
	Id = 4111,
	Name = "挑战：船长的诅咒",
	UnlockCostList = {
		{
			Value = 320105,
			Num = 1,
		},
	},
	Character = 220227,
	AcceptSpeech = 14411101,
	Desc = "曾经抵达过宇宙之海尽头的幽灵船船长，古老的亡魂帮助魔术师找回了全部的冒险记忆。不过对于现在的魔术师而言，征服星辰大海已不再重要，重要的是赢得微笑女神对他的青睐。",
	RewardUnlock = 232111,
	ResultText = "船长的诅咒解锁了",
	NumCap = 5,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG01",
	StartScene = "MUS_StartScene",
	TeamCondition = {
		{
			Condition = "TeamCharacterIdOr",
			Value = 
			{
				220227,
			},
			Desc = "队伍中必须有魔术师",
			Hint = "队伍中必须有魔术师",
		},
	},
	Enemy = {
		{
			Value = 244123,
			Level = 75,
		},
	},
}
ChallengeConfig[ChallengeID.Id4112] =
{
	Id = 4112,
	Name = "挑战：战国の大名",
	UnlockCostList = {
		{
			Value = 320103,
			Num = 1,
		},
	},
	Character = 220228,
	AcceptSpeech = 14411201,
	Desc = "前任主人是比起战争，更喜爱蹴鞠与歌咏的风雅人物，听说流着将军家的名门血统，以当主的身份指挥家将保护着祖传的土地。",
	RewardUnlock = 232112,
	ResultText = "战国の大名解锁了",
	NumCap = 5,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG01",
	StartScene = "MUS_StartScene",
	TeamCondition = {
		{
			Condition = "TeamCharacterIdOr",
			Value = 
			{
				220228,
			},
			Desc = "队伍中必须有武士",
			Hint = "队伍中必须有武士",
		},
	},
	Enemy = {
		{
			Value = 244124,
			Level = 25,
		},
	},
}
ChallengeConfig[ChallengeID.Id4113] =
{
	Id = 4113,
	Name = "挑战：战国の青雷",
	UnlockCostList = {
		{
			Value = 320105,
			Num = 1,
		},
	},
	Character = 220228,
	AcceptSpeech = 14411301,
	Desc = "前任主人是喜欢异国文化，剑术高超的顶级武士，性格高傲且正直开朗。即使面对多个敌人，也没有丝毫胆怯。",
	RewardUnlock = 232113,
	ResultText = "战国の青雷解锁了",
	NumCap = 5,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG01",
	StartScene = "MUS_StartScene",
	TeamCondition = {
		{
			Condition = "TeamCharacterIdOr",
			Value = 
			{
				220228,
			},
			Desc = "队伍中必须有武士",
			Hint = "队伍中必须有武士",
		},
	},
	Enemy = {
		{
			Value = 244125,
			Level = 75,
		},
	},
}
ChallengeConfig[ChallengeID.Id4114] =
{
	Id = 4114,
	Name = "挑战：战国の龙狼",
	UnlockCostList = {
		{
			Value = 320104,
			Num = 1,
		},
	},
	Character = 220228,
	AcceptSpeech = 14411401,
	Desc = "龙狼武士的战袍，衣服中具有龙狼之魂。每当武士对眼下的一切感到困惑时，他就会轻轻抚摸战袍，希望找回心中的安宁。",
	RewardUnlock = 232114,
	ResultText = "战国の龙狼解锁了",
	NumCap = 1,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG02",
	StartScene = "MUS_StartScene",
	TeamCondition = {
		{
			Condition = "TeamCharacterIdOr",
			Value = 
			{
				220228,
			},
			Desc = "队伍中必须有武士",
			Hint = "队伍中必须有武士",
		},
	},
	Enemy = {
		{
			Value = 244126,
			Level = 35,
		},
	},
}
ChallengeConfig[ChallengeID.Id4115] =
{
	Id = 4115,
	Name = "挑战：帝国统帅",
	UnlockCostList = {
		{
			Value = 320105,
			Num = 1,
		},
	},
	Character = 220229,
	AcceptSpeech = 14411501,
	Desc = "庄严肃穆的帝国统帅制服，只要披上这件战炮，那么名人蜡像的军队就能展现出震动整个大陆的战斗力。",
	RewardUnlock = 232115,
	ResultText = "帝国统帅解锁了",
	NumCap = 5,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG01",
	StartScene = "MUS_StartScene",
	TeamCondition = {
		{
			Condition = "TeamCharacterIdOr",
			Value = 
			{
				220229,
			},
			Desc = "队伍中必须有名人蜡像",
			Hint = "队伍中必须有名人蜡像",
		},
	},
	Enemy = {
		{
			Value = 244127,
			Level = 50,
		},
		{
			Value = 244128,
			Level = 50,
		},
		{
			Value = 244129,
			Level = 50,
		},
		{
			Value = 244130,
			Level = 50,
		},
	},
}
ChallengeConfig[ChallengeID.Id4116] =
{
	Id = 4116,
	Name = "挑战：皇帝加冕",
	UnlockCostList = {
		{
			Value = 320105,
			Num = 1,
		},
	},
	Character = 220229,
	AcceptSpeech = 14411601,
	Desc = "年轻的统帅急于向整个大陆证明自己的英明神武并建立自己的帝国，他一把夺过了本应由教皇授予他的皇冠，戴上皇冠那一刻，整个大陆都只能在他面前俯首。",
	RewardUnlock = 232116,
	ResultText = "皇帝加冕解锁了",
	NumCap = 5,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG01",
	StartScene = "MUS_StartScene",
	TeamCondition = {
		{
			Condition = "TeamCharacterIdOr",
			Value = 
			{
				220229,
			},
			Desc = "队伍中必须有名人蜡像",
			Hint = "队伍中必须有名人蜡像",
		},
	},
	Enemy = {
		{
			Value = 244131,
			Level = 75,
		},
	},
}
ChallengeConfig[ChallengeID.Id4117] =
{
	Id = 4117,
	Name = "挑战：凯旋",
	UnlockCostList = {
		{
			Value = 320105,
			Num = 1,
		},
	},
	Character = 220229,
	AcceptSpeech = 14411701,
	Desc = "名人蜡像总是那么自信，无论情况多么艰难，他都不曾放弃胜利的信念。于是越来越多人跟随他，希望成为他的同伴。",
	RewardUnlock = 232117,
	ResultText = "凯旋解锁了",
	NumCap = 5,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "MUSBG02",
	StartScene = "MUS_StartScene",
	TeamCondition = {
		{
			Condition = "TeamCharacterIdOr",
			Value = 
			{
				220229,
			},
			Desc = "队伍中必须有名人蜡像",
			Hint = "队伍中必须有名人蜡像",
		},
	},
	Enemy = {
		{
			Value = 244132,
			Level = 50,
		},
	},
}
ChallengeConfig[ChallengeID.Id4118] =
{
	Id = 4118,
	Name = "挑战：冬日报童",
	UnlockCostList = {
		{
			Value = 320101,
			Num = 1,
		},
	},
	Character = 220301,
	AcceptSpeech = 14411801,
	Desc = "非常保暖的送报套装，因为核心部分十分保暖，连裸露的身体部分也丝毫感觉不到寒意。据说穿着这件套装，可以在-273.14℃的环境连续工作噢~",
	RewardUnlock = 232123,
	ResultText = "冬日报童解锁了",
	NumCap = 5,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "SUSBG01",
	StartScene = "SUS_StartScene",
	TeamCondition = {
		{
			Condition = "TeamCharacterIdOr",
			Value = 
			{
				220301,
			},
			Desc = "队伍中必须有报童",
			Hint = "队伍中必须有报童",
		},
	},
	Enemy = {
		{
			Value = 244133,
			Level = 25,
		},
	},
}
ChallengeConfig[ChallengeID.Id4119] =
{
	Id = 4119,
	Name = "挑战：茶话会作家",
	UnlockCostList = {
		{
			Value = 320103,
			Num = 1,
		},
	},
	Character = 220302,
	AcceptSpeech = 14411901,
	Desc = "复古却不失活泼的聚会套装，穿在知性的阿加莎小姐身上更显出其独树一帜的品味。",
	RewardUnlock = 232118,
	ResultText = "茶话会作家解锁了",
	NumCap = 5,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG01",
	StartScene = "SUS_StartScene",
	TeamCondition = {
		{
			Condition = "TeamCharacterIdOr",
			Value = 
			{
				220302,
			},
			Desc = "队伍中必须有阿加莎",
			Hint = "队伍中必须有阿加莎",
		},
	},
	Enemy = {
		{
			Value = 244134,
			Level = 35,
		},
	},
}
ChallengeConfig[ChallengeID.Id4120] =
{
	Id = 4120,
	Name = "挑战：吊死",
	UnlockCostList = {
		{
			Value = 320103,
			Num = 1,
		},
	},
	Character = 220303,
	AcceptSpeech = 14412001,
	Desc = "脖子上套着粗麻绳的套装，对于每天要跑20个片场扮演死者的死者而言，在演出特定场景时，几乎不用怎么化妆就能直接出场，非常方便噢~",
	RewardUnlock = 232119,
	ResultText = "吊死解锁了",
	NumCap = 5,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG01",
	StartScene = "SUS_StartScene",
	Enemy = {
		{
			Value = 244135,
			Level = 35,
		},
	},
}
ChallengeConfig[ChallengeID.Id4121] =
{
	Id = 4121,
	Name = "挑战：淹死",
	UnlockCostList = {
		{
			Value = 320103,
			Num = 1,
		},
	},
	Character = 220303,
	AcceptSpeech = 14412101,
	Desc = "头上套着注水金鱼缸的套装，对于每天要跑20个片场扮演死者的死者而言，在演出特定场景时，几乎不用怎么化妆就能直接出场，非常方便噢~",
	RewardUnlock = 232120,
	ResultText = "淹死解锁了",
	NumCap = 5,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG01",
	StartScene = "SUS_StartScene",
	Enemy = {
		{
			Value = 244136,
			Level = 35,
		},
	},
}
ChallengeConfig[ChallengeID.Id4122] =
{
	Id = 4122,
	Name = "挑战：朋克证人",
	UnlockCostList = {
		{
			Value = 320102,
			Num = 1,
		},
	},
	Character = 220304,
	AcceptSpeech = 14412201,
	Desc = "悬疑星有史以来最大型连续剧《朋克神探》中的证人角色。对于证人而言，是一次向全宇宙观众展现自己推理能力的机会。",
	RewardUnlock = 232121,
	ResultText = "朋克证人解锁了",
	NumCap = 5,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "SUSBG04",
	StartScene = "SUS_StartScene",
	TeamCondition = {
		{
			Condition = "TeamCharacterIdOr",
			Value = 
			{
				220304,
			},
			Desc = "队伍中必须有证人",
			Hint = "队伍中必须有证人",
		},
	},
	Enemy = {
		{
			Value = 244137,
			Level = 25,
		},
	},
}
ChallengeConfig[ChallengeID.Id4123] =
{
	Id = 4123,
	Name = "挑战：屠夫",
	UnlockCostList = {
		{
			Value = 320103,
			Num = 1,
		},
	},
	Character = 220305,
	AcceptSpeech = 14412301,
	Desc = "能够完美呈现何谓恐怖的凶手外套，兜帽下让人无法辨别的脸，似乎时刻都在注视着你。",
	RewardUnlock = 232122,
	ResultText = "屠夫解锁了",
	NumCap = 5,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG01",
	StartScene = "SUS_StartScene",
	TeamCondition = {
		{
			Condition = "TeamCharacterIdOr",
			Value = 
			{
				220305,
			},
			Desc = "队伍中必须有凶手",
			Hint = "队伍中必须有凶手",
		},
	},
	Enemy = {
		{
			Value = 244138,
			Level = 35,
		},
	},
}
ChallengeConfig[ChallengeID.Id4124] =
{
	Id = 4124,
	Name = "挑战：泳装小泪",
	UnlockCostList = {
		{
			Value = 320101,
			Num = 1,
		},
	},
	Character = 220306,
	AcceptSpeech = 14412401,
	Desc = "展现少女完美身姿的淑女泳装。然而遮阳帽下却隐藏着整套情报分析设备，即使在沙滩上，也能完美收集情报。",
	RewardUnlock = 232124,
	ResultText = "泳装小泪解锁了",
	NumCap = 3,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "SUSBG02",
	StartScene = "SUS_StartScene",
	TeamCondition = {
		{
			Condition = "TeamCharacterIdOr",
			Value = 
			{
				220306,
			},
			Desc = "队伍中必须有小泪",
			Hint = "队伍中必须有小泪",
		},
		{
			Condition = "NeedTagAnd",
			Value = 
			{
				562918,
			},
			Desc = "必须是猫眼组的队员",
			Hint = "必须是猫眼组的队员",
		},
	},
	Enemy = {
		{
			Value = 244139,
			Level = 25,
		},
	},
}
ChallengeConfig[ChallengeID.Id4125] =
{
	Id = 4125,
	Name = "挑战：泳装小瞳",
	UnlockCostList = {
		{
			Value = 320101,
			Num = 1,
		},
	},
	Character = 220307,
	AcceptSpeech = 14412501,
	Desc = "展现少女完美身姿的动感泳装。然而曼妙长裙下却隐藏着完整的强化作战骨骼。即使身着泳装，也能进行高强度格斗。",
	RewardUnlock = 232125,
	ResultText = "泳装小瞳解锁了",
	NumCap = 3,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "SUSBG02",
	StartScene = "SUS_StartScene",
	TeamCondition = {
		{
			Condition = "TeamCharacterIdOr",
			Value = 
			{
				220307,
			},
			Desc = "队伍中必须有小瞳",
			Hint = "队伍中必须有小瞳",
		},
		{
			Condition = "NeedTagAnd",
			Value = 
			{
				562918,
			},
			Desc = "必须是猫眼组的队员",
			Hint = "必须是猫眼组的队员",
		},
	},
	Enemy = {
		{
			Value = 244140,
			Level = 25,
		},
	},
}
ChallengeConfig[ChallengeID.Id4126] =
{
	Id = 4126,
	Name = "挑战：泳装小爱",
	UnlockCostList = {
		{
			Value = 320101,
			Num = 1,
		},
	},
	Character = 220308,
	AcceptSpeech = 14412601,
	Desc = "展现少女完美身姿的可爱泳装。然而全套泳装都是经改良的特制武器。即使在沙滩上，也能忽然变出一辆堡垒级坦克进行强火力作战。",
	RewardUnlock = 232126,
	ResultText = "泳装小爱解锁了",
	NumCap = 3,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "SUSBG02",
	StartScene = "SUS_StartScene",
	TeamCondition = {
		{
			Condition = "TeamCharacterIdOr",
			Value = 
			{
				220308,
			},
			Desc = "队伍中必须有小爱",
			Hint = "队伍中必须有小爱",
		},
		{
			Condition = "NeedTagAnd",
			Value = 
			{
				562918,
			},
			Desc = "必须是猫眼组的队员",
			Hint = "必须是猫眼组的队员",
		},
	},
	Enemy = {
		{
			Value = 244141,
			Level = 25,
		},
	},
}
ChallengeConfig[ChallengeID.Id4127] =
{
	Id = 4127,
	Name = "挑战：使命必达",
	UnlockCostList = {
		{
			Value = 320102,
			Num = 1,
		},
	},
	Character = 220309,
	AcceptSpeech = 14412701,
	Desc = "编辑长的催稿必杀套装，无论对方躲在天涯海角，都能驾驶飞机立刻赶到。即使飞行服被偷走，也能使用备用装置立刻传送到飞行服所在区域。",
	RewardUnlock = 232127,
	ResultText = "使命必达解锁了",
	NumCap = 5,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG01",
	StartScene = "SUS_StartScene",
	TeamCondition = {
		{
			Condition = "TeamCharacterIdOr",
			Value = 
			{
				220309,
			},
			Desc = "队伍中必须有编辑长",
			Hint = "队伍中必须有编辑长",
		},
	},
	Enemy = {
		{
			Value = 244142,
			Level = 35,
		},
	},
}
ChallengeConfig[ChallengeID.Id4128] =
{
	Id = 4128,
	Name = "挑战：翻译组",
	UnlockCostList = {
		{
			Value = 320101,
			Num = 1,
		},
	},
	Character = 220310,
	AcceptSpeech = 14412801,
	Desc = "经过一番学习后，读者终于从阅读爱好者变成了一位文字工作者，虽然目前还只能从事阅读翻译的工作，不过相信未来一定可以踏上写作的道路。",
	RewardUnlock = 232128,
	ResultText = "翻译组解锁了",
	NumCap = 5,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "SUSBG04",
	StartScene = "SUS_StartScene",
	TeamCondition = {
		{
			Condition = "TeamCharacterIdOr",
			Value = 
			{
				220310,
			},
			Desc = "队伍中必须有读者",
			Hint = "队伍中必须有读者",
		},
	},
	Enemy = {
		{
			Value = 244143,
			Level = 25,
		},
	},
}
ChallengeConfig[ChallengeID.Id4129] =
{
	Id = 4129,
	Name = "挑战：受害者乙",
	UnlockCostList = {
		{
			Value = 320101,
			Num = 1,
		},
	},
	Character = 220311,
	AcceptSpeech = 14412901,
	Desc = "在影片中成功逆袭的女二号角色，即使遍体鳞伤，也要坚强地活下去。",
	RewardUnlock = 232129,
	ResultText = "受害者乙解锁了",
	NumCap = 5,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG01",
	StartScene = "SUS_StartScene",
	TeamCondition = {
		{
			Condition = "TeamCharacterIdOr",
			Value = 
			{
				220311,
			},
			Desc = "队伍中必须有受害者",
			Hint = "队伍中必须有受害者",
		},
	},
	Enemy = {
		{
			Value = 244144,
			Level = 25,
		},
	},
}
ChallengeConfig[ChallengeID.Id4130] =
{
	Id = 4130,
	Name = "挑战：律政女王",
	UnlockCostList = {
		{
			Value = 320102,
			Num = 1,
		},
	},
	Character = 220312,
	AcceptSpeech = 14413001,
	Desc = "法庭上人见人怕的律政界女王，据说以前还是学校选美冠军之一呢~",
	RewardUnlock = 232130,
	ResultText = "律政女王解锁了",
	NumCap = 5,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG01",
	StartScene = "SUS_StartScene",
	TeamCondition = {
		{
			Condition = "TeamCharacterIdOr",
			Value = 
			{
				220312,
			},
			Desc = "队伍中必须有律师",
			Hint = "队伍中必须有律师",
		},
	},
	Enemy = {
		{
			Value = 244145,
			Level = 35,
		},
	},
}
ChallengeConfig[ChallengeID.Id4131] =
{
	Id = 4131,
	Name = "挑战：宅女侦探",
	UnlockCostList = {
		{
			Value = 320102,
			Num = 1,
		},
	},
	Character = 220313,
	AcceptSpeech = 14413101,
	Desc = "房东太太的魔力侦探服，说它具有魔力是因为只要房东太太换上它，就能重现青春活力，头脑和身手都会回复三十年前的水平噢~",
	RewardUnlock = 232131,
	ResultText = "宅女侦探解锁了",
	NumCap = 5,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG01",
	StartScene = "SUS_StartScene",
	TeamCondition = {
		{
			Condition = "TeamCharacterIdOr",
			Value = 
			{
				220313,
			},
			Desc = "队伍中必须有房东太太",
			Hint = "队伍中必须有房东太太",
		},
	},
	Enemy = {
		{
			Value = 244146,
			Level = 35,
		},
	},
}
ChallengeConfig[ChallengeID.Id4132] =
{
	Id = 4132,
	Name = "挑战：朋克酒保",
	UnlockCostList = {
		{
			Value = 320102,
			Num = 1,
		},
	},
	Character = 220314,
	AcceptSpeech = 14413201,
	Desc = "悬疑星有史以来最大型连续剧《朋克神探》中的酒保角色。虽然表面还是调酒师，但实际上负责情报的交易工作，是掌握着“朋克宇宙”最多秘密的男人。",
	RewardUnlock = 232132,
	ResultText = "朋克酒保解锁了",
	NumCap = 5,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG01",
	StartScene = "SUS_StartScene",
	TeamCondition = {
		{
			Condition = "TeamCharacterIdOr",
			Value = 
			{
				220314,
			},
			Desc = "队伍中必须有调酒师",
			Hint = "队伍中必须有调酒师",
		},
	},
	Enemy = {
		{
			Value = 244147,
			Level = 35,
		},
	},
}
ChallengeConfig[ChallengeID.Id4133] =
{
	Id = 4133,
	Name = "挑战：MK-II 加强型",
	UnlockCostList = {
		{
			Value = 320104,
			Num = 1,
		},
	},
	Character = 220315,
	AcceptSpeech = 14413301,
	Desc = "普通行动舱的强化版本，更适于在恶劣环境中进行战斗。不过为了节省舱体容量，因此去除了大量工作模块。",
	RewardUnlock = 232133,
	ResultText = "MK-II 加强型解锁了",
	NumCap = 5,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG01",
	StartScene = "SUS_StartScene",
	TeamCondition = {
		{
			Condition = "TeamCharacterIdOr",
			Value = 
			{
				220315,
			},
			Desc = "队伍中必须有博士",
			Hint = "队伍中必须有博士",
		},
	},
	Enemy = {
		{
			Value = 244148,
			Level = 50,
		},
	},
}
ChallengeConfig[ChallengeID.Id4134] =
{
	Id = 4134,
	Name = "挑战：黑警察",
	UnlockCostList = {
		{
			Value = 320104,
			Num = 1,
		},
	},
	Character = 220316,
	AcceptSpeech = 14413401,
	Desc = "豆豆警官击败黑警长后在组织中建立的新身份。此后，他将以黑警长的身份继续深入调查组织内部的罪恶秘密，希望有一天能够将组织彻底捣毁。",
	RewardUnlock = 232134,
	ResultText = "黑警察解锁了",
	NumCap = 5,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG01",
	StartScene = "SUS_StartScene",
	TeamCondition = {
		{
			Condition = "TeamCharacterIdOr",
			Value = 
			{
				220316,
			},
			Desc = "队伍中必须有豆豆警官",
			Hint = "队伍中必须有豆豆警官",
		},
	},
	Enemy = {
		{
			Value = 244149,
			Level = 50,
		},
	},
}
ChallengeConfig[ChallengeID.Id4135] =
{
	Id = 4135,
	Name = "挑战：黑法医",
	UnlockCostList = {
		{
			Value = 320104,
			Num = 1,
		},
	},
	Character = 220317,
	AcceptSpeech = 14413501,
	Desc = "法医从黑色法医组织手中抢来的制服，使用了特制金属及皮料制成，透气性及保护性一流，非常适合作为战斗服使用。",
	RewardUnlock = 232135,
	ResultText = "黑法医解锁了",
	NumCap = 5,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG01",
	StartScene = "SUS_StartScene",
	TeamCondition = {
		{
			Condition = "TeamCharacterIdOr",
			Value = 
			{
				220317,
			},
			Desc = "队伍中必须有法医",
			Hint = "队伍中必须有法医",
		},
	},
	Enemy = {
		{
			Value = 244150,
			Level = 50,
		},
	},
}
ChallengeConfig[ChallengeID.Id4136] =
{
	Id = 4136,
	Name = "挑战：正义之友",
	UnlockCostList = {
		{
			Value = 320103,
			Num = 1,
		},
	},
	Character = 220318,
	AcceptSpeech = 14413601,
	Desc = "重新相信了人性的检察官。如今的他内心变得更强大了，放弃了对绝对法律的执着后，他对于善与恶，罪与罚的定义也更了然于心了。",
	RewardUnlock = 232136,
	ResultText = "正义之友解锁了",
	NumCap = 5,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG01",
	StartScene = "SUS_StartScene",
	TeamCondition = {
		{
			Condition = "TeamCharacterIdOr",
			Value = 
			{
				220318,
			},
			Desc = "队伍中必须有检察官",
			Hint = "队伍中必须有检察官",
		},
	},
	Enemy = {
		{
			Value = 244151,
			Level = 35,
		},
	},
}
ChallengeConfig[ChallengeID.Id4137] =
{
	Id = 4137,
	Name = "挑战：女法官",
	UnlockCostList = {
		{
			Value = 320102,
			Num = 1,
		},
	},
	Character = 220319,
	AcceptSpeech = 14413701,
	Desc = "女装的法官服饰。虽然法官已届中年，不过穿上这身庄重又不失素雅的服装后，引得路上的中年男性频频回头了。",
	RewardUnlock = 232137,
	ResultText = "女法官解锁了",
	NumCap = 5,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG01",
	StartScene = "SUS_StartScene",
	TeamCondition = {
		{
			Condition = "TeamCharacterIdOr",
			Value = 
			{
				220319,
			},
			Desc = "队伍中必须有法官",
			Hint = "队伍中必须有法官",
		},
	},
	Enemy = {
		{
			Value = 244152,
			Level = 25,
		},
	},
}
ChallengeConfig[ChallengeID.Id4138] =
{
	Id = 4138,
	Name = "挑战：朋克助理",
	UnlockCostList = {
		{
			Value = 320103,
			Num = 1,
		},
	},
	Character = 220320,
	AcceptSpeech = 14413801,
	Desc = "悬疑星有史以来最大型连续剧《朋克神探》中的助理角色。装备了由博士发明的低出力型助理工作舱，阉割了部分作战功能，但提升了装置的稳定性。",
	RewardUnlock = 232138,
	ResultText = "朋克助理解锁了",
	NumCap = 5,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "MUSBG03",
	StartScene = "SUS_StartScene",
	TeamCondition = {
		{
			Condition = "TeamCharacterIdOr",
			Value = 
			{
				220320,
			},
			Desc = "队伍中必须有侦探助理",
			Hint = "队伍中必须有侦探助理",
		},
	},
	Enemy = {
		{
			Value = 244153,
			Level = 35,
		},
	},
}
ChallengeConfig[ChallengeID.Id4139] =
{
	Id = 4139,
	Name = "挑战：女装助理",
	UnlockCostList = {
		{
			Value = 320102,
			Num = 1,
		},
	},
	Character = 220320,
	AcceptSpeech = 14413901,
	Desc = "女装的助理服装。乖巧的打扮显得侦探助理更可爱，听说助理穿上这套衣服后被不少青年男子搭讪了呢~",
	RewardUnlock = 232139,
	ResultText = "女装助理解锁了",
	NumCap = 5,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG01",
	StartScene = "SUS_StartScene",
	TeamCondition = {
		{
			Condition = "TeamCharacterIdOr",
			Value = 
			{
				220320,
			},
			Desc = "队伍中必须有侦探助理",
			Hint = "队伍中必须有侦探助理",
		},
	},
	Enemy = {
		{
			Value = 244154,
			Level = 25,
		},
	},
}
ChallengeConfig[ChallengeID.Id4140] =
{
	Id = 4140,
	Name = "挑战：睡衣助理",
	UnlockCostList = {
		{
			Value = 320103,
			Num = 1,
		},
	},
	Character = 220320,
	AcceptSpeech = 14414001,
	Desc = "侦探助理的睡衣套装，和大侦探与教授进行枕头大战的指定套装，玩累了以后，可以直接倒下来睡觉。",
	RewardUnlock = 232140,
	ResultText = "睡衣助理解锁了",
	NumCap = 5,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG01",
	StartScene = "SUS_StartScene",
	TeamCondition = {
		{
			Condition = "TeamCharacterIdOr",
			Value = 
			{
				220320,
			},
			Desc = "队伍中必须有侦探助理",
			Hint = "队伍中必须有侦探助理",
		},
	},
	Enemy = {
		{
			Value = 244155,
			Level = 35,
		},
	},
}
ChallengeConfig[ChallengeID.Id4141] =
{
	Id = 4141,
	Name = "挑战：午夜访客",
	UnlockCostList = {
		{
			Value = 320104,
			Num = 1,
		},
	},
	Character = 220321,
	AcceptSpeech = 14414101,
	Desc = "杰克祖父留给他的代表复仇的外套，只有当杰克的仇人出现时，杰克才会穿上这件衣服，向对方施以愤怒之火。",
	RewardUnlock = 232141,
	ResultText = "午夜访客解锁了",
	NumCap = 5,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG01",
	StartScene = "SUS_StartScene",
	TeamCondition = {
		{
			Condition = "TeamCharacterIdOr",
			Value = 
			{
				220321,
			},
			Desc = "队伍中必须有杰克瑞波",
			Hint = "队伍中必须有杰克瑞波",
		},
	},
	Enemy = {
		{
			Value = 244156,
			Level = 50,
		},
	},
}
ChallengeConfig[ChallengeID.Id4142] =
{
	Id = 4142,
	Name = "挑战：大作家",
	UnlockCostList = {
		{
			Value = 320104,
			Num = 1,
		},
	},
	Character = 220322,
	AcceptSpeech = 14414201,
	Desc = "名动悬疑星的大作家，笔下创作了绝对经典的侦探形象，为后世侦探小说定下了完美范本。其本人更是后世无数侦探的偶像。",
	RewardUnlock = 232142,
	ResultText = "大作家解锁了",
	NumCap = 5,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG02",
	StartScene = "SUS_StartScene",
	TeamCondition = {
		{
			Condition = "TeamCharacterIdOr",
			Value = 
			{
				220322,
			},
			Desc = "队伍中必须有蓝衣小学生",
			Hint = "队伍中必须有蓝衣小学生",
		},
	},
	Enemy = {
		{
			Value = 244157,
			Level = 35,
		},
	},
}
ChallengeConfig[ChallengeID.Id4143] =
{
	Id = 4143,
	Name = "挑战：高中生",
	UnlockCostList = {
		{
			Value = 320104,
			Num = 1,
		},
	},
	Character = 220322,
	AcceptSpeech = 14414301,
	Desc = "服用了解药的蓝衣小学生终于又成功变回了高中生。这次的解药稳定性远超以往，蓝衣小学生可以随时选择什么时候复原以及复原多久。",
	RewardUnlock = 232143,
	ResultText = "高中生解锁了",
	NumCap = 5,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG01",
	StartScene = "SUS_StartScene",
	TeamCondition = {
		{
			Condition = "TeamCharacterIdOr",
			Value = 
			{
				220322,
			},
			Desc = "队伍中必须有蓝衣小学生",
			Hint = "队伍中必须有蓝衣小学生",
		},
	},
	Enemy = {
		{
			Value = 244158,
			Level = 35,
		},
	},
}
ChallengeConfig[ChallengeID.Id4144] =
{
	Id = 4144,
	Name = "挑战：精神控制",
	UnlockCostList = {
		{
			Value = 320104,
			Num = 1,
		},
	},
	Character = 220323,
	AcceptSpeech = 14414401,
	Desc = "由迈克罗夫特主力研究的脑力扩散装置，能够使意识进入不同维度的世界。迈克罗夫特坚信，构成真实世界的远不止我们现在所知的这一切。",
	RewardUnlock = 232144,
	ResultText = "精神控制解锁了",
	NumCap = 5,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "SUSBG04",
	StartScene = "SUS_StartScene",
	TeamCondition = {
		{
			Condition = "TeamCharacterIdOr",
			Value = 
			{
				220323,
			},
			Desc = "队伍中必须有迈克罗夫特",
			Hint = "队伍中必须有迈克罗夫特",
		},
	},
	Enemy = {
		{
			Value = 244159,
			Level = 35,
		},
	},
}
ChallengeConfig[ChallengeID.Id4145] =
{
	Id = 4145,
	Name = "挑战：睡衣侦探",
	UnlockCostList = {
		{
			Value = 320105,
			Num = 1,
		},
	},
	Character = 220324,
	AcceptSpeech = 14414501,
	Desc = "大侦探的睡衣套装，和侦探助理与教授进行枕头大战的指定套装，玩累了以后，可以直接倒下来睡觉。",
	RewardUnlock = 232145,
	ResultText = "睡衣侦探解锁了",
	NumCap = 5,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG01",
	StartScene = "SUS_StartScene",
	TeamCondition = {
		{
			Condition = "TeamCharacterIdOr",
			Value = 
			{
				220324,
			},
			Desc = "队伍中必须有大侦探",
			Hint = "队伍中必须有大侦探",
		},
	},
	Enemy = {
		{
			Value = 244160,
			Level = 75,
		},
	},
}
ChallengeConfig[ChallengeID.Id4146] =
{
	Id = 4146,
	Name = "挑战：朋克侦探",
	UnlockCostList = {
		{
			Value = 320105,
			Num = 1,
		},
	},
	Character = 220324,
	AcceptSpeech = 14414601,
	Desc = "悬疑星有史以来最大型连续剧《朋克神探》中的第一男主角。大侦探将再次与他的宿敌进行较量。不过装备了最高标准的防毒面具及灵感烟斗，这次大侦探再也不怕教授的毒雾，也不会因为被击碎灵感而无法断案了。",
	RewardUnlock = 232146,
	ResultText = "朋克侦探解锁了",
	NumCap = 5,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG01",
	StartScene = "SUS_StartScene",
	TeamCondition = {
		{
			Condition = "TeamCharacterIdOr",
			Value = 
			{
				220324,
			},
			Desc = "队伍中必须有大侦探",
			Hint = "队伍中必须有大侦探",
		},
	},
	Enemy = {
		{
			Value = 244161,
			Level = 75,
		},
	},
}
ChallengeConfig[ChallengeID.Id4147] =
{
	Id = 4147,
	Name = "挑战：卷发侦探",
	UnlockCostList = {
		{
			Value = 320105,
			Num = 1,
		},
	},
	Character = 220324,
	AcceptSpeech = 14414701,
	Desc = "穿上了心爱的针织衫后，大侦探的头发也自然卷了起来。语速似乎也加快了，没有10级的英语听力根本不知道他在说什么……",
	RewardUnlock = 232147,
	ResultText = "卷发侦探解锁了",
	NumCap = 5,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG01",
	StartScene = "SUS_StartScene",
	TeamCondition = {
		{
			Condition = "TeamCharacterIdOr",
			Value = 
			{
				220324,
			},
			Desc = "队伍中必须有大侦探",
			Hint = "队伍中必须有大侦探",
		},
	},
	Enemy = {
		{
			Value = 244162,
			Level = 75,
		},
	},
}
ChallengeConfig[ChallengeID.Id4148] =
{
	Id = 4148,
	Name = "挑战：朋克教授",
	UnlockCostList = {
		{
			Value = 320105,
			Num = 1,
		},
	},
	Character = 220325,
	AcceptSpeech = 14414801,
	Desc = "悬疑星有史以来最大型连续剧《朋克神探》中的第一反派。装备了高星实验室最新的邪恶灵感装置及增强型一发倒地枪，比以往更危险！\n据说，这次反派的目标依然是破坏城市和平，挑战大侦探。",
	RewardUnlock = 232148,
	ResultText = "朋克教授解锁了",
	NumCap = 5,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG01",
	StartScene = "SUS_StartScene",
	TeamCondition = {
		{
			Condition = "TeamCharacterIdOr",
			Value = 
			{
				220325,
			},
			Desc = "队伍中必须有教授",
			Hint = "队伍中必须有教授",
		},
	},
	Enemy = {
		{
			Value = 244163,
			Level = 75,
		},
	},
}
ChallengeConfig[ChallengeID.Id4149] =
{
	Id = 4149,
	Name = "挑战：睡衣教授",
	UnlockCostList = {
		{
			Value = 320105,
			Num = 1,
		},
	},
	Character = 220325,
	AcceptSpeech = 14414901,
	Desc = "教授的睡衣套装，和大侦探与侦探助理进行枕头大战的指定套装，玩累了以后，可以直接倒下来睡觉。",
	RewardUnlock = 232149,
	ResultText = "睡衣教授解锁了",
	NumCap = 5,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG01",
	StartScene = "SUS_StartScene",
	TeamCondition = {
		{
			Condition = "TeamCharacterIdOr",
			Value = 
			{
				220325,
			},
			Desc = "队伍中必须有教授",
			Hint = "队伍中必须有教授",
		},
	},
	Enemy = {
		{
			Value = 244164,
			Level = 75,
		},
	},
}
ChallengeConfig[ChallengeID.Id4150] =
{
	Id = 4150,
	Name = "挑战：化学教授",
	UnlockCostList = {
		{
			Value = 320105,
			Num = 1,
		},
	},
	Character = 220325,
	AcceptSpeech = 14415001,
	Desc = "内置物质转换器的防化服，据说价值180亿。可以过滤任何形式的有害物质，对于进行危险实验能起到至关重要的保护作用。",
	RewardUnlock = 232150,
	ResultText = "化学教授解锁了",
	NumCap = 5,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG01",
	StartScene = "SUS_StartScene",
	TeamCondition = {
		{
			Condition = "TeamCharacterIdOr",
			Value = 
			{
				220325,
			},
			Desc = "队伍中必须有教授",
			Hint = "队伍中必须有教授",
		},
	},
	Enemy = {
		{
			Value = 244165,
			Level = 75,
		},
	},
}
ChallengeConfig[ChallengeID.Id4151] =
{
	Id = 4151,
	Name = "挑战：外星史莱姆",
	UnlockCostList = {
		{
			Value = 320103,
			Num = 1,
		},
	},
	Character = 221001,
	AcceptSpeech = 14415101,
	Desc = "史莱姆大王的外星度假套装，内置恒温调节装置、供氧装置及排泄物处理装置。穿上这一身装备，那无论哪里都能轻松前往了。",
	RewardUnlock = 232151,
	ResultText = "外星史莱姆解锁了",
	NumCap = 5,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG01",
	StartScene = "ARENA_StartScene",
	TeamCondition = {
		{
			Condition = "TeamCharacterIdOr",
			Value = 
			{
				221001,
			},
			Desc = "队伍中必须有史莱姆大王",
			Hint = "队伍中必须有史莱姆大王",
		},
	},
	Enemy = {
		{
			Value = 244166,
			Level = 35,
		},
	},
}
ChallengeConfig[ChallengeID.Id4152] =
{
	Id = 4152,
	Name = "挑战：外星雇佣兵",
	UnlockCostList = {
		{
			Value = 320104,
			Num = 1,
		},
	},
	Character = 221002,
	AcceptSpeech = 14415201,
	Desc = "精灵王子的外星度假套装，内置特调饮料装置、热门漫画同步装置及发丝打理装置。穿上这一身装备，那无论哪里都能轻松前往了。",
	RewardUnlock = 232152,
	ResultText = "外星雇佣兵解锁了",
	NumCap = 5,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG01",
	StartScene = "ARENA_StartScene",
	TeamCondition = {
		{
			Condition = "TeamCharacterIdOr",
			Value = 
			{
				221002,
			},
			Desc = "队伍中必须有精灵王子",
			Hint = "队伍中必须有精灵王子",
		},
	},
	Enemy = {
		{
			Value = 244167,
			Level = 50,
		},
	},
}
ChallengeConfig[ChallengeID.Id4153] =
{
	Id = 4153,
	Name = "挑战：圣诞树女王",
	UnlockCostList = {
		{
			Value = 320105,
			Num = 1,
		},
	},
	Character = 221003,
	AcceptSpeech = 14415301,
	Desc = "华丽的冬季节套裙，充满了节日的气氛。灿烂夺目的灯光，让整个不夜城熠熠生辉噢~",
	RewardUnlock = 232153,
	ResultText = "圣诞树女王解锁了",
	NumCap = 5,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG01",
	StartScene = "ARENA_StartScene",
	TeamCondition = {
		{
			Condition = "TeamCharacterIdOr",
			Value = 
			{
				221003,
			},
			Desc = "队伍中必须有玉璧女王",
			Hint = "队伍中必须有玉璧女王",
		},
	},
	Enemy = {
		{
			Value = 244168,
			Level = 75,
		},
	},
}
ChallengeConfig[ChallengeID.Id4154] =
{
	Id = 4154,
	Name = "挑战：DJ酋长",
	UnlockCostList = {
		{
			Value = 320151,
			Num = 6,
		},
	},
	Character = 221004,
	AcceptSpeech = 14415401,
	Desc = "酋长的DJ套装，只要他整个人沉浸入音乐王国时，双手就会不自觉地打出完美的节拍。",
	RewardUnlock = 232154,
	ResultText = "DJ酋长解锁了",
	NumCap = 5,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG01",
	StartScene = "ARENA_StartScene",
	TeamCondition = {
		{
			Condition = "TeamCharacterIdOr",
			Value = 
			{
				221004,
			},
			Desc = "队伍中必须有部落酋长",
			Hint = "队伍中必须有部落酋长",
		},
	},
	Enemy = {
		{
			Value = 244169,
			Level = 50,
		},
	},
}
ChallengeConfig[ChallengeID.Id4155] =
{
	Id = 4155,
	Name = "挑战：菜姬",
	UnlockCostList = {
		{
			Value = 320102,
			Num = 1,
		},
	},
	Character = 221005,
	AcceptSpeech = 14415501,
	Desc = "冒险世界最菜角色的专用服装，是叶姬小姐凭借实力从一众菜鸡冒险者手中争取来的。",
	RewardUnlock = 232155,
	ResultText = "菜姬解锁了",
	NumCap = 5,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG01",
	StartScene = "ARENA_StartScene",
	TeamCondition = {
		{
			Condition = "TeamCharacterIdOr",
			Value = 
			{
				221005,
			},
			Desc = "队伍中必须有叶姬",
			Hint = "队伍中必须有叶姬",
		},
	},
	Enemy = {
		{
			Value = 244170,
			Level = 35,
		},
		{
			Value = 244171,
			Level = 35,
		},
		{
			Value = 244172,
			Level = 35,
		},
	},
}
ChallengeConfig[ChallengeID.Id4156] =
{
	Id = 4156,
	Name = "挑战：黄桃小姐",
	UnlockCostList = {
		{
			Value = 320102,
			Num = 1,
		},
	},
	Character = 221006,
	AcceptSpeech = 14415601,
	Desc = "青春活泼的黄桃礼服，让看到的人就如同吃了真的黄桃一样补充水分和矿物质，元气满满地迎接新一天的工作挑战。",
	RewardUnlock = 232156,
	ResultText = "黄桃小姐解锁了",
	NumCap = 5,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "SUSBG01",
	StartScene = "ARENA_StartScene",
	TeamCondition = {
		{
			Condition = "TeamCharacterIdOr",
			Value = 
			{
				221006,
			},
			Desc = "队伍中必须有桃几小姐",
			Hint = "队伍中必须有桃几小姐",
		},
	},
	Enemy = {
		{
			Value = 244173,
			Level = 35,
		},
	},
}
ChallengeConfig[ChallengeID.Id4157] =
{
	Id = 4157,
	Name = "挑战：死亡骑士",
	UnlockCostList = {
		{
			Value = 320105,
			Num = 1,
		},
	},
	Character = 223001,
	AcceptSpeech = 14415701,
	Desc = "在策划设定里，他们是黑暗世界向人类世界进攻的先锋骑士，他们掌握黑暗力量，使用邪恶的武器。不过事实上，他们可能只是因为这个职业造型特别帅才选择了它。",
	RewardUnlock = 232157,
	ResultText = "死亡骑士解锁了",
	NumCap = 5,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG01",
	StartScene = "RPG_StartScene",
	TeamCondition = {
		{
			Condition = "TeamCharacterIdOr",
			Value = 
			{
				223001,
			},
			Desc = "队伍中必须有圣骑士",
			Hint = "队伍中必须有圣骑士",
		},
	},
	Enemy = {
		{
			Value = 244174,
			Level = 75,
		},
	},
}
ChallengeConfig[ChallengeID.Id4158] =
{
	Id = 4158,
	Name = "挑战：雄鹰氏族",
	UnlockCostList = {
		{
			Value = 320105,
			Num = 1,
		},
	},
	Character = 223002,
	AcceptSpeech = 14415801,
	Desc = "来自高地的野蛮人，以巨鹰作为氏族图腾。其特制的雄鹰头冠非常帅气，不过只有成为其族人，才能获得佩戴鹰冠的殊荣。",
	RewardUnlock = 232158,
	ResultText = "雄鹰氏族解锁了",
	NumCap = 5,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG01",
	StartScene = "RPG_StartScene",
	TeamCondition = {
		{
			Condition = "TeamCharacterIdOr",
			Value = 
			{
				223002,
			},
			Desc = "队伍中必须有野蛮人",
			Hint = "队伍中必须有野蛮人",
		},
	},
	Enemy = {
		{
			Value = 244175,
			Level = 75,
		},
	},
}
ChallengeConfig[ChallengeID.Id4159] =
{
	Id = 4159,
	Name = "挑战：吟游诗人",
	UnlockCostList = {
		{
			Value = 320105,
			Num = 1,
		},
	},
	Character = 223003,
	AcceptSpeech = 14415901,
	Desc = "流浪于冒险世界各个角落的吟游诗人，他们最擅长在轻快的琴声中为酒馆诸人唱上一段英雄叙事诗，不过其实他们还有很多别的生存本领。",
	RewardUnlock = 232159,
	ResultText = "吟游诗人解锁了",
	NumCap = 5,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG01",
	StartScene = "RPG_StartScene",
	TeamCondition = {
		{
			Condition = "TeamCharacterIdOr",
			Value = 
			{
				223003,
			},
			Desc = "队伍中必须有盗贼",
			Hint = "队伍中必须有盗贼",
		},
	},
	Enemy = {
		{
			Value = 244176,
			Level = 75,
		},
	},
}
ChallengeConfig[ChallengeID.Id4160] =
{
	Id = 4160,
	Name = "挑战：巫女",
	UnlockCostList = {
		{
			Value = 320105,
			Num = 1,
		},
	},
	Character = 223004,
	AcceptSpeech = 14416001,
	Desc = "依靠巫女神楽就能安抚附近的神明。巫女正是依靠这种特殊的方式保护身边之人的。跟随节拍，只要诚心地进行祈福，就能得到神明的保佑。",
	RewardUnlock = 232160,
	ResultText = "巫女解锁了",
	NumCap = 5,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG01",
	StartScene = "RPG_StartScene",
	TeamCondition = {
		{
			Condition = "TeamCharacterIdOr",
			Value = 
			{
				223004,
			},
			Desc = "队伍中必须有舞娘",
			Hint = "队伍中必须有舞娘",
		},
	},
	Enemy = {
		{
			Value = 244177,
			Level = 75,
		},
	},
}
ChallengeConfig[ChallengeID.Id4161] =
{
	Id = 4161,
	Name = "挑战：死灵法师",
	UnlockCostList = {
		{
			Value = 320105,
			Num = 1,
		},
	},
	Character = 223005,
	AcceptSpeech = 14416101,
	Desc = "穿梭于活人与死人世界间的通灵法师，死灵法师能够召唤亡灵与之谈话，且可以缔结种种约束控制被自己召回现世的亡灵。",
	RewardUnlock = 232161,
	ResultText = "死灵法师解锁了",
	NumCap = 5,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG01",
	StartScene = "RPG_StartScene",
	TeamCondition = {
		{
			Condition = "TeamCharacterIdOr",
			Value = 
			{
				223005,
			},
			Desc = "队伍中必须有学者",
			Hint = "队伍中必须有学者",
		},
	},
	Enemy = {
		{
			Value = 244178,
			Level = 75,
		},
	},
}
ChallengeConfig[ChallengeID.Id4162] =
{
	Id = 4162,
	Name = "挑战：炼金术师",
	UnlockCostList = {
		{
			Value = 320105,
			Num = 1,
		},
	},
	Character = 223006,
	AcceptSpeech = 14416201,
	Desc = "装备了铁匠工具的药师，能够应对更多复杂的手工作业了。",
	RewardUnlock = 232162,
	ResultText = "炼金术师解锁了",
	NumCap = 5,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG01",
	StartScene = "RPG_StartScene",
	TeamCondition = {
		{
			Condition = "TeamCharacterIdOr",
			Value = 
			{
				223006,
			},
			Desc = "队伍中必须有药师",
			Hint = "队伍中必须有药师",
		},
	},
	Enemy = {
		{
			Value = 244179,
			Level = 75,
		},
	},
}
ChallengeConfig[ChallengeID.Id4163] =
{
	Id = 4163,
	Name = "挑战：新的视界",
	UnlockCostList = {
		{
			Value = 320104,
			Num = 1,
		},
	},
	Character = 220426,
	AcceptSpeech = 14416301,
	Desc = "更改了发型，意外地发现视野竟然开阔了许多，粉丝们也表示非常惊喜。虽然牙牙个人不太喜欢，却还是老老实实接受了。",
	RewardUnlock = 232188,
	ResultText = "新的视界解锁了",
	NumCap = 5,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG01",
	StartScene = "SEA_StartScene",
	TeamCondition = {
		{
			Condition = "TeamCharacterIdOr",
			Value = 
			{
				220426,
			},
			Desc = "队伍中必须有白鲨牙牙",
			Hint = "队伍中必须有白鲨牙牙",
		},
	},
	Enemy = {
		{
			Value = 244180,
			Level = 50,
		},
	},
}
ChallengeConfig[ChallengeID.Id4164] =
{
	Id = 4164,
	Name = "挑战：真正的自己",
	UnlockCostList = {
		{
			Value = 320104,
			Num = 1,
		},
	},
	Character = 220427,
	AcceptSpeech = 14416401,
	Desc = "赶走骚扰自己的私生后，鲸鲨依伶从不知何处获得了力量和喜悦，大概是一直戴着温柔懂事的面具，而现在终于可以做回自己了吧。",
	RewardUnlock = 232189,
	ResultText = "真正的自己解锁了",
	NumCap = 5,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG01",
	StartScene = "SEA_StartScene",
	TeamCondition = {
		{
			Condition = "TeamCharacterIdOr",
			Value = 
			{
				220427,
			},
			Desc = "队伍中必须有鲸鲨依伶",
			Hint = "队伍中必须有鲸鲨依伶",
		},
	},
	Enemy = {
		{
			Value = 244181,
			Level = 50,
		},
	},
}
ChallengeConfig[ChallengeID.Id4165] =
{
	Id = 4165,
	Name = "挑战：酷boy映冬",
	UnlockCostList = {
		{
			Value = 320104,
			Num = 1,
		},
	},
	Character = 220428,
	AcceptSpeech = 14416501,
	Desc = "背带裤衬托精致的身形，七分裤未遮掩洁白的脚腕。这套衣服穿上后，会帅气值提高了999点。",
	RewardUnlock = 232190,
	ResultText = "酷boy映冬解锁了",
	NumCap = 3,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG01",
	StartScene = "SEA_StartScene",
	TeamCondition = {
		{
			Condition = "TeamCharacterIdOr",
			Value = 
			{
				220428,
			},
			Desc = "队伍中必须有琵琶映冬",
			Hint = "队伍中必须有琵琶映冬",
		},
	},
	Enemy = {
		{
			Value = 244182,
			Level = 50,
		},
	},
}
ChallengeConfig[ChallengeID.Id4166] =
{
	Id = 4166,
	Name = "挑战：粉红海豚",
	UnlockCostList = {
		{
			Value = 320103,
			Num = 1,
		},
	},
	Character = 220401,
	AcceptSpeech = 14416601,
	Desc = "凛增加了健身项目后，由于长期的剧烈运动，身体发生了一些变化，成为了拥有奇异颜色的粉红海豚。",
	RewardUnlock = 232163,
	ResultText = "粉红海豚解锁了",
	NumCap = 3,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG01",
	StartScene = "SEA_StartScene",
	TeamCondition = {
		{
			Condition = "TeamCharacterIdOr",
			Value = 
			{
				220401,
			},
			Desc = "队伍中必须有海豚凛",
			Hint = "队伍中必须有海豚凛",
		},
	},
	Enemy = {
		{
			Value = 244183,
			Level = 35,
		},
	},
}
ChallengeConfig[ChallengeID.Id4167] =
{
	Id = 4167,
	Name = "挑战：侠客珍",
	UnlockCostList = {
		{
			Value = 320103,
			Num = 1,
		},
	},
	Character = 220407,
	AcceptSpeech = 14416701,
	Desc = "自从发现自己的珍珠具有亮瞎别人眼睛的功能，珍就开展了抓贼的副业，还因此得到了海洋警局的赞美。",
	RewardUnlock = 232169,
	ResultText = "侠客珍解锁了",
	NumCap = 3,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG01",
	StartScene = "SEA_StartScene",
	TeamCondition = {
		{
			Condition = "TeamCharacterIdOr",
			Value = 
			{
				220407,
			},
			Desc = "队伍中必须有扇贝珍",
			Hint = "队伍中必须有扇贝珍",
		},
	},
	Enemy = {
		{
			Value = 244184,
			Level = 35,
		},
	},
}
ChallengeConfig[ChallengeID.Id4168] =
{
	Id = 4168,
	Name = "挑战：人气主播",
	UnlockCostList = {
		{
			Value = 320103,
			Num = 1,
		},
	},
	Character = 220408,
	AcceptSpeech = 14416801,
	Desc = "在换上男装后，美莎“男装大佬”的形象果然成功吸引了众多观众，TA的商业价值也因此在鱼乐圈偶像中上升至top1。",
	RewardUnlock = 232170,
	ResultText = "人气主播解锁了",
	NumCap = 5,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG01",
	StartScene = "SEA_StartScene",
	TeamCondition = {
		{
			Condition = "TeamCharacterIdOr",
			Value = 
			{
				220408,
			},
			Desc = "队伍中必须有海螺美莎",
			Hint = "队伍中必须有海螺美莎",
		},
	},
	Enemy = {
		{
			Value = 244185,
			Level = 35,
		},
	},
}
ChallengeConfig[ChallengeID.Id4169] =
{
	Id = 4169,
	Name = "挑战：耀眼新星",
	UnlockCostList = {
		{
			Value = 320103,
			Num = 1,
		},
	},
	Character = 220404,
	AcceptSpeech = 14416901,
	Desc = "在导演面前大闹一场，虽然有些冲动，但大家都注意到了椰子，TA的知名度迅速提升了。",
	RewardUnlock = 232166,
	ResultText = "耀眼新星解锁了",
	NumCap = 5,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "SEABG03",
	StartScene = "SEA_StartScene",
	TeamCondition = {
		{
			Condition = "TeamCharacterIdOr",
			Value = 
			{
				220404,
			},
			Desc = "队伍中必须有鲎椰子",
			Hint = "队伍中必须有鲎椰子",
		},
	},
	Enemy = {
		{
			Value = 244186,
			Level = 35,
		},
	},
}
ChallengeConfig[ChallengeID.Id4170] =
{
	Id = 4170,
	Name = "挑战：达人香菜",
	UnlockCostList = {
		{
			Value = 320103,
			Num = 1,
		},
	},
	Character = 220409,
	AcceptSpeech = 14417001,
	Desc = "用上了牛皮鼓后，演出中再没出现鼓被敲破的场景。香菜的地位也不断被重视，终于成为了当红鼓手。",
	RewardUnlock = 232171,
	ResultText = "达人香菜解锁了",
	NumCap = 5,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG01",
	StartScene = "SEA_StartScene",
	TeamCondition = {
		{
			Condition = "TeamCharacterIdOr",
			Value = 
			{
				220409,
			},
			Desc = "队伍中必须有蟹香菜",
			Hint = "队伍中必须有蟹香菜",
		},
	},
	Enemy = {
		{
			Value = 244187,
			Level = 35,
		},
	},
}
ChallengeConfig[ChallengeID.Id4171] =
{
	Id = 4171,
	Name = "挑战：摇滚伊洛",
	UnlockCostList = {
		{
			Value = 320103,
			Num = 1,
		},
	},
	Character = 220410,
	AcceptSpeech = 14417101,
	Desc = "虾伊洛终于成功通过面试，去了外星学习，现在，TA的弹琴水平已经炉火纯青了。",
	RewardUnlock = 232172,
	ResultText = "摇滚伊洛解锁了",
	NumCap = 5,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG01",
	StartScene = "SEA_StartScene",
	TeamCondition = {
		{
			Condition = "TeamCharacterIdOr",
			Value = 
			{
				220410,
			},
			Desc = "队伍中必须有虾伊洛",
			Hint = "队伍中必须有虾伊洛",
		},
	},
	Enemy = {
		{
			Value = 244188,
			Level = 35,
		},
	},
}
ChallengeConfig[ChallengeID.Id4172] =
{
	Id = 4172,
	Name = "挑战：翌日的幻然",
	UnlockCostList = {
		{
			Value = 320103,
			Num = 1,
		},
	},
	Character = 220411,
	AcceptSpeech = 14417201,
	Desc = "在胖揍了32块镜子后，幻然意识到了问题的严重性——这世界上骗人的镜子越来越多了，于是TA只得无奈接受了现状。",
	RewardUnlock = 232173,
	ResultText = "翌日的幻然解锁了",
	NumCap = 5,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG01",
	StartScene = "SEA_StartScene",
	TeamCondition = {
		{
			Condition = "TeamCharacterIdOr",
			Value = 
			{
				220411,
			},
			Desc = "队伍中必须有海兔幻然",
			Hint = "队伍中必须有海兔幻然",
		},
	},
	Enemy = {
		{
			Value = 244189,
			Level = 35,
		},
	},
}
ChallengeConfig[ChallengeID.Id4173] =
{
	Id = 4173,
	Name = "挑战：新人遥",
	UnlockCostList = {
		{
			Value = 320103,
			Num = 1,
		},
	},
	Character = 220412,
	AcceptSpeech = 14417301,
	Desc = "非常正经的衣服，确保观众不会联想到小丑，误以为自己是杂技团演员。唯一的缺点是，观众现在也看不出TA是个偶像了。",
	RewardUnlock = 232174,
	ResultText = "新人遥解锁了",
	NumCap = 5,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG01",
	StartScene = "SEA_StartScene",
	TeamCondition = {
		{
			Condition = "TeamCharacterIdOr",
			Value = 
			{
				220412,
			},
			Desc = "队伍中必须有小丑遥",
			Hint = "队伍中必须有小丑遥",
		},
	},
	Enemy = {
		{
			Value = 244190,
			Level = 35,
		},
		{
			Value = 244191,
			Level = 35,
		},
	},
}
ChallengeConfig[ChallengeID.Id4174] =
{
	Id = 4174,
	Name = "挑战：黑嗓小茨",
	UnlockCostList = {
		{
			Value = 320103,
			Num = 1,
		},
	},
	Character = 220413,
	AcceptSpeech = 14417401,
	Desc = "为了不让自己的歌声将观众的头盖骨掀翻，小茨戴了一个海胆头作为测试。每当TA感觉到这个海胆头要脱落时，都会稍稍控制下自己的嗓音。",
	RewardUnlock = 232175,
	ResultText = "黑嗓小茨解锁了",
	NumCap = 5,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG01",
	StartScene = "SEA_StartScene",
	TeamCondition = {
		{
			Condition = "TeamCharacterIdOr",
			Value = 
			{
				220413,
			},
			Desc = "队伍中必须有海胆小茨",
			Hint = "队伍中必须有海胆小茨",
		},
	},
	Enemy = {
		{
			Value = 244192,
			Level = 35,
		},
	},
}
ChallengeConfig[ChallengeID.Id4175] =
{
	Id = 4175,
	Name = "挑战：双生翻",
	UnlockCostList = {
		{
			Value = 320103,
			Num = 1,
		},
	},
	Character = 220406,
	AcceptSpeech = 14417501,
	Desc = "因为总是被欺负，鱼不翻分裂出了另一个人格保护自己。从此，再也没有人敢欺负TA了。",
	RewardUnlock = 232168,
	ResultText = "双生翻解锁了",
	NumCap = 5,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG01",
	StartScene = "SEA_StartScene",
	TeamCondition = {
		{
			Condition = "TeamCharacterIdOr",
			Value = 
			{
				220406,
			},
			Desc = "队伍中必须有鱼不翻",
			Hint = "队伍中必须有鱼不翻",
		},
	},
	Enemy = {
		{
			Value = 244193,
			Level = 35,
		},
	},
}
ChallengeConfig[ChallengeID.Id4176] =
{
	Id = 4176,
	Name = "挑战：核嗓凉风",
	UnlockCostList = {
		{
			Value = 320103,
			Num = 1,
		},
	},
	Character = 220414,
	AcceptSpeech = 14417601,
	Desc = "为了出演《华丽的贵公子》舞台剧，凉风改变了风格，飒爽的英姿与同时具备两性魅力的特征吸引了无数尖叫声。",
	RewardUnlock = 232176,
	ResultText = "核嗓凉风解锁了",
	NumCap = 5,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG01",
	StartScene = "SEA_StartScene",
	TeamCondition = {
		{
			Condition = "TeamCharacterIdOr",
			Value = 
			{
				220414,
			},
			Desc = "队伍中必须有蝠鲼凉风",
			Hint = "队伍中必须有蝠鲼凉风",
		},
	},
	Enemy = {
		{
			Value = 244194,
			Level = 35,
		},
		{
			Value = 244195,
			Level = 35,
		},
	},
}
ChallengeConfig[ChallengeID.Id4177] =
{
	Id = 4177,
	Name = "挑战：舞王希波",
	UnlockCostList = {
		{
			Value = 320103,
			Num = 1,
		},
	},
	Character = 220415,
	AcceptSpeech = 14417701,
	Desc = "将额前的头发用秘制发胶固定，看上去非常丝滑。经测试，在12级台风天行走也不会变形。",
	RewardUnlock = 232177,
	ResultText = "舞王希波解锁了",
	NumCap = 5,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG01",
	StartScene = "SEA_StartScene",
	TeamCondition = {
		{
			Condition = "TeamCharacterIdOr",
			Value = 
			{
				220415,
			},
			Desc = "队伍中必须有海马希波",
			Hint = "队伍中必须有海马希波",
		},
	},
	Enemy = {
		{
			Value = 244196,
			Level = 35,
		},
	},
}
ChallengeConfig[ChallengeID.Id4178] =
{
	Id = 4178,
	Name = "挑战：控场茉白",
	UnlockCostList = {
		{
			Value = 320103,
			Num = 1,
		},
	},
	Character = 220405,
	AcceptSpeech = 14417801,
	Desc = "在发现《莫生气》口诀也救不了自己后，茉白自觉地去定制了一套紧身服，希望可以用它来提醒自己不要生气。",
	RewardUnlock = 232167,
	ResultText = "控场茉白解锁了",
	NumCap = 5,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "SEABG03",
	StartScene = "SEA_StartScene",
	TeamCondition = {
		{
			Condition = "TeamCharacterIdOr",
			Value = 
			{
				220405,
			},
			Desc = "队伍中必须有刺豚茉白",
			Hint = "队伍中必须有刺豚茉白",
		},
	},
	Enemy = {
		{
			Value = 244197,
			Level = 35,
		},
	},
}
ChallengeConfig[ChallengeID.Id4179] =
{
	Id = 4179,
	Name = "挑战：时尚先锋",
	UnlockCostList = {
		{
			Value = 320103,
			Num = 1,
		},
	},
	Character = 220416,
	AcceptSpeech = 14417901,
	Desc = "在造型设计师的努力下，彩雅终于收获了满意的造型，感觉自己的时尚感又增加了许多。",
	RewardUnlock = 232178,
	ResultText = "时尚先锋解锁了",
	NumCap = 5,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG01",
	StartScene = "SEA_StartScene",
	TeamCondition = {
		{
			Condition = "TeamCharacterIdOr",
			Value = 
			{
				220416,
			},
			Desc = "队伍中必须有海葵彩雅",
			Hint = "队伍中必须有海葵彩雅",
		},
	},
	Enemy = {
		{
			Value = 244198,
			Level = 35,
		},
	},
}
ChallengeConfig[ChallengeID.Id4180] =
{
	Id = 4180,
	Name = "挑战：狂野希",
	UnlockCostList = {
		{
			Value = 320103,
			Num = 1,
		},
	},
	Character = 220417,
	AcceptSpeech = 14418001,
	Desc = "为了在演唱会出入方便，斗鱼希换了一身打扮，特别是将发荡不羁爱自由的头发收束了起来，这样一来，效果好了不少。",
	RewardUnlock = 232179,
	ResultText = "狂野希解锁了",
	NumCap = 5,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "SEABG03",
	StartScene = "SEA_StartScene",
	TeamCondition = {
		{
			Condition = "TeamCharacterIdOr",
			Value = 
			{
				220417,
			},
			Desc = "队伍中必须有斗鱼希",
			Hint = "队伍中必须有斗鱼希",
		},
	},
	Enemy = {
		{
			Value = 244199,
			Level = 35,
		},
	},
}
ChallengeConfig[ChallengeID.Id4181] =
{
	Id = 4181,
	Name = "挑战：导师墨",
	UnlockCostList = {
		{
			Value = 320103,
			Num = 1,
		},
	},
	Character = 220402,
	AcceptSpeech = 14418101,
	Desc = "当上培训老师后，墨除了传授各种音乐技巧外，还经常和学员分享鱼乐圈的新鲜事。每到这时，TA都会严肃地讲一句：这瓜不保真。",
	RewardUnlock = 232164,
	ResultText = "导师墨解锁了",
	NumCap = 5,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG01",
	StartScene = "SEA_StartScene",
	TeamCondition = {
		{
			Condition = "TeamCharacterIdOr",
			Value = 
			{
				220402,
			},
			Desc = "队伍中必须有乌贼墨",
			Hint = "队伍中必须有乌贼墨",
		},
	},
	Enemy = {
		{
			Value = 244200,
			Level = 35,
		},
	},
}
ChallengeConfig[ChallengeID.Id4182] =
{
	Id = 4182,
	Name = "挑战：爆破橘",
	UnlockCostList = {
		{
			Value = 320103,
			Num = 1,
		},
	},
	Character = 220418,
	AcceptSpeech = 14418201,
	Desc = "在「三参有幸一起唱」的主题演唱会上，为橘定制的服装。头上和脖子上的名贵海参由橘有钱的爸爸提供。再次声明，橘是凭实力参与提案会的！",
	RewardUnlock = 232180,
	ResultText = "爆破橘解锁了",
	NumCap = 5,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG01",
	StartScene = "SEA_StartScene",
	TeamCondition = {
		{
			Condition = "TeamCharacterIdOr",
			Value = 
			{
				220418,
			},
			Desc = "队伍中必须有海参橘",
			Hint = "队伍中必须有海参橘",
		},
	},
	Enemy = {
		{
			Value = 244201,
			Level = 35,
		},
		{
			Value = 244202,
			Level = 35,
		},
		{
			Value = 244203,
			Level = 35,
		},
	},
}
ChallengeConfig[ChallengeID.Id4183] =
{
	Id = 4183,
	Name = "挑战：光影未来",
	UnlockCostList = {
		{
			Value = 320103,
			Num = 1,
		},
	},
	Character = 220419,
	AcceptSpeech = 14418301,
	Desc = "从医院出来后，为了让自己两只眼睛变成同样的视力，于是在另一侧也装上了灯泡。",
	RewardUnlock = 232181,
	ResultText = "光影未来解锁了",
	NumCap = 5,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG01",
	StartScene = "SEA_StartScene",
	TeamCondition = {
		{
			Condition = "TeamCharacterIdOr",
			Value = 
			{
				220419,
			},
			Desc = "队伍中必须有鮟鱇明",
			Hint = "队伍中必须有鮟鱇明",
		},
	},
	Enemy = {
		{
			Value = 244204,
			Level = 35,
		},
	},
}
ChallengeConfig[ChallengeID.Id4184] =
{
	Id = 4184,
	Name = "挑战：欧皇彩",
	UnlockCostList = {
		{
			Value = 320104,
			Num = 1,
		},
	},
	Character = 220420,
	AcceptSpeech = 14418401,
	Desc = "打败了不夜城的家伙后，海豹彩正大光明地接下了奖池代抽的工作，因为奖金极高，整个人都容光焕发了起来。",
	RewardUnlock = 232182,
	ResultText = "欧皇彩解锁了",
	NumCap = 5,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG01",
	StartScene = "SEA_StartScene",
	TeamCondition = {
		{
			Condition = "TeamCharacterIdOr",
			Value = 
			{
				220420,
			},
			Desc = "队伍中必须有海豹彩",
			Hint = "队伍中必须有海豹彩",
		},
	},
	Enemy = {
		{
			Value = 244205,
			Level = 50,
		},
		{
			Value = 244206,
			Level = 50,
		},
		{
			Value = 244207,
			Level = 50,
		},
	},
}
ChallengeConfig[ChallengeID.Id4185] =
{
	Id = 4185,
	Name = "挑战：豹纹闪电",
	UnlockCostList = {
		{
			Value = 320104,
			Num = 1,
		},
	},
	Character = 220403,
	AcceptSpeech = 14418501,
	Desc = "换上这套自己设计的服装后，鳗鱼伊俄的粉丝们兴奋不已不已，纷纷表示没见过有人能把长颈鹿装穿得这么好看。甚至配合服装，粉丝们还为TA想好了下一场演唱会的主题：「一鹿有你」。",
	RewardUnlock = 232165,
	ResultText = "豹纹闪电解锁了",
	NumCap = 5,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG01",
	StartScene = "SEA_StartScene",
	TeamCondition = {
		{
			Condition = "TeamCharacterIdOr",
			Value = 
			{
				220403,
			},
			Desc = "队伍中必须有电鳗伊俄",
			Hint = "队伍中必须有电鳗伊俄",
		},
	},
	Enemy = {
		{
			Value = 244208,
			Level = 50,
		},
	},
}
ChallengeConfig[ChallengeID.Id4186] =
{
	Id = 4186,
	Name = "挑战：僧帽纱纱",
	UnlockCostList = {
		{
			Value = 320104,
			Num = 1,
		},
	},
	Character = 220421,
	AcceptSpeech = 14418601,
	Desc = "纱纱喝下药水，得偿所愿，变成了“谁摸谁死”的体质。虽说依然不能和好友拥抱，但因为自己也可以保护别人了，而变得非常开心。",
	RewardUnlock = 232183,
	ResultText = "僧帽纱纱解锁了",
	NumCap = 5,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG01",
	StartScene = "SEA_StartScene",
	TeamCondition = {
		{
			Condition = "TeamCharacterIdOr",
			Value = 
			{
				220421,
			},
			Desc = "队伍中必须有黄金纱纱",
			Hint = "队伍中必须有黄金纱纱",
		},
	},
	Enemy = {
		{
			Value = 244209,
			Level = 50,
		},
	},
}
ChallengeConfig[ChallengeID.Id4187] =
{
	Id = 4187,
	Name = "挑战：大正和风",
	UnlockCostList = {
		{
			Value = 320104,
			Num = 1,
		},
	},
	Character = 220422,
	AcceptSpeech = 14418701,
	Desc = "向馆主证明了自己的决心后，丝丝终于穿上了威风凛凛的大正和服。当握紧武士刀的时候，TA总会心头一热——“纵然逃脱不了分离的命运，但至少现在可以守护着TA”。",
	RewardUnlock = 232184,
	ResultText = "大正和风解锁了",
	NumCap = 5,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "SEABG03",
	StartScene = "SEA_StartScene",
	TeamCondition = {
		{
			Condition = "TeamCharacterIdOr",
			Value = 
			{
				220422,
			},
			Desc = "队伍中必须有灯塔丝丝",
			Hint = "队伍中必须有灯塔丝丝",
		},
	},
	Enemy = {
		{
			Value = 244210,
			Level = 50,
		},
	},
}
ChallengeConfig[ChallengeID.Id4188] =
{
	Id = 4188,
	Name = "挑战：深渊的寻沙",
	UnlockCostList = {
		{
			Value = 320104,
			Num = 1,
		},
	},
	Character = 220423,
	AcceptSpeech = 14418801,
	Desc = "原以为《逆袭的二公子》讲的是被笼罩在优秀大哥阴影下的角色故事。等实际排练才发现这个角色是家中独子，原来这个「二」并不是指排位……",
	RewardUnlock = 232185,
	ResultText = "深渊的寻沙解锁了",
	NumCap = 5,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG01",
	StartScene = "SEA_StartScene",
	TeamCondition = {
		{
			Condition = "TeamCharacterIdOr",
			Value = 
			{
				220423,
			},
			Desc = "队伍中必须有海星寻沙",
			Hint = "队伍中必须有海星寻沙",
		},
	},
	Enemy = {
		{
			Value = 244211,
			Level = 50,
		},
		{
			Value = 244212,
			Level = 50,
		},
	},
}
ChallengeConfig[ChallengeID.Id4189] =
{
	Id = 4189,
	Name = "挑战：蓝环舞妍",
	UnlockCostList = {
		{
			Value = 320104,
			Num = 1,
		},
	},
	Character = 220424,
	AcceptSpeech = 14418901,
	Desc = "虽然近似的长相无法改变，但为了不再让歌迷把自己和刺豚茉白搞混，舞妍换了一套风格更加鲜明的服装。",
	RewardUnlock = 232186,
	ResultText = "蓝环舞妍解锁了",
	NumCap = 5,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG01",
	StartScene = "SEA_StartScene",
	TeamCondition = {
		{
			Condition = "TeamCharacterIdOr",
			Value = 
			{
				220424,
			},
			Desc = "队伍中必须有章鱼舞妍",
			Hint = "队伍中必须有章鱼舞妍",
		},
	},
	Enemy = {
		{
			Value = 244213,
			Level = 50,
		},
	},
}
ChallengeConfig[ChallengeID.Id4190] =
{
	Id = 4190,
	Name = "挑战：黑白森林",
	UnlockCostList = {
		{
			Value = 320104,
			Num = 1,
		},
	},
	Character = 220425,
	AcceptSpeech = 14419001,
	Desc = "黑白两色的搭配，完美地烘托了话剧的主题。只是在排练时经常走错站位，加上总是带着蛇出行，因此被凉风和寻沙调侃是《蛇皮的黑白执事》。",
	RewardUnlock = 232187,
	ResultText = "黑白森林解锁了",
	NumCap = 5,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG01",
	StartScene = "SEA_StartScene",
	TeamCondition = {
		{
			Condition = "TeamCharacterIdOr",
			Value = 
			{
				220425,
			},
			Desc = "队伍中必须有海蛇莱斯莉",
			Hint = "队伍中必须有海蛇莱斯莉",
		},
	},
	Enemy = {
		{
			Value = 244214,
			Level = 50,
		},
		{
			Value = 244215,
			Level = 50,
		},
	},
}
ChallengeConfig[ChallengeID.Id4191] =
{
	Id = 4191,
	Name = "挑战：人气珊瑚",
	UnlockCostList = {
		{
			Value = 320105,
			Num = 1,
		},
	},
	Character = 220429,
	AcceptSpeech = 14419101,
	Desc = "珊瑚在晚会上高歌一曲，获得了观众们的喜爱和赞美，还和假唱艺人形成鲜明对比，在海洋网络上的人气迅速上涨。",
	RewardUnlock = 232191,
	ResultText = "人气珊瑚解锁了",
	NumCap = 5,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "SEABG03",
	StartScene = "SEA_StartScene",
	TeamCondition = {
		{
			Condition = "TeamCharacterIdOr",
			Value = 
			{
				220429,
			},
			Desc = "队伍中必须有珊瑚阿卡",
			Hint = "队伍中必须有珊瑚阿卡",
		},
	},
	Enemy = {
		{
			Value = 244216,
			Level = 75,
		},
	},
}
ChallengeConfig[ChallengeID.Id4192] =
{
	Id = 4192,
	Name = "挑战：真正的王者",
	UnlockCostList = {
		{
			Value = 320105,
			Num = 1,
		},
	},
	Character = 220430,
	AcceptSpeech = 14419201,
	Desc = "逃脱梦魇，虎鲸京放下过往，整个世界似乎明亮了，TA反复告诉自己，不管经历什么，都不能丢掉爱与温柔，才能成为真正的王者。",
	RewardUnlock = 232192,
	ResultText = "真正的王者解锁了",
	NumCap = 5,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG01",
	StartScene = "SEA_StartScene",
	TeamCondition = {
		{
			Condition = "TeamCharacterIdOr",
			Value = 
			{
				220430,
			},
			Desc = "队伍中必须有虎鲸京",
			Hint = "队伍中必须有虎鲸京",
		},
	},
	Enemy = {
		{
			Value = 244217,
			Level = 75,
		},
	},
}
ChallengeConfig[ChallengeID.Id4193] =
{
	Id = 4193,
	Name = "挑战：黑国王",
	UnlockCostList = {
		{
			Value = 320104,
			Num = 1,
		},
	},
	Character = 223041,
	AcceptSpeech = 14419301,
	Desc = "黑棋星人的世代领袖，每天都在思考如何组织新的攻势反击白棋星人。本身虽然非常弱小，经常成为对方进攻的突破口，不过依靠手下们的拼死保护，每次都能毫发无伤。",
	RewardUnlock = 232223,
	ResultText = "黑国王解锁了",
	NumCap = 5,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG01",
	StartScene = "ARENA_StartScene",
	TeamCondition = {
		{
			Condition = "TeamCharacterIdOr",
			Value = 
			{
				223041,
			},
			Desc = "队伍中必须有白国王",
			Hint = "队伍中必须有白国王",
		},
	},
	Enemy = {
		{
			Value = 244218,
			Level = 50,
		},
	},
}
ChallengeConfig[ChallengeID.Id4194] =
{
	Id = 4194,
	Name = "挑战：黑皇后",
	UnlockCostList = {
		{
			Value = 320104,
			Num = 1,
		},
	},
	Character = 223042,
	AcceptSpeech = 14419401,
	Desc = "地位仅次于国王的黑棋皇后，能够调动娘家军团四面出击。据说，以前进攻能力非常弱，后来凭借其背后的娘家势力，多次逼迫委员会修改规则，才成为战场上最逆天的存在。",
	RewardUnlock = 232224,
	ResultText = "黑皇后解锁了",
	NumCap = 5,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG01",
	StartScene = "ARENA_StartScene",
	TeamCondition = {
		{
			Condition = "TeamCharacterIdOr",
			Value = 
			{
				223042,
			},
			Desc = "队伍中必须有白皇后",
			Hint = "队伍中必须有白皇后",
		},
	},
	Enemy = {
		{
			Value = 244219,
			Level = 50,
		},
	},
}
ChallengeConfig[ChallengeID.Id4195] =
{
	Id = 4195,
	Name = "挑战：黑主教",
	UnlockCostList = {
		{
			Value = 320104,
			Num = 1,
		},
	},
	Character = 223043,
	AcceptSpeech = 14419501,
	Desc = "黑棋国的大主教，是民众信仰的象征，在战场上可以斜着随便走。平时虽然经常和国王暗中较劲，但是大敌当前时，会不顾一切地保护国王。",
	RewardUnlock = 232225,
	ResultText = "黑主教解锁了",
	NumCap = 5,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG01",
	StartScene = "ARENA_StartScene",
	TeamCondition = {
		{
			Condition = "TeamCharacterIdOr",
			Value = 
			{
				223043,
			},
			Desc = "队伍中必须有白主教",
			Hint = "队伍中必须有白主教",
		},
	},
	Enemy = {
		{
			Value = 244220,
			Level = 50,
		},
	},
}
ChallengeConfig[ChallengeID.Id4196] =
{
	Id = 4196,
	Name = "挑战：黑城堡",
	UnlockCostList = {
		{
			Value = 320104,
			Num = 1,
		},
	},
	Character = 223044,
	AcceptSpeech = 14419601,
	Desc = "代表着王国最强兵器的强力战车，也被人称为黑色城堡，在战场上可以横行无忌。作战风格异常勇猛，经常比赛还未开始，便已孤身一人杀入敌阵，曾多次被裁判罚判抢步。",
	RewardUnlock = 232226,
	ResultText = "黑城堡解锁了",
	NumCap = 5,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG01",
	StartScene = "ARENA_StartScene",
	TeamCondition = {
		{
			Condition = "TeamCharacterIdOr",
			Value = 
			{
				223044,
			},
			Desc = "队伍中必须有白城堡",
			Hint = "队伍中必须有白城堡",
		},
	},
	Enemy = {
		{
			Value = 244221,
			Level = 50,
		},
	},
}
ChallengeConfig[ChallengeID.Id4197] =
{
	Id = 4197,
	Name = "挑战：黑骑士",
	UnlockCostList = {
		{
			Value = 320104,
			Num = 1,
		},
	},
	Character = 223045,
	AcceptSpeech = 14419701,
	Desc = "受到国王册封，荣升骑士头衔的战马，象征着王国高贵的骑士精神。平时虽然总是标榜自己的崇高道德，不过打完仗拿战利品时却毫不手软。",
	RewardUnlock = 232227,
	ResultText = "黑骑士解锁了",
	NumCap = 5,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG01",
	StartScene = "ARENA_StartScene",
	TeamCondition = {
		{
			Condition = "TeamCharacterIdOr",
			Value = 
			{
				223045,
			},
			Desc = "队伍中必须有白骑士",
			Hint = "队伍中必须有白骑士",
		},
	},
	Enemy = {
		{
			Value = 244222,
			Level = 50,
		},
	},
}
ChallengeConfig[ChallengeID.Id4198] =
{
	Id = 4198,
	Name = "挑战：黑卫兵",
	UnlockCostList = {
		{
			Value = 320103,
			Num = 1,
		},
	},
	Character = 223046,
	AcceptSpeech = 14419801,
	Desc = "来自平民家庭的王国基层士兵，为维持生计被迫参军。在战场上是不起眼的存在，不过为了迎接随时可能到来的“兵升变”，卫兵每次上场都会带齐主教、战车和骑士的头冠。毕竟，触底的一刻就是华丽逆转的开始。",
	RewardUnlock = 232228,
	ResultText = "黑卫兵解锁了",
	NumCap = 5,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG01",
	StartScene = "ARENA_StartScene",
	TeamCondition = {
		{
			Condition = "TeamCharacterIdOr",
			Value = 
			{
				223046,
			},
			Desc = "队伍中必须有白卫兵",
			Hint = "队伍中必须有白卫兵",
		},
	},
	Enemy = {
		{
			Value = 244223,
			Level = 35,
		},
	},
}
ChallengeConfig[ChallengeID.Id4199] =
{
	Id = 4199,
	Name = "挑战：雪之松",
	UnlockCostList = {
		{
			Value = 320103,
			Num = 1,
		},
	},
	Character = 223061,
	AcceptSpeech = 14419901,
	Desc = "听说冒险星本来没有白狼，只是野狼的毛被松芊芊薅光后，露出了雪白的身体，被人误以为是新品种……",
	RewardUnlock = 232229,
	ResultText = "雪之松解锁了",
	NumCap = 5,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG01",
	StartScene = "ARENA_StartScene",
	TeamCondition = {
		{
			Condition = "TeamCharacterIdOr",
			Value = 
			{
				223061,
			},
			Desc = "队伍中必须有松芊芊",
			Hint = "队伍中必须有松芊芊",
		},
	},
	Enemy = {
		{
			Value = 244224,
			Level = 35,
		},
	},
}
ChallengeConfig[ChallengeID.Id4200] =
{
	Id = 4200,
	Name = "挑战：小少爷",
	UnlockCostList = {
		{
			Value = 320103,
			Num = 1,
		},
	},
	Character = 223062,
	AcceptSpeech = 14420001,
	Desc = "吃完了眼睛上的咸鸭蛋，两颊的粉条，眉毛、下巴和头上的扇贝干，额上的两只蟹钳……休休终于露出了本来的面貌，哦哦哦，还要除掉头上的那根春笋和两边的棉花糖。嗯……或许还有身后伪装成尾巴的腊肠。。",
	RewardUnlock = 232230,
	ResultText = "小少爷解锁了",
	NumCap = 5,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG01",
	StartScene = "ARENA_StartScene",
	TeamCondition = {
		{
			Condition = "TeamCharacterIdOr",
			Value = 
			{
				223062,
			},
			Desc = "队伍中必须有休休",
			Hint = "队伍中必须有休休",
		},
	},
	Enemy = {
		{
			Value = 244225,
			Level = 35,
		},
	},
}
ChallengeConfig[ChallengeID.Id4201] =
{
	Id = 4201,
	Name = "挑战：帅小鸽",
	UnlockCostList = {
		{
			Value = 320103,
			Num = 1,
		},
	},
	Character = 223063,
	AcceptSpeech = 14420101,
	Desc = "在朋友的巧手下，阿宁厚厚的羽绒服被改成了时尚的外套、好看的针织帽、印有图案的短袖、宽松的运动裤，甚至还有帽子上的小饰品……",
	RewardUnlock = 232231,
	ResultText = "帅小鸽解锁了",
	NumCap = 5,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG01",
	StartScene = "ARENA_StartScene",
	TeamCondition = {
		{
			Condition = "TeamCharacterIdOr",
			Value = 
			{
				223063,
			},
			Desc = "队伍中必须有阿宁",
			Hint = "队伍中必须有阿宁",
		},
	},
	Enemy = {
		{
			Value = 244226,
			Level = 35,
		},
	},
}
ChallengeConfig[ChallengeID.Id4202] =
{
	Id = 4202,
	Name = "挑战：纯之恋",
	UnlockCostList = {
		{
			Value = 320103,
			Num = 1,
		},
	},
	Character = 223064,
	AcceptSpeech = 14420201,
	Desc = "这套衣服据说完全没有摩擦力，不仅可以将使用者360度无死角包裹，还可让任何滴在其上的液体都顺着衣服的曲线流到地面。",
	RewardUnlock = 232232,
	ResultText = "纯之恋解锁了",
	NumCap = 5,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG02",
	StartScene = "ARENA_StartScene",
	TeamCondition = {
		{
			Condition = "TeamCharacterIdOr",
			Value = 
			{
				223064,
			},
			Desc = "队伍中必须有倪不染",
			Hint = "队伍中必须有倪不染",
		},
	},
	Enemy = {
		{
			Value = 244227,
			Level = 35,
		},
	},
}
ChallengeConfig[ChallengeID.Id4203] =
{
	Id = 4203,
	Name = "挑战：昼与夜",
	UnlockCostList = {
		{
			Value = 320104,
			Num = 1,
		},
	},
	Character = 223065,
	AcceptSpeech = 14420301,
	Desc = "修身贴合的旗袍和国潮正装，对于穿着者的体型要求近乎苛刻，多一两肉都会变成紧身衣。",
	RewardUnlock = 232233,
	ResultText = "昼与夜解锁了",
	NumCap = 5,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG01",
	StartScene = "ARENA_StartScene",
	TeamCondition = {
		{
			Condition = "TeamCharacterIdOr",
			Value = 
			{
				223065,
			},
			Desc = "队伍中必须有小始小终",
			Hint = "队伍中必须有小始小终",
		},
	},
	Enemy = {
		{
			Value = 244228,
			Level = 50,
		},
	},
}
ChallengeConfig[ChallengeID.Id4204] =
{
	Id = 4204,
	Name = "挑战：空之鲤",
	UnlockCostList = {
		{
			Value = 320104,
			Num = 1,
		},
	},
	Character = 223066,
	AcceptSpeech = 14420401,
	Desc = "通过某种神秘配方调配鱼缸后，锦鲤鲤的外貌发生了巨变。只是那个秘方怎么看都更像食谱……",
	RewardUnlock = 232234,
	ResultText = "空之鲤解锁了",
	NumCap = 5,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG01",
	StartScene = "ARENA_StartScene",
	TeamCondition = {
		{
			Condition = "TeamCharacterIdOr",
			Value = 
			{
				223066,
			},
			Desc = "队伍中必须有锦鲤鲤",
			Hint = "队伍中必须有锦鲤鲤",
		},
	},
	Enemy = {
		{
			Value = 244229,
			Level = 50,
		},
	},
}
ChallengeConfig[ChallengeID.Id4205] =
{
	Id = 4205,
	Name = "挑战：夕大人",
	UnlockCostList = {
		{
			Value = 320105,
			Num = 1,
		},
	},
	Character = 223067,
	AcceptSpeech = 14420501,
	Desc = "在染缸里彻底浸泡过后，年大人果然发生了变化！他开始散发出一股酱瓜味……",
	RewardUnlock = 232235,
	ResultText = "夕大人解锁了",
	NumCap = 5,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG01",
	StartScene = "ARENA_StartScene",
	TeamCondition = {
		{
			Condition = "TeamCharacterIdOr",
			Value = 
			{
				223067,
			},
			Desc = "队伍中必须有年大人",
			Hint = "队伍中必须有年大人",
		},
	},
	Enemy = {
		{
			Value = 244230,
			Level = 75,
		},
	},
}
ChallengeConfig[ChallengeID.Id4206] =
{
	Id = 4206,
	Name = "挑战：除旧迎新",
	UnlockCostList = {
		{
			Value = 321052,
			Num = 5,
		},
	},
	Character = 220003,
	AcceptSpeech = 14420601,
	Desc = "会长大人为剑士定制的新年礼服，洋溢着满满的喜气，能够为来年带来好运。",
	RewardUnlock = 232236,
	ResultText = "除旧迎新解锁了",
	NumCap = 5,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG01",
	StartScene = "RPG_StartScene",
	TeamCondition = {
		{
			Condition = "TeamCharacterIdOr",
			Value = 
			{
				220003,
			},
			Desc = "队伍中必须有剑士",
			Hint = "队伍中必须有剑士",
		},
	},
	Enemy = {
		{
			Value = 244231,
			Level = 25,
		},
	},
}
ChallengeConfig[ChallengeID.Id4207] =
{
	Id = 4207,
	Name = "挑战：幻术师",
	UnlockCostList = {
		{
			Value = 320104,
			Num = 1,
		},
	},
	Character = 223007,
	AcceptSpeech = 14420701,
	Desc = "每10000个族人中只有一人能拥有的幻之魔力。解开封印后，术士的奇怪犄角将化为圣洁的独角，原本不愿与他亲近的人似乎都会不自觉地被他所吸引。",
	RewardUnlock = 232237,
	ResultText = "幻术师解锁了",
	NumCap = 5,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG01",
	StartScene = "RPG_StartScene",
	TeamCondition = {
		{
			Condition = "TeamCharacterIdOr",
			Value = 
			{
				223007,
			},
			Desc = "队伍中必须有术士",
			Hint = "队伍中必须有术士",
		},
	},
	Enemy = {
		{
			Value = 244232,
			Level = 50,
		},
	},
}
ChallengeConfig[ChallengeID.Id4208] =
{
	Id = 4208,
	Name = "挑战：狼先知",
	UnlockCostList = {
		{
			Value = 320105,
			Num = 1,
		},
	},
	Character = 223008,
	AcceptSpeech = 14420801,
	Desc = "换了伙伴的德鲁伊，很快和小狼也能够融洽地相处起来。原本打算偷偷溜走的小狼在吃了德鲁伊自制的饼干后，打算努力工作，永久性地顶替掉小熊。",
	RewardUnlock = 232238,
	ResultText = "狼先知解锁了",
	NumCap = 5,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG01",
	StartScene = "RPG_StartScene",
	TeamCondition = {
		{
			Condition = "TeamCharacterIdOr",
			Value = 
			{
				223008,
			},
			Desc = "队伍中必须有德鲁伊",
			Hint = "队伍中必须有德鲁伊",
		},
	},
	Enemy = {
		{
			Value = 244233,
			Level = 50,
		},
	},
}
ChallengeConfig[ChallengeID.Id4209] =
{
	Id = 4209,
	Name = "挑战：黑可可",
	UnlockCostList = {
		{
			Value = 320103,
			Num = 1,
		},
	},
	Character = 223081,
	AcceptSpeech = 14420901,
	Desc = "专门为人传情达意的美食星小红娘。据说由她转交到对方手中的信物，对方一定无法拒绝，告白成功率会提升350%。",
	RewardUnlock = 232239,
	ResultText = "黑可可解锁了",
	NumCap = 5,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG01",
	StartScene = "FAT_StartScene",
	TeamCondition = {
		{
			Condition = "TeamCharacterIdOr",
			Value = 
			{
				223081,
			},
			Desc = "队伍中必须有白可可",
			Hint = "队伍中必须有白可可",
		},
	},
	Enemy = {
		{
			Value = 244234,
			Level = 35,
		},
	},
}
ChallengeConfig[ChallengeID.Id4210] =
{
	Id = 4210,
	Name = "挑战：食人鱼",
	UnlockCostList = {
		{
			Value = 320103,
			Num = 1,
		},
	},
	Character = 223082,
	AcceptSpeech = 14421001,
	Desc = "虽然换装后能再次参加比赛，但这依然不能改变鱼罐头在智力问答赛中一轮游的窘境。\n“这位选手的表现让我想起了个人，你是不是有个失散多年的弟弟？”\n“没有！我答对了吗？可以晋级了吗？”\n“额……”",
	RewardUnlock = 232240,
	ResultText = "食人鱼解锁了",
	NumCap = 5,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG01",
	StartScene = "ARENA_StartScene",
	TeamCondition = {
		{
			Condition = "TeamCharacterIdOr",
			Value = 
			{
				223082,
			},
			Desc = "队伍中必须有鱼罐头",
			Hint = "队伍中必须有鱼罐头",
		},
	},
	Enemy = {
		{
			Value = 244235,
			Level = 35,
		},
	},
}
ChallengeConfig[ChallengeID.Id4211] =
{
	Id = 4211,
	Name = "挑战：泡椒子",
	UnlockCostList = {
		{
			Value = 320103,
			Num = 1,
		},
	},
	Character = 223101,
	AcceptSpeech = 14421101,
	Desc = "在辣椒界中，只有更辣，没有最辣。辣辣子参加了一年一度的比辣大赛，希望能打败上一届擂主。",
	RewardUnlock = 232241,
	ResultText = "泡椒子解锁了",
	NumCap = 5,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG01",
	StartScene = "FAT_StartScene",
	TeamCondition = {
		{
			Condition = "TeamCharacterIdOr",
			Value = 
			{
				223101,
			},
			Desc = "队伍中必须有辣辣子",
			Hint = "队伍中必须有辣辣子",
		},
	},
	Enemy = {
		{
			Value = 244236,
			Level = 35,
		},
	},
}
ChallengeConfig[ChallengeID.Id4212] =
{
	Id = 4212,
	Name = "挑战：抹茶泡面",
	UnlockCostList = {
		{
			Value = 320103,
			Num = 1,
		},
	},
	Character = 223102,
	AcceptSpeech = 14421201,
	Desc = "作为养生大师的板蓝根泡面，会定期开发更营养的泡面，但似乎并不容易被他人接受。",
	RewardUnlock = 232242,
	ResultText = "抹茶泡面解锁了",
	NumCap = 5,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG01",
	StartScene = "FAT_StartScene",
	TeamCondition = {
		{
			Condition = "TeamCharacterIdOr",
			Value = 
			{
				223102,
			},
			Desc = "队伍中必须有板蓝根泡面",
			Hint = "队伍中必须有板蓝根泡面",
		},
	},
	Enemy = {
		{
			Value = 244237,
			Level = 35,
		},
	},
}
ChallengeConfig[ChallengeID.Id4213] =
{
	Id = 4213,
	Name = "挑战：目光披萨",
	UnlockCostList = {
		{
			Value = 320103,
			Num = 1,
		},
	},
	Character = 223103,
	AcceptSpeech = 14421301,
	Desc = "因为只有高度近视的客人才会来买皮蛋披萨，考虑到受众群体，想推出一些能够对他们身体有好处的披萨，并为此专门询问了养生大师。",
	RewardUnlock = 232243,
	ResultText = "目光披萨解锁了",
	NumCap = 5,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG01",
	StartScene = "FAT_StartScene",
	TeamCondition = {
		{
			Condition = "TeamCharacterIdOr",
			Value = 
			{
				223103,
			},
			Desc = "队伍中必须有皮蛋披萨",
			Hint = "队伍中必须有皮蛋披萨",
		},
	},
	Enemy = {
		{
			Value = 244238,
			Level = 35,
		},
	},
}
ChallengeConfig[ChallengeID.Id4214] =
{
	Id = 4214,
	Name = "挑战：鲱鱼汉堡",
	UnlockCostList = {
		{
			Value = 320104,
			Num = 1,
		},
	},
	Character = 223104,
	AcceptSpeech = 14421401,
	Desc = "为了让更多人能接收鲱鱼料理，他也准备了一些其他食材进行辅助。没想到却被一些喜欢占小便宜的人钻了空子……",
	RewardUnlock = 232244,
	ResultText = "鲱鱼汉堡解锁了",
	NumCap = 5,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG01",
	StartScene = "FAT_StartScene",
	TeamCondition = {
		{
			Condition = "TeamCharacterIdOr",
			Value = 
			{
				223104,
			},
			Desc = "队伍中必须有鲱鱼饭团",
			Hint = "队伍中必须有鲱鱼饭团",
		},
	},
	Enemy = {
		{
			Value = 244239,
			Level = 50,
		},
	},
}
ChallengeConfig[ChallengeID.Id4215] =
{
	Id = 4215,
	Name = "挑战：基维企克",
	UnlockCostList = {
		{
			Value = 320104,
			Num = 1,
		},
	},
	Character = 223105,
	AcceptSpeech = 14421501,
	Desc = "由于海燕个头太小，每次只吃内脏的话非常浪费。于是，基维把眼光转向了其他食材。",
	RewardUnlock = 232245,
	ResultText = "基维企克解锁了",
	NumCap = 5,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG01",
	StartScene = "FAT_StartScene",
	TeamCondition = {
		{
			Condition = "TeamCharacterIdOr",
			Value = 
			{
				223105,
			},
			Desc = "队伍中必须有基维燕克",
			Hint = "队伍中必须有基维燕克",
		},
	},
	Enemy = {
		{
			Value = 244240,
			Level = 50,
		},
	},
}
ChallengeConfig[ChallengeID.Id4216] =
{
	Id = 4216,
	Name = "挑战：吱吱包",
	UnlockCostList = {
		{
			Value = 320104,
			Num = 1,
		},
	},
	Character = 223106,
	AcceptSpeech = 14421601,
	Desc = "听说菠萝包很受欢迎，为了扩宽自己的销量，猪猪包有了新的想法……",
	RewardUnlock = 232246,
	ResultText = "吱吱包解锁了",
	NumCap = 5,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG01",
	StartScene = "FAT_StartScene",
	TeamCondition = {
		{
			Condition = "TeamCharacterIdOr",
			Value = 
			{
				223106,
			},
			Desc = "队伍中必须有猪猪包",
			Hint = "队伍中必须有猪猪包",
		},
	},
	Enemy = {
		{
			Value = 244241,
			Level = 50,
		},
	},
}
ChallengeConfig[ChallengeID.Id4217] =
{
	Id = 4217,
	Name = "挑战：金渐层",
	UnlockCostList = {
		{
			Value = 320105,
			Num = 1,
		},
	},
	Character = 223107,
	AcceptSpeech = 14421701,
	Desc = "听说用金渐层猫猫的粑粑制作出的咖啡非常美味，史卡想引诱金渐层品种的猫猫，可无论怎么做，都看不到猫猫的身影……",
	RewardUnlock = 232247,
	ResultText = "金渐层解锁了",
	NumCap = 5,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG01",
	StartScene = "FAT_StartScene",
	TeamCondition = {
		{
			Condition = "TeamCharacterIdOr",
			Value = 
			{
				223107,
			},
			Desc = "队伍中必须有史卡",
			Hint = "队伍中必须有史卡",
		},
	},
	Enemy = {
		{
			Value = 244242,
			Level = 75,
		},
	},
}
ChallengeConfig[ChallengeID.Id4218] =
{
	Id = 4218,
	Name = "挑战：白葡萄酿",
	UnlockCostList = {
		{
			Value = 320105,
			Num = 1,
		},
	},
	Character = 223108,
	AcceptSpeech = 14421801,
	Desc = "拜兰帝以酿造出100度的酒为目标，不断发起挑战，而检验挑战是否成功是由三位评委说了算。",
	RewardUnlock = 232248,
	ResultText = "白葡萄酿解锁了",
	NumCap = 5,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG01",
	StartScene = "FAT_StartScene",
	TeamCondition = {
		{
			Condition = "TeamCharacterIdOr",
			Value = 
			{
				223108,
			},
			Desc = "队伍中必须有拜兰帝",
			Hint = "队伍中必须有拜兰帝",
		},
	},
	Enemy = {
		{
			Value = 244243,
			Level = 75,
		},
	},
}
ChallengeConfig[ChallengeID.Id4219] =
{
	Id = 4219,
	Name = "挑战：巨星清音",
	UnlockCostList = {
		{
			Value = 320105,
			Num = 1,
		},
	},
	Character = 220431,
	AcceptSpeech = 14421901,
	Desc = "人鱼清音获得了魔力，可以发出蛊惑人心的魔音，还有一把吸力极强的三叉戟，然而在海底，却吸来了许多铁皮垃圾。",
	RewardUnlock = 232249,
	ResultText = "巨星清音解锁了",
	NumCap = 5,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG01",
	StartScene = "SEA_StartScene",
	TeamCondition = {
		{
			Condition = "TeamCharacterIdOr",
			Value = 
			{
				220431,
			},
			Desc = "队伍中必须有人鱼清音",
			Hint = "队伍中必须有人鱼清音",
		},
	},
	Enemy = {
		{
			Value = 244244,
			Level = 75,
		},
	},
}
ChallengeConfig[ChallengeID.Id4220] =
{
	Id = 4220,
	Name = "挑战：你快扫鸭",
	UnlockCostList = {
		{
			Value = 320103,
			Num = 1,
		},
	},
	Character = 223121,
	AcceptSpeech = 14422001,
	Desc = "因为掌握先进科技，并将其运用进打扫工作后，工作效率明显提升，终于顺利升职，但也因为这样，常常被老板认为在摸鱼。",
	RewardUnlock = 232250,
	ResultText = "你快扫鸭解锁了",
	NumCap = 5,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG01",
	StartScene = "ARENA_StartScene",
	TeamCondition = {
		{
			Condition = "TeamCharacterIdOr",
			Value = 
			{
				223121,
			},
			Desc = "队伍中必须有扫地鸡",
			Hint = "队伍中必须有扫地鸡",
		},
	},
	Enemy = {
		{
			Value = 244245,
			Level = 35,
		},
	},
}
ChallengeConfig[ChallengeID.Id4221] =
{
	Id = 4221,
	Name = "挑战：红玫瑰",
	UnlockCostList = {
		{
			Value = 320103,
			Num = 1,
		},
	},
	Character = 223122,
	AcceptSpeech = 14422101,
	Desc = "美丽的红色玫瑰，用鲜血和树精交换，才变成了现在的模样，据说背负着某种诅咒。",
	RewardUnlock = 232251,
	ResultText = "红玫瑰解锁了",
	NumCap = 5,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG03",
	StartScene = "ARENA_StartScene",
	TeamCondition = {
		{
			Condition = "TeamCharacterIdOr",
			Value = 
			{
				223122,
			},
			Desc = "队伍中必须有白蔷薇",
			Hint = "队伍中必须有白蔷薇",
		},
	},
	Enemy = {
		{
			Value = 244246,
			Level = 35,
		},
	},
}
ChallengeConfig[ChallengeID.Id4222] =
{
	Id = 4222,
	Name = "挑战：小狼帽",
	UnlockCostList = {
		{
			Value = 320104,
			Num = 1,
		},
	},
	Character = 223123,
	AcceptSpeech = 14422201,
	Desc = "原来，小红帽的真实身份，是森林里的猎狼者。她以猎杀形单影只的狼为乐趣，出手干脆利落，不留下任何蛛丝马迹。",
	RewardUnlock = 232252,
	ResultText = "小狼帽解锁了",
	NumCap = 5,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG01",
	StartScene = "ARENA_StartScene",
	TeamCondition = {
		{
			Condition = "TeamCharacterIdOr",
			Value = 
			{
				223123,
			},
			Desc = "队伍中必须有小红帽",
			Hint = "队伍中必须有小红帽",
		},
	},
	Enemy = {
		{
			Value = 244247,
			Level = 50,
		},
	},
}
ChallengeConfig[ChallengeID.Id4223] =
{
	Id = 4223,
	Name = "挑战：羽化灵均",
	UnlockCostList = {
		{
			Value = 320105,
			Num = 1,
		},
	},
	Character = 223124,
	AcceptSpeech = 14422301,
	Desc = "自从羽化登仙，灵均就坐上了机械白鹤，因此遨游宇宙的速度大大提高，去的地方也更远了，据说一天之内就可以走遍5个星球。",
	RewardUnlock = 232253,
	ResultText = "羽化灵均解锁了",
	NumCap = 5,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG01",
	StartScene = "ARENA_StartScene",
	TeamCondition = {
		{
			Condition = "TeamCharacterIdOr",
			Value = 
			{
				223124,
			},
			Desc = "队伍中必须有灵均",
			Hint = "队伍中必须有灵均",
		},
	},
	Enemy = {
		{
			Value = 244248,
			Level = 75,
		},
	},
}
ChallengeConfig[ChallengeID.Id4224] =
{
	Id = 4224,
	Name = "挑战：魔王号车头",
	UnlockCostList = {
		{
			Value = 320104,
			Num = 1,
		},
	},
	Character = 223125,
	AcceptSpeech = 14422401,
	Desc = "魔王集团交通部头号领军人物，也是魔王列车号车头。保持着朝九晚五，一周五天的良好工作节奏，是魔王集团中坚决拒绝加班的人。",
	RewardUnlock = 232254,
	ResultText = "魔王号车头解锁了",
	NumCap = 5,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG01",
	StartScene = "ARENA_StartScene",
	TeamCondition = {
		{
			Condition = "TeamCharacterIdOr",
			Value = 
			{
				223125,
			},
			Desc = "队伍中必须有龙头老大",
			Hint = "队伍中必须有龙头老大",
		},
	},
	Enemy = {
		{
			Value = 244249,
			Level = 50,
		},
	},
}
ChallengeConfig[ChallengeID.Id4225] =
{
	Id = 4225,
	Name = "挑战：列车长",
	UnlockCostList = {
		{
			Value = 320104,
			Num = 1,
		},
	},
	Character = 223126,
	AcceptSpeech = 14422501,
	Desc = "魔王列车号售票员，是列车上的老好人，和每位同事和乘客都有良好的关系，当然，因为面试时候的不愉快，至今没有和小队长讲过话。",
	RewardUnlock = 232255,
	ResultText = "列车长解锁了",
	NumCap = 5,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG01",
	StartScene = "ARENA_StartScene",
	TeamCondition = {
		{
			Condition = "TeamCharacterIdOr",
			Value = 
			{
				223126,
			},
			Desc = "队伍中必须有抬鼓达人",
			Hint = "队伍中必须有抬鼓达人",
		},
	},
	Enemy = {
		{
			Value = 244250,
			Level = 50,
		},
	},
}
ChallengeConfig[ChallengeID.Id4226] =
{
	Id = 4226,
	Name = "挑战：车厢一号",
	UnlockCostList = {
		{
			Value = 320103,
			Num = 1,
		},
	},
	Character = 223127,
	AcceptSpeech = 14422601,
	Desc = "魔王列车号一号车厢，实现了列车自动化行进后，再也不需要在自己的脑中进行运算了。",
	RewardUnlock = 232256,
	ResultText = "车厢一号解锁了",
	NumCap = 5,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG01",
	StartScene = "ARENA_StartScene",
	TeamCondition = {
		{
			Condition = "TeamCharacterIdOr",
			Value = 
			{
				223127,
			},
			Desc = "队伍中必须有桨手一号",
			Hint = "队伍中必须有桨手一号",
		},
	},
	Enemy = {
		{
			Value = 244251,
			Level = 35,
		},
	},
}
ChallengeConfig[ChallengeID.Id4227] =
{
	Id = 4227,
	Name = "挑战：车厢二号",
	UnlockCostList = {
		{
			Value = 320103,
			Num = 1,
		},
	},
	Character = 223128,
	AcceptSpeech = 14422701,
	Desc = "魔王列车号二号车厢，时常出现动力不足，无法前进的情况，全靠一号车厢带动，否则就要被扔进回收站了。",
	RewardUnlock = 232257,
	ResultText = "车厢二号解锁了",
	NumCap = 5,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG01",
	StartScene = "ARENA_StartScene",
	TeamCondition = {
		{
			Condition = "TeamCharacterIdOr",
			Value = 
			{
				223128,
			},
			Desc = "队伍中必须有桨手二号",
			Hint = "队伍中必须有桨手二号",
		},
	},
	Enemy = {
		{
			Value = 244252,
			Level = 35,
		},
	},
}
ChallengeConfig[ChallengeID.Id4228] =
{
	Id = 4228,
	Name = "挑战：魔王号车尾",
	UnlockCostList = {
		{
			Value = 320103,
			Num = 1,
		},
	},
	Character = 223129,
	AcceptSpeech = 14422801,
	Desc = "魔王集团交通部车尾，面试时期，凭借与吊车尾的缘分，才战胜了许多竞争对手，成为获得了这份工作。",
	RewardUnlock = 232258,
	ResultText = "魔王号车尾解锁了",
	NumCap = 5,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG01",
	StartScene = "ARENA_StartScene",
	TeamCondition = {
		{
			Condition = "TeamCharacterIdOr",
			Value = 
			{
				223129,
			},
			Desc = "队伍中必须有龙尾小弟",
			Hint = "队伍中必须有龙尾小弟",
		},
	},
	Enemy = {
		{
			Value = 244253,
			Level = 35,
		},
	},
}
ChallengeConfig[ChallengeID.Id4229] =
{
	Id = 4229,
	Name = "挑战：泳装呜呜",
	UnlockCostList = {
		{
			Value = 320106,
			Num = 1,
		},
	},
	Character = 220001,
	AcceptSpeech = 14422901,
	Desc = "呜呜的夏日泳装。打败史莱姆大王后，呜呜终于上了小鸭子泳圈，只要有小溪，就可以来一场刺激的漂流游戏。",
	RewardUnlock = 232259,
	ResultText = "泳装呜呜解锁了",
	NumCap = 5,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG01",
	StartScene = "ARENA_StartScene",
	TeamCondition = {
		{
			Condition = "TeamCharacterIdOr",
			Value = 
			{
				220001,
				220002,
			},
			Desc = "队伍中必须有呜呜或漆漆",
			Hint = "队伍中必须有呜呜或漆漆",
		},
	},
	Enemy = {
		{
			Value = 244254,
			Level = 35,
		},
	},
}
ChallengeConfig[ChallengeID.Id4230] =
{
	Id = 4230,
	Name = "挑战：泳装漆漆",
	UnlockCostList = {
		{
			Value = 320107,
			Num = 1,
		},
	},
	Character = 220002,
	AcceptSpeech = 14423001,
	Desc = "漆漆的夏日泳装。下水玩耍的漆漆，立马就钻进了羊驼救生圈中，当事喵表示，浮在河流上真的太好玩啦。",
	RewardUnlock = 232260,
	ResultText = "泳装漆漆解锁了",
	NumCap = 5,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG01",
	StartScene = "ARENA_StartScene",
	TeamCondition = {
		{
			Condition = "TeamCharacterIdOr",
			Value = 
			{
				220001,
				220002,
			},
			Desc = "队伍中必须有呜呜或漆漆",
			Hint = "队伍中必须有呜呜或漆漆",
		},
	},
	Enemy = {
		{
			Value = 244255,
			Level = 35,
		},
	},
}
ChallengeConfig[ChallengeID.Id4231] =
{
	Id = 4231,
	Name = "挑战：华服牵牛",
	UnlockCostList = {
		{
			Value = 320103,
			Num = 1,
		},
	},
	Character = 223130,
	AcceptSpeech = 14423101,
	Desc = "牵牛最终选择了红色的外套，经过一番精心打扮，自信心大大提高。如果告白成功，一定要邀请她跳一支舞——他这样想到。",
	RewardUnlock = 232261,
	ResultText = "华服牵牛解锁了",
	NumCap = 5,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG01",
	StartScene = "ARENA_StartScene",
	TeamCondition = {
		{
			Condition = "TeamCharacterIdOr",
			Value = 
			{
				223130,
			},
			Desc = "队伍中必须有牵牛",
			Hint = "队伍中必须有牵牛",
		},
	},
	Enemy = {
		{
			Value = 244256,
			Level = 35,
		},
	},
}
ChallengeConfig[ChallengeID.Id4232] =
{
	Id = 4232,
	Name = "挑战：星月一心",
	UnlockCostList = {
		{
			Value = 320104,
			Num = 1,
		},
	},
	Character = 223131,
	AcceptSpeech = 14423201,
	Desc = "打败竞争对手后，一心如愿以偿，获得了红裙，裙摆上的星空刺绣和金色装饰让她心旷神怡。",
	RewardUnlock = 232262,
	ResultText = "星月一心解锁了",
	NumCap = 5,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG01",
	StartScene = "ARENA_StartScene",
	TeamCondition = {
		{
			Condition = "TeamCharacterIdOr",
			Value = 
			{
				223131,
			},
			Desc = "队伍中必须有一心",
			Hint = "队伍中必须有一心",
		},
	},
	Enemy = {
		{
			Value = 244257,
			Level = 35,
		},
	},
}
ChallengeConfig[ChallengeID.Id4233] =
{
	Id = 4233,
	Name = "挑战：林间二橘",
	UnlockCostList = {
		{
			Value = 320104,
			Num = 1,
		},
	},
	Character = 223132,
	AcceptSpeech = 14423301,
	Desc = "经过内心的暴走和纠结，二橘最终选择了这条裙子，翠绿如森林，橙红似夕阳，两种颜色交相辉映，让整件衣裳闪闪发光。",
	RewardUnlock = 232263,
	ResultText = "林间二橘解锁了",
	NumCap = 5,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG01",
	StartScene = "ARENA_StartScene",
	TeamCondition = {
		{
			Condition = "TeamCharacterIdOr",
			Value = 
			{
				223132,
			},
			Desc = "队伍中必须有二橘",
			Hint = "队伍中必须有二橘",
		},
	},
	Enemy = {
		{
			Value = 244258,
			Level = 35,
		},
	},
}
ChallengeConfig[ChallengeID.Id4234] =
{
	Id = 4234,
	Name = "挑战：猫猫三花",
	UnlockCostList = {
		{
			Value = 320104,
			Num = 1,
		},
	},
	Character = 223133,
	AcceptSpeech = 14423401,
	Desc = "最后，三花还是选择了由很多簪子组成的头饰，拿下簪子对着猫咪晃一晃，猫猫们就会立刻扑过来，亲测有效，爱撸猫人士必备！",
	RewardUnlock = 232264,
	ResultText = "猫猫三花解锁了",
	NumCap = 5,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG01",
	StartScene = "ARENA_StartScene",
	TeamCondition = {
		{
			Condition = "TeamCharacterIdOr",
			Value = 
			{
				223133,
			},
			Desc = "队伍中必须有三花",
			Hint = "队伍中必须有三花",
		},
	},
	Enemy = {
		{
			Value = 244259,
			Level = 35,
		},
	},
}
ChallengeConfig[ChallengeID.Id4235] =
{
	Id = 4235,
	Name = "挑战：夜樱四荔",
	UnlockCostList = {
		{
			Value = 320104,
			Num = 1,
		},
	},
	Character = 223134,
	AcceptSpeech = 14423501,
	Desc = "四荔直接穿着新衣离开了服装店，因为有巨大的下摆和层层叠叠的装饰，藏匿整蛊工具似乎变得更容易了。",
	RewardUnlock = 232265,
	ResultText = "夜樱四荔解锁了",
	NumCap = 5,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG01",
	StartScene = "ARENA_StartScene",
	TeamCondition = {
		{
			Condition = "TeamCharacterIdOr",
			Value = 
			{
				223134,
			},
			Desc = "队伍中必须有四荔",
			Hint = "队伍中必须有四荔",
		},
	},
	Enemy = {
		{
			Value = 244260,
			Level = 35,
		},
	},
}
ChallengeConfig[ChallengeID.Id4236] =
{
	Id = 4236,
	Name = "挑战：青瓷五行",
	UnlockCostList = {
		{
			Value = 320103,
			Num = 1,
		},
	},
	Character = 223135,
	AcceptSpeech = 14423601,
	Desc = "抓出凶手的五行，此刻斗志昂扬：“作为追逐犯人的侦探，还是穿得简单一点吧。”于是她选择了一条典雅的青色窄裙。",
	RewardUnlock = 232266,
	ResultText = "青瓷五行解锁了",
	NumCap = 5,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG01",
	StartScene = "ARENA_StartScene",
	TeamCondition = {
		{
			Condition = "TeamCharacterIdOr",
			Value = 
			{
				223135,
			},
			Desc = "队伍中必须有五行",
			Hint = "队伍中必须有五行",
		},
	},
	Enemy = {
		{
			Value = 244261,
			Level = 35,
		},
	},
}
ChallengeConfig[ChallengeID.Id4237] =
{
	Id = 4237,
	Name = "挑战：白兔六瑶",
	UnlockCostList = {
		{
			Value = 320103,
			Num = 1,
		},
	},
	Character = 223136,
	AcceptSpeech = 14423701,
	Desc = "成功换好衣裳，六瑶从试衣间里走出来。看着镜中的自己，她终于露出了开心的微笑。",
	RewardUnlock = 232267,
	ResultText = "白兔六瑶解锁了",
	NumCap = 5,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG01",
	StartScene = "ARENA_StartScene",
	TeamCondition = {
		{
			Condition = "TeamCharacterIdOr",
			Value = 
			{
				223136,
			},
			Desc = "队伍中必须有六瑶",
			Hint = "队伍中必须有六瑶",
		},
	},
	Enemy = {
		{
			Value = 244262,
			Level = 35,
		},
	},
}
ChallengeConfig[ChallengeID.Id4238] =
{
	Id = 4238,
	Name = "挑战：樱花七织",
	UnlockCostList = {
		{
			Value = 320103,
			Num = 1,
		},
	},
	Character = 223137,
	AcceptSpeech = 14423801,
	Desc = "穿上裙子，七织心满意足地离开了服装店，没走几步，店里的员工小哥就忙不迭地向她跑来道歉，还邀请她与自己庙会同游。那么，要不要答应他呢？",
	RewardUnlock = 232268,
	ResultText = "樱花七织解锁了",
	NumCap = 5,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG01",
	StartScene = "ARENA_StartScene",
	TeamCondition = {
		{
			Condition = "TeamCharacterIdOr",
			Value = 
			{
				223137,
			},
			Desc = "队伍中必须有七织",
			Hint = "队伍中必须有七织",
		},
	},
	Enemy = {
		{
			Value = 244263,
			Level = 35,
		},
	},
}
ChallengeConfig[ChallengeID.Id4239] =
{
	Id = 4239,
	Name = "挑战：姻缘神",
	UnlockCostList = {
		{
			Value = 320105,
			Num = 1,
		},
	},
	Character = 223138,
	AcceptSpeech = 14423901,
	CompleteSpeech = 14423951,
	Desc = "在被婚介所辞退，流亡街流浪的岁月中，月佬渐渐发现，所谓有情，其实是人与人之间的因缘羁绊，并非完全由自己缠绕的红线所决定。念之于此，他决定重返婚介所，让自己的老板，放下操纵人间姻缘的权利，让他们自己决定今后的感情与命运。",
	RewardUnlock = 232269,
	ResultText = "姻缘神解锁了",
	NumCap = 5,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG01",
	StartScene = "ARENA_StartScene",
	TeamCondition = {
		{
			Condition = "TeamCharacterIdOr",
			Value = 
			{
				223138,
			},
			Desc = "队伍中必须有月佬",
			Hint = "队伍中必须有月佬",
		},
	},
	Enemy = {
		{
			Value = 244264,
			Level = 75,
		},
	},
}
ChallengeConfig[ChallengeID.Id4240] =
{
	Id = 4240,
	Name = "挑战：部落公主",
	UnlockCostList = {
		{
			Value = 320151,
			Num = 8,
		},
	},
	Character = 221007,
	AcceptSpeech = 14424001,
	Desc = "威逼利诱下，酋长妹妹终于同意留在不夜城。她一边看着前来抽卡的冒险家们，一边暗自盘算着：\n哥哥走了，应该让谁来接替我呢？",
	RewardUnlock = 232310,
	ResultText = "部落公主解锁了",
	NumCap = 5,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG01",
	StartScene = "ARENA_StartScene",
	TeamCondition = {
		{
			Condition = "TeamCharacterIdOr",
			Value = 
			{
				221007,
			},
			Desc = "队伍中必须有酋长妹妹",
			Hint = "队伍中必须有酋长妹妹",
		},
	},
	Enemy = {
		{
			Value = 244265,
			Level = 50,
		},
		{
			Value = 244266,
			Level = 50,
		},
		{
			Value = 244267,
			Level = 50,
		},
	},
}
ChallengeConfig[ChallengeID.Id4241] =
{
	Id = 4241,
	Name = "挑战：超音速圆圆",
	UnlockCostList = {
		{
			Value = 320103,
			Num = 1,
		},
	},
	Character = 223139,
	AcceptSpeech = 14424101,
	Desc = "拿到轮滑的圆圆，在公路上自由快速前进，送信的速度更快了，客户好评率提高至99.99%。并且，她还为自己留出了更多周游宇宙的时间。",
	RewardUnlock = 232311,
	ResultText = "超音速圆圆解锁了",
	NumCap = 5,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG01",
	StartScene = "ARENA_StartScene",
	TeamCondition = {
		{
			Condition = "TeamCharacterIdOr",
			Value = 
			{
				223139,
			},
			Desc = "队伍中必须有团圆圆",
			Hint = "队伍中必须有团圆圆",
		},
	},
	Enemy = {
		{
			Value = 244268,
			Level = 35,
		},
	},
}
ChallengeConfig[ChallengeID.Id4242] =
{
	Id = 4242,
	Name = "挑战：万圣之夜",
	UnlockCostList = {
		{
			Value = 320104,
			Num = 1,
		},
	},
	Character = 223140,
	AcceptSpeech = 14424201,
	Desc = "迪斯科野狼拒绝了小红帽的试探，让她把银耳环放至原位。\n她在怀疑我的身份吗？迪斯科野狼不禁这样想。但今晚是美好的万圣夜，四处弥漫着喧闹和快乐的空气，试探与诡计不该出现在这里。于是他收敛了严肃的面孔，换上万圣套装，问道：\n“你看，我穿这身好看吗？”",
	RewardUnlock = 232312,
	ResultText = "万圣之夜解锁了",
	NumCap = 5,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG01",
	StartScene = "ARENA_StartScene",
	TeamCondition = {
		{
			Condition = "TeamCharacterIdOr",
			Value = 
			{
				223140,
			},
			Desc = "队伍中必须有迪斯科野狼",
			Hint = "队伍中必须有迪斯科野狼",
		},
	},
	Enemy = {
		{
			Value = 244269,
			Level = 50,
		},
	},
}
ChallengeConfig[ChallengeID.Id4243] =
{
	Id = 4243,
	Name = "挑战：林间雪鸢",
	UnlockCostList = {
		{
			Value = 320105,
			Num = 1,
		},
	},
	Character = 223141,
	AcceptSpeech = 14424301,
	Desc = "取下面具，雪神露出她原本的面容。只要这里没有人来，她就可以活成最真实的模样，无忧无虑地在山林间舞蹈。此刻的她，仿佛一只无所顾忌的自由鸟。",
	RewardUnlock = 232315,
	ResultText = "林间雪鸢解锁了",
	NumCap = 5,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG01",
	StartScene = "ARENA_StartScene",
	TeamCondition = {
		{
			Condition = "TeamCharacterIdOr",
			Value = 
			{
				223141,
			},
			Desc = "队伍中必须有雪神",
			Hint = "队伍中必须有雪神",
		},
	},
	Enemy = {
		{
			Value = 244270,
			Level = 75,
		},
	},
}
ChallengeConfig[ChallengeID.Id4244] =
{
	Id = 4244,
	Name = "挑战：温泉女郎",
	UnlockCostList = {
		{
			Value = 320105,
			Num = 1,
		},
	},
	Character = 223142,
	AcceptSpeech = 14424401,
	Desc = "今天的一切都已尘埃落定，猫眼厨娘脱下工作服，换上自己的泳衣，跳入温泉，开始享受这段美好的夜晚时光。",
	RewardUnlock = 232316,
	ResultText = "温泉女郎解锁了",
	NumCap = 5,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG01",
	StartScene = "ARENA_StartScene",
	TeamCondition = {
		{
			Condition = "TeamCharacterIdOr",
			Value = 
			{
				223142,
			},
			Desc = "队伍中必须有猫眼厨娘",
			Hint = "队伍中必须有猫眼厨娘",
		},
	},
	Enemy = {
		{
			Value = 244271,
			Level = 75,
		},
	},
}
ChallengeConfig[ChallengeID.Id4245] =
{
	Id = 4245,
	Name = "挑战：如坠冰窟",
	UnlockCostList = {
		{
			Value = 320104,
			Num = 1,
		},
	},
	Character = 223143,
	AcceptSpeech = 14424501,
	Desc = "被冻成人形冰冰杆的温泉鉴赏家伫立在别墅门口，成为了一道靓丽的风景线。如果一切能重来，他一定会在离开前，对别墅的打扫阿姨说一句：“别、关、门。”",
	RewardUnlock = 232317,
	ResultText = "如坠冰窟解锁了",
	NumCap = 5,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG01",
	StartScene = "ARENA_StartScene",
	TeamCondition = {
		{
			Condition = "TeamCharacterIdOr",
			Value = 
			{
				223143,
			},
			Desc = "队伍中必须有温泉鉴赏家",
			Hint = "队伍中必须有温泉鉴赏家",
		},
	},
	Enemy = {
		{
			Value = 244272,
			Level = 50,
		},
	},
}
ChallengeConfig[ChallengeID.Id4246] =
{
	Id = 4246,
	Name = "挑战：雪地马拉松",
	UnlockCostList = {
		{
			Value = 320104,
			Num = 1,
		},
	},
	Character = 223144,
	AcceptSpeech = 14424601,
	Desc = "为了进行雪地马拉松，健身教练准备了一身完整的装备，气势汹汹地出发了。但是粗心的他，竟然忘记了给宝贝儿子穿上裤子。",
	RewardUnlock = 232318,
	ResultText = "雪地马拉松解锁了",
	NumCap = 5,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG01",
	StartScene = "ARENA_StartScene",
	TeamCondition = {
		{
			Condition = "TeamCharacterIdOr",
			Value = 
			{
				223144,
			},
			Desc = "队伍中必须有健身教练",
			Hint = "队伍中必须有健身教练",
		},
	},
	Enemy = {
		{
			Value = 244273,
			Level = 50,
		},
	},
}
ChallengeConfig[ChallengeID.Id4247] =
{
	Id = 4247,
	Name = "挑战：熊熊燃烧",
	UnlockCostList = {
		{
			Value = 320104,
			Num = 1,
		},
	},
	Character = 223145,
	AcceptSpeech = 14424701,
	Desc = "断耳熊穿上这件名为“熊熊燃烧”的裙子，果然气色好了许多。虽然不知道，她能不能忘记过去伤心的往事，但至少现在的日子是幸福的。对她来说，这就足够了。",
	RewardUnlock = 232319,
	ResultText = "熊熊燃烧解锁了",
	NumCap = 5,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG01",
	StartScene = "ARENA_StartScene",
	TeamCondition = {
		{
			Condition = "TeamCharacterIdOr",
			Value = 
			{
				223145,
			},
			Desc = "队伍中必须有断耳熊",
			Hint = "队伍中必须有断耳熊",
		},
	},
	Enemy = {
		{
			Value = 244274,
			Level = 50,
		},
	},
}
ChallengeConfig[ChallengeID.Id4248] =
{
	Id = 4248,
	Name = "挑战：水中健将",
	UnlockCostList = {
		{
			Value = 320104,
			Num = 1,
		},
	},
	Character = 223146,
	AcceptSpeech = 14424801,
	Desc = "克服心理障碍，成功下水的雪中猎人终于体会到温泉的美妙。他闭上眼睛，在温暖的池中漂浮。然而，由于这里“禁止宠物进入”，他的狗狗只能套着游泳圈，假装在水里玩过了。",
	RewardUnlock = 232320,
	ResultText = "水中健将解锁了",
	NumCap = 5,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG01",
	StartScene = "ARENA_StartScene",
	TeamCondition = {
		{
			Condition = "TeamCharacterIdOr",
			Value = 
			{
				223146,
			},
			Desc = "队伍中必须有雪中猎人",
			Hint = "队伍中必须有雪中猎人",
		},
	},
	Enemy = {
		{
			Value = 244275,
			Level = 50,
		},
	},
}
ChallengeConfig[ChallengeID.Id4249] =
{
	Id = 4249,
	Name = "挑战：雪中女主角",
	UnlockCostList = {
		{
			Value = 320104,
			Num = 1,
		},
	},
	Character = 223147,
	AcceptSpeech = 14424901,
	Desc = "编剧妹子走在路上，灵感如温泉一样喷涌。此刻的她不是她自己，仿佛化身为故事里的女主角，体验着笔下之人的喜怒哀乐。",
	RewardUnlock = 232321,
	ResultText = "雪中女主角解锁了",
	NumCap = 5,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG01",
	StartScene = "ARENA_StartScene",
	TeamCondition = {
		{
			Condition = "TeamCharacterIdOr",
			Value = 
			{
				223147,
			},
			Desc = "队伍中必须有编剧妹子",
			Hint = "队伍中必须有编剧妹子",
		},
	},
	Enemy = {
		{
			Value = 244276,
			Level = 50,
		},
	},
}
ChallengeConfig[ChallengeID.Id4250] =
{
	Id = 4250,
	Name = "挑战：暴走雪人",
	UnlockCostList = {
		{
			Value = 320104,
			Num = 1,
		},
	},
	Character = 223148,
	AcceptSpeech = 14425001,
	Desc = "被惹怒的雪人展示出了自己狂野和暴怒的一面，全身散发出危险的气息。对于这时候的他，是应该温柔地安抚，还是以暴制暴地对待呢？",
	RewardUnlock = 232322,
	ResultText = "暴走雪人解锁了",
	NumCap = 5,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG04",
	StartScene = "ARENA_StartScene",
	TeamCondition = {
		{
			Condition = "TeamCharacterIdOr",
			Value = 
			{
				223148,
			},
			Desc = "队伍中必须有思诺曼",
			Hint = "队伍中必须有思诺曼",
		},
	},
	Enemy = {
		{
			Value = 244277,
			Level = 50,
		},
	},
}
