
ChallengeConfig[ChallengeID.Id7001] =
{
	Id = 7001,
	Name = "挑战木制宝箱怪",
	Desc = "活跃于野外地区的初级宝箱，通过其极具迷惑性的外表引诱冒险者靠近，然后“啊呜”一口吃掉。",
	ResultText = "击败木制宝箱怪了",
	Dialog = "你可不要看不起我啊！ ",
	NumCap = 5,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG01",
	StartScene = "ARENA_StartScene",
	Enemy = {
		{
			Value = 241001,
			Level = 1,
		},
	},
}
ChallengeConfig[ChallengeID.Id7002] =
{
	Id = 7002,
	Name = "挑战稀有宝箱怪",
	Desc = "活跃于危险地区的中级宝箱，金色的光芒会让老练的冒险者忘乎所以地靠近，在他打开宝箱的一刹那，就把对方吃掉。",
	ResultText = "击败稀有宝箱怪了",
	Dialog = "终于要被打开了吗？",
	NumCap = 5,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG01",
	StartScene = "ARENA_StartScene",
	Enemy = {
		{
			Value = 241002,
			Level = 1,
		},
	},
}
ChallengeConfig[ChallengeID.Id7003] =
{
	Id = 7003,
	Name = "挑战传奇宝箱怪",
	Desc = "深藏于顶级副本的史诗宝箱，再警惕的冒险者也无法抗拒他的璀璨光辉。而那些靠近的冒险者就再也回不来了。",
	ResultText = "击败传奇宝箱怪了",
	Dialog = "你来晚了，已经没宝物了…",
	NumCap = 5,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG01",
	StartScene = "ARENA_StartScene",
	Enemy = {
		{
			Value = 241003,
			Level = 1,
		},
	},
}
ChallengeConfig[ChallengeID.Id7004] =
{
	Id = 7004,
	Name = "挑战圣骑士",
	Desc = "来自大圣堂的贵族武士，恪守着对神圣许下的誓言，行走世界各地打击邪恶与异端。做事虽然很刻板，但是是很可靠的伙伴。",
	ResultText = "圣骑士加入了队伍",
	Dialog = "愿圣光与你我同在！",
	NumCap = 5,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG01",
	StartScene = "ARENA_StartScene",
	Enemy = {
		{
			Value = 241004,
			Level = 1,
		},
	},
}
ChallengeConfig[ChallengeID.Id7005] =
{
	Id = 7005,
	Name = "挑战黑暗料理师",
	Desc = "遭到美食星放逐的料理大师，为了贯彻本人的料理之道，加入了神秘的宇宙海贼组织。在得到了黑暗的力量后，目前在美食星经营流动摊贩，出售让人无法拒绝的黑暗食物。",
	ResultText = "击退了黑暗料理师",
	Dialog = "不吃就不吃，我自己吃！",
	NumCap = 5,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "FATBG02",
	StartScene = "ARENA_StartScene",
	TeamCondition = {
		{
			Condition = "NeedTagOr",
			Value = 
			{
				560104,
			},
			Desc = "必须是美食星的队员",
			Hint = "必须是美食星的队员",
		},
	},
	Enemy = {
		{
			Value = 240801,
			Level = 50,
		},
	},
}
ChallengeConfig[ChallengeID.Id7006] =
{
	Id = 7006,
	Name = "挑战飙车王",
	Desc = "来自未知星球的飙车一族，参与了多起宇宙抢劫事件，是宇宙警视厅的重要通缉犯之一。据可靠消息，该犯罪分子目前已加入大型宇宙犯罪团伙。",
	ResultText = "击退了飙车王",
	Dialog = "上这么多人，体育精神呢？",
	NumCap = 5,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "MUSBG03",
	StartScene = "ARENA_StartScene",
	TeamCondition = {
		{
			Condition = "BanTagAnd",
			Value = 
			{
				561203,
			},
			Desc = "必须不是火元素的队员",
			Hint = "必须不是火元素的队员",
		},
	},
	Enemy = {
		{
			Value = 240802,
			Level = 75,
		},
	},
}
ChallengeConfig[ChallengeID.Id7007] =
{
	Id = 7007,
	Name = "挑战术士",
	Desc = "来自喧嚣之城的异族术士，以全A成绩进入魔法学院。然而即使在学术氛围浓郁的魔法学院里，仍因头上的奇怪犄角而遭人排挤。值得一提的是，术士在异世界语方面似乎极具天赋。",
	ResultText = "击退了术士",
	Dialog = "终于，有人关注我了。",
	NumCap = 5,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG05",
	StartScene = "ARENA_StartScene",
	TeamCondition = {
		{
			Condition = "NeedTagOr",
			Value = 
			{
				560103,
			},
			Desc = "必须是冒险星的队员",
			Hint = "必须是冒险星的队员",
		},
	},
	Enemy = {
		{
			Value = 240803,
			Level = 55,
		},
	},
}
ChallengeConfig[ChallengeID.Id7008] =
{
	Id = 7008,
	Name = "挑战另一个呜呜",
	AcceptSpeech = 14700801,
	Desc = "虽然和呜呜长得一样，动作也一样，但是！味道和呜呜完全不同喵！",
	ResultText = "击退了呜呜？",
	Dialog = "嘿嘿嘿嘿，竟然被发现了。",
	NumCap = 5,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "SUSBG04",
	StartScene = "ARENA_StartScene",
	TeamCondition = {
		{
			Condition = "TeamCharacterIdOr",
			Value = 
			{
				220001,
				220002,
			},
			Desc = "队伍中必须有呜呜或漆漆",
			Hint = "队伍中必须有呜呜或漆漆",
		},
	},
	Enemy = {
		{
			Value = 240804,
			Level = 65,
		},
	},
}
ChallengeConfig[ChallengeID.Id7009] =
{
	Id = 7009,
	Name = "挑战另一个漆漆",
	AcceptSpeech = 14700901,
	Desc = "虽然和漆漆长得一样，动作也一样，但是！体温和漆漆完全不同喵！",
	ResultText = "击退了漆漆？",
	Dialog = "嘿嘿嘿嘿，竟然又被发现了…",
	NumCap = 5,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "SUSBG04",
	StartScene = "ARENA_StartScene",
	TeamCondition = {
		{
			Condition = "TeamCharacterIdOr",
			Value = 
			{
				220001,
				220002,
			},
			Desc = "队伍中必须有呜呜或漆漆",
			Hint = "队伍中必须有呜呜或漆漆",
		},
	},
	Enemy = {
		{
			Value = 240805,
			Level = 70,
		},
	},
}
ChallengeConfig[ChallengeID.Id7010] =
{
	Id = 7010,
	Name = "挑战另一个收藏家",
	Desc = "另一个爷爷？可是爷爷明明不会，好吧…爷爷可能确实会做这么奇怪的事情！",
	ResultText = "击退了收藏家？",
	Dialog = "嘿嘿嘿嘿，竟然还被发现了…",
	NumCap = 5,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "SUSBG04",
	StartScene = "ARENA_StartScene",
	TeamCondition = {
		{
			Condition = "TeamCharacterIdOr",
			Value = 
			{
				220001,
				220002,
			},
			Desc = "队伍中必须有呜呜或漆漆",
			Hint = "队伍中必须有呜呜或漆漆",
		},
	},
	Enemy = {
		{
			Value = 240806,
			Level = 75,
		},
	},
}
ChallengeConfig[ChallengeID.Id7011] =
{
	Id = 7011,
	Name = "挑战百变怪客",
	Desc = "来自遥远星球的百变怪人。因马戏团长克扣工资而出逃，凭借变形能力潜入博物馆星球。据说，Ta非常善于伪装，制造的爆炸物也非比寻常。如果收到Ta的礼物，千万不要打开！",
	ResultText = "击退了百变怪客",
	Dialog = "嘿嘿嘿嘿，后会有期！",
	NumCap = 5,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "SUSBG04",
	StartScene = "ARENA_StartScene",
	TeamCondition = {
		{
			Condition = "TeamCharacterIdOr",
			Value = 
			{
				220001,
				220002,
			},
			Desc = "队伍中必须有呜呜或漆漆",
			Hint = "队伍中必须有呜呜或漆漆",
		},
		{
			Condition = "NeedTagOr",
			Value = 
			{
				560105,
			},
			Desc = "必须是博物馆星的队员",
			Hint = "必须是博物馆星的队员",
		},
	},
	Enemy = {
		{
			Value = 240807,
			Level = 80,
		},
	},
}
ChallengeConfig[ChallengeID.Id7012] =
{
	Id = 7012,
	Name = "挑战专员小鸽",
	Desc = "来自定制订单中心的服务专员。每天都在忙碌地为用户们抄写订单需求并发送到订单中心。不过“偶尔”也会不知去向，然后就没有然后了！",
	ResultText = "教训了专员小鸽",
	Dialog = "这次一定帮你送到！",
	NumCap = 5,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "FATBG04",
	StartScene = "ARENA_StartScene",
	TeamCondition = {
		{
			Condition = "TeamCharacterIdOr",
			Value = 
			{
				220001,
				220002,
			},
			Desc = "队伍中必须有呜呜或漆漆",
			Hint = "队伍中必须有呜呜或漆漆",
		},
	},
	Enemy = {
		{
			Value = 240808,
			Level = 42,
		},
	},
}
ChallengeConfig[ChallengeID.Id7013] =
{
	Id = 7013,
	Name = "挑战“伯爵”",
	Desc = "代号“伯爵”的犯罪分子，相传出身自高贵的家族。因为追求极致的艺术品，“伯爵”变得越来越孤僻。终日远离人群，独自钻研着赋予艺术品生命的方法。",
	ResultText = "击退了“伯爵”",
	Dialog = "各位，容我暂时告退。",
	NumCap = 5,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "MUSBG02",
	StartScene = "ARENA_StartScene",
	TeamCondition = {
		{
			Condition = "TeamCharacterIdOr",
			Value = 
			{
				220227,
				220226,
			},
			Desc = "队伍中必须有魔术师或微笑女神",
			Hint = "队伍中必须有魔术师或微笑女神",
		},
		{
			Condition = "NeedTagOr",
			Value = 
			{
				560105,
			},
			Desc = "必须是博物馆星的队员",
			Hint = "必须是博物馆星的队员",
		},
	},
	Enemy = {
		{
			Value = 240809,
			Level = 95,
		},
	},
}
ChallengeConfig[ChallengeID.Id7014] =
{
	Id = 7014,
	Name = "挑战凶手",
	Desc = "我是凶手，可我是被冤枉的，这有什么矛盾吗？",
	ResultText = "打败了凶手",
	Dialog = "我预判了你的预判的预判",
	NumCap = 5,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "SUSBG02",
	StartScene = "ARENA_StartScene",
	TeamCondition = {
		{
			Condition = "NeedTagOr",
			Value = 
			{
				560106,
			},
			Desc = "必须是悬疑星的队员",
			Hint = "必须是悬疑星的队员",
		},
	},
	Enemy = {
		{
			Value = 240810,
			Level = 95,
		},
	},
}
ChallengeConfig[ChallengeID.Id7015] =
{
	Id = 7015,
	Name = "挑战“波罗”",
	Desc = "代号“波罗”，痴迷侦探小说的危险分子，据说曾在一次推理比赛中败北，从此把大侦探视为宿敌，多年的努力只为完成一次“完美的犯罪”。",
	ResultText = "“波罗”逃走了…",
	Dialog = "我……我还会再回来的！",
	NumCap = 5,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "SUSBG02",
	StartScene = "ARENA_StartScene",
	TeamCondition = {
		{
			Condition = "NeedTagOr",
			Value = 
			{
				560106,
			},
			Desc = "必须是悬疑星的队员",
			Hint = "必须是悬疑星的队员",
		},
	},
	Enemy = {
		{
			Value = 240811,
			Level = 95,
		},
	},
}
