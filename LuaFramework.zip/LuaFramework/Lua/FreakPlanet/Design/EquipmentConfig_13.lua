
EquipmentConfig[EquipmentID.Id393] =
{
	Character = 220410,
	Rarity = 3,
	UpgradeId = 930029,
	LevelList = {
		{
			Level = 1,
			Info = 920353,
			Ability = {
				{
					Value = 200001,
					Num = 57,
				},
				{
					Value = 200005,
					Num = 9,
				},
			},
		},
		{
			Level = 2,
			Info = 920353,
			Ability = {
				{
					Value = 200001,
					Num = 114,
				},
				{
					Value = 200005,
					Num = 18,
				},
			},
		},
		{
			Level = 3,
			Info = 920353,
			Ability = {
				{
					Value = 200001,
					Num = 171,
				},
				{
					Value = 200005,
					Num = 27,
				},
			},
		},
		{
			Level = 4,
			Info = 920353,
			Ability = {
				{
					Value = 200001,
					Num = 228,
				},
				{
					Value = 200005,
					Num = 36,
				},
			},
		},
		{
			Level = 5,
			Info = 920353,
			Ability = {
				{
					Value = 200001,
					Num = 285,
				},
				{
					Value = 200005,
					Num = 45,
				},
			},
			SkillList = {
				{
					Id = 100651,
					Value = 5,
				},
			},
		},
		{
			Level = 6,
			Info = 920353,
			Ability = {
				{
					Value = 200001,
					Num = 342,
				},
				{
					Value = 200005,
					Num = 54,
				},
			},
			SkillList = {
				{
					Id = 100651,
					Value = 5,
				},
			},
		},
		{
			Level = 7,
			Info = 920353,
			Ability = {
				{
					Value = 200001,
					Num = 399,
				},
				{
					Value = 200005,
					Num = 63,
				},
			},
			SkillList = {
				{
					Id = 100651,
					Value = 5,
				},
			},
		},
		{
			Level = 8,
			Info = 920353,
			Ability = {
				{
					Value = 200001,
					Num = 456,
				},
				{
					Value = 200005,
					Num = 72,
				},
			},
			SkillList = {
				{
					Id = 100651,
					Value = 5,
				},
			},
		},
		{
			Level = 9,
			Info = 920353,
			Ability = {
				{
					Value = 200001,
					Num = 513,
				},
				{
					Value = 200005,
					Num = 81,
				},
			},
			SkillList = {
				{
					Id = 100651,
					Value = 5,
				},
			},
		},
		{
			Level = 10,
			Info = 920353,
			Ability = {
				{
					Value = 200001,
					Num = 570,
				},
				{
					Value = 200005,
					Num = 90,
				},
			},
			SkillList = {
				{
					Id = 100651,
					Value = 5,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id394] =
{
	Character = 220410,
	Rarity = 3,
	UpgradeId = 930030,
	LevelList = {
		{
			Level = 1,
			Info = 920354,
			Ability = {
				{
					Value = 200001,
					Num = 57,
				},
				{
					Value = 200007,
					Num = 6,
				},
			},
		},
		{
			Level = 2,
			Info = 920354,
			Ability = {
				{
					Value = 200001,
					Num = 114,
				},
				{
					Value = 200007,
					Num = 12,
				},
			},
		},
		{
			Level = 3,
			Info = 920354,
			Ability = {
				{
					Value = 200001,
					Num = 171,
				},
				{
					Value = 200007,
					Num = 18,
				},
			},
		},
		{
			Level = 4,
			Info = 920354,
			Ability = {
				{
					Value = 200001,
					Num = 228,
				},
				{
					Value = 200007,
					Num = 24,
				},
			},
		},
		{
			Level = 5,
			Info = 920354,
			Ability = {
				{
					Value = 200001,
					Num = 285,
				},
				{
					Value = 200007,
					Num = 30,
				},
			},
		},
		{
			Level = 6,
			Info = 920354,
			Ability = {
				{
					Value = 200001,
					Num = 342,
				},
				{
					Value = 200007,
					Num = 36,
				},
			},
		},
		{
			Level = 7,
			Info = 920354,
			Ability = {
				{
					Value = 200001,
					Num = 399,
				},
				{
					Value = 200007,
					Num = 42,
				},
			},
		},
		{
			Level = 8,
			Info = 920354,
			Ability = {
				{
					Value = 200001,
					Num = 456,
				},
				{
					Value = 200007,
					Num = 48,
				},
			},
			SkillList = {
				{
					Id = 100563,
					Value = -5,
				},
			},
		},
		{
			Level = 9,
			Info = 920354,
			Ability = {
				{
					Value = 200001,
					Num = 513,
				},
				{
					Value = 200007,
					Num = 54,
				},
			},
			SkillList = {
				{
					Id = 100563,
					Value = -5,
				},
			},
		},
		{
			Level = 10,
			Info = 920354,
			Ability = {
				{
					Value = 200001,
					Num = 570,
				},
				{
					Value = 200007,
					Num = 60,
				},
			},
			SkillList = {
				{
					Id = 100563,
					Value = -5,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id395] =
{
	Character = 220411,
	Rarity = 3,
	UpgradeId = 930009,
	LevelList = {
		{
			Level = 1,
			Info = 920356,
			Ability = {
				{
					Value = 200002,
					Num = 45,
				},
				{
					Value = 200008,
					Num = 9,
				},
			},
		},
		{
			Level = 2,
			Info = 920356,
			Ability = {
				{
					Value = 200002,
					Num = 90,
				},
				{
					Value = 200008,
					Num = 18,
				},
			},
		},
		{
			Level = 3,
			Info = 920356,
			Ability = {
				{
					Value = 200002,
					Num = 135,
				},
				{
					Value = 200008,
					Num = 27,
				},
			},
		},
		{
			Level = 4,
			Info = 920356,
			Ability = {
				{
					Value = 200002,
					Num = 180,
				},
				{
					Value = 200008,
					Num = 36,
				},
			},
		},
		{
			Level = 5,
			Info = 920356,
			Ability = {
				{
					Value = 200002,
					Num = 225,
				},
				{
					Value = 200008,
					Num = 45,
				},
			},
			SkillList = {
				{
					Id = 100652,
					Value = 5,
				},
			},
		},
		{
			Level = 6,
			Info = 920356,
			Ability = {
				{
					Value = 200002,
					Num = 270,
				},
				{
					Value = 200008,
					Num = 54,
				},
			},
			SkillList = {
				{
					Id = 100652,
					Value = 5,
				},
			},
		},
		{
			Level = 7,
			Info = 920356,
			Ability = {
				{
					Value = 200002,
					Num = 315,
				},
				{
					Value = 200008,
					Num = 63,
				},
			},
			SkillList = {
				{
					Id = 100652,
					Value = 5,
				},
			},
		},
		{
			Level = 8,
			Info = 920356,
			Ability = {
				{
					Value = 200002,
					Num = 360,
				},
				{
					Value = 200008,
					Num = 72,
				},
			},
			SkillList = {
				{
					Id = 100652,
					Value = 5,
				},
			},
		},
		{
			Level = 9,
			Info = 920356,
			Ability = {
				{
					Value = 200002,
					Num = 405,
				},
				{
					Value = 200008,
					Num = 81,
				},
			},
			SkillList = {
				{
					Id = 100652,
					Value = 5,
				},
			},
		},
		{
			Level = 10,
			Info = 920356,
			Ability = {
				{
					Value = 200002,
					Num = 450,
				},
				{
					Value = 200008,
					Num = 90,
				},
			},
			SkillList = {
				{
					Id = 100652,
					Value = 5,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id396] =
{
	Character = 220411,
	Rarity = 3,
	UpgradeId = 930010,
	LevelList = {
		{
			Level = 1,
			Info = 920357,
			Ability = {
				{
					Value = 200002,
					Num = 45,
				},
				{
					Value = 200005,
					Num = 6,
				},
			},
		},
		{
			Level = 2,
			Info = 920357,
			Ability = {
				{
					Value = 200002,
					Num = 90,
				},
				{
					Value = 200005,
					Num = 12,
				},
			},
		},
		{
			Level = 3,
			Info = 920357,
			Ability = {
				{
					Value = 200002,
					Num = 135,
				},
				{
					Value = 200005,
					Num = 18,
				},
			},
		},
		{
			Level = 4,
			Info = 920357,
			Ability = {
				{
					Value = 200002,
					Num = 180,
				},
				{
					Value = 200005,
					Num = 24,
				},
			},
		},
		{
			Level = 5,
			Info = 920357,
			Ability = {
				{
					Value = 200002,
					Num = 225,
				},
				{
					Value = 200005,
					Num = 30,
				},
			},
		},
		{
			Level = 6,
			Info = 920357,
			Ability = {
				{
					Value = 200002,
					Num = 270,
				},
				{
					Value = 200005,
					Num = 36,
				},
			},
		},
		{
			Level = 7,
			Info = 920357,
			Ability = {
				{
					Value = 200002,
					Num = 315,
				},
				{
					Value = 200005,
					Num = 42,
				},
			},
		},
		{
			Level = 8,
			Info = 920357,
			Ability = {
				{
					Value = 200002,
					Num = 360,
				},
				{
					Value = 200005,
					Num = 48,
				},
			},
			SkillList = {
				{
					Id = 100555,
					Value = 25,
				},
			},
		},
		{
			Level = 9,
			Info = 920357,
			Ability = {
				{
					Value = 200002,
					Num = 405,
				},
				{
					Value = 200005,
					Num = 54,
				},
			},
			SkillList = {
				{
					Id = 100555,
					Value = 25,
				},
			},
		},
		{
			Level = 10,
			Info = 920357,
			Ability = {
				{
					Value = 200002,
					Num = 450,
				},
				{
					Value = 200005,
					Num = 60,
				},
			},
			SkillList = {
				{
					Id = 100555,
					Value = 25,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id397] =
{
	Character = 220412,
	Rarity = 3,
	UpgradeId = 930029,
	LevelList = {
		{
			Level = 1,
			Info = 920359,
			Ability = {
				{
					Value = 200001,
					Num = 54,
				},
				{
					Value = 200006,
					Num = 9,
				},
			},
		},
		{
			Level = 2,
			Info = 920359,
			Ability = {
				{
					Value = 200001,
					Num = 108,
				},
				{
					Value = 200006,
					Num = 18,
				},
			},
		},
		{
			Level = 3,
			Info = 920359,
			Ability = {
				{
					Value = 200001,
					Num = 162,
				},
				{
					Value = 200006,
					Num = 27,
				},
			},
		},
		{
			Level = 4,
			Info = 920359,
			Ability = {
				{
					Value = 200001,
					Num = 216,
				},
				{
					Value = 200006,
					Num = 36,
				},
			},
		},
		{
			Level = 5,
			Info = 920359,
			Ability = {
				{
					Value = 200001,
					Num = 270,
				},
				{
					Value = 200006,
					Num = 45,
				},
			},
			SkillList = {
				{
					Id = 100651,
					Value = 5,
				},
			},
		},
		{
			Level = 6,
			Info = 920359,
			Ability = {
				{
					Value = 200001,
					Num = 324,
				},
				{
					Value = 200006,
					Num = 54,
				},
			},
			SkillList = {
				{
					Id = 100651,
					Value = 5,
				},
			},
		},
		{
			Level = 7,
			Info = 920359,
			Ability = {
				{
					Value = 200001,
					Num = 378,
				},
				{
					Value = 200006,
					Num = 63,
				},
			},
			SkillList = {
				{
					Id = 100651,
					Value = 5,
				},
			},
		},
		{
			Level = 8,
			Info = 920359,
			Ability = {
				{
					Value = 200001,
					Num = 432,
				},
				{
					Value = 200006,
					Num = 72,
				},
			},
			SkillList = {
				{
					Id = 100651,
					Value = 5,
				},
			},
		},
		{
			Level = 9,
			Info = 920359,
			Ability = {
				{
					Value = 200001,
					Num = 486,
				},
				{
					Value = 200006,
					Num = 81,
				},
			},
			SkillList = {
				{
					Id = 100651,
					Value = 5,
				},
			},
		},
		{
			Level = 10,
			Info = 920359,
			Ability = {
				{
					Value = 200001,
					Num = 540,
				},
				{
					Value = 200006,
					Num = 90,
				},
			},
			SkillList = {
				{
					Id = 100651,
					Value = 5,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id398] =
{
	Character = 220412,
	Rarity = 3,
	UpgradeId = 930010,
	LevelList = {
		{
			Level = 1,
			Info = 920360,
			Ability = {
				{
					Value = 200002,
					Num = 45,
				},
				{
					Value = 200008,
					Num = 6,
				},
			},
		},
		{
			Level = 2,
			Info = 920360,
			Ability = {
				{
					Value = 200002,
					Num = 90,
				},
				{
					Value = 200008,
					Num = 12,
				},
			},
		},
		{
			Level = 3,
			Info = 920360,
			Ability = {
				{
					Value = 200002,
					Num = 135,
				},
				{
					Value = 200008,
					Num = 18,
				},
			},
		},
		{
			Level = 4,
			Info = 920360,
			Ability = {
				{
					Value = 200002,
					Num = 180,
				},
				{
					Value = 200008,
					Num = 24,
				},
			},
		},
		{
			Level = 5,
			Info = 920360,
			Ability = {
				{
					Value = 200002,
					Num = 225,
				},
				{
					Value = 200008,
					Num = 30,
				},
			},
		},
		{
			Level = 6,
			Info = 920360,
			Ability = {
				{
					Value = 200002,
					Num = 270,
				},
				{
					Value = 200008,
					Num = 36,
				},
			},
		},
		{
			Level = 7,
			Info = 920360,
			Ability = {
				{
					Value = 200002,
					Num = 315,
				},
				{
					Value = 200008,
					Num = 42,
				},
			},
		},
		{
			Level = 8,
			Info = 920360,
			Ability = {
				{
					Value = 200002,
					Num = 360,
				},
				{
					Value = 200008,
					Num = 48,
				},
			},
			SkillList = {
				{
					Id = 100232,
					Value = 25,
				},
			},
		},
		{
			Level = 9,
			Info = 920360,
			Ability = {
				{
					Value = 200002,
					Num = 405,
				},
				{
					Value = 200008,
					Num = 54,
				},
			},
			SkillList = {
				{
					Id = 100232,
					Value = 25,
				},
			},
		},
		{
			Level = 10,
			Info = 920360,
			Ability = {
				{
					Value = 200002,
					Num = 450,
				},
				{
					Value = 200008,
					Num = 60,
				},
			},
			SkillList = {
				{
					Id = 100232,
					Value = 25,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id399] =
{
	Character = 220413,
	Rarity = 3,
	UpgradeId = 930029,
	LevelList = {
		{
			Level = 1,
			Info = 920362,
			Ability = {
				{
					Value = 200001,
					Num = 57,
				},
				{
					Value = 200007,
					Num = 9,
				},
			},
		},
		{
			Level = 2,
			Info = 920362,
			Ability = {
				{
					Value = 200001,
					Num = 114,
				},
				{
					Value = 200007,
					Num = 18,
				},
			},
		},
		{
			Level = 3,
			Info = 920362,
			Ability = {
				{
					Value = 200001,
					Num = 171,
				},
				{
					Value = 200007,
					Num = 27,
				},
			},
		},
		{
			Level = 4,
			Info = 920362,
			Ability = {
				{
					Value = 200001,
					Num = 228,
				},
				{
					Value = 200007,
					Num = 36,
				},
			},
		},
		{
			Level = 5,
			Info = 920362,
			Ability = {
				{
					Value = 200001,
					Num = 285,
				},
				{
					Value = 200007,
					Num = 45,
				},
			},
			SkillList = {
				{
					Id = 100651,
					Value = 5,
				},
			},
		},
		{
			Level = 6,
			Info = 920362,
			Ability = {
				{
					Value = 200001,
					Num = 342,
				},
				{
					Value = 200007,
					Num = 54,
				},
			},
			SkillList = {
				{
					Id = 100651,
					Value = 5,
				},
			},
		},
		{
			Level = 7,
			Info = 920362,
			Ability = {
				{
					Value = 200001,
					Num = 399,
				},
				{
					Value = 200007,
					Num = 63,
				},
			},
			SkillList = {
				{
					Id = 100651,
					Value = 5,
				},
			},
		},
		{
			Level = 8,
			Info = 920362,
			Ability = {
				{
					Value = 200001,
					Num = 456,
				},
				{
					Value = 200007,
					Num = 72,
				},
			},
			SkillList = {
				{
					Id = 100651,
					Value = 5,
				},
			},
		},
		{
			Level = 9,
			Info = 920362,
			Ability = {
				{
					Value = 200001,
					Num = 513,
				},
				{
					Value = 200007,
					Num = 81,
				},
			},
			SkillList = {
				{
					Id = 100651,
					Value = 5,
				},
			},
		},
		{
			Level = 10,
			Info = 920362,
			Ability = {
				{
					Value = 200001,
					Num = 570,
				},
				{
					Value = 200007,
					Num = 90,
				},
			},
			SkillList = {
				{
					Id = 100651,
					Value = 5,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id400] =
{
	Character = 220413,
	Rarity = 3,
	UpgradeId = 930030,
	LevelList = {
		{
			Level = 1,
			Info = 920363,
			Ability = {
				{
					Value = 200001,
					Num = 57,
				},
				{
					Value = 200005,
					Num = 6,
				},
			},
		},
		{
			Level = 2,
			Info = 920363,
			Ability = {
				{
					Value = 200001,
					Num = 114,
				},
				{
					Value = 200005,
					Num = 12,
				},
			},
		},
		{
			Level = 3,
			Info = 920363,
			Ability = {
				{
					Value = 200001,
					Num = 171,
				},
				{
					Value = 200005,
					Num = 18,
				},
			},
		},
		{
			Level = 4,
			Info = 920363,
			Ability = {
				{
					Value = 200001,
					Num = 228,
				},
				{
					Value = 200005,
					Num = 24,
				},
			},
		},
		{
			Level = 5,
			Info = 920363,
			Ability = {
				{
					Value = 200001,
					Num = 285,
				},
				{
					Value = 200005,
					Num = 30,
				},
			},
		},
		{
			Level = 6,
			Info = 920363,
			Ability = {
				{
					Value = 200001,
					Num = 342,
				},
				{
					Value = 200005,
					Num = 36,
				},
			},
		},
		{
			Level = 7,
			Info = 920363,
			Ability = {
				{
					Value = 200001,
					Num = 399,
				},
				{
					Value = 200005,
					Num = 42,
				},
			},
		},
		{
			Level = 8,
			Info = 920363,
			Ability = {
				{
					Value = 200001,
					Num = 456,
				},
				{
					Value = 200005,
					Num = 48,
				},
			},
			SkillList = {
				{
					Id = 101701,
					Value = 216,
				},
			},
		},
		{
			Level = 9,
			Info = 920363,
			Ability = {
				{
					Value = 200001,
					Num = 513,
				},
				{
					Value = 200005,
					Num = 54,
				},
			},
			SkillList = {
				{
					Id = 101701,
					Value = 216,
				},
			},
		},
		{
			Level = 10,
			Info = 920363,
			Ability = {
				{
					Value = 200001,
					Num = 570,
				},
				{
					Value = 200005,
					Num = 60,
				},
			},
			SkillList = {
				{
					Id = 101701,
					Value = 216,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id401] =
{
	Character = 220406,
	Rarity = 3,
	UpgradeId = 930029,
	LevelList = {
		{
			Level = 1,
			Info = 920341,
			Ability = {
				{
					Value = 200001,
					Num = 57,
				},
				{
					Value = 200006,
					Num = 9,
				},
			},
		},
		{
			Level = 2,
			Info = 920341,
			Ability = {
				{
					Value = 200001,
					Num = 114,
				},
				{
					Value = 200006,
					Num = 18,
				},
			},
		},
		{
			Level = 3,
			Info = 920341,
			Ability = {
				{
					Value = 200001,
					Num = 171,
				},
				{
					Value = 200006,
					Num = 27,
				},
			},
		},
		{
			Level = 4,
			Info = 920341,
			Ability = {
				{
					Value = 200001,
					Num = 228,
				},
				{
					Value = 200006,
					Num = 36,
				},
			},
		},
		{
			Level = 5,
			Info = 920341,
			Ability = {
				{
					Value = 200001,
					Num = 285,
				},
				{
					Value = 200006,
					Num = 45,
				},
			},
		},
		{
			Level = 6,
			Info = 920341,
			Ability = {
				{
					Value = 200001,
					Num = 342,
				},
				{
					Value = 200006,
					Num = 54,
				},
			},
		},
		{
			Level = 7,
			Info = 920341,
			Ability = {
				{
					Value = 200001,
					Num = 399,
				},
				{
					Value = 200006,
					Num = 63,
				},
			},
		},
		{
			Level = 8,
			Info = 920341,
			Ability = {
				{
					Value = 200001,
					Num = 456,
				},
				{
					Value = 200006,
					Num = 72,
				},
			},
			SkillList = {
				{
					Id = 100562,
					Value = -5,
				},
			},
		},
		{
			Level = 9,
			Info = 920341,
			Ability = {
				{
					Value = 200001,
					Num = 513,
				},
				{
					Value = 200006,
					Num = 81,
				},
			},
			SkillList = {
				{
					Id = 100562,
					Value = -5,
				},
			},
		},
		{
			Level = 10,
			Info = 920341,
			Ability = {
				{
					Value = 200001,
					Num = 570,
				},
				{
					Value = 200006,
					Num = 90,
				},
			},
			SkillList = {
				{
					Id = 100562,
					Value = -5,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id402] =
{
	Character = 220406,
	Rarity = 3,
	UpgradeId = 930030,
	LevelList = {
		{
			Level = 1,
			Info = 920342,
			Ability = {
				{
					Value = 200001,
					Num = 57,
				},
				{
					Value = 200007,
					Num = 6,
				},
			},
		},
		{
			Level = 2,
			Info = 920342,
			Ability = {
				{
					Value = 200001,
					Num = 114,
				},
				{
					Value = 200007,
					Num = 12,
				},
			},
		},
		{
			Level = 3,
			Info = 920342,
			Ability = {
				{
					Value = 200001,
					Num = 171,
				},
				{
					Value = 200007,
					Num = 18,
				},
			},
		},
		{
			Level = 4,
			Info = 920342,
			Ability = {
				{
					Value = 200001,
					Num = 228,
				},
				{
					Value = 200007,
					Num = 24,
				},
			},
		},
		{
			Level = 5,
			Info = 920342,
			Ability = {
				{
					Value = 200001,
					Num = 285,
				},
				{
					Value = 200007,
					Num = 30,
				},
			},
		},
		{
			Level = 6,
			Info = 920342,
			Ability = {
				{
					Value = 200001,
					Num = 342,
				},
				{
					Value = 200007,
					Num = 36,
				},
			},
		},
		{
			Level = 7,
			Info = 920342,
			Ability = {
				{
					Value = 200001,
					Num = 399,
				},
				{
					Value = 200007,
					Num = 42,
				},
			},
		},
		{
			Level = 8,
			Info = 920342,
			Ability = {
				{
					Value = 200001,
					Num = 456,
				},
				{
					Value = 200007,
					Num = 48,
				},
			},
			SkillList = {
				{
					Id = 100606,
					Value = -25,
				},
			},
		},
		{
			Level = 9,
			Info = 920342,
			Ability = {
				{
					Value = 200001,
					Num = 513,
				},
				{
					Value = 200007,
					Num = 54,
				},
			},
			SkillList = {
				{
					Id = 100606,
					Value = -25,
				},
			},
		},
		{
			Level = 10,
			Info = 920342,
			Ability = {
				{
					Value = 200001,
					Num = 570,
				},
				{
					Value = 200007,
					Num = 60,
				},
			},
			SkillList = {
				{
					Id = 100606,
					Value = -25,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id403] =
{
	Character = 220406,
	Rarity = 3,
	NeedChallenge = 145159,
	UpgradeId = 930011,
	LevelList = {
		{
			Level = 1,
			Info = 920343,
			Ability = {
				{
					Value = 200002,
					Num = 84,
				},
			},
		},
		{
			Level = 2,
			Info = 920343,
			Ability = {
				{
					Value = 200002,
					Num = 140,
				},
			},
		},
		{
			Level = 3,
			Info = 920343,
			Ability = {
				{
					Value = 200002,
					Num = 196,
				},
			},
		},
		{
			Level = 4,
			Info = 920343,
			Ability = {
				{
					Value = 200002,
					Num = 252,
				},
			},
		},
		{
			Level = 5,
			Info = 920343,
			Ability = {
				{
					Value = 200002,
					Num = 308,
				},
				{
					Value = 200004,
					Num = 25,
				},
			},
		},
		{
			Level = 6,
			Info = 920343,
			Ability = {
				{
					Value = 200002,
					Num = 364,
				},
				{
					Value = 200004,
					Num = 30,
				},
			},
		},
		{
			Level = 7,
			Info = 920343,
			Ability = {
				{
					Value = 200002,
					Num = 420,
				},
				{
					Value = 200004,
					Num = 35,
				},
			},
		},
		{
			Level = 8,
			Info = 920343,
			Ability = {
				{
					Value = 200002,
					Num = 476,
				},
				{
					Value = 200004,
					Num = 40,
				},
			},
			SkillList = {
				{
					Id = 101745,
					Value = 60,
				},
			},
		},
		{
			Level = 9,
			Info = 920343,
			Ability = {
				{
					Value = 200002,
					Num = 532,
				},
				{
					Value = 200004,
					Num = 45,
				},
			},
			SkillList = {
				{
					Id = 101745,
					Value = 60,
				},
			},
		},
		{
			Level = 10,
			Info = 920343,
			Ability = {
				{
					Value = 200002,
					Num = 588,
				},
				{
					Value = 200004,
					Num = 50,
				},
			},
			SkillList = {
				{
					Id = 101745,
					Value = 60,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id404] =
{
	Character = 220414,
	Rarity = 3,
	UpgradeId = 930029,
	LevelList = {
		{
			Level = 1,
			Info = 920365,
			Ability = {
				{
					Value = 200001,
					Num = 57,
				},
				{
					Value = 200005,
					Num = 9,
				},
			},
		},
		{
			Level = 2,
			Info = 920365,
			Ability = {
				{
					Value = 200001,
					Num = 114,
				},
				{
					Value = 200005,
					Num = 18,
				},
			},
		},
		{
			Level = 3,
			Info = 920365,
			Ability = {
				{
					Value = 200001,
					Num = 171,
				},
				{
					Value = 200005,
					Num = 27,
				},
			},
		},
		{
			Level = 4,
			Info = 920365,
			Ability = {
				{
					Value = 200001,
					Num = 228,
				},
				{
					Value = 200005,
					Num = 36,
				},
			},
		},
		{
			Level = 5,
			Info = 920365,
			Ability = {
				{
					Value = 200001,
					Num = 285,
				},
				{
					Value = 200005,
					Num = 45,
				},
			},
			SkillList = {
				{
					Id = 100651,
					Value = 5,
				},
			},
		},
		{
			Level = 6,
			Info = 920365,
			Ability = {
				{
					Value = 200001,
					Num = 342,
				},
				{
					Value = 200005,
					Num = 54,
				},
			},
			SkillList = {
				{
					Id = 100651,
					Value = 5,
				},
			},
		},
		{
			Level = 7,
			Info = 920365,
			Ability = {
				{
					Value = 200001,
					Num = 399,
				},
				{
					Value = 200005,
					Num = 63,
				},
			},
			SkillList = {
				{
					Id = 100651,
					Value = 5,
				},
			},
		},
		{
			Level = 8,
			Info = 920365,
			Ability = {
				{
					Value = 200001,
					Num = 456,
				},
				{
					Value = 200005,
					Num = 72,
				},
			},
			SkillList = {
				{
					Id = 100651,
					Value = 5,
				},
			},
		},
		{
			Level = 9,
			Info = 920365,
			Ability = {
				{
					Value = 200001,
					Num = 513,
				},
				{
					Value = 200005,
					Num = 81,
				},
			},
			SkillList = {
				{
					Id = 100651,
					Value = 5,
				},
			},
		},
		{
			Level = 10,
			Info = 920365,
			Ability = {
				{
					Value = 200001,
					Num = 570,
				},
				{
					Value = 200005,
					Num = 90,
				},
			},
			SkillList = {
				{
					Id = 100651,
					Value = 5,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id405] =
{
	Character = 220414,
	Rarity = 3,
	UpgradeId = 930010,
	LevelList = {
		{
			Level = 1,
			Info = 920366,
			Ability = {
				{
					Value = 200002,
					Num = 42,
				},
				{
					Value = 200008,
					Num = 6,
				},
			},
		},
		{
			Level = 2,
			Info = 920366,
			Ability = {
				{
					Value = 200002,
					Num = 84,
				},
				{
					Value = 200008,
					Num = 12,
				},
			},
		},
		{
			Level = 3,
			Info = 920366,
			Ability = {
				{
					Value = 200002,
					Num = 126,
				},
				{
					Value = 200008,
					Num = 18,
				},
			},
		},
		{
			Level = 4,
			Info = 920366,
			Ability = {
				{
					Value = 200002,
					Num = 168,
				},
				{
					Value = 200008,
					Num = 24,
				},
			},
		},
		{
			Level = 5,
			Info = 920366,
			Ability = {
				{
					Value = 200002,
					Num = 210,
				},
				{
					Value = 200008,
					Num = 30,
				},
			},
		},
		{
			Level = 6,
			Info = 920366,
			Ability = {
				{
					Value = 200002,
					Num = 252,
				},
				{
					Value = 200008,
					Num = 36,
				},
			},
		},
		{
			Level = 7,
			Info = 920366,
			Ability = {
				{
					Value = 200002,
					Num = 294,
				},
				{
					Value = 200008,
					Num = 42,
				},
			},
		},
		{
			Level = 8,
			Info = 920366,
			Ability = {
				{
					Value = 200002,
					Num = 336,
				},
				{
					Value = 200008,
					Num = 48,
				},
			},
			SkillList = {
				{
					Id = 100551,
					Value = 25,
				},
			},
		},
		{
			Level = 9,
			Info = 920366,
			Ability = {
				{
					Value = 200002,
					Num = 378,
				},
				{
					Value = 200008,
					Num = 54,
				},
			},
			SkillList = {
				{
					Id = 100551,
					Value = 25,
				},
			},
		},
		{
			Level = 10,
			Info = 920366,
			Ability = {
				{
					Value = 200002,
					Num = 420,
				},
				{
					Value = 200008,
					Num = 60,
				},
			},
			SkillList = {
				{
					Id = 100551,
					Value = 25,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id406] =
{
	Character = 220414,
	Rarity = 3,
	NeedChallenge = 145160,
	UpgradeId = 930011,
	LevelList = {
		{
			Level = 1,
			Info = 920367,
			Ability = {
				{
					Value = 200002,
					Num = 84,
				},
			},
		},
		{
			Level = 2,
			Info = 920367,
			Ability = {
				{
					Value = 200002,
					Num = 140,
				},
			},
		},
		{
			Level = 3,
			Info = 920367,
			Ability = {
				{
					Value = 200002,
					Num = 196,
				},
			},
		},
		{
			Level = 4,
			Info = 920367,
			Ability = {
				{
					Value = 200002,
					Num = 252,
				},
			},
		},
		{
			Level = 5,
			Info = 920367,
			Ability = {
				{
					Value = 200002,
					Num = 308,
				},
				{
					Value = 200004,
					Num = 25,
				},
			},
		},
		{
			Level = 6,
			Info = 920367,
			Ability = {
				{
					Value = 200002,
					Num = 364,
				},
				{
					Value = 200004,
					Num = 30,
				},
			},
		},
		{
			Level = 7,
			Info = 920367,
			Ability = {
				{
					Value = 200002,
					Num = 420,
				},
				{
					Value = 200004,
					Num = 35,
				},
			},
		},
		{
			Level = 8,
			Info = 920367,
			Ability = {
				{
					Value = 200002,
					Num = 476,
				},
				{
					Value = 200004,
					Num = 40,
				},
			},
			SkillList = {
				{
					Id = 100601,
					Value = 12,
				},
			},
		},
		{
			Level = 9,
			Info = 920367,
			Ability = {
				{
					Value = 200002,
					Num = 532,
				},
				{
					Value = 200004,
					Num = 45,
				},
			},
			SkillList = {
				{
					Id = 100601,
					Value = 12,
				},
			},
		},
		{
			Level = 10,
			Info = 920367,
			Ability = {
				{
					Value = 200002,
					Num = 588,
				},
				{
					Value = 200004,
					Num = 50,
				},
			},
			SkillList = {
				{
					Id = 100601,
					Value = 12,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id407] =
{
	Character = 220415,
	Rarity = 3,
	UpgradeId = 930029,
	LevelList = {
		{
			Level = 1,
			Info = 920368,
			Ability = {
				{
					Value = 200001,
					Num = 54,
				},
				{
					Value = 200005,
					Num = 15,
				},
			},
		},
		{
			Level = 2,
			Info = 920368,
			Ability = {
				{
					Value = 200001,
					Num = 108,
				},
				{
					Value = 200005,
					Num = 30,
				},
			},
		},
		{
			Level = 3,
			Info = 920368,
			Ability = {
				{
					Value = 200001,
					Num = 162,
				},
				{
					Value = 200005,
					Num = 45,
				},
			},
		},
		{
			Level = 4,
			Info = 920368,
			Ability = {
				{
					Value = 200001,
					Num = 216,
				},
				{
					Value = 200005,
					Num = 60,
				},
			},
		},
		{
			Level = 5,
			Info = 920368,
			Ability = {
				{
					Value = 200001,
					Num = 270,
				},
				{
					Value = 200005,
					Num = 75,
				},
			},
			SkillList = {
				{
					Id = 100651,
					Value = 5,
				},
			},
		},
		{
			Level = 6,
			Info = 920368,
			Ability = {
				{
					Value = 200001,
					Num = 324,
				},
				{
					Value = 200005,
					Num = 90,
				},
			},
			SkillList = {
				{
					Id = 100651,
					Value = 5,
				},
			},
		},
		{
			Level = 7,
			Info = 920368,
			Ability = {
				{
					Value = 200001,
					Num = 378,
				},
				{
					Value = 200005,
					Num = 105,
				},
			},
			SkillList = {
				{
					Id = 100651,
					Value = 5,
				},
			},
		},
		{
			Level = 8,
			Info = 920368,
			Ability = {
				{
					Value = 200001,
					Num = 432,
				},
				{
					Value = 200005,
					Num = 120,
				},
			},
			SkillList = {
				{
					Id = 100651,
					Value = 5,
				},
			},
		},
		{
			Level = 9,
			Info = 920368,
			Ability = {
				{
					Value = 200001,
					Num = 486,
				},
				{
					Value = 200005,
					Num = 135,
				},
			},
			SkillList = {
				{
					Id = 100651,
					Value = 5,
				},
			},
		},
		{
			Level = 10,
			Info = 920368,
			Ability = {
				{
					Value = 200001,
					Num = 540,
				},
				{
					Value = 200005,
					Num = 150,
				},
			},
			SkillList = {
				{
					Id = 100651,
					Value = 5,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id408] =
{
	Character = 220415,
	Rarity = 3,
	UpgradeId = 930010,
	LevelList = {
		{
			Level = 1,
			Info = 920369,
			Ability = {
				{
					Value = 200002,
					Num = 45,
				},
				{
					Value = 200005,
					Num = 15,
				},
			},
		},
		{
			Level = 2,
			Info = 920369,
			Ability = {
				{
					Value = 200002,
					Num = 90,
				},
				{
					Value = 200005,
					Num = 30,
				},
			},
		},
		{
			Level = 3,
			Info = 920369,
			Ability = {
				{
					Value = 200002,
					Num = 135,
				},
				{
					Value = 200005,
					Num = 45,
				},
			},
		},
		{
			Level = 4,
			Info = 920369,
			Ability = {
				{
					Value = 200002,
					Num = 180,
				},
				{
					Value = 200005,
					Num = 60,
				},
			},
		},
		{
			Level = 5,
			Info = 920369,
			Ability = {
				{
					Value = 200002,
					Num = 225,
				},
				{
					Value = 200005,
					Num = 75,
				},
			},
		},
		{
			Level = 6,
			Info = 920369,
			Ability = {
				{
					Value = 200002,
					Num = 270,
				},
				{
					Value = 200005,
					Num = 90,
				},
			},
		},
		{
			Level = 7,
			Info = 920369,
			Ability = {
				{
					Value = 200002,
					Num = 315,
				},
				{
					Value = 200005,
					Num = 105,
				},
			},
		},
		{
			Level = 8,
			Info = 920369,
			Ability = {
				{
					Value = 200002,
					Num = 360,
				},
				{
					Value = 200005,
					Num = 120,
				},
			},
			SkillList = {
				{
					Id = 100552,
					Value = 25,
				},
			},
		},
		{
			Level = 9,
			Info = 920369,
			Ability = {
				{
					Value = 200002,
					Num = 405,
				},
				{
					Value = 200005,
					Num = 135,
				},
			},
			SkillList = {
				{
					Id = 100552,
					Value = 25,
				},
			},
		},
		{
			Level = 10,
			Info = 920369,
			Ability = {
				{
					Value = 200002,
					Num = 450,
				},
				{
					Value = 200005,
					Num = 150,
				},
			},
			SkillList = {
				{
					Id = 100552,
					Value = 25,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id409] =
{
	Character = 220415,
	Rarity = 3,
	NeedChallenge = 145161,
	UpgradeId = 930011,
	LevelList = {
		{
			Level = 1,
			Info = 920370,
			Ability = {
				{
					Value = 200002,
					Num = 90,
				},
			},
		},
		{
			Level = 2,
			Info = 920370,
			Ability = {
				{
					Value = 200002,
					Num = 150,
				},
			},
		},
		{
			Level = 3,
			Info = 920370,
			Ability = {
				{
					Value = 200002,
					Num = 210,
				},
			},
		},
		{
			Level = 4,
			Info = 920370,
			Ability = {
				{
					Value = 200002,
					Num = 270,
				},
			},
		},
		{
			Level = 5,
			Info = 920370,
			Ability = {
				{
					Value = 200002,
					Num = 330,
				},
				{
					Value = 200004,
					Num = 25,
				},
			},
		},
		{
			Level = 6,
			Info = 920370,
			Ability = {
				{
					Value = 200002,
					Num = 390,
				},
				{
					Value = 200004,
					Num = 30,
				},
			},
		},
		{
			Level = 7,
			Info = 920370,
			Ability = {
				{
					Value = 200002,
					Num = 450,
				},
				{
					Value = 200004,
					Num = 35,
				},
			},
		},
		{
			Level = 8,
			Info = 920370,
			Ability = {
				{
					Value = 200002,
					Num = 510,
				},
				{
					Value = 200004,
					Num = 40,
				},
			},
			SkillList = {
				{
					Id = 100201,
					Value = 25,
				},
			},
		},
		{
			Level = 9,
			Info = 920370,
			Ability = {
				{
					Value = 200002,
					Num = 570,
				},
				{
					Value = 200004,
					Num = 45,
				},
			},
			SkillList = {
				{
					Id = 100201,
					Value = 25,
				},
			},
		},
		{
			Level = 10,
			Info = 920370,
			Ability = {
				{
					Value = 200002,
					Num = 630,
				},
				{
					Value = 200004,
					Num = 50,
				},
			},
			SkillList = {
				{
					Id = 100201,
					Value = 25,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id410] =
{
	Character = 220405,
	Rarity = 3,
	UpgradeId = 930029,
	LevelList = {
		{
			Level = 1,
			Info = 920338,
			Ability = {
				{
					Value = 200001,
					Num = 57,
				},
				{
					Value = 200007,
					Num = 9,
				},
			},
		},
		{
			Level = 2,
			Info = 920338,
			Ability = {
				{
					Value = 200001,
					Num = 114,
				},
				{
					Value = 200007,
					Num = 18,
				},
			},
		},
		{
			Level = 3,
			Info = 920338,
			Ability = {
				{
					Value = 200001,
					Num = 171,
				},
				{
					Value = 200007,
					Num = 27,
				},
			},
		},
		{
			Level = 4,
			Info = 920338,
			Ability = {
				{
					Value = 200001,
					Num = 228,
				},
				{
					Value = 200007,
					Num = 36,
				},
			},
		},
		{
			Level = 5,
			Info = 920338,
			Ability = {
				{
					Value = 200001,
					Num = 285,
				},
				{
					Value = 200007,
					Num = 45,
				},
			},
			SkillList = {
				{
					Id = 100653,
					Value = 36,
				},
			},
		},
		{
			Level = 6,
			Info = 920338,
			Ability = {
				{
					Value = 200001,
					Num = 342,
				},
				{
					Value = 200007,
					Num = 54,
				},
			},
			SkillList = {
				{
					Id = 100653,
					Value = 36,
				},
			},
		},
		{
			Level = 7,
			Info = 920338,
			Ability = {
				{
					Value = 200001,
					Num = 399,
				},
				{
					Value = 200007,
					Num = 63,
				},
			},
			SkillList = {
				{
					Id = 100653,
					Value = 36,
				},
			},
		},
		{
			Level = 8,
			Info = 920338,
			Ability = {
				{
					Value = 200001,
					Num = 456,
				},
				{
					Value = 200007,
					Num = 72,
				},
			},
			SkillList = {
				{
					Id = 100653,
					Value = 36,
				},
			},
		},
		{
			Level = 9,
			Info = 920338,
			Ability = {
				{
					Value = 200001,
					Num = 513,
				},
				{
					Value = 200007,
					Num = 81,
				},
			},
			SkillList = {
				{
					Id = 100653,
					Value = 36,
				},
			},
		},
		{
			Level = 10,
			Info = 920338,
			Ability = {
				{
					Value = 200001,
					Num = 570,
				},
				{
					Value = 200007,
					Num = 90,
				},
			},
			SkillList = {
				{
					Id = 100653,
					Value = 36,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id411] =
{
	Character = 220405,
	Rarity = 3,
	UpgradeId = 930010,
	LevelList = {
		{
			Level = 1,
			Info = 920339,
			Ability = {
				{
					Value = 200002,
					Num = 42,
				},
				{
					Value = 200006,
					Num = 6,
				},
			},
		},
		{
			Level = 2,
			Info = 920339,
			Ability = {
				{
					Value = 200002,
					Num = 84,
				},
				{
					Value = 200006,
					Num = 12,
				},
			},
		},
		{
			Level = 3,
			Info = 920339,
			Ability = {
				{
					Value = 200002,
					Num = 126,
				},
				{
					Value = 200006,
					Num = 18,
				},
			},
		},
		{
			Level = 4,
			Info = 920339,
			Ability = {
				{
					Value = 200002,
					Num = 168,
				},
				{
					Value = 200006,
					Num = 24,
				},
			},
		},
		{
			Level = 5,
			Info = 920339,
			Ability = {
				{
					Value = 200002,
					Num = 210,
				},
				{
					Value = 200006,
					Num = 30,
				},
			},
		},
		{
			Level = 6,
			Info = 920339,
			Ability = {
				{
					Value = 200002,
					Num = 252,
				},
				{
					Value = 200006,
					Num = 36,
				},
			},
		},
		{
			Level = 7,
			Info = 920339,
			Ability = {
				{
					Value = 200002,
					Num = 294,
				},
				{
					Value = 200006,
					Num = 42,
				},
			},
		},
		{
			Level = 8,
			Info = 920339,
			Ability = {
				{
					Value = 200002,
					Num = 336,
				},
				{
					Value = 200006,
					Num = 48,
				},
			},
			SkillList = {
				{
					Id = 101761,
					Value = 75,
				},
			},
		},
		{
			Level = 9,
			Info = 920339,
			Ability = {
				{
					Value = 200002,
					Num = 378,
				},
				{
					Value = 200006,
					Num = 54,
				},
			},
			SkillList = {
				{
					Id = 101761,
					Value = 75,
				},
			},
		},
		{
			Level = 10,
			Info = 920339,
			Ability = {
				{
					Value = 200002,
					Num = 420,
				},
				{
					Value = 200006,
					Num = 60,
				},
			},
			SkillList = {
				{
					Id = 101761,
					Value = 75,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id412] =
{
	Character = 220405,
	Rarity = 3,
	NeedChallenge = 145162,
	UpgradeId = 930031,
	LevelList = {
		{
			Level = 1,
			Info = 920340,
			Ability = {
				{
					Value = 200001,
					Num = 114,
				},
			},
		},
		{
			Level = 2,
			Info = 920340,
			Ability = {
				{
					Value = 200001,
					Num = 190,
				},
			},
		},
		{
			Level = 3,
			Info = 920340,
			Ability = {
				{
					Value = 200001,
					Num = 266,
				},
			},
		},
		{
			Level = 4,
			Info = 920340,
			Ability = {
				{
					Value = 200001,
					Num = 342,
				},
			},
		},
		{
			Level = 5,
			Info = 920340,
			Ability = {
				{
					Value = 200001,
					Num = 418,
				},
				{
					Value = 200003,
					Num = 25,
				},
			},
		},
		{
			Level = 6,
			Info = 920340,
			Ability = {
				{
					Value = 200001,
					Num = 494,
				},
				{
					Value = 200003,
					Num = 30,
				},
			},
		},
		{
			Level = 7,
			Info = 920340,
			Ability = {
				{
					Value = 200001,
					Num = 570,
				},
				{
					Value = 200003,
					Num = 35,
				},
			},
		},
		{
			Level = 8,
			Info = 920340,
			Ability = {
				{
					Value = 200001,
					Num = 646,
				},
				{
					Value = 200003,
					Num = 40,
				},
			},
			SkillList = {
				{
					Id = 101744,
					Value = 7,
				},
			},
		},
		{
			Level = 9,
			Info = 920340,
			Ability = {
				{
					Value = 200001,
					Num = 722,
				},
				{
					Value = 200003,
					Num = 45,
				},
			},
			SkillList = {
				{
					Id = 101744,
					Value = 7,
				},
			},
		},
		{
			Level = 10,
			Info = 920340,
			Ability = {
				{
					Value = 200001,
					Num = 798,
				},
				{
					Value = 200003,
					Num = 50,
				},
			},
			SkillList = {
				{
					Id = 101744,
					Value = 7,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id413] =
{
	Character = 220416,
	Rarity = 3,
	UpgradeId = 930029,
	LevelList = {
		{
			Level = 1,
			Info = 920371,
			Ability = {
				{
					Value = 200001,
					Num = 57,
				},
				{
					Value = 200007,
					Num = 9,
				},
			},
		},
		{
			Level = 2,
			Info = 920371,
			Ability = {
				{
					Value = 200001,
					Num = 114,
				},
				{
					Value = 200007,
					Num = 18,
				},
			},
		},
		{
			Level = 3,
			Info = 920371,
			Ability = {
				{
					Value = 200001,
					Num = 171,
				},
				{
					Value = 200007,
					Num = 27,
				},
			},
		},
		{
			Level = 4,
			Info = 920371,
			Ability = {
				{
					Value = 200001,
					Num = 228,
				},
				{
					Value = 200007,
					Num = 36,
				},
			},
		},
		{
			Level = 5,
			Info = 920371,
			Ability = {
				{
					Value = 200001,
					Num = 285,
				},
				{
					Value = 200007,
					Num = 45,
				},
			},
			SkillList = {
				{
					Id = 100651,
					Value = 5,
				},
			},
		},
		{
			Level = 6,
			Info = 920371,
			Ability = {
				{
					Value = 200001,
					Num = 342,
				},
				{
					Value = 200007,
					Num = 54,
				},
			},
			SkillList = {
				{
					Id = 100651,
					Value = 5,
				},
			},
		},
		{
			Level = 7,
			Info = 920371,
			Ability = {
				{
					Value = 200001,
					Num = 399,
				},
				{
					Value = 200007,
					Num = 63,
				},
			},
			SkillList = {
				{
					Id = 100651,
					Value = 5,
				},
			},
		},
		{
			Level = 8,
			Info = 920371,
			Ability = {
				{
					Value = 200001,
					Num = 456,
				},
				{
					Value = 200007,
					Num = 72,
				},
			},
			SkillList = {
				{
					Id = 100651,
					Value = 5,
				},
			},
		},
		{
			Level = 9,
			Info = 920371,
			Ability = {
				{
					Value = 200001,
					Num = 513,
				},
				{
					Value = 200007,
					Num = 81,
				},
			},
			SkillList = {
				{
					Id = 100651,
					Value = 5,
				},
			},
		},
		{
			Level = 10,
			Info = 920371,
			Ability = {
				{
					Value = 200001,
					Num = 570,
				},
				{
					Value = 200007,
					Num = 90,
				},
			},
			SkillList = {
				{
					Id = 100651,
					Value = 5,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id414] =
{
	Character = 220416,
	Rarity = 3,
	UpgradeId = 930030,
	LevelList = {
		{
			Level = 1,
			Info = 920372,
			Ability = {
				{
					Value = 200001,
					Num = 57,
				},
				{
					Value = 200008,
					Num = 6,
				},
			},
		},
		{
			Level = 2,
			Info = 920372,
			Ability = {
				{
					Value = 200001,
					Num = 114,
				},
				{
					Value = 200008,
					Num = 12,
				},
			},
		},
		{
			Level = 3,
			Info = 920372,
			Ability = {
				{
					Value = 200001,
					Num = 171,
				},
				{
					Value = 200008,
					Num = 18,
				},
			},
		},
		{
			Level = 4,
			Info = 920372,
			Ability = {
				{
					Value = 200001,
					Num = 228,
				},
				{
					Value = 200008,
					Num = 24,
				},
			},
		},
		{
			Level = 5,
			Info = 920372,
			Ability = {
				{
					Value = 200001,
					Num = 285,
				},
				{
					Value = 200008,
					Num = 30,
				},
			},
		},
		{
			Level = 6,
			Info = 920372,
			Ability = {
				{
					Value = 200001,
					Num = 342,
				},
				{
					Value = 200008,
					Num = 36,
				},
			},
		},
		{
			Level = 7,
			Info = 920372,
			Ability = {
				{
					Value = 200001,
					Num = 399,
				},
				{
					Value = 200008,
					Num = 42,
				},
			},
		},
		{
			Level = 8,
			Info = 920372,
			Ability = {
				{
					Value = 200001,
					Num = 456,
				},
				{
					Value = 200008,
					Num = 48,
				},
			},
			SkillList = {
				{
					Id = 101901,
					Value = 12,
				},
			},
		},
		{
			Level = 9,
			Info = 920372,
			Ability = {
				{
					Value = 200001,
					Num = 513,
				},
				{
					Value = 200008,
					Num = 54,
				},
			},
			SkillList = {
				{
					Id = 101901,
					Value = 12,
				},
			},
		},
		{
			Level = 10,
			Info = 920372,
			Ability = {
				{
					Value = 200001,
					Num = 570,
				},
				{
					Value = 200008,
					Num = 60,
				},
			},
			SkillList = {
				{
					Id = 101901,
					Value = 12,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id415] =
{
	Character = 220416,
	Rarity = 3,
	NeedChallenge = 145163,
	UpgradeId = 930031,
	LevelList = {
		{
			Level = 1,
			Info = 920373,
			Ability = {
				{
					Value = 200001,
					Num = 114,
				},
			},
		},
		{
			Level = 2,
			Info = 920373,
			Ability = {
				{
					Value = 200001,
					Num = 190,
				},
			},
		},
		{
			Level = 3,
			Info = 920373,
			Ability = {
				{
					Value = 200001,
					Num = 266,
				},
			},
		},
		{
			Level = 4,
			Info = 920373,
			Ability = {
				{
					Value = 200001,
					Num = 342,
				},
			},
		},
		{
			Level = 5,
			Info = 920373,
			Ability = {
				{
					Value = 200001,
					Num = 418,
				},
				{
					Value = 200003,
					Num = 25,
				},
			},
		},
		{
			Level = 6,
			Info = 920373,
			Ability = {
				{
					Value = 200001,
					Num = 494,
				},
				{
					Value = 200003,
					Num = 30,
				},
			},
		},
		{
			Level = 7,
			Info = 920373,
			Ability = {
				{
					Value = 200001,
					Num = 570,
				},
				{
					Value = 200003,
					Num = 35,
				},
			},
		},
		{
			Level = 8,
			Info = 920373,
			Ability = {
				{
					Value = 200001,
					Num = 646,
				},
				{
					Value = 200003,
					Num = 40,
				},
			},
			SkillList = {
				{
					Id = 101525,
					Value = -12,
				},
			},
		},
		{
			Level = 9,
			Info = 920373,
			Ability = {
				{
					Value = 200001,
					Num = 722,
				},
				{
					Value = 200003,
					Num = 45,
				},
			},
			SkillList = {
				{
					Id = 101525,
					Value = -12,
				},
			},
		},
		{
			Level = 10,
			Info = 920373,
			Ability = {
				{
					Value = 200001,
					Num = 798,
				},
				{
					Value = 200003,
					Num = 50,
				},
			},
			SkillList = {
				{
					Id = 101525,
					Value = -12,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id416] =
{
	Character = 220417,
	Rarity = 3,
	UpgradeId = 930009,
	LevelList = {
		{
			Level = 1,
			Info = 920374,
			Ability = {
				{
					Value = 200002,
					Num = 45,
				},
				{
					Value = 200007,
					Num = 15,
				},
			},
		},
		{
			Level = 2,
			Info = 920374,
			Ability = {
				{
					Value = 200002,
					Num = 90,
				},
				{
					Value = 200007,
					Num = 30,
				},
			},
		},
		{
			Level = 3,
			Info = 920374,
			Ability = {
				{
					Value = 200002,
					Num = 135,
				},
				{
					Value = 200007,
					Num = 45,
				},
			},
		},
		{
			Level = 4,
			Info = 920374,
			Ability = {
				{
					Value = 200002,
					Num = 180,
				},
				{
					Value = 200007,
					Num = 60,
				},
			},
		},
		{
			Level = 5,
			Info = 920374,
			Ability = {
				{
					Value = 200002,
					Num = 225,
				},
				{
					Value = 200007,
					Num = 75,
				},
			},
			SkillList = {
				{
					Id = 100652,
					Value = 5,
				},
			},
		},
		{
			Level = 6,
			Info = 920374,
			Ability = {
				{
					Value = 200002,
					Num = 270,
				},
				{
					Value = 200007,
					Num = 90,
				},
			},
			SkillList = {
				{
					Id = 100652,
					Value = 5,
				},
			},
		},
		{
			Level = 7,
			Info = 920374,
			Ability = {
				{
					Value = 200002,
					Num = 315,
				},
				{
					Value = 200007,
					Num = 105,
				},
			},
			SkillList = {
				{
					Id = 100652,
					Value = 5,
				},
			},
		},
		{
			Level = 8,
			Info = 920374,
			Ability = {
				{
					Value = 200002,
					Num = 360,
				},
				{
					Value = 200007,
					Num = 120,
				},
			},
			SkillList = {
				{
					Id = 100652,
					Value = 5,
				},
			},
		},
		{
			Level = 9,
			Info = 920374,
			Ability = {
				{
					Value = 200002,
					Num = 405,
				},
				{
					Value = 200007,
					Num = 135,
				},
			},
			SkillList = {
				{
					Id = 100652,
					Value = 5,
				},
			},
		},
		{
			Level = 10,
			Info = 920374,
			Ability = {
				{
					Value = 200002,
					Num = 450,
				},
				{
					Value = 200007,
					Num = 150,
				},
			},
			SkillList = {
				{
					Id = 100652,
					Value = 5,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id417] =
{
	Character = 220417,
	Rarity = 3,
	UpgradeId = 930010,
	LevelList = {
		{
			Level = 1,
			Info = 920375,
			Ability = {
				{
					Value = 200002,
					Num = 45,
				},
				{
					Value = 200007,
					Num = 15,
				},
			},
		},
		{
			Level = 2,
			Info = 920375,
			Ability = {
				{
					Value = 200002,
					Num = 90,
				},
				{
					Value = 200007,
					Num = 30,
				},
			},
		},
		{
			Level = 3,
			Info = 920375,
			Ability = {
				{
					Value = 200002,
					Num = 135,
				},
				{
					Value = 200007,
					Num = 45,
				},
			},
		},
		{
			Level = 4,
			Info = 920375,
			Ability = {
				{
					Value = 200002,
					Num = 180,
				},
				{
					Value = 200007,
					Num = 60,
				},
			},
		},
		{
			Level = 5,
			Info = 920375,
			Ability = {
				{
					Value = 200002,
					Num = 225,
				},
				{
					Value = 200007,
					Num = 75,
				},
			},
		},
		{
			Level = 6,
			Info = 920375,
			Ability = {
				{
					Value = 200002,
					Num = 270,
				},
				{
					Value = 200007,
					Num = 90,
				},
			},
		},
		{
			Level = 7,
			Info = 920375,
			Ability = {
				{
					Value = 200002,
					Num = 315,
				},
				{
					Value = 200007,
					Num = 105,
				},
			},
		},
		{
			Level = 8,
			Info = 920375,
			Ability = {
				{
					Value = 200002,
					Num = 360,
				},
				{
					Value = 200007,
					Num = 120,
				},
			},
			SkillList = {
				{
					Id = 100553,
					Value = 25,
				},
			},
		},
		{
			Level = 9,
			Info = 920375,
			Ability = {
				{
					Value = 200002,
					Num = 405,
				},
				{
					Value = 200007,
					Num = 135,
				},
			},
			SkillList = {
				{
					Id = 100553,
					Value = 25,
				},
			},
		},
		{
			Level = 10,
			Info = 920375,
			Ability = {
				{
					Value = 200002,
					Num = 450,
				},
				{
					Value = 200007,
					Num = 150,
				},
			},
			SkillList = {
				{
					Id = 100553,
					Value = 25,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id418] =
{
	Character = 220417,
	Rarity = 3,
	NeedChallenge = 145164,
	UpgradeId = 930011,
	LevelList = {
		{
			Level = 1,
			Info = 920376,
			Ability = {
				{
					Value = 200002,
					Num = 90,
				},
			},
		},
		{
			Level = 2,
			Info = 920376,
			Ability = {
				{
					Value = 200002,
					Num = 150,
				},
			},
		},
		{
			Level = 3,
			Info = 920376,
			Ability = {
				{
					Value = 200002,
					Num = 210,
				},
			},
		},
		{
			Level = 4,
			Info = 920376,
			Ability = {
				{
					Value = 200002,
					Num = 270,
				},
			},
		},
		{
			Level = 5,
			Info = 920376,
			Ability = {
				{
					Value = 200002,
					Num = 330,
				},
				{
					Value = 200004,
					Num = 25,
				},
			},
		},
		{
			Level = 6,
			Info = 920376,
			Ability = {
				{
					Value = 200002,
					Num = 390,
				},
				{
					Value = 200004,
					Num = 30,
				},
			},
		},
		{
			Level = 7,
			Info = 920376,
			Ability = {
				{
					Value = 200002,
					Num = 450,
				},
				{
					Value = 200004,
					Num = 35,
				},
			},
		},
		{
			Level = 8,
			Info = 920376,
			Ability = {
				{
					Value = 200002,
					Num = 510,
				},
				{
					Value = 200004,
					Num = 40,
				},
			},
			SkillList = {
				{
					Id = 101731,
					Value = 720,
				},
			},
		},
		{
			Level = 9,
			Info = 920376,
			Ability = {
				{
					Value = 200002,
					Num = 570,
				},
				{
					Value = 200004,
					Num = 45,
				},
			},
			SkillList = {
				{
					Id = 101731,
					Value = 720,
				},
			},
		},
		{
			Level = 10,
			Info = 920376,
			Ability = {
				{
					Value = 200002,
					Num = 630,
				},
				{
					Value = 200004,
					Num = 50,
				},
			},
			SkillList = {
				{
					Id = 101731,
					Value = 720,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id419] =
{
	Character = 220402,
	Rarity = 3,
	UpgradeId = 930029,
	LevelList = {
		{
			Level = 1,
			Info = 920329,
			Ability = {
				{
					Value = 200001,
					Num = 54,
				},
				{
					Value = 200005,
					Num = 9,
				},
			},
		},
		{
			Level = 2,
			Info = 920329,
			Ability = {
				{
					Value = 200001,
					Num = 108,
				},
				{
					Value = 200005,
					Num = 18,
				},
			},
		},
		{
			Level = 3,
			Info = 920329,
			Ability = {
				{
					Value = 200001,
					Num = 162,
				},
				{
					Value = 200005,
					Num = 27,
				},
			},
		},
		{
			Level = 4,
			Info = 920329,
			Ability = {
				{
					Value = 200001,
					Num = 216,
				},
				{
					Value = 200005,
					Num = 36,
				},
			},
		},
		{
			Level = 5,
			Info = 920329,
			Ability = {
				{
					Value = 200001,
					Num = 270,
				},
				{
					Value = 200005,
					Num = 45,
				},
			},
		},
		{
			Level = 6,
			Info = 920329,
			Ability = {
				{
					Value = 200001,
					Num = 324,
				},
				{
					Value = 200005,
					Num = 54,
				},
			},
		},
		{
			Level = 7,
			Info = 920329,
			Ability = {
				{
					Value = 200001,
					Num = 378,
				},
				{
					Value = 200005,
					Num = 63,
				},
			},
		},
		{
			Level = 8,
			Info = 920329,
			Ability = {
				{
					Value = 200001,
					Num = 432,
				},
				{
					Value = 200005,
					Num = 72,
				},
			},
			SkillList = {
				{
					Id = 100565,
					Value = -5,
				},
			},
		},
		{
			Level = 9,
			Info = 920329,
			Ability = {
				{
					Value = 200001,
					Num = 486,
				},
				{
					Value = 200005,
					Num = 81,
				},
			},
			SkillList = {
				{
					Id = 100565,
					Value = -5,
				},
			},
		},
		{
			Level = 10,
			Info = 920329,
			Ability = {
				{
					Value = 200001,
					Num = 540,
				},
				{
					Value = 200005,
					Num = 90,
				},
			},
			SkillList = {
				{
					Id = 100565,
					Value = -5,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id420] =
{
	Character = 220402,
	Rarity = 3,
	UpgradeId = 930030,
	LevelList = {
		{
			Level = 1,
			Info = 920330,
			Ability = {
				{
					Value = 200001,
					Num = 54,
				},
				{
					Value = 200008,
					Num = 6,
				},
			},
		},
		{
			Level = 2,
			Info = 920330,
			Ability = {
				{
					Value = 200001,
					Num = 108,
				},
				{
					Value = 200008,
					Num = 12,
				},
			},
		},
		{
			Level = 3,
			Info = 920330,
			Ability = {
				{
					Value = 200001,
					Num = 162,
				},
				{
					Value = 200008,
					Num = 18,
				},
			},
		},
		{
			Level = 4,
			Info = 920330,
			Ability = {
				{
					Value = 200001,
					Num = 216,
				},
				{
					Value = 200008,
					Num = 24,
				},
			},
		},
		{
			Level = 5,
			Info = 920330,
			Ability = {
				{
					Value = 200001,
					Num = 270,
				},
				{
					Value = 200008,
					Num = 30,
				},
			},
		},
		{
			Level = 6,
			Info = 920330,
			Ability = {
				{
					Value = 200001,
					Num = 324,
				},
				{
					Value = 200008,
					Num = 36,
				},
			},
		},
		{
			Level = 7,
			Info = 920330,
			Ability = {
				{
					Value = 200001,
					Num = 378,
				},
				{
					Value = 200008,
					Num = 42,
				},
			},
		},
		{
			Level = 8,
			Info = 920330,
			Ability = {
				{
					Value = 200001,
					Num = 432,
				},
				{
					Value = 200008,
					Num = 48,
				},
			},
			SkillList = {
				{
					Id = 101701,
					Value = 216,
				},
			},
		},
		{
			Level = 9,
			Info = 920330,
			Ability = {
				{
					Value = 200001,
					Num = 486,
				},
				{
					Value = 200008,
					Num = 54,
				},
			},
			SkillList = {
				{
					Id = 101701,
					Value = 216,
				},
			},
		},
		{
			Level = 10,
			Info = 920330,
			Ability = {
				{
					Value = 200001,
					Num = 540,
				},
				{
					Value = 200008,
					Num = 60,
				},
			},
			SkillList = {
				{
					Id = 101701,
					Value = 216,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id421] =
{
	Character = 220402,
	Rarity = 3,
	NeedChallenge = 145165,
	UpgradeId = 930011,
	LevelList = {
		{
			Level = 1,
			Info = 920331,
			Ability = {
				{
					Value = 200002,
					Num = 84,
				},
			},
		},
		{
			Level = 2,
			Info = 920331,
			Ability = {
				{
					Value = 200002,
					Num = 140,
				},
			},
		},
		{
			Level = 3,
			Info = 920331,
			Ability = {
				{
					Value = 200002,
					Num = 196,
				},
			},
		},
		{
			Level = 4,
			Info = 920331,
			Ability = {
				{
					Value = 200002,
					Num = 252,
				},
			},
		},
		{
			Level = 5,
			Info = 920331,
			Ability = {
				{
					Value = 200002,
					Num = 308,
				},
				{
					Value = 200004,
					Num = 25,
				},
			},
		},
		{
			Level = 6,
			Info = 920331,
			Ability = {
				{
					Value = 200002,
					Num = 364,
				},
				{
					Value = 200004,
					Num = 30,
				},
			},
		},
		{
			Level = 7,
			Info = 920331,
			Ability = {
				{
					Value = 200002,
					Num = 420,
				},
				{
					Value = 200004,
					Num = 35,
				},
			},
		},
		{
			Level = 8,
			Info = 920331,
			Ability = {
				{
					Value = 200002,
					Num = 476,
				},
				{
					Value = 200004,
					Num = 40,
				},
			},
			SkillList = {
				{
					Id = 101503,
					Value = -22,
				},
			},
		},
		{
			Level = 9,
			Info = 920331,
			Ability = {
				{
					Value = 200002,
					Num = 532,
				},
				{
					Value = 200004,
					Num = 45,
				},
			},
			SkillList = {
				{
					Id = 101503,
					Value = -22,
				},
			},
		},
		{
			Level = 10,
			Info = 920331,
			Ability = {
				{
					Value = 200002,
					Num = 588,
				},
				{
					Value = 200004,
					Num = 50,
				},
			},
			SkillList = {
				{
					Id = 101503,
					Value = -22,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id422] =
{
	Character = 220418,
	Rarity = 3,
	UpgradeId = 930029,
	LevelList = {
		{
			Level = 1,
			Info = 920377,
			Ability = {
				{
					Value = 200001,
					Num = 57,
				},
				{
					Value = 200006,
					Num = 15,
				},
			},
		},
		{
			Level = 2,
			Info = 920377,
			Ability = {
				{
					Value = 200001,
					Num = 114,
				},
				{
					Value = 200006,
					Num = 30,
				},
			},
		},
		{
			Level = 3,
			Info = 920377,
			Ability = {
				{
					Value = 200001,
					Num = 171,
				},
				{
					Value = 200006,
					Num = 45,
				},
			},
		},
		{
			Level = 4,
			Info = 920377,
			Ability = {
				{
					Value = 200001,
					Num = 228,
				},
				{
					Value = 200006,
					Num = 60,
				},
			},
		},
		{
			Level = 5,
			Info = 920377,
			Ability = {
				{
					Value = 200001,
					Num = 285,
				},
				{
					Value = 200006,
					Num = 75,
				},
			},
			SkillList = {
				{
					Id = 100651,
					Value = 5,
				},
			},
		},
		{
			Level = 6,
			Info = 920377,
			Ability = {
				{
					Value = 200001,
					Num = 342,
				},
				{
					Value = 200006,
					Num = 90,
				},
			},
			SkillList = {
				{
					Id = 100651,
					Value = 5,
				},
			},
		},
		{
			Level = 7,
			Info = 920377,
			Ability = {
				{
					Value = 200001,
					Num = 399,
				},
				{
					Value = 200006,
					Num = 105,
				},
			},
			SkillList = {
				{
					Id = 100651,
					Value = 5,
				},
			},
		},
		{
			Level = 8,
			Info = 920377,
			Ability = {
				{
					Value = 200001,
					Num = 456,
				},
				{
					Value = 200006,
					Num = 120,
				},
			},
			SkillList = {
				{
					Id = 100651,
					Value = 5,
				},
			},
		},
		{
			Level = 9,
			Info = 920377,
			Ability = {
				{
					Value = 200001,
					Num = 513,
				},
				{
					Value = 200006,
					Num = 135,
				},
			},
			SkillList = {
				{
					Id = 100651,
					Value = 5,
				},
			},
		},
		{
			Level = 10,
			Info = 920377,
			Ability = {
				{
					Value = 200001,
					Num = 570,
				},
				{
					Value = 200006,
					Num = 150,
				},
			},
			SkillList = {
				{
					Id = 100651,
					Value = 5,
				},
			},
		},
	},
}
