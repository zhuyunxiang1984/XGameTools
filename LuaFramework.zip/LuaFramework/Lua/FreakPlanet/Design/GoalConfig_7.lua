
GoalConfig[GoalID.Id8001] =
{
	Id = 8001,
	Name = "道具店装修3",
	GoalType = GoalType.Main,
	ShowFirst = false,
	PreCondition = {
		PreArea = 130001,
		PreGoal = 
		{
			300035,
			300018,
		},
	},
	GoalTrigger = 
	{
		TriggerType.CollectItem,
	},
	GoalCondition = 
	{
		{
			Name = "拥有至少[62E7E7]3级[-][FDDE40]道具店[-]",
			Type = ItemType.WorkShop,
			CountType = GoalCountType.Current,
			Num = 1,
			Value = 160001,
			Level = 3,
		},
	},
	Reward = {
		{
			Value = 360003,
			Num = 1,
		},
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id8002] =
{
	Id = 8002,
	Name = "道具店装修4",
	GoalType = GoalType.Main,
	ShowFirst = false,
	PreCondition = {
		PreArea = 130001,
		PreGoal = 
		{
			300046,
			308001,
		},
	},
	GoalTrigger = 
	{
		TriggerType.CollectItem,
	},
	GoalCondition = 
	{
		{
			Name = "拥有至少[62E7E7]4级[-][FDDE40]道具店[-]",
			Type = ItemType.WorkShop,
			CountType = GoalCountType.Current,
			Num = 1,
			Value = 160001,
			Level = 4,
		},
	},
	Reward = {
		{
			Value = 360102,
			Num = 1,
		},
		{
			Value = 2,
			Num = 30,
		},
	},
}
GoalConfig[GoalID.Id8003] =
{
	Id = 8003,
	Name = "道具店装修5",
	GoalType = GoalType.Main,
	ShowFirst = false,
	PreCondition = {
		PreArea = 130001,
		PreGoal = 
		{
			300332,
			308002,
		},
	},
	GoalTrigger = 
	{
		TriggerType.CollectItem,
	},
	GoalCondition = 
	{
		{
			Name = "拥有至少[62E7E7]5级[-][FDDE40]道具店[-]",
			Type = ItemType.WorkShop,
			CountType = GoalCountType.Current,
			Num = 1,
			Value = 160001,
			Level = 5,
		},
	},
	Reward = {
		{
			Value = 360004,
			Num = 1,
		},
		{
			Value = 2,
			Num = 30,
		},
	},
}
GoalConfig[GoalID.Id8004] =
{
	Id = 8004,
	Name = "道具店装修6",
	GoalType = GoalType.Main,
	ShowFirst = false,
	PreCondition = {
		PreArea = 130001,
		PreGoal = 
		{
			300333,
			308003,
		},
	},
	GoalTrigger = 
	{
		TriggerType.CollectItem,
	},
	GoalCondition = 
	{
		{
			Name = "老板红着脸暗示我们继续投资升级…\n拥有至少[62E7E7]6级[-][FDDE40]道具店[-]",
			Type = ItemType.WorkShop,
			CountType = GoalCountType.Current,
			Num = 1,
			Value = 160001,
			Level = 6,
		},
	},
	Reward = {
		{
			Value = 360103,
			Num = 1,
		},
		{
			Value = 2,
			Num = 30,
		},
	},
}
GoalConfig[GoalID.Id8005] =
{
	Id = 8005,
	Name = "道具店装修7",
	GoalType = GoalType.Main,
	ShowFirst = false,
	PreCondition = {
		PreArea = 130001,
		PreGoal = 
		{
			300334,
			308004,
		},
	},
	GoalTrigger = 
	{
		TriggerType.CollectItem,
	},
	GoalCondition = 
	{
		{
			Name = "拥有至少[62E7E7]7级[-][FDDE40]道具店[-]",
			Type = ItemType.WorkShop,
			CountType = GoalCountType.Current,
			Num = 1,
			Value = 160001,
			Level = 7,
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 50,
		},
	},
}
GoalConfig[GoalID.Id8051] =
{
	Id = 8051,
	Name = "超市开张",
	GoalType = GoalType.Main,
	ShowFirst = false,
	PreCondition = {
		PreArea = 130001,
		PreGoal = 
		{
			300046,
		},
	},
	GoalTrigger = 
	{
		TriggerType.CollectItem,
	},
	GoalCondition = 
	{
		{
			Name = "要不要去不夜城再招募一些船员呢？\n拥有[FDDE40]角色[-]9个",
			Type = ItemType.Character,
			CountType = GoalCountType.Current,
			Num = 9,
			Value = -1,
		},
	},
	Reward = {
		{
			Value = 160002,
			Num = 1,
		},
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id8052] =
{
	Id = 8052,
	Name = "超市装修2",
	GoalType = GoalType.Main,
	ShowFirst = false,
	PreCondition = {
		PreArea = 130001,
		PreGoal = 
		{
			308051,
		},
	},
	GoalTrigger = 
	{
		TriggerType.CollectItem,
	},
	GoalCondition = 
	{
		{
			Name = "拥有至少[62E7E7]2级[-][FDDE40]超市[-]",
			Type = ItemType.WorkShop,
			CountType = GoalCountType.Current,
			Num = 1,
			Value = 160002,
			Level = 2,
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id8053] =
{
	Id = 8053,
	Name = "超市装修3",
	GoalType = GoalType.Main,
	ShowFirst = false,
	PreCondition = {
		PreArea = 130001,
		PreGoal = 
		{
			300055,
			308052,
		},
	},
	GoalTrigger = 
	{
		TriggerType.CollectItem,
	},
	GoalCondition = 
	{
		{
			Name = "拥有至少[62E7E7]3级[-][FDDE40]超市[-]",
			Type = ItemType.WorkShop,
			CountType = GoalCountType.Current,
			Num = 1,
			Value = 160002,
			Level = 3,
		},
	},
	Reward = {
		{
			Value = 360007,
			Num = 1,
		},
		{
			Value = 2,
			Num = 30,
		},
	},
}
GoalConfig[GoalID.Id8054] =
{
	Id = 8054,
	Name = "超市装修4",
	GoalType = GoalType.Main,
	ShowFirst = false,
	PreCondition = {
		PreArea = 130001,
		PreGoal = 
		{
			300413,
			308053,
		},
	},
	GoalTrigger = 
	{
		TriggerType.CollectItem,
	},
	GoalCondition = 
	{
		{
			Name = "拥有至少[62E7E7]4级[-][FDDE40]超市[-]",
			Type = ItemType.WorkShop,
			CountType = GoalCountType.Current,
			Num = 1,
			Value = 160002,
			Level = 4,
		},
	},
	Reward = {
		{
			Value = 360106,
			Num = 1,
		},
		{
			Value = 2,
			Num = 30,
		},
	},
}
GoalConfig[GoalID.Id8055] =
{
	Id = 8055,
	Name = "超市装修5",
	GoalType = GoalType.Main,
	ShowFirst = false,
	PreCondition = {
		PreArea = 130001,
		PreGoal = 
		{
			300741,
			308054,
		},
	},
	GoalTrigger = 
	{
		TriggerType.CollectItem,
	},
	GoalCondition = 
	{
		{
			Name = "拥有至少[62E7E7]5级[-][FDDE40]超市[-]",
			Type = ItemType.WorkShop,
			CountType = GoalCountType.Current,
			Num = 1,
			Value = 160002,
			Level = 5,
		},
	},
	Reward = {
		{
			Value = 360008,
			Num = 1,
		},
		{
			Value = 2,
			Num = 50,
		},
	},
}
GoalConfig[GoalID.Id8056] =
{
	Id = 8056,
	Name = "超市装修6",
	GoalType = GoalType.Main,
	ShowFirst = false,
	PreCondition = {
		PreArea = 130001,
		PreGoal = 
		{
			300742,
			308055,
		},
	},
	GoalTrigger = 
	{
		TriggerType.CollectItem,
	},
	GoalCondition = 
	{
		{
			Name = "拥有至少[62E7E7]6级[-][FDDE40]超市[-]",
			Type = ItemType.WorkShop,
			CountType = GoalCountType.Current,
			Num = 1,
			Value = 160002,
			Level = 6,
		},
	},
	Reward = {
		{
			Value = 360107,
			Num = 1,
		},
		{
			Value = 2,
			Num = 50,
		},
	},
}
GoalConfig[GoalID.Id8057] =
{
	Id = 8057,
	Name = "超市装修7",
	GoalType = GoalType.Main,
	ShowFirst = false,
	PreCondition = {
		PreArea = 130001,
		PreGoal = 
		{
			300743,
			308056,
		},
	},
	GoalTrigger = 
	{
		TriggerType.CollectItem,
	},
	GoalCondition = 
	{
		{
			Name = "拥有至少[62E7E7]7级[-][FDDE40]超市[-]",
			Type = ItemType.WorkShop,
			CountType = GoalCountType.Current,
			Num = 1,
			Value = 160002,
			Level = 7,
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 75,
		},
	},
}
GoalConfig[GoalID.Id8101] =
{
	Id = 8101,
	Name = "警察局新分局",
	GoalType = GoalType.Main,
	ShowFirst = false,
	PreCondition = {
		PreArea = 130001,
		PreGoal = 
		{
			300421,
		},
	},
	GoalTrigger = 
	{
		TriggerType.CollectItem,
	},
	GoalCondition = 
	{
		{
			Name = "署长说，警察局只面向大型冒险队招工…\n拥有[FDDE40]角色[-]24个",
			Type = ItemType.Character,
			CountType = GoalCountType.Current,
			Num = 24,
			Value = -1,
		},
	},
	Reward = {
		{
			Value = 160003,
			Num = 1,
		},
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id8102] =
{
	Id = 8102,
	Name = "警察局装修2",
	GoalType = GoalType.Main,
	ShowFirst = false,
	PreCondition = {
		PreArea = 130001,
		PreGoal = 
		{
			308101,
		},
	},
	GoalTrigger = 
	{
		TriggerType.CollectItem,
	},
	GoalCondition = 
	{
		{
			Name = "拥有至少[62E7E7]2级[-][FDDE40]警察局[-]",
			Type = ItemType.WorkShop,
			CountType = GoalCountType.Current,
			Num = 1,
			Value = 160003,
			Level = 2,
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 30,
		},
	},
}
GoalConfig[GoalID.Id8103] =
{
	Id = 8103,
	Name = "警察局装修3",
	GoalType = GoalType.Main,
	ShowFirst = false,
	PreCondition = {
		PreArea = 130001,
		PreGoal = 
		{
			300443,
			308102,
		},
	},
	GoalTrigger = 
	{
		TriggerType.CollectItem,
	},
	GoalCondition = 
	{
		{
			Name = "拥有至少[62E7E7]3级[-][FDDE40]警察局[-]",
			Type = ItemType.WorkShop,
			CountType = GoalCountType.Current,
			Num = 1,
			Value = 160003,
			Level = 3,
		},
	},
	Reward = {
		{
			Value = 360011,
			Num = 1,
		},
		{
			Value = 2,
			Num = 30,
		},
	},
}
GoalConfig[GoalID.Id8104] =
{
	Id = 8104,
	Name = "警察局装修4",
	GoalType = GoalType.Main,
	ShowFirst = false,
	PreCondition = {
		PreArea = 130001,
		PreGoal = 
		{
			300490,
			308103,
		},
	},
	GoalTrigger = 
	{
		TriggerType.CollectItem,
	},
	GoalCondition = 
	{
		{
			Name = "拥有至少[62E7E7]4级[-][FDDE40]警察局[-]",
			Type = ItemType.WorkShop,
			CountType = GoalCountType.Current,
			Num = 1,
			Value = 160003,
			Level = 4,
		},
	},
	Reward = {
		{
			Value = 360110,
			Num = 1,
		},
		{
			Value = 2,
			Num = 50,
		},
	},
}
GoalConfig[GoalID.Id8105] =
{
	Id = 8105,
	Name = "警察局装修5",
	GoalType = GoalType.Main,
	ShowFirst = false,
	PreCondition = {
		PreArea = 130001,
		PreGoal = 
		{
			300807,
			308104,
		},
	},
	GoalTrigger = 
	{
		TriggerType.CollectItem,
	},
	GoalCondition = 
	{
		{
			Name = "拥有至少[62E7E7]5级[-][FDDE40]警察局[-]",
			Type = ItemType.WorkShop,
			CountType = GoalCountType.Current,
			Num = 1,
			Value = 160003,
			Level = 5,
		},
	},
	Reward = {
		{
			Value = 360012,
			Num = 1,
		},
		{
			Value = 2,
			Num = 50,
		},
	},
}
GoalConfig[GoalID.Id8106] =
{
	Id = 8106,
	Name = "警察局装修6",
	GoalType = GoalType.Main,
	ShowFirst = false,
	PreCondition = {
		PreArea = 130001,
		PreGoal = 
		{
			300832,
			308105,
		},
	},
	GoalTrigger = 
	{
		TriggerType.CollectItem,
	},
	GoalCondition = 
	{
		{
			Name = "拥有至少[62E7E7]6级[-][FDDE40]警察局[-]",
			Type = ItemType.WorkShop,
			CountType = GoalCountType.Current,
			Num = 1,
			Value = 160003,
			Level = 6,
		},
	},
	Reward = {
		{
			Value = 360111,
			Num = 1,
		},
		{
			Value = 2,
			Num = 75,
		},
	},
}
GoalConfig[GoalID.Id8107] =
{
	Id = 8107,
	Name = "警察局装修7",
	GoalType = GoalType.Main,
	ShowFirst = false,
	PreCondition = {
		PreArea = 130001,
		PreGoal = 
		{
			301144,
			308106,
		},
	},
	GoalTrigger = 
	{
		TriggerType.CollectItem,
	},
	GoalCondition = 
	{
		{
			Name = "拥有至少[62E7E7]7级[-][FDDE40]警察局[-]",
			Type = ItemType.WorkShop,
			CountType = GoalCountType.Current,
			Num = 1,
			Value = 160003,
			Level = 7,
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 100,
		},
	},
}
GoalConfig[GoalID.Id8151] =
{
	Id = 8151,
	Name = "事务所开张",
	GoalType = GoalType.Main,
	ShowFirst = false,
	PreCondition = {
		PreArea = 130001,
		PreGoal = 
		{
			300814,
		},
	},
	GoalTrigger = 
	{
		TriggerType.CollectItem,
	},
	GoalCondition = 
	{
		{
			Name = "所长表示，人数能确保三班倒工作就行…\n拥有[FDDE40]角色[-]32个",
			Type = ItemType.Character,
			CountType = GoalCountType.Current,
			Num = 32,
			Value = -1,
		},
	},
	Reward = {
		{
			Value = 160004,
			Num = 1,
		},
		{
			Value = 2,
			Num = 30,
		},
	},
}
GoalConfig[GoalID.Id8152] =
{
	Id = 8152,
	Name = "事务所装修2",
	GoalType = GoalType.Main,
	ShowFirst = false,
	PreCondition = {
		PreArea = 130001,
		PreGoal = 
		{
			308151,
		},
	},
	GoalTrigger = 
	{
		TriggerType.CollectItem,
	},
	GoalCondition = 
	{
		{
			Name = "拥有至少[62E7E7]2级[-][FDDE40]事务所[-]",
			Type = ItemType.WorkShop,
			CountType = GoalCountType.Current,
			Num = 1,
			Value = 160004,
			Level = 2,
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 30,
		},
	},
}
GoalConfig[GoalID.Id8153] =
{
	Id = 8153,
	Name = "事务所装修3",
	GoalType = GoalType.Main,
	ShowFirst = false,
	PreCondition = {
		PreArea = 130001,
		PreGoal = 
		{
			300819,
			308152,
		},
	},
	GoalTrigger = 
	{
		TriggerType.CollectItem,
	},
	GoalCondition = 
	{
		{
			Name = "拥有至少[62E7E7]3级[-][FDDE40]事务所[-]",
			Type = ItemType.WorkShop,
			CountType = GoalCountType.Current,
			Num = 1,
			Value = 160004,
			Level = 3,
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 50,
		},
	},
}
GoalConfig[GoalID.Id8154] =
{
	Id = 8154,
	Name = "事务所装修4",
	GoalType = GoalType.Main,
	ShowFirst = false,
	PreCondition = {
		PreArea = 130001,
		PreGoal = 
		{
			300840,
			308153,
		},
	},
	GoalTrigger = 
	{
		TriggerType.CollectItem,
	},
	GoalCondition = 
	{
		{
			Name = "拥有至少[62E7E7]4级[-][FDDE40]事务所[-]",
			Type = ItemType.WorkShop,
			CountType = GoalCountType.Current,
			Num = 1,
			Value = 160004,
			Level = 4,
		},
	},
	Reward = {
		{
			Value = 360118,
			Num = 1,
		},
		{
			Value = 2,
			Num = 50,
		},
	},
}
GoalConfig[GoalID.Id8155] =
{
	Id = 8155,
	Name = "事务所装修5",
	GoalType = GoalType.Main,
	ShowFirst = false,
	PreCondition = {
		PreArea = 130001,
		PreGoal = 
		{
			300852,
			308154,
		},
	},
	GoalTrigger = 
	{
		TriggerType.CollectItem,
	},
	GoalCondition = 
	{
		{
			Name = "拥有至少[62E7E7]5级[-][FDDE40]事务所[-]",
			Type = ItemType.WorkShop,
			CountType = GoalCountType.Current,
			Num = 1,
			Value = 160004,
			Level = 5,
		},
	},
	Reward = {
		{
			Value = 360114,
			Num = 1,
		},
		{
			Value = 2,
			Num = 75,
		},
	},
}
GoalConfig[GoalID.Id8156] =
{
	Id = 8156,
	Name = "事务所装修6",
	GoalType = GoalType.Main,
	ShowFirst = false,
	PreCondition = {
		PreArea = 130001,
		PreGoal = 
		{
			301146,
			308155,
		},
	},
	GoalTrigger = 
	{
		TriggerType.CollectItem,
	},
	GoalCondition = 
	{
		{
			Name = "拥有至少[62E7E7]6级[-][FDDE40]事务所[-]",
			Type = ItemType.WorkShop,
			CountType = GoalCountType.Current,
			Num = 1,
			Value = 160004,
			Level = 6,
		},
	},
	Reward = {
		{
			Value = 360119,
			Num = 1,
		},
		{
			Value = 2,
			Num = 100,
		},
	},
}
GoalConfig[GoalID.Id8157] =
{
	Id = 8157,
	Name = "事务所装修7",
	GoalType = GoalType.Main,
	ShowFirst = false,
	PreCondition = {
		PreArea = 130001,
		PreGoal = 
		{
			301556,
			308156,
		},
	},
	GoalTrigger = 
	{
		TriggerType.CollectItem,
	},
	GoalCondition = 
	{
		{
			Name = "拥有至少[62E7E7]7级[-][FDDE40]事务所[-]",
			Type = ItemType.WorkShop,
			CountType = GoalCountType.Current,
			Num = 1,
			Value = 160004,
			Level = 7,
		},
	},
	Reward = {
		{
			Value = 360115,
			Num = 1,
		},
		{
			Value = 2,
			Num = 120,
		},
	},
}
