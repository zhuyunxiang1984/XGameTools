
EquipmentConfig[EquipmentID.Id271] =
{
	Character = 220318,
	Rarity = 3,
	UpgradeId = 930010,
	LevelList = {
		{
			Level = 1,
			Info = 920301,
			Ability = {
				{
					Value = 200002,
					Num = 42,
				},
				{
					Value = 200008,
					Num = 6,
				},
			},
		},
		{
			Level = 2,
			Info = 920301,
			Ability = {
				{
					Value = 200002,
					Num = 84,
				},
				{
					Value = 200008,
					Num = 12,
				},
			},
		},
		{
			Level = 3,
			Info = 920301,
			Ability = {
				{
					Value = 200002,
					Num = 126,
				},
				{
					Value = 200008,
					Num = 18,
				},
			},
		},
		{
			Level = 4,
			Info = 920301,
			Ability = {
				{
					Value = 200002,
					Num = 168,
				},
				{
					Value = 200008,
					Num = 24,
				},
			},
		},
		{
			Level = 5,
			Info = 920301,
			Ability = {
				{
					Value = 200002,
					Num = 210,
				},
				{
					Value = 200008,
					Num = 30,
				},
			},
			SkillList = {
				{
					Id = 101759,
					Value = 32,
				},
			},
		},
		{
			Level = 6,
			Info = 920301,
			Ability = {
				{
					Value = 200002,
					Num = 252,
				},
				{
					Value = 200008,
					Num = 36,
				},
			},
			SkillList = {
				{
					Id = 101759,
					Value = 32,
				},
			},
		},
		{
			Level = 7,
			Info = 920301,
			Ability = {
				{
					Value = 200002,
					Num = 294,
				},
				{
					Value = 200008,
					Num = 42,
				},
			},
			SkillList = {
				{
					Id = 101759,
					Value = 32,
				},
			},
		},
		{
			Level = 8,
			Info = 920301,
			Ability = {
				{
					Value = 200002,
					Num = 336,
				},
				{
					Value = 200008,
					Num = 48,
				},
			},
			SkillList = {
				{
					Id = 101759,
					Value = 32,
				},
			},
		},
		{
			Level = 9,
			Info = 920301,
			Ability = {
				{
					Value = 200002,
					Num = 378,
				},
				{
					Value = 200008,
					Num = 54,
				},
			},
			SkillList = {
				{
					Id = 101759,
					Value = 32,
				},
			},
		},
		{
			Level = 10,
			Info = 920301,
			Ability = {
				{
					Value = 200002,
					Num = 420,
				},
				{
					Value = 200008,
					Num = 60,
				},
			},
			SkillList = {
				{
					Id = 101759,
					Value = 32,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id272] =
{
	Character = 220318,
	Rarity = 3,
	NeedChallenge = 145110,
	UpgradeId = 930031,
	LevelList = {
		{
			Level = 1,
			Info = 920302,
			Ability = {
				{
					Value = 200001,
					Num = 108,
				},
			},
		},
		{
			Level = 2,
			Info = 920302,
			Ability = {
				{
					Value = 200001,
					Num = 180,
				},
			},
		},
		{
			Level = 3,
			Info = 920302,
			Ability = {
				{
					Value = 200001,
					Num = 252,
				},
			},
		},
		{
			Level = 4,
			Info = 920302,
			Ability = {
				{
					Value = 200001,
					Num = 324,
				},
			},
		},
		{
			Level = 5,
			Info = 920302,
			Ability = {
				{
					Value = 200001,
					Num = 396,
				},
				{
					Value = 200003,
					Num = 25,
				},
			},
		},
		{
			Level = 6,
			Info = 920302,
			Ability = {
				{
					Value = 200001,
					Num = 468,
				},
				{
					Value = 200003,
					Num = 30,
				},
			},
		},
		{
			Level = 7,
			Info = 920302,
			Ability = {
				{
					Value = 200001,
					Num = 540,
				},
				{
					Value = 200003,
					Num = 35,
				},
			},
		},
		{
			Level = 8,
			Info = 920302,
			Ability = {
				{
					Value = 200001,
					Num = 612,
				},
				{
					Value = 200003,
					Num = 40,
				},
			},
			SkillList = {
				{
					Id = 100106,
					Value = -9,
				},
			},
		},
		{
			Level = 9,
			Info = 920302,
			Ability = {
				{
					Value = 200001,
					Num = 684,
				},
				{
					Value = 200003,
					Num = 45,
				},
			},
			SkillList = {
				{
					Id = 100106,
					Value = -9,
				},
			},
		},
		{
			Level = 10,
			Info = 920302,
			Ability = {
				{
					Value = 200001,
					Num = 756,
				},
				{
					Value = 200003,
					Num = 50,
				},
			},
			SkillList = {
				{
					Id = 100106,
					Value = -9,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id273] =
{
	Character = 220319,
	Rarity = 3,
	UpgradeId = 930009,
	LevelList = {
		{
			Level = 1,
			Info = 920303,
			Ability = {
				{
					Value = 200002,
					Num = 51,
				},
				{
					Value = 200008,
					Num = 9,
				},
			},
		},
		{
			Level = 2,
			Info = 920303,
			Ability = {
				{
					Value = 200002,
					Num = 102,
				},
				{
					Value = 200008,
					Num = 18,
				},
			},
		},
		{
			Level = 3,
			Info = 920303,
			Ability = {
				{
					Value = 200002,
					Num = 153,
				},
				{
					Value = 200008,
					Num = 27,
				},
			},
		},
		{
			Level = 4,
			Info = 920303,
			Ability = {
				{
					Value = 200002,
					Num = 204,
				},
				{
					Value = 200008,
					Num = 36,
				},
			},
		},
		{
			Level = 5,
			Info = 920303,
			Ability = {
				{
					Value = 200002,
					Num = 255,
				},
				{
					Value = 200008,
					Num = 45,
				},
			},
			SkillList = {
				{
					Id = 100652,
					Value = 5,
				},
			},
		},
		{
			Level = 6,
			Info = 920303,
			Ability = {
				{
					Value = 200002,
					Num = 306,
				},
				{
					Value = 200008,
					Num = 54,
				},
			},
			SkillList = {
				{
					Id = 100652,
					Value = 5,
				},
			},
		},
		{
			Level = 7,
			Info = 920303,
			Ability = {
				{
					Value = 200002,
					Num = 357,
				},
				{
					Value = 200008,
					Num = 63,
				},
			},
			SkillList = {
				{
					Id = 100652,
					Value = 5,
				},
			},
		},
		{
			Level = 8,
			Info = 920303,
			Ability = {
				{
					Value = 200002,
					Num = 408,
				},
				{
					Value = 200008,
					Num = 72,
				},
			},
			SkillList = {
				{
					Id = 100652,
					Value = 5,
				},
			},
		},
		{
			Level = 9,
			Info = 920303,
			Ability = {
				{
					Value = 200002,
					Num = 459,
				},
				{
					Value = 200008,
					Num = 81,
				},
			},
			SkillList = {
				{
					Id = 100652,
					Value = 5,
				},
			},
		},
		{
			Level = 10,
			Info = 920303,
			Ability = {
				{
					Value = 200002,
					Num = 510,
				},
				{
					Value = 200008,
					Num = 90,
				},
			},
			SkillList = {
				{
					Id = 100652,
					Value = 5,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id274] =
{
	Character = 220319,
	Rarity = 3,
	UpgradeId = 930010,
	LevelList = {
		{
			Level = 1,
			Info = 920304,
			Ability = {
				{
					Value = 200002,
					Num = 51,
				},
				{
					Value = 200005,
					Num = 6,
				},
			},
		},
		{
			Level = 2,
			Info = 920304,
			Ability = {
				{
					Value = 200002,
					Num = 102,
				},
				{
					Value = 200005,
					Num = 12,
				},
			},
		},
		{
			Level = 3,
			Info = 920304,
			Ability = {
				{
					Value = 200002,
					Num = 153,
				},
				{
					Value = 200005,
					Num = 18,
				},
			},
		},
		{
			Level = 4,
			Info = 920304,
			Ability = {
				{
					Value = 200002,
					Num = 204,
				},
				{
					Value = 200005,
					Num = 24,
				},
			},
		},
		{
			Level = 5,
			Info = 920304,
			Ability = {
				{
					Value = 200002,
					Num = 255,
				},
				{
					Value = 200005,
					Num = 30,
				},
			},
		},
		{
			Level = 6,
			Info = 920304,
			Ability = {
				{
					Value = 200002,
					Num = 306,
				},
				{
					Value = 200005,
					Num = 36,
				},
			},
		},
		{
			Level = 7,
			Info = 920304,
			Ability = {
				{
					Value = 200002,
					Num = 357,
				},
				{
					Value = 200005,
					Num = 42,
				},
			},
		},
		{
			Level = 8,
			Info = 920304,
			Ability = {
				{
					Value = 200002,
					Num = 408,
				},
				{
					Value = 200005,
					Num = 48,
				},
			},
			SkillList = {
				{
					Id = 100744,
					Value = 2,
				},
			},
		},
		{
			Level = 9,
			Info = 920304,
			Ability = {
				{
					Value = 200002,
					Num = 459,
				},
				{
					Value = 200005,
					Num = 54,
				},
			},
			SkillList = {
				{
					Id = 100744,
					Value = 2,
				},
			},
		},
		{
			Level = 10,
			Info = 920304,
			Ability = {
				{
					Value = 200002,
					Num = 510,
				},
				{
					Value = 200005,
					Num = 60,
				},
			},
			SkillList = {
				{
					Id = 100744,
					Value = 2,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id275] =
{
	Character = 220319,
	Rarity = 3,
	NeedChallenge = 145111,
	UpgradeId = 930011,
	LevelList = {
		{
			Level = 1,
			Info = 920305,
			Ability = {
				{
					Value = 200002,
					Num = 102,
				},
			},
		},
		{
			Level = 2,
			Info = 920305,
			Ability = {
				{
					Value = 200002,
					Num = 170,
				},
			},
		},
		{
			Level = 3,
			Info = 920305,
			Ability = {
				{
					Value = 200002,
					Num = 238,
				},
			},
		},
		{
			Level = 4,
			Info = 920305,
			Ability = {
				{
					Value = 200002,
					Num = 306,
				},
			},
		},
		{
			Level = 5,
			Info = 920305,
			Ability = {
				{
					Value = 200002,
					Num = 374,
				},
			},
		},
		{
			Level = 6,
			Info = 920305,
			Ability = {
				{
					Value = 200002,
					Num = 442,
				},
			},
		},
		{
			Level = 7,
			Info = 920305,
			Ability = {
				{
					Value = 200002,
					Num = 510,
				},
			},
		},
		{
			Level = 8,
			Info = 920305,
			Ability = {
				{
					Value = 200002,
					Num = 578,
				},
			},
			SkillList = {
				{
					Id = 100652,
					Value = 25,
				},
				{
					Id = 100602,
					Value = -50,
				},
			},
		},
		{
			Level = 9,
			Info = 920305,
			Ability = {
				{
					Value = 200002,
					Num = 646,
				},
			},
			SkillList = {
				{
					Id = 100652,
					Value = 25,
				},
				{
					Id = 100602,
					Value = -50,
				},
			},
		},
		{
			Level = 10,
			Info = 920305,
			Ability = {
				{
					Value = 200002,
					Num = 714,
				},
			},
			SkillList = {
				{
					Id = 100652,
					Value = 25,
				},
				{
					Id = 100602,
					Value = -50,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id276] =
{
	Character = 220320,
	Rarity = 3,
	UpgradeId = 930029,
	LevelList = {
		{
			Level = 1,
			Info = 920306,
			Ability = {
				{
					Value = 200001,
					Num = 54,
				},
				{
					Value = 200006,
					Num = 9,
				},
			},
		},
		{
			Level = 2,
			Info = 920306,
			Ability = {
				{
					Value = 200001,
					Num = 108,
				},
				{
					Value = 200006,
					Num = 18,
				},
			},
		},
		{
			Level = 3,
			Info = 920306,
			Ability = {
				{
					Value = 200001,
					Num = 162,
				},
				{
					Value = 200006,
					Num = 27,
				},
			},
		},
		{
			Level = 4,
			Info = 920306,
			Ability = {
				{
					Value = 200001,
					Num = 216,
				},
				{
					Value = 200006,
					Num = 36,
				},
			},
		},
		{
			Level = 5,
			Info = 920306,
			Ability = {
				{
					Value = 200001,
					Num = 270,
				},
				{
					Value = 200006,
					Num = 45,
				},
			},
		},
		{
			Level = 6,
			Info = 920306,
			Ability = {
				{
					Value = 200001,
					Num = 324,
				},
				{
					Value = 200006,
					Num = 54,
				},
			},
		},
		{
			Level = 7,
			Info = 920306,
			Ability = {
				{
					Value = 200001,
					Num = 378,
				},
				{
					Value = 200006,
					Num = 63,
				},
			},
		},
		{
			Level = 8,
			Info = 920306,
			Ability = {
				{
					Value = 200001,
					Num = 432,
				},
				{
					Value = 200006,
					Num = 72,
				},
			},
			SkillList = {
				{
					Id = 100561,
					Value = -5,
				},
			},
		},
		{
			Level = 9,
			Info = 920306,
			Ability = {
				{
					Value = 200001,
					Num = 486,
				},
				{
					Value = 200006,
					Num = 81,
				},
			},
			SkillList = {
				{
					Id = 100561,
					Value = -5,
				},
			},
		},
		{
			Level = 10,
			Info = 920306,
			Ability = {
				{
					Value = 200001,
					Num = 540,
				},
				{
					Value = 200006,
					Num = 90,
				},
			},
			SkillList = {
				{
					Id = 100561,
					Value = -5,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id277] =
{
	Character = 220320,
	Rarity = 3,
	UpgradeId = 930030,
	LevelList = {
		{
			Level = 1,
			Info = 920307,
			Ability = {
				{
					Value = 200001,
					Num = 54,
				},
				{
					Value = 200005,
					Num = 6,
				},
			},
		},
		{
			Level = 2,
			Info = 920307,
			Ability = {
				{
					Value = 200001,
					Num = 108,
				},
				{
					Value = 200005,
					Num = 12,
				},
			},
		},
		{
			Level = 3,
			Info = 920307,
			Ability = {
				{
					Value = 200001,
					Num = 162,
				},
				{
					Value = 200005,
					Num = 18,
				},
			},
		},
		{
			Level = 4,
			Info = 920307,
			Ability = {
				{
					Value = 200001,
					Num = 216,
				},
				{
					Value = 200005,
					Num = 24,
				},
			},
		},
		{
			Level = 5,
			Info = 920307,
			Ability = {
				{
					Value = 200001,
					Num = 270,
				},
				{
					Value = 200005,
					Num = 30,
				},
			},
		},
		{
			Level = 6,
			Info = 920307,
			Ability = {
				{
					Value = 200001,
					Num = 324,
				},
				{
					Value = 200005,
					Num = 36,
				},
			},
		},
		{
			Level = 7,
			Info = 920307,
			Ability = {
				{
					Value = 200001,
					Num = 378,
				},
				{
					Value = 200005,
					Num = 42,
				},
			},
		},
		{
			Level = 8,
			Info = 920307,
			Ability = {
				{
					Value = 200001,
					Num = 432,
				},
				{
					Value = 200005,
					Num = 48,
				},
			},
			SkillList = {
				{
					Id = 101742,
					Value = 15,
				},
			},
		},
		{
			Level = 9,
			Info = 920307,
			Ability = {
				{
					Value = 200001,
					Num = 486,
				},
				{
					Value = 200005,
					Num = 54,
				},
			},
			SkillList = {
				{
					Id = 101742,
					Value = 15,
				},
			},
		},
		{
			Level = 10,
			Info = 920307,
			Ability = {
				{
					Value = 200001,
					Num = 540,
				},
				{
					Value = 200005,
					Num = 60,
				},
			},
			SkillList = {
				{
					Id = 101742,
					Value = 15,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id278] =
{
	Character = 220320,
	Rarity = 3,
	NeedChallenge = 145112,
	UpgradeId = 930031,
	LevelList = {
		{
			Level = 1,
			Info = 920308,
			Ability = {
				{
					Value = 200001,
					Num = 108,
				},
			},
		},
		{
			Level = 2,
			Info = 920308,
			Ability = {
				{
					Value = 200001,
					Num = 180,
				},
			},
		},
		{
			Level = 3,
			Info = 920308,
			Ability = {
				{
					Value = 200001,
					Num = 252,
				},
			},
		},
		{
			Level = 4,
			Info = 920308,
			Ability = {
				{
					Value = 200001,
					Num = 324,
				},
			},
		},
		{
			Level = 5,
			Info = 920308,
			Ability = {
				{
					Value = 200001,
					Num = 396,
				},
				{
					Value = 200003,
					Num = 25,
				},
			},
		},
		{
			Level = 6,
			Info = 920308,
			Ability = {
				{
					Value = 200001,
					Num = 468,
				},
				{
					Value = 200003,
					Num = 30,
				},
			},
		},
		{
			Level = 7,
			Info = 920308,
			Ability = {
				{
					Value = 200001,
					Num = 540,
				},
				{
					Value = 200003,
					Num = 35,
				},
			},
		},
		{
			Level = 8,
			Info = 920308,
			Ability = {
				{
					Value = 200001,
					Num = 612,
				},
				{
					Value = 200003,
					Num = 40,
				},
			},
			SkillList = {
				{
					Id = 101743,
					Value = 7,
				},
			},
		},
		{
			Level = 9,
			Info = 920308,
			Ability = {
				{
					Value = 200001,
					Num = 684,
				},
				{
					Value = 200003,
					Num = 45,
				},
			},
			SkillList = {
				{
					Id = 101743,
					Value = 7,
				},
			},
		},
		{
			Level = 10,
			Info = 920308,
			Ability = {
				{
					Value = 200001,
					Num = 756,
				},
				{
					Value = 200003,
					Num = 50,
				},
			},
			SkillList = {
				{
					Id = 101743,
					Value = 7,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id279] =
{
	Character = 220321,
	Rarity = 4,
	UpgradeId = 930013,
	LevelList = {
		{
			Level = 1,
			Info = 920309,
			Ability = {
				{
					Value = 200002,
					Num = 60,
				},
				{
					Value = 200005,
					Num = 21,
				},
			},
		},
		{
			Level = 2,
			Info = 920309,
			Ability = {
				{
					Value = 200002,
					Num = 120,
				},
				{
					Value = 200005,
					Num = 42,
				},
			},
		},
		{
			Level = 3,
			Info = 920309,
			Ability = {
				{
					Value = 200002,
					Num = 180,
				},
				{
					Value = 200005,
					Num = 63,
				},
			},
		},
		{
			Level = 4,
			Info = 920309,
			Ability = {
				{
					Value = 200002,
					Num = 240,
				},
				{
					Value = 200005,
					Num = 84,
				},
			},
		},
		{
			Level = 5,
			Info = 920309,
			Ability = {
				{
					Value = 200002,
					Num = 300,
				},
				{
					Value = 200005,
					Num = 105,
				},
			},
		},
		{
			Level = 6,
			Info = 920309,
			Ability = {
				{
					Value = 200002,
					Num = 360,
				},
				{
					Value = 200005,
					Num = 126,
				},
			},
		},
		{
			Level = 7,
			Info = 920309,
			Ability = {
				{
					Value = 200002,
					Num = 420,
				},
				{
					Value = 200005,
					Num = 147,
				},
			},
		},
		{
			Level = 8,
			Info = 920309,
			Ability = {
				{
					Value = 200002,
					Num = 480,
				},
				{
					Value = 200005,
					Num = 168,
				},
			},
			SkillList = {
				{
					Id = 100554,
					Value = 25,
				},
			},
		},
		{
			Level = 9,
			Info = 920309,
			Ability = {
				{
					Value = 200002,
					Num = 540,
				},
				{
					Value = 200005,
					Num = 189,
				},
			},
			SkillList = {
				{
					Id = 100554,
					Value = 25,
				},
			},
		},
		{
			Level = 10,
			Info = 920309,
			Ability = {
				{
					Value = 200002,
					Num = 600,
				},
				{
					Value = 200005,
					Num = 210,
				},
			},
			SkillList = {
				{
					Id = 100554,
					Value = 25,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id280] =
{
	Character = 220321,
	Rarity = 4,
	UpgradeId = 930014,
	LevelList = {
		{
			Level = 1,
			Info = 920310,
			Ability = {
				{
					Value = 200002,
					Num = 60,
				},
				{
					Value = 200005,
					Num = 21,
				},
			},
		},
		{
			Level = 2,
			Info = 920310,
			Ability = {
				{
					Value = 200002,
					Num = 120,
				},
				{
					Value = 200005,
					Num = 42,
				},
			},
		},
		{
			Level = 3,
			Info = 920310,
			Ability = {
				{
					Value = 200002,
					Num = 180,
				},
				{
					Value = 200005,
					Num = 63,
				},
			},
		},
		{
			Level = 4,
			Info = 920310,
			Ability = {
				{
					Value = 200002,
					Num = 240,
				},
				{
					Value = 200005,
					Num = 84,
				},
			},
		},
		{
			Level = 5,
			Info = 920310,
			Ability = {
				{
					Value = 200002,
					Num = 300,
				},
				{
					Value = 200005,
					Num = 105,
				},
			},
		},
		{
			Level = 6,
			Info = 920310,
			Ability = {
				{
					Value = 200002,
					Num = 360,
				},
				{
					Value = 200005,
					Num = 126,
				},
			},
		},
		{
			Level = 7,
			Info = 920310,
			Ability = {
				{
					Value = 200002,
					Num = 420,
				},
				{
					Value = 200005,
					Num = 147,
				},
			},
		},
		{
			Level = 8,
			Info = 920310,
			Ability = {
				{
					Value = 200002,
					Num = 480,
				},
				{
					Value = 200005,
					Num = 168,
				},
			},
			SkillList = {
				{
					Id = 101744,
					Value = 7,
				},
			},
		},
		{
			Level = 9,
			Info = 920310,
			Ability = {
				{
					Value = 200002,
					Num = 540,
				},
				{
					Value = 200005,
					Num = 189,
				},
			},
			SkillList = {
				{
					Id = 101744,
					Value = 7,
				},
			},
		},
		{
			Level = 10,
			Info = 920310,
			Ability = {
				{
					Value = 200002,
					Num = 600,
				},
				{
					Value = 200005,
					Num = 210,
				},
			},
			SkillList = {
				{
					Id = 101744,
					Value = 7,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id281] =
{
	Character = 220321,
	Rarity = 4,
	NeedChallenge = 145113,
	UpgradeId = 930015,
	LevelList = {
		{
			Level = 1,
			Info = 920311,
			Ability = {
				{
					Value = 200002,
					Num = 120,
				},
			},
		},
		{
			Level = 2,
			Info = 920311,
			Ability = {
				{
					Value = 200002,
					Num = 200,
				},
			},
		},
		{
			Level = 3,
			Info = 920311,
			Ability = {
				{
					Value = 200002,
					Num = 280,
				},
			},
		},
		{
			Level = 4,
			Info = 920311,
			Ability = {
				{
					Value = 200002,
					Num = 360,
				},
			},
		},
		{
			Level = 5,
			Info = 920311,
			Ability = {
				{
					Value = 200002,
					Num = 440,
				},
				{
					Value = 200004,
					Num = 25,
				},
			},
		},
		{
			Level = 6,
			Info = 920311,
			Ability = {
				{
					Value = 200002,
					Num = 520,
				},
				{
					Value = 200004,
					Num = 30,
				},
			},
		},
		{
			Level = 7,
			Info = 920311,
			Ability = {
				{
					Value = 200002,
					Num = 600,
				},
				{
					Value = 200004,
					Num = 35,
				},
			},
		},
		{
			Level = 8,
			Info = 920311,
			Ability = {
				{
					Value = 200002,
					Num = 680,
				},
				{
					Value = 200004,
					Num = 40,
				},
			},
			SkillList = {
				{
					Id = 101733,
					Value = 90,
				},
			},
		},
		{
			Level = 9,
			Info = 920311,
			Ability = {
				{
					Value = 200002,
					Num = 760,
				},
				{
					Value = 200004,
					Num = 45,
				},
			},
			SkillList = {
				{
					Id = 101733,
					Value = 90,
				},
			},
		},
		{
			Level = 10,
			Info = 920311,
			Ability = {
				{
					Value = 200002,
					Num = 840,
				},
				{
					Value = 200004,
					Num = 50,
				},
			},
			SkillList = {
				{
					Id = 101733,
					Value = 90,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id282] =
{
	Character = 220322,
	Rarity = 4,
	UpgradeId = 930013,
	LevelList = {
		{
			Level = 1,
			Info = 920312,
			Ability = {
				{
					Value = 200002,
					Num = 57,
				},
				{
					Value = 200008,
					Num = 12,
				},
			},
		},
		{
			Level = 2,
			Info = 920312,
			Ability = {
				{
					Value = 200002,
					Num = 114,
				},
				{
					Value = 200008,
					Num = 24,
				},
			},
		},
		{
			Level = 3,
			Info = 920312,
			Ability = {
				{
					Value = 200002,
					Num = 171,
				},
				{
					Value = 200008,
					Num = 36,
				},
			},
		},
		{
			Level = 4,
			Info = 920312,
			Ability = {
				{
					Value = 200002,
					Num = 228,
				},
				{
					Value = 200008,
					Num = 48,
				},
			},
		},
		{
			Level = 5,
			Info = 920312,
			Ability = {
				{
					Value = 200002,
					Num = 285,
				},
				{
					Value = 200008,
					Num = 60,
				},
			},
		},
		{
			Level = 6,
			Info = 920312,
			Ability = {
				{
					Value = 200002,
					Num = 342,
				},
				{
					Value = 200008,
					Num = 72,
				},
			},
		},
		{
			Level = 7,
			Info = 920312,
			Ability = {
				{
					Value = 200002,
					Num = 399,
				},
				{
					Value = 200008,
					Num = 84,
				},
			},
		},
		{
			Level = 8,
			Info = 920312,
			Ability = {
				{
					Value = 200002,
					Num = 456,
				},
				{
					Value = 200008,
					Num = 96,
				},
			},
			SkillList = {
				{
					Id = 100552,
					Value = 25,
				},
			},
		},
		{
			Level = 9,
			Info = 920312,
			Ability = {
				{
					Value = 200002,
					Num = 513,
				},
				{
					Value = 200008,
					Num = 108,
				},
			},
			SkillList = {
				{
					Id = 100552,
					Value = 25,
				},
			},
		},
		{
			Level = 10,
			Info = 920312,
			Ability = {
				{
					Value = 200002,
					Num = 570,
				},
				{
					Value = 200008,
					Num = 120,
				},
			},
			SkillList = {
				{
					Id = 100552,
					Value = 25,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id283] =
{
	Character = 220322,
	Rarity = 4,
	UpgradeId = 930034,
	LevelList = {
		{
			Level = 1,
			Info = 920313,
			Ability = {
				{
					Value = 200001,
					Num = 69,
				},
				{
					Value = 200005,
					Num = 9,
				},
			},
		},
		{
			Level = 2,
			Info = 920313,
			Ability = {
				{
					Value = 200001,
					Num = 138,
				},
				{
					Value = 200005,
					Num = 18,
				},
			},
		},
		{
			Level = 3,
			Info = 920313,
			Ability = {
				{
					Value = 200001,
					Num = 207,
				},
				{
					Value = 200005,
					Num = 27,
				},
			},
		},
		{
			Level = 4,
			Info = 920313,
			Ability = {
				{
					Value = 200001,
					Num = 276,
				},
				{
					Value = 200005,
					Num = 36,
				},
			},
		},
		{
			Level = 5,
			Info = 920313,
			Ability = {
				{
					Value = 200001,
					Num = 345,
				},
				{
					Value = 200005,
					Num = 45,
				},
			},
		},
		{
			Level = 6,
			Info = 920313,
			Ability = {
				{
					Value = 200001,
					Num = 414,
				},
				{
					Value = 200005,
					Num = 54,
				},
			},
		},
		{
			Level = 7,
			Info = 920313,
			Ability = {
				{
					Value = 200001,
					Num = 483,
				},
				{
					Value = 200005,
					Num = 63,
				},
			},
		},
		{
			Level = 8,
			Info = 920313,
			Ability = {
				{
					Value = 200001,
					Num = 552,
				},
				{
					Value = 200005,
					Num = 72,
				},
			},
			SkillList = {
				{
					Id = 101761,
					Value = 75,
				},
			},
		},
		{
			Level = 9,
			Info = 920313,
			Ability = {
				{
					Value = 200001,
					Num = 621,
				},
				{
					Value = 200005,
					Num = 81,
				},
			},
			SkillList = {
				{
					Id = 101761,
					Value = 75,
				},
			},
		},
		{
			Level = 10,
			Info = 920313,
			Ability = {
				{
					Value = 200001,
					Num = 690,
				},
				{
					Value = 200005,
					Num = 90,
				},
			},
			SkillList = {
				{
					Id = 101761,
					Value = 75,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id284] =
{
	Character = 220322,
	Rarity = 4,
	NeedChallenge = 145114,
	UpgradeId = 930015,
	LevelList = {
		{
			Level = 1,
			Info = 920314,
			Ability = {
				{
					Value = 200002,
					Num = 114,
				},
			},
		},
		{
			Level = 2,
			Info = 920314,
			Ability = {
				{
					Value = 200002,
					Num = 190,
				},
			},
		},
		{
			Level = 3,
			Info = 920314,
			Ability = {
				{
					Value = 200002,
					Num = 266,
				},
			},
		},
		{
			Level = 4,
			Info = 920314,
			Ability = {
				{
					Value = 200002,
					Num = 342,
				},
			},
		},
		{
			Level = 5,
			Info = 920314,
			Ability = {
				{
					Value = 200002,
					Num = 418,
				},
				{
					Value = 200004,
					Num = 25,
				},
			},
		},
		{
			Level = 6,
			Info = 920314,
			Ability = {
				{
					Value = 200002,
					Num = 494,
				},
				{
					Value = 200004,
					Num = 30,
				},
			},
		},
		{
			Level = 7,
			Info = 920314,
			Ability = {
				{
					Value = 200002,
					Num = 570,
				},
				{
					Value = 200004,
					Num = 35,
				},
			},
		},
		{
			Level = 8,
			Info = 920314,
			Ability = {
				{
					Value = 200002,
					Num = 646,
				},
				{
					Value = 200004,
					Num = 40,
				},
			},
			SkillList = {
				{
					Id = 101733,
					Value = 90,
				},
			},
		},
		{
			Level = 9,
			Info = 920314,
			Ability = {
				{
					Value = 200002,
					Num = 722,
				},
				{
					Value = 200004,
					Num = 45,
				},
			},
			SkillList = {
				{
					Id = 101733,
					Value = 90,
				},
			},
		},
		{
			Level = 10,
			Info = 920314,
			Ability = {
				{
					Value = 200002,
					Num = 798,
				},
				{
					Value = 200004,
					Num = 50,
				},
			},
			SkillList = {
				{
					Id = 101733,
					Value = 90,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id285] =
{
	Character = 220323,
	Rarity = 4,
	UpgradeId = 930013,
	LevelList = {
		{
			Level = 1,
			Info = 920315,
			Ability = {
				{
					Value = 200002,
					Num = 57,
				},
				{
					Value = 200008,
					Num = 21,
				},
			},
		},
		{
			Level = 2,
			Info = 920315,
			Ability = {
				{
					Value = 200002,
					Num = 114,
				},
				{
					Value = 200008,
					Num = 42,
				},
			},
		},
		{
			Level = 3,
			Info = 920315,
			Ability = {
				{
					Value = 200002,
					Num = 171,
				},
				{
					Value = 200008,
					Num = 63,
				},
			},
		},
		{
			Level = 4,
			Info = 920315,
			Ability = {
				{
					Value = 200002,
					Num = 228,
				},
				{
					Value = 200008,
					Num = 84,
				},
			},
		},
		{
			Level = 5,
			Info = 920315,
			Ability = {
				{
					Value = 200002,
					Num = 285,
				},
				{
					Value = 200008,
					Num = 105,
				},
			},
			SkillList = {
				{
					Id = 100652,
					Value = 5,
				},
			},
		},
		{
			Level = 6,
			Info = 920315,
			Ability = {
				{
					Value = 200002,
					Num = 342,
				},
				{
					Value = 200008,
					Num = 126,
				},
			},
			SkillList = {
				{
					Id = 100652,
					Value = 5,
				},
			},
		},
		{
			Level = 7,
			Info = 920315,
			Ability = {
				{
					Value = 200002,
					Num = 399,
				},
				{
					Value = 200008,
					Num = 147,
				},
			},
			SkillList = {
				{
					Id = 100652,
					Value = 5,
				},
			},
		},
		{
			Level = 8,
			Info = 920315,
			Ability = {
				{
					Value = 200002,
					Num = 456,
				},
				{
					Value = 200008,
					Num = 168,
				},
			},
			SkillList = {
				{
					Id = 100652,
					Value = 5,
				},
			},
		},
		{
			Level = 9,
			Info = 920315,
			Ability = {
				{
					Value = 200002,
					Num = 513,
				},
				{
					Value = 200008,
					Num = 189,
				},
			},
			SkillList = {
				{
					Id = 100652,
					Value = 5,
				},
			},
		},
		{
			Level = 10,
			Info = 920315,
			Ability = {
				{
					Value = 200002,
					Num = 570,
				},
				{
					Value = 200008,
					Num = 210,
				},
			},
			SkillList = {
				{
					Id = 100652,
					Value = 5,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id286] =
{
	Character = 220323,
	Rarity = 4,
	UpgradeId = 930014,
	LevelList = {
		{
			Level = 1,
			Info = 920317,
			Ability = {
				{
					Value = 200002,
					Num = 57,
				},
				{
					Value = 200008,
					Num = 21,
				},
			},
		},
		{
			Level = 2,
			Info = 920317,
			Ability = {
				{
					Value = 200002,
					Num = 114,
				},
				{
					Value = 200008,
					Num = 42,
				},
			},
		},
		{
			Level = 3,
			Info = 920317,
			Ability = {
				{
					Value = 200002,
					Num = 171,
				},
				{
					Value = 200008,
					Num = 63,
				},
			},
		},
		{
			Level = 4,
			Info = 920317,
			Ability = {
				{
					Value = 200002,
					Num = 228,
				},
				{
					Value = 200008,
					Num = 84,
				},
			},
		},
		{
			Level = 5,
			Info = 920317,
			Ability = {
				{
					Value = 200002,
					Num = 285,
				},
				{
					Value = 200008,
					Num = 105,
				},
			},
		},
		{
			Level = 6,
			Info = 920317,
			Ability = {
				{
					Value = 200002,
					Num = 342,
				},
				{
					Value = 200008,
					Num = 126,
				},
			},
		},
		{
			Level = 7,
			Info = 920317,
			Ability = {
				{
					Value = 200002,
					Num = 399,
				},
				{
					Value = 200008,
					Num = 147,
				},
			},
		},
		{
			Level = 8,
			Info = 920317,
			Ability = {
				{
					Value = 200002,
					Num = 456,
				},
				{
					Value = 200008,
					Num = 168,
				},
			},
			SkillList = {
				{
					Id = 101504,
					Value = -22,
				},
			},
		},
		{
			Level = 9,
			Info = 920317,
			Ability = {
				{
					Value = 200002,
					Num = 513,
				},
				{
					Value = 200008,
					Num = 189,
				},
			},
			SkillList = {
				{
					Id = 101504,
					Value = -22,
				},
			},
		},
		{
			Level = 10,
			Info = 920317,
			Ability = {
				{
					Value = 200002,
					Num = 570,
				},
				{
					Value = 200008,
					Num = 210,
				},
			},
			SkillList = {
				{
					Id = 101504,
					Value = -22,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id287] =
{
	Character = 220323,
	Rarity = 4,
	NeedChallenge = 145115,
	UpgradeId = 930035,
	LevelList = {
		{
			Level = 1,
			Info = 920316,
			Ability = {
				{
					Value = 200001,
					Num = 138,
				},
			},
		},
		{
			Level = 2,
			Info = 920316,
			Ability = {
				{
					Value = 200001,
					Num = 230,
				},
			},
		},
		{
			Level = 3,
			Info = 920316,
			Ability = {
				{
					Value = 200001,
					Num = 322,
				},
			},
		},
		{
			Level = 4,
			Info = 920316,
			Ability = {
				{
					Value = 200001,
					Num = 414,
				},
			},
		},
		{
			Level = 5,
			Info = 920316,
			Ability = {
				{
					Value = 200001,
					Num = 506,
				},
				{
					Value = 200002,
					Num = 110,
				},
			},
		},
		{
			Level = 6,
			Info = 920316,
			Ability = {
				{
					Value = 200001,
					Num = 598,
				},
				{
					Value = 200002,
					Num = 130,
				},
			},
		},
		{
			Level = 7,
			Info = 920316,
			Ability = {
				{
					Value = 200001,
					Num = 690,
				},
				{
					Value = 200002,
					Num = 150,
				},
			},
		},
		{
			Level = 8,
			Info = 920316,
			Ability = {
				{
					Value = 200001,
					Num = 782,
				},
				{
					Value = 200002,
					Num = 170,
				},
			},
			SkillList = {
				{
					Id = 101525,
					Value = -12,
				},
			},
		},
		{
			Level = 9,
			Info = 920316,
			Ability = {
				{
					Value = 200001,
					Num = 874,
				},
				{
					Value = 200002,
					Num = 190,
				},
			},
			SkillList = {
				{
					Id = 101525,
					Value = -12,
				},
			},
		},
		{
			Level = 10,
			Info = 920316,
			Ability = {
				{
					Value = 200001,
					Num = 966,
				},
				{
					Value = 200002,
					Num = 210,
				},
			},
			SkillList = {
				{
					Id = 101525,
					Value = -12,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id288] =
{
	Character = 220324,
	Rarity = 5,
	UpgradeId = 930017,
	LevelList = {
		{
			Level = 1,
			Info = 920318,
			Ability = {
				{
					Value = 200002,
					Num = 69,
				},
				{
					Value = 200008,
					Num = 21,
				},
			},
		},
		{
			Level = 2,
			Info = 920318,
			Ability = {
				{
					Value = 200002,
					Num = 138,
				},
				{
					Value = 200008,
					Num = 42,
				},
			},
		},
		{
			Level = 3,
			Info = 920318,
			Ability = {
				{
					Value = 200002,
					Num = 207,
				},
				{
					Value = 200008,
					Num = 63,
				},
			},
		},
		{
			Level = 4,
			Info = 920318,
			Ability = {
				{
					Value = 200002,
					Num = 276,
				},
				{
					Value = 200008,
					Num = 84,
				},
			},
		},
		{
			Level = 5,
			Info = 920318,
			Ability = {
				{
					Value = 200002,
					Num = 345,
				},
				{
					Value = 200008,
					Num = 105,
				},
			},
		},
		{
			Level = 6,
			Info = 920318,
			Ability = {
				{
					Value = 200002,
					Num = 414,
				},
				{
					Value = 200008,
					Num = 126,
				},
			},
		},
		{
			Level = 7,
			Info = 920318,
			Ability = {
				{
					Value = 200002,
					Num = 483,
				},
				{
					Value = 200008,
					Num = 147,
				},
			},
		},
		{
			Level = 8,
			Info = 920318,
			Ability = {
				{
					Value = 200002,
					Num = 552,
				},
				{
					Value = 200008,
					Num = 168,
				},
			},
			SkillList = {
				{
					Id = 100555,
					Value = 25,
				},
			},
		},
		{
			Level = 9,
			Info = 920318,
			Ability = {
				{
					Value = 200002,
					Num = 621,
				},
				{
					Value = 200008,
					Num = 189,
				},
			},
			SkillList = {
				{
					Id = 100555,
					Value = 25,
				},
			},
		},
		{
			Level = 10,
			Info = 920318,
			Ability = {
				{
					Value = 200002,
					Num = 690,
				},
				{
					Value = 200008,
					Num = 210,
				},
			},
			SkillList = {
				{
					Id = 100555,
					Value = 25,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id289] =
{
	Character = 220324,
	Rarity = 5,
	UpgradeId = 930018,
	LevelList = {
		{
			Level = 1,
			Info = 920319,
			Ability = {
				{
					Value = 200002,
					Num = 69,
				},
				{
					Value = 200008,
					Num = 21,
				},
			},
		},
		{
			Level = 2,
			Info = 920319,
			Ability = {
				{
					Value = 200002,
					Num = 138,
				},
				{
					Value = 200008,
					Num = 42,
				},
			},
		},
		{
			Level = 3,
			Info = 920319,
			Ability = {
				{
					Value = 200002,
					Num = 207,
				},
				{
					Value = 200008,
					Num = 63,
				},
			},
		},
		{
			Level = 4,
			Info = 920319,
			Ability = {
				{
					Value = 200002,
					Num = 276,
				},
				{
					Value = 200008,
					Num = 84,
				},
			},
		},
		{
			Level = 5,
			Info = 920319,
			Ability = {
				{
					Value = 200002,
					Num = 345,
				},
				{
					Value = 200008,
					Num = 105,
				},
			},
		},
		{
			Level = 6,
			Info = 920319,
			Ability = {
				{
					Value = 200002,
					Num = 414,
				},
				{
					Value = 200008,
					Num = 126,
				},
			},
		},
		{
			Level = 7,
			Info = 920319,
			Ability = {
				{
					Value = 200002,
					Num = 483,
				},
				{
					Value = 200008,
					Num = 147,
				},
			},
		},
		{
			Level = 8,
			Info = 920319,
			Ability = {
				{
					Value = 200002,
					Num = 552,
				},
				{
					Value = 200008,
					Num = 168,
				},
			},
			SkillList = {
				{
					Id = 100652,
					Value = 7,
				},
			},
		},
		{
			Level = 9,
			Info = 920319,
			Ability = {
				{
					Value = 200002,
					Num = 621,
				},
				{
					Value = 200008,
					Num = 189,
				},
			},
			SkillList = {
				{
					Id = 100652,
					Value = 7,
				},
			},
		},
		{
			Level = 10,
			Info = 920319,
			Ability = {
				{
					Value = 200002,
					Num = 690,
				},
				{
					Value = 200008,
					Num = 210,
				},
			},
			SkillList = {
				{
					Id = 100652,
					Value = 7,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id290] =
{
	Character = 220324,
	Rarity = 5,
	NeedChallenge = 145116,
	UpgradeId = 930019,
	LevelList = {
		{
			Level = 1,
			Info = 920320,
			Ability = {
				{
					Value = 200002,
					Num = 138,
				},
			},
		},
		{
			Level = 2,
			Info = 920320,
			Ability = {
				{
					Value = 200002,
					Num = 230,
				},
			},
		},
		{
			Level = 3,
			Info = 920320,
			Ability = {
				{
					Value = 200002,
					Num = 322,
				},
			},
		},
		{
			Level = 4,
			Info = 920320,
			Ability = {
				{
					Value = 200002,
					Num = 414,
				},
			},
		},
		{
			Level = 5,
			Info = 920320,
			Ability = {
				{
					Value = 200002,
					Num = 506,
				},
				{
					Value = 200004,
					Num = 25,
				},
			},
		},
		{
			Level = 6,
			Info = 920320,
			Ability = {
				{
					Value = 200002,
					Num = 598,
				},
				{
					Value = 200004,
					Num = 30,
				},
			},
		},
		{
			Level = 7,
			Info = 920320,
			Ability = {
				{
					Value = 200002,
					Num = 690,
				},
				{
					Value = 200004,
					Num = 35,
				},
			},
		},
		{
			Level = 8,
			Info = 920320,
			Ability = {
				{
					Value = 200002,
					Num = 782,
				},
				{
					Value = 200004,
					Num = 40,
				},
			},
			SkillList = {
				{
					Id = 101745,
					Value = 60,
				},
			},
		},
		{
			Level = 9,
			Info = 920320,
			Ability = {
				{
					Value = 200002,
					Num = 874,
				},
				{
					Value = 200004,
					Num = 45,
				},
			},
			SkillList = {
				{
					Id = 101745,
					Value = 60,
				},
			},
		},
		{
			Level = 10,
			Info = 920320,
			Ability = {
				{
					Value = 200002,
					Num = 966,
				},
				{
					Value = 200004,
					Num = 50,
				},
			},
			SkillList = {
				{
					Id = 101745,
					Value = 60,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id291] =
{
	Character = 220324,
	Rarity = 5,
	NeedChallenge = 145117,
	UpgradeId = 930040,
	LevelList = {
		{
			Level = 1,
			Info = 920321,
			Ability = {
				{
					Value = 200001,
					Num = 252,
				},
			},
		},
		{
			Level = 2,
			Info = 920321,
			Ability = {
				{
					Value = 200001,
					Num = 392,
				},
			},
		},
		{
			Level = 3,
			Info = 920321,
			Ability = {
				{
					Value = 200001,
					Num = 532,
				},
			},
		},
		{
			Level = 4,
			Info = 920321,
			Ability = {
				{
					Value = 200001,
					Num = 672,
				},
			},
		},
		{
			Level = 5,
			Info = 920321,
			Ability = {
				{
					Value = 200001,
					Num = 812,
				},
				{
					Value = 200003,
					Num = 25,
				},
			},
		},
		{
			Level = 6,
			Info = 920321,
			Ability = {
				{
					Value = 200001,
					Num = 952,
				},
				{
					Value = 200003,
					Num = 30,
				},
			},
		},
		{
			Level = 7,
			Info = 920321,
			Ability = {
				{
					Value = 200001,
					Num = 1092,
				},
				{
					Value = 200003,
					Num = 35,
				},
			},
		},
		{
			Level = 8,
			Info = 920321,
			Ability = {
				{
					Value = 200001,
					Num = 1232,
				},
				{
					Value = 200003,
					Num = 40,
				},
			},
			SkillList = {
				{
					Id = 101744,
					Value = 7,
				},
			},
		},
		{
			Level = 9,
			Info = 920321,
			Ability = {
				{
					Value = 200001,
					Num = 1372,
				},
				{
					Value = 200003,
					Num = 45,
				},
			},
			SkillList = {
				{
					Id = 101744,
					Value = 7,
				},
			},
		},
		{
			Level = 10,
			Info = 920321,
			Ability = {
				{
					Value = 200001,
					Num = 1512,
				},
				{
					Value = 200003,
					Num = 50,
				},
			},
			SkillList = {
				{
					Id = 101744,
					Value = 7,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id292] =
{
	Character = 220325,
	Rarity = 5,
	UpgradeId = 930017,
	LevelList = {
		{
			Level = 1,
			Info = 920322,
			Ability = {
				{
					Value = 200002,
					Num = 69,
				},
				{
					Value = 200008,
					Num = 12,
				},
			},
		},
		{
			Level = 2,
			Info = 920322,
			Ability = {
				{
					Value = 200002,
					Num = 138,
				},
				{
					Value = 200008,
					Num = 24,
				},
			},
		},
		{
			Level = 3,
			Info = 920322,
			Ability = {
				{
					Value = 200002,
					Num = 207,
				},
				{
					Value = 200008,
					Num = 36,
				},
			},
		},
		{
			Level = 4,
			Info = 920322,
			Ability = {
				{
					Value = 200002,
					Num = 276,
				},
				{
					Value = 200008,
					Num = 48,
				},
			},
		},
		{
			Level = 5,
			Info = 920322,
			Ability = {
				{
					Value = 200002,
					Num = 345,
				},
				{
					Value = 200008,
					Num = 60,
				},
			},
		},
		{
			Level = 6,
			Info = 920322,
			Ability = {
				{
					Value = 200002,
					Num = 414,
				},
				{
					Value = 200008,
					Num = 72,
				},
			},
		},
		{
			Level = 7,
			Info = 920322,
			Ability = {
				{
					Value = 200002,
					Num = 483,
				},
				{
					Value = 200008,
					Num = 84,
				},
			},
		},
		{
			Level = 8,
			Info = 920322,
			Ability = {
				{
					Value = 200002,
					Num = 552,
				},
				{
					Value = 200008,
					Num = 96,
				},
			},
			SkillList = {
				{
					Id = 100554,
					Value = 25,
				},
			},
		},
		{
			Level = 9,
			Info = 920322,
			Ability = {
				{
					Value = 200002,
					Num = 621,
				},
				{
					Value = 200008,
					Num = 108,
				},
			},
			SkillList = {
				{
					Id = 100554,
					Value = 25,
				},
			},
		},
		{
			Level = 10,
			Info = 920322,
			Ability = {
				{
					Value = 200002,
					Num = 690,
				},
				{
					Value = 200008,
					Num = 120,
				},
			},
			SkillList = {
				{
					Id = 100554,
					Value = 25,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id293] =
{
	Character = 220325,
	Rarity = 5,
	UpgradeId = 930018,
	LevelList = {
		{
			Level = 1,
			Info = 920323,
			Ability = {
				{
					Value = 200002,
					Num = 69,
				},
				{
					Value = 200005,
					Num = 9,
				},
			},
		},
		{
			Level = 2,
			Info = 920323,
			Ability = {
				{
					Value = 200002,
					Num = 138,
				},
				{
					Value = 200005,
					Num = 18,
				},
			},
		},
		{
			Level = 3,
			Info = 920323,
			Ability = {
				{
					Value = 200002,
					Num = 207,
				},
				{
					Value = 200005,
					Num = 27,
				},
			},
		},
		{
			Level = 4,
			Info = 920323,
			Ability = {
				{
					Value = 200002,
					Num = 276,
				},
				{
					Value = 200005,
					Num = 36,
				},
			},
		},
		{
			Level = 5,
			Info = 920323,
			Ability = {
				{
					Value = 200002,
					Num = 345,
				},
				{
					Value = 200005,
					Num = 45,
				},
			},
		},
		{
			Level = 6,
			Info = 920323,
			Ability = {
				{
					Value = 200002,
					Num = 414,
				},
				{
					Value = 200005,
					Num = 54,
				},
			},
		},
		{
			Level = 7,
			Info = 920323,
			Ability = {
				{
					Value = 200002,
					Num = 483,
				},
				{
					Value = 200005,
					Num = 63,
				},
			},
		},
		{
			Level = 8,
			Info = 920323,
			Ability = {
				{
					Value = 200002,
					Num = 552,
				},
				{
					Value = 200005,
					Num = 72,
				},
			},
			SkillList = {
				{
					Id = 100554,
					Value = 25,
				},
			},
		},
		{
			Level = 9,
			Info = 920323,
			Ability = {
				{
					Value = 200002,
					Num = 621,
				},
				{
					Value = 200005,
					Num = 81,
				},
			},
			SkillList = {
				{
					Id = 100554,
					Value = 25,
				},
			},
		},
		{
			Level = 10,
			Info = 920323,
			Ability = {
				{
					Value = 200002,
					Num = 690,
				},
				{
					Value = 200005,
					Num = 90,
				},
			},
			SkillList = {
				{
					Id = 100554,
					Value = 25,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id294] =
{
	Character = 220325,
	Rarity = 5,
	NeedChallenge = 145118,
	UpgradeId = 930039,
	LevelList = {
		{
			Level = 1,
			Info = 920324,
			Ability = {
				{
					Value = 200001,
					Num = 168,
				},
			},
		},
		{
			Level = 2,
			Info = 920324,
			Ability = {
				{
					Value = 200001,
					Num = 280,
				},
			},
		},
		{
			Level = 3,
			Info = 920324,
			Ability = {
				{
					Value = 200001,
					Num = 392,
				},
			},
		},
		{
			Level = 4,
			Info = 920324,
			Ability = {
				{
					Value = 200001,
					Num = 504,
				},
			},
		},
		{
			Level = 5,
			Info = 920324,
			Ability = {
				{
					Value = 200001,
					Num = 616,
				},
				{
					Value = 200003,
					Num = 25,
				},
			},
		},
		{
			Level = 6,
			Info = 920324,
			Ability = {
				{
					Value = 200001,
					Num = 728,
				},
				{
					Value = 200003,
					Num = 30,
				},
			},
		},
		{
			Level = 7,
			Info = 920324,
			Ability = {
				{
					Value = 200001,
					Num = 840,
				},
				{
					Value = 200003,
					Num = 35,
				},
			},
		},
		{
			Level = 8,
			Info = 920324,
			Ability = {
				{
					Value = 200001,
					Num = 952,
				},
				{
					Value = 200003,
					Num = 40,
				},
			},
			SkillList = {
				{
					Id = 101762,
					Value = 8,
				},
			},
		},
		{
			Level = 9,
			Info = 920324,
			Ability = {
				{
					Value = 200001,
					Num = 1064,
				},
				{
					Value = 200003,
					Num = 45,
				},
			},
			SkillList = {
				{
					Id = 101762,
					Value = 8,
				},
			},
		},
		{
			Level = 10,
			Info = 920324,
			Ability = {
				{
					Value = 200001,
					Num = 1176,
				},
				{
					Value = 200003,
					Num = 50,
				},
			},
			SkillList = {
				{
					Id = 101762,
					Value = 8,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id295] =
{
	Character = 220325,
	Rarity = 5,
	NeedChallenge = 145119,
	UpgradeId = 930020,
	LevelList = {
		{
			Level = 1,
			Info = 920325,
			Ability = {
				{
					Value = 200002,
					Num = 207,
				},
			},
		},
		{
			Level = 2,
			Info = 920325,
			Ability = {
				{
					Value = 200002,
					Num = 322,
				},
			},
		},
		{
			Level = 3,
			Info = 920325,
			Ability = {
				{
					Value = 200002,
					Num = 437,
				},
			},
		},
		{
			Level = 4,
			Info = 920325,
			Ability = {
				{
					Value = 200002,
					Num = 552,
				},
			},
		},
		{
			Level = 5,
			Info = 920325,
			Ability = {
				{
					Value = 200002,
					Num = 667,
				},
				{
					Value = 200004,
					Num = 25,
				},
			},
		},
		{
			Level = 6,
			Info = 920325,
			Ability = {
				{
					Value = 200002,
					Num = 782,
				},
				{
					Value = 200004,
					Num = 30,
				},
			},
		},
		{
			Level = 7,
			Info = 920325,
			Ability = {
				{
					Value = 200002,
					Num = 897,
				},
				{
					Value = 200004,
					Num = 35,
				},
			},
		},
		{
			Level = 8,
			Info = 920325,
			Ability = {
				{
					Value = 200002,
					Num = 1012,
				},
				{
					Value = 200004,
					Num = 40,
				},
			},
			SkillList = {
				{
					Id = 100605,
					Value = 36,
				},
			},
		},
		{
			Level = 9,
			Info = 920325,
			Ability = {
				{
					Value = 200002,
					Num = 1127,
				},
				{
					Value = 200004,
					Num = 45,
				},
			},
			SkillList = {
				{
					Id = 100605,
					Value = 36,
				},
			},
		},
		{
			Level = 10,
			Info = 920325,
			Ability = {
				{
					Value = 200002,
					Num = 1242,
				},
				{
					Value = 200004,
					Num = 50,
				},
			},
			SkillList = {
				{
					Id = 100605,
					Value = 36,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id296] =
{
	Character = 221001,
	Rarity = 3,
	UpgradeId = 930029,
	LevelList = {
		{
			Level = 1,
			Info = 920509,
			Ability = {
				{
					Value = 200001,
					Num = 54,
				},
				{
					Value = 200007,
					Num = 9,
				},
			},
		},
		{
			Level = 2,
			Info = 920509,
			Ability = {
				{
					Value = 200001,
					Num = 108,
				},
				{
					Value = 200007,
					Num = 18,
				},
			},
		},
		{
			Level = 3,
			Info = 920509,
			Ability = {
				{
					Value = 200001,
					Num = 162,
				},
				{
					Value = 200007,
					Num = 27,
				},
			},
		},
		{
			Level = 4,
			Info = 920509,
			Ability = {
				{
					Value = 200001,
					Num = 216,
				},
				{
					Value = 200007,
					Num = 36,
				},
			},
		},
		{
			Level = 5,
			Info = 920509,
			Ability = {
				{
					Value = 200001,
					Num = 270,
				},
				{
					Value = 200007,
					Num = 45,
				},
			},
		},
		{
			Level = 6,
			Info = 920509,
			Ability = {
				{
					Value = 200001,
					Num = 324,
				},
				{
					Value = 200007,
					Num = 54,
				},
			},
		},
		{
			Level = 7,
			Info = 920509,
			Ability = {
				{
					Value = 200001,
					Num = 378,
				},
				{
					Value = 200007,
					Num = 63,
				},
			},
		},
		{
			Level = 8,
			Info = 920509,
			Ability = {
				{
					Value = 200001,
					Num = 432,
				},
				{
					Value = 200007,
					Num = 72,
				},
			},
			SkillList = {
				{
					Id = 100564,
					Value = -5,
				},
			},
		},
		{
			Level = 9,
			Info = 920509,
			Ability = {
				{
					Value = 200001,
					Num = 486,
				},
				{
					Value = 200007,
					Num = 81,
				},
			},
			SkillList = {
				{
					Id = 100564,
					Value = -5,
				},
			},
		},
		{
			Level = 10,
			Info = 920509,
			Ability = {
				{
					Value = 200001,
					Num = 540,
				},
				{
					Value = 200007,
					Num = 90,
				},
			},
			SkillList = {
				{
					Id = 100564,
					Value = -5,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id297] =
{
	Character = 221001,
	Rarity = 3,
	UpgradeId = 930030,
	LevelList = {
		{
			Level = 1,
			Info = 920510,
			Ability = {
				{
					Value = 200001,
					Num = 54,
				},
				{
					Value = 200006,
					Num = 6,
				},
			},
		},
		{
			Level = 2,
			Info = 920510,
			Ability = {
				{
					Value = 200001,
					Num = 108,
				},
				{
					Value = 200006,
					Num = 12,
				},
			},
		},
		{
			Level = 3,
			Info = 920510,
			Ability = {
				{
					Value = 200001,
					Num = 162,
				},
				{
					Value = 200006,
					Num = 18,
				},
			},
		},
		{
			Level = 4,
			Info = 920510,
			Ability = {
				{
					Value = 200001,
					Num = 216,
				},
				{
					Value = 200006,
					Num = 24,
				},
			},
		},
		{
			Level = 5,
			Info = 920510,
			Ability = {
				{
					Value = 200001,
					Num = 270,
				},
				{
					Value = 200006,
					Num = 30,
				},
			},
		},
		{
			Level = 6,
			Info = 920510,
			Ability = {
				{
					Value = 200001,
					Num = 324,
				},
				{
					Value = 200006,
					Num = 36,
				},
			},
		},
		{
			Level = 7,
			Info = 920510,
			Ability = {
				{
					Value = 200001,
					Num = 378,
				},
				{
					Value = 200006,
					Num = 42,
				},
			},
		},
		{
			Level = 8,
			Info = 920510,
			Ability = {
				{
					Value = 200001,
					Num = 432,
				},
				{
					Value = 200006,
					Num = 48,
				},
			},
			SkillList = {
				{
					Id = 100564,
					Value = -5,
				},
			},
		},
		{
			Level = 9,
			Info = 920510,
			Ability = {
				{
					Value = 200001,
					Num = 486,
				},
				{
					Value = 200006,
					Num = 54,
				},
			},
			SkillList = {
				{
					Id = 100564,
					Value = -5,
				},
			},
		},
		{
			Level = 10,
			Info = 920510,
			Ability = {
				{
					Value = 200001,
					Num = 540,
				},
				{
					Value = 200006,
					Num = 60,
				},
			},
			SkillList = {
				{
					Id = 100564,
					Value = -5,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id298] =
{
	Character = 221001,
	Rarity = 3,
	NeedChallenge = 145120,
	UpgradeId = 930031,
	LevelList = {
		{
			Level = 1,
			Info = 920511,
			Ability = {
				{
					Value = 200001,
					Num = 108,
				},
			},
		},
		{
			Level = 2,
			Info = 920511,
			Ability = {
				{
					Value = 200001,
					Num = 180,
				},
			},
		},
		{
			Level = 3,
			Info = 920511,
			Ability = {
				{
					Value = 200001,
					Num = 252,
				},
			},
		},
		{
			Level = 4,
			Info = 920511,
			Ability = {
				{
					Value = 200001,
					Num = 324,
				},
			},
		},
		{
			Level = 5,
			Info = 920511,
			Ability = {
				{
					Value = 200001,
					Num = 396,
				},
				{
					Value = 200003,
					Num = 25,
				},
			},
			SkillList = {
				{
					Id = 100651,
					Value = 5,
				},
			},
		},
		{
			Level = 6,
			Info = 920511,
			Ability = {
				{
					Value = 200001,
					Num = 468,
				},
				{
					Value = 200003,
					Num = 30,
				},
			},
			SkillList = {
				{
					Id = 100651,
					Value = 5,
				},
			},
		},
		{
			Level = 7,
			Info = 920511,
			Ability = {
				{
					Value = 200001,
					Num = 540,
				},
				{
					Value = 200003,
					Num = 35,
				},
			},
			SkillList = {
				{
					Id = 100651,
					Value = 5,
				},
			},
		},
		{
			Level = 8,
			Info = 920511,
			Ability = {
				{
					Value = 200001,
					Num = 612,
				},
				{
					Value = 200003,
					Num = 40,
				},
			},
			SkillList = {
				{
					Id = 100651,
					Value = 5,
				},
			},
		},
		{
			Level = 9,
			Info = 920511,
			Ability = {
				{
					Value = 200001,
					Num = 684,
				},
				{
					Value = 200003,
					Num = 45,
				},
			},
			SkillList = {
				{
					Id = 100651,
					Value = 5,
				},
			},
		},
		{
			Level = 10,
			Info = 920511,
			Ability = {
				{
					Value = 200001,
					Num = 756,
				},
				{
					Value = 200003,
					Num = 50,
				},
			},
			SkillList = {
				{
					Id = 100651,
					Value = 5,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id299] =
{
	Character = 221002,
	Rarity = 4,
	UpgradeId = 930013,
	LevelList = {
		{
			Level = 1,
			Info = 920512,
			Ability = {
				{
					Value = 200002,
					Num = 66,
				},
				{
					Value = 200005,
					Num = 12,
				},
			},
		},
		{
			Level = 2,
			Info = 920512,
			Ability = {
				{
					Value = 200002,
					Num = 132,
				},
				{
					Value = 200005,
					Num = 24,
				},
			},
		},
		{
			Level = 3,
			Info = 920512,
			Ability = {
				{
					Value = 200002,
					Num = 198,
				},
				{
					Value = 200005,
					Num = 36,
				},
			},
		},
		{
			Level = 4,
			Info = 920512,
			Ability = {
				{
					Value = 200002,
					Num = 264,
				},
				{
					Value = 200005,
					Num = 48,
				},
			},
		},
		{
			Level = 5,
			Info = 920512,
			Ability = {
				{
					Value = 200002,
					Num = 330,
				},
				{
					Value = 200005,
					Num = 60,
				},
			},
		},
		{
			Level = 6,
			Info = 920512,
			Ability = {
				{
					Value = 200002,
					Num = 396,
				},
				{
					Value = 200005,
					Num = 72,
				},
			},
		},
		{
			Level = 7,
			Info = 920512,
			Ability = {
				{
					Value = 200002,
					Num = 462,
				},
				{
					Value = 200005,
					Num = 84,
				},
			},
		},
		{
			Level = 8,
			Info = 920512,
			Ability = {
				{
					Value = 200002,
					Num = 528,
				},
				{
					Value = 200005,
					Num = 96,
				},
			},
			SkillList = {
				{
					Id = 100555,
					Value = 25,
				},
			},
		},
		{
			Level = 9,
			Info = 920512,
			Ability = {
				{
					Value = 200002,
					Num = 594,
				},
				{
					Value = 200005,
					Num = 108,
				},
			},
			SkillList = {
				{
					Id = 100555,
					Value = 25,
				},
			},
		},
		{
			Level = 10,
			Info = 920512,
			Ability = {
				{
					Value = 200002,
					Num = 660,
				},
				{
					Value = 200005,
					Num = 120,
				},
			},
			SkillList = {
				{
					Id = 100555,
					Value = 25,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id300] =
{
	Character = 221002,
	Rarity = 4,
	UpgradeId = 930034,
	LevelList = {
		{
			Level = 1,
			Info = 920513,
			Ability = {
				{
					Value = 200001,
					Num = 69,
				},
				{
					Value = 200006,
					Num = 9,
				},
			},
		},
		{
			Level = 2,
			Info = 920513,
			Ability = {
				{
					Value = 200001,
					Num = 138,
				},
				{
					Value = 200006,
					Num = 18,
				},
			},
		},
		{
			Level = 3,
			Info = 920513,
			Ability = {
				{
					Value = 200001,
					Num = 207,
				},
				{
					Value = 200006,
					Num = 27,
				},
			},
		},
		{
			Level = 4,
			Info = 920513,
			Ability = {
				{
					Value = 200001,
					Num = 276,
				},
				{
					Value = 200006,
					Num = 36,
				},
			},
		},
		{
			Level = 5,
			Info = 920513,
			Ability = {
				{
					Value = 200001,
					Num = 345,
				},
				{
					Value = 200006,
					Num = 45,
				},
			},
		},
		{
			Level = 6,
			Info = 920513,
			Ability = {
				{
					Value = 200001,
					Num = 414,
				},
				{
					Value = 200006,
					Num = 54,
				},
			},
		},
		{
			Level = 7,
			Info = 920513,
			Ability = {
				{
					Value = 200001,
					Num = 483,
				},
				{
					Value = 200006,
					Num = 63,
				},
			},
		},
		{
			Level = 8,
			Info = 920513,
			Ability = {
				{
					Value = 200001,
					Num = 552,
				},
				{
					Value = 200006,
					Num = 72,
				},
			},
			SkillList = {
				{
					Id = 100564,
					Value = -5,
				},
			},
		},
		{
			Level = 9,
			Info = 920513,
			Ability = {
				{
					Value = 200001,
					Num = 621,
				},
				{
					Value = 200006,
					Num = 81,
				},
			},
			SkillList = {
				{
					Id = 100564,
					Value = -5,
				},
			},
		},
		{
			Level = 10,
			Info = 920513,
			Ability = {
				{
					Value = 200001,
					Num = 690,
				},
				{
					Value = 200006,
					Num = 90,
				},
			},
			SkillList = {
				{
					Id = 100564,
					Value = -5,
				},
			},
		},
	},
}
