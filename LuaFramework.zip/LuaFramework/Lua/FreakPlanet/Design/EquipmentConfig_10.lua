
EquipmentConfig[EquipmentID.Id301] =
{
	Character = 221002,
	Rarity = 4,
	NeedChallenge = 145121,
	UpgradeId = 930015,
	LevelList = {
		{
			Level = 1,
			Info = 920514,
			Ability = {
				{
					Value = 200002,
					Num = 132,
				},
			},
		},
		{
			Level = 2,
			Info = 920514,
			Ability = {
				{
					Value = 200002,
					Num = 220,
				},
			},
		},
		{
			Level = 3,
			Info = 920514,
			Ability = {
				{
					Value = 200002,
					Num = 308,
				},
			},
		},
		{
			Level = 4,
			Info = 920514,
			Ability = {
				{
					Value = 200002,
					Num = 396,
				},
			},
		},
		{
			Level = 5,
			Info = 920514,
			Ability = {
				{
					Value = 200002,
					Num = 484,
				},
				{
					Value = 200004,
					Num = 25,
				},
			},
			SkillList = {
				{
					Id = 100652,
					Value = 5,
				},
			},
		},
		{
			Level = 6,
			Info = 920514,
			Ability = {
				{
					Value = 200002,
					Num = 572,
				},
				{
					Value = 200004,
					Num = 30,
				},
			},
			SkillList = {
				{
					Id = 100652,
					Value = 5,
				},
			},
		},
		{
			Level = 7,
			Info = 920514,
			Ability = {
				{
					Value = 200002,
					Num = 660,
				},
				{
					Value = 200004,
					Num = 35,
				},
			},
			SkillList = {
				{
					Id = 100652,
					Value = 5,
				},
			},
		},
		{
			Level = 8,
			Info = 920514,
			Ability = {
				{
					Value = 200002,
					Num = 748,
				},
				{
					Value = 200004,
					Num = 40,
				},
			},
			SkillList = {
				{
					Id = 100652,
					Value = 5,
				},
			},
		},
		{
			Level = 9,
			Info = 920514,
			Ability = {
				{
					Value = 200002,
					Num = 836,
				},
				{
					Value = 200004,
					Num = 45,
				},
			},
			SkillList = {
				{
					Id = 100652,
					Value = 5,
				},
			},
		},
		{
			Level = 10,
			Info = 920514,
			Ability = {
				{
					Value = 200002,
					Num = 924,
				},
				{
					Value = 200004,
					Num = 50,
				},
			},
			SkillList = {
				{
					Id = 100652,
					Value = 5,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id302] =
{
	Character = 221003,
	Rarity = 5,
	UpgradeId = 930037,
	LevelList = {
		{
			Level = 1,
			Info = 920515,
			Ability = {
				{
					Value = 200001,
					Num = 84,
				},
			},
		},
		{
			Level = 2,
			Info = 920515,
			Ability = {
				{
					Value = 200001,
					Num = 168,
				},
			},
		},
		{
			Level = 3,
			Info = 920515,
			Ability = {
				{
					Value = 200001,
					Num = 252,
				},
			},
		},
		{
			Level = 4,
			Info = 920515,
			Ability = {
				{
					Value = 200001,
					Num = 336,
				},
			},
		},
		{
			Level = 5,
			Info = 920515,
			Ability = {
				{
					Value = 200001,
					Num = 420,
				},
			},
			SkillList = {
				{
					Id = 100651,
					Value = 5,
				},
			},
		},
		{
			Level = 6,
			Info = 920515,
			Ability = {
				{
					Value = 200001,
					Num = 504,
				},
			},
			SkillList = {
				{
					Id = 100651,
					Value = 5,
				},
			},
		},
		{
			Level = 7,
			Info = 920515,
			Ability = {
				{
					Value = 200001,
					Num = 588,
				},
			},
			SkillList = {
				{
					Id = 100651,
					Value = 5,
				},
			},
		},
		{
			Level = 8,
			Info = 920515,
			Ability = {
				{
					Value = 200001,
					Num = 672,
				},
			},
			SkillList = {
				{
					Id = 100651,
					Value = 5,
				},
				{
					Id = 100564,
					Value = -5,
				},
			},
		},
		{
			Level = 9,
			Info = 920515,
			Ability = {
				{
					Value = 200001,
					Num = 756,
				},
			},
			SkillList = {
				{
					Id = 100651,
					Value = 5,
				},
				{
					Id = 100564,
					Value = -5,
				},
			},
		},
		{
			Level = 10,
			Info = 920515,
			Ability = {
				{
					Value = 200001,
					Num = 840,
				},
			},
			SkillList = {
				{
					Id = 100651,
					Value = 5,
				},
				{
					Id = 100564,
					Value = -5,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id303] =
{
	Character = 221003,
	Rarity = 5,
	UpgradeId = 930018,
	LevelList = {
		{
			Level = 1,
			Info = 920516,
			Ability = {
				{
					Value = 200002,
					Num = 69,
				},
				{
					Value = 200006,
					Num = 9,
				},
			},
		},
		{
			Level = 2,
			Info = 920516,
			Ability = {
				{
					Value = 200002,
					Num = 138,
				},
				{
					Value = 200006,
					Num = 18,
				},
			},
		},
		{
			Level = 3,
			Info = 920516,
			Ability = {
				{
					Value = 200002,
					Num = 207,
				},
				{
					Value = 200006,
					Num = 27,
				},
			},
		},
		{
			Level = 4,
			Info = 920516,
			Ability = {
				{
					Value = 200002,
					Num = 276,
				},
				{
					Value = 200006,
					Num = 36,
				},
			},
		},
		{
			Level = 5,
			Info = 920516,
			Ability = {
				{
					Value = 200002,
					Num = 345,
				},
				{
					Value = 200006,
					Num = 45,
				},
			},
		},
		{
			Level = 6,
			Info = 920516,
			Ability = {
				{
					Value = 200002,
					Num = 414,
				},
				{
					Value = 200006,
					Num = 54,
				},
			},
		},
		{
			Level = 7,
			Info = 920516,
			Ability = {
				{
					Value = 200002,
					Num = 483,
				},
				{
					Value = 200006,
					Num = 63,
				},
			},
		},
		{
			Level = 8,
			Info = 920516,
			Ability = {
				{
					Value = 200002,
					Num = 552,
				},
				{
					Value = 200006,
					Num = 72,
				},
			},
			SkillList = {
				{
					Id = 100555,
					Value = 25,
				},
			},
		},
		{
			Level = 9,
			Info = 920516,
			Ability = {
				{
					Value = 200002,
					Num = 621,
				},
				{
					Value = 200006,
					Num = 81,
				},
			},
			SkillList = {
				{
					Id = 100555,
					Value = 25,
				},
			},
		},
		{
			Level = 10,
			Info = 920516,
			Ability = {
				{
					Value = 200002,
					Num = 690,
				},
				{
					Value = 200006,
					Num = 90,
				},
			},
			SkillList = {
				{
					Id = 100555,
					Value = 25,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id304] =
{
	Character = 221003,
	Rarity = 5,
	NeedChallenge = 145122,
	UpgradeId = 930019,
	LevelList = {
		{
			Level = 1,
			Info = 920517,
			Ability = {
				{
					Value = 200002,
					Num = 138,
				},
			},
		},
		{
			Level = 2,
			Info = 920517,
			Ability = {
				{
					Value = 200002,
					Num = 230,
				},
			},
		},
		{
			Level = 3,
			Info = 920517,
			Ability = {
				{
					Value = 200002,
					Num = 322,
				},
			},
		},
		{
			Level = 4,
			Info = 920517,
			Ability = {
				{
					Value = 200002,
					Num = 414,
				},
			},
		},
		{
			Level = 5,
			Info = 920517,
			Ability = {
				{
					Value = 200002,
					Num = 506,
				},
				{
					Value = 200004,
					Num = 25,
				},
			},
		},
		{
			Level = 6,
			Info = 920517,
			Ability = {
				{
					Value = 200002,
					Num = 598,
				},
				{
					Value = 200004,
					Num = 30,
				},
			},
		},
		{
			Level = 7,
			Info = 920517,
			Ability = {
				{
					Value = 200002,
					Num = 690,
				},
				{
					Value = 200004,
					Num = 35,
				},
			},
		},
		{
			Level = 8,
			Info = 920517,
			Ability = {
				{
					Value = 200002,
					Num = 782,
				},
				{
					Value = 200004,
					Num = 40,
				},
			},
			SkillList = {
				{
					Id = 100703,
					Value = 2,
				},
			},
		},
		{
			Level = 9,
			Info = 920517,
			Ability = {
				{
					Value = 200002,
					Num = 874,
				},
				{
					Value = 200004,
					Num = 45,
				},
			},
			SkillList = {
				{
					Id = 100703,
					Value = 2,
				},
			},
		},
		{
			Level = 10,
			Info = 920517,
			Ability = {
				{
					Value = 200002,
					Num = 966,
				},
				{
					Value = 200004,
					Num = 50,
				},
			},
			SkillList = {
				{
					Id = 100703,
					Value = 2,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id305] =
{
	Character = 221003,
	Rarity = 5,
	NeedChallenge = 145123,
	UpgradeId = 930020,
	LevelList = {
		{
			Level = 1,
			Info = 920518,
			Ability = {
				{
					Value = 200002,
					Num = 207,
				},
			},
		},
		{
			Level = 2,
			Info = 920518,
			Ability = {
				{
					Value = 200002,
					Num = 322,
				},
			},
		},
		{
			Level = 3,
			Info = 920518,
			Ability = {
				{
					Value = 200002,
					Num = 437,
				},
			},
		},
		{
			Level = 4,
			Info = 920518,
			Ability = {
				{
					Value = 200002,
					Num = 552,
				},
			},
		},
		{
			Level = 5,
			Info = 920518,
			Ability = {
				{
					Value = 200002,
					Num = 667,
				},
				{
					Value = 200004,
					Num = 25,
				},
			},
		},
		{
			Level = 6,
			Info = 920518,
			Ability = {
				{
					Value = 200002,
					Num = 782,
				},
				{
					Value = 200004,
					Num = 30,
				},
			},
		},
		{
			Level = 7,
			Info = 920518,
			Ability = {
				{
					Value = 200002,
					Num = 897,
				},
				{
					Value = 200004,
					Num = 35,
				},
			},
		},
		{
			Level = 8,
			Info = 920518,
			Ability = {
				{
					Value = 200002,
					Num = 1012,
				},
				{
					Value = 200004,
					Num = 40,
				},
			},
			SkillList = {
				{
					Id = 101722,
					Value = 432,
				},
			},
		},
		{
			Level = 9,
			Info = 920518,
			Ability = {
				{
					Value = 200002,
					Num = 1127,
				},
				{
					Value = 200004,
					Num = 45,
				},
			},
			SkillList = {
				{
					Id = 101722,
					Value = 432,
				},
			},
		},
		{
			Level = 10,
			Info = 920518,
			Ability = {
				{
					Value = 200002,
					Num = 1242,
				},
				{
					Value = 200004,
					Num = 50,
				},
			},
			SkillList = {
				{
					Id = 101722,
					Value = 432,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id306] =
{
	Character = 221004,
	Rarity = 3,
	UpgradeId = 930109,
	LevelList = {
		{
			Level = 1,
			Info = 920519,
			Ability = {
				{
					Value = 200001,
					Num = 57,
				},
				{
					Value = 200007,
					Num = 9,
				},
			},
		},
		{
			Level = 2,
			Info = 920519,
			Ability = {
				{
					Value = 200001,
					Num = 114,
				},
				{
					Value = 200007,
					Num = 18,
				},
			},
		},
		{
			Level = 3,
			Info = 920519,
			Ability = {
				{
					Value = 200001,
					Num = 171,
				},
				{
					Value = 200007,
					Num = 27,
				},
			},
		},
		{
			Level = 4,
			Info = 920519,
			Ability = {
				{
					Value = 200001,
					Num = 228,
				},
				{
					Value = 200007,
					Num = 36,
				},
			},
		},
		{
			Level = 5,
			Info = 920519,
			Ability = {
				{
					Value = 200001,
					Num = 285,
				},
				{
					Value = 200007,
					Num = 45,
				},
			},
		},
		{
			Level = 6,
			Info = 920519,
			Ability = {
				{
					Value = 200001,
					Num = 342,
				},
				{
					Value = 200007,
					Num = 54,
				},
			},
		},
		{
			Level = 7,
			Info = 920519,
			Ability = {
				{
					Value = 200001,
					Num = 399,
				},
				{
					Value = 200007,
					Num = 63,
				},
			},
		},
		{
			Level = 8,
			Info = 920519,
			Ability = {
				{
					Value = 200001,
					Num = 456,
				},
				{
					Value = 200007,
					Num = 72,
				},
			},
			SkillList = {
				{
					Id = 100565,
					Value = -5,
				},
			},
		},
		{
			Level = 9,
			Info = 920519,
			Ability = {
				{
					Value = 200001,
					Num = 513,
				},
				{
					Value = 200007,
					Num = 81,
				},
			},
			SkillList = {
				{
					Id = 100565,
					Value = -5,
				},
			},
		},
		{
			Level = 10,
			Info = 920519,
			Ability = {
				{
					Value = 200001,
					Num = 570,
				},
				{
					Value = 200007,
					Num = 90,
				},
			},
			SkillList = {
				{
					Id = 100565,
					Value = -5,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id307] =
{
	Character = 221004,
	Rarity = 3,
	UpgradeId = 930110,
	LevelList = {
		{
			Level = 1,
			Info = 920520,
			Ability = {
				{
					Value = 200001,
					Num = 57,
				},
				{
					Value = 200008,
					Num = 6,
				},
			},
		},
		{
			Level = 2,
			Info = 920520,
			Ability = {
				{
					Value = 200001,
					Num = 114,
				},
				{
					Value = 200008,
					Num = 12,
				},
			},
		},
		{
			Level = 3,
			Info = 920520,
			Ability = {
				{
					Value = 200001,
					Num = 171,
				},
				{
					Value = 200008,
					Num = 18,
				},
			},
		},
		{
			Level = 4,
			Info = 920520,
			Ability = {
				{
					Value = 200001,
					Num = 228,
				},
				{
					Value = 200008,
					Num = 24,
				},
			},
		},
		{
			Level = 5,
			Info = 920520,
			Ability = {
				{
					Value = 200001,
					Num = 285,
				},
				{
					Value = 200008,
					Num = 30,
				},
			},
		},
		{
			Level = 6,
			Info = 920520,
			Ability = {
				{
					Value = 200001,
					Num = 342,
				},
				{
					Value = 200008,
					Num = 36,
				},
			},
		},
		{
			Level = 7,
			Info = 920520,
			Ability = {
				{
					Value = 200001,
					Num = 399,
				},
				{
					Value = 200008,
					Num = 42,
				},
			},
		},
		{
			Level = 8,
			Info = 920520,
			Ability = {
				{
					Value = 200001,
					Num = 456,
				},
				{
					Value = 200008,
					Num = 48,
				},
			},
			SkillList = {
				{
					Id = 100564,
					Value = -50,
				},
			},
		},
		{
			Level = 9,
			Info = 920520,
			Ability = {
				{
					Value = 200001,
					Num = 513,
				},
				{
					Value = 200008,
					Num = 54,
				},
			},
			SkillList = {
				{
					Id = 100564,
					Value = -50,
				},
			},
		},
		{
			Level = 10,
			Info = 920520,
			Ability = {
				{
					Value = 200001,
					Num = 570,
				},
				{
					Value = 200008,
					Num = 60,
				},
			},
			SkillList = {
				{
					Id = 100564,
					Value = -50,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id308] =
{
	Character = 221004,
	Rarity = 3,
	NeedChallenge = 145124,
	UpgradeId = 930111,
	LevelList = {
		{
			Level = 1,
			Info = 920521,
			Ability = {
				{
					Value = 200001,
					Num = 114,
				},
			},
			SkillList = {
				{
					Id = 100251,
					Value = 30,
				},
			},
		},
		{
			Level = 2,
			Info = 920521,
			Ability = {
				{
					Value = 200001,
					Num = 190,
				},
			},
			SkillList = {
				{
					Id = 100251,
					Value = 35,
				},
			},
		},
		{
			Level = 3,
			Info = 920521,
			Ability = {
				{
					Value = 200001,
					Num = 266,
				},
			},
			SkillList = {
				{
					Id = 100251,
					Value = 40,
				},
			},
		},
		{
			Level = 4,
			Info = 920521,
			Ability = {
				{
					Value = 200001,
					Num = 342,
				},
			},
			SkillList = {
				{
					Id = 100251,
					Value = 45,
				},
			},
		},
		{
			Level = 5,
			Info = 920521,
			Ability = {
				{
					Value = 200001,
					Num = 418,
				},
				{
					Value = 200003,
					Num = 25,
				},
			},
			SkillList = {
				{
					Id = 100251,
					Value = 50,
				},
			},
		},
		{
			Level = 6,
			Info = 920521,
			Ability = {
				{
					Value = 200001,
					Num = 494,
				},
				{
					Value = 200003,
					Num = 30,
				},
			},
			SkillList = {
				{
					Id = 100251,
					Value = 55,
				},
			},
		},
		{
			Level = 7,
			Info = 920521,
			Ability = {
				{
					Value = 200001,
					Num = 570,
				},
				{
					Value = 200003,
					Num = 35,
				},
			},
			SkillList = {
				{
					Id = 100251,
					Value = 60,
				},
			},
		},
		{
			Level = 8,
			Info = 920521,
			Ability = {
				{
					Value = 200001,
					Num = 646,
				},
				{
					Value = 200003,
					Num = 40,
				},
			},
			SkillList = {
				{
					Id = 100251,
					Value = 65,
				},
			},
		},
		{
			Level = 9,
			Info = 920521,
			Ability = {
				{
					Value = 200001,
					Num = 722,
				},
				{
					Value = 200003,
					Num = 45,
				},
			},
			SkillList = {
				{
					Id = 100251,
					Value = 70,
				},
			},
		},
		{
			Level = 10,
			Info = 920521,
			Ability = {
				{
					Value = 200001,
					Num = 798,
				},
				{
					Value = 200003,
					Num = 50,
				},
			},
			SkillList = {
				{
					Id = 100251,
					Value = 75,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id309] =
{
	Character = 221005,
	Rarity = 2,
	UpgradeId = 930005,
	LevelList = {
		{
			Level = 1,
			Info = 920522,
			Ability = {
				{
					Value = 200002,
					Num = 33,
				},
				{
					Value = 200005,
					Num = 6,
				},
			},
		},
		{
			Level = 2,
			Info = 920522,
			Ability = {
				{
					Value = 200002,
					Num = 66,
				},
				{
					Value = 200005,
					Num = 12,
				},
			},
		},
		{
			Level = 3,
			Info = 920522,
			Ability = {
				{
					Value = 200002,
					Num = 99,
				},
				{
					Value = 200005,
					Num = 18,
				},
			},
		},
		{
			Level = 4,
			Info = 920522,
			Ability = {
				{
					Value = 200002,
					Num = 132,
				},
				{
					Value = 200005,
					Num = 24,
				},
			},
		},
		{
			Level = 5,
			Info = 920522,
			Ability = {
				{
					Value = 200002,
					Num = 165,
				},
				{
					Value = 200005,
					Num = 30,
				},
			},
		},
		{
			Level = 6,
			Info = 920522,
			Ability = {
				{
					Value = 200002,
					Num = 198,
				},
				{
					Value = 200005,
					Num = 36,
				},
			},
		},
		{
			Level = 7,
			Info = 920522,
			Ability = {
				{
					Value = 200002,
					Num = 231,
				},
				{
					Value = 200005,
					Num = 42,
				},
			},
		},
		{
			Level = 8,
			Info = 920522,
			Ability = {
				{
					Value = 200002,
					Num = 264,
				},
				{
					Value = 200005,
					Num = 48,
				},
			},
			SkillList = {
				{
					Id = 100551,
					Value = 25,
				},
			},
		},
		{
			Level = 9,
			Info = 920522,
			Ability = {
				{
					Value = 200002,
					Num = 297,
				},
				{
					Value = 200005,
					Num = 54,
				},
			},
			SkillList = {
				{
					Id = 100551,
					Value = 25,
				},
			},
		},
		{
			Level = 10,
			Info = 920522,
			Ability = {
				{
					Value = 200002,
					Num = 330,
				},
				{
					Value = 200005,
					Num = 60,
				},
			},
			SkillList = {
				{
					Id = 100551,
					Value = 25,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id310] =
{
	Character = 221005,
	Rarity = 2,
	NeedChallenge = 145125,
	UpgradeId = 930026,
	LevelList = {
		{
			Level = 1,
			Info = 920523,
			Ability = {
				{
					Value = 200001,
					Num = 42,
				},
				{
					Value = 200007,
					Num = 3,
				},
			},
		},
		{
			Level = 2,
			Info = 920523,
			Ability = {
				{
					Value = 200001,
					Num = 84,
				},
				{
					Value = 200007,
					Num = 6,
				},
			},
		},
		{
			Level = 3,
			Info = 920523,
			Ability = {
				{
					Value = 200001,
					Num = 126,
				},
				{
					Value = 200007,
					Num = 9,
				},
			},
		},
		{
			Level = 4,
			Info = 920523,
			Ability = {
				{
					Value = 200001,
					Num = 168,
				},
				{
					Value = 200007,
					Num = 12,
				},
			},
		},
		{
			Level = 5,
			Info = 920523,
			Ability = {
				{
					Value = 200001,
					Num = 210,
				},
				{
					Value = 200007,
					Num = 15,
				},
			},
			SkillList = {
				{
					Id = 100652,
					Value = 5,
				},
			},
		},
		{
			Level = 6,
			Info = 920523,
			Ability = {
				{
					Value = 200001,
					Num = 252,
				},
				{
					Value = 200007,
					Num = 18,
				},
			},
			SkillList = {
				{
					Id = 100652,
					Value = 5,
				},
			},
		},
		{
			Level = 7,
			Info = 920523,
			Ability = {
				{
					Value = 200001,
					Num = 294,
				},
				{
					Value = 200007,
					Num = 21,
				},
			},
			SkillList = {
				{
					Id = 100652,
					Value = 5,
				},
			},
		},
		{
			Level = 8,
			Info = 920523,
			Ability = {
				{
					Value = 200001,
					Num = 336,
				},
				{
					Value = 200007,
					Num = 24,
				},
			},
			SkillList = {
				{
					Id = 100652,
					Value = 5,
				},
			},
		},
		{
			Level = 9,
			Info = 920523,
			Ability = {
				{
					Value = 200001,
					Num = 378,
				},
				{
					Value = 200007,
					Num = 27,
				},
			},
			SkillList = {
				{
					Id = 100652,
					Value = 5,
				},
			},
		},
		{
			Level = 10,
			Info = 920523,
			Ability = {
				{
					Value = 200001,
					Num = 420,
				},
				{
					Value = 200007,
					Num = 30,
				},
			},
			SkillList = {
				{
					Id = 100652,
					Value = 5,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id312] =
{
	Character = 221006,
	Rarity = 2,
	UpgradeId = 930025,
	LevelList = {
		{
			Level = 1,
			Info = 920525,
			Ability = {
				{
					Value = 200001,
					Num = 42,
				},
				{
					Value = 200006,
					Num = 6,
				},
			},
		},
		{
			Level = 2,
			Info = 920525,
			Ability = {
				{
					Value = 200001,
					Num = 84,
				},
				{
					Value = 200006,
					Num = 12,
				},
			},
		},
		{
			Level = 3,
			Info = 920525,
			Ability = {
				{
					Value = 200001,
					Num = 126,
				},
				{
					Value = 200006,
					Num = 18,
				},
			},
		},
		{
			Level = 4,
			Info = 920525,
			Ability = {
				{
					Value = 200001,
					Num = 168,
				},
				{
					Value = 200006,
					Num = 24,
				},
			},
		},
		{
			Level = 5,
			Info = 920525,
			Ability = {
				{
					Value = 200001,
					Num = 210,
				},
				{
					Value = 200006,
					Num = 30,
				},
			},
		},
		{
			Level = 6,
			Info = 920525,
			Ability = {
				{
					Value = 200001,
					Num = 252,
				},
				{
					Value = 200006,
					Num = 36,
				},
			},
		},
		{
			Level = 7,
			Info = 920525,
			Ability = {
				{
					Value = 200001,
					Num = 294,
				},
				{
					Value = 200006,
					Num = 42,
				},
			},
		},
		{
			Level = 8,
			Info = 920525,
			Ability = {
				{
					Value = 200001,
					Num = 336,
				},
				{
					Value = 200006,
					Num = 48,
				},
			},
			SkillList = {
				{
					Id = 100562,
					Value = -5,
				},
			},
		},
		{
			Level = 9,
			Info = 920525,
			Ability = {
				{
					Value = 200001,
					Num = 378,
				},
				{
					Value = 200006,
					Num = 54,
				},
			},
			SkillList = {
				{
					Id = 100562,
					Value = -5,
				},
			},
		},
		{
			Level = 10,
			Info = 920525,
			Ability = {
				{
					Value = 200001,
					Num = 420,
				},
				{
					Value = 200006,
					Num = 60,
				},
			},
			SkillList = {
				{
					Id = 100562,
					Value = -5,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id313] =
{
	Character = 221006,
	Rarity = 2,
	NeedChallenge = 145126,
	UpgradeId = 930006,
	LevelList = {
		{
			Level = 1,
			Info = 920526,
			Ability = {
				{
					Value = 200002,
					Num = 33,
				},
				{
					Value = 200005,
					Num = 3,
				},
			},
		},
		{
			Level = 2,
			Info = 920526,
			Ability = {
				{
					Value = 200002,
					Num = 66,
				},
				{
					Value = 200005,
					Num = 6,
				},
			},
		},
		{
			Level = 3,
			Info = 920526,
			Ability = {
				{
					Value = 200002,
					Num = 99,
				},
				{
					Value = 200005,
					Num = 9,
				},
			},
		},
		{
			Level = 4,
			Info = 920526,
			Ability = {
				{
					Value = 200002,
					Num = 132,
				},
				{
					Value = 200005,
					Num = 12,
				},
			},
		},
		{
			Level = 5,
			Info = 920526,
			Ability = {
				{
					Value = 200002,
					Num = 165,
				},
				{
					Value = 200005,
					Num = 15,
				},
			},
			SkillList = {
				{
					Id = 100651,
					Value = 5,
				},
			},
		},
		{
			Level = 6,
			Info = 920526,
			Ability = {
				{
					Value = 200002,
					Num = 198,
				},
				{
					Value = 200005,
					Num = 18,
				},
			},
			SkillList = {
				{
					Id = 100651,
					Value = 5,
				},
			},
		},
		{
			Level = 7,
			Info = 920526,
			Ability = {
				{
					Value = 200002,
					Num = 231,
				},
				{
					Value = 200005,
					Num = 21,
				},
			},
			SkillList = {
				{
					Id = 100651,
					Value = 5,
				},
			},
		},
		{
			Level = 8,
			Info = 920526,
			Ability = {
				{
					Value = 200002,
					Num = 264,
				},
				{
					Value = 200005,
					Num = 24,
				},
			},
			SkillList = {
				{
					Id = 100651,
					Value = 5,
				},
			},
		},
		{
			Level = 9,
			Info = 920526,
			Ability = {
				{
					Value = 200002,
					Num = 297,
				},
				{
					Value = 200005,
					Num = 27,
				},
			},
			SkillList = {
				{
					Id = 100651,
					Value = 5,
				},
			},
		},
		{
			Level = 10,
			Info = 920526,
			Ability = {
				{
					Value = 200002,
					Num = 330,
				},
				{
					Value = 200005,
					Num = 30,
				},
			},
			SkillList = {
				{
					Id = 100651,
					Value = 5,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id315] =
{
	Character = 222001,
	Rarity = 4,
	UpgradeId = 930053,
	LevelList = {
		{
			Level = 1,
			Info = 920531,
			Ability = {
				{
					Value = 200002,
					Num = 54,
				},
				{
					Value = 200005,
					Num = 12,
				},
			},
		},
		{
			Level = 2,
			Info = 920531,
			Ability = {
				{
					Value = 200002,
					Num = 108,
				},
				{
					Value = 200005,
					Num = 24,
				},
			},
		},
		{
			Level = 3,
			Info = 920531,
			Ability = {
				{
					Value = 200002,
					Num = 162,
				},
				{
					Value = 200005,
					Num = 36,
				},
			},
		},
		{
			Level = 4,
			Info = 920531,
			Ability = {
				{
					Value = 200002,
					Num = 216,
				},
				{
					Value = 200005,
					Num = 48,
				},
			},
		},
		{
			Level = 5,
			Info = 920531,
			Ability = {
				{
					Value = 200002,
					Num = 270,
				},
				{
					Value = 200005,
					Num = 60,
				},
			},
			SkillList = {
				{
					Id = 100652,
					Value = 5,
				},
			},
		},
		{
			Level = 6,
			Info = 920531,
			Ability = {
				{
					Value = 200002,
					Num = 324,
				},
				{
					Value = 200005,
					Num = 72,
				},
			},
			SkillList = {
				{
					Id = 100652,
					Value = 5,
				},
			},
		},
		{
			Level = 7,
			Info = 920531,
			Ability = {
				{
					Value = 200002,
					Num = 378,
				},
				{
					Value = 200005,
					Num = 84,
				},
			},
			SkillList = {
				{
					Id = 100652,
					Value = 5,
				},
			},
		},
		{
			Level = 8,
			Info = 920531,
			Ability = {
				{
					Value = 200002,
					Num = 432,
				},
				{
					Value = 200005,
					Num = 96,
				},
			},
			SkillList = {
				{
					Id = 100652,
					Value = 5,
				},
			},
		},
		{
			Level = 9,
			Info = 920531,
			Ability = {
				{
					Value = 200002,
					Num = 486,
				},
				{
					Value = 200005,
					Num = 108,
				},
			},
			SkillList = {
				{
					Id = 100652,
					Value = 5,
				},
			},
		},
		{
			Level = 10,
			Info = 920531,
			Ability = {
				{
					Value = 200002,
					Num = 540,
				},
				{
					Value = 200005,
					Num = 120,
				},
			},
			SkillList = {
				{
					Id = 100652,
					Value = 5,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id316] =
{
	Character = 222001,
	Rarity = 4,
	UpgradeId = 930054,
	LevelList = {
		{
			Level = 1,
			Info = 920532,
			Ability = {
				{
					Value = 200002,
					Num = 54,
				},
				{
					Value = 200006,
					Num = 9,
				},
			},
		},
		{
			Level = 2,
			Info = 920532,
			Ability = {
				{
					Value = 200002,
					Num = 108,
				},
				{
					Value = 200006,
					Num = 18,
				},
			},
		},
		{
			Level = 3,
			Info = 920532,
			Ability = {
				{
					Value = 200002,
					Num = 162,
				},
				{
					Value = 200006,
					Num = 27,
				},
			},
		},
		{
			Level = 4,
			Info = 920532,
			Ability = {
				{
					Value = 200002,
					Num = 216,
				},
				{
					Value = 200006,
					Num = 36,
				},
			},
		},
		{
			Level = 5,
			Info = 920532,
			Ability = {
				{
					Value = 200002,
					Num = 270,
				},
				{
					Value = 200006,
					Num = 45,
				},
			},
		},
		{
			Level = 6,
			Info = 920532,
			Ability = {
				{
					Value = 200002,
					Num = 324,
				},
				{
					Value = 200006,
					Num = 54,
				},
			},
		},
		{
			Level = 7,
			Info = 920532,
			Ability = {
				{
					Value = 200002,
					Num = 378,
				},
				{
					Value = 200006,
					Num = 63,
				},
			},
		},
		{
			Level = 8,
			Info = 920532,
			Ability = {
				{
					Value = 200002,
					Num = 432,
				},
				{
					Value = 200006,
					Num = 72,
				},
			},
			SkillList = {
				{
					Id = 101502,
					Value = -4,
				},
			},
		},
		{
			Level = 9,
			Info = 920532,
			Ability = {
				{
					Value = 200002,
					Num = 486,
				},
				{
					Value = 200006,
					Num = 81,
				},
			},
			SkillList = {
				{
					Id = 101502,
					Value = -4,
				},
			},
		},
		{
			Level = 10,
			Info = 920532,
			Ability = {
				{
					Value = 200002,
					Num = 540,
				},
				{
					Value = 200006,
					Num = 90,
				},
			},
			SkillList = {
				{
					Id = 101502,
					Value = -4,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id317] =
{
	Character = 222001,
	Rarity = 4,
	NeedChallenge = 145127,
	UpgradeId = 930075,
	LevelList = {
		{
			Level = 1,
			Info = 920533,
			Ability = {
				{
					Value = 200001,
					Num = 150,
				},
			},
		},
		{
			Level = 2,
			Info = 920533,
			Ability = {
				{
					Value = 200001,
					Num = 250,
				},
			},
		},
		{
			Level = 3,
			Info = 920533,
			Ability = {
				{
					Value = 200001,
					Num = 350,
				},
			},
		},
		{
			Level = 4,
			Info = 920533,
			Ability = {
				{
					Value = 200001,
					Num = 450,
				},
			},
		},
		{
			Level = 5,
			Info = 920533,
			Ability = {
				{
					Value = 200001,
					Num = 550,
				},
				{
					Value = 200003,
					Num = 25,
				},
			},
		},
		{
			Level = 6,
			Info = 920533,
			Ability = {
				{
					Value = 200001,
					Num = 650,
				},
				{
					Value = 200003,
					Num = 30,
				},
			},
		},
		{
			Level = 7,
			Info = 920533,
			Ability = {
				{
					Value = 200001,
					Num = 750,
				},
				{
					Value = 200003,
					Num = 35,
				},
			},
		},
		{
			Level = 8,
			Info = 920533,
			Ability = {
				{
					Value = 200001,
					Num = 850,
				},
				{
					Value = 200003,
					Num = 40,
				},
			},
			SkillList = {
				{
					Id = 101746,
					Value = 5,
				},
			},
		},
		{
			Level = 9,
			Info = 920533,
			Ability = {
				{
					Value = 200001,
					Num = 950,
				},
				{
					Value = 200003,
					Num = 45,
				},
			},
			SkillList = {
				{
					Id = 101746,
					Value = 5,
				},
			},
		},
		{
			Level = 10,
			Info = 920533,
			Ability = {
				{
					Value = 200001,
					Num = 1050,
				},
				{
					Value = 200003,
					Num = 50,
				},
			},
			SkillList = {
				{
					Id = 101746,
					Value = 5,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id318] =
{
	Character = 222021,
	Rarity = 4,
	UpgradeId = 930073,
	LevelList = {
		{
			Level = 1,
			Info = 920534,
			Ability = {
				{
					Value = 200001,
					Num = 69,
				},
				{
					Value = 200006,
					Num = 12,
				},
			},
		},
		{
			Level = 2,
			Info = 920534,
			Ability = {
				{
					Value = 200001,
					Num = 138,
				},
				{
					Value = 200006,
					Num = 24,
				},
			},
		},
		{
			Level = 3,
			Info = 920534,
			Ability = {
				{
					Value = 200001,
					Num = 207,
				},
				{
					Value = 200006,
					Num = 36,
				},
			},
		},
		{
			Level = 4,
			Info = 920534,
			Ability = {
				{
					Value = 200001,
					Num = 276,
				},
				{
					Value = 200006,
					Num = 48,
				},
			},
		},
		{
			Level = 5,
			Info = 920534,
			Ability = {
				{
					Value = 200001,
					Num = 345,
				},
				{
					Value = 200006,
					Num = 60,
				},
			},
			SkillList = {
				{
					Id = 100651,
					Value = 5,
				},
			},
		},
		{
			Level = 6,
			Info = 920534,
			Ability = {
				{
					Value = 200001,
					Num = 414,
				},
				{
					Value = 200006,
					Num = 72,
				},
			},
			SkillList = {
				{
					Id = 100651,
					Value = 5,
				},
			},
		},
		{
			Level = 7,
			Info = 920534,
			Ability = {
				{
					Value = 200001,
					Num = 483,
				},
				{
					Value = 200006,
					Num = 84,
				},
			},
			SkillList = {
				{
					Id = 100651,
					Value = 5,
				},
			},
		},
		{
			Level = 8,
			Info = 920534,
			Ability = {
				{
					Value = 200001,
					Num = 552,
				},
				{
					Value = 200006,
					Num = 96,
				},
			},
			SkillList = {
				{
					Id = 100651,
					Value = 5,
				},
			},
		},
		{
			Level = 9,
			Info = 920534,
			Ability = {
				{
					Value = 200001,
					Num = 621,
				},
				{
					Value = 200006,
					Num = 108,
				},
			},
			SkillList = {
				{
					Id = 100651,
					Value = 5,
				},
			},
		},
		{
			Level = 10,
			Info = 920534,
			Ability = {
				{
					Value = 200001,
					Num = 690,
				},
				{
					Value = 200006,
					Num = 120,
				},
			},
			SkillList = {
				{
					Id = 100651,
					Value = 5,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id319] =
{
	Character = 222021,
	Rarity = 4,
	UpgradeId = 930054,
	LevelList = {
		{
			Level = 1,
			Info = 920535,
			Ability = {
				{
					Value = 200002,
					Num = 60,
				},
				{
					Value = 200005,
					Num = 9,
				},
			},
		},
		{
			Level = 2,
			Info = 920535,
			Ability = {
				{
					Value = 200002,
					Num = 120,
				},
				{
					Value = 200005,
					Num = 18,
				},
			},
		},
		{
			Level = 3,
			Info = 920535,
			Ability = {
				{
					Value = 200002,
					Num = 180,
				},
				{
					Value = 200005,
					Num = 27,
				},
			},
		},
		{
			Level = 4,
			Info = 920535,
			Ability = {
				{
					Value = 200002,
					Num = 240,
				},
				{
					Value = 200005,
					Num = 36,
				},
			},
		},
		{
			Level = 5,
			Info = 920535,
			Ability = {
				{
					Value = 200002,
					Num = 300,
				},
				{
					Value = 200005,
					Num = 45,
				},
			},
		},
		{
			Level = 6,
			Info = 920535,
			Ability = {
				{
					Value = 200002,
					Num = 360,
				},
				{
					Value = 200005,
					Num = 54,
				},
			},
		},
		{
			Level = 7,
			Info = 920535,
			Ability = {
				{
					Value = 200002,
					Num = 420,
				},
				{
					Value = 200005,
					Num = 63,
				},
			},
		},
		{
			Level = 8,
			Info = 920535,
			Ability = {
				{
					Value = 200002,
					Num = 480,
				},
				{
					Value = 200005,
					Num = 72,
				},
			},
			SkillList = {
				{
					Id = 100553,
					Value = 25,
				},
			},
		},
		{
			Level = 9,
			Info = 920535,
			Ability = {
				{
					Value = 200002,
					Num = 540,
				},
				{
					Value = 200005,
					Num = 81,
				},
			},
			SkillList = {
				{
					Id = 100553,
					Value = 25,
				},
			},
		},
		{
			Level = 10,
			Info = 920535,
			Ability = {
				{
					Value = 200002,
					Num = 600,
				},
				{
					Value = 200005,
					Num = 90,
				},
			},
			SkillList = {
				{
					Id = 100553,
					Value = 25,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id320] =
{
	Character = 222021,
	Rarity = 4,
	NeedChallenge = 145128,
	UpgradeId = 930055,
	LevelList = {
		{
			Level = 1,
			Info = 920536,
			Ability = {
				{
					Value = 200002,
					Num = 120,
				},
			},
		},
		{
			Level = 2,
			Info = 920536,
			Ability = {
				{
					Value = 200002,
					Num = 200,
				},
			},
		},
		{
			Level = 3,
			Info = 920536,
			Ability = {
				{
					Value = 200002,
					Num = 280,
				},
			},
		},
		{
			Level = 4,
			Info = 920536,
			Ability = {
				{
					Value = 200002,
					Num = 360,
				},
			},
		},
		{
			Level = 5,
			Info = 920536,
			Ability = {
				{
					Value = 200002,
					Num = 440,
				},
				{
					Value = 200003,
					Num = 25,
				},
			},
		},
		{
			Level = 6,
			Info = 920536,
			Ability = {
				{
					Value = 200002,
					Num = 520,
				},
				{
					Value = 200003,
					Num = 30,
				},
			},
		},
		{
			Level = 7,
			Info = 920536,
			Ability = {
				{
					Value = 200002,
					Num = 600,
				},
				{
					Value = 200003,
					Num = 35,
				},
			},
		},
		{
			Level = 8,
			Info = 920536,
			Ability = {
				{
					Value = 200002,
					Num = 680,
				},
				{
					Value = 200003,
					Num = 40,
				},
			},
			SkillList = {
				{
					Id = 101762,
					Value = 5,
				},
			},
		},
		{
			Level = 9,
			Info = 920536,
			Ability = {
				{
					Value = 200002,
					Num = 760,
				},
				{
					Value = 200003,
					Num = 45,
				},
			},
			SkillList = {
				{
					Id = 101762,
					Value = 5,
				},
			},
		},
		{
			Level = 10,
			Info = 920536,
			Ability = {
				{
					Value = 200002,
					Num = 840,
				},
				{
					Value = 200003,
					Num = 50,
				},
			},
			SkillList = {
				{
					Id = 101762,
					Value = 5,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id321] =
{
	Character = 222041,
	Rarity = 4,
	UpgradeId = 930073,
	LevelList = {
		{
			Level = 1,
			Info = 920537,
			Ability = {
				{
					Value = 200001,
					Num = 69,
				},
				{
					Value = 200005,
					Num = 21,
				},
			},
		},
		{
			Level = 2,
			Info = 920537,
			Ability = {
				{
					Value = 200001,
					Num = 138,
				},
				{
					Value = 200005,
					Num = 42,
				},
			},
		},
		{
			Level = 3,
			Info = 920537,
			Ability = {
				{
					Value = 200001,
					Num = 207,
				},
				{
					Value = 200005,
					Num = 63,
				},
			},
		},
		{
			Level = 4,
			Info = 920537,
			Ability = {
				{
					Value = 200001,
					Num = 276,
				},
				{
					Value = 200005,
					Num = 84,
				},
			},
		},
		{
			Level = 5,
			Info = 920537,
			Ability = {
				{
					Value = 200001,
					Num = 345,
				},
				{
					Value = 200005,
					Num = 105,
				},
			},
		},
		{
			Level = 6,
			Info = 920537,
			Ability = {
				{
					Value = 200001,
					Num = 414,
				},
				{
					Value = 200005,
					Num = 126,
				},
			},
		},
		{
			Level = 7,
			Info = 920537,
			Ability = {
				{
					Value = 200001,
					Num = 483,
				},
				{
					Value = 200005,
					Num = 147,
				},
			},
		},
		{
			Level = 8,
			Info = 920537,
			Ability = {
				{
					Value = 200001,
					Num = 552,
				},
				{
					Value = 200005,
					Num = 168,
				},
			},
			SkillList = {
				{
					Id = 101786,
					Value = 100,
				},
			},
		},
		{
			Level = 9,
			Info = 920537,
			Ability = {
				{
					Value = 200001,
					Num = 621,
				},
				{
					Value = 200005,
					Num = 189,
				},
			},
			SkillList = {
				{
					Id = 101786,
					Value = 100,
				},
			},
		},
		{
			Level = 10,
			Info = 920537,
			Ability = {
				{
					Value = 200001,
					Num = 690,
				},
				{
					Value = 200005,
					Num = 210,
				},
			},
			SkillList = {
				{
					Id = 101786,
					Value = 100,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id322] =
{
	Character = 222041,
	Rarity = 4,
	UpgradeId = 930054,
	LevelList = {
		{
			Level = 1,
			Info = 920538,
			Ability = {
				{
					Value = 200002,
					Num = 60,
				},
				{
					Value = 200005,
					Num = 21,
				},
			},
		},
		{
			Level = 2,
			Info = 920538,
			Ability = {
				{
					Value = 200002,
					Num = 120,
				},
				{
					Value = 200005,
					Num = 42,
				},
			},
		},
		{
			Level = 3,
			Info = 920538,
			Ability = {
				{
					Value = 200002,
					Num = 180,
				},
				{
					Value = 200005,
					Num = 63,
				},
			},
		},
		{
			Level = 4,
			Info = 920538,
			Ability = {
				{
					Value = 200002,
					Num = 240,
				},
				{
					Value = 200005,
					Num = 84,
				},
			},
		},
		{
			Level = 5,
			Info = 920538,
			Ability = {
				{
					Value = 200002,
					Num = 300,
				},
				{
					Value = 200005,
					Num = 105,
				},
			},
		},
		{
			Level = 6,
			Info = 920538,
			Ability = {
				{
					Value = 200002,
					Num = 360,
				},
				{
					Value = 200005,
					Num = 126,
				},
			},
		},
		{
			Level = 7,
			Info = 920538,
			Ability = {
				{
					Value = 200002,
					Num = 420,
				},
				{
					Value = 200005,
					Num = 147,
				},
			},
		},
		{
			Level = 8,
			Info = 920538,
			Ability = {
				{
					Value = 200002,
					Num = 480,
				},
				{
					Value = 200005,
					Num = 168,
				},
			},
			SkillList = {
				{
					Id = 100551,
					Value = 25,
				},
			},
		},
		{
			Level = 9,
			Info = 920538,
			Ability = {
				{
					Value = 200002,
					Num = 540,
				},
				{
					Value = 200005,
					Num = 189,
				},
			},
			SkillList = {
				{
					Id = 100551,
					Value = 25,
				},
			},
		},
		{
			Level = 10,
			Info = 920538,
			Ability = {
				{
					Value = 200002,
					Num = 600,
				},
				{
					Value = 200005,
					Num = 210,
				},
			},
			SkillList = {
				{
					Id = 100551,
					Value = 25,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id323] =
{
	Character = 222041,
	Rarity = 4,
	NeedChallenge = 145129,
	UpgradeId = 930055,
	LevelList = {
		{
			Level = 1,
			Info = 920539,
			Ability = {
				{
					Value = 200002,
					Num = 120,
				},
			},
		},
		{
			Level = 2,
			Info = 920539,
			Ability = {
				{
					Value = 200002,
					Num = 200,
				},
			},
		},
		{
			Level = 3,
			Info = 920539,
			Ability = {
				{
					Value = 200002,
					Num = 280,
				},
			},
		},
		{
			Level = 4,
			Info = 920539,
			Ability = {
				{
					Value = 200002,
					Num = 360,
				},
			},
		},
		{
			Level = 5,
			Info = 920539,
			Ability = {
				{
					Value = 200002,
					Num = 440,
				},
				{
					Value = 200004,
					Num = 25,
				},
			},
		},
		{
			Level = 6,
			Info = 920539,
			Ability = {
				{
					Value = 200002,
					Num = 520,
				},
				{
					Value = 200004,
					Num = 30,
				},
			},
		},
		{
			Level = 7,
			Info = 920539,
			Ability = {
				{
					Value = 200002,
					Num = 600,
				},
				{
					Value = 200004,
					Num = 35,
				},
			},
		},
		{
			Level = 8,
			Info = 920539,
			Ability = {
				{
					Value = 200002,
					Num = 680,
				},
				{
					Value = 200004,
					Num = 40,
				},
			},
			SkillList = {
				{
					Id = 101731,
					Value = 900,
				},
			},
		},
		{
			Level = 9,
			Info = 920539,
			Ability = {
				{
					Value = 200002,
					Num = 760,
				},
				{
					Value = 200004,
					Num = 45,
				},
			},
			SkillList = {
				{
					Id = 101731,
					Value = 900,
				},
			},
		},
		{
			Level = 10,
			Info = 920539,
			Ability = {
				{
					Value = 200002,
					Num = 840,
				},
				{
					Value = 200004,
					Num = 50,
				},
			},
			SkillList = {
				{
					Id = 101731,
					Value = 900,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id324] =
{
	Character = 222042,
	Rarity = 4,
	UpgradeId = 930053,
	LevelList = {
		{
			Level = 1,
			Info = 920540,
			Ability = {
				{
					Value = 200002,
					Num = 54,
				},
				{
					Value = 200006,
					Num = 12,
				},
			},
		},
		{
			Level = 2,
			Info = 920540,
			Ability = {
				{
					Value = 200002,
					Num = 108,
				},
				{
					Value = 200006,
					Num = 24,
				},
			},
		},
		{
			Level = 3,
			Info = 920540,
			Ability = {
				{
					Value = 200002,
					Num = 162,
				},
				{
					Value = 200006,
					Num = 36,
				},
			},
		},
		{
			Level = 4,
			Info = 920540,
			Ability = {
				{
					Value = 200002,
					Num = 216,
				},
				{
					Value = 200006,
					Num = 48,
				},
			},
		},
		{
			Level = 5,
			Info = 920540,
			Ability = {
				{
					Value = 200002,
					Num = 270,
				},
				{
					Value = 200006,
					Num = 60,
				},
			},
		},
		{
			Level = 6,
			Info = 920540,
			Ability = {
				{
					Value = 200002,
					Num = 324,
				},
				{
					Value = 200006,
					Num = 72,
				},
			},
		},
		{
			Level = 7,
			Info = 920540,
			Ability = {
				{
					Value = 200002,
					Num = 378,
				},
				{
					Value = 200006,
					Num = 84,
				},
			},
		},
		{
			Level = 8,
			Info = 920540,
			Ability = {
				{
					Value = 200002,
					Num = 432,
				},
				{
					Value = 200006,
					Num = 96,
				},
			},
			SkillList = {
				{
					Id = 101738,
					Value = 15,
				},
			},
		},
		{
			Level = 9,
			Info = 920540,
			Ability = {
				{
					Value = 200002,
					Num = 486,
				},
				{
					Value = 200006,
					Num = 108,
				},
			},
			SkillList = {
				{
					Id = 101738,
					Value = 15,
				},
			},
		},
		{
			Level = 10,
			Info = 920540,
			Ability = {
				{
					Value = 200002,
					Num = 540,
				},
				{
					Value = 200006,
					Num = 120,
				},
			},
			SkillList = {
				{
					Id = 101738,
					Value = 15,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id325] =
{
	Character = 222042,
	Rarity = 4,
	UpgradeId = 930054,
	LevelList = {
		{
			Level = 1,
			Info = 920541,
			Ability = {
				{
					Value = 200002,
					Num = 54,
				},
				{
					Value = 200008,
					Num = 12,
				},
			},
		},
		{
			Level = 2,
			Info = 920541,
			Ability = {
				{
					Value = 200002,
					Num = 108,
				},
				{
					Value = 200008,
					Num = 24,
				},
			},
		},
		{
			Level = 3,
			Info = 920541,
			Ability = {
				{
					Value = 200002,
					Num = 162,
				},
				{
					Value = 200008,
					Num = 36,
				},
			},
		},
		{
			Level = 4,
			Info = 920541,
			Ability = {
				{
					Value = 200002,
					Num = 216,
				},
				{
					Value = 200008,
					Num = 48,
				},
			},
		},
		{
			Level = 5,
			Info = 920541,
			Ability = {
				{
					Value = 200002,
					Num = 270,
				},
				{
					Value = 200008,
					Num = 60,
				},
			},
		},
		{
			Level = 6,
			Info = 920541,
			Ability = {
				{
					Value = 200002,
					Num = 324,
				},
				{
					Value = 200008,
					Num = 72,
				},
			},
		},
		{
			Level = 7,
			Info = 920541,
			Ability = {
				{
					Value = 200002,
					Num = 378,
				},
				{
					Value = 200008,
					Num = 84,
				},
			},
		},
		{
			Level = 8,
			Info = 920541,
			Ability = {
				{
					Value = 200002,
					Num = 432,
				},
				{
					Value = 200008,
					Num = 96,
				},
			},
			SkillList = {
				{
					Id = 101738,
					Value = 15,
				},
			},
		},
		{
			Level = 9,
			Info = 920541,
			Ability = {
				{
					Value = 200002,
					Num = 486,
				},
				{
					Value = 200008,
					Num = 108,
				},
			},
			SkillList = {
				{
					Id = 101738,
					Value = 15,
				},
			},
		},
		{
			Level = 10,
			Info = 920541,
			Ability = {
				{
					Value = 200002,
					Num = 540,
				},
				{
					Value = 200008,
					Num = 120,
				},
			},
			SkillList = {
				{
					Id = 101738,
					Value = 15,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id326] =
{
	Character = 222042,
	Rarity = 4,
	NeedChallenge = 145130,
	UpgradeId = 930075,
	LevelList = {
		{
			Level = 1,
			Info = 920542,
			Ability = {
				{
					Value = 200001,
					Num = 144,
				},
			},
		},
		{
			Level = 2,
			Info = 920542,
			Ability = {
				{
					Value = 200001,
					Num = 240,
				},
			},
		},
		{
			Level = 3,
			Info = 920542,
			Ability = {
				{
					Value = 200001,
					Num = 336,
				},
			},
		},
		{
			Level = 4,
			Info = 920542,
			Ability = {
				{
					Value = 200001,
					Num = 432,
				},
			},
		},
		{
			Level = 5,
			Info = 920542,
			Ability = {
				{
					Value = 200001,
					Num = 528,
				},
				{
					Value = 200003,
					Num = 25,
				},
			},
		},
		{
			Level = 6,
			Info = 920542,
			Ability = {
				{
					Value = 200001,
					Num = 624,
				},
				{
					Value = 200003,
					Num = 30,
				},
			},
		},
		{
			Level = 7,
			Info = 920542,
			Ability = {
				{
					Value = 200001,
					Num = 720,
				},
				{
					Value = 200003,
					Num = 35,
				},
			},
		},
		{
			Level = 8,
			Info = 920542,
			Ability = {
				{
					Value = 200001,
					Num = 816,
				},
				{
					Value = 200003,
					Num = 40,
				},
			},
			SkillList = {
				{
					Id = 100728,
					Value = 2,
				},
			},
		},
		{
			Level = 9,
			Info = 920542,
			Ability = {
				{
					Value = 200001,
					Num = 912,
				},
				{
					Value = 200003,
					Num = 45,
				},
			},
			SkillList = {
				{
					Id = 100728,
					Value = 2,
				},
			},
		},
		{
			Level = 10,
			Info = 920542,
			Ability = {
				{
					Value = 200001,
					Num = 1008,
				},
				{
					Value = 200003,
					Num = 50,
				},
			},
			SkillList = {
				{
					Id = 100728,
					Value = 2,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id327] =
{
	Character = 222043,
	Rarity = 4,
	UpgradeId = 930073,
	LevelList = {
		{
			Level = 1,
			Info = 920543,
			Ability = {
				{
					Value = 200001,
					Num = 75,
				},
				{
					Value = 200007,
					Num = 12,
				},
			},
		},
		{
			Level = 2,
			Info = 920543,
			Ability = {
				{
					Value = 200001,
					Num = 150,
				},
				{
					Value = 200007,
					Num = 24,
				},
			},
		},
		{
			Level = 3,
			Info = 920543,
			Ability = {
				{
					Value = 200001,
					Num = 225,
				},
				{
					Value = 200007,
					Num = 36,
				},
			},
		},
		{
			Level = 4,
			Info = 920543,
			Ability = {
				{
					Value = 200001,
					Num = 300,
				},
				{
					Value = 200007,
					Num = 48,
				},
			},
		},
		{
			Level = 5,
			Info = 920543,
			Ability = {
				{
					Value = 200001,
					Num = 375,
				},
				{
					Value = 200007,
					Num = 60,
				},
			},
		},
		{
			Level = 6,
			Info = 920543,
			Ability = {
				{
					Value = 200001,
					Num = 450,
				},
				{
					Value = 200007,
					Num = 72,
				},
			},
		},
		{
			Level = 7,
			Info = 920543,
			Ability = {
				{
					Value = 200001,
					Num = 525,
				},
				{
					Value = 200007,
					Num = 84,
				},
			},
		},
		{
			Level = 8,
			Info = 920543,
			Ability = {
				{
					Value = 200001,
					Num = 600,
				},
				{
					Value = 200007,
					Num = 96,
				},
			},
			SkillList = {
				{
					Id = 100564,
					Value = -5,
				},
			},
		},
		{
			Level = 9,
			Info = 920543,
			Ability = {
				{
					Value = 200001,
					Num = 675,
				},
				{
					Value = 200007,
					Num = 108,
				},
			},
			SkillList = {
				{
					Id = 100564,
					Value = -5,
				},
			},
		},
		{
			Level = 10,
			Info = 920543,
			Ability = {
				{
					Value = 200001,
					Num = 750,
				},
				{
					Value = 200007,
					Num = 120,
				},
			},
			SkillList = {
				{
					Id = 100564,
					Value = -5,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id328] =
{
	Character = 222043,
	Rarity = 4,
	UpgradeId = 930054,
	LevelList = {
		{
			Level = 1,
			Info = 920544,
			Ability = {
				{
					Value = 200002,
					Num = 54,
				},
				{
					Value = 200005,
					Num = 9,
				},
			},
		},
		{
			Level = 2,
			Info = 920544,
			Ability = {
				{
					Value = 200002,
					Num = 108,
				},
				{
					Value = 200005,
					Num = 18,
				},
			},
		},
		{
			Level = 3,
			Info = 920544,
			Ability = {
				{
					Value = 200002,
					Num = 162,
				},
				{
					Value = 200005,
					Num = 27,
				},
			},
		},
		{
			Level = 4,
			Info = 920544,
			Ability = {
				{
					Value = 200002,
					Num = 216,
				},
				{
					Value = 200005,
					Num = 36,
				},
			},
		},
		{
			Level = 5,
			Info = 920544,
			Ability = {
				{
					Value = 200002,
					Num = 270,
				},
				{
					Value = 200005,
					Num = 45,
				},
			},
		},
		{
			Level = 6,
			Info = 920544,
			Ability = {
				{
					Value = 200002,
					Num = 324,
				},
				{
					Value = 200005,
					Num = 54,
				},
			},
		},
		{
			Level = 7,
			Info = 920544,
			Ability = {
				{
					Value = 200002,
					Num = 378,
				},
				{
					Value = 200005,
					Num = 63,
				},
			},
		},
		{
			Level = 8,
			Info = 920544,
			Ability = {
				{
					Value = 200002,
					Num = 432,
				},
				{
					Value = 200005,
					Num = 72,
				},
			},
			SkillList = {
				{
					Id = 101503,
					Value = -22,
				},
			},
		},
		{
			Level = 9,
			Info = 920544,
			Ability = {
				{
					Value = 200002,
					Num = 486,
				},
				{
					Value = 200005,
					Num = 81,
				},
			},
			SkillList = {
				{
					Id = 101503,
					Value = -22,
				},
			},
		},
		{
			Level = 10,
			Info = 920544,
			Ability = {
				{
					Value = 200002,
					Num = 540,
				},
				{
					Value = 200005,
					Num = 90,
				},
			},
			SkillList = {
				{
					Id = 101503,
					Value = -22,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id329] =
{
	Character = 222043,
	Rarity = 4,
	NeedChallenge = 145131,
	UpgradeId = 930055,
	LevelList = {
		{
			Level = 1,
			Info = 920545,
			Ability = {
				{
					Value = 200002,
					Num = 108,
				},
			},
		},
		{
			Level = 2,
			Info = 920545,
			Ability = {
				{
					Value = 200002,
					Num = 180,
				},
			},
		},
		{
			Level = 3,
			Info = 920545,
			Ability = {
				{
					Value = 200002,
					Num = 252,
				},
			},
		},
		{
			Level = 4,
			Info = 920545,
			Ability = {
				{
					Value = 200002,
					Num = 324,
				},
			},
		},
		{
			Level = 5,
			Info = 920545,
			Ability = {
				{
					Value = 200002,
					Num = 396,
				},
				{
					Value = 200001,
					Num = 176,
				},
			},
		},
		{
			Level = 6,
			Info = 920545,
			Ability = {
				{
					Value = 200002,
					Num = 468,
				},
				{
					Value = 200001,
					Num = 208,
				},
			},
		},
		{
			Level = 7,
			Info = 920545,
			Ability = {
				{
					Value = 200002,
					Num = 540,
				},
				{
					Value = 200001,
					Num = 240,
				},
			},
		},
		{
			Level = 8,
			Info = 920545,
			Ability = {
				{
					Value = 200002,
					Num = 612,
				},
				{
					Value = 200001,
					Num = 272,
				},
			},
			SkillList = {
				{
					Id = 101761,
					Value = 75,
				},
			},
		},
		{
			Level = 9,
			Info = 920545,
			Ability = {
				{
					Value = 200002,
					Num = 684,
				},
				{
					Value = 200001,
					Num = 304,
				},
			},
			SkillList = {
				{
					Id = 101761,
					Value = 75,
				},
			},
		},
		{
			Level = 10,
			Info = 920545,
			Ability = {
				{
					Value = 200002,
					Num = 756,
				},
				{
					Value = 200001,
					Num = 336,
				},
			},
			SkillList = {
				{
					Id = 101761,
					Value = 75,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id330] =
{
	Character = 222044,
	Rarity = 4,
	UpgradeId = 930073,
	LevelList = {
		{
			Level = 1,
			Info = 920547,
			Ability = {
				{
					Value = 200001,
					Num = 69,
				},
				{
					Value = 200008,
					Num = 12,
				},
			},
		},
		{
			Level = 2,
			Info = 920547,
			Ability = {
				{
					Value = 200001,
					Num = 138,
				},
				{
					Value = 200008,
					Num = 24,
				},
			},
		},
		{
			Level = 3,
			Info = 920547,
			Ability = {
				{
					Value = 200001,
					Num = 207,
				},
				{
					Value = 200008,
					Num = 36,
				},
			},
		},
		{
			Level = 4,
			Info = 920547,
			Ability = {
				{
					Value = 200001,
					Num = 276,
				},
				{
					Value = 200008,
					Num = 48,
				},
			},
		},
		{
			Level = 5,
			Info = 920547,
			Ability = {
				{
					Value = 200001,
					Num = 345,
				},
				{
					Value = 200008,
					Num = 60,
				},
			},
		},
		{
			Level = 6,
			Info = 920547,
			Ability = {
				{
					Value = 200001,
					Num = 414,
				},
				{
					Value = 200008,
					Num = 72,
				},
			},
		},
		{
			Level = 7,
			Info = 920547,
			Ability = {
				{
					Value = 200001,
					Num = 483,
				},
				{
					Value = 200008,
					Num = 84,
				},
			},
		},
		{
			Level = 8,
			Info = 920547,
			Ability = {
				{
					Value = 200001,
					Num = 552,
				},
				{
					Value = 200008,
					Num = 96,
				},
			},
			SkillList = {
				{
					Id = 100565,
					Value = -5,
				},
			},
		},
		{
			Level = 9,
			Info = 920547,
			Ability = {
				{
					Value = 200001,
					Num = 621,
				},
				{
					Value = 200008,
					Num = 108,
				},
			},
			SkillList = {
				{
					Id = 100565,
					Value = -5,
				},
			},
		},
		{
			Level = 10,
			Info = 920547,
			Ability = {
				{
					Value = 200001,
					Num = 690,
				},
				{
					Value = 200008,
					Num = 120,
				},
			},
			SkillList = {
				{
					Id = 100565,
					Value = -5,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id331] =
{
	Character = 222044,
	Rarity = 4,
	UpgradeId = 930054,
	LevelList = {
		{
			Level = 1,
			Info = 920546,
			Ability = {
				{
					Value = 200002,
					Num = 60,
				},
				{
					Value = 200006,
					Num = 9,
				},
			},
		},
		{
			Level = 2,
			Info = 920546,
			Ability = {
				{
					Value = 200002,
					Num = 120,
				},
				{
					Value = 200006,
					Num = 18,
				},
			},
		},
		{
			Level = 3,
			Info = 920546,
			Ability = {
				{
					Value = 200002,
					Num = 180,
				},
				{
					Value = 200006,
					Num = 27,
				},
			},
		},
		{
			Level = 4,
			Info = 920546,
			Ability = {
				{
					Value = 200002,
					Num = 240,
				},
				{
					Value = 200006,
					Num = 36,
				},
			},
		},
		{
			Level = 5,
			Info = 920546,
			Ability = {
				{
					Value = 200002,
					Num = 300,
				},
				{
					Value = 200006,
					Num = 45,
				},
			},
		},
		{
			Level = 6,
			Info = 920546,
			Ability = {
				{
					Value = 200002,
					Num = 360,
				},
				{
					Value = 200006,
					Num = 54,
				},
			},
		},
		{
			Level = 7,
			Info = 920546,
			Ability = {
				{
					Value = 200002,
					Num = 420,
				},
				{
					Value = 200006,
					Num = 63,
				},
			},
		},
		{
			Level = 8,
			Info = 920546,
			Ability = {
				{
					Value = 200002,
					Num = 480,
				},
				{
					Value = 200006,
					Num = 72,
				},
			},
			SkillList = {
				{
					Id = 100554,
					Value = 25,
				},
			},
		},
		{
			Level = 9,
			Info = 920546,
			Ability = {
				{
					Value = 200002,
					Num = 540,
				},
				{
					Value = 200006,
					Num = 81,
				},
			},
			SkillList = {
				{
					Id = 100554,
					Value = 25,
				},
			},
		},
		{
			Level = 10,
			Info = 920546,
			Ability = {
				{
					Value = 200002,
					Num = 600,
				},
				{
					Value = 200006,
					Num = 90,
				},
			},
			SkillList = {
				{
					Id = 100554,
					Value = 25,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id332] =
{
	Character = 222044,
	Rarity = 4,
	NeedChallenge = 145132,
	UpgradeId = 930055,
	LevelList = {
		{
			Level = 1,
			Info = 920548,
			Ability = {
				{
					Value = 200002,
					Num = 120,
				},
			},
		},
		{
			Level = 2,
			Info = 920548,
			Ability = {
				{
					Value = 200002,
					Num = 200,
				},
			},
		},
		{
			Level = 3,
			Info = 920548,
			Ability = {
				{
					Value = 200002,
					Num = 280,
				},
			},
		},
		{
			Level = 4,
			Info = 920548,
			Ability = {
				{
					Value = 200002,
					Num = 360,
				},
			},
		},
		{
			Level = 5,
			Info = 920548,
			Ability = {
				{
					Value = 200002,
					Num = 440,
				},
				{
					Value = 200004,
					Num = 5,
				},
			},
		},
		{
			Level = 6,
			Info = 920548,
			Ability = {
				{
					Value = 200002,
					Num = 520,
				},
				{
					Value = 200004,
					Num = 5,
				},
			},
		},
		{
			Level = 7,
			Info = 920548,
			Ability = {
				{
					Value = 200002,
					Num = 600,
				},
				{
					Value = 200004,
					Num = 5,
				},
			},
		},
		{
			Level = 8,
			Info = 920548,
			Ability = {
				{
					Value = 200002,
					Num = 680,
				},
				{
					Value = 200004,
					Num = 5,
				},
			},
			SkillList = {
				{
					Id = 101745,
					Value = 60,
				},
			},
		},
		{
			Level = 9,
			Info = 920548,
			Ability = {
				{
					Value = 200002,
					Num = 760,
				},
				{
					Value = 200004,
					Num = 5,
				},
			},
			SkillList = {
				{
					Id = 101745,
					Value = 60,
				},
			},
		},
		{
			Level = 10,
			Info = 920548,
			Ability = {
				{
					Value = 200002,
					Num = 840,
				},
				{
					Value = 200004,
					Num = 5,
				},
			},
			SkillList = {
				{
					Id = 101745,
					Value = 60,
				},
			},
		},
	},
}
