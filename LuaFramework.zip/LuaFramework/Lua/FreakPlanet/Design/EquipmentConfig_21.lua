
EquipmentConfig[EquipmentID.Id633] =
{
	Character = 220412,
	Rarity = 3,
	NeedChallenge = 145157,
	UpgradeId = 930011,
	LevelList = {
		{
			Level = 1,
			Info = 920361,
			Ability = {
				{
					Value = 200002,
					Num = 90,
				},
			},
		},
		{
			Level = 2,
			Info = 920361,
			Ability = {
				{
					Value = 200002,
					Num = 150,
				},
			},
		},
		{
			Level = 3,
			Info = 920361,
			Ability = {
				{
					Value = 200002,
					Num = 210,
				},
			},
		},
		{
			Level = 4,
			Info = 920361,
			Ability = {
				{
					Value = 200002,
					Num = 270,
				},
			},
		},
		{
			Level = 5,
			Info = 920361,
			Ability = {
				{
					Value = 200002,
					Num = 330,
				},
				{
					Value = 200004,
					Num = 25,
				},
			},
		},
		{
			Level = 6,
			Info = 920361,
			Ability = {
				{
					Value = 200002,
					Num = 390,
				},
				{
					Value = 200004,
					Num = 30,
				},
			},
		},
		{
			Level = 7,
			Info = 920361,
			Ability = {
				{
					Value = 200002,
					Num = 450,
				},
				{
					Value = 200004,
					Num = 35,
				},
			},
		},
		{
			Level = 8,
			Info = 920361,
			Ability = {
				{
					Value = 200002,
					Num = 510,
				},
				{
					Value = 200004,
					Num = 40,
				},
			},
			SkillList = {
				{
					Id = 101744,
					Value = 7,
				},
			},
		},
		{
			Level = 9,
			Info = 920361,
			Ability = {
				{
					Value = 200002,
					Num = 570,
				},
				{
					Value = 200004,
					Num = 45,
				},
			},
			SkillList = {
				{
					Id = 101744,
					Value = 7,
				},
			},
		},
		{
			Level = 10,
			Info = 920361,
			Ability = {
				{
					Value = 200002,
					Num = 630,
				},
				{
					Value = 200004,
					Num = 50,
				},
			},
			SkillList = {
				{
					Id = 101744,
					Value = 7,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id634] =
{
	Character = 220413,
	Rarity = 3,
	NeedChallenge = 145158,
	UpgradeId = 930031,
	LevelList = {
		{
			Level = 1,
			Info = 920364,
			Ability = {
				{
					Value = 200001,
					Num = 114,
				},
			},
		},
		{
			Level = 2,
			Info = 920364,
			Ability = {
				{
					Value = 200001,
					Num = 190,
				},
			},
		},
		{
			Level = 3,
			Info = 920364,
			Ability = {
				{
					Value = 200001,
					Num = 266,
				},
			},
		},
		{
			Level = 4,
			Info = 920364,
			Ability = {
				{
					Value = 200001,
					Num = 342,
				},
			},
		},
		{
			Level = 5,
			Info = 920364,
			Ability = {
				{
					Value = 200001,
					Num = 418,
				},
				{
					Value = 200003,
					Num = 25,
				},
			},
		},
		{
			Level = 6,
			Info = 920364,
			Ability = {
				{
					Value = 200001,
					Num = 494,
				},
				{
					Value = 200003,
					Num = 30,
				},
			},
		},
		{
			Level = 7,
			Info = 920364,
			Ability = {
				{
					Value = 200001,
					Num = 570,
				},
				{
					Value = 200003,
					Num = 35,
				},
			},
		},
		{
			Level = 8,
			Info = 920364,
			Ability = {
				{
					Value = 200001,
					Num = 646,
				},
				{
					Value = 200003,
					Num = 40,
				},
			},
			SkillList = {
				{
					Id = 100606,
					Value = -25,
				},
			},
		},
		{
			Level = 9,
			Info = 920364,
			Ability = {
				{
					Value = 200001,
					Num = 722,
				},
				{
					Value = 200003,
					Num = 45,
				},
			},
			SkillList = {
				{
					Id = 100606,
					Value = -25,
				},
			},
		},
		{
			Level = 10,
			Info = 920364,
			Ability = {
				{
					Value = 200001,
					Num = 798,
				},
				{
					Value = 200003,
					Num = 50,
				},
			},
			SkillList = {
				{
					Id = 100606,
					Value = -25,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id635] =
{
	Character = 223101,
	Rarity = 3,
	UpgradeId = 930009,
	LevelList = {
		{
			Level = 1,
			Info = 920669,
			Ability = {
				{
					Value = 200002,
					Num = 42,
				},
				{
					Value = 200005,
					Num = 9,
				},
			},
		},
		{
			Level = 2,
			Info = 920669,
			Ability = {
				{
					Value = 200002,
					Num = 84,
				},
				{
					Value = 200005,
					Num = 18,
				},
			},
		},
		{
			Level = 3,
			Info = 920669,
			Ability = {
				{
					Value = 200002,
					Num = 126,
				},
				{
					Value = 200005,
					Num = 27,
				},
			},
		},
		{
			Level = 4,
			Info = 920669,
			Ability = {
				{
					Value = 200002,
					Num = 168,
				},
				{
					Value = 200005,
					Num = 36,
				},
			},
		},
		{
			Level = 5,
			Info = 920669,
			Ability = {
				{
					Value = 200002,
					Num = 210,
				},
				{
					Value = 200005,
					Num = 45,
				},
			},
		},
		{
			Level = 6,
			Info = 920669,
			Ability = {
				{
					Value = 200002,
					Num = 252,
				},
				{
					Value = 200005,
					Num = 54,
				},
			},
		},
		{
			Level = 7,
			Info = 920669,
			Ability = {
				{
					Value = 200002,
					Num = 294,
				},
				{
					Value = 200005,
					Num = 63,
				},
			},
		},
		{
			Level = 8,
			Info = 920669,
			Ability = {
				{
					Value = 200002,
					Num = 336,
				},
				{
					Value = 200005,
					Num = 72,
				},
			},
			SkillList = {
				{
					Id = 100553,
					Value = 25,
				},
			},
		},
		{
			Level = 9,
			Info = 920669,
			Ability = {
				{
					Value = 200002,
					Num = 378,
				},
				{
					Value = 200005,
					Num = 81,
				},
			},
			SkillList = {
				{
					Id = 100553,
					Value = 25,
				},
			},
		},
		{
			Level = 10,
			Info = 920669,
			Ability = {
				{
					Value = 200002,
					Num = 420,
				},
				{
					Value = 200005,
					Num = 90,
				},
			},
			SkillList = {
				{
					Id = 100553,
					Value = 25,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id636] =
{
	Character = 223101,
	Rarity = 3,
	UpgradeId = 930010,
	LevelList = {
		{
			Level = 1,
			Info = 920670,
			Ability = {
				{
					Value = 200002,
					Num = 42,
				},
				{
					Value = 200006,
					Num = 6,
				},
			},
		},
		{
			Level = 2,
			Info = 920670,
			Ability = {
				{
					Value = 200002,
					Num = 84,
				},
				{
					Value = 200006,
					Num = 12,
				},
			},
		},
		{
			Level = 3,
			Info = 920670,
			Ability = {
				{
					Value = 200002,
					Num = 126,
				},
				{
					Value = 200006,
					Num = 18,
				},
			},
		},
		{
			Level = 4,
			Info = 920670,
			Ability = {
				{
					Value = 200002,
					Num = 168,
				},
				{
					Value = 200006,
					Num = 24,
				},
			},
		},
		{
			Level = 5,
			Info = 920670,
			Ability = {
				{
					Value = 200002,
					Num = 210,
				},
				{
					Value = 200006,
					Num = 30,
				},
			},
		},
		{
			Level = 6,
			Info = 920670,
			Ability = {
				{
					Value = 200002,
					Num = 252,
				},
				{
					Value = 200006,
					Num = 36,
				},
			},
		},
		{
			Level = 7,
			Info = 920670,
			Ability = {
				{
					Value = 200002,
					Num = 294,
				},
				{
					Value = 200006,
					Num = 42,
				},
			},
		},
		{
			Level = 8,
			Info = 920670,
			Ability = {
				{
					Value = 200002,
					Num = 336,
				},
				{
					Value = 200006,
					Num = 48,
				},
			},
			SkillList = {
				{
					Id = 101711,
					Value = 90,
				},
			},
		},
		{
			Level = 9,
			Info = 920670,
			Ability = {
				{
					Value = 200002,
					Num = 378,
				},
				{
					Value = 200006,
					Num = 54,
				},
			},
			SkillList = {
				{
					Id = 101711,
					Value = 90,
				},
			},
		},
		{
			Level = 10,
			Info = 920670,
			Ability = {
				{
					Value = 200002,
					Num = 420,
				},
				{
					Value = 200006,
					Num = 60,
				},
			},
			SkillList = {
				{
					Id = 101711,
					Value = 90,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id637] =
{
	Character = 223101,
	Rarity = 3,
	NeedChallenge = 145249,
	UpgradeId = 930011,
	LevelList = {
		{
			Level = 1,
			Info = 920671,
			Ability = {
				{
					Value = 200002,
					Num = 84,
				},
			},
		},
		{
			Level = 2,
			Info = 920671,
			Ability = {
				{
					Value = 200002,
					Num = 140,
				},
			},
		},
		{
			Level = 3,
			Info = 920671,
			Ability = {
				{
					Value = 200002,
					Num = 196,
				},
			},
		},
		{
			Level = 4,
			Info = 920671,
			Ability = {
				{
					Value = 200002,
					Num = 252,
				},
			},
		},
		{
			Level = 5,
			Info = 920671,
			Ability = {
				{
					Value = 200002,
					Num = 308,
				},
				{
					Value = 200004,
					Num = 25,
				},
			},
		},
		{
			Level = 6,
			Info = 920671,
			Ability = {
				{
					Value = 200002,
					Num = 364,
				},
				{
					Value = 200004,
					Num = 30,
				},
			},
		},
		{
			Level = 7,
			Info = 920671,
			Ability = {
				{
					Value = 200002,
					Num = 420,
				},
				{
					Value = 200004,
					Num = 35,
				},
			},
		},
		{
			Level = 8,
			Info = 920671,
			Ability = {
				{
					Value = 200002,
					Num = 476,
				},
				{
					Value = 200004,
					Num = 40,
				},
			},
			SkillList = {
				{
					Id = 101775,
					Value = 25,
				},
			},
		},
		{
			Level = 9,
			Info = 920671,
			Ability = {
				{
					Value = 200002,
					Num = 532,
				},
				{
					Value = 200004,
					Num = 45,
				},
			},
			SkillList = {
				{
					Id = 101775,
					Value = 25,
				},
			},
		},
		{
			Level = 10,
			Info = 920671,
			Ability = {
				{
					Value = 200002,
					Num = 588,
				},
				{
					Value = 200004,
					Num = 50,
				},
			},
			SkillList = {
				{
					Id = 101775,
					Value = 25,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id638] =
{
	Character = 223102,
	Rarity = 3,
	UpgradeId = 930029,
	LevelList = {
		{
			Level = 1,
			Info = 920672,
			Ability = {
				{
					Value = 200001,
					Num = 54,
				},
				{
					Value = 200005,
					Num = 9,
				},
			},
		},
		{
			Level = 2,
			Info = 920672,
			Ability = {
				{
					Value = 200001,
					Num = 108,
				},
				{
					Value = 200005,
					Num = 18,
				},
			},
		},
		{
			Level = 3,
			Info = 920672,
			Ability = {
				{
					Value = 200001,
					Num = 162,
				},
				{
					Value = 200005,
					Num = 27,
				},
			},
		},
		{
			Level = 4,
			Info = 920672,
			Ability = {
				{
					Value = 200001,
					Num = 216,
				},
				{
					Value = 200005,
					Num = 36,
				},
			},
		},
		{
			Level = 5,
			Info = 920672,
			Ability = {
				{
					Value = 200001,
					Num = 270,
				},
				{
					Value = 200005,
					Num = 45,
				},
			},
		},
		{
			Level = 6,
			Info = 920672,
			Ability = {
				{
					Value = 200001,
					Num = 324,
				},
				{
					Value = 200005,
					Num = 54,
				},
			},
		},
		{
			Level = 7,
			Info = 920672,
			Ability = {
				{
					Value = 200001,
					Num = 378,
				},
				{
					Value = 200005,
					Num = 63,
				},
			},
		},
		{
			Level = 8,
			Info = 920672,
			Ability = {
				{
					Value = 200001,
					Num = 432,
				},
				{
					Value = 200005,
					Num = 72,
				},
			},
			SkillList = {
				{
					Id = 100561,
					Value = -5,
				},
			},
		},
		{
			Level = 9,
			Info = 920672,
			Ability = {
				{
					Value = 200001,
					Num = 486,
				},
				{
					Value = 200005,
					Num = 81,
				},
			},
			SkillList = {
				{
					Id = 100561,
					Value = -5,
				},
			},
		},
		{
			Level = 10,
			Info = 920672,
			Ability = {
				{
					Value = 200001,
					Num = 540,
				},
				{
					Value = 200005,
					Num = 90,
				},
			},
			SkillList = {
				{
					Id = 100561,
					Value = -5,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id639] =
{
	Character = 223102,
	Rarity = 3,
	UpgradeId = 930030,
	LevelList = {
		{
			Level = 1,
			Info = 920673,
			Ability = {
				{
					Value = 200001,
					Num = 54,
				},
				{
					Value = 200007,
					Num = 6,
				},
			},
		},
		{
			Level = 2,
			Info = 920673,
			Ability = {
				{
					Value = 200001,
					Num = 108,
				},
				{
					Value = 200007,
					Num = 12,
				},
			},
		},
		{
			Level = 3,
			Info = 920673,
			Ability = {
				{
					Value = 200001,
					Num = 162,
				},
				{
					Value = 200007,
					Num = 18,
				},
			},
		},
		{
			Level = 4,
			Info = 920673,
			Ability = {
				{
					Value = 200001,
					Num = 216,
				},
				{
					Value = 200007,
					Num = 24,
				},
			},
		},
		{
			Level = 5,
			Info = 920673,
			Ability = {
				{
					Value = 200001,
					Num = 270,
				},
				{
					Value = 200007,
					Num = 30,
				},
			},
		},
		{
			Level = 6,
			Info = 920673,
			Ability = {
				{
					Value = 200001,
					Num = 324,
				},
				{
					Value = 200007,
					Num = 36,
				},
			},
		},
		{
			Level = 7,
			Info = 920673,
			Ability = {
				{
					Value = 200001,
					Num = 378,
				},
				{
					Value = 200007,
					Num = 42,
				},
			},
		},
		{
			Level = 8,
			Info = 920673,
			Ability = {
				{
					Value = 200001,
					Num = 432,
				},
				{
					Value = 200007,
					Num = 48,
				},
			},
			SkillList = {
				{
					Id = 101706,
					Value = 54,
				},
			},
		},
		{
			Level = 9,
			Info = 920673,
			Ability = {
				{
					Value = 200001,
					Num = 486,
				},
				{
					Value = 200007,
					Num = 54,
				},
			},
			SkillList = {
				{
					Id = 101706,
					Value = 54,
				},
			},
		},
		{
			Level = 10,
			Info = 920673,
			Ability = {
				{
					Value = 200001,
					Num = 540,
				},
				{
					Value = 200007,
					Num = 60,
				},
			},
			SkillList = {
				{
					Id = 101706,
					Value = 54,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id640] =
{
	Character = 223102,
	Rarity = 3,
	NeedChallenge = 145250,
	UpgradeId = 930031,
	LevelList = {
		{
			Level = 1,
			Info = 920674,
			Ability = {
				{
					Value = 200001,
					Num = 108,
				},
			},
		},
		{
			Level = 2,
			Info = 920674,
			Ability = {
				{
					Value = 200001,
					Num = 180,
				},
			},
		},
		{
			Level = 3,
			Info = 920674,
			Ability = {
				{
					Value = 200001,
					Num = 252,
				},
			},
		},
		{
			Level = 4,
			Info = 920674,
			Ability = {
				{
					Value = 200001,
					Num = 324,
				},
			},
		},
		{
			Level = 5,
			Info = 920674,
			Ability = {
				{
					Value = 200001,
					Num = 396,
				},
				{
					Value = 200003,
					Num = 25,
				},
			},
		},
		{
			Level = 6,
			Info = 920674,
			Ability = {
				{
					Value = 200001,
					Num = 468,
				},
				{
					Value = 200003,
					Num = 30,
				},
			},
		},
		{
			Level = 7,
			Info = 920674,
			Ability = {
				{
					Value = 200001,
					Num = 540,
				},
				{
					Value = 200003,
					Num = 35,
				},
			},
		},
		{
			Level = 8,
			Info = 920674,
			Ability = {
				{
					Value = 200001,
					Num = 612,
				},
				{
					Value = 200003,
					Num = 40,
				},
			},
			SkillList = {
				{
					Id = 101730,
					Value = 648,
				},
			},
		},
		{
			Level = 9,
			Info = 920674,
			Ability = {
				{
					Value = 200001,
					Num = 684,
				},
				{
					Value = 200003,
					Num = 45,
				},
			},
			SkillList = {
				{
					Id = 101730,
					Value = 648,
				},
			},
		},
		{
			Level = 10,
			Info = 920674,
			Ability = {
				{
					Value = 200001,
					Num = 756,
				},
				{
					Value = 200003,
					Num = 50,
				},
			},
			SkillList = {
				{
					Id = 101730,
					Value = 648,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id641] =
{
	Character = 223103,
	Rarity = 3,
	UpgradeId = 930009,
	LevelList = {
		{
			Level = 1,
			Info = 920675,
			Ability = {
				{
					Value = 200002,
					Num = 42,
				},
				{
					Value = 200007,
					Num = 9,
				},
			},
		},
		{
			Level = 2,
			Info = 920675,
			Ability = {
				{
					Value = 200002,
					Num = 84,
				},
				{
					Value = 200007,
					Num = 18,
				},
			},
		},
		{
			Level = 3,
			Info = 920675,
			Ability = {
				{
					Value = 200002,
					Num = 126,
				},
				{
					Value = 200007,
					Num = 27,
				},
			},
		},
		{
			Level = 4,
			Info = 920675,
			Ability = {
				{
					Value = 200002,
					Num = 168,
				},
				{
					Value = 200007,
					Num = 36,
				},
			},
		},
		{
			Level = 5,
			Info = 920675,
			Ability = {
				{
					Value = 200002,
					Num = 210,
				},
				{
					Value = 200007,
					Num = 45,
				},
			},
		},
		{
			Level = 6,
			Info = 920675,
			Ability = {
				{
					Value = 200002,
					Num = 252,
				},
				{
					Value = 200007,
					Num = 54,
				},
			},
		},
		{
			Level = 7,
			Info = 920675,
			Ability = {
				{
					Value = 200002,
					Num = 294,
				},
				{
					Value = 200007,
					Num = 63,
				},
			},
		},
		{
			Level = 8,
			Info = 920675,
			Ability = {
				{
					Value = 200002,
					Num = 336,
				},
				{
					Value = 200007,
					Num = 72,
				},
			},
			SkillList = {
				{
					Id = 100554,
					Value = 25,
				},
			},
		},
		{
			Level = 9,
			Info = 920675,
			Ability = {
				{
					Value = 200002,
					Num = 378,
				},
				{
					Value = 200007,
					Num = 81,
				},
			},
			SkillList = {
				{
					Id = 100554,
					Value = 25,
				},
			},
		},
		{
			Level = 10,
			Info = 920675,
			Ability = {
				{
					Value = 200002,
					Num = 420,
				},
				{
					Value = 200007,
					Num = 90,
				},
			},
			SkillList = {
				{
					Id = 100554,
					Value = 25,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id642] =
{
	Character = 223103,
	Rarity = 3,
	UpgradeId = 930030,
	LevelList = {
		{
			Level = 1,
			Info = 920676,
			Ability = {
				{
					Value = 200001,
					Num = 54,
				},
				{
					Value = 200006,
					Num = 6,
				},
			},
		},
		{
			Level = 2,
			Info = 920676,
			Ability = {
				{
					Value = 200001,
					Num = 108,
				},
				{
					Value = 200006,
					Num = 12,
				},
			},
		},
		{
			Level = 3,
			Info = 920676,
			Ability = {
				{
					Value = 200001,
					Num = 162,
				},
				{
					Value = 200006,
					Num = 18,
				},
			},
		},
		{
			Level = 4,
			Info = 920676,
			Ability = {
				{
					Value = 200001,
					Num = 216,
				},
				{
					Value = 200006,
					Num = 24,
				},
			},
		},
		{
			Level = 5,
			Info = 920676,
			Ability = {
				{
					Value = 200001,
					Num = 270,
				},
				{
					Value = 200006,
					Num = 30,
				},
			},
		},
		{
			Level = 6,
			Info = 920676,
			Ability = {
				{
					Value = 200001,
					Num = 324,
				},
				{
					Value = 200006,
					Num = 36,
				},
			},
		},
		{
			Level = 7,
			Info = 920676,
			Ability = {
				{
					Value = 200001,
					Num = 378,
				},
				{
					Value = 200006,
					Num = 42,
				},
			},
		},
		{
			Level = 8,
			Info = 920676,
			Ability = {
				{
					Value = 200001,
					Num = 432,
				},
				{
					Value = 200006,
					Num = 48,
				},
			},
			SkillList = {
				{
					Id = 101704,
					Value = 30,
				},
			},
		},
		{
			Level = 9,
			Info = 920676,
			Ability = {
				{
					Value = 200001,
					Num = 486,
				},
				{
					Value = 200006,
					Num = 54,
				},
			},
			SkillList = {
				{
					Id = 101704,
					Value = 30,
				},
			},
		},
		{
			Level = 10,
			Info = 920676,
			Ability = {
				{
					Value = 200001,
					Num = 540,
				},
				{
					Value = 200006,
					Num = 60,
				},
			},
			SkillList = {
				{
					Id = 101704,
					Value = 30,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id643] =
{
	Character = 223103,
	Rarity = 3,
	NeedChallenge = 145251,
	UpgradeId = 930031,
	LevelList = {
		{
			Level = 1,
			Info = 920677,
			Ability = {
				{
					Value = 200001,
					Num = 108,
				},
			},
		},
		{
			Level = 2,
			Info = 920677,
			Ability = {
				{
					Value = 200001,
					Num = 180,
				},
			},
		},
		{
			Level = 3,
			Info = 920677,
			Ability = {
				{
					Value = 200001,
					Num = 252,
				},
			},
		},
		{
			Level = 4,
			Info = 920677,
			Ability = {
				{
					Value = 200001,
					Num = 324,
				},
			},
		},
		{
			Level = 5,
			Info = 920677,
			Ability = {
				{
					Value = 200001,
					Num = 396,
				},
				{
					Value = 200003,
					Num = 25,
				},
			},
		},
		{
			Level = 6,
			Info = 920677,
			Ability = {
				{
					Value = 200001,
					Num = 468,
				},
				{
					Value = 200003,
					Num = 30,
				},
			},
		},
		{
			Level = 7,
			Info = 920677,
			Ability = {
				{
					Value = 200001,
					Num = 540,
				},
				{
					Value = 200003,
					Num = 35,
				},
			},
		},
		{
			Level = 8,
			Info = 920677,
			Ability = {
				{
					Value = 200001,
					Num = 612,
				},
				{
					Value = 200003,
					Num = 40,
				},
			},
			SkillList = {
				{
					Id = 100606,
					Value = -25,
				},
			},
		},
		{
			Level = 9,
			Info = 920677,
			Ability = {
				{
					Value = 200001,
					Num = 684,
				},
				{
					Value = 200003,
					Num = 45,
				},
			},
			SkillList = {
				{
					Id = 100606,
					Value = -25,
				},
			},
		},
		{
			Level = 10,
			Info = 920677,
			Ability = {
				{
					Value = 200001,
					Num = 756,
				},
				{
					Value = 200003,
					Num = 50,
				},
			},
			SkillList = {
				{
					Id = 100606,
					Value = -25,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id644] =
{
	Character = 223104,
	Rarity = 4,
	UpgradeId = 930033,
	LevelList = {
		{
			Level = 1,
			Info = 920678,
			Ability = {
				{
					Value = 200001,
					Num = 75,
				},
				{
					Value = 200006,
					Num = 12,
				},
			},
		},
		{
			Level = 2,
			Info = 920678,
			Ability = {
				{
					Value = 200001,
					Num = 150,
				},
				{
					Value = 200006,
					Num = 24,
				},
			},
		},
		{
			Level = 3,
			Info = 920678,
			Ability = {
				{
					Value = 200001,
					Num = 225,
				},
				{
					Value = 200006,
					Num = 36,
				},
			},
		},
		{
			Level = 4,
			Info = 920678,
			Ability = {
				{
					Value = 200001,
					Num = 300,
				},
				{
					Value = 200006,
					Num = 48,
				},
			},
		},
		{
			Level = 5,
			Info = 920678,
			Ability = {
				{
					Value = 200001,
					Num = 375,
				},
				{
					Value = 200006,
					Num = 60,
				},
			},
		},
		{
			Level = 6,
			Info = 920678,
			Ability = {
				{
					Value = 200001,
					Num = 450,
				},
				{
					Value = 200006,
					Num = 72,
				},
			},
		},
		{
			Level = 7,
			Info = 920678,
			Ability = {
				{
					Value = 200001,
					Num = 525,
				},
				{
					Value = 200006,
					Num = 84,
				},
			},
		},
		{
			Level = 8,
			Info = 920678,
			Ability = {
				{
					Value = 200001,
					Num = 600,
				},
				{
					Value = 200006,
					Num = 96,
				},
			},
			SkillList = {
				{
					Id = 100561,
					Value = -5,
				},
			},
		},
		{
			Level = 9,
			Info = 920678,
			Ability = {
				{
					Value = 200001,
					Num = 675,
				},
				{
					Value = 200006,
					Num = 108,
				},
			},
			SkillList = {
				{
					Id = 100561,
					Value = -5,
				},
			},
		},
		{
			Level = 10,
			Info = 920678,
			Ability = {
				{
					Value = 200001,
					Num = 750,
				},
				{
					Value = 200006,
					Num = 120,
				},
			},
			SkillList = {
				{
					Id = 100561,
					Value = -5,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id645] =
{
	Character = 223104,
	Rarity = 4,
	UpgradeId = 930014,
	LevelList = {
		{
			Level = 1,
			Info = 920679,
			Ability = {
				{
					Value = 200002,
					Num = 54,
				},
				{
					Value = 200005,
					Num = 9,
				},
			},
		},
		{
			Level = 2,
			Info = 920679,
			Ability = {
				{
					Value = 200002,
					Num = 108,
				},
				{
					Value = 200005,
					Num = 18,
				},
			},
		},
		{
			Level = 3,
			Info = 920679,
			Ability = {
				{
					Value = 200002,
					Num = 162,
				},
				{
					Value = 200005,
					Num = 27,
				},
			},
		},
		{
			Level = 4,
			Info = 920679,
			Ability = {
				{
					Value = 200002,
					Num = 216,
				},
				{
					Value = 200005,
					Num = 36,
				},
			},
		},
		{
			Level = 5,
			Info = 920679,
			Ability = {
				{
					Value = 200002,
					Num = 270,
				},
				{
					Value = 200005,
					Num = 45,
				},
			},
		},
		{
			Level = 6,
			Info = 920679,
			Ability = {
				{
					Value = 200002,
					Num = 324,
				},
				{
					Value = 200005,
					Num = 54,
				},
			},
		},
		{
			Level = 7,
			Info = 920679,
			Ability = {
				{
					Value = 200002,
					Num = 378,
				},
				{
					Value = 200005,
					Num = 63,
				},
			},
		},
		{
			Level = 8,
			Info = 920679,
			Ability = {
				{
					Value = 200002,
					Num = 432,
				},
				{
					Value = 200005,
					Num = 72,
				},
			},
			SkillList = {
				{
					Id = 101744,
					Value = 7,
				},
			},
		},
		{
			Level = 9,
			Info = 920679,
			Ability = {
				{
					Value = 200002,
					Num = 486,
				},
				{
					Value = 200005,
					Num = 81,
				},
			},
			SkillList = {
				{
					Id = 101744,
					Value = 7,
				},
			},
		},
		{
			Level = 10,
			Info = 920679,
			Ability = {
				{
					Value = 200002,
					Num = 540,
				},
				{
					Value = 200005,
					Num = 90,
				},
			},
			SkillList = {
				{
					Id = 101744,
					Value = 7,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id646] =
{
	Character = 223104,
	Rarity = 4,
	NeedChallenge = 145252,
	UpgradeId = 930035,
	LevelList = {
		{
			Level = 1,
			Info = 920680,
			Ability = {
				{
					Value = 200001,
					Num = 150,
				},
			},
		},
		{
			Level = 2,
			Info = 920680,
			Ability = {
				{
					Value = 200001,
					Num = 250,
				},
			},
		},
		{
			Level = 3,
			Info = 920680,
			Ability = {
				{
					Value = 200001,
					Num = 350,
				},
			},
		},
		{
			Level = 4,
			Info = 920680,
			Ability = {
				{
					Value = 200001,
					Num = 450,
				},
			},
		},
		{
			Level = 5,
			Info = 920680,
			Ability = {
				{
					Value = 200001,
					Num = 550,
				},
				{
					Value = 200003,
					Num = 25,
				},
			},
		},
		{
			Level = 6,
			Info = 920680,
			Ability = {
				{
					Value = 200001,
					Num = 650,
				},
				{
					Value = 200003,
					Num = 30,
				},
			},
		},
		{
			Level = 7,
			Info = 920680,
			Ability = {
				{
					Value = 200001,
					Num = 750,
				},
				{
					Value = 200003,
					Num = 35,
				},
			},
		},
		{
			Level = 8,
			Info = 920680,
			Ability = {
				{
					Value = 200001,
					Num = 850,
				},
				{
					Value = 200003,
					Num = 40,
				},
			},
			SkillList = {
				{
					Id = 100565,
					Value = -5,
				},
			},
		},
		{
			Level = 9,
			Info = 920680,
			Ability = {
				{
					Value = 200001,
					Num = 950,
				},
				{
					Value = 200003,
					Num = 45,
				},
			},
			SkillList = {
				{
					Id = 100565,
					Value = -5,
				},
			},
		},
		{
			Level = 10,
			Info = 920680,
			Ability = {
				{
					Value = 200001,
					Num = 1050,
				},
				{
					Value = 200003,
					Num = 50,
				},
			},
			SkillList = {
				{
					Id = 100565,
					Value = -5,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id647] =
{
	Character = 223105,
	Rarity = 4,
	UpgradeId = 930033,
	LevelList = {
		{
			Level = 1,
			Info = 920681,
			Ability = {
				{
					Value = 200001,
					Num = 69,
				},
				{
					Value = 200006,
					Num = 12,
				},
			},
		},
		{
			Level = 2,
			Info = 920681,
			Ability = {
				{
					Value = 200001,
					Num = 138,
				},
				{
					Value = 200006,
					Num = 24,
				},
			},
		},
		{
			Level = 3,
			Info = 920681,
			Ability = {
				{
					Value = 200001,
					Num = 207,
				},
				{
					Value = 200006,
					Num = 36,
				},
			},
		},
		{
			Level = 4,
			Info = 920681,
			Ability = {
				{
					Value = 200001,
					Num = 276,
				},
				{
					Value = 200006,
					Num = 48,
				},
			},
		},
		{
			Level = 5,
			Info = 920681,
			Ability = {
				{
					Value = 200001,
					Num = 345,
				},
				{
					Value = 200006,
					Num = 60,
				},
			},
		},
		{
			Level = 6,
			Info = 920681,
			Ability = {
				{
					Value = 200001,
					Num = 414,
				},
				{
					Value = 200006,
					Num = 72,
				},
			},
		},
		{
			Level = 7,
			Info = 920681,
			Ability = {
				{
					Value = 200001,
					Num = 483,
				},
				{
					Value = 200006,
					Num = 84,
				},
			},
		},
		{
			Level = 8,
			Info = 920681,
			Ability = {
				{
					Value = 200001,
					Num = 552,
				},
				{
					Value = 200006,
					Num = 96,
				},
			},
			SkillList = {
				{
					Id = 100564,
					Value = -5,
				},
			},
		},
		{
			Level = 9,
			Info = 920681,
			Ability = {
				{
					Value = 200001,
					Num = 621,
				},
				{
					Value = 200006,
					Num = 108,
				},
			},
			SkillList = {
				{
					Id = 100564,
					Value = -5,
				},
			},
		},
		{
			Level = 10,
			Info = 920681,
			Ability = {
				{
					Value = 200001,
					Num = 690,
				},
				{
					Value = 200006,
					Num = 120,
				},
			},
			SkillList = {
				{
					Id = 100564,
					Value = -5,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id648] =
{
	Character = 223105,
	Rarity = 4,
	UpgradeId = 930034,
	LevelList = {
		{
			Level = 1,
			Info = 920682,
			Ability = {
				{
					Value = 200001,
					Num = 69,
				},
				{
					Value = 200008,
					Num = 9,
				},
			},
		},
		{
			Level = 2,
			Info = 920682,
			Ability = {
				{
					Value = 200001,
					Num = 138,
				},
				{
					Value = 200008,
					Num = 18,
				},
			},
		},
		{
			Level = 3,
			Info = 920682,
			Ability = {
				{
					Value = 200001,
					Num = 207,
				},
				{
					Value = 200008,
					Num = 27,
				},
			},
		},
		{
			Level = 4,
			Info = 920682,
			Ability = {
				{
					Value = 200001,
					Num = 276,
				},
				{
					Value = 200008,
					Num = 36,
				},
			},
		},
		{
			Level = 5,
			Info = 920682,
			Ability = {
				{
					Value = 200001,
					Num = 345,
				},
				{
					Value = 200008,
					Num = 45,
				},
			},
		},
		{
			Level = 6,
			Info = 920682,
			Ability = {
				{
					Value = 200001,
					Num = 414,
				},
				{
					Value = 200008,
					Num = 54,
				},
			},
		},
		{
			Level = 7,
			Info = 920682,
			Ability = {
				{
					Value = 200001,
					Num = 483,
				},
				{
					Value = 200008,
					Num = 63,
				},
			},
		},
		{
			Level = 8,
			Info = 920682,
			Ability = {
				{
					Value = 200001,
					Num = 552,
				},
				{
					Value = 200008,
					Num = 72,
				},
			},
			SkillList = {
				{
					Id = 100606,
					Value = -25,
				},
			},
		},
		{
			Level = 9,
			Info = 920682,
			Ability = {
				{
					Value = 200001,
					Num = 621,
				},
				{
					Value = 200008,
					Num = 81,
				},
			},
			SkillList = {
				{
					Id = 100606,
					Value = -25,
				},
			},
		},
		{
			Level = 10,
			Info = 920682,
			Ability = {
				{
					Value = 200001,
					Num = 690,
				},
				{
					Value = 200008,
					Num = 90,
				},
			},
			SkillList = {
				{
					Id = 100606,
					Value = -25,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id649] =
{
	Character = 223105,
	Rarity = 4,
	NeedChallenge = 145253,
	UpgradeId = 930015,
	LevelList = {
		{
			Level = 1,
			Info = 920683,
			Ability = {
				{
					Value = 200002,
					Num = 108,
				},
			},
		},
		{
			Level = 2,
			Info = 920683,
			Ability = {
				{
					Value = 200002,
					Num = 180,
				},
			},
		},
		{
			Level = 3,
			Info = 920683,
			Ability = {
				{
					Value = 200002,
					Num = 252,
				},
			},
		},
		{
			Level = 4,
			Info = 920683,
			Ability = {
				{
					Value = 200002,
					Num = 324,
				},
			},
		},
		{
			Level = 5,
			Info = 920683,
			Ability = {
				{
					Value = 200002,
					Num = 396,
				},
				{
					Value = 200004,
					Num = 25,
				},
			},
		},
		{
			Level = 6,
			Info = 920683,
			Ability = {
				{
					Value = 200002,
					Num = 468,
				},
				{
					Value = 200004,
					Num = 30,
				},
			},
		},
		{
			Level = 7,
			Info = 920683,
			Ability = {
				{
					Value = 200002,
					Num = 540,
				},
				{
					Value = 200004,
					Num = 35,
				},
			},
		},
		{
			Level = 8,
			Info = 920683,
			Ability = {
				{
					Value = 200002,
					Num = 612,
				},
				{
					Value = 200004,
					Num = 40,
				},
			},
			SkillList = {
				{
					Id = 101738,
					Value = 15,
				},
			},
		},
		{
			Level = 9,
			Info = 920683,
			Ability = {
				{
					Value = 200002,
					Num = 684,
				},
				{
					Value = 200004,
					Num = 45,
				},
			},
			SkillList = {
				{
					Id = 101738,
					Value = 15,
				},
			},
		},
		{
			Level = 10,
			Info = 920683,
			Ability = {
				{
					Value = 200002,
					Num = 756,
				},
				{
					Value = 200004,
					Num = 50,
				},
			},
			SkillList = {
				{
					Id = 101738,
					Value = 15,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id650] =
{
	Character = 223106,
	Rarity = 4,
	UpgradeId = 930033,
	LevelList = {
		{
			Level = 1,
			Info = 920684,
			Ability = {
				{
					Value = 200001,
					Num = 75,
				},
				{
					Value = 200007,
					Num = 12,
				},
			},
		},
		{
			Level = 2,
			Info = 920684,
			Ability = {
				{
					Value = 200001,
					Num = 150,
				},
				{
					Value = 200007,
					Num = 24,
				},
			},
		},
		{
			Level = 3,
			Info = 920684,
			Ability = {
				{
					Value = 200001,
					Num = 225,
				},
				{
					Value = 200007,
					Num = 36,
				},
			},
		},
		{
			Level = 4,
			Info = 920684,
			Ability = {
				{
					Value = 200001,
					Num = 300,
				},
				{
					Value = 200007,
					Num = 48,
				},
			},
		},
		{
			Level = 5,
			Info = 920684,
			Ability = {
				{
					Value = 200001,
					Num = 375,
				},
				{
					Value = 200007,
					Num = 60,
				},
			},
		},
		{
			Level = 6,
			Info = 920684,
			Ability = {
				{
					Value = 200001,
					Num = 450,
				},
				{
					Value = 200007,
					Num = 72,
				},
			},
		},
		{
			Level = 7,
			Info = 920684,
			Ability = {
				{
					Value = 200001,
					Num = 525,
				},
				{
					Value = 200007,
					Num = 84,
				},
			},
		},
		{
			Level = 8,
			Info = 920684,
			Ability = {
				{
					Value = 200001,
					Num = 600,
				},
				{
					Value = 200007,
					Num = 96,
				},
			},
			SkillList = {
				{
					Id = 100563,
					Value = -5,
				},
			},
		},
		{
			Level = 9,
			Info = 920684,
			Ability = {
				{
					Value = 200001,
					Num = 675,
				},
				{
					Value = 200007,
					Num = 108,
				},
			},
			SkillList = {
				{
					Id = 100563,
					Value = -5,
				},
			},
		},
		{
			Level = 10,
			Info = 920684,
			Ability = {
				{
					Value = 200001,
					Num = 750,
				},
				{
					Value = 200007,
					Num = 120,
				},
			},
			SkillList = {
				{
					Id = 100563,
					Value = -5,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id651] =
{
	Character = 223106,
	Rarity = 4,
	UpgradeId = 930014,
	LevelList = {
		{
			Level = 1,
			Info = 920685,
			Ability = {
				{
					Value = 200002,
					Num = 54,
				},
				{
					Value = 200008,
					Num = 9,
				},
			},
		},
		{
			Level = 2,
			Info = 920685,
			Ability = {
				{
					Value = 200002,
					Num = 108,
				},
				{
					Value = 200008,
					Num = 18,
				},
			},
		},
		{
			Level = 3,
			Info = 920685,
			Ability = {
				{
					Value = 200002,
					Num = 162,
				},
				{
					Value = 200008,
					Num = 27,
				},
			},
		},
		{
			Level = 4,
			Info = 920685,
			Ability = {
				{
					Value = 200002,
					Num = 216,
				},
				{
					Value = 200008,
					Num = 36,
				},
			},
		},
		{
			Level = 5,
			Info = 920685,
			Ability = {
				{
					Value = 200002,
					Num = 270,
				},
				{
					Value = 200008,
					Num = 45,
				},
			},
		},
		{
			Level = 6,
			Info = 920685,
			Ability = {
				{
					Value = 200002,
					Num = 324,
				},
				{
					Value = 200008,
					Num = 54,
				},
			},
		},
		{
			Level = 7,
			Info = 920685,
			Ability = {
				{
					Value = 200002,
					Num = 378,
				},
				{
					Value = 200008,
					Num = 63,
				},
			},
		},
		{
			Level = 8,
			Info = 920685,
			Ability = {
				{
					Value = 200002,
					Num = 432,
				},
				{
					Value = 200008,
					Num = 72,
				},
			},
			SkillList = {
				{
					Id = 101701,
					Value = 252,
				},
			},
		},
		{
			Level = 9,
			Info = 920685,
			Ability = {
				{
					Value = 200002,
					Num = 486,
				},
				{
					Value = 200008,
					Num = 81,
				},
			},
			SkillList = {
				{
					Id = 101701,
					Value = 252,
				},
			},
		},
		{
			Level = 10,
			Info = 920685,
			Ability = {
				{
					Value = 200002,
					Num = 540,
				},
				{
					Value = 200008,
					Num = 90,
				},
			},
			SkillList = {
				{
					Id = 101701,
					Value = 252,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id652] =
{
	Character = 223106,
	Rarity = 4,
	NeedChallenge = 145254,
	UpgradeId = 930015,
	LevelList = {
		{
			Level = 1,
			Info = 920686,
			Ability = {
				{
					Value = 200002,
					Num = 108,
				},
			},
		},
		{
			Level = 2,
			Info = 920686,
			Ability = {
				{
					Value = 200002,
					Num = 180,
				},
			},
		},
		{
			Level = 3,
			Info = 920686,
			Ability = {
				{
					Value = 200002,
					Num = 252,
				},
			},
		},
		{
			Level = 4,
			Info = 920686,
			Ability = {
				{
					Value = 200002,
					Num = 324,
				},
			},
		},
		{
			Level = 5,
			Info = 920686,
			Ability = {
				{
					Value = 200002,
					Num = 396,
				},
				{
					Value = 200004,
					Num = 25,
				},
			},
		},
		{
			Level = 6,
			Info = 920686,
			Ability = {
				{
					Value = 200002,
					Num = 468,
				},
				{
					Value = 200004,
					Num = 30,
				},
			},
		},
		{
			Level = 7,
			Info = 920686,
			Ability = {
				{
					Value = 200002,
					Num = 540,
				},
				{
					Value = 200004,
					Num = 35,
				},
			},
		},
		{
			Level = 8,
			Info = 920686,
			Ability = {
				{
					Value = 200002,
					Num = 612,
				},
				{
					Value = 200004,
					Num = 40,
				},
			},
			SkillList = {
				{
					Id = 101745,
					Value = 60,
				},
			},
		},
		{
			Level = 9,
			Info = 920686,
			Ability = {
				{
					Value = 200002,
					Num = 684,
				},
				{
					Value = 200004,
					Num = 45,
				},
			},
			SkillList = {
				{
					Id = 101745,
					Value = 60,
				},
			},
		},
		{
			Level = 10,
			Info = 920686,
			Ability = {
				{
					Value = 200002,
					Num = 756,
				},
				{
					Value = 200004,
					Num = 50,
				},
			},
			SkillList = {
				{
					Id = 101745,
					Value = 60,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id653] =
{
	Character = 223107,
	Rarity = 4,
	UpgradeId = 930013,
	LevelList = {
		{
			Level = 1,
			Info = 920687,
			Ability = {
				{
					Value = 200002,
					Num = 60,
				},
				{
					Value = 200008,
					Num = 12,
				},
			},
		},
		{
			Level = 2,
			Info = 920687,
			Ability = {
				{
					Value = 200002,
					Num = 120,
				},
				{
					Value = 200008,
					Num = 24,
				},
			},
		},
		{
			Level = 3,
			Info = 920687,
			Ability = {
				{
					Value = 200002,
					Num = 180,
				},
				{
					Value = 200008,
					Num = 36,
				},
			},
		},
		{
			Level = 4,
			Info = 920687,
			Ability = {
				{
					Value = 200002,
					Num = 240,
				},
				{
					Value = 200008,
					Num = 48,
				},
			},
		},
		{
			Level = 5,
			Info = 920687,
			Ability = {
				{
					Value = 200002,
					Num = 300,
				},
				{
					Value = 200008,
					Num = 60,
				},
			},
		},
		{
			Level = 6,
			Info = 920687,
			Ability = {
				{
					Value = 200002,
					Num = 360,
				},
				{
					Value = 200008,
					Num = 72,
				},
			},
		},
		{
			Level = 7,
			Info = 920687,
			Ability = {
				{
					Value = 200002,
					Num = 420,
				},
				{
					Value = 200008,
					Num = 84,
				},
			},
		},
		{
			Level = 8,
			Info = 920687,
			Ability = {
				{
					Value = 200002,
					Num = 480,
				},
				{
					Value = 200008,
					Num = 96,
				},
			},
			SkillList = {
				{
					Id = 100652,
					Value = 7,
				},
			},
		},
		{
			Level = 9,
			Info = 920687,
			Ability = {
				{
					Value = 200002,
					Num = 540,
				},
				{
					Value = 200008,
					Num = 108,
				},
			},
			SkillList = {
				{
					Id = 100652,
					Value = 7,
				},
			},
		},
		{
			Level = 10,
			Info = 920687,
			Ability = {
				{
					Value = 200002,
					Num = 600,
				},
				{
					Value = 200008,
					Num = 120,
				},
			},
			SkillList = {
				{
					Id = 100652,
					Value = 7,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id654] =
{
	Character = 223107,
	Rarity = 4,
	UpgradeId = 930014,
	LevelList = {
		{
			Level = 1,
			Info = 920688,
			Ability = {
				{
					Value = 200002,
					Num = 60,
				},
				{
					Value = 200005,
					Num = 9,
				},
			},
		},
		{
			Level = 2,
			Info = 920688,
			Ability = {
				{
					Value = 200002,
					Num = 120,
				},
				{
					Value = 200005,
					Num = 18,
				},
			},
		},
		{
			Level = 3,
			Info = 920688,
			Ability = {
				{
					Value = 200002,
					Num = 180,
				},
				{
					Value = 200005,
					Num = 27,
				},
			},
		},
		{
			Level = 4,
			Info = 920688,
			Ability = {
				{
					Value = 200002,
					Num = 240,
				},
				{
					Value = 200005,
					Num = 36,
				},
			},
		},
		{
			Level = 5,
			Info = 920688,
			Ability = {
				{
					Value = 200002,
					Num = 300,
				},
				{
					Value = 200005,
					Num = 45,
				},
			},
		},
		{
			Level = 6,
			Info = 920688,
			Ability = {
				{
					Value = 200002,
					Num = 360,
				},
				{
					Value = 200005,
					Num = 54,
				},
			},
		},
		{
			Level = 7,
			Info = 920688,
			Ability = {
				{
					Value = 200002,
					Num = 420,
				},
				{
					Value = 200005,
					Num = 63,
				},
			},
		},
		{
			Level = 8,
			Info = 920688,
			Ability = {
				{
					Value = 200002,
					Num = 480,
				},
				{
					Value = 200005,
					Num = 72,
				},
			},
			SkillList = {
				{
					Id = 101761,
					Value = 75,
				},
			},
		},
		{
			Level = 9,
			Info = 920688,
			Ability = {
				{
					Value = 200002,
					Num = 540,
				},
				{
					Value = 200005,
					Num = 81,
				},
			},
			SkillList = {
				{
					Id = 101761,
					Value = 75,
				},
			},
		},
		{
			Level = 10,
			Info = 920688,
			Ability = {
				{
					Value = 200002,
					Num = 600,
				},
				{
					Value = 200005,
					Num = 90,
				},
			},
			SkillList = {
				{
					Id = 101761,
					Value = 75,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id655] =
{
	Character = 223107,
	Rarity = 4,
	NeedChallenge = 145255,
	UpgradeId = 930015,
	LevelList = {
		{
			Level = 1,
			Info = 920689,
			Ability = {
				{
					Value = 200002,
					Num = 120,
				},
			},
		},
		{
			Level = 2,
			Info = 920689,
			Ability = {
				{
					Value = 200002,
					Num = 200,
				},
			},
		},
		{
			Level = 3,
			Info = 920689,
			Ability = {
				{
					Value = 200002,
					Num = 280,
				},
			},
		},
		{
			Level = 4,
			Info = 920689,
			Ability = {
				{
					Value = 200002,
					Num = 360,
				},
			},
		},
		{
			Level = 5,
			Info = 920689,
			Ability = {
				{
					Value = 200002,
					Num = 440,
				},
				{
					Value = 200004,
					Num = 25,
				},
			},
		},
		{
			Level = 6,
			Info = 920689,
			Ability = {
				{
					Value = 200002,
					Num = 520,
				},
				{
					Value = 200004,
					Num = 30,
				},
			},
		},
		{
			Level = 7,
			Info = 920689,
			Ability = {
				{
					Value = 200002,
					Num = 600,
				},
				{
					Value = 200004,
					Num = 35,
				},
			},
		},
		{
			Level = 8,
			Info = 920689,
			Ability = {
				{
					Value = 200002,
					Num = 680,
				},
				{
					Value = 200004,
					Num = 40,
				},
			},
			SkillList = {
				{
					Id = 101731,
					Value = 900,
				},
			},
		},
		{
			Level = 9,
			Info = 920689,
			Ability = {
				{
					Value = 200002,
					Num = 760,
				},
				{
					Value = 200004,
					Num = 45,
				},
			},
			SkillList = {
				{
					Id = 101731,
					Value = 900,
				},
			},
		},
		{
			Level = 10,
			Info = 920689,
			Ability = {
				{
					Value = 200002,
					Num = 840,
				},
				{
					Value = 200004,
					Num = 50,
				},
			},
			SkillList = {
				{
					Id = 101731,
					Value = 900,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id656] =
{
	Character = 223108,
	Rarity = 5,
	UpgradeId = 930037,
	LevelList = {
		{
			Level = 1,
			Info = 920690,
			Ability = {
				{
					Value = 200001,
					Num = 84,
				},
				{
					Value = 200005,
					Num = 12,
				},
			},
		},
		{
			Level = 2,
			Info = 920690,
			Ability = {
				{
					Value = 200001,
					Num = 168,
				},
				{
					Value = 200005,
					Num = 24,
				},
			},
		},
		{
			Level = 3,
			Info = 920690,
			Ability = {
				{
					Value = 200001,
					Num = 252,
				},
				{
					Value = 200005,
					Num = 36,
				},
			},
		},
		{
			Level = 4,
			Info = 920690,
			Ability = {
				{
					Value = 200001,
					Num = 336,
				},
				{
					Value = 200005,
					Num = 48,
				},
			},
		},
		{
			Level = 5,
			Info = 920690,
			Ability = {
				{
					Value = 200001,
					Num = 420,
				},
				{
					Value = 200005,
					Num = 60,
				},
			},
		},
		{
			Level = 6,
			Info = 920690,
			Ability = {
				{
					Value = 200001,
					Num = 504,
				},
				{
					Value = 200005,
					Num = 72,
				},
			},
		},
		{
			Level = 7,
			Info = 920690,
			Ability = {
				{
					Value = 200001,
					Num = 588,
				},
				{
					Value = 200005,
					Num = 84,
				},
			},
		},
		{
			Level = 8,
			Info = 920690,
			Ability = {
				{
					Value = 200001,
					Num = 672,
				},
				{
					Value = 200005,
					Num = 96,
				},
			},
			SkillList = {
				{
					Id = 100562,
					Value = -5,
				},
			},
		},
		{
			Level = 9,
			Info = 920690,
			Ability = {
				{
					Value = 200001,
					Num = 756,
				},
				{
					Value = 200005,
					Num = 108,
				},
			},
			SkillList = {
				{
					Id = 100562,
					Value = -5,
				},
			},
		},
		{
			Level = 10,
			Info = 920690,
			Ability = {
				{
					Value = 200001,
					Num = 840,
				},
				{
					Value = 200005,
					Num = 120,
				},
			},
			SkillList = {
				{
					Id = 100562,
					Value = -5,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id657] =
{
	Character = 223108,
	Rarity = 5,
	UpgradeId = 930018,
	LevelList = {
		{
			Level = 1,
			Info = 920691,
			Ability = {
				{
					Value = 200002,
					Num = 72,
				},
				{
					Value = 200008,
					Num = 9,
				},
			},
		},
		{
			Level = 2,
			Info = 920691,
			Ability = {
				{
					Value = 200002,
					Num = 144,
				},
				{
					Value = 200008,
					Num = 18,
				},
			},
		},
		{
			Level = 3,
			Info = 920691,
			Ability = {
				{
					Value = 200002,
					Num = 216,
				},
				{
					Value = 200008,
					Num = 27,
				},
			},
		},
		{
			Level = 4,
			Info = 920691,
			Ability = {
				{
					Value = 200002,
					Num = 288,
				},
				{
					Value = 200008,
					Num = 36,
				},
			},
		},
		{
			Level = 5,
			Info = 920691,
			Ability = {
				{
					Value = 200002,
					Num = 360,
				},
				{
					Value = 200008,
					Num = 45,
				},
			},
		},
		{
			Level = 6,
			Info = 920691,
			Ability = {
				{
					Value = 200002,
					Num = 432,
				},
				{
					Value = 200008,
					Num = 54,
				},
			},
		},
		{
			Level = 7,
			Info = 920691,
			Ability = {
				{
					Value = 200002,
					Num = 504,
				},
				{
					Value = 200008,
					Num = 63,
				},
			},
		},
		{
			Level = 8,
			Info = 920691,
			Ability = {
				{
					Value = 200002,
					Num = 576,
				},
				{
					Value = 200008,
					Num = 72,
				},
			},
			SkillList = {
				{
					Id = 100652,
					Value = 7,
				},
			},
		},
		{
			Level = 9,
			Info = 920691,
			Ability = {
				{
					Value = 200002,
					Num = 648,
				},
				{
					Value = 200008,
					Num = 81,
				},
			},
			SkillList = {
				{
					Id = 100652,
					Value = 7,
				},
			},
		},
		{
			Level = 10,
			Info = 920691,
			Ability = {
				{
					Value = 200002,
					Num = 720,
				},
				{
					Value = 200008,
					Num = 90,
				},
			},
			SkillList = {
				{
					Id = 100652,
					Value = 7,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id658] =
{
	Character = 223108,
	Rarity = 5,
	NeedChallenge = 145256,
	UpgradeId = 930019,
	LevelList = {
		{
			Level = 1,
			Info = 920692,
			Ability = {
				{
					Value = 200002,
					Num = 144,
				},
			},
		},
		{
			Level = 2,
			Info = 920692,
			Ability = {
				{
					Value = 200002,
					Num = 240,
				},
			},
		},
		{
			Level = 3,
			Info = 920692,
			Ability = {
				{
					Value = 200002,
					Num = 336,
				},
			},
		},
		{
			Level = 4,
			Info = 920692,
			Ability = {
				{
					Value = 200002,
					Num = 432,
				},
			},
		},
		{
			Level = 5,
			Info = 920692,
			Ability = {
				{
					Value = 200002,
					Num = 528,
				},
				{
					Value = 200004,
					Num = 25,
				},
			},
		},
		{
			Level = 6,
			Info = 920692,
			Ability = {
				{
					Value = 200002,
					Num = 624,
				},
				{
					Value = 200004,
					Num = 30,
				},
			},
		},
		{
			Level = 7,
			Info = 920692,
			Ability = {
				{
					Value = 200002,
					Num = 720,
				},
				{
					Value = 200004,
					Num = 35,
				},
			},
		},
		{
			Level = 8,
			Info = 920692,
			Ability = {
				{
					Value = 200002,
					Num = 816,
				},
				{
					Value = 200004,
					Num = 40,
				},
			},
			SkillList = {
				{
					Id = 100555,
					Value = 25,
				},
			},
		},
		{
			Level = 9,
			Info = 920692,
			Ability = {
				{
					Value = 200002,
					Num = 912,
				},
				{
					Value = 200004,
					Num = 45,
				},
			},
			SkillList = {
				{
					Id = 100555,
					Value = 25,
				},
			},
		},
		{
			Level = 10,
			Info = 920692,
			Ability = {
				{
					Value = 200002,
					Num = 1008,
				},
				{
					Value = 200004,
					Num = 50,
				},
			},
			SkillList = {
				{
					Id = 100555,
					Value = 25,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id659] =
{
	Character = 223108,
	Rarity = 5,
	NeedChallenge = 145257,
	UpgradeId = 930020,
	LevelList = {
		{
			Level = 1,
			Info = 920693,
			Ability = {
				{
					Value = 200002,
					Num = 216,
				},
			},
		},
		{
			Level = 2,
			Info = 920693,
			Ability = {
				{
					Value = 200002,
					Num = 336,
				},
			},
		},
		{
			Level = 3,
			Info = 920693,
			Ability = {
				{
					Value = 200002,
					Num = 456,
				},
			},
		},
		{
			Level = 4,
			Info = 920693,
			Ability = {
				{
					Value = 200002,
					Num = 576,
				},
			},
		},
		{
			Level = 5,
			Info = 920693,
			Ability = {
				{
					Value = 200002,
					Num = 696,
				},
				{
					Value = 200004,
					Num = 25,
				},
			},
		},
		{
			Level = 6,
			Info = 920693,
			Ability = {
				{
					Value = 200002,
					Num = 816,
				},
				{
					Value = 200004,
					Num = 30,
				},
			},
		},
		{
			Level = 7,
			Info = 920693,
			Ability = {
				{
					Value = 200002,
					Num = 936,
				},
				{
					Value = 200004,
					Num = 35,
				},
			},
		},
		{
			Level = 8,
			Info = 920693,
			Ability = {
				{
					Value = 200002,
					Num = 1056,
				},
				{
					Value = 200004,
					Num = 40,
				},
			},
			SkillList = {
				{
					Id = 100605,
					Value = 36,
				},
			},
		},
		{
			Level = 9,
			Info = 920693,
			Ability = {
				{
					Value = 200002,
					Num = 1176,
				},
				{
					Value = 200004,
					Num = 45,
				},
			},
			SkillList = {
				{
					Id = 100605,
					Value = 36,
				},
			},
		},
		{
			Level = 10,
			Info = 920693,
			Ability = {
				{
					Value = 200002,
					Num = 1296,
				},
				{
					Value = 200004,
					Num = 50,
				},
			},
			SkillList = {
				{
					Id = 100605,
					Value = 36,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id660] =
{
	Character = 223121,
	Rarity = 3,
	UpgradeId = 930029,
	LevelList = {
		{
			Level = 1,
			Info = 920694,
			Ability = {
				{
					Value = 200001,
					Num = 57,
				},
				{
					Value = 200005,
					Num = 12,
				},
			},
		},
		{
			Level = 2,
			Info = 920694,
			Ability = {
				{
					Value = 200001,
					Num = 114,
				},
				{
					Value = 200005,
					Num = 24,
				},
			},
		},
		{
			Level = 3,
			Info = 920694,
			Ability = {
				{
					Value = 200001,
					Num = 171,
				},
				{
					Value = 200005,
					Num = 36,
				},
			},
		},
		{
			Level = 4,
			Info = 920694,
			Ability = {
				{
					Value = 200001,
					Num = 228,
				},
				{
					Value = 200005,
					Num = 48,
				},
			},
		},
		{
			Level = 5,
			Info = 920694,
			Ability = {
				{
					Value = 200001,
					Num = 285,
				},
				{
					Value = 200005,
					Num = 60,
				},
			},
		},
		{
			Level = 6,
			Info = 920694,
			Ability = {
				{
					Value = 200001,
					Num = 342,
				},
				{
					Value = 200005,
					Num = 72,
				},
			},
		},
		{
			Level = 7,
			Info = 920694,
			Ability = {
				{
					Value = 200001,
					Num = 399,
				},
				{
					Value = 200005,
					Num = 84,
				},
			},
		},
		{
			Level = 8,
			Info = 920694,
			Ability = {
				{
					Value = 200001,
					Num = 456,
				},
				{
					Value = 200005,
					Num = 96,
				},
			},
			SkillList = {
				{
					Id = 100656,
					Value = 10,
				},
			},
		},
		{
			Level = 9,
			Info = 920694,
			Ability = {
				{
					Value = 200001,
					Num = 513,
				},
				{
					Value = 200005,
					Num = 108,
				},
			},
			SkillList = {
				{
					Id = 100656,
					Value = 10,
				},
			},
		},
		{
			Level = 10,
			Info = 920694,
			Ability = {
				{
					Value = 200001,
					Num = 570,
				},
				{
					Value = 200005,
					Num = 120,
				},
			},
			SkillList = {
				{
					Id = 100656,
					Value = 10,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id661] =
{
	Character = 223121,
	Rarity = 3,
	UpgradeId = 930010,
	LevelList = {
		{
			Level = 1,
			Info = 920696,
			Ability = {
				{
					Value = 200002,
					Num = 42,
				},
				{
					Value = 200006,
					Num = 9,
				},
			},
		},
		{
			Level = 2,
			Info = 920696,
			Ability = {
				{
					Value = 200002,
					Num = 84,
				},
				{
					Value = 200006,
					Num = 18,
				},
			},
		},
		{
			Level = 3,
			Info = 920696,
			Ability = {
				{
					Value = 200002,
					Num = 126,
				},
				{
					Value = 200006,
					Num = 27,
				},
			},
		},
		{
			Level = 4,
			Info = 920696,
			Ability = {
				{
					Value = 200002,
					Num = 168,
				},
				{
					Value = 200006,
					Num = 36,
				},
			},
		},
		{
			Level = 5,
			Info = 920696,
			Ability = {
				{
					Value = 200002,
					Num = 210,
				},
				{
					Value = 200006,
					Num = 45,
				},
			},
		},
		{
			Level = 6,
			Info = 920696,
			Ability = {
				{
					Value = 200002,
					Num = 252,
				},
				{
					Value = 200006,
					Num = 54,
				},
			},
		},
		{
			Level = 7,
			Info = 920696,
			Ability = {
				{
					Value = 200002,
					Num = 294,
				},
				{
					Value = 200006,
					Num = 63,
				},
			},
		},
		{
			Level = 8,
			Info = 920696,
			Ability = {
				{
					Value = 200002,
					Num = 336,
				},
				{
					Value = 200006,
					Num = 72,
				},
			},
			SkillList = {
				{
					Id = 100655,
					Value = 10,
				},
			},
		},
		{
			Level = 9,
			Info = 920696,
			Ability = {
				{
					Value = 200002,
					Num = 378,
				},
				{
					Value = 200006,
					Num = 81,
				},
			},
			SkillList = {
				{
					Id = 100655,
					Value = 10,
				},
			},
		},
		{
			Level = 10,
			Info = 920696,
			Ability = {
				{
					Value = 200002,
					Num = 420,
				},
				{
					Value = 200006,
					Num = 90,
				},
			},
			SkillList = {
				{
					Id = 100655,
					Value = 10,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id662] =
{
	Character = 223121,
	Rarity = 3,
	NeedChallenge = 145258,
	UpgradeId = 930011,
	LevelList = {
		{
			Level = 1,
			Info = 920695,
			Ability = {
				{
					Value = 200002,
					Num = 84,
				},
			},
		},
		{
			Level = 2,
			Info = 920695,
			Ability = {
				{
					Value = 200002,
					Num = 140,
				},
			},
		},
		{
			Level = 3,
			Info = 920695,
			Ability = {
				{
					Value = 200002,
					Num = 196,
				},
			},
		},
		{
			Level = 4,
			Info = 920695,
			Ability = {
				{
					Value = 200002,
					Num = 252,
				},
			},
		},
		{
			Level = 5,
			Info = 920695,
			Ability = {
				{
					Value = 200002,
					Num = 308,
				},
				{
					Value = 200004,
					Num = 25,
				},
			},
		},
		{
			Level = 6,
			Info = 920695,
			Ability = {
				{
					Value = 200002,
					Num = 364,
				},
				{
					Value = 200004,
					Num = 30,
				},
			},
		},
		{
			Level = 7,
			Info = 920695,
			Ability = {
				{
					Value = 200002,
					Num = 420,
				},
				{
					Value = 200004,
					Num = 35,
				},
			},
		},
		{
			Level = 8,
			Info = 920695,
			Ability = {
				{
					Value = 200002,
					Num = 476,
				},
				{
					Value = 200004,
					Num = 40,
				},
			},
			SkillList = {
				{
					Id = 101902,
					Value = 12,
				},
			},
		},
		{
			Level = 9,
			Info = 920695,
			Ability = {
				{
					Value = 200002,
					Num = 532,
				},
				{
					Value = 200004,
					Num = 45,
				},
			},
			SkillList = {
				{
					Id = 101902,
					Value = 12,
				},
			},
		},
		{
			Level = 10,
			Info = 920695,
			Ability = {
				{
					Value = 200002,
					Num = 588,
				},
				{
					Value = 200004,
					Num = 50,
				},
			},
			SkillList = {
				{
					Id = 101902,
					Value = 12,
				},
			},
		},
	},
}
