LocalizationConfig={};
LocalizationConfig["loc_confirm"] =
{
	zh = "确认",
	en = "OK",
	zht = "確認",
}
LocalizationConfig["loc_cancel"] =
{
	zh = "取消",
	en = "Cancel",
	zht = "取消",
}
LocalizationConfig["loc_Music"] =
{
	zh = "音乐",
	en = "Music",
	zht = "音樂",
}
LocalizationConfig["loc_Sound"] =
{
	zh = "声音",
	en = "Sound",
	zht = "聲音",
}
LocalizationConfig["loc_Notification"] =
{
	zh = "推送",
	en = "Notification",
	zht = "推送",
}
LocalizationConfig["loc_Language"] =
{
	zh = "语言",
	en = "Language",
	zht = "語言",
}
LocalizationConfig["loc_CurrentLanguage"] =
{
	zh = "中文",
	en = "English",
	zht = "繁体中文",
}
LocalizationConfig["loc_TurnOn"] =
{
	zh = "开启",
	en = "On",
	zht = "開啟",
}
LocalizationConfig["loc_TurnOff"] =
{
	zh = "关闭",
	en = "Off",
	zht = "關閉",
}
LocalizationConfig["loc_AbilityNotMatch"] =
{
	zh = "属性不匹配",
	en = "Unmatched",
	zht = "屬性不匹配",
}
LocalizationConfig["loc_SimpleStage"] =
{
	zh = "%d阶",
	en = "LV.%d",
	zht = "%d級",
}
LocalizationConfig["loc_SimpleLevel"] =
{
	zh = "%d级",
	en = "LV.%d",
	zht = "%d級",
}
LocalizationConfig["loc_FullLevel"] =
{
	zh = "等级",
	en = "Level",
	zht = "等級",
}
LocalizationConfig["loc_Miss"] =
{
	zh = "miss",
	en = "miss",
	zht = "miss",
}
LocalizationConfig["loc_Max"] =
{
	zh = "MAX",
	en = "MAX",
	zht = "MAX",
}
LocalizationConfig["loc_PlanetLevelUnlock"] =
{
	zh = "%d级解锁",
	en = "Unlocks at LV.%d",
	zht = "%d級解鎖",
}
LocalizationConfig["loc_LabLevelUnlock"] =
{
	zh = "实验室%d级解锁",
	en = "Unlocks at Lab LV.%d",
	zht = "實驗室%d級解鎖",
}
LocalizationConfig["loc_LabFull"] =
{
	zh = "实验室没有空位",
	en = "No empty space",
	zht = "實驗室沒有空位",
}
LocalizationConfig["loc_LabTitle"] =
{
	zh = "实验室",
	en = "Lab",
	zht = "實驗室",
}
LocalizationConfig["loc_LabCraftTarget"] =
{
	zh = "合成目标：",
	en = "Craft Target",
	zht = "合成目標：",
}
LocalizationConfig["loc_LabCrafting"] =
{
	zh = "合成中",
	en = "Crafting",
	zht = "合成中",
}
LocalizationConfig["loc_LabRebooting"] =
{
	zh = "正在重启系统…………",
	en = "Rebooting…",
	zht = "正在重啟系統…………",
}
LocalizationConfig["loc_Complete"] =
{
	zh = "完成",
	en = "Complete",
	zht = "完成",
}
LocalizationConfig["loc_Completed"] =
{
	zh = "已结束",
	en = "Ended",
	zht = "已結束",
}
LocalizationConfig["loc_ExpValue"] =
{
	zh = "经验值",
	en = "EXP",
	zht = "經驗值",
}
LocalizationConfig["loc_Exp"] =
{
	zh = "经验",
	en = "EXP",
	zht = "經驗",
}
LocalizationConfig["loc_CollectionProgress"] =
{
	zh = "收集度",
	en = "Collection Progress",
	zht = "收集度",
}
LocalizationConfig["loc_Submit"] =
{
	zh = "提交",
	en = "Submit",
	zht = "提交",
}
LocalizationConfig["loc_Reward"] =
{
	zh = "领取",
	en = "Claim",
	zht = "領取",
}
LocalizationConfig["loc_CharacterNoSkill"] =
{
	zh = "就一条咸鱼，什么技能都没有",
	en = "Lowest of the low hoping for better days. Has no skills at all",
	zht = "就一條鹹魚，什麼技能都沒有",
}
LocalizationConfig["loc_SkinNoSkill"] =
{
	zh = "朴素套装，什么技能都没有",
	en = "Just an average Joe with no skills, wearing plain clothes",
	zht = "樸素套裝，什麼技能都沒有",
}
LocalizationConfig["loc_ExploreHint"] =
{
	zh = "此次探索不会获得任务物品，只获得一定的经验",
	en = "This exploration will not acquire any quest items, but some EXP",
	zht = "此次探索不會獲得任務物品，只獲得一定的經驗",
}
LocalizationConfig["loc_CraftMaterialNotEnough"] =
{
	zh = "研发所需要的素材不足",
	en = "Insufficient materials for research",
	zht = "研發所需要的素材不足",
}
LocalizationConfig["loc_LabStackNumberWarning"] =
{
	zh = "%s物品一次研发上限%d个",
	en = "%d %s are allowed for each research at most",
	zht = "%s物品一次研發上限%d個",
}
LocalizationConfig["loc_DiamondNotEnough"] =
{
	zh = "玉璧不足",
	en = "Not enough Jade",
	zht = "玉璧不足",
}
LocalizationConfig["loc_GoldNotEnough"] =
{
	zh = "金币不足",
	en = "Not enough Gold",
	zht = "金幣不足",
}
LocalizationConfig["loc_UpgradeMaterialNotEnough"] =
{
	zh = "所需物品不足",
	en = "Insufficient items",
	zht = "所需物品不足",
}
LocalizationConfig["loc_QuitGame"] =
{
	zh = "退出游戏？",
	en = "Quit now?",
	zht = "退出遊戲？",
}
LocalizationConfig["loc_SummonCompleted"] =
{
	zh = "活动池已结束",
	en = "Event Pool has ended",
	zht = "活動池已結束",
}
LocalizationConfig["loc_Challenge"] =
{
	zh = "挑战",
	en = "Challenge",
	zht = "挑戰",
}
LocalizationConfig["loc_Activated"] =
{
	zh = "已激活",
	en = "Activated",
	zht = "已啟動",
}
LocalizationConfig["loc_NotActivated"] =
{
	zh = "未激活",
	en = "Not Activated",
	zht = "未啟動",
}
LocalizationConfig["loc_Start"] =
{
	zh = "开始",
	en = "Start",
	zht = "開始",
}
LocalizationConfig["loc_LabSpeedBuff"] =
{
	zh = "生产速度加成",
	en = "Production Speed Bonus",
	zht = "生產速度加成",
}
LocalizationConfig["loc_LabRoomNumber"] =
{
	zh = "生产车间数量",
	en = "Workshops",
	zht = "生產車間數量",
}
LocalizationConfig["loc_LabStackNumber"] =
{
	zh = "物品堆叠数量",
	en = "Stacked Items",
	zht = "物品堆疊數量",
}
LocalizationConfig["loc_ShowArea"] =
{
	zh = "在星球上表演",
	en = "Show on the planet",
	zht = "在星球上表演",
}
LocalizationConfig["loc_WatchArea"] =
{
	zh = "前往观看",
	en = "Go watch",
	zht = "前往觀看",
}
LocalizationConfig["loc_Exploring"] =
{
	zh = "探索中",
	en = "Exploring",
	zht = "探索中",
}
LocalizationConfig["loc_Labing"] =
{
	zh = "实验中",
	en = "Experimenting",
	zht = "實驗中",
}
LocalizationConfig["loc_White"] =
{
	zh = "白色",
	en = "White",
	zht = "白色",
}
LocalizationConfig["loc_Blue"] =
{
	zh = "蓝色",
	en = "Blue",
	zht = "藍色",
}
LocalizationConfig["loc_Purple"] =
{
	zh = "紫色",
	en = "Purple",
	zht = "紫色",
}
LocalizationConfig["loc_Gold"] =
{
	zh = "金色",
	en = "Gold",
	zht = "金色",
}
LocalizationConfig["loc_Colour"] =
{
	zh = "彩色",
	en = "Colour",
	zht = "彩色",
}
LocalizationConfig["loc_Global_Confirm"] =
{
	zh = "确认",
	en = "Confirm",
	zht = "確認",
}
LocalizationConfig["loc_Global_Return"] =
{
	zh = "返回",
	en = "Back",
	zht = "返回",
}
LocalizationConfig["loc_Global_Start"] =
{
	zh = "出发",
	en = "Depart",
	zht = "出發",
}
LocalizationConfig["loc_Global_SpeedUp"] =
{
	zh = "加速",
	en = "Accelerate",
	zht = "加速",
}
LocalizationConfig["loc_Global_Select"] =
{
	zh = "选择",
	en = "Select",
	zht = "選擇",
}
LocalizationConfig["loc_Global_Unload"] =
{
	zh = "卸下",
	en = "Unequip",
	zht = "卸下",
}
LocalizationConfig["loc_Global_Unable"] =
{
	zh = "不能选",
	en = "Cannot be selected",
	zht = "不能選",
}
LocalizationConfig["loc_CannotChanged"] =
{
	zh = "探索中无法更换",
	en = "Cannot be changed during exploration",
	zht = "探索中無法更換",
}
LocalizationConfig["loc_ShipSelect"] =
{
	zh = "选择飞船",
	en = "Select Spaceship",
	zht = "選擇飛船",
}
LocalizationConfig["loc_UpgradePlanet"] =
{
	zh = "升级星球",
	en = "Upgrade Planet",
	zht = "升級星球",
}
LocalizationConfig["loc_Spaceship"] =
{
	zh = "飞船",
	en = "Spaceship",
	zht = "飛船",
}
LocalizationConfig["loc_Planet"] =
{
	zh = "星球",
	en = "Planet",
	zht = "星球",
}
LocalizationConfig["loc_Character"] =
{
	zh = "角色",
	en = "Character",
	zht = "角色",
}
LocalizationConfig["loc_Goods"] =
{
	zh = "物品",
	en = "Items",
	zht = "物品",
}
LocalizationConfig["loc_Equipment"] =
{
	zh = "装备",
	en = "Equipment",
	zht = "裝備",
}
LocalizationConfig["loc_Skin"] =
{
	zh = "换装",
	en = "Swap equipment",
	zht = "換裝",
}
LocalizationConfig["loc_PlanetRank1"] =
{
	zh = "一级",
	en = "Lv.1",
	zht = "一級",
}
LocalizationConfig["loc_PlanetRank2"] =
{
	zh = "二级",
	en = "Lv.2",
	zht = "二級",
}
LocalizationConfig["loc_PlanetRank3"] =
{
	zh = "三级",
	en = "Lv.3",
	zht = "三級",
}
LocalizationConfig["loc_PlanetRank4"] =
{
	zh = "四级",
	en = "Lv.4",
	zht = "四級",
}
LocalizationConfig["loc_PlanetRank5"] =
{
	zh = "五级",
	en = "Lv.5",
	zht = "五級",
}
LocalizationConfig["loc_MainTask"] =
{
	zh = "主线",
	en = "Main",
	zht = "主線",
}
LocalizationConfig["loc_SideTask"] =
{
	zh = "支线",
	en = "Side",
	zht = "支線",
}
LocalizationConfig["loc_WeekTask"] =
{
	zh = "周常",
	en = "Weekly ",
	zht = "周常",
}
LocalizationConfig["loc_ActivityTask"] =
{
	zh = "活动",
	en = "Event",
	zht = "活動",
}
LocalizationConfig["loc_Restart"] =
{
	zh = "正在重启系统",
	en = "Rebooting…",
	zht = "正在重啟系統",
}
LocalizationConfig["loc_UpgradeLab"] =
{
	zh = "升级实验室",
	en = "Upgrade Lab",
	zht = "升級實驗室",
}
LocalizationConfig["loc_UpgradeAddition"] =
{
	zh = "升级加成",
	en = "Upgrade Bonus",
	zht = "升級加成",
}
LocalizationConfig["loc_UpgradeGoods"] =
{
	zh = "升级材料",
	en = "Upgrade Materials",
	zht = "升級材料",
}
LocalizationConfig["loc_Settle"] =
{
	zh = "结算",
	en = "Tally",
	zht = "結算",
}
LocalizationConfig["loc_NewArea"] =
{
	zh = "解锁区域",
	en = "Unlock Area",
	zht = "解鎖區域",
}
LocalizationConfig["loc_UpgradeConditions"] =
{
	zh = "升级条件",
	en = "Upgrade Requirements",
	zht = "升級條件",
}
LocalizationConfig["loc_TimeLeft"] =
{
	zh = "剩余时间",
	en = "Time Remaining",
	zht = "剩餘時間",
}
LocalizationConfig["loc_Once"] =
{
	zh = "抽1次",
	en = "Draw Once",
	zht = "抽1次",
}
LocalizationConfig["loc_TenTimes"] =
{
	zh = "抽10次",
	en = "Draw 10 Times",
	zht = "抽10次",
}
LocalizationConfig["loc_SummonPreviewTitle"] =
{
	zh = "奖池内容",
	en = "Reward Pool Content",
	zht = "獎池內容",
}
LocalizationConfig["loc_Chip"] =
{
	zh = "珍宝",
	en = "Chip",
	zht = "晶片",
}
LocalizationConfig["loc_Global_Filter"] =
{
	zh = "筛选",
	en = "Filter",
	zht = "篩選",
}
LocalizationConfig["loc_Global_SetUp"] =
{
	zh = "设置",
	en = "Settings",
	zht = "設置",
}
LocalizationConfig["loc_Global_SignIn"] =
{
	zh = "签到",
	en = "Sign in",
	zht = "簽到",
}
LocalizationConfig["loc_Global_Notice"] =
{
	zh = "公告",
	en = "Notice",
	zht = "公告",
}
LocalizationConfig["loc_Global_Mail"] =
{
	zh = "邮件",
	en = "Mail",
	zht = "郵件",
}
LocalizationConfig["loc_Global_Reset"] =
{
	zh = "重置",
	en = "Reset",
	zht = "重置",
}
LocalizationConfig["loc_Global_Try"] =
{
	zh = "试穿",
	en = "Try On",
	zht = "試穿",
}
LocalizationConfig["loc_Global_Task"] =
{
	zh = "任务",
	en = "Task",
	zht = "任務",
}
LocalizationConfig["loc_Global_Hi"] =
{
	zh = "咦",
	en = "Hi",
	zht = "咦",
}
LocalizationConfig["loc_Global_Reward"] =
{
	zh = "奖励",
	en = "Reward",
	zht = "獎勵",
}
LocalizationConfig["loc_global_item_detail_1"] =
{
	zh = "来源",
	en = "Source",
	zht = "來源",
}
LocalizationConfig["loc_global_item_detail_2"] =
{
	zh = "介绍",
	en = "Introduction",
	zht = "介紹",
}
LocalizationConfig["loc_global_item_detail_3"] =
{
	zh = "配方",
	en = "Formula",
	zht = "配方",
}
LocalizationConfig["loc_global_item_detail_4"] =
{
	zh = "技能",
	en = "Skill",
	zht = "技能",
}
LocalizationConfig["loc_global_item_detail_5"] =
{
	zh = "套装部件",
	en = "Suit Part",
	zht = "套裝部件",
}
LocalizationConfig["loc_global_item_source_explore"] =
{
	zh = "探索",
	en = "Exploration",
	zht = "探索",
}
LocalizationConfig["loc_global_item_source_mission"] =
{
	zh = "任务",
	en = "Mission",
	zht = "任務",
}
LocalizationConfig["loc_global_item_source_summon"] =
{
	zh = "抽奖",
	en = "Summon",
	zht = "抽獎",
}
LocalizationConfig["loc_global_item_source_craft"] =
{
	zh = "合成",
	en = "Craft",
	zht = "合成",
}
LocalizationConfig["loc_global_item_source_package"] =
{
	zh = "礼包",
	en = "Pack",
	zht = "禮包",
}
LocalizationConfig["loc_global_deco_source_0"] =
{
	zh = "已拥有",
	en = "Owned",
	zht = "已擁有",
}
LocalizationConfig["loc_global_deco_source_explore"] =
{
	zh = "探索获得",
	en = "From Exploration",
	zht = "探索獲得",
}
LocalizationConfig["loc_global_deco_source_mission"] =
{
	zh = "任务获得",
	en = "From Mission",
	zht = "任務獲得",
}
LocalizationConfig["loc_global_deco_source_summon"] =
{
	zh = "抽奖获得",
	en = "From Summon",
	zht = "抽獎獲得",
}
LocalizationConfig["loc_global_deco_source_craft"] =
{
	zh = "合成获得",
	en = "From Craft",
	zht = "合成獲得",
}
LocalizationConfig["loc_global_deco_source_package"] =
{
	zh = "礼包赠送",
	en = "From Pack",
	zht = "禮包贈送",
}
LocalizationConfig["loc_global_deco_buy_confirm"] =
{
	zh = "是否确认购买，消耗：",
	en = "Confirm purchase and spend:",
	zht = "是否確認購買，消耗：",
}
LocalizationConfig["loc_global_deco_buy_fail"] =
{
	zh = "哎呀呀，钱不太够呢",
	en = "Oh dear, you don't quite have enough money",
	zht = "哎呀呀，錢不太夠呢",
}
LocalizationConfig["loc_global_deco_do_not_own"] =
{
	zh = "您还没有获得这件物品，不能装备",
	en = "You haven't yet obtained this item, unable to equip",
	zht = "您還沒有獲得這件物品，不能裝備",
}
LocalizationConfig["loc_global_gallary_didnot_unlock"] =
{
	zh = "未解锁",
	en = "Locked",
	zht = "未解鎖",
}
LocalizationConfig["loc_global_furniture"] =
{
	zh = "家具",
	en = "Item",
	zht = "傢俱",
}
LocalizationConfig["loc_global_server_dev"] =
{
	zh = "开发服",
	en = "Development Server",
	zht = "開發服",
}
LocalizationConfig["loc_global_server_qa"] =
{
	zh = "测试服",
	en = "Beta Server",
	zht = "測試服",
}
LocalizationConfig["loc_global_server_online"] =
{
	zh = "正式服",
	en = "Official Server",
	zht = "正式服",
}
LocalizationConfig["loc_global_id_empty"] =
{
	zh = "账号不能为空",
	en = "Account cannot be blank",
	zht = "帳號不能為空",
}
LocalizationConfig["loc_global_password_empty"] =
{
	zh = "密码不能为空",
	en = "Password cannot be blank",
	zht = "密碼不能為空",
}
LocalizationConfig["loc_global_initial_password_empty"] =
{
	zh = "初始密码不能为空",
	en = "Initial password cannot be blank",
	zht = "初始密碼不能為空",
}
LocalizationConfig["loc_global_new_password_empty"] =
{
	zh = "新密码不能为空",
	en = "New password cannot be blank",
	zht = "新密碼不能為空",
}
LocalizationConfig["loc_global_password_no_match"] =
{
	zh = "新密码不一致",
	en = "New password doesn't match",
	zht = "新密碼不一致",
}
LocalizationConfig["loc_global_password_change_succeed"] =
{
	zh = "密码修改成功",
	en = "Successfully changed password",
	zht = "密碼修改成功",
}
LocalizationConfig["loc_global_need_finish_mission"] =
{
	zh = "完成主线任务解锁模块",
	en = "Complete main storyline to unlock modules",
	zht = "完成主線任務解鎖模組",
}
LocalizationConfig["loc_global_star_lock"] =
{
	zh = "星球未解锁",
	en = "Planet Locked",
	zht = "星球未解鎖",
}
LocalizationConfig["loc_global_lottery_lock"] =
{
	zh = "抽奖池暂未开放",
	en = "Summon Pool is not yet available",
	zht = "抽獎池暫未開放",
}
LocalizationConfig["loc_global_recipe_lock"] =
{
	zh = "合成配方未解锁",
	en = "Craft formula locked",
	zht = "合成配方未解鎖",
}
LocalizationConfig["loc_global_finish_mission"] =
{
	zh = "点击领取",
	en = "Click to collect",
	zht = "點擊領取",
}
LocalizationConfig["loc_global_finish_explore"] =
{
	zh = "完成探索",
	en = "Exploration completed",
	zht = "完成探索",
}
LocalizationConfig["loc_global_finish_workshop"] =
{
	zh = "打工店报酬已结清，领取后才能继续工作。",
	en = "打工店报酬已结清，领取后才能继续工作。",
	zht = "打工店报酬已结清，领取后才能继续工作。",
}
LocalizationConfig["loc_global_x_day"] =
{
	zh = "第%d天",
	en = "Day %d",
	zht = "第%d天",
}
LocalizationConfig["loc_global_today"] =
{
	zh = "今天",
	en = "Today",
	zht = "今天",
}
LocalizationConfig["loc_global_character_used"] =
{
	zh = "角色已经被占用",
	en = "Character is already in use",
	zht = "角色已經被佔用",
}
LocalizationConfig["loc_global_cancel_explore_confirm"] =
{
	zh = "确认取消探索？",
	en = "Are you sure you want to cancel exploration?",
	zht = "確認取消探索？",
}
LocalizationConfig["loc_global_sell_item_confirm"] =
{
	zh = "确认卖出物品？",
	en = "Are you sure you want to sell this item?",
	zht = "確認賣出物品？",
}
LocalizationConfig["loc_global_no_item_selected"] =
{
	zh = "未选择任何物品",
	en = "You haven't selected any items",
	zht = "未選擇任何物品",
}
LocalizationConfig["loc_global_error_code_1"] =
{
	zh = "解密消息错误",
	en = "Decipher information error",
	zht = "解密消息錯誤",
}
LocalizationConfig["loc_global_error_code_2"] =
{
	zh = "登录状态过期，游戏将重启",
	en = "Login has expired, the game will reset",
	zht = "登錄狀態過期，遊戲將重啟",
}
LocalizationConfig["loc_global_error_code_3"] =
{
	zh = "数据库错误",
	en = "Database error",
	zht = "資料庫錯誤",
}
LocalizationConfig["loc_global_error_code_4"] =
{
	zh = "账户被禁止登录",
	en = "Account has been banned",
	zht = "帳戶被禁止登錄",
}
LocalizationConfig["loc_global_error_code_5"] =
{
	zh = "密码错误",
	en = "Password error",
	zht = "密碼錯誤",
}
LocalizationConfig["loc_global_error_code_6"] =
{
	zh = "用户未找到",
	en = "User not found",
	zht = "用戶未找到",
}
LocalizationConfig["loc_global_error_code_31"] =
{
	zh = "实名,证件号，手机号格式错误",
	en = "Name verification, identification or phone number format error",
	zht = "實名,證件號，手機號格式錯誤",
}
LocalizationConfig["loc_global_error_code_32"] =
{
	zh = "账号重复绑定",
	en = "Account has already been bound",
	zht = "帳號重複綁定",
}
LocalizationConfig["loc_global_error_code_33"] =
{
	zh = "请求验证码错误",
	en = "Verification code request error",
	zht = "請求驗證碼錯誤",
}
LocalizationConfig["loc_global_error_code_34"] =
{
	zh = "验证验证码错误",
	en = "Verification error",
	zht = "驗證驗證碼錯誤",
}
LocalizationConfig["loc_global_error_code_35"] =
{
	zh = "密码格式错误",
	en = "Password format error",
	zht = "密碼格式錯誤",
}
LocalizationConfig["loc_global_error_code_36"] =
{
	zh = "昵称未找到",
	en = "Nickname not found",
	zht = "昵稱未找到",
}
LocalizationConfig["loc_global_error_code_37"] =
{
	zh = "绑定手机号错误",
	en = "Phone number binding error",
	zht = "綁定手機號錯誤",
}
LocalizationConfig["loc_global_error_code_38"] =
{
	zh = "暂停支付",
	en = "Temporarily stop payment",
	zht = "暫停支付",
}
LocalizationConfig["loc_global_error_code_39"] =
{
	zh = "禁止支付",
	en = "Prohibit payment",
	zht = "禁止支付",
}
LocalizationConfig["loc_global_error_code_103"] =
{
	zh = "禁止抽奖",
	en = "[未翻译]禁止抽奖",
	zht = "禁止支付",
}
LocalizationConfig["loc_global_error_code"] =
{
	zh = "错误码",
	en = "Error code",
	zht = "錯誤碼",
}
LocalizationConfig["loc_global_error_code_game_reset"] =
{
	zh = "游戏将重启",
	en = "The game will reset",
	zht = "遊戲將重啟",
}
LocalizationConfig["loc_global_time_day"] =
{
	zh = "天",
	en = "Days",
	zht = "天",
}
LocalizationConfig["loc_global_time_hour"] =
{
	zh = "小时",
	en = "Hours",
	zht = "小時",
}
LocalizationConfig["loc_global_time_minite"] =
{
	zh = "分钟",
	en = "Minutes",
	zht = "分鐘",
}
LocalizationConfig["loc_global_time_second"] =
{
	zh = "秒",
	en = "Seconds",
	zht = "秒",
}
LocalizationConfig["loc_global_freakplanet"] =
{
	zh = "妙奇星球",
	en = "Wonderful Planet",
	zht = "妙奇星球",
}
LocalizationConfig["loc_global_cellphone_empty"] =
{
	zh = "手机号不能为空",
	en = "Phone number cannot be blank",
	zht = "手機號不能為空",
}
LocalizationConfig["loc_global_cellphone_code_empty"] =
{
	zh = "验证码不能为空",
	en = "Verification code cannot be blank",
	zht = "驗證碼不能為空",
}
LocalizationConfig["loc_global_cellphone_code_sent"] =
{
	zh = "验证码已发送至手机",
	en = "Verification code has been sent to your phone",
	zht = "驗證碼已發送至手機",
}
LocalizationConfig["loc_global_diamond_name"] =
{
	zh = "玉璧",
	en = "Jade",
	zht = "玉璧",
}
LocalizationConfig["loc_global_diamond_des"] =
{
	zh = "在这个奇妙的世界，玉璧是勤奋与财富的象征",
	en = "In this wonderous world, jade is the symbol of diligence and riches",
	zht = "在這個奇妙的世界，玉璧是勤奮與財富的象徵",
}
LocalizationConfig["loc_global_coin_name"] =
{
	zh = "金币",
	en = "Gold",
	zht = "金幣",
}
LocalizationConfig["loc_global_coin_des"] =
{
	zh = "在那个真实的世界，金币是快乐与梦想的象征",
	en = "In that 'real' world, gold represents happiness and dreams",
	zht = "在那個真實的世界，金幣是快樂與夢想的象徵",
}
LocalizationConfig["loc_global_upziping"] =
{
	zh = "解压文件：%d/%d",
	en = "Extracting Files: %d/%d",
	zht = "解壓文件：%d/%d",
}
LocalizationConfig["loc_update_file_error"] =
{
	zh = "部分文件更新失败，不影响继续游戏，是否重试？",
	en = "A part of the file failed to update but it won't affect your current gaming experience, would you like to retry?",
	zht = "部分檔更新失敗，不影響繼續遊戲，是否重試？",
}
LocalizationConfig["locsp_1"] =
{
	zh = "无法连接到网络",
	en = "Unable to connect to the network",
	zht = "無法連接到網路",
}
LocalizationConfig["locsp_2"] =
{
	zh = "网关",
	en = "Gateway",
	zht = "閘道",
}
LocalizationConfig["locsp_3"] =
{
	zh = "资源服务器",
	en = "Asset Server",
	zht = "資原始伺服器",
}
LocalizationConfig["locsp_4"] =
{
	zh = "游戏服务器",
	en = "Game Server",
	zht = "遊戲伺服器",
}
LocalizationConfig["locsp_5"] =
{
	zh = "请求出错",
	en = "Request error",
	zht = "請求出錯",
}
LocalizationConfig["locsp_6"] =
{
	zh = "请求被取消",
	en = "Request cancelled",
	zht = "請求被取消",
}
LocalizationConfig["locsp_7"] =
{
	zh = "请求连接超时",
	en = "Connection request timed out ",
	zht = "請求連接逾時",
}
LocalizationConfig["locsp_8"] =
{
	zh = "请求处理超时",
	en = "Process request timed out",
	zht = "請求處理超時",
}
LocalizationConfig["locsp_9"] =
{
	zh = "请求返回错误码",
	en = "Request error code",
	zht = "請求返回錯誤碼",
}
LocalizationConfig["locsp_10"] =
{
	zh = "下载启动文件",
	en = "Download starup files",
	zht = "下載開機檔案",
}
LocalizationConfig["locsp_11"] =
{
	zh = "下载游戏文件",
	en = "Download game files",
	zht = "下載遊戲檔",
}
LocalizationConfig["locsp_12"] =
{
	zh = "更新启动文件",
	en = "Update startup files",
	zht = "更新開機檔案",
}
LocalizationConfig["locsp_13"] =
{
	zh = "更新游戏文件",
	en = "Update game file",
	zht = "更新遊戲檔",
}
LocalizationConfig["locsp_14"] =
{
	zh = "重试",
	en = "Retry",
	zht = "重試",
}
LocalizationConfig["locsp_15"] =
{
	zh = "问题上报",
	en = "Report",
	zht = "問題上報",
}
LocalizationConfig["loc_ShipName_1"] =
{
	zh = "新手飞船",
	en = "Novice Ship",
	zht = "新手飛船",
}
LocalizationConfig["loc_ShipName_2"] =
{
	zh = "海盗飞船",
	en = "Pirate Ship",
	zht = "海盜飛船",
}
LocalizationConfig["loc_ShipName_3"] =
{
	zh = "复古飞船",
	en = "Vintage Ship",
	zht = "復古飛船",
}
LocalizationConfig["loc_ShipName_4"] =
{
	zh = "海马飞船",
	en = "Seahorse Ship",
	zht = "海馬飛船",
}
LocalizationConfig["loc_ShipName_5"] =
{
	zh = "章鱼飞船",
	en = "Octo Ship",
	zht = "章魚飛船",
}
LocalizationConfig["loc_ShipName_6"] =
{
	zh = "悬疑星飞船",
	en = "Suspense Ship",
	zht = "懸疑星飛船",
}
LocalizationConfig["loc_ShipName_7"] =
{
	zh = "美食星飞船",
	en = "Dessert Ship",
	zht = "美食星飛船",
}
LocalizationConfig["loc_ShipName_8"] =
{
	zh = "冒险星飞船",
	en = "Adventure Ship",
	zht = "冒險星飛船",
}
LocalizationConfig["loc_ShipName_9"] =
{
	zh = "博物馆星飞船",
	en = "Museum Ship",
	zht = "博物館星飛船",
}
LocalizationConfig["loc_ShipName_10"] =
{
	zh = "拖拉机飞船",
	en = "Tractor Ship",
	zht = "拖拉機飛船",
}
LocalizationConfig["loc_ShipName_11"] =
{
	zh = "捕鱼船飞船",
	en = "Fishing Ship",
	zht = "捕魚船飛船",
}
LocalizationConfig["loc_ShipDescribe_1"] =
{
	zh = "铁鱼潜水舱改造而来的飞船，可靠性非常强",
	en = "A ship made from an iron fish submarine, extremely reliable",
	zht = "鐵魚潛水艙改造而來的飛船，可靠性非常強",
}
LocalizationConfig["loc_ShipDescribe_2"] =
{
	zh = "海盗飞船在战斗掠夺方面有得天独厚的优势，谁上都会感觉到力量",
	en = "Pirate airships are the best suited for plundering during combat, anyone who boards it can feel the power of it.",
	zht = "海盜飛船在戰鬥掠奪方面有得天獨厚的優勢，誰上都會感覺到力量",
}
LocalizationConfig["loc_ShipDescribe_3"] =
{
	zh = "看起来破破烂烂的飞船，实际内部都是高科技，星间穿越什么都是小意思",
	en = "It looks like an old, tattered ship, but the insides are actually adorned with hi-tech equipment. It can travel between galaxies with the flick of a switch",
	zht = "看起來破破爛爛的飛船，實際內部都是高科技，星間穿越什麼都是小意思",
}
LocalizationConfig["loc_ShipDescribe_4"] =
{
	zh = "生物工程学的结晶，飞行效率增加不少",
	en = "A bioengineered crystal, greatly increases flying efficiency.",
	zht = "生物工程學的結晶，飛行效率增加不少",
}
LocalizationConfig["loc_ShipDescribe_5"] =
{
	zh = "八爪章鱼，手多行动次数也多。",
	en = "An octopus, it's many tentacles allow for more actions.",
	zht = "八爪章魚，手多行動次數也多。",
}
LocalizationConfig["loc_ShipDescribe_6"] =
{
	zh = "聪明人喜欢呆着的飞船，保证头脑活络",
	en = "Those who are smart like to stay on this ship to guarantee that their mind stays lively",
	zht = "聰明人喜歡呆著的飛船，保證頭腦活絡",
}
LocalizationConfig["loc_ShipDescribe_7"] =
{
	zh = "有着各类美食的熏陶，怎么也对料理有点帮助",
	en = "Has all sorts of nurturing foods, it provides a bit of assistance to food and cooking",
	zht = "有著各類美食的薰陶，怎麼也對料理有點幫助",
}
LocalizationConfig["loc_ShipDescribe_8"] =
{
	zh = "里面有各种模拟冒险游戏机，一天玩下来骨头都散了",
	en = "Filled with all sorts of virtual adventure games machines, you'll sink into your sofa after playing all day",
	zht = "裡面有各種模擬冒險遊戲機，一天玩下來骨頭都散了",
}
LocalizationConfig["loc_ShipDescribe_9"] =
{
	zh = "这个飞船被古代地球的各个神明保佑过，保你下半生猫粮不愁",
	en = "This ship has been blessed by many of the earth's ancient gods, giving you the blessing of cat food aplenty for the rest of your days",
	zht = "這個飛船被古代地球的各個神明保佑過，保你下半生貓糧不愁",
}
LocalizationConfig["loc_ShipDescribe_10"] =
{
	zh = "牛牌拖拉机，性能可靠不用多说",
	en = "Bull Tractor, needless to say it's rather reliable",
	zht = "牛牌拖拉機，性能可靠不用多說",
}
LocalizationConfig["loc_ShipDescribe_11"] =
{
	zh = "捕渔船有一天在太空中捞到一个金闪闪的鱼叉，据说是神器，怎么个神还没研究出来",
	en = "The fishing boat managed to catch a shiny trident one day while flying through space, it's said to be the artefact of a deity, but what deity exactly, no one is sure",
	zht = "捕漁船有一天在太空中撈到一個金閃閃的魚叉，據說是神器，怎麼個神還沒研究出來",
}
LocalizationConfig["loc_StarName_1"] =
{
	zh = "悬疑星",
	en = "Doubt Planet",
	zht = "懸疑星",
}
LocalizationConfig["loc_StarName_2"] =
{
	zh = "冒险星",
	en = "RPG Planet",
	zht = "冒險星",
}
LocalizationConfig["loc_StarName_3"] =
{
	zh = "美食星",
	en = "Fat Planet",
	zht = "美食星",
}
LocalizationConfig["loc_StarName_4"] =
{
	zh = "博物馆星",
	en = "[未翻译]博物馆星",
	zht = "博物館星",
}
LocalizationConfig["loc_AreaName_1"] =
{
	zh = "事件现场",
	en = "Scene of Event",
	zht = "事件現場",
}
LocalizationConfig["loc_AreaName_2"] =
{
	zh = "安静的街道",
	en = "Quiet Street",
	zht = "安靜的街道",
}
LocalizationConfig["loc_AreaName_3"] =
{
	zh = "警察局门口",
	en = "Police Station",
	zht = "警察局門口",
}
LocalizationConfig["loc_AreaName_4"] =
{
	zh = "检验室",
	en = "Lab",
	zht = "檢驗室",
}
LocalizationConfig["loc_AreaName_5"] =
{
	zh = "贝壳街",
	en = "Shell Street",
	zht = "貝殼街",
}
LocalizationConfig["loc_AreaName_6"] =
{
	zh = "不夜街",
	en = "Sleepless Street",
	zht = "不夜街",
}
LocalizationConfig["loc_AreaName_7"] =
{
	zh = "商业街",
	en = "High Street",
	zht = "商業街",
}
LocalizationConfig["loc_AreaName_8"] =
{
	zh = "楼顶天台",
	en = "Rooftop",
	zht = "樓頂天臺",
}
LocalizationConfig["loc_AreaName_9"] =
{
	zh = "初始城镇",
	en = "Starter Town",
	zht = "初始城鎮",
}
LocalizationConfig["loc_AreaName_10"] =
{
	zh = "地下迷宫",
	en = "Labyrinth",
	zht = "地下迷宮",
}
LocalizationConfig["loc_AreaName_11"] =
{
	zh = "洞穴入口",
	en = "Cave Entrance",
	zht = "洞穴入口",
}
LocalizationConfig["loc_AreaName_12"] =
{
	zh = "火焰山背",
	en = "Flame Mountain",
	zht = "火焰山背",
}
LocalizationConfig["loc_AreaName_13"] =
{
	zh = "神秘沼泽",
	en = "Mysterious Swamp",
	zht = "神秘沼澤",
}
LocalizationConfig["loc_AreaName_14"] =
{
	zh = "工会商店",
	en = "Guild Store",
	zht = "工會商店",
}
LocalizationConfig["loc_AreaName_15"] =
{
	zh = "迷雾森林",
	en = "Misty Forest",
	zht = "迷霧森林",
}
LocalizationConfig["loc_AreaName_16"] =
{
	zh = "暗夜空间",
	en = "Dark Plane",
	zht = "暗夜空間",
}
LocalizationConfig["loc_AreaName_17"] =
{
	zh = "可乐工厂",
	en = "Cola Factory",
	zht = "可樂工廠",
}
LocalizationConfig["loc_AreaName_18"] =
{
	zh = "冰淇淋街",
	en = "Walls Street",
	zht = "霜淇淋街",
}
LocalizationConfig["loc_AreaName_19"] =
{
	zh = "奶茶工厂",
	en = "Tea Factory",
	zht = "奶茶工廠",
}
LocalizationConfig["loc_AreaName_20"] =
{
	zh = "快餐街",
	en = "Fast Food Street",
	zht = "速食街",
}
LocalizationConfig["loc_AreaName_21"] =
{
	zh = "巧克力小镇",
	en = "Chocolate Town",
	zht = "巧克力小鎮",
}
LocalizationConfig["loc_AreaName_22"] =
{
	zh = "抹茶蛋糕园",
	en = "Matcha Garden",
	zht = "抹茶蛋糕園",
}
LocalizationConfig["loc_AreaName_23"] =
{
	zh = "甜甜圈小镇",
	en = "Donut Town",
	zht = "甜甜圈小鎮",
}
LocalizationConfig["loc_AreaName_24"] =
{
	zh = "糖果街",
	en = "Candy Street",
	zht = "糖果街",
}
LocalizationConfig["loc_AreaName_25"] =
{
	zh = "化石馆",
	en = "Fossil Museum",
	zht = "化石館",
}
LocalizationConfig["loc_AreaName_26"] =
{
	zh = "水族馆",
	en = "Sea Museum",
	zht = "水族館",
}
LocalizationConfig["loc_AreaName_27"] =
{
	zh = "埃及馆",
	en = "Egypt Museum",
	zht = "埃及館",
}
LocalizationConfig["loc_AreaName_28"] =
{
	zh = "长走廊",
	en = "Hallway",
	zht = "長走廊",
}
LocalizationConfig["loc_AreaName_29"] =
{
	zh = "非洲馆",
	en = "Africa Museum",
	zht = "非洲館",
}
LocalizationConfig["loc_AreaName_30"] =
{
	zh = "瓷器馆",
	en = "Pottery Museum",
	zht = "瓷器館",
}
LocalizationConfig["loc_AreaName_31"] =
{
	zh = "画廊",
	en = "Art Gallery",
	zht = "畫廊",
}
LocalizationConfig["loc_AreaName_32"] =
{
	zh = "雕像馆",
	en = "Statue Gallery",
	zht = "雕像館",
}
LocalizationConfig["loc_AbilityName_1"] =
{
	zh = "细心",
	en = "Attentive",
	zht = "細心",
}
LocalizationConfig["loc_AbilityName_2"] =
{
	zh = "创造",
	en = "Creativity",
	zht = "創造",
}
LocalizationConfig["loc_AbilityName_3"] =
{
	zh = "逻辑",
	en = "Logic",
	zht = "邏輯",
}
LocalizationConfig["loc_AbilityName_4"] =
{
	zh = "神秘",
	en = "Mystery",
	zht = "神秘",
}
LocalizationConfig["loc_AbilityName_5"] =
{
	zh = "体力",
	en = "HP",
	zht = "體力",
}
LocalizationConfig["loc_AbilityName_6"] =
{
	zh = "胆识",
	en = "Courage",
	zht = "膽識",
}
LocalizationConfig["loc_AbilityName_7"] =
{
	zh = "艺术",
	en = "Arts",
	zht = "藝術",
}
LocalizationConfig["loc_AbilityName_8"] =
{
	zh = "电脑",
	en = "IT",
	zht = "電腦",
}
LocalizationConfig["loc_AbilityName_9"] =
{
	zh = "烹饪",
	en = "Cooking",
	zht = "烹飪",
}
LocalizationConfig["loc_AbilityName_10"] =
{
	zh = "忍耐",
	en = "Tenacity",
	zht = "忍耐",
}
LocalizationConfig["loc_AbilityName_11"] =
{
	zh = "颜值",
	en = "Looks",
	zht = "顏值",
}
LocalizationConfig["loc_AbilityName_12"] =
{
	zh = "亲和",
	en = "Affinity",
	zht = "親和",
}
LocalizationConfig["loc_AbilityName_13"] =
{
	zh = "运气",
	en = "Luck",
	zht = "運氣",
}
LocalizationConfig["loc_AbilityName_14"] =
{
	zh = "口才",
	en = "Speech",
	zht = "口才",
}
LocalizationConfig["loc_AbilityName_15"] =
{
	zh = "速度",
	en = "Speed",
	zht = "速度",
}
LocalizationConfig["loc_AbilityName_16"] =
{
	zh = "数学",
	en = "Math",
	zht = "數學",
}
LocalizationConfig["loc_ChracterName_SP1"] =
{
	zh = "娜娜",
	en = "Nana",
	zht = "娜娜",
}
LocalizationConfig["loc_ChracterName_SP2"] =
{
	zh = "大管家",
	en = "Steward",
	zht = "大管家",
}
LocalizationConfig["loc_CharacterName_1"] =
{
	zh = "呜呜",
	en = "Count Mews",
	zht = "嗚嗚",
}
LocalizationConfig["loc_CharacterName_2"] =
{
	zh = "咕咕",
	en = "Salem",
	zht = "咕咕",
}
LocalizationConfig["loc_CharacterName_3"] =
{
	zh = "剑士",
	en = "Swordsman",
	zht = "劍士",
}
LocalizationConfig["loc_CharacterName_4"] =
{
	zh = "猎人",
	en = "Hunter",
	zht = "獵人",
}
LocalizationConfig["loc_CharacterName_5"] =
{
	zh = "部落老大",
	en = "Chieftain",
	zht = "部落老大",
}
LocalizationConfig["loc_CharacterName_6"] =
{
	zh = "弓箭手",
	en = "Archer",
	zht = "弓箭手",
}
LocalizationConfig["loc_CharacterName_7"] =
{
	zh = "小小弟",
	en = "Disciple",
	zht = "小小弟",
}
LocalizationConfig["loc_CharacterName_8"] =
{
	zh = "射鸡师",
	en = "Designer",
	zht = "設計師",
}
LocalizationConfig["loc_CharacterName_9"] =
{
	zh = "牧师",
	en = "Cleric",
	zht = "牧師",
}
LocalizationConfig["loc_CharacterName_10"] =
{
	zh = "大魔王",
	en = "Dark Lord",
	zht = "大魔王",
}
LocalizationConfig["loc_CharacterName_11"] =
{
	zh = "魔法师",
	en = "Mage",
	zht = "魔法師",
}
LocalizationConfig["loc_CharacterName_12"] =
{
	zh = "扫地僧",
	en = "Chore Monk",
	zht = "掃地僧",
}
LocalizationConfig["loc_CharacterName_13"] =
{
	zh = "老爷爷",
	en = "Old Geezer",
	zht = "老爺爺",
}
LocalizationConfig["loc_CharacterName_14"] =
{
	zh = "女王大人",
	en = "Queenie",
	zht = "女王大人",
}
LocalizationConfig["loc_CharacterName_15"] =
{
	zh = "老奶奶",
	en = "Granny",
	zht = "老奶奶",
}
LocalizationConfig["loc_CharacterName_16"] =
{
	zh = "普通居民",
	en = "Resident",
	zht = "普通居民",
}
LocalizationConfig["loc_CharacterName_17"] =
{
	zh = "异虫霸格",
	en = "System Bug",
	zht = "異蟲霸格",
}
LocalizationConfig["loc_CharacterName_18"] =
{
	zh = "除虫者",
	en = "Debugger",
	zht = "除蟲者",
}
LocalizationConfig["loc_CharacterName_19"] =
{
	zh = "城镇卫兵",
	en = "City Guard",
	zht = "城鎮衛兵",
}
LocalizationConfig["loc_CharacterName_20"] =
{
	zh = "木偶师",
	en = "Puppeteer",
	zht = "木偶師",
}
LocalizationConfig["loc_CharacterName_21"] =
{
	zh = "骨头兵",
	en = "Skeleton",
	zht = "骷髏兵",
}
LocalizationConfig["loc_CharacterName_22"] =
{
	zh = "程序猿",
	en = "Programmer",
	zht = "程式猿",
}
LocalizationConfig["loc_CharacterName_23"] =
{
	zh = "原画妹子",
	en = "Paintress",
	zht = "原畫妹子",
}
LocalizationConfig["loc_CharacterName_24"] =
{
	zh = "旅行商人",
	en = "Merchant",
	zht = "旅行商人",
}
LocalizationConfig["loc_CharacterName_25"] =
{
	zh = "配音演员",
	en = "Dubber",
	zht = "配音演員",
}
LocalizationConfig["loc_CharacterName_26"] =
{
	zh = "异世界画家",
	en = "Virtuoso",
	zht = "異世界畫家",
}
LocalizationConfig["loc_CharacterName_27"] =
{
	zh = "火枪手",
	en = "Musketeer",
	zht = "火槍手",
}
LocalizationConfig["loc_CharacterName_28"] =
{
	zh = "调音师",
	en = "DJ",
	zht = "調音師",
}
LocalizationConfig["loc_CharacterName_29"] =
{
	zh = "刺客",
	en = "Assassin",
	zht = "刺客",
}
LocalizationConfig["loc_CharacterName_30"] =
{
	zh = "小魔王",
	en = "Dark Chief",
	zht = "小魔王",
}
LocalizationConfig["loc_CharacterName_31"] =
{
	zh = "龙骑士",
	en = "Dragoon",
	zht = "龍騎士",
}
LocalizationConfig["loc_CharacterName_32"] =
{
	zh = "黑龙王子",
	en = "Dark Drago",
	zht = "黑龍王子",
}
LocalizationConfig["loc_CharacterName_33"] =
{
	zh = "汽水王子",
	en = "Soda",
	zht = "汽水王子",
}
LocalizationConfig["loc_CharacterName_34"] =
{
	zh = "奶茶王子",
	en = "Milk Tea",
	zht = "奶茶王子",
}
LocalizationConfig["loc_CharacterName_35"] =
{
	zh = "小黄",
	en = "Lil Yellow",
	zht = "小黃",
}
LocalizationConfig["loc_CharacterName_36"] =
{
	zh = "番茄酱侍卫",
	en = "Ketchup",
	zht = "番茄醬侍衛",
}
LocalizationConfig["loc_CharacterName_37"] =
{
	zh = "棒棒糖女仆",
	en = "Lollipop",
	zht = "棒棒糖女僕",
}
LocalizationConfig["loc_CharacterName_38"] =
{
	zh = "虾条公主",
	en = "Prawn Chip",
	zht = "蝦條公主",
}
LocalizationConfig["loc_CharacterName_39"] =
{
	zh = "培根女巫",
	en = "Bacon",
	zht = "培根女巫",
}
LocalizationConfig["loc_CharacterName_40"] =
{
	zh = "炸鸡魔后",
	en = "Fried Chicken",
	zht = "炸雞魔後",
}
LocalizationConfig["loc_CharacterName_41"] =
{
	zh = "妙脆角公主",
	en = "Bugle",
	zht = "妙脆角公主",
}
LocalizationConfig["loc_CharacterName_42"] =
{
	zh = "热狗先生",
	en = "Mr. Hotdog",
	zht = "熱狗先生",
}
LocalizationConfig["loc_CharacterName_43"] =
{
	zh = "小绿",
	en = "Lil Green",
	zht = "小綠",
}
LocalizationConfig["loc_CharacterName_44"] =
{
	zh = "可乐王子",
	en = "Cola",
	zht = "可樂王子",
}
LocalizationConfig["loc_CharacterName_45"] =
{
	zh = "小红",
	en = "Lil Red",
	zht = "小紅",
}
LocalizationConfig["loc_CharacterName_46"] =
{
	zh = "小橙",
	en = "Lil Orange",
	zht = "小橙",
}
LocalizationConfig["loc_CharacterName_47"] =
{
	zh = "小蓝",
	en = "Lil Blue",
	zht = "小藍",
}
LocalizationConfig["loc_CharacterName_48"] =
{
	zh = "小青",
	en = "Lil Cobalt",
	zht = "小青",
}
LocalizationConfig["loc_CharacterName_49"] =
{
	zh = "小紫",
	en = "Lil Purple",
	zht = "小紫",
}
LocalizationConfig["loc_CharacterName_50"] =
{
	zh = "棉花糖公主",
	en = "Candyfloss",
	zht = "棉花糖公主",
}
LocalizationConfig["loc_CharacterName_51"] =
{
	zh = "咖啡小姐",
	en = "Ms. Coffee",
	zht = "咖啡小姐",
}
LocalizationConfig["loc_CharacterName_52"] =
{
	zh = "甜筒皇后",
	en = "Queen Cone",
	zht = "甜筒皇后",
}
LocalizationConfig["loc_CharacterName_53"] =
{
	zh = "华夫饼仙子",
	en = "Wafflette",
	zht = "華夫餅仙子",
}
LocalizationConfig["loc_CharacterName_54"] =
{
	zh = "松饼仙子",
	en = "Pancakette",
	zht = "松餅仙子",
}
LocalizationConfig["loc_CharacterName_55"] =
{
	zh = "冰淇淋公主",
	en = "Apple",
	zht = "霜淇淋公主",
}
LocalizationConfig["loc_CharacterName_56"] =
{
	zh = "蛋糕卷公主",
	en = "Swiss Roll",
	zht = "蛋糕卷公主",
}
LocalizationConfig["loc_CharacterName_57"] =
{
	zh = "栗子蛋糕公主",
	en = "Chestnut Cake",
	zht = "栗子蛋糕公主",
}
LocalizationConfig["loc_CharacterName_58"] =
{
	zh = "啤酒王子",
	en = "Beer",
	zht = "啤酒王子",
}
LocalizationConfig["loc_CharacterName_59"] =
{
	zh = "薯片夫人",
	en = "Mrs. Chip",
	zht = "薯片夫人",
}
LocalizationConfig["loc_CharacterName_60"] =
{
	zh = "布丁仙子",
	en = "Pudingette",
	zht = "布丁仙子",
}
LocalizationConfig["loc_CharacterName_61"] =
{
	zh = "汉堡小姐",
	en = "Ms. Hammie",
	zht = "漢堡小姐",
}
LocalizationConfig["loc_CharacterName_62"] =
{
	zh = "薯条国王",
	en = "King Fry",
	zht = "薯條國王",
}
LocalizationConfig["loc_CharacterName_63"] =
{
	zh = "爆米花女王",
	en = "Popcorn",
	zht = "爆米花女王",
}
LocalizationConfig["loc_CharacterName_64"] =
{
	zh = "保安",
	en = "Security",
	zht = "保安",
}
LocalizationConfig["loc_CharacterName_65"] =
{
	zh = "浣熊小弟",
	en = "Lil Raccy",
	zht = "浣熊小弟",
}
LocalizationConfig["loc_CharacterName_66"] =
{
	zh = "阿努比斯",
	en = "Anubis",
	zht = "阿努比斯",
}
LocalizationConfig["loc_CharacterName_67"] =
{
	zh = "中世纪铠甲",
	en = "Armor Suit",
	zht = "中世紀鎧甲",
}
LocalizationConfig["loc_CharacterName_68"] =
{
	zh = "侦探小姐",
	en = "Agatha",
	zht = "偵探小姐",
}
LocalizationConfig["loc_CharacterName_69"] =
{
	zh = "浣熊大哥",
	en = "Big Raccy",
	zht = "浣熊大哥",
}
LocalizationConfig["loc_CharacterName_70"] =
{
	zh = "微笑女神",
	en = "Mona",
	zht = "微笑女神",
}
LocalizationConfig["loc_CharacterName_71"] =
{
	zh = "魔术师",
	en = "Kidi",
	zht = "魔術師",
}
LocalizationConfig["loc_CharacterName_72"] =
{
	zh = "荷鲁斯",
	en = "Horus",
	zht = "荷魯斯",
}
LocalizationConfig["loc_CharacterName_73"] =
{
	zh = "浣熊二哥",
	en = "Raccy",
	zht = "浣熊二哥",
}
LocalizationConfig["loc_CharacterName_74"] =
{
	zh = "创造之神",
	en = "Demiurge",
	zht = "創造之神",
}
LocalizationConfig["loc_CharacterName_75"] =
{
	zh = "日本武士",
	en = "Samurai",
	zht = "日本武士",
}
LocalizationConfig["loc_CharacterName_76"] =
{
	zh = "赛特",
	en = "Set",
	zht = "賽特",
}
LocalizationConfig["loc_CharacterName_77"] =
{
	zh = "索贝克",
	en = "Sobek",
	zht = "索貝克",
}
LocalizationConfig["loc_CharacterName_78"] =
{
	zh = "木乃伊",
	en = "Mummy",
	zht = "木乃伊",
}
LocalizationConfig["loc_CharacterName_79"] =
{
	zh = "兵马俑",
	en = "Terracotta",
	zht = "兵馬俑",
}
LocalizationConfig["loc_CharacterName_80"] =
{
	zh = "默艾",
	en = "Moai",
	zht = "默艾",
}
LocalizationConfig["loc_CharacterName_81"] =
{
	zh = "独耳画像",
	en = "Gogh",
	zht = "獨耳畫像",
}
LocalizationConfig["loc_CharacterName_82"] =
{
	zh = "石柱人",
	en = "Pillar Man",
	zht = "石柱人",
}
LocalizationConfig["loc_CharacterName_83"] =
{
	zh = "半人马石像",
	en = "Centaur",
	zht = "半人馬石像",
}
LocalizationConfig["loc_CharacterName_84"] =
{
	zh = "带耳环的少女",
	en = "Meisje",
	zht = "帶耳環的少女",
}
LocalizationConfig["loc_CharacterName_85"] =
{
	zh = "呐喊家",
	en = "Scream",
	zht = "呐喊家",
}
LocalizationConfig["loc_CharacterName_86"] =
{
	zh = "猪蹄古董",
	en = "Pig Foot",
	zht = "豬蹄古董",
}
LocalizationConfig["loc_CharacterName_87"] =
{
	zh = "亚当",
	en = "Adam",
	zht = "亞當",
}
LocalizationConfig["loc_CharacterName_88"] =
{
	zh = "原始人爸爸",
	en = "Cave Dad",
	zht = "原始人爸爸",
}
LocalizationConfig["loc_CharacterName_89"] =
{
	zh = "原始人妈妈",
	en = "Cave Mom",
	zht = "原始人媽媽",
}
LocalizationConfig["loc_CharacterName_90"] =
{
	zh = "原始人儿子",
	en = "Cave Kid",
	zht = "原始人兒子",
}
LocalizationConfig["loc_CharacterName_91"] =
{
	zh = "哭泣的女人",
	en = "Weeper",
	zht = "哭泣的女人",
}
LocalizationConfig["loc_CharacterName_92"] =
{
	zh = "弗里达",
	en = "Frida",
	zht = "弗裡達",
}
LocalizationConfig["loc_CharacterName_93"] =
{
	zh = "名人蜡像",
	en = "Waxwork",
	zht = "名人蠟像",
}
LocalizationConfig["loc_CharacterName_94"] =
{
	zh = "豆豆警官",
	en = "Ploddie",
	zht = "豆豆警官",
}
LocalizationConfig["loc_CharacterName_95"] =
{
	zh = "侦探助理",
	en = "Watsoon",
	zht = "偵探助理",
}
LocalizationConfig["loc_CharacterName_96"] =
{
	zh = "倒霉蛋",
	en = "Poor Guy",
	zht = "倒楣蛋",
}
LocalizationConfig["loc_CharacterName_97"] =
{
	zh = "法医",
	en = "Horatio",
	zht = "法醫",
}
LocalizationConfig["loc_CharacterName_98"] =
{
	zh = "大侦探",
	en = "Holmees",
	zht = "大偵探",
}
LocalizationConfig["loc_CharacterName_99"] =
{
	zh = "迈克罗夫特",
	en = "Mycroft",
	zht = "邁克羅夫特",
}
LocalizationConfig["loc_CharacterName_100"] =
{
	zh = "蓝衣小学生",
	en = "Boy Blue",
	zht = "藍衣小學生",
}
LocalizationConfig["loc_CharacterName_101"] =
{
	zh = "凶手",
	en = "Outlaw",
	zht = "兇手",
}
LocalizationConfig["loc_CharacterName_102"] =
{
	zh = "马夫",
	en = "Cabbie",
	zht = "馬夫",
}
LocalizationConfig["loc_CharacterName_103"] =
{
	zh = "法官",
	en = "The Beak",
	zht = "法官",
}
LocalizationConfig["loc_CharacterName_104"] =
{
	zh = "小泪",
	en = "Rui",
	zht = "小淚",
}
LocalizationConfig["loc_CharacterName_105"] =
{
	zh = "杰克瑞波",
	en = "Ripper",
	zht = "傑克瑞波",
}
LocalizationConfig["loc_CharacterName_106"] =
{
	zh = "报童",
	en = "Paper Boy",
	zht = "報童",
}
LocalizationConfig["loc_CharacterName_107"] =
{
	zh = "读者",
	en = "Reader",
	zht = "讀者",
}
LocalizationConfig["loc_CharacterName_108"] =
{
	zh = "编辑长",
	en = "The Editor",
	zht = "編輯長",
}
LocalizationConfig["loc_CharacterName_109"] =
{
	zh = "小爱",
	en = "Ai",
	zht = "小愛",
}
LocalizationConfig["loc_CharacterName_110"] =
{
	zh = "嫌疑人",
	en = "Shady Sam",
	zht = "嫌疑人",
}
LocalizationConfig["loc_CharacterName_111"] =
{
	zh = "逝者",
	en = "Morty",
	zht = "逝者",
}
LocalizationConfig["loc_CharacterName_112"] =
{
	zh = "律师",
	en = "Suity Cid",
	zht = "律師",
}
LocalizationConfig["loc_CharacterName_113"] =
{
	zh = "房东太太",
	en = "Landlady",
	zht = "房東太太",
}
LocalizationConfig["loc_CharacterName_114"] =
{
	zh = "调酒师",
	en = "Bartender",
	zht = "調酒師",
}
LocalizationConfig["loc_CharacterName_115"] =
{
	zh = "博士",
	en = "The Doctor",
	zht = "博士",
}
LocalizationConfig["loc_CharacterName_116"] =
{
	zh = "小瞳",
	en = "Hitomi",
	zht = "小瞳",
}
LocalizationConfig["loc_CharacterName_117"] =
{
	zh = "证人",
	en = "Magoo",
	zht = "證人",
}
LocalizationConfig["loc_CharacterName_118"] =
{
	zh = "检察官",
	en = "Prosecutor",
	zht = "檢察官",
}
LocalizationConfig["loc_CharacterName_119"] =
{
	zh = "教授",
	en = "The Prof.",
	zht = "教授",
}
LocalizationConfig["loc_CharacterDes_1"] =
{
	zh = "刚成年的猫咪伯爵。胆小怕事，没有什么做事经验，却被授命管理整个怪咖星系。",
	en = "A young kitty count. Despite being timid and inexperienced, he has been chosen to administer the whole Superstar Galaxy.",
	zht = "剛成年的貓咪伯爵。膽小怕事，沒有什麼做事經驗，卻被授命管理整個怪咖星系。",
}
LocalizationConfig["loc_CharacterDes_2"] =
{
	zh = "猫咪界第一的接班人。曾经差点饿死在路边，全靠吃呜呜嫌弃的午饭活下来。负责出谋划策跑前跑后。",
	en = "The best feline attendant in the land. He was saved from starving by eating the lunch that Count Mews didn't want, he now runs all his errands for him",
	zht = "貓咪界第一的接班人。曾經差點餓死在路邊，全靠吃嗚嗚嫌棄的午飯活下來。負責出謀劃策跑前跑後。",
}
LocalizationConfig["loc_CharacterDes_3"] =
{
	zh = "有主角光环的剑士，因为总是能躲过危险，在战斗中现在充当了肉盾的角色，攻击什么的都交给其他人了。",
	en = "A swordsman with a main character's halo. Always able to avoid harm, he nowadays acts as a meat shield, he relies on others to attack and do other things.",
	zht = "有主角光環的劍士，因為總是能躲過危險，在戰鬥中現在充當了肉盾的角色，攻擊什麼的都交給其他人了。",
}
LocalizationConfig["loc_CharacterDes_4"] =
{
	zh = "爱喝酒的猎人。称不喝酒就出门相当于打猎不带弓箭。关键时刻会使出醉剑剑法，是个不可忽视的战力。",
	en = "A hunter who loves a drink. Leaving the house without a drink is like hunting without a bow to him. Uses drunken sword when in need, you better watch out.",
	zht = "愛喝酒的獵人。稱不喝酒就出門相當於打獵不帶弓箭。關鍵時刻會使出醉劍劍法，是個不可忽視的戰力。",
}
LocalizationConfig["loc_CharacterDes_5"] =
{
	zh = "隐居在森林中的部落老大，喜欢帮助迷路的人。为三天两头受伤的勇者总结出了一套急救疗伤标准流程，并注册了专利，赚了不少钱。",
	en = "Head of a forest tribe, he likes helping people who are lost. As his warriors kept getting injured, he made a fortune from patenting an emergency treatment.",
	zht = "隱居在森林中的部落老大，喜歡幫助迷路的人。為三天兩頭受傷的勇者總結出了一套急救療傷標準流程，並註冊了專利，賺了不少錢。",
}
LocalizationConfig["loc_CharacterDes_6"] =
{
	zh = "隔壁国家的公主，逃出来体验生活。从小跟着家庭教师学剑术，能轻松射中移动中的物体。",
	en = "Princess of the neighboring kingdom who ran away to experience life. She learned how to use a sword from a young age and can easily shoot moving targets.",
	zht = "隔壁國家的公主，逃出來體驗生活。從小跟著家庭教師學劍術，能輕鬆射中移動中的物體。",
}
LocalizationConfig["loc_CharacterDes_7"] =
{
	zh = "恶魔城中忠诚的打手之一，生命力顽强，流星飞小锤是他的拿手好戏。是勇者队练级的好帮手。",
	en = "One of the loyal fighters of the Necropolis. Tough and tenacious, he's skilled with the mace he carries. He's a great addition to a team of warriors.",
	zht = "惡魔城中忠誠的打手之一，生命力頑強，流星飛小錘是他的拿手好戲。是勇者隊練級的好幫手。",
}
LocalizationConfig["loc_CharacterDes_8"] =
{
	zh = "冒险星的创世神，时不时颠覆造物主的创造结果。自称老司机，样样精通，更在创造各种霸格中起到了关键性作用。",
	en = "Adventure Planet's lord of creation, he sometimes ruins the creator's works. He says he's an expert who's good at everything, especially at creating bugs.",
	zht = "冒險星的創世神，時不時顛覆造物主的創造結果。自稱老司機，樣樣精通，更在創造各種霸格中起到了關鍵性作用。",
}
LocalizationConfig["loc_CharacterDes_9"] =
{
	zh = "可爱的女孩子，喜欢带着奶瓶，负责在战斗中时不时的给队友补充能量。",
	en = "A cute girl who carries a milk bottle that's used to replenish energy to teammates in battle.",
	zht = "可愛的女孩子，喜歡帶著奶瓶，負責在戰鬥中時不時的給隊友補充能量。",
}
LocalizationConfig["loc_CharacterDes_10"] =
{
	zh = "原本是王子，后来因为打麻将输给了魔王，被迫卖身给魔王做接班人。后来发现魔王的生活比王子轻松多了，每天只想着抓公主回来享受生活。",
	en = "Prince who became Dark Lord from losing a game of poker to the original. He found a Dark Lord's life is easier than a prince's, he just captures princesses.",
	zht = "原本是王子，後來因為打麻將輸給了魔王，被迫賣身給魔王做接班人。後來發現魔王的生活比王子輕鬆多了，每天只想著抓公主回來享受生活。",
}
LocalizationConfig["loc_CharacterDes_11"] =
{
	zh = "有强大法力的红发魔女，有预言的能力，因为人们不喜欢听不好的预言只能暗中帮助人们。遇到紧急时刻会睁开第三只眼睛。",
	en = "A red-haired sorceress. Can predict the future, but secretly helps others as they don't want to hear her bad prophecies. Uses her third eye when in need.",
	zht = "有強大法力的紅發魔女，有預言的能力，因為人們不喜歡聽不好的預言只能暗中幫助人們。遇到緊急時刻會睜開第三只眼睛。",
}
LocalizationConfig["loc_CharacterDes_12"] =
{
	zh = "忠实的扫地僧，日复一日保持着各个区域的清洁，一旦发现虫子就会立刻通知灭虫组。",
	en = "A faithful monk who keeps the place clean, if he finds an insect infestation he'll call the exterminator right away.",
	zht = "忠實的掃地僧，日復一日保持著各個區域的清潔，一旦發現蟲子就會立刻通知滅蟲組。",
}
LocalizationConfig["loc_CharacterDes_13"] =
{
	zh = "居家老爷爷，喜欢宅在家里帮老奶奶干活。闲的时候会玩玩游戏，对外称自己会龟派气功。",
	en = "An old man who likes to help granny do the chores house chores. He likes to play games in his leisure time and claims to be able to do Shaolin Kungfu",
	zht = "居家老爺爺，喜歡宅在家裡幫老奶奶幹活。閑的時候會玩玩遊戲，對外稱自己會龜派氣功。",
}
LocalizationConfig["loc_CharacterDes_14"] =
{
	zh = "喜欢四处旅行的女王大人偷偷离开了城堡，想自己体验一下冒险的感觉，不过每次都被路过的大小勇者带回了城堡。",
	en = "She loves travelling and often sneaks out her castle so that she can get a taste of adventure, but is always brought back to the castle by adventurers.",
	zht = "喜歡四處旅行的女王大人偷偷離開了城堡，想自己體驗一下冒險的感覺，不過每次都被路過的大小勇者帶回了城堡。",
}
LocalizationConfig["loc_CharacterDes_15"] =
{
	zh = "退休的女勇者，曾击败数条恶龙，现在隐居在小村子中。据说，她在关键时刻可以使用积蓄的力量返老还童。",
	en = "A retired warrior who once defeated many dragons, she now lives quietly in her village. It's said that she can regain her youthful vigor when necessary.",
	zht = "退休的女勇者，曾擊敗數條惡龍，現在隱居在小村子中。據說，她在關鍵時刻可以使用積蓄的力量返老還童。",
}
LocalizationConfig["loc_CharacterDes_16"] =
{
	zh = "冒险星的普通居民，因为勇者们总是进来翻箱倒柜，只能把值钱的东西一直背在身上。",
	en = "A normal resident of Adventure Planet, he carries all his valuables around on his back to prevent other heroes from stealing it all.",
	zht = "冒險星的普通居民，因為勇者們總是進來翻箱倒櫃，只能把值錢的東西一直背在身上。",
}
LocalizationConfig["loc_CharacterDes_17"] =
{
	zh = "霸格是造物过程中必然会附加生产的存在。也有人说这是远古种族萨尔那加制作的强大生物，因此霸格越修越多生生不息。",
	en = "Bugs are an inevitable part of the creation process. Some say they were made by the ancient Xel'naga, the more you try and fix them, the more there will be.",
	zht = "霸格是造物過程中必然會附加生產的存在。也有人說這是遠古種族薩爾那加製作的強大生物，因此霸格越修越多生生不息。",
}
LocalizationConfig["loc_CharacterDes_18"] =
{
	zh = "平时不被重视的存在，关键时刻引导众人一起驱赶霸格，也有很多人会转职为专业除虫者，对霸格战力+500%。",
	en = "No one normally cares about them, but they help expel bugs when needed. Lots of people change their class to Debuggers, battle power against Bugs +500%.",
	zht = "平時不被重視的存在，關鍵時刻引導眾人一起驅趕霸格，也有很多人會轉職為專業除蟲者，對霸格戰力+500%。",
}
LocalizationConfig["loc_CharacterDes_19"] =
{
	zh = "冒险星最强战力之一，拥有永远比对手高5级的神圣祝福。可惜要带他打魔王的时候总是不愿意走，说是膝盖中箭后，比较喜欢作息规律的职业。",
	en = "One of Adventure Planet's best fighters who's always 5 levels higher than opponents. But if you ask him to help fight the Dark Lord, he says his knee's bad.",
	zht = "冒險星最強戰力之一，擁有永遠比對手高5級的神聖祝福。可惜要帶他打魔王的時候總是不願意走，說是膝蓋中箭後，比較喜歡作息規律的職業。",
}
LocalizationConfig["loc_CharacterDes_20"] =
{
	zh = "“控制了骨骼，你就控制了这个人”这是木偶师的名言。他甚至能同时控制几架小飞机上天。",
	en = "If you control their bones, you control this person' is the puppeteer's famous saying. He can even control multiple planes in the sky ay once.",
	zht = "“控制了骨骼，你就控制了這個人”這是木偶師的名言。他甚至能同時控制幾架小飛機上天。",
}
LocalizationConfig["loc_CharacterDes_21"] =
{
	zh = "冒险星中最普通的存在，各种角色练级的起点。据小骷髅说最怕的对手是各种涅法雷姆。",
	en = "The most common being on Adventure Planet, they are the starting point for many different characters. Apparently their most feared opponents are Nephalems.",
	zht = "冒險星中最普通的存在，各種角色練級的起點。據小骷髏說最怕的對手是各種涅法雷姆。",
}
LocalizationConfig["loc_CharacterDes_22"] =
{
	zh = "冒险星的造物主，有闭眼写代码的神技。困了就靠头上的小弟来醒脑。造物的同时也造就了星球中各种名为霸格的神迹。",
	en = "Creator of Adventure Planet, can code with his eyes closed. When he's tired, his brother wakes him up. His creations have also made many miraculous bugs.",
	zht = "冒險星的造物主，有閉眼寫代碼的神技。困了就靠頭上的小弟來醒腦。造物的同時也造就了星球中各種名為霸格的神跡。",
}
LocalizationConfig["loc_CharacterDes_23"] =
{
	zh = "这个星球本来没有色彩，直到一位仙女给星球填上了各种颜色。",
	en = "This planet was originally without color until a fairy came along and filled it in.",
	zht = "這個星球本來沒有色彩，直到一位仙女給星球填上了各種顏色。",
}
LocalizationConfig["loc_CharacterDes_24"] =
{
	zh = "据说行走在各地的商人都是实力非凡的退役勇者。卖出去1000块的道具，下一秒就是100块的回收价，却没有谁敢和他们吵架。",
	en = "It's said that merchants that wanders are retired warriors. They sell an item for 1000, but only accept 100 to buy it back and no one dares to argue.",
	zht = "據說行走在各地的商人都是實力非凡的退役勇者。賣出去1000塊的道具，下一秒就是100塊的回收價，卻沒有誰敢和他們吵架。",
}
LocalizationConfig["loc_CharacterDes_25"] =
{
	zh = "前偶像歌手，尝试配音后发现了自己的职业真爱，现在依靠多变的声线获得了很多粉丝。",
	en = "She used to be a famous singer but after trying voice acting she found her true calling. She now uses her versatile voice to gain countless followers.",
	zht = "前偶像歌手，嘗試配音後發現了自己的職業真愛，現在依靠多變的聲線獲得了很多粉絲。",
}
LocalizationConfig["loc_CharacterDes_26"] =
{
	zh = "摄影家兼画家的神奇存在，人们总是争论他的摄影技术和绘画技术到底哪个高，然而他自称自己的篮球技术才是最好的。",
	en = "Mystical photographer and painter. People are always arguing whether his photography or painting is better, but he says his basketball skills are the best.",
	zht = "攝影家兼畫家的神奇存在，人們總是爭論他的攝影技術和繪畫技術到底哪個高，然而他自稱自己的籃球技術才是最好的。",
}
LocalizationConfig["loc_CharacterDes_27"] =
{
	zh = "在这个星球，人们不大使用火药，因为反正威力也不如魔法。不过可以偶尔拿个玩具枪扮演一下西部牛仔过过瘾。",
	en = "People don't really use gunpowder on this planet, as it's not as powerful as magic. But sometimes people will dress up as cowboys and play with toy guns.",
	zht = "在這個星球，人們不大使用火藥，因為反正威力也不如魔法。不過可以偶爾拿個玩具槍扮演一下西部牛仔過過癮。",
}
LocalizationConfig["loc_CharacterDes_28"] =
{
	zh = "曾经的流浪诗人，后来喜欢上电子乐。立志成为用音乐让人们获得快乐的偶像。",
	en = "An ex-wandering bard who acquired a taste for electronic music. He's determined to become everyone's idol, using music to make them happy.",
	zht = "曾經的流浪詩人，後來喜歡上電子樂。立志成為用音樂讓人們獲得快樂的偶像。",
}
LocalizationConfig["loc_CharacterDes_29"] =
{
	zh = "反应迅速，擅长找到敌人的弱点，很有前途。特地买了黑色斗篷和猫儿鞋，据说这些能减少走路时的声音。",
	en = "Rapid reactions and great at finding enemies' weak spots, full of promise. He bought a black cape and cat slippers to reduce the noise of his footsteps.",
	zht = "反應迅速，擅長找到敵人的弱點，很有前途。特地買了黑色斗篷和貓兒鞋，據說這些能減少走路時的聲音。",
}
LocalizationConfig["loc_CharacterDes_30"] =
{
	zh = "曾经是魔王的好朋友，一直不服新来的大魔王。经历了99战99败之后，准备去人类世界研究最新的战斗技法。",
	en = "Once the Dark Lord's friend, he's never liked the new one. After losing 99 of 99 battles, he headed to the human realm to research new battle techniques.",
	zht = "曾經是魔王的好朋友，一直不服新來的大魔王。經歷了99戰99敗之後，準備去人類世界研究最新的戰鬥技法。",
}
LocalizationConfig["loc_CharacterDes_31"] =
{
	zh = "本来是高阶职业龙骑士，后来因为鸟类动物保护法出台而丢了工作。现在常骑在马上做各种活动的开幕式表演。",
	en = "A prestigious Dragoon who lost his job when a new avian protection act came into force. He now rides horses performing at event opening ceremonies.",
	zht = "本來是高階職業龍騎士，後來因為鳥類動物保護法出臺而丟了工作。現在常騎在馬上做各種活動的開幕式表演。",
}
LocalizationConfig["loc_CharacterDes_32"] =
{
	zh = "喜欢扮成普通人体验生活的黑龙王子，爱好睡觉和和平。每顿都要吃很多肉，因此自己打工的钱都用在吃上了。一不小心会露出尾巴。",
	en = "Black Dragon Prince that pretends to be a normal person, loves sleep and peace. All his money's used on buying meat. He often accidentally reveals his tail.",
	zht = "喜歡扮成普通人體驗生活的黑龍王子，愛好睡覺和和平。每頓都要吃很多肉，因此自己打工的錢都用在吃上了。一不小心會露出尾巴。",
}
LocalizationConfig["loc_CharacterDes_33"] =
{
	zh = "如同马里奥配路易吉一样，可乐王子的弟弟汽水王子也有很多粉丝。",
	en = "Just like Mario and Luigi, Cola and Sprite have loads of fans.",
	zht = "如同馬里奧配路易吉一樣，可樂王子的弟弟汽水王子也有很多粉絲。",
}
LocalizationConfig["loc_CharacterDes_34"] =
{
	zh = "奶茶王子是下午出场的偶像，很喜欢戴各种首饰，比如珍珠椰果蒟蒻之类。据说和奶茶玩久了特别容易发胖。",
	en = "Milk Tea Prince is the the afternoon star who loves accessorizing with tapioca pearls and such. It's easy to gain too much weight when playing with him.",
	zht = "奶茶王子是下午出場的偶像，很喜歡戴各種首飾，比如珍珠椰果蒟蒻之類。據說和奶茶玩久了特別容易發胖。",
}
LocalizationConfig["loc_CharacterDes_35"] =
{
	zh = "七彩糖中的绝对主力，柠檬味的，一颗一颗又一颗。",
	en = "The star of the skittle siblings, the lemon flavor is extremely moreish.",
	zht = "七彩糖中的絕對主力，檸檬味的，一顆一顆又一顆。",
}
LocalizationConfig["loc_CharacterDes_36"] =
{
	zh = "番茄侍卫，中心耿耿的伴随在薯条国王的左右，是众多侍卫当中最受欢迎的。",
	en = "The king's ketchup bodyguard. Loyally follows by King Fry's side, he's the most popular of the king's guards.",
	zht = "番茄侍衛，中心耿耿的伴隨在薯條國王的左右，是眾多侍衛當中最受歡迎的。",
}
LocalizationConfig["loc_CharacterDes_37"] =
{
	zh = "爱吃棒棒糖的女仆，把棒棒糖直接插在头顶，随时都可以拿下来吃。",
	en = "A maid who loves eating lollipops. She's stuck a bunch of lollipops in her hair so she can eat one whenever she wants.",
	zht = "愛吃棒棒糖的女僕，把棒棒糖直接插在頭頂，隨時都可以拿下來吃。",
}
LocalizationConfig["loc_CharacterDes_38"] =
{
	zh = "薯片女王的大女儿，生性活泼，连头发都跟着一起拧成了活泼的浪味仙。",
	en = "The eldest of Mrs. Chip's two daughters. She's bubbly and full of energy, even her hair is twisted into vivacious waves.",
	zht = "薯片女王的大女兒，生性活潑，連頭髮都跟著一起擰成了活潑的浪味仙。",
}
LocalizationConfig["loc_CharacterDes_39"] =
{
	zh = "黑发女巫，平时喜欢烤培根，烤培根的同时把自己的头发也烫卷了。",
	en = "A black-haired witch, she often loves grilling bacon while curling her hair.",
	zht = "黑髮女巫，平時喜歡烤培根，烤培根的同時把自己的頭髮也燙卷了。",
}
LocalizationConfig["loc_CharacterDes_40"] =
{
	zh = "黑魔后，原本翅膀长在背后，被拔掉之后发现装不回去了，又不想扔掉就别在头发上了",
	en = "An evil queen, after pulling off the two chicken wings on her back, she realized that she couldn't get them back on so she just shoved them in her hair.",
	zht = "黑魔後，原本翅膀長在背後，被拔掉之後發現裝不回去了，又不想扔掉就別在頭髮上了",
}
LocalizationConfig["loc_CharacterDes_41"] =
{
	zh = "薯片女王的小女儿，既可以将作为食物，又可以戴在手指上玩，实在是太实用了，好吃又好玩。",
	en = "The youngest of Mrs. Chip's two daughters. She can be eaten as a snack or put onto the tips of your fingers; both delicious and fun.",
	zht = "薯片女王的小女兒，既可以將作為食物，又可以戴在手指上玩，實在是太實用了，好吃又好玩。",
}
LocalizationConfig["loc_CharacterDes_42"] =
{
	zh = "性格内向，喜欢躲在面包里面，一直单身，不知道为什么一直被别人叫做狗。",
	en = "An introverted chap who likes to hide inside his bun. Forever single, he really doesn't understand why everyone always calls him a dog.",
	zht = "性格內向，喜歡躲在麵包裡面，一直單身，不知道為什麼一直被別人叫做狗。",
}
LocalizationConfig["loc_CharacterDes_43"] =
{
	zh = "七彩糖中的新星，据说评价呈两极分化状态。",
	en = "The new star of the skittle siblings, opinion about her is divided into two camps: one that loves her, and the other that hates her.",
	zht = "七彩糖中的新星，據說評價呈兩極分化狀態。",
}
LocalizationConfig["loc_CharacterDes_44"] =
{
	zh = "最受欢迎的饮料王子，身披红色外衣，喜欢用嘴对嘴的方式传递爱意。",
	en = "The most popular of the Prince of Drinks, he wears a red overcoat and loves to pass on his love directly by mouth.",
	zht = "最受歡迎的飲料王子，身披紅色外衣，喜歡用嘴對嘴的方式傳遞愛意。",
}
LocalizationConfig["loc_CharacterDes_45"] =
{
	zh = "七彩糖中的大哥，苹果味的，算是个新口味。",
	en = "The oldest of the skittles, his apple flavor can be said to be a relatively new addition to the siblings.",
	zht = "七彩糖中的大哥，蘋果味的，算是個新口味。",
}
LocalizationConfig["loc_CharacterDes_46"] =
{
	zh = "七彩糖中的主力，橘子味的，小孩子的最爱。",
	en = "The main skittle sibling, kids love their orange flavor.",
	zht = "七彩糖中的主力，橘子味的，小孩子的最愛。",
}
LocalizationConfig["loc_CharacterDes_47"] =
{
	zh = "七彩糖中的沉稳角色，香味给人更深的印象。",
	en = "The most chilled out of the skittle siblings, her aroma gives people a deep, lasting impression.",
	zht = "七彩糖中的沉穩角色，香味給人更深的印象。",
}
LocalizationConfig["loc_CharacterDes_48"] =
{
	zh = "七彩糖中的隐藏角色，酸酸甜甜是大人的最爱。",
	en = "The hidden character among the skittle siblings, loved by adults for he sweet and sour flavor.",
	zht = "七彩糖中的隱藏角色，酸酸甜甜是大人的最愛。",
}
LocalizationConfig["loc_CharacterDes_49"] =
{
	zh = "七彩糖中的老七，葡萄味的，颜色不亮但是味道浓郁。",
	en = "The seventh of the skittle siblings, his color may not be very eye-catching but his grape flavor is deep and rich.",
	zht = "七彩糖中的老七，葡萄味的，顏色不亮但是味道濃郁。",
}
LocalizationConfig["loc_CharacterDes_50"] =
{
	zh = "天生一头棉花糖般柔软的头发，睡觉都不需要枕头，随便在哪儿都能倒头就睡。",
	en = "With a head of soft cotton candy, she doesn't need a pillow to sleep. Wherever she goes, all she has to do is lie on the ground and she'll be fast away.",
	zht = "天生一頭棉花糖般柔軟的頭髮，睡覺都不需要枕頭，隨便在哪兒都能倒頭就睡。",
}
LocalizationConfig["loc_CharacterDes_51"] =
{
	zh = "精神不好的时候，就靠咖啡妹妹来帮你提神了。咖啡的多变口味和魅力，使它被称为世界三大饮料之一。",
	en = "When feeling drowsy, let Ms. Coffee give you a little pick-me-up. Coffee's array of flavors has made it into one of the most popular drinks in the world.",
	zht = "精神不好的時候，就靠咖啡妹妹來幫你提神了。咖啡的多變口味和魅力，使它被稱為世界三大飲料之一。",
}
LocalizationConfig["loc_CharacterDes_52"] =
{
	zh = "非常自恋的巧克力熔岩皇后，每天都要和魔镜玩求生欲问答游戏，一不小心答错，就会让她身体里的巧克力酱爆出来。",
	en = "A narcissistic chocolate lava queen, she plays a quiz game with her magic mirror everyday, if she answers incorrectly all her chocolate lava erupts out.",
	zht = "非常自戀的巧克力熔岩皇后，每天都要和魔鏡玩求生欲問答遊戲，一不小心答錯，就會讓她身體裡的巧克力醬爆出來。",
}
LocalizationConfig["loc_CharacterDes_53"] =
{
	zh = "本来只是早餐仪式中简单的一部分，被添加了各种饰品后变得非常吸引人",
	en = "Originally just a simple breakfast accompaniment, after adding all sorts of dressings she became much more attractive.",
	zht = "本來只是早餐儀式中簡單的一部分，被添加了各種飾品後變得非常吸引人",
}
LocalizationConfig["loc_CharacterDes_54"] =
{
	zh = "薄薄软软的饼，又一个草莓的好伙伴。如果拿两片松饼中间加入红豆沙，就可以吸引来一个留着口水的机器猫咪",
	en = "A thin and soft cake which likes to hang with strawberry. If you slap maple syrup between two pieces, you can attract a certain mechanical kitty.",
	zht = "薄薄軟軟的餅，又一個草莓的好夥伴。如果拿兩片松餅中間加入紅豆沙，就可以吸引來一個留著口水的機器貓咪",
}
LocalizationConfig["loc_CharacterDes_55"] =
{
	zh = "爱吃苹果的公举，但是经常会被苹果噎得昏厥过去。需要王子的人工呼吸才能醒过来。",
	en = "A princess that loves eating apples, but often chokes and faints when eating them. She'll only come round again once a prince has given her CPR.",
	zht = "愛吃蘋果的公舉，但是經常會被蘋果噎得昏厥過去。需要王子的人工呼吸才能醒過來。",
}
LocalizationConfig["loc_CharacterDes_56"] =
{
	zh = "喜欢用打蛋器给自己卷头发，卷着卷着把自己的头发卷成了蛋糕卷。",
	en = "Likes to use a cake mixer to curl her hair into a swiss roll.",
	zht = "喜歡用打蛋器給自己卷頭髮，卷著卷著把自己的頭髮卷成了蛋糕卷。",
}
LocalizationConfig["loc_CharacterDes_57"] =
{
	zh = "时时刻刻用吹风机让自己的巧克力发型融化成最完美的造型。",
	en = "Constantly uses a blow dryer to melt her chocolate hair into the perfect style.",
	zht = "時時刻刻用吹風機讓自己的巧克力髮型融化成最完美的造型。",
}
LocalizationConfig["loc_CharacterDes_58"] =
{
	zh = "成年人王子，夏天冰镇后口味更佳。和烤肉在一起的时候，会突然变得精神焕发。",
	en = "An adult prince, great on a summer's day after being cooled for a time and truly refreshing alongside barbeque.",
	zht = "成年人王子，夏天冰鎮後口味更佳。和烤肉在一起的時候，會突然變得精神煥發。",
}
LocalizationConfig["loc_CharacterDes_59"] =
{
	zh = "可乐王子的舞蹈老师，两人一起跳舞的时候，就会形成一股快乐的旋风，根本不停不来。",
	en = "The dance instructor of Cola, when the two of them dance together they'll whip up a delightful storm and wont be able to stop.",
	zht = "可樂王子的舞蹈老師，兩人一起跳舞的時候，就會形成一股快樂的旋風，根本不停不來。",
}
LocalizationConfig["loc_CharacterDes_60"] =
{
	zh = "布丁仙女，身体非常柔软，轻轻碰她一下就会颤抖起来",
	en = "A pudding fairy with an extremely soft and flexible body, she shakes uncontrollably from just a light tap.",
	zht = "布丁仙女，身體非常柔軟，輕輕碰她一下就會顫抖起來",
}
LocalizationConfig["loc_CharacterDes_61"] =
{
	zh = "美食星最可爱的居民汉堡小姐。很喜欢自拍之后把自己p的很不像自己，所以每次见到她本人的时候都会心情复杂",
	en = "The most adorable resident of Dessert Planet. Loves to photoshop selfies so they look nothing like her, making it an odd encounter when meeting in person.",
	zht = "美食星最可愛的居民漢堡小姐。很喜歡自拍之後把自己p的很不像自己，所以每次見到她本人的時候都會心情複雜",
}
LocalizationConfig["loc_CharacterDes_62"] =
{
	zh = "美食星球的薯条国王，和油脂融合之后，发型变得异常的闪亮，浑身充满了香气",
	en = "The French fry king of Dessert Plane. After fusing with oil, his hair became extremely shiny and his whole body started to emit a delicious smell.",
	zht = "美食星球的薯條國王，和油脂融合之後，髮型變得異常的閃亮，渾身充滿了香氣",
}
LocalizationConfig["loc_CharacterDes_63"] =
{
	zh = "影院女神，平时不太容易出现在人们的视野中，到了电影院中可就是她的主场了。",
	en = "The queen of the movie theater. She isn't regularly found elsewhere, but the movie theater is her turf beyond a doubt.",
	zht = "影院女神，平時不太容易出現在人們的視野中，到了電影院中可就是她的主場了。",
}
LocalizationConfig["loc_CharacterDes_64"] =
{
	zh = "一个这么大的博物馆星只有一个保安，真是太辛苦了，难怪总是在打瞌睡。",
	en = "A planet as large as Museum Planet merely has a single security guard, no wonder he's always sleeping.",
	zht = "一個這麼大的博物館星只有一個保安，真是太辛苦了，難怪總是在打瞌睡。",
}
LocalizationConfig["loc_CharacterDes_65"] =
{
	zh = "特别喜欢参观博物馆的小浣熊，但每次都会因为没买票被拦在门外。",
	en = "A little raccoon that loves visiting museums, but he's always stopped from entering for not having a ticket.",
	zht = "特別喜歡參觀博物館的小浣熊，但每次都會因為沒買票被攔在門外。",
}
LocalizationConfig["loc_CharacterDes_66"] =
{
	zh = "据称是一位有着胡狼头的男性。但是大部分人都喜欢叫他狗头，据说只有手速大佬才有资格和他成为朋友",
	en = "A man who's said to have the head of a jackal, but most people just call him dog head. He only befriends those with quick hands.",
	zht = "據稱是一位有著胡狼頭的男性。但是大部分人都喜歡叫他狗頭，據說只有手速大佬才有資格和他成為朋友",
}
LocalizationConfig["loc_CharacterDes_67"] =
{
	zh = "看上去十分坚硬的铠甲，你绝对想不到其中有魔物，还能做成美味的料理",
	en = "A suit of armor that looks extremely solid, you'd never guess that there's a monster inside that's also able to make great food.",
	zht = "看上去十分堅硬的鎧甲，你絕對想不到其中有魔物，還能做成美味的料理",
}
LocalizationConfig["loc_CharacterDes_68"] =
{
	zh = "一直在调查各地出现的神秘玫瑰花，到现在也没查出什么线索。",
	en = "She's been inspecting the mysterious roses that sprout up all over the place, but hasn't found any clues up to now.",
	zht = "一直在調查各地出現的神秘玫瑰花，到現在也沒查出什麼線索。",
}
LocalizationConfig["loc_CharacterDes_69"] =
{
	zh = "特别喜欢参观博物馆的小浣熊，但每次都会因为没买票被拦在门外。",
	en = "A little raccoon that loves visiting museums, but he's always stopped from entering for not having a ticket.",
	zht = "特別喜歡參觀博物館的小浣熊，但每次都會因為沒買票被攔在門外。",
}
LocalizationConfig["loc_CharacterDes_70"] =
{
	zh = "微微一笑很倾城，似笑非笑的神秘感，让整个博物馆星为之倾倒",
	en = "She has an enamoring, mysterious smile that everyone in Museum Planet admires.",
	zht = "微微一笑很傾城，似笑非笑的神秘感，讓整個博物館星為之傾倒",
}
LocalizationConfig["loc_CharacterDes_71"] =
{
	zh = "白衣服魔术师，一直默默的守护着微笑女神，一旦女神遇到麻烦他就会使出玫瑰花绝招。",
	en = "A magician dressed in white who silently guards Mona. As soon a Mona gets into any trouble, he whips out his ultimate rose move.",
	zht = "白衣服魔術師，一直默默的守護著微笑女神，一旦女神遇到麻煩他就會使出玫瑰花絕招。",
}
LocalizationConfig["loc_CharacterDes_72"] =
{
	zh = "关于荷鲁斯的传说很多，最早的版本说他是一位隼形的造物神，他的眼睛是太阳和月亮。当新月出现时，他就成了一个瞎子。想来这肯定不方便看电视打游戏吧。",
	en = "Legend says he's the falcon god of creation, his eyes were the sun and moon. Whenever there was a new moon, he became blind. He must have watched much TV",
	zht = "關於荷魯斯的傳說很多，最早的版本說他是一位隼形的造物神，他的眼睛是太陽和月亮。當新月出現時，他就成了一個瞎子。想來這肯定不方便看電視打遊戲吧。",
}
LocalizationConfig["loc_CharacterDes_73"] =
{
	zh = "特别喜欢参观博物馆的小浣熊，但每次都会因为没买票被拦在门外。",
	en = "A little raccoon that loves visiting museums, but he's always stopped from entering for not having a ticket.",
	zht = "特別喜歡參觀博物館的小浣熊，但每次都會因為沒買票被攔在門外。",
}
LocalizationConfig["loc_CharacterDes_74"] =
{
	zh = "根据神话故事绘制的肖像，举起一只手指等待着…",
	en = "A portrait drawn about a myth, he points his finger and waits……",
	zht = "根據神話故事繪製的肖像，舉起一隻手指等待著…",
}
LocalizationConfig["loc_CharacterDes_75"] =
{
	zh = "造型非常讲究，金光闪闪，很有艺术价值。",
	en = "He's meticulous about his shiny, gold appearance, giving him great artistic value.",
	zht = "造型非常講究，金光閃閃，很有藝術價值。",
}
LocalizationConfig["loc_CharacterDes_76"] =
{
	zh = "据说是一位豺头人身的神祇，长有长方形的耳朵和弯曲凸出的长嘴。一些人相信这实际上描绘的是土豚，或者是羚羊，驴，鳄鱼或是河马的头（再看看我们这位？）",
	en = "A sort of jackal-headed person with rectangular ears and a curved, protruding snout. Some think it could be an aardvark, donkey or even hippo's head.",
	zht = "據說是一位豺頭人身的神祇，長有長方形的耳朵和彎曲凸出的長嘴。一些人相信這實際上描繪的是土豚，或者是羚羊，驢，鱷魚或是河馬的頭（再看看我們這位？）",
}
LocalizationConfig["loc_CharacterDes_77"] =
{
	zh = "这位鳄鱼头的神应该是没什么争议了，不过头上顶着这么重的东西总觉得挺辛苦的",
	en = "There isn't any dispute that this god's head is a crocodile, it's just that he must have a hard time lugging such a heavy thing around on his head.",
	zht = "這位鱷魚頭的神應該是沒什麼爭議了，不過頭上頂著這麼重的東西總覺得挺辛苦的",
}
LocalizationConfig["loc_CharacterDes_78"] =
{
	zh = "把自己裹得严严实实，连眼睛也遮住了，前进只能靠手摸了",
	en = "After wrapping himself up so tightly, even his eyes have been covered, the only way he's able to get around is by feeling his way in front of himself.",
	zht = "把自己裹得嚴嚴實實，連眼睛也遮住了，前進只能靠手摸了",
}
LocalizationConfig["loc_CharacterDes_79"] =
{
	zh = "来自遥远的东方，他说他们那里还有很多很多和他一样的雕像。",
	en = "He comes from the Far East, he says there are loads of statues just like him over there.",
	zht = "來自遙遠的東方，他說他們那裡還有很多很多和他一樣的雕像。",
}
LocalizationConfig["loc_CharacterDes_80"] =
{
	zh = "非常神秘的巨型半身人雕像。被各种学者研究来研究去的，倒是发现有些石像可不止半身",
	en = "Mysterious monolithic half-human statues. After undergoing extensive research, it's been discovered that some of them have more than half a body.",
	zht = "非常神秘的巨型半身人雕像。被各種學者研究來研究去的，倒是發現有些石像可不止半身",
}
LocalizationConfig["loc_CharacterDes_81"] =
{
	zh = "是一位画家先去掉了自己的耳朵，再把自己画下来的神奇作品，光是盯着看一会都会觉得耳朵疼。",
	en = "A peculiar portrait painted by an artist after he cut off one of his own ears, after staring at it for a while, you'll feel your ear starting to hurt.",
	zht = "是一位畫家先去掉了自己的耳朵，再把自己畫下來的神奇作品，光是盯著看一會都會覺得耳朵疼。",
}
LocalizationConfig["loc_CharacterDes_82"] =
{
	zh = "被雕刻在石柱上的人，与石柱融为一体。曾经有四个人从石柱里跑了出来准备统治世界，被波纹使者花式解决了",
	en = "A man who's carved into a pillar, becoming one with it. Four people once ran out and tried to rule the world before being dealt with by Bowen's emissary.",
	zht = "被雕刻在石柱上的人，與石柱融為一體。曾經有四個人從石柱裡跑了出來準備統治世界，被波紋使者花式解決了",
}
LocalizationConfig["loc_CharacterDes_83"] =
{
	zh = "神话传说中的雕像，上半身是人形，下半身是奔跑的马，为了不破坏马的美感，自己又另外长出两只脚专门用来走路。",
	en = "A mythical statue, its top half is a person, and the bottom half is a galloping horse. It destroyed its lower-body aesthetics by sprouting two human feet.",
	zht = "神話傳說中的雕像，上半身是人形，下半身是奔跑的馬，為了不破壞馬的美感，自己又另外長出兩隻腳專門用來走路。",
}
LocalizationConfig["loc_CharacterDes_84"] =
{
	zh = "少女一定要带上耳环，然后四十五度角微笑，这可是最完美的自拍方式。",
	en = "Girls should wear an earring and smile at a forty-five degree angle for the most perfect selfie.",
	zht = "少女一定要帶上耳環，然後四十五度角微笑，這可是最完美的自拍方式。",
}
LocalizationConfig["loc_CharacterDes_85"] =
{
	zh = "很久很久以前，一位画家想用艺术喊出内心的声音，为此而创作的画作，谁知道流传到今天变成了一个非常流行的表情。",
	en = "A long time ago, an artist painted the sound within himself, who'd have known that it would end up being turned into a famous emoji.",
	zht = "很久很久以前，一位畫家想用藝術喊出內心的聲音，為此而創作的畫作，誰知道流傳到今天變成了一個非常流行的表情。",
}
LocalizationConfig["loc_CharacterDes_86"] =
{
	zh = "好几千年以前的一只猪蹄，被考古学家找到的时候，皮肤还有弹性，可是保存技术有限，没多久就氧化了。",
	en = "Archaeologists discovered a pig's trotter from thousands of years ago whose skin still had elasticity but it oxidized not long after.",
	zht = "好幾千年以前的一隻豬蹄，被考古學家找到的時候，皮膚還有彈性，可是保存技術有限，沒多久就氧化了。",
}
LocalizationConfig["loc_CharacterDes_87"] =
{
	zh = "根据神话故事绘制的肖像，举起一只手指等待着…",
	en = "A portrait drawn about a myth, he points his finger and waits……",
	zht = "根據神話故事繪製的肖像，舉起一隻手指等待著…",
}
LocalizationConfig["loc_CharacterDes_88"] =
{
	zh = "博物馆里为了还原出原始人的生活状态制作的蜡像， 嗯，原始人真的是这样子吗？",
	en = "A waxwork made by the museum in an attempt to recreate what real primitive humans were like. Did they really look like this do you think?",
	zht = "博物館裡為了還原出原始人的生活狀態製作的蠟像， 嗯，原始人真的是這樣子嗎？",
}
LocalizationConfig["loc_CharacterDes_89"] =
{
	zh = "博物馆里为了还原出原始人的生活状态制作的蜡像， 嗯，可是为什么脸看起来有点像哪个明星呢？",
	en = "A waxwork made by the museum in an attempt to recreate what real primitive humans were like. But why does she look oddly familiar to a certain celebrity?",
	zht = "博物館裡為了還原出原始人的生活狀態製作的蠟像， 嗯，可是為什麼臉看起來有點像哪個明星呢？",
}
LocalizationConfig["loc_CharacterDes_90"] =
{
	zh = "爸爸的头发是棕色的，妈妈的头发是红色的，儿子的头发为什么是白色的？",
	en = "His father's hair is brown and his mother's hair is red……so why is his hair white?",
	zht = "爸爸的頭髮是棕色的，媽媽的頭髮是紅色的，兒子的頭髮為什麼是白色的？",
}
LocalizationConfig["loc_CharacterDes_91"] =
{
	zh = "哭着哭着整个人就变成了解构艺术画像！流芳百世。",
	en = "All her crying messed up her features and now they're all over the place! It's a look that has gone down in history.",
	zht = "哭著哭著整個人就變成瞭解構藝術畫像！流芳百世。",
}
LocalizationConfig["loc_CharacterDes_92"] =
{
	zh = "特别喜欢使用超粗眉笔画眉毛，一不小心就连一起了。",
	en = "She loves drawing on exceptionally thick eyebrows, but this time she accidentally joined the two together.",
	zht = "特別喜歡使用超粗眉筆劃眉毛，一不小心就連一起了。",
}
LocalizationConfig["loc_CharacterDes_93"] =
{
	zh = "根据有名的历史人物制作的蜡像，放在博物馆里人气很高呢。",
	en = "A waxwork made after a famous historical figure, it's an extremely popular ehibit within the museum.",
	zht = "根據有名的歷史人物製作的蠟像，放在博物館裡人氣很高呢。",
}
LocalizationConfig["loc_CharacterDes_94"] =
{
	zh = "身为警察却很倒霉。俗话说吃饭睡觉打豆豆，豆豆虽然有点可怜，不过也许这就是他喜欢给人起外号的后果。",
	en = "A pretty lousy policeman in all honesty, this is probably why others have given him this nickname.",
	zht = "身為員警卻很倒楣。俗話說吃飯睡覺打豆豆，豆豆雖然有點可憐，不過也許這就是他喜歡給人起外號的後果。",
}
LocalizationConfig["loc_CharacterDes_95"] =
{
	zh = "真正的主角！曾经是个霍比特人，得到了秘宝之后选择做一个普通人，直到后来碰上了命中注定的人。",
	en = "The real protagonist! He was a hobbit but became a normal person after finding his 'precious'.",
	zht = "真正的主角！曾經是個霍比特人，得到了秘寶之後選擇做一個普通人，直到後來碰上了命中註定的人。",
}
LocalizationConfig["loc_CharacterDes_96"] =
{
	zh = "经常因为各种原因摔跤受伤，是医院的常客，但是神奇的是一直没有挂掉，这到底是倒霉还是幸运呢？",
	en = "He always gets hurt, making him a common sight at hospitals; it's a miracle he's still alive. Is he cursed or just simply unlucky?",
	zht = "經常因為各種原因摔跤受傷，是醫院的常客，但是神奇的是一直沒有掛掉，這到底是倒楣還是幸運呢？",
}
LocalizationConfig["loc_CharacterDes_97"] =
{
	zh = "装束看起来有点吓人。由于工作太过繁重，不得已把各种眼镜，剪刀随身携带，不加班全凭手艺。传说他还会地球上失传千年的解牛刀法。",
	en = "He looks scary but carries all his gear as he's got so much work to do. It's said he knows a knife technique that was lost for millennia.",
	zht = "裝束看起來有點嚇人。由於工作太過繁重，不得已把各種眼鏡，剪刀隨身攜帶，不加班全憑手藝。傳說他還會地球上失傳千年的解牛刀法。",
}
LocalizationConfig["loc_CharacterDes_98"] =
{
	zh = "天生的主角？据说大侦探的智商可不是团队里最高的，推理这个东西靠的还是个人的努力，想成为侦探的小伙子们加油啦。",
	en = "Born to be a protagonist? Of course not, He is not the smartest person, but he works hard to solve cases.",
	zht = "天生的主角？據說大偵探的智商可不是團隊裡最高的，推理這個東西靠的還是個人的努力，想成為偵探的小夥子們加油啦。",
}
LocalizationConfig["loc_CharacterDes_99"] =
{
	zh = "可能是这个世界上智商最高的人，对推理没有什么兴趣。时间都花在了保护爱闯祸的弟弟身上。",
	en = "Possibly the smartest man in the world, but not interested in solving crimes at all. He spends all his time getting his little brother out of trouble.",
	zht = "可能是這個世界上智商最高的人，對推理沒有什麼興趣。時間都花在了保護愛闖禍的弟弟身上。",
}
LocalizationConfig["loc_CharacterDes_100"] =
{
	zh = "天才小学生，逻辑超强，非常喜欢写侦探小说，有传言说他本来是成年人，因为一次意外身体缩小变成了小学生。",
	en = "A gifted elementary student with epic powers of deduction who loves writing detective stories. It's said he's an adult that was turned back into a student.",
	zht = "天才小學生，邏輯超強，非常喜歡寫偵探小說，有傳言說他本來是成年人，因為一次意外身體縮小變成了小學生。",
}
LocalizationConfig["loc_CharacterDes_101"] =
{
	zh = "充满谜团的犯罪者。特技：无限附身，可以控制各种角色做出坏事，自己因而一直逍遥法外。",
	en = "An enigmatic criminal. Skill: Unlimited possession, he can control all sorts of characters and make them perform misdeeds, he thus remains at large.",
	zht = "充滿謎團的犯罪者。特技：無限附身，可以控制各種角色做出壞事，自己因而一直逍遙法外。",
}
LocalizationConfig["loc_CharacterDes_102"] =
{
	zh = "出门没马车，不如乌龟爬，悬疑星的老司机。最近他们成立了一个嘟嘟马车的协会，集体要求涨工资。福特先生对此表示强烈抗议。",
	en = "No cab, no way. These experienced cabbies of Suspense Planet formed the Ooh Brrgh Cab Association for higher wages. Mr. Ford fervently opposed this.",
	zht = "出門沒馬車，不如烏龜爬，懸疑星的老司機。最近他們成立了一個嘟嘟馬車的協會，集體要求漲工資。福特先生對此表示強烈抗議。",
}
LocalizationConfig["loc_CharacterDes_103"] =
{
	zh = "公平和正义的代表。手握小锤掌握生杀大权。头顶贵重的假发，不仅可以代表法官的公正无私，还能让人看起来容光焕发，真是好东西。",
	en = "Representative of fairness and justice, the gavel he holds has the power of life and death. His wig isn't just a symbol of justice, it's really cool too.",
	zht = "公平和正義的代表。手握小錘掌握生殺大權。頭頂貴重的假髮，不僅可以代表法官的公正無私，還能讓人看起來容光煥發，真是好東西。",
}
LocalizationConfig["loc_CharacterDes_104"] =
{
	zh = "神秘三人女团中的大姐，擅长事前观察和计划。",
	en = "The eldest of the mysterious sister art thief trio, she's good at observation and planning.",
	zht = "神秘三人女團中的大姐，擅長事前觀察和計畫。",
}
LocalizationConfig["loc_CharacterDes_105"] =
{
	zh = "历史上最可怕且神秘的犯罪者之一，因他而出的书不计其数，被列举出的嫌疑人众多，关于他的讨论也许永远不会停止。",
	en = "One of the most terrifying and mysterious criminals ever, with countless books written about him and many suspects, maybe discussion will continue forever.",
	zht = "歷史上最可怕且神秘的犯罪者之一，因他而出的書不計其數，被列舉出的嫌疑人眾多，關於他的討論也許永遠不會停止。",
}
LocalizationConfig["loc_CharacterDes_106"] =
{
	zh = "需要什么小道消息，找他们肯定没错。",
	en = "If you need any information, you can always find them.",
	zht = "需要什麼小道消息，找他們肯定沒錯。",
}
LocalizationConfig["loc_CharacterDes_107"] =
{
	zh = "爱读书看报的小学生。居然没有近视眼，是用最新的激光技术做了视力改善手术吗？",
	en = "An elementary student who loves reading books and newspapers. He may not be short-sighted, but did he have corrective laser eye surgery anyway?",
	zht = "愛讀書看報的小學生。居然沒有近視眼，是用最新的雷射技術做了視力改善手術嗎？",
}
LocalizationConfig["loc_CharacterDes_108"] =
{
	zh = "报社的编辑长。十分忙碌，身上带着好几个电话。据说现在正在练习用意念和人通讯。",
	en = "The chief editor of a newspaper. Extremely busy all the time, she carries many phones with her. It's said that she's practicing telepathic communication.",
	zht = "報社的編輯長。十分忙碌，身上帶著好幾個電話。據說現在正在練習用意念和人通訊。",
}
LocalizationConfig["loc_CharacterDes_109"] =
{
	zh = "神秘三人女团中的三妹，擅长操作各种机械。",
	en = "The youngest of the mysterious sister art thief trio, she has an affinity for machinery operation.",
	zht = "神秘三人女團中的三妹，擅長操作各種機械。",
}
LocalizationConfig["loc_CharacterDes_110"] =
{
	zh = "嫌疑人被抓的概率十分高，不过在侦探故事中，你可能看到反转，或者反转反转再反转。",
	en = "He's the usual suspect, but there are twists in detective stories, or even twists within twists.",
	zht = "嫌疑人被抓的概率十分高，不過在偵探故事中，你可能看到反轉，或者反轉反轉再反轉。",
}
LocalizationConfig["loc_CharacterDes_111"] =
{
	zh = "这把刀拔出来，他就是真正的逝者了。说有些人活着，但是他已经死了，大概就是这个意思。",
	en = "If that knife's pulled out he'll be dead for sure. It's said that some bodies live on even after they're dead inside, that's more or less what Morty is.",
	zht = "這把刀拔出來，他就是真正的逝者了。說有些人活著，但是他已經死了，大概就是這個意思。",
}
LocalizationConfig["loc_CharacterDes_112"] =
{
	zh = "在学校里经常被人欺负，于是选择拿起厚重的书本防身。后来在不知不觉中记住了六法全书，走上了靠知识保护自己的道路。",
	en = "He was bullied at school, so he carried big books to protect himself, he eventually knew everything in them and began using knowledge to protect himself.",
	zht = "在學校裡經常被人欺負，於是選擇拿起厚重的書本防身。後來在不知不覺中記住了六法全書，走上了靠知識保護自己的道路。",
}
LocalizationConfig["loc_CharacterDes_113"] =
{
	zh = "身怀各种绝技的房东太太。不管是多奇怪的房客过来，都能管理得如同自家猫咪一样服帖。有时还会开豪华跑车出去兜风。",
	en = "An old landlady with all sorts of skills. No matter the tenant, she makes them as obedient as her house cats. She sometimes even rides in her sportscar.",
	zht = "身懷各種絕技的房東太太。不管是多奇怪的房客過來，都能管理得如同自家貓咪一樣服帖。有時還會開豪華跑車出去兜風。",
}
LocalizationConfig["loc_CharacterDes_114"] =
{
	zh = "年轻帅气的调酒师，其娴熟的技术和磁性的声线深受各种美女欢迎，从他这里可以拿到很多不容易获取的情报。",
	en = "A young, attractive bartender. His great skills make him a chick magnet, you can obtain all sorts of intel that's hard to come by from him.",
	zht = "年輕帥氣的調酒師，其嫺熟的技術和磁性的聲線深受各種美女歡迎，從他這裡可以拿到很多不容易獲取的情報。",
}
LocalizationConfig["loc_CharacterDes_115"] =
{
	zh = "带着眼镜的博士。拥有天马行空的想象力和说干就干的创造力。虽然很多发明在使用一段时间后就会出现致命缺陷，但是大家还是很期待他稀奇古怪的新点子。",
	en = "A doctor with glasses. He has a pioneering imagination and creativity, His inventions have fatal flaws in them, but everyone loves them anyway.",
	zht = "帶著眼鏡的博士。擁有天馬行空的想像力和說幹就幹的創造力。雖然很多發明在使用一段時間後就會出現致命缺陷，但是大家還是很期待他稀奇古怪的新點子。",
}
LocalizationConfig["loc_CharacterDes_116"] =
{
	zh = "神秘三人女团中的二姐，身手出众，临场应变能力出色。",
	en = "The middle sister of the mysterious sister art thief trio, she has amazing athletic ability and can work her way out of any restraints.",
	zht = "神秘三人女團中的二姐，身手出眾，臨場應變能力出色。",
}
LocalizationConfig["loc_CharacterDes_117"] =
{
	zh = "看起来还算稳重，梦想是成为侦探，然而因为视力问题一直搞错各种东西。",
	en = "Looks stable and dreams of being a detective, but his eyesight is always causing him trouble.",
	zht = "看起來還算穩重，夢想是成為偵探，然而因為視力問題一直搞錯各種東西。",
}
LocalizationConfig["loc_CharacterDes_118"] =
{
	zh = "年轻有为的检察官，绝技是用额头夹死蚊子。如果他邀请你一起下国际象棋，千万不要答应！",
	en = "A young, promising prosecutor who can kill mosquitoes with his forehead. If he invites you to a game of chess, don't accept the offer!",
	zht = "年輕有為的檢察官，絕技是用額頭夾死蚊子。如果他邀請你一起下國際象棋，千萬不要答應！",
}
LocalizationConfig["loc_CharacterDes_119"] =
{
	zh = "捣蛋大师，智商情商超高，给整个星球带来了巨大的麻烦，但这一切都是为了引起大侦探的注意。",
	en = "The master of disaster. With his high IQ and EQ, he has brought catastrophe to the whole planet, but this is all just to attract Holmees' attention.",
	zht = "搗蛋大師，智商情商超高，給整個星球帶來了巨大的麻煩，但這一切都是為了引起大偵探的注意。",
}
LocalizationConfig["loc_CharacterSkill_1"] =
{
	zh = "细心 + %d",
	en = "Attentive +%d",
	zht = "細心 + %d",
}
LocalizationConfig["loc_CharacterSkill_2"] =
{
	zh = "创造 + %d",
	en = "Creativity +%d",
	zht = "創造 + %d",
}
LocalizationConfig["loc_CharacterSkill_3"] =
{
	zh = "逻辑 + %d",
	en = "Logic +%d",
	zht = "邏輯 + %d",
}
LocalizationConfig["loc_CharacterSkill_4"] =
{
	zh = "神秘 + %d",
	en = "Mystery +%d",
	zht = "神秘 + %d",
}
LocalizationConfig["loc_CharacterSkill_5"] =
{
	zh = "体力 + %d",
	en = "HP +%d",
	zht = "體力 + %d",
}
LocalizationConfig["loc_CharacterSkill_6"] =
{
	zh = "胆识 + %d",
	en = "Courage +%d",
	zht = "膽識 + %d",
}
LocalizationConfig["loc_CharacterSkill_7"] =
{
	zh = "艺术 + %d",
	en = "Arts +%d",
	zht = "藝術 + %d",
}
LocalizationConfig["loc_CharacterSkill_8"] =
{
	zh = "电脑 + %d",
	en = "IT +%d",
	zht = "電腦 + %d",
}
LocalizationConfig["loc_CharacterSkill_9"] =
{
	zh = "烹饪 + %d",
	en = "Cooking +%d",
	zht = "烹飪 + %d",
}
LocalizationConfig["loc_CharacterSkill_10"] =
{
	zh = "忍耐 + %d",
	en = "Tenacity +%d",
	zht = "忍耐 + %d",
}
LocalizationConfig["loc_CharacterSkill_11"] =
{
	zh = "颜值 + %d",
	en = "Looks +%d",
	zht = "顏值 + %d",
}
LocalizationConfig["loc_CharacterSkill_12"] =
{
	zh = "亲和 + %d",
	en = "Affinity +%d",
	zht = "親和 + %d",
}
LocalizationConfig["loc_CharacterSkill_13"] =
{
	zh = "运气 + %d",
	en = "Luck +%d",
	zht = "運氣 + %d",
}
LocalizationConfig["loc_CharacterSkill_14"] =
{
	zh = "口才 + %d",
	en = "Speech +%d",
	zht = "口才 + %d",
}
LocalizationConfig["loc_CharacterSkill_15"] =
{
	zh = "速度 + %d",
	en = "Speed +%d",
	zht = "速度 + %d",
}
LocalizationConfig["loc_CharacterSkill_16"] =
{
	zh = "数学 + %d",
	en = "Math +%d",
	zht = "數學 + %d",
}
LocalizationConfig["loc_CharacterSkill_17"] =
{
	zh = "全属性 + %d",
	en = "All Stats +%d",
	zht = "全屬性 + %d",
}
LocalizationConfig["loc_CharacterSkill_18"] =
{
	zh = "全队细心 + %d",
	en = "Party Attentive +%d",
	zht = "全隊細心 + %d",
}
LocalizationConfig["loc_CharacterSkill_19"] =
{
	zh = "全队创造 + %d",
	en = "Party Creativity +%d",
	zht = "全隊創造 + %d",
}
LocalizationConfig["loc_CharacterSkill_20"] =
{
	zh = "全队逻辑 + %d",
	en = "Party Logic +%d",
	zht = "全隊邏輯 + %d",
}
LocalizationConfig["loc_CharacterSkill_21"] =
{
	zh = "全队神秘 + %d",
	en = "Party Mystery +%d",
	zht = "全隊神秘 + %d",
}
LocalizationConfig["loc_CharacterSkill_22"] =
{
	zh = "全队体力 + %d",
	en = "Party HP +%d",
	zht = "全隊體力 + %d",
}
LocalizationConfig["loc_CharacterSkill_23"] =
{
	zh = "全队胆识 + %d",
	en = "Party Courage+%d",
	zht = "全隊膽識 + %d",
}
LocalizationConfig["loc_CharacterSkill_24"] =
{
	zh = "全队艺术 + %d",
	en = "Party Arts +%d",
	zht = "全隊藝術 + %d",
}
LocalizationConfig["loc_CharacterSkill_25"] =
{
	zh = "全队电脑 + %d",
	en = "Party IT +%d",
	zht = "全隊電腦 + %d",
}
LocalizationConfig["loc_CharacterSkill_26"] =
{
	zh = "全队烹饪 + %d",
	en = "Party Cooking +%d",
	zht = "全隊烹飪 + %d",
}
LocalizationConfig["loc_CharacterSkill_27"] =
{
	zh = "全队忍耐 + %d",
	en = "Party Tenacity +%d",
	zht = "全隊忍耐 + %d",
}
LocalizationConfig["loc_CharacterSkill_28"] =
{
	zh = "全队颜值 + %d",
	en = "Party Looks +%d",
	zht = "全隊顏值 + %d",
}
LocalizationConfig["loc_CharacterSkill_29"] =
{
	zh = "全队亲和 + %d",
	en = "Party Affinity +%d",
	zht = "全隊親和 + %d",
}
LocalizationConfig["loc_CharacterSkill_30"] =
{
	zh = "全队运气 + %d",
	en = "Party Luck +%d",
	zht = "全隊運氣 + %d",
}
LocalizationConfig["loc_CharacterSkill_31"] =
{
	zh = "全队口才 + %d",
	en = "Party Speech +%d",
	zht = "全隊口才 + %d",
}
LocalizationConfig["loc_CharacterSkill_32"] =
{
	zh = "全队速度 + %d",
	en = "Party Speed +%d",
	zht = "全隊速度 + %d",
}
LocalizationConfig["loc_CharacterSkill_33"] =
{
	zh = "全队数学 + %d",
	en = "Party Math +%d",
	zht = "全隊數學 + %d",
}
LocalizationConfig["loc_CharacterSkill_34"] =
{
	zh = "全队全属性 + %d",
	en = "All Party Stats +%d",
	zht = "全隊全屬性 + %d",
}
LocalizationConfig["loc_CharacterSkill_35"] =
{
	zh = "细心 + %d%%",
	en = "Attentive + %d%%",
	zht = "細心 + %d%%",
}
LocalizationConfig["loc_CharacterSkill_36"] =
{
	zh = "创造 + %d%%",
	en = "Creativity + %d%%",
	zht = "創造 + %d%%",
}
LocalizationConfig["loc_CharacterSkill_37"] =
{
	zh = "逻辑 + %d%%",
	en = "Logic + %d%%",
	zht = "邏輯 + %d%%",
}
LocalizationConfig["loc_CharacterSkill_38"] =
{
	zh = "神秘 + %d%%",
	en = "Mystery + %d%%",
	zht = "神秘 + %d%%",
}
LocalizationConfig["loc_CharacterSkill_39"] =
{
	zh = "体力 + %d%%",
	en = "HP + %d%%",
	zht = "體力 + %d%%",
}
LocalizationConfig["loc_CharacterSkill_40"] =
{
	zh = "胆识 + %d%%",
	en = "Courage + %d%%",
	zht = "膽識 + %d%%",
}
LocalizationConfig["loc_CharacterSkill_41"] =
{
	zh = "艺术 + %d%%",
	en = "Arts + %d%%",
	zht = "藝術 + %d%%",
}
LocalizationConfig["loc_CharacterSkill_42"] =
{
	zh = "电脑 + %d%%",
	en = "IT + %d%%",
	zht = "電腦 + %d%%",
}
LocalizationConfig["loc_CharacterSkill_43"] =
{
	zh = "烹饪 + %d%%",
	en = "Cooking + %d%%",
	zht = "烹飪 + %d%%",
}
LocalizationConfig["loc_CharacterSkill_44"] =
{
	zh = "忍耐 + %d%%",
	en = "Tenacity + %d%%",
	zht = "忍耐 + %d%%",
}
LocalizationConfig["loc_CharacterSkill_45"] =
{
	zh = "颜值 + %d%%",
	en = "Looks + %d%%",
	zht = "顏值 + %d%%",
}
LocalizationConfig["loc_CharacterSkill_46"] =
{
	zh = "亲和 + %d%%",
	en = "Affinity + %d%%",
	zht = "親和 + %d%%",
}
LocalizationConfig["loc_CharacterSkill_47"] =
{
	zh = "运气 + %d%%",
	en = "Luck + %d%%",
	zht = "運氣 + %d%%",
}
LocalizationConfig["loc_CharacterSkill_48"] =
{
	zh = "口才 + %d%%",
	en = "Speech + %d%%",
	zht = "口才 + %d%%",
}
LocalizationConfig["loc_CharacterSkill_49"] =
{
	zh = "速度 + %d%%",
	en = "Speed + %d%%",
	zht = "速度 + %d%%",
}
LocalizationConfig["loc_CharacterSkill_50"] =
{
	zh = "数学 + %d%%",
	en = "Math + %d%%",
	zht = "數學 + %d%%",
}
LocalizationConfig["loc_CharacterSkill_51"] =
{
	zh = "全属性 + %d%%",
	en = "All Stats + %d%%",
	zht = "全屬性 + %d%%",
}
LocalizationConfig["loc_CharacterSkill_52"] =
{
	zh = "全队细心 + %d%%",
	en = "Party Attentive + %d%%",
	zht = "全隊細心 + %d%%",
}
LocalizationConfig["loc_CharacterSkill_53"] =
{
	zh = "全队创造 + %d%%",
	en = "Party Creativity + %d%%",
	zht = "全隊創造 + %d%%",
}
LocalizationConfig["loc_CharacterSkill_54"] =
{
	zh = "全队逻辑 + %d%%",
	en = "Party Logic + %d%%",
	zht = "全隊邏輯 + %d%%",
}
LocalizationConfig["loc_CharacterSkill_55"] =
{
	zh = "全队神秘 + %d%%",
	en = "Party Mystery + %d%%",
	zht = "全隊神秘 + %d%%",
}
LocalizationConfig["loc_CharacterSkill_56"] =
{
	zh = "全队体力 + %d%%",
	en = "Party HP + %d%%",
	zht = "全隊體力 + %d%%",
}
LocalizationConfig["loc_CharacterSkill_57"] =
{
	zh = "全队胆识 + %d%%",
	en = "Party Courage + %d%%",
	zht = "全隊膽識 + %d%%",
}
LocalizationConfig["loc_CharacterSkill_58"] =
{
	zh = "全队艺术 + %d%%",
	en = "Party Arts + %d%%",
	zht = "全隊藝術 + %d%%",
}
LocalizationConfig["loc_CharacterSkill_59"] =
{
	zh = "全队电脑 + %d%%",
	en = "Party IT + %d%%",
	zht = "全隊電腦 + %d%%",
}
LocalizationConfig["loc_CharacterSkill_60"] =
{
	zh = "全队烹饪 + %d%%",
	en = "Party Cooking + %d%%",
	zht = "全隊烹飪 + %d%%",
}
LocalizationConfig["loc_CharacterSkill_61"] =
{
	zh = "全队忍耐 + %d%%",
	en = "Party Tenacity + %d%%",
	zht = "全隊忍耐 + %d%%",
}
LocalizationConfig["loc_CharacterSkill_62"] =
{
	zh = "全队颜值 + %d%%",
	en = "Party Looks + %d%%",
	zht = "全隊顏值 + %d%%",
}
LocalizationConfig["loc_CharacterSkill_63"] =
{
	zh = "全队亲和 + %d%%",
	en = "Party Affinity + %d%%",
	zht = "全隊親和 + %d%%",
}
LocalizationConfig["loc_CharacterSkill_64"] =
{
	zh = "全队运气 + %d%%",
	en = "Party Luck + %d%%",
	zht = "全隊運氣 + %d%%",
}
LocalizationConfig["loc_CharacterSkill_65"] =
{
	zh = "全队口才 + %d%%",
	en = "Party Speech + %d%%",
	zht = "全隊口才 + %d%%",
}
LocalizationConfig["loc_CharacterSkill_66"] =
{
	zh = "全队速度 + %d%%",
	en = "Party Speed + %d%%",
	zht = "全隊速度 + %d%%",
}
LocalizationConfig["loc_CharacterSkill_67"] =
{
	zh = "全队数学 + %d%%",
	en = "Party Math + %d%%",
	zht = "全隊數學 + %d%%",
}
LocalizationConfig["loc_CharacterSkill_68"] =
{
	zh = "全队全属性 + %d%%",
	en = "Party Stats + %d%%",
	zht = "全隊全屬性 + %d%%",
}
LocalizationConfig["loc_CharacterSkill_69"] =
{
	zh = "探索悬疑星产出 + %d%%",
	en = "Suspense Planet Exploration Earnings + %d%%",
	zht = "探索懸疑星產出 + %d%%",
}
LocalizationConfig["loc_CharacterSkill_70"] =
{
	zh = "探索冒险星产出 + %d%%",
	en = "Adventure Planet Exploration Earnings + %d%%",
	zht = "探索冒險星產出 + %d%%",
}
LocalizationConfig["loc_CharacterSkill_71"] =
{
	zh = "探索美食星产出 + %d%%",
	en = "Dessert Planet Exploration Earnings + %d%%",
	zht = "探索美食星產出 + %d%%",
}
LocalizationConfig["loc_CharacterSkill_72"] =
{
	zh = "探索博物馆星产出 + %d%%",
	en = "Museum Planet Exploration Earnings + %d%%",
	zht = "探索博物館星產出 + %d%%",
}
LocalizationConfig["loc_CharacterSkill_73"] =
{
	zh = "探索新星球星产出 + %d%%",
	en = "New Planet Exploration Earnings + %d%%",
	zht = "探索新星球星產出 + %d%%",
}
LocalizationConfig["loc_CharacterSkill_74"] =
{
	zh = "探索产出 + %d%%",
	en = "Exploration Earnings + %d%%",
	zht = "探索產出 + %d%%",
}
LocalizationConfig["loc_CharacterSkill_75"] =
{
	zh = "探索悬疑星时间 - %d%%",
	en = "Suspense Planet Exploration Time - %d%%",
	zht = "探索懸疑星時間 - %d%%",
}
LocalizationConfig["loc_CharacterSkill_76"] =
{
	zh = "探索冒险星时间 - %d%%",
	en = "Adventure Planet Exploration Time - %d%%",
	zht = "探索冒險星時間 - %d%%",
}
LocalizationConfig["loc_CharacterSkill_77"] =
{
	zh = "探索美食星时间 - %d%%",
	en = "Dessert Planet Exploration Time - %d%%",
	zht = "探索美食星時間 - %d%%",
}
LocalizationConfig["loc_CharacterSkill_78"] =
{
	zh = "探索博物馆星时间 - %d%%",
	en = "Museum Planet Exploration Time - %d%%",
	zht = "探索博物館星時間 - %d%%",
}
LocalizationConfig["loc_CharacterSkill_79"] =
{
	zh = "探索新星球星时间 - %d%%",
	en = "New Planet Exploration Time - %d%%",
	zht = "探索新星球星時間 - %d%%",
}
LocalizationConfig["loc_CharacterSkill_80"] =
{
	zh = "探索时间 - %d%%",
	en = "Exploration Time - %d%%",
	zht = "探索時間 - %d%%",
}
LocalizationConfig["loc_CharacterSkill_81"] =
{
	zh = "探索悬疑星暴击率 + %d%%",
	en = "Suspense Planet Exploration Crit Rate + %d%%",
	zht = "探索懸疑星暴擊率 + %d%%",
}
LocalizationConfig["loc_CharacterSkill_82"] =
{
	zh = "探索冒险星暴击率 + %d%%",
	en = "Adventure Planet Exploration Crit Rate + %d%%",
	zht = "探索冒險星暴擊率 + %d%%",
}
LocalizationConfig["loc_CharacterSkill_83"] =
{
	zh = "探索美食星暴击率 + %d%%",
	en = "Dessert Planet Exploration Crit Rate + %d%%",
	zht = "探索美食星暴擊率 + %d%%",
}
LocalizationConfig["loc_CharacterSkill_84"] =
{
	zh = "探索博物馆星暴击率 + %d%%",
	en = "Museum Planet Exploration Crit Rate + %d%%",
	zht = "探索博物館星暴擊率 + %d%%",
}
LocalizationConfig["loc_CharacterSkill_85"] =
{
	zh = "探索新星球星暴击率 + %d%%",
	en = "New Planet Exploration Crit Rate + %d%%",
	zht = "探索新星球星暴擊率 + %d%%",
}
LocalizationConfig["loc_CharacterSkill_86"] =
{
	zh = "探索暴击率 + %d%%",
	en = "Exploration Crit Rate + %d%%",
	zht = "探索暴擊率 + %d%%",
}
LocalizationConfig["loc_CharacterSkill_87"] =
{
	zh = "探索悬疑星经验值 + %d%%",
	en = "Suspense Planet Exploration Exp + %d%%",
	zht = "探索懸疑星經驗值 + %d%%",
}
LocalizationConfig["loc_CharacterSkill_88"] =
{
	zh = "探索冒险星经验值 + %d%%",
	en = "Adventure Planet Exploration Exp + %d%%",
	zht = "探索冒險星經驗值 + %d%%",
}
LocalizationConfig["loc_CharacterSkill_89"] =
{
	zh = "探索美食星经验值 + %d%%",
	en = "Dessert Planet Exploration Exp + %d%%",
	zht = "探索美食星經驗值 + %d%%",
}
LocalizationConfig["loc_CharacterSkill_90"] =
{
	zh = "探索博物馆星经验值 + %d%%",
	en = "Museum Planet Exploration Exp + %d%%",
	zht = "探索博物館星經驗值 + %d%%",
}
LocalizationConfig["loc_CharacterSkill_91"] =
{
	zh = "探索新星球星经验值 + %d%%",
	en = "New Planet Exploration Exp + %d%%",
	zht = "探索新星球星經驗值 + %d%%",
}
LocalizationConfig["loc_CharacterSkill_92"] =
{
	zh = "探索时经验值 + %d%%",
	en = "Exploration Exp + %d%%",
	zht = "探索時經驗值 + %d%%",
}
LocalizationConfig["loc_CharacterSkill_93"] =
{
	zh = "探索悬疑星全队经验值 + %d%%",
	en = "Suspense Planet Exploration Party Exp + %d%%",
	zht = "探索懸疑星全隊經驗值 + %d%%",
}
LocalizationConfig["loc_CharacterSkill_94"] =
{
	zh = "探索冒险星全队经验值 + %d%%",
	en = "Adventure Planet Exploration Party Exp + %d%%",
	zht = "探索冒險星全隊經驗值 + %d%%",
}
LocalizationConfig["loc_CharacterSkill_95"] =
{
	zh = "探索美食星全队经验值 + %d%%",
	en = "Dessert Planet Exploration Party Exp + %d%%",
	zht = "探索美食星全隊經驗值 + %d%%",
}
LocalizationConfig["loc_CharacterSkill_96"] =
{
	zh = "探索博物馆星全队经验值 + %d%%",
	en = "Museum Planet Exploration Party Exp + %d%%",
	zht = "探索博物館星全隊經驗值 + %d%%",
}
LocalizationConfig["loc_CharacterSkill_97"] =
{
	zh = "探索新星球星全队经验值 + %d%%",
	en = "New Planet Exploration Party Exp + %d%%",
	zht = "探索新星球星全隊經驗值 + %d%%",
}
LocalizationConfig["loc_CharacterSkill_98"] =
{
	zh = "探索全队经验值 + %d%%",
	en = "Exploration Party Exp + %d%%",
	zht = "探索全隊經驗值 + %d%%",
}
LocalizationConfig["loc_CharacterSkill_99"] =
{
	zh = "和大侦探探索产出 + %d%%",
	en = "Earnings from exploring with Holmees + %d%%",
	zht = "和大偵探探索產出 + %d%%",
}
LocalizationConfig["loc_CharacterSkill_100"] =
{
	zh = "探索检验室全队经验值 + %d%%",
	en = "Party Exp in Lab Exploration + %d%%",
	zht = "探索檢驗室全隊經驗值 + %d%%",
}
LocalizationConfig["loc_CharacterSkill_101"] =
{
	zh = "探索晶石暴击概率提升 + %d%%",
	en = "Crystal Exploration Crit Rate + %d%%",
	zht = "探索晶石暴擊概率提升 + %d%%",
}
LocalizationConfig["loc_CharacterSkill_102"] =
{
	zh = "探索晶石产量提升 + %d%%",
	en = "Crystal Exploration Earnings + %d%%",
	zht = "探索晶石產量提升 + %d%%",
}
LocalizationConfig["loc_CharacterSkill_103"] =
{
	zh = "战斗时守护者能力 - %d%%",
	en = "Guardian Ability When Fighting - %d%%",
	zht = "戰鬥時守護者能力 - %d%%",
}
LocalizationConfig["loc_CharacterSkill_104"] =
{
	zh = "探索时人数限制 + %d",
	en = "Exploration Member Limit + %d",
	zht = "探索時人數限制 + %d",
}
LocalizationConfig["loc_CharacterSkill_105"] =
{
	zh = "探索时人数限制 - %d",
	en = "Exploration Member Limit - %d",
	zht = "探索時人數限制 - %d",
}
LocalizationConfig["loc_CharacterSkill_106"] =
{
	zh = "探索可以额外重复%d次",
	en = "Can Repeat Exploration An Extra %d Times",
	zht = "探索可以額外重複%d次",
}
LocalizationConfig["loc_CharacterSkill_107"] =
{
	zh = "探索冒险星时间 + %d%%",
	en = "Adventure Planet Exploration Time + %d%%",
	zht = "探索冒險星時間 + %d%%",
}
LocalizationConfig["loc_CharacterSkill_108"] =
{
	zh = "探索美食星时间 + %d%%",
	en = "Dessert Planet Exploration Time + %d%%",
	zht = "探索美食星時間 + %d%%",
}
LocalizationConfig["loc_CharacterSkill_109"] =
{
	zh = "探索博物馆星时间 + %d%%",
	en = "Museum Planet Exploration Time + %d%%",
	zht = "探索博物館星時間 + %d%%",
}
LocalizationConfig["loc_CharacterSkill_110"] =
{
	zh = "探索悬疑星时间 + %d%%",
	en = "Suspense Planet Exploration Time + %d%%",
	zht = "探索懸疑星時間 + %d%%",
}
LocalizationConfig["loc_CharacterSkill_111"] =
{
	zh = "探索时间 + %d%%",
	en = "Exploration Time + %d%%",
	zht = "探索時間 + %d%%",
}
LocalizationConfig["loc_CharacterSkill_112"] =
{
	zh = "探索冒险星有%d%%概率立刻完成",
	en = "Have a %d%% chance of instantly completing exploration when exploring Adventure Planet",
	zht = "探索冒險星有%d%%概率立刻完成",
}
LocalizationConfig["loc_CharacterSkill_113"] =
{
	zh = "探索美食星有%d%%概率立刻完成",
	en = "Have a %d%% chance of instantly completing exploration when exploring Dessert Planet",
	zht = "探索美食星有%d%%概率立刻完成",
}
LocalizationConfig["loc_CharacterSkill_114"] =
{
	zh = "探索博物馆星有%d%%概率立刻完成",
	en = "Have a %d%% chance of instantly completing exploration when exploring Museum Planet",
	zht = "探索博物館星有%d%%概率立刻完成",
}
LocalizationConfig["loc_CharacterSkill_115"] =
{
	zh = "探索悬疑星有%d%%概率立刻完成",
	en = "Have a %d%% chance of instantly completing exploration when exploring Suspense Planet",
	zht = "探索懸疑星有%d%%概率立刻完成",
}
LocalizationConfig["loc_CharacterSkill_116"] =
{
	zh = "探索星球有%d%%概率立刻完成",
	en = "Have a %d%% chance of instantly completing exploration when exploring a new Planet",
	zht = "探索星球有%d%%概率立刻完成",
}
LocalizationConfig["loc_CharacterSkill_117"] =
{
	zh = "浣熊三人组一起探索产出 + %d%%",
	en = "Exploration Earnings With Group of 3 Raccoons + %d%%",
	zht = "浣熊三人組一起探索產出 + %d%%",
}
LocalizationConfig["loc_CharacterSkill_118"] =
{
	zh = "创世纪两人组一起，组合全属性 + %d%%",
	en = "When with Genesis group of 2: Group's Stats + %d%%",
	zht = "創世紀兩人組一起，組合全屬性 + %d%%",
}
LocalizationConfig["loc_ItemName_1"] =
{
	zh = "细心晶片",
	en = "Attentive Chip",
	zht = "細心晶片",
}
LocalizationConfig["loc_ItemName_2"] =
{
	zh = "创造晶片",
	en = "Creativity Chip",
	zht = "創造晶片",
}
LocalizationConfig["loc_ItemName_3"] =
{
	zh = "逻辑晶片",
	en = "Logic Chip",
	zht = "邏輯晶片",
}
LocalizationConfig["loc_ItemName_4"] =
{
	zh = "神秘晶片",
	en = "Mystery Chip",
	zht = "神秘晶片",
}
LocalizationConfig["loc_ItemName_5"] =
{
	zh = "体力晶片",
	en = "HP Chip",
	zht = "體力晶片",
}
LocalizationConfig["loc_ItemName_6"] =
{
	zh = "胆识晶片",
	en = "Courage Chip",
	zht = "膽識晶片",
}
LocalizationConfig["loc_ItemName_7"] =
{
	zh = "艺术晶片",
	en = "Arts Chip",
	zht = "藝術晶片",
}
LocalizationConfig["loc_ItemName_8"] =
{
	zh = "电脑晶片",
	en = "IT Chip",
	zht = "電腦晶片",
}
LocalizationConfig["loc_ItemName_9"] =
{
	zh = "烹饪晶片",
	en = "Cooking Chip",
	zht = "烹飪晶片",
}
LocalizationConfig["loc_ItemName_10"] =
{
	zh = "忍耐晶片",
	en = "Tenacity Chip",
	zht = "忍耐晶片",
}
LocalizationConfig["loc_ItemName_11"] =
{
	zh = "颜值晶片",
	en = "Looks Chip",
	zht = "顏值晶片",
}
LocalizationConfig["loc_ItemName_12"] =
{
	zh = "亲和晶片",
	en = "Affinity Chip",
	zht = "親和晶片",
}
LocalizationConfig["loc_ItemName_13"] =
{
	zh = "运气晶片",
	en = "Luck Chip",
	zht = "運氣晶片",
}
LocalizationConfig["loc_ItemName_14"] =
{
	zh = "口才晶片",
	en = "Speech Chip",
	zht = "口才晶片",
}
LocalizationConfig["loc_ItemName_15"] =
{
	zh = "速度晶片",
	en = "Speed Chip",
	zht = "速度晶片",
}
LocalizationConfig["loc_ItemName_16"] =
{
	zh = "数学晶片",
	en = "Math Chip",
	zht = "數學晶片",
}
LocalizationConfig["loc_ItemName_17"] =
{
	zh = "细心晶石",
	en = "Attentive Mineral",
	zht = "細心晶石",
}
LocalizationConfig["loc_ItemName_18"] =
{
	zh = "创造晶石",
	en = "Creativity Mineral",
	zht = "創造晶石",
}
LocalizationConfig["loc_ItemName_19"] =
{
	zh = "逻辑晶石",
	en = "Logic Mineral",
	zht = "邏輯晶石",
}
LocalizationConfig["loc_ItemName_20"] =
{
	zh = "神秘晶石",
	en = "Mystery Mineral",
	zht = "神秘晶石",
}
LocalizationConfig["loc_ItemName_21"] =
{
	zh = "体力晶石",
	en = "HP Mineral",
	zht = "體力晶石",
}
LocalizationConfig["loc_ItemName_22"] =
{
	zh = "胆识晶石",
	en = "Courage Mineral",
	zht = "膽識晶石",
}
LocalizationConfig["loc_ItemName_23"] =
{
	zh = "艺术晶石",
	en = "Arts Mineral",
	zht = "藝術晶石",
}
LocalizationConfig["loc_ItemName_24"] =
{
	zh = "电脑晶石",
	en = "IT Mineral",
	zht = "電腦晶石",
}
LocalizationConfig["loc_ItemName_25"] =
{
	zh = "烹饪晶石",
	en = "Cooking Mineral",
	zht = "烹飪晶石",
}
LocalizationConfig["loc_ItemName_26"] =
{
	zh = "忍耐晶石",
	en = "Tenacity Mineral",
	zht = "忍耐晶石",
}
LocalizationConfig["loc_ItemName_27"] =
{
	zh = "颜值晶石",
	en = "Looks Mineral",
	zht = "顏值晶石",
}
LocalizationConfig["loc_ItemName_28"] =
{
	zh = "亲和晶石",
	en = "Affinity Mineral",
	zht = "親和晶石",
}
LocalizationConfig["loc_ItemName_29"] =
{
	zh = "运气晶石",
	en = "Luck Mineral",
	zht = "運氣晶石",
}
LocalizationConfig["loc_ItemName_30"] =
{
	zh = "口才晶石",
	en = "Speech Mineral",
	zht = "口才晶石",
}
LocalizationConfig["loc_ItemName_31"] =
{
	zh = "速度晶石",
	en = "Speed Mineral",
	zht = "速度晶石",
}
LocalizationConfig["loc_ItemName_32"] =
{
	zh = "数学晶石",
	en = "Math Mineral",
	zht = "數學晶石",
}
LocalizationConfig["loc_ItemName_33"] =
{
	zh = "细心结晶",
	en = "Attentive Crystal",
	zht = "細心結晶",
}
LocalizationConfig["loc_ItemName_34"] =
{
	zh = "创造结晶",
	en = "Creativity Crystal",
	zht = "創造結晶",
}
LocalizationConfig["loc_ItemName_35"] =
{
	zh = "逻辑结晶",
	en = "Logic Crystal",
	zht = "邏輯結晶",
}
LocalizationConfig["loc_ItemName_36"] =
{
	zh = "神秘结晶",
	en = "Mystery Crystal",
	zht = "神秘結晶",
}
LocalizationConfig["loc_ItemName_37"] =
{
	zh = "体力结晶",
	en = "HP Crystal",
	zht = "體力結晶",
}
LocalizationConfig["loc_ItemName_38"] =
{
	zh = "胆识结晶",
	en = "Courage Crystal",
	zht = "膽識結晶",
}
LocalizationConfig["loc_ItemName_39"] =
{
	zh = "艺术结晶",
	en = "Arts Crystal",
	zht = "藝術結晶",
}
LocalizationConfig["loc_ItemName_40"] =
{
	zh = "电脑结晶",
	en = "IT Crystal",
	zht = "電腦結晶",
}
LocalizationConfig["loc_ItemName_41"] =
{
	zh = "烹饪结晶",
	en = "Cooking Crystal",
	zht = "烹飪結晶",
}
LocalizationConfig["loc_ItemName_42"] =
{
	zh = "忍耐结晶",
	en = "Tenacity Crystal",
	zht = "忍耐結晶",
}
LocalizationConfig["loc_ItemName_43"] =
{
	zh = "颜值结晶",
	en = "Looks Crystal",
	zht = "顏值結晶",
}
LocalizationConfig["loc_ItemName_44"] =
{
	zh = "亲和结晶",
	en = "Affinity Crystal",
	zht = "親和結晶",
}
LocalizationConfig["loc_ItemName_45"] =
{
	zh = "运气结晶",
	en = "Luck Crystal",
	zht = "運氣結晶",
}
LocalizationConfig["loc_ItemName_46"] =
{
	zh = "口才结晶",
	en = "Speech Crystal",
	zht = "口才結晶",
}
LocalizationConfig["loc_ItemName_47"] =
{
	zh = "速度结晶",
	en = "Speed Crystal",
	zht = "速度結晶",
}
LocalizationConfig["loc_ItemName_48"] =
{
	zh = "数学结晶",
	en = "Math Crystal",
	zht = "數學結晶",
}
LocalizationConfig["loc_ItemName_49"] =
{
	zh = "体力条",
	en = "HP Bar",
	zht = "體力條",
}
LocalizationConfig["loc_ItemName_50"] =
{
	zh = "药草",
	en = "Herb",
	zht = "藥草",
}
LocalizationConfig["loc_ItemName_51"] =
{
	zh = "秘籍",
	en = "Cheat Book",
	zht = "秘笈",
}
LocalizationConfig["loc_ItemName_52"] =
{
	zh = "任务卷轴",
	en = "Scroll",
	zht = "任務卷軸",
}
LocalizationConfig["loc_ItemName_53"] =
{
	zh = "魔法条",
	en = "MP Bar",
	zht = "魔法條",
}
LocalizationConfig["loc_ItemName_54"] =
{
	zh = "火把",
	en = "Torch",
	zht = "火把",
}
LocalizationConfig["loc_ItemName_55"] =
{
	zh = "陨石",
	en = "Meteorite",
	zht = "隕石",
}
LocalizationConfig["loc_ItemName_56"] =
{
	zh = "路点",
	en = "Waypoint",
	zht = "路點",
}
LocalizationConfig["loc_ItemName_57"] =
{
	zh = "技能条",
	en = "AP Bar",
	zht = "技能條",
}
LocalizationConfig["loc_ItemName_58"] =
{
	zh = "沙子",
	en = "Sand",
	zht = "沙子",
}
LocalizationConfig["loc_ItemName_59"] =
{
	zh = "毛皮",
	en = "Hide",
	zht = "毛皮",
}
LocalizationConfig["loc_ItemName_60"] =
{
	zh = "迷宫",
	en = "Labyrinth",
	zht = "迷宮",
}
LocalizationConfig["loc_ItemName_61"] =
{
	zh = "对话框",
	en = "Speech Box",
	zht = "對話方塊",
}
LocalizationConfig["loc_ItemName_62"] =
{
	zh = "光盘",
	en = "CD",
	zht = "光碟",
}
LocalizationConfig["loc_ItemName_63"] =
{
	zh = "存档",
	en = "Save File",
	zht = "存檔",
}
LocalizationConfig["loc_ItemName_64"] =
{
	zh = "传送门",
	en = "Portal",
	zht = "傳送門",
}
LocalizationConfig["loc_ItemName_65"] =
{
	zh = "小体力瓶",
	en = "HP Vial",
	zht = "小體力瓶",
}
LocalizationConfig["loc_ItemName_66"] =
{
	zh = "大体力瓶",
	en = "HP Bottle",
	zht = "大體力瓶",
}
LocalizationConfig["loc_ItemName_67"] =
{
	zh = "地图",
	en = "Map",
	zht = "地圖",
}
LocalizationConfig["loc_ItemName_68"] =
{
	zh = "木剑",
	en = "Wood Sword",
	zht = "木劍",
}
LocalizationConfig["loc_ItemName_69"] =
{
	zh = "简易芯片",
	en = "Chip",
	zht = "簡易晶片",
}
LocalizationConfig["loc_ItemName_70"] =
{
	zh = "沙漏",
	en = "Hourglass",
	zht = "沙漏",
}
LocalizationConfig["loc_ItemName_71"] =
{
	zh = "音量",
	en = "Volume",
	zht = "音量",
}
LocalizationConfig["loc_ItemName_72"] =
{
	zh = "盾牌",
	en = "Shield",
	zht = "盾牌",
}
LocalizationConfig["loc_ItemName_73"] =
{
	zh = "好结局",
	en = "Happy Ending",
	zht = "好結局",
}
LocalizationConfig["loc_ItemName_74"] =
{
	zh = "坏结局",
	en = "Bad Ending",
	zht = "壞結局",
}
LocalizationConfig["loc_ItemName_75"] =
{
	zh = "隐藏结局",
	en = "Hidden Ending",
	zht = "隱藏結局",
}
LocalizationConfig["loc_ItemName_76"] =
{
	zh = "神秘光环",
	en = "Halo",
	zht = "神秘光環",
}
LocalizationConfig["loc_ItemName_77"] =
{
	zh = "圣剑",
	en = "Excalibur",
	zht = "聖劍",
}
LocalizationConfig["loc_ItemName_78"] =
{
	zh = "路牌",
	en = "Sign",
	zht = "路牌",
}
LocalizationConfig["loc_ItemName_79"] =
{
	zh = "流星锤",
	en = "Mace",
	zht = "流星錘",
}
LocalizationConfig["loc_ItemName_80"] =
{
	zh = "自发光灯泡",
	en = "Lightbulb",
	zht = "自發光燈泡",
}
LocalizationConfig["loc_ItemName_81"] =
{
	zh = "玩具汽车",
	en = "Toy Car",
	zht = "玩具汽車",
}
LocalizationConfig["loc_ItemName_82"] =
{
	zh = "天使之杖",
	en = "Angel Rod",
	zht = "天使之杖",
}
LocalizationConfig["loc_ItemName_83"] =
{
	zh = "奶瓶",
	en = "Milk Bottle",
	zht = "奶瓶",
}
LocalizationConfig["loc_ItemName_84"] =
{
	zh = "复活十字章",
	en = "Cross",
	zht = "復活十字章",
}
LocalizationConfig["loc_ItemName_85"] =
{
	zh = "三叉戟",
	en = "Trident",
	zht = "三叉戟",
}
LocalizationConfig["loc_ItemName_86"] =
{
	zh = "蓝火头骨",
	en = "Blue Skull",
	zht = "藍火頭骨",
}
LocalizationConfig["loc_ItemName_87"] =
{
	zh = "扑克牌",
	en = "Poker Card",
	zht = "撲克牌",
}
LocalizationConfig["loc_ItemName_88"] =
{
	zh = "小喇叭",
	en = "Megaphone",
	zht = "小喇叭",
}
LocalizationConfig["loc_ItemName_89"] =
{
	zh = "传奇法杖",
	en = "Epic Staff",
	zht = "傳奇法杖",
}
LocalizationConfig["loc_ItemName_90"] =
{
	zh = "魔术师之帽",
	en = "Mage Hat",
	zht = "魔術師之帽",
}
LocalizationConfig["loc_ItemName_91"] =
{
	zh = "苍蝇拍",
	en = "Fly Swat",
	zht = "蒼蠅拍",
}
LocalizationConfig["loc_ItemName_92"] =
{
	zh = "法杖",
	en = "Mage Staff",
	zht = "法杖",
}
LocalizationConfig["loc_ItemName_93"] =
{
	zh = "宠物小黄",
	en = "Puppy",
	zht = "寵物小黃",
}
LocalizationConfig["loc_ItemName_94"] =
{
	zh = "女王皇冠",
	en = "Queen Crown",
	zht = "女王皇冠",
}
LocalizationConfig["loc_ItemName_95"] =
{
	zh = "女王手套",
	en = "Queen Glove",
	zht = "女王手套",
}
LocalizationConfig["loc_ItemName_96"] =
{
	zh = "能量饮料",
	en = "Red Taurus",
	zht = "能量飲料",
}
LocalizationConfig["loc_ItemName_97"] =
{
	zh = "便携平板",
	en = "Tablet",
	zht = "便攜平板",
}
LocalizationConfig["loc_ItemName_98"] =
{
	zh = "神笔",
	en = "Magicbrush",
	zht = "神筆",
}
LocalizationConfig["loc_ItemName_99"] =
{
	zh = "彩虹墨水",
	en = "Rainbow Ink",
	zht = "彩虹墨水",
}
LocalizationConfig["loc_ItemName_100"] =
{
	zh = "万能键盘",
	en = "Keyboard",
	zht = "萬能鍵盤",
}
LocalizationConfig["loc_ItemName_101"] =
{
	zh = "随身音响",
	en = "Boombox",
	zht = "隨身音響",
}
LocalizationConfig["loc_ItemName_102"] =
{
	zh = "猫耳",
	en = "Cat Ears",
	zht = "貓耳",
}
LocalizationConfig["loc_ItemName_103"] =
{
	zh = "合金匕首",
	en = "Dagger",
	zht = "合金匕首",
}
LocalizationConfig["loc_ItemName_104"] =
{
	zh = "钱袋",
	en = "Gold Pouch",
	zht = "錢袋",
}
LocalizationConfig["loc_ItemName_105"] =
{
	zh = "雷霆小锤",
	en = "Thor Hammer",
	zht = "雷霆小錘",
}
LocalizationConfig["loc_ItemName_106"] =
{
	zh = "轻便肩甲",
	en = "Light Pads",
	zht = "輕便肩甲",
}
LocalizationConfig["loc_ItemName_107"] =
{
	zh = "十级背包",
	en = "Lv.10 Bag",
	zht = "十級背包",
}
LocalizationConfig["loc_ItemName_108"] =
{
	zh = "隐身药水",
	en = "Cloaking Potion",
	zht = "隱身藥水",
}
LocalizationConfig["loc_ItemName_109"] =
{
	zh = "主线剧本",
	en = "Script",
	zht = "主線劇本",
}
LocalizationConfig["loc_ItemName_110"] =
{
	zh = "主播话筒",
	en = "Microphone",
	zht = "主播話筒",
}
LocalizationConfig["loc_ItemName_111"] =
{
	zh = "安全头盔",
	en = "Helmet",
	zht = "安全頭盔",
}
LocalizationConfig["loc_ItemName_112"] =
{
	zh = "篮球鞋",
	en = "Basketball Shoes",
	zht = "籃球鞋",
}
LocalizationConfig["loc_ItemName_113"] =
{
	zh = "异世界相机",
	en = "Camera",
	zht = "異世界相機",
}
LocalizationConfig["loc_ItemName_114"] =
{
	zh = "骨头",
	en = "Bone",
	zht = "骨頭",
}
LocalizationConfig["loc_ItemName_115"] =
{
	zh = "遥控器",
	en = "Remote",
	zht = "遙控器",
}
LocalizationConfig["loc_ItemName_116"] =
{
	zh = "黄金左轮",
	en = "Revolver",
	zht = "黃金左輪",
}
LocalizationConfig["loc_ItemName_117"] =
{
	zh = "牛仔帽",
	en = "Cowboy Hat",
	zht = "牛仔帽",
}
LocalizationConfig["loc_ItemName_118"] =
{
	zh = "迷你钢板",
	en = "Mini Plate",
	zht = "迷你鋼板",
}
LocalizationConfig["loc_ItemName_119"] =
{
	zh = "旋转长枪",
	en = "Lance",
	zht = "旋轉長槍",
}
LocalizationConfig["loc_ItemName_120"] =
{
	zh = "魔法盾牌",
	en = "Mg Shield",
	zht = "魔法盾牌",
}
LocalizationConfig["loc_ItemName_121"] =
{
	zh = "伸缩皮带",
	en = "Belt",
	zht = "伸縮皮帶",
}
LocalizationConfig["loc_ItemName_122"] =
{
	zh = "变身披风",
	en = "Cloak",
	zht = "變身披風",
}
LocalizationConfig["loc_ItemName_123"] =
{
	zh = "迷你翅膀",
	en = "Mini Wing",
	zht = "迷你翅膀",
}
LocalizationConfig["loc_ItemName_124"] =
{
	zh = "龙角飞镖",
	en = "Horn Dart",
	zht = "龍角飛鏢",
}
LocalizationConfig["loc_ItemName_125"] =
{
	zh = "龙爪手套",
	en = "Claw Glove",
	zht = "龍爪手套",
}
LocalizationConfig["loc_ItemName_126"] =
{
	zh = "方糖",
	en = "Sugar Cube",
	zht = "方糖",
}
LocalizationConfig["loc_ItemName_127"] =
{
	zh = "奶昔",
	en = "Milkshake",
	zht = "奶昔",
}
LocalizationConfig["loc_ItemName_128"] =
{
	zh = "香草粉",
	en = "Vanilla",
	zht = "香草粉",
}
LocalizationConfig["loc_ItemName_129"] =
{
	zh = "甜酒",
	en = "Liqueur",
	zht = "甜酒",
}
LocalizationConfig["loc_ItemName_130"] =
{
	zh = "体重秤",
	en = "Scales",
	zht = "體重秤",
}
LocalizationConfig["loc_ItemName_131"] =
{
	zh = "肉桂粉",
	en = "Cinnamon",
	zht = "肉桂粉",
}
LocalizationConfig["loc_ItemName_132"] =
{
	zh = "布丁",
	en = "Pudding",
	zht = "布丁",
}
LocalizationConfig["loc_ItemName_133"] =
{
	zh = "开心果",
	en = "Pistachio",
	zht = "開心果",
}
LocalizationConfig["loc_ItemName_134"] =
{
	zh = "果胶",
	en = "Pectin",
	zht = "果膠",
}
LocalizationConfig["loc_ItemName_135"] =
{
	zh = "芝士块",
	en = "Cheese",
	zht = "芝士塊",
}
LocalizationConfig["loc_ItemName_136"] =
{
	zh = "黄油",
	en = "Butter",
	zht = "黃油",
}
LocalizationConfig["loc_ItemName_137"] =
{
	zh = "香肠",
	en = "Sausage",
	zht = "香腸",
}
LocalizationConfig["loc_ItemName_138"] =
{
	zh = "白巧克力",
	en = "White Choc",
	zht = "白巧克力",
}
LocalizationConfig["loc_ItemName_139"] =
{
	zh = "黑巧克力",
	en = "Dark Choc",
	zht = "黑巧克力",
}
LocalizationConfig["loc_ItemName_140"] =
{
	zh = "可可粉",
	en = "Coco",
	zht = "可哥粉",
}
LocalizationConfig["loc_ItemName_141"] =
{
	zh = "榛子",
	en = "Hazelnut",
	zht = "榛子",
}
LocalizationConfig["loc_ItemName_142"] =
{
	zh = "奶油",
	en = "Cream",
	zht = "奶油",
}
LocalizationConfig["loc_ItemName_143"] =
{
	zh = "核桃",
	en = "Walnut",
	zht = "核桃",
}
LocalizationConfig["loc_ItemName_144"] =
{
	zh = "腰果",
	en = "Cashew",
	zht = "腰果",
}
LocalizationConfig["loc_ItemName_145"] =
{
	zh = "沙拉酱",
	en = "Salad Dressing",
	zht = "沙拉醬",
}
LocalizationConfig["loc_ItemName_146"] =
{
	zh = "面粉",
	en = "Flour",
	zht = "麵粉",
}
LocalizationConfig["loc_ItemName_147"] =
{
	zh = "糖浆",
	en = "Syrup",
	zht = "糖漿",
}
LocalizationConfig["loc_ItemName_148"] =
{
	zh = "烤肉粉",
	en = "Barbeque Powder",
	zht = "烤肉粉",
}
LocalizationConfig["loc_ItemName_149"] =
{
	zh = "糖纸",
	en = "Wrapper",
	zht = "糖紙",
}
LocalizationConfig["loc_ItemName_150"] =
{
	zh = "旋转吸管",
	en = "Curlystraw",
	zht = "旋轉吸管",
}
LocalizationConfig["loc_ItemName_151"] =
{
	zh = "翠绿披风",
	en = "Jade Cloak",
	zht = "翠綠披風",
}
LocalizationConfig["loc_ItemName_152"] =
{
	zh = "粗长吸管",
	en = "Thickstraw",
	zht = "粗長吸管",
}
LocalizationConfig["loc_ItemName_153"] =
{
	zh = "冰晶皇冠",
	en = "Ice Crown",
	zht = "冰晶皇冠",
}
LocalizationConfig["loc_ItemName_154"] =
{
	zh = "高礼帽",
	en = "Top Hat",
	zht = "高禮帽",
}
LocalizationConfig["loc_ItemName_155"] =
{
	zh = "围裙",
	en = "Apron",
	zht = "圍裙",
}
LocalizationConfig["loc_ItemName_156"] =
{
	zh = "小番茄",
	en = "Tomato",
	zht = "小番茄",
}
LocalizationConfig["loc_ItemName_157"] =
{
	zh = "糖球",
	en = "Gobstopper",
	zht = "糖球",
}
LocalizationConfig["loc_ItemName_158"] =
{
	zh = "卷发棒",
	en = "Curlers",
	zht = "卷髮棒",
}
LocalizationConfig["loc_ItemName_159"] =
{
	zh = "遮阳帽",
	en = "Sun Hat",
	zht = "遮陽帽",
}
LocalizationConfig["loc_ItemName_160"] =
{
	zh = "黑色披风",
	en = "Black Cape",
	zht = "黑色披風",
}
LocalizationConfig["loc_ItemName_161"] =
{
	zh = "叉子",
	en = "Fork",
	zht = "叉子",
}
LocalizationConfig["loc_ItemName_162"] =
{
	zh = "芝麻酱",
	en = "Sesame Sauce",
	zht = "芝麻醬",
}
LocalizationConfig["loc_ItemName_163"] =
{
	zh = "鸡翅",
	en = "Chicken Wing",
	zht = "雞翅",
}
LocalizationConfig["loc_ItemName_164"] =
{
	zh = "三角脆片",
	en = "Tortilla",
	zht = "三角脆片",
}
LocalizationConfig["loc_ItemName_165"] =
{
	zh = "生菜",
	en = "Lettuce",
	zht = "生菜",
}
LocalizationConfig["loc_ItemName_166"] =
{
	zh = "黄芥末",
	en = "Mustard",
	zht = "黃芥末",
}
LocalizationConfig["loc_ItemName_167"] =
{
	zh = "折弯吸管",
	en = "Straw",
	zht = "折彎吸管",
}
LocalizationConfig["loc_ItemName_168"] =
{
	zh = "血红披风",
	en = "Red Cape",
	zht = "血紅披風",
}
LocalizationConfig["loc_ItemName_169"] =
{
	zh = "核子瓶盖",
	en = "Bottlecap",
	zht = "核子瓶蓋",
}
LocalizationConfig["loc_ItemName_170"] =
{
	zh = "苹果",
	en = "Apple",
	zht = "蘋果",
}
LocalizationConfig["loc_ItemName_171"] =
{
	zh = "公主领结",
	en = "Bow",
	zht = "公主領結",
}
LocalizationConfig["loc_ItemName_172"] =
{
	zh = "草莓",
	en = "Strawberry",
	zht = "草莓",
}
LocalizationConfig["loc_ItemName_173"] =
{
	zh = "搅拌机",
	en = "Mixer",
	zht = "攪拌機",
}
LocalizationConfig["loc_ItemName_174"] =
{
	zh = "栗子",
	en = "Chestnut",
	zht = "栗子",
}
LocalizationConfig["loc_ItemName_175"] =
{
	zh = "吹风机",
	en = "Blow dryer",
	zht = "吹風機",
}
LocalizationConfig["loc_ItemName_176"] =
{
	zh = "瞌睡帽",
	en = "Night Cap",
	zht = "瞌睡帽",
}
LocalizationConfig["loc_ItemName_177"] =
{
	zh = "咖啡豆",
	en = "Coffee Bean",
	zht = "咖啡豆",
}
LocalizationConfig["loc_ItemName_178"] =
{
	zh = "开瓶器",
	en = "Bottle Opener",
	zht = "開瓶器",
}
LocalizationConfig["loc_ItemName_179"] =
{
	zh = "冰镇酒杯",
	en = "Cool Glass",
	zht = "冰鎮酒杯",
}
LocalizationConfig["loc_ItemName_180"] =
{
	zh = "随身镜",
	en = "Mirror",
	zht = "隨身鏡",
}
LocalizationConfig["loc_ItemName_181"] =
{
	zh = "草帽",
	en = "Straw Hat",
	zht = "草帽",
}
LocalizationConfig["loc_ItemName_182"] =
{
	zh = "围脖",
	en = "Muffler",
	zht = "圍脖",
}
LocalizationConfig["loc_ItemName_183"] =
{
	zh = "星星棒",
	en = "Star Wand",
	zht = "星星棒",
}
LocalizationConfig["loc_ItemName_184"] =
{
	zh = "玉米",
	en = "Corn",
	zht = "玉米",
}
LocalizationConfig["loc_ItemName_185"] =
{
	zh = "焦糖",
	en = "Toffee",
	zht = "焦糖",
}
LocalizationConfig["loc_ItemName_186"] =
{
	zh = "爆米花盒子",
	en = "Popcorn Box",
	zht = "爆米花盒子",
}
LocalizationConfig["loc_ItemName_187"] =
{
	zh = "项圈",
	en = "Collar",
	zht = "項圈",
}
LocalizationConfig["loc_ItemName_188"] =
{
	zh = "蜂蜜",
	en = "Honey",
	zht = "蜂蜜",
}
LocalizationConfig["loc_ItemName_189"] =
{
	zh = "鸡蛋",
	en = "Egg",
	zht = "雞蛋",
}
LocalizationConfig["loc_ItemName_190"] =
{
	zh = "牛奶",
	en = "Milk",
	zht = "牛奶",
}
LocalizationConfig["loc_ItemName_191"] =
{
	zh = "肉饼",
	en = "Burger",
	zht = "肉餅",
}
LocalizationConfig["loc_ItemName_192"] =
{
	zh = "芝士片",
	en = "Cheese Slice",
	zht = "芝士片",
}
LocalizationConfig["loc_ItemName_193"] =
{
	zh = "土豆",
	en = "Potato",
	zht = "土豆",
}
LocalizationConfig["loc_ItemName_194"] =
{
	zh = "健身背心",
	en = "Vest",
	zht = "健身背心",
}
LocalizationConfig["loc_ItemName_195"] =
{
	zh = "皇冠",
	en = "Crown",
	zht = "皇冠",
}
LocalizationConfig["loc_ItemName_196"] =
{
	zh = "摄像头",
	en = "CCTV Cam",
	zht = "攝像頭",
}
LocalizationConfig["loc_ItemName_197"] =
{
	zh = "讲解耳机",
	en = "Guide Earpiece",
	zht = "講解耳機",
}
LocalizationConfig["loc_ItemName_198"] =
{
	zh = "说明卡",
	en = "Explanation Card",
	zht = "說明卡",
}
LocalizationConfig["loc_ItemName_199"] =
{
	zh = "小铲子",
	en = "Spade",
	zht = "小鏟子",
}
LocalizationConfig["loc_ItemName_200"] =
{
	zh = "瓷器碎片",
	en = "Pottery Shard",
	zht = "瓷器碎片",
}
LocalizationConfig["loc_ItemName_201"] =
{
	zh = "警报器",
	en = "Alarm",
	zht = "警報器",
}
LocalizationConfig["loc_ItemName_202"] =
{
	zh = "复活宝石",
	en = "Heart",
	zht = "復活寶石",
}
LocalizationConfig["loc_ItemName_203"] =
{
	zh = "封条",
	en = "Seal",
	zht = "封條",
}
LocalizationConfig["loc_ItemName_204"] =
{
	zh = "扫把",
	en = "Broom",
	zht = "掃把",
}
LocalizationConfig["loc_ItemName_205"] =
{
	zh = "红外线勘探器",
	en = "IR Detector",
	zht = "紅外線勘探器",
}
LocalizationConfig["loc_ItemName_206"] =
{
	zh = "画框",
	en = "Frame",
	zht = "畫框",
}
LocalizationConfig["loc_ItemName_207"] =
{
	zh = "警示带",
	en = "Stanchion",
	zht = "警示帶",
}
LocalizationConfig["loc_ItemName_208"] =
{
	zh = "导览图",
	en = "Guide Map",
	zht = "導覽圖",
}
LocalizationConfig["loc_ItemName_209"] =
{
	zh = "盆栽",
	en = "Planter",
	zht = "盆栽",
}
LocalizationConfig["loc_ItemName_210"] =
{
	zh = "古钱",
	en = "Ancient Coin",
	zht = "古錢",
}
LocalizationConfig["loc_ItemName_211"] =
{
	zh = "小碗",
	en = "Bowl",
	zht = "小碗",
}
LocalizationConfig["loc_ItemName_212"] =
{
	zh = "保险箱",
	en = "Safe",
	zht = "保險箱",
}
LocalizationConfig["loc_ItemName_213"] =
{
	zh = "灭火器",
	en = "Extinguisher",
	zht = "滅火器",
}
LocalizationConfig["loc_ItemName_214"] =
{
	zh = "门票",
	en = "Ticket",
	zht = "門票",
}
LocalizationConfig["loc_ItemName_215"] =
{
	zh = "冰箱贴",
	en = "Fridge Magnet",
	zht = "冰箱貼",
}
LocalizationConfig["loc_ItemName_216"] =
{
	zh = "对讲机",
	en = "Walkie Talkie",
	zht = "對講機",
}
LocalizationConfig["loc_ItemName_217"] =
{
	zh = "鼻涕泡",
	en = "Snot Bubble",
	zht = "鼻涕泡",
}
LocalizationConfig["loc_ItemName_218"] =
{
	zh = "绿色布包",
	en = "Green Bag",
	zht = "綠色布包",
}
LocalizationConfig["loc_ItemName_219"] =
{
	zh = "大头手杖",
	en = "Pharaoh Scepter",
	zht = "大頭手杖",
}
LocalizationConfig["loc_ItemName_220"] =
{
	zh = "蓝色宝石",
	en = "Blue Gem",
	zht = "藍色寶石",
}
LocalizationConfig["loc_ItemName_221"] =
{
	zh = "藏宝图",
	en = "Treasure Map",
	zht = "藏寶圖",
}
LocalizationConfig["loc_ItemName_222"] =
{
	zh = "微笑",
	en = "Smiley",
	zht = "微笑",
}
LocalizationConfig["loc_ItemName_223"] =
{
	zh = "头纱",
	en = "Veil",
	zht = "頭紗",
}
LocalizationConfig["loc_ItemName_224"] =
{
	zh = "达芬奇的信",
	en = "Da Vinci Letter",
	zht = "達芬奇的信",
}
LocalizationConfig["loc_ItemName_225"] =
{
	zh = "魔术帽",
	en = "Magic Hat",
	zht = "魔術帽",
}
LocalizationConfig["loc_ItemName_226"] =
{
	zh = "玫瑰花",
	en = "Rose",
	zht = "玫瑰花",
}
LocalizationConfig["loc_ItemName_227"] =
{
	zh = "预告信",
	en = "Warning Letter",
	zht = "預告信",
}
LocalizationConfig["loc_ItemName_228"] =
{
	zh = "独眼镜片",
	en = "Monocle",
	zht = "獨眼鏡片",
}
LocalizationConfig["loc_ItemName_229"] =
{
	zh = "折弯手杖",
	en = "Bent Cane",
	zht = "折彎手杖",
}
LocalizationConfig["loc_ItemName_230"] =
{
	zh = "小方帽",
	en = "Square Cap",
	zht = "小方帽",
}
LocalizationConfig["loc_ItemName_231"] =
{
	zh = "蓝色布包",
	en = "Blue Bag",
	zht = "藍色布包",
}
LocalizationConfig["loc_ItemName_232"] =
{
	zh = "装饰刀",
	en = "Decorative Sword",
	zht = "裝飾刀",
}
LocalizationConfig["loc_ItemName_233"] =
{
	zh = "头盔",
	en = "Kabuto",
	zht = "頭盔",
}
LocalizationConfig["loc_ItemName_234"] =
{
	zh = "绳结",
	en = "Knot",
	zht = "繩結",
}
LocalizationConfig["loc_ItemName_235"] =
{
	zh = "迷你手刀",
	en = "Mini Knife",
	zht = "迷你手刀",
}
LocalizationConfig["loc_ItemName_236"] =
{
	zh = "方盒耳朵",
	en = "Box Ears",
	zht = "方盒耳朵",
}
LocalizationConfig["loc_ItemName_237"] =
{
	zh = "短小手杖",
	en = "Ankh",
	zht = "短小手杖",
}
LocalizationConfig["loc_ItemName_238"] =
{
	zh = "黄金帽子",
	en = "Gold Hat",
	zht = "黃金帽子",
}
LocalizationConfig["loc_ItemName_239"] =
{
	zh = "绷带",
	en = "Bandage",
	zht = "繃帶",
}
LocalizationConfig["loc_ItemName_240"] =
{
	zh = "防腐剂",
	en = "Preservative",
	zht = "防腐劑",
}
LocalizationConfig["loc_ItemName_241"] =
{
	zh = "向日葵",
	en = "Sunflower",
	zht = "向日葵",
}
LocalizationConfig["loc_ItemName_242"] =
{
	zh = "星空",
	en = "Starry Night",
	zht = "星空",
}
LocalizationConfig["loc_ItemName_243"] =
{
	zh = "耳朵",
	en = "Ear",
	zht = "耳朵",
}
LocalizationConfig["loc_ItemName_244"] =
{
	zh = "珍珠耳环",
	en = "Pearl Earring",
	zht = "珍珠耳環",
}
LocalizationConfig["loc_ItemName_245"] =
{
	zh = "头巾",
	en = "Turban",
	zht = "頭巾",
}
LocalizationConfig["loc_ItemName_246"] =
{
	zh = "乐谱",
	en = "Sheet Music",
	zht = "樂譜",
}
LocalizationConfig["loc_ItemName_247"] =
{
	zh = "黑长衫",
	en = "Black Shirt",
	zht = "黑長衫",
}
LocalizationConfig["loc_ItemName_248"] =
{
	zh = "酱油",
	en = "Soy Sauce",
	zht = "醬油",
}
LocalizationConfig["loc_ItemName_249"] =
{
	zh = "皇家印章",
	en = "Royal Seal",
	zht = "皇家印章",
}
LocalizationConfig["loc_ItemName_250"] =
{
	zh = "肋骨",
	en = "Rib Bone",
	zht = "肋骨",
}
LocalizationConfig["loc_ItemName_251"] =
{
	zh = "石头手杖",
	en = "Stone Rod",
	zht = "石頭手杖",
}
LocalizationConfig["loc_ItemName_252"] =
{
	zh = "化石项链",
	en = "Fossil",
	zht = "化石項鍊",
}
LocalizationConfig["loc_ItemName_253"] =
{
	zh = "化石肉腿",
	en = "Ham Fossil",
	zht = "化石肉腿",
}
LocalizationConfig["loc_ItemName_254"] =
{
	zh = "鲜花头饰",
	en = "Flower Headwear",
	zht = "鮮花頭飾",
}
LocalizationConfig["loc_ItemName_255"] =
{
	zh = "超粗眉笔",
	en = "Eyebrow Pencil",
	zht = "超粗眉筆",
}
LocalizationConfig["loc_ItemName_256"] =
{
	zh = "徽章",
	en = "Medal",
	zht = "徽章",
}
LocalizationConfig["loc_ItemName_257"] =
{
	zh = "火枪",
	en = "Flintlock",
	zht = "火槍",
}
LocalizationConfig["loc_ItemName_258"] =
{
	zh = "二角帽",
	en = "Bicorne",
	zht = "二角帽",
}
LocalizationConfig["loc_ItemName_259"] =
{
	zh = "内增高鞋垫",
	en = "Shoe Insoles",
	zht = "內增高鞋墊",
}
LocalizationConfig["loc_ItemName_260"] =
{
	zh = "铅笔",
	en = "Pencil",
	zht = "鉛筆",
}
LocalizationConfig["loc_ItemName_261"] =
{
	zh = "胶带",
	en = "Tape",
	zht = "膠帶",
}
LocalizationConfig["loc_ItemName_262"] =
{
	zh = "头发",
	en = "Hair",
	zht = "頭髮",
}
LocalizationConfig["loc_ItemName_263"] =
{
	zh = "菜刀",
	en = "Veggie Knife",
	zht = "菜刀",
}
LocalizationConfig["loc_ItemName_264"] =
{
	zh = "指纹",
	en = "Fingerprint",
	zht = "指紋",
}
LocalizationConfig["loc_ItemName_265"] =
{
	zh = "照片",
	en = "Photo",
	zht = "照片",
}
LocalizationConfig["loc_ItemName_266"] =
{
	zh = "火柴",
	en = "Match",
	zht = "火柴",
}
LocalizationConfig["loc_ItemName_267"] =
{
	zh = "钢丝",
	en = "Wire",
	zht = "鋼絲",
}
LocalizationConfig["loc_ItemName_268"] =
{
	zh = "指甲",
	en = "Fingernail",
	zht = "指甲",
}
LocalizationConfig["loc_ItemName_269"] =
{
	zh = "镜子",
	en = "Mirror",
	zht = "鏡子",
}
LocalizationConfig["loc_ItemName_270"] =
{
	zh = "脚印",
	en = "Footprint",
	zht = "腳印",
}
LocalizationConfig["loc_ItemName_271"] =
{
	zh = "面具",
	en = "Mask",
	zht = "面具",
}
LocalizationConfig["loc_ItemName_272"] =
{
	zh = "烟头",
	en = "Butt",
	zht = "煙頭",
}
LocalizationConfig["loc_ItemName_273"] =
{
	zh = "笔记本",
	en = "Notepad",
	zht = "筆記本",
}
LocalizationConfig["loc_ItemName_274"] =
{
	zh = "硬币",
	en = "Coin",
	zht = "硬幣",
}
LocalizationConfig["loc_ItemName_275"] =
{
	zh = "小飞镖",
	en = "Dart",
	zht = "小飛鏢",
}
LocalizationConfig["loc_ItemName_276"] =
{
	zh = "放大镜",
	en = "Magnifying Lens",
	zht = "放大鏡",
}
LocalizationConfig["loc_ItemName_277"] =
{
	zh = "刻痕胶带",
	en = "Marked Tape",
	zht = "刻痕膠帶",
}
LocalizationConfig["loc_ItemName_278"] =
{
	zh = "手表",
	en = "Watch",
	zht = "手錶",
}
LocalizationConfig["loc_ItemName_279"] =
{
	zh = "钓鱼线",
	en = "Fishing Line",
	zht = "釣魚線",
}
LocalizationConfig["loc_ItemName_280"] =
{
	zh = "三文鱼干",
	en = "Dried Salmon",
	zht = "三文魚幹",
}
LocalizationConfig["loc_ItemName_281"] =
{
	zh = "直通电话",
	en = "Phone",
	zht = "直通電話",
}
LocalizationConfig["loc_ItemName_282"] =
{
	zh = "便携游戏机",
	en = "Video Game",
	zht = "便攜遊戲機",
}
LocalizationConfig["loc_ItemName_283"] =
{
	zh = "一发倒地枪",
	en = "Stun Gun",
	zht = "一發倒地槍",
}
LocalizationConfig["loc_ItemName_284"] =
{
	zh = "警官证",
	en = "Police ID",
	zht = "警官證",
}
LocalizationConfig["loc_ItemName_285"] =
{
	zh = "手环",
	en = "Cuffs",
	zht = "手環",
}
LocalizationConfig["loc_ItemName_286"] =
{
	zh = "拐杖",
	en = "Walking Stick",
	zht = "拐杖",
}
LocalizationConfig["loc_ItemName_287"] =
{
	zh = "玩具枪",
	en = "Toy Gun",
	zht = "玩具槍",
}
LocalizationConfig["loc_ItemName_288"] =
{
	zh = "烟盒",
	en = "Cig Pack",
	zht = "煙盒",
}
LocalizationConfig["loc_ItemName_289"] =
{
	zh = "贝雷帽",
	en = "Beret",
	zht = "貝雷帽",
}
LocalizationConfig["loc_ItemName_290"] =
{
	zh = "5000度眼镜",
	en = "Thick Glasses",
	zht = "5000度眼鏡",
}
LocalizationConfig["loc_ItemName_291"] =
{
	zh = "手术刀",
	en = "Scalpel",
	zht = "手術刀",
}
LocalizationConfig["loc_ItemName_292"] =
{
	zh = "手术锤",
	en = "Hammer",
	zht = "手術錘",
}
LocalizationConfig["loc_ItemName_293"] =
{
	zh = "烟斗",
	en = "Pipe",
	zht = "煙斗",
}
LocalizationConfig["loc_ItemName_294"] =
{
	zh = "鸭舌帽",
	en = "Duck Cap",
	zht = "鴨舌帽",
}
LocalizationConfig["loc_ItemName_295"] =
{
	zh = "小提琴",
	en = "Violin",
	zht = "小提琴",
}
LocalizationConfig["loc_ItemName_296"] =
{
	zh = "锥形瓶",
	en = "Conical Flask",
	zht = "錐形瓶",
}
LocalizationConfig["loc_ItemName_297"] =
{
	zh = "黑色长柄伞",
	en = "Black Umbrella",
	zht = "黑色長柄傘",
}
LocalizationConfig["loc_ItemName_298"] =
{
	zh = "头戴监视器",
	en = "Head Monitor",
	zht = "頭戴監視器",
}
LocalizationConfig["loc_ItemName_299"] =
{
	zh = "真相",
	en = "Truth",
	zht = "真相",
}
LocalizationConfig["loc_ItemName_300"] =
{
	zh = "瞌睡针",
	en = "Needle",
	zht = "瞌睡針",
}
LocalizationConfig["loc_ItemName_301"] =
{
	zh = "强力球鞋",
	en = "Sneakers",
	zht = "強力球鞋",
}
LocalizationConfig["loc_ItemName_302"] =
{
	zh = "紧身皮衣",
	en = "Jacket",
	zht = "緊身皮衣",
}
LocalizationConfig["loc_ItemName_303"] =
{
	zh = "审判之锤",
	en = "Gavel",
	zht = "審判之錘",
}
LocalizationConfig["loc_ItemName_304"] =
{
	zh = "关键道具",
	en = "Key Item",
	zht = "關鍵道具",
}
LocalizationConfig["loc_ItemName_305"] =
{
	zh = "橡皮膏",
	en = "Plaster",
	zht = "橡皮膏",
}
LocalizationConfig["loc_ItemName_306"] =
{
	zh = "隐身披风",
	en = "Invisible Cloak",
	zht = "隱身披風",
}
LocalizationConfig["loc_ItemName_307"] =
{
	zh = "围巾",
	en = "Scarf",
	zht = "圍巾",
}
LocalizationConfig["loc_ItemName_308"] =
{
	zh = "不在场证明",
	en = "Absence Proof",
	zht = "不在場證明",
}
LocalizationConfig["loc_ItemName_309"] =
{
	zh = "吊水瓶",
	en = "IV Drip",
	zht = "吊水瓶",
}
LocalizationConfig["loc_ItemName_310"] =
{
	zh = "换装面具",
	en = "Face Changer",
	zht = "換裝面具",
}
LocalizationConfig["loc_ItemName_311"] =
{
	zh = "夜视眼镜",
	en = "Night Vision",
	zht = "夜視眼鏡",
}
LocalizationConfig["loc_ItemName_312"] =
{
	zh = "假象",
	en = "Illusion",
	zht = "假像",
}
LocalizationConfig["loc_ItemName_313"] =
{
	zh = "最后一封信",
	en = "Last Letter",
	zht = "最後一封信",
}
LocalizationConfig["loc_ItemName_314"] =
{
	zh = "六库全书",
	en = "Law Book",
	zht = "六庫全書",
}
LocalizationConfig["loc_ItemName_315"] =
{
	zh = "毛线球",
	en = "Wool",
	zht = "毛線球",
}
LocalizationConfig["loc_ItemName_316"] =
{
	zh = "美味咖啡",
	en = "Coffee",
	zht = "美味咖啡",
}
LocalizationConfig["loc_ItemName_317"] =
{
	zh = "正义",
	en = "Justice",
	zht = "正義",
}
LocalizationConfig["loc_ItemName_318"] =
{
	zh = "发胶",
	en = "Hair Gel",
	zht = "髮膠",
}
LocalizationConfig["loc_ItemName_319"] =
{
	zh = "国际象棋",
	en = "Chess",
	zht = "國際象棋",
}
LocalizationConfig["loc_ItemName_320"] =
{
	zh = "调酒杯",
	en = "Shaker",
	zht = "調酒杯",
}
LocalizationConfig["loc_ItemName_321"] =
{
	zh = "万能扳手",
	en = "Spanner",
	zht = "萬能扳手",
}
LocalizationConfig["loc_ItemName_322"] =
{
	zh = "黑色长鞭",
	en = "Black Whip",
	zht = "黑色長鞭",
}
LocalizationConfig["loc_ItemDes_1"] =
{
	zh = "坚硬的小晶石，刻着有点模糊的图案，在实验室中可以发挥作用的样子",
	en = "A small, solid crystal with an unclear picture etched into it. It seems to have some kinda use in the Lab",
	zht = "堅硬的小晶石，刻著有點模糊的圖案，在實驗室中可以發揮作用的樣子",
}
LocalizationConfig["loc_ItemDes_2"] =
{
	zh = "坚硬的小晶石，刻着有点模糊的图案，在实验室中可以发挥作用的样子",
	en = "A small, solid crystal with an unclear picture etched into it. It seems to have some kinda use in the Lab",
	zht = "堅硬的小晶石，刻著有點模糊的圖案，在實驗室中可以發揮作用的樣子",
}
LocalizationConfig["loc_ItemDes_3"] =
{
	zh = "坚硬的小晶石，刻着有点模糊的图案，在实验室中可以发挥作用的样子",
	en = "A small, solid crystal with an unclear picture etched into it. It seems to have some kinda use in the Lab",
	zht = "堅硬的小晶石，刻著有點模糊的圖案，在實驗室中可以發揮作用的樣子",
}
LocalizationConfig["loc_ItemDes_4"] =
{
	zh = "坚硬的小晶石，刻着有点模糊的图案，在实验室中可以发挥作用的样子",
	en = "A small, solid crystal with an unclear picture etched into it. It seems to have some kinda use in the Lab",
	zht = "堅硬的小晶石，刻著有點模糊的圖案，在實驗室中可以發揮作用的樣子",
}
LocalizationConfig["loc_ItemDes_5"] =
{
	zh = "坚硬的小晶石，刻着有点模糊的图案，在实验室中可以发挥作用的样子",
	en = "A small, solid crystal with an unclear picture etched into it. It seems to have some kinda use in the Lab",
	zht = "堅硬的小晶石，刻著有點模糊的圖案，在實驗室中可以發揮作用的樣子",
}
LocalizationConfig["loc_ItemDes_6"] =
{
	zh = "坚硬的小晶石，刻着有点模糊的图案，在实验室中可以发挥作用的样子",
	en = "A small, solid crystal with an unclear picture etched into it. It seems to have some kinda use in the Lab",
	zht = "堅硬的小晶石，刻著有點模糊的圖案，在實驗室中可以發揮作用的樣子",
}
LocalizationConfig["loc_ItemDes_7"] =
{
	zh = "坚硬的小晶石，刻着有点模糊的图案，在实验室中可以发挥作用的样子",
	en = "A small, solid crystal with an unclear picture etched into it. It seems to have some kinda use in the Lab",
	zht = "堅硬的小晶石，刻著有點模糊的圖案，在實驗室中可以發揮作用的樣子",
}
LocalizationConfig["loc_ItemDes_8"] =
{
	zh = "坚硬的小晶石，刻着有点模糊的图案，在实验室中可以发挥作用的样子",
	en = "A small, solid crystal with an unclear picture etched into it. It seems to have some kinda use in the Lab",
	zht = "堅硬的小晶石，刻著有點模糊的圖案，在實驗室中可以發揮作用的樣子",
}
LocalizationConfig["loc_ItemDes_9"] =
{
	zh = "坚硬的小晶石，刻着有点模糊的图案，在实验室中可以发挥作用的样子",
	en = "A small, solid crystal with an unclear picture etched into it. It seems to have some kinda use in the Lab",
	zht = "堅硬的小晶石，刻著有點模糊的圖案，在實驗室中可以發揮作用的樣子",
}
LocalizationConfig["loc_ItemDes_10"] =
{
	zh = "坚硬的小晶石，刻着有点模糊的图案，在实验室中可以发挥作用的样子",
	en = "A small, solid crystal with an unclear picture etched into it. It seems to have some kinda use in the Lab",
	zht = "堅硬的小晶石，刻著有點模糊的圖案，在實驗室中可以發揮作用的樣子",
}
LocalizationConfig["loc_ItemDes_11"] =
{
	zh = "坚硬的小晶石，刻着有点模糊的图案，在实验室中可以发挥作用的样子",
	en = "A small, solid crystal with an unclear picture etched into it. It seems to have some kinda use in the Lab",
	zht = "堅硬的小晶石，刻著有點模糊的圖案，在實驗室中可以發揮作用的樣子",
}
LocalizationConfig["loc_ItemDes_12"] =
{
	zh = "坚硬的小晶石，刻着有点模糊的图案，在实验室中可以发挥作用的样子",
	en = "A small, solid crystal with an unclear picture etched into it. It seems to have some kinda use in the Lab",
	zht = "堅硬的小晶石，刻著有點模糊的圖案，在實驗室中可以發揮作用的樣子",
}
LocalizationConfig["loc_ItemDes_13"] =
{
	zh = "坚硬的小晶石，刻着有点模糊的图案，在实验室中可以发挥作用的样子",
	en = "A small, solid crystal with an unclear picture etched into it. It seems to have some kinda use in the Lab",
	zht = "堅硬的小晶石，刻著有點模糊的圖案，在實驗室中可以發揮作用的樣子",
}
LocalizationConfig["loc_ItemDes_14"] =
{
	zh = "坚硬的小晶石，刻着有点模糊的图案，在实验室中可以发挥作用的样子",
	en = "A small, solid crystal with an unclear picture etched into it. It seems to have some kinda use in the Lab",
	zht = "堅硬的小晶石，刻著有點模糊的圖案，在實驗室中可以發揮作用的樣子",
}
LocalizationConfig["loc_ItemDes_15"] =
{
	zh = "坚硬的小晶石，刻着有点模糊的图案，在实验室中可以发挥作用的样子",
	en = "A small, solid crystal with an unclear picture etched into it. It seems to have some kinda use in the Lab",
	zht = "堅硬的小晶石，刻著有點模糊的圖案，在實驗室中可以發揮作用的樣子",
}
LocalizationConfig["loc_ItemDes_16"] =
{
	zh = "坚硬的小晶石，刻着有点模糊的图案，在实验室中可以发挥作用的样子",
	en = "A small, solid crystal with an unclear picture etched into it. It seems to have some kinda use in the Lab",
	zht = "堅硬的小晶石，刻著有點模糊的圖案，在實驗室中可以發揮作用的樣子",
}
LocalizationConfig["loc_ItemDes_17"] =
{
	zh = "通透的蓝色晶石，刻着有点模糊的图案，其中蕴藏的能量用来合成会发生什么呢",
	en = "A transparent blue crystal with an unclear drawing on it, what will happen if you use the power contained within it for synthesis?",
	zht = "通透的藍色晶石，刻著有點模糊的圖案，其中蘊藏的能量用來合成會發生什麼呢",
}
LocalizationConfig["loc_ItemDes_18"] =
{
	zh = "通透的蓝色晶石，刻着有点模糊的图案，其中蕴藏的能量用来合成会发生什么呢",
	en = "A transparent blue crystal with an unclear drawing on it, what will happen if you use the power contained within it for synthesis?",
	zht = "通透的藍色晶石，刻著有點模糊的圖案，其中蘊藏的能量用來合成會發生什麼呢",
}
LocalizationConfig["loc_ItemDes_19"] =
{
	zh = "通透的蓝色晶石，刻着有点模糊的图案，其中蕴藏的能量用来合成会发生什么呢",
	en = "A transparent blue crystal with an unclear drawing on it, what will happen if you use the power contained within it for synthesis?",
	zht = "通透的藍色晶石，刻著有點模糊的圖案，其中蘊藏的能量用來合成會發生什麼呢",
}
LocalizationConfig["loc_ItemDes_20"] =
{
	zh = "通透的蓝色晶石，刻着有点模糊的图案，其中蕴藏的能量用来合成会发生什么呢",
	en = "A transparent blue crystal with an unclear drawing on it, what will happen if you use the power contained within it for synthesis?",
	zht = "通透的藍色晶石，刻著有點模糊的圖案，其中蘊藏的能量用來合成會發生什麼呢",
}
LocalizationConfig["loc_ItemDes_21"] =
{
	zh = "通透的蓝色晶石，刻着有点模糊的图案，其中蕴藏的能量用来合成会发生什么呢",
	en = "A transparent blue crystal with an unclear drawing on it, what will happen if you use the power contained within it for synthesis?",
	zht = "通透的藍色晶石，刻著有點模糊的圖案，其中蘊藏的能量用來合成會發生什麼呢",
}
LocalizationConfig["loc_ItemDes_22"] =
{
	zh = "通透的蓝色晶石，刻着有点模糊的图案，其中蕴藏的能量用来合成会发生什么呢",
	en = "A transparent blue crystal with an unclear drawing on it, what will happen if you use the power contained within it for synthesis?",
	zht = "通透的藍色晶石，刻著有點模糊的圖案，其中蘊藏的能量用來合成會發生什麼呢",
}
LocalizationConfig["loc_ItemDes_23"] =
{
	zh = "通透的蓝色晶石，刻着有点模糊的图案，其中蕴藏的能量用来合成会发生什么呢",
	en = "A transparent blue crystal with an unclear drawing on it, what will happen if you use the power contained within it for synthesis?",
	zht = "通透的藍色晶石，刻著有點模糊的圖案，其中蘊藏的能量用來合成會發生什麼呢",
}
LocalizationConfig["loc_ItemDes_24"] =
{
	zh = "通透的蓝色晶石，刻着有点模糊的图案，其中蕴藏的能量用来合成会发生什么呢",
	en = "A transparent blue crystal with an unclear drawing on it, what will happen if you use the power contained within it for synthesis?",
	zht = "通透的藍色晶石，刻著有點模糊的圖案，其中蘊藏的能量用來合成會發生什麼呢",
}
LocalizationConfig["loc_ItemDes_25"] =
{
	zh = "通透的蓝色晶石，刻着有点模糊的图案，其中蕴藏的能量用来合成会发生什么呢",
	en = "A transparent blue crystal with an unclear drawing on it, what will happen if you use the power contained within it for synthesis?",
	zht = "通透的藍色晶石，刻著有點模糊的圖案，其中蘊藏的能量用來合成會發生什麼呢",
}
LocalizationConfig["loc_ItemDes_26"] =
{
	zh = "通透的蓝色晶石，刻着有点模糊的图案，其中蕴藏的能量用来合成会发生什么呢",
	en = "A transparent blue crystal with an unclear drawing on it, what will happen if you use the power contained within it for synthesis?",
	zht = "通透的藍色晶石，刻著有點模糊的圖案，其中蘊藏的能量用來合成會發生什麼呢",
}
LocalizationConfig["loc_ItemDes_27"] =
{
	zh = "通透的蓝色晶石，刻着有点模糊的图案，其中蕴藏的能量用来合成会发生什么呢",
	en = "A transparent blue crystal with an unclear drawing on it, what will happen if you use the power contained within it for synthesis?",
	zht = "通透的藍色晶石，刻著有點模糊的圖案，其中蘊藏的能量用來合成會發生什麼呢",
}
LocalizationConfig["loc_ItemDes_28"] =
{
	zh = "通透的蓝色晶石，刻着有点模糊的图案，其中蕴藏的能量用来合成会发生什么呢",
	en = "A transparent blue crystal with an unclear drawing on it, what will happen if you use the power contained within it for synthesis?",
	zht = "通透的藍色晶石，刻著有點模糊的圖案，其中蘊藏的能量用來合成會發生什麼呢",
}
LocalizationConfig["loc_ItemDes_29"] =
{
	zh = "通透的蓝色晶石，刻着有点模糊的图案，其中蕴藏的能量用来合成会发生什么呢",
	en = "A transparent blue crystal with an unclear drawing on it, what will happen if you use the power contained within it for synthesis?",
	zht = "通透的藍色晶石，刻著有點模糊的圖案，其中蘊藏的能量用來合成會發生什麼呢",
}
LocalizationConfig["loc_ItemDes_30"] =
{
	zh = "通透的蓝色晶石，刻着有点模糊的图案，其中蕴藏的能量用来合成会发生什么呢",
	en = "A transparent blue crystal with an unclear drawing on it, what will happen if you use the power contained within it for synthesis?",
	zht = "通透的藍色晶石，刻著有點模糊的圖案，其中蘊藏的能量用來合成會發生什麼呢",
}
LocalizationConfig["loc_ItemDes_31"] =
{
	zh = "通透的蓝色晶石，刻着有点模糊的图案，其中蕴藏的能量用来合成会发生什么呢",
	en = "A transparent blue crystal with an unclear drawing on it, what will happen if you use the power contained within it for synthesis?",
	zht = "通透的藍色晶石，刻著有點模糊的圖案，其中蘊藏的能量用來合成會發生什麼呢",
}
LocalizationConfig["loc_ItemDes_32"] =
{
	zh = "通透的蓝色晶石，刻着有点模糊的图案，其中蕴藏的能量用来合成会发生什么呢",
	en = "A transparent blue crystal with an unclear drawing on it, what will happen if you use the power contained within it for synthesis?",
	zht = "通透的藍色晶石，刻著有點模糊的圖案，其中蘊藏的能量用來合成會發生什麼呢",
}
LocalizationConfig["loc_ItemDes_33"] =
{
	zh = "发出紫色幽光的晶石，刻着有点模糊的图案，拿在手上就能感觉到一股未知的力量",
	en = "A crystal that emits a dim purple glow with an unclear drawing etched into it, from holding it in your hand you can feel a kind of unknown power.",
	zht = "發出紫色幽光的晶石，刻著有點模糊的圖案，拿在手上就能感覺到一股未知的力量",
}
LocalizationConfig["loc_ItemDes_34"] =
{
	zh = "发出紫色幽光的晶石，刻着有点模糊的图案，拿在手上就能感觉到一股未知的力量",
	en = "A crystal that emits a dim purple glow with an unclear drawing etched into it, from holding it in your hand you can feel a kind of unknown power.",
	zht = "發出紫色幽光的晶石，刻著有點模糊的圖案，拿在手上就能感覺到一股未知的力量",
}
LocalizationConfig["loc_ItemDes_35"] =
{
	zh = "发出紫色幽光的晶石，刻着有点模糊的图案，拿在手上就能感觉到一股未知的力量",
	en = "A crystal that emits a dim purple glow with an unclear drawing etched into it, from holding it in your hand you can feel a kind of unknown power.",
	zht = "發出紫色幽光的晶石，刻著有點模糊的圖案，拿在手上就能感覺到一股未知的力量",
}
LocalizationConfig["loc_ItemDes_36"] =
{
	zh = "发出紫色幽光的晶石，刻着有点模糊的图案，拿在手上就能感觉到一股未知的力量",
	en = "A crystal that emits a dim purple glow with an unclear drawing etched into it, from holding it in your hand you can feel a kind of unknown power.",
	zht = "發出紫色幽光的晶石，刻著有點模糊的圖案，拿在手上就能感覺到一股未知的力量",
}
LocalizationConfig["loc_ItemDes_37"] =
{
	zh = "发出紫色幽光的晶石，刻着有点模糊的图案，拿在手上就能感觉到一股未知的力量",
	en = "A crystal that emits a dim purple glow with an unclear drawing etched into it, from holding it in your hand you can feel a kind of unknown power.",
	zht = "發出紫色幽光的晶石，刻著有點模糊的圖案，拿在手上就能感覺到一股未知的力量",
}
LocalizationConfig["loc_ItemDes_38"] =
{
	zh = "发出紫色幽光的晶石，刻着有点模糊的图案，拿在手上就能感觉到一股未知的力量",
	en = "A crystal that emits a dim purple glow with an unclear drawing etched into it, from holding it in your hand you can feel a kind of unknown power.",
	zht = "發出紫色幽光的晶石，刻著有點模糊的圖案，拿在手上就能感覺到一股未知的力量",
}
LocalizationConfig["loc_ItemDes_39"] =
{
	zh = "发出紫色幽光的晶石，刻着有点模糊的图案，拿在手上就能感觉到一股未知的力量",
	en = "A crystal that emits a dim purple glow with an unclear drawing etched into it, from holding it in your hand you can feel a kind of unknown power.",
	zht = "發出紫色幽光的晶石，刻著有點模糊的圖案，拿在手上就能感覺到一股未知的力量",
}
LocalizationConfig["loc_ItemDes_40"] =
{
	zh = "发出紫色幽光的晶石，刻着有点模糊的图案，拿在手上就能感觉到一股未知的力量",
	en = "A crystal that emits a dim purple glow with an unclear drawing etched into it, from holding it in your hand you can feel a kind of unknown power.",
	zht = "發出紫色幽光的晶石，刻著有點模糊的圖案，拿在手上就能感覺到一股未知的力量",
}
LocalizationConfig["loc_ItemDes_41"] =
{
	zh = "发出紫色幽光的晶石，刻着有点模糊的图案，拿在手上就能感觉到一股未知的力量",
	en = "A crystal that emits a dim purple glow with an unclear drawing etched into it, from holding it in your hand you can feel a kind of unknown power.",
	zht = "發出紫色幽光的晶石，刻著有點模糊的圖案，拿在手上就能感覺到一股未知的力量",
}
LocalizationConfig["loc_ItemDes_42"] =
{
	zh = "发出紫色幽光的晶石，刻着有点模糊的图案，拿在手上就能感觉到一股未知的力量",
	en = "A crystal that emits a dim purple glow with an unclear drawing etched into it, from holding it in your hand you can feel a kind of unknown power.",
	zht = "發出紫色幽光的晶石，刻著有點模糊的圖案，拿在手上就能感覺到一股未知的力量",
}
LocalizationConfig["loc_ItemDes_43"] =
{
	zh = "发出紫色幽光的晶石，刻着有点模糊的图案，拿在手上就能感觉到一股未知的力量",
	en = "A crystal that emits a dim purple glow with an unclear drawing etched into it, from holding it in your hand you can feel a kind of unknown power.",
	zht = "發出紫色幽光的晶石，刻著有點模糊的圖案，拿在手上就能感覺到一股未知的力量",
}
LocalizationConfig["loc_ItemDes_44"] =
{
	zh = "发出紫色幽光的晶石，刻着有点模糊的图案，拿在手上就能感觉到一股未知的力量",
	en = "A crystal that emits a dim purple glow with an unclear drawing etched into it, from holding it in your hand you can feel a kind of unknown power.",
	zht = "發出紫色幽光的晶石，刻著有點模糊的圖案，拿在手上就能感覺到一股未知的力量",
}
LocalizationConfig["loc_ItemDes_45"] =
{
	zh = "发出紫色幽光的晶石，刻着有点模糊的图案，拿在手上就能感觉到一股未知的力量",
	en = "A crystal that emits a dim purple glow with an unclear drawing etched into it, from holding it in your hand you can feel a kind of unknown power.",
	zht = "發出紫色幽光的晶石，刻著有點模糊的圖案，拿在手上就能感覺到一股未知的力量",
}
LocalizationConfig["loc_ItemDes_46"] =
{
	zh = "发出紫色幽光的晶石，刻着有点模糊的图案，拿在手上就能感觉到一股未知的力量",
	en = "A crystal that emits a dim purple glow with an unclear drawing etched into it, from holding it in your hand you can feel a kind of unknown power.",
	zht = "發出紫色幽光的晶石，刻著有點模糊的圖案，拿在手上就能感覺到一股未知的力量",
}
LocalizationConfig["loc_ItemDes_47"] =
{
	zh = "发出紫色幽光的晶石，刻着有点模糊的图案，拿在手上就能感觉到一股未知的力量",
	en = "A crystal that emits a dim purple glow with an unclear drawing etched into it, from holding it in your hand you can feel a kind of unknown power.",
	zht = "發出紫色幽光的晶石，刻著有點模糊的圖案，拿在手上就能感覺到一股未知的力量",
}
LocalizationConfig["loc_ItemDes_48"] =
{
	zh = "发出紫色幽光的晶石，刻着有点模糊的图案，拿在手上就能感觉到一股未知的力量",
	en = "A crystal that emits a dim purple glow with an unclear drawing etched into it, from holding it in your hand you can feel a kind of unknown power.",
	zht = "發出紫色幽光的晶石，刻著有點模糊的圖案，拿在手上就能感覺到一股未知的力量",
}
LocalizationConfig["loc_ItemDes_49"] =
{
	zh = "体力是一切的基础。“活着才有输出”，是专家模式里某人的名言。",
	en = "HP is the basis of everything. 'You must be alive to do damage' is an often uttered mantra by players in expert mode",
	zht = "體力是一切的基礎。“活著才有輸出”，是專家模式裡某人的名言。",
}
LocalizationConfig["loc_ItemDes_50"] =
{
	zh = "看起来平淡无奇的药草，但是小心不要中毒了",
	en = "An unremarkable looking herb, but don't each too much, lest you accidentally poison yourself",
	zht = "看起來平淡無奇的藥草，但是小心不要中毒了",
}
LocalizationConfig["loc_ItemDes_51"] =
{
	zh = "看看攻略，看看密码，旅程突然变的轻松了起来",
	en = "Use it to read walkthroughs and check passwords, it'll make your adventure much easier",
	zht = "看看攻略，看看密碼，旅程突然變的輕鬆了起來",
}
LocalizationConfig["loc_ItemDes_52"] =
{
	zh = "为什么要接任务？“因为任务就在那里”",
	en = "Why do you accept the quest? 'Because it's there'",
	zht = "為什麼要接任務？“因為任務就在那裡”",
}
LocalizationConfig["loc_ItemDes_53"] =
{
	zh = "有魔法条，一切皆有可能，魔法条空了有时候比掉体力更可怕是没错",
	en = "When you have your MP Bar anything is possible, sometimes having an empty MP bar is worse than losing HP.",
	zht = "有魔法條，一切皆有可能，魔法條空了有時候比掉體力更可怕是沒錯",
}
LocalizationConfig["loc_ItemDes_54"] =
{
	zh = "进入迷宫探险的必备之物，平时都可以坚持很久",
	en = "A necessity for exploring labyrinths, they normally last a long time",
	zht = "進入迷宮探險的必備之物，平時都可以堅持很久",
}
LocalizationConfig["loc_ItemDes_55"] =
{
	zh = "一看就经过了历练的陨石碎片，识货的铁匠会喜欢",
	en = "A meteorite shard that has evidently been tempered, a blacksmith that knows his stuff will love it",
	zht = "一看就經過了歷練的隕石碎片，識貨的鐵匠會喜歡",
}
LocalizationConfig["loc_ItemDes_56"] =
{
	zh = "曾经没有路点，需求的人多了，也就有了这神秘光标",
	en = "Initially there weren't any waypoints, but due to overwhelming demand, these mysterious marks of light were added",
	zht = "曾經沒有路點，需求的人多了，也就有了這神秘游標",
}
LocalizationConfig["loc_ItemDes_57"] =
{
	zh = "想要让自己招式更厉害吗？多攒点技能点吧，可以让你表演起来更帅气",
	en = "Do you want to make your moves more powerful? Save up more points to make your performances more awesome",
	zht = "想要讓自己招式更厲害嗎？多攢點技能點吧，可以讓你表演起來更帥氣",
}
LocalizationConfig["loc_ItemDes_58"] =
{
	zh = "一小团沙子，能挖出什么宝来吗",
	en = "A lump of sand, I wonder if there's anything hidden inside it?",
	zht = "一小團沙子，能挖出什麼寶來嗎",
}
LocalizationConfig["loc_ItemDes_59"] =
{
	zh = "经过处理的怪物毛皮，当被子用很合适",
	en = "A processed monster hide, it works great as a blanket",
	zht = "經過處理的怪物毛皮，當被子用很合適",
}
LocalizationConfig["loc_ItemDes_60"] =
{
	zh = "其实是大魔王家的前院，你要见到大魔王本人就必须要穿过它。",
	en = "This is in fact the Dark Lord's yard, if you want to see him in person, you must pass through here.",
	zht = "其實是大魔王家的前院，你要見到大魔王本人就必須要穿過它。",
}
LocalizationConfig["loc_ItemDes_61"] =
{
	zh = "点下去，小小的对话框就会变大进化为真正的文字框",
	en = "Tap to make the small speech bubble turn into a true text box",
	zht = "點下去，小小的對話方塊就會變大進化為真正的文字框",
}
LocalizationConfig["loc_ItemDes_62"] =
{
	zh = "有个公司居然叫光盘计划，我觉得他们一定都很懂得节约粮食",
	en = "There's a company called the CD Project (Clean Dish Project), they must know how to conserve food well.",
	zht = "有個公司居然叫光碟計畫，我覺得他們一定都很懂得節約糧食",
}
LocalizationConfig["loc_ItemDes_63"] =
{
	zh = "最重要的东西之一，小小体积巨大力量的代表，一旦丢失，那就只能重来了。",
	en = "One of the most important items in the game, it's small but holds great power within it. If lost, you'll have to start all over again.",
	zht = "最重要的東西之一，小小體積巨大力量的代表，一旦丟失，那就只能重來了。",
}
LocalizationConfig["loc_ItemDes_64"] =
{
	zh = "世界那么大，传送门的存在让一切变的方便多了，还能听听格拉多斯唱歌",
	en = "With such a big world, portals help to make travel much easier. You even get to hear GLaDOS sing while you do it",
	zht = "世界那麼大，傳送門的存在讓一切變的方便多了，還能聽聽格拉多斯唱歌",
}
LocalizationConfig["loc_ItemDes_65"] =
{
	zh = "喝一口，回30%体力，注意不要买到假冒伪劣或者过期产品",
	en = "Sip it to restore 30% HP, be sure not to buy counterfeit or ones that have passed their expiration date.",
	zht = "喝一口，回30%體力，注意不要買到假冒偽劣或者過期產品",
}
LocalizationConfig["loc_ItemDes_66"] =
{
	zh = "瓶子大了不少，回复量却没有相对应增加那么多，还容易要上厕所",
	en = "A much bigger container, but the amount of HP restored doesn't seem to be much greater. Drinking it will also make you need the toilet more often.",
	zht = "瓶子大了不少，回復量卻沒有相對應增加那麼多，還容易要上廁所",
}
LocalizationConfig["loc_ItemDes_67"] =
{
	zh = "一小片地图，能不能看懂全靠运气。",
	en = "A small map, whether or not you can read it is entirely down to luck",
	zht = "一小片地圖，能不能看懂全靠運氣。",
}
LocalizationConfig["loc_ItemDes_68"] =
{
	zh = "用来练习的木剑，练好了可以成为勇者哦",
	en = "Used to practice sword fighting, once you've practiced enough you can become a great warrior",
	zht = "用來練習的木劍，練好了可以成為勇者哦",
}
LocalizationConfig["loc_ItemDes_69"] =
{
	zh = "小小身材大大力量，据说是导力科技驱动的",
	en = "A small body packed with a load of power, it's said to be powered by orbment technology",
	zht = "小小身材大大力量，據說是導力科技驅動的",
}
LocalizationConfig["loc_ItemDes_70"] =
{
	zh = "普通人拿来计时，高手拿来停住时间",
	en = "Most people use it to keep time, experts use it to stop time",
	zht = "普通人拿來計時，高手拿來停住時間",
}
LocalizationConfig["loc_ItemDes_71"] =
{
	zh = "每个在说话的人头上都会冒出这个东西，拿走它，感觉一切都安静了",
	en = "Everyone will emit this when speaking, if you take it away you'll notice that everything is peaceful and quiet",
	zht = "每個在說話的人頭上都會冒出這個東西，拿走它，感覺一切都安靜了",
}
LocalizationConfig["loc_ItemDes_72"] =
{
	zh = "方方正正又很光滑的小盾牌，老妈拿来当切菜板很合适",
	en = "A smooth, square little shield, mom thinks it's great for chopping food on.",
	zht = "方方正正又很光滑的小盾牌，老媽拿來當切菜板很合適",
}
LocalizationConfig["loc_ItemDes_73"] =
{
	zh = "也称为正常结局，其实获取难度不是很高，比打出人生的好结局容易多了",
	en = "Also known as the normal ending, it actually isn't that hard to get, much easier than getting one in real life",
	zht = "也稱為正常結局，其實獲取難度不是很高，比打出人生的好結局容易多了",
}
LocalizationConfig["loc_ItemDes_74"] =
{
	zh = "拿到这个会让人心情难过，马上再重玩一遍吧",
	en = "This will make people a little sad……you can always play through again……",
	zht = "拿到這個會讓人心情難過，馬上再重玩一遍吧",
}
LocalizationConfig["loc_ItemDes_75"] =
{
	zh = "歪打正着的结局，或者看看攻略书，来获得传说中的真真真好结局",
	en = "The ending you can get if you're lucky enough, or if you read a walkthrough. This will give you the legendary truest and greatest happy ending",
	zht = "歪打正著的結局，或者看看攻略書，來獲得傳說中的真真真好結局",
}
LocalizationConfig["loc_ItemDes_76"] =
{
	zh = "可爱的装饰物，戴在头上有天使的感觉，以前有一只羊也很喜欢戴",
	en = "A cute accessory, putting it on your head makes you feel like an angel. There used to be a sheep that loved wearing this too.",
	zht = "可愛的裝飾物，戴在頭上有天使的感覺，以前有一隻羊也很喜歡戴",
}
LocalizationConfig["loc_ItemDes_77"] =
{
	zh = "没开刃的剑，主要用来格挡，如果使用者魔力够的话就能配合使出各种招式",
	en = "A blunt sword that's primarily used for blocking. If the user's magic is good enough, it can be used to perform all sorts of cool moves.",
	zht = "沒開刃的劍，主要用來格擋，如果使用者魔力夠的話就能配合使出各種招式",
}
LocalizationConfig["loc_ItemDes_78"] =
{
	zh = "冒险中随时会从空中掉落的路牌，“左边红色软糖，右边蓝色软糖，请选择”",
	en = "Signs will randomly drop from the sky during your adventures, “the red candy is to the left, the blue candy is to the right. Please choose.”",
	zht = "冒險中隨時會從空中掉落的路牌，“左邊紅色軟糖，右邊藍色軟糖，請選擇”",
}
LocalizationConfig["loc_ItemDes_79"] =
{
	zh = "不是很尖的练习锤，拿来练练飞马流星拳也不错",
	en = "A practice mace that's not too sharp, great for practicing falcon punches with",
	zht = "不是很尖的練習錘，拿來練練飛馬流星拳也不錯",
}
LocalizationConfig["loc_ItemDes_80"] =
{
	zh = "自充电的灯泡，没有灵感的时候拿来放在头上就会发生点什么",
	en = "A self-charging lightbulb, if you're feeling uninspired and don't have any good ideas you can place it on your head and see what happens.",
	zht = "自充電的燈泡，沒有靈感的時候拿來放在頭上就會發生點什麼",
}
LocalizationConfig["loc_ItemDes_81"] =
{
	zh = "基础的玩具汽车，收集很多的话就可以玩交通模拟了",
	en = "A basic toy car, if you collect a lot of them you can play cars with your friends",
	zht = "基礎的玩具汽車，收集很多的話就可以玩交通模擬了",
}
LocalizationConfig["loc_ItemDes_82"] =
{
	zh = "左键加血，右键加工，还可以用来跳绳。关键时刻敲头也行",
	en = "Press the left button to recover health or the right one to recover wealth, you can also use it as a jump rope. You can also whack people over the head with it when you need to too.",
	zht = "左鍵加血，右鍵加工，還可以用來跳繩。關鍵時刻敲頭也行",
}
LocalizationConfig["loc_ItemDes_83"] =
{
	zh = "纳米技术，对着生命值低的队友扔过去即可迅速回复队友生命，甚至还可禁止敌人回复生命值",
	en = "Designed with Nano technology, throw it to a teammate with low health to rapidly recover their health, it can even be used to stop enemies from recovering HP",
	zht = "納米技術，對著生命值低的隊友扔過去即可迅速回復隊友生命，甚至還可禁止敵人回復生命值",
}
LocalizationConfig["loc_ItemDes_84"] =
{
	zh = "生命值归零的时候会自动破碎，保命一次。然而有时候会故障不工作……",
	en = "It will automatically shatter once your HP reaches zero, giving you one more chance. But it sometimes malfunctions",
	zht = "生命值歸零的時候會自動破碎，保命一次。然而有時候會故障不工作……",
}
LocalizationConfig["loc_ItemDes_85"] =
{
	zh = "很好的叉鱼工具，可以一次叉三条鱼。据说这个也能控制所有海中生物，不过目前还没人成功",
	en = "A great tool for fishing, it can catch three fish at once. It's said that it can also control all sea creatures, but no one has used it successfully in this way yet.",
	zht = "很好的叉魚工具，可以一次叉三條魚。據說這個也能控制所有海中生物，不過目前還沒人成功",
}
LocalizationConfig["loc_ItemDes_86"] =
{
	zh = "冒蓝火但是不会发出哒哒哒的声音。琼斯表示，这个不是水晶头骨，很安全",
	en = "It emits a blue flame but doesn't make a crackling noise. Jones says that this isn't a crystal skill, so it's perfectly safe",
	zht = "冒藍火但是不會發出噠噠噠的聲音。鐘斯表示，這個不是水晶頭骨，很安全",
}
LocalizationConfig["loc_ItemDes_87"] =
{
	zh = "有人用扑克牌挡子弹，有人拿来搭房子。是魔术师表演必备的道具。",
	en = "Some people throw poker cards, firing them like bullets, others use them to build houses. It's a must-have for all magic shows.",
	zht = "有人用撲克牌擋子彈，有人拿來搭房子。是魔術師表演必備的道具。",
}
LocalizationConfig["loc_ItemDes_88"] =
{
	zh = "带上小喇叭才能让全服的小弟听到你的声音",
	en = "Use the megaphone to make everyone on the server hear your voice.",
	zht = "帶上小喇叭才能讓全服的小弟聽到你的聲音",
}
LocalizationConfig["loc_ItemDes_89"] =
{
	zh = "封印了魔王的法杖，使用者稍微不小心就可能被反噬，应当被保存在魔法师学院",
	en = "A staff that has a dark lord sealing inside it, if users aren't careful they might be devoured by it. It ought to kept in a Mage's Academy",
	zht = "封印了魔王的法杖，使用者稍微不小心就可能被反噬，應當被保存在魔法師學院",
}
LocalizationConfig["loc_ItemDes_90"] =
{
	zh = "具有生命力的帽子，曾和披风好兄弟一起游玩，现在好兄弟下落不明",
	en = "A living hat, it used to travel with its best friend Cloak, but Cloak has since gone missing",
	zht = "具有生命力的帽子，曾和披風好兄弟一起遊玩，現在好兄弟下落不明",
}
LocalizationConfig["loc_ItemDes_91"] =
{
	zh = "不错的武器",
	en = "A pretty good weapon",
	zht = "不錯的武器",
}
LocalizationConfig["loc_ItemDes_92"] =
{
	zh = "稍微注入魔力的树枝，想飞起来还很难",
	en = "A branch with a little bit of magic power imbued within it, it probably won't help you to fly high",
	zht = "稍微注入魔力的樹枝，想飛起來還很難",
}
LocalizationConfig["loc_ItemDes_93"] =
{
	zh = "行走江湖，带个宠物会愉快不少，虽然目前还只会卖萌，但是有可能练着练着攻击力就比主角还高了",
	en = "You'll be much happier when wandering the land with a pet. It may not be good for much other thank looking adorable right now, but if you train it up a bit, it may very well become more powerful than your main character",
	zht = "行走江湖，帶個寵物會愉快不少，雖然目前還只會賣萌，但是有可能練著練著攻擊力就比主角還高了",
}
LocalizationConfig["loc_ItemDes_94"] =
{
	zh = "看着挺大一个东西，可以变形为细剑，也能作为飞行道具",
	en = "It looks really big and can turn into a thin blade, it can even help its wearer fly.",
	zht = "看著挺大一個東西，可以變形為細劍，也能作為飛行道具",
}
LocalizationConfig["loc_ItemDes_95"] =
{
	zh = "温暖的手套，特殊工艺制作，绝对不会影响玩手机和平板等设备",
	en = "A warm glove made with special craftsmanship, it won't effect your use of phones or tablets at all.",
	zht = "溫暖的手套，特殊工藝製作，絕對不會影響玩手機和平板等設備",
}
LocalizationConfig["loc_ItemDes_96"] =
{
	zh = "超频人脑就靠饮料了。",
	en = "Great for overclocking your brain.",
	zht = "超頻人腦就靠飲料了。",
}
LocalizationConfig["loc_ItemDes_97"] =
{
	zh = "看起来是普通平板，实际是可随意悬浮在任何地方的显示器，很厉害",
	en = "Looks like a normal tablet but it actually has a fully holographic display, so awesome!",
	zht = "看起來是普通平板，實際是可隨意懸浮在任何地方的顯示器，很厲害",
}
LocalizationConfig["loc_ItemDes_98"] =
{
	zh = "最新款复古画笔，其实是内置核动力的立体打印机",
	en = "The newest vintage-style brush, it's core functionality actually comes from the 3D printer within it",
	zht = "最新款復古畫筆，其實是內置核動力的立體印表機",
}
LocalizationConfig["loc_ItemDes_99"] =
{
	zh = "如彩虹一般变化色彩的墨水，可自定义颜色变化",
	en = "An ink that has all the colors of the rainbow, you can customize the colors yourself",
	zht = "如彩虹一般變化色彩的墨水，可自訂顏色變化",
}
LocalizationConfig["loc_ItemDes_100"] =
{
	zh = "轻便的音乐键盘，电钢琴和传统钢琴音色都能完美胜任",
	en = "A light and highly portable keyboard, it can model electronic and traditional pianos perfectly",
	zht = "輕便的音樂鍵盤，電鋼琴和傳統鋼琴音色都能完美勝任",
}
LocalizationConfig["loc_ItemDes_101"] =
{
	zh = "带在身上到处走可能会被市民投诉吧。",
	en = "If you wander around with this, you might get charged with noise pollution",
	zht = "帶在身上到處走可能會被市民投訴吧。",
}
LocalizationConfig["loc_ItemDes_102"] =
{
	zh = "变装游戏用具，带上以后可爱值增加，还附带走路消音功能",
	en = "Used for playing dress up, wearing it will significantly increase your cute points and will even quieten the sound of your footsteps",
	zht = "變裝遊戲用具，帶上以後可愛值增加，還附帶走路消音功能",
}
LocalizationConfig["loc_ItemDes_103"] =
{
	zh = "艾德快金属制作，切什么东西都和切豆腐差不多，磨刀一次一天起",
	en = "Made from adamantine, it can cut through anything like a hot knife through butter. Sharpen it once per day.",
	zht = "艾德快金屬製作，切什麼東西都和切豆腐差不多，磨刀一次一天起",
}
LocalizationConfig["loc_ItemDes_104"] =
{
	zh = "会四处捡到的东西，一样大小的钱袋，可能开出一百万，也可能开个几块钱",
	en = "Can be picked up all across the land. Every pouch is the same size, it may contain one million or just one piece of gold within it",
	zht = "會四處撿到的東西，一樣大小的錢袋，可能開出一百萬，也可能開個幾塊錢",
}
LocalizationConfig["loc_ItemDes_105"] =
{
	zh = "大锤80，小锤40。扔的准还能晕住人，总的来说是高手向的武器",
	en = "Big ones are 80, small ones are 40, when thrown accurately it can even stun enemies. Generally speaking, they're the weapon of experts",
	zht = "大錘80，小錘40。扔的准還能暈住人，總的來說是高手向的武器",
}
LocalizationConfig["loc_ItemDes_106"] =
{
	zh = "为了凹造型使用的轻便盔甲。上面用巧克力球做装饰，饿了可以拿起来吃",
	en = "Light armor with a concave design. It's adorned with chocolate balls, you can take them off and eat them when you're hungry",
	zht = "為了凹造型使用的輕便盔甲。上面用巧克力球做裝飾，餓了可以拿起來吃",
}
LocalizationConfig["loc_ItemDes_107"] =
{
	zh = "小小的背包可以装下无穷无尽的东西，简直就是一个黑洞。",
	en = "A small bag that can be filled with a countless amount of items, it truly is a blackhole.",
	zht = "小小的背包可以裝下無窮無盡的東西，簡直就是一個黑洞。",
}
LocalizationConfig["loc_ItemDes_108"] =
{
	zh = "喝了就不会遇敌的方便药水。出门常备一点准没错，就是价格有点贵。",
	en = "A convenient potion that will prevent you from being attacked by enemies when drank. It's a great idea to take some with you on your journeys, but it's a little pricey.",
	zht = "喝了就不會遇敵的方便藥水。出門常備一點准沒錯，就是價格有點貴。",
}
LocalizationConfig["loc_ItemDes_109"] =
{
	zh = "写剧本是个头疼事，写得不好会被玩家抱怨",
	en = "Writing a script is a massive headache, if you don't write it well, players will complain",
	zht = "寫劇本是個頭疼事，寫得不好會被玩家抱怨",
}
LocalizationConfig["loc_ItemDes_110"] =
{
	zh = "价格不菲的麦克风，拒绝电流麦，保护竞技环境",
	en = "A pricey microphone, say no to electric mics to protect our gaming environment",
	zht = "價格不菲的麥克風，拒絕電流麥，保護競技環境",
}
LocalizationConfig["loc_ItemDes_111"] =
{
	zh = "复古造型，兼具通风和过滤灰尘功能，防护力4级，居家旅行野外求生必备",
	en = "An antique-style model that's both breezy and can filter dirt and dust. With Lv.4 defense, it's a must for those surviving in the wilderness.",
	zht = "復古造型，兼具通風和過濾灰塵功能，防護力4級，居家旅行野外求生必備",
}
LocalizationConfig["loc_ItemDes_112"] =
{
	zh = "穿着好的篮球鞋可以让你从罚球线起跳扣篮成功的概率提高0.01%，吸引小姑娘注意力的几率提高1%",
	en = "Wearing basketball shoes will increase your probability of being able to successfully dunk from the free throw line by 0.01% and increase girls' attraction to you by 1%",
	zht = "穿著好的籃球鞋可以讓你從罰球線起跳扣籃成功的概率提高0.01%，吸引小姑娘注意力的幾率提高1%",
}
LocalizationConfig["loc_ItemDes_113"] =
{
	zh = "传说在玉米村有个相机，拍谁谁美，带着这个去冒险再合适不过了",
	en = "Legend has it that there's a camera in Cornville that can make anyone look beautiful, perfect for taking with you on your adventures",
	zht = "傳說在玉米村有個相機，拍誰誰美，帶著這個去冒險再合適不過了",
}
LocalizationConfig["loc_ItemDes_114"] =
{
	zh = "一根普通的骨头，不是专业的医生，你根本认不出这是哪里的骨头，但是它自己总能知道自己从哪里来要回到哪里去",
	en = "An ordinary bone, if you're not a professional physician you won't recognize what part of a body this belongs to but it knows where it's from and where it should return to itself",
	zht = "一根普通的骨頭，不是專業的醫生，你根本認不出這是哪裡的骨頭，但是它自己總能知道自己從哪裡來要回到哪裡去",
}
LocalizationConfig["loc_ItemDes_115"] =
{
	zh = "普通飞机的遥控器，经过科学改造，可以遥控各种生物。对操作者的精神力有严格的要求",
	en = "An ordinary plane remote, after undergoing modifications, it's able to control various creatures. It has a strict demand on the user's mental spirit",
	zht = "普通飛機的遙控器，經過科學改造，可以遙控各種生物。對操作者的精神力有嚴格的要求",
}
LocalizationConfig["loc_ItemDes_116"] =
{
	zh = "曾经3000点换的金枪还是稀有品，现在已然是烂大街的货色",
	en = "Golden revolvers like this used to be a rare item that cost 3000, now they can be found in any of the stalls selling tat on the highstreets",
	zht = "曾經3000點換的金槍還是稀有品，現在已然是爛大街的貨色",
}
LocalizationConfig["loc_ItemDes_117"] =
{
	zh = "帽子做大一点，就可以迷惑对手，躲过被爆头的命运",
	en = "With a slightly bigger hat, you can confuse your opponents and avoid having your head blown off",
	zht = "帽子做大一點，就可以迷惑對手，躲過被爆頭的命運",
}
LocalizationConfig["loc_ItemDes_118"] =
{
	zh = "放在胸口可以挡子弹哦",
	en = "Can protect your chest from bullets",
	zht = "放在胸口可以擋子彈哦",
}
LocalizationConfig["loc_ItemDes_119"] =
{
	zh = "带着这杆长枪，做一个下蹲准备动作，就可以不停往前冲啦",
	en = "If you crouch down and do a power-up action with this lance, you will be able to charge forwards without stopping",
	zht = "帶著這杆長槍，做一個下蹲準備動作，就可以不停往前沖啦",
}
LocalizationConfig["loc_ItemDes_120"] =
{
	zh = "平时是迷你盾牌，需要用的时候可以展开",
	en = "A shield that's normally really tiny, it can be enlarged when you need to use it.",
	zht = "平時是迷你盾牌，需要用的時候可以展開",
}
LocalizationConfig["loc_ItemDes_121"] =
{
	zh = "关键时刻可以用来捆绑怪物，活的怪物可要值钱的多",
	en = "Can be used to tie up monsters at the crucial moment, living monsters are worth much more",
	zht = "關鍵時刻可以用來捆綁怪物，活的怪物可要值錢的多",
}
LocalizationConfig["loc_ItemDes_122"] =
{
	zh = "可以在各个种族之间切换形态的披风，制造工艺不为人所知",
	en = "A cloak that allows you to change between different races, the technology and techniques used to create it are unknown",
	zht = "可以在各個種族之間切換形態的披風，製造工藝不為人所知",
}
LocalizationConfig["loc_ItemDes_123"] =
{
	zh = "小小翅膀巨大升力，不管多胖的人戴上都能自由翱翔",
	en = "A small wing with a great amount of lift, no matter how fat the user is, they can all soar freely through the air when wearing this",
	zht = "小小翅膀巨大升力，不管多胖的人戴上都能自由翱翔",
}
LocalizationConfig["loc_ItemDes_124"] =
{
	zh = "看起来是角色扮演的道具，其实可以当飞镖扔出去",
	en = "It looks like part of a roleplaying costume, but it can actually be thrown as a dart",
	zht = "看起來是角色扮演的道具，其實可以當飛鏢扔出去",
}
LocalizationConfig["loc_ItemDes_125"] =
{
	zh = "非常耐热的手套，看起来也很可爱",
	en = "A glove that can withstand a lot of heat, it's really adorable",
	zht = "非常耐熱的手套，看起來也很可愛",
}
LocalizationConfig["loc_ItemDes_126"] =
{
	zh = "一罐可乐等于9颗方糖，我选择……",
	en = "One can of cola contains 9 of these, I think I'll choose…….",
	zht = "一罐可樂等於9顆方糖，我選擇……",
}
LocalizationConfig["loc_ItemDes_127"] =
{
	zh = "传统奶昔是手摇的，现在已经很少见了",
	en = "Traditional milkshakes shaken by hand are an extremely rare sight nowadays",
	zht = "傳統奶昔是手搖的，現在已經很少見了",
}
LocalizationConfig["loc_ItemDes_128"] =
{
	zh = "香草冰淇淋必备",
	en = "A necessity for making vanilla ice-cream",
	zht = "香草霜淇淋必備",
}
LocalizationConfig["loc_ItemDes_129"] =
{
	zh = "中药中重要的配方之一，要拿来喝也不是不可以",
	en = "One of the most important ingredients for Chinese medicine, you can drink it straight too if you want",
	zht = "中藥中重要的配方之一，要拿來喝也不是不可以",
}
LocalizationConfig["loc_ItemDes_130"] =
{
	zh = "美食星人最害怕的东西之一，看到一个拆掉一个",
	en = "One of the most feared instruments in Dessert Planet, they're not allowed to be left in working condition",
	zht = "美食星人最害怕的東西之一，看到一個拆掉一個",
}
LocalizationConfig["loc_ItemDes_131"] =
{
	zh = "可以做料理，但是注意不要直接吃，呛到可不是开玩笑的",
	en = "Can be used in cooking, but don't eat it directly, choking on it isn't much fun",
	zht = "可以做料理，但是注意不要直接吃，嗆到可不是開玩笑的",
}
LocalizationConfig["loc_ItemDes_132"] =
{
	zh = "爱吃布丁的一定爱吃果冻，爱吃果冻的不一定爱吃布丁",
	en = "Those who love pudding also love jelly, but those who love jelly don't necessarily love pudding",
	zht = "愛吃布丁的一定愛吃果凍，愛吃果凍的不一定愛吃布丁",
}
LocalizationConfig["loc_ItemDes_133"] =
{
	zh = "开心果并不是天生就开口笑的，很多是后期加工开口",
	en = "Pistachios don't naturally open their mouths to smile, most only smile after undergoing processing",
	zht = "開心果並不是天生就開口笑的，很多是後期加工開口",
}
LocalizationConfig["loc_ItemDes_134"] =
{
	zh = "看起来很有弹性的也很美味，不过还是要和其他东西放在一起才行",
	en = "It looks gummy and yummy, but it really needs to be mixed with other things first",
	zht = "看起來很有彈性的也很美味，不過還是要和其他東西放在一起才行",
}
LocalizationConfig["loc_ItemDes_135"] =
{
	zh = "从动画片里看是小老鼠的最爱",
	en = "Cartoons tell us that mouse love eating this",
	zht = "從動畫片裡看是小老鼠的最愛",
}
LocalizationConfig["loc_ItemDes_136"] =
{
	zh = "煎牛排的必备搭配",
	en = "A must-have for frying steak",
	zht = "煎牛排的必備搭配",
}
LocalizationConfig["loc_ItemDes_137"] =
{
	zh = "世界上最长的香肠，长度为392米，好想咬一口",
	en = "The longest sausage in the world is 392 meters long, I'd love to take a bit outta that",
	zht = "世界上最長的香腸，長度為392米，好想咬一口",
}
LocalizationConfig["loc_ItemDes_138"] =
{
	zh = "不含可可粉的巧克力，也会比较甜哦",
	en = "A type of chocolate that doesn't contain much coco but is pretty sweet",
	zht = "不含可哥粉的巧克力，也會比較甜哦",
}
LocalizationConfig["loc_ItemDes_139"] =
{
	zh = "乳质含量小于百分之十二的才是真正的黑巧克力，适当食用有助有心血管健康哦",
	en = "True dark chocolate contains less than 20% milk solids, it's nice to eat and good for the health of your veins",
	zht = "乳質含量小於百分之十二的才是真正的黑巧克力，適當食用有助有心血管健康哦",
}
LocalizationConfig["loc_ItemDes_140"] =
{
	zh = "可以做巧克力，也可以冲豆浆",
	en = "Can be made into chocolate, or mixed with milk",
	zht = "可以做巧克力，也可以沖豆漿",
}
LocalizationConfig["loc_ItemDes_141"] =
{
	zh = "四大坚果之一，好吃但不能多吃",
	en = "One of the four great nuts, it's delicious but you can't eat too much",
	zht = "四大堅果之一，好吃但不能多吃",
}
LocalizationConfig["loc_ItemDes_142"] =
{
	zh = "没有奶油的的蛋糕没有灵魂",
	en = "A cake with no cream is a cake with no soul",
	zht = "沒有奶油的的蛋糕沒有靈魂",
}
LocalizationConfig["loc_ItemDes_143"] =
{
	zh = "吃点核桃也许可以变聪明，猛吃核桃肯定会变胖",
	en = "If you eat a little walnut you may become a bit smarter; if you eat a lot of walnut you'll definitely become fat",
	zht = "吃點核桃也許可以變聰明，猛吃核桃肯定會變胖",
}
LocalizationConfig["loc_ItemDes_144"] =
{
	zh = "常出现于餐桌的坚果",
	en = "A common appearance on the dinner table",
	zht = "常出現于餐桌的堅果",
}
LocalizationConfig["loc_ItemDes_145"] =
{
	zh = "吃沙拉的时候，最不应该加的就是沙拉酱",
	en = "When eating salad, the thing that you certainly shouldn't add is salad dressing",
	zht = "吃沙拉的時候，最不應該加的就是沙拉醬",
}
LocalizationConfig["loc_ItemDes_146"] =
{
	zh = "可以制作成各种食物的奇妙粉末",
	en = "A wonderful powder that can be used to make all sorts of foods",
	zht = "可以製作成各種食物的奇妙粉末",
}
LocalizationConfig["loc_ItemDes_147"] =
{
	zh = "甜甜的东西，储存环境不当心的话会引来大量蚂蚁",
	en = "A sweet liquid, if you're not careful with its storage, you might end up infested with ants",
	zht = "甜甜的東西，儲存環境不當心的話會引來大量螞蟻",
}
LocalizationConfig["loc_ItemDes_148"] =
{
	zh = "料理专用，不仅有助于调味，还能帮助嫩肉",
	en = "Used for cooking, it not only helps add flavor but also helps to tenderize the meat",
	zht = "料理專用，不僅有助於調味，還能幫助嫩肉",
}
LocalizationConfig["loc_ItemDes_149"] =
{
	zh = "买糖纸送糖，香味恒久远，一张永流传",
	en = "Buy a candy wrapper and get a free candy, the sweet scent on it lasts for ever",
	zht = "買糖紙送糖，香味恒久遠，一張永流傳",
}
LocalizationConfig["loc_ItemDes_150"] =
{
	zh = "稍微高级一点的吸管，远远看起来有种中间夹了柠檬片的感觉",
	en = "A more advanced type of straw, from afar it looks like a piece of lemon has been stuck in the middle",
	zht = "稍微高級一點的吸管，遠遠看起來有種中間夾了檸檬片的感覺",
}
LocalizationConfig["loc_ItemDes_151"] =
{
	zh = "环保的披风，穿上去带些许的隐身效果，同时风属性攻击免疫",
	en = "An environmentally friendly cloak, wearing it gives the wearer some invisibility and immunity to wind element attacks",
	zht = "環保的披風，穿上去帶些許的隱身效果，同時風屬性攻擊免疫",
}
LocalizationConfig["loc_ItemDes_152"] =
{
	zh = "自从有了珍珠奶茶这个东西以后，超粗吸管也成了甜品店标配之一。",
	en = "Ever since pearl tea was invented, the thick straw became a regular stock of dessert stores.",
	zht = "自從有了珍珠奶茶這個東西以後，超粗吸管也成了甜品店標配之一。",
}
LocalizationConfig["loc_ItemDes_153"] =
{
	zh = "用北极冰块制作。泰坦尼克号碰撞之后，每块冰块都好像有了故事一样。",
	en = "Made with icebergs from the north pole. After the sinking of the Titanic, it seems as if each piece of ice has its own story to tell.",
	zht = "用北極冰塊製作。泰坦尼克號碰撞之後，每塊冰塊都好像有了故事一樣。",
}
LocalizationConfig["loc_ItemDes_154"] =
{
	zh = "侍卫专用高礼帽，没有一定实力是带不了的哦",
	en = "The top hat used by guards, only those with great ability are able to wear it",
	zht = "侍衛專用高禮帽，沒有一定實力是帶不了的哦",
}
LocalizationConfig["loc_ItemDes_155"] =
{
	zh = "纳米材料特制围裙，不管沾到什么东西，只需用力甩一甩就干净了",
	en = "An apron made from Nano materials, anything that sticks to it can be shaken off with a brief shake",
	zht = "納米材料特製圍裙，不管沾到什麼東西，只需用力甩一甩就乾淨了",
}
LocalizationConfig["loc_ItemDes_156"] =
{
	zh = "番茄富含维生素，小番茄则是挑选零食时的上佳选择，有时候有点酸就是了",
	en = "Tomatoes are packed full of vitamins, these small tomatoes are a great snack choice. Their only pitfall is that sometimes they're a little sour",
	zht = "番茄富含維生素，小番茄則是挑選零食時的上佳選擇，有時候有點酸就是了",
}
LocalizationConfig["loc_ItemDes_157"] =
{
	zh = "相比玻璃弹珠，多了点粘性",
	en = "A considerable bit stickier than marbles",
	zht = "相比玻璃彈珠，多了點粘性",
}
LocalizationConfig["loc_ItemDes_158"] =
{
	zh = "想给头发做造型，必不可少的就是卷发棒，最新款自动卷发棒很受欢迎",
	en = "If you want to style your hair a little then you can't do without a curler, the newest model with automatic curling is extremely popular",
	zht = "想給頭髮做造型，必不可少的就是卷髮棒，最新款自動卷髮棒很受歡迎",
}
LocalizationConfig["loc_ItemDes_159"] =
{
	zh = "带有香味的遮阳帽，每天早上买一顶，太阳小了以后可以顺便吃掉一点，简直完美的产品",
	en = "A fragrant sun hat, buy one every morning and gradually eat it as the sun lowers in the sky. Truly a great product.",
	zht = "帶有香味的遮陽帽，每天早上買一頂，太陽小了以後可以順便吃掉一點，簡直完美的產品",
}
LocalizationConfig["loc_ItemDes_160"] =
{
	zh = "并不透明的黑色披风，小部分附带隐身功能",
	en = "A completely opaque black cape, it also has minor invisibility effects",
	zht = "並不透明的黑色披風，小部分附帶隱身功能",
}
LocalizationConfig["loc_ItemDes_161"] =
{
	zh = "烤肉专用叉子，音乐课也能拿来当做道具用",
	en = "A fork that's used for barbequed meat, it can also be used for pitch in music lessons",
	zht = "烤肉專用叉子，音樂課也能拿來當做道具用",
}
LocalizationConfig["loc_ItemDes_162"] =
{
	zh = "作为火锅中的常用蘸料之一，改善口感勾起食欲的同时，还可以补充钙质",
	en = "One of the most common hotpot dipping sauces, it changes the taste of the food while piquing appetite and is also a great source of calcium.",
	zht = "作為火鍋中的常用蘸料之一，改善口感勾起食欲的同時，還可以補充鈣質",
}
LocalizationConfig["loc_ItemDes_163"] =
{
	zh = "看起来有点焦掉了，实际咬下去的话还是鲜嫩多汁的",
	en = "It looks a little overcooked but when you take a bite it's still nice and juicy",
	zht = "看起來有點焦掉了，實際咬下去的話還是鮮嫩多汁的",
}
LocalizationConfig["loc_ItemDes_164"] =
{
	zh = "看起来像是吉他的拨片，其实挺厚的，吃起来味道也不错",
	en = "It looks like a guitar pick and is actually really thick, but it still tastes great",
	zht = "看起來像是吉他的撥片，其實挺厚的，吃起來味道也不錯",
}
LocalizationConfig["loc_ItemDes_165"] =
{
	zh = "生菜中含有膳食纤维和维生素，有消除多余脂肪的作用。然而猛吃生菜加烤肉肯定是会胖的",
	en = "Lettuce contains dietary fiber and vitamins and can remove excess fat. But you'll still get fat from eating too much meat with your lettuce",
	zht = "生菜中含有膳食纖維和維生素，有消除多餘脂肪的作用。然而猛吃生菜加烤肉肯定是會胖的",
}
LocalizationConfig["loc_ItemDes_166"] =
{
	zh = "据说黄芥末才是真正的芥末，不过现代人也就只在吃热狗的时候有机会接触了。",
	en = "It's said that mustard is much better than wasabi or horseradish, but nowadays people only have the chance to have it with their hotdogs.",
	zht = "據說黃芥末才是真正的芥末，不過現代人也就只在吃熱狗的時候有機會接觸了。",
}
LocalizationConfig["loc_ItemDes_167"] =
{
	zh = "普通的吸管，折弯设计可以让人从各个角度喝到饮料，懒人必备",
	en = "A common straw, straws enable people to drink their drinks from any given angle, a must-have for the lazy",
	zht = "普通的吸管，折彎設計可以讓人從各個角度喝到飲料，懶人必備",
}
LocalizationConfig["loc_ItemDes_168"] =
{
	zh = "帅气的披风，穿上之后攻击带有回体力效果，附带火属性免疫",
	en = "A cool looking cape, wearers will be able to restore HP from their attacks and have immunity from fire element attacks",
	zht = "帥氣的披風，穿上之後攻擊帶有回體力效果，附帶火屬性免疫",
}
LocalizationConfig["loc_ItemDes_169"] =
{
	zh = "某科幻故事中价值连城的瓶盖，可以换各种吃的喝的除了可乐",
	en = "Bottlecaps are priceless in a certain sci-fi story, they can be traded for all sorts of food and drink……except for cola that is",
	zht = "某科幻故事中價值連城的瓶蓋，可以換各種吃的喝的除了可樂",
}
LocalizationConfig["loc_ItemDes_170"] =
{
	zh = "这年头，咬掉一口的苹果可比完整的苹果贵多了",
	en = "These days, an apple with a bit taken out of it is much more expensive than a complete one",
	zht = "這年頭，咬掉一口的蘋果可比完整的蘋果貴多了",
}
LocalizationConfig["loc_ItemDes_171"] =
{
	zh = "这个领结没有变声功能，但是有变身功能，所以得戴在头上",
	en = "This bow won't help you transform your voice, but it will let you transform your form, so you should wear one on your head",
	zht = "這個領結沒有變聲功能，但是有變身功能，所以得戴在頭上",
}
LocalizationConfig["loc_ItemDes_172"] =
{
	zh = "新鲜的小草莓，放在各种蛋糕上就是核心的存在，谁不希望自己的蛋糕上有小草莓呢",
	en = "A fresh strawberry, one of the staples of cake dressings, no one wants a small one on their cake though",
	zht = "新鮮的小草莓，放在各種蛋糕上就是核心的存在，誰不希望自己的蛋糕上有小草莓呢",
}
LocalizationConfig["loc_ItemDes_173"] =
{
	zh = "最新产品，超强马达，可以用来钓鱼，放风筝",
	en = "The newest model with a really powerful motor, it can be used for fishing or kiting",
	zht = "最新產品，超強馬達，可以用來釣魚，放風箏",
}
LocalizationConfig["loc_ItemDes_174"] =
{
	zh = "冬天来一份糖炒栗子，没有比这更高级的享受了。哦，没人帮你剥除外。",
	en = "Eating sweet roast chestnuts in winter is the best thing in the world. Oh, that is unless no one helps you to peel them.",
	zht = "冬天來一份糖炒栗子，沒有比這更高級的享受了。哦，沒人幫你剝除外。",
}
LocalizationConfig["loc_ItemDes_175"] =
{
	zh = "吹风机的妙用：手机贴膜，拆手机屏幕。电脑城维修师傅必备",
	en = "Great uses for blow dryers: Adding a protective cover to your phone, or removing the phone's screen. A necessity for repair technicians.",
	zht = "吹風機的妙用：手機貼膜，拆手機螢幕。電腦城維修師傅必備",
}
LocalizationConfig["loc_ItemDes_176"] =
{
	zh = "戴上这个帽子一定会睡得很香，只是夏天的话可能会有点热",
	en = "Wearing this cap is guaranteed to give you a great night's sleep, although you may find it a little too hot during winter",
	zht = "戴上這個帽子一定會睡得很香，只是夏天的話可能會有點熱",
}
LocalizationConfig["loc_ItemDes_177"] =
{
	zh = "听说猫猫也会吃这个",
	en = "I've heard that cats eat these too",
	zht = "聽說貓貓也會吃這個",
}
LocalizationConfig["loc_ItemDes_178"] =
{
	zh = "即便现在有了开瓶器，还是有人身怀筷子开瓶盖的绝技",
	en = "Even though we have bottle openers there are still those who can open bottles through other means",
	zht = "即便現在有了開瓶器，還是有人身懷筷子開瓶蓋的絕技",
}
LocalizationConfig["loc_ItemDes_179"] =
{
	zh = "提前放到冰箱里，拿出来以后就是冰冰凉的杯子，靠的是中间夹层里的水，曾经风靡一时",
	en = "Place it in the freezer for a while and when you take it out it's a cool, frosty glass, it uses water between two pieces of glass to achieve this effect and used to be all the rage",
	zht = "提前放到冰箱裡，拿出來以後就是冰冰涼的杯子，靠的是中間夾層裡的水，曾經風靡一時",
}
LocalizationConfig["loc_ItemDes_180"] =
{
	zh = "虽然性能比不上落地镜，但是对于爱美的姑娘来说，带着随身看两眼是必须的",
	en = "It may not be as good as a floor mirror, but for girls who care about their appearance, it allows them to check their complexion whenever, wherever",
	zht = "雖然性能比不上落地鏡，但是對於愛美的姑娘來說，帶著隨身看兩眼是必須的",
}
LocalizationConfig["loc_ItemDes_181"] =
{
	zh = "弯弯的大草帽，完美的弧线使得各个角度看起来都很美丽",
	en = "A curved straw hat, its perfect arc makes it beautiful from all angles",
	zht = "彎彎的大草帽，完美的弧線使得各個角度看起來都很美麗",
}
LocalizationConfig["loc_ItemDes_182"] =
{
	zh = "用来装饰的围脖，保暖作用一般，当然也刷不出什么东西",
	en = "A decorative scarf, it's just ok at helping you keep warm and of course what you see is what you get with it",
	zht = "用來裝飾的圍脖，保暖作用一般，當然也刷不出什麼東西",
}
LocalizationConfig["loc_ItemDes_183"] =
{
	zh = "挥洒一下，就能完成你一个愿望，只有仙女挥动才有用哦",
	en = "With a flick of a wrist it will make your wishes come true, it only works in the hand of a true fairy",
	zht = "揮灑一下，就能完成你一個願望，只有仙女揮動才有用哦",
}
LocalizationConfig["loc_ItemDes_184"] =
{
	zh = "减肥的玉米粒，经常在沙拉中见到。小时候常用来喂人民广场的鸽子们",
	en = "Sweetcorn is great for losing weight, meaning it's often found in salads. Childhood memories of feeding the pigeons with it come flooding back",
	zht = "減肥的玉米粒，經常在沙拉中見到。小時候常用來喂人民廣場的鴿子們",
}
LocalizationConfig["loc_ItemDes_185"] =
{
	zh = "焦糖的味道和香味，令人爱不释手",
	en = "The taste and sell of toffee makes people find it hard to give it up",
	zht = "焦糖的味道和香味，令人愛不釋手",
}
LocalizationConfig["loc_ItemDes_186"] =
{
	zh = "爆米花盒子可以有很多形式和花头，有时候买个爆米花，就是为了帅气的包装",
	en = "Popcorn boxes call in all sorts of shapes and forms, sometimes people buy popcorn just for the cool looking box",
	zht = "爆米花盒子可以有很多形式和花頭，有時候買個爆米花，就是為了帥氣的包裝",
}
LocalizationConfig["loc_ItemDes_187"] =
{
	zh = "精致的小项圈，完美的装饰品",
	en = "An exquisite collar, a truly perfect accessory",
	zht = "精緻的小項圈，完美的裝飾品",
}
LocalizationConfig["loc_ItemDes_188"] =
{
	zh = "熊喜欢吃蜂蜜是原因的，那就是，美味！",
	en = "The reason bears love eating honey is because of its…….great flavor!",
	zht = "熊喜歡吃蜂蜜是原因的，那就是，美味！",
}
LocalizationConfig["loc_ItemDes_189"] =
{
	zh = "鸡蛋营养丰富，各种蛋糕都会用到",
	en = "Eggs are filled with nutrition, they're used in all sorts of cakes",
	zht = "雞蛋營養豐富，各種蛋糕都會用到",
}
LocalizationConfig["loc_ItemDes_190"] =
{
	zh = "温泉之后来一杯牛奶真是神仙般的体验",
	en = "Drinking a cool glass of milk after bathing in a hot spring is one of the best experiences ever",
	zht = "溫泉之後來一杯牛奶真是神仙般的體驗",
}
LocalizationConfig["loc_ItemDes_191"] =
{
	zh = "左边这家的肉饼好吃？还右边这家的肉饼好吃？还是都不好吃？？",
	en = "Is the burger place on the left better? Or the one on the right? Or are they both terrible?",
	zht = "左邊這家的肉餅好吃？還右邊這家的肉餅好吃？還是都不好吃？？",
}
LocalizationConfig["loc_ItemDes_192"] =
{
	zh = "芝士本身味道有点奇怪，但是作为配料却十分完美",
	en = "Cheese may smell a bit odd, but it's perfect as an accompaniment.",
	zht = "芝士本身味道有點奇怪，但是作為配料卻十分完美",
}
LocalizationConfig["loc_ItemDes_193"] =
{
	zh = "土豆营养丰富，带皮炸更好吃哦，在家炸可以考虑用空气炸锅",
	en = "Potatoes are filled with nutrition, they're much nicer fried with their skins still on. If you're gonna fry them at home you can use an air fryer",
	zht = "土豆營養豐富，帶皮炸更好吃哦，在家炸可以考慮用空氣炸鍋",
}
LocalizationConfig["loc_ItemDes_194"] =
{
	zh = "展示肌肉的绝佳“工具”",
	en = "The best “tool” for showing off your muscles",
	zht = "展示肌肉的絕佳“工具”",
}
LocalizationConfig["loc_ItemDes_195"] =
{
	zh = "用纸做的皇冠，但是国王依然每天都高高兴兴地戴着它。",
	en = "The crown may just be made out of paper, but the king still happily wears it every day.",
	zht = "用紙做的皇冠，但是國王依然每天都高高興興地戴著它。",
}
LocalizationConfig["loc_ItemDes_196"] =
{
	zh = "联网的摄像头，一下子就能发现所有乾坤",
	en = "A CCTV camera with network connection, you can see everything with it in an instant",
	zht = "聯網的攝像頭，一下子就能發現所有乾坤",
}
LocalizationConfig["loc_ItemDes_197"] =
{
	zh = "说明卡的升级版，在逛各种大型纪念场馆的时候非常有用，现在有的地方还有可视版本",
	en = "The upgrade from explanation cards, extremely useful when walking around different memorials, there are even places that have visual ones nowadays",
	zht = "說明卡的升級版，在逛各種大型紀念場館的時候非常有用，現在有的地方還有可視版本",
}
LocalizationConfig["loc_ItemDes_198"] =
{
	zh = "有人逛博物馆是看图片，有人是看各种介绍和说明，不过说明卡的字比较小看起来很累",
	en = "Some people look at the pictures when visiting museums, others read different sorts of introductions and explanations. The words on explanation cards are a little small, they're pretty tiring to read.",
	zht = "有人逛博物館是看圖片，有人是看各種介紹和說明，不過說明卡的字比較小看起來很累",
}
LocalizationConfig["loc_ItemDes_199"] =
{
	zh = "这是古代考古学家用来考古的铲子，遗产中的遗产",
	en = "A spade used by archaeologists, a relic within a relic",
	zht = "這是古代考古學家用來考古的鏟子，遺產中的遺產",
}
LocalizationConfig["loc_ItemDes_200"] =
{
	zh = "可能是某件艺术品的碎片",
	en = "It might be the fragment of some kind of work of art",
	zht = "可能是某件藝術品的碎片",
}
LocalizationConfig["loc_ItemDes_201"] =
{
	zh = "那些很容易看到的警报器其实都是假的骗人的，真的一旦发声真叫一个毁天灭地",
	en = "Those who say they can easily find alarms are all liars, if an alarm actually starts ringing it really is a complete disaster",
	zht = "那些很容易看到的警報器其實都是假的騙人的，真的一旦發聲真叫一個毀天滅地",
}
LocalizationConfig["loc_ItemDes_202"] =
{
	zh = "凑齐六颗宝石就有了宇宙最强的力量啦，弹指之间……发现混进了一颗假的！",
	en = "Collect six of them to obtain the greatest power in the universe, until with a snap of the fingers……you discover there's a fake among them!",
	zht = "湊齊六顆寶石就有了宇宙最強的力量啦，彈指之間……發現混進了一顆假的！",
}
LocalizationConfig["loc_ItemDes_203"] =
{
	zh = "为了让普通民众不被恶魔力量的侵蚀，古人们会把各种邪恶的东西封印起来",
	en = "In order to prevent ordinary people from being corrupted by evil forces, the ancients would seal all sorts of evil stuff",
	zht = "為了讓普通民眾不被惡魔力量的侵蝕，古人們會把各種邪惡的東西封印起來",
}
LocalizationConfig["loc_ItemDes_204"] =
{
	zh = "乱扔垃圾的话，这个扫把会偷偷打你",
	en = "If you litter, this broom will smack you when you're not looking",
	zht = "亂扔垃圾的話，這個掃把會偷偷打你",
}
LocalizationConfig["loc_ItemDes_205"] =
{
	zh = "“您好，欢迎光临”“您好，欢迎再来”",
	en = "“Ding dong!”, “Ding dong!”",
	zht = "“您好，歡迎光臨”“您好，歡迎再來”",
}
LocalizationConfig["loc_ItemDes_206"] =
{
	zh = "画框一般都有魔力，否则画里面的东西过不了两天就跑光了",
	en = "Painting frames usually have magical powers, otherwise the stuff in the paintings will all be gone within two days flat",
	zht = "畫框一般都有魔力，否則畫裡面的東西過不了兩天就跑光了",
}
LocalizationConfig["loc_ItemDes_207"] =
{
	zh = "随意穿过警示带的人都会被标记，晚上会有人来找",
	en = "Those who cross over stanchions will be marked, people will then come and take them in the night",
	zht = "隨意穿過警示帶的人都會被標記，晚上會有人來找",
}
LocalizationConfig["loc_ItemDes_208"] =
{
	zh = "逛展览逛迷路了可不好，有了导览图才能意识到自己迷路不是因为没有地图",
	en = "Getting lost around the exhibits is terrible, you'll only know that the reason you're lost isn't because you have a map if you already have a guide map",
	zht = "逛展覽逛迷路了可不好，有了導覽圖才能意識到自己迷路不是因為沒有地圖",
}
LocalizationConfig["loc_ItemDes_209"] =
{
	zh = "不管放在哪里都能提升一点舒适度，空气也会好起来",
	en = "It'll liven up the place anywhere it's placed, the room's air will also be cleaner",
	zht = "不管放在哪裡都能提升一點舒適度，空氣也會好起來",
}
LocalizationConfig["loc_ItemDes_210"] =
{
	zh = "面值一般不高，价值却可能很高，不小心扔了就亏了",
	en = "It may not have much face value, but it could be worth something. If you accidently throw it away you might end up kicking yourself",
	zht = "面值一般不高，價值卻可能很高，不小心扔了就虧了",
}
LocalizationConfig["loc_ItemDes_211"] =
{
	zh = "有人说是丐帮丢掉的",
	en = "People say it was thrown away by a group of beggars",
	zht = "有人說是丐幫丟掉的",
}
LocalizationConfig["loc_ItemDes_212"] =
{
	zh = "保险箱的存在就是为了告诉别人我这里有好东西啊！有本事来打开我啊！不过炸开保险箱的时候要当心",
	en = "The presence of a safe screams that it's got something valuable in it! “Open me if you can!” But you must be careful if you're planning on blowing it open",
	zht = "保險箱的存在就是為了告訴別人我這裡有好東西啊！有本事來打開我啊！不過炸開保險箱的時候要當心",
}
LocalizationConfig["loc_ItemDes_213"] =
{
	zh = "把火势消灭于萌芽之中，可以说是无价的产品",
	en = "Reduces a growing flame to a small ember, it could be said to be priceless",
	zht = "把火勢消滅于萌芽之中，可以說是無價的產品",
}
LocalizationConfig["loc_ItemDes_214"] =
{
	zh = "参加任何展览都要门票，即使是免费项目也要统计一下人头。收集多了可以开一个门票展览会",
	en = "All exhibitions require tickets, even free ones need to keep a head count. Once you've collected a bunch you can open your own exhibition ticket exhibition",
	zht = "參加任何展覽都要門票，即使是免費項目也要統計一下人頭。收集多了可以開一個門票展覽會",
}
LocalizationConfig["loc_ItemDes_215"] =
{
	zh = "上面有着各种有纪念意义的图案",
	en = "They have all sorts of souvenir pictures on them",
	zht = "上面有著各種有紀念意義的圖案",
}
LocalizationConfig["loc_ItemDes_216"] =
{
	zh = "在没有信号的地方，对讲机可是十分好用的工具，小型车队也可以使用。使用大功率的对讲机时要申报一下",
	en = "Walkie talkies are really useful in places with no signal, small convoys can also use them. More powerful ones must be declared first though.",
	zht = "在沒有信號的地方，對講機可是十分好用的工具，小型車隊也可以使用。使用大功率的對講機時要申報一下",
}
LocalizationConfig["loc_ItemDes_217"] =
{
	zh = "睡觉吹出好看的鼻涕泡是需要天分的",
	en = "It takes talent to blow a good snot bubble when you're sleeping",
	zht = "睡覺吹出好看的鼻涕泡是需要天分的",
}
LocalizationConfig["loc_ItemDes_218"] =
{
	zh = "背着这个东西看起来就会像小偷，其实用来放衣服很不错",
	en = "Wearing this will make you look like a thief, but it's actually great for carrying clothes",
	zht = "背著這個東西看起來就會像小偷，其實用來放衣服很不錯",
}
LocalizationConfig["loc_ItemDes_219"] =
{
	zh = "中间有个环的手杖，看起来可以发射激光什么的",
	en = "A scepter with a ring in the middle of it that looks like it can shoot lasers and such",
	zht = "中間有個環的手杖，看起來可以發射鐳射什麼的",
}
LocalizationConfig["loc_ItemDes_220"] =
{
	zh = "拥有神秘力量的蓝色宝石，从外表观察应该很有分量，实际可以悬浮在空中，看不到任何接缝",
	en = "A blue gem with mysterious powers, it looks like it must have great power from the looks of it. It's actually able to float in mid-air without anything holding it up",
	zht = "擁有神秘力量的藍色寶石，從外表觀察應該很有分量，實際可以懸浮在空中，看不到任何接縫",
}
LocalizationConfig["loc_ItemDes_221"] =
{
	zh = "没有藏宝图，你根本不知道找不到宝藏是没有地图的错",
	en = "Without a map, you wouldn't know that the reason you're not able to find the treasure is because of not having a map",
	zht = "沒有藏寶圖，你根本不知道找不到寶藏是沒有地圖的錯",
}
LocalizationConfig["loc_ItemDes_222"] =
{
	zh = "33.333333%的微笑",
	en = "33.333333% smiles",
	zht = "33.333333%的微笑",
}
LocalizationConfig["loc_ItemDes_223"] =
{
	zh = "若隐若现，看不到的永远是最令人心动的",
	en = "Partially hidden underneath, not being able to see the whole thing will always make people feel charmed",
	zht = "若隱若現，看不到的永遠是最令人心動的",
}
LocalizationConfig["loc_ItemDes_224"] =
{
	zh = "作者给这位女神留下了一封信，上面写着如何保持神秘微笑的方法，这个方法让这位女神500年来人气一直不跌。",
	en = "The writer has left a letter to this beauty explaining the way to keep a mysterious smile, this method has already made this woman enjoy 500 years of popularity.",
	zht = "作者給這位女神留下了一封信，上面寫著如何保持神秘微笑的方法，這個方法讓這位女神500年來人氣一直不跌。",
}
LocalizationConfig["loc_ItemDes_225"] =
{
	zh = "小小的魔术帽里藏了一片玫瑰花田",
	en = "There's a field of roses hidden in this magician's hat",
	zht = "小小的魔術帽裡藏了一片玫瑰花田",
}
LocalizationConfig["loc_ItemDes_226"] =
{
	zh = "魔术里必不可少的道具，既浪漫又有气氛",
	en = "A must-have item for magic tricks, it's both romantic and atmospheric",
	zht = "魔術裡必不可少的道具，既浪漫又有氣氛",
}
LocalizationConfig["loc_ItemDes_227"] =
{
	zh = "看起来是预告信，其实全是写给微笑女神的情书",
	en = "It looks like a letter of warning, but it's actually a love letter written to Mona",
	zht = "看起來是預告信，其實全是寫給微笑女神的情書",
}
LocalizationConfig["loc_ItemDes_228"] =
{
	zh = "为了让魔术表演避免失误而特意研制出来的眼镜，带着又帅气又实用。",
	en = "A monocle specially developed to prevent any mishaps during magic acts, it's both useful and charming at the same time.",
	zht = "為了讓魔術表演避免失誤而特意研製出來的眼鏡，帶著又帥氣又實用。",
}
LocalizationConfig["loc_ItemDes_229"] =
{
	zh = "有着神秘优美曲线的手杖。一定来自某种失落的高深文明",
	en = "A cane with a mysterious and beautiful bend in it. It must come from some sort of lost civilization",
	zht = "有著神秘優美曲線的手杖。一定來自某種失落的高深文明",
}
LocalizationConfig["loc_ItemDes_230"] =
{
	zh = "朴实的小方帽，谁戴都会感觉高了一阶",
	en = "A durable square cap, whoever wears it will feel a level higher",
	zht = "樸實的小方帽，誰戴都會感覺高了一階",
}
LocalizationConfig["loc_ItemDes_231"] =
{
	zh = "背着这个东西看起来就会像小偷，其实用来放衣服很不错",
	en = "Wearing this will make you look like a thief, but it's actually great for carrying clothes",
	zht = "背著這個東西看起來就會像小偷，其實用來放衣服很不錯",
}
LocalizationConfig["loc_ItemDes_232"] =
{
	zh = "普普通通的盔甲，配上这把装饰刀，立刻就会变得有气势。",
	en = "The most pedestrian of armor will look much more dignified with one of these swords",
	zht = "普普通通的盔甲，配上這把裝飾刀，立刻就會變得有氣勢。",
}
LocalizationConfig["loc_ItemDes_233"] =
{
	zh = "装饰华丽，是厉害的人才能使用的奢侈品",
	en = "Majestically adorned, it's a luxury item that's only used by the most talented of people",
	zht = "裝飾華麗，是厲害的人才能使用的奢侈品",
}
LocalizationConfig["loc_ItemDes_234"] =
{
	zh = "对于日本武士来说，粗绳子有很多很多很多很多用途……当然绳子要够粗",
	en = "For samurai, thick ropes have many many many uses……of course this rope's thick enough",
	zht = "對於日本武士來說，粗繩子有很多很多很多很多用途……當然繩子要夠粗",
}
LocalizationConfig["loc_ItemDes_235"] =
{
	zh = "乍看像一把菜刀，其实是非常实用的手杖，握起来非常舒服绝对不会掉",
	en = "It looks a little like a vegetable knife, but it's actually a really useful rod. It's extremely comfortable to old, there's no chance you'd drop it",
	zht = "乍看像一把菜刀，其實是非常實用的手杖，握起來非常舒服絕對不會掉",
}
LocalizationConfig["loc_ItemDes_236"] =
{
	zh = "这个耳朵采用超强磁吸接口，随便拿随便放，又不容易掉下来",
	en = "These ears have powerful magnetic connectors. Pick them up and place them wherever you want, they won't fall off easily",
	zht = "這個耳朵採用超強磁吸介面，隨便拿隨便放，又不容易掉下來",
}
LocalizationConfig["loc_ItemDes_237"] =
{
	zh = "看起来像奶嘴的手杖，为什么这么短呢，引人深思",
	en = "A scepter that looks a little like a pacifier, why is it so short? It make you think……",
	zht = "看起來像奶嘴的手杖，為什麼這麼短呢，引人深思",
}
LocalizationConfig["loc_ItemDes_238"] =
{
	zh = "正版的帽子是用黄金做的，不过有看到用玉米山寨的，是不是太省钱了",
	en = "Real gold hats are made from solid gold, but this looks like a counterfeit made from corn, isn't that a little too cheap?",
	zht = "正版的帽子是用黃金做的，不過有看到用玉米山寨的，是不是太省錢了",
}
LocalizationConfig["loc_ItemDes_239"] =
{
	zh = "神秘又古老的布条，为了防晒可以用它包裹全身",
	en = "An ancient and mysterious strip of cloth, you can wrap yourself up in it to stop yourself from getting sunburn",
	zht = "神秘又古老的布條，為了防曬可以用它包裹全身",
}
LocalizationConfig["loc_ItemDes_240"] =
{
	zh = "是一种很安全的添加剂，不知道吃了之后会不会永葆青春呢。",
	en = "It's a really safe additive, who knows, once you've eaten it you may even keep young forever.",
	zht = "是一種很安全的添加劑，不知道吃了之後會不會永葆青春呢。",
}
LocalizationConfig["loc_ItemDes_241"] =
{
	zh = "一位钟爱静物组的艺术家画了很多版本",
	en = "A still-life painter has painted many different versions of it",
	zht = "一位鍾愛靜物組的藝術家畫了很多版本",
}
LocalizationConfig["loc_ItemDes_242"] =
{
	zh = "你看到的星空只是星空，而他看到的星空是流动的银河",
	en = "When you look at the starry night sky, all you see is stars. But when he looks at it, he sees galaxies in full motion",
	zht = "你看到的星空只是星空，而他看到的星空是流動的銀河",
}
LocalizationConfig["loc_ItemDes_243"] =
{
	zh = "这个世界有太多不理解不认同的声音，干脆拿掉这只耳朵，这样世界就变得安静了很多。",
	en = "This world has so many different sounds that people don't understand or agree with, may as well cut one off and make the world much more peaceful",
	zht = "這個世界有太多不理解不認同的聲音，乾脆拿掉這只耳朵，這樣世界就變得安靜了很多。",
}
LocalizationConfig["loc_ItemDes_244"] =
{
	zh = "少女戴上珍珠耳环的那一刻注定会成为一幅名画",
	en = "The moment that girl put on this pearl earring, she was destined to become a famous painting",
	zht = "少女戴上珍珠耳環的那一刻註定會成為一幅名畫",
}
LocalizationConfig["loc_ItemDes_245"] =
{
	zh = "原本是一块非常普通的头巾，但在被少女包在头上以后有了不一样的美感。",
	en = "It was originally a completely normal turban, but after the girl put it on, it had a special beauty to it",
	zht = "原本是一塊非常普通的頭巾，但在被少女包在頭上以後有了不一樣的美感。",
}
LocalizationConfig["loc_ItemDes_246"] =
{
	zh = "乐谱上只有一些简单的音符和，跟着唱起来有种忐忑的感觉。",
	en = "The sheet music just has some simple notation, singing them gives you an easy feeling.",
	zht = "樂譜上只有一些簡單的音符和，跟著唱起來有種忐忑的感覺。",
}
LocalizationConfig["loc_ItemDes_247"] =
{
	zh = "纯黑的衬衫，穿上直接变成黑衣人",
	en = "A pure black shirt, after wearing it you instantly become a man in black",
	zht = "純黑的襯衫，穿上直接變成黑衣人",
}
LocalizationConfig["loc_ItemDes_248"] =
{
	zh = "在古老的东方，这种调料非常厉害，能把任何食物做成同一种味道。",
	en = "In the ancient east, this condiment is extremely great, it give any food the exact same flavor",
	zht = "在古老的東方，這種調料非常厲害，能把任何食物做成同一種味道。",
}
LocalizationConfig["loc_ItemDes_249"] =
{
	zh = "纯金打造的印章，曾经不小心掉到脚上导致骨折",
	en = "A seal made of pure gold, I accidentally broke my foot once when I dropped it on it",
	zht = "純金打造的印章，曾經不小心掉到腳上導致骨折",
}
LocalizationConfig["loc_ItemDes_250"] =
{
	zh = "点石可以成金，肋骨可以变人。远古的化学和生物技术都非常先进呢",
	en = "Turn a stone to gold in a touch, turn a rib to a person in a touch Ancient biochemical technology was really advanced",
	zht = "點石可以成金，肋骨可以變人。遠古的化學和生物技術都非常先進呢",
}
LocalizationConfig["loc_ItemDes_251"] =
{
	zh = "曾经是用来投掷的矛，石头被磨光滑了就可以拿来当手杖，敲人威力仍在",
	en = "It used to be thrown as a spear, after smoothing and polishing the stone, it can be used as a rod to whack people with",
	zht = "曾經是用來投擲的矛，石頭被磨光滑了就可以拿來當手杖，敲人威力仍在",
}
LocalizationConfig["loc_ItemDes_252"] =
{
	zh = "化石恒久远，一颗永流传",
	en = "A fossil from the distant past, a single fossil can last forever",
	zht = "化石恒久遠，一顆永流傳",
}
LocalizationConfig["loc_ItemDes_253"] =
{
	zh = "这个肉腿放了几千年，却还是那么的诱人。不过真咬下去的话，牙齿估计会哭",
	en = "This leg of ham has sat around for thousands of years, but it still looks just as tasty. But don't try and bite it if you want to keep your teeth",
	zht = "這個肉腿放了幾千年，卻還是那麼的誘人。不過真咬下去的話，牙齒估計會哭",
}
LocalizationConfig["loc_ItemDes_254"] =
{
	zh = "虽然现在已经不流行把鲜花戴在头上当做装饰了，但某位艺术家还是很热衷这种打扮。",
	en = "Although it's not a popular look anymore, there is still an artist who loves dressing this way.",
	zht = "雖然現在已經不流行把鮮花戴在頭上當做裝飾了，但某位藝術家還是很熱衷這種打扮。",
}
LocalizationConfig["loc_ItemDes_255"] =
{
	zh = "很奇怪的眉笔，轻轻一画就特别浓。",
	en = "A chubby eyebrow pencil, it can draw a thick line with just a slight touch",
	zht = "很奇怪的眉筆，輕輕一畫就特別濃。",
}
LocalizationConfig["loc_ItemDes_256"] =
{
	zh = "军人身上的徽章有着多种象征意义。有些骗子也喜欢在自己衣服上放很多徽章，但往往一被问到就傻了眼",
	en = "Medals on the uniforms of soldiers can represent all sorts of different things. There are also some swindlers who like to place medals on their own clothes, but as soon as they're asked about them, they don't know how to respond.",
	zht = "軍人身上的徽章有著多種象徵意義。有些騙子也喜歡在自己衣服上放很多徽章，但往往一被問到就傻了眼",
}
LocalizationConfig["loc_ItemDes_257"] =
{
	zh = "放了很多年的火枪，基本只能做装饰和威吓用，从来没放进去过子弹，也不知道应该用什么子弹",
	en = "A flintlock pistol that's been lying around for many years, it can basically only be used as decoration or to scare people. It's never been loaded, and no one knows what bullets it uses anyway",
	zht = "放了很多年的火槍，基本只能做裝飾和威嚇用，從來沒放進去過子彈，也不知道應該用什麼子彈",
}
LocalizationConfig["loc_ItemDes_258"] =
{
	zh = "本来是饺子形状的包包，某天下雨天顶在头上之后发现效果出奇的好",
	en = "Originally a semi-circle-shaped bag, someone put in on their head one day when it was raining and discovered that it was actually extremely effective",
	zht = "本來是餃子形狀的包包，某天下雨天頂在頭上之後發現效果出奇的好",
}
LocalizationConfig["loc_ItemDes_259"] =
{
	zh = "男女皆可使用",
	en = "A unisex pair of insoles that can boost your size",
	zht = "男女皆可使用",
}
LocalizationConfig["loc_ItemDes_260"] =
{
	zh = "铅笔削尖了也是厉害的武器，喜欢转笔的同学可要小心",
	en = "A sharp pencil is also a powerful weapon, be careful when spinning it around your fingers",
	zht = "鉛筆削尖了也是厲害的武器，喜歡轉筆的同學可要小心",
}
LocalizationConfig["loc_ItemDes_261"] =
{
	zh = "普普通通的胶带，却是制造各种密室的好帮手",
	en = "An ordinary roll of tape, it's a great help for making secret chambers",
	zht = "普普通通的膠帶，卻是製造各種密室的好幫手",
}
LocalizationConfig["loc_ItemDes_262"] =
{
	zh = "一根头发就能包含很多信息，这一大撮头发，怕是假发",
	en = "I strand of hair holds a lot of information, but this clump of hair looks like it could be fake",
	zht = "一根頭髮就能包含很多資訊，這一大撮頭髮，怕是假髮",
}
LocalizationConfig["loc_ItemDes_263"] =
{
	zh = "看起来是普通的菜刀，其实是个好证据",
	en = "Looks like a normal vegetable knife, but it's actually a great piece of evidence",
	zht = "看起來是普通的菜刀，其實是個好證據",
}
LocalizationConfig["loc_ItemDes_264"] =
{
	zh = "一个完美的指纹，其实不好获得，不过好在很多时候残缺的也够用了",
	en = "A perfect fingerprint like this isn't easy to come by, but partial ones are often good enough",
	zht = "一個完美的指紋，其實不好獲得，不過好在很多時候殘缺的也夠用了",
}
LocalizationConfig["loc_ItemDes_265"] =
{
	zh = "据称百分之90的神秘人都在照片里有迹可循",
	en = "Apparently, 90% of mysterious people can be seen in photos",
	zht = "據稱百分之90的神秘人都在照片裡有跡可循",
}
LocalizationConfig["loc_ItemDes_266"] =
{
	zh = "据说有人喜欢划火柴的声音，有人喜欢划火柴的味道，呲啦一声，回味无穷",
	en = "It's said that some people like the sound of a striking match, others like the smell of a lit match, with a scratch and a crackle, get a load of that great smell",
	zht = "據說有人喜歡劃火柴的聲音，有人喜歡劃火柴的味道，呲啦一聲，回味無窮",
}
LocalizationConfig["loc_ItemDes_267"] =
{
	zh = "绳子里再穿钢丝，嘿嘿嘿",
	en = "This rope has been reinforced with steel wire, yeah!",
	zht = "繩子裡再穿鋼絲，嘿嘿嘿",
}
LocalizationConfig["loc_ItemDes_268"] =
{
	zh = "这么漂亮的假指甲，哪里有的做？",
	en = "Such a beautiful false nail, where are these from?",
	zht = "這麼漂亮的假指甲，哪裡有的做？",
}
LocalizationConfig["loc_ItemDes_269"] =
{
	zh = "上面有微妙的裂痕，但是人像居然维持完整",
	en = "There's a small crack in it, but the person in it seems to still be complete",
	zht = "上面有微妙的裂痕，但是人像居然維持完整",
}
LocalizationConfig["loc_ItemDes_270"] =
{
	zh = "实在无法想象为什么凶手会留下如此明显的痕迹",
	en = "I really have no idea why this mysterious person would leave such a clear trace",
	zht = "實在無法想像為什麼凶手會留下如此明顯的痕跡",
}
LocalizationConfig["loc_ItemDes_271"] =
{
	zh = "带上也许就变成了另一个人哦",
	en = "If you wear it you might turn into someone else",
	zht = "帶上也許就變成了另一個人哦",
}
LocalizationConfig["loc_ItemDes_272"] =
{
	zh = "看起来刚刚点燃过的样子，要不要追呢",
	en = "It looks like this cigarette has just been stubbed out, maybe you should try and catch up with whoever smoked it",
	zht = "看起來剛剛點燃過的樣子，要不要追呢",
}
LocalizationConfig["loc_ItemDes_273"] =
{
	zh = "上面密密麻麻写着很多名字，时间",
	en = "There are lots of names and times scrawled in it",
	zht = "上面密密麻麻寫著很多名字，時間",
}
LocalizationConfig["loc_ItemDes_274"] =
{
	zh = "小小的硬币是变魔术的基础",
	en = "Small coins like this are the basis of magic tricks",
	zht = "小小的硬幣是變魔術的基礎",
}
LocalizationConfig["loc_ItemDes_275"] =
{
	zh = "用来练习瞄准的最简单的玩具",
	en = "The simplest toy for practicing aiming",
	zht = "用來練習瞄準的最簡單的玩具",
}
LocalizationConfig["loc_ItemDes_276"] =
{
	zh = "人手一个，用来寻找线索的基本工具",
	en = "Held with one hand, its one of the basic tools for searching for clues",
	zht = "人手一個，用來尋找線索的基本工具",
}
LocalizationConfig["loc_ItemDes_277"] =
{
	zh = "撕起来方便很多的无敌胶带",
	en = "The greatest kind of tape, it's much more easy to tear",
	zht = "撕起來方便很多的無敵膠帶",
}
LocalizationConfig["loc_ItemDes_278"] =
{
	zh = "对着手表问现在几点，过一会儿就会显示出时间",
	en = "Ask the watch the time and it'll show you after a short time",
	zht = "對著手錶問現在幾點，過一會兒就會顯示出時間",
}
LocalizationConfig["loc_ItemDes_279"] =
{
	zh = "细如发丝，坚如……钢丝",
	en = "Fine, durable…….and made of wire",
	zht = "細如髮絲，堅如……鋼絲",
}
LocalizationConfig["loc_ItemDes_280"] =
{
	zh = "经过特殊处理的三文鱼干，吃起来就和吃新鲜刺身一般美味，还有各种味道可以选择哦",
	en = "Specially processed dried salmon, it still tastes just like the fresh kind, there's also a variety of flavors to choose from",
	zht = "經過特殊處理的三文魚幹，吃起來就和吃新鮮刺身一般美味，還有各種味道可以選擇哦",
}
LocalizationConfig["loc_ItemDes_281"] =
{
	zh = "由薛定谔的喵研究的量子通讯电话。实现了超越光速的通信。喵星科技，以喵为本",
	en = "A quantum communications phone invented by Schrodinger's cat It can send messages faster than the speed of light. Kitty technology; designed by cats, for cats",
	zht = "由薛定諤的喵研究的量子通訊電話。實現了超越光速的通信。喵星科技，以喵為本",
}
LocalizationConfig["loc_ItemDes_282"] =
{
	zh = "统一宇宙的游戏机，支持全平台的各种大作，首发护航游戏一条命3",
	en = "A universal games console, it supports all sorts of famous titles from all platforms, the first game released is Whole Life 3",
	zht = "統一宇宙的遊戲機，支持全平臺的各種大作，首發護航遊戲一條命3",
}
LocalizationConfig["loc_ItemDes_283"] =
{
	zh = "很好用的防身武器，打中必然晕倒。",
	en = "A great self-defense weapon, whoever hit by it will fall to the floor stunned",
	zht = "很好用的防身武器，打中必然暈倒。",
}
LocalizationConfig["loc_ItemDes_284"] =
{
	zh = "你有权保持沉默，不过你所说的一切都会成为呈堂证供",
	en = "You have the right to remain silent, anything you do say can and will be given as evidence in a court of law",
	zht = "你有權保持沉默，不過你所說的一切都會成為呈堂證供",
}
LocalizationConfig["loc_ItemDes_285"] =
{
	zh = "这个真不是娱乐道具，另外娱乐到兴头上钥匙找不到了也是很麻烦的，别问我怎么知道的",
	en = "These really aren't a toy, if you play with these and lose the key you'll be in a whole heap of trouble. Don't ask me how I know this",
	zht = "這個真不是娛樂道具，另外娛樂到興頭上鑰匙找不到了也是很麻煩的，別問我怎麼知道的",
}
LocalizationConfig["loc_ItemDes_286"] =
{
	zh = "看起来是普通木头做的拐杖，里面可能暗藏机关",
	en = "A walking stick that seems to be made from common wood, maybe there's a special device hidden inside",
	zht = "看起來是普通木頭做的拐杖，裡面可能暗藏機關",
}
LocalizationConfig["loc_ItemDes_287"] =
{
	zh = "气势很吓人，关键时候没什么用。",
	en = "It looks pretty scary but is useless when it comes down to it.",
	zht = "氣勢很嚇人，關鍵時候沒什麼用。",
}
LocalizationConfig["loc_ItemDes_288"] =
{
	zh = "上面写着吸烟有害健康，打开里面什么都没有",
	en = "It says that smoking is damaging to your health, but you still feel fine after opening the pack",
	zht = "上面寫著吸煙有害健康，打開裡面什麼都沒有",
}
LocalizationConfig["loc_ItemDes_289"] =
{
	zh = "绿色贝雷帽加战斗力，红色贝雷帽加书生气",
	en = "Green buries increase combat ability, red ones increase your pretentiousness",
	zht = "綠色貝雷帽加戰鬥力，紅色貝雷帽加書生氣",
}
LocalizationConfig["loc_ItemDes_290"] =
{
	zh = "每造一副眼镜，就有2瓶啤酒被喝掉！保护视力，关爱啤酒肚",
	en = "For each pair of glasses made, 2 bottles of beer are drank! Protect your eyesight and love your beer belly",
	zht = "每造一副眼鏡，就有2瓶啤酒被喝掉！保護視力，關愛啤酒肚",
}
LocalizationConfig["loc_ItemDes_291"] =
{
	zh = "每天拆快递都靠这把手术刀，直接切开箱子，十分便捷和舒适",
	en = "This scalpel's used every day for opening packages, just cut the box open. Extremely convenient and comfortable to use.",
	zht = "每天拆快遞都靠這把手術刀，直接切開箱子，十分便捷和舒適",
}
LocalizationConfig["loc_ItemDes_292"] =
{
	zh = "看到医生做手术拿锤子就害怕？那你可要当心保护好自己不要受伤",
	en = "Does seeing a doctor using a hammer to perform surgery scare you? You best make sure you don't need a trip to the operating theater then",
	zht = "看到醫生做手術拿錘子就害怕？那你可要當心保護好自己不要受傷",
}
LocalizationConfig["loc_ItemDes_293"] =
{
	zh = "吸烟有害健康！只吸烟斗的话可以考虑",
	en = "Smoking is bad for your health! But if it's a pipe, I'll think about it",
	zht = "吸煙有害健康！只吸煙鬥的話可以考慮",
}
LocalizationConfig["loc_ItemDes_294"] =
{
	zh = "带上之后感觉会变聪明一点",
	en = "Wearing this makes you feel a bit smarter",
	zht = "帶上之後感覺會變聰明一點",
}
LocalizationConfig["loc_ItemDes_295"] =
{
	zh = "学小提琴是很痛苦的，主要是楼上楼下的人痛苦",
	en = "Learning the violin is really painful, your neighbors' ears are the ones who feel the most pain of all",
	zht = "學小提琴是很痛苦的，主要是樓上樓下的人痛苦",
}
LocalizationConfig["loc_ItemDes_296"] =
{
	zh = "又称鄂伦麦尔瓶，一种化学实验室常见的玻璃仪器。",
	en = "Also known as an Erlenmeyer flask, it's a common glass instrument found in chemistry labs.",
	zht = "又稱鄂倫麥爾瓶，一種化學實驗室常見的玻璃儀器。",
}
LocalizationConfig["loc_ItemDes_297"] =
{
	zh = "要优雅，就要带这种长柄伞。可攻可守千变万化",
	en = "If you want to look elegant, you should carry this umbrella. It can be used to both attack and defend",
	zht = "要優雅，就要帶這種長柄傘。可攻可守千變萬化",
}
LocalizationConfig["loc_ItemDes_298"] =
{
	zh = "可以连接到各种摄像头的监视器，并能补足其他信息",
	en = "A monitor that can connect to all sorts of cameras and can fill in other information",
	zht = "可以連接到各種攝像頭的監視器，並能補足其他資訊",
}
LocalizationConfig["loc_ItemDes_299"] =
{
	zh = "真相永远只有一个！结局永远不会来临！",
	en = "There's only ever one truth! The end will never come!",
	zht = "真相永遠只有一個！結局永遠不會來臨！",
}
LocalizationConfig["loc_ItemDes_300"] =
{
	zh = "立竿见影又无毒无副作用的瞌睡针，醒来以后绝对不会发现自己刚刚睡着了",
	en = "A sleeping needle that instantly works and doesn't contain poison or negative side effects, one you wake up, you won't even realize that you were just sleeping",
	zht = "立竿見影又無毒無副作用的瞌睡針，醒來以後絕對不會發現自己剛剛睡著了",
}
LocalizationConfig["loc_ItemDes_301"] =
{
	zh = "可以让小学生直接变身为热血运动漫画主角的神奇道具。小翼同学很想试一试这个球鞋",
	en = "Magical shoes that turn elementary school kids into hot-blooded sporty anime characters. Jane would love to try these shoes",
	zht = "可以讓小學生直接變身為熱血運動漫畫主角的神奇道具。小翼同學很想試一試這個球鞋",
}
LocalizationConfig["loc_ItemDes_302"] =
{
	zh = "带有神秘涂层的皮衣，几乎没有反光，动起来也不会发出声音",
	en = "A leather jacket that has a mysterious layer of coating, it almost doesn't reflect any light and wearers won't make any noise when moving",
	zht = "帶有神秘塗層的皮衣，幾乎沒有反光，動起來也不會發出聲音",
}
LocalizationConfig["loc_ItemDes_303"] =
{
	zh = "非常方便的小锤子，出现于在各种场合，敲一敲听一听就知道瓷砖贴的好不好",
	en = "A really convenient little hammer that's useful in all sorts of different situations. You can knock of pottery with it to check its quality",
	zht = "非常方便的小錘子，出現於在各種場合，敲一敲聽一聽就知道瓷磚貼的好不好",
}
LocalizationConfig["loc_ItemDes_304"] =
{
	zh = "找到关键道具！这就是传说中解开谜团的道具了。",
	en = "Found the key item! This is the legendary item used to unravel the mystery.",
	zht = "找到關鍵道具！這就是傳說中解開謎團的道具了。",
}
LocalizationConfig["loc_ItemDes_305"] =
{
	zh = "身上有伤就来一块，贴的不当心的话，撕掉的时候可是很可怕哦",
	en = "Stick one on your wound, but if you're not careful when sticking it on, it will be really painful to take back off",
	zht = "身上有傷就來一塊，貼的不當心的話，撕掉的時候可是很可怕哦",
}
LocalizationConfig["loc_ItemDes_306"] =
{
	zh = "穿上以后你就再也看不见我了。",
	en = "Once I put this on, you'll never see me again.",
	zht = "穿上以後你就再也看不見我了。",
}
LocalizationConfig["loc_ItemDes_307"] =
{
	zh = "看起来很暖和的围巾，关键时刻可以触发必杀",
	en = "A scarf that looks warm and cozy, it can also trigger an ultimate skill at the key moment",
	zht = "看起來很暖和的圍巾，關鍵時刻可以觸發必殺",
}
LocalizationConfig["loc_ItemDes_308"] =
{
	zh = "掏出这张纸，立刻变成局外人",
	en = "Present this piece of paper to instantly become ruled out as a suspect",
	zht = "掏出這張紙，立刻變成局外人",
}
LocalizationConfig["loc_ItemDes_309"] =
{
	zh = "输液的时候总是很担心空气进去，然而看着滴滴答答一会儿就睡着了",
	en = "When getting an IV, people are always worried about air getting in, but after watching it drip a short while they fall asleep",
	zht = "輸液的時候總是很擔心空氣進去，然而看著滴滴答答一會兒就睡著了",
}
LocalizationConfig["loc_ItemDes_310"] =
{
	zh = "高阶神秘人用来隐藏身份的道具，只有少数人才会使用",
	en = "Top-rate mysterious persons use it to hide their identity, only a few people are able to use this item",
	zht = "高階神秘人用來隱藏身份的道具，只有少數人才會使用",
}
LocalizationConfig["loc_ItemDes_311"] =
{
	zh = "不同于萨姆大叔的夜视仪，适合平时出门携带的太阳镜",
	en = "Different from Sam Fisher's night vision goggles, these are shades that you can take with you wherever you go",
	zht = "不同于薩姆大叔的夜視儀，適合平時出門攜帶的太陽鏡",
}
LocalizationConfig["loc_ItemDes_312"] =
{
	zh = "阴谋诡计并不可怕，可怕的是人心的动摇",
	en = "Tricks and schemes aren't scary, what's scary is fear itself",
	zht = "陰謀詭計並不可怕，可怕的是人心的動搖",
}
LocalizationConfig["loc_ItemDes_313"] =
{
	zh = "充满了悲伤的气息，也许在这封信里能找到一些关键信息。",
	en = "A melancholic letter, maybe it has some crucial information written in it.",
	zht = "充滿了悲傷的氣息，也許在這封信裡能找到一些關鍵資訊。",
}
LocalizationConfig["loc_ItemDes_314"] =
{
	zh = "法律考试之所以那么难，和里面条条框框的复杂性有着相当的关系，能背出来这么厚一本书的都不是普通人",
	en = "The reason why law exams are so hard is because of all the complex nature of all the articles, lines, stipulations and addendums included in this book. No normal person is able to memorize all the information contained in this giant book.",
	zht = "法律考試之所以那麼難，和裡面條條框框的複雜性有著相當的關係，能背出來這麼厚一本書的都不是普通人",
}
LocalizationConfig["loc_ItemDes_315"] =
{
	zh = "训练猫咪的利器，不把毛线卷好可没有饭吃",
	en = "A great item for training kitties, if you don't roll it back up properly you won't have any dinner",
	zht = "訓練貓咪的利器，不把毛線卷好可沒有飯吃",
}
LocalizationConfig["loc_ItemDes_316"] =
{
	zh = "拥有神奇魔力的咖啡，谁喝了都会想要再来一杯",
	en = "Magical coffee, whoever drinks it will always want another cup",
	zht = "擁有神奇魔力的咖啡，誰喝了都會想要再來一杯",
}
LocalizationConfig["loc_ItemDes_317"] =
{
	zh = "各大漫画英雄用来推进剧情的关键字。",
	en = "A key word used by comic book heroes to progress the story.",
	zht = "各大漫畫英雄用來推進劇情的關鍵字。",
}
LocalizationConfig["loc_ItemDes_318"] =
{
	zh = "维持一个好的发型真的不容易，一个月30瓶发胶的开销也蛮大的",
	en = "It's not easy to maintain a good hairstyle, 30 bottles of hair gel per month is expensive though",
	zht = "維持一個好的髮型真的不容易，一個月30瓶髮膠的開銷也蠻大的",
}
LocalizationConfig["loc_ItemDes_319"] =
{
	zh = "国际象棋曾是一个很好的智力锻炼活动，后来变成训练人工智能的工具",
	en = "Chess used to be a great way to exercise peoples' intelligence, it later became a tool used to train AI machines",
	zht = "國際象棋曾是一個很好的智力鍛煉活動，後來變成訓練人工智慧的工具",
}
LocalizationConfig["loc_ItemDes_320"] =
{
	zh = "自带残影的调酒杯，盯着看说不定会被催眠",
	en = "A stained cocktail shaker, if you stare at it a while, you may be hypnotized",
	zht = "自帶殘影的調酒杯，盯著看說不定會被催眠",
}
LocalizationConfig["loc_ItemDes_321"] =
{
	zh = "看起来平淡无奇的扳手，实际都是纳米变形结构，用起来非常顺手",
	en = "It looks like just a regular spanner, but in fact its got a Nano deformed structure making it really easy to use",
	zht = "看起來平淡無奇的扳手，實際都是納米變形結構，用起來非常順手",
}
LocalizationConfig["loc_ItemDes_322"] =
{
	zh = "主要用来进行各种攀爬作业，不要想太多",
	en = "Mainly used for all sorts of climbing activities, get those other ideas out your head",
	zht = "主要用來進行各種攀爬作業，不要想太多",
}
LocalizationConfig["loc_CostumeSuit_Original_1"] =
{
	zh = "呜呜初始",
	en = "Count Mews",
	zht = "嗚嗚初始",
}
LocalizationConfig["loc_CostumeSuit_Original_2"] =
{
	zh = "咕咕初始",
	en = "Salem",
	zht = "咕咕初始",
}
LocalizationConfig["loc_CostumeSuit_Original_3"] =
{
	zh = "剑士初始",
	en = "Swordsman",
	zht = "劍士初始",
}
LocalizationConfig["loc_CostumeSuit_Original_4"] =
{
	zh = "猎人初始",
	en = "Hunter",
	zht = "獵人初始",
}
LocalizationConfig["loc_CostumeSuit_Original_5"] =
{
	zh = "部落老大初始",
	en = "Chieftain",
	zht = "部落老大初始",
}
LocalizationConfig["loc_CostumeSuit_Original_6"] =
{
	zh = "弓箭手初始",
	en = "Archer",
	zht = "弓箭手初始",
}
LocalizationConfig["loc_CostumeSuit_Original_7"] =
{
	zh = "小小弟初始",
	en = "Disciple",
	zht = "小小弟初始",
}
LocalizationConfig["loc_CostumeSuit_Original_8"] =
{
	zh = "射鸡师初始",
	en = "Designer",
	zht = "射雞師初始",
}
LocalizationConfig["loc_CostumeSuit_Original_9"] =
{
	zh = "牧师初始",
	en = "Cleric",
	zht = "牧師初始",
}
LocalizationConfig["loc_CostumeSuit_Original_10"] =
{
	zh = "大魔王初始",
	en = "Dark Lord",
	zht = "大魔王初始",
}
LocalizationConfig["loc_CostumeSuit_Original_11"] =
{
	zh = "魔法师初始",
	en = "Mage",
	zht = "魔法師初始",
}
LocalizationConfig["loc_CostumeSuit_Original_12"] =
{
	zh = "扫地僧初始",
	en = "Chore Monk",
	zht = "掃地僧初始",
}
LocalizationConfig["loc_CostumeSuit_Original_13"] =
{
	zh = "老爷爷初始",
	en = "Old Geezer",
	zht = "老爺爺初始",
}
LocalizationConfig["loc_CostumeSuit_Original_14"] =
{
	zh = "女王大人初始",
	en = "Queenie",
	zht = "女王大人初始",
}
LocalizationConfig["loc_CostumeSuit_Original_15"] =
{
	zh = "老奶奶初始",
	en = "Granny",
	zht = "老奶奶初始",
}
LocalizationConfig["loc_CostumeSuit_Original_16"] =
{
	zh = "普通居民初始",
	en = "Resident",
	zht = "普通居民初始",
}
LocalizationConfig["loc_CostumeSuit_Original_17"] =
{
	zh = "异虫霸格初始",
	en = "System Bug",
	zht = "異蟲霸格初始",
}
LocalizationConfig["loc_CostumeSuit_Original_18"] =
{
	zh = "除虫者初始",
	en = "Debugger",
	zht = "除蟲者初始",
}
LocalizationConfig["loc_CostumeSuit_Original_19"] =
{
	zh = "城镇卫兵初始",
	en = "City Guard",
	zht = "城鎮衛兵初始",
}
LocalizationConfig["loc_CostumeSuit_Original_20"] =
{
	zh = "木偶师初始",
	en = "Puppeteer",
	zht = "木偶師初始",
}
LocalizationConfig["loc_CostumeSuit_Original_21"] =
{
	zh = "骨头兵初始",
	en = "Skeleton",
	zht = "骨頭兵初始",
}
LocalizationConfig["loc_CostumeSuit_Original_22"] =
{
	zh = "程序猿初始",
	en = "Programmer",
	zht = "程式猿初始",
}
LocalizationConfig["loc_CostumeSuit_Original_23"] =
{
	zh = "原画妹子初始",
	en = "Paintress",
	zht = "原畫妹子初始",
}
LocalizationConfig["loc_CostumeSuit_Original_24"] =
{
	zh = "旅行商人初始",
	en = "Merchant",
	zht = "旅行商人初始",
}
LocalizationConfig["loc_CostumeSuit_Original_25"] =
{
	zh = "配音演员初始",
	en = "Dubber",
	zht = "配音演員初始",
}
LocalizationConfig["loc_CostumeSuit_Original_26"] =
{
	zh = "异世界画家初始",
	en = "Virtuoso",
	zht = "異世界畫家初始",
}
LocalizationConfig["loc_CostumeSuit_Original_27"] =
{
	zh = "火枪手初始",
	en = "Musketeer",
	zht = "火槍手初始",
}
LocalizationConfig["loc_CostumeSuit_Original_28"] =
{
	zh = "调音师初始",
	en = "DJ",
	zht = "調音師初始",
}
LocalizationConfig["loc_CostumeSuit_Original_29"] =
{
	zh = "刺客初始",
	en = "Assassin",
	zht = "刺客初始",
}
LocalizationConfig["loc_CostumeSuit_Original_30"] =
{
	zh = "小魔王初始",
	en = "Dark Chief",
	zht = "小魔王初始",
}
LocalizationConfig["loc_CostumeSuit_Original_31"] =
{
	zh = "龙骑士初始",
	en = "Dragoon",
	zht = "龍騎士初始",
}
LocalizationConfig["loc_CostumeSuit_Original_32"] =
{
	zh = "黑龙王子初始",
	en = "Dark Drago",
	zht = "黑龍王子初始",
}
LocalizationConfig["loc_CostumeSuit_Original_33"] =
{
	zh = "汽水王子初始",
	en = "Soda",
	zht = "汽水王子初始",
}
LocalizationConfig["loc_CostumeSuit_Original_34"] =
{
	zh = "奶茶王子初始",
	en = "Milk Tea",
	zht = "奶茶王子初始",
}
LocalizationConfig["loc_CostumeSuit_Original_35"] =
{
	zh = "小黄初始",
	en = "Lil Yellow",
	zht = "小黃初始",
}
LocalizationConfig["loc_CostumeSuit_Original_36"] =
{
	zh = "番茄酱侍卫初始",
	en = "Ketchup",
	zht = "番茄醬侍衛初始",
}
LocalizationConfig["loc_CostumeSuit_Original_37"] =
{
	zh = "棒棒糖女仆初始",
	en = "Lollipop",
	zht = "棒棒糖女僕初始",
}
LocalizationConfig["loc_CostumeSuit_Original_38"] =
{
	zh = "虾条公主初始",
	en = "Prawn Chip",
	zht = "蝦條公主初始",
}
LocalizationConfig["loc_CostumeSuit_Original_39"] =
{
	zh = "培根女巫初始",
	en = "Bacon",
	zht = "培根女巫初始",
}
LocalizationConfig["loc_CostumeSuit_Original_40"] =
{
	zh = "炸鸡魔后初始",
	en = "Fried Chicken",
	zht = "炸雞魔後初始",
}
LocalizationConfig["loc_CostumeSuit_Original_41"] =
{
	zh = "妙脆角公主初始",
	en = "Bugle",
	zht = "妙脆角公主初始",
}
LocalizationConfig["loc_CostumeSuit_Original_42"] =
{
	zh = "热狗先生初始",
	en = "Mr. Hotdog",
	zht = "熱狗先生初始",
}
LocalizationConfig["loc_CostumeSuit_Original_43"] =
{
	zh = "小绿初始",
	en = "Lil Green",
	zht = "小綠初始",
}
LocalizationConfig["loc_CostumeSuit_Original_44"] =
{
	zh = "可乐王子初始",
	en = "Cola",
	zht = "可樂王子初始",
}
LocalizationConfig["loc_CostumeSuit_Original_45"] =
{
	zh = "小红初始",
	en = "Lil Red",
	zht = "小紅初始",
}
LocalizationConfig["loc_CostumeSuit_Original_46"] =
{
	zh = "小橙初始",
	en = "Lil Orange",
	zht = "小橙初始",
}
LocalizationConfig["loc_CostumeSuit_Original_47"] =
{
	zh = "小蓝初始",
	en = "Lil Blue",
	zht = "小藍初始",
}
LocalizationConfig["loc_CostumeSuit_Original_48"] =
{
	zh = "小青初始",
	en = "Lil Cobalt",
	zht = "小青初始",
}
LocalizationConfig["loc_CostumeSuit_Original_49"] =
{
	zh = "小紫初始",
	en = "Lil Purple",
	zht = "小紫初始",
}
LocalizationConfig["loc_CostumeSuit_Original_50"] =
{
	zh = "棉花糖公主初始",
	en = "Candyfloss",
	zht = "棉花糖公主初始",
}
LocalizationConfig["loc_CostumeSuit_Original_51"] =
{
	zh = "咖啡小姐初始",
	en = "Ms. Coffee",
	zht = "咖啡小姐初始",
}
LocalizationConfig["loc_CostumeSuit_Original_52"] =
{
	zh = "甜筒皇后初始",
	en = "Queen Cone",
	zht = "甜筒皇后初始",
}
LocalizationConfig["loc_CostumeSuit_Original_53"] =
{
	zh = "华夫饼仙子初始",
	en = "Wafflette",
	zht = "華夫餅仙子初始",
}
LocalizationConfig["loc_CostumeSuit_Original_54"] =
{
	zh = "松饼仙子初始",
	en = "Pancakette",
	zht = "松餅仙子初始",
}
LocalizationConfig["loc_CostumeSuit_Original_55"] =
{
	zh = "冰淇淋公主初始",
	en = "Apple",
	zht = "霜淇淋公主初始",
}
LocalizationConfig["loc_CostumeSuit_Original_56"] =
{
	zh = "蛋糕卷公主初始",
	en = "Swiss Roll",
	zht = "蛋糕卷公主初始",
}
LocalizationConfig["loc_CostumeSuit_Original_57"] =
{
	zh = "栗子蛋糕公主初始",
	en = "Chestnut Cake",
	zht = "栗子蛋糕公主初始",
}
LocalizationConfig["loc_CostumeSuit_Original_58"] =
{
	zh = "啤酒王子初始",
	en = "Beer",
	zht = "啤酒王子初始",
}
LocalizationConfig["loc_CostumeSuit_Original_59"] =
{
	zh = "薯片夫人初始",
	en = "Mrs. Chip",
	zht = "薯片夫人初始",
}
LocalizationConfig["loc_CostumeSuit_Original_60"] =
{
	zh = "布丁仙子初始",
	en = "Pudingette",
	zht = "布丁仙子初始",
}
LocalizationConfig["loc_CostumeSuit_Original_61"] =
{
	zh = "汉堡小姐初始",
	en = "Ms. Hammie",
	zht = "漢堡小姐初始",
}
LocalizationConfig["loc_CostumeSuit_Original_62"] =
{
	zh = "薯条国王初始",
	en = "King Fry",
	zht = "薯條國王初始",
}
LocalizationConfig["loc_CostumeSuit_Original_63"] =
{
	zh = "爆米花女王初始",
	en = "Popcorn",
	zht = "爆米花女王初始",
}
LocalizationConfig["loc_CostumeSuit_Original_64"] =
{
	zh = "保安初始",
	en = "Security",
	zht = "保安初始",
}
LocalizationConfig["loc_CostumeSuit_Original_65"] =
{
	zh = "浣熊小弟初始",
	en = "Lil Raccy",
	zht = "浣熊小弟初始",
}
LocalizationConfig["loc_CostumeSuit_Original_66"] =
{
	zh = "阿努比斯初始",
	en = "Anubis",
	zht = "阿努比斯初始",
}
LocalizationConfig["loc_CostumeSuit_Original_67"] =
{
	zh = "中世纪铠甲初始",
	en = "Armor Suit",
	zht = "中世紀鎧甲初始",
}
LocalizationConfig["loc_CostumeSuit_Original_68"] =
{
	zh = "侦探小姐初始",
	en = "Agatha",
	zht = "偵探小姐初始",
}
LocalizationConfig["loc_CostumeSuit_Original_69"] =
{
	zh = "浣熊大哥初始",
	en = "Big Raccy",
	zht = "浣熊大哥初始",
}
LocalizationConfig["loc_CostumeSuit_Original_70"] =
{
	zh = "微笑女神初始",
	en = "Mona",
	zht = "微笑女神初始",
}
LocalizationConfig["loc_CostumeSuit_Original_71"] =
{
	zh = "魔术师初始",
	en = "Kidi",
	zht = "魔術師初始",
}
LocalizationConfig["loc_CostumeSuit_Original_72"] =
{
	zh = "荷鲁斯初始",
	en = "Horus",
	zht = "荷魯斯初始",
}
LocalizationConfig["loc_CostumeSuit_Original_73"] =
{
	zh = "浣熊二哥初始",
	en = "Raccy",
	zht = "浣熊二哥初始",
}
LocalizationConfig["loc_CostumeSuit_Original_74"] =
{
	zh = "创造之神初始",
	en = "Demiurge",
	zht = "創造之神初始",
}
LocalizationConfig["loc_CostumeSuit_Original_75"] =
{
	zh = "日本武士初始",
	en = "Samurai",
	zht = "日本武士初始",
}
LocalizationConfig["loc_CostumeSuit_Original_76"] =
{
	zh = "赛特初始",
	en = "Set",
	zht = "賽特初始",
}
LocalizationConfig["loc_CostumeSuit_Original_77"] =
{
	zh = "索贝克初始",
	en = "Sobek",
	zht = "索貝克初始",
}
LocalizationConfig["loc_CostumeSuit_Original_78"] =
{
	zh = "木乃伊初始",
	en = "Mummy",
	zht = "木乃伊初始",
}
LocalizationConfig["loc_CostumeSuit_Original_79"] =
{
	zh = "兵马俑初始",
	en = "Terracotta",
	zht = "兵馬俑初始",
}
LocalizationConfig["loc_CostumeSuit_Original_80"] =
{
	zh = "默艾初始",
	en = "Moai",
	zht = "默艾初始",
}
LocalizationConfig["loc_CostumeSuit_Original_81"] =
{
	zh = "独耳画像初始",
	en = "Gogh",
	zht = "獨耳畫像初始",
}
LocalizationConfig["loc_CostumeSuit_Original_82"] =
{
	zh = "石柱人初始",
	en = "Pillar Man",
	zht = "石柱人初始",
}
LocalizationConfig["loc_CostumeSuit_Original_83"] =
{
	zh = "半人马石像初始",
	en = "Centaur",
	zht = "半人馬石像初始",
}
LocalizationConfig["loc_CostumeSuit_Original_84"] =
{
	zh = "带耳环的少女初始",
	en = "Meisje",
	zht = "帶耳環的少女初始",
}
LocalizationConfig["loc_CostumeSuit_Original_85"] =
{
	zh = "呐喊家初始",
	en = "Scream",
	zht = "呐喊家初始",
}
LocalizationConfig["loc_CostumeSuit_Original_86"] =
{
	zh = "猪蹄古董初始",
	en = "Pig Foot",
	zht = "豬蹄古董初始",
}
LocalizationConfig["loc_CostumeSuit_Original_87"] =
{
	zh = "亚当初始",
	en = "Adam",
	zht = "亞當初始",
}
LocalizationConfig["loc_CostumeSuit_Original_88"] =
{
	zh = "原始人爸爸初始",
	en = "Cave Dad",
	zht = "原始人爸爸初始",
}
LocalizationConfig["loc_CostumeSuit_Original_89"] =
{
	zh = "原始人妈妈初始",
	en = "Cave Mom",
	zht = "原始人媽媽初始",
}
LocalizationConfig["loc_CostumeSuit_Original_90"] =
{
	zh = "原始人儿子初始",
	en = "Cave Kid",
	zht = "原始人兒子初始",
}
LocalizationConfig["loc_CostumeSuit_Original_91"] =
{
	zh = "哭泣的女人初始",
	en = "Weeper",
	zht = "哭泣的女人初始",
}
LocalizationConfig["loc_CostumeSuit_Original_92"] =
{
	zh = "弗里达初始",
	en = "Frida",
	zht = "弗裡達初始",
}
LocalizationConfig["loc_CostumeSuit_Original_93"] =
{
	zh = "名人蜡像初始",
	en = "Waxwork",
	zht = "名人蠟像初始",
}
LocalizationConfig["loc_CostumeSuit_Original_94"] =
{
	zh = "豆豆警官初始",
	en = "Ploddie",
	zht = "豆豆警官初始",
}
LocalizationConfig["loc_CostumeSuit_Original_95"] =
{
	zh = "侦探助理初始",
	en = "Watsoon",
	zht = "偵探助理初始",
}
LocalizationConfig["loc_CostumeSuit_Original_96"] =
{
	zh = "证人初始",
	en = "Poor Guy",
	zht = "證人初始",
}
LocalizationConfig["loc_CostumeSuit_Original_97"] =
{
	zh = "法医初始",
	en = "Horatio",
	zht = "法醫初始",
}
LocalizationConfig["loc_CostumeSuit_Original_98"] =
{
	zh = "大侦探初始",
	en = "Holmees",
	zht = "大偵探初始",
}
LocalizationConfig["loc_CostumeSuit_Original_99"] =
{
	zh = "迈克罗夫特初始",
	en = "Mycroft",
	zht = "邁克羅夫特初始",
}
LocalizationConfig["loc_CostumeSuit_Original_100"] =
{
	zh = "蓝衣小学生初始",
	en = "Boy Blue",
	zht = "藍衣小學生初始",
}
LocalizationConfig["loc_CostumeSuit_Original_101"] =
{
	zh = "凶手初始",
	en = "Outlaw",
	zht = "兇手初始",
}
LocalizationConfig["loc_CostumeSuit_Original_102"] =
{
	zh = "马夫初始",
	en = "Cabbie",
	zht = "馬夫初始",
}
LocalizationConfig["loc_CostumeSuit_Original_103"] =
{
	zh = "法官初始",
	en = "The Beak",
	zht = "法官初始",
}
LocalizationConfig["loc_CostumeSuit_Original_104"] =
{
	zh = "小泪初始",
	en = "Rui",
	zht = "小淚初始",
}
LocalizationConfig["loc_CostumeSuit_Original_105"] =
{
	zh = "杰克瑞波初始",
	en = "Ripper",
	zht = "傑克瑞波初始",
}
LocalizationConfig["loc_CostumeSuit_Original_106"] =
{
	zh = "报童初始",
	en = "Paper Boy",
	zht = "報童初始",
}
LocalizationConfig["loc_CostumeSuit_Original_107"] =
{
	zh = "读者初始",
	en = "Reader",
	zht = "讀者初始",
}
LocalizationConfig["loc_CostumeSuit_Original_108"] =
{
	zh = "编辑长初始",
	en = "The Editor",
	zht = "編輯長初始",
}
LocalizationConfig["loc_CostumeSuit_Original_109"] =
{
	zh = "小爱初始",
	en = "Ai",
	zht = "小愛初始",
}
LocalizationConfig["loc_CostumeSuit_Original_110"] =
{
	zh = "嫌疑人初始",
	en = "Shady Sam",
	zht = "嫌疑人初始",
}
LocalizationConfig["loc_CostumeSuit_Original_111"] =
{
	zh = "逝者初始",
	en = "Morty",
	zht = "逝者初始",
}
LocalizationConfig["loc_CostumeSuit_Original_112"] =
{
	zh = "律师初始",
	en = "Suity Cid",
	zht = "律師初始",
}
LocalizationConfig["loc_CostumeSuit_Original_113"] =
{
	zh = "房东太太初始",
	en = "Landlady",
	zht = "房東太太初始",
}
LocalizationConfig["loc_CostumeSuit_Original_114"] =
{
	zh = "调酒师初始",
	en = "Bartender",
	zht = "調酒師初始",
}
LocalizationConfig["loc_CostumeSuit_Original_115"] =
{
	zh = "博士初始",
	en = "The Doctor",
	zht = "博士初始",
}
LocalizationConfig["loc_CostumeSuit_Original_116"] =
{
	zh = "小瞳初始",
	en = "Hitomi",
	zht = "小瞳初始",
}
LocalizationConfig["loc_CostumeSuit_Original_117"] =
{
	zh = "倒霉蛋初始",
	en = "Magoo",
	zht = "倒楣蛋初始",
}
LocalizationConfig["loc_CostumeSuit_Original_118"] =
{
	zh = "检察官初始",
	en = "Prosecutor",
	zht = "檢察官初始",
}
LocalizationConfig["loc_CostumeSuit_Original_119"] =
{
	zh = "教授初始",
	en = "The Prof.",
	zht = "教授初始",
}
LocalizationConfig["loc_CostumeSuit_Name_1"] =
{
	zh = "机械咕咕",
	en = "Mecha Salem",
	zht = "機械咕咕",
}
LocalizationConfig["loc_CostumeSuit_Name_2"] =
{
	zh = "机械呜呜",
	en = "Mecha Mews",
	zht = "機械嗚嗚",
}
LocalizationConfig["loc_CostumeSuit_Name_3"] =
{
	zh = "生存不易",
	en = "Hard Survival",
	zht = "生存不易",
}
LocalizationConfig["loc_CostumeSuit_Name_4"] =
{
	zh = "骄傲放纵",
	en = "Proud indulgence",
	zht = "驕傲放縱",
}
LocalizationConfig["loc_CostumeSuit_Name_5"] =
{
	zh = "嘻哈DJ",
	en = "Hip Hop DJ",
	zht = "嘻哈DJ",
}
LocalizationConfig["loc_CostumeSuit_Name_6"] =
{
	zh = "二次元歌者",
	en = "Anime",
	zht = "二次元歌者",
}
LocalizationConfig["loc_CostumeSuit_Name_7"] =
{
	zh = "假林克",
	en = "Link Costume",
	zht = "假林克",
}
LocalizationConfig["loc_CostumeSuit_Name_8"] =
{
	zh = "马猴烧酒",
	en = "Mahou shoujo",
	zht = "馬猴燒酒",
}
LocalizationConfig["loc_CostumeSuit_Name_9"] =
{
	zh = "小奶牛",
	en = "Cow",
	zht = "小奶牛",
}
LocalizationConfig["loc_CostumeSuit_Name_10"] =
{
	zh = "小护士",
	en = "Nurse",
	zht = "小護士",
}
LocalizationConfig["loc_CostumeSuit_Name_11"] =
{
	zh = "忍者",
	en = "Ninja",
	zht = "忍者",
}
LocalizationConfig["loc_CostumeSuit_Name_12"] =
{
	zh = "暗影",
	en = "Shadow",
	zht = "暗影",
}
LocalizationConfig["loc_CostumeSuit_Name_13"] =
{
	zh = "猪面獠牙",
	en = "Pig Toothed",
	zht = "豬面獠牙",
}
LocalizationConfig["loc_CostumeSuit_Name_14"] =
{
	zh = "美杜莎",
	en = "Medusa",
	zht = "美杜莎",
}
LocalizationConfig["loc_CostumeSuit_Name_15"] =
{
	zh = "男装魔王",
	en = "Dark Lord",
	zht = "男裝魔王",
}
LocalizationConfig["loc_CostumeSuit_Name_16"] =
{
	zh = "常服魔王",
	en = "Casual",
	zht = "常服魔王",
}
LocalizationConfig["loc_CostumeSuit_Name_17"] =
{
	zh = "日常",
	en = "Everyday",
	zht = "日常",
}
LocalizationConfig["loc_CostumeSuit_Name_18"] =
{
	zh = "蝙蝠",
	en = "Bat",
	zht = "蝙蝠",
}
LocalizationConfig["loc_CostumeSuit_Name_19"] =
{
	zh = "青面獠牙",
	en = "Big Toothed",
	zht = "青面獠牙",
}
LocalizationConfig["loc_CostumeSuit_Name_20"] =
{
	zh = "商行天下",
	en = "Business Rules",
	zht = "商行天下",
}
LocalizationConfig["loc_CostumeSuit_Name_21"] =
{
	zh = "传声画意",
	en = "Audial Picture",
	zht = "傳聲畫意",
}
LocalizationConfig["loc_CostumeSuit_Name_22"] =
{
	zh = "年轻的时候",
	en = "Youth",
	zht = "年輕的時候",
}
LocalizationConfig["loc_CostumeSuit_Name_23"] =
{
	zh = "森林猎手",
	en = "Forest Hunter",
	zht = "森林獵手",
}
LocalizationConfig["loc_CostumeSuit_Name_24"] =
{
	zh = "保卫城镇",
	en = "Defend the City",
	zht = "保衛城鎮",
}
LocalizationConfig["loc_CostumeSuit_Name_25"] =
{
	zh = "女仆套装",
	en = "Maid Set",
	zht = "女僕套裝",
}
LocalizationConfig["loc_CostumeSuit_Name_26"] =
{
	zh = "扫地套装",
	en = "Sweeper Set",
	zht = "掃地套裝",
}
LocalizationConfig["loc_CostumeSuit_Name_27"] =
{
	zh = "长者休闲服",
	en = "Leisure Wear",
	zht = "長者休閒服",
}
LocalizationConfig["loc_CostumeSuit_Name_28"] =
{
	zh = "黑暗女王",
	en = "Dark Queen",
	zht = "黑暗女王",
}
LocalizationConfig["loc_CostumeSuit_Name_29"] =
{
	zh = "光之女王",
	en = "Light",
	zht = "光之女王",
}
LocalizationConfig["loc_CostumeSuit_Name_30"] =
{
	zh = "华丽女王",
	en = "Majestic",
	zht = "華麗女王",
}
LocalizationConfig["loc_CostumeSuit_Name_31"] =
{
	zh = "马良神笔",
	en = "Magic Pen",
	zht = "馬良神筆",
}
LocalizationConfig["loc_CostumeSuit_Name_32"] =
{
	zh = "龙太子",
	en = "Dragon Prince",
	zht = "龍太子",
}
LocalizationConfig["loc_CostumeSuit_Name_33"] =
{
	zh = "海龙王",
	en = "Dragon King",
	zht = "海龍王",
}
LocalizationConfig["loc_CostumeSuit_Name_34"] =
{
	zh = "百发百中",
	en = "None Miss",
	zht = "百發百中",
}
LocalizationConfig["loc_CostumeSuit_Name_35"] =
{
	zh = "维京人",
	en = "Viking",
	zht = "維京人",
}
LocalizationConfig["loc_CostumeSuit_Name_36"] =
{
	zh = "怪物猎人",
	en = "Creep Hunter",
	zht = "怪物獵人",
}
LocalizationConfig["loc_CostumeSuit_Name_37"] =
{
	zh = "一个火枪手",
	en = "A Musketeer",
	zht = "一個火槍手",
}
LocalizationConfig["loc_CostumeSuit_Name_38"] =
{
	zh = "机械操控",
	en = "Machine Control",
	zht = "機械操控",
}
LocalizationConfig["loc_CostumeSuit_Name_39"] =
{
	zh = "异形",
	en = "Xenomorph",
	zht = "異形",
}
LocalizationConfig["loc_CostumeSuit_Name_40"] =
{
	zh = "雷普利",
	en = "Ripley",
	zht = "雷普利",
}
LocalizationConfig["loc_CostumeSuit_Name_41"] =
{
	zh = "骷髅套装",
	en = "Skeleton Set",
	zht = "骷髏套裝",
}
LocalizationConfig["loc_CostumeSuit_Name_42"] =
{
	zh = "红蓝",
	en = "Red & Blue",
	zht = "紅藍",
}
LocalizationConfig["loc_CostumeSuit_Name_43"] =
{
	zh = "樱花",
	en = "Sakura",
	zht = "櫻花",
}
LocalizationConfig["loc_CostumeSuit_Name_44"] =
{
	zh = "零度",
	en = "Zero",
	zht = "零度",
}
LocalizationConfig["loc_CostumeSuit_Name_45"] =
{
	zh = "抹茶甜筒",
	en = "Matcha",
	zht = "抹茶甜筒",
}
LocalizationConfig["loc_CostumeSuit_Name_46"] =
{
	zh = "五彩爆米花",
	en = "Rainbow",
	zht = "五彩爆米花",
}
LocalizationConfig["loc_CostumeSuit_Name_47"] =
{
	zh = "白松露爆米花",
	en = "Truffle",
	zht = "白松露爆米花",
}
LocalizationConfig["loc_CostumeSuit_Name_48"] =
{
	zh = "焦糖爆米花",
	en = "Toffee",
	zht = "焦糖爆米花",
}
LocalizationConfig["loc_CostumeSuit_Name_49"] =
{
	zh = "鸡肉卷",
	en = "Burrito",
	zht = "雞肉卷",
}
LocalizationConfig["loc_CostumeSuit_Name_50"] =
{
	zh = "软糖妹子",
	en = "Gummy Girl",
	zht = "軟糖妹子",
}
LocalizationConfig["loc_CostumeSuit_Name_51"] =
{
	zh = "牛角面包",
	en = "Croissant",
	zht = "牛角麵包",
}
LocalizationConfig["loc_CostumeSuit_Name_52"] =
{
	zh = "小龙女",
	en = "Dragon Gal",
	zht = "小龍女",
}
LocalizationConfig["loc_CostumeSuit_Name_53"] =
{
	zh = "甜甜圈侍女",
	en = "Donut Maid",
	zht = "甜甜圈侍女",
}
LocalizationConfig["loc_CostumeSuit_Name_54"] =
{
	zh = "炸虾魔后",
	en = "Prawn",
	zht = "炸蝦魔後",
}
LocalizationConfig["loc_CostumeSuit_Name_55"] =
{
	zh = "辣条",
	en = "Chili Strip",
	zht = "辣條",
}
LocalizationConfig["loc_CostumeSuit_Name_56"] =
{
	zh = "巧克力饼干条",
	en = "Cookie Sticks",
	zht = "巧克力餅乾條",
}
LocalizationConfig["loc_CostumeSuit_Name_57"] =
{
	zh = "旋风薯条国王",
	en = "Curly Fry ",
	zht = "旋風薯條國王",
}
LocalizationConfig["loc_CostumeSuit_Name_58"] =
{
	zh = "辣酱侍卫",
	en = "Chili Sauce",
	zht = "辣醬侍衛",
}
LocalizationConfig["loc_CostumeSuit_Name_59"] =
{
	zh = "沙拉酱侍卫",
	en = "Salad Dressing",
	zht = "沙拉醬侍衛",
}
LocalizationConfig["loc_CostumeSuit_Name_60"] =
{
	zh = "巧克力酱侍卫",
	en = "Choco Sauce",
	zht = "巧克力醬侍衛",
}
LocalizationConfig["loc_CostumeSuit_Name_61"] =
{
	zh = "折扇武士",
	en = "[未翻译]折扇武士",
	zht = "摺扇武士",
}
LocalizationConfig["loc_CostumeSuit_Name_62"] =
{
	zh = "匕首武士",
	en = "[未翻译]匕首武士",
	zht = "匕首武士",
}
LocalizationConfig["loc_CostumeSuit_Name_63"] =
{
	zh = "肩甲武士",
	en = "[未翻译]肩甲武士",
	zht = "肩甲武士",
}
LocalizationConfig["loc_CostumeSuit_Name_64"] =
{
	zh = "头坚强",
	en = "[未翻译]头坚强",
	zht = "頭堅強",
}
LocalizationConfig["loc_CostumeSuit_Name_65"] =
{
	zh = "环保半人马",
	en = "[未翻译]环保半人马",
	zht = "環保半人馬",
}
LocalizationConfig["loc_CostumeSuit_Name_66"] =
{
	zh = "独眼假面",
	en = "[未翻译]独眼假面",
	zht = "獨眼假面",
}
LocalizationConfig["loc_CostumeSuit_Name_67"] =
{
	zh = "银发假面",
	en = "[未翻译]银发假面",
	zht = "銀髮假面",
}
LocalizationConfig["loc_CostumeSuit_Name_68"] =
{
	zh = "礼帽假面",
	en = "[未翻译]礼帽假面",
	zht = "禮帽假面",
}
LocalizationConfig["loc_CostumeSuit_Name_69"] =
{
	zh = "小学生标配",
	en = "[未翻译]小学生标配",
	zht = "小學生標配",
}
LocalizationConfig["loc_CostumeSuit_Name_70"] =
{
	zh = "学会微笑",
	en = "[未翻译]学会微笑",
	zht = "學會微笑",
}
LocalizationConfig["loc_CostumeSuit_Name_71"] =
{
	zh = "神秘微笑",
	en = "[未翻译]神秘微笑",
	zht = "神秘微笑",
}
LocalizationConfig["loc_CostumeSuit_Name_72"] =
{
	zh = "原来是你",
	en = "[未翻译]原来是你",
	zht = "原來是你",
}
LocalizationConfig["loc_CostumeSuit_Name_73"] =
{
	zh = "有原相逢",
	en = "[未翻译]有原相逢",
	zht = "有原相逢",
}
LocalizationConfig["loc_CostumeSuit_Name_74"] =
{
	zh = "小原人",
	en = "[未翻译]小原人",
	zht = "小原人",
}
LocalizationConfig["loc_CostumeSuit_Name_75"] =
{
	zh = "不羁妲丽",
	en = "[未翻译]不羁妲丽",
	zht = "不羈妲麗",
}
LocalizationConfig["loc_CostumeSuit_Name_76"] =
{
	zh = "插花妲丽",
	en = "[未翻译]插花妲丽",
	zht = "插花妲麗",
}
LocalizationConfig["loc_CostumeSuit_Name_77"] =
{
	zh = "骑士服",
	en = "[未翻译]骑士服",
	zht = "騎士服",
}
LocalizationConfig["loc_CostumeSuit_Name_78"] =
{
	zh = "功勋骑士服",
	en = "[未翻译]功勋骑士服",
	zht = "功勳騎士服",
}
LocalizationConfig["loc_CostumeSuit_Name_79"] =
{
	zh = "华丽骑士服",
	en = "[未翻译]华丽骑士服",
	zht = "華麗騎士服",
}
LocalizationConfig["loc_CostumeSuit_Name_80"] =
{
	zh = "大侦探睡衣",
	en = "Pajamas Holmees",
	zht = "大偵探睡衣",
}
LocalizationConfig["loc_CostumeSuit_Name_81"] =
{
	zh = "机械大侦探",
	en = "Mecha Holmees",
	zht = "機械大偵探",
}
LocalizationConfig["loc_CostumeSuit_Name_82"] =
{
	zh = "卷福",
	en = "Curly",
	zht = "卷福",
}
LocalizationConfig["loc_CostumeSuit_Name_83"] =
{
	zh = "机械助理",
	en = "Mecha Watsoon",
	zht = "機械助理",
}
LocalizationConfig["loc_CostumeSuit_Name_84"] =
{
	zh = "女仆助理",
	en = "Maid Watsoon",
	zht = "女僕助理",
}
LocalizationConfig["loc_CostumeSuit_Name_85"] =
{
	zh = "助理睡衣",
	en = "Pajamas Watsoon",
	zht = "助理睡衣",
}
LocalizationConfig["loc_CostumeSuit_Name_86"] =
{
	zh = "机械教授",
	en = "Mecha Prof.",
	zht = "機械教授",
}
LocalizationConfig["loc_CostumeSuit_Name_87"] =
{
	zh = "小熊睡衣",
	en = "Bear Pajamas",
	zht = "小熊睡衣",
}
LocalizationConfig["loc_CostumeSuit_Name_88"] =
{
	zh = "化学实验师",
	en = "Chemist",
	zht = "化學實驗師",
}
LocalizationConfig["loc_CostumeSuit_Name_89"] =
{
	zh = "特殊警察",
	en = "SWAT",
	zht = "特殊員警",
}
LocalizationConfig["loc_CostumeSuit_Name_90"] =
{
	zh = "淹死",
	en = "[未翻译]淹死",
	zht = "淹死",
}
LocalizationConfig["loc_CostumeSuit_Name_91"] =
{
	zh = "自杀",
	en = "[未翻译]自杀",
	zht = "自殺",
}
LocalizationConfig["loc_CostumeSuit_Name_92"] =
{
	zh = "日常服装",
	en = "Casual",
	zht = "日常服裝",
}
LocalizationConfig["loc_CostumeSuit_Name_93"] =
{
	zh = "正装",
	en = "Formal",
	zht = "正裝",
}
LocalizationConfig["loc_CostumeSuit_Name_94"] =
{
	zh = "大作家",
	en = "Writer",
	zht = "大作家",
}
LocalizationConfig["loc_CostumeSuit_Name_95"] =
{
	zh = "魔术服",
	en = "Magician",
	zht = "魔術服",
}
LocalizationConfig["loc_CostumeSuit_Des_1"] =
{
	zh = "你好，我是机械战喵",
	en = "Hey there, I'm Mecha Salem",
	zht = "你好，我是機械戰喵",
}
LocalizationConfig["loc_CostumeSuit_Des_2"] =
{
	zh = "你好，我是机械战警",
	en = "Hey there, I'm Mecha Mews",
	zht = "你好，我是機械戰警",
}
LocalizationConfig["loc_CostumeSuit_Des_3"] =
{
	zh = "肩负着家庭和事业两座大山",
	en = "Shouldering the two great mountains of home life and work life",
	zht = "肩負著家庭和事業兩座大山",
}
LocalizationConfig["loc_CostumeSuit_Des_4"] =
{
	zh = "飞啊飞，我骄傲放纵",
	en = "Fly my proud indulgence",
	zht = "飛啊飛，我驕傲放縱",
}
LocalizationConfig["loc_CostumeSuit_Des_5"] =
{
	zh = "呦呦切闹，你有没有福瑞斯戴尔呀",
	en = "Sup dawg, can ya giv' me yo' best freestyle bro?",
	zht = "呦呦切鬧，你有沒有福瑞斯戴爾呀",
}
LocalizationConfig["loc_CostumeSuit_Des_6"] =
{
	zh = "阿拉嚓嚓拉力拉力令拉巴力刚丁刚丁刚多",
	en = "Takami o mezasushite, narifuri kamawazu……",
	zht = "阿拉嚓嚓拉力拉力令拉巴力剛丁剛丁剛多",
}
LocalizationConfig["loc_CostumeSuit_Des_7"] =
{
	zh = "为了致敬勇者届的大神而制作的套装，看起来只有颜色像而已了",
	en = "A suit that pays homage to a great warrior, although only the color looks the same",
	zht = "為了致敬勇者屆的大神而製作的套裝，看起來只有顏色像而已了",
}
LocalizationConfig["loc_CostumeSuit_Des_8"] =
{
	zh = "极品调酒师",
	en = "Best bartender",
	zht = "極品調酒師",
}
LocalizationConfig["loc_CostumeSuit_Des_9"] =
{
	zh = "我是一支行走的超大型奶瓶",
	en = "I'm a just a giant walking milk bottle",
	zht = "我是一支行走的超大型奶瓶",
}
LocalizationConfig["loc_CostumeSuit_Des_10"] =
{
	zh = "穿上之后补血速度极快，一针见效",
	en = "After putting it on, your HP regen speed will increase. Just one shot is all you need.",
	zht = "穿上之後補血速度極快，一針見效",
}
LocalizationConfig["loc_CostumeSuit_Des_11"] =
{
	zh = "伊贺流忍者没想法 嘿 不会用武士刀比划 嘿",
	en = "Iga ninjas have no thoughts of their own, they won't compare their katana skills with others",
	zht = "伊賀流忍者沒想法 嘿 不會用武士刀比劃 嘿",
}
LocalizationConfig["loc_CostumeSuit_Des_12"] =
{
	zh = "你看不见我，你看不见我，什么你看得见？",
	en = "You can't see me, you can't see me…….how can you see me?",
	zht = "你看不見我，你看不見我，什麼你看得見？",
}
LocalizationConfig["loc_CostumeSuit_Des_13"] =
{
	zh = "代表了勇气与力量",
	en = "Represents bravery and strength",
	zht = "代表了勇氣與力量",
}
LocalizationConfig["loc_CostumeSuit_Des_14"] =
{
	zh = "不要直视我的眼睛，我的美貌会让你石化",
	en = "Don't stare into my eyes, my beauty is literally petrifying",
	zht = "不要直視我的眼睛，我的美貌會讓你石化",
}
LocalizationConfig["loc_CostumeSuit_Des_15"] =
{
	zh = "换个男装也一样很有气势",
	en = "Still looks fabulous in another set of male clothing",
	zht = "換個男裝也一樣很有氣勢",
}
LocalizationConfig["loc_CostumeSuit_Des_16"] =
{
	zh = "日常的中性装扮",
	en = "A neutral set of everyday clothing",
	zht = "日常的中性裝扮",
}
LocalizationConfig["loc_CostumeSuit_Des_17"] =
{
	zh = "小魔王的日常装扮",
	en = "The Dark Chief's daily attire",
	zht = "小魔王的日常裝扮",
}
LocalizationConfig["loc_CostumeSuit_Des_18"] =
{
	zh = "小魔王的蝙蝠主题服装",
	en = "The Dark Chief's Bat-themed costume",
	zht = "小魔王的蝙蝠主題服裝",
}
LocalizationConfig["loc_CostumeSuit_Des_19"] =
{
	zh = "好像根本没有什么杀伤力",
	en = "It doesn't seem to have any real power",
	zht = "好像根本沒有什麼殺傷力",
}
LocalizationConfig["loc_CostumeSuit_Des_20"] =
{
	zh = "赚钱不易",
	en = "Scraping a living",
	zht = "賺錢不易",
}
LocalizationConfig["loc_CostumeSuit_Des_21"] =
{
	zh = "画面不是重点，声音才是重点",
	en = "The picture isn't the important part, it's the sound",
	zht = "畫面不是重點，聲音才是重點",
}
LocalizationConfig["loc_CostumeSuit_Des_22"] =
{
	zh = "穿上瞬间回到年期时候样子的神奇套装",
	en = "A magical costume that instantly takes you back to how you were when you were young",
	zht = "穿上瞬間回到年期時候樣子的神奇套裝",
}
LocalizationConfig["loc_CostumeSuit_Des_23"] =
{
	zh = "我是追狼的猎人",
	en = "I'm a wolf-chasing hunter",
	zht = "我是追狼的獵人",
}
LocalizationConfig["loc_CostumeSuit_Des_24"] =
{
	zh = "冰冷的金属卫兵服下有颗温暖的心",
	en = "Beneath the cold metal guard armor is a warm heart.",
	zht = "冰冷的金屬衛兵服下有顆溫暖的心",
}
LocalizationConfig["loc_CostumeSuit_Des_25"] =
{
	zh = "服务型工服",
	en = "Service work clothes",
	zht = "服務型工服",
}
LocalizationConfig["loc_CostumeSuit_Des_26"] =
{
	zh = "缝缝补补又三年",
	en = "It's been patched up and mended for three years",
	zht = "縫縫補補又三年",
}
LocalizationConfig["loc_CostumeSuit_Des_27"] =
{
	zh = "老爷爷也可以有颗童心",
	en = "Old people can also be a child at heart",
	zht = "老爺爺也可以有顆童心",
}
LocalizationConfig["loc_CostumeSuit_Des_28"] =
{
	zh = "自带黑魔法的套装",
	en = "A costume that contains dark magic",
	zht = "自帶黑魔法的套裝",
}
LocalizationConfig["loc_CostumeSuit_Des_29"] =
{
	zh = "自带光魔法的套装",
	en = "A costume that contains light magic",
	zht = "自帶光魔法的套裝",
}
LocalizationConfig["loc_CostumeSuit_Des_30"] =
{
	zh = "为了华丽所以就画的很华丽的套装",
	en = "A magnificent costume that is majestic and resplendent just for the sake of it",
	zht = "為了華麗所以就畫的很華麗的套裝",
}
LocalizationConfig["loc_CostumeSuit_Des_31"] =
{
	zh = "唯一有鞋子的套装",
	en = "The only costume set with shoes",
	zht = "唯一有鞋子的套裝",
}
LocalizationConfig["loc_CostumeSuit_Des_32"] =
{
	zh = "中国神话里的龙太子套装",
	en = "A costume inspired by the Dragon Prince of Chinese mythology",
	zht = "中國神話裡的龍太子套裝",
}
LocalizationConfig["loc_CostumeSuit_Des_33"] =
{
	zh = "中国神话中海龙王的套装",
	en = "A costume inspired by the Sea Dragon King of Chinese mythology",
	zht = "中國神話中海龍王的套裝",
}
LocalizationConfig["loc_CostumeSuit_Des_34"] =
{
	zh = "百步穿羊！",
	en = "Bullseye!",
	zht = "百步穿羊！",
}
LocalizationConfig["loc_CostumeSuit_Des_35"] =
{
	zh = "骑着恶龙的维京人，充满了勇气的套装",
	en = "A dragon-riding Viking, a costume that's filled with courage and valor",
	zht = "騎著惡龍的維京人，充滿了勇氣的套裝",
}
LocalizationConfig["loc_CostumeSuit_Des_36"] =
{
	zh = "收集了很多素材才合成出来的套装",
	en = "A costume that is made from many different materials that have been gathered together",
	zht = "收集了很多素材才合成出來的套裝",
}
LocalizationConfig["loc_CostumeSuit_Des_37"] =
{
	zh = "星球里富有的人才买得起的套装",
	en = "A costume set that only the richest people on the planet can afford",
	zht = "星球裡富有的人才買得起的套裝",
}
LocalizationConfig["loc_CostumeSuit_Des_38"] =
{
	zh = "自备假发",
	en = "Comes with its own wig",
	zht = "自備假髮",
}
LocalizationConfig["loc_CostumeSuit_Des_39"] =
{
	zh = "一扎看都觉得有点可怕，要是盯着看可要命了",
	en = "Just one glance makes you feel a little scared, staring at it for a while is truly unbearable",
	zht = "一紮看都覺得有點可怕，要是盯著看可要命了",
}
LocalizationConfig["loc_CostumeSuit_Des_40"] =
{
	zh = "曾经有一位女英雄，战胜了吃人的外星人，她留下了这个套装",
	en = "There was once a female hero that defeated human-eating aliens. This is the costume she left behind",
	zht = "曾經有一位女英雄，戰勝了吃人的外星人，她留下了這個套裝",
}
LocalizationConfig["loc_CostumeSuit_Des_41"] =
{
	zh = "非常骨感",
	en = "Really bony",
	zht = "非常骨感",
}
LocalizationConfig["loc_CostumeSuit_Des_42"] =
{
	zh = "可乐的外套也不一定就非要穿红色的对吧，对吧？",
	en = "A cola jacket doesn't necessarily just have to be red……right?",
	zht = "可樂的外套也不一定就非要穿紅色的對吧，對吧？",
}
LocalizationConfig["loc_CostumeSuit_Des_43"] =
{
	zh = "限量发售的套装，自带一股樱花的香味",
	en = "A limited edition costume set, it carries the sweet fragrance of cherry blossoms",
	zht = "限量發售的套裝，自帶一股櫻花的香味",
}
LocalizationConfig["loc_CostumeSuit_Des_44"] =
{
	zh = "非常酷，非常无糖，非常黑",
	en = "Really cool, sugar free and really dark",
	zht = "非常酷，非常無糖，非常黑",
}
LocalizationConfig["loc_CostumeSuit_Des_45"] =
{
	zh = "抹茶甜筒冰淇淋套装",
	en = "A matcha ice-cream cone costume",
	zht = "抹茶甜筒霜淇淋套裝",
}
LocalizationConfig["loc_CostumeSuit_Des_46"] =
{
	zh = "五彩爆米花，不用担心都是用的春天然染料",
	en = "Rainbow popcorn, there's no need to worry, it uses all-natural ingredients",
	zht = "五彩爆米花，不用擔心都是用的春天然染料",
}
LocalizationConfig["loc_CostumeSuit_Des_47"] =
{
	zh = "世界最贵的爆米花！一桶500美金，吃了难道会发光？",
	en = "The world's most expensive popcorn! $500 a bucket, do you think you'll shine when you eat it?",
	zht = "世界最貴的爆米花！一桶500美金，吃了難道會發光？",
}
LocalizationConfig["loc_CostumeSuit_Des_48"] =
{
	zh = "东方风情的和服套装",
	en = "An eastern-style kimono costume",
	zht = "東方風情的和服套裝",
}
LocalizationConfig["loc_CostumeSuit_Des_49"] =
{
	zh = "墨西哥卷饼套装",
	en = "A Mexican burrito costume",
	zht = "墨西哥卷餅套裝",
}
LocalizationConfig["loc_CostumeSuit_Des_50"] =
{
	zh = "五彩软糖套装，软妹子专用",
	en = "A colored gummy costume, specially made for soft girls",
	zht = "五彩軟糖套裝，軟妹子專用",
}
LocalizationConfig["loc_CostumeSuit_Des_51"] =
{
	zh = "发饰牛角大面包套装",
	en = "A croissant costume",
	zht = "發飾牛角大麵包套裝",
}
LocalizationConfig["loc_CostumeSuit_Des_52"] =
{
	zh = "原本透着一股仙气的套装配上一对鸡腿头饰之后……",
	en = "An elegant costume, once a chicken leg headpiece has been added it looks……",
	zht = "原本透著一股仙氣的套裝配上一對雞腿頭飾之後……",
}
LocalizationConfig["loc_CostumeSuit_Des_53"] =
{
	zh = "甜甜圈做成的丸子头搭配汉服非常可爱",
	en = "This round donut headpiece looks adorable with Hanfu",
	zht = "甜甜圈做成的丸子頭搭配漢服非常可愛",
}
LocalizationConfig["loc_CostumeSuit_Des_54"] =
{
	zh = "非常适合冬天的套装，热油炸虾和超厚裙子",
	en = "A costume that is suitable for winter: Hot fried prawns with a thick, heavy dress",
	zht = "非常適合冬天的套裝，熱油炸蝦和超厚裙子",
}
LocalizationConfig["loc_CostumeSuit_Des_55"] =
{
	zh = "辣条套装，穿上还是需要点勇气",
	en = "A chili strip costume, requires a little courage to wear",
	zht = "辣條套裝，穿上還是需要點勇氣",
}
LocalizationConfig["loc_CostumeSuit_Des_56"] =
{
	zh = "根据流行小零食设计的套装",
	en = "A costume designed around a popular snack",
	zht = "根據流行小零食設計的套裝",
}
LocalizationConfig["loc_CostumeSuit_Des_57"] =
{
	zh = "非常正式的加冕仪式套装",
	en = "Extremely formal coronation attire",
	zht = "非常正式的加冕儀式套裝",
}
LocalizationConfig["loc_CostumeSuit_Des_58"] =
{
	zh = "这个可非常厉害了，简直是女神级别的套装",
	en = "This is extremely awesome, simply the costume of a goddess",
	zht = "這個可非常厲害了，簡直是女神級別的套裝",
}
LocalizationConfig["loc_CostumeSuit_Des_59"] =
{
	zh = "透着一股奶香味的白色套装",
	en = "A white costume with a milky fragrance",
	zht = "透著一股奶香味的白色套裝",
}
LocalizationConfig["loc_CostumeSuit_Des_60"] =
{
	zh = "透着一股巧克力香味的棕色套装",
	en = "A brown costume with a chocolatey fragrance",
	zht = "透著一股巧克力香味的棕色套裝",
}
LocalizationConfig["loc_CostumeSuit_Des_61"] =
{
	zh = "成为武士的第一步，就是先整一套武士装备",
	en = "[未翻译]成为武士的第一步，就是先整一套武士装备",
	zht = "成为武士的第一步，就是先整一套武士装备",
}
LocalizationConfig["loc_CostumeSuit_Des_62"] =
{
	zh = "沉重的爱",
	en = "[未翻译]沉重的爱",
	zht = "沉重的爱",
}
LocalizationConfig["loc_CostumeSuit_Des_63"] =
{
	zh = "由于肩甲太重而常常拿不起弓",
	en = "[未翻译]由于肩甲太重而常常拿不起弓",
	zht = "由于肩甲太重而常常拿不起弓",
}
LocalizationConfig["loc_CostumeSuit_Des_64"] =
{
	zh = "铁头功速成套装",
	en = "[未翻译]铁头功速成套装",
	zht = "铁头功速成套装",
}
LocalizationConfig["loc_CostumeSuit_Des_65"] =
{
	zh = "喵脆角是亮点",
	en = "[未翻译]喵脆角是亮点",
	zht = "喵脆角是亮点",
}
LocalizationConfig["loc_CostumeSuit_Des_66"] =
{
	zh = "由于脑袋太大而导致眼罩经常系不上",
	en = "[未翻译]由于脑袋太大而导致眼罩经常系不上",
	zht = "由于脑袋太大而导致眼罩经常系不上",
}
LocalizationConfig["loc_CostumeSuit_Des_67"] =
{
	zh = "常因为照镜子时感叹衣服太酷而忘了自己要干什么",
	en = "[未翻译]常因为照镜子时感叹衣服太酷而忘了自己要干什么",
	zht = "常因为照镜子时感叹衣服太酷而忘了自己要干什么",
}
LocalizationConfig["loc_CostumeSuit_Des_68"] =
{
	zh = "可以随时来段魔术秀",
	en = "[未翻译]可以随时来段魔术秀",
	zht = "可以随时来段魔术秀",
}
LocalizationConfig["loc_CostumeSuit_Des_69"] =
{
	zh = "谁说小学生不能当侦探的？",
	en = "[未翻译]谁说小学生不能当侦探的？",
	zht = "谁说小学生不能当侦探的？",
}
LocalizationConfig["loc_CostumeSuit_Des_70"] =
{
	zh = "穿上这套，你就是最神秘的女人",
	en = "[未翻译]穿上这套，你就是最神秘的女人",
	zht = "穿上这套，你就是最神秘的女人",
}
LocalizationConfig["loc_CostumeSuit_Des_71"] =
{
	zh = "穿上这套，你会拥有最神秘的微笑",
	en = "[未翻译]穿上这套，你会拥有最神秘的微笑",
	zht = "穿上這套，你會擁有最神秘的微笑",
}
LocalizationConfig["loc_CostumeSuit_Des_72"] =
{
	zh = "身份的象征",
	en = "[未翻译]身份的象征",
	zht = "身份的象徵",
}
LocalizationConfig["loc_CostumeSuit_Des_73"] =
{
	zh = "夏天的轻便套装",
	en = "[未翻译]夏天的轻便套装",
	zht = "夏天的輕便套裝",
}
LocalizationConfig["loc_CostumeSuit_Des_74"] =
{
	zh = "扎辫子的也可能是男孩子",
	en = "[未翻译]扎辫子的也可能是男孩子",
	zht = "紮辮子的也可能是男孩子",
}
LocalizationConfig["loc_CostumeSuit_Des_75"] =
{
	zh = "眉毛让人无法移开目光",
	en = "[未翻译]眉毛让人无法移开目光",
	zht = "眉毛让人无法移开目光",
}
LocalizationConfig["loc_CostumeSuit_Des_76"] =
{
	zh = "头上的花比眉毛更亮眼",
	en = "[未翻译]头上的花比眉毛更亮眼",
	zht = "头上的花比眉毛更亮眼",
}
LocalizationConfig["loc_CostumeSuit_Des_77"] =
{
	zh = "用手中的剑来守护",
	en = "[未翻译]用手中的剑来守护",
	zht = "用手中的剑来守护",
}
LocalizationConfig["loc_CostumeSuit_Des_78"] =
{
	zh = "穿久了有高低肩的隐患",
	en = "[未翻译]穿久了有高低肩的隐患",
	zht = "穿久了有高低肩的隐患",
}
LocalizationConfig["loc_CostumeSuit_Des_79"] =
{
	zh = "不知道为什么有点像和平大使呢……",
	en = "[未翻译]不知道为什么有点像和平大使呢……",
	zht = "不知道为什么有点像和平大使呢……",
}
LocalizationConfig["loc_CostumeSuit_Des_80"] =
{
	zh = "令人浮想联翩的睡衣姿态！拉小提琴也更放松了！",
	en = "Pajamas that cause thoughts and ideas to flow through your mind! Playing the violin will make you even more relaxed!",
	zht = "令人浮想联翩的睡衣姿态！拉小提琴也更放松了！",
}
LocalizationConfig["loc_CostumeSuit_Des_81"] =
{
	zh = "坚硬的外壳能让我的头脑更加清醒",
	en = "The hard outer-shell makes my mind clearer",
	zht = "坚硬的外壳能让我的头脑更加清醒",
}
LocalizationConfig["loc_CostumeSuit_Des_82"] =
{
	zh = "头发是卷的思路从来不打卷，设下重重拳套让敌人打卷！",
	en = "With curly hair your train of thought will never aimlessly go round in circles, hit the enemy hard and make them roll!",
	zht = "头发是卷的思路从来不打卷，设下重重拳套让敌人打卷！",
}
LocalizationConfig["loc_CostumeSuit_Des_83"] =
{
	zh = "其实内心一直想要飞上太空，在无重力环境下制作美食",
	en = "Deep down, he's actually always wanted to fly to outer space and do some zero G cooking",
	zht = "其实内心一直想要飞上太空，在无重力环境下制作美食",
}
LocalizationConfig["loc_CostumeSuit_Des_84"] =
{
	zh = "偶尔扮演个女仆，思考问题更加清醒",
	en = "Sometimes dresses up as a maid, it helps him to think more clearly",
	zht = "偶尔扮演个女仆，思考问题更加清醒",
}
LocalizationConfig["loc_CostumeSuit_Des_85"] =
{
	zh = "令人浮想联翩的睡衣姿态！",
	en = "Pajamas that cause thoughts and ideas to flow through your mind!",
	zht = "令人浮想联翩的睡衣姿态！",
}
LocalizationConfig["loc_CostumeSuit_Des_86"] =
{
	zh = "机械感十足，更加神秘了",
	en = "Nice and mechanical, much more mysterious",
	zht = "机械感十足，更加神秘了",
}
LocalizationConfig["loc_CostumeSuit_Des_87"] =
{
	zh = "别看这个外形有点不正经，助眠效果可是非常好",
	en = "Don't worry about how it looks, it helps you get a great night's sleep",
	zht = "别看这个外形有点不正经，助眠效果可是非常好",
}
LocalizationConfig["loc_CostumeSuit_Des_88"] =
{
	zh = "做化学实验必不可少的装备",
	en = "A must-have for conducting chemistry experiments",
	zht = "做化学实验必不可少的装备",
}
LocalizationConfig["loc_CostumeSuit_Des_89"] =
{
	zh = "换上特殊身份的同时，装备也要换成特殊装备",
	en = "When changing to a special identity, you must also change into special gear",
	zht = "换上特殊身份的同时，装备也要换成特殊装备",
}
LocalizationConfig["loc_CostumeSuit_Des_90"] =
{
	zh = "好看又好用",
	en = "[未翻译]好看又好用",
	zht = "好看又好用",
}
LocalizationConfig["loc_CostumeSuit_Des_91"] =
{
	zh = "方便又实用",
	en = "[未翻译]方便又实用",
	zht = "方便又实用",
}
LocalizationConfig["loc_CostumeSuit_Des_92"] =
{
	zh = "日常的马甲款套装",
	en = "A casual vest suit",
	zht = "日常的马甲款套装",
}
LocalizationConfig["loc_CostumeSuit_Des_93"] =
{
	zh = "正式场合穿着的套装，在辩论中先用气势压倒对方",
	en = "A suit worn for formal occasions, helps you to use your dignified airs to counter opponents during debates",
	zht = "正式场合穿着的套装，在辩论中先用气势压倒对方",
}
LocalizationConfig["loc_CostumeSuit_Des_94"] =
{
	zh = "大作家专用套装",
	en = "A costume made specially for writers",
	zht = "大作家专用套装",
}
LocalizationConfig["loc_CostumeSuit_Des_95"] =
{
	zh = "外表看起来普通的礼服，里面可是藏了很多的机关",
	en = "The jacket looks like a regular suit jacket, but there are actually a load of mechanisms hidden inside",
	zht = "外表看起来普通的礼服，里面可是藏了很多的机关",
}
LocalizationConfig["loc_CostumeSuit_CosItem_1"] =
{
	zh = "头盔",
	en = "Cuirass",
	zht = "頭盔",
}
LocalizationConfig["loc_CostumeSuit_CosItem_2"] =
{
	zh = "胸甲",
	en = "Helmet",
	zht = "胸甲",
}
LocalizationConfig["loc_CostumeSuit_CosItem_3"] =
{
	zh = "头戴式投影仪",
	en = "Head Projector",
	zht = "頭戴式投影儀",
}
LocalizationConfig["loc_CostumeSuit_CosItem_4"] =
{
	zh = "时刻备战包",
	en = "Preparation Pack",
	zht = "時刻備戰包",
}
LocalizationConfig["loc_CostumeSuit_CosItem_5"] =
{
	zh = "扳手",
	en = "Spanner",
	zht = "扳手",
}
LocalizationConfig["loc_CostumeSuit_CosItem_6"] =
{
	zh = "信号灯",
	en = "Signal Light",
	zht = "信號燈",
}
LocalizationConfig["loc_CostumeSuit_CosItem_7"] =
{
	zh = "飞机头",
	en = "Plane Head",
	zht = "飛機頭",
}
LocalizationConfig["loc_CostumeSuit_CosItem_8"] =
{
	zh = "飞机尾",
	en = "Plane Tail",
	zht = "飛機尾",
}
LocalizationConfig["loc_CostumeSuit_CosItem_9"] =
{
	zh = "嘻哈外套",
	en = "RNB Jacket",
	zht = "嘻哈外套",
}
LocalizationConfig["loc_CostumeSuit_CosItem_10"] =
{
	zh = "吉他",
	en = "Guitar",
	zht = "吉他",
}
LocalizationConfig["loc_CostumeSuit_CosItem_11"] =
{
	zh = "二次元衣服",
	en = "Anime Clothing",
	zht = "二次元衣服",
}
LocalizationConfig["loc_CostumeSuit_CosItem_12"] =
{
	zh = "小绿帽",
	en = "Green Cap",
	zht = "小綠帽",
}
LocalizationConfig["loc_CostumeSuit_CosItem_13"] =
{
	zh = "小绿衣",
	en = "Green Custom",
	zht = "小綠衣",
}
LocalizationConfig["loc_CostumeSuit_CosItem_14"] =
{
	zh = "欧式长剑",
	en = "Euro Sword",
	zht = "歐式長劍",
}
LocalizationConfig["loc_CostumeSuit_CosItem_15"] =
{
	zh = "魔法帽",
	en = "Magic Hat",
	zht = "魔法帽",
}
LocalizationConfig["loc_CostumeSuit_CosItem_16"] =
{
	zh = "魔法斗篷",
	en = "Magic Cloak",
	zht = "魔法斗篷",
}
LocalizationConfig["loc_CostumeSuit_CosItem_17"] =
{
	zh = "魔法手杖",
	en = "Magic Staff",
	zht = "魔法手杖",
}
LocalizationConfig["loc_CostumeSuit_CosItem_18"] =
{
	zh = "金牛角",
	en = "Gold Horn",
	zht = "金牛角",
}
LocalizationConfig["loc_CostumeSuit_CosItem_19"] =
{
	zh = "奶牛上衣",
	en = "Cow Jacket",
	zht = "奶牛上衣",
}
LocalizationConfig["loc_CostumeSuit_CosItem_20"] =
{
	zh = "护士帽",
	en = "Nurse Hat",
	zht = "護士帽",
}
LocalizationConfig["loc_CostumeSuit_CosItem_21"] =
{
	zh = "护士衣",
	en = "Nurse Dress",
	zht = "護士衣",
}
LocalizationConfig["loc_CostumeSuit_CosItem_22"] =
{
	zh = "玩具针筒",
	en = "Syringe",
	zht = "玩具針筒",
}
LocalizationConfig["loc_CostumeSuit_CosItem_23"] =
{
	zh = "玩具加血枪",
	en = "Toy HP Gun",
	zht = "玩具加血槍",
}
LocalizationConfig["loc_CostumeSuit_CosItem_24"] =
{
	zh = "忍者面具",
	en = "Ninja Mask",
	zht = "忍者面具",
}
LocalizationConfig["loc_CostumeSuit_CosItem_25"] =
{
	zh = "忍者盔甲",
	en = "Ninja Armor",
	zht = "忍者盔甲",
}
LocalizationConfig["loc_CostumeSuit_CosItem_26"] =
{
	zh = "苦无",
	en = "Kunai",
	zht = "苦無",
}
LocalizationConfig["loc_CostumeSuit_CosItem_27"] =
{
	zh = "暗影帽子",
	en = "Shadow Hat",
	zht = "暗影帽子",
}
LocalizationConfig["loc_CostumeSuit_CosItem_28"] =
{
	zh = "暗影衣服",
	en = "Shadow Clothes",
	zht = "暗影衣服",
}
LocalizationConfig["loc_CostumeSuit_CosItem_29"] =
{
	zh = "漆黑短刀",
	en = "Black Dagger",
	zht = "漆黑短刀",
}
LocalizationConfig["loc_CostumeSuit_CosItem_30"] =
{
	zh = "农耕衣",
	en = "Farmer's Clothes",
	zht = "農耕衣",
}
LocalizationConfig["loc_CostumeSuit_CosItem_31"] =
{
	zh = "花纹大棒",
	en = "Beautified Rod",
	zht = "花紋大棒",
}
LocalizationConfig["loc_CostumeSuit_CosItem_32"] =
{
	zh = "猪皮袄",
	en = "Pig Skin Jacket",
	zht = "豬皮襖",
}
LocalizationConfig["loc_CostumeSuit_CosItem_33"] =
{
	zh = "美杜莎皇冠",
	en = "Medusa Crown",
	zht = "美杜莎皇冠",
}
LocalizationConfig["loc_CostumeSuit_CosItem_34"] =
{
	zh = "蛇皮衣服",
	en = "Snake Clothes",
	zht = "蛇皮衣服",
}
LocalizationConfig["loc_CostumeSuit_CosItem_35"] =
{
	zh = "男装头盔",
	en = "Male Helmet",
	zht = "男裝頭盔",
}
LocalizationConfig["loc_CostumeSuit_CosItem_36"] =
{
	zh = "男装盔甲",
	en = "Male Armor",
	zht = "男裝盔甲",
}
LocalizationConfig["loc_CostumeSuit_CosItem_37"] =
{
	zh = "男装裤子",
	en = "Male Pants",
	zht = "男裝褲子",
}
LocalizationConfig["loc_CostumeSuit_CosItem_38"] =
{
	zh = "男装手杖",
	en = "Male Rod",
	zht = "男裝手杖",
}
LocalizationConfig["loc_CostumeSuit_CosItem_39"] =
{
	zh = "日常发饰",
	en = "Daily Headwear",
	zht = "日常發飾",
}
LocalizationConfig["loc_CostumeSuit_CosItem_40"] =
{
	zh = "日常外套",
	en = "Daily Coat",
	zht = "日常外套",
}
LocalizationConfig["loc_CostumeSuit_CosItem_41"] =
{
	zh = "日常手杖",
	en = "Daily Scepter",
	zht = "日常手杖",
}
LocalizationConfig["loc_CostumeSuit_CosItem_42"] =
{
	zh = "小魔王头饰",
	en = "Evil Headwear",
	zht = "小魔王頭飾",
}
LocalizationConfig["loc_CostumeSuit_CosItem_43"] =
{
	zh = "小魔王衣服",
	en = "Evil Clothes",
	zht = "小魔王衣服",
}
LocalizationConfig["loc_CostumeSuit_CosItem_44"] =
{
	zh = "蝙蝠翅膀",
	en = "Bat Wings",
	zht = "蝙蝠翅膀",
}
LocalizationConfig["loc_CostumeSuit_CosItem_45"] =
{
	zh = "头骨棉袄",
	en = "Skull Jacket",
	zht = "頭骨棉襖",
}
LocalizationConfig["loc_CostumeSuit_CosItem_46"] =
{
	zh = "骨锤",
	en = "Bone Hammer",
	zht = "骨錘",
}
LocalizationConfig["loc_CostumeSuit_CosItem_47"] =
{
	zh = "口袋大衣",
	en = "Pocket Coat",
	zht = "口袋大衣",
}
LocalizationConfig["loc_CostumeSuit_CosItem_48"] =
{
	zh = "宣传红旗",
	en = "Red Flag",
	zht = "宣傳紅旗",
}
LocalizationConfig["loc_CostumeSuit_CosItem_49"] =
{
	zh = "背篓",
	en = "Pack Basket",
	zht = "背簍",
}
LocalizationConfig["loc_CostumeSuit_CosItem_50"] =
{
	zh = "红色背带裙",
	en = "Red Overall",
	zht = "紅色背帶裙",
}
LocalizationConfig["loc_CostumeSuit_CosItem_51"] =
{
	zh = "话筒",
	en = "Microphone",
	zht = "話筒",
}
LocalizationConfig["loc_CostumeSuit_CosItem_52"] =
{
	zh = "筒裙",
	en = "Tube Skirt",
	zht = "筒裙",
}
LocalizationConfig["loc_CostumeSuit_CosItem_53"] =
{
	zh = "狩猎套",
	en = "Hunting Set",
	zht = "狩獵套",
}
LocalizationConfig["loc_CostumeSuit_CosItem_54"] =
{
	zh = "猎人护额",
	en = "Hunter Headband",
	zht = "獵人護額",
}
LocalizationConfig["loc_CostumeSuit_CosItem_55"] =
{
	zh = "卫兵帽",
	en = "Guard Hat",
	zht = "衛兵帽",
}
LocalizationConfig["loc_CostumeSuit_CosItem_56"] =
{
	zh = "卫兵服",
	en = "Guard Clothing",
	zht = "衛兵服",
}
LocalizationConfig["loc_CostumeSuit_CosItem_57"] =
{
	zh = "女仆装",
	en = "Maid Set",
	zht = "女僕裝",
}
LocalizationConfig["loc_CostumeSuit_CosItem_58"] =
{
	zh = "环卫衣",
	en = "Sanitation Suit",
	zht = "環衛衣",
}
LocalizationConfig["loc_CostumeSuit_CosItem_59"] =
{
	zh = "兔兔礼帽",
	en = "Bunny Hat",
	zht = "兔兔禮帽",
}
LocalizationConfig["loc_CostumeSuit_CosItem_60"] =
{
	zh = "糖果撞色衣",
	en = "Contrasting Suit",
	zht = "糖果撞色衣",
}
LocalizationConfig["loc_CostumeSuit_CosItem_61"] =
{
	zh = "黑头冠",
	en = "Black Crown",
	zht = "黑頭冠",
}
LocalizationConfig["loc_CostumeSuit_CosItem_62"] =
{
	zh = "黑外套",
	en = "Black Coat",
	zht = "黑外套",
}
LocalizationConfig["loc_CostumeSuit_CosItem_63"] =
{
	zh = "黑礼服裙",
	en = "Black Dress",
	zht = "黑禮服裙",
}
LocalizationConfig["loc_CostumeSuit_CosItem_64"] =
{
	zh = "白头冠",
	en = "White Crown",
	zht = "白頭冠",
}
LocalizationConfig["loc_CostumeSuit_CosItem_65"] =
{
	zh = "白外套",
	en = "White Coat",
	zht = "白外套",
}
LocalizationConfig["loc_CostumeSuit_CosItem_66"] =
{
	zh = "白礼服裙",
	en = "White Dress",
	zht = "白禮服裙",
}
LocalizationConfig["loc_CostumeSuit_CosItem_67"] =
{
	zh = "琉璃皇冠",
	en = "Glaze Crown",
	zht = "琉璃皇冠",
}
LocalizationConfig["loc_CostumeSuit_CosItem_68"] =
{
	zh = "毛绒披风",
	en = "Fur Cape",
	zht = "毛絨披風",
}
LocalizationConfig["loc_CostumeSuit_CosItem_69"] =
{
	zh = "老实人马甲",
	en = "Honest Man Vest",
	zht = "老實人馬甲",
}
LocalizationConfig["loc_CostumeSuit_CosItem_70"] =
{
	zh = "枣红帽",
	en = "Date Hat",
	zht = "棗紅帽",
}
LocalizationConfig["loc_CostumeSuit_CosItem_71"] =
{
	zh = "太子龙角",
	en = "Prince's Horn",
	zht = "太子龍角",
}
LocalizationConfig["loc_CostumeSuit_CosItem_72"] =
{
	zh = "绸缎上衣",
	en = "Silk Jacket",
	zht = "綢緞上衣",
}
LocalizationConfig["loc_CostumeSuit_CosItem_73"] =
{
	zh = "绸缎下装",
	en = "Silk Pants",
	zht = "綢緞下裝",
}
LocalizationConfig["loc_CostumeSuit_CosItem_74"] =
{
	zh = "肉腿",
	en = "Ham",
	zht = "肉腿",
}
LocalizationConfig["loc_CostumeSuit_CosItem_75"] =
{
	zh = "龙王角",
	en = "King's Horn",
	zht = "龍王角",
}
LocalizationConfig["loc_CostumeSuit_CosItem_76"] =
{
	zh = "龙王上衣",
	en = "King Jacket",
	zht = "龍王上衣",
}
LocalizationConfig["loc_CostumeSuit_CosItem_77"] =
{
	zh = "龙王下装",
	en = "King Pants",
	zht = "龍王下裝",
}
LocalizationConfig["loc_CostumeSuit_CosItem_78"] =
{
	zh = "咸鱼",
	en = "Salted Fish",
	zht = "鹹魚",
}
LocalizationConfig["loc_CostumeSuit_CosItem_79"] =
{
	zh = "弓箭服",
	en = "Bow Clothes",
	zht = "弓箭服",
}
LocalizationConfig["loc_CostumeSuit_CosItem_80"] =
{
	zh = "维京帽子",
	en = "Viking Hat",
	zht = "維京帽子",
}
LocalizationConfig["loc_CostumeSuit_CosItem_81"] =
{
	zh = "维京上衣",
	en = "Viking Jacket",
	zht = "維京上衣",
}
LocalizationConfig["loc_CostumeSuit_CosItem_82"] =
{
	zh = "维京锤",
	en = "Viking Hammer",
	zht = "維京錘",
}
LocalizationConfig["loc_CostumeSuit_CosItem_83"] =
{
	zh = "独角发带",
	en = "Unicorn Band",
	zht = "獨角發帶",
}
LocalizationConfig["loc_CostumeSuit_CosItem_84"] =
{
	zh = "猎龙上衣",
	en = "Dragon Jacket",
	zht = "獵龍上衣",
}
LocalizationConfig["loc_CostumeSuit_CosItem_85"] =
{
	zh = "猎龙下装",
	en = "Dragon Pants",
	zht = "獵龍下裝",
}
LocalizationConfig["loc_CostumeSuit_CosItem_86"] =
{
	zh = "猎龙大刀",
	en = "Dragon Sword",
	zht = "獵龍大刀",
}
LocalizationConfig["loc_CostumeSuit_CosItem_87"] =
{
	zh = "牛仔帽",
	en = "Cowboy Hat",
	zht = "牛仔帽",
}
LocalizationConfig["loc_CostumeSuit_CosItem_88"] =
{
	zh = "三角披风",
	en = "Triangle Cloak",
	zht = "三角披風",
}
LocalizationConfig["loc_CostumeSuit_CosItem_89"] =
{
	zh = "火枪",
	en = "Musket",
	zht = "火槍",
}
LocalizationConfig["loc_CostumeSuit_CosItem_90"] =
{
	zh = "白毛大棉袄",
	en = "White Fur Jacket",
	zht = "白毛大棉襖",
}
LocalizationConfig["loc_CostumeSuit_CosItem_91"] =
{
	zh = "机械玩偶",
	en = "Mechanical Doll",
	zht = "機械玩偶",
}
LocalizationConfig["loc_CostumeSuit_CosItem_92"] =
{
	zh = "异形头盔",
	en = "Xeno Helm",
	zht = "異形頭盔",
}
LocalizationConfig["loc_CostumeSuit_CosItem_93"] =
{
	zh = "异形上衣",
	en = "Xeno Jacket",
	zht = "異形上衣",
}
LocalizationConfig["loc_CostumeSuit_CosItem_94"] =
{
	zh = "独眼虫",
	en = "Cyclops Bug",
	zht = "獨眼蟲",
}
LocalizationConfig["loc_CostumeSuit_CosItem_95"] =
{
	zh = "尾巴",
	en = "Tail",
	zht = "尾巴",
}
LocalizationConfig["loc_CostumeSuit_CosItem_96"] =
{
	zh = "防尘上衣",
	en = "Dustcoat",
	zht = "防塵上衣",
}
LocalizationConfig["loc_CostumeSuit_CosItem_97"] =
{
	zh = "防尘裤子",
	en = "Dust Pants",
	zht = "防塵褲子",
}
LocalizationConfig["loc_CostumeSuit_CosItem_98"] =
{
	zh = "头盔",
	en = "Helmet",
	zht = "頭盔",
}
LocalizationConfig["loc_CostumeSuit_CosItem_99"] =
{
	zh = "蓝色帽子",
	en = "Blue Hat",
	zht = "藍色帽子",
}
LocalizationConfig["loc_CostumeSuit_CosItem_100"] =
{
	zh = "染色假发",
	en = "Dyed Wig",
	zht = "染色假髮",
}
LocalizationConfig["loc_CostumeSuit_CosItem_101"] =
{
	zh = "红色盖子",
	en = "Red Lid",
	zht = "紅色蓋子",
}
LocalizationConfig["loc_CostumeSuit_CosItem_102"] =
{
	zh = "樱花头带",
	en = "Sakura Band",
	zht = "櫻花頭帶",
}
LocalizationConfig["loc_CostumeSuit_CosItem_103"] =
{
	zh = "粉红外套",
	en = "Pink Jacket",
	zht = "粉紅外套",
}
LocalizationConfig["loc_CostumeSuit_CosItem_104"] =
{
	zh = "樱花糖浆",
	en = "Sakura Syrup",
	zht = "櫻花糖漿",
}
LocalizationConfig["loc_CostumeSuit_CosItem_105"] =
{
	zh = "漆黑帽子",
	en = "Black Hat",
	zht = "漆黑帽子",
}
LocalizationConfig["loc_CostumeSuit_CosItem_106"] =
{
	zh = "零度胸针",
	en = "Zero Broach",
	zht = "零度胸針",
}
LocalizationConfig["loc_CostumeSuit_CosItem_107"] =
{
	zh = "无糖外套",
	en = "Zero Jacket",
	zht = "無糖外套",
}
LocalizationConfig["loc_CostumeSuit_CosItem_108"] =
{
	zh = "奶油帽子",
	en = "Cream Hat",
	zht = "奶油帽子",
}
LocalizationConfig["loc_CostumeSuit_CosItem_109"] =
{
	zh = "巧克力抹胸",
	en = "Choco Tube Top",
	zht = "巧克力抹胸",
}
LocalizationConfig["loc_CostumeSuit_CosItem_110"] =
{
	zh = "绿绒外套",
	en = "Green Jacket",
	zht = "綠絨外套",
}
LocalizationConfig["loc_CostumeSuit_CosItem_111"] =
{
	zh = "抹茶甜酱",
	en = "Matcha Sauce",
	zht = "抹茶甜醬",
}
LocalizationConfig["loc_CostumeSuit_CosItem_112"] =
{
	zh = "红色皇冠",
	en = "Red Crown",
	zht = "紅色皇冠",
}
LocalizationConfig["loc_CostumeSuit_CosItem_113"] =
{
	zh = "桃心耳环",
	en = "Heart Earrings",
	zht = "桃心耳環",
}
LocalizationConfig["loc_CostumeSuit_CosItem_114"] =
{
	zh = "桃心手杖",
	en = "Heart Rod",
	zht = "桃心手杖",
}
LocalizationConfig["loc_CostumeSuit_CosItem_115"] =
{
	zh = "金丝绒衣服",
	en = "Gold Clothes",
	zht = "金絲絨衣服",
}
LocalizationConfig["loc_CostumeSuit_CosItem_116"] =
{
	zh = "羽毛头饰",
	en = "Feather Headwear",
	zht = "羽毛頭飾",
}
LocalizationConfig["loc_CostumeSuit_CosItem_117"] =
{
	zh = "铂金项链",
	en = "Pt Necklace",
	zht = "鉑金項鍊",
}
LocalizationConfig["loc_CostumeSuit_CosItem_118"] =
{
	zh = "白羽扇",
	en = "Feather Fan",
	zht = "白羽扇",
}
LocalizationConfig["loc_CostumeSuit_CosItem_119"] =
{
	zh = "金丝礼服",
	en = "Gold Dress",
	zht = "金絲禮服",
}
LocalizationConfig["loc_CostumeSuit_CosItem_120"] =
{
	zh = "艺妓发簪",
	en = "Geisha Pin",
	zht = "藝妓發簪",
}
LocalizationConfig["loc_CostumeSuit_CosItem_121"] =
{
	zh = "艺妓扇子",
	en = "Geisha Fan",
	zht = "藝妓扇子",
}
LocalizationConfig["loc_CostumeSuit_CosItem_122"] =
{
	zh = "鸡块帽子",
	en = "Nugget Hat",
	zht = "雞塊帽子",
}
LocalizationConfig["loc_CostumeSuit_CosItem_123"] =
{
	zh = "卷饼外套",
	en = "Burrito Jacket",
	zht = "卷餅外套",
}
LocalizationConfig["loc_CostumeSuit_CosItem_124"] =
{
	zh = "生菜领子",
	en = "Lettuce Collar",
	zht = "生菜領子",
}
LocalizationConfig["loc_CostumeSuit_CosItem_125"] =
{
	zh = "软糖花环",
	en = "Candy Garland",
	zht = "軟糖花環",
}
LocalizationConfig["loc_CostumeSuit_CosItem_126"] =
{
	zh = "柔软的裙子",
	en = "Soft Dress",
	zht = "柔軟的裙子",
}
LocalizationConfig["loc_CostumeSuit_CosItem_127"] =
{
	zh = "巧克力翅膀",
	en = "Chocolate Wings",
	zht = "巧克力翅膀",
}
LocalizationConfig["loc_CostumeSuit_CosItem_128"] =
{
	zh = "牛角帽子",
	en = "Croissant Hat",
	zht = "牛角帽子",
}
LocalizationConfig["loc_CostumeSuit_CosItem_129"] =
{
	zh = "玉女剑",
	en = "Jade Blade",
	zht = "玉女劍",
}
LocalizationConfig["loc_CostumeSuit_CosItem_130"] =
{
	zh = "白纱裙",
	en = "Gauze Dress",
	zht = "白紗裙",
}
LocalizationConfig["loc_CostumeSuit_CosItem_131"] =
{
	zh = "甜甜圈",
	en = "Donut",
	zht = "甜甜圈",
}
LocalizationConfig["loc_CostumeSuit_CosItem_132"] =
{
	zh = "缎带",
	en = "Silk Band",
	zht = "緞帶",
}
LocalizationConfig["loc_CostumeSuit_CosItem_133"] =
{
	zh = "草莓小叉",
	en = "Strawberry Fork",
	zht = "草莓小叉",
}
LocalizationConfig["loc_CostumeSuit_CosItem_134"] =
{
	zh = "炸虾头饰",
	en = "Prawn Headwear",
	zht = "炸蝦頭飾",
}
LocalizationConfig["loc_CostumeSuit_CosItem_135"] =
{
	zh = "油炸许可证",
	en = "Frying Permit",
	zht = "油炸許可證",
}
LocalizationConfig["loc_CostumeSuit_CosItem_136"] =
{
	zh = "油纸",
	en = "Grease Paper",
	zht = "油紙",
}
LocalizationConfig["loc_CostumeSuit_CosItem_137"] =
{
	zh = "超厚裙子",
	en = "Heavy Dress",
	zht = "超厚裙子",
}
LocalizationConfig["loc_CostumeSuit_CosItem_138"] =
{
	zh = "辣条帽子",
	en = "Chili Hat",
	zht = "辣條帽子",
}
LocalizationConfig["loc_CostumeSuit_CosItem_139"] =
{
	zh = "黑巧克力条",
	en = "Dark Choc",
	zht = "黑巧克力條",
}
LocalizationConfig["loc_CostumeSuit_CosItem_140"] =
{
	zh = "白巧克力条",
	en = "White Choc",
	zht = "白巧克力條",
}
LocalizationConfig["loc_CostumeSuit_CosItem_141"] =
{
	zh = "高级饼干盒",
	en = "Cookie Case",
	zht = "高級餅乾盒",
}
LocalizationConfig["loc_CostumeSuit_CosItem_142"] =
{
	zh = "加冕皇冠",
	en = "Crown",
	zht = "加冕皇冠",
}
LocalizationConfig["loc_CostumeSuit_CosItem_143"] =
{
	zh = "旋风薯条",
	en = "Curly Fry",
	zht = "旋風薯條",
}
LocalizationConfig["loc_CostumeSuit_CosItem_144"] =
{
	zh = "国王外套",
	en = "Formal Jacket",
	zht = "國王外套",
}
LocalizationConfig["loc_CostumeSuit_CosItem_145"] =
{
	zh = "正装裤子",
	en = "Formal Pants",
	zht = "正裝褲子",
}
LocalizationConfig["loc_CostumeSuit_CosItem_146"] =
{
	zh = "辣酱盖子",
	en = "Chili Lid",
	zht = "辣醬蓋子",
}
LocalizationConfig["loc_CostumeSuit_CosItem_147"] =
{
	zh = "沙拉酱盖子",
	en = "Salad Lid",
	zht = "沙拉醬蓋子",
}
LocalizationConfig["loc_CostumeSuit_CosItem_148"] =
{
	zh = "沙拉酱瓶子",
	en = "Salad Bottle",
	zht = "沙拉醬瓶子",
}
LocalizationConfig["loc_CostumeSuit_CosItem_149"] =
{
	zh = "透明翅膀",
	en = "Salad Wings",
	zht = "透明翅膀",
}
LocalizationConfig["loc_CostumeSuit_CosItem_150"] =
{
	zh = "巧克力酱盖子",
	en = "Choco Lid",
	zht = "巧克力醬蓋子",
}
LocalizationConfig["loc_CostumeSuit_CosItem_151"] =
{
	zh = "巧克力酱瓶子",
	en = "Choco Bottle",
	zht = "巧克力醬瓶子",
}
LocalizationConfig["loc_CostumeSuit_CosItem_152"] =
{
	zh = "简易头盔",
	en = "Simple Helmet",
	zht = "簡易頭盔",
}
LocalizationConfig["loc_CostumeSuit_CosItem_153"] =
{
	zh = "波点马甲",
	en = "Polka Dot Vest",
	zht = "波點馬甲",
}
LocalizationConfig["loc_CostumeSuit_CosItem_154"] =
{
	zh = "白绳腰带",
	en = "White Belt",
	zht = "白繩腰帶",
}
LocalizationConfig["loc_CostumeSuit_CosItem_155"] =
{
	zh = "武士折扇",
	en = "Samurai Fan",
	zht = "武士摺扇",
}
LocalizationConfig["loc_CostumeSuit_CosItem_156"] =
{
	zh = "绿光头套",
	en = "Green Headgear",
	zht = "綠光頭套",
}
LocalizationConfig["loc_CostumeSuit_CosItem_157"] =
{
	zh = "V领上衣",
	en = "V Collar Shirt",
	zht = "V領上衣",
}
LocalizationConfig["loc_CostumeSuit_CosItem_158"] =
{
	zh = "鹿皮半开裙",
	en = "Deerskin Skirt",
	zht = "鹿皮半開裙",
}
LocalizationConfig["loc_CostumeSuit_CosItem_159"] =
{
	zh = "匕首",
	en = "Dagger",
	zht = "匕首",
}
LocalizationConfig["loc_CostumeSuit_CosItem_160"] =
{
	zh = "肩甲上衣",
	en = "Pauldrons",
	zht = "肩甲上衣",
}
LocalizationConfig["loc_CostumeSuit_CosItem_161"] =
{
	zh = "百步弓",
	en = "100-Pace Bow",
	zht = "百步弓",
}
LocalizationConfig["loc_CostumeSuit_CosItem_162"] =
{
	zh = "玉绿头套",
	en = "Jade Headgear",
	zht = "玉綠頭套",
}
LocalizationConfig["loc_CostumeSuit_CosItem_163"] =
{
	zh = "石头王冠",
	en = "Stone Crown",
	zht = "石頭王冠",
}
LocalizationConfig["loc_CostumeSuit_CosItem_164"] =
{
	zh = "藤叶头绳",
	en = "Vine Headband",
	zht = "藤葉頭繩",
}
LocalizationConfig["loc_CostumeSuit_CosItem_165"] =
{
	zh = "喵脆角",
	en = "Crispy Meow Horn",
	zht = "喵脆角",
}
LocalizationConfig["loc_CostumeSuit_CosItem_166"] =
{
	zh = "胸巾",
	en = "Chest Cloth",
	zht = "胸巾",
}
LocalizationConfig["loc_CostumeSuit_CosItem_167"] =
{
	zh = "单边眼罩",
	en = "Eye Patch",
	zht = "單邊眼罩",
}
LocalizationConfig["loc_CostumeSuit_CosItem_168"] =
{
	zh = "猫领结披风",
	en = "Bow Tie Cape",
	zht = "貓領結披風",
}
LocalizationConfig["loc_CostumeSuit_CosItem_169"] =
{
	zh = "英伦马甲",
	en = "English Vest",
	zht = "英倫馬甲",
}
LocalizationConfig["loc_CostumeSuit_CosItem_170"] =
{
	zh = "英伦短裤",
	en = "English Shorts",
	zht = "英倫短褲",
}
LocalizationConfig["loc_CostumeSuit_CosItem_171"] =
{
	zh = "异形眼镜",
	en = "Alien Glasses",
	zht = "異形眼鏡",
}
LocalizationConfig["loc_CostumeSuit_CosItem_172"] =
{
	zh = "立领披风",
	en = "Standup Cape",
	zht = "立領披風",
}
LocalizationConfig["loc_CostumeSuit_CosItem_173"] =
{
	zh = "紫色马甲",
	en = "Purple Vest",
	zht = "紫色馬甲",
}
LocalizationConfig["loc_CostumeSuit_CosItem_174"] =
{
	zh = "紫色裤子",
	en = "Purple Pants",
	zht = "紫色褲子",
}
LocalizationConfig["loc_CostumeSuit_CosItem_175"] =
{
	zh = "假面眼镜",
	en = "False Glasses",
	zht = "假面眼鏡",
}
LocalizationConfig["loc_CostumeSuit_CosItem_176"] =
{
	zh = "白花礼帽",
	en = "Lily Hat",
	zht = "白花禮帽",
}
LocalizationConfig["loc_CostumeSuit_CosItem_177"] =
{
	zh = "标准制服",
	en = "Standard Uniform",
	zht = "標準制服",
}
LocalizationConfig["loc_CostumeSuit_CosItem_178"] =
{
	zh = "西装裤子",
	en = "Suit Pants",
	zht = "西裝褲子",
}
LocalizationConfig["loc_CostumeSuit_CosItem_179"] =
{
	zh = "粗框眼镜",
	en = "Fine Rim Glasses",
	zht = "粗框眼鏡",
}
LocalizationConfig["loc_CostumeSuit_CosItem_180"] =
{
	zh = "绿领巾",
	en = "Green Scarf",
	zht = "綠領巾",
}
LocalizationConfig["loc_CostumeSuit_CosItem_181"] =
{
	zh = "背带裤",
	en = "Overalls",
	zht = "背帶褲",
}
LocalizationConfig["loc_CostumeSuit_CosItem_182"] =
{
	zh = "口袋背心",
	en = "Pocket Vest",
	zht = "口袋背心",
}
LocalizationConfig["loc_CostumeSuit_CosItem_183"] =
{
	zh = "黑色纱巾",
	en = "Black Gauze",
	zht = "黑色紗巾",
}
LocalizationConfig["loc_CostumeSuit_CosItem_184"] =
{
	zh = "粉色纱巾",
	en = "Pink Gauze",
	zht = "粉色紗巾",
}
LocalizationConfig["loc_CostumeSuit_CosItem_185"] =
{
	zh = "假花装饰",
	en = "Fake Flower",
	zht = "假花裝飾",
}
LocalizationConfig["loc_CostumeSuit_CosItem_186"] =
{
	zh = "漆木画框",
	en = "Painted Frame",
	zht = "漆木畫框",
}
LocalizationConfig["loc_CostumeSuit_CosItem_187"] =
{
	zh = "羽毛冠",
	en = "Feather Crown",
	zht = "羽毛冠",
}
LocalizationConfig["loc_CostumeSuit_CosItem_188"] =
{
	zh = "兽齿项链",
	en = "Tooth Torque",
	zht = "獸齒項鍊",
}
LocalizationConfig["loc_CostumeSuit_CosItem_189"] =
{
	zh = "特色敝膝裤",
	en = "Open Knee Pants",
	zht = "特色敝膝褲",
}
LocalizationConfig["loc_CostumeSuit_CosItem_190"] =
{
	zh = "羽毛发带",
	en = "Feather Hairband",
	zht = "羽毛發帶",
}
LocalizationConfig["loc_CostumeSuit_CosItem_191"] =
{
	zh = "麻布敝膝裙",
	en = "Hemp Skirt",
	zht = "麻布敝膝裙",
}
LocalizationConfig["loc_CostumeSuit_CosItem_192"] =
{
	zh = "绿巾腰带",
	en = "Green Cloth Belt",
	zht = "綠巾腰帶",
}
LocalizationConfig["loc_CostumeSuit_CosItem_193"] =
{
	zh = "编绳花辫",
	en = "Rope Braid",
	zht = "編繩花辮",
}
LocalizationConfig["loc_CostumeSuit_CosItem_194"] =
{
	zh = "菱形腰带",
	en = "Diamond Belt",
	zht = "菱形腰帶",
}
LocalizationConfig["loc_CostumeSuit_CosItem_195"] =
{
	zh = "小鸟玩偶",
	en = "Bird Doll",
	zht = "小鳥玩偶",
}
LocalizationConfig["loc_CostumeSuit_CosItem_196"] =
{
	zh = "交叉围巾",
	en = "Cross Scarf",
	zht = "交叉圍巾",
}
LocalizationConfig["loc_CostumeSuit_CosItem_197"] =
{
	zh = "波浪裙",
	en = "Wave Dress",
	zht = "波浪裙",
}
LocalizationConfig["loc_CostumeSuit_CosItem_198"] =
{
	zh = "骑士剑",
	en = "Knight's Sword",
	zht = "騎士劍",
}
LocalizationConfig["loc_CostumeSuit_CosItem_199"] =
{
	zh = "骑士服",
	en = "Knight's Clothes",
	zht = "騎士服",
}
LocalizationConfig["loc_CostumeSuit_CosItem_200"] =
{
	zh = "骑士帽",
	en = "Knight's Hat",
	zht = "騎士帽",
}
LocalizationConfig["loc_CostumeSuit_CosItem_201"] =
{
	zh = "骑士裤",
	en = "Knight's Pants",
	zht = "騎士褲",
}
LocalizationConfig["loc_CostumeSuit_CosItem_202"] =
{
	zh = "功勋帽",
	en = "Exploit Hat",
	zht = "功勳帽",
}
LocalizationConfig["loc_CostumeSuit_CosItem_203"] =
{
	zh = "红披风",
	en = "Red Cloak",
	zht = "紅披風",
}
LocalizationConfig["loc_CostumeSuit_CosItem_204"] =
{
	zh = "腰带",
	en = "Belt",
	zht = "腰帶",
}
LocalizationConfig["loc_CostumeSuit_CosItem_205"] =
{
	zh = "红勋章",
	en = "Red Medal",
	zht = "紅勳章",
}
LocalizationConfig["loc_CostumeSuit_CosItem_206"] =
{
	zh = "花环",
	en = "Garland",
	zht = "花環",
}
LocalizationConfig["loc_CostumeSuit_CosItem_207"] =
{
	zh = "华丽披风",
	en = "Gorgeous Cloak",
	zht = "華麗披風",
}
LocalizationConfig["loc_CostumeSuit_CosItem_208"] =
{
	zh = "手杖",
	en = "Staff",
	zht = "手杖",
}
LocalizationConfig["loc_CostumeSuit_CosItem_209"] =
{
	zh = "加冕长裤",
	en = "Coronation Pants",
	zht = "加冕長褲",
}
LocalizationConfig["loc_CostumeSuit_CosItem_210"] =
{
	zh = "助眠枕头",
	en = "Comfy Pillow",
	zht = "助眠枕頭",
}
LocalizationConfig["loc_CostumeSuit_CosItem_211"] =
{
	zh = "侦探睡裤",
	en = "Pajama Pants",
	zht = "偵探睡褲",
}
LocalizationConfig["loc_CostumeSuit_CosItem_212"] =
{
	zh = "侦探睡衣",
	en = "Pajamas",
	zht = "偵探睡衣",
}
LocalizationConfig["loc_CostumeSuit_CosItem_213"] =
{
	zh = "毛球睡帽",
	en = "Pajama Hat",
	zht = "毛球睡帽",
}
LocalizationConfig["loc_CostumeSuit_CosItem_214"] =
{
	zh = "机械头盔",
	en = "Mecha Helmet",
	zht = "機械頭盔",
}
LocalizationConfig["loc_CostumeSuit_CosItem_215"] =
{
	zh = "呢子大衣",
	en = "Tweed Jacket",
	zht = "呢子大衣",
}
LocalizationConfig["loc_CostumeSuit_CosItem_216"] =
{
	zh = "普通西裤",
	en = "Trousers",
	zht = "普通西褲",
}
LocalizationConfig["loc_CostumeSuit_CosItem_217"] =
{
	zh = "太空头盔",
	en = "Space Helmet",
	zht = "太空頭盔",
}
LocalizationConfig["loc_CostumeSuit_CosItem_218"] =
{
	zh = "女仆上衣",
	en = "Maid Jacket",
	zht = "女僕上衣",
}
LocalizationConfig["loc_CostumeSuit_CosItem_219"] =
{
	zh = "女仆裤子",
	en = "Maid Pants",
	zht = "女僕褲子",
}
LocalizationConfig["loc_CostumeSuit_CosItem_220"] =
{
	zh = "女仆头饰",
	en = "Maid Headgear",
	zht = "女僕頭飾",
}
LocalizationConfig["loc_CostumeSuit_CosItem_221"] =
{
	zh = "女仆雨伞",
	en = "Maid Umbrella",
	zht = "女僕雨傘",
}
LocalizationConfig["loc_CostumeSuit_CosItem_222"] =
{
	zh = "休闲睡衣",
	en = "Comfy Pillow",
	zht = "休閒睡衣",
}
LocalizationConfig["loc_CostumeSuit_CosItem_223"] =
{
	zh = "休闲睡裤",
	en = "Pajama Pants",
	zht = "休閒睡褲",
}
LocalizationConfig["loc_CostumeSuit_CosItem_224"] =
{
	zh = "枕头",
	en = "Pajamas",
	zht = "枕頭",
}
LocalizationConfig["loc_CostumeSuit_CosItem_225"] =
{
	zh = "毛球睡帽",
	en = "Pajama Hat",
	zht = "毛球睡帽",
}
LocalizationConfig["loc_CostumeSuit_CosItem_226"] =
{
	zh = "机械背包",
	en = "Mecha Bag",
	zht = "機械背包",
}
LocalizationConfig["loc_CostumeSuit_CosItem_227"] =
{
	zh = "机械上衣",
	en = "Mecha Jacket",
	zht = "機械上衣",
}
LocalizationConfig["loc_CostumeSuit_CosItem_228"] =
{
	zh = "机械裤子",
	en = "Mecha Pants",
	zht = "機械褲子",
}
LocalizationConfig["loc_CostumeSuit_CosItem_229"] =
{
	zh = "机械帽子",
	en = "Mecha Helmet",
	zht = "機械帽子",
}
LocalizationConfig["loc_CostumeSuit_CosItem_230"] =
{
	zh = "小熊睡帽",
	en = "Bear Hat",
	zht = "小熊睡帽",
}
LocalizationConfig["loc_CostumeSuit_CosItem_231"] =
{
	zh = "小熊睡衣",
	en = "Bear Pajamas",
	zht = "小熊睡衣",
}
LocalizationConfig["loc_CostumeSuit_CosItem_232"] =
{
	zh = "防毒面具",
	en = "Respirator",
	zht = "防毒面具",
}
LocalizationConfig["loc_CostumeSuit_CosItem_233"] =
{
	zh = "工作服",
	en = "Uniform",
	zht = "工作服",
}
LocalizationConfig["loc_CostumeSuit_CosItem_234"] =
{
	zh = "实验背包",
	en = "Experiment Bag",
	zht = "實驗背包",
}
LocalizationConfig["loc_CostumeSuit_CosItem_235"] =
{
	zh = "防爆头盔",
	en = "Blast Helmet",
	zht = "防爆頭盔",
}
LocalizationConfig["loc_CostumeSuit_CosItem_236"] =
{
	zh = "防爆上衣",
	en = "Blast Jacket",
	zht = "防爆上衣",
}
LocalizationConfig["loc_CostumeSuit_CosItem_237"] =
{
	zh = "防爆裤子",
	en = "Blast Pants",
	zht = "防爆褲子",
}
LocalizationConfig["loc_CostumeSuit_CosItem_238"] =
{
	zh = "探照灯",
	en = "Searchlight",
	zht = "探照燈",
}
LocalizationConfig["loc_CostumeSuit_CosItem_239"] =
{
	zh = "淹死鱼缸",
	en = "[未翻译]淹死鱼缸",
	zht = "淹死魚缸",
}
LocalizationConfig["loc_CostumeSuit_CosItem_240"] =
{
	zh = "上吊之绳",
	en = "[未翻译]上吊之绳",
	zht = "上吊之繩",
}
LocalizationConfig["loc_CostumeSuit_CosItem_241"] =
{
	zh = "西装马甲",
	en = "Suit Vest",
	zht = "西裝馬甲",
}
LocalizationConfig["loc_CostumeSuit_CosItem_242"] =
{
	zh = "西装裤子",
	en = "Suit Pants",
	zht = "西裝褲子",
}
LocalizationConfig["loc_CostumeSuit_CosItem_243"] =
{
	zh = "绿正装",
	en = "Green Jacket",
	zht = "綠正裝",
}
LocalizationConfig["loc_CostumeSuit_CosItem_244"] =
{
	zh = "正装裤子",
	en = "Formal Pants",
	zht = "正裝褲子",
}
LocalizationConfig["loc_CostumeSuit_CosItem_245"] =
{
	zh = "假胡子",
	en = "Fake mustache",
	zht = "假鬍子",
}
LocalizationConfig["loc_CostumeSuit_CosItem_246"] =
{
	zh = "作家上衣",
	en = "Writer's Jacket",
	zht = "作家上衣",
}
LocalizationConfig["loc_CostumeSuit_CosItem_247"] =
{
	zh = "作家裤子",
	en = "Writer's Pants",
	zht = "作家褲子",
}
LocalizationConfig["loc_CostumeSuit_CosItem_248"] =
{
	zh = "魔术礼帽",
	en = "Magician Hat",
	zht = "魔術禮帽",
}
LocalizationConfig["loc_CostumeSuit_CosItem_249"] =
{
	zh = "魔术师上衣",
	en = "Magician Jacket",
	zht = "魔術師上衣",
}
LocalizationConfig["loc_CostumeSuit_CosItem_250"] =
{
	zh = "机械小刀",
	en = "Magician Knife",
	zht = "機械小刀",
}
LocalizationConfig["loc_CostumeSuit_CosItem_Des_1"] =
{
	zh = "复古中透着时尚的套装",
	en = "A fashionable vintage set",
	zht = "復古中透著時尚的套裝",
}
LocalizationConfig["loc_CostumeSuit_CosItem_Des_2"] =
{
	zh = "复古中透着时尚的套装",
	en = "A fashionable vintage set",
	zht = "復古中透著時尚的套裝",
}
LocalizationConfig["loc_CostumeSuit_CosItem_Des_3"] =
{
	zh = "你甚至可以在投影仪上养娃",
	en = "You can even raise a child through the projector",
	zht = "你甚至可以在投影儀上養娃",
}
LocalizationConfig["loc_CostumeSuit_CosItem_Des_4"] =
{
	zh = "为了应对随时可能面对的加班而准备的生存包",
	en = "A survival pack prepared to deal with the possibility of overtime at anytime",
	zht = "為了應對隨時可能面對的加班而準備的生存包",
}
LocalizationConfig["loc_CostumeSuit_CosItem_Des_5"] =
{
	zh = "用来修理电脑",
	en = "Used to repair computers",
	zht = "用來修理電腦",
}
LocalizationConfig["loc_CostumeSuit_CosItem_Des_6"] =
{
	zh = "想休息的时候就调成红灯，反之则调成绿灯",
	en = "Just turn it red when you want to rest or green when you don't",
	zht = "想休息的時候就調成紅燈，反之則調成綠燈",
}
LocalizationConfig["loc_CostumeSuit_CosItem_Des_7"] =
{
	zh = "是飞机头不是飞机头",
	en = "It's the head of a plane not the quiff",
	zht = "是飛機頭不是飛機頭",
}
LocalizationConfig["loc_CostumeSuit_CosItem_Des_8"] =
{
	zh = "飞机尾确实是飞机尾",
	en = "It truly is a plane tail",
	zht = "飛機尾確實是飛機尾",
}
LocalizationConfig["loc_CostumeSuit_CosItem_Des_9"] =
{
	zh = "宽大的嘻哈感十足的衣服",
	en = "A baggy jacket that looks really dope",
	zht = "寬大的嘻哈感十足的衣服",
}
LocalizationConfig["loc_CostumeSuit_CosItem_Des_10"] =
{
	zh = "特殊塑料制作的电吉他",
	en = "An electric guitar made from special plastic",
	zht = "特殊塑膠製作的電吉他",
}
LocalizationConfig["loc_CostumeSuit_CosItem_Des_11"] =
{
	zh = "二次元美少女的衣服",
	en = "Beautiful anime girl clothes",
	zht = "二次元美少女的衣服",
}
LocalizationConfig["loc_CostumeSuit_CosItem_Des_12"] =
{
	zh = "为了向自己的偶像致敬定制的帽子",
	en = "A green cap custom-made to pay homage to your idol",
	zht = "為了向自己的偶像致敬定制的帽子",
}
LocalizationConfig["loc_CostumeSuit_CosItem_Des_13"] =
{
	zh = "为了向自己的偶像致敬定制的衣服",
	en = "Green clothes custom-made to pay homage to your idol",
	zht = "為了向自己的偶像致敬定制的衣服",
}
LocalizationConfig["loc_CostumeSuit_CosItem_Des_14"] =
{
	zh = "还是想保留点自己的特色，找了一把欧式长剑",
	en = "Found a European longsword to display a little individuality",
	zht = "還是想保留點自己的特色，找了一把歐式長劍",
}
LocalizationConfig["loc_CostumeSuit_CosItem_Des_15"] =
{
	zh = "弯曲的帽尾可以减少飞行时的阻力",
	en = "The curved tail of the hat reduces resistance when flying",
	zht = "彎曲的帽尾可以減少飛行時的阻力",
}
LocalizationConfig["loc_CostumeSuit_CosItem_Des_16"] =
{
	zh = "襟前镶嵌着有魔力的宝石",
	en = "The front has a magic gem inlaid in it",
	zht = "襟前鑲嵌著有魔力的寶石",
}
LocalizationConfig["loc_CostumeSuit_CosItem_Des_17"] =
{
	zh = "手杖上镶嵌着魔力石",
	en = "A staff inlaid with magic gems",
	zht = "手杖上鑲嵌著魔力石",
}
LocalizationConfig["loc_CostumeSuit_CosItem_Des_18"] =
{
	zh = "奶牛是不长角的，所以这个百分百是个装饰了",
	en = "Cows don't grow horns so this is 100% just for decoration",
	zht = "奶牛是不長角的，所以這個百分百是個裝飾了",
}
LocalizationConfig["loc_CostumeSuit_CosItem_Des_19"] =
{
	zh = "奶牛花纹的上衣",
	en = "Jacket with a cow skin pattern",
	zht = "奶牛花紋的上衣",
}
LocalizationConfig["loc_CostumeSuit_CosItem_Des_20"] =
{
	zh = "白的护士帽，变装派对上常常出现",
	en = "A white nurse's hat that's a regular sight at fancy dress parties",
	zht = "白的護士帽，變裝派對上常常出現",
}
LocalizationConfig["loc_CostumeSuit_CosItem_Des_21"] =
{
	zh = "白色的护士衣，很修身，变装派对上常常出现",
	en = "A slimming white nurse's dress, it's a regular sight at fancy dress parties",
	zht = "白色的護士衣，很修身，變裝派對上常常出現",
}
LocalizationConfig["loc_CostumeSuit_CosItem_Des_22"] =
{
	zh = "扮演护士必不可少的道具",
	en = "A must-have for any nurse's costume",
	zht = "扮演護士必不可少的道具",
}
LocalizationConfig["loc_CostumeSuit_CosItem_Des_23"] =
{
	zh = "扮演护士必不可少的道具",
	en = "A must-have for any nurse's costume",
	zht = "扮演護士必不可少的道具",
}
LocalizationConfig["loc_CostumeSuit_CosItem_Des_24"] =
{
	zh = "神秘的面具，带上就会感觉充满了力量",
	en = "A mysterious mask, wearing it makes you feel full of energy",
	zht = "神秘的面具，帶上就會感覺充滿了力量",
}
LocalizationConfig["loc_CostumeSuit_CosItem_Des_25"] =
{
	zh = "古老的盔甲，轻盈又坚固",
	en = "Ancient armor that's both light and strong",
	zht = "古老的盔甲，輕盈又堅固",
}
LocalizationConfig["loc_CostumeSuit_CosItem_Des_26"] =
{
	zh = "忍者们最擅长使用的小道具",
	en = "The tool that ninjas use the best",
	zht = "忍者們最擅長使用的小道具",
}
LocalizationConfig["loc_CostumeSuit_CosItem_Des_27"] =
{
	zh = "在光线暗的地方，会自动变得更暗",
	en = "It will automatically turn darker in places with less light",
	zht = "在光線暗的地方，會自動變得更暗",
}
LocalizationConfig["loc_CostumeSuit_CosItem_Des_28"] =
{
	zh = "可以很好的影藏在黑夜里的衣服",
	en = "Clothes that allow you to hide in the darkness of the night",
	zht = "可以很好的影藏在黑夜裡的衣服",
}
LocalizationConfig["loc_CostumeSuit_CosItem_Des_29"] =
{
	zh = "在黑夜里，无论怎么挥舞都不会出现刀光",
	en = "During the night, the blade won't reflect any light no mater how you swing it",
	zht = "在黑夜裡，無論怎麼揮舞都不會出現刀光",
}
LocalizationConfig["loc_CostumeSuit_CosItem_Des_30"] =
{
	zh = "只有水果还有一点色彩",
	en = "Only fruit can add a bit of color",
	zht = "只有水果還有一點色彩",
}
LocalizationConfig["loc_CostumeSuit_CosItem_Des_31"] =
{
	zh = "用真狼牙做刺",
	en = "The spikes are made from real wolves' teeth",
	zht = "用真狼牙做刺",
}
LocalizationConfig["loc_CostumeSuit_CosItem_Des_32"] =
{
	zh = "部落每一界新老大都要亲自捕捉并杀死一只野猪",
	en = "Every new leader of the tribe must catch and kill a boar themselves",
	zht = "部落每一界新老大都要親自捕捉並殺死一隻野豬",
}
LocalizationConfig["loc_CostumeSuit_CosItem_Des_33"] =
{
	zh = "美杜莎皇冠，带上之后一头秀发立刻就变成了蛇",
	en = "Medusa's Crown, after wearing it, your hair instantly turns into snakes",
	zht = "美杜莎皇冠，帶上之後一頭秀髮立刻就變成了蛇",
}
LocalizationConfig["loc_CostumeSuit_CosItem_Des_34"] =
{
	zh = "美杜莎女王华丽外衣",
	en = "Queen Medusa's magnificent clothing",
	zht = "美杜莎女王華麗外衣",
}
LocalizationConfig["loc_CostumeSuit_CosItem_Des_35"] =
{
	zh = "大魔王的男装头盔",
	en = "The Dark Lord's male helmet",
	zht = "大魔王的男裝頭盔",
}
LocalizationConfig["loc_CostumeSuit_CosItem_Des_36"] =
{
	zh = "防御力加成的男装盔甲",
	en = "Male armor with a defense bonus",
	zht = "防禦力加成的男裝盔甲",
}
LocalizationConfig["loc_CostumeSuit_CosItem_Des_37"] =
{
	zh = "防御力加成的男装裤子",
	en = "Male pants with a defense bonus",
	zht = "防禦力加成的男裝褲子",
}
LocalizationConfig["loc_CostumeSuit_CosItem_Des_38"] =
{
	zh = "攻击力加成的男款手杖",
	en = "A male rod with an attack bonus",
	zht = "攻擊力加成的男款手杖",
}
LocalizationConfig["loc_CostumeSuit_CosItem_Des_39"] =
{
	zh = "魔王的日常发饰",
	en = "The hair accessory that the Dark Lord wears every day",
	zht = "魔王的日常發飾",
}
LocalizationConfig["loc_CostumeSuit_CosItem_Des_40"] =
{
	zh = "魔王的日常衣服",
	en = "Clothing that the Dark Lord wears every day",
	zht = "魔王的日常衣服",
}
LocalizationConfig["loc_CostumeSuit_CosItem_Des_41"] =
{
	zh = "魔王的日常手杖",
	en = "The scepter that the Dark Lord carries with him every day",
	zht = "魔王的日常手杖",
}
LocalizationConfig["loc_CostumeSuit_CosItem_Des_42"] =
{
	zh = "日常的反派头饰",
	en = "Villains' everyday headwear",
	zht = "日常的反派頭飾",
}
LocalizationConfig["loc_CostumeSuit_CosItem_Des_43"] =
{
	zh = "日常的反派衣服",
	en = "Villains' everyday clothing",
	zht = "日常的反派衣服",
}
LocalizationConfig["loc_CostumeSuit_CosItem_Des_44"] =
{
	zh = "蝙蝠主题的头饰",
	en = "Bat themed headgear",
	zht = "蝙蝠主題的頭飾",
}
LocalizationConfig["loc_CostumeSuit_CosItem_Des_45"] =
{
	zh = "用绿叶捣碎的青汁染成的绿领",
	en = "A green collar dyed from a green dye made from mashed green leaves",
	zht = "用綠葉搗碎的青汁染成的綠領",
}
LocalizationConfig["loc_CostumeSuit_CosItem_Des_46"] =
{
	zh = "可以把你锤到只剩骨头哦",
	en = "It can hammer you into the ground, only leaving bones behind",
	zht = "可以把你錘到只剩骨頭哦",
}
LocalizationConfig["loc_CostumeSuit_CosItem_Des_47"] =
{
	zh = "把钱袋放在外面看起来好像不是很安全呢……",
	en = "Leaving your wallet outside doesn't seem very safe……",
	zht = "把錢袋放在外面看起來好像不是很安全呢……",
}
LocalizationConfig["loc_CostumeSuit_CosItem_Des_48"] =
{
	zh = "树大招风的红旗",
	en = "A red flag that waves in the wind",
	zht = "樹大招風的紅旗",
}
LocalizationConfig["loc_CostumeSuit_CosItem_Des_49"] =
{
	zh = "装着各种奇妙的东西",
	en = "Filled with all sorts of incredible things",
	zht = "裝著各種奇妙的東西",
}
LocalizationConfig["loc_CostumeSuit_CosItem_Des_50"] =
{
	zh = "轻熟女风",
	en = "A young woman's style",
	zht = "輕熟女風",
}
LocalizationConfig["loc_CostumeSuit_CosItem_Des_51"] =
{
	zh = "收音品质优良",
	en = "It has great reception",
	zht = "收音品質優良",
}
LocalizationConfig["loc_CostumeSuit_CosItem_Des_52"] =
{
	zh = "虽然是筒裙，但走起路来依然方便",
	en = "It may be a tube skirt, but it's still easy to walk around in",
	zht = "雖然是筒裙，但走起路來依然方便",
}
LocalizationConfig["loc_CostumeSuit_CosItem_Des_53"] =
{
	zh = "冷兵器狩猎时代",
	en = "The age of cold weapon hunting",
	zht = "冷兵器狩獵時代",
}
LocalizationConfig["loc_CostumeSuit_CosItem_Des_54"] =
{
	zh = "带上就能回到从年轻的样子，再也不想脱下来了",
	en = "Wearing it will take you back to your youth, once it's on you won't want to take it off",
	zht = "帶上就能回到從年輕的樣子，再也不想脫下來了",
}
LocalizationConfig["loc_CostumeSuit_CosItem_Des_55"] =
{
	zh = "投币启动卫兵",
	en = "Insert coin to activate guard",
	zht = "投幣啟動衛兵",
}
LocalizationConfig["loc_CostumeSuit_CosItem_Des_56"] =
{
	zh = "金属打造，走起路来会有金属碰撞的声音",
	en = "Made from metal, you can hear it clang when you walk",
	zht = "金屬打造，走起路來會有金屬碰撞的聲音",
}
LocalizationConfig["loc_CostumeSuit_CosItem_Des_57"] =
{
	zh = "不是只有年轻女生的女仆装才叫女仆装",
	en = "Maids outfits are not just for young women",
	zht = "不是只有年輕女生的女僕裝才叫女僕裝",
}
LocalizationConfig["loc_CostumeSuit_CosItem_Des_58"] =
{
	zh = "扫地时穿得衣服",
	en = "Convenient for sweeping floors in",
	zht = "掃地時穿得衣服",
}
LocalizationConfig["loc_CostumeSuit_CosItem_Des_59"] =
{
	zh = "礼帽上配了个别致的胡萝卜色毛毡兔头",
	en = "A hat with a pair of unique carrot-colored bunny ears",
	zht = "禮帽上配了個別致的胡蘿蔔色毛氈兔頭",
}
LocalizationConfig["loc_CostumeSuit_CosItem_Des_60"] =
{
	zh = "衣襟合一起时像一只红蝴蝶",
	en = "When the robe is brought together it looks like a red butterfly",
	zht = "衣襟合一起時像一隻紅蝴蝶",
}
LocalizationConfig["loc_CostumeSuit_CosItem_Des_61"] =
{
	zh = "黑色的头冠，带上之后适合使用黑魔法",
	en = "A black crown, suited for using black magic",
	zht = "黑色的頭冠，帶上之後適合使用黑魔法",
}
LocalizationConfig["loc_CostumeSuit_CosItem_Des_62"] =
{
	zh = "黑色的衣服，穿上之后适合使用黑魔法",
	en = "Black clothes, suited for using black magic",
	zht = "黑色的衣服，穿上之後適合使用黑魔法",
}
LocalizationConfig["loc_CostumeSuit_CosItem_Des_63"] =
{
	zh = "黑色的裙子，穿上之后适合使用黑魔法",
	en = "A black dress, suited for using black magic",
	zht = "黑色的裙子，穿上之後適合使用黑魔法",
}
LocalizationConfig["loc_CostumeSuit_CosItem_Des_64"] =
{
	zh = "白色的头冠，带上之后光明魔法加成",
	en = "A white crown, gives the wearer a light magic bonus upon wearing",
	zht = "白色的頭冠，帶上之後光明魔法加成",
}
LocalizationConfig["loc_CostumeSuit_CosItem_Des_65"] =
{
	zh = "白色的上衣，穿上之后光明魔法加成",
	en = "A white coat, it gives the wearer a light magic bonus upon wearing",
	zht = "白色的上衣，穿上之後光明魔法加成",
}
LocalizationConfig["loc_CostumeSuit_CosItem_Des_66"] =
{
	zh = "白色的裙子，穿上之后光明魔法加成",
	en = "White dress, gives the wearer a light magic bonus upon wearing",
	zht = "白色的裙子，穿上之後光明魔法加成",
}
LocalizationConfig["loc_CostumeSuit_CosItem_Des_67"] =
{
	zh = "琉璃皇冠，皇冠中的奢侈品",
	en = "A glazed crown, it's luxurious even for a crown",
	zht = "琉璃皇冠，皇冠中的奢侈品",
}
LocalizationConfig["loc_CostumeSuit_CosItem_Des_68"] =
{
	zh = "顶级仿真毛皮制作的华丽披风",
	en = "A delightful cape made from top-grade artificial fur",
	zht = "頂級模擬毛皮製作的華麗披風",
}
LocalizationConfig["loc_CostumeSuit_CosItem_Des_69"] =
{
	zh = "土旧老式制服",
	en = "Old-fashioned style costume",
	zht = "土舊老式制服",
}
LocalizationConfig["loc_CostumeSuit_CosItem_Des_70"] =
{
	zh = "只有戴上帽子才能盖住灵感",
	en = "Only by wearing this hat can you contain your inspiration",
	zht = "只有戴上帽子才能蓋住靈感",
}
LocalizationConfig["loc_CostumeSuit_CosItem_Des_71"] =
{
	zh = "还没有完全长大的龙角",
	en = "A dragon horn that hasn't completely grown up",
	zht = "還沒有完全長大的龍角",
}
LocalizationConfig["loc_CostumeSuit_CosItem_Des_72"] =
{
	zh = "华丽绸缎制作的上衣，当然是具备防水功能的",
	en = "A magnificent jacket made from silk, it's waterproof of course",
	zht = "華麗綢緞製作的上衣，當然是具備防水功能的",
}
LocalizationConfig["loc_CostumeSuit_CosItem_Des_73"] =
{
	zh = "华丽绸缎制作的下装，当然是具备防水功能的",
	en = "Magnificent pants made from silk, they're waterproof of course",
	zht = "華麗綢緞製作的下裝，當然是具備防水功能的",
}
LocalizationConfig["loc_CostumeSuit_CosItem_Des_74"] =
{
	zh = "龙太子最爱吃的食物",
	en = "The Dragon Prince's favorite food",
	zht = "龍太子最愛吃的食物",
}
LocalizationConfig["loc_CostumeSuit_CosItem_Des_75"] =
{
	zh = "已经成熟的大龙角",
	en = "A fully mature dragon horn",
	zht = "已經成熟的大龍角",
}
LocalizationConfig["loc_CostumeSuit_CosItem_Des_76"] =
{
	zh = "高级的绸缎制作的上衣，不仅防水还抗压力",
	en = "A jacket made from top silk, not only water resistant but pressure resistant too",
	zht = "高級的綢緞製作的上衣，不僅防水還抗壓力",
}
LocalizationConfig["loc_CostumeSuit_CosItem_Des_77"] =
{
	zh = "高级的绸缎制作的上衣，不仅防水还抗压力",
	en = "Pants made from top silk, not only water resistant but pressure resistant too",
	zht = "高級的綢緞製作的上衣，不僅防水還抗壓力",
}
LocalizationConfig["loc_CostumeSuit_CosItem_Des_78"] =
{
	zh = "海龙王最爱吃的食物",
	en = "The Sea Dragon King's favorite food",
	zht = "海龍王最愛吃的食物",
}
LocalizationConfig["loc_CostumeSuit_CosItem_Des_79"] =
{
	zh = "无袖马甲方便活动",
	en = "A sleeveless vest that is easy to move around in",
	zht = "無袖馬甲方便活動",
}
LocalizationConfig["loc_CostumeSuit_CosItem_Des_80"] =
{
	zh = "维京猎龙人留下来的帽子",
	en = "A hat left by Viking dragon hunters",
	zht = "維京獵龍人留下來的帽子",
}
LocalizationConfig["loc_CostumeSuit_CosItem_Des_81"] =
{
	zh = "维京猎龙人留下来的上衣",
	en = "A jacket left by Viking dragon hunters",
	zht = "維京獵龍人留下來的上衣",
}
LocalizationConfig["loc_CostumeSuit_CosItem_Des_82"] =
{
	zh = "维京猎龙人留下来的锤子",
	en = "A hammer left by Viking dragon hunters",
	zht = "維京獵龍人留下來的錘子",
}
LocalizationConfig["loc_CostumeSuit_CosItem_Des_83"] =
{
	zh = "造型可爱的发饰",
	en = "A cute headband",
	zht = "造型可愛的發飾",
}
LocalizationConfig["loc_CostumeSuit_CosItem_Des_84"] =
{
	zh = "从龙身上取得材料制作而成的上衣",
	en = "A jacket made from materials taken from a dragon's body",
	zht = "從龍身上取得材料製作而成的上衣",
}
LocalizationConfig["loc_CostumeSuit_CosItem_Des_85"] =
{
	zh = "从龙身上取得材料制作而成的下装",
	en = "Pants made from materials taken from a dragon's body",
	zht = "從龍身上取得材料製作而成的下裝",
}
LocalizationConfig["loc_CostumeSuit_CosItem_Des_86"] =
{
	zh = "体积庞大的武器，使用起来需要很大的力气",
	en = "A ginormous weapon, requires a lot of strength to wield it",
	zht = "體積龐大的武器，使用起來需要很大的力氣",
}
LocalizationConfig["loc_CostumeSuit_CosItem_Des_87"] =
{
	zh = "常常因为风太大而不停的追帽子",
	en = "A hat fat often gets blown off the wearers head by strong winds",
	zht = "常常因為風太大而不停的追帽子",
}
LocalizationConfig["loc_CostumeSuit_CosItem_Des_88"] =
{
	zh = "风沙大时可以用来遮面",
	en = "Can be used to cover your face during sandstorms",
	zht = "風沙大時可以用來遮面",
}
LocalizationConfig["loc_CostumeSuit_CosItem_Des_89"] =
{
	zh = "杀伤力极强",
	en = "Extremely deadly",
	zht = "殺傷力極強",
}
LocalizationConfig["loc_CostumeSuit_CosItem_Des_90"] =
{
	zh = "穿着的人完全不在意衣服怎样，只在意手中的机械玩偶",
	en = "Those who wear it are not at all bothered about how their clothes look, they're just bothered about the mechanical doll in their hand",
	zht = "穿著的人完全不在意衣服怎樣，只在意手中的機械玩偶",
}
LocalizationConfig["loc_CostumeSuit_CosItem_Des_91"] =
{
	zh = "动画最爱的机械木偶",
	en = "The wooden mechanical doll most loved by cartoons",
	zht = "動畫最愛的機械木偶",
}
LocalizationConfig["loc_CostumeSuit_CosItem_Des_92"] =
{
	zh = "形状非常特殊，半透明的外壳，可以看见里面真的没脑子",
	en = "A specially shaped helmet, the outer shell is translucent allowing you to see that there really isn't any brain inside",
	zht = "形狀非常特殊，半透明的外殼，可以看見裡面真的沒腦子",
}
LocalizationConfig["loc_CostumeSuit_CosItem_Des_93"] =
{
	zh = "形状怪异的上衣",
	en = "An oddly shaped jacket",
	zht = "形狀怪異的上衣",
}
LocalizationConfig["loc_CostumeSuit_CosItem_Des_94"] =
{
	zh = "像小宠物一样漂浮在半空的虫子，不知道会不会突然张嘴抱住你的脸",
	en = "A little bug that floats in mid-air, it's unsure whether or not it'll suddenly open its mouth and suck on your face",
	zht = "像小寵物一樣漂浮在半空的蟲子，不知道會不會突然張嘴抱住你的臉",
}
LocalizationConfig["loc_CostumeSuit_CosItem_Des_95"] =
{
	zh = "形状怪异的尾巴",
	en = "An oddly shaped tail",
	zht = "形狀怪異的尾巴",
}
LocalizationConfig["loc_CostumeSuit_CosItem_Des_96"] =
{
	zh = "非常专业的防尘上衣，穿上之后立刻化身女战神",
	en = "An extremely professional dustcoat, after wearing it you'll automatically turn into a warrior goddess",
	zht = "非常專業的防塵上衣，穿上之後立刻化身女戰神",
}
LocalizationConfig["loc_CostumeSuit_CosItem_Des_97"] =
{
	zh = "非常专业的防尘裤子，穿上之后立刻化身女战神",
	en = "Extremely professional dust pants, after wearing them you'll automatically turn into a warrior goddess",
	zht = "非常專業的防塵褲子，穿上之後立刻化身女戰神",
}
LocalizationConfig["loc_CostumeSuit_CosItem_Des_98"] =
{
	zh = "保护头骨的头盔，有些残缺，凑合着用吧",
	en = "A helmet that protects the skill, there are bits missing, make do with it the best you can",
	zht = "保護頭骨的頭盔，有些殘缺，湊合著用吧",
}
LocalizationConfig["loc_CostumeSuit_CosItem_Des_99"] =
{
	zh = "红蓝搭配的颜色才是经典",
	en = "Blue and red is a classic match",
	zht = "紅藍搭配的顏色才是經典",
}
LocalizationConfig["loc_CostumeSuit_CosItem_Des_100"] =
{
	zh = "红蓝搭配的颜色才是经典",
	en = "Blue and red is a classic match",
	zht = "紅藍搭配的顏色才是經典",
}
LocalizationConfig["loc_CostumeSuit_CosItem_Des_101"] =
{
	zh = "铝制的红色小盖子",
	en = "A little aluminum red cap",
	zht = "鋁制的紅色小蓋子",
}
LocalizationConfig["loc_CostumeSuit_CosItem_Des_102"] =
{
	zh = "用来装饰粉红色的头发非常合适",
	en = "It really suits pink hair",
	zht = "用來裝飾粉紅色的頭髮非常合適",
}
LocalizationConfig["loc_CostumeSuit_CosItem_Des_103"] =
{
	zh = "画有樱花图案的和风外套",
	en = "An oriental-style overgarment with cherry blossom drawings on it",
	zht = "畫有櫻花圖案的和風外套",
}
LocalizationConfig["loc_CostumeSuit_CosItem_Des_104"] =
{
	zh = "使用一点就会让全身都散发出樱花的香甜味道",
	en = "By just using a little, you can make your whole body smell of cherry blossoms",
	zht = "使用一點就會讓全身都散發出櫻花的香甜味道",
}
LocalizationConfig["loc_CostumeSuit_CosItem_Des_105"] =
{
	zh = "深黑色的帽子，带上会显得特别酷",
	en = "A pitch-black hat, wearing it will make you look really cool",
	zht = "深黑色的帽子，帶上會顯得特別酷",
}
LocalizationConfig["loc_CostumeSuit_CosItem_Des_106"] =
{
	zh = "能迅速降温的高科技胸针，带上立刻降到零度不结冰的状态",
	en = "A broach with advanced technology that rapidly reduces temperature, wearing it will instantly reduce the temperature to zero degrees without freezing the wearer",
	zht = "能迅速降溫的高科技胸針，帶上立刻降到零度不結冰的狀態",
}
LocalizationConfig["loc_CostumeSuit_CosItem_Des_107"] =
{
	zh = "穿上立刻能蒸发掉身体里的糖份，但缺还能喝起来有甜味",
	en = "Wearing it will instantly burn off all the sugar within your body, but you can still experience the sweetness of soft drinks",
	zht = "穿上立刻能蒸發掉身體裡的糖份，但缺還能喝起來有甜味",
}
LocalizationConfig["loc_CostumeSuit_CosItem_Des_108"] =
{
	zh = "奶油堆积装饰而成的帽子",
	en = "A hat made from a pile of cream",
	zht = "奶油堆積裝飾而成的帽子",
}
LocalizationConfig["loc_CostumeSuit_CosItem_Des_109"] =
{
	zh = "巧克力做成的抹胸，不知道穿在身上会不会化掉",
	en = "A chocolate tube top, be careful it doesn't melt while you're wearing it",
	zht = "巧克力做成的抹胸，不知道穿在身上會不會化掉",
}
LocalizationConfig["loc_CostumeSuit_CosItem_Des_110"] =
{
	zh = "绒绒的绿色外套，",
	en = "A furry green jacket",
	zht = "絨絨的綠色外套，",
}
LocalizationConfig["loc_CostumeSuit_CosItem_Des_111"] =
{
	zh = "使用一点就会让全身都散发出抹茶的香味",
	en = "By just using a little, you can make your whole body smell of green tea",
	zht = "使用一點就會讓全身都散發出抹茶的香味",
}
LocalizationConfig["loc_CostumeSuit_CosItem_Des_112"] =
{
	zh = "带上就会变成五彩爆米花",
	en = "Wearing it will turn you into rainbow popcorn",
	zht = "帶上就會變成五彩爆米花",
}
LocalizationConfig["loc_CostumeSuit_CosItem_Des_113"] =
{
	zh = "闪闪发光的红色琉璃耳环",
	en = "Shiny red glazed earrings",
	zht = "閃閃發光的紅色琉璃耳環",
}
LocalizationConfig["loc_CostumeSuit_CosItem_Des_114"] =
{
	zh = "调味专用的桃心手杖",
	en = "A heart rod specially used to add flavor",
	zht = "調味專用的桃心手杖",
}
LocalizationConfig["loc_CostumeSuit_CosItem_Des_115"] =
{
	zh = "五彩爆米花专用的盒子",
	en = "The box used to hold rainbow popcorn",
	zht = "五彩爆米花專用的盒子",
}
LocalizationConfig["loc_CostumeSuit_CosItem_Des_116"] =
{
	zh = "白天鹅羽毛做成的装饰",
	en = "Headgear made from swan's feathers",
	zht = "白天鵝羽毛做成的裝飾",
}
LocalizationConfig["loc_CostumeSuit_CosItem_Des_117"] =
{
	zh = "贵重金属制作的项链",
	en = "A necklace made from a precious metal",
	zht = "貴重金屬製作的項鍊",
}
LocalizationConfig["loc_CostumeSuit_CosItem_Des_118"] =
{
	zh = "白天鹅羽毛做成的装饰",
	en = "Headgear made from swan's feathers",
	zht = "白天鵝羽毛做成的裝飾",
}
LocalizationConfig["loc_CostumeSuit_CosItem_Des_119"] =
{
	zh = "天鹅绒加上金属丝线编制而成的爆米花礼盒",
	en = "A popcorn giftbox made from swan feathers and woven gold thread",
	zht = "天鵝絨加上金屬絲線編制而成的爆米花禮盒",
}
LocalizationConfig["loc_CostumeSuit_CosItem_Des_120"] =
{
	zh = "据说越是简单朴素的发簪越是能体现艺妓地位高",
	en = "It's said that the plainness of the hairpin represents a Geisha's status, with the plainer hairpins indicating a higher status",
	zht = "據說越是簡單樸素的發簪越是能體現藝妓地位高",
}
LocalizationConfig["loc_CostumeSuit_CosItem_Des_121"] =
{
	zh = "艺妓跳舞专用的扇子",
	en = "A fan used to perform Geisha dances",
	zht = "藝妓跳舞專用的扇子",
}
LocalizationConfig["loc_CostumeSuit_CosItem_Des_122"] =
{
	zh = "香喷喷炸鸡块，肉食主义最爱",
	en = "Delicious smelling chicken nuggets, a meat eater's favorite",
	zht = "香噴噴炸雞塊，肉食主義最愛",
}
LocalizationConfig["loc_CostumeSuit_CosItem_Des_123"] =
{
	zh = "墨西哥原产的麦香卷饼",
	en = "A delicious Mexican burrito",
	zht = "墨西哥原產的麥香卷餅",
}
LocalizationConfig["loc_CostumeSuit_CosItem_Des_124"] =
{
	zh = "健康的蔬菜大翻领",
	en = "A healthy lettuce lapel",
	zht = "健康的蔬菜大翻領",
}
LocalizationConfig["loc_CostumeSuit_CosItem_Des_125"] =
{
	zh = "什锦水果味软糖花环",
	en = "A garland made from assorted fruit flavor gum drops",
	zht = "什錦水果味軟糖花環",
}
LocalizationConfig["loc_CostumeSuit_CosItem_Des_126"] =
{
	zh = "软糯的蛋糕做成的裙子",
	en = "A dress made from glutinous rice cake",
	zht = "軟糯的蛋糕做成的裙子",
}
LocalizationConfig["loc_CostumeSuit_CosItem_Des_127"] =
{
	zh = "巧克力脆片做的装饰翅膀",
	en = "Decorative wings made from thin and crunchy chocolate pieces",
	zht = "巧克力脆片做的裝飾翅膀",
}
LocalizationConfig["loc_CostumeSuit_CosItem_Des_128"] =
{
	zh = "法式牛角面包大礼帽",
	en = "A top hat made from French croissants",
	zht = "法式牛角麵包大禮帽",
}
LocalizationConfig["loc_CostumeSuit_CosItem_Des_129"] =
{
	zh = "威力巨大的魔剑，但是力量却一直被剑上面的小笼包压制着",
	en = "A powerful enchanted sword, but its power is suppressed by the small steamed buns on it",
	zht = "威力巨大的魔劍，但是力量卻一直被劍上面的小籠包壓制著",
}
LocalizationConfig["loc_CostumeSuit_CosItem_Des_130"] =
{
	zh = "轻盈的白纱裙，自带一股仙气",
	en = "A light white gauze dress, it gives the wearer and angelic look",
	zht = "輕盈的白紗裙，自帶一股仙氣",
}
LocalizationConfig["loc_CostumeSuit_CosItem_Des_131"] =
{
	zh = "把甜甜圈当装饰戴在头上假装成侍女",
	en = "Wear a donut on your head and pretend to be a maid",
	zht = "把甜甜圈當裝飾戴在頭上假裝成侍女",
}
LocalizationConfig["loc_CostumeSuit_CosItem_Des_132"] =
{
	zh = "汉服里的标准搭配",
	en = "A standard part of a Hanfu garment",
	zht = "漢服裡的標準搭配",
}
LocalizationConfig["loc_CostumeSuit_CosItem_Des_133"] =
{
	zh = "据说草莓是特意插在上面当装饰的，不许吃的",
	en = "It's said that the strawberry is stuck on top of it as decoration, you're not allowed to eat it!",
	zht = "據說草莓是特意插在上面當裝飾的，不許吃的",
}
LocalizationConfig["loc_CostumeSuit_CosItem_Des_134"] =
{
	zh = "能把炸虾当做头饰也是需要很大的勇气",
	en = "Using fried shrimp to adorn the head requires a lot of courage",
	zht = "能把炸蝦當做頭飾也是需要很大的勇氣",
}
LocalizationConfig["loc_CostumeSuit_CosItem_Des_135"] =
{
	zh = "非常关键的部件，要是没有它你无法穿上整套换装",
	en = "A crucial part of the set, if you don't have this, you won't be able to wear the whole set",
	zht = "非常關鍵的部件，要是沒有它你無法穿上整套換裝",
}
LocalizationConfig["loc_CostumeSuit_CosItem_Des_136"] =
{
	zh = "炸虾太油了，油纸可以吸掉一些油",
	en = "Fried shrimp is too oily, greaseproof paper can absorb some of the oil",
	zht = "炸蝦太油了，油紙可以吸掉一些油",
}
LocalizationConfig["loc_CostumeSuit_CosItem_Des_137"] =
{
	zh = "保暖效果特别好的裙子",
	en = "A dress that is extremely well insulated",
	zht = "保暖效果特別好的裙子",
}
LocalizationConfig["loc_CostumeSuit_CosItem_Des_138"] =
{
	zh = "非常火爆的辣条帽子，看上去不怒自威",
	en = "A fiery chili strip hat, it gives a really stern look",
	zht = "非常火爆的辣條帽子，看上去不怒自威",
}
LocalizationConfig["loc_CostumeSuit_CosItem_Des_139"] =
{
	zh = "浓郁的黑巧克力条",
	en = "A strip of dark chocolate",
	zht = "濃郁的黑巧克力條",
}
LocalizationConfig["loc_CostumeSuit_CosItem_Des_140"] =
{
	zh = "甜而不腻的白巧克力条",
	en = "A sweet but not sickly strip of white chocolate",
	zht = "甜而不膩的白巧克力條",
}
LocalizationConfig["loc_CostumeSuit_CosItem_Des_141"] =
{
	zh = "用来装巧克力饼干条的高级盒子",
	en = "A sophisticated case used for holding chocolate cookies",
	zht = "用來裝巧克力餅乾條的高級盒子",
}
LocalizationConfig["loc_CostumeSuit_CosItem_Des_142"] =
{
	zh = "加冕仪式上的正式皇冠",
	en = "The official crown used during coronations",
	zht = "加冕儀式上的正式皇冠",
}
LocalizationConfig["loc_CostumeSuit_CosItem_Des_143"] =
{
	zh = "原本直着的头发烫一下变成卷发了",
	en = "Straight hair that's been curled with an iron",
	zht = "原本直著的頭髮燙一下變成卷髮了",
}
LocalizationConfig["loc_CostumeSuit_CosItem_Des_144"] =
{
	zh = "国王的正装外套",
	en = "The king's formal jacket",
	zht = "國王的正裝外套",
}
LocalizationConfig["loc_CostumeSuit_CosItem_Des_145"] =
{
	zh = "国王的正装西裤",
	en = "The king's formal suit pants",
	zht = "國王的正裝西褲",
}
LocalizationConfig["loc_CostumeSuit_CosItem_Des_146"] =
{
	zh = "帽子翻开来里面都有一层厚厚的辣油",
	en = "Turn over the hat and you'll see a thick layer of chili oil inside",
	zht = "帽子翻開來裡面都有一層厚厚的辣油",
}
LocalizationConfig["loc_CostumeSuit_CosItem_Des_147"] =
{
	zh = "白色的带着一股香味的帽子",
	en = "A white, delicious-smelling hat",
	zht = "白色的帶著一股香味的帽子",
}
LocalizationConfig["loc_CostumeSuit_CosItem_Des_148"] =
{
	zh = "透明的瓶子包裹着白色的酱料，搭配各种蔬菜都很美味",
	en = "A white sauce encased by a transparent bottle, it's delicious with any type of vegetable",
	zht = "透明的瓶子包裹著白色的醬料，搭配各種蔬菜都很美味",
}
LocalizationConfig["loc_CostumeSuit_CosItem_Des_149"] =
{
	zh = "白色的带着一股香味的天使翅膀",
	en = "White, delicious-smelling angel wings",
	zht = "白色的帶著一股香味的天使翅膀",
}
LocalizationConfig["loc_CostumeSuit_CosItem_Des_150"] =
{
	zh = "黏腻的巧克力酱帽子，上面居然还插了一根没吃完的饼干条",
	en = "A hat made from gooey chocolate sauce, there's an uneaten dip stick still in it",
	zht = "黏膩的巧克力醬帽子，上面居然還插了一根沒吃完的餅乾條",
}
LocalizationConfig["loc_CostumeSuit_CosItem_Des_151"] =
{
	zh = "里面的巧克力酱适合涂抹在各种面包上吃",
	en = "The chocolate sauce inside is great spread across any kind of bread",
	zht = "裡面的巧克力醬適合塗抹在各種麵包上吃",
}
LocalizationConfig["loc_CostumeSuit_CosItem_Des_152"] =
{
	zh = "基础款武士头套",
	en = "A samurai's most basic headgear",
	zht = "基礎款武士頭套",
}
LocalizationConfig["loc_CostumeSuit_CosItem_Des_153"] =
{
	zh = "流行波点元素与传统元素相碰撞",
	en = "A coming together of popular polka dots with traditional elements",
	zht = "流行波點元素與傳統元素相碰撞",
}
LocalizationConfig["loc_CostumeSuit_CosItem_Des_154"] =
{
	zh = "由于手经常蹭到而逐渐变黑",
	en = "Has turned black after being frequently rubbed by hands",
	zht = "由於手經常蹭到而逐漸變黑",
}
LocalizationConfig["loc_CostumeSuit_CosItem_Des_155"] =
{
	zh = "和头套上扇子配套",
	en = "A matching fan to go with the headgear",
	zht = "和頭套上扇子配套",
}
LocalizationConfig["loc_CostumeSuit_CosItem_Des_156"] =
{
	zh = "这就是爱",
	en = "This is true love",
	zht = "這就是愛",
}
LocalizationConfig["loc_CostumeSuit_CosItem_Des_157"] =
{
	zh = "就算布料笨重也不能来忘了来点吸睛的设计",
	en = "Even with cumbersome material, you can't forget a fine design",
	zht = "就算布料笨重也不能來忘了來點吸睛的設計",
}
LocalizationConfig["loc_CostumeSuit_CosItem_Des_158"] =
{
	zh = "百褶裙上搭配半块梅花鹿皮，野性中带着俏皮",
	en = "A pleated skirt with half of a reindeer pelt, both wild and smart-looking",
	zht = "百褶裙上搭配半塊梅花鹿皮，野性中帶著俏皮",
}
LocalizationConfig["loc_CostumeSuit_CosItem_Des_159"] =
{
	zh = "能轻易的划开动物的肚皮",
	en = "An animal's stomach that can be easily cut open",
	zht = "能輕易的劃開動物的肚皮",
}
LocalizationConfig["loc_CostumeSuit_CosItem_Des_160"] =
{
	zh = "保护胳膊",
	en = "Protects the arms",
	zht = "保護胳膊",
}
LocalizationConfig["loc_CostumeSuit_CosItem_Des_161"] =
{
	zh = "据说拿到就可以百步穿杨的弓",
	en = "It's said to be a bow that fires with pinpoint accuracy",
	zht = "據說拿到就可以百步穿楊的弓",
}
LocalizationConfig["loc_CostumeSuit_CosItem_Des_162"] =
{
	zh = "专为没有头发的人制作",
	en = "Made specially for those without hair",
	zht = "專為沒有頭髮的人製作",
}
LocalizationConfig["loc_CostumeSuit_CosItem_Des_163"] =
{
	zh = "头能千斤顶的人才能戴",
	en = "Only the most talented of people can wear it",
	zht = "頭能千斤頂的人才能戴",
}
LocalizationConfig["loc_CostumeSuit_CosItem_Des_164"] =
{
	zh = "时尚又环保",
	en = "Fashionable and environmentally friendly",
	zht = "時尚又環保",
}
LocalizationConfig["loc_CostumeSuit_CosItem_Des_165"] =
{
	zh = "饿的时候可以拿下来吃",
	en = "You can take it off and eat it when you're hungry",
	zht = "餓的時候可以拿下來吃",
}
LocalizationConfig["loc_CostumeSuit_CosItem_Des_166"] =
{
	zh = "犹抱琵琶半遮面",
	en = "Covers half the face",
	zht = "猶抱琵琶半遮面",
}
LocalizationConfig["loc_CostumeSuit_CosItem_Des_167"] =
{
	zh = "戴单边眼罩的十有八九都是中二病",
	en = "80-90% of people with eye patches are immature kids",
	zht = "戴單邊眼罩的十有八九都是中二病",
}
LocalizationConfig["loc_CostumeSuit_CosItem_Des_168"] =
{
	zh = "猫头领结内别有洞天",
	en = "There's a paradise inside the cat's head bow tie",
	zht = "貓頭領結內別有洞天",
}
LocalizationConfig["loc_CostumeSuit_CosItem_Des_169"] =
{
	zh = "侦探必备",
	en = "A must-have for detectives",
	zht = "偵探必備",
}
LocalizationConfig["loc_CostumeSuit_CosItem_Des_170"] =
{
	zh = "绅士风",
	en = "Very Genteel",
	zht = "紳士風",
}
LocalizationConfig["loc_CostumeSuit_CosItem_Des_171"] =
{
	zh = "作为没有镜腿的眼镜，不知道是怎么挂在脸上的",
	en = "A pair of glasses without the temple, not quite sure about how to wear them",
	zht = "作為沒有鏡腿的眼鏡，不知道是怎麼掛在臉上的",
}
LocalizationConfig["loc_CostumeSuit_CosItem_Des_172"] =
{
	zh = "可以遮住双下巴",
	en = "Can hide a double chin",
	zht = "可以遮住雙下巴",
}
LocalizationConfig["loc_CostumeSuit_CosItem_Des_173"] =
{
	zh = "神秘的颜色配神秘的人",
	en = "A mysterious color for a mysterious person",
	zht = "神秘的顏色配神秘的人",
}
LocalizationConfig["loc_CostumeSuit_CosItem_Des_174"] =
{
	zh = "没什么特色",
	en = "Nothing particularly special",
	zht = "沒什麼特色",
}
LocalizationConfig["loc_CostumeSuit_CosItem_Des_175"] =
{
	zh = "单向镜面，别人看不到你的眼睛",
	en = "One-way lenses, others aren't able to see your eyes",
	zht = "單向鏡面，別人看不到你的眼睛",
}
LocalizationConfig["loc_CostumeSuit_CosItem_Des_176"] =
{
	zh = "可以遮住发际线",
	en = "Can conceal hairlines",
	zht = "可以遮住髮際線",
}
LocalizationConfig["loc_CostumeSuit_CosItem_Des_177"] =
{
	zh = "穿这个的也可能是服务生哦",
	en = "Whoever wears this might be a waiter",
	zht = "穿這個的也可能是服務生哦",
}
LocalizationConfig["loc_CostumeSuit_CosItem_Des_178"] =
{
	zh = "太普通了，不值得多说",
	en = "Too common, nothing else worth saying",
	zht = "太普通了，不值得多說",
}
LocalizationConfig["loc_CostumeSuit_CosItem_Des_179"] =
{
	zh = "小小年纪写了太多作业，早早就戴上了厚重的眼镜",
	en = "Kids who do too much homework at a young age have to wear this pair of thick glasses early on in life",
	zht = "小小年紀寫了太多作業，早早就戴上了厚重的眼鏡",
}
LocalizationConfig["loc_CostumeSuit_CosItem_Des_180"] =
{
	zh = "再熬熬就可以换红领巾了",
	en = "If you keep it up for a bit longer you can swap a red scarf",
	zht = "再熬熬就可以換紅領巾了",
}
LocalizationConfig["loc_CostumeSuit_CosItem_Des_181"] =
{
	zh = "真的不是反人类设计吗",
	en = "Doesn't this design really go against humanity?",
	zht = "真的不是反人類設計嗎",
}
LocalizationConfig["loc_CostumeSuit_CosItem_Des_182"] =
{
	zh = "手太短的话可能插不进兜里",
	en = "If your arms are too short, you might not be able to reach inside the pocket",
	zht = "手太短的話可能插不進兜裡",
}
LocalizationConfig["loc_CostumeSuit_CosItem_Des_183"] =
{
	zh = "纱巾自带假发哦",
	en = "Gauze with its own wig",
	zht = "紗巾自帶假髮哦",
}
LocalizationConfig["loc_CostumeSuit_CosItem_Des_184"] =
{
	zh = "发色热辣",
	en = "A hot and sexy hair color",
	zht = "發色熱辣",
}
LocalizationConfig["loc_CostumeSuit_CosItem_Des_185"] =
{
	zh = "点缀画框的小装饰",
	en = "A small ornament for adorning picture frames",
	zht = "點綴畫框的小裝飾",
}
LocalizationConfig["loc_CostumeSuit_CosItem_Des_186"] =
{
	zh = "春色满框框不住",
	en = "The full color of spring bursts out from the picture",
	zht = "春色滿框框不住",
}
LocalizationConfig["loc_CostumeSuit_CosItem_Des_187"] =
{
	zh = "插满了羽毛，气势十足",
	en = "Filled with feathers, gives an imposing look",
	zht = "插滿了羽毛，氣勢十足",
}
LocalizationConfig["loc_CostumeSuit_CosItem_Des_188"] =
{
	zh = "力量的象征",
	en = "A symbol of power",
	zht = "力量的象徵",
}
LocalizationConfig["loc_CostumeSuit_CosItem_Des_189"] =
{
	zh = "上面绣着古老的图腾",
	en = "Embroidered with an ancient totem on it",
	zht = "上面繡著古老的圖騰",
}
LocalizationConfig["loc_CostumeSuit_CosItem_Des_190"] =
{
	zh = "适合夏天佩戴",
	en = "Suitable for wearing in summer",
	zht = "適合夏天佩戴",
}
LocalizationConfig["loc_CostumeSuit_CosItem_Des_191"] =
{
	zh = "缝缝补补又三年",
	en = "It's been patched up and mended for three years",
	zht = "縫縫補補又三年",
}
LocalizationConfig["loc_CostumeSuit_CosItem_Des_192"] =
{
	zh = "把绿领巾当腰带使",
	en = "Using the green scarf as a belt",
	zht = "把綠領巾當腰帶使",
}
LocalizationConfig["loc_CostumeSuit_CosItem_Des_193"] =
{
	zh = "很特别的发型",
	en = "A very unique hairstyle",
	zht = "很特別的髮型",
}
LocalizationConfig["loc_CostumeSuit_CosItem_Des_194"] =
{
	zh = "与菱形纹上衣相呼应",
	en = "Goes splendidly with the diamond-patterned shirt",
	zht = "與菱形紋上衣相呼應",
}
LocalizationConfig["loc_CostumeSuit_CosItem_Des_195"] =
{
	zh = "焦色小鸟",
	en = "A brown bird",
	zht = "焦色小鳥",
}
LocalizationConfig["loc_CostumeSuit_CosItem_Des_196"] =
{
	zh = "挡风装饰两不误",
	en = "Can be used equally well for guarding against the wind or as decoration",
	zht = "擋風裝飾兩不誤",
}
LocalizationConfig["loc_CostumeSuit_CosItem_Des_197"] =
{
	zh = "桃子红，粉嫩嫩",
	en = "A lovely, tender peach color",
	zht = "桃子紅，粉嫩嫩",
}
LocalizationConfig["loc_CostumeSuit_CosItem_Des_198"] =
{
	zh = "没人看见的时候可以串上肉当烤叉用",
	en = "When no one's looking, it can be used as a fork for grilled meat",
	zht = "沒人看見的時候可以串上肉當烤叉用",
}
LocalizationConfig["loc_CostumeSuit_CosItem_Des_199"] =
{
	zh = "绒线镶边，帅气又精致",
	en = "Its woven edges make it both handsome and exquisite",
	zht = "絨線鑲邊，帥氣又精緻",
}
LocalizationConfig["loc_CostumeSuit_CosItem_Des_200"] =
{
	zh = "帽大不挡风",
	en = "A hat that doesn't really stop much wind",
	zht = "帽大不擋風",
}
LocalizationConfig["loc_CostumeSuit_CosItem_Des_201"] =
{
	zh = "专为骑士设计的裤子，超强弹力又耐磨",
	en = "Pants designed especially for knights, they have extremely good elasticity and durability",
	zht = "專為騎士設計的褲子，超強彈力又耐磨",
}
LocalizationConfig["loc_CostumeSuit_CosItem_Des_202"] =
{
	zh = "帽子上的圆圈让人想要瞄准",
	en = "The circle on the top of the hat makes people want to aim at it",
	zht = "帽子上的圓圈讓人想要瞄準",
}
LocalizationConfig["loc_CostumeSuit_CosItem_Des_203"] =
{
	zh = "好、、好重啊",
	en = "Sooooo heavy",
	zht = "好、、好重啊",
}
LocalizationConfig["loc_CostumeSuit_CosItem_Des_204"] =
{
	zh = "努力勒出腰线",
	en = "Try hard to bring in the waistline",
	zht = "努力勒出腰線",
}
LocalizationConfig["loc_CostumeSuit_CosItem_Des_205"] =
{
	zh = "获得某项成就得到的奖励",
	en = "A rewards obtained from earning some achievement",
	zht = "獲得某項成就得到的獎勵",
}
LocalizationConfig["loc_CostumeSuit_CosItem_Des_206"] =
{
	zh = "和平大使即视感",
	en = "Gives the look of an ambassador of peace",
	zht = "和平大使即視感",
}
LocalizationConfig["loc_CostumeSuit_CosItem_Des_207"] =
{
	zh = "附带口水巾",
	en = "Comes with bib attached",
	zht = "附帶口水巾",
}
LocalizationConfig["loc_CostumeSuit_CosItem_Des_208"] =
{
	zh = "有让人想要举起来的魔力",
	en = "Has the magic power to make people want to put their hands in the air",
	zht = "有讓人想要舉起來的魔力",
}
LocalizationConfig["loc_CostumeSuit_CosItem_Des_209"] =
{
	zh = "加冕仪式中穿着的长裤",
	en = "Pants worn for coronation ceremonies",
	zht = "加冕儀式中穿著的長褲",
}
LocalizationConfig["loc_CostumeSuit_CosItem_Des_210"] =
{
	zh = "躺上去帮助睡眠，一觉睡到大天亮",
	en = "Lie on it and it'll help you sleep well, being able to sleep all the way through to mid-morning daylight",
	zht = "躺上去幫助睡眠，一覺睡到大天亮",
}
LocalizationConfig["loc_CostumeSuit_CosItem_Des_211"] =
{
	zh = "在家就不要穿那么随便啦",
	en = "You probably shouldn't dress so freely even at home",
	zht = "在家就不要穿那麼隨便啦",
}
LocalizationConfig["loc_CostumeSuit_CosItem_Des_212"] =
{
	zh = "在家就不要穿那么随便啦",
	en = "You probably shouldn't dress so freely even at home",
	zht = "在家就不要穿那麼隨便啦",
}
LocalizationConfig["loc_CostumeSuit_CosItem_Des_213"] =
{
	zh = "在家就不要穿那么随便啦",
	en = "You probably shouldn't dress so freely even at home",
	zht = "在家就不要穿那麼隨便啦",
}
LocalizationConfig["loc_CostumeSuit_CosItem_Des_214"] =
{
	zh = "复古中透着时尚的套装",
	en = "A fashionable vintage set",
	zht = "復古中透著時尚的套裝",
}
LocalizationConfig["loc_CostumeSuit_CosItem_Des_215"] =
{
	zh = "流行英剧当中的造型",
	en = "Modelled after popular English TV dramas",
	zht = "流行英劇當中的造型",
}
LocalizationConfig["loc_CostumeSuit_CosItem_Des_216"] =
{
	zh = "流行英剧当中的造型",
	en = "Modelled after popular English TV dramas",
	zht = "流行英劇當中的造型",
}
LocalizationConfig["loc_CostumeSuit_CosItem_Des_217"] =
{
	zh = "想要太空旅行，安全第一",
	en = "Safety first if you want to travel to outer space",
	zht = "想要太空旅行，安全第一",
}
LocalizationConfig["loc_CostumeSuit_CosItem_Des_218"] =
{
	zh = "请问需要什么帮助吗",
	en = "Excuse me, do you need anything?",
	zht = "請問需要什麼説明嗎",
}
LocalizationConfig["loc_CostumeSuit_CosItem_Des_219"] =
{
	zh = "请问需要什么帮助吗",
	en = "Excuse me, do you need anything?",
	zht = "請問需要什麼説明嗎",
}
LocalizationConfig["loc_CostumeSuit_CosItem_Des_220"] =
{
	zh = "请问需要什么帮助吗",
	en = "Excuse me, do you need anything?",
	zht = "請問需要什麼説明嗎",
}
LocalizationConfig["loc_CostumeSuit_CosItem_Des_221"] =
{
	zh = "请问需要什么帮助吗",
	en = "Excuse me, do you need anything?",
	zht = "請問需要什麼説明嗎",
}
LocalizationConfig["loc_CostumeSuit_CosItem_Des_222"] =
{
	zh = "躺上去帮助睡眠，一觉睡到大天亮",
	en = "Lie on it and it'll help you sleep well, being able to sleep all the way through to mid-morning daylight",
	zht = "躺上去幫助睡眠，一覺睡到大天亮",
}
LocalizationConfig["loc_CostumeSuit_CosItem_Des_223"] =
{
	zh = "在家就不要穿那么随便啦",
	en = "You probably shouldn't dress so freely even at home",
	zht = "在家就不要穿那麼隨便啦",
}
LocalizationConfig["loc_CostumeSuit_CosItem_Des_224"] =
{
	zh = "在家就不要穿那么随便啦",
	en = "You probably shouldn't dress so freely even at home",
	zht = "在家就不要穿那麼隨便啦",
}
LocalizationConfig["loc_CostumeSuit_CosItem_Des_225"] =
{
	zh = "在家就不要穿那么随便啦",
	en = "You probably shouldn't dress so freely even at home",
	zht = "在家就不要穿那麼隨便啦",
}
LocalizationConfig["loc_CostumeSuit_CosItem_Des_226"] =
{
	zh = "复古中透着时尚的套装",
	en = "A fashionable vintage set",
	zht = "復古中透著時尚的套裝",
}
LocalizationConfig["loc_CostumeSuit_CosItem_Des_227"] =
{
	zh = "复古中透着时尚的套装",
	en = "A fashionable vintage set",
	zht = "復古中透著時尚的套裝",
}
LocalizationConfig["loc_CostumeSuit_CosItem_Des_228"] =
{
	zh = "复古中透着时尚的套装",
	en = "A fashionable vintage set",
	zht = "復古中透著時尚的套裝",
}
LocalizationConfig["loc_CostumeSuit_CosItem_Des_229"] =
{
	zh = "复古中透着时尚的套装",
	en = "A fashionable vintage set",
	zht = "復古中透著時尚的套裝",
}
LocalizationConfig["loc_CostumeSuit_CosItem_Des_230"] =
{
	zh = "无论白天是什么样子，睡觉前一定要把自己打扮的萌萌的",
	en = "No matter what your day was like, you should always dress up nice and cute before bed",
	zht = "無論白天是什麼樣子，睡覺前一定要把自己打扮的萌萌的",
}
LocalizationConfig["loc_CostumeSuit_CosItem_Des_231"] =
{
	zh = "无论白天是什么样子，睡觉前一定要把自己打扮的萌萌的",
	en = "No matter what your day was like, you should always dress up nice and cute before bed",
	zht = "無論白天是什麼樣子，睡覺前一定要把自己打扮的萌萌的",
}
LocalizationConfig["loc_CostumeSuit_CosItem_Des_232"] =
{
	zh = "做化学实验必备的防毒面具",
	en = "You should always wear a respirator when conducting chemical experiments",
	zht = "做化學實驗必備的防毒面具",
}
LocalizationConfig["loc_CostumeSuit_CosItem_Des_233"] =
{
	zh = "实验室专用的工作服",
	en = "A laboratory uniform",
	zht = "實驗室專用的工作服",
}
LocalizationConfig["loc_CostumeSuit_CosItem_Des_234"] =
{
	zh = "为了随时随地做实验的化学背包",
	en = "A chemistry bag that allows you to perform experiments anytime, anywhere",
	zht = "為了隨時隨地做實驗的化學背包",
}
LocalizationConfig["loc_CostumeSuit_CosItem_Des_235"] =
{
	zh = "看起来坚硬无比的头盔，防弹又防爆",
	en = "A helmet that looks extremely solid, it can protect against both bullets and explosion blasts",
	zht = "看起來堅硬無比的頭盔，防彈又防爆",
}
LocalizationConfig["loc_CostumeSuit_CosItem_Des_236"] =
{
	zh = "特级警察专门的上衣",
	en = "A jacket worn by SWAT team members",
	zht = "特級員警專門的上衣",
}
LocalizationConfig["loc_CostumeSuit_CosItem_Des_237"] =
{
	zh = "特级警察专门的裤子",
	en = "Pants worn by SWAT team members",
	zht = "特級員警專門的褲子",
}
LocalizationConfig["loc_CostumeSuit_CosItem_Des_238"] =
{
	zh = "会360度旋转的探照灯，是不是能照亮目标不一定，但一定会暴露自己",
	en = "A searchlight that can rotate 360 degrees, it won't necessarily expose its target, but it will definitely expose itself",
	zht = "會360度旋轉的探照燈，是不是能照亮目標不一定，但一定會暴露自己",
}
LocalizationConfig["loc_CostumeSuit_CosItem_Des_239"] =
{
	zh = "倒着放也不会漏水的高级鱼缸",
	en = "A sophisticated fish tank that won't drip water even when it's placed upside down",
	zht = "倒著放也不會漏水的高級魚缸",
}
LocalizationConfig["loc_CostumeSuit_CosItem_Des_240"] =
{
	zh = "看似古典的工具，自动收缩功能广受好评",
	en = "Looks like a classic tool, its automatic shrinking feature has earned it wide acclaim",
	zht = "看似古典的工具，自動收縮功能廣受好評",
}
LocalizationConfig["loc_CostumeSuit_CosItem_Des_241"] =
{
	zh = "日常穿着的马甲，轻便又实用",
	en = "A vest that can be worn every day, both light and functional",
	zht = "日常穿著的馬甲，輕便又實用",
}
LocalizationConfig["loc_CostumeSuit_CosItem_Des_242"] =
{
	zh = "日常穿着的裤子，非常舒适",
	en = "Pants that can be worn every day, really comfortable",
	zht = "日常穿著的褲子，非常舒適",
}
LocalizationConfig["loc_CostumeSuit_CosItem_Des_243"] =
{
	zh = "在正式场合穿着的西装外套，很有气势",
	en = "A suit jacket that can be worn on formal occasions, gives a very dignified appearance",
	zht = "在正式場合穿著的西裝外套，很有氣勢",
}
LocalizationConfig["loc_CostumeSuit_CosItem_Des_244"] =
{
	zh = "在正式场合穿着的裤子，非常正经",
	en = "Pants than can be worn on formal occasions, give a really respectable appearance",
	zht = "在正式場合穿著的褲子，非常正經",
}
LocalizationConfig["loc_CostumeSuit_CosItem_Des_245"] =
{
	zh = "带上之后立刻变得很成熟，再也不会被叫小学生了",
	en = "Gives a really mature look upon wearing, you won't be called a school kid anymore with this on",
	zht = "帶上之後立刻變得很成熟，再也不會被叫小學生了",
}
LocalizationConfig["loc_CostumeSuit_CosItem_Des_246"] =
{
	zh = "款式成熟的外套，穿上就再也不会被叫小学生了",
	en = "A mature-looking jacket, you won't be called a school kid anymore with this on",
	zht = "款式成熟的外套，穿上就再也不會被叫小學生了",
}
LocalizationConfig["loc_CostumeSuit_CosItem_Des_247"] =
{
	zh = "款式成熟的裤子，穿上就再也不会被叫小学生了",
	en = "Mature-looking pants, you won't be called a school kid anymore with this on",
	zht = "款式成熟的褲子，穿上就再也不會被叫小學生了",
}
LocalizationConfig["loc_CostumeSuit_CosItem_Des_248"] =
{
	zh = "魔术师专用大礼帽，里面藏了各种奇怪的道具",
	en = "A hat specially worn by magicians, there are all sorts of strange items hidden within it",
	zht = "魔術師專用大禮帽，裡面藏了各種奇怪的道具",
}
LocalizationConfig["loc_CostumeSuit_CosItem_Des_249"] =
{
	zh = "魔术师专用上衣，黑色披风下面也是藏着很多机关",
	en = "A jacket specially worn by magicians, there's a load of devices hidden under the black cape",
	zht = "魔術師專用上衣，黑色披風下面也是藏著很多機關",
}
LocalizationConfig["loc_CostumeSuit_CosItem_Des_250"] =
{
	zh = "魔术师专用的表演道具",
	en = "Used by magicians during magic performances",
	zht = "魔術師專用的表演道具",
}
LocalizationConfig["loc_DecaItem_Name_1"] =
{
	zh = "小书柜",
	en = "Bookcase",
	zht = "小書櫃",
}
LocalizationConfig["loc_DecaItem_Name_2"] =
{
	zh = "普通的吊灯",
	en = "Light",
	zht = "普通的吊燈",
}
LocalizationConfig["loc_DecaItem_Name_3"] =
{
	zh = "普通的沙发",
	en = "Sofa",
	zht = "普通的沙發",
}
LocalizationConfig["loc_DecaItem_Name_4"] =
{
	zh = "普通的桌子",
	en = "Table",
	zht = "普通的桌子",
}
LocalizationConfig["loc_DecaItem_Name_5"] =
{
	zh = "普通的画",
	en = "Painting",
	zht = "普通的畫",
}
LocalizationConfig["loc_DecaItem_Name_6"] =
{
	zh = "星际窗户",
	en = "Cosmic Window",
	zht = "星際窗戶",
}
LocalizationConfig["loc_DecaItem_Name_7"] =
{
	zh = "甜蜜五斗柜",
	en = "Sweet Drawers",
	zht = "甜蜜五斗櫃",
}
LocalizationConfig["loc_DecaItem_Name_8"] =
{
	zh = "甜蜜吊灯",
	en = "Sweet Light",
	zht = "甜蜜吊燈",
}
LocalizationConfig["loc_DecaItem_Name_9"] =
{
	zh = "华夫饼沙发",
	en = "Waffle Sofa",
	zht = "華夫餅沙發",
}
LocalizationConfig["loc_DecaItem_Name_10"] =
{
	zh = "纸杯蛋糕桌",
	en = "Cupcake Table",
	zht = "紙杯蛋糕桌",
}
LocalizationConfig["loc_DecaItem_Name_11"] =
{
	zh = "棒棒糖挂饰",
	en = "Lollipop Hanging",
	zht = "棒棒糖掛飾",
}
LocalizationConfig["loc_DecaItem_Name_12"] =
{
	zh = "甜点展示柜",
	en = "Snack Case",
	zht = "甜點展示櫃",
}
LocalizationConfig["loc_DecaItem_Name_13"] =
{
	zh = "重金属矮柜",
	en = "Metal Cabinet",
	zht = "重金屬矮櫃",
}
LocalizationConfig["loc_DecaItem_Name_14"] =
{
	zh = "蒸汽朋克时钟",
	en = "Steampunk Clock",
	zht = "蒸汽朋克時鐘",
}
LocalizationConfig["loc_DecaItem_Name_15"] =
{
	zh = "蒸汽朋克轮椅",
	en = "Metal Wheelchair",
	zht = "蒸汽朋克輪椅",
}
LocalizationConfig["loc_DecaItem_Name_16"] =
{
	zh = "重金属之桌",
	en = "Metal Table",
	zht = "重金屬之桌",
}
LocalizationConfig["loc_DecaItem_Name_17"] =
{
	zh = "重金属圆窗",
	en = "Metal Window",
	zht = "重金屬圓窗",
}
LocalizationConfig["loc_DecaItem_Name_18"] =
{
	zh = "数据显示屏",
	en = "Data Display",
	zht = "資料顯示屏",
}
LocalizationConfig["loc_DecaItem_Name_19"] =
{
	zh = "橱柜",
	en = "Cabinet",
	zht = "櫥櫃",
}
LocalizationConfig["loc_DecaItem_Name_20"] =
{
	zh = "飞碟吊灯",
	en = "UFO Light",
	zht = "飛碟吊燈",
}
LocalizationConfig["loc_DecaItem_Name_21"] =
{
	zh = "粉红沙发",
	en = "Pink Sofa",
	zht = "粉紅沙發",
}
LocalizationConfig["loc_DecaItem_Name_22"] =
{
	zh = "酒桶桌",
	en = "Keg Table",
	zht = "酒桶桌",
}
LocalizationConfig["loc_DecaItem_Name_23"] =
{
	zh = "转轮电话",
	en = "Rotary Phone",
	zht = "轉輪電話",
}
LocalizationConfig["loc_DecaItem_Name_24"] =
{
	zh = "小电视",
	en = "TV",
	zht = "小電視",
}
LocalizationConfig["loc_DecaItem_Name_25"] =
{
	zh = "休眠舱",
	en = "Stasis Chamber",
	zht = "休眠艙",
}
LocalizationConfig["loc_DecaItem_Name_26"] =
{
	zh = "矿洞吊灯",
	en = "Mine Lamp",
	zht = "礦洞吊燈",
}
LocalizationConfig["loc_DecaItem_Name_27"] =
{
	zh = "古典沙发",
	en = "Classic Sofa",
	zht = "古典沙發",
}
LocalizationConfig["loc_DecaItem_Name_28"] =
{
	zh = "早餐木桌",
	en = "Breakfast Table",
	zht = "早餐木桌",
}
LocalizationConfig["loc_DecaItem_Name_29"] =
{
	zh = "挂花",
	en = "Hanging Flowers",
	zht = "掛花",
}
LocalizationConfig["loc_DecaItem_Name_30"] =
{
	zh = "怪兽电视",
	en = "Monster TV",
	zht = "怪獸電視",
}
LocalizationConfig["loc_DecaItem_Name_31"] =
{
	zh = "猫架",
	en = "Cat Tree",
	zht = "貓架",
}
LocalizationConfig["loc_DecaItem_Name_32"] =
{
	zh = "鬼面吊灯",
	en = "Monster Light",
	zht = "鬼面吊燈",
}
LocalizationConfig["loc_DecaItem_Name_33"] =
{
	zh = "文化人沙发",
	en = "Cultured Sofa",
	zht = "文化人沙發",
}
LocalizationConfig["loc_DecaItem_Name_34"] =
{
	zh = "公园石桌",
	en = "Stone Table",
	zht = "公園石桌",
}
LocalizationConfig["loc_DecaItem_Name_35"] =
{
	zh = "天使壁挂",
	en = "Angel Hanging",
	zht = "天使壁掛",
}
LocalizationConfig["loc_DecaItem_Name_36"] =
{
	zh = "窗电一体显示屏",
	en = "Window Monitor",
	zht = "窗電一體顯示幕",
}
LocalizationConfig["loc_DecaItem_Name_37"] =
{
	zh = "电子取票机",
	en = "Ticket Machine",
	zht = "電子取票機",
}
LocalizationConfig["loc_DecaItem_Name_38"] =
{
	zh = "投影仪",
	en = "Projector",
	zht = "投影儀",
}
LocalizationConfig["loc_DecaItem_Name_39"] =
{
	zh = "按摩沙发",
	en = "Massage Chair",
	zht = "按摩沙發",
}
LocalizationConfig["loc_DecaItem_Name_40"] =
{
	zh = "影院餐桌",
	en = "Theater Table",
	zht = "影院餐桌",
}
LocalizationConfig["loc_DecaItem_Name_41"] =
{
	zh = "电影海报",
	en = "Theater Poster",
	zht = "電影海報",
}
LocalizationConfig["loc_DecaItem_Name_42"] =
{
	zh = "电影预告屏",
	en = "Trailer Screen",
	zht = "電影預告屏",
}
LocalizationConfig["loc_DecaItem_Name_43"] =
{
	zh = "任务看板",
	en = "Work Board",
	zht = "任務看板",
}
LocalizationConfig["loc_DecaItem_Name_44"] =
{
	zh = "蜜蜂吊灯",
	en = "Bee Light",
	zht = "蜜蜂吊燈",
}
LocalizationConfig["loc_DecaItem_Name_45"] =
{
	zh = "卧龙石座",
	en = "Dragon Seat",
	zht = "臥龍石座",
}
LocalizationConfig["loc_DecaItem_Name_46"] =
{
	zh = "龙之餐桌",
	en = "Dragon Table",
	zht = "龍之餐桌",
}
LocalizationConfig["loc_DecaItem_Name_47"] =
{
	zh = "龙牙火炬",
	en = "Dragon Torch",
	zht = "龍牙火炬",
}
LocalizationConfig["loc_DecaItem_Name_48"] =
{
	zh = "龙晶显示屏",
	en = "Obsidian Screen",
	zht = "龍晶顯示幕",
}
LocalizationConfig["loc_DecaItem_Name_49"] =
{
	zh = "街机柜子",
	en = "Arcade Cupboard",
	zht = "街機櫃子",
}
LocalizationConfig["loc_DecaItem_Name_50"] =
{
	zh = "格斗吊灯",
	en = "Fighter Light",
	zht = "格鬥吊燈",
}
LocalizationConfig["loc_DecaItem_Name_51"] =
{
	zh = "赛车街机",
	en = "Arcade Racer",
	zht = "賽車街機",
}
LocalizationConfig["loc_DecaItem_Name_52"] =
{
	zh = "双人投币对战桌",
	en = "Arcade Table",
	zht = "雙人投幣對戰桌",
}
LocalizationConfig["loc_DecaItem_Name_53"] =
{
	zh = "游戏海报",
	en = "Game Poster",
	zht = "遊戲海報",
}
LocalizationConfig["loc_DecaItem_Name_54"] =
{
	zh = "游戏机之窗",
	en = "Console Window",
	zht = "遊戲機之窗",
}
LocalizationConfig["loc_DecaItem_Name_55"] =
{
	zh = "机器人充电桩",
	en = "Robot Charger",
	zht = "機器人充電樁",
}
LocalizationConfig["loc_DecaItem_Name_56"] =
{
	zh = "老式吊灯",
	en = "Vintage Light",
	zht = "老式吊燈",
}
LocalizationConfig["loc_DecaItem_Name_57"] =
{
	zh = "斯格特之窗",
	en = "Scott's Window",
	zht = "斯格特之窗",
}
LocalizationConfig["loc_DecaItem_Name_58"] =
{
	zh = "超能饮料售货机",
	en = "Vending Machine",
	zht = "超能飲料售貨機",
}
LocalizationConfig["loc_DecaItem_Name_59"] =
{
	zh = "小鸟灯",
	en = "Bird Light",
	zht = "小鳥燈",
}
LocalizationConfig["loc_DecaItem_Name_60"] =
{
	zh = "遥控器型电视",
	en = "Remote TV",
	zht = "遙控器型電視",
}
LocalizationConfig["loc_DecaItem_Des_1"] =
{
	zh = "初始的小书柜，简陋的很。",
	en = "A basic, crude bookshelf.",
	zht = "初始的小書櫃，簡陋的很。",
}
LocalizationConfig["loc_DecaItem_Des_2"] =
{
	zh = "普通的贴皮吊灯，有时候会因为接触不良一闪一闪的，有点吓人。",
	en = "A regular upholstered ceiling light, sometimes it will flicker due to a lose connection, pretty spooky.",
	zht = "普通的貼皮吊燈，有時候會因為接觸不良一閃一閃的，有點嚇人。",
}
LocalizationConfig["loc_DecaItem_Des_3"] =
{
	zh = "初始的普通沙发，粗糙的皮质，坐上去有点不舒服。",
	en = "A regular, basic sofa with crude leather, it’s not too comfy to sit on.",
	zht = "初始的普通沙發，粗糙的皮質，坐上去有點不舒服。",
}
LocalizationConfig["loc_DecaItem_Des_4"] =
{
	zh = "初始的普通桌子，桌子上还放着一些欢迎水果。",
	en = "A basic table, someone’s even placed a welcome basket on it.",
	zht = "初始的普通桌子，桌子上還放著一些歡迎水果。",
}
LocalizationConfig["loc_DecaItem_Des_5"] =
{
	zh = "初始挂画，也不知道是谁随便挂上去的，就一直留在那里了。",
	en = "A basic hang-up painting, you don’t know who put it there, it’s just been left there the whole time.",
	zht = "初始掛畫，也不知道是誰隨便掛上去的，就一直留在那裡了。",
}
LocalizationConfig["loc_DecaItem_Des_6"] =
{
	zh = "飞船初始的窗户，普通的窗框，普通的玻璃，稍微有点不一样的大概就是那对小猫耳朵了。",
	en = "A basic ship window, it has a regular frame and normal glass. The only thing that's any different is probably the pair of cat ears.",
	zht = "飛船初始的窗戶，普通的窗框，普通的玻璃，稍微有點不一樣的大概就是那對小貓耳朵了。",
}
LocalizationConfig["loc_DecaItem_Des_7"] =
{
	zh = "用千层蛋糕堆成小矮柜的样子，抽屉拉开里面全都是奶油。",
	en = "A chest of drawers made from stacks of layer cake, the drawers are filled with cream.",
	zht = "用千層蛋糕堆成小矮櫃的樣子，抽屜拉開裡面全都是奶油。",
}
LocalizationConfig["loc_DecaItem_Des_8"] =
{
	zh = "蛋糕做的吊灯，点燃的蜡烛烤着蛋糕上的奶油，不知道会不会滴下来。",
	en = "A light made out of cake, the lit candle heats the cream on the cake, don't know whether it'll drip down.",
	zht = "蛋糕做的吊燈，點燃的蠟燭烤著蛋糕上的奶油，不知道會不會滴下來。",
}
LocalizationConfig["loc_DecaItem_Des_9"] =
{
	zh = "华夫饼制作的沙发，椅背上是厚厚的蜂蜜，坐上去不知道会不会被粘住。",
	en = "A sofa made of waffles, the back of the sofa is covered in a thick layer of honey, you might get stuck when leaning on it.",
	zht = "華夫餅製作的沙發，椅背上是厚厚的蜂蜜，坐上去不知道會不會被粘住。",
}
LocalizationConfig["loc_DecaItem_Des_10"] =
{
	zh = "纸杯蛋糕做成的桌子，在上面吃东西会不知不觉的把桌子也吃掉吧。",
	en = "A table made from cupcakes, be careful not to eat the table itself when dining on it.",
	zht = "紙杯蛋糕做成的桌子，在上面吃東西會不知不覺的把桌子也吃掉吧。",
}
LocalizationConfig["loc_DecaItem_Des_11"] =
{
	zh = "棒棒糖和棉花糖组合的壁挂装饰。",
	en = "A wall hanging made from lollipops and cotton candy.",
	zht = "棒棒糖和棉花糖組合的壁掛裝飾。",
}
LocalizationConfig["loc_DecaItem_Des_12"] =
{
	zh = "柜子里面放了各种面包甜点，还自带温控保鲜系统，随便什么时候拿出来都是很新鲜的。",
	en = "All sorts of breads and snacks are kept inside the case, it even has a temperature control system meaning the snacks are always fresh.",
	zht = "櫃子裡面放了各種麵包甜點，還自帶溫控保鮮系統，隨便什麼時候拿出來都是很新鮮的。",
}
LocalizationConfig["loc_DecaItem_Des_13"] =
{
	zh = "有着蒸汽朋克风格的矮柜",
	en = "A steampunk style cabinet",
	zht = "有著蒸汽朋克風格的矮櫃",
}
LocalizationConfig["loc_DecaItem_Des_14"] =
{
	zh = "蒸汽朋克风格的挂钟，造型复杂，表盘却很小。",
	en = "A steampunk style clock, it's extremely complex, but the dial's really small.",
	zht = "蒸汽朋克風格的掛鐘，造型複雜，錶盤卻很小。",
}
LocalizationConfig["loc_DecaItem_Des_15"] =
{
	zh = "看起来像是一堆废铁拼凑出来的椅子，实际上功能齐全还具备人体工程学的设计。",
	en = "A chair that looks like it's made out of scrap metal, but it's actually fully functional and even has an ergonomic design.",
	zht = "看起來像是一堆廢鐵拼湊出來的椅子，實際上功能齊全還具備人體工程學的設計。",
}
LocalizationConfig["loc_DecaItem_Des_16"] =
{
	zh = "混合金属制作的餐桌，非常笨重，对于那些坐在腿脚喜欢乱踢的人，可是非常实用，完全踢不动。",
	en = "A breakfast table made from a mixture of metals, extremely cumbersome but extremely useful for those who enjoy kicking their legs when sitting down, it won't move an inch if kicked.",
	zht = "混合金屬製作的餐桌，非常笨重，對於那些坐在腿腳喜歡亂踢的人，可是非常實用，完全踢不動。",
}
LocalizationConfig["loc_DecaItem_Des_17"] =
{
	zh = "混合金属制作的圆形窗户，挂在墙上有种阴森森的感觉。",
	en = "A round-shaped window made out of mixed metals, hanging it on the wall gives the room a dark feel.",
	zht = "混合金屬製作的圓形窗戶，掛在牆上有種陰森森的感覺。",
}
LocalizationConfig["loc_DecaItem_Des_18"] =
{
	zh = "屏幕上不停滚动的数据，这是人工智能小娜为了时刻监视飞船状态",
	en = "A screen with data constantly rolling across it, this is how the ship's AI Cortana monitors the ship's status",
	zht = "螢幕上不停滾動的資料，這是人工智慧小娜為了時刻監視飛船狀態",
}
LocalizationConfig["loc_DecaItem_Des_19"] =
{
	zh = "普通的橱柜，用来放碗筷厨具非常实用。",
	en = "A regular cabinet, extremely useful for storing dishes.",
	zht = "普通的櫥櫃，用來放碗筷廚具非常實用。",
}
LocalizationConfig["loc_DecaItem_Des_20"] =
{
	zh = "飞碟造型的吊灯，灯光从小窗户里面透出来，大飞船里装着小飞碟。",
	en = "A light modelled like an UFO, the light from the electric light shines outside the small window and you can see a little flying saucer inside the big spaceship.",
	zht = "飛碟造型的吊燈，燈光從小窗戶裡面透出來，大飛船裡裝著小飛碟。",
}
LocalizationConfig["loc_DecaItem_Des_21"] =
{
	zh = "桃心图案搭配粉红色的布料，椅背上搭着的蕾丝装饰，无一不透着少女的气息。",
	en = "Made with pink cloth covered in hearts, the back of the sofa is draped with lace, overflowing with youthful femininity.",
	zht = "桃心圖案搭配粉紅色的布料，椅背上搭著的蕾絲裝飾，無一不透著少女的氣息。",
}
LocalizationConfig["loc_DecaItem_Des_22"] =
{
	zh = "废旧的酒桶制作而成的桌子，时不时的散发出阵阵酒香来。",
	en = "A table made from an old beer keg, every now and then a malty smell comes from it.",
	zht = "廢舊的酒桶製作而成的桌子，時不時的散發出陣陣酒香來。",
}
LocalizationConfig["loc_DecaItem_Des_23"] =
{
	zh = "古董转轮电话装饰，实际上是不能用来打电话的。",
	en = "A decorative antique rotary dial telephone, it can't actually make phone calls though.",
	zht = "古董轉輪電話裝飾，實際上是不能用來打電話的。",
}
LocalizationConfig["loc_DecaItem_Des_24"] =
{
	zh = "复古的小电视，两根为了提升信号强度的天线放在两侧就像叉着腰一样。",
	en = "A vintage TV, the two signal-boosting aerials on the sides of the TV look like two arms in akimbo.",
	zht = "復古的小電視，兩根為了提升信號強度的天線放在兩側就像叉著腰一樣。",
}
LocalizationConfig["loc_DecaItem_Des_25"] =
{
	zh = "全自动休眠仓，唤醒周期为666天。",
	en = "A fully automatic stasis cabin, its waking cycle is every 1337 days.",
	zht = "全自動休眠倉，喚醒週期為666天。",
}
LocalizationConfig["loc_DecaItem_Des_26"] =
{
	zh = "原本是矿洞里使用的吊灯，现在拿过来做成装饰灯也很不错。",
	en = "A lamp originally used down the mines, it’s now used as a cool decoration.",
	zht = "原本是礦洞裡使用的吊燈，現在拿過來做成裝飾燈也很不錯。",
}
LocalizationConfig["loc_DecaItem_Des_27"] =
{
	zh = "厚重的实木加上精美的丝绒制作的沙发，古典又优雅。",
	en = "A sofa made from sturdy wood adorned with fine velvet, it's both classic and elegant.",
	zht = "厚重的實木加上精美的絲絨製作的沙發，古典又優雅。",
}
LocalizationConfig["loc_DecaItem_Des_28"] =
{
	zh = "上面放着美味的面包和牛奶的桌子，作为早餐专用的桌子是非常合适了。",
	en = "A table with delicious bread and milk on it, extremely suitable for a table used for eating breakfast.",
	zht = "上面放著美味的麵包和牛奶的桌子，作為早餐專用的桌子是非常合適了。",
}
LocalizationConfig["loc_DecaItem_Des_29"] =
{
	zh = "鲜花壁挂，在太空上养花养草可是件奢侈的事情，所以这些花当然只是仿真花而已。",
	en = "Fresh flowers that hang on the wall, growing flowers in space is an absolute luxury, so these flowers are false of course.",
	zht = "鮮花壁掛，在太空上養花養草可是件奢侈的事情，所以這些花當然只是模擬花而已。",
}
LocalizationConfig["loc_DecaItem_Des_30"] =
{
	zh = "怪兽主题电视，上面会24小时循环播放怪兽主题的电影。",
	en = "A monster themed TV, it continuously plays monster themed films 24 hours a day.",
	zht = "怪獸主題電視，上面會24小時迴圈播放怪獸主題的電影。",
}
LocalizationConfig["loc_DecaItem_Des_31"] =
{
	zh = "木质猫架，双层设计，让猫咪在里面更自如的玩耍",
	en = "A cat tree with two floors, let your cats play freely inside it",
	zht = "木質貓架，雙層設計，讓貓咪在裡面更自如的玩耍",
}
LocalizationConfig["loc_DecaItem_Des_32"] =
{
	zh = "盘踞在吊灯的恶灵，使原本普通的吊灯呈现出了诡异的形态。",
	en = "The evil soul that resides within the light turned this common light into a strange shape.",
	zht = "盤踞在吊燈的惡靈，使原本普通的吊燈呈現出了詭異的形態。",
}
LocalizationConfig["loc_DecaItem_Des_33"] =
{
	zh = "沙发旁边放上地球仪，有空随便转转，看起来非常有文化。",
	en = "There's a globe next to the sofa, you can spin it round when you've got nothing else to do, it has a really cultured look.",
	zht = "沙發旁邊放上地球儀，有空隨便轉轉，看起來非常有文化。",
}
LocalizationConfig["loc_DecaItem_Des_34"] =
{
	zh = "公园常见的石桌子，上面还放着一个盆栽。",
	en = "A common stone table that can be found in some parks, there's even a flower pot on top of it.",
	zht = "公園常見的石桌子，上面還放著一個盆栽。",
}
LocalizationConfig["loc_DecaItem_Des_35"] =
{
	zh = "白色石膏做的天使肖像壁挂，可能时间长了有点泛黄。",
	en = "An angel's bust made from white plaster that hangs on the wall, it might have turned a little yellow from being hung for too long.",
	zht = "白色石膏做的天使肖像壁掛，可能時間長了有點泛黃。",
}
LocalizationConfig["loc_DecaItem_Des_36"] =
{
	zh = "既是窗户也是电视机，想看风景的时候就把电视关了，想看电视的时候就把窗户关了。",
	en = "It's both a window and a TV screen, if you want to look at the scenery you just have to turn off the TV, if you want to watch TV you just have to turn the window off.",
	zht = "既是窗戶也是電視機，想看風景的時候就把電視關了，想看電視的時候就把窗戶關了。",
}
LocalizationConfig["loc_DecaItem_Des_37"] =
{
	zh = "电影大厅必备的东西，再也不用排着长队取票了。",
	en = "A necessary piece of equipment for movie theater lobbies, you no longer have to line up to collect your ticket.",
	zht = "電影大廳必備的東西，再也不用排著長隊取票了。",
}
LocalizationConfig["loc_DecaItem_Des_38"] =
{
	zh = "内置广告内容的投影仪。",
	en = "A projector with built-in advertisements.",
	zht = "內置廣告內容的投影儀。",
}
LocalizationConfig["loc_DecaItem_Des_39"] =
{
	zh = "影院大厅常见的按摩沙发，经常看到有人坐在上面但是没有在按摩。",
	en = "A massage chair often found in movie theater lobbies, you can often see people sitting on them, but they're never using the massage function.",
	zht = "影院大廳常見的按摩沙發，經常看到有人坐在上面但是沒有在按摩。",
}
LocalizationConfig["loc_DecaItem_Des_40"] =
{
	zh = "电影还没开始的时候，可以坐在餐桌边等待，边等边吃爆米花，吃完了，一会看电影的时候就没得吃了。",
	en = "You can sit by the table to wait for your movie to start, eating popcorn while you wait until there's none left, then when the movie starts you find you don't have anything to eat.",
	zht = "電影還沒開始的時候，可以坐在餐桌邊等待，邊等邊吃爆米花，吃完了，一會看電影的時候就沒得吃了。",
}
LocalizationConfig["loc_DecaItem_Des_41"] =
{
	zh = "经典电影海报，因为没有版权就不说是什么电影了。",
	en = "A classic movie poster, as we don't have the rights, we can't say which movie it is exactly.",
	zht = "經典電影海報，因為沒有版權就不說是什麼電影了。",
}
LocalizationConfig["loc_DecaItem_Des_42"] =
{
	zh = "影院大厅的必备，屏幕上会滚动播放着最近上映的电影宣传片。",
	en = "A necessity for any movie theater, the screen will show the trailers of all the recently released films.",
	zht = "影院大廳的必備，螢幕上會滾動播放著最近上映的電影宣傳片。",
}
LocalizationConfig["loc_DecaItem_Des_43"] =
{
	zh = "复古装饰的任务看板，上面还有猫脸的装饰。",
	en = "A vintage decorative work bulletin board, there’s even a cat’s face drawn on it.",
	zht = "復古裝飾的任務看板，上面還有貓臉的裝飾。",
}
LocalizationConfig["loc_DecaItem_Des_44"] =
{
	zh = "蜜蜂造型的吊灯，看起来是很适合放在儿童房间吧。",
	en = "A light that looks like a bee, it seems really suitable for a children’s room.",
	zht = "蜜蜂造型的吊燈，看起來是很適合放在兒童房間吧。",
}
LocalizationConfig["loc_DecaItem_Des_45"] =
{
	zh = "龙族的石座沙发，出门之前在上面坐一会可以提升战斗力。",
	en = "A stone dragon seat, sitting on it for a while before leaving the house will increase your combat ability.",
	zht = "龍族的石座沙發，出門之前在上面坐一會可以提升戰鬥力。",
}
LocalizationConfig["loc_DecaItem_Des_46"] =
{
	zh = "桌子上放的都是龙族爱吃的超大号肉食。",
	en = "The table's filled with the large meat that dragons love to eat.",
	zht = "桌子上放的都是龍族愛吃的超大號肉食。",
}
LocalizationConfig["loc_DecaItem_Des_47"] =
{
	zh = "火炬造型的壁灯，挂在墙上有种在原始洞穴里的感觉。",
	en = "A wall lamp that looks like a torch, hanging it on the wall gives the feeling of being in a primitive cave.",
	zht = "火炬造型的壁燈，掛在牆上有種在原始洞穴裡的感覺。",
}
LocalizationConfig["loc_DecaItem_Des_48"] =
{
	zh = "古代龙族留下来的显示屏，虽然已经无法播放了，但是上面仍然能看到一些曾经的影像。",
	en = "A screen left behind by the ancient dragon people, it may not be able to broadcast anything anymore, but you can still see some old images that remain on it.",
	zht = "古代龍族留下來的顯示幕，雖然已經無法播放了，但是上面仍然能看到一些曾經的影像。",
}
LocalizationConfig["loc_DecaItem_Des_49"] =
{
	zh = "看起来是一个街机的样子，其实是个柜子，不知道打开柜子能不能看到无敌破坏王在里面喝汽水呢？",
	en = "It looks like an arcade machine, but it's really a cupboard. Who knows, maybe if you open it you'll see Wreck it Ralph drinking a can of soda inside.",
	zht = "看起來是一個街機的樣子，其實是個櫃子，不知道打開櫃子能不能看到無敵破壞王在裡面喝汽水呢？",
}
LocalizationConfig["loc_DecaItem_Des_50"] =
{
	zh = "吊灯上面的VS字样正好搭配上整个整个游戏机家具组，呈现出一种在格斗游戏现场的感觉。",
	en = "The 'VS' letters on the light are a great match for any combination of furniture within the game, it gives the aesthetic of being in a fighting game.",
	zht = "吊燈上面的VS字樣正好搭配上整個整個遊戲機傢俱組，呈現出一種在格鬥遊戲現場的感覺。",
}
LocalizationConfig["loc_DecaItem_Des_51"] =
{
	zh = "超大型赛车街机沙发，怎么可能淡定的坐在上面呢。",
	en = "A giant racing arcade machine sofa, it's not the sort of sofa that you can simple 'sit on'.",
	zht = "超大型賽車街機沙發，怎麼可能淡定的坐在上面呢。",
}
LocalizationConfig["loc_DecaItem_Des_52"] =
{
	zh = "投币就可以开始对战吃汉堡比赛，赢了的人会奖励一个汉堡。",
	en = "Insert coins to start a hamburger-eating competition against your opponent, whoever wins gets a hamburger.",
	zht = "投幣就可以開始對戰吃漢堡比賽，贏了的人會獎勵一個漢堡。",
}
LocalizationConfig["loc_DecaItem_Des_53"] =
{
	zh = "经典游戏海报，因为没有版权就不说是什么游戏了。",
	en = "A classic game poster, as we don't have the rights, we can't say which game it is exactly.",
	zht = "經典遊戲海報，因為沒有版權就不說是什麼遊戲了。",
}
LocalizationConfig["loc_DecaItem_Des_54"] =
{
	zh = "经典游戏机造型的窗户，透过玻璃看着外面的星空有种真的在玩太空侵略者的感觉。",
	en = "A window in the shape of a classic games console, staring out at space through this window gives you the feeling of playing space invader.",
	zht = "經典遊戲機造型的窗戶，透過玻璃看著外面的星空有種真的在玩太空侵略者的感覺。",
}
LocalizationConfig["loc_DecaItem_Des_55"] =
{
	zh = "专门为懒人设计的充电桩，会自动寻找没电的手机强行充电。",
	en = "A charger specially designed for lazy people, it will automatically find phones with no power and forcefully charge them.",
	zht = "專門為懶人設計的充電樁，會自動尋找沒電的手機強行充電。",
}
LocalizationConfig["loc_DecaItem_Des_56"] =
{
	zh = "复古的铜质吊灯，发着黄光的钨丝灯泡。",
	en = "An ancient-style bronze light with a filament lightbulb that emits a yellow light",
	zht = "復古的銅質吊燈，發著黃光的鎢絲燈泡。",
}
LocalizationConfig["loc_DecaItem_Des_57"] =
{
	zh = "大鼻子的斯格特，透过这扇窗户看到了美丽的玫瑰，和自己的美好之处。",
	en = "Large-nosed Scott, you can see beautiful roses through the window and the place of your dreams.",
	zht = "大鼻子的斯格特，透過這扇窗戶看到了美麗的玫瑰，和自己的美好之處。",
}
LocalizationConfig["loc_DecaItem_Des_58"] =
{
	zh = "插上电就能迅速制冷的贩卖机，因为补货太麻烦，导致经常缺货。",
	en = "A vending machine that instantly cools when plugged in, as it's such an effort to restock, it's often out of stock.",
	zht = "插上電就能迅速製冷的販賣機，因為補貨太麻煩，導致經常缺貨。",
}
LocalizationConfig["loc_DecaItem_Des_59"] =
{
	zh = "小鸟造型的灯，兼具报时的功能，但是什么时候报时呢，好像没啥规律。",
	en = "A light in the shape of a bird, it is also able to tell the time, but it doesn’t seem to have any regular pattern to when it does.",
	zht = "小鳥造型的燈，兼具報時的功能，但是什麼時候報時呢，好像沒啥規律。",
}
LocalizationConfig["loc_DecaItem_Des_60"] =
{
	zh = "智能遥控换频道电视，换台的时候只要对着屏幕大声说",
	en = "A smart remote-controlled TV, whenever you want to switch the channel, you just need to shout at the TV",
	zht = "智慧遙控換頻道電視，換台的時候只要對著螢幕大聲說",
}
LocalizationConfig["loc_DecaItem_Suit_1"] =
{
	zh = "原厂套装",
	en = "Factory Set",
	zht = "原廠套裝",
}
LocalizationConfig["loc_DecaItem_Suit_2"] =
{
	zh = "甜蜜套装",
	en = "Sweet Set",
	zht = "甜蜜套裝",
}
LocalizationConfig["loc_DecaItem_Suit_3"] =
{
	zh = "重金属套装",
	en = "Metal Set",
	zht = "重金屬套裝",
}
LocalizationConfig["loc_DecaItem_Suit_4"] =
{
	zh = "影院套装",
	en = "Movie Set",
	zht = "影院套裝",
}
LocalizationConfig["loc_DecaItem_Suit_5"] =
{
	zh = "屠龙套装",
	en = "Dragon Set",
	zht = "屠龍套裝",
}
LocalizationConfig["loc_DecaItem_Suit_6"] =
{
	zh = "街机套装",
	en = "Arcade Set",
	zht = "街機套裝",
}
LocalizationConfig["loc_tutorial_msg_33"] =
{
	zh = "[714747]成功，豆豆警官也变厉害了！[-]",
	en = "[未翻译][714747]成功，豆豆警官也变厉害了！[-]",
	zht = "[714747]成功，豆豆警官也變厲害了！[-]",
}
LocalizationConfig["loc_tutorial_msg_34"] =
{
	zh = "[2CBF00]左右滑动[-][714747]切换星球，这次向左滑动吧[-]",
	en = "[未翻译][2CBF00]左右滑动[-][714747]切换星球，这次向左滑动吧[-]",
	zht = "[2CBF00]左右滑動[-][714747]切換星球，這次向左滑動吧[-]",
}
LocalizationConfig["loc_story_msg_1"] =
{
	zh = "看样子，这里是个以RPG的方式来推进剧情的星球。",
	en = "It looks like this is a planet where the storyline is progressed in an RPG style.",
	zht = "看樣子，這裡是個以RPG的方式來推進劇情的星球。",
}
LocalizationConfig["loc_story_msg_2"] =
{
	zh = "RPG吗？刚好我这里有一个。（掏出火箭推进榴弹（Rocket-propelled grenade））",
	en = "An RPG? Luckily, I've got one here. (Pulls out a Rocket-propelled grenade)",
	zht = "RPG嗎？剛好我這裡有一個。（掏出火箭推進榴彈（Rocket-propelled grenade））",
}
LocalizationConfig["loc_story_msg_3"] =
{
	zh = "（流汗）不不不，是角色扮演（role-playing game）的意思啦。",
	en = "(Dripping with sweat) No no no, I meant a role-playing game.",
	zht = "（流汗）不不不，是角色扮演（role-playing game）的意思啦。",
}
LocalizationConfig["loc_story_msg_4"] =
{
	zh = "那里有个在练级的青年，我们过去问问吧。",
	en = "There's a youth training over there, let's go and ask him.",
	zht = "那裡有個在練級的青年，我們過去問問吧。",
}
LocalizationConfig["loc_story_msg_5"] =
{
	zh = "你们不是魔王的手下？",
	en = "You're not an underling of the Dark Lord?",
	zht = "你們不是魔王的手下？",
}
LocalizationConfig["loc_story_msg_6"] =
{
	zh = "当然不是，我们来自猫咪星球，是来收取星球租金的。",
	en = "Of course not, we come from Meow Meow Planet, we're here to collect your planet's rent.",
	zht = "當然不是，我們來自貓咪星球，是來收取星球租金的。",
}
LocalizationConfig["loc_story_msg_7"] =
{
	zh = "额……听起来我们像是另一个魔王……",
	en = "Oh……sounds like we're another type of Dark Lord……",
	zht = "額……聽起來我們像是另一個魔王……",
}
LocalizationConfig["loc_story_msg_8"] =
{
	zh = "恐怕你们要空手而归了，这个星球被魔王所统治，现在所有人都在向他交保护费。",
	en = "I'm afraid you're going to have to go back empty-handed. This planet is controlled by the Dark Lord, everyone gives him protection money now.",
	zht = "恐怕你們要空手而歸了，這個星球被魔王所統治，現在所有人都在向他交保護費。",
}
LocalizationConfig["loc_story_msg_9"] =
{
	zh = "太可恶了，他怎么可以抢我们的钱！",
	en = "Disgraceful, how can he steal our money away like that?",
	zht = "太可惡了，他怎麼可以搶我們的錢！",
}
LocalizationConfig["loc_story_msg_10"] =
{
	zh = "喂喂喂，你是不是太有代入感了！",
	en = "Hey hey hey, don't you feel like it's so engaging?",
	zht = "喂喂喂，你是不是太有代入感了！",
}
LocalizationConfig["loc_story_msg_11"] =
{
	zh = "我可以帮助你们打败魔王。",
	en = "I can help you defeat the Dark Lord.",
	zht = "我可以幫助你們打敗魔王。",
}
LocalizationConfig["loc_story_msg_12"] =
{
	zh = "太好了，那我们该怎么感谢你？",
	en = "Great, then how should we thank you?",
	zht = "太好了，那我們該怎麼感謝你？",
}
LocalizationConfig["loc_story_msg_13"] =
{
	zh = "自从居民们向魔王交保护费后，我再也没法从民房的抽屉里找到什么有用的东西。",
	en = "Ever since the residents here started giving the Dark Lord protection money, we haven't been able to find any useful things in the houses' drawers.",
	zht = "自從居民們向魔王交保護費後，我再也沒法從民房的抽屜裡找到什麼有用的東西。",
}
LocalizationConfig["loc_story_msg_14"] =
{
	zh = "如果能打败他的话，我想我也许可以重新找回作为勇者的乐趣。",
	en = "If you can defeat him, I might be able to rekindle the joy of being a hero.",
	zht = "如果能打敗他的話，我想我也許可以重新找回作為勇者的樂趣。",
}
LocalizationConfig["loc_story_msg_15"] =
{
	zh = "怎么听起来像是一群更坏的人在谋划怎么打败坏人……",
	en = "Why does it sound like a group of even worse people planning how to defeat a group of bad people……",
	zht = "怎麼聽起來像是一群更壞的人在謀劃怎麼打敗壞人……",
}
LocalizationConfig["loc_story_msg_16"] =
{
	zh = "魔王行踪飘忽不定，如果想要找到他的话，我们需要猎人的帮助，他的追踪能力很强。",
	en = "The Dark Lord's whereabouts is uncertain, if you want to find him we need the hunter's help, he is excellent at tracking.",
	zht = "魔王行蹤飄忽不定，如果想要找到他的話，我們需要獵人的説明，他的追蹤能力很強。",
}
LocalizationConfig["loc_story_msg_17"] =
{
	zh = "那我们赶紧去找他吧。",
	en = "Then let's go find him.",
	zht = "那我們趕緊去找他吧。",
}
LocalizationConfig["loc_story_msg_18"] =
{
	zh = "为了以防万一我提醒下，这是个RPG的世界，遇到打不过的敌人，我们需要……",
	en = "Just in case, let me remind you, this is an RPG world, when encountering enemies we can't defeat we must……",
	zht = "為了以防萬一我提醒下，這是個RPG的世界，遇到打不過的敵人，我們需要……",
}
LocalizationConfig["loc_story_msg_19"] =
{
	zh = "我知道，探索，升级，穿装备呗，简单！",
	en = "I know, I know, explore, level up, equip gear, easy!",
	zht = "我知道，探索，升級，穿裝備唄，簡單！",
}
LocalizationConfig["loc_story_msg_20"] =
{
	zh = "你们是什么人？",
	en = "Who are you?",
	zht = "你們是什麼人？",
}
LocalizationConfig["loc_story_msg_21"] =
{
	zh = "我们想要打败魔王，但不知道他的所在，所以来寻求你的帮助。",
	en = "We want to defeat the Dark Lord, but we don't know where he is. We're here for your help.",
	zht = "我們想要打敗魔王，但不知道他的所在，所以來尋求你的幫助。",
}
LocalizationConfig["loc_story_msg_22"] =
{
	zh = "就凭你们几个恐怕很难打败魔王。",
	en = "It'll be hard to defeat the Dark Lord with just the few of you.",
	zht = "就憑你們幾個恐怕很難打敗魔王。",
}
LocalizationConfig["loc_story_msg_23"] =
{
	zh = "不试试怎么知道？再说旅途中还会有别的伙伴加入。",
	en = "We won't know until we've tried now will we? Others will join us during our journey as well.",
	zht = "不試試怎麼知道？再說旅途中還會有別的夥伴加入。",
}
LocalizationConfig["loc_story_msg_24"] =
{
	zh = "……",
	en = "……",
	zht = "……",
}
LocalizationConfig["loc_story_msg_25"] =
{
	zh = "好吧，我就帮帮你们。",
	en = "OK then, I'll help you.",
	zht = "好吧，我就幫幫你們。",
}
LocalizationConfig["loc_story_msg_26"] =
{
	zh = "哇，卖了不少钱呢",
	en = "Wow, this is worth a good chunk of gold",
	zht = "哇，賣了不少錢呢",
}
LocalizationConfig["loc_story_msg_27"] =
{
	zh = "说明这星球的东西还都有点价值",
	en = "Meaning the things on this planet have a bit of value",
	zht = "說明這星球的東西還都有點價值",
}
LocalizationConfig["loc_story_msg_28"] =
{
	zh = "这可都是辛苦钱，每个物品都要探索好久呢",
	en = "This money was hard-earned, I had to explore for a long time before finding each of these items.",
	zht = "這可都是辛苦錢，每個物品都要探索好久呢",
}
LocalizationConfig["loc_story_msg_29"] =
{
	zh = "是吗，我感觉一旦探索开始之后，后面的时光总是过的很快呢",
	en = "Really? I feel like the time I spend exploring is always really happy.",
	zht = "是嗎，我感覺一旦探索開始之後，後面的時光總是過的很快呢",
}
LocalizationConfig["loc_story_msg_30"] =
{
	zh = "哇，升级以后样子变了不少呢",
	en = "Wow, it looks really different after upgrading.",
	zht = "哇，升級以後樣子變了不少呢",
}
LocalizationConfig["loc_story_msg_31"] =
{
	zh = "是啊好神奇，赶紧去新区域看看吧",
	en = "Yeah, it's really amazing. Go to the new are and have a look.",
	zht = "是啊好神奇，趕緊去新區域看看吧",
}
LocalizationConfig["loc_story_msg_32"] =
{
	zh = "你是魔王的手下吗？",
	en = "Are you one of the Dark Lord's underlings?",
	zht = "你是魔王的手下嗎？",
}
LocalizationConfig["loc_story_msg_33"] =
{
	zh = "我曾经也是个冒险者，直到我膝盖中了一箭。",
	en = "I used to be an adventurer like you, then I took an arrow in the knee.",
	zht = "我曾經也是個冒險者，直到我膝蓋中了一箭。",
}
LocalizationConfig["loc_story_msg_34"] =
{
	zh = "所以，这就是你在这里打劫我们的理由？",
	en = "So this is the reason why you robbed us?",
	zht = "所以，這就是你在這裡打劫我們的理由？",
}
LocalizationConfig["loc_story_msg_35"] =
{
	zh = "误会误会……",
	en = "It's a misunderstanding, please……",
	zht = "誤會誤會……",
}
LocalizationConfig["loc_story_msg_36"] =
{
	zh = "等一下，先别打他！",
	en = "Wait, don't hit him!",
	zht = "等一下，先別打他！",
}
LocalizationConfig["loc_story_msg_37"] =
{
	zh = "咕咕，我们在这家伙手里吃了不少的苦头，你不会想放过他吧？",
	en = "Salem, we had a miserable time because of this guy, you're not thinking of letting him go are you?",
	zht = "咕咕，我們在這傢伙手裡吃了不少的苦頭，你不會想放過他吧？",
}
LocalizationConfig["loc_story_msg_38"] =
{
	zh = "打还是要打的，我只是觉得，能射中他膝盖的人或许会是个强力的伙伴。",
	en = "He deserves to be beaten up of course, but I just think that the person who shot his knee might make a strong companion.",
	zht = "打還是要打的，我只是覺得，能射中他膝蓋的人或許會是個強力的夥伴。",
}
LocalizationConfig["loc_story_msg_39"] =
{
	zh = "有道理诶！",
	en = "You have a point!",
	zht = "有道理誒！",
}
LocalizationConfig["loc_story_msg_40"] =
{
	zh = "你们要去打败魔王？算了吧，我劝你们放弃这个念头。",
	en = "You're going to defeat the Dark Lord? Forget it, I urge you to abandon this idea of yours.",
	zht = "你們要去打敗魔王？算了吧，我勸你們放棄這個念頭。",
}
LocalizationConfig["loc_story_msg_41"] =
{
	zh = "为什么？",
	en = "Why?",
	zht = "為什麼？",
}
LocalizationConfig["loc_story_msg_42"] =
{
	zh = "魔王已经刀枪不入，我的弓箭对他完全不起作用。",
	en = "The Dark Lord can't be hurt by our weapons, my bow is completely useless against him.",
	zht = "魔王已經刀槍不入，我的弓箭對他完全不起作用。",
}
LocalizationConfig["loc_story_msg_43"] =
{
	zh = "他不可能完全没有弱点吧？",
	en = "He couldn't possibly not have any weakness at all surely?",
	zht = "他不可能完全沒有弱點吧？",
}
LocalizationConfig["loc_story_msg_44"] =
{
	zh = "上次和他交手的时候，所有的攻击都不能伤到他，他已经进化为无敌的魔王了。",
	en = "Last time I fought with him, none of my attacks could hurt him, he's already evolved into an invincible Dark Lord.",
	zht = "上次和他交手的時候，所有的攻擊都不能傷到他，他已經進化為無敵的魔王了。",
}
LocalizationConfig["loc_story_msg_45"] =
{
	zh = "如果能抓到魔王的手下，会不会打探到魔王的一些秘密呢？",
	en = "If we can capture his underlings, do you think we might be able to find out some of the Dark Lord's secrets?",
	zht = "如果能抓到魔王的手下，會不會打探到魔王的一些秘密呢？",
}
LocalizationConfig["loc_story_msg_46"] =
{
	zh = "……",
	en = "…",
	zht = "……",
}
LocalizationConfig["loc_story_msg_47"] =
{
	zh = "倒是可以试一试，我知道他的手下在哪里，我来给你们带路。",
	en = "You can try, I know where his underlings are, I'll take you.",
	zht = "倒是可以試一試，我知道他的手下在哪裡，我來給你們帶路。",
}
LocalizationConfig["loc_story_msg_48"] =
{
	zh = "星球到3级啦，真不容易",
	en = "The planet's Lv.3! That really wasn't easy.",
	zht = "星球到3級啦，真不容易",
}
LocalizationConfig["loc_story_msg_49"] =
{
	zh = "是大家努力的结果",
	en = "We managed it through everyone's hard work",
	zht = "是大家努力的結果",
}
LocalizationConfig["loc_story_msg_50"] =
{
	zh = "5级会怎么样呢",
	en = "What will Lv.5 be like?",
	zht = "5級會怎麼樣呢",
}
LocalizationConfig["loc_story_msg_51"] =
{
	zh = "真是令人期待呢",
	en = "I can't wait",
	zht = "真是令人期待呢",
}
LocalizationConfig["loc_story_msg_52"] =
{
	zh = "虽然你们打败了我，但我可是魔王的头号手下，绝对不会泄露魔王大人现在在暗夜空间的！",
	en = "You may have defeated me, but I'm the Dark Lord's chief underling, I won't let it slip that the Dark Lord is currently in the Dark Plane.",
	zht = "雖然你們打敗了我，但我可是魔王的頭號手下，絕對不會洩露魔王大人現在在暗夜空間的！",
}
LocalizationConfig["loc_story_msg_53"] =
{
	zh = "……",
	en = "…",
	zht = "……",
}
LocalizationConfig["loc_story_msg_54"] =
{
	zh = "我知道你们的目的，我是绝对不会告诉你魔王大人的弱点是怕精神攻击！",
	en = "I know what your goal is, but I won't ever tell you that the Dark Lord's weakness is that he's afraid of psychological attacks!",
	zht = "我知道你們的目的，我是絕對不會告訴你魔王大人的弱點是怕精神攻擊！",
}
LocalizationConfig["loc_story_msg_55"] =
{
	zh = "……",
	en = "……",
	zht = "……",
}
LocalizationConfig["loc_story_msg_56"] =
{
	zh = "我守口如瓶，不会透露只有牧师才会知道魔王大人怕什么精神攻击！",
	en = "My lips are sealed, I won't reveal that only the Cleric knows what psychological attack the Dark Lord is afraid of!",
	zht = "我守口如瓶，不會透露只有牧師才會知道魔王大人怕什麼精神攻擊！",
}
LocalizationConfig["loc_story_msg_57"] =
{
	zh = "……",
	en = "……",
	zht = "……",
}
LocalizationConfig["loc_story_msg_58"] =
{
	zh = "我更加不会说出，只有公会商店的射鸡师才知道牧师的所在！",
	en = "What I definitely won't tell you is that the Guild Store's Shooter is the only person who knows where the Cleric is!",
	zht = "我更加不會說出，只有公會商店的射雞師才知道牧師的所在！",
}
LocalizationConfig["loc_story_msg_59"] =
{
	zh = "……",
	en = "……",
	zht = "……",
}
LocalizationConfig["loc_story_msg_60"] =
{
	zh = "来吧，尽情地拷打我，我不会屈服于你们的淫威！这只能愈发凸显我对魔王大人的忠诚！",
	en = "Go on then, torture me, I won't submit to your abuse! This will only make my loyalty to the Dark Lord stronger!",
	zht = "來吧，盡情地拷打我，我不會屈服於你們的淫威！這只能愈發凸顯我對魔王大人的忠誠！",
}
LocalizationConfig["loc_story_msg_61"] =
{
	zh = "额……这个，恐怕真的不需要……",
	en = "Erm……I don't think we really need to……",
	zht = "額……這個，恐怕真的不需要……",
}
LocalizationConfig["loc_story_msg_62"] =
{
	zh = "我突然觉得，魔王也许并非是不能被打败的。",
	en = "I suddenly feel that maybe the Dark Lord really isn't completely impossible to defeat.",
	zht = "我突然覺得，魔王也許並非是不能被打敗的。",
}
LocalizationConfig["loc_story_msg_63"] =
{
	zh = "我是这个游戏的设计者之一，这个形象是我在这个世界的投影。",
	en = "I'm one of the designers of this game, this figure is my projection onto this world.",
	zht = "我是這個遊戲的設計者之一，這個形象是我在這個世界的投影。",
}
LocalizationConfig["loc_story_msg_64"] =
{
	zh = "我知道你们想要什么。",
	en = "I know what you want.",
	zht = "我知道你們想要什麼。",
}
LocalizationConfig["loc_story_msg_65"] =
{
	zh = "拿着这张纸，里面有如何击败魔王的线索。",
	en = "Take this piece of paper, inside it is a clue on how to defeat the Dark Lord.",
	zht = "拿著這張紙，裡面有如何擊敗魔王的線索。",
}
LocalizationConfig["loc_story_msg_66"] =
{
	zh = "我有个问题。",
	en = "I have a question.",
	zht = "我有個問題。",
}
LocalizationConfig["loc_story_msg_67"] =
{
	zh = "什么问题？",
	en = "What question?",
	zht = "什麼問題？",
}
LocalizationConfig["loc_story_msg_68"] =
{
	zh = "为什么你会直接出现在我们面前？这一般不是游戏的彩蛋吗？",
	en = "Why have you appeared to me? Isn't this normally an in-game Easter egg?",
	zht = "為什麼你會直接出現在我們面前？這一般不是遊戲的彩蛋嗎？",
}
LocalizationConfig["loc_story_msg_69"] =
{
	zh = "……",
	en = "……",
	zht = "……",
}
LocalizationConfig["loc_story_msg_70"] =
{
	zh = "好吧，没想到居然是只猫发现了问题的所在……",
	en = "OK, I didn't think that a cat of all things would find out what the problem is……",
	zht = "好吧，沒想到居然是只貓發現了問題的所在……",
}
LocalizationConfig["loc_story_msg_71"] =
{
	zh = "其实是我们没来得及画贤者角色，无奈之下，只能由我客串一下……",
	en = "It's actually because we didn't have the time to draw a Sage character, so all we could do was include me as a guest character instead……",
	zht = "其實是我們沒來得及畫賢者角色，無奈之下，只能由我客串一下……",
}
LocalizationConfig["loc_story_msg_72"] =
{
	zh = "工期紧真是害死人呐！",
	en = "Having such a tight schedule is such a pain!",
	zht = "工期緊真是害死人呐！",
}
LocalizationConfig["loc_story_msg_73"] =
{
	zh = "这就是纸上写的地址，那里好像有个人！",
	en = "Here's the address written on the paper, I think there's someone over there!",
	zht = "這就是紙上寫的地址，那裡好像有個人！",
}
LocalizationConfig["loc_story_msg_74"] =
{
	zh = "冒险者们，你们终于来了，我在此等候很久了。",
	en = "Adventurers, you're finally here, I've be waiting for a good while.",
	zht = "冒險者們，你們終於來了，我在此等候很久了。",
}
LocalizationConfig["loc_story_msg_75"] =
{
	zh = "你就是我们要找的人吗？",
	en = "Are you the person we're looking for?",
	zht = "你就是我們要找的人嗎？",
}
LocalizationConfig["loc_story_msg_76"] =
{
	zh = "没错。",
	en = "That's right.",
	zht = "沒錯。",
}
LocalizationConfig["loc_story_msg_77"] =
{
	zh = "你要怎么证明这点呢？",
	en = "Can you prove it?",
	zht = "你要怎麼證明這點呢？",
}
LocalizationConfig["loc_story_msg_78"] =
{
	zh = "我在梦中受到了神谕，得知魔王的弱点，见到他后，你们只要这样这样，然后那样那样……",
	en = "A god came to me in my dream and told me the Dark Lord's weakness, once you see him you just have to do this and this……and then that and that",
	zht = "我在夢中受到了神諭，得知魔王的弱點，見到他後，你們只要這樣這樣，然後那樣那樣……",
}
LocalizationConfig["loc_story_msg_79"] =
{
	zh = "喔噢，真是十足的坏点子！",
	en = "Wow, that really is a horrible trick!",
	zht = "喔噢，真是十足的壞點子！",
}
LocalizationConfig["loc_story_msg_80"] =
{
	zh = "我已经开始有点同情这个魔王了……",
	en = "I'm already starting to feel sorry for the Dark Lord……",
	zht = "我已經開始有點同情這個魔王了……",
}
LocalizationConfig["loc_story_msg_81"] =
{
	zh = "愚蠢的冒险者们，如果你们够聪明的话，就应该知道刀剑与魔法再不能伤我分毫，你们这是自寻死路！",
	en = "Foolish adventurers, if you were smart enough you'd know that swords and magic can't harm me at all, what you're doing here is suicide!",
	zht = "愚蠢的冒險者們，如果你們夠聰明的話，就應該知道刀劍與魔法再不能傷我分毫，你們這是自尋死路！",
}
LocalizationConfig["loc_story_msg_82"] =
{
	zh = "嘿嘿，是吗？",
	en = "Hee-hee, really?",
	zht = "嘿嘿，是嗎？",
}
LocalizationConfig["loc_story_msg_83"] =
{
	zh = "趁我还没动手前，尽情地笑吧，等会儿你们就会哭了！",
	en = "Laugh while you still can, you'll be crying before long!",
	zht = "趁我還沒動手前，盡情地笑吧，等會兒你們就會哭了！",
}
LocalizationConfig["loc_story_msg_84"] =
{
	zh = "蚯蚓钻进了你的裤子，你的皮肤立刻变得湿润、粘稠~~~",
	en = "Worms have wriggled their way into your pants, your skin turns moist and sticky……",
	zht = "蚯蚓鑽進了你的褲子，你的皮膚立刻變得濕潤、粘稠~~~",
}
LocalizationConfig["loc_story_msg_85"] =
{
	zh = "什……什么？你们……你们怎么会知道我怕这个？",
	en = "Wha……what? How……how do you know my fears?",
	zht = "什……什麼？你們……你們怎麼會知道我怕這個？",
}
LocalizationConfig["loc_story_msg_86"] =
{
	zh = "你乳糖不耐，可你妈妈还是逼你喝下了大杯牛奶，在学校里，你的肚子在男生面前奏起了美妙的音乐~",
	en = "You're lactose intolerant, but your mother still forces you to drink a large cup of milk. At school, your stomach makes the most wonderful noises right in front of the boys.",
	zht = "你乳糖不耐，可你媽媽還是逼你喝下了大杯牛奶，在學校裡，你的肚子在男生面前奏起了美妙的音樂~",
}
LocalizationConfig["loc_story_msg_87"] =
{
	zh = "不要，不要再说了！太……太丢人了！",
	en = "Don't, stop it! It's……so embarrassing!",
	zht = "不要，不要再說了！太……太丟人了！",
}
LocalizationConfig["loc_story_msg_88"] =
{
	zh = "你不喜欢打针，不幸的是，在夏天时，你不小心掉进了一个塞满针筒的坑里，尖尖的针头直接刺穿了你娇嫩的皮肤~~~",
	en = "You're afraid of needles and injections, but unfortunately for you, during the summer you accidentally fall into a pit of needles. The sharp needles pierce your tender skin……",
	zht = "你不喜歡打針，不幸的是，在夏天時，你不小心掉進了一個塞滿針筒的坑裡，尖尖的針頭直接刺穿了你嬌嫩的皮膚~~~",
}
LocalizationConfig["loc_story_msg_89"] =
{
	zh = "啊——痛！痛！痛！",
	en = "Agh……Ouch! Ouch! Ouch!",
	zht = "啊——痛！痛！痛！",
}
LocalizationConfig["loc_story_msg_90"] =
{
	zh = "坑太深了，你爬不上来，一次又一次地掉进去~~~",
	en = "The pit is too deep, you can't climb out, you keep falling back into it, time and time again……",
	zht = "坑太深了，你爬不上來，一次又一次地掉進去~~~",
}
LocalizationConfig["loc_story_msg_91"] =
{
	zh = "救命，救命！",
	en = "Help, help!",
	zht = "救命，救命！",
}
LocalizationConfig["loc_story_msg_92"] =
{
	zh = "她的精神已经快要崩溃了，是时候来最后一击了！",
	en = "He's close to having a breakdown, it's time to deal the last blow!",
	zht = "她的精神已經快要崩潰了，是時候來最後一擊了！",
}
LocalizationConfig["loc_story_msg_93"] =
{
	zh = "（拿出黑板）咕咕，看你的了！",
	en = "(Pulls out blackboard) Salem, let's see it!",
	zht = "（拿出黑板）咕咕，看你的了！",
}
LocalizationConfig["loc_story_msg_94"] =
{
	zh = "喵星人合体技之超级噪音攻击！",
	en = "Meow Planet's people's special super noise attack!",
	zht = "喵星人合體技之超級噪音攻擊！",
}
LocalizationConfig["loc_story_msg_95"] =
{
	zh = "（伸出爪子在黑板上用力划下）咝——咝——",
	en = "(Stretches out claw and scratches the blackboard with a lot of force) SCREECH……SCREECH……",
	zht = "（伸出爪子在黑板上用力劃下）噝——噝——",
}
LocalizationConfig["loc_story_msg_96"] =
{
	zh = "啊——啊——",
	en = "Ah……AH……",
	zht = "啊——啊——",
}
LocalizationConfig["loc_story_msg_97"] =
{
	zh = "……",
	en = "……",
	zht = "……",
}
LocalizationConfig["loc_story_msg_98"] =
{
	zh = "魔王倒下了，居然这么简单就打败了她。",
	en = "The Dark Lord has fallen, who'd have thought it'd be so easy to defeat her?",
	zht = "魔王倒下了，居然這麼簡單就打敗了她。",
}
LocalizationConfig["loc_story_msg_99"] =
{
	zh = "这大概是史上最弱的魔王了。",
	en = "This must be the weakest Dark Lord in history.",
	zht = "這大概是史上最弱的魔王了。",
}
LocalizationConfig["loc_story_msg_100"] =
{
	zh = "攒了不少钱了，看来把你送到这个星球是对的",
	en = "You saved a good deal of money, looks like sending you to this planet was the right thing to do.",
	zht = "攢了不少錢了，看來把你送到這個星球是對的",
}
LocalizationConfig["loc_story_msg_101"] =
{
	zh = "呜，我还要多久才能回家呢",
	en = "Heh, how long has it been since I've gone home?",
	zht = "嗚，我還要多久才能回家呢",
}
LocalizationConfig["loc_story_msg_102"] =
{
	zh = "喵大王对你最近表现还算满意，好好探索别的星球吧，现在还了……5%的债务啦",
	en = "King Meow is pretty pleased with your recent performance, go and explore other planets, you still have……5% debt!",
	zht = "喵大王對你最近表現還算滿意，好好探索別的星球吧，現在還了……5%的債務啦",
}
LocalizationConfig["loc_story_msg_103"] =
{
	zh = "哇，怎么才这点呀",
	en = "Woah, is that all?",
	zht = "哇，怎麼才這點呀",
}
LocalizationConfig["loc_story_msg_104"] =
{
	zh = "加油探索，加油收租，我看好你[摸头]",
	en = "Keep up the exploration, carry on collecting rent, I'll be watching for you [strokes head]",
	zht = "加油探索，加油收租，我看好你[摸頭]",
}
LocalizationConfig["loc_story_msg_105"] =
{
	zh = "听说这是个下午茶盛行的星球，到处都是美食啊~口水都要流出来了~",
	en = "I heard that afternoon tea is all the rage on this planet, there's delicious food everywhere we go ah……I'm watering at the mouth",
	zht = "聽說這是個下午茶盛行的星球，到處都是美食啊~口水都要流出來了~",
}
LocalizationConfig["loc_story_msg_106"] =
{
	zh = "冷静一点，你已经是只胖橘猫了！要是再贪吃，你会被舱门卡住进不了飞船的！",
	en = "Calm down, you're already a fat orange cat! If you carry on indulging yourself, you'll get stuck in our ship's cabin door!",
	zht = "冷靜一點，你已經是只胖橘貓了！要是再貪吃，你會被艙門卡住進不了飛船的！",
}
LocalizationConfig["loc_story_msg_107"] =
{
	zh = "喵……",
	en = "Meow……",
	zht = "喵……",
}
LocalizationConfig["loc_story_msg_108"] =
{
	zh = "别装可怜了，那边有个人在哭，我们去看看吧。",
	en = "Stop your sniveling. Someone's crying over there, let's go see.",
	zht = "別裝可憐了，那邊有個人在哭，我們去看看吧。",
}
LocalizationConfig["loc_story_msg_109"] =
{
	zh = "你是谁？为什么一个人在这里哭？",
	en = "Who are you? Why are you here crying on your own?",
	zht = "你是誰？為什麼一個人在這裡哭？",
}
LocalizationConfig["loc_story_msg_110"] =
{
	zh = "呜呜呜……我是这个星球上的汽水王子。",
	en = "Wah wah……I'm the Soda Prince of this planet.",
	zht = "嗚嗚嗚……我是這個星球上的汽水王子。",
}
LocalizationConfig["loc_story_msg_111"] =
{
	zh = "但是，昨天早上醒来后，我突然发现自己体内没有汽了……",
	en = "But when I woke up yesterday, I suddenly discovered that I don't have any gas inside me……",
	zht = "但是，昨天早上醒來後，我突然發現自己體內沒有汽了……",
}
LocalizationConfig["loc_story_msg_112"] =
{
	zh = "听起来好像也没什么。",
	en = "It doesn't sound like a bit deal.",
	zht = "聽起來好像也沒什麼。",
}
LocalizationConfig["loc_story_msg_113"] =
{
	zh = "这个星球上人人都爱吃下午茶，我之所以是王子，就是因为喜欢我的人多。",
	en = "The people on this planet all love teatime, the reason why I'm a prince is because lots of people like me.",
	zht = "這個星球上人人都愛吃下午茶，我之所以是王子，就是因為喜歡我的人多。",
}
LocalizationConfig["loc_story_msg_114"] =
{
	zh = "没汽的我就只是普通的糖水，再也不是能让人们打出满足饱嗝的汽水。",
	en = "If I don't have any gas, I'm just a regular sugary water not a soda that can give people a satisfying burp.",
	zht = "沒汽的我就只是普通的糖水，再也不是能讓人們打出滿足飽嗝的汽水。",
}
LocalizationConfig["loc_story_msg_115"] =
{
	zh = "人们不会喜欢这样的我，我就再也不是下午茶的主角之一了，呜呜呜……",
	en = "If people don't like me like this, I won't be one of the main features of teatime anymore, Wah wah……",
	zht = "人們不會喜歡這樣的我，我就再也不是下午茶的主角之一了，嗚嗚嗚……",
}
LocalizationConfig["loc_story_msg_116"] =
{
	zh = "听起来好可怜，咕咕，我们帮帮他吧。",
	en = "Sounds very sad, Salem……let's help him.",
	zht = "聽起來好可憐，咕咕，我們幫幫他吧。",
}
LocalizationConfig["loc_story_msg_117"] =
{
	zh = "……",
	en = "……",
	zht = "……",
}
LocalizationConfig["loc_story_msg_118"] =
{
	zh = "是谁把你害成这样，你有线索吗？",
	en = "Who did this to you, do you have any clues?",
	zht = "是誰把你害成這樣，你有線索嗎？",
}
LocalizationConfig["loc_story_msg_119"] =
{
	zh = "一定是奶茶王子！他是我的竞争对手，一直嫉妒我和什么零食都百搭！",
	en = "It must have been that Milk Tea Prince! He is my competitor, he's always been jealous of how well I go with all types of snacks!",
	zht = "一定是奶茶王子！他是我的競爭對手，一直嫉妒我和什麼零食都百搭！",
}
LocalizationConfig["loc_story_msg_120"] =
{
	zh = "今天看到我时，他还跑开了，如果心里没鬼，为什么要躲着我？",
	en = "He ran off when he saw me today. If he's innocent, why is he avoiding me?",
	zht = "今天看到我時，他還跑開了，如果心裡沒鬼，為什麼要躲著我？",
}
LocalizationConfig["loc_story_msg_121"] =
{
	zh = "有点道理，那我们去找找奶茶王子吧。",
	en = "That's a good point, let's go find Milk Tea Prince then.",
	zht = "有點道理，那我們去找找奶茶王子吧。",
}
LocalizationConfig["loc_story_msg_122"] =
{
	zh = "给我站住！",
	en = "Stop right there!",
	zht = "給我站住！",
}
LocalizationConfig["loc_story_msg_123"] =
{
	zh = "不要，不要过来！",
	en = "No, don't come any closer!",
	zht = "不要，不要過來！",
}
LocalizationConfig["loc_story_msg_124"] =
{
	zh = "你这家伙，是不是你……诶？你……你怎么……",
	en = "You, it was you, wasn't it……huh? What's……what's up with you?……",
	zht = "你這傢伙，是不是你……誒？你……你怎麼……",
}
LocalizationConfig["loc_story_msg_125"] =
{
	zh = "还是被你发现了……",
	en = "You've found me out……",
	zht = "還是被你發現了……",
}
LocalizationConfig["loc_story_msg_126"] =
{
	zh = "你体内的珍珠呢？难道说……不是你偷走了我的汽？",
	en = "Where are your pearls? So……it wasn't you who stole my gas?",
	zht = "你體內的珍珠呢？難道說……不是你偷走了我的汽？",
}
LocalizationConfig["loc_story_msg_127"] =
{
	zh = "听说你没汽后，我还幸灾乐祸。但今早醒来后，我发现自己体内的珍珠也不见了。",
	en = "After hearing that you had no gas left, I was really smug about it. But when I woke up today I noticed that my own pearls from inside my body were gone.",
	zht = "聽說你沒汽後，我還幸災樂禍。但今早醒來後，我發現自己體內的珍珠也不見了。",
}
LocalizationConfig["loc_story_msg_128"] =
{
	zh = "喝奶茶会变胖，如果奶茶中有珍珠，用吸管吸珍珠的时候会让脸显得瘦，这就是女孩们喜欢我的原因。",
	en = "Drinking milk tea makes you fat, but if there are pearls in the tea, when you such pearls with a straw you will seem thin. That's why girls like me.",
	zht = "喝奶茶會變胖，如果奶茶中有珍珠，用吸管吸珍珠的時候會讓臉顯得瘦，這就是女孩們喜歡我的原因。",
}
LocalizationConfig["loc_story_msg_129"] =
{
	zh = "没了珍珠的话，我就再也不是女孩们的心头好了……",
	en = "Without any pearls, I'm no longer the heartthrob with the ladies that I was before……",
	zht = "沒了珍珠的話，我就再也不是女孩們的心頭好了……",
}
LocalizationConfig["loc_story_msg_130"] =
{
	zh = "奶茶王子也是受害者，那这到底是谁干的呢？",
	en = "The Milk Tea Prince is also a victim, then who was it exactly?",
	zht = "奶茶王子也是受害者，那這到底是誰幹的呢？",
}
LocalizationConfig["loc_story_msg_131"] =
{
	zh = "看来事有蹊跷，我们先到处打听下，看能不能找到线索吧。",
	en = "This seems rather strange, let's ask around and see if we can find any clues.",
	zht = "看來事有蹊蹺，我們先到處打聽下，看能不能找到線索吧。",
}
LocalizationConfig["loc_story_msg_132"] =
{
	zh = "汽水王子！奶茶王子！",
	en = "Soda Prince! Milk Tea Prince!",
	zht = "汽水王子！奶茶王子！",
}
LocalizationConfig["loc_story_msg_133"] =
{
	zh = "有人在喊你们，是你们的朋友吗？",
	en = "Someone's calling for you, are they your friend?",
	zht = "有人在喊你們，是你們的朋友嗎？",
}
LocalizationConfig["loc_story_msg_134"] =
{
	zh = "你是谁？",
	en = "Who are you?",
	zht = "你是誰？",
}
LocalizationConfig["loc_story_msg_135"] =
{
	zh = "虽然不记得哪里见过，但是看起来好眼熟啊。",
	en = "I don't remember where I've seen him before, but he does look pretty familiar.",
	zht = "雖然不記得哪裡見過，但是看起來好眼熟啊。",
}
LocalizationConfig["loc_story_msg_136"] =
{
	zh = "哎，也难怪你们不认识我了。失去了柠檬的味道后，现在人们都喊我“阿斯巴甜”……",
	en = "Sigh, no wonder you don't recognize me. After losing my lemon flavor, people now just call me “aspartame”……",
	zht = "哎，也難怪你們不認識我了。失去了檸檬的味道後，現在人們都喊我“阿斯巴甜”……",
}
LocalizationConfig["loc_story_msg_137"] =
{
	zh = "啊！",
	en = "Ah!",
	zht = "啊！",
}
LocalizationConfig["loc_story_msg_138"] =
{
	zh = "柠檬？难道你是……",
	en = "Lemon? Could you be……",
	zht = "檸檬？難道你是……",
}
LocalizationConfig["loc_story_msg_139"] =
{
	zh = "我是柠檬口味的彩虹糖——小黄。至少曾经是……",
	en = "I'm the lemon-flavored Skittle - Lil Yellow. Or at least, I was……",
	zht = "我是檸檬口味的彩虹糖——小黃。至少曾經是……",
}
LocalizationConfig["loc_story_msg_140"] =
{
	zh = "你怎么变成这样了？",
	en = "What's happened to you?",
	zht = "你怎麼變成這樣了？",
}
LocalizationConfig["loc_story_msg_141"] =
{
	zh = "我只记得眼前闪过道黑影后就晕过去了，醒来后就变成这样。",
	en = "I just remember a dark shadow suddenly rushing past me before passing out, when I woke up, I was like this.",
	zht = "我只記得眼前閃過道黑影後就暈過去了，醒來後就變成這樣。",
}
LocalizationConfig["loc_story_msg_142"] =
{
	zh = "没想你也……",
	en = "So you've also……",
	zht = "沒想你也……",
}
LocalizationConfig["loc_story_msg_143"] =
{
	zh = "也？难道说你们……",
	en = "Also? You're saying that you……",
	zht = "也？難道說你們……",
}
LocalizationConfig["loc_story_msg_144"] =
{
	zh = "你猜得没错，他们一个被偷走了汽，一个被偷走了珍珠。",
	en = "That's right, one of them has had their gas stolen, the other had their pearls taken.",
	zht = "你猜得沒錯，他們一個被偷走了汽，一個被偷走了珍珠。",
}
LocalizationConfig["loc_story_msg_145"] =
{
	zh = "这……",
	en = "This is so……",
	zht = "這……",
}
LocalizationConfig["loc_story_msg_146"] =
{
	zh = "算上你，已经出现了三个受害者了。",
	en = "Adding you, there have been three victims.",
	zht = "算上你，已經出現了三個受害者了。",
}
LocalizationConfig["loc_story_msg_147"] =
{
	zh = "看来事态严重，我们得要赶紧通知国王让他加强国内的防备了。",
	en = "This seems like a serious matter, we've got to notify the King, get him to increase the guard within the kingdom.",
	zht = "看來事態嚴重，我們得要趕緊通知國王讓他加強國內的防備了。",
}
LocalizationConfig["loc_story_msg_148"] =
{
	zh = "番茄酱侍卫，我有急事报告！",
	en = "Chief Guard Ketchup, I have something urgent to report!",
	zht = "番茄醬侍衛，我有急事報告！",
}
LocalizationConfig["loc_story_msg_149"] =
{
	zh = "等一下，他的样子有点奇怪。",
	en = "Wait, he looks a little strange.",
	zht = "等一下，他的樣子有點奇怪。",
}
LocalizationConfig["loc_story_msg_150"] =
{
	zh = "嘿嘿嘿……我已经不再是番茄酱侍卫了，我现在是番茄汤侍卫。",
	en = "Hehehe……I'm no longer the Ketchup Guard, I'm now just a Tomato Soup Guard.",
	zht = "嘿嘿嘿……我已經不再是番茄醬侍衛了，我現在是番茄湯侍衛。",
}
LocalizationConfig["loc_story_msg_151"] =
{
	zh = "什么？",
	en = "What?",
	zht = "什麼？",
}
LocalizationConfig["loc_story_msg_152"] =
{
	zh = "薯条国王呢？你把他怎么样了？",
	en = "Where's King French Fry? What have you done to him?",
	zht = "薯條國王呢？你把他怎麼樣了？",
}
LocalizationConfig["loc_story_msg_153"] =
{
	zh = "放心，国王现在很好，他正躺在一滩番茄汤上呢，嘿嘿嘿……",
	en = "Don't worry, the King is fine, he's lying in a pool of tomato soup, hehehe……",
	zht = "放心，國王現在很好，他正躺在一灘番茄湯上呢，嘿嘿嘿……",
}
LocalizationConfig["loc_story_msg_154"] =
{
	zh = "薯条配番茄汤！这是下午茶的禁忌，国王一定是受不了这个打击晕过去了。",
	en = "French fries with tomato soup? That is forbidden at teatime, the King must have passed out from not being able to stand it.",
	zht = "薯條配番茄湯！這是下午茶的禁忌，國王一定是受不了這個打擊暈過去了。",
}
LocalizationConfig["loc_story_msg_155"] =
{
	zh = "哼哼哼……所有受欢迎的下午茶都该死，去死吧……",
	en = "Hmph……All the teatime snacks deserve to die, take this!……",
	zht = "哼哼哼……所有受歡迎的下午茶都該死，去死吧……",
}
LocalizationConfig["loc_story_msg_156"] =
{
	zh = "咣！",
	en = "Bang!",
	zht = "咣！",
}
LocalizationConfig["loc_story_msg_157"] =
{
	zh = "啊——",
	en = "Ah……",
	zht = "啊——",
}
LocalizationConfig["loc_story_msg_158"] =
{
	zh = "哼，样子好凶，还好被我用石头敲晕。不过看样子，他是被人控制住了。",
	en = "Wooh, he looked really fierce, it's a good thing I knocked him out with this stone. But from the looks of it, he's under someone else's control.",
	zht = "哼，樣子好凶，還好被我用石頭敲暈。不過看樣子，他是被人控制住了。",
}
LocalizationConfig["loc_story_msg_159"] =
{
	zh = "照他刚才说的来看，对方的目标是受人们欢迎的下午茶。",
	en = "From what he just said, whoever it is' target are the popular teatime snacks.",
	zht = "照他剛才說的來看，對方的目標是受人們歡迎的下午茶。",
}
LocalizationConfig["loc_story_msg_160"] =
{
	zh = "糟了！",
	en = "Oh no!",
	zht = "糟了！",
}
LocalizationConfig["loc_story_msg_161"] =
{
	zh = "怎么了？",
	en = "What's up?",
	zht = "怎麼了？",
}
LocalizationConfig["loc_story_msg_162"] =
{
	zh = "如果你说的是真的话，这个城堡里还有一个可以下手的目标。",
	en = "If what you're saying is true, there's another target left in this castle.",
	zht = "如果你說的是真的話，這個城堡裡還有一個可以下手的目標。",
}
LocalizationConfig["loc_story_msg_163"] =
{
	zh = "是谁？",
	en = "Who is it?",
	zht = "是誰？",
}
LocalizationConfig["loc_story_msg_164"] =
{
	zh = "虾条公主！",
	en = "Princess Prawn Chip!",
	zht = "蝦條公主！",
}
LocalizationConfig["loc_story_msg_165"] =
{
	zh = "快来人啊，公主被人抓走了！",
	en = "Help, the princess has been kidnapped!",
	zht = "快來人啊，公主被人抓走了！",
}
LocalizationConfig["loc_story_msg_166"] =
{
	zh = "那人往哪里走了？",
	en = "Where did that person go?",
	zht = "那人往哪裡走了？",
}
LocalizationConfig["loc_story_msg_167"] =
{
	zh = "那里！",
	en = "Over there!",
	zht = "那裡！",
}
LocalizationConfig["loc_story_msg_168"] =
{
	zh = "快，也许我们还来得及！",
	en = "Quickly, we might still be able to make it in time!",
	zht = "快，也許我們還來得及！",
}
LocalizationConfig["loc_story_msg_169"] =
{
	zh = "公主！你没受伤吧？",
	en = "Princess! You're not hurt are you?",
	zht = "公主！你沒受傷吧？",
}
LocalizationConfig["loc_story_msg_170"] =
{
	zh = "额……啊……",
	en = "Oh……Ah……",
	zht = "額……啊……",
}
LocalizationConfig["loc_story_msg_171"] =
{
	zh = "糟了，那人让虾条公主受了潮，她无法出声了。",
	en = "Oh no, Princess Prawn Chip's been dampened, making her unable to speak.",
	zht = "糟了，那人讓蝦條公主受了潮，她無法出聲了。",
}
LocalizationConfig["loc_story_msg_172"] =
{
	zh = "不用说也知道，清脆的咀嚼声是虾条公主受欢迎的原因。",
	en = "It goes without saying that the reason Princess Prawn Chip is so popular is because of her crispy chewing sound.",
	zht = "不用說也知道，清脆的咀嚼聲是蝦條公主受歡迎的原因。",
}
LocalizationConfig["loc_story_msg_173"] =
{
	zh = "好狠毒的手段。",
	en = "What a cruel thing to do.",
	zht = "好狠毒的手段。",
}
LocalizationConfig["loc_story_msg_174"] =
{
	zh = "虾条公主，是谁把你变成这个样子的？你看到那人的脸了吗？",
	en = "Princess Prawn Chip, who did this to you? Did you see their face?",
	zht = "蝦條公主，是誰把你變成這個樣子的？你看到那人的臉了嗎？",
}
LocalizationConfig["loc_story_msg_175"] =
{
	zh = "呜……啊……",
	en = "Oh……Ah……",
	zht = "嗚……啊……",
}
LocalizationConfig["loc_story_msg_176"] =
{
	zh = "公主是想说什么吗？",
	en = "What are you trying to say, princess?",
	zht = "公主是想說什麼嗎？",
}
LocalizationConfig["loc_story_msg_177"] =
{
	zh = "我明白了！",
	en = "I know!",
	zht = "我明白了！",
}
LocalizationConfig["loc_story_msg_178"] =
{
	zh = "公主的意思是，对方蒙着脸，没看清对方的样子。",
	en = "The princess is saying that whoever it was covered their face, she didn't get a clear look at them.",
	zht = "公主的意思是，對方蒙著臉，沒看清對方的樣子。",
}
LocalizationConfig["loc_story_msg_179"] =
{
	zh = "但那人临走前说，下一个目标是培根女巫，让你们快点去找她。",
	en = "But before they left, they said that their next target was Sorceress Bacon, go and find her ASAP.",
	zht = "但那人臨走前說，下一個目標是培根女巫，讓你們快點去找她。",
}
LocalizationConfig["loc_story_msg_180"] =
{
	zh = "嗯……嗯……",
	en = "Mmm……hmmm……",
	zht = "嗯……嗯……",
}
LocalizationConfig["loc_story_msg_181"] =
{
	zh = "这么瞎比划都能看懂……",
	en = "How are you able to read this chicken scratch writing?",
	zht = "這麼瞎比劃都能看懂……",
}
LocalizationConfig["loc_story_msg_182"] =
{
	zh = "别吐槽了！我们快走吧，希望这次能抓住那人。",
	en = "Quick your complaining! Let's go, I hope that we're able to catch them this time.",
	zht = "別吐槽了！我們快走吧，希望這次能抓住那人。",
}
LocalizationConfig["loc_story_msg_183"] =
{
	zh = "前面有人倒在地上。",
	en = "There's someone lying on the floor up ahead.",
	zht = "前面有人倒在地上。",
}
LocalizationConfig["loc_story_msg_184"] =
{
	zh = "猪肉干小姐，你没事吧？",
	en = "Ms. Jerky, are you ok?",
	zht = "豬肉幹小姐，你沒事吧？",
}
LocalizationConfig["loc_story_msg_185"] =
{
	zh = "唔……嗯……额……",
	en = "Oh……mmmm……aawww……",
	zht = "唔……嗯……額……",
}
LocalizationConfig["loc_story_msg_186"] =
{
	zh = "她在说什么？",
	en = "What's she saying?",
	zht = "她在說什麼？",
}
LocalizationConfig["loc_story_msg_187"] =
{
	zh = "我听听……",
	en = "Let me listen……",
	zht = "我聽聽……",
}
LocalizationConfig["loc_story_msg_188"] =
{
	zh = "她说她不是猪肉干小姐，她是被夺走全身油水的培根女巫……",
	en = "She saying that she isn't Ms. Jerky, she's Sorceress Bacon, but she's had all her oil and moisture taken……",
	zht = "她說她不是豬肉幹小姐，她是被奪走全身油水的培根女巫……",
}
LocalizationConfig["loc_story_msg_189"] =
{
	zh = "啊！我们又来晚了一步。",
	en = "Ah! We're one step too late again.",
	zht = "啊！我們又來晚了一步。",
}
LocalizationConfig["loc_story_msg_190"] =
{
	zh = "她是因为全身脱水而晕倒，让她喝点水再说吧。",
	en = "She fainted after being dehydrated, give her some water.",
	zht = "她是因為全身脫水而暈倒，讓她喝點水再說吧。",
}
LocalizationConfig["loc_story_msg_191"] =
{
	zh = "咕咚，咕咚……",
	en = "Glug, glug……",
	zht = "咕咚，咕咚……",
}
LocalizationConfig["loc_story_msg_192"] =
{
	zh = "谢谢你们救了我。",
	en = "Thank you for saving me.",
	zht = "謝謝你們救了我。",
}
LocalizationConfig["loc_story_msg_193"] =
{
	zh = "谢就不用了，我们想知道是谁把你变成这样。",
	en = "There's no need to thank us, we'd like to know who did this to you though.",
	zht = "謝就不用了，我們想知道是誰把你變成這樣。",
}
LocalizationConfig["loc_story_msg_194"] =
{
	zh = "那人从背后袭击了我，夺走了我的油锅，我没来得及看清对方长相。",
	en = "Whoever it was, they attacked me from behind, they took my frying pan, I wasn't able to see who they were in time.",
	zht = "那人從背後襲擊了我，奪走了我的油鍋，我沒來得及看清對方長相。",
}
LocalizationConfig["loc_story_msg_195"] =
{
	zh = "就是那个可以将各种口味融合于自身的油锅吗？",
	en = "You mean that frying pan that allows you to combine any flavor with yourself?",
	zht = "就是那個可以將各種口味融合於自身的油鍋嗎？",
}
LocalizationConfig["loc_story_msg_196"] =
{
	zh = "没错。不过对方太大意了，我到底是个女巫，可以通过魔法得知对方的身份。",
	en = "That's right. Butt this person has been too reckless, I'm a sorceress, I can find out who they are from using my magic.",
	zht = "沒錯。不過對方太大意了，我到底是個女巫，可以通過魔法得知對方的身份。",
}
LocalizationConfig["loc_story_msg_197"] =
{
	zh = "事不宜迟，快动手吧。",
	en = "There's no time to waste, do it right away.",
	zht = "事不宜遲，快動手吧。",
}
LocalizationConfig["loc_story_msg_198"] =
{
	zh = "无糖的乌龙茶，没有夹心的饼干，脱脂的牛奶……",
	en = "Sugarless oolong tea, cookies with no filling, 100% skimmed milk……",
	zht = "無糖的烏龍茶，沒有夾心的餅乾，脫脂的牛奶……",
}
LocalizationConfig["loc_story_msg_199"] =
{
	zh = "被世人抛弃在角角落落的下午茶啊，听从我的召唤，来此聚集，将你们所知的一切告诉我！",
	en = "Forsaken teatime snacks everywhere, listen to my call, assemble here and tell me everything you know!",
	zht = "被世人拋棄在角角落落的下午茶啊，聽從我的召喚，來此聚集，將你們所知的一切告訴我！",
}
LocalizationConfig["loc_story_msg_200"] =
{
	zh = "嗯，嗯，嗯……",
	en = "Mhmm, mmmm, mhm……",
	zht = "嗯，嗯，嗯……",
}
LocalizationConfig["loc_story_msg_201"] =
{
	zh = "我知道对方是谁了。",
	en = "I know who the culprit is.",
	zht = "我知道對方是誰了。",
}
LocalizationConfig["loc_story_msg_202"] =
{
	zh = "是谁？",
	en = "Who is it?",
	zht = "是誰？",
}
LocalizationConfig["loc_story_msg_203"] =
{
	zh = "烤翅女皇！",
	en = "Queen Chicken Wing!",
	zht = "烤翅女皇！",
}
LocalizationConfig["loc_story_msg_204"] =
{
	zh = "她为什么要这么做？",
	en = "Why would she want to do this?",
	zht = "她為什麼要這麼做？",
}
LocalizationConfig["loc_story_msg_205"] =
{
	zh = "她曾经是最受欢迎的下午茶，但人们的口味变了后，她就失宠了。",
	en = "She used to be the most popular teatime snack of all, but after people's tastes changed, she was left on the sidelines.",
	zht = "她曾經是最受歡迎的下午茶，但人們的口味變了後，她就失寵了。",
}
LocalizationConfig["loc_story_msg_206"] =
{
	zh = "她虽然很强，但贪婪也会成为她的弱点……",
	en = "She may be powerful, but greed will be her demise……",
	zht = "她雖然很強，但貪婪也會成為她的弱點……",
}
LocalizationConfig["loc_story_msg_207"] =
{
	zh = "这是什么意思？",
	en = "What do you mean?",
	zht = "這是什麼意思？",
}
LocalizationConfig["loc_story_msg_208"] =
{
	zh = "到时候你就知道了。",
	en = "You'll know when the time comes.",
	zht = "到時候你就知道了。",
}
LocalizationConfig["loc_story_msg_209"] =
{
	zh = "你的阴谋到此为止了，烤翅女皇！",
	en = "Your scheme's over, Queen Chicken Wing!",
	zht = "你的陰謀到此為止了，烤翅女皇！",
}
LocalizationConfig["loc_story_msg_210"] =
{
	zh = "哼哼哼，烤翅女皇已经不复存在了，我已经通过油锅融合了所有受欢迎的下午茶的特点。",
	en = "Hmph, Queen Chicken Wing is no more, I have used this frying pan to combine all the most popular features of teatime.",
	zht = "哼哼哼，烤翅女皇已經不復存在了，我已經通過油鍋融合了所有受歡迎的下午茶的特點。",
}
LocalizationConfig["loc_story_msg_211"] =
{
	zh = "现在，你们应该称我为“炸鸡魔后”。",
	en = "You should call me “Queen Fried Chicken” now.",
	zht = "現在，你們應該稱我為“炸雞魔後”。",
}
LocalizationConfig["loc_story_msg_212"] =
{
	zh = "什么味道这么难闻？",
	en = "What stinks so much?",
	zht = "什麼味道這麼難聞？",
}
LocalizationConfig["loc_story_msg_213"] =
{
	zh = "好像是……炸鸡魔后身上飘出来的。",
	en = "I think it's……coming from Queen Fried Chicken",
	zht = "好像是……炸雞魔後身上飄出來的。",
}
LocalizationConfig["loc_story_msg_214"] =
{
	zh = "可恶，你们两个外来者不懂欣赏就不要开口！",
	en = "Hmmph, if you two outsiders don't understand, don't open your mouths!",
	zht = "可惡，你們兩個外來者不懂欣賞就不要開口！",
}
LocalizationConfig["loc_story_msg_215"] =
{
	zh = "额，其实……",
	en = "Erm, actually……",
	zht = "額，其實……",
}
LocalizationConfig["loc_story_msg_216"] =
{
	zh = "我们也觉得难闻！",
	en = "We don't like it either!",
	zht = "我們也覺得難聞！",
}
LocalizationConfig["loc_story_msg_217"] =
{
	zh = "啧啧，她身上混着柠檬的酸味、皮肤上泛着汽水的气泡、脸上沾着奶茶中的珍珠……",
	en = "Tut tut, her body has a mixture of the sour smell of lemons, skin is covered soda bubbles and a face covered in milk tea pearls……",
	zht = "嘖嘖，她身上混著檸檬的酸味、皮膚上泛著汽水的氣泡、臉上沾著奶茶中的珍珠……",
}
LocalizationConfig["loc_story_msg_218"] =
{
	zh = "你为了成为最受欢迎的下午茶而夺走了别人的特点，但这样反而让你不伦不类。",
	en = "In an attempt to become the most popular teatime snack, you've taken the features of other people but this has actually made you both a little of everything and nothing all at the same time.",
	zht = "你為了成為最受歡迎的下午茶而奪走了別人的特點，但這樣反而讓你不倫不類。",
}
LocalizationConfig["loc_story_msg_219"] =
{
	zh = "不会的，不会的，你们在骗我！",
	en = "That can't be, it's impossible, you're lying!",
	zht = "不會的，不會的，你們在騙我！",
}
LocalizationConfig["loc_story_msg_220"] =
{
	zh = "我的油锅除了能融合特点之外，还能告知真相，你好好看着它吧",
	en = "Along with being able to fuse features, my frying pan can also reveal the truth, take a look.",
	zht = "我的油鍋除了能融合特點之外，還能告知真相，你好好看著它吧",
}
LocalizationConfig["loc_story_msg_221"] =
{
	zh = "油锅啊油锅，告诉我，谁是这个星球上最不受欢迎的下午茶。",
	en = "Frying pan, oh frying pan, tell me, who is the most unpopular teatime snack on this planet?",
	zht = "油鍋啊油鍋，告訴我，誰是這個星球上最不受歡迎的下午茶。",
}
LocalizationConfig["loc_story_msg_222"] =
{
	zh = "什么？油锅中竟然是我的样子！",
	en = "What? My face is on the frying pan!",
	zht = "什麼？油鍋中竟然是我的樣子！",
}
LocalizationConfig["loc_story_msg_223"] =
{
	zh = "不！不——",
	en = "No! Noooo……",
	zht = "不！不——",
}
LocalizationConfig["loc_story_msg_224"] =
{
	zh = "竟然被自己的样子吓晕。",
	en = "She's been scared by her own reflection.",
	zht = "竟然被自己的樣子嚇暈。",
}
LocalizationConfig["loc_story_msg_225"] =
{
	zh = "真是自作自受。",
	en = "She's made her own bed, let her lie in it.",
	zht = "真是自作自受。",
}
LocalizationConfig["loc_story_msg_226"] =
{
	zh = "诶呀呜呜，这次任务完成的更快了呀",
	en = "Aye, Count Mews this quest has been completed even quicker than the last.",
	zht = "誒呀嗚嗚，這次任務完成的更快了呀",
}
LocalizationConfig["loc_story_msg_227"] =
{
	zh = "呜，为了回家我也是很认真的",
	en = "Ooh, I'm really serious about getting home too",
	zht = "嗚，為了回家我也是很認真的",
}
LocalizationConfig["loc_story_msg_228"] =
{
	zh = "为了补偿你的辛苦工作，给你带了点三文鱼干",
	en = "Here's some dried salmon to make up for your hard work.",
	zht = "為了補償你的辛苦工作，給你帶了點三文魚幹",
}
LocalizationConfig["loc_story_msg_229"] =
{
	zh = "哇，这么好！！",
	en = "Woah, thank you so much!!",
	zht = "哇，這麼好！！",
}
LocalizationConfig["loc_story_msg_230"] =
{
	zh = "上等的三文鱼干，给你打个折扣掉五万金币，去新的星球加油吧",
	en = "Top-quality dried salmon, I'll give you a discount and deduct 50,000 gold, good luck at the next planet",
	zht = "上等的三文魚幹，給你打個折扣掉五萬金幣，去新的星球加油吧",
}
LocalizationConfig["loc_story_msg_231"] =
{
	zh = "强买强卖呀！喂呜呜你这就吃起来了吗！给我留一点呢！",
	en = "Hard sell, hard buy! Woah, Count Mews, you're stuffing it into your mouth already? Leave a little for me!",
	zht = "強買強賣呀！喂嗚嗚你這就吃起來了嗎！給我留一點呢！",
}
LocalizationConfig["loc_story_msg_232"] =
{
	zh = "听说这里是以藏品众多而闻名的博物馆星球。",
	en = "I heard that this is the famous Museum Planet that is full of all sorts of collections!",
	zht = "聽說這裡是以藏品眾多而聞名的博物館星球。",
}
LocalizationConfig["loc_story_msg_233"] =
{
	zh = "哇！要是捡到几件藏品我们就发财了。",
	en = "Wow! If we manage to pick up a few artifacts from the collections we'll be rich!",
	zht = "哇！要是撿到幾件藏品我們就發財了。",
}
LocalizationConfig["loc_story_msg_234"] =
{
	zh = "怎么捡？",
	en = "How could we pick them up?",
	zht = "怎麼撿？",
}
LocalizationConfig["loc_story_msg_235"] =
{
	zh = "当然去博物馆捡！",
	en = "From the museum of course!",
	zht = "當然去博物館撿！",
}
LocalizationConfig["loc_story_msg_236"] =
{
	zh = "去博物馆……捡藏品……吗？",
	en = "You want to go to the museum……and take items from their collection?",
	zht = "去博物館……撿藏品……嗎？",
}
LocalizationConfig["loc_story_msg_237"] =
{
	zh = "你是不是对“捡东西”这个词有什么误会……",
	en = "Have you got some sort of misunderstanding about what “pick up things” means?",
	zht = "你是不是對“撿東西”這個詞有什麼誤會……",
}
LocalizationConfig["loc_story_msg_238"] =
{
	zh = "据我得到的消息，这个星球的博物馆似乎发生了什么事情。",
	en = "According to the message I received, something seems to have happened at this museum.",
	zht = "據我得到的消息，這個星球的博物館似乎發生了什麼事情。",
}
LocalizationConfig["loc_story_msg_239"] =
{
	zh = "不管发生什么事，里面的藏品我都要捡回去！",
	en = "No matter what's happened, I want to take all the artifacts there back with us!",
	zht = "不管發生什麼事，裡面的藏品我都要撿回去！",
}
LocalizationConfig["loc_story_msg_240"] =
{
	zh = "（小声）这样和抢有什么分别？",
	en = "(Whispers) What's the difference between doing that and stealing?",
	zht = "（小聲）這樣和搶有什麼分別？",
}
LocalizationConfig["loc_story_msg_241"] =
{
	zh = "你为什么不让我们进来？是怕我们把藏品都捡光吗？",
	en = "Why don't you want to let me in? Are you afraid we'll take everything?",
	zht = "你為什麼不讓我們進來？是怕我們把藏品都撿光嗎？",
}
LocalizationConfig["loc_story_msg_242"] =
{
	zh = "这个博物馆里面的藏品都活了，我不让你们进来是怕你们遇到危险？",
	en = "All the collections in this museum are alive. The reason I won't let you in is because I'm afraid it'll be dangerous.",
	zht = "這個博物館裡面的藏品都活了，我不讓你們進來是怕你們遇到危險？",
}
LocalizationConfig["loc_story_msg_243"] =
{
	zh = "藏品都活了？这是怎么回事？",
	en = "The collections are alive? What?",
	zht = "藏品都活了？這是怎麼回事？",
}
LocalizationConfig["loc_story_msg_244"] =
{
	zh = "这个博物馆只有我一个保安，因为太累我经常会忍不住打瞌睡。",
	en = "I'm the only security guard at this museum, I often can't help but fall asleep from exhaustion.",
	zht = "這個博物館只有我一個保安，因為太累我經常會忍不住打瞌睡。",
}
LocalizationConfig["loc_story_msg_245"] =
{
	zh = "昨天打瞌睡时，眼前闪过白影，醒来后，发现里面的藏品大部分不见了，而剩下的都活了。",
	en = "When I was sleeping yesterday, a white shadow rushed past me. When I woke up, I noticed that most of the items on display had disappeared, the remaining ones were all alive.",
	zht = "昨天打瞌睡時，眼前閃過白影，醒來後，發現裡面的藏品大部分不見了，而剩下的都活了。",
}
LocalizationConfig["loc_story_msg_246"] =
{
	zh = "它们走来走去，太吓人了……",
	en = "They were walking around, it was terrifying……",
	zht = "它們走來走去，太嚇人了……",
}
LocalizationConfig["loc_story_msg_247"] =
{
	zh = "居然发生了这种事……让我们进去看看吧，说不定我们能解决。",
	en = "I'd never of thought that something like this could happen……let us go inside and take a look. We might be able to help you solve this problem.",
	zht = "居然發生了這種事……讓我們進去看看吧，說不定我們能解決。",
}
LocalizationConfig["loc_story_msg_248"] =
{
	zh = "好吧，我可以让你们进去，但一定要小心。",
	en = "OK then, I'll let you inside, but you've gotta be careful.",
	zht = "好吧，我可以讓你們進去，但一定要小心。",
}
LocalizationConfig["loc_story_msg_249"] =
{
	zh = "你这个小偷，躲在这里干什么？",
	en = "Hey thief, what are you doing hiding here?",
	zht = "你這個小偷，躲在這裡幹什麼？",
}
LocalizationConfig["loc_story_msg_250"] =
{
	zh = "不不不，我只是普通的游客而已，藏品突然复活让我吓了一跳，所以才躲起来。",
	en = "No no no, I'm just a visitor, I was terrified when the exhibition pieces all came back to life so I hid here.",
	zht = "不不不，我只是普通的遊客而已，藏品突然復活讓我嚇了一跳，所以才躲起來。",
}
LocalizationConfig["loc_story_msg_251"] =
{
	zh = "游客？可是你这幅模样真的很像小偷诶……",
	en = "Visitor? But you really look like a thief……",
	zht = "遊客？可是你這幅模樣真的很像小偷誒……",
}
LocalizationConfig["loc_story_msg_252"] =
{
	zh = "是……是吗？原来大哥没骗我，我还以为它嫉妒我头巾的样式好看才这么说……",
	en = "Hmm……really? You aren't lying, I thought is said that because it was jealous of my great-looking bandanna……",
	zht = "是……是嗎？原來大哥沒騙我，我還以為它嫉妒我頭巾的樣式好看才這麼說……",
}
LocalizationConfig["loc_story_msg_253"] =
{
	zh = "你为啥要戴这么个头巾？",
	en = "Why are you wearing this bandanna?",
	zht = "你為啥要戴這麼個頭巾？",
}
LocalizationConfig["loc_story_msg_254"] =
{
	zh = "我们兄弟三人，是为方便面代言的明星，因为名声在外，所以出门才……",
	en = "Me and my other two brothers are famous ramen spokespeople, as we're so famous, when we leave the house we'll……",
	zht = "我們兄弟三人，是為速食麵代言的明星，因為名聲在外，所以出門才……",
}
LocalizationConfig["loc_story_msg_255"] =
{
	zh = "那你知道这里到底发生了什么事吗？",
	en = "Then do you know what exactly happened here?",
	zht = "那你知道這裡到底發生了什麼事嗎？",
}
LocalizationConfig["loc_story_msg_256"] =
{
	zh = "藏品突然就这么动起来了，我也不清楚是怎么回事。",
	en = "The collection items suddenly came to life, I don't quite understand why either.",
	zht = "藏品突然就這麼動起來了，我也不清楚是怎麼回事。",
}
LocalizationConfig["loc_story_msg_257"] =
{
	zh = "我们再往里走走看看吧。",
	en = "Let's go further inside and see.",
	zht = "我們再往裡走走看看吧。",
}
LocalizationConfig["loc_story_msg_258"] =
{
	zh = "这只小狗好凶啊！我们两个人才能制服它。",
	en = "This little dog's really vicious! It's taken the two of us to restrain it.",
	zht = "這只小狗好凶啊！我們兩個人才能制服它。",
}
LocalizationConfig["loc_story_msg_259"] =
{
	zh = "竟然敢称我阿努比斯为小狗，可恶！",
	en = "You dare to call the great Anubis a dog? Hmmph!",
	zht = "竟然敢稱我阿努比斯為小狗，可惡！",
}
LocalizationConfig["loc_story_msg_260"] =
{
	zh = "这家伙挣扎的力气太大，不想个办法困住它的话，我们没法前进。",
	en = "This guy's too strong, if we don't find a way to restrain him, we won't be able to go any further.",
	zht = "這傢伙掙扎的力氣太大，不想個辦法困住它的話，我們沒法前進。",
}
LocalizationConfig["loc_story_msg_261"] =
{
	zh = "哼哼，我是来自遥远星球的死神，不会这么简单就被困住的！",
	en = "Hmph, I'm the lord of death from a distant planet, I won't be so easily restrained!",
	zht = "哼哼，我是來自遙遠星球的死神，不會這麼簡單就被困住的！",
}
LocalizationConfig["loc_story_msg_262"] =
{
	zh = "我有办法了！",
	en = "I have an idea!",
	zht = "我有辦法了！",
}
LocalizationConfig["loc_story_msg_263"] =
{
	zh = "什么？都这个时候了，你还有心思合成物品？",
	en = "What? You're still in the mood to synthesize items at a time like this?",
	zht = "什麼？都這個時候了，你還有心思合成物品？",
}
LocalizationConfig["loc_story_msg_264"] =
{
	zh = "火把和任务卷轴……你不是认真的吧？",
	en = "A torch and a scroll……You can't be serious?",
	zht = "火把和任務卷軸……你不是認真的吧？",
}
LocalizationConfig["loc_story_msg_265"] =
{
	zh = "完工！",
	en = "Complete!",
	zht = "完工！",
}
LocalizationConfig["loc_story_msg_266"] =
{
	zh = "竟然想用骨头来诱惑我？我可是胡狼啊，绝对不会为一根骨头屈服的，汪汪！",
	en = "You want to use a bone to lure me? I'm a jackal, I won't be so easily won over by a mere bone, woof!",
	zht = "竟然想用骨頭來誘惑我？我可是胡狼啊，絕對不會為一根骨頭屈服的，汪汪！",
}
LocalizationConfig["loc_story_msg_267"] =
{
	zh = "怎……怎么回事？我怎么不由自主地……",
	en = "Wh……what's going? How am I moving without……",
	zht = "怎……怎麼回事？我怎麼不由自主地……",
}
LocalizationConfig["loc_story_msg_268"] =
{
	zh = "嘿嘿，嘴上说不要，身体却很老实啊。",
	en = "Hee-hee, your mouth says no, but your body screams yes.",
	zht = "嘿嘿，嘴上說不要，身體卻很老實啊。",
}
LocalizationConfig["loc_story_msg_269"] =
{
	zh = "我要是嘴馋这根骨头我就是小狗！",
	en = "If I can't help but gnaw on this bone then I'm no more than a little dog!",
	zht = "我要是嘴饞這根骨頭我就是小狗！",
}
LocalizationConfig["loc_story_msg_270"] =
{
	zh = "汪！",
	en = "Woof!",
	zht = "汪！",
}
LocalizationConfig["loc_story_msg_271"] =
{
	zh = "呜呜，这家伙怎么了？",
	en = "Count Mews, what's up with this guy?",
	zht = "嗚嗚，這傢伙怎麼了？",
}
LocalizationConfig["loc_story_msg_272"] =
{
	zh = "嘿嘿，我听说胡狼是犬科动物，既然是犬科，应该都喜欢骨头吧。",
	en = "Hee-hee, I heard that jackals were part of the canine family, since they're canines they ought to love bones.",
	zht = "嘿嘿，我聽說胡狼是犬科動物，既然是犬科，應該都喜歡骨頭吧。",
}
LocalizationConfig["loc_story_msg_273"] =
{
	zh = "想不想要这根骨头呀？",
	en = "Do you want this bone?",
	zht = "想不想要這根骨頭呀？",
}
LocalizationConfig["loc_story_msg_274"] =
{
	zh = "不想！",
	en = "No!",
	zht = "不想！",
}
LocalizationConfig["loc_story_msg_275"] =
{
	zh = "汪！",
	en = "Woof!",
	zht = "汪！",
}
LocalizationConfig["loc_story_msg_276"] =
{
	zh = "既然不想要，那我就扔了它。（扔出去）去吧。",
	en = "As you don't want it, I'll throw it away. (Throws away) Go fetch.",
	zht = "既然不想要，那我就扔了它。（扔出去）去吧。",
}
LocalizationConfig["loc_story_msg_277"] =
{
	zh = "哈……哈……哈……",
	en = "Ha……ha……ha……",
	zht = "哈……哈……哈……",
}
LocalizationConfig["loc_story_msg_278"] =
{
	zh = "竟然真的像小狗一样冲了出去……",
	en = "He really did run after it just like a dog……",
	zht = "竟然真的像小狗一樣沖了出去……",
}
LocalizationConfig["loc_story_msg_279"] =
{
	zh = "这个铠甲无论被打倒多少次，都能自己站起来……",
	en = "No matter how many times this armor is knocked down, it will always stand back up again……",
	zht = "這個鎧甲無論被打倒多少次，都能自己站起來……",
}
LocalizationConfig["loc_story_msg_280"] =
{
	zh = "加油，我们一定可以打败它的！",
	en = "Come on, we can defeat it!",
	zht = "加油，我們一定可以打敗它的！",
}
LocalizationConfig["loc_story_msg_281"] =
{
	zh = "住手！不要打了，我的盔甲都要出现裂痕了……",
	en = "Stop! Don't hit me, my armor's about to crack……",
	zht = "住手！不要打了，我的盔甲都要出現裂痕了……",
}
LocalizationConfig["loc_story_msg_282"] =
{
	zh = "我可是来自中世纪的盔甲，年龄都几千岁了，你们忍心这样殴打一个老人家吗？",
	en = "I'm a suit of armor from the middle ages, I'm already thousands of years old, are you really so hardhearted that you'd beat an old man like this?",
	zht = "我可是來自中世紀的盔甲，年齡都幾千歲了，你們忍心這樣毆打一個老人家嗎？",
}
LocalizationConfig["loc_story_msg_283"] =
{
	zh = "这……不是你先动手的吗？",
	en = "You hit us first didn't you?",
	zht = "這……不是你先動手的嗎？",
}
LocalizationConfig["loc_story_msg_284"] =
{
	zh = "这样吧，只要你们能满足我的要求，我就让你们通过这里。",
	en = "How about this, as long as you meet my demands, I'll let you through",
	zht = "這樣吧，只要你們能滿足我的要求，我就讓你們通過這裡。",
}
LocalizationConfig["loc_story_msg_285"] =
{
	zh = "什么要求？",
	en = "What demands?",
	zht = "什麼要求？",
}
LocalizationConfig["loc_story_msg_286"] =
{
	zh = "上次有个小男孩来这里玩的时候，随身携带的平板上在播放着机器人动画。",
	en = "There was a little boy playing around here before, he was carrying a tablet with him that was playing a robot cartoon.",
	zht = "上次有個小男孩來這裡玩的時候，隨身攜帶的平板上在播放著機器人動畫。",
}
LocalizationConfig["loc_story_msg_287"] =
{
	zh = "机器人组合的样子很像拼装盔甲，而且台词听起来很有趣，你们配合我表演下，我就不为难你们。",
	en = "The robots looked like they were made from armor and their lines were great, if you perform it with me I'll let you go.",
	zht = "機器人組合的樣子很像拼裝盔甲，而且臺詞聽起來很有趣，你們配合我表演下，我就不為難你們。",
}
LocalizationConfig["loc_story_msg_288"] =
{
	zh = "可是我们不懂什么台词。",
	en = "But we don't know the lines……",
	zht = "可是我們不懂什麼臺詞。",
}
LocalizationConfig["loc_story_msg_289"] =
{
	zh = "我记得，我教你们。",
	en = "I remember, I'll teach you.",
	zht = "我記得，我教你們。",
}
LocalizationConfig["loc_story_msg_290"] =
{
	zh = "台词是这样……这样……那样……那样……",
	en = "The lines were this……this……that……that",
	zht = "臺詞是這樣……這樣……那樣……那樣……",
}
LocalizationConfig["loc_story_msg_291"] =
{
	zh = "这台词好热血！",
	en = "These lines are so powerful!",
	zht = "這臺詞好熱血！",
}
LocalizationConfig["loc_story_msg_292"] =
{
	zh = "好……好羞耻……",
	en = "So……so disgraceful…… ",
	zht = "好……好羞恥……",
}
LocalizationConfig["loc_story_msg_293"] =
{
	zh = "台词都背熟了吗？开始吧！",
	en = "Do you remember your lines? Let's start!",
	zht = "臺詞都背熟了嗎？開始吧！",
}
LocalizationConfig["loc_story_msg_294"] =
{
	zh = "开启连锁控制，热能装置连接！",
	en = "Activate chain control, connect thermal device!",
	zht = "開啟連鎖控制，熱能裝置連接！",
}
LocalizationConfig["loc_story_msg_295"] =
{
	zh = "启动电源，增大推力，开始组合！",
	en = "Activate power source, increase propulsion, start forming!",
	zht = "啟動電源，增大推力，開始組合！",
}
LocalizationConfig["loc_story_msg_296"] =
{
	zh = "前进！无敌机器人。",
	en = "Advance! Invincible robot.",
	zht = "前進！無敵機器人。",
}
LocalizationConfig["loc_story_msg_297"] =
{
	zh = "组成脚和腿。",
	en = "Form feet and legs.",
	zht = "組成腳和腿。",
}
LocalizationConfig["loc_story_msg_298"] =
{
	zh = "组成躯干和手臂。",
	en = "Form body and arms.",
	zht = "組成軀幹和手臂。",
}
LocalizationConfig["loc_story_msg_299"] =
{
	zh = "我来组成头部！",
	en = "I'll form the head!",
	zht = "我來組成頭部！",
}
LocalizationConfig["loc_story_msg_300"] =
{
	zh = "耶，咕咕，我们成功了！",
	en = "Yeah, Salem, we did it!",
	zht = "耶，咕咕，我們成功了！",
}
LocalizationConfig["loc_story_msg_301"] =
{
	zh = "不错，你们表现很好，可以通过这里了。",
	en = "Not bad, you did a great job, you can pass through here.",
	zht = "不錯，你們表現很好，可以通過這裡了。",
}
LocalizationConfig["loc_story_msg_302"] =
{
	zh = "呜呜，这件事你要是敢说出去，我一定会把你扔出飞船的！",
	en = "Count Mews if you speak about this to anyone, I will throw you out of the ship!",
	zht = "嗚嗚，這件事你要是敢說出去，我一定會把你扔出飛船的！",
}
LocalizationConfig["loc_story_msg_303"] =
{
	zh = "……",
	en = "……",
	zht = "……",
}
LocalizationConfig["loc_story_msg_304"] =
{
	zh = "这个藏品很有意思，整体风格都非常近代。",
	en = "This collection piece is really astounding, its got a really modern style.",
	zht = "這個藏品很有意思，整體風格都非常近代。",
}
LocalizationConfig["loc_story_msg_305"] =
{
	zh = "……",
	en = "……",
	zht = "……",
}
LocalizationConfig["loc_story_msg_306"] =
{
	zh = "你看这个蝴蝶结，这个帽子，还有双辫子，都非常的时尚。",
	en = "Look at this bow, this hat and these pigtails, they're all really fashionable.",
	zht = "你看這個蝴蝶結，這個帽子，還有雙辮子，都非常的時尚。",
}
LocalizationConfig["loc_story_msg_307"] =
{
	zh = "……",
	en = "……",
	zht = "……",
}
LocalizationConfig["loc_story_msg_308"] =
{
	zh = "看起来还是个侦探的打扮，咕咕，你说这会是什么时代的藏品？",
	en = "It looks like a detective's clothing, Salem. What time do you think this piece is from?",
	zht = "看起來還是個偵探的打扮，咕咕，你說這會是什麼時代的藏品？",
}
LocalizationConfig["loc_story_msg_309"] =
{
	zh = "我对这个没研究，不好说。",
	en = "I couldn't say, I don't know anything about it.",
	zht = "我對這個沒研究，不好說。",
}
LocalizationConfig["loc_story_msg_310"] =
{
	zh = "我说你们够了！我不是什么藏品，我是来调查案件的私人侦探！",
	en = "Enough! I'm not some collection piece, I'm a private detective here on an investigation.",
	zht = "我說你們夠了！我不是什麼藏品，我是來調查案件的私人偵探！",
}
LocalizationConfig["loc_story_msg_311"] =
{
	zh = "啊！",
	en = "Ah!",
	zht = "啊！",
}
LocalizationConfig["loc_story_msg_312"] =
{
	zh = "这……",
	en = "This is so……",
	zht = "這……",
}
LocalizationConfig["loc_story_msg_313"] =
{
	zh = "咳咳……侦探小姐，我们也是来看看到底发生了什么事的，你有什么线索吗？",
	en = "Cough cough……Miss……detective, we're here to find out what exactly happened here too, do you have any clues?",
	zht = "咳咳……偵探小姐，我們也是來看看到底發生了什麼事的，你有什麼線索嗎？",
}
LocalizationConfig["loc_story_msg_314"] =
{
	zh = "哼！当然有了，我发现了一个奇怪的白衣男子，凡是被他碰过的藏品都会有生命。",
	en = "Hmph! Of course I do, I found a strange man dressed in white, every collection piece he touches turns to life.",
	zht = "哼！當然有了，我發現了一個奇怪的白衣男子，凡是被他碰過的藏品都會有生命。",
}
LocalizationConfig["loc_story_msg_315"] =
{
	zh = "白衣男子应该就是引起一切问题的人了，他现在在哪里？",
	en = "This man dressed in white must be the one causing all the problems, where is he now?",
	zht = "白衣男子應該就是引起一切問題的人了，他現在在哪裡？",
}
LocalizationConfig["loc_story_msg_316"] =
{
	zh = "他往瓷器馆那里走了。",
	en = "He went to the Pottery Museum.",
	zht = "他往瓷器館那裡走了。",
}
LocalizationConfig["loc_story_msg_317"] =
{
	zh = "咕咕，我们快追！",
	en = "Salem, quick, let's chase him!",
	zht = "咕咕，我們快追！",
}
LocalizationConfig["loc_story_msg_318"] =
{
	zh = "你们这些怪物，快把我弟弟交出来！",
	en = "Damn monsters, give me my brother back now!",
	zht = "你們這些怪物，快把我弟弟交出來！",
}
LocalizationConfig["loc_story_msg_319"] =
{
	zh = "冷静一点，我们不是复活的藏品。",
	en = "Calm down, we're not living museum pieces.",
	zht = "冷靜一點，我們不是復活的藏品。",
}
LocalizationConfig["loc_story_msg_320"] =
{
	zh = "真的吗？",
	en = "Really?",
	zht = "真的嗎？",
}
LocalizationConfig["loc_story_msg_321"] =
{
	zh = "看你的样子……莫非，你是浣熊三兄弟中的一人？",
	en = "From the looks of you……I'd say, could you be one of the three raccoon brothers?",
	zht = "看你的樣子……莫非，你是浣熊三兄弟中的一人？",
}
LocalizationConfig["loc_story_msg_322"] =
{
	zh = "你怎么知道？",
	en = "How do you know?",
	zht = "你怎麼知道？",
}
LocalizationConfig["loc_story_msg_323"] =
{
	zh = "我们在水族馆遇到浣熊小弟了。",
	en = "We ran into Lil Raccy in the Sea Museum.",
	zht = "我們在水族館遇到浣熊小弟了。",
}
LocalizationConfig["loc_story_msg_324"] =
{
	zh = "原来弟弟在那里！我还以为走散后，它被怪物抓了。",
	en = "So that's where my brother is! I thought he had been captured by monsters after he left me.",
	zht = "原來弟弟在那裡！我還以為走散後，它被怪物抓了。",
}
LocalizationConfig["loc_story_msg_325"] =
{
	zh = "你在这里有见到一个白衣男子吗？",
	en = "Have you seen a man in white around here?",
	zht = "你在這裡有見到一個白衣男子嗎？",
}
LocalizationConfig["loc_story_msg_326"] =
{
	zh = "嗯嗯，我看到他往画廊走了。",
	en = "Yeah, I saw him head towards the Art Gallery.",
	zht = "嗯嗯，我看到他往畫廊走了。",
}
LocalizationConfig["loc_story_msg_327"] =
{
	zh = "这次，他要复活画中人吗？",
	en = "Does he want to bring the people in the paintings to life this time?",
	zht = "這次，他要復活畫中人嗎？",
}
LocalizationConfig["loc_story_msg_328"] =
{
	zh = "你们是来追那个白衣男子的吗？",
	en = "Are you chasing the man in white?",
	zht = "你們是來追那個白衣男子的嗎？",
}
LocalizationConfig["loc_story_msg_329"] =
{
	zh = "看你顶着画框的样子，应该是被他复活的藏品？",
	en = "Judging from the frame around you, I'm guessing you're one of the exhibition pieces he brought to life?",
	zht = "看你頂著畫框的樣子，應該是被他復活的藏品？",
}
LocalizationConfig["loc_story_msg_330"] =
{
	zh = "没错。",
	en = "That's right.",
	zht = "沒錯。",
}
LocalizationConfig["loc_story_msg_331"] =
{
	zh = "你原因告诉我们他的下落？",
	en = "Can you tell us where he went?",
	zht = "你原因告訴我們他的下落？",
}
LocalizationConfig["loc_story_msg_332"] =
{
	zh = "可以，只要你帮我个忙。",
	en = "Of course, as long as you help me out.",
	zht = "可以，只要你幫我個忙。",
}
LocalizationConfig["loc_story_msg_333"] =
{
	zh = "什么忙？",
	en = "What kind of help do you need?",
	zht = "什麼忙？",
}
LocalizationConfig["loc_story_msg_334"] =
{
	zh = "人们称我为微笑女神，就在于我笑容迷人。但复活后，我发现无法重现微笑的模样。",
	en = "People call me the smiling lady because of my captivating smile, but ever since being brought to life I'm not able to recreate that smile.",
	zht = "人們稱我為微笑女神，就在於我笑容迷人。但復活後，我發現無法重現微笑的模樣。",
}
LocalizationConfig["loc_story_msg_335"] =
{
	zh = "笑得太多，就变成傻笑女神，笑得太少，就变成冷笑女神，笑得不够真心，就变成假笑女神……",
	en = "If I smile too much, I'll turn into the lady with the airheaded smile, if I smile too little, I'll turn into the sneering lady, if I don't smile don't smile genuinely enough, I'll turn into the fake-smiling lady……",
	zht = "笑得太多，就變成傻笑女神，笑得太少，就變成冷笑女神，笑得不夠真心，就變成假笑女神……",
}
LocalizationConfig["loc_story_msg_336"] =
{
	zh = "所以，你想找回先前微笑的感觉？",
	en = "So you want to get back the same feeling of the smile you had before?",
	zht = "所以，你想找回先前微笑的感覺？",
}
LocalizationConfig["loc_story_msg_337"] =
{
	zh = "对！你们可以帮帮我吗？笑到什么程度才算是迷人的微笑？",
	en = "That's right! Can you help me? What sort of smile is a truly enchanting one?",
	zht = "對！你們可以幫幫我嗎？笑到什麼程度才算是迷人的微笑？",
}
LocalizationConfig["loc_story_msg_338"] =
{
	zh = "我们可以帮你确认，你一点点调整笑容，总会有个合适的程度。",
	en = "We can help you decide, slowly adjust your smile, there's gotta be just the right one, I'm sure.",
	zht = "我們可以幫你確認，你一點點調整笑容，總會有個合適的程度。",
}
LocalizationConfig["loc_story_msg_339"] =
{
	zh = "真的吗？那我们现在可以开始吗？",
	en = "Really? Can we start now then?",
	zht = "真的嗎？那我們現在可以開始嗎？",
}
LocalizationConfig["loc_story_msg_340"] =
{
	zh = "来吧。",
	en = "Let's go.",
	zht = "來吧。",
}
LocalizationConfig["loc_story_msg_341"] =
{
	zh = "嘿嘿嘿……",
	en = "Hee-hee hee……",
	zht = "嘿嘿嘿……",
}
LocalizationConfig["loc_story_msg_342"] =
{
	zh = "不行，太过奸诈了！",
	en = "That's not right, too wicked!",
	zht = "不行，太過奸詐了！",
}
LocalizationConfig["loc_story_msg_343"] =
{
	zh = "呵呵呵……",
	en = "Ah ah ah……",
	zht = "呵呵呵……",
}
LocalizationConfig["loc_story_msg_344"] =
{
	zh = "不行，太过冷淡了！",
	en = "That's not it, too cold!",
	zht = "不行，太過冷淡了！",
}
LocalizationConfig["loc_story_msg_345"] =
{
	zh = "哈哈哈……",
	en = "Hahaha……",
	zht = "哈哈哈……",
}
LocalizationConfig["loc_story_msg_346"] =
{
	zh = "不行，太过豪放了！",
	en = "That's not it either, too over-the-top",
	zht = "不行，太過豪放了！",
}
LocalizationConfig["loc_story_msg_347"] =
{
	zh = "……",
	en = "……",
	zht = "……",
}
LocalizationConfig["loc_story_msg_348"] =
{
	zh = "住手，你的阴谋到此为止了！",
	en = "Stop right there, your scheming will stop right now!",
	zht = "住手，你的陰謀到此為止了！",
}
LocalizationConfig["loc_story_msg_349"] =
{
	zh = "阴谋？",
	en = "My scheming?",
	zht = "陰謀？",
}
LocalizationConfig["loc_story_msg_350"] =
{
	zh = "没错，你妄想借助复活的藏品来统治这个星球的阴谋是不会得逞的！",
	en = "That's right, your delusion of wanting to rule this planet with the collection pieces you have brought to life won't succeed!",
	zht = "沒錯，你妄想借助復活的藏品來統治這個星球的陰謀是不會得逞的！",
}
LocalizationConfig["loc_story_msg_351"] =
{
	zh = "统治星球？",
	en = "Rule the planet?",
	zht = "統治星球？",
}
LocalizationConfig["loc_story_msg_352"] =
{
	zh = "难道不是吗？",
	en = "Isn't that your plan?",
	zht = "難道不是嗎？",
}
LocalizationConfig["loc_story_msg_353"] =
{
	zh = "你们不要乱扣帽子。我只是个关心这个博物馆的魔术师，并没有什么阴谋。",
	en = "You shouldn't jump to conclusions. I'm just a magician that cares for this museum, I'm not plotting anything.",
	zht = "你們不要亂扣帽子。我只是個關心這個博物館的魔術師，並沒有什麼陰謀。",
}
LocalizationConfig["loc_story_msg_354"] =
{
	zh = "那你为什么要复活这些藏品？",
	en = "Then why do you want to bring all these museum pieces to life?",
	zht = "那你為什麼要復活這些藏品？",
}
LocalizationConfig["loc_story_msg_355"] =
{
	zh = "这个博物馆年代久远，而且藏品并不是很多，所以人气大不如前。",
	en = "This museum is old and it doesn't have many exhibition pieces, so its popularity has waned.",
	zht = "這個博物館年代久遠，而且藏品並不是很多，所以人氣大不如前。",
}
LocalizationConfig["loc_story_msg_356"] =
{
	zh = "我就想，如果这些藏品都能动，讲述自己的故事，会不会吸引游客前来，所以……",
	en = "I just wondered whether it would attract more customers if these pieces could move themselves and tell people their stories, so……",
	zht = "我就想，如果這些藏品都能動，講述自己的故事，會不會吸引遊客前來，所以……",
}
LocalizationConfig["loc_story_msg_357"] =
{
	zh = "可是，你只是个魔术师，怎么会这种能力？",
	en = "But, you're just a magician, how are you able to do this?",
	zht = "可是，你只是個魔術師，怎麼會這種能力？",
}
LocalizationConfig["loc_story_msg_358"] =
{
	zh = "这是我的小秘密，我其实是个冒牌魔术师。",
	en = "It's my little secret, I'm actually just a phony magician.",
	zht = "這是我的小秘密，我其實是個冒牌魔術師。",
}
LocalizationConfig["loc_story_msg_359"] =
{
	zh = "冒牌？",
	en = "Phony?",
	zht = "冒牌？",
}
LocalizationConfig["loc_story_msg_360"] =
{
	zh = "没错，但是我有特殊能力。比如，我是真的把人切成两半，然后再复活……",
	en = "That's right, but I have special abilities. For example, I can really cut people in two, and then bring them back to life……",
	zht = "沒錯，但是我有特殊能力。比如，我是真的把人切成兩半，然後再復活……",
}
LocalizationConfig["loc_story_msg_361"] =
{
	zh = "听起来是个恐怖故事。",
	en = "Sounds like a terrifying story.",
	zht = "聽起來是個恐怖故事。",
}
LocalizationConfig["loc_story_msg_362"] =
{
	zh = "如果不相信的话，我可以表演下。你可以帮我一起完成吗？",
	en = "If you don't believe me I can perform for you. Can you help me out?",
	zht = "如果不相信的話，我可以表演下。你可以幫我一起完成嗎？",
}
LocalizationConfig["loc_story_msg_363"] =
{
	zh = "够了够了，我们相信！",
	en = "Enough then, I believe you.",
	zht = "夠了夠了，我們相信！",
}
LocalizationConfig["loc_story_msg_364"] =
{
	zh = "没想到背后的原因竟然是这样……",
	en = "I wouldn't have expected his motive to be this…",
	zht = "沒想到背後的原因竟然是這樣……",
}
LocalizationConfig["loc_story_msg_365"] =
{
	zh = "哇塞，呜呜，没想到你这么能赚钱啊，有什么秘诀吗",
	en = "Wow, Count Mews, I didn't know you were so good at earning money, what's your secret?",
	zht = "哇塞，嗚嗚，沒想到你這麼能賺錢啊，有什麼秘訣嗎",
}
LocalizationConfig["loc_story_msg_366"] =
{
	zh = "就是点一下，点一下，点一下，然后睡觉",
	en = "You just tap, tap, tap and then sleep.",
	zht = "就是點一下，點一下，點一下，然後睡覺",
}
LocalizationConfig["loc_story_msg_367"] =
{
	zh = "哎呀你不告诉我就不告诉我，骗我点两下什么意思，这点钱也就还点利息吧",
	en = "If you don't wanna tell me then don't tell me, what's the point in tricking me into tapping it, this small amount of money ca just help me pay back a little interest",
	zht = "哎呀你不告訴我就不告訴我，騙我點兩下什麼意思，這點錢也就還點利息吧",
}
LocalizationConfig["loc_story_msg_368"] =
{
	zh = "这样，你去下个星球发现点更加好的东西吧，这样还债的效率也会提高",
	en = "How about this, find something a little better on the next planet, it will increase your debt repayments",
	zht = "這樣，你去下個星球發現點更加好的東西吧，這樣還債的效率也會提高",
}
LocalizationConfig["loc_story_msg_369"] =
{
	zh = "哎，为什么这个星球没什么值钱花瓶之类的东西",
	en = "Sigh, why aren't there any expensive vases and the like on this planet?",
	zht = "哎，為什麼這個星球沒什麼值錢花瓶之類的東西",
}
LocalizationConfig["loc_story_msg_370"] =
{
	zh = "听说这个星球叫做悬疑星，真是满满的严肃气氛，真想参与个大案子~",
	en = "This planet's called Suspense Planet, it really does have an overwhelmingly tense atmosphere, I'd love to take part in a big case",
	zht = "聽說這個星球叫做懸疑星，真是滿滿的嚴肅氣氛，真想參與個大案子~",
}
LocalizationConfig["loc_story_msg_371"] =
{
	zh = "说什么傻话，万一被卷进奇怪的事件中，我们反而可能会被误认为是凶手。",
	en = "What are you talking about? If we're dragged into some kind of strange series of events, we might be mistaken for the culprits.",
	zht = "說什麼傻話，萬一被捲進奇怪的事件中，我們反而可能會被誤認為是兇手。",
}
LocalizationConfig["loc_story_msg_372"] =
{
	zh = "不要这么凶，我就是想想……",
	en = "Now now, there's no need to be so angry, I was just supposing……",
	zht = "不要這麼凶，我就是想想……",
}
LocalizationConfig["loc_story_msg_373"] =
{
	zh = "等等，那边天台上好像有三个人在缠斗！看样子要出事，我们快去看看吧。",
	en = "Wait, there seems to be three people shaking on that rooftop! It looks like something might go wrong, let's go and take a look.",
	zht = "等等，那邊天臺上好像有三個人在纏鬥！看樣子要出事，我們快去看看吧。",
}
LocalizationConfig["loc_story_msg_374"] =
{
	zh = "这人怎么胸前插着刀躺在血泊中？看样子奄奄一息了……",
	en = "Why is there a person lying in a pool of blood with a knife in his chest? It looks like he's taking his last few breaths……",
	zht = "這人怎麼胸前插著刀躺在血泊中？看樣子奄奄一息了……",
}
LocalizationConfig["loc_story_msg_375"] =
{
	zh = "没猜错的话，应该是被人捅刀后从天台上推了下来。",
	en = "If I were to guess, it looks like he was pushed off the rooftop after being stabbed with the knife.",
	zht = "沒猜錯的話，應該是被人捅刀後從天臺上推了下來。",
}
LocalizationConfig["loc_story_msg_376"] =
{
	zh = "你们在这里干什么？",
	en = "What are you doing here?",
	zht = "你們在這裡幹什麼？",
}
LocalizationConfig["loc_story_msg_377"] =
{
	zh = "我们……",
	en = "We're……",
	zht = "我們……",
}
LocalizationConfig["loc_story_msg_378"] =
{
	zh = "这！你们竟然捅伤别人！",
	en = "Here! You dare to stab another person!",
	zht = "這！你們竟然捅傷別人！",
}
LocalizationConfig["loc_story_msg_379"] =
{
	zh = "警官，你听我们解释，我们不是凶手。",
	en = "Please let us explain officer, we aren't the culprits.",
	zht = "警官，你聽我們解釋，我們不是兇手。",
}
LocalizationConfig["loc_story_msg_380"] =
{
	zh = "一般案发现场的第一发现者大多是凶手，而且凶手也喜欢回到案发现场。",
	en = "The first one at the scene of the crime is usually the culprit and culprits like to return to the scene of the crime.",
	zht = "一般案發現場的第一發現者大多是兇手，而且兇手也喜歡回到案發現場。",
}
LocalizationConfig["loc_story_msg_381"] =
{
	zh = "你们外貌可疑，怎么看也不像这个星球的居民，还是先跟我回去一趟警局再说吧。",
	en = "You all look suspicious and you don't look like you're from this planet, you best come back to the police station with me first.",
	zht = "你們外貌可疑，怎麼看也不像這個星球的居民，還是先跟我回去一趟警局再說吧。",
}
LocalizationConfig["loc_story_msg_382"] =
{
	zh = "没想到这回真的参与了一个大案子……",
	en = "I didn't think that we would actually be part of a big investigation……",
	zht = "沒想到這回真的參與了一個大案子……",
}
LocalizationConfig["loc_story_msg_383"] =
{
	zh = "别说了，呜呜，我们快跑。",
	en = "Don't mention it, let's get out of here Count Mews.",
	zht = "別說了，嗚嗚，我們快跑。",
}
LocalizationConfig["loc_story_msg_384"] =
{
	zh = "居然还跑，你们果然是凶手，给我站住！",
	en = "You're running away? You really rare the culprits, stop right there!",
	zht = "居然還跑，你們果然是兇手，給我站住！",
}
LocalizationConfig["loc_story_msg_385"] =
{
	zh = "咕咕，我们不是凶手，为什么要跑？",
	en = "Salem, we aren't the culprits, why are we running?",
	zht = "咕咕，我們不是兇手，為什麼要跑？",
}
LocalizationConfig["loc_story_msg_386"] =
{
	zh = "周围没有人证，一旦进了警局，想要洗脱嫌疑会非常费劲。",
	en = "There aren't any witnesses around, as soon as we enter the police station, it will be really hard for us to clear our names as suspects.",
	zht = "周圍沒有人證，一旦進了警局，想要洗脫嫌疑會非常費勁。",
}
LocalizationConfig["loc_story_msg_387"] =
{
	zh = "那现在怎么办？",
	en = "Then what should we do now?",
	zht = "那現在怎麼辦？",
}
LocalizationConfig["loc_story_msg_388"] =
{
	zh = "我听大管家说，这个星球有很多的侦探，不如先找侦探帮我们破案。",
	en = "I heard the High Steward say that there are loads of detectives on this planet, we might as well go and find a detective who can help us solve this case.",
	zht = "我聽大管家說，這個星球有很多的偵探，不如先找偵探幫我們破案。",
}
LocalizationConfig["loc_story_msg_389"] =
{
	zh = "好主意！",
	en = "Good idea!",
	zht = "好主意！",
}
LocalizationConfig["loc_story_msg_390"] =
{
	zh = "这里不是侦探所，而是家医院……",
	en = "This isn't a detective agency, it's a hospital……",
	zht = "這裡不是偵探所，而是家醫院……",
}
LocalizationConfig["loc_story_msg_391"] =
{
	zh = "大管家的消息应该没错，我们进去看看先。",
	en = "The High Steward's information probably isn't wrong, let's go inside and take a look first.",
	zht = "大管家的消息應該沒錯，我們進去看看先。",
}
LocalizationConfig["loc_story_msg_392"] =
{
	zh = "请问，你们是来看什么病的？",
	en = "Excuse me, are you here to see a doctor?",
	zht = "請問，你們是來看什麼病的？",
}
LocalizationConfig["loc_story_msg_393"] =
{
	zh = "我们想找侦探。",
	en = "We're looking for a detective.",
	zht = "我們想找偵探。",
}
LocalizationConfig["loc_story_msg_394"] =
{
	zh = "真不巧，侦探外出了，我是侦探助手，有什么可以帮你的吗？",
	en = "How very unfortunate, Holmees is not here, I'm his assistant, is there anything I can help you with?",
	zht = "真不巧，偵探外出了，我是偵探助手，有什麼可以幫你的嗎？",
}
LocalizationConfig["loc_story_msg_395"] =
{
	zh = "你不是医生吗？",
	en = "Aren't you a doctor?",
	zht = "你不是醫生嗎？",
}
LocalizationConfig["loc_story_msg_396"] =
{
	zh = "医生是我的本职工作，出于兴趣，我的副业是侦探助手。",
	en = "My main job is as a doctor, but out of interest I also work a second job as the detective's assistant.",
	zht = "醫生是我的本職工作，出於興趣，我的副業是偵探助手。",
}
LocalizationConfig["loc_story_msg_397"] =
{
	zh = "好吧，我们想请你帮忙破案，案件是这样这样……",
	en = "OK then, we would like you to help us solve a case, it's like this…",
	zht = "好吧，我們想請你幫忙破案，案件是這樣這樣……",
}
LocalizationConfig["loc_story_msg_398"] =
{
	zh = "听起来很麻烦啊，我这边因为有病人也走不开，建议你们去找找倒霉蛋。",
	en = "Sounds like a great deal of trouble, I'm afraid I also have patients to attend to, so I'm unable to leave here. I suggest you find Poor Guy.",
	zht = "聽起來很麻煩啊，我這邊因為有病人也走不開，建議你們去找找倒楣蛋。",
}
LocalizationConfig["loc_story_msg_399"] =
{
	zh = "他是个有名的大侦探吗？",
	en = "Is he a famous detective?",
	zht = "他是個有名的大偵探嗎？",
}
LocalizationConfig["loc_story_msg_400"] =
{
	zh = "喂喂喂，听名字也知道是个很不靠谱的人吧……",
	en = "Hey hey hey, from his name you can tell he's not a very reliable sort of chap……",
	zht = "喂喂喂，聽名字也知道是個很不靠譜的人吧……",
}
LocalizationConfig["loc_story_msg_401"] =
{
	zh = "这个人虽然运气差，不过情报多，你们去问问吧。",
	en = "He may not have the best of luck, but he has lots of intel. You can go and ask him.",
	zht = "這個人雖然運氣差，不過情報多，你們去問問吧。",
}
LocalizationConfig["loc_story_msg_402"] =
{
	zh = "那我们去碰碰这个运气吧。",
	en = "Let's try our luck then, I guess.",
	zht = "那我們去碰碰這個運氣吧。",
}
LocalizationConfig["loc_story_msg_403"] =
{
	zh = "你们是侦探助手介绍来的？说吧，找我有什么事。",
	en = "Were you sent by the detective's assistant? Tell me then, what do you want?",
	zht = "你們是偵探助手介紹來的？說吧，找我有什麼事。",
}
LocalizationConfig["loc_story_msg_404"] =
{
	zh = "今天的案子你听说了吗？有个人男人被人捅刀后从天台掉了下来。",
	en = "Have you heard about the case today? A man fell off a rooftop after being stabbed.",
	zht = "今天的案子你聽說了嗎？有個人男人被人捅刀後從天臺掉了下來。",
}
LocalizationConfig["loc_story_msg_405"] =
{
	zh = "听说了听说了，凶器似乎是把水果刀。据说凶器被法医保管。",
	en = "Yes, I've heard, the murder weapon seems to have been a fruit knife. I've heard that Horatio the crime scene investigator is taking care of the weapon.",
	zht = "聽說了聽說了，兇器似乎是把水果刀。據說兇器被法醫保管。",
}
LocalizationConfig["loc_story_msg_406"] =
{
	zh = "刚好我这里就有一把，你摸摸看。",
	en = "Luckily I have one here, take it and have a look.",
	zht = "剛好我這裡就有一把，你摸摸看。",
}
LocalizationConfig["loc_story_msg_407"] =
{
	zh = "哇哦，果然是把好锋利的水果刀。",
	en = "Wow, just as I thought, this is a really sharp fruit knife.",
	zht = "哇哦，果然是把好鋒利的水果刀。",
}
LocalizationConfig["loc_story_msg_408"] =
{
	zh = "如果找到法医，说不定能凭指纹找到凶手。",
	en = "If you can find Horatio, you might be able to find the murderer from the fingerprints.",
	zht = "如果找到法醫，說不定能憑指紋找到兇手。",
}
LocalizationConfig["loc_story_msg_409"] =
{
	zh = "那你知道法医在哪里吗？",
	en = "Then do you know where he is?",
	zht = "那你知道法醫在哪裡嗎？",
}
LocalizationConfig["loc_story_msg_410"] =
{
	zh = "我经常去，他的地址是……",
	en = "I often go see him, his address is……",
	zht = "我經常去，他的地址是……",
}
LocalizationConfig["loc_story_msg_411"] =
{
	zh = "你是法医？",
	en = "Are you Horatio?",
	zht = "你是法醫？",
}
LocalizationConfig["loc_story_msg_412"] =
{
	zh = "你们找我有事？",
	en = "What can I do for you?",
	zht = "你們找我有事？",
}
LocalizationConfig["loc_story_msg_413"] =
{
	zh = "这个乌鸦头的面具真是好恐怖……",
	en = "That raven mask is really terrifying……",
	zht = "這個烏鴉頭的面具真是好恐怖……",
}
LocalizationConfig["loc_story_msg_414"] =
{
	zh = "说正事！",
	en = "It really is!",
	zht = "說正事！",
}
LocalizationConfig["loc_story_msg_415"] =
{
	zh = "咳咳，我们想问问，今天发生的凶杀案的凶器上，有指纹吗？",
	en = "Cough cough, we'd like to ask you if there were fingerprints on the weapon used for today's murder?",
	zht = "咳咳，我們想問問，今天發生的兇殺案的兇器上，有指紋嗎？",
}
LocalizationConfig["loc_story_msg_416"] =
{
	zh = "有啊，目前已经通过大星球联盟指纹库锁定了凶手。",
	en = "There were, we've already found the murderer through matching it with the Planetary Alliance Fingerprint Database.",
	zht = "有啊，目前已經通過大星球聯盟指紋庫鎖定了兇手。",
}
LocalizationConfig["loc_story_msg_417"] =
{
	zh = "凶手是谁？",
	en = "Who was it?",
	zht = "兇手是誰？",
}
LocalizationConfig["loc_story_msg_418"] =
{
	zh = "我看看啊，名字是……猫咪星球的——呜呜！",
	en = "Let's see, the name is……Kitty Cat Planet's……Count Mews!",
	zht = "我看看啊，名字是……貓咪星球的——嗚嗚！",
}
LocalizationConfig["loc_story_msg_419"] =
{
	zh = "！",
	en = "!",
	zht = "！",
}
LocalizationConfig["loc_story_msg_420"] =
{
	zh = "！",
	en = "!",
	zht = "！",
}
LocalizationConfig["loc_story_msg_421"] =
{
	zh = "说起来，你长得和他还真是很像呢。",
	en = "Speaking of which, you really do look a lot like him.",
	zht = "說起來，你長得和他還真是很像呢。",
}
LocalizationConfig["loc_story_msg_422"] =
{
	zh = "错……错觉……",
	en = "You're……mistaken……",
	zht = "錯……錯覺……",
}
LocalizationConfig["loc_story_msg_423"] =
{
	zh = "对对对，一定是巧合。哈哈，我们还有事，就先走了。",
	en = "Yeah that's right, it must just be a coincidence. Haha, we' have some stuff to do, we'll be on our way now.",
	zht = "對對對，一定是巧合。哈哈，我們還有事，就先走了。",
}
LocalizationConfig["loc_story_msg_424"] =
{
	zh = "咕咕，凶器上有我的指纹，怎么办？",
	en = "Salem, my fingerprints are on the murder weapon, what should we do?",
	zht = "咕咕，兇器上有我的指紋，怎麼辦？",
}
LocalizationConfig["loc_story_msg_425"] =
{
	zh = "不要急，我收到消息，大侦探已经回来了，我们去找他帮帮忙吧。",
	en = "Don't worry, I've received a message, Holmees has returned already, let's see if he can help us.",
	zht = "不要急，我收到消息，大偵探已經回來了，我們去找他幫幫忙吧。",
}
LocalizationConfig["loc_story_msg_426"] =
{
	zh = "你们的事情，我听助手说了。",
	en = "My assistant told me all about your problem.",
	zht = "你們的事情，我聽助手說了。",
}
LocalizationConfig["loc_story_msg_427"] =
{
	zh = "现在更麻烦了，我们去法医那里，发现凶器上有我的指纹。",
	en = "It's even worse now, we went to Horatio and discovered that the murder weapon has my finger prints on it.",
	zht = "現在更麻煩了，我們去法醫那裡，發現兇器上有我的指紋。",
}
LocalizationConfig["loc_story_msg_428"] =
{
	zh = "！",
	en = "!",
	zht = "！",
}
LocalizationConfig["loc_story_msg_429"] =
{
	zh = "如果是这样子的话……",
	en = "Well if that is the case……",
	zht = "如果是這樣子的話……",
}
LocalizationConfig["loc_story_msg_430"] =
{
	zh = "会怎样？",
	en = "What?",
	zht = "會怎樣？",
}
LocalizationConfig["loc_story_msg_431"] =
{
	zh = "凶手就是你们没跑了！",
	en = "The murderer must be you!",
	zht = "兇手就是你們沒跑了！",
}
LocalizationConfig["loc_story_msg_432"] =
{
	zh = "呜呜真的要开始呜呜了……",
	en = "Count Mews, are we really gonna start this? Mew mew……",
	zht = "嗚嗚真的要開始嗚嗚了……",
}
LocalizationConfig["loc_story_msg_433"] =
{
	zh = "侦探先生，我们真的不是凶手，不然也不会费大力气来找你了。",
	en = "Mr.Holmees, we really aren't the murderers, otherwise we wouldn't spend so much effort finding you.",
	zht = "偵探先生，我們真的不是兇手，不然也不會費大力氣來找你了。",
}
LocalizationConfig["loc_story_msg_434"] =
{
	zh = "这案件确实棘手，如果连我都没头绪的话……",
	en = "This really is a prickly case, if not even I have any leads……",
	zht = "這案件確實棘手，如果連我都沒頭緒的話……",
}
LocalizationConfig["loc_story_msg_435"] =
{
	zh = "怎么办？",
	en = "What should we do?",
	zht = "怎麼辦？",
}
LocalizationConfig["loc_story_msg_436"] =
{
	zh = "我带你们去找我哥哥吧，虽然不服气，但他是这个星球最聪明的人，他或许能帮你们。",
	en = "I'll take you to see my older brother, he may be a bit of a maverick by he is the smartest person on this planet, he might be able to help you.",
	zht = "我帶你們去找我哥哥吧，雖然不服氣，但他是這個星球最聰明的人，他或許能幫你們。",
}
LocalizationConfig["loc_story_msg_437"] =
{
	zh = "嗡嗡嗡……嗡嗡嗡……嗡嗡嗡……",
	en = "Bzzzz……bzzzz……bzzzzz……",
	zht = "嗡嗡嗡……嗡嗡嗡……嗡嗡嗡……",
}
LocalizationConfig["loc_story_msg_438"] =
{
	zh = "他到底在说什么？",
	en = "What the hell is he talking about?",
	zht = "他到底在說什麼？",
}
LocalizationConfig["loc_story_msg_439"] =
{
	zh = "哎，我哥哥过于理性，已经完全将自己变成了机器人。",
	en = "Sigh, my brother is too eccentric, he's completely turned himself into a robot.",
	zht = "哎，我哥哥過於理性，已經完全將自己變成了機器人。",
}
LocalizationConfig["loc_story_msg_440"] =
{
	zh = "难道就没人能听懂他说的话？",
	en = "Is no one able to understand what he says?",
	zht = "難道就沒人能聽懂他說的話？",
}
LocalizationConfig["loc_story_msg_441"] =
{
	zh = "他现在的话语都是以电磁波的方式，通过天线传向对方。",
	en = "He's speaking through electromagnetic waves that are transmitted to the aerial of whoever he is speaking to.",
	zht = "他現在的話語都是以電磁波的方式，通過天線傳向對方。",
}
LocalizationConfig["loc_story_msg_442"] =
{
	zh = "意思是？",
	en = "That means……",
	zht = "意思是？",
}
LocalizationConfig["loc_story_msg_443"] =
{
	zh = "意思就是——你们没有天线，这个问题就没法和你们解释了。",
	en = "What that means is that you don't have an aerial. I'm not able to give you a full explanation of this problem.",
	zht = "意思就是——你們沒有天線，這個問題就沒法和你們解釋了。",
}
LocalizationConfig["loc_story_msg_444"] =
{
	zh = "那我就洗脱不了嫌疑了？",
	en = "Then won't I be able to clear my name?",
	zht = "那我就洗脫不了嫌疑了？",
}
LocalizationConfig["loc_story_msg_445"] =
{
	zh = "还有一个办法。",
	en = "I have one more idea.",
	zht = "還有一個辦法。",
}
LocalizationConfig["loc_story_msg_446"] =
{
	zh = "是什么？",
	en = "What is it?",
	zht = "是什麼？",
}
LocalizationConfig["loc_story_msg_447"] =
{
	zh = "这个星球上有个奇怪的小学生，他有种特殊的超能力，每次案发都会在现场出现。",
	en = "There's a strange elementary student on this planet, he has a special superpower, he always appears at the scene of every crime.",
	zht = "這個星球上有個奇怪的小學生，他有種特殊的超能力，每次案發都會在現場出現。",
}
LocalizationConfig["loc_story_msg_448"] =
{
	zh = "听上去真是种特别没用、特别倒霉的超能力……",
	en = "It sounds like a truly useless, horrible superpower……",
	zht = "聽上去真是種特別沒用、特別倒楣的超能力……",
}
LocalizationConfig["loc_story_msg_449"] =
{
	zh = "这么说，他有可能看到了凶手的样貌？",
	en = "That means that he might have seen what the real murderer looks like?",
	zht = "這麼說，他有可能看到了兇手的樣貌？",
}
LocalizationConfig["loc_story_msg_450"] =
{
	zh = "没错！",
	en = "That's right!",
	zht = "沒錯！",
}
LocalizationConfig["loc_story_msg_451"] =
{
	zh = "我确实在现场，也知道凶手是谁。",
	en = "I was in fact at the scene and I know who the murderer is.",
	zht = "我確實在現場，也知道兇手是誰。",
}
LocalizationConfig["loc_story_msg_452"] =
{
	zh = "凶手是谁？",
	en = "Who is it?",
	zht = "兇手是誰？",
}
LocalizationConfig["loc_story_msg_453"] =
{
	zh = "凶手是黑影人，他可以附身在其他人身上，你们永远没办法抓住他。",
	en = "The murderer is a mysterious person who can possess other people, you're never going to catch him.",
	zht = "兇手是黑影人，他可以附身在其他人身上，你們永遠沒辦法抓住他。",
}
LocalizationConfig["loc_story_msg_454"] =
{
	zh = "只要能找到他，一定有办法抓住他的。",
	en = "As long as we can find him, there must be a way to catch him.",
	zht = "只要能找到他，一定有辦法抓住他的。",
}
LocalizationConfig["loc_story_msg_455"] =
{
	zh = "这个星球上的案子大多是他干的，我可以利用自己的能力帮你们找到他。",
	en = "Most of the cases on this planet were committed by him, I can use my power to help you find him.",
	zht = "這個星球上的案子大多是他幹的，我可以利用自己的能力幫你們找到他。",
}
LocalizationConfig["loc_story_msg_456"] =
{
	zh = "之后，就看你们自己的了。",
	en = "The rest is up to you.",
	zht = "之後，就看你們自己的了。",
}
LocalizationConfig["loc_story_msg_457"] =
{
	zh = "我们一定可以抓住这个坏蛋的！",
	en = "We'll catch this guy!",
	zht = "我們一定可以抓住這個壞蛋的！",
}
LocalizationConfig["loc_story_msg_458"] =
{
	zh = "这里是楼顶天台，前面有个人影，我们过去看看吧。",
	en = "This is the rooftop, there's someone over there, let's go take a look.",
	zht = "這裡是樓頂天臺，前面有個人影，我們過去看看吧。",
}
LocalizationConfig["loc_story_msg_459"] =
{
	zh = "你就是那个作案无数的黑影人吧？",
	en = "Are you that mysterious person who has all those cases?",
	zht = "你就是那個作案無數的黑影人吧？",
}
LocalizationConfig["loc_story_msg_460"] =
{
	zh = "没错，你们又来了。",
	en = "That's right, you're back again.",
	zht = "沒錯，你們又來了。",
}
LocalizationConfig["loc_story_msg_461"] =
{
	zh = "听你的话，好像我们之前已经来过了。",
	en = "You say it as though we've been here before.",
	zht = "聽你的話，好像我們之前已經來過了。",
}
LocalizationConfig["loc_story_msg_462"] =
{
	zh = "一会儿你就会明白。",
	en = "You'll understand soon.",
	zht = "一會兒你就會明白。",
}
LocalizationConfig["loc_story_msg_463"] =
{
	zh = "你这个坏蛋，快点认罪，好洗脱我的嫌疑！",
	en = "You scumbag, admit to your crime and let me clear my name!",
	zht = "你這個壞蛋，快點認罪，好洗脫我的嫌疑！",
}
LocalizationConfig["loc_story_msg_464"] =
{
	zh = "那把刀上面确实有你的指纹，并非我伪造的。",
	en = "Your fingerprints were found on the knife, I didn't forge them.",
	zht = "那把刀上面確實有你的指紋，並非我偽造的。",
}
LocalizationConfig["loc_story_msg_465"] =
{
	zh = "不可能！",
	en = "Impossible!",
	zht = "不可能！",
}
LocalizationConfig["loc_story_msg_466"] =
{
	zh = "你的目的是什么？",
	en = "What do you want?",
	zht = "你的目的是什麼？",
}
LocalizationConfig["loc_story_msg_467"] =
{
	zh = "制造一起完美犯罪，让这个星球的侦探谁也破不了案。",
	en = "Create the perfect crime that no detective on this planet will be able to solve.",
	zht = "製造一起完美犯罪，讓這個星球的偵探誰也破不了案。",
}
LocalizationConfig["loc_story_msg_468"] =
{
	zh = "为什么偏偏是我？",
	en = "But why me?",
	zht = "為什麼偏偏是我？",
}
LocalizationConfig["loc_story_msg_469"] =
{
	zh = "我并没有特别针对你，只能说，很不凑巧，你出现了。",
	en = "I don't have anything against you specifically, all I can say that your appearance here was very unfortunate.",
	zht = "我並沒有特別針對你，只能說，很不湊巧，你出現了。",
}
LocalizationConfig["loc_story_msg_470"] =
{
	zh = "如果我们向警局告发，迟早会水落石出的。",
	en = "If we tell this to the police station, they'll manage to get to the bottom of it sooner or later.",
	zht = "如果我們向警局告發，遲早會水落石出的。",
}
LocalizationConfig["loc_story_msg_471"] =
{
	zh = "所有人都知道我会附身，但很少有人知道我的另一个能力。",
	en = "Everyone knows that I can possess people, but very few people know about my other power.",
	zht = "所有人都知道我會附身，但很少有人知道我的另一個能力。",
}
LocalizationConfig["loc_story_msg_472"] =
{
	zh = "另一个能力？",
	en = "Other power?",
	zht = "另一個能力？",
}
LocalizationConfig["loc_story_msg_473"] =
{
	zh = "没错，就是时间连接。",
	en = "That's right, it's temporal connection.",
	zht = "沒錯，就是時間連接。",
}
LocalizationConfig["loc_story_msg_474"] =
{
	zh = "时间连接？",
	en = "Temporal connection?",
	zht = "時間連接？",
}
LocalizationConfig["loc_story_msg_475"] =
{
	zh = "我可以将一段时间首尾连接，除非离开这个星球，否则，所有人都会永远活在这段时间中。",
	en = "I can join the end of a period of time with the beginning of another, unless they leave this planet, everyone will be stuck in this period of time forever.",
	zht = "我可以將一段時間首尾連接，除非離開這個星球，否則，所有人都會永遠活在這段時間中。",
}
LocalizationConfig["loc_story_msg_476"] =
{
	zh = "哇哦！这么厉害？",
	en = "Woah! That's a great power!",
	zht = "哇哦！這麼厲害？",
}
LocalizationConfig["loc_story_msg_477"] =
{
	zh = "别犯傻崇拜他，他可是凶手啊！",
	en = "Don't stand there in awe of him, he's a murderer!",
	zht = "別犯傻崇拜他，他可是兇手啊！",
}
LocalizationConfig["loc_story_msg_478"] =
{
	zh = "你们都在这里干什么？快走开，我要打扫天台的卫生了。",
	en = "What are you all doing here? Get out of here now, I want to clean up this rooftop.",
	zht = "你們都在這裡幹什麼？快走開，我要打掃天臺的衛生了。",
}
LocalizationConfig["loc_story_msg_479"] =
{
	zh = "这人！不就是那个受害者吗？",
	en = "That's……! Are they the victim?",
	zht = "這人！不就是那個受害者嗎？",
}
LocalizationConfig["loc_story_msg_480"] =
{
	zh = "糟了！看来我们已经回到了先前的时间中了，如果不阻止这个大叔，案件又要重演了！",
	en = "Oh no! It looks like we're back at the beginning of the time period again, if we don't stop this man, it's going to happen again!",
	zht = "糟了！看來我們已經回到了先前的時間中了，如果不阻止這個大叔，案件又要重演了！",
}
LocalizationConfig["loc_story_msg_481"] =
{
	zh = "哈哈，你们别白费力气了。",
	en = "Haha, don't waste your efforts.",
	zht = "哈哈，你們別白費力氣了。",
}
LocalizationConfig["loc_story_msg_482"] =
{
	zh = "他消失了！",
	en = "He's disappeared!",
	zht = "他消失了！",
}
LocalizationConfig["loc_story_msg_483"] =
{
	zh = "一定是附身在大叔身上了，你看大叔掏出刀子了，快抓住他。",
	en = "He must have possessed that man, look he's pulled a knife out, catch him.",
	zht = "一定是附身在大叔身上了，你看大叔掏出刀子了，快抓住他。",
}
LocalizationConfig["loc_story_msg_484"] =
{
	zh = "都给我滚开！",
	en = "Get out the way!",
	zht = "都給我滾開！",
}
LocalizationConfig["loc_story_msg_485"] =
{
	zh = "大叔，冷静点！啊呀——",
	en = "Calm down sir! Ahhh……",
	zht = "大叔，冷靜點！啊呀——",
}
LocalizationConfig["loc_story_msg_486"] =
{
	zh = "呜哇——",
	en = "Uggh……",
	zht = "嗚哇——",
}
LocalizationConfig["loc_story_msg_487"] =
{
	zh = "呜呜，你怎么用刀捅了他？",
	en = "Count Mews, you stabbed him with a knife?",
	zht = "嗚嗚，你怎麼用刀捅了他？",
}
LocalizationConfig["loc_story_msg_488"] =
{
	zh = "我……我不是故意的……",
	en = "It……it wasn't on purpose.",
	zht = "我……我不是故意的……",
}
LocalizationConfig["loc_story_msg_489"] =
{
	zh = "他站不住了，要掉下去了，快抓……",
	en = "He can't stand up properly, he's about to fall, quickly catch……",
	zht = "他站不住了，要掉下去了，快抓……",
}
LocalizationConfig["loc_story_msg_490"] =
{
	zh = "他……他掉下去了……",
	en = "He……he fell……",
	zht = "他……他掉下去了……",
}
LocalizationConfig["loc_story_msg_491"] =
{
	zh = "糟糕，又没能拦住他！诶？我为什么要说又？",
	en = "Oh no, no one stopped him this time either! Huh? Why did I say “this time”?",
	zht = "糟糕，又沒能攔住他！誒？我為什麼要說又？",
}
LocalizationConfig["loc_story_msg_492"] =
{
	zh = "警车来了，我们快走！",
	en = "There's a police car, let's get out of here!",
	zht = "警車來了，我們快走！",
}
LocalizationConfig["loc_story_msg_493"] =
{
	zh = "可恶！难道这个星球的租金我们只能放弃吗？",
	en = "Dammit! Are we not going to be able to get this planet's rent?",
	zht = "可惡！難道這個星球的租金我們只能放棄嗎？",
}
LocalizationConfig["loc_story_msg_494"] =
{
	zh = "干的不错呀，花瓶的钱，大王说不用还了",
	en = "[未翻译]干的不错呀，花瓶的钱，大王说不用还了",
	zht = "幹的不錯呀，花瓶的錢，大王說不用還了",
}
LocalizationConfig["loc_story_msg_495"] =
{
	zh = "什么，那我们可以回家了吗",
	en = "[未翻译]什么，那我们可以回家了吗",
	zht = "什麼，那我們可以回家了嗎",
}
LocalizationConfig["loc_story_msg_496"] =
{
	zh = "当然不行啦，大王给你晋升了为了侯爵，你要管理这个妙奇星云",
	en = "[未翻译]当然不行啦，大王给你晋升了为了侯爵，你要管理这个妙奇星云",
	zht = "當然不行啦，大王給你晉升了為了侯爵，你要管理這個妙奇星雲",
}
LocalizationConfig["loc_story_msg_497"] =
{
	zh = "但是我想回家吃鱼干",
	en = "[未翻译]但是我想回家吃鱼干",
	zht = "但是我想回家吃魚幹",
}
LocalizationConfig["loc_story_msg_498"] =
{
	zh = "大王说了，好好干，不管是鱼干还是游戏机，都给你送最新的来，加油吧",
	en = "[未翻译]大王说了，好好干，不管是鱼干还是游戏机，都给你送最新的来，加油吧",
	zht = "大王說了，好好幹，不管是魚幹還是遊戲機，都給你送最新的來，加油吧",
}
LocalizationConfig["loc_story_msg_499"] =
{
	zh = "听起来好像还不错，那我先努力试试吧",
	en = "[未翻译]听起来好像还不错，那我先努力试试吧",
	zht = "聽起來好像還不錯，那我先努力試試吧",
}
LocalizationConfig["loc_story_msg_500"] =
{
	zh = "升爵位了呢，还好像不错，哎，傻猫有傻福",
	en = "[未翻译]升爵位了呢，还好像不错，哎，傻猫有傻福",
	zht = "升爵位了呢，還好像不錯，哎，傻貓有傻福",
}
LocalizationConfig["loc_mission_title1"] =
{
	zh = "绿色星球",
	en = "[未翻译]绿色星球",
	zht = "綠色星球",
}
LocalizationConfig["loc_mission_title2"] =
{
	zh = "剑士的伙伴",
	en = "[未翻译]剑士的伙伴",
	zht = "劍士的夥伴",
}
LocalizationConfig["loc_mission_title3"] =
{
	zh = "开始赚钱",
	en = "[未翻译]开始赚钱",
	zht = "開始賺錢",
}
LocalizationConfig["loc_mission_title4"] =
{
	zh = "升级星球(1)",
	en = "[未翻译]升级星球(1)",
	zht = "升級星球(1)",
}
LocalizationConfig["loc_mission_title5"] =
{
	zh = "猎人的力量",
	en = "[未翻译]猎人的力量",
	zht = "獵人的力量",
}
LocalizationConfig["loc_mission_title6"] =
{
	zh = "弓箭手最厉害",
	en = "[未翻译]弓箭手最厉害",
	zht = "弓箭手最厲害",
}
LocalizationConfig["loc_mission_title7"] =
{
	zh = "升级星球(2)",
	en = "[未翻译]升级星球(2)",
	zht = "升級星球(2)",
}
LocalizationConfig["loc_mission_title8"] =
{
	zh = "汽水好喝吗",
	en = "[未翻译]汽水好喝吗",
	zht = "汽水好喝嗎",
}
LocalizationConfig["loc_mission_title9"] =
{
	zh = "攻略是谁写的",
	en = "[未翻译]攻略是谁写的",
	zht = "攻略是誰寫的",
}
LocalizationConfig["loc_mission_title10"] =
{
	zh = "三角阵容",
	en = "[未翻译]三角阵容",
	zht = "三角陣容",
}
LocalizationConfig["loc_mission_title11"] =
{
	zh = "最终决战",
	en = "[未翻译]最终决战",
	zht = "最終決戰",
}
LocalizationConfig["loc_mission_title12"] =
{
	zh = "收租专家",
	en = "[未翻译]收租专家",
	zht = "收租專家",
}
LocalizationConfig["loc_mission_title13"] =
{
	zh = "绿油油星的地貌1",
	en = "[未翻译]绿油油星的地貌1",
	zht = "綠油油星的地貌1",
}
LocalizationConfig["loc_mission_title14"] =
{
	zh = "绿油油星的地貌2",
	en = "[未翻译]绿油油星的地貌2",
	zht = "綠油油星的地貌2",
}
LocalizationConfig["loc_mission_title15"] =
{
	zh = "绿油油星的地貌3",
	en = "[未翻译]绿油油星的地貌3",
	zht = "綠油油星的地貌3",
}
LocalizationConfig["loc_mission_title16"] =
{
	zh = "绿油油星的地貌4",
	en = "[未翻译]绿油油星的地貌4",
	zht = "綠油油星的地貌4",
}
LocalizationConfig["loc_mission_title17"] =
{
	zh = "绿油油星的地貌5",
	en = "[未翻译]绿油油星的地貌5",
	zht = "綠油油星的地貌5",
}
LocalizationConfig["loc_mission_title18"] =
{
	zh = "绿油油星的地貌6",
	en = "[未翻译]绿油油星的地貌6",
	zht = "綠油油星的地貌6",
}
LocalizationConfig["loc_mission_title19"] =
{
	zh = "绿油油星的地貌7",
	en = "[未翻译]绿油油星的地貌7",
	zht = "綠油油星的地貌7",
}
LocalizationConfig["loc_mission_title20"] =
{
	zh = "开始交易",
	en = "[未翻译]开始交易",
	zht = "開始交易",
}
LocalizationConfig["loc_mission_title21"] =
{
	zh = "扩大交易",
	en = "[未翻译]扩大交易",
	zht = "擴大交易",
}
LocalizationConfig["loc_mission_title22"] =
{
	zh = "交易大佬",
	en = "[未翻译]交易大佬",
	zht = "交易大佬",
}
LocalizationConfig["loc_mission_title23"] =
{
	zh = "绿油油星的资源1",
	en = "[未翻译]绿油油星的资源1",
	zht = "綠油油星的資源1",
}
LocalizationConfig["loc_mission_title24"] =
{
	zh = "绿油油星的资源2",
	en = "[未翻译]绿油油星的资源2",
	zht = "綠油油星的資源2",
}
LocalizationConfig["loc_mission_title25"] =
{
	zh = "绿油油星的资源3",
	en = "[未翻译]绿油油星的资源3",
	zht = "綠油油星的資源3",
}
LocalizationConfig["loc_mission_title26"] =
{
	zh = "绿油油星的资源4",
	en = "[未翻译]绿油油星的资源4",
	zht = "綠油油星的資源4",
}
LocalizationConfig["loc_mission_title27"] =
{
	zh = "绿油油星的资源5",
	en = "[未翻译]绿油油星的资源5",
	zht = "綠油油星的資源5",
}
LocalizationConfig["loc_mission_title28"] =
{
	zh = "绿油油星的资源6",
	en = "[未翻译]绿油油星的资源6",
	zht = "綠油油星的資源6",
}
LocalizationConfig["loc_mission_title29"] =
{
	zh = "绿油油星的资源7",
	en = "[未翻译]绿油油星的资源7",
	zht = "綠油油星的資源7",
}
LocalizationConfig["loc_mission_title30"] =
{
	zh = "绿油油星的资源8",
	en = "[未翻译]绿油油星的资源8",
	zht = "綠油油星的資源8",
}
LocalizationConfig["loc_mission_title31"] =
{
	zh = "绿油油星的资源9",
	en = "[未翻译]绿油油星的资源9",
	zht = "綠油油星的資源9",
}
LocalizationConfig["loc_mission_title32"] =
{
	zh = "绿油油星的资源10",
	en = "[未翻译]绿油油星的资源10",
	zht = "綠油油星的資源10",
}
LocalizationConfig["loc_mission_title33"] =
{
	zh = "绿油油星的资源11",
	en = "[未翻译]绿油油星的资源11",
	zht = "綠油油星的資源11",
}
LocalizationConfig["loc_mission_title34"] =
{
	zh = "绿油油星的资源12",
	en = "[未翻译]绿油油星的资源12",
	zht = "綠油油星的資源12",
}
LocalizationConfig["loc_mission_title35"] =
{
	zh = "绿油油星的资源13",
	en = "[未翻译]绿油油星的资源13",
	zht = "綠油油星的資源13",
}
LocalizationConfig["loc_mission_title36"] =
{
	zh = "绿油油星的资源14",
	en = "[未翻译]绿油油星的资源14",
	zht = "綠油油星的資源14",
}
LocalizationConfig["loc_mission_title37"] =
{
	zh = "绿油油星的资源15",
	en = "[未翻译]绿油油星的资源15",
	zht = "綠油油星的資源15",
}
LocalizationConfig["loc_mission_title38"] =
{
	zh = "绿油油星的资源16",
	en = "[未翻译]绿油油星的资源16",
	zht = "綠油油星的資源16",
}
LocalizationConfig["loc_mission_title39"] =
{
	zh = "绿油油星的资源17",
	en = "[未翻译]绿油油星的资源17",
	zht = "綠油油星的資源17",
}
LocalizationConfig["loc_mission_title40"] =
{
	zh = "绿油油星的资源18",
	en = "[未翻译]绿油油星的资源18",
	zht = "綠油油星的資源18",
}
LocalizationConfig["loc_mission_title41"] =
{
	zh = "绿油油星的资源19",
	en = "[未翻译]绿油油星的资源19",
	zht = "綠油油星的資源19",
}
LocalizationConfig["loc_mission_title42"] =
{
	zh = "绿油油星的资源20",
	en = "[未翻译]绿油油星的资源20",
	zht = "綠油油星的資源20",
}
LocalizationConfig["loc_mission_title43"] =
{
	zh = "绿油油星的资源21",
	en = "[未翻译]绿油油星的资源21",
	zht = "綠油油星的資源21",
}
LocalizationConfig["loc_mission_title44"] =
{
	zh = "甜蜜星球",
	en = "[未翻译]甜蜜星球",
	zht = "甜蜜星球",
}
LocalizationConfig["loc_mission_title45"] =
{
	zh = "友情的力量",
	en = "[未翻译]友情的力量",
	zht = "友情的力量",
}
LocalizationConfig["loc_mission_title46"] =
{
	zh = "重要的小朋友",
	en = "[未翻译]重要的小朋友",
	zht = "重要的小朋友",
}
LocalizationConfig["loc_mission_title47"] =
{
	zh = "调取监控",
	en = "[未翻译]调取监控",
	zht = "調取監控",
}
LocalizationConfig["loc_mission_title48"] =
{
	zh = "战斗女仆",
	en = "[未翻译]战斗女仆",
	zht = "戰鬥女僕",
}
LocalizationConfig["loc_mission_title49"] =
{
	zh = "拯救公主",
	en = "[未翻译]拯救公主",
	zht = "拯救公主",
}
LocalizationConfig["loc_mission_title50"] =
{
	zh = "毒药良口",
	en = "[未翻译]毒药良口",
	zht = "毒藥良口",
}
LocalizationConfig["loc_mission_title51"] =
{
	zh = "黑白皇后",
	en = "[未翻译]黑白皇后",
	zht = "黑白皇后",
}
LocalizationConfig["loc_mission_title52"] =
{
	zh = "走上正轨",
	en = "[未翻译]走上正轨",
	zht = "走上正軌",
}
LocalizationConfig["loc_mission_title53"] =
{
	zh = "甜蜜蜜星的地貌1",
	en = "[未翻译]甜蜜蜜星的地貌1",
	zht = "甜蜜蜜星的地貌1",
}
LocalizationConfig["loc_mission_title54"] =
{
	zh = "甜蜜蜜星的地貌2",
	en = "[未翻译]甜蜜蜜星的地貌2",
	zht = "甜蜜蜜星的地貌2",
}
LocalizationConfig["loc_mission_title55"] =
{
	zh = "甜蜜蜜星的地貌3",
	en = "[未翻译]甜蜜蜜星的地貌3",
	zht = "甜蜜蜜星的地貌3",
}
LocalizationConfig["loc_mission_title56"] =
{
	zh = "甜蜜蜜星的地貌4",
	en = "[未翻译]甜蜜蜜星的地貌4",
	zht = "甜蜜蜜星的地貌4",
}
LocalizationConfig["loc_mission_title57"] =
{
	zh = "甜蜜蜜星的地貌5",
	en = "[未翻译]甜蜜蜜星的地貌5",
	zht = "甜蜜蜜星的地貌5",
}
LocalizationConfig["loc_mission_title58"] =
{
	zh = "甜蜜蜜星的地貌6",
	en = "[未翻译]甜蜜蜜星的地貌6",
	zht = "甜蜜蜜星的地貌6",
}
LocalizationConfig["loc_mission_title59"] =
{
	zh = "甜蜜蜜星的资源1",
	en = "[未翻译]甜蜜蜜星的资源1",
	zht = "甜蜜蜜星的資源1",
}
LocalizationConfig["loc_mission_title60"] =
{
	zh = "甜蜜蜜星的资源2",
	en = "[未翻译]甜蜜蜜星的资源2",
	zht = "甜蜜蜜星的資源2",
}
LocalizationConfig["loc_mission_title61"] =
{
	zh = "甜蜜蜜星的资源3",
	en = "[未翻译]甜蜜蜜星的资源3",
	zht = "甜蜜蜜星的資源3",
}
LocalizationConfig["loc_mission_title62"] =
{
	zh = "甜蜜蜜星的资源4",
	en = "[未翻译]甜蜜蜜星的资源4",
	zht = "甜蜜蜜星的資源4",
}
LocalizationConfig["loc_mission_title63"] =
{
	zh = "甜蜜蜜星的资源5",
	en = "[未翻译]甜蜜蜜星的资源5",
	zht = "甜蜜蜜星的資源5",
}
LocalizationConfig["loc_mission_title64"] =
{
	zh = "甜蜜蜜星的资源6",
	en = "[未翻译]甜蜜蜜星的资源6",
	zht = "甜蜜蜜星的資源6",
}
LocalizationConfig["loc_mission_title65"] =
{
	zh = "甜蜜蜜星的资源7",
	en = "[未翻译]甜蜜蜜星的资源7",
	zht = "甜蜜蜜星的資源7",
}
LocalizationConfig["loc_mission_title66"] =
{
	zh = "甜蜜蜜星的资源8",
	en = "[未翻译]甜蜜蜜星的资源8",
	zht = "甜蜜蜜星的資源8",
}
LocalizationConfig["loc_mission_title67"] =
{
	zh = "甜蜜蜜星的资源9",
	en = "[未翻译]甜蜜蜜星的资源9",
	zht = "甜蜜蜜星的資源9",
}
LocalizationConfig["loc_mission_title68"] =
{
	zh = "甜蜜蜜星的资源10",
	en = "[未翻译]甜蜜蜜星的资源10",
	zht = "甜蜜蜜星的資源10",
}
LocalizationConfig["loc_mission_title69"] =
{
	zh = "甜蜜蜜星的资源11",
	en = "[未翻译]甜蜜蜜星的资源11",
	zht = "甜蜜蜜星的資源11",
}
LocalizationConfig["loc_mission_title70"] =
{
	zh = "甜蜜蜜星的资源12",
	en = "[未翻译]甜蜜蜜星的资源12",
	zht = "甜蜜蜜星的資源12",
}
LocalizationConfig["loc_mission_title71"] =
{
	zh = "甜蜜蜜星的资源13",
	en = "[未翻译]甜蜜蜜星的资源13",
	zht = "甜蜜蜜星的資源13",
}
LocalizationConfig["loc_mission_title72"] =
{
	zh = "甜蜜蜜星的资源14",
	en = "[未翻译]甜蜜蜜星的资源14",
	zht = "甜蜜蜜星的資源14",
}
LocalizationConfig["loc_mission_title73"] =
{
	zh = "甜蜜蜜星的资源15",
	en = "[未翻译]甜蜜蜜星的资源15",
	zht = "甜蜜蜜星的資源15",
}
LocalizationConfig["loc_mission_title74"] =
{
	zh = "甜蜜蜜星的资源16",
	en = "[未翻译]甜蜜蜜星的资源16",
	zht = "甜蜜蜜星的資源16",
}
LocalizationConfig["loc_mission_title75"] =
{
	zh = "甜蜜蜜星的资源17",
	en = "[未翻译]甜蜜蜜星的资源17",
	zht = "甜蜜蜜星的資源17",
}
LocalizationConfig["loc_mission_title76"] =
{
	zh = "甜蜜蜜星的资源18",
	en = "[未翻译]甜蜜蜜星的资源18",
	zht = "甜蜜蜜星的資源18",
}
LocalizationConfig["loc_mission_title77"] =
{
	zh = "甜蜜蜜星的资源19",
	en = "[未翻译]甜蜜蜜星的资源19",
	zht = "甜蜜蜜星的資源19",
}
LocalizationConfig["loc_mission_title78"] =
{
	zh = "甜蜜蜜星的资源20",
	en = "[未翻译]甜蜜蜜星的资源20",
	zht = "甜蜜蜜星的資源20",
}
LocalizationConfig["loc_mission_title79"] =
{
	zh = "破旧星球",
	en = "[未翻译]破旧星球",
	zht = "破舊星球",
}
LocalizationConfig["loc_mission_title80"] =
{
	zh = "抓小偷啦",
	en = "[未翻译]抓小偷啦",
	zht = "抓小偷啦",
}
LocalizationConfig["loc_mission_title81"] =
{
	zh = "没有木乃伊",
	en = "[未翻译]没有木乃伊",
	zht = "沒有木乃伊",
}
LocalizationConfig["loc_mission_title82"] =
{
	zh = "铠甲迷音",
	en = "[未翻译]铠甲迷音",
	zht = "鎧甲迷音",
}
LocalizationConfig["loc_mission_title83"] =
{
	zh = "找到小姑娘",
	en = "[未翻译]找到小姑娘",
	zht = "找到小姑娘",
}
LocalizationConfig["loc_mission_title84"] =
{
	zh = "浣熊二号",
	en = "[未翻译]浣熊二号",
	zht = "浣熊二號",
}
LocalizationConfig["loc_mission_title85"] =
{
	zh = "失踪人口",
	en = "[未翻译]失踪人口",
	zht = "失蹤人口",
}
LocalizationConfig["loc_mission_title86"] =
{
	zh = "获取真相",
	en = "[未翻译]获取真相",
	zht = "獲取真相",
}
LocalizationConfig["loc_mission_title87"] =
{
	zh = "更上一颗星",
	en = "[未翻译]更上一颗星",
	zht = "更上一顆星",
}
LocalizationConfig["loc_mission_title88"] =
{
	zh = "破烂烂星的地貌1",
	en = "[未翻译]破烂烂星的地貌1",
	zht = "破爛爛星的地貌1",
}
LocalizationConfig["loc_mission_title89"] =
{
	zh = "破烂烂星的地貌2",
	en = "[未翻译]破烂烂星的地貌2",
	zht = "破爛爛星的地貌2",
}
LocalizationConfig["loc_mission_title90"] =
{
	zh = "破烂烂星的地貌3",
	en = "[未翻译]破烂烂星的地貌3",
	zht = "破爛爛星的地貌3",
}
LocalizationConfig["loc_mission_title91"] =
{
	zh = "破烂烂星的地貌4",
	en = "[未翻译]破烂烂星的地貌4",
	zht = "破爛爛星的地貌4",
}
LocalizationConfig["loc_mission_title92"] =
{
	zh = "破烂烂星的地貌5",
	en = "[未翻译]破烂烂星的地貌5",
	zht = "破爛爛星的地貌5",
}
LocalizationConfig["loc_mission_title93"] =
{
	zh = "破烂烂星的地貌6",
	en = "[未翻译]破烂烂星的地貌6",
	zht = "破爛爛星的地貌6",
}
LocalizationConfig["loc_mission_title94"] =
{
	zh = "破烂烂星的资源1",
	en = "[未翻译]破烂烂星的资源1",
	zht = "破爛爛星的資源1",
}
LocalizationConfig["loc_mission_title95"] =
{
	zh = "破烂烂星的资源2",
	en = "[未翻译]破烂烂星的资源2",
	zht = "破爛爛星的資源2",
}
LocalizationConfig["loc_mission_title96"] =
{
	zh = "破烂烂星的资源3",
	en = "[未翻译]破烂烂星的资源3",
	zht = "破爛爛星的資源3",
}
LocalizationConfig["loc_mission_title97"] =
{
	zh = "破烂烂星的资源4",
	en = "[未翻译]破烂烂星的资源4",
	zht = "破爛爛星的資源4",
}
LocalizationConfig["loc_mission_title98"] =
{
	zh = "破烂烂星的资源5",
	en = "[未翻译]破烂烂星的资源5",
	zht = "破爛爛星的資源5",
}
LocalizationConfig["loc_mission_title99"] =
{
	zh = "破烂烂星的资源6",
	en = "[未翻译]破烂烂星的资源6",
	zht = "破爛爛星的資源6",
}
LocalizationConfig["loc_mission_title100"] =
{
	zh = "破烂烂星的资源7",
	en = "[未翻译]破烂烂星的资源7",
	zht = "破爛爛星的資源7",
}
LocalizationConfig["loc_mission_title101"] =
{
	zh = "破烂烂星的资源8",
	en = "[未翻译]破烂烂星的资源8",
	zht = "破爛爛星的資源8",
}
LocalizationConfig["loc_mission_title102"] =
{
	zh = "破烂烂星的资源9",
	en = "[未翻译]破烂烂星的资源9",
	zht = "破爛爛星的資源9",
}
LocalizationConfig["loc_mission_title103"] =
{
	zh = "破烂烂星的资源10",
	en = "[未翻译]破烂烂星的资源10",
	zht = "破爛爛星的資源10",
}
LocalizationConfig["loc_mission_title104"] =
{
	zh = "破烂烂星的资源11",
	en = "[未翻译]破烂烂星的资源11",
	zht = "破爛爛星的資源11",
}
LocalizationConfig["loc_mission_title105"] =
{
	zh = "破烂烂星的资源12",
	en = "[未翻译]破烂烂星的资源12",
	zht = "破爛爛星的資源12",
}
LocalizationConfig["loc_mission_title106"] =
{
	zh = "破烂烂星的资源13",
	en = "[未翻译]破烂烂星的资源13",
	zht = "破爛爛星的資源13",
}
LocalizationConfig["loc_mission_title107"] =
{
	zh = "破烂烂星的资源14",
	en = "[未翻译]破烂烂星的资源14",
	zht = "破爛爛星的資源14",
}
LocalizationConfig["loc_mission_title108"] =
{
	zh = "破烂烂星的资源15",
	en = "[未翻译]破烂烂星的资源15",
	zht = "破爛爛星的資源15",
}
LocalizationConfig["loc_mission_title109"] =
{
	zh = "破烂烂星的资源16",
	en = "[未翻译]破烂烂星的资源16",
	zht = "破爛爛星的資源16",
}
LocalizationConfig["loc_mission_title110"] =
{
	zh = "破烂烂星的资源17",
	en = "[未翻译]破烂烂星的资源17",
	zht = "破爛爛星的資源17",
}
LocalizationConfig["loc_mission_title111"] =
{
	zh = "破烂烂星的资源18",
	en = "[未翻译]破烂烂星的资源18",
	zht = "破爛爛星的資源18",
}
LocalizationConfig["loc_mission_title112"] =
{
	zh = "悬疑星球",
	en = "[未翻译]悬疑星球",
	zht = "懸疑星球",
}
LocalizationConfig["loc_mission_title113"] =
{
	zh = "寻找线索",
	en = "[未翻译]寻找线索",
	zht = "尋找線索",
}
LocalizationConfig["loc_mission_title114"] =
{
	zh = "询问老大",
	en = "[未翻译]询问老大",
	zht = "詢問老大",
}
LocalizationConfig["loc_mission_title115"] =
{
	zh = "询问法医",
	en = "[未翻译]询问法医",
	zht = "詢問法醫",
}
LocalizationConfig["loc_mission_title116"] =
{
	zh = "侦探的力量",
	en = "[未翻译]侦探的力量",
	zht = "偵探的力量",
}
LocalizationConfig["loc_mission_title117"] =
{
	zh = "神秘小组",
	en = "[未翻译]神秘小组",
	zht = "神秘小組",
}
LocalizationConfig["loc_mission_title118"] =
{
	zh = "小学生",
	en = "[未翻译]小学生",
	zht = "小學生",
}
LocalizationConfig["loc_mission_title119"] =
{
	zh = "击败凶手",
	en = "[未翻译]击败凶手",
	zht = "擊敗凶手",
}
LocalizationConfig["loc_mission_title120"] =
{
	zh = "赔偿国王的花瓶",
	en = "[未翻译]赔偿国王的花瓶",
	zht = "賠償國王的花瓶",
}
LocalizationConfig["loc_mission_title121"] =
{
	zh = "阴森森星的地貌1",
	en = "[未翻译]阴森森星的地貌1",
	zht = "陰森森星的地貌1",
}
LocalizationConfig["loc_mission_title122"] =
{
	zh = "阴森森星的地貌2",
	en = "[未翻译]阴森森星的地貌2",
	zht = "陰森森星的地貌2",
}
LocalizationConfig["loc_mission_title123"] =
{
	zh = "阴森森星的地貌3",
	en = "[未翻译]阴森森星的地貌3",
	zht = "陰森森星的地貌3",
}
LocalizationConfig["loc_mission_title124"] =
{
	zh = "阴森森星的地貌4",
	en = "[未翻译]阴森森星的地貌4",
	zht = "陰森森星的地貌4",
}
LocalizationConfig["loc_mission_title125"] =
{
	zh = "阴森森星的地貌5",
	en = "[未翻译]阴森森星的地貌5",
	zht = "陰森森星的地貌5",
}
LocalizationConfig["loc_mission_title126"] =
{
	zh = "阴森森星的资源1",
	en = "[未翻译]阴森森星的资源1",
	zht = "陰森森星的資源1",
}
LocalizationConfig["loc_mission_title127"] =
{
	zh = "阴森森星的资源2",
	en = "[未翻译]阴森森星的资源2",
	zht = "陰森森星的資源2",
}
LocalizationConfig["loc_mission_title128"] =
{
	zh = "阴森森星的资源3",
	en = "[未翻译]阴森森星的资源3",
	zht = "陰森森星的資源3",
}
LocalizationConfig["loc_mission_title129"] =
{
	zh = "阴森森星的资源4",
	en = "[未翻译]阴森森星的资源4",
	zht = "陰森森星的資源4",
}
LocalizationConfig["loc_mission_title130"] =
{
	zh = "阴森森星的资源5",
	en = "[未翻译]阴森森星的资源5",
	zht = "陰森森星的資源5",
}
LocalizationConfig["loc_mission_title131"] =
{
	zh = "阴森森星的资源6",
	en = "[未翻译]阴森森星的资源6",
	zht = "陰森森星的資源6",
}
LocalizationConfig["loc_mission_title132"] =
{
	zh = "阴森森星的资源7",
	en = "[未翻译]阴森森星的资源7",
	zht = "陰森森星的資源7",
}
LocalizationConfig["loc_mission_title133"] =
{
	zh = "阴森森星的资源8",
	en = "[未翻译]阴森森星的资源8",
	zht = "陰森森星的資源8",
}
LocalizationConfig["loc_mission_title134"] =
{
	zh = "阴森森星的资源9",
	en = "[未翻译]阴森森星的资源9",
	zht = "陰森森星的資源9",
}
LocalizationConfig["loc_mission_title135"] =
{
	zh = "阴森森星的资源10",
	en = "[未翻译]阴森森星的资源10",
	zht = "陰森森星的資源10",
}
LocalizationConfig["loc_mission_title136"] =
{
	zh = "阴森森星的资源11",
	en = "[未翻译]阴森森星的资源11",
	zht = "陰森森星的資源11",
}
LocalizationConfig["loc_mission_title137"] =
{
	zh = "阴森森星的资源12",
	en = "[未翻译]阴森森星的资源12",
	zht = "陰森森星的資源12",
}
LocalizationConfig["loc_mission_title138"] =
{
	zh = "阴森森星的资源13",
	en = "[未翻译]阴森森星的资源13",
	zht = "陰森森星的資源13",
}
LocalizationConfig["loc_mission_title139"] =
{
	zh = "阴森森星的资源14",
	en = "[未翻译]阴森森星的资源14",
	zht = "陰森森星的資源14",
}
LocalizationConfig["loc_mission_title140"] =
{
	zh = "阴森森星的资源15",
	en = "[未翻译]阴森森星的资源15",
	zht = "陰森森星的資源15",
}
LocalizationConfig["loc_mission_title141"] =
{
	zh = "阴森森星的资源15",
	en = "[未翻译]阴森森星的资源15",
	zht = "陰森森星的資源15",
}
LocalizationConfig["loc_mission_hint1"] =
{
	zh = "花瓶就是这么贵！",
	en = "[未翻译]花瓶就是这么贵！",
	zht = "花瓶就是這麼貴！",
}
LocalizationConfig["loc_mission_hint2"] =
{
	zh = "我头上可是主角光环呀！",
	en = "[未翻译]我头上可是主角光环呀！",
	zht = "我頭上可是主角光環呀！",
}
LocalizationConfig["loc_mission_hint3"] =
{
	zh = "我们是热爱研究的喵",
	en = "[未翻译]我们是热爱研究的喵",
	zht = "我們是熱愛研究的喵",
}
LocalizationConfig["loc_mission_hint4"] =
{
	zh = "生存技能我可是很厉害的",
	en = "[未翻译]生存技能我可是很厉害的",
	zht = "生存技能我可是很厲害的",
}
LocalizationConfig["loc_mission_hint5"] =
{
	zh = "我头上可是主角光环呀！",
	en = "[未翻译]我头上可是主角光环呀！",
	zht = "我頭上可是主角光環呀！",
}
LocalizationConfig["loc_mission_hint6"] =
{
	zh = "我头上可是主角光环呀！",
	en = "[未翻译]我头上可是主角光环呀！",
	zht = "我頭上可是主角光環呀！",
}
LocalizationConfig["loc_mission_hint7"] =
{
	zh = "生存技能我可是很厉害的",
	en = "[未翻译]生存技能我可是很厉害的",
	zht = "生存技能我可是很厲害的",
}
LocalizationConfig["loc_mission_hint8"] =
{
	zh = "瞄准，发射！",
	en = "[未翻译]瞄准，发射！",
	zht = "瞄準，發射！",
}
LocalizationConfig["loc_mission_hint9"] =
{
	zh = "瞄准，发射！",
	en = "[未翻译]瞄准，发射！",
	zht = "瞄準，發射！",
}
LocalizationConfig["loc_mission_hint10"] =
{
	zh = "我可能会算错",
	en = "[未翻译]我可能会算错",
	zht = "我可能會算錯",
}
LocalizationConfig["loc_mission_hint11"] =
{
	zh = "我头上可是主角光环呀！",
	en = "[未翻译]我头上可是主角光环呀！",
	zht = "我頭上可是主角光環呀！",
}
LocalizationConfig["loc_mission_hint12"] =
{
	zh = "花瓶就是这么贵！",
	en = "[未翻译]花瓶就是这么贵！",
	zht = "花瓶就是這麼貴！",
}
LocalizationConfig["loc_mission_hint13"] =
{
	zh = "我们是热爱研究的喵",
	en = "[未翻译]我们是热爱研究的喵",
	zht = "我們是熱愛研究的喵",
}
LocalizationConfig["loc_mission_hint14"] =
{
	zh = "我们是热爱研究的喵",
	en = "[未翻译]我们是热爱研究的喵",
	zht = "我們是熱愛研究的喵",
}
LocalizationConfig["loc_mission_hint15"] =
{
	zh = "我们是热爱研究的喵",
	en = "[未翻译]我们是热爱研究的喵",
	zht = "我們是熱愛研究的喵",
}
LocalizationConfig["loc_mission_hint16"] =
{
	zh = "我们是热爱研究的喵",
	en = "[未翻译]我们是热爱研究的喵",
	zht = "我們是熱愛研究的喵",
}
LocalizationConfig["loc_mission_hint17"] =
{
	zh = "我们是热爱研究的喵",
	en = "[未翻译]我们是热爱研究的喵",
	zht = "我們是熱愛研究的喵",
}
LocalizationConfig["loc_mission_hint18"] =
{
	zh = "我们是热爱研究的喵",
	en = "[未翻译]我们是热爱研究的喵",
	zht = "我們是熱愛研究的喵",
}
LocalizationConfig["loc_mission_hint19"] =
{
	zh = "我们是热爱研究的喵",
	en = "[未翻译]我们是热爱研究的喵",
	zht = "我們是熱愛研究的喵",
}
LocalizationConfig["loc_mission_hint20"] =
{
	zh = "卖各种物品获得金币喵",
	en = "[未翻译]卖各种物品获得金币喵",
	zht = "賣各種物品獲得金幣喵",
}
LocalizationConfig["loc_mission_hint21"] =
{
	zh = "卖各种物品获得金币喵",
	en = "[未翻译]卖各种物品获得金币喵",
	zht = "賣各種物品獲得金幣喵",
}
LocalizationConfig["loc_mission_hint22"] =
{
	zh = "卖各种物品获得金币喵",
	en = "[未翻译]卖各种物品获得金币喵",
	zht = "賣各種物品獲得金幣喵",
}
LocalizationConfig["loc_mission_hint23"] =
{
	zh = "我们是热爱研究的喵",
	en = "[未翻译]我们是热爱研究的喵",
	zht = "我們是熱愛研究的喵",
}
LocalizationConfig["loc_mission_hint24"] =
{
	zh = "我们是热爱探险的喵",
	en = "[未翻译]我们是热爱探险的喵",
	zht = "我們是熱愛探險的喵",
}
LocalizationConfig["loc_mission_hint25"] =
{
	zh = "我们是热爱研究的喵",
	en = "[未翻译]我们是热爱研究的喵",
	zht = "我們是熱愛研究的喵",
}
LocalizationConfig["loc_mission_hint26"] =
{
	zh = "我们是热爱探险的喵",
	en = "[未翻译]我们是热爱探险的喵",
	zht = "我們是熱愛探險的喵",
}
LocalizationConfig["loc_mission_hint27"] =
{
	zh = "我们是热爱研究的喵",
	en = "[未翻译]我们是热爱研究的喵",
	zht = "我們是熱愛研究的喵",
}
LocalizationConfig["loc_mission_hint28"] =
{
	zh = "我们是热爱探险的喵",
	en = "[未翻译]我们是热爱探险的喵",
	zht = "我們是熱愛探險的喵",
}
LocalizationConfig["loc_mission_hint29"] =
{
	zh = "我们是热爱研究的喵",
	en = "[未翻译]我们是热爱研究的喵",
	zht = "我們是熱愛研究的喵",
}
LocalizationConfig["loc_mission_hint30"] =
{
	zh = "我们是热爱探险的喵",
	en = "[未翻译]我们是热爱探险的喵",
	zht = "我們是熱愛探險的喵",
}
LocalizationConfig["loc_mission_hint31"] =
{
	zh = "我们是热爱研究的喵",
	en = "[未翻译]我们是热爱研究的喵",
	zht = "我們是熱愛研究的喵",
}
LocalizationConfig["loc_mission_hint32"] =
{
	zh = "我们是热爱探险的喵",
	en = "[未翻译]我们是热爱探险的喵",
	zht = "我們是熱愛探險的喵",
}
LocalizationConfig["loc_mission_hint33"] =
{
	zh = "我们是热爱研究的喵",
	en = "[未翻译]我们是热爱研究的喵",
	zht = "我們是熱愛研究的喵",
}
LocalizationConfig["loc_mission_hint34"] =
{
	zh = "我们是热爱研究的喵",
	en = "[未翻译]我们是热爱研究的喵",
	zht = "我們是熱愛研究的喵",
}
LocalizationConfig["loc_mission_hint35"] =
{
	zh = "我们是热爱研究的喵",
	en = "[未翻译]我们是热爱研究的喵",
	zht = "我們是熱愛研究的喵",
}
LocalizationConfig["loc_mission_hint36"] =
{
	zh = "我们是热爱探险的喵",
	en = "[未翻译]我们是热爱探险的喵",
	zht = "我們是熱愛探險的喵",
}
LocalizationConfig["loc_mission_hint37"] =
{
	zh = "我们是热爱探险的喵",
	en = "[未翻译]我们是热爱探险的喵",
	zht = "我們是熱愛探險的喵",
}
LocalizationConfig["loc_mission_hint38"] =
{
	zh = "我们是热爱研究的喵",
	en = "[未翻译]我们是热爱研究的喵",
	zht = "我們是熱愛研究的喵",
}
LocalizationConfig["loc_mission_hint39"] =
{
	zh = "我们是热爱研究的喵",
	en = "[未翻译]我们是热爱研究的喵",
	zht = "我們是熱愛研究的喵",
}
LocalizationConfig["loc_mission_hint40"] =
{
	zh = "我们是热爱探险的喵",
	en = "[未翻译]我们是热爱探险的喵",
	zht = "我們是熱愛探險的喵",
}
LocalizationConfig["loc_mission_hint41"] =
{
	zh = "我们是热爱研究的喵",
	en = "[未翻译]我们是热爱研究的喵",
	zht = "我們是熱愛研究的喵",
}
LocalizationConfig["loc_mission_hint42"] =
{
	zh = "我们是热爱探险的喵",
	en = "[未翻译]我们是热爱探险的喵",
	zht = "我們是熱愛探險的喵",
}
LocalizationConfig["loc_mission_hint43"] =
{
	zh = "我们是热爱研究的喵",
	en = "[未翻译]我们是热爱研究的喵",
	zht = "我們是熱愛研究的喵",
}
LocalizationConfig["loc_mission_hint44"] =
{
	zh = "花瓶就是这么贵！",
	en = "[未翻译]花瓶就是这么贵！",
	zht = "花瓶就是這麼貴！",
}
LocalizationConfig["loc_mission_hint45"] =
{
	zh = "公主不见了！",
	en = "[未翻译]公主不见了！",
	zht = "公主不見了！",
}
LocalizationConfig["loc_mission_hint46"] =
{
	zh = "公主不见了！",
	en = "[未翻译]公主不见了！",
	zht = "公主不見了！",
}
LocalizationConfig["loc_mission_hint47"] =
{
	zh = "公主不见了！",
	en = "[未翻译]公主不见了！",
	zht = "公主不見了！",
}
LocalizationConfig["loc_mission_hint48"] =
{
	zh = "一切都会得到控制",
	en = "[未翻译]一切都会得到控制",
	zht = "一切都會得到控制",
}
LocalizationConfig["loc_mission_hint49"] =
{
	zh = "一切都会得到控制",
	en = "[未翻译]一切都会得到控制",
	zht = "一切都會得到控制",
}
LocalizationConfig["loc_mission_hint50"] =
{
	zh = "皇后以前不是这样的",
	en = "[未翻译]皇后以前不是这样的",
	zht = "皇后以前不是這樣的",
}
LocalizationConfig["loc_mission_hint51"] =
{
	zh = "皇后以前不是这样的",
	en = "[未翻译]皇后以前不是这样的",
	zht = "皇后以前不是這樣的",
}
LocalizationConfig["loc_mission_hint52"] =
{
	zh = "花瓶就是这么贵！",
	en = "[未翻译]花瓶就是这么贵！",
	zht = "花瓶就是這麼貴！",
}
LocalizationConfig["loc_mission_hint53"] =
{
	zh = "我们是热爱吃喝的喵",
	en = "[未翻译]我们是热爱吃喝的喵",
	zht = "我們是熱愛吃喝的喵",
}
LocalizationConfig["loc_mission_hint54"] =
{
	zh = "我们是热爱吃喝的喵",
	en = "[未翻译]我们是热爱吃喝的喵",
	zht = "我們是熱愛吃喝的喵",
}
LocalizationConfig["loc_mission_hint55"] =
{
	zh = "我们是热爱吃喝的喵",
	en = "[未翻译]我们是热爱吃喝的喵",
	zht = "我們是熱愛吃喝的喵",
}
LocalizationConfig["loc_mission_hint56"] =
{
	zh = "我们是热爱吃喝的喵",
	en = "[未翻译]我们是热爱吃喝的喵",
	zht = "我們是熱愛吃喝的喵",
}
LocalizationConfig["loc_mission_hint57"] =
{
	zh = "我们是热爱吃喝的喵",
	en = "[未翻译]我们是热爱吃喝的喵",
	zht = "我們是熱愛吃喝的喵",
}
LocalizationConfig["loc_mission_hint58"] =
{
	zh = "我们是热爱吃喝的喵",
	en = "[未翻译]我们是热爱吃喝的喵",
	zht = "我們是熱愛吃喝的喵",
}
LocalizationConfig["loc_mission_hint59"] =
{
	zh = "我们是热爱吃喝的喵",
	en = "[未翻译]我们是热爱吃喝的喵",
	zht = "我們是熱愛吃喝的喵",
}
LocalizationConfig["loc_mission_hint60"] =
{
	zh = "我们是热爱吃喝的喵",
	en = "[未翻译]我们是热爱吃喝的喵",
	zht = "我們是熱愛吃喝的喵",
}
LocalizationConfig["loc_mission_hint61"] =
{
	zh = "我们是热爱吃喝的喵",
	en = "[未翻译]我们是热爱吃喝的喵",
	zht = "我們是熱愛吃喝的喵",
}
LocalizationConfig["loc_mission_hint62"] =
{
	zh = "我们是热爱吃喝的喵",
	en = "[未翻译]我们是热爱吃喝的喵",
	zht = "我們是熱愛吃喝的喵",
}
LocalizationConfig["loc_mission_hint63"] =
{
	zh = "我们是热爱吃喝的喵",
	en = "[未翻译]我们是热爱吃喝的喵",
	zht = "我們是熱愛吃喝的喵",
}
LocalizationConfig["loc_mission_hint64"] =
{
	zh = "我们是热爱吃喝的喵",
	en = "[未翻译]我们是热爱吃喝的喵",
	zht = "我們是熱愛吃喝的喵",
}
LocalizationConfig["loc_mission_hint65"] =
{
	zh = "我们是热爱吃喝的喵",
	en = "[未翻译]我们是热爱吃喝的喵",
	zht = "我們是熱愛吃喝的喵",
}
LocalizationConfig["loc_mission_hint66"] =
{
	zh = "我们是热爱吃喝的喵",
	en = "[未翻译]我们是热爱吃喝的喵",
	zht = "我們是熱愛吃喝的喵",
}
LocalizationConfig["loc_mission_hint67"] =
{
	zh = "我们是热爱吃喝的喵",
	en = "[未翻译]我们是热爱吃喝的喵",
	zht = "我們是熱愛吃喝的喵",
}
LocalizationConfig["loc_mission_hint68"] =
{
	zh = "我们是热爱吃喝的喵",
	en = "[未翻译]我们是热爱吃喝的喵",
	zht = "我們是熱愛吃喝的喵",
}
LocalizationConfig["loc_mission_hint69"] =
{
	zh = "我们是热爱吃喝的喵",
	en = "[未翻译]我们是热爱吃喝的喵",
	zht = "我們是熱愛吃喝的喵",
}
LocalizationConfig["loc_mission_hint70"] =
{
	zh = "我们是热爱吃喝的喵",
	en = "[未翻译]我们是热爱吃喝的喵",
	zht = "我們是熱愛吃喝的喵",
}
LocalizationConfig["loc_mission_hint71"] =
{
	zh = "我们是热爱吃喝的喵",
	en = "[未翻译]我们是热爱吃喝的喵",
	zht = "我們是熱愛吃喝的喵",
}
LocalizationConfig["loc_mission_hint72"] =
{
	zh = "我们是热爱吃喝的喵",
	en = "[未翻译]我们是热爱吃喝的喵",
	zht = "我們是熱愛吃喝的喵",
}
LocalizationConfig["loc_mission_hint73"] =
{
	zh = "我们是热爱吃喝的喵",
	en = "[未翻译]我们是热爱吃喝的喵",
	zht = "我們是熱愛吃喝的喵",
}
LocalizationConfig["loc_mission_hint74"] =
{
	zh = "我们是热爱吃喝的喵",
	en = "[未翻译]我们是热爱吃喝的喵",
	zht = "我們是熱愛吃喝的喵",
}
LocalizationConfig["loc_mission_hint75"] =
{
	zh = "我们是热爱吃喝的喵",
	en = "[未翻译]我们是热爱吃喝的喵",
	zht = "我們是熱愛吃喝的喵",
}
LocalizationConfig["loc_mission_hint76"] =
{
	zh = "我们是热爱吃喝的喵",
	en = "[未翻译]我们是热爱吃喝的喵",
	zht = "我們是熱愛吃喝的喵",
}
LocalizationConfig["loc_mission_hint77"] =
{
	zh = "我们是热爱吃喝的喵",
	en = "[未翻译]我们是热爱吃喝的喵",
	zht = "我們是熱愛吃喝的喵",
}
LocalizationConfig["loc_mission_hint78"] =
{
	zh = "我们是热爱吃喝的喵",
	en = "[未翻译]我们是热爱吃喝的喵",
	zht = "我們是熱愛吃喝的喵",
}
LocalizationConfig["loc_mission_hint79"] =
{
	zh = "花瓶就是这么贵！",
	en = "[未翻译]花瓶就是这么贵！",
	zht = "花瓶就是這麼貴！",
}
LocalizationConfig["loc_mission_hint80"] =
{
	zh = "要么没小偷，要么来一群",
	en = "[未翻译]要么没小偷，要么来一群",
	zht = "要麼沒小偷，要麼來一群",
}
LocalizationConfig["loc_mission_hint81"] =
{
	zh = "要么没小偷，要么来一群",
	en = "[未翻译]要么没小偷，要么来一群",
	zht = "要麼沒小偷，要麼來一群",
}
LocalizationConfig["loc_mission_hint82"] =
{
	zh = "要么没小偷，要么来一群",
	en = "[未翻译]要么没小偷，要么来一群",
	zht = "要麼沒小偷，要麼來一群",
}
LocalizationConfig["loc_mission_hint83"] =
{
	zh = "要么没小偷，要么来一群",
	en = "[未翻译]要么没小偷，要么来一群",
	zht = "要麼沒小偷，要麼來一群",
}
LocalizationConfig["loc_mission_hint84"] =
{
	zh = "天下没有解决不了的案子",
	en = "[未翻译]天下没有解决不了的案子",
	zht = "天下沒有解決不了的案子",
}
LocalizationConfig["loc_mission_hint85"] =
{
	zh = "要么没小偷，要么来一群",
	en = "[未翻译]要么没小偷，要么来一群",
	zht = "要麼沒小偷，要麼來一群",
}
LocalizationConfig["loc_mission_hint86"] =
{
	zh = "天下没有解决不了的案子",
	en = "[未翻译]天下没有解决不了的案子",
	zht = "天下沒有解決不了的案子",
}
LocalizationConfig["loc_mission_hint87"] =
{
	zh = "花瓶就是这么贵！",
	en = "[未翻译]花瓶就是这么贵！",
	zht = "花瓶就是這麼貴！",
}
LocalizationConfig["loc_mission_hint88"] =
{
	zh = "我们是热爱历史的喵",
	en = "[未翻译]我们是热爱历史的喵",
	zht = "我們是熱愛歷史的喵",
}
LocalizationConfig["loc_mission_hint89"] =
{
	zh = "我们是热爱历史的喵",
	en = "[未翻译]我们是热爱历史的喵",
	zht = "我們是熱愛歷史的喵",
}
LocalizationConfig["loc_mission_hint90"] =
{
	zh = "我们是热爱历史的喵",
	en = "[未翻译]我们是热爱历史的喵",
	zht = "我們是熱愛歷史的喵",
}
LocalizationConfig["loc_mission_hint91"] =
{
	zh = "我们是热爱历史的喵",
	en = "[未翻译]我们是热爱历史的喵",
	zht = "我們是熱愛歷史的喵",
}
LocalizationConfig["loc_mission_hint92"] =
{
	zh = "我们是热爱历史的喵",
	en = "[未翻译]我们是热爱历史的喵",
	zht = "我們是熱愛歷史的喵",
}
LocalizationConfig["loc_mission_hint93"] =
{
	zh = "我们是热爱历史的喵",
	en = "[未翻译]我们是热爱历史的喵",
	zht = "我們是熱愛歷史的喵",
}
LocalizationConfig["loc_mission_hint94"] =
{
	zh = "我们是热爱历史的喵",
	en = "[未翻译]我们是热爱历史的喵",
	zht = "我們是熱愛歷史的喵",
}
LocalizationConfig["loc_mission_hint95"] =
{
	zh = "我们是热爱历史的喵",
	en = "[未翻译]我们是热爱历史的喵",
	zht = "我們是熱愛歷史的喵",
}
LocalizationConfig["loc_mission_hint96"] =
{
	zh = "我们是热爱历史的喵",
	en = "[未翻译]我们是热爱历史的喵",
	zht = "我們是熱愛歷史的喵",
}
LocalizationConfig["loc_mission_hint97"] =
{
	zh = "我们是热爱历史的喵",
	en = "[未翻译]我们是热爱历史的喵",
	zht = "我們是熱愛歷史的喵",
}
LocalizationConfig["loc_mission_hint98"] =
{
	zh = "我们是热爱历史的喵",
	en = "[未翻译]我们是热爱历史的喵",
	zht = "我們是熱愛歷史的喵",
}
LocalizationConfig["loc_mission_hint99"] =
{
	zh = "我们是热爱历史的喵",
	en = "[未翻译]我们是热爱历史的喵",
	zht = "我們是熱愛歷史的喵",
}
LocalizationConfig["loc_mission_hint100"] =
{
	zh = "我们是热爱历史的喵",
	en = "[未翻译]我们是热爱历史的喵",
	zht = "我們是熱愛歷史的喵",
}
LocalizationConfig["loc_mission_hint101"] =
{
	zh = "我们是热爱历史的喵",
	en = "[未翻译]我们是热爱历史的喵",
	zht = "我們是熱愛歷史的喵",
}
LocalizationConfig["loc_mission_hint102"] =
{
	zh = "我们是热爱历史的喵",
	en = "[未翻译]我们是热爱历史的喵",
	zht = "我們是熱愛歷史的喵",
}
LocalizationConfig["loc_mission_hint103"] =
{
	zh = "我们是热爱历史的喵",
	en = "[未翻译]我们是热爱历史的喵",
	zht = "我們是熱愛歷史的喵",
}
LocalizationConfig["loc_mission_hint104"] =
{
	zh = "我们是热爱历史的喵",
	en = "[未翻译]我们是热爱历史的喵",
	zht = "我們是熱愛歷史的喵",
}
LocalizationConfig["loc_mission_hint105"] =
{
	zh = "我们是热爱历史的喵",
	en = "[未翻译]我们是热爱历史的喵",
	zht = "我們是熱愛歷史的喵",
}
LocalizationConfig["loc_mission_hint106"] =
{
	zh = "我们是热爱历史的喵",
	en = "[未翻译]我们是热爱历史的喵",
	zht = "我們是熱愛歷史的喵",
}
LocalizationConfig["loc_mission_hint107"] =
{
	zh = "我们是热爱历史的喵",
	en = "[未翻译]我们是热爱历史的喵",
	zht = "我們是熱愛歷史的喵",
}
LocalizationConfig["loc_mission_hint108"] =
{
	zh = "我们是热爱历史的喵",
	en = "[未翻译]我们是热爱历史的喵",
	zht = "我們是熱愛歷史的喵",
}
LocalizationConfig["loc_mission_hint109"] =
{
	zh = "我们是热爱历史的喵",
	en = "[未翻译]我们是热爱历史的喵",
	zht = "我們是熱愛歷史的喵",
}
LocalizationConfig["loc_mission_hint110"] =
{
	zh = "我们是热爱历史的喵",
	en = "[未翻译]我们是热爱历史的喵",
	zht = "我們是熱愛歷史的喵",
}
LocalizationConfig["loc_mission_hint111"] =
{
	zh = "我们是热爱历史的喵",
	en = "[未翻译]我们是热爱历史的喵",
	zht = "我們是熱愛歷史的喵",
}
LocalizationConfig["loc_mission_hint112"] =
{
	zh = "花瓶就是这么贵！",
	en = "[未翻译]花瓶就是这么贵！",
	zht = "花瓶就是這麼貴！",
}
LocalizationConfig["loc_mission_hint113"] =
{
	zh = "有什么我可以帮你的？",
	en = "[未翻译]有什么我可以帮你的？",
	zht = "有什麼我可以幫你的？",
}
LocalizationConfig["loc_mission_hint114"] =
{
	zh = "有什么我可以帮你的？",
	en = "[未翻译]有什么我可以帮你的？",
	zht = "有什麼我可以幫你的？",
}
LocalizationConfig["loc_mission_hint115"] =
{
	zh = "有什么我可以帮你的？",
	en = "[未翻译]有什么我可以帮你的？",
	zht = "有什麼我可以幫你的？",
}
LocalizationConfig["loc_mission_hint116"] =
{
	zh = "有什么我可以帮你的？",
	en = "[未翻译]有什么我可以帮你的？",
	zht = "有什麼我可以幫你的？",
}
LocalizationConfig["loc_mission_hint117"] =
{
	zh = "有什么我可以帮你的？",
	en = "[未翻译]有什么我可以帮你的？",
	zht = "有什麼我可以幫你的？",
}
LocalizationConfig["loc_mission_hint118"] =
{
	zh = "有什么我可以帮你的？",
	en = "[未翻译]有什么我可以帮你的？",
	zht = "有什麼我可以幫你的？",
}
LocalizationConfig["loc_mission_hint119"] =
{
	zh = "有什么我可以帮你的？",
	en = "[未翻译]有什么我可以帮你的？",
	zht = "有什麼我可以幫你的？",
}
LocalizationConfig["loc_mission_hint120"] =
{
	zh = "花瓶就是这么贵！",
	en = "[未翻译]花瓶就是这么贵！",
	zht = "花瓶就是這麼貴！",
}
LocalizationConfig["loc_mission_hint121"] =
{
	zh = "我们是热爱谜题的喵",
	en = "[未翻译]我们是热爱谜题的喵",
	zht = "我們是熱愛謎題的喵",
}
LocalizationConfig["loc_mission_hint122"] =
{
	zh = "我们是热爱谜题的喵",
	en = "[未翻译]我们是热爱谜题的喵",
	zht = "我們是熱愛謎題的喵",
}
LocalizationConfig["loc_mission_hint123"] =
{
	zh = "我们是热爱谜题的喵",
	en = "[未翻译]我们是热爱谜题的喵",
	zht = "我們是熱愛謎題的喵",
}
LocalizationConfig["loc_mission_hint124"] =
{
	zh = "我们是热爱谜题的喵",
	en = "[未翻译]我们是热爱谜题的喵",
	zht = "我們是熱愛謎題的喵",
}
LocalizationConfig["loc_mission_hint125"] =
{
	zh = "我们是热爱谜题的喵",
	en = "[未翻译]我们是热爱谜题的喵",
	zht = "我們是熱愛謎題的喵",
}
LocalizationConfig["loc_mission_hint126"] =
{
	zh = "我们是热爱谜题的喵",
	en = "[未翻译]我们是热爱谜题的喵",
	zht = "我們是熱愛謎題的喵",
}
LocalizationConfig["loc_mission_hint127"] =
{
	zh = "我们是热爱谜题的喵",
	en = "[未翻译]我们是热爱谜题的喵",
	zht = "我們是熱愛謎題的喵",
}
LocalizationConfig["loc_mission_hint128"] =
{
	zh = "我们是热爱谜题的喵",
	en = "[未翻译]我们是热爱谜题的喵",
	zht = "我們是熱愛謎題的喵",
}
LocalizationConfig["loc_mission_hint129"] =
{
	zh = "我们是热爱谜题的喵",
	en = "[未翻译]我们是热爱谜题的喵",
	zht = "我們是熱愛謎題的喵",
}
LocalizationConfig["loc_mission_hint130"] =
{
	zh = "我们是热爱谜题的喵",
	en = "[未翻译]我们是热爱谜题的喵",
	zht = "我們是熱愛謎題的喵",
}
LocalizationConfig["loc_mission_hint131"] =
{
	zh = "我们是热爱谜题的喵",
	en = "[未翻译]我们是热爱谜题的喵",
	zht = "我們是熱愛謎題的喵",
}
LocalizationConfig["loc_mission_hint132"] =
{
	zh = "我们是热爱谜题的喵",
	en = "[未翻译]我们是热爱谜题的喵",
	zht = "我們是熱愛謎題的喵",
}
LocalizationConfig["loc_mission_hint133"] =
{
	zh = "我们是热爱谜题的喵",
	en = "[未翻译]我们是热爱谜题的喵",
	zht = "我們是熱愛謎題的喵",
}
LocalizationConfig["loc_mission_hint134"] =
{
	zh = "我们是热爱谜题的喵",
	en = "[未翻译]我们是热爱谜题的喵",
	zht = "我們是熱愛謎題的喵",
}
LocalizationConfig["loc_mission_hint135"] =
{
	zh = "我们是热爱谜题的喵",
	en = "[未翻译]我们是热爱谜题的喵",
	zht = "我們是熱愛謎題的喵",
}
LocalizationConfig["loc_mission_hint136"] =
{
	zh = "我们是热爱谜题的喵",
	en = "[未翻译]我们是热爱谜题的喵",
	zht = "我們是熱愛謎題的喵",
}
LocalizationConfig["loc_mission_hint137"] =
{
	zh = "我们是热爱谜题的喵",
	en = "[未翻译]我们是热爱谜题的喵",
	zht = "我們是熱愛謎題的喵",
}
LocalizationConfig["loc_mission_hint138"] =
{
	zh = "我们是热爱谜题的喵",
	en = "[未翻译]我们是热爱谜题的喵",
	zht = "我們是熱愛謎題的喵",
}
LocalizationConfig["loc_mission_hint139"] =
{
	zh = "我们是热爱谜题的喵",
	en = "[未翻译]我们是热爱谜题的喵",
	zht = "我們是熱愛謎題的喵",
}
LocalizationConfig["loc_mission_hint140"] =
{
	zh = "我们是热爱谜题的喵",
	en = "[未翻译]我们是热爱谜题的喵",
	zht = "我們是熱愛謎題的喵",
}
LocalizationConfig["loc_mission_hint141"] =
{
	zh = "我们是热爱谜题的喵",
	en = "[未翻译]我们是热爱谜题的喵",
	zht = "我們是熱愛謎題的喵",
}
LocalizationConfig["loc_mission_PreDesc1"] =
{
	zh = "这个星球的地貌都是方方正正的呢",
	en = "[未翻译]这个星球的地貌都是方方正正的呢",
	zht = "這個星球的地貌都是方方正正的呢",
}
LocalizationConfig["loc_mission_PreDesc2"] =
{
	zh = "猎人躲进了地下洞穴，去把他抓出来吧",
	en = "[未翻译]猎人躲进了地下洞穴，去把他抓出来吧",
	zht = "獵人躲進了地下洞穴，去把他抓出來吧",
}
LocalizationConfig["loc_mission_PreDesc3"] =
{
	zh = "这个星球有很多新奇的资源，可以直接卖给喵星杂货铺",
	en = "[未翻译]这个星球有很多新奇的资源，可以直接卖给喵星杂货铺",
	zht = "這個星球有很多新奇的資源，可以直接賣給喵星雜貨鋪",
}
LocalizationConfig["loc_mission_PreDesc4"] =
{
	zh = "要开拓新区域的话，要升级星球哦",
	en = "[未翻译]要开拓新区域的话，要升级星球哦",
	zht = "要開拓新區域的話，要升級星球哦",
}
LocalizationConfig["loc_mission_PreDesc5"] =
{
	zh = "去找这边的猎人问问消息",
	en = "[未翻译]去找这边的猎人问问消息",
	zht = "去找這邊的獵人問問消息",
}
LocalizationConfig["loc_mission_PreDesc6"] =
{
	zh = "现在需要找回傲娇的弓箭手了",
	en = "[未翻译]现在需要找回傲娇的弓箭手了",
	zht = "現在需要找回傲嬌的弓箭手了",
}
LocalizationConfig["loc_mission_PreDesc7"] =
{
	zh = "要开拓新区域的话，要升级星球哦",
	en = "[未翻译]要开拓新区域的话，要升级星球哦",
	zht = "要開拓新區域的話，要升級星球哦",
}
LocalizationConfig["loc_mission_PreDesc8"] =
{
	zh = "爱喝汽水的随从，我们去找他",
	en = "[未翻译]爱喝汽水的随从，我们去找他",
	zht = "愛喝汽水的隨從，我們去找他",
}
LocalizationConfig["loc_mission_PreDesc9"] =
{
	zh = "既然有个室外高人，不去问一下不合适",
	en = "[未翻译]既然有个室外高人，不去问一下不合适",
	zht = "既然有個室外高人，不去問一下不合適",
}
LocalizationConfig["loc_mission_PreDesc10"] =
{
	zh = "没有专业牧师怎能挑战大魔王",
	en = "[未翻译]没有专业牧师怎能挑战大魔王",
	zht = "沒有專業牧師怎能挑戰大魔王",
}
LocalizationConfig["loc_mission_PreDesc11"] =
{
	zh = "是时候进行真正的战斗了",
	en = "[未翻译]是时候进行真正的战斗了",
	zht = "是時候進行真正的戰鬥了",
}
LocalizationConfig["loc_mission_PreDesc12"] =
{
	zh = "干的不错，不过你的欠款还有很多",
	en = "[未翻译]干的不错，不过你的欠款还有很多",
	zht = "幹的不錯，不過你的欠款還有很多",
}
LocalizationConfig["loc_mission_PreDesc13"] =
{
	zh = "我们的科学家对这个绿油油星球有点兴趣，你先多逛逛",
	en = "[未翻译]我们的科学家对这个绿油油星球有点兴趣，你先多逛逛",
	zht = "我們的科學家對這個綠油油星球有點興趣，你先多逛逛",
}
LocalizationConfig["loc_mission_PreDesc14"] =
{
	zh = "我们的科学家对这个绿油油星球有点兴趣，你先多逛逛",
	en = "[未翻译]我们的科学家对这个绿油油星球有点兴趣，你先多逛逛",
	zht = "我們的科學家對這個綠油油星球有點興趣，你先多逛逛",
}
LocalizationConfig["loc_mission_PreDesc15"] =
{
	zh = "我们的科学家对这个绿油油星球有点兴趣，你先多逛逛",
	en = "[未翻译]我们的科学家对这个绿油油星球有点兴趣，你先多逛逛",
	zht = "我們的科學家對這個綠油油星球有點興趣，你先多逛逛",
}
LocalizationConfig["loc_mission_PreDesc16"] =
{
	zh = "我们的科学家对这个绿油油星球有点兴趣，你先多逛逛",
	en = "[未翻译]我们的科学家对这个绿油油星球有点兴趣，你先多逛逛",
	zht = "我們的科學家對這個綠油油星球有點興趣，你先多逛逛",
}
LocalizationConfig["loc_mission_PreDesc17"] =
{
	zh = "我们的科学家对这个绿油油星球有点兴趣，你先多逛逛",
	en = "[未翻译]我们的科学家对这个绿油油星球有点兴趣，你先多逛逛",
	zht = "我們的科學家對這個綠油油星球有點興趣，你先多逛逛",
}
LocalizationConfig["loc_mission_PreDesc18"] =
{
	zh = "我们的科学家对这个绿油油星球有点兴趣，你先多逛逛",
	en = "[未翻译]我们的科学家对这个绿油油星球有点兴趣，你先多逛逛",
	zht = "我們的科學家對這個綠油油星球有點興趣，你先多逛逛",
}
LocalizationConfig["loc_mission_PreDesc19"] =
{
	zh = "我们的科学家对这个绿油油星球有点兴趣，你先多逛逛",
	en = "[未翻译]我们的科学家对这个绿油油星球有点兴趣，你先多逛逛",
	zht = "我們的科學家對這個綠油油星球有點興趣，你先多逛逛",
}
LocalizationConfig["loc_mission_PreDesc20"] =
{
	zh = "这个星球有很多新奇的资源，可以直接卖给喵星杂货铺",
	en = "[未翻译]这个星球有很多新奇的资源，可以直接卖给喵星杂货铺",
	zht = "這個星球有很多新奇的資源，可以直接賣給喵星雜貨鋪",
}
LocalizationConfig["loc_mission_PreDesc21"] =
{
	zh = "这个星球有很多新奇的资源，可以直接卖给喵星杂货铺",
	en = "[未翻译]这个星球有很多新奇的资源，可以直接卖给喵星杂货铺",
	zht = "這個星球有很多新奇的資源，可以直接賣給喵星雜貨鋪",
}
LocalizationConfig["loc_mission_PreDesc22"] =
{
	zh = "这个星球有很多新奇的资源，可以直接卖给喵星杂货铺",
	en = "[未翻译]这个星球有很多新奇的资源，可以直接卖给喵星杂货铺",
	zht = "這個星球有很多新奇的資源，可以直接賣給喵星雜貨鋪",
}
LocalizationConfig["loc_mission_PreDesc23"] =
{
	zh = "我们的科学家对这个绿油油星球有点兴趣，拿点资源回来研究一下吧",
	en = "[未翻译]我们的科学家对这个绿油油星球有点兴趣，拿点资源回来研究一下吧",
	zht = "我們的科學家對這個綠油油星球有點興趣，拿點資源回來研究一下吧",
}
LocalizationConfig["loc_mission_PreDesc24"] =
{
	zh = "有钱试试十连抽吧",
	en = "[未翻译]有钱试试十连抽吧",
	zht = "有錢試試十連抽吧",
}
LocalizationConfig["loc_mission_PreDesc25"] =
{
	zh = "我们的科学家对这个绿油油星球有点兴趣，拿点资源回来研究一下吧",
	en = "[未翻译]我们的科学家对这个绿油油星球有点兴趣，拿点资源回来研究一下吧",
	zht = "我們的科學家對這個綠油油星球有點興趣，拿點資源回來研究一下吧",
}
LocalizationConfig["loc_mission_PreDesc26"] =
{
	zh = "我们做了不少小体力瓶，用掉点吧",
	en = "[未翻译]我们做了不少小体力瓶，用掉点吧",
	zht = "我們做了不少小體力瓶，用掉點吧",
}
LocalizationConfig["loc_mission_PreDesc27"] =
{
	zh = "我们的科学家对这个绿油油星球有点兴趣，拿点资源回来研究一下吧",
	en = "[未翻译]我们的科学家对这个绿油油星球有点兴趣，拿点资源回来研究一下吧",
	zht = "我們的科學家對這個綠油油星球有點興趣，拿點資源回來研究一下吧",
}
LocalizationConfig["loc_mission_PreDesc28"] =
{
	zh = "我们的队伍需要壮大",
	en = "[未翻译]我们的队伍需要壮大",
	zht = "我們的隊伍需要壯大",
}
LocalizationConfig["loc_mission_PreDesc29"] =
{
	zh = "我们的科学家对这个绿油油星球有点兴趣，拿点资源回来研究一下吧",
	en = "[未翻译]我们的科学家对这个绿油油星球有点兴趣，拿点资源回来研究一下吧",
	zht = "我們的科學家對這個綠油油星球有點興趣，拿點資源回來研究一下吧",
}
LocalizationConfig["loc_mission_PreDesc30"] =
{
	zh = "我们出门在外要有防身之物",
	en = "[未翻译]我们出门在外要有防身之物",
	zht = "我們出門在外要有防身之物",
}
LocalizationConfig["loc_mission_PreDesc31"] =
{
	zh = "我们的科学家对这个绿油油星球有点兴趣，拿点资源回来研究一下吧",
	en = "[未翻译]我们的科学家对这个绿油油星球有点兴趣，拿点资源回来研究一下吧",
	zht = "我們的科學家對這個綠油油星球有點興趣，拿點資源回來研究一下吧",
}
LocalizationConfig["loc_mission_PreDesc32"] =
{
	zh = "我们的队伍需要个更多给力的伙伴",
	en = "[未翻译]我们的队伍需要个更多给力的伙伴",
	zht = "我們的隊伍需要個更多給力的夥伴",
}
LocalizationConfig["loc_mission_PreDesc33"] =
{
	zh = "我们的科学家对这个绿油油星球有点兴趣，拿点资源回来研究一下吧",
	en = "[未翻译]我们的科学家对这个绿油油星球有点兴趣，拿点资源回来研究一下吧",
	zht = "我們的科學家對這個綠油油星球有點興趣，拿點資源回來研究一下吧",
}
LocalizationConfig["loc_mission_PreDesc34"] =
{
	zh = "我们的科学家对这个绿油油星球有点兴趣，拿点资源回来研究一下吧",
	en = "[未翻译]我们的科学家对这个绿油油星球有点兴趣，拿点资源回来研究一下吧",
	zht = "我們的科學家對這個綠油油星球有點興趣，拿點資源回來研究一下吧",
}
LocalizationConfig["loc_mission_PreDesc35"] =
{
	zh = "我们的科学家对这个绿油油星球有点兴趣，拿点资源回来研究一下吧",
	en = "[未翻译]我们的科学家对这个绿油油星球有点兴趣，拿点资源回来研究一下吧",
	zht = "我們的科學家對這個綠油油星球有點興趣，拿點資源回來研究一下吧",
}
LocalizationConfig["loc_mission_PreDesc36"] =
{
	zh = "我们的队伍需要个更多给力的伙伴",
	en = "[未翻译]我们的队伍需要个更多给力的伙伴",
	zht = "我們的隊伍需要個更多給力的夥伴",
}
LocalizationConfig["loc_mission_PreDesc37"] =
{
	zh = "我们的队伍需要个更多实用的装备",
	en = "[未翻译]我们的队伍需要个更多实用的装备",
	zht = "我們的隊伍需要個更多實用的裝備",
}
LocalizationConfig["loc_mission_PreDesc38"] =
{
	zh = "我们的科学家对这个绿油油星球有点兴趣，拿点资源回来研究一下吧",
	en = "[未翻译]我们的科学家对这个绿油油星球有点兴趣，拿点资源回来研究一下吧",
	zht = "我們的科學家對這個綠油油星球有點興趣，拿點資源回來研究一下吧",
}
LocalizationConfig["loc_mission_PreDesc39"] =
{
	zh = "我们的科学家对这个绿油油星球有点兴趣，拿点资源回来研究一下吧",
	en = "[未翻译]我们的科学家对这个绿油油星球有点兴趣，拿点资源回来研究一下吧",
	zht = "我們的科學家對這個綠油油星球有點興趣，拿點資源回來研究一下吧",
}
LocalizationConfig["loc_mission_PreDesc40"] =
{
	zh = "我们的队伍需要个更多高等级的队员",
	en = "[未翻译]我们的队伍需要个更多高等级的队员",
	zht = "我們的隊伍需要個更多高等級的隊員",
}
LocalizationConfig["loc_mission_PreDesc41"] =
{
	zh = "我们的科学家对这个绿油油星球有点兴趣，拿点资源回来研究一下吧",
	en = "[未翻译]我们的科学家对这个绿油油星球有点兴趣，拿点资源回来研究一下吧",
	zht = "我們的科學家對這個綠油油星球有點興趣，拿點資源回來研究一下吧",
}
LocalizationConfig["loc_mission_PreDesc42"] =
{
	zh = "我们的队伍需要个更多有用的道具",
	en = "[未翻译]我们的队伍需要个更多有用的道具",
	zht = "我們的隊伍需要個更多有用的道具",
}
LocalizationConfig["loc_mission_PreDesc43"] =
{
	zh = "我们的科学家对这个绿油油星球有点兴趣，拿点资源回来研究一下吧",
	en = "[未翻译]我们的科学家对这个绿油油星球有点兴趣，拿点资源回来研究一下吧",
	zht = "我們的科學家對這個綠油油星球有點興趣，拿點資源回來研究一下吧",
}
LocalizationConfig["loc_mission_PreDesc44"] =
{
	zh = "好像来到一个甜甜腻腻的星球，那边有个清爽的帅哥，去看看",
	en = "[未翻译]好像来到一个甜甜腻腻的星球，那边有个清爽的帅哥，去看看",
	zht = "好像來到一個甜甜膩膩的星球，那邊有個清爽的帥哥，去看看",
}
LocalizationConfig["loc_mission_PreDesc45"] =
{
	zh = "他们说要一起去找公主，那我们去说服另外一个吧",
	en = "[未翻译]他们说要一起去找公主，那我们去说服另外一个吧",
	zht = "他們說要一起去找公主，那我們去說服另外一個吧",
}
LocalizationConfig["loc_mission_PreDesc46"] =
{
	zh = "线索在小朋友手里，给他点糖吃不知道行不行",
	en = "[未翻译]线索在小朋友手里，给他点糖吃不知道行不行",
	zht = "線索在小朋友手裡，給他點糖吃不知道行不行",
}
LocalizationConfig["loc_mission_PreDesc47"] =
{
	zh = "得拜托这个星球的侍卫队长调一下监控了",
	en = "[未翻译]得拜托这个星球的侍卫队长调一下监控了",
	zht = "得拜託這個星球的侍衛隊長調一下監控了",
}
LocalizationConfig["loc_mission_PreDesc48"] =
{
	zh = "女仆小姐姐应该知道棉花糖公主的去处",
	en = "[未翻译]女仆小姐姐应该知道棉花糖公主的去处",
	zht = "女僕小姐姐應該知道棉花糖公主的去處",
}
LocalizationConfig["loc_mission_PreDesc49"] =
{
	zh = "先救回小姐，再去惩治坏人吧",
	en = "[未翻译]先救回小姐，再去惩治坏人吧",
	zht = "先救回小姐，再去懲治壞人吧",
}
LocalizationConfig["loc_mission_PreDesc50"] =
{
	zh = "女巫使用了魔咒，去找女巫解除吧",
	en = "[未翻译]女巫使用了魔咒，去找女巫解除吧",
	zht = "女巫使用了魔咒，去找女巫解除吧",
}
LocalizationConfig["loc_mission_PreDesc51"] =
{
	zh = "一切都是黑衣皇后干的好事，去战胜她吧",
	en = "[未翻译]一切都是黑衣皇后干的好事，去战胜她吧",
	zht = "一切都是黑衣皇后幹的好事，去戰勝她吧",
}
LocalizationConfig["loc_mission_PreDesc52"] =
{
	zh = "干的不错，不过你的欠款还有很多",
	en = "[未翻译]干的不错，不过你的欠款还有很多",
	zht = "幹的不錯，不過你的欠款還有很多",
}
LocalizationConfig["loc_mission_PreDesc53"] =
{
	zh = "我们的厨师对这个甜蜜蜜星球有点兴趣，你先多逛逛",
	en = "[未翻译]我们的厨师对这个甜蜜蜜星球有点兴趣，你先多逛逛",
	zht = "我們的廚師對這個甜蜜蜜星球有點興趣，你先多逛逛",
}
LocalizationConfig["loc_mission_PreDesc54"] =
{
	zh = "我们的厨师对这个甜蜜蜜星球有点兴趣，你先多逛逛",
	en = "[未翻译]我们的厨师对这个甜蜜蜜星球有点兴趣，你先多逛逛",
	zht = "我們的廚師對這個甜蜜蜜星球有點興趣，你先多逛逛",
}
LocalizationConfig["loc_mission_PreDesc55"] =
{
	zh = "我们的厨师对这个甜蜜蜜星球有点兴趣，你先多逛逛",
	en = "[未翻译]我们的厨师对这个甜蜜蜜星球有点兴趣，你先多逛逛",
	zht = "我們的廚師對這個甜蜜蜜星球有點興趣，你先多逛逛",
}
LocalizationConfig["loc_mission_PreDesc56"] =
{
	zh = "我们的厨师对这个甜蜜蜜星球有点兴趣，你先多逛逛",
	en = "[未翻译]我们的厨师对这个甜蜜蜜星球有点兴趣，你先多逛逛",
	zht = "我們的廚師對這個甜蜜蜜星球有點興趣，你先多逛逛",
}
LocalizationConfig["loc_mission_PreDesc57"] =
{
	zh = "我们的厨师对这个甜蜜蜜星球有点兴趣，你先多逛逛",
	en = "[未翻译]我们的厨师对这个甜蜜蜜星球有点兴趣，你先多逛逛",
	zht = "我們的廚師對這個甜蜜蜜星球有點興趣，你先多逛逛",
}
LocalizationConfig["loc_mission_PreDesc58"] =
{
	zh = "我们的厨师对这个甜蜜蜜星球有点兴趣，你先多逛逛",
	en = "[未翻译]我们的厨师对这个甜蜜蜜星球有点兴趣，你先多逛逛",
	zht = "我們的廚師對這個甜蜜蜜星球有點興趣，你先多逛逛",
}
LocalizationConfig["loc_mission_PreDesc59"] =
{
	zh = "我们的厨师对这个甜蜜蜜星球有点兴趣，拿点资源回来研究一下吧",
	en = "[未翻译]我们的厨师对这个甜蜜蜜星球有点兴趣，拿点资源回来研究一下吧",
	zht = "我們的廚師對這個甜蜜蜜星球有點興趣，拿點資源回來研究一下吧",
}
LocalizationConfig["loc_mission_PreDesc60"] =
{
	zh = "我们的厨师对这个甜蜜蜜星球有点兴趣，拿点资源回来研究一下吧",
	en = "[未翻译]我们的厨师对这个甜蜜蜜星球有点兴趣，拿点资源回来研究一下吧",
	zht = "我們的廚師對這個甜蜜蜜星球有點興趣，拿點資源回來研究一下吧",
}
LocalizationConfig["loc_mission_PreDesc61"] =
{
	zh = "我们的厨师对这个甜蜜蜜星球有点兴趣，拿点资源回来研究一下吧",
	en = "[未翻译]我们的厨师对这个甜蜜蜜星球有点兴趣，拿点资源回来研究一下吧",
	zht = "我們的廚師對這個甜蜜蜜星球有點興趣，拿點資源回來研究一下吧",
}
LocalizationConfig["loc_mission_PreDesc62"] =
{
	zh = "我们的厨师对这个甜蜜蜜星球有点兴趣，拿点资源回来研究一下吧",
	en = "[未翻译]我们的厨师对这个甜蜜蜜星球有点兴趣，拿点资源回来研究一下吧",
	zht = "我們的廚師對這個甜蜜蜜星球有點興趣，拿點資源回來研究一下吧",
}
LocalizationConfig["loc_mission_PreDesc63"] =
{
	zh = "我们的厨师对这个甜蜜蜜星球有点兴趣，拿点资源回来研究一下吧",
	en = "[未翻译]我们的厨师对这个甜蜜蜜星球有点兴趣，拿点资源回来研究一下吧",
	zht = "我們的廚師對這個甜蜜蜜星球有點興趣，拿點資源回來研究一下吧",
}
LocalizationConfig["loc_mission_PreDesc64"] =
{
	zh = "我们的厨师对这个甜蜜蜜星球有点兴趣，拿点资源回来研究一下吧",
	en = "[未翻译]我们的厨师对这个甜蜜蜜星球有点兴趣，拿点资源回来研究一下吧",
	zht = "我們的廚師對這個甜蜜蜜星球有點興趣，拿點資源回來研究一下吧",
}
LocalizationConfig["loc_mission_PreDesc65"] =
{
	zh = "我们的厨师对这个甜蜜蜜星球有点兴趣，拿点资源回来研究一下吧",
	en = "[未翻译]我们的厨师对这个甜蜜蜜星球有点兴趣，拿点资源回来研究一下吧",
	zht = "我們的廚師對這個甜蜜蜜星球有點興趣，拿點資源回來研究一下吧",
}
LocalizationConfig["loc_mission_PreDesc66"] =
{
	zh = "我们的厨师对这个甜蜜蜜星球有点兴趣，拿点资源回来研究一下吧",
	en = "[未翻译]我们的厨师对这个甜蜜蜜星球有点兴趣，拿点资源回来研究一下吧",
	zht = "我們的廚師對這個甜蜜蜜星球有點興趣，拿點資源回來研究一下吧",
}
LocalizationConfig["loc_mission_PreDesc67"] =
{
	zh = "我们的厨师对这个甜蜜蜜星球有点兴趣，拿点资源回来研究一下吧",
	en = "[未翻译]我们的厨师对这个甜蜜蜜星球有点兴趣，拿点资源回来研究一下吧",
	zht = "我們的廚師對這個甜蜜蜜星球有點興趣，拿點資源回來研究一下吧",
}
LocalizationConfig["loc_mission_PreDesc68"] =
{
	zh = "我们的厨师对这个甜蜜蜜星球有点兴趣，拿点资源回来研究一下吧",
	en = "[未翻译]我们的厨师对这个甜蜜蜜星球有点兴趣，拿点资源回来研究一下吧",
	zht = "我們的廚師對這個甜蜜蜜星球有點興趣，拿點資源回來研究一下吧",
}
LocalizationConfig["loc_mission_PreDesc69"] =
{
	zh = "我们的厨师对这个甜蜜蜜星球有点兴趣，拿点资源回来研究一下吧",
	en = "[未翻译]我们的厨师对这个甜蜜蜜星球有点兴趣，拿点资源回来研究一下吧",
	zht = "我們的廚師對這個甜蜜蜜星球有點興趣，拿點資源回來研究一下吧",
}
LocalizationConfig["loc_mission_PreDesc70"] =
{
	zh = "我们的厨师对这个甜蜜蜜星球有点兴趣，拿点资源回来研究一下吧",
	en = "[未翻译]我们的厨师对这个甜蜜蜜星球有点兴趣，拿点资源回来研究一下吧",
	zht = "我們的廚師對這個甜蜜蜜星球有點興趣，拿點資源回來研究一下吧",
}
LocalizationConfig["loc_mission_PreDesc71"] =
{
	zh = "我们的厨师对这个甜蜜蜜星球有点兴趣，拿点资源回来研究一下吧",
	en = "[未翻译]我们的厨师对这个甜蜜蜜星球有点兴趣，拿点资源回来研究一下吧",
	zht = "我們的廚師對這個甜蜜蜜星球有點興趣，拿點資源回來研究一下吧",
}
LocalizationConfig["loc_mission_PreDesc72"] =
{
	zh = "我们的厨师对这个甜蜜蜜星球有点兴趣，拿点资源回来研究一下吧",
	en = "[未翻译]我们的厨师对这个甜蜜蜜星球有点兴趣，拿点资源回来研究一下吧",
	zht = "我們的廚師對這個甜蜜蜜星球有點興趣，拿點資源回來研究一下吧",
}
LocalizationConfig["loc_mission_PreDesc73"] =
{
	zh = "我们的厨师对这个甜蜜蜜星球有点兴趣，拿点资源回来研究一下吧",
	en = "[未翻译]我们的厨师对这个甜蜜蜜星球有点兴趣，拿点资源回来研究一下吧",
	zht = "我們的廚師對這個甜蜜蜜星球有點興趣，拿點資源回來研究一下吧",
}
LocalizationConfig["loc_mission_PreDesc74"] =
{
	zh = "我们的厨师对这个甜蜜蜜星球有点兴趣，拿点资源回来研究一下吧",
	en = "[未翻译]我们的厨师对这个甜蜜蜜星球有点兴趣，拿点资源回来研究一下吧",
	zht = "我們的廚師對這個甜蜜蜜星球有點興趣，拿點資源回來研究一下吧",
}
LocalizationConfig["loc_mission_PreDesc75"] =
{
	zh = "我们的厨师对这个甜蜜蜜星球有点兴趣，拿点资源回来研究一下吧",
	en = "[未翻译]我们的厨师对这个甜蜜蜜星球有点兴趣，拿点资源回来研究一下吧",
	zht = "我們的廚師對這個甜蜜蜜星球有點興趣，拿點資源回來研究一下吧",
}
LocalizationConfig["loc_mission_PreDesc76"] =
{
	zh = "我们的厨师对这个甜蜜蜜星球有点兴趣，拿点资源回来研究一下吧",
	en = "[未翻译]我们的厨师对这个甜蜜蜜星球有点兴趣，拿点资源回来研究一下吧",
	zht = "我們的廚師對這個甜蜜蜜星球有點興趣，拿點資源回來研究一下吧",
}
LocalizationConfig["loc_mission_PreDesc77"] =
{
	zh = "我们的厨师对这个甜蜜蜜星球有点兴趣，拿点资源回来研究一下吧",
	en = "[未翻译]我们的厨师对这个甜蜜蜜星球有点兴趣，拿点资源回来研究一下吧",
	zht = "我們的廚師對這個甜蜜蜜星球有點興趣，拿點資源回來研究一下吧",
}
LocalizationConfig["loc_mission_PreDesc78"] =
{
	zh = "我们的厨师对这个甜蜜蜜星球有点兴趣，拿点资源回来研究一下吧",
	en = "[未翻译]我们的厨师对这个甜蜜蜜星球有点兴趣，拿点资源回来研究一下吧",
	zht = "我們的廚師對這個甜蜜蜜星球有點興趣，拿點資源回來研究一下吧",
}
LocalizationConfig["loc_mission_PreDesc79"] =
{
	zh = "这个星球满是灰尘，要不是有个活人还以为被抛弃了呢",
	en = "[未翻译]这个星球满是灰尘，要不是有个活人还以为被抛弃了呢",
	zht = "這個星球滿是灰塵，要不是有個活人還以為被拋棄了呢",
}
LocalizationConfig["loc_mission_PreDesc80"] =
{
	zh = "鬼鬼祟祟的小鬼，先抓了不会错",
	en = "[未翻译]鬼鬼祟祟的小鬼，先抓了不会错",
	zht = "鬼鬼祟祟的小鬼，先抓了不會錯",
}
LocalizationConfig["loc_mission_PreDesc81"] =
{
	zh = "去埃及馆的话，要过了里面的各位看门人呢",
	en = "[未翻译]去埃及馆的话，要过了里面的各位看门人呢",
	zht = "去埃及館的話，要過了裡面的各位看門人呢",
}
LocalizationConfig["loc_mission_PreDesc82"] =
{
	zh = "铠甲会动？它敢动一下我咬它",
	en = "[未翻译]铠甲会动？它敢动一下我咬它",
	zht = "鎧甲會動？它敢動一下我咬它",
}
LocalizationConfig["loc_mission_PreDesc83"] =
{
	zh = "看看是迷路的小姑娘还是隐藏的大盗",
	en = "[未翻译]看看是迷路的小姑娘还是隐藏的大盗",
	zht = "看看是迷路的小姑娘還是隱藏的大盜",
}
LocalizationConfig["loc_mission_PreDesc84"] =
{
	zh = "这次听我的信息，肯定是没的错了",
	en = "[未翻译]这次听我的信息，肯定是没的错了",
	zht = "這次聽我的資訊，肯定是沒的錯了",
}
LocalizationConfig["loc_mission_PreDesc85"] =
{
	zh = "既然知道微笑女神的位置了，赶紧去救人出来",
	en = "[未翻译]既然知道微笑女神的位置了，赶紧去救人出来",
	zht = "既然知道微笑女神的位置了，趕緊去救人出來",
}
LocalizationConfig["loc_mission_PreDesc86"] =
{
	zh = "为了弄清楚大盗的真正目的，唯有亲自审问",
	en = "[未翻译]为了弄清楚大盗的真正目的，唯有亲自审问",
	zht = "為了弄清楚大盜的真正目的，唯有親自審問",
}
LocalizationConfig["loc_mission_PreDesc87"] =
{
	zh = "早点还清欠款早点回家咯",
	en = "[未翻译]早点还清欠款早点回家咯",
	zht = "早點還清欠款早點回家咯",
}
LocalizationConfig["loc_mission_PreDesc88"] =
{
	zh = "我们的学者对这个破烂烂星球有点兴趣，你先多逛逛",
	en = "[未翻译]我们的学者对这个破烂烂星球有点兴趣，你先多逛逛",
	zht = "我們的學者對這個破爛爛星球有點興趣，你先多逛逛",
}
LocalizationConfig["loc_mission_PreDesc89"] =
{
	zh = "我们的学者对这个破烂烂星球有点兴趣，你先多逛逛",
	en = "[未翻译]我们的学者对这个破烂烂星球有点兴趣，你先多逛逛",
	zht = "我們的學者對這個破爛爛星球有點興趣，你先多逛逛",
}
LocalizationConfig["loc_mission_PreDesc90"] =
{
	zh = "我们的学者对这个破烂烂星球有点兴趣，你先多逛逛",
	en = "[未翻译]我们的学者对这个破烂烂星球有点兴趣，你先多逛逛",
	zht = "我們的學者對這個破爛爛星球有點興趣，你先多逛逛",
}
LocalizationConfig["loc_mission_PreDesc91"] =
{
	zh = "我们的学者对这个破烂烂星球有点兴趣，你先多逛逛",
	en = "[未翻译]我们的学者对这个破烂烂星球有点兴趣，你先多逛逛",
	zht = "我們的學者對這個破爛爛星球有點興趣，你先多逛逛",
}
LocalizationConfig["loc_mission_PreDesc92"] =
{
	zh = "我们的学者对这个破烂烂星球有点兴趣，你先多逛逛",
	en = "[未翻译]我们的学者对这个破烂烂星球有点兴趣，你先多逛逛",
	zht = "我們的學者對這個破爛爛星球有點興趣，你先多逛逛",
}
LocalizationConfig["loc_mission_PreDesc93"] =
{
	zh = "我们的学者对这个破烂烂星球有点兴趣，你先多逛逛",
	en = "[未翻译]我们的学者对这个破烂烂星球有点兴趣，你先多逛逛",
	zht = "我們的學者對這個破爛爛星球有點興趣，你先多逛逛",
}
LocalizationConfig["loc_mission_PreDesc94"] =
{
	zh = "我们的学者对这个破烂烂星球有点兴趣，拿点资源回来研究一下吧",
	en = "[未翻译]我们的学者对这个破烂烂星球有点兴趣，拿点资源回来研究一下吧",
	zht = "我們的學者對這個破爛爛星球有點興趣，拿點資源回來研究一下吧",
}
LocalizationConfig["loc_mission_PreDesc95"] =
{
	zh = "我们的学者对这个破烂烂星球有点兴趣，拿点资源回来研究一下吧",
	en = "[未翻译]我们的学者对这个破烂烂星球有点兴趣，拿点资源回来研究一下吧",
	zht = "我們的學者對這個破爛爛星球有點興趣，拿點資源回來研究一下吧",
}
LocalizationConfig["loc_mission_PreDesc96"] =
{
	zh = "我们的学者对这个破烂烂星球有点兴趣，拿点资源回来研究一下吧",
	en = "[未翻译]我们的学者对这个破烂烂星球有点兴趣，拿点资源回来研究一下吧",
	zht = "我們的學者對這個破爛爛星球有點興趣，拿點資源回來研究一下吧",
}
LocalizationConfig["loc_mission_PreDesc97"] =
{
	zh = "我们的学者对这个破烂烂星球有点兴趣，拿点资源回来研究一下吧",
	en = "[未翻译]我们的学者对这个破烂烂星球有点兴趣，拿点资源回来研究一下吧",
	zht = "我們的學者對這個破爛爛星球有點興趣，拿點資源回來研究一下吧",
}
LocalizationConfig["loc_mission_PreDesc98"] =
{
	zh = "我们的学者对这个破烂烂星球有点兴趣，拿点资源回来研究一下吧",
	en = "[未翻译]我们的学者对这个破烂烂星球有点兴趣，拿点资源回来研究一下吧",
	zht = "我們的學者對這個破爛爛星球有點興趣，拿點資源回來研究一下吧",
}
LocalizationConfig["loc_mission_PreDesc99"] =
{
	zh = "我们的学者对这个破烂烂星球有点兴趣，拿点资源回来研究一下吧",
	en = "[未翻译]我们的学者对这个破烂烂星球有点兴趣，拿点资源回来研究一下吧",
	zht = "我們的學者對這個破爛爛星球有點興趣，拿點資源回來研究一下吧",
}
LocalizationConfig["loc_mission_PreDesc100"] =
{
	zh = "我们的学者对这个破烂烂星球有点兴趣，拿点资源回来研究一下吧",
	en = "[未翻译]我们的学者对这个破烂烂星球有点兴趣，拿点资源回来研究一下吧",
	zht = "我們的學者對這個破爛爛星球有點興趣，拿點資源回來研究一下吧",
}
LocalizationConfig["loc_mission_PreDesc101"] =
{
	zh = "我们的学者对这个破烂烂星球有点兴趣，拿点资源回来研究一下吧",
	en = "[未翻译]我们的学者对这个破烂烂星球有点兴趣，拿点资源回来研究一下吧",
	zht = "我們的學者對這個破爛爛星球有點興趣，拿點資源回來研究一下吧",
}
LocalizationConfig["loc_mission_PreDesc102"] =
{
	zh = "我们的学者对这个破烂烂星球有点兴趣，拿点资源回来研究一下吧",
	en = "[未翻译]我们的学者对这个破烂烂星球有点兴趣，拿点资源回来研究一下吧",
	zht = "我們的學者對這個破爛爛星球有點興趣，拿點資源回來研究一下吧",
}
LocalizationConfig["loc_mission_PreDesc103"] =
{
	zh = "我们的学者对这个破烂烂星球有点兴趣，拿点资源回来研究一下吧",
	en = "[未翻译]我们的学者对这个破烂烂星球有点兴趣，拿点资源回来研究一下吧",
	zht = "我們的學者對這個破爛爛星球有點興趣，拿點資源回來研究一下吧",
}
LocalizationConfig["loc_mission_PreDesc104"] =
{
	zh = "我们的学者对这个破烂烂星球有点兴趣，拿点资源回来研究一下吧",
	en = "[未翻译]我们的学者对这个破烂烂星球有点兴趣，拿点资源回来研究一下吧",
	zht = "我們的學者對這個破爛爛星球有點興趣，拿點資源回來研究一下吧",
}
LocalizationConfig["loc_mission_PreDesc105"] =
{
	zh = "我们的学者对这个破烂烂星球有点兴趣，拿点资源回来研究一下吧",
	en = "[未翻译]我们的学者对这个破烂烂星球有点兴趣，拿点资源回来研究一下吧",
	zht = "我們的學者對這個破爛爛星球有點興趣，拿點資源回來研究一下吧",
}
LocalizationConfig["loc_mission_PreDesc106"] =
{
	zh = "我们的学者对这个破烂烂星球有点兴趣，拿点资源回来研究一下吧",
	en = "[未翻译]我们的学者对这个破烂烂星球有点兴趣，拿点资源回来研究一下吧",
	zht = "我們的學者對這個破爛爛星球有點興趣，拿點資源回來研究一下吧",
}
LocalizationConfig["loc_mission_PreDesc107"] =
{
	zh = "我们的学者对这个破烂烂星球有点兴趣，拿点资源回来研究一下吧",
	en = "[未翻译]我们的学者对这个破烂烂星球有点兴趣，拿点资源回来研究一下吧",
	zht = "我們的學者對這個破爛爛星球有點興趣，拿點資源回來研究一下吧",
}
LocalizationConfig["loc_mission_PreDesc108"] =
{
	zh = "我们的学者对这个破烂烂星球有点兴趣，拿点资源回来研究一下吧",
	en = "[未翻译]我们的学者对这个破烂烂星球有点兴趣，拿点资源回来研究一下吧",
	zht = "我們的學者對這個破爛爛星球有點興趣，拿點資源回來研究一下吧",
}
LocalizationConfig["loc_mission_PreDesc109"] =
{
	zh = "我们的学者对这个破烂烂星球有点兴趣，拿点资源回来研究一下吧",
	en = "[未翻译]我们的学者对这个破烂烂星球有点兴趣，拿点资源回来研究一下吧",
	zht = "我們的學者對這個破爛爛星球有點興趣，拿點資源回來研究一下吧",
}
LocalizationConfig["loc_mission_PreDesc110"] =
{
	zh = "我们的学者对这个破烂烂星球有点兴趣，拿点资源回来研究一下吧",
	en = "[未翻译]我们的学者对这个破烂烂星球有点兴趣，拿点资源回来研究一下吧",
	zht = "我們的學者對這個破爛爛星球有點興趣，拿點資源回來研究一下吧",
}
LocalizationConfig["loc_mission_PreDesc111"] =
{
	zh = "我们的学者对这个破烂烂星球有点兴趣，拿点资源回来研究一下吧",
	en = "[未翻译]我们的学者对这个破烂烂星球有点兴趣，拿点资源回来研究一下吧",
	zht = "我們的學者對這個破爛爛星球有點興趣，拿點資源回來研究一下吧",
}
LocalizationConfig["loc_mission_PreDesc112"] =
{
	zh = "我们看看这个星球有点啥",
	en = "[未翻译]我们看看这个星球有点啥",
	zht = "我們看看這個星球有點啥",
}
LocalizationConfig["loc_mission_PreDesc113"] =
{
	zh = "你要找线索啊，那边那个呆呆的医生，你们可以去问问呢",
	en = "[未翻译]你要找线索啊，那边那个呆呆的医生，你们可以去问问呢",
	zht = "你要找線索啊，那邊那個呆呆的醫生，你們可以去問問呢",
}
LocalizationConfig["loc_mission_PreDesc114"] =
{
	zh = "线索显示我们要去找看起来很倒霉的人",
	en = "[未翻译]线索显示我们要去找看起来很倒霉的人",
	zht = "線索顯示我們要去找看起來很倒楣的人",
}
LocalizationConfig["loc_mission_PreDesc115"] =
{
	zh = "据说他有一个脱氧核糖核酸数据库",
	en = "[未翻译]据说他有一个脱氧核糖核酸数据库",
	zht = "據說他有一個去氧核糖核酸資料庫",
}
LocalizationConfig["loc_mission_PreDesc116"] =
{
	zh = "找了很多线索还是没啥头绪，我们去找这里最厉害的侦探吧",
	en = "[未翻译]找了很多线索还是没啥头绪，我们去找这里最厉害的侦探吧",
	zht = "找了很多線索還是沒啥頭緒，我們去找這裡最厲害的偵探吧",
}
LocalizationConfig["loc_mission_PreDesc117"] =
{
	zh = "去找大侦探的哥哥问一问",
	en = "[未翻译]去找大侦探的哥哥问一问",
	zht = "去找大偵探的哥哥問一問",
}
LocalizationConfig["loc_mission_PreDesc118"] =
{
	zh = "听说有个小学生对凶手很了解",
	en = "[未翻译]听说有个小学生对凶手很了解",
	zht = "聽說有個小學生對凶手很瞭解",
}
LocalizationConfig["loc_mission_PreDesc119"] =
{
	zh = "去击败凶手，解放这个星球吧",
	en = "[未翻译]去击败凶手，解放这个星球吧",
	zht = "去擊敗凶手，解放這個星球吧",
}
LocalizationConfig["loc_mission_PreDesc120"] =
{
	zh = "国王可是超级生气呢",
	en = "[未翻译]国王可是超级生气呢",
	zht = "國王可是超級生氣呢",
}
LocalizationConfig["loc_mission_PreDesc121"] =
{
	zh = "我们的市民对这个阴森森星有点兴趣，你先多逛逛",
	en = "[未翻译]我们的市民对这个阴森森星有点兴趣，你先多逛逛",
	zht = "我們的市民對這個陰森森星有點興趣，你先多逛逛",
}
LocalizationConfig["loc_mission_PreDesc122"] =
{
	zh = "我们的市民对这个阴森森星有点兴趣，你先多逛逛",
	en = "[未翻译]我们的市民对这个阴森森星有点兴趣，你先多逛逛",
	zht = "我們的市民對這個陰森森星有點興趣，你先多逛逛",
}
LocalizationConfig["loc_mission_PreDesc123"] =
{
	zh = "我们的市民对这个阴森森星有点兴趣，你先多逛逛",
	en = "[未翻译]我们的市民对这个阴森森星有点兴趣，你先多逛逛",
	zht = "我們的市民對這個陰森森星有點興趣，你先多逛逛",
}
LocalizationConfig["loc_mission_PreDesc124"] =
{
	zh = "我们的市民对这个阴森森星有点兴趣，你先多逛逛",
	en = "[未翻译]我们的市民对这个阴森森星有点兴趣，你先多逛逛",
	zht = "我們的市民對這個陰森森星有點興趣，你先多逛逛",
}
LocalizationConfig["loc_mission_PreDesc125"] =
{
	zh = "我们的市民对这个阴森森星有点兴趣，你先多逛逛",
	en = "[未翻译]我们的市民对这个阴森森星有点兴趣，你先多逛逛",
	zht = "我們的市民對這個陰森森星有點興趣，你先多逛逛",
}
LocalizationConfig["loc_mission_PreDesc126"] =
{
	zh = "我们的市民对这个阴森森星有点兴趣，拿点资源回来研究一下吧",
	en = "[未翻译]我们的市民对这个阴森森星有点兴趣，拿点资源回来研究一下吧",
	zht = "我們的市民對這個陰森森星有點興趣，拿點資源回來研究一下吧",
}
LocalizationConfig["loc_mission_PreDesc127"] =
{
	zh = "我们的市民对这个阴森森星有点兴趣，拿点资源回来研究一下吧",
	en = "[未翻译]我们的市民对这个阴森森星有点兴趣，拿点资源回来研究一下吧",
	zht = "我們的市民對這個陰森森星有點興趣，拿點資源回來研究一下吧",
}
LocalizationConfig["loc_mission_PreDesc128"] =
{
	zh = "我们的市民对这个阴森森星有点兴趣，拿点资源回来研究一下吧",
	en = "[未翻译]我们的市民对这个阴森森星有点兴趣，拿点资源回来研究一下吧",
	zht = "我們的市民對這個陰森森星有點興趣，拿點資源回來研究一下吧",
}
LocalizationConfig["loc_mission_PreDesc129"] =
{
	zh = "我们的市民对这个阴森森星有点兴趣，拿点资源回来研究一下吧",
	en = "[未翻译]我们的市民对这个阴森森星有点兴趣，拿点资源回来研究一下吧",
	zht = "我們的市民對這個陰森森星有點興趣，拿點資源回來研究一下吧",
}
LocalizationConfig["loc_mission_PreDesc130"] =
{
	zh = "我们的市民对这个阴森森星有点兴趣，拿点资源回来研究一下吧",
	en = "[未翻译]我们的市民对这个阴森森星有点兴趣，拿点资源回来研究一下吧",
	zht = "我們的市民對這個陰森森星有點興趣，拿點資源回來研究一下吧",
}
LocalizationConfig["loc_mission_PreDesc131"] =
{
	zh = "我们的市民对这个阴森森星有点兴趣，拿点资源回来研究一下吧",
	en = "[未翻译]我们的市民对这个阴森森星有点兴趣，拿点资源回来研究一下吧",
	zht = "我們的市民對這個陰森森星有點興趣，拿點資源回來研究一下吧",
}
LocalizationConfig["loc_mission_PreDesc132"] =
{
	zh = "我们的市民对这个阴森森星有点兴趣，拿点资源回来研究一下吧",
	en = "[未翻译]我们的市民对这个阴森森星有点兴趣，拿点资源回来研究一下吧",
	zht = "我們的市民對這個陰森森星有點興趣，拿點資源回來研究一下吧",
}
LocalizationConfig["loc_mission_PreDesc133"] =
{
	zh = "我们的市民对这个阴森森星有点兴趣，拿点资源回来研究一下吧",
	en = "[未翻译]我们的市民对这个阴森森星有点兴趣，拿点资源回来研究一下吧",
	zht = "我們的市民對這個陰森森星有點興趣，拿點資源回來研究一下吧",
}
LocalizationConfig["loc_mission_PreDesc134"] =
{
	zh = "我们的市民对这个阴森森星有点兴趣，拿点资源回来研究一下吧",
	en = "[未翻译]我们的市民对这个阴森森星有点兴趣，拿点资源回来研究一下吧",
	zht = "我們的市民對這個陰森森星有點興趣，拿點資源回來研究一下吧",
}
LocalizationConfig["loc_mission_PreDesc135"] =
{
	zh = "我们的市民对这个阴森森星有点兴趣，拿点资源回来研究一下吧",
	en = "[未翻译]我们的市民对这个阴森森星有点兴趣，拿点资源回来研究一下吧",
	zht = "我們的市民對這個陰森森星有點興趣，拿點資源回來研究一下吧",
}
LocalizationConfig["loc_mission_PreDesc136"] =
{
	zh = "我们的市民对这个阴森森星有点兴趣，拿点资源回来研究一下吧",
	en = "[未翻译]我们的市民对这个阴森森星有点兴趣，拿点资源回来研究一下吧",
	zht = "我們的市民對這個陰森森星有點興趣，拿點資源回來研究一下吧",
}
LocalizationConfig["loc_mission_PreDesc137"] =
{
	zh = "我们的市民对这个阴森森星有点兴趣，拿点资源回来研究一下吧",
	en = "[未翻译]我们的市民对这个阴森森星有点兴趣，拿点资源回来研究一下吧",
	zht = "我們的市民對這個陰森森星有點興趣，拿點資源回來研究一下吧",
}
LocalizationConfig["loc_mission_PreDesc138"] =
{
	zh = "我们的市民对这个阴森森星有点兴趣，拿点资源回来研究一下吧",
	en = "[未翻译]我们的市民对这个阴森森星有点兴趣，拿点资源回来研究一下吧",
	zht = "我們的市民對這個陰森森星有點興趣，拿點資源回來研究一下吧",
}
LocalizationConfig["loc_mission_PreDesc139"] =
{
	zh = "我们的市民对这个阴森森星有点兴趣，拿点资源回来研究一下吧",
	en = "[未翻译]我们的市民对这个阴森森星有点兴趣，拿点资源回来研究一下吧",
	zht = "我們的市民對這個陰森森星有點興趣，拿點資源回來研究一下吧",
}
LocalizationConfig["loc_mission_PreDesc140"] =
{
	zh = "我们的市民对这个阴森森星有点兴趣，拿点资源回来研究一下吧",
	en = "[未翻译]我们的市民对这个阴森森星有点兴趣，拿点资源回来研究一下吧",
	zht = "我們的市民對這個陰森森星有點興趣，拿點資源回來研究一下吧",
}
LocalizationConfig["loc_mission_PreDesc141"] =
{
	zh = "我们的市民对这个阴森森星有点兴趣，拿点资源回来研究一下吧",
	en = "[未翻译]我们的市民对这个阴森森星有点兴趣，拿点资源回来研究一下吧",
	zht = "我們的市民對這個陰森森星有點興趣，拿點資源回來研究一下吧",
}
LocalizationConfig["loc_mission_Desc1"] =
{
	zh = "击败{Value}",
	en = "[未翻译]击败{Value}",
	zht = "擊敗{Value}",
}
LocalizationConfig["loc_mission_Desc2"] =
{
	zh = "击败{Value}",
	en = "[未翻译]击败{Value}",
	zht = "擊敗{Value}",
}
LocalizationConfig["loc_mission_Desc3"] =
{
	zh = "售卖{Value}{Num}个",
	en = "[未翻译]售卖{Value}{Num}个",
	zht = "售賣{Value}{Num}個",
}
LocalizationConfig["loc_mission_Desc4"] =
{
	zh = "升级{Value}到{Level}级",
	en = "[未翻译]升级{Value}到{Level}级",
	zht = "升級{Value}到{Level}級",
}
LocalizationConfig["loc_mission_Desc5"] =
{
	zh = "击败{Value}",
	en = "[未翻译]击败{Value}",
	zht = "擊敗{Value}",
}
LocalizationConfig["loc_mission_Desc6"] =
{
	zh = "击败{Value}",
	en = "[未翻译]击败{Value}",
	zht = "擊敗{Value}",
}
LocalizationConfig["loc_mission_Desc7"] =
{
	zh = "升级{Value}到{Level}级",
	en = "[未翻译]升级{Value}到{Level}级",
	zht = "升級{Value}到{Level}級",
}
LocalizationConfig["loc_mission_Desc8"] =
{
	zh = "击败{Value}",
	en = "[未翻译]击败{Value}",
	zht = "擊敗{Value}",
}
LocalizationConfig["loc_mission_Desc9"] =
{
	zh = "击败{Value}",
	en = "[未翻译]击败{Value}",
	zht = "擊敗{Value}",
}
LocalizationConfig["loc_mission_Desc10"] =
{
	zh = "击败{Value}",
	en = "[未翻译]击败{Value}",
	zht = "擊敗{Value}",
}
LocalizationConfig["loc_mission_Desc11"] =
{
	zh = "击败{Value}",
	en = "[未翻译]击败{Value}",
	zht = "擊敗{Value}",
}
LocalizationConfig["loc_mission_Desc12"] =
{
	zh = "提交{Num}个金币",
	en = "[未翻译]提交{Num}个金币",
	zht = "提交{Num}個金幣",
}
LocalizationConfig["loc_mission_Desc13"] =
{
	zh = "探索{Value}{Num}次",
	en = "[未翻译]探索{Value}{Num}次",
	zht = "探索{Value}{Num}次",
}
LocalizationConfig["loc_mission_Desc14"] =
{
	zh = "探索{Value}{Num}小时",
	en = "[未翻译]探索{Value}{Num}小时",
	zht = "探索{Value}{Num}小時",
}
LocalizationConfig["loc_mission_Desc15"] =
{
	zh = "使用{Character}探索{Value}{Num}次",
	en = "[未翻译]使用{Character}探索{Value}{Num}次",
	zht = "使用{Character}探索{Value}{Num}次",
}
LocalizationConfig["loc_mission_Desc16"] =
{
	zh = "探索{Value}{Num}次",
	en = "[未翻译]探索{Value}{Num}次",
	zht = "探索{Value}{Num}次",
}
LocalizationConfig["loc_mission_Desc17"] =
{
	zh = "探索获得道具{Num}个",
	en = "[未翻译]探索获得道具{Num}个",
	zht = "探索獲得道具{Num}個",
}
LocalizationConfig["loc_mission_Desc18"] =
{
	zh = "探索{Value}{Num}次",
	en = "[未翻译]探索{Value}{Num}次",
	zht = "探索{Value}{Num}次",
}
LocalizationConfig["loc_mission_Desc19"] =
{
	zh = "探索{Value}{Num}次",
	en = "[未翻译]探索{Value}{Num}次",
	zht = "探索{Value}{Num}次",
}
LocalizationConfig["loc_mission_Desc20"] =
{
	zh = "售卖获得{Num}个{Value}",
	en = "[未翻译]售卖获得{Num}个{Value}",
	zht = "售賣獲得{Num}個{Value}",
}
LocalizationConfig["loc_mission_Desc21"] =
{
	zh = "售卖获得{Num}个{Value}",
	en = "[未翻译]售卖获得{Num}个{Value}",
	zht = "售賣獲得{Num}個{Value}",
}
LocalizationConfig["loc_mission_Desc22"] =
{
	zh = "售卖获得{Num}个{Value}",
	en = "[未翻译]售卖获得{Num}个{Value}",
	zht = "售賣獲得{Num}個{Value}",
}
LocalizationConfig["loc_mission_Desc23"] =
{
	zh = "提交{Value}{Num}个",
	en = "[未翻译]提交{Value}{Num}个",
	zht = "提交{Value}{Num}個",
}
LocalizationConfig["loc_mission_Desc24"] =
{
	zh = "获得伙伴{Value}",
	en = "[未翻译]获得伙伴{Value}",
	zht = "獲得夥伴{Value}",
}
LocalizationConfig["loc_mission_Desc25"] =
{
	zh = "提交{Value}{Num}个",
	en = "[未翻译]提交{Value}{Num}个",
	zht = "提交{Value}{Num}個",
}
LocalizationConfig["loc_mission_Desc26"] =
{
	zh = "合成消耗{Value}{Num}个",
	en = "[未翻译]合成消耗{Value}{Num}个",
	zht = "合成消耗{Value}{Num}個",
}
LocalizationConfig["loc_mission_Desc27"] =
{
	zh = "提交{Value}{Num}个",
	en = "[未翻译]提交{Value}{Num}个",
	zht = "提交{Value}{Num}個",
}
LocalizationConfig["loc_mission_Desc28"] =
{
	zh = "拥有角色{Num}个",
	en = "[未翻译]拥有角色{Num}个",
	zht = "擁有角色{Num}個",
}
LocalizationConfig["loc_mission_Desc29"] =
{
	zh = "提交{Value}{Num}个",
	en = "[未翻译]提交{Value}{Num}个",
	zht = "提交{Value}{Num}個",
}
LocalizationConfig["loc_mission_Desc30"] =
{
	zh = "拥有{Value}{Num}个",
	en = "[未翻译]拥有{Value}{Num}个",
	zht = "擁有{Value}{Num}個",
}
LocalizationConfig["loc_mission_Desc31"] =
{
	zh = "提交{Value}{Num}个",
	en = "[未翻译]提交{Value}{Num}个",
	zht = "提交{Value}{Num}個",
}
LocalizationConfig["loc_mission_Desc32"] =
{
	zh = "给{Character}装备{Value}",
	en = "[未翻译]给{Character}装备{Value}",
	zht = "給{Character}裝備{Value}",
}
LocalizationConfig["loc_mission_Desc33"] =
{
	zh = "提交{Value}{Num}个",
	en = "[未翻译]提交{Value}{Num}个",
	zht = "提交{Value}{Num}個",
}
LocalizationConfig["loc_mission_Desc34"] =
{
	zh = "提交{Value}{Num}个",
	en = "[未翻译]提交{Value}{Num}个",
	zht = "提交{Value}{Num}個",
}
LocalizationConfig["loc_mission_Desc35"] =
{
	zh = "提交{Value}{Num}个",
	en = "[未翻译]提交{Value}{Num}个",
	zht = "提交{Value}{Num}個",
}
LocalizationConfig["loc_mission_Desc36"] =
{
	zh = "给{Character}装备{Value}",
	en = "[未翻译]给{Character}装备{Value}",
	zht = "給{Character}裝備{Value}",
}
LocalizationConfig["loc_mission_Desc37"] =
{
	zh = "合成获得{Value}{Num}个",
	en = "[未翻译]合成获得{Value}{Num}个",
	zht = "合成獲得{Value}{Num}個",
}
LocalizationConfig["loc_mission_Desc38"] =
{
	zh = "提交{Value}{Num}个",
	en = "[未翻译]提交{Value}{Num}个",
	zht = "提交{Value}{Num}個",
}
LocalizationConfig["loc_mission_Desc39"] =
{
	zh = "提交{Value}{Num}个",
	en = "[未翻译]提交{Value}{Num}个",
	zht = "提交{Value}{Num}個",
}
LocalizationConfig["loc_mission_Desc40"] =
{
	zh = "拥有{Level}级角色{Num}个",
	en = "[未翻译]拥有{Level}级角色{Num}个",
	zht = "擁有{Level}級角色{Num}個",
}
LocalizationConfig["loc_mission_Desc41"] =
{
	zh = "提交{Value}{Num}个",
	en = "[未翻译]提交{Value}{Num}个",
	zht = "提交{Value}{Num}個",
}
LocalizationConfig["loc_mission_Desc42"] =
{
	zh = "拥有{Ability}属性的道具{Num}种",
	en = "[未翻译]拥有{Ability}属性的道具{Num}种",
	zht = "擁有{Ability}屬性的道具{Num}種",
}
LocalizationConfig["loc_mission_Desc43"] =
{
	zh = "提交{Value}{Num}个",
	en = "[未翻译]提交{Value}{Num}个",
	zht = "提交{Value}{Num}個",
}
LocalizationConfig["loc_mission_Desc44"] =
{
	zh = "击败{Value}",
	en = "[未翻译]击败{Value}",
	zht = "擊敗{Value}",
}
LocalizationConfig["loc_mission_Desc45"] =
{
	zh = "击败{Value}",
	en = "[未翻译]击败{Value}",
	zht = "擊敗{Value}",
}
LocalizationConfig["loc_mission_Desc46"] =
{
	zh = "击败{Value}",
	en = "[未翻译]击败{Value}",
	zht = "擊敗{Value}",
}
LocalizationConfig["loc_mission_Desc47"] =
{
	zh = "击败{Value}",
	en = "[未翻译]击败{Value}",
	zht = "擊敗{Value}",
}
LocalizationConfig["loc_mission_Desc48"] =
{
	zh = "击败{Value}",
	en = "[未翻译]击败{Value}",
	zht = "擊敗{Value}",
}
LocalizationConfig["loc_mission_Desc49"] =
{
	zh = "击败{Value}",
	en = "[未翻译]击败{Value}",
	zht = "擊敗{Value}",
}
LocalizationConfig["loc_mission_Desc50"] =
{
	zh = "击败{Value}",
	en = "[未翻译]击败{Value}",
	zht = "擊敗{Value}",
}
LocalizationConfig["loc_mission_Desc51"] =
{
	zh = "击败{Value}",
	en = "[未翻译]击败{Value}",
	zht = "擊敗{Value}",
}
LocalizationConfig["loc_mission_Desc52"] =
{
	zh = "提交{Num}个金币",
	en = "[未翻译]提交{Num}个金币",
	zht = "提交{Num}個金幣",
}
LocalizationConfig["loc_mission_Desc53"] =
{
	zh = "探索{Value}{Num}次",
	en = "[未翻译]探索{Value}{Num}次",
	zht = "探索{Value}{Num}次",
}
LocalizationConfig["loc_mission_Desc54"] =
{
	zh = "探索{Value}{Num}次",
	en = "[未翻译]探索{Value}{Num}次",
	zht = "探索{Value}{Num}次",
}
LocalizationConfig["loc_mission_Desc55"] =
{
	zh = "探索{Value}{Num}次",
	en = "[未翻译]探索{Value}{Num}次",
	zht = "探索{Value}{Num}次",
}
LocalizationConfig["loc_mission_Desc56"] =
{
	zh = "探索{Value}{Num}次",
	en = "[未翻译]探索{Value}{Num}次",
	zht = "探索{Value}{Num}次",
}
LocalizationConfig["loc_mission_Desc57"] =
{
	zh = "探索{Value}{Num}次",
	en = "[未翻译]探索{Value}{Num}次",
	zht = "探索{Value}{Num}次",
}
LocalizationConfig["loc_mission_Desc58"] =
{
	zh = "探索{Value}{Num}次",
	en = "[未翻译]探索{Value}{Num}次",
	zht = "探索{Value}{Num}次",
}
LocalizationConfig["loc_mission_Desc59"] =
{
	zh = "提交{Value}{Num}个",
	en = "[未翻译]提交{Value}{Num}个",
	zht = "提交{Value}{Num}個",
}
LocalizationConfig["loc_mission_Desc60"] =
{
	zh = "提交{Value}{Num}个",
	en = "[未翻译]提交{Value}{Num}个",
	zht = "提交{Value}{Num}個",
}
LocalizationConfig["loc_mission_Desc61"] =
{
	zh = "提交{Value}{Num}个",
	en = "[未翻译]提交{Value}{Num}个",
	zht = "提交{Value}{Num}個",
}
LocalizationConfig["loc_mission_Desc62"] =
{
	zh = "提交{Value}{Num}个",
	en = "[未翻译]提交{Value}{Num}个",
	zht = "提交{Value}{Num}個",
}
LocalizationConfig["loc_mission_Desc63"] =
{
	zh = "提交{Value}{Num}个",
	en = "[未翻译]提交{Value}{Num}个",
	zht = "提交{Value}{Num}個",
}
LocalizationConfig["loc_mission_Desc64"] =
{
	zh = "提交{Value}{Num}个",
	en = "[未翻译]提交{Value}{Num}个",
	zht = "提交{Value}{Num}個",
}
LocalizationConfig["loc_mission_Desc65"] =
{
	zh = "提交{Value}{Num}个",
	en = "[未翻译]提交{Value}{Num}个",
	zht = "提交{Value}{Num}個",
}
LocalizationConfig["loc_mission_Desc66"] =
{
	zh = "提交{Value}{Num}个",
	en = "[未翻译]提交{Value}{Num}个",
	zht = "提交{Value}{Num}個",
}
LocalizationConfig["loc_mission_Desc67"] =
{
	zh = "提交{Value}{Num}个",
	en = "[未翻译]提交{Value}{Num}个",
	zht = "提交{Value}{Num}個",
}
LocalizationConfig["loc_mission_Desc68"] =
{
	zh = "提交{Value}{Num}个",
	en = "[未翻译]提交{Value}{Num}个",
	zht = "提交{Value}{Num}個",
}
LocalizationConfig["loc_mission_Desc69"] =
{
	zh = "提交{Value}{Num}个",
	en = "[未翻译]提交{Value}{Num}个",
	zht = "提交{Value}{Num}個",
}
LocalizationConfig["loc_mission_Desc70"] =
{
	zh = "提交{Value}{Num}个",
	en = "[未翻译]提交{Value}{Num}个",
	zht = "提交{Value}{Num}個",
}
LocalizationConfig["loc_mission_Desc71"] =
{
	zh = "提交{Value}{Num}个",
	en = "[未翻译]提交{Value}{Num}个",
	zht = "提交{Value}{Num}個",
}
LocalizationConfig["loc_mission_Desc72"] =
{
	zh = "提交{Value}{Num}个",
	en = "[未翻译]提交{Value}{Num}个",
	zht = "提交{Value}{Num}個",
}
LocalizationConfig["loc_mission_Desc73"] =
{
	zh = "提交{Value}{Num}个",
	en = "[未翻译]提交{Value}{Num}个",
	zht = "提交{Value}{Num}個",
}
LocalizationConfig["loc_mission_Desc74"] =
{
	zh = "提交{Value}{Num}个",
	en = "[未翻译]提交{Value}{Num}个",
	zht = "提交{Value}{Num}個",
}
LocalizationConfig["loc_mission_Desc75"] =
{
	zh = "提交{Value}{Num}个",
	en = "[未翻译]提交{Value}{Num}个",
	zht = "提交{Value}{Num}個",
}
LocalizationConfig["loc_mission_Desc76"] =
{
	zh = "提交{Value}{Num}个",
	en = "[未翻译]提交{Value}{Num}个",
	zht = "提交{Value}{Num}個",
}
LocalizationConfig["loc_mission_Desc77"] =
{
	zh = "提交{Value}{Num}个",
	en = "[未翻译]提交{Value}{Num}个",
	zht = "提交{Value}{Num}個",
}
LocalizationConfig["loc_mission_Desc78"] =
{
	zh = "提交{Value}{Num}个",
	en = "[未翻译]提交{Value}{Num}个",
	zht = "提交{Value}{Num}個",
}
LocalizationConfig["loc_mission_Desc79"] =
{
	zh = "击败{Value}",
	en = "[未翻译]击败{Value}",
	zht = "擊敗{Value}",
}
LocalizationConfig["loc_mission_Desc80"] =
{
	zh = "击败{Value}",
	en = "[未翻译]击败{Value}",
	zht = "擊敗{Value}",
}
LocalizationConfig["loc_mission_Desc81"] =
{
	zh = "击败{Value}",
	en = "[未翻译]击败{Value}",
	zht = "擊敗{Value}",
}
LocalizationConfig["loc_mission_Desc82"] =
{
	zh = "击败{Value}",
	en = "[未翻译]击败{Value}",
	zht = "擊敗{Value}",
}
LocalizationConfig["loc_mission_Desc83"] =
{
	zh = "击败{Value}",
	en = "[未翻译]击败{Value}",
	zht = "擊敗{Value}",
}
LocalizationConfig["loc_mission_Desc84"] =
{
	zh = "击败{Value}",
	en = "[未翻译]击败{Value}",
	zht = "擊敗{Value}",
}
LocalizationConfig["loc_mission_Desc85"] =
{
	zh = "击败{Value}",
	en = "[未翻译]击败{Value}",
	zht = "擊敗{Value}",
}
LocalizationConfig["loc_mission_Desc86"] =
{
	zh = "击败{Value}",
	en = "[未翻译]击败{Value}",
	zht = "擊敗{Value}",
}
LocalizationConfig["loc_mission_Desc87"] =
{
	zh = "提交{Num}个金币",
	en = "[未翻译]提交{Num}个金币",
	zht = "提交{Num}個金幣",
}
LocalizationConfig["loc_mission_Desc88"] =
{
	zh = "探索{Value}{Num}次",
	en = "[未翻译]探索{Value}{Num}次",
	zht = "探索{Value}{Num}次",
}
LocalizationConfig["loc_mission_Desc89"] =
{
	zh = "探索{Value}{Num}次",
	en = "[未翻译]探索{Value}{Num}次",
	zht = "探索{Value}{Num}次",
}
LocalizationConfig["loc_mission_Desc90"] =
{
	zh = "探索{Value}{Num}次",
	en = "[未翻译]探索{Value}{Num}次",
	zht = "探索{Value}{Num}次",
}
LocalizationConfig["loc_mission_Desc91"] =
{
	zh = "探索{Value}{Num}次",
	en = "[未翻译]探索{Value}{Num}次",
	zht = "探索{Value}{Num}次",
}
LocalizationConfig["loc_mission_Desc92"] =
{
	zh = "探索{Value}{Num}次",
	en = "[未翻译]探索{Value}{Num}次",
	zht = "探索{Value}{Num}次",
}
LocalizationConfig["loc_mission_Desc93"] =
{
	zh = "探索{Value}{Num}次",
	en = "[未翻译]探索{Value}{Num}次",
	zht = "探索{Value}{Num}次",
}
LocalizationConfig["loc_mission_Desc94"] =
{
	zh = "提交{Value}{Num}个",
	en = "[未翻译]提交{Value}{Num}个",
	zht = "提交{Value}{Num}個",
}
LocalizationConfig["loc_mission_Desc95"] =
{
	zh = "提交{Value}{Num}个",
	en = "[未翻译]提交{Value}{Num}个",
	zht = "提交{Value}{Num}個",
}
LocalizationConfig["loc_mission_Desc96"] =
{
	zh = "提交{Value}{Num}个",
	en = "[未翻译]提交{Value}{Num}个",
	zht = "提交{Value}{Num}個",
}
LocalizationConfig["loc_mission_Desc97"] =
{
	zh = "提交{Value}{Num}个",
	en = "[未翻译]提交{Value}{Num}个",
	zht = "提交{Value}{Num}個",
}
LocalizationConfig["loc_mission_Desc98"] =
{
	zh = "提交{Value}{Num}个",
	en = "[未翻译]提交{Value}{Num}个",
	zht = "提交{Value}{Num}個",
}
LocalizationConfig["loc_mission_Desc99"] =
{
	zh = "提交{Value}{Num}个",
	en = "[未翻译]提交{Value}{Num}个",
	zht = "提交{Value}{Num}個",
}
LocalizationConfig["loc_mission_Desc100"] =
{
	zh = "提交{Value}{Num}个",
	en = "[未翻译]提交{Value}{Num}个",
	zht = "提交{Value}{Num}個",
}
LocalizationConfig["loc_mission_Desc101"] =
{
	zh = "提交{Value}{Num}个",
	en = "[未翻译]提交{Value}{Num}个",
	zht = "提交{Value}{Num}個",
}
LocalizationConfig["loc_mission_Desc102"] =
{
	zh = "提交{Value}{Num}个",
	en = "[未翻译]提交{Value}{Num}个",
	zht = "提交{Value}{Num}個",
}
LocalizationConfig["loc_mission_Desc103"] =
{
	zh = "提交{Value}{Num}个",
	en = "[未翻译]提交{Value}{Num}个",
	zht = "提交{Value}{Num}個",
}
LocalizationConfig["loc_mission_Desc104"] =
{
	zh = "提交{Value}{Num}个",
	en = "[未翻译]提交{Value}{Num}个",
	zht = "提交{Value}{Num}個",
}
LocalizationConfig["loc_mission_Desc105"] =
{
	zh = "提交{Value}{Num}个",
	en = "[未翻译]提交{Value}{Num}个",
	zht = "提交{Value}{Num}個",
}
LocalizationConfig["loc_mission_Desc106"] =
{
	zh = "提交{Value}{Num}个",
	en = "[未翻译]提交{Value}{Num}个",
	zht = "提交{Value}{Num}個",
}
LocalizationConfig["loc_mission_Desc107"] =
{
	zh = "提交{Value}{Num}个",
	en = "[未翻译]提交{Value}{Num}个",
	zht = "提交{Value}{Num}個",
}
LocalizationConfig["loc_mission_Desc108"] =
{
	zh = "提交{Value}{Num}个",
	en = "[未翻译]提交{Value}{Num}个",
	zht = "提交{Value}{Num}個",
}
LocalizationConfig["loc_mission_Desc109"] =
{
	zh = "提交{Value}{Num}个",
	en = "[未翻译]提交{Value}{Num}个",
	zht = "提交{Value}{Num}個",
}
LocalizationConfig["loc_mission_Desc110"] =
{
	zh = "提交{Value}{Num}个",
	en = "[未翻译]提交{Value}{Num}个",
	zht = "提交{Value}{Num}個",
}
LocalizationConfig["loc_mission_Desc111"] =
{
	zh = "提交{Value}{Num}个",
	en = "[未翻译]提交{Value}{Num}个",
	zht = "提交{Value}{Num}個",
}
LocalizationConfig["loc_mission_Desc112"] =
{
	zh = "击败{Value}",
	en = "[未翻译]击败{Value}",
	zht = "擊敗{Value}",
}
LocalizationConfig["loc_mission_Desc113"] =
{
	zh = "击败{Value}",
	en = "[未翻译]击败{Value}",
	zht = "擊敗{Value}",
}
LocalizationConfig["loc_mission_Desc114"] =
{
	zh = "击败{Value}",
	en = "[未翻译]击败{Value}",
	zht = "擊敗{Value}",
}
LocalizationConfig["loc_mission_Desc115"] =
{
	zh = "击败{Value}",
	en = "[未翻译]击败{Value}",
	zht = "擊敗{Value}",
}
LocalizationConfig["loc_mission_Desc116"] =
{
	zh = "击败{Value}",
	en = "[未翻译]击败{Value}",
	zht = "擊敗{Value}",
}
LocalizationConfig["loc_mission_Desc117"] =
{
	zh = "击败{Value}",
	en = "[未翻译]击败{Value}",
	zht = "擊敗{Value}",
}
LocalizationConfig["loc_mission_Desc118"] =
{
	zh = "击败{Value}",
	en = "[未翻译]击败{Value}",
	zht = "擊敗{Value}",
}
LocalizationConfig["loc_mission_Desc119"] =
{
	zh = "击败{Value}",
	en = "[未翻译]击败{Value}",
	zht = "擊敗{Value}",
}
LocalizationConfig["loc_mission_Desc120"] =
{
	zh = "提交{Num}个金币",
	en = "[未翻译]提交{Num}个金币",
	zht = "提交{Num}個金幣",
}
LocalizationConfig["loc_mission_Desc121"] =
{
	zh = "探索{Value}{Num}次",
	en = "[未翻译]探索{Value}{Num}次",
	zht = "探索{Value}{Num}次",
}
LocalizationConfig["loc_mission_Desc122"] =
{
	zh = "探索{Value}{Num}次",
	en = "[未翻译]探索{Value}{Num}次",
	zht = "探索{Value}{Num}次",
}
LocalizationConfig["loc_mission_Desc123"] =
{
	zh = "探索{Value}{Num}次",
	en = "[未翻译]探索{Value}{Num}次",
	zht = "探索{Value}{Num}次",
}
LocalizationConfig["loc_mission_Desc124"] =
{
	zh = "探索{Value}{Num}次",
	en = "[未翻译]探索{Value}{Num}次",
	zht = "探索{Value}{Num}次",
}
LocalizationConfig["loc_mission_Desc125"] =
{
	zh = "探索{Value}{Num}次",
	en = "[未翻译]探索{Value}{Num}次",
	zht = "探索{Value}{Num}次",
}
LocalizationConfig["loc_mission_Desc126"] =
{
	zh = "提交{Value}{Num}个",
	en = "[未翻译]提交{Value}{Num}个",
	zht = "提交{Value}{Num}個",
}
LocalizationConfig["loc_mission_Desc127"] =
{
	zh = "提交{Value}{Num}个",
	en = "[未翻译]提交{Value}{Num}个",
	zht = "提交{Value}{Num}個",
}
LocalizationConfig["loc_mission_Desc128"] =
{
	zh = "提交{Value}{Num}个",
	en = "[未翻译]提交{Value}{Num}个",
	zht = "提交{Value}{Num}個",
}
LocalizationConfig["loc_mission_Desc129"] =
{
	zh = "提交{Value}{Num}个",
	en = "[未翻译]提交{Value}{Num}个",
	zht = "提交{Value}{Num}個",
}
LocalizationConfig["loc_mission_Desc130"] =
{
	zh = "提交{Value}{Num}个",
	en = "[未翻译]提交{Value}{Num}个",
	zht = "提交{Value}{Num}個",
}
LocalizationConfig["loc_mission_Desc131"] =
{
	zh = "提交{Value}{Num}个",
	en = "[未翻译]提交{Value}{Num}个",
	zht = "提交{Value}{Num}個",
}
LocalizationConfig["loc_mission_Desc132"] =
{
	zh = "提交{Value}{Num}个",
	en = "[未翻译]提交{Value}{Num}个",
	zht = "提交{Value}{Num}個",
}
LocalizationConfig["loc_mission_Desc133"] =
{
	zh = "提交{Value}{Num}个",
	en = "[未翻译]提交{Value}{Num}个",
	zht = "提交{Value}{Num}個",
}
LocalizationConfig["loc_mission_Desc134"] =
{
	zh = "提交{Value}{Num}个",
	en = "[未翻译]提交{Value}{Num}个",
	zht = "提交{Value}{Num}個",
}
LocalizationConfig["loc_mission_Desc135"] =
{
	zh = "提交{Value}{Num}个",
	en = "[未翻译]提交{Value}{Num}个",
	zht = "提交{Value}{Num}個",
}
LocalizationConfig["loc_mission_Desc136"] =
{
	zh = "提交{Value}{Num}个",
	en = "[未翻译]提交{Value}{Num}个",
	zht = "提交{Value}{Num}個",
}
LocalizationConfig["loc_mission_Desc137"] =
{
	zh = "提交{Value}{Num}个",
	en = "[未翻译]提交{Value}{Num}个",
	zht = "提交{Value}{Num}個",
}
LocalizationConfig["loc_mission_Desc138"] =
{
	zh = "提交{Value}{Num}个",
	en = "[未翻译]提交{Value}{Num}个",
	zht = "提交{Value}{Num}個",
}
LocalizationConfig["loc_mission_Desc139"] =
{
	zh = "提交{Value}{Num}个",
	en = "[未翻译]提交{Value}{Num}个",
	zht = "提交{Value}{Num}個",
}
LocalizationConfig["loc_mission_Desc140"] =
{
	zh = "提交{Value}{Num}个",
	en = "[未翻译]提交{Value}{Num}个",
	zht = "提交{Value}{Num}個",
}
LocalizationConfig["loc_mission_Desc141"] =
{
	zh = "提交{Value}{Num}个",
	en = "[未翻译]提交{Value}{Num}个",
	zht = "提交{Value}{Num}個",
}
LocalizationConfig["loc_fight_1"] =
{
	zh = "奇怪的年轻人",
	en = "[未翻译]奇怪的年轻人",
	zht = "奇怪的年輕人",
}
LocalizationConfig["loc_fight_2"] =
{
	zh = "奇怪的中年人",
	en = "[未翻译]奇怪的中年人",
	zht = "奇怪的中年人",
}
LocalizationConfig["loc_fight_3"] =
{
	zh = "奇怪的壮汉",
	en = "[未翻译]奇怪的壮汉",
	zht = "奇怪的壯漢",
}
LocalizationConfig["loc_fight_4"] =
{
	zh = "奇怪的射手",
	en = "[未翻译]奇怪的射手",
	zht = "奇怪的射手",
}
LocalizationConfig["loc_fight_5"] =
{
	zh = "胆小的跟班",
	en = "[未翻译]胆小的跟班",
	zht = "膽小的跟班",
}
LocalizationConfig["loc_fight_6"] =
{
	zh = "迷之设计师",
	en = "[未翻译]迷之设计师",
	zht = "迷之設計師",
}
LocalizationConfig["loc_fight_7"] =
{
	zh = "生气的牧师",
	en = "[未翻译]生气的牧师",
	zht = "生氣的牧師",
}
LocalizationConfig["loc_fight_8"] =
{
	zh = "可怕的大魔王",
	en = "[未翻译]可怕的大魔王",
	zht = "可怕的大魔王",
}
LocalizationConfig["loc_fight_9"] =
{
	zh = "潇洒的王子",
	en = "[未翻译]潇洒的王子",
	zht = "瀟灑的王子",
}
LocalizationConfig["loc_fight_10"] =
{
	zh = "王子的跟班",
	en = "[未翻译]王子的跟班",
	zht = "王子的跟班",
}
LocalizationConfig["loc_fight_11"] =
{
	zh = "黄色帽子的小朋友",
	en = "[未翻译]黄色帽子的小朋友",
	zht = "黃色帽子的小朋友",
}
LocalizationConfig["loc_fight_12"] =
{
	zh = "带着高帽子的侍卫",
	en = "[未翻译]带着高帽子的侍卫",
	zht = "帶著高帽子的侍衛",
}
LocalizationConfig["loc_fight_13"] =
{
	zh = "能打的女仆",
	en = "[未翻译]能打的女仆",
	zht = "能打的女僕",
}
LocalizationConfig["loc_fight_14"] =
{
	zh = "乖乖大小姐",
	en = "[未翻译]乖乖大小姐",
	zht = "乖乖大小姐",
}
LocalizationConfig["loc_fight_15"] =
{
	zh = "神秘的女巫",
	en = "[未翻译]神秘的女巫",
	zht = "神秘的女巫",
}
LocalizationConfig["loc_fight_16"] =
{
	zh = "黑衣皇后",
	en = "[未翻译]黑衣皇后",
	zht = "黑衣皇后",
}
LocalizationConfig["loc_fight_17"] =
{
	zh = "孤单的保安",
	en = "[未翻译]孤单的保安",
	zht = "孤單的保安",
}
LocalizationConfig["loc_fight_18"] =
{
	zh = "慌张的浣熊",
	en = "[未翻译]慌张的浣熊",
	zht = "慌張的浣熊",
}
LocalizationConfig["loc_fight_19"] =
{
	zh = "帅气的狗头人",
	en = "[未翻译]帅气的狗头人",
	zht = "帥氣的狗頭人",
}
LocalizationConfig["loc_fight_20"] =
{
	zh = "会动的铠甲",
	en = "[未翻译]会动的铠甲",
	zht = "會動的鎧甲",
}
LocalizationConfig["loc_fight_21"] =
{
	zh = "带帽子的小姐",
	en = "[未翻译]带帽子的小姐",
	zht = "帶帽子的小姐",
}
LocalizationConfig["loc_fight_22"] =
{
	zh = "沉稳的浣熊",
	en = "[未翻译]沉稳的浣熊",
	zht = "沉穩的浣熊",
}
LocalizationConfig["loc_fight_23"] =
{
	zh = "微笑的画框",
	en = "[未翻译]微笑的画框",
	zht = "微笑的畫框",
}
LocalizationConfig["loc_fight_24"] =
{
	zh = "白衣大盗",
	en = "[未翻译]白衣大盗",
	zht = "白衣大盜",
}
LocalizationConfig["loc_fight_25"] =
{
	zh = "迷之警察",
	en = "[未翻译]迷之警察",
	zht = "迷之員警",
}
LocalizationConfig["loc_fight_26"] =
{
	zh = "神秘的医生",
	en = "[未翻译]神秘的医生",
	zht = "神秘的醫生",
}
LocalizationConfig["loc_fight_27"] =
{
	zh = "倒霉的人",
	en = "[未翻译]倒霉的人",
	zht = "倒楣的人",
}
LocalizationConfig["loc_fight_28"] =
{
	zh = "奇怪的法医",
	en = "[未翻译]奇怪的法医",
	zht = "奇怪的法醫",
}
LocalizationConfig["loc_fight_29"] =
{
	zh = "奇怪的侦探",
	en = "[未翻译]奇怪的侦探",
	zht = "奇怪的偵探",
}
LocalizationConfig["loc_fight_30"] =
{
	zh = "帅气的聪明人",
	en = "[未翻译]帅气的聪明人",
	zht = "帥氣的聰明人",
}
LocalizationConfig["loc_fight_31"] =
{
	zh = "奇怪的小学生",
	en = "[未翻译]奇怪的小学生",
	zht = "奇怪的小學生",
}
LocalizationConfig["loc_fight_32"] =
{
	zh = "可怕的凶手",
	en = "[未翻译]可怕的凶手",
	zht = "可怕的凶手",
}
LocalizationConfig["loc_story_msg_txt1_1"] =
{
	zh = "是魔王新的手下吗？我不会输给你们",
	en = "[未翻译]是魔王新的手下吗？我不会输给你们",
	zht = "是魔王新的手下嗎？我不會輸給你們",
}
LocalizationConfig["loc_story_msg_txt1_2"] =
{
	zh = "哇，谁不要靠近我，我不要出去了",
	en = "[未翻译]哇，谁不要靠近我，我不要出去了",
	zht = "哇，誰不要靠近我，我不要出去了",
}
LocalizationConfig["loc_story_msg_txt1_3"] =
{
	zh = "要想从此过，留下买路财！",
	en = "[未翻译]要想从此过，留下买路财！",
	zht = "要想從此過，留下買路財！",
}
LocalizationConfig["loc_story_msg_txt1_4"] =
{
	zh = "魔王已经不可战胜了，放弃吧。",
	en = "[未翻译]魔王已经不可战胜了，放弃吧。",
	zht = "魔王已經不可戰勝了，放棄吧。",
}
LocalizationConfig["loc_story_msg_txt1_5"] =
{
	zh = "别指望我会透露魔王大人的消息。",
	en = "[未翻译]别指望我会透露魔王大人的消息。",
	zht = "別指望我會透露魔王大人的消息。",
}
LocalizationConfig["loc_story_msg_txt1_6"] =
{
	zh = "我是谁？我怎么在这里？你们要干嘛？",
	en = "[未翻译]我是谁？我怎么在这里？你们要干嘛？",
	zht = "我是誰？我怎麼在這裡？你們要幹嘛？",
}
LocalizationConfig["loc_story_msg_txt1_7"] =
{
	zh = "你们终于来了，先接受我的考验。",
	en = "[未翻译]你们终于来了，先接受我的考验。",
	zht = "你們終於來了，先接受我的考驗。",
}
LocalizationConfig["loc_story_msg_txt1_8"] =
{
	zh = "又有送死的来了呀",
	en = "[未翻译]又有送死的来了呀",
	zht = "又有送死的來了呀",
}
LocalizationConfig["loc_story_msg_txt1_9"] =
{
	zh = "哇，让我去死吧。",
	en = "[未翻译]哇，让我去死吧。",
	zht = "哇，讓我去死吧。",
}
LocalizationConfig["loc_story_msg_txt1_10"] =
{
	zh = "你们别过来！",
	en = "[未翻译]你们别过来！",
	zht = "你們別過來！",
}
LocalizationConfig["loc_story_msg_txt1_11"] =
{
	zh = "生活已经不甜了。",
	en = "[未翻译]生活已经不甜了。",
	zht = "生活已經不甜了。",
}
LocalizationConfig["loc_story_msg_txt1_12"] =
{
	zh = "受欢迎的下午茶，都去死！",
	en = "[未翻译]受欢迎的下午茶，都去死！",
	zht = "受歡迎的下午茶，都去死！",
}
LocalizationConfig["loc_story_msg_txt1_13"] =
{
	zh = "快把公主叫出来。",
	en = "[未翻译]快把公主叫出来。",
	zht = "快把公主叫出來。",
}
LocalizationConfig["loc_story_msg_txt1_14"] =
{
	zh = "唔唔唔……",
	en = "[未翻译]唔唔唔……",
	zht = "唔唔唔……",
}
LocalizationConfig["loc_story_msg_txt1_15"] =
{
	zh = "你们看我像什么？",
	en = "[未翻译]你们看我像什么？",
	zht = "你們看我像什麼？",
}
LocalizationConfig["loc_story_msg_txt1_16"] =
{
	zh = "哈哈，你们来晚了！",
	en = "[未翻译]哈哈，你们来晚了！",
	zht = "哈哈，你們來晚了！",
}
LocalizationConfig["loc_story_msg_txt1_17"] =
{
	zh = "站住，不许进去！",
	en = "[未翻译]站住，不许进去！",
	zht = "站住，不許進去！",
}
LocalizationConfig["loc_story_msg_txt1_18"] =
{
	zh = "哇，你们突然出现在我背后好吓人。",
	en = "[未翻译]哇，你们突然出现在我背后好吓人。",
	zht = "哇，你們突然出現在我背後好嚇人。",
}
LocalizationConfig["loc_story_msg_txt1_19"] =
{
	zh = "此处神圣领地不可喧哗。",
	en = "[未翻译]此处神圣领地不可喧哗。",
	zht = "此處神聖領地不可喧嘩。",
}
LocalizationConfig["loc_story_msg_txt1_20"] =
{
	zh = "……",
	en = "[未翻译]……",
	zht = "……",
}
LocalizationConfig["loc_story_msg_txt1_21"] =
{
	zh = "……",
	en = "[未翻译]……",
	zht = "……",
}
LocalizationConfig["loc_story_msg_txt1_22"] =
{
	zh = "怪物们，交出我弟弟！",
	en = "[未翻译]怪物们，交出我弟弟！",
	zht = "怪物們，交出我弟弟！",
}
LocalizationConfig["loc_story_msg_txt1_23"] =
{
	zh = "怎样的微笑才迷人呢？",
	en = "[未翻译]怎样的微笑才迷人呢？",
	zht = "怎樣的微笑才迷人呢？",
}
LocalizationConfig["loc_story_msg_txt1_24"] =
{
	zh = "你们怎么这么粗鲁？",
	en = "[未翻译]你们怎么这么粗鲁？",
	zht = "你們怎麼這麼粗魯？",
}
LocalizationConfig["loc_story_msg_txt1_25"] =
{
	zh = "你们一定是凶手。",
	en = "[未翻译]你们一定是凶手。",
	zht = "你們一定是兇手。",
}
LocalizationConfig["loc_story_msg_txt1_26"] =
{
	zh = "你们有何贵干？",
	en = "[未翻译]你们有何贵干？",
	zht = "你們有何貴幹？",
}
LocalizationConfig["loc_story_msg_txt1_27"] =
{
	zh = "你们想打听点什么呢？",
	en = "[未翻译]你们想打听点什么呢？",
	zht = "你們想打聽點什麼呢？",
}
LocalizationConfig["loc_story_msg_txt1_28"] =
{
	zh = "我工作很忙，没事不要打扰我。",
	en = "[未翻译]我工作很忙，没事不要打扰我。",
	zht = "我工作很忙，沒事不要打擾我。",
}
LocalizationConfig["loc_story_msg_txt1_29"] =
{
	zh = "根据现场信息，你们就是凶手。",
	en = "[未翻译]根据现场信息，你们就是凶手。",
	zht = "根據現場資訊，你們就是兇手。",
}
LocalizationConfig["loc_story_msg_txt1_30"] =
{
	zh = "嗡嗡嗡……嗡嗡嗡……嗡嗡嗡……",
	en = "[未翻译]嗡嗡嗡……嗡嗡嗡……嗡嗡嗡……",
	zht = "嗡嗡嗡……嗡嗡嗡……嗡嗡嗡……",
}
LocalizationConfig["loc_story_msg_txt1_31"] =
{
	zh = "我看到了一切，你们的努力只能是徒劳。",
	en = "[未翻译]我看到了一切，你们的努力只能是徒劳。",
	zht = "我看到了一切，你們的努力只能是徒勞。",
}
LocalizationConfig["loc_story_msg_txt1_32"] =
{
	zh = "哈哈哈哈，你们又来了。",
	en = "[未翻译]哈哈哈哈，你们又来了。",
	zht = "哈哈哈哈，你們又來了。",
}
LocalizationConfig["loc_story_msg_txt2_1"] =
{
	zh = "不是，我们是新到这个星球的……",
	en = "[未翻译]不是，我们是新到这个星球的……",
	zht = "不是，我們是新到這個星球的……",
}
LocalizationConfig["loc_story_msg_txt2_2"] =
{
	zh = "我们需要你的能力。",
	en = "[未翻译]我们需要你的能力。",
	zht = "我們需要你的能力。",
}
LocalizationConfig["loc_story_msg_txt2_3"] =
{
	zh = "居然想打劫我们，做梦！",
	en = "[未翻译]居然想打劫我们，做梦！",
	zht = "居然想打劫我們，做夢！",
}
LocalizationConfig["loc_story_msg_txt2_4"] =
{
	zh = "没有战胜不了的魔王，一起想想办法。",
	en = "[未翻译]没有战胜不了的魔王，一起想想办法。",
	zht = "沒有戰勝不了的魔王，一起想想辦法。",
}
LocalizationConfig["loc_story_msg_txt2_5"] =
{
	zh = "糖衣炮弹、严刑拷打，选一个！",
	en = "[未翻译]糖衣炮弹、严刑拷打，选一个！",
	zht = "糖衣炮彈、嚴刑拷打，選一個！",
}
LocalizationConfig["loc_story_msg_txt2_6"] =
{
	zh = "我们有事相求。",
	en = "[未翻译]我们有事相求。",
	zht = "我們有事相求。",
}
LocalizationConfig["loc_story_msg_txt2_7"] =
{
	zh = "居然还要考验！",
	en = "[未翻译]居然还要考验！",
	zht = "居然還要考驗！",
}
LocalizationConfig["loc_story_msg_txt2_8"] =
{
	zh = "单挑VS群殴，你真有胆子。",
	en = "[未翻译]单挑VS群殴，你真有胆子。",
	zht = "單挑VS群毆，你真有膽子。",
}
LocalizationConfig["loc_story_msg_txt2_9"] =
{
	zh = "怎么回事？",
	en = "[未翻译]怎么回事？",
	zht = "怎麼回事？",
}
LocalizationConfig["loc_story_msg_txt2_10"] =
{
	zh = "做了坏事还想跑？",
	en = "[未翻译]做了坏事还想跑？",
	zht = "做了壞事還想跑？",
}
LocalizationConfig["loc_story_msg_txt2_11"] =
{
	zh = "生活不是只有甜。",
	en = "[未翻译]生活不是只有甜。",
	zht = "生活不是只有甜。",
}
LocalizationConfig["loc_story_msg_txt2_12"] =
{
	zh = "醒醒，不要被人控制！",
	en = "[未翻译]醒醒，不要被人控制！",
	zht = "醒醒，不要被人控制！",
}
LocalizationConfig["loc_story_msg_txt2_13"] =
{
	zh = "我们不是坏人。",
	en = "[未翻译]我们不是坏人。",
	zht = "我們不是壞人。",
}
LocalizationConfig["loc_story_msg_txt2_14"] =
{
	zh = "我们是来帮你的。",
	en = "[未翻译]我们是来帮你的。",
	zht = "我們是來幫你的。",
}
LocalizationConfig["loc_story_msg_txt2_15"] =
{
	zh = "猪肉干？",
	en = "[未翻译]猪肉干？",
	zht = "豬肉幹？",
}
LocalizationConfig["loc_story_msg_txt2_16"] =
{
	zh = "贪婪会吞噬你。",
	en = "[未翻译]贪婪会吞噬你。",
	zht = "貪婪會吞噬你。",
}
LocalizationConfig["loc_story_msg_txt2_17"] =
{
	zh = "为什么要拦住我们？",
	en = "[未翻译]为什么要拦住我们？",
	zht = "為什麼要攔住我們？",
}
LocalizationConfig["loc_story_msg_txt2_18"] =
{
	zh = "你是小偷吧？",
	en = "[未翻译]你是小偷吧？",
	zht = "你是小偷吧？",
}
LocalizationConfig["loc_story_msg_txt2_19"] =
{
	zh = "会说话的小狗？",
	en = "[未翻译]会说话的小狗？",
	zht = "會說話的小狗？",
}
LocalizationConfig["loc_story_msg_txt2_20"] =
{
	zh = "这个铠甲好像动起来了。",
	en = "[未翻译]这个铠甲好像动起来了。",
	zht = "這個鎧甲好像動起來了。",
}
LocalizationConfig["loc_story_msg_txt2_21"] =
{
	zh = "这个雕像栩栩如生。",
	en = "[未翻译]这个雕像栩栩如生。",
	zht = "這個雕像栩栩如生。",
}
LocalizationConfig["loc_story_msg_txt2_22"] =
{
	zh = "等等，你好像误会了……",
	en = "[未翻译]等等，你好像误会了……",
	zht = "等等，你好像誤會了……",
}
LocalizationConfig["loc_story_msg_txt2_23"] =
{
	zh = "33.3333……%的微笑？",
	en = "[未翻译]33.3333……%的微笑？",
	zht = "33.3333……%的微笑？",
}
LocalizationConfig["loc_story_msg_txt2_24"] =
{
	zh = "幕后黑手，束手就擒吧！",
	en = "[未翻译]幕后黑手，束手就擒吧！",
	zht = "幕後黑手，束手就擒吧！",
}
LocalizationConfig["loc_story_msg_txt2_25"] =
{
	zh = "我们真的只是路过。",
	en = "[未翻译]我们真的只是路过。",
	zht = "我們真的只是路過。",
}
LocalizationConfig["loc_story_msg_txt2_26"] =
{
	zh = "请帮我们洗脱嫌疑吧。",
	en = "[未翻译]请帮我们洗脱嫌疑吧。",
	zht = "請幫我們洗脫嫌疑吧。",
}
LocalizationConfig["loc_story_msg_txt2_27"] =
{
	zh = "今天的案子你有线索吗？",
	en = "[未翻译]今天的案子你有线索吗？",
	zht = "今天的案子你有線索嗎？",
}
LocalizationConfig["loc_story_msg_txt2_28"] =
{
	zh = "我们想知道嫌疑人的资料。",
	en = "[未翻译]我们想知道嫌疑人的资料。",
	zht = "我們想知道嫌疑人的資料。",
}
LocalizationConfig["loc_story_msg_txt2_29"] =
{
	zh = "难道你也不能帮我们。",
	en = "[未翻译]难道你也不能帮我们。",
	zht = "難道你也不能幫我們。",
}
LocalizationConfig["loc_story_msg_txt2_30"] =
{
	zh = "说人话！",
	en = "[未翻译]说人话！",
	zht = "說人話！",
}
LocalizationConfig["loc_story_msg_txt2_31"] =
{
	zh = "不试试怎么知道。",
	en = "[未翻译]不试试怎么知道。",
	zht = "不試試怎麼知道。",
}
LocalizationConfig["loc_story_msg_txt2_32"] =
{
	zh = "我们可是有备而来，束手就擒吧。",
	en = "[未翻译]我们可是有备而来，束手就擒吧。",
	zht = "我們可是有備而來，束手就擒吧。",
}
LocalizationConfig["loc_story_msg_txt3_1"] =
{
	zh = "原来你们不是魔王手下，早说呢。",
	en = "[未翻译]原来你们不是魔王手下，早说呢。",
	zht = "原來你們不是魔王手下，早說呢。",
}
LocalizationConfig["loc_story_msg_txt3_2"] =
{
	zh = "你们得保护好我啊。",
	en = "[未翻译]你们得保护好我啊。",
	zht = "你們得保護好我啊。",
}
LocalizationConfig["loc_story_msg_txt3_3"] =
{
	zh = "这么霸道，到底谁才是强盗……",
	en = "[未翻译]这么霸道，到底谁才是强盗……",
	zht = "這麼霸道，到底誰才是強盜……",
}
LocalizationConfig["loc_story_msg_txt3_4"] =
{
	zh = "好吧，再试一次。",
	en = "[未翻译]好吧，再试一次。",
	zht = "好吧，再試一次。",
}
LocalizationConfig["loc_story_msg_txt3_5"] =
{
	zh = "我死都不会说的。",
	en = "[未翻译]我死都不会说的。",
	zht = "我死都不會說的。",
}
LocalizationConfig["loc_story_msg_txt3_6"] =
{
	zh = "去吧，年轻的勇士们！",
	en = "[未翻译]去吧，年轻的勇士们！",
	zht = "去吧，年輕的勇士們！",
}
LocalizationConfig["loc_story_msg_txt3_7"] =
{
	zh = "走吧，我已经等不及了，嘿嘿……",
	en = "[未翻译]走吧，我已经等不及了，嘿嘿……",
	zht = "走吧，我已經等不及了，嘿嘿……",
}
LocalizationConfig["loc_story_msg_txt3_8"] =
{
	zh = "为什么……怎么会……",
	en = "[未翻译]为什么……怎么会……",
	zht = "為什麼……怎麼會……",
}
LocalizationConfig["loc_story_msg_txt3_9"] =
{
	zh = "活着已经没意思了……",
	en = "[未翻译]活着已经没意思了……",
	zht = "活著已經沒意思了……",
}
LocalizationConfig["loc_story_msg_txt3_10"] =
{
	zh = "误会了，我也是受害者。",
	en = "[未翻译]误会了，我也是受害者。",
	zht = "誤會了，我也是受害者。",
}
LocalizationConfig["loc_story_msg_txt3_11"] =
{
	zh = "你们能帮我找回甜味吗？",
	en = "[未翻译]你们能帮我找回甜味吗？",
	zht = "你們能幫我找回甜味嗎？",
}
LocalizationConfig["loc_story_msg_txt3_12"] =
{
	zh = "啊——",
	en = "[未翻译]啊——",
	zht = "啊——",
}
LocalizationConfig["loc_story_msg_txt3_13"] =
{
	zh = "快去救救公主。",
	en = "[未翻译]快去救救公主。",
	zht = "快去救救公主。",
}
LocalizationConfig["loc_story_msg_txt3_14"] =
{
	zh = "唔唔唔……",
	en = "[未翻译]唔唔唔……",
	zht = "唔唔唔……",
}
LocalizationConfig["loc_story_msg_txt3_15"] =
{
	zh = "请帮我找回丢失的油水。",
	en = "[未翻译]请帮我找回丢失的油水。",
	zht = "請幫我找回丟失的油水。",
}
LocalizationConfig["loc_story_msg_txt3_16"] =
{
	zh = "我竟然……输了！",
	en = "[未翻译]我竟然……输了！",
	zht = "我竟然……輸了！",
}
LocalizationConfig["loc_story_msg_txt3_17"] =
{
	zh = "里面很危险。",
	en = "[未翻译]里面很危险。",
	zht = "裡面很危險。",
}
LocalizationConfig["loc_story_msg_txt3_18"] =
{
	zh = "其实我是个好浣熊。",
	en = "[未翻译]其实我是个好浣熊。",
	zht = "其實我是個好浣熊。",
}
LocalizationConfig["loc_story_msg_txt3_19"] =
{
	zh = "我才不是小狗。",
	en = "[未翻译]我才不是小狗。",
	zht = "我才不是小狗。",
}
LocalizationConfig["loc_story_msg_txt3_20"] =
{
	zh = "……居然被你们发现了。",
	en = "[未翻译]……居然被你们发现了。",
	zht = "……居然被你們發現了。",
}
LocalizationConfig["loc_story_msg_txt3_21"] =
{
	zh = "原来是真人啊。",
	en = "[未翻译]原来是真人啊。",
	zht = "原來是真人啊。",
}
LocalizationConfig["loc_story_msg_txt3_22"] =
{
	zh = "我们没抓你弟弟。",
	en = "[未翻译]我们没抓你弟弟。",
	zht = "我們沒抓你弟弟。",
}
LocalizationConfig["loc_story_msg_txt3_23"] =
{
	zh = "这个微笑刚刚好。",
	en = "[未翻译]这个微笑刚刚好。",
	zht = "這個微笑剛剛好。",
}
LocalizationConfig["loc_story_msg_txt3_24"] =
{
	zh = "终于阻止了坏人的阴谋！",
	en = "[未翻译]终于阻止了坏人的阴谋！",
	zht = "終於阻止了壞人的陰謀！",
}
LocalizationConfig["loc_story_msg_txt3_25"] =
{
	zh = "别妄想能逃掉。",
	en = "[未翻译]别妄想能逃掉。",
	zht = "別妄想能逃掉。",
}
LocalizationConfig["loc_story_msg_txt3_26"] =
{
	zh = "我给你们指条路。",
	en = "[未翻译]我给你们指条路。",
	zht = "我給你們指條路。",
}
LocalizationConfig["loc_story_msg_txt3_27"] =
{
	zh = "去法医那里看看吧。",
	en = "[未翻译]去法医那里看看吧。",
	zht = "去法醫那裡看看吧。",
}
LocalizationConfig["loc_story_msg_txt3_28"] =
{
	zh = "真固执，我就告诉你们吧。",
	en = "[未翻译]真固执，我就告诉你们吧。",
	zht = "真固執，我就告訴你們吧。",
}
LocalizationConfig["loc_story_msg_txt3_29"] =
{
	zh = "去找我哥哥吧，他或许能帮上忙。",
	en = "[未翻译]去找我哥哥吧，他或许能帮上忙。",
	zht = "去找我哥哥吧，他或許能幫上忙。",
}
LocalizationConfig["loc_story_msg_txt3_30"] =
{
	zh = "嗡嗡嗡……嗡嗡嗡……嗡嗡嗡……",
	en = "[未翻译]嗡嗡嗡……嗡嗡嗡……嗡嗡嗡……",
	zht = "嗡嗡嗡……嗡嗡嗡……嗡嗡嗡……",
}
LocalizationConfig["loc_story_msg_txt3_31"] =
{
	zh = "好吧，我就帮帮你们。",
	en = "[未翻译]好吧，我就帮帮你们。",
	zht = "好吧，我就幫幫你們。",
}
LocalizationConfig["loc_story_msg_txt3_32"] =
{
	zh = "这一切都在我算计中。",
	en = "[未翻译]这一切都在我算计中。",
	zht = "這一切都在我算計中。",
}
LocalizationConfig["loc_story_msg_txt3_33"] =
{
	zh = "告诉魔王叫他亲自来。",
	en = "[未翻译]告诉魔王叫他亲自来。",
	zht = "告訴魔王叫他親自來。",
}
LocalizationConfig["loc_story_msg_txt3_34"] =
{
	zh = "年轻喵，好好练级再回来吧。",
	en = "[未翻译]年轻喵，好好练级再回来吧。",
	zht = "年輕喵，好好練級再回來吧。",
}
LocalizationConfig["loc_story_msg_txt3_35"] =
{
	zh = "把钱财都乖乖交出来。",
	en = "[未翻译]把钱财都乖乖交出来。",
	zht = "把錢財都乖乖交出來。",
}
LocalizationConfig["loc_story_msg_txt3_36"] =
{
	zh = "你们太弱了。",
	en = "[未翻译]你们太弱了。",
	zht = "你們太弱了。",
}
LocalizationConfig["loc_story_msg_txt3_37"] =
{
	zh = "哈哈，魔王大人比我厉害多了。",
	en = "[未翻译]哈哈，魔王大人比我厉害多了。",
	zht = "哈哈，魔王大人比我厲害多了。",
}
LocalizationConfig["loc_story_msg_txt3_38"] =
{
	zh = "你们还没准备好。",
	en = "[未翻译]你们还没准备好。",
	zht = "你們還沒準備好。",
}
LocalizationConfig["loc_story_msg_txt3_39"] =
{
	zh = "真厉害，这下能打败魔王了。",
	en = "[未翻译]真厉害，这下能打败魔王了。",
	zht = "真厲害，這下能打敗魔王了。",
}
LocalizationConfig["loc_story_msg_txt3_40"] =
{
	zh = "哈哈，邪恶必胜",
	en = "[未翻译]哈哈，邪恶必胜",
	zht = "哈哈，邪惡必勝",
}
LocalizationConfig["loc_story_msg_txt3_41"] =
{
	zh = "别拦我，让我死了算了。",
	en = "[未翻译]别拦我，让我死了算了。",
	zht = "別攔我，讓我死了算了。",
}
LocalizationConfig["loc_story_msg_txt3_42"] =
{
	zh = "你们一定是奶茶喝多了",
	en = "[未翻译]你们一定是奶茶喝多了",
	zht = "你們一定是奶茶喝多了",
}
LocalizationConfig["loc_story_msg_txt3_43"] =
{
	zh = "没糖就不是真正的快乐。",
	en = "[未翻译]没糖就不是真正的快乐。",
	zht = "沒糖就不是真正的快樂。",
}
LocalizationConfig["loc_story_msg_txt3_44"] =
{
	zh = "我才是最受欢迎的下午茶！",
	en = "[未翻译]我才是最受欢迎的下午茶！",
	zht = "我才是最受歡迎的下午茶！",
}
LocalizationConfig["loc_story_msg_txt3_45"] =
{
	zh = "我自己去就好了",
	en = "[未翻译]我自己去就好了",
	zht = "我自己去就好了",
}
LocalizationConfig["loc_story_msg_txt3_46"] =
{
	zh = "唔唔唔……",
	en = "[未翻译]唔唔唔……",
	zht = "唔唔唔……",
}
LocalizationConfig["loc_story_msg_txt3_47"] =
{
	zh = "把油水还给我！",
	en = "[未翻译]把油水还给我！",
	zht = "把油水還給我！",
}
LocalizationConfig["loc_story_msg_txt3_48"] =
{
	zh = "你们的特点，我就笑纳了。",
	en = "[未翻译]你们的特点，我就笑纳了。",
	zht = "你們的特點，我就笑納了。",
}
LocalizationConfig["loc_story_msg_txt3_49"] =
{
	zh = "快走快走。",
	en = "[未翻译]快走快走。",
	zht = "快走快走。",
}
LocalizationConfig["loc_story_msg_txt3_50"] =
{
	zh = "你们这些家伙别想抓住我。",
	en = "[未翻译]你们这些家伙别想抓住我。",
	zht = "你們這些傢伙別想抓住我。",
}
LocalizationConfig["loc_story_msg_txt3_51"] =
{
	zh = "胆敢小看我阿努比斯！",
	en = "[未翻译]胆敢小看我阿努比斯！",
	zht = "膽敢小看我阿努比斯！",
}
LocalizationConfig["loc_story_msg_txt3_52"] =
{
	zh = "……",
	en = "[未翻译]……",
	zht = "……",
}
LocalizationConfig["loc_story_msg_txt3_53"] =
{
	zh = "竟敢把本小姐当雕像！",
	en = "[未翻译]竟敢把本小姐当雕像！",
	zht = "竟敢把本小姐當雕像！",
}
LocalizationConfig["loc_story_msg_txt3_54"] =
{
	zh = "竟然打我弟弟的主意。",
	en = "[未翻译]竟然打我弟弟的主意。",
	zht = "竟然打我弟弟的主意。",
}
LocalizationConfig["loc_story_msg_txt3_55"] =
{
	zh = "果然，这个微笑还是不行呢……",
	en = "[未翻译]果然，这个微笑还是不行呢……",
	zht = "果然，這個微笑還是不行呢……",
}
LocalizationConfig["loc_story_msg_txt3_56"] =
{
	zh = "你们冷静下我再解释。",
	en = "[未翻译]你们冷静下我再解释。",
	zht = "你們冷靜下我再解釋。",
}
LocalizationConfig["loc_story_msg_txt3_57"] =
{
	zh = "你们被捕了！",
	en = "[未翻译]你们被捕了！",
	zht = "你們被捕了！",
}
LocalizationConfig["loc_story_msg_txt3_58"] =
{
	zh = "再多搜集点信息我才能帮你们。",
	en = "[未翻译]再多搜集点信息我才能帮你们。",
	zht = "再多搜集點資訊我才能幫你們。",
}
LocalizationConfig["loc_story_msg_txt3_59"] =
{
	zh = "你们的事，我爱莫能助。",
	en = "[未翻译]你们的事，我爱莫能助。",
	zht = "你們的事，我愛莫能助。",
}
LocalizationConfig["loc_story_msg_txt3_60"] =
{
	zh = "不要打断我的工作！",
	en = "[未翻译]不要打断我的工作！",
	zht = "不要打斷我的工作！",
}
LocalizationConfig["loc_story_msg_txt3_61"] =
{
	zh = "放弃吧，你们无法洗脱嫌疑。",
	en = "[未翻译]放弃吧，你们无法洗脱嫌疑。",
	zht = "放棄吧，你們無法洗脫嫌疑。",
}
LocalizationConfig["loc_story_msg_txt3_62"] =
{
	zh = "嗡嗡嗡……嗡嗡嗡……嗡嗡嗡……",
	en = "[未翻译]嗡嗡嗡……嗡嗡嗡……嗡嗡嗡……",
	zht = "嗡嗡嗡……嗡嗡嗡……嗡嗡嗡……",
}
LocalizationConfig["loc_story_msg_txt3_63"] =
{
	zh = "真相只有一个，你们就是凶手！",
	en = "[未翻译]真相只有一个，你们就是凶手！",
	zht = "真相只有一個，你們就是兇手！",
}
LocalizationConfig["loc_story_msg_txt3_64"] =
{
	zh = "你们是我计划的一环。",
	en = "[未翻译]你们是我计划的一环。",
	zht = "你們是我計畫的一環。",
}
LocalizationConfig["loc_story_msg_emoji_1"] =
{
	zh = "/emoji_kaixin",
	en = "/emoji_kaixin",
	zht = "/emoji_kaixin",
}
LocalizationConfig["loc_story_msg_emoji_2"] =
{
	zh = "/emoji_wunai",
	en = "/emoji_wunai",
	zht = "/emoji_wunai",
}
LocalizationConfig["loc_tutorial_1"] =
{
	zh = "[714747]出发去[-][2CBF00]战斗[-][714747]吧[-]",
	en = "[未翻译][714747]出发去[-][2CBF00]战斗[-][714747]吧[-]",
	zht = "[714747]出發去[-][2CBF00]戰鬥[-][714747]吧[-]",
}
LocalizationConfig["loc_tutorial_2"] =
{
	zh = "[714747]再次出发[-]",
	en = "[未翻译][714747]再次出发[-]",
	zht = "[714747]再次出發[-]",
}
LocalizationConfig["loc_tutorial_3"] =
{
	zh = "[714747]领取探索成果[-]",
	en = "[未翻译][714747]领取探索成果[-]",
	zht = "[714747]領取探索成果[-]",
}
LocalizationConfig["loc_tutorial_4"] =
{
	zh = "[714747]领取任务奖励[-]",
	en = "[未翻译][714747]领取任务奖励[-]",
	zht = "[714747]領取任務獎勵[-]",
}
LocalizationConfig["loc_tutorial_5"] =
{
	zh = "[714747]开始合成[-]",
	en = "[未翻译][714747]开始合成[-]",
	zht = "[714747]開始合成[-]",
}
LocalizationConfig["loc_tutorial_6"] =
{
	zh = "[714747]数值都亮了，走起！[-]",
	en = "[未翻译][714747]数值都亮了，走起！[-]",
	zht = "[714747]數值都亮了，走起！[-]",
}
LocalizationConfig["loc_tutorial_7"] =
{
	zh = "[714747]简单吧，我去充电了，有缘再见[-]",
	en = "[未翻译][714747]简单吧，我去充电了，有缘再见[-]",
	zht = "[714747]簡單吧，我去充電了，有緣再見[-]",
}
LocalizationConfig["loc_tutorial_8"] =
{
	zh = "[714747]任务完成，去看看有啥奖励[-]",
	en = "[未翻译][714747]任务完成，去看看有啥奖励[-]",
	zht = "[714747]任務完成，去看看有啥獎勵[-]",
}
LocalizationConfig["loc_tutorial_9"] =
{
	zh = "[714747]根据数据库的资料，这里好像是一个叫冒险星的星球[-]",
	en = "[未翻译][714747]根据数据库的资料，这里好像是一个叫冒险星的星球[-]",
	zht = "[714747]根據資料庫的資料，這裡好像是一個叫冒險星的星球[-]",
}
LocalizationConfig["loc_tutorial_10"] =
{
	zh = "[714747]这不是刚刚打罐子的青年[-]",
	en = "[未翻译][714747]这不是刚刚打罐子的青年[-]",
	zht = "[714747]這不是剛剛打罐子的青年[-]",
}
LocalizationConfig["loc_tutorial_11"] =
{
	zh = "[714747]前往完成新任务[-]",
	en = "[未翻译][714747]前往完成新任务[-]",
	zht = "[714747]前往完成新任務[-]",
}
LocalizationConfig["loc_tutorial_12"] =
{
	zh = "[714747]点击[-][2CBF00]星球[-]",
	en = "[未翻译][714747]点击[-][2CBF00]星球[-]",
	zht = "[714747]點擊[-][2CBF00]星球[-]",
}
LocalizationConfig["loc_tutorial_13"] =
{
	zh = "[714747]去探索看看能获得什么好东西[-]",
	en = "[未翻译][714747]去探索看看能获得什么好东西[-]",
	zht = "[714747]去探索看看能獲得什麼好東西[-]",
}
LocalizationConfig["loc_tutorial_14"] =
{
	zh = "[714747]有两个数值，[-][2CBF00]体力[-][714747]和[-][2CBF00]胆识[-]",
	en = "[未翻译][714747]有两个数值，[-][2CBF00]体力[-][714747]和[-][2CBF00]胆识[-]",
	zht = "[714747]有兩個數值，[-][2CBF00]體力[-][714747]和[-][2CBF00]膽識[-]",
}
LocalizationConfig["loc_tutorial_15"] =
{
	zh = "[714747]有[-][2CBF00]体力[-][714747]的呜呜[-]",
	en = "[未翻译][714747]有[-][2CBF00]体力[-][714747]的呜呜[-]",
	zht = "[714747]有[-][2CBF00]體力[-][714747]的嗚嗚[-]",
}
LocalizationConfig["loc_tutorial_16"] =
{
	zh = "[714747]有[-][2CBF00]胆识[-][714747]的咕咕[-]",
	en = "[未翻译][714747]有[-][2CBF00]胆识[-][714747]的咕咕[-]",
	zht = "[714747]有[-][2CBF00]膽識[-][714747]的咕咕[-]",
}
LocalizationConfig["loc_tutorial_17"] =
{
	zh = "[714747]体力点亮了！胆识还不够[-]",
	en = "[未翻译][714747]体力点亮了！胆识还不够[-]",
	zht = "[714747]體力點亮了！膽識還不夠[-]",
}
LocalizationConfig["loc_tutorial_18"] =
{
	zh = "[714747]他败给了充满体力和胆识的猫咪组合[-]",
	en = "[未翻译][714747]他败给了充满体力和胆识的猫咪组合[-]",
	zht = "[714747]他敗給了充滿體力和膽識的貓咪組合[-]",
}
LocalizationConfig["loc_tutorial_19"] =
{
	zh = "[714747]选上呜呜[-]",
	en = "[未翻译][714747]选上呜呜[-]",
	zht = "[714747]選上嗚嗚[-]",
}
LocalizationConfig["loc_tutorial_20"] =
{
	zh = "[714747]选上咕咕[-]",
	en = "[未翻译][714747]选上咕咕[-]",
	zht = "[714747]選上咕咕[-]",
}
LocalizationConfig["loc_tutorial_21"] =
{
	zh = "[714747]看来要等一段时间了。我们加速跳过吧[-]",
	en = "[未翻译][714747]看来要等一段时间了。我们加速跳过吧[-]",
	zht = "[714747]看來要等一段時間了。我們加速跳過吧[-]",
}
LocalizationConfig["loc_tutorial_22"] =
{
	zh = "[714747]领取任务奖励[-]",
	en = "[未翻译][714747]领取任务奖励[-]",
	zht = "[714747]領取任務獎勵[-]",
}
LocalizationConfig["loc_tutorial_23"] =
{
	zh = "[2CBF00]加速[-][714747]别客气[-]",
	en = "[未翻译][2CBF00]加速[-][714747]别客气[-]",
	zht = "[2CBF00]加速[-][714747]別客氣[-]",
}
LocalizationConfig["loc_tutorial_24"] =
{
	zh = "[714747]探索结束，看看探索到了什么[-]",
	en = "[未翻译][714747]探索结束，看看探索到了什么[-]",
	zht = "[714747]探索結束，看看探索到了什麼[-]",
}
LocalizationConfig["loc_tutorial_25"] =
{
	zh = "[714747]升级了！干得不错，多[-][2CBF00]探索[-][714747]就自然会[-][2CBF00]升级[-][714747]哦[-]",
	en = "[未翻译][714747]升级了！干得不错，多[-][2CBF00]探索[-][714747]就自然会[-][2CBF00]升级[-][714747]哦[-]",
	zht = "[714747]升級了！幹得不錯，多[-][2CBF00]探索[-][714747]就自然會[-][2CBF00]升級[-][714747]哦[-]",
}
LocalizationConfig["loc_tutorial_26"] =
{
	zh = "[714747]任务完成，去看看吧[-]",
	en = "[未翻译][714747]任务完成，去看看吧[-]",
	zht = "[714747]任務完成，去看看吧[-]",
}
LocalizationConfig["loc_tutorial_27"] =
{
	zh = "[714747]我们去[-][2CBF00]实验室[-][714747]进行合成吧[-]",
	en = "[未翻译][714747]我们去[-][2CBF00]实验室[-][714747]进行合成吧[-]",
	zht = "[714747]我們去[-][2CBF00]實驗室[-][714747]進行合成吧[-]",
}
LocalizationConfig["loc_tutorial_28"] =
{
	zh = "[714747]前往实验室[-]",
	en = "[未翻译][714747]前往实验室[-]",
	zht = "[714747]前往實驗室[-]",
}
LocalizationConfig["loc_tutorial_29"] =
{
	zh = "[714747]合成目标小血瓶[-]",
	en = "[未翻译][714747]合成目标小血瓶[-]",
	zht = "[714747]合成目標小血瓶[-]",
}
LocalizationConfig["loc_tutorial_30"] =
{
	zh = "[714747]试试长按[-]",
	en = "[未翻译][714747]试试长按[-]",
	zht = "[714747]試試長按[-]",
}
LocalizationConfig["loc_tutorial_31"] =
{
	zh = "[714747]看看出现了什么神奇的按钮[-]",
	en = "[未翻译][714747]看看出现了什么神奇的按钮[-]",
	zht = "[714747]看看出現了什麼神奇的按鈕[-]",
}
LocalizationConfig["loc_tutorial_32"] =
{
	zh = "[714747]资源足够没问题[-]",
	en = "[未翻译][714747]资源足够没问题[-]",
	zht = "[714747]資源足夠沒問題[-]",
}
LocalizationConfig["loc_tutorial_33"] =
{
	zh = "[714747]去选择属性匹配的装备，让角色变得更强[-]",
	en = "[未翻译][714747]去选择属性匹配的装备，让角色变得更强[-]",
	zht = "[714747]去選擇屬性匹配的裝備，讓角色變得更強[-]",
}
LocalizationConfig["loc_tutorial_34"] =
{
	zh = "[714747]可以激活技能了，但是需要消耗角色喜欢的装备[-]",
	en = "[未翻译][714747]可以激活技能了，但是需要消耗角色喜欢的装备[-]",
	zht = "[714747]可以啟動技能了，但是需要消耗角色喜歡的裝備[-]",
}
LocalizationConfig["loc_tutorial_35"] =
{
	zh = "[714747]集齐皮肤碎片解锁皮肤[-]",
	en = "[未翻译][714747]集齐皮肤碎片解锁皮肤[-]",
	zht = "[714747]集齊皮膚碎片解鎖皮膚[-]",
}
LocalizationConfig["loc_tutorial_36"] =
{
	zh = "[714747]提交道具突破等级上限[-]",
	en = "[未翻译][714747]提交道具突破等级上限[-]",
	zht = "[714747]提交道具突破等級上限[-]",
}
LocalizationConfig["loc_tutorial_37"] =
{
	zh = "[714747]这是可以换装了吗？[-]",
	en = "[未翻译][714747]这是可以换装了吗？[-]",
	zht = "[714747]這是可以換裝了嗎？[-]",
}
LocalizationConfig["loc_tutorial_38"] =
{
	zh = "[714747]突破可以提升角色等级上限[-]",
	en = "[未翻译][714747]突破可以提升角色等级上限[-]",
	zht = "[714747]突破可以提升角色等級上限[-]",
}
LocalizationConfig["loc_tutorial_39"] =
{
	zh = "[714747]这里选择飞船[-]",
	en = "[未翻译][714747]这里选择飞船[-]",
	zht = "[714747]這裡選擇飛船[-]",
}
LocalizationConfig["loc_tutorial_40"] =
{
	zh = "[714747]飞船技能可以提供对整个星球的探索加成[-]",
	en = "[未翻译][714747]飞船技能可以提供对整个星球的探索加成[-]",
	zht = "[714747]飛船技能可以提供對整個星球的探索加成[-]",
}
LocalizationConfig["loc_tutorial_41"] =
{
	zh = "[714747]选好点击确定就好，记得飞船只有星球探索都完成的时候才可以更换哦[-]",
	en = "[未翻译][714747]选好点击确定就好，记得飞船只有星球探索都完成的时候才可以更换哦[-]",
	zht = "[714747]選好點擊確定就好，記得飛船只有星球探索都完成的時候才可以更換哦[-]",
}
LocalizationConfig["loc_tutorial_42"] =
{
	zh = "[714747]有新星球可以探索了[-][2CBF00]左右滑动[-][714747]可以切换星球，这次向左滑动吧[-]",
	en = "[未翻译][714747]有新星球可以探索了[-][2CBF00]左右滑动[-][714747]可以切换星球，这次向左滑动吧[-]",
	zht = "[714747]有新星球可以探索了[-][2CBF00]左右滑動[-][714747]可以切換星球，這次向左滑動吧[-]",
}
LocalizationConfig["loc_tutorial_43"] =
{
	zh = "[714747]角色还可以通过给特定物品来解放技能，就留给小猫咪们自己发现了！[-]",
	en = "[未翻译][714747]角色还可以通过给特定物品来解放技能，就留给小猫咪们自己发现了！[-]",
	zht = "[714747]角色還可以通過給特定物品來解放技能，就留給小貓咪們自己發現了！[-]",
}
LocalizationConfig["loc_tutorial_44"] =
{
	zh = "[714747]返回星球[-]",
	en = "[未翻译][714747]返回星球[-]",
	zht = "[714747]返回星球[-]",
}
LocalizationConfig["loc_tutorial_45"] =
{
	zh = "[714747]最后一步教程了，加油[-]",
	en = "[未翻译][714747]最后一步教程了，加油[-]",
	zht = "[714747]最後一步教程了，加油[-]",
}
LocalizationConfig["loc_global_item_source_battle"] =
{
	zh = "星球战斗",
	en = "[未翻译]星球战斗",
	zht = "星球戰鬥",
}
LocalizationConfig["loc_global_item_source_signin"] =
{
	zh = "每日登录",
	en = "[未翻译]每日登录",
	zht = "每日登錄",
}
LocalizationConfig["loc_global_deco_source_signin"] =
{
	zh = "登录获得",
	en = "[未翻译]登录获得",
	zht = "登錄獲得",
}
LocalizationConfig["loc_global_network_check"] =
{
	zh = "检查网络后重试",
	en = "[未翻译]检查网络后重试",
	zht = "檢查網路後重試",
}
LocalizationConfig["loc_test1"] =
{
	zh = "33.333333%的微笑",
	en = "[未翻译]33.333333%的微笑",
	zht = "33.333333%的微笑",
}
LocalizationConfig["loc_global_no_mail"] =
{
	zh = "邮箱空空如也呢",
	en = "[未翻译]邮箱空空如也呢",
	zht = "郵箱空空如也呢",
}
LocalizationConfig["loc_global_leaderboard_text1"] =
{
	zh = "排行榜每天刷新一次",
	en = "[未翻译]排行榜每天刷新一次",
	zht = "排行榜每天重繪一次",
}
LocalizationConfig["loc_global_leaderboard_text2"] =
{
	zh = "未排名",
	en = "[未翻译]未排名",
	zht = "未排名",
}
LocalizationConfig["loc_rankpage_title"] =
{
	zh = "排行榜",
	en = "[未翻译]排行榜",
	zht = "排行榜",
}
LocalizationConfig["loc_global_receieved_no"] =
{
	zh = "未领取",
	en = "[未翻译]未领取",
	zht = "未領取",
}
LocalizationConfig["loc_global_receieved"] =
{
	zh = "已领取",
	en = "[未翻译]已领取",
	zht = "已領取",
}
LocalizationConfig["loc_global_rare"] =
{
	zh = "小概率",
	en = "[未翻译]小概率",
	zht = "小概率",
}
LocalizationConfig["loc_global_skip"] =
{
	zh = "跳过",
	en = "Skip",
	zht = "跳過",
}
LocalizationConfig["loc_global_decoration_collect"] =
{
	zh = "快去领装修奖励吧！",
	en = "[未翻译]快去领装修奖励吧！",
	zht = "快去領裝修獎勵吧！",
}
LocalizationConfig["loc_global_maintenance"] =
{
	zh = "游戏维护中",
	en = "[未翻译]游戏维护中",
	zht = "遊戲維護中",
}
LocalizationConfig["loc_global_update_restart"] =
{
	zh = "检测到文件更新，需要重新启动游戏",
	en = "[未翻译]检测到文件更新，需要重新启动游戏",
	zht = "檢測到檔更新，需要重新開機遊戲",
}
LocalizationConfig["loc_global_sell"] =
{
	zh = "卖掉",
	en = "[未翻译]卖掉",
	zht = "賣掉",
}
LocalizationConfig["loc_global_nickname"] =
{
	zh = "玩家昵称",
	en = "[未翻译]玩家昵称",
	zht = "玩家昵稱",
}
LocalizationConfig["loc_global_days"] =
{
	zh = "游戏天数",
	en = "[未翻译]游戏天数",
	zht = "遊戲天數",
}
LocalizationConfig["loc_global_nickname_modify"] =
{
	zh = "修改昵称",
	en = "[未翻译]修改昵称",
	zht = "修改昵稱",
}
LocalizationConfig["loc_global_bind_phone"] =
{
	zh = "绑定手机号",
	en = "[未翻译]绑定手机号",
	zht = "綁定手機號",
}
LocalizationConfig["loc_global_bind_ID"] =
{
	zh = "实名认证",
	en = "[未翻译]实名认证",
	zht = "實名認證",
}
LocalizationConfig["loc_global_sensitive_words"] =
{
	zh = "昵称含有敏感词",
	en = "[未翻译]昵称含有敏感词",
	zht = "昵稱含有敏感詞",
}
LocalizationConfig["loc_global_nickname_modify1"] =
{
	zh = "昵称长度要求在1到10个字符之间",
	en = "[未翻译]昵称长度要求在1到10个字符之间",
	zht = "昵稱長度要求在1到10個字元之間",
}
LocalizationConfig["loc_global_nickname_modify2"] =
{
	zh = "昵称只能包含中文﹑英文字母和数字",
	en = "[未翻译]昵称只能包含中文﹑英文字母和数字",
	zht = "昵稱只能包含中文﹑英文字母和數位",
}
LocalizationConfig["loc_global_password_rule1"] =
{
	zh = "密码长度要求在6到18个字符之间",
	en = "[未翻译]密码长度要求在6到18个字符之间",
	zht = "密碼長度要求在6到18個字元之間",
}
LocalizationConfig["loc_global_password_rule2"] =
{
	zh = "密码必须且只能使用字母+数字组合",
	en = "[未翻译]密码必须且只能使用字母+数字组合",
	zht = "密碼必須且只能使用字母+數位組合",
}
LocalizationConfig["loc_global_id_password_error"] =
{
	zh = "账号密码错误",
	en = "[未翻译]账号密码错误",
	zht = "帳號密碼錯誤",
}
LocalizationConfig["loc_global_id_password_deactivated"] =
{
	zh = "账号被停用",
	en = "[未翻译]账号被停用",
	zht = "帳號被停用",
}
LocalizationConfig["loc_global_id_nickname_used"] =
{
	zh = "昵称已有人使用",
	en = "[未翻译]昵称已有人使用",
	zht = "昵稱已有人使用",
}
LocalizationConfig["loc_global_id_password_noexists"] =
{
	zh = "账号不存在",
	en = "[未翻译]账号不存在",
	zht = "帳號不存在",
}
LocalizationConfig["loc_exploring_equipment_unable"] =
{
	zh = "探索中，不能更换装备",
	en = "[未翻译]探索中，不能更换装备",
	zht = "探索中，不能更換裝備",
}
LocalizationConfig["loc_upgrade_upperlimit"] =
{
	zh = "探索队伍人数上限+%d",
	en = "[未翻译]探索队伍人数上限+%d",
	zht = "探索隊伍人數上限+%d",
}
LocalizationConfig["loc_gallery"] =
{
	zh = "图鉴",
}
LocalizationConfig["loc_warehouse"] =
{
	zh = "仓库",
	en = "Warehouse",
	zht = "倉庫",
}
LocalizationConfig["loc_lounge"] =
{
	zh = "休息室",
	en = "Lounge",
	zht = "休息室",
}
LocalizationConfig["loc_market"] =
{
	zh = "市场",
	en = "Market",
	zht = "市场",
}
LocalizationConfig["loc_blackhole"] =
{
	zh = "不夜城",
}
LocalizationConfig["loc_arena"] =
{
	zh = "流亡街",
}
LocalizationConfig["loc_promote"] =
{
	zh = "突破",
	en = "[未翻译]突破",
	zht = "突破",
}
LocalizationConfig["loc_characterpromote_title"] =
{
	zh = "生物实验室",
	en = "[未翻译]生物实验室",
	zht = "生物實驗室",
}
LocalizationConfig["loc_characterskill_unlock"] =
{
	zh = "解锁角色技能",
	en = "[未翻译]解锁角色技能",
	zht = "解鎖角色技能",
}
LocalizationConfig["loc_account_healthtips"] =
{
	zh = "      《健康游戏忠告》      \n抵制不良游戏，拒绝盗版游戏。适度游戏益脑，沉迷游戏伤身。\n注意自我保护，谨防受骗上当。合理安排时间，享受健康生活。",
	en = " ",
	zht = " ",
}
LocalizationConfig["loc_account_nickname_login"] =
{
	zh = "昵称登陆",
	en = "Nickname login",
	zht = "昵稱登陸",
}
LocalizationConfig["loc_account_startgame"] =
{
	zh = "开始游戏",
	en = "Start game",
	zht = "開始遊戲",
}
LocalizationConfig["loc_account_gamelogo"] =
{
	zh = "Airship",
	en = "Airship_EN",
	zht = "Airship",
}
LocalizationConfig["loc_account_nickname"] =
{
	zh = "昵称",
	en = "Nickname",
	zht = "昵稱",
}
LocalizationConfig["loc_account_initialpassword"] =
{
	zh = "初始密码",
	en = "Initial Password",
	zht = "初始密碼",
}
LocalizationConfig["loc_account_newpassword"] =
{
	zh = "新密码",
	en = "New Password",
	zht = "新密碼",
}
LocalizationConfig["loc_account_password_confirm"] =
{
	zh = "确认密码",
	en = "Confirm Password",
	zht = "確認密碼",
}
LocalizationConfig["loc_account_nickname_wrong"] =
{
	zh = "昵称或密码错误",
	en = "Wrong Nicknname of Passowrd",
	zht = "昵稱或密碼錯誤",
}
LocalizationConfig["loc_account_verification_code1"] =
{
	zh = "获取验证码",
	en = "Get the code",
	zht = "獲取驗證碼",
}
LocalizationConfig["loc_account_verification_code2"] =
{
	zh = "验证码",
	en = "Verification code",
	zht = "驗證碼",
}
LocalizationConfig["loc_account_phone_number"] =
{
	zh = "手机号",
	en = "Phone number",
	zht = "手機號",
}
LocalizationConfig["loc_account_newID"] =
{
	zh = "创建新账号",
	en = "Create a new account",
	zht = "創建新帳號",
}
LocalizationConfig["loc_account_service"] =
{
	zh = "客服",
	en = "Customer service",
	zht = "客服",
}
LocalizationConfig["loc_account_password_modify"] =
{
	zh = "修改密码",
	en = "Change password",
	zht = "修改密碼",
}
LocalizationConfig["loc_account_password_reset"] =
{
	zh = "重置密码",
	en = "Reset password",
	zht = "重置密碼",
}
LocalizationConfig["loc_account_setID"] =
{
	zh = "赶紧设置昵称账号，等你丢了就傻眼了。",
	en = "Please set up a nickname account",
	zht = "趕緊設置昵稱帳號，等你丟了就傻眼了。",
}
LocalizationConfig["loc_account_password"] =
{
	zh = "密码",
	en = "Password",
	zht = "密碼",
}
LocalizationConfig["loc_challenge_level_select"] =
{
	zh = "选择挑战等级",
	en = "Challenge level",
	zht = "選擇挑战等級",
}
LocalizationConfig["loc_global_CantStart"] =
{
	zh = "钱不够，走不了",
	en = "Not enough money to go",
	zht = "錢不夠，走不了",
}
LocalizationConfig["loc_challenge_rules"] =
{
	zh = "本周规则",
	en = "Rules of the week",
	zht = "本周規則",
}
LocalizationConfig["loc_skin_change"] =
{
	zh = "换上",
	en = "Change",
	zht = "換上",
}
LocalizationConfig["loc_skill_describe"] =
{
	zh = "技能描述",
	en = "Skill description：",
	zht = "技能描述",
}
LocalizationConfig["loc_Reward_and_explore"] =
{
	zh = "领取并探索",
	en = "Receive and explore",
	zht = "領取並探索",
}
LocalizationConfig["loc_GalleryRank"] =
{
	zh = "排名",
	en = "Rank",
	zht = "排名",
}
LocalizationConfig["loc_cancellation"] =
{
	zh = "注销",
	en = "Cancellation",
	zht = "註銷",
}
LocalizationConfig["loc_global_IAPshop"] =
{
	zh = "商店",
	en = "Shop",
	zht = "商店",
}
LocalizationConfig["loc_global_IAPshop_Discount"] =
{
	zh = "首充翻倍",
	en = "[未翻译]首充翻倍",
	zht = "首充翻倍",
}
LocalizationConfig["loc_market_not_enough"] =
{
	zh = "不够",
	en = "Not enough",
	zht = "不夠",
}
LocalizationConfig["loc_market_Sold"] =
{
	zh = "已售完",
	en = "Sold",
	zht = "已售",
}
LocalizationConfig["loc_market_Refresh"] =
{
	zh = "刷新",
	en = "Refresh",
	zht = "重繪",
}
LocalizationConfig["loc_mail_previous"] =
{
	zh = "上一封",
	en = "Previous",
	zht = "上一封",
}
LocalizationConfig["loc_mail_next"] =
{
	zh = "下一封",
	en = "Next",
	zht = "下一封",
}
LocalizationConfig["loc_global_new"] =
{
	zh = "新",
	en = "New",
	zht = "新",
}
LocalizationConfig["loc_SuitBonuses"] =
{
	zh = "套装奖励",
	en = "[未翻译]套装奖励",
	zht = "套裝獎勵",
}
LocalizationConfig["loc_Drop_Objects"] =
{
	zh = "掉落物品",
	en = "[未翻译]掉落物品",
	zht = "掉落物品",
}
LocalizationConfig["loc_Probability_Publicity"] =
{
	zh = "概率公示",
	en = "[未翻译]概率公示",
	zht = "概率公示",
}
LocalizationConfig["loc_Change_Position"] =
{
	zh = "换个姿势",
	en = "[未翻译]换个姿势",
	zht = "換個姿勢",
}
LocalizationConfig["loc_summon_share"] =
{
	zh = "炫耀",
	en = "Share",
	zht = "炫耀",
}
LocalizationConfig["loc_summon_had"] =
{
	zh = "已有",
	en = "Had",
	zht = "已有",
}
LocalizationConfig["loc_jade_gift"] =
{
	zh = "{Num}枚玉璧\n赠送{NumPlus}枚玉璧",
	en = "[未翻译]{Num}枚玉璧\n赠送{NumPlus}枚玉璧",
	zht = "{Num}枚玉璧\n贈送{NumPlus}枚玉璧",
}
LocalizationConfig["loc_Unconnected"] =
{
	zh = "未接通",
	en = "[未翻译]未接通",
	zht = "未接通",
}
LocalizationConfig["loc_summon_ID_1"] =
{
	zh = "绿色奖池",
	en = "[未翻译]绿色奖池",
	zht = "綠色獎池",
}
LocalizationConfig["loc_summon_ID_2"] =
{
	zh = "甜蜜奖池",
	en = "[未翻译]甜蜜奖池",
	zht = "甜蜜獎池",
}
LocalizationConfig["loc_summon_ID_3"] =
{
	zh = "破烂奖池",
	en = "[未翻译]破烂奖池",
	zht = "破爛獎池",
}
LocalizationConfig["loc_summon_ID_4"] =
{
	zh = "阴森奖池",
	en = "[未翻译]阴森奖池",
	zht = "陰森獎池",
}
LocalizationConfig["loc_exploring_all_attribute"] =
{
	zh = "全属性",
	en = "[未翻译]全属性",
	zht = "全屬性",
}
LocalizationConfig["loc_ItemDetail_From"] =
{
	zh = "来自",
	en = "From",
	zht = "來自",
}
LocalizationConfig["loc_exploring_ship_unable"] =
{
	zh = "探索中，不能更换飞船",
	en = "[未翻译]探索中，不能更换飞船",
	zht = "探索中，不能更換飛船",
}
LocalizationConfig["loc_global_Maxed"] =
{
	zh = "满级",
	en = "[未翻译]满级",
	zht = "滿級",
}
LocalizationConfig["loc_Item_formula"] =
{
	zh = "{Value}配方",
	en = "recipe of {value}",
	zht = "{Value}配方",
}
LocalizationConfig["loc_global_Go"] =
{
	zh = "前往",
	en = "[未翻译]前往",
	zht = "前往",
}
LocalizationConfig["loc_account_DifferentPlaces"] =
{
	zh = "该账号已在其他设备上登录，需要重新登录游戏",
	en = "[未翻译]该账号已在其他设备上登录，需要重新登录游戏",
	zht = "該帳號已在其他設備上登錄，需要重新登錄遊戲",
}
LocalizationConfig["loc_MarketDialogue"] =
{
	zh = "都是通过特殊渠道搞来的小玩意儿，客人要是看得上的只管拿走吧~~",
	en = "[未翻译]都是通过特殊渠道搞来的小玩意儿，客人要是看得上的只管拿走吧~~",
	zht = "收購各種物品，價格美麗，我的臉雖然很黑，可我的心，一點都不黑！",
}
LocalizationConfig["loc_Network_error"] =
{
	zh = "网络连接出错，游戏将重启",
	en = "Network Connection Error,the game will be restarted",
	zht = "網路連接出錯，遊戲將重啟",
}
LocalizationConfig["loc_EnemyRarity_1"] =
{
	zh = "到处都有",
	en = "Everywhere",
	zht = "到处都有",
}
LocalizationConfig["loc_EnemyRarity_2"] =
{
	zh = "普通",
	en = "Normal",
	zht = "普通",
}
LocalizationConfig["loc_EnemyRarity_3"] =
{
	zh = "稀有",
	en = "Rare",
	zht = "稀有",
}
LocalizationConfig["loc_EnemyRarity_4"] =
{
	zh = "超稀有",
	en = "Super Rare",
	zht = "超稀有",
}
LocalizationConfig["loc_Global_Workshop"] =
{
	zh = "打工",
	en = "Workshop",
	zht = "打工",
}
LocalizationConfig["loc_Global_Zoo"] =
{
	zh = "动物园",
	en = "Zoo",
	zht = "动物园",
}
LocalizationConfig["loc_Global_Explore_Food"] =
{
	zh = "食物",
	en = "Food",
	zht = "食物",
}
LocalizationConfig["loc_Global_Explore_Item"] =
{
	zh = "道具",
	en = "Item",
	zht = "道具",
}
LocalizationConfig["loc_Upgrade"] =
{
	zh = "升级",
	en = "Upgrade",
	zht = "升级",
}
LocalizationConfig["loc_promoteToUnlockSkill"] =
{
	zh = "升阶后解锁技能",
	en = "Promote to unlock skill",
	zht = "升阶后解锁技能",
}
LocalizationConfig["loc_Food"] =
{
	zh = "食物",
	en = "[未翻译]食物",
	zht = "[未翻译]食物",
}
LocalizationConfig["loc_CatchItem"] =
{
	zh = "捕捉",
	en = "[未翻译]捕捉",
	zht = "[未翻译]捕捉",
}
LocalizationConfig["loc_EventItem"] =
{
	zh = "玩具",
	en = "[未翻译]玩具",
	zht = "[未翻译]玩具",
}
LocalizationConfig["loc_CharacterStageUp_1"] =
{
	zh = "2星激活技能",
	en = "[未翻译]2星激活技能",
	zht = "[未翻译]2星激活技能",
}
LocalizationConfig["loc_CharacterStageUp_2"] =
{
	zh = "3星技能变强",
	en = "[未翻译]3星技能变强",
	zht = "[未翻译]3星技能变强",
}
LocalizationConfig["loc_CharacterStageUp_3"] =
{
	zh = "满阶~撒花~",
	en = "[未翻译]满阶~撒花~",
	zht = "[未翻译]满阶~撒花~",
}
LocalizationConfig["loc_Storge_Explore"] =
{
	zh = "探索",
	en = "[未翻译]探索",
	zht = "[未翻译]探索",
}
LocalizationConfig["loc_Storge_Material"] =
{
	zh = "素材",
	en = "[未翻译]素材",
	zht = "[未翻译]素材",
}
LocalizationConfig["loc_Storge_Chip"] =
{
	zh = "珍宝",
	en = "[未翻译]珍宝",
	zht = "[未翻译]珍宝",
}
LocalizationConfig["loc_Storge_Pet"] =
{
	zh = "宠物",
	en = "[未翻译]宠物",
	zht = "[未翻译]宠物",
}
LocalizationConfig["loc_Storge_Event"] =
{
	zh = "玩具",
	en = "[未翻译]玩具",
	zht = "[未翻译]玩具",
}
LocalizationConfig["loc_global_mailIsOverdue"] =
{
	zh = "{Time}后过期",
	en = "[未翻译]{Time}后过期",
	zht = "[未翻译]{Time}后过期",
}
LocalizationConfig["loc_global_item_source_arenamarket"] =
{
	zh = "商店",
	en = "[未翻译]商店",
	zht = "[未翻译]商店",
}
LocalizationConfig["loc_global_item_source_workshop"] =
{
	zh = "打工",
	en = "[未翻译]打工",
	zht = "[未翻译]打工",
}
LocalizationConfig["loc_global_item_source_challenge"] =
{
	zh = "挑战",
	en = "[未翻译]挑战",
	zht = "[未翻译]挑战",
}
LocalizationConfig["loc_global_item_source_event"] =
{
	zh = "事件",
	en = "[未翻译]事件",
	zht = "[未翻译]事件",
}
LocalizationConfig["loc_global_item_source_arena"] =
{
	zh = "流亡街",
	en = "[未翻译]流亡街",
	zht = "[未翻译]流亡街",
}
LocalizationConfig["loc_global_exploretime_original"] =
{
	zh = "{Time}",
	en = "[未翻译]{Time}",
	zht = "[未翻译]{Time}",
}
LocalizationConfig["loc_global_exploretime_skillReduce"] =
{
	zh = "技能 -{Time}",
	en = "[未翻译]技能 -{Time}",
	zht = "[未翻译]技能 -{Time}",
}
LocalizationConfig["loc_global_exploretime_skillIncrease"] =
{
	zh = "技能 +{Time}",
	en = "[未翻译]技能 +{Time}",
	zht = "[未翻译]技能 +{Time}",
}
LocalizationConfig["loc_challenge_need_exploretime"] =
{
	zh = "需要探索\n{Time}",
	en = "[未翻译]需要探索\n{Time}",
	zht = "[未翻译]需要探索\n{Time}",
}
LocalizationConfig["loc_comic1_sentense1"] =
{
	zh = "某一天……",
	en = "This is a galaxy ruled by kitties",
	zht = "這是一個被貓咪統治的星系",
}
LocalizationConfig["loc_comic1_sentense2"] =
{
	zh = "在一个神秘宇宙的图书馆里",
	en = "Now why is the galaxy ruled by kitties?",
	zht = "至於貓咪為什麼會統治星系呢",
}
LocalizationConfig["loc_comic1_sentense3"] =
{
	zh = "两个小猫在打赌，输的吃一本书。",
	en = "Well, the answer is",
	zht = "呃，其實答案很簡單",
}
LocalizationConfig["loc_comic1_sentense4"] =
{
	zh = "比赛内容没人知道~",
	en = "I don't really know either",
	zht = "我也不知道",
}
LocalizationConfig["loc_comic1_sentense5"] =
{
	zh = "最后，小黑猫输了……",
	en = "One day…",
	zht = "某一天…………",
}
LocalizationConfig["loc_comic2_sentense6"] =
{
	zh = "就这本~吃掉！",
	en = "However, considering your status as a Count,",
	zht = "考慮到你伯爵的身份,",
}
LocalizationConfig["loc_comic2_sentense7"] =
{
	zh = "这么大一本！",
	en = "You are now ordered to collect rent in unknown galaxies instead. ",
	zht = "發配你去未知星系探索收租。",
}
LocalizationConfig["loc_comic2_sentense8"] =
{
	zh = "保险柜里拿的喵~",
	en = "You will be sent to the Weird Nebulas",
	zht = "你會被發配到怪咖星雲",
}
LocalizationConfig["loc_comic2_sentense1"] =
{
	zh = "呜呜！你是不是拿了星际图鉴！",
	en = "Wuwu! You broke the king's favorite vase!",
	zht = "嗚嗚！你打碎大王最愛的花瓶。",
}
LocalizationConfig["loc_comic2_sentense2"] =
{
	zh = "喵嗷！！你们在吃什么书！",
	en = "You know what punishments await you right!",
	zht = "要受到什麼懲罰，心裡應該清楚了吧！",
}
LocalizationConfig["loc_comic3_sentense1"] =
{
	zh = "喵？",
	en = "Eh, about",
	zht = "呃，大概",
}
LocalizationConfig["loc_comic3_sentense2"] =
{
	zh = "好像闯祸了……",
	en = " a week without dried salmon…",
	zht = "一個禮拜不能吃三文魚幹……",
}
LocalizationConfig["loc_comic2_sentense3"] =
{
	zh = "是《星际图鉴》？！",
	en = "According to the Meow Meow Code of Law published last year,",
	zht = "根據去年頒佈的貓咪法典，",
}
LocalizationConfig["loc_comic2_sentense4"] =
{
	zh = "竟然把珍贵的SSS级藏品吃掉了？！",
	en = "Damage done to items worth over a million Meownies ",
	zht = "破壞價值百萬貓幣以上的物品",
}
LocalizationConfig["loc_comic2_sentense5"] =
{
	zh = "罚你禁闭十天而且没零食吃！",
	en = "Means banishment to space!!",
	zht = "是要流放太空的！！",
}
LocalizationConfig["loc_comic3_sentense3"] =
{
	zh = "喵……",
	en = "!! What!!!",
	zht = "！！神馬",
}
LocalizationConfig["loc_comic3_sentense4"] =
{
	zh = "我还是小猫……",
	en = "I'm not even an adult yet",
	zht = "我還沒成年",
}
LocalizationConfig["loc_comic3_sentense5"] =
{
	zh = "没零食吃是不是太过分了……",
	en = "Sending me to space, that might as well means I'm dead!",
	zht = "流放太空等於直接送我去死呀！",
}
LocalizationConfig["loc_comic3_sentense6"] =
{
	zh = "总管大人！",
	en = "Grand Keeper!",
	zht = "總管大人！",
}
LocalizationConfig["loc_comic3_sentense7"] =
{
	zh = "书是我吃的！不要罚呜呜！",
	en = "Please let me go with Wuwu!",
	zht = "請讓我和嗚嗚一起去吧！",
}
LocalizationConfig["loc_comic2_sentense9"] =
{
	zh = "嗷……如果不想被罚的话……",
	en = "But there's no rule that you can't go together",
	zht = "到沒有規定不可以主動一起前往。",
}
LocalizationConfig["loc_comic2_sentense10"] =
{
	zh = "就必须把缺失的资料补回来！",
	en = "However, be sure to think about it clearly.",
	zht = "不過你要想清楚。",
}
LocalizationConfig["loc_comic2_sentense11"] =
{
	zh = "要和原来的一模一样才行！",
	en = "Because you may never make it back home.",
	zht = "當心有去無回。",
}
LocalizationConfig["loc_comic3_sentense8"] =
{
	zh = "放心吧！总管大人！",
	en = "I can't be without Wuwu,",
	zht = "沒有嗚嗚就沒有我，",
}
LocalizationConfig["loc_comic3_sentense9"] =
{
	zh = "呜呜，出发喵~",
	en = "I'm going as well!",
	zht = "我要去!",
}
LocalizationConfig["loc_comic4_sentense1"] =
{
	zh = "报告！",
	en = "Report!",
	zht = "報告！",
}
LocalizationConfig["loc_comic4_sentense2"] =
{
	zh = "引擎失火！",
	en = "A crash has been recorded!",
	zht = "發生墜機！",
}
LocalizationConfig["loc_comic4_sentense3"] =
{
	zh = "准备进入近地轨道！",
	en = "Report!",
	zht = "報告！！",
}
LocalizationConfig["loc_comic4_sentense4"] =
{
	zh = "准备紧急迫降！打开休眠舱！",
	en = "Due to the accident, the sleeping pods will be opened before schedule!",
	zht = "發生意外，提前打開睡眠倉！",
}
LocalizationConfig["loc_comic6_sentense1"] =
{
	zh = "喵~这么快就到了？哈欠~",
	en = "Meow, how did we get here so fast? I wanted to nap a little more.",
	zht = "喵啊，怎麼這麼快就到了，我還沒睡夠呢。",
}
LocalizationConfig["loc_comic6_sentense2"] =
{
	zh = "喵？这是哪里喵？出去看看吧~",
	en = "Seems like we've arrived in a strange place, let's go take a look outside.",
	zht = "好像到了奇怪的地方，出去看看吧。",
}
LocalizationConfig["loc_tutorials_mission1_1"] =
{
	zh = "[652B2B]登陆未知星球，室外气温24℃。[-]",
	en = "[未翻译][652B2B]登陆未知星球，室外气温24℃。[-]",
	zht = "[未翻译][652B2B]登陆未知星球，室外气温24℃。[-]",
}
LocalizationConfig["loc_tutorials_mission1_2"] =
{
	zh = "[652B2B]那么，探索下\n着陆点吧~[-]",
	en = "[未翻译][652B2B]那么，探索下\n着陆点吧~[-]",
	zht = "[未翻译][652B2B]那么，探索下\n着陆点吧~[-]",
}
LocalizationConfig["loc_tutorials_mission1_2_1"] =
{
	zh = "[652B2B]出发！[-]",
	en = "[未翻译][652B2B]出发！[-]",
	zht = "[未翻译][652B2B]出发！[-]",
}
LocalizationConfig["loc_tutorials_mission1_3"] =
{
	zh = "[652B2B]派遣呜呜上场[-]",
	en = "[未翻译][652B2B]派遣呜呜上场[-]",
	zht = "[未翻译][652B2B]派遣呜呜上场[-]",
}
LocalizationConfig["loc_tutorials_mission1_4"] =
{
	zh = "[652B2B]史莱姆出没，要求队伍战力160！[-]",
	en = "[未翻译][652B2B]史莱姆出没，要求队伍战力160！[-]",
	zht = "[未翻译][652B2B]史莱姆出没，要求队伍战力160！[-]",
}
LocalizationConfig["loc_tutorials_mission1_5"] =
{
	zh = "[652B2B]派遣漆漆增援[-]",
	en = "[未翻译][652B2B]派遣漆漆增援[-]",
	zht = "[未翻译][652B2B]派遣漆漆增援[-]",
}
LocalizationConfig["loc_tutorials_mission1_6"] =
{
	zh = "[652B2B]这样就能击败沿途的史莱姆了！[-]",
	en = "[未翻译][652B2B]这样就能击败沿途的史莱姆了！[-]",
	zht = "[未翻译][652B2B]这样就能击败沿途的史莱姆了！[-]",
}
LocalizationConfig["loc_tutorials_mission1_7"] =
{
	zh = "[652B2B]人员确定！[-]",
	en = "[未翻译][652B2B]人员确定！[-]",
	zht = "[未翻译][652B2B]人员确定！[-]",
}
LocalizationConfig["loc_tutorials_mission1_8"] =
{
	zh = "[652B2B]带上口粮\n探索1分30秒![-]",
	en = "[未翻译][652B2B]带上口粮\n探索1分30秒![-]",
	zht = "[未翻译][652B2B]带上口粮\n探索1分30秒![-]",
}
LocalizationConfig["loc_tutorials_mission1_9"] =
{
	zh = "[652B2B]出发！[-]",
	en = "[未翻译][652B2B]出发！[-]",
	zht = "[未翻译][652B2B]出发！[-]",
}
LocalizationConfig["loc_tutorials_mission1_10"] =
{
	zh = "[652B2B]本次直接加速完成吧~[-]",
	en = "[未翻译][652B2B]本次直接加速完成吧~[-]",
	zht = "[未翻译][652B2B]本次直接加速完成吧~[-]",
}
LocalizationConfig["loc_tutorials_mission1_11"] =
{
	zh = "[652B2B]点它！[-]",
	en = "[未翻译][652B2B]点它！[-]",
	zht = "[未翻译][652B2B]点它！[-]",
}
LocalizationConfig["loc_tutorials_mission1_12"] =
{
	zh = "[652B2B]探索完成喵~\n因为时间短，没遇到敌人喵~[-]",
	en = "[未翻译][652B2B]探索完成喵~\n因为时间短，没遇到敌人喵~[-]",
	zht = "[未翻译][652B2B]探索完成喵~\n因为时间短，没遇到敌人喵~[-]",
}
LocalizationConfig["loc_tutorials_mission1_13"] =
{
	zh = "[652B2B]任务完成！\n请签收奖励！[-]",
	en = "[未翻译][652B2B]任务完成！\n请签收奖励！[-]",
	zht = "[未翻译][652B2B]任务完成！\n请签收奖励！[-]",
}
LocalizationConfig["loc_tutorials_mission1_14"] =
{
	zh = "[652B2B]收到总部奖励，请收件人签收！[-]",
	en = "[未翻译][652B2B]收到总部奖励，请收件人签收！[-]",
	zht = "[未翻译][652B2B]收到总部奖励，请收件人签收！[-]",
}
LocalizationConfig["loc_tutorials_mission2_1"] =
{
	zh = "[652B2B]请前往舱室进行队员升级作业[-]",
	en = "[未翻译][652B2B]请前往舱室进行队员升级作业[-]",
	zht = "[未翻译][652B2B]请前往舱室进行队员升级作业[-]",
}
LocalizationConfig["loc_tutorials_mission2_2"] =
{
	zh = "[652B2B]升级对象：呜呜\n点击进入升级板[-]",
	en = "[未翻译][652B2B]升级对象：呜呜\n点击进入升级板[-]",
	zht = "[未翻译][652B2B]升级对象：呜呜\n点击进入升级板[-]",
}
LocalizationConfig["loc_tutorials_mission2_3"] =
{
	zh = "[652B2B]点击升级[-]",
	en = "[未翻译][652B2B]点击升级[-]",
	zht = "[未翻译][652B2B]点击升级[-]",
}
LocalizationConfig["loc_tutorials_mission2_4"] =
{
	zh = "[652B2B]点它去交任务！[-]",
	en = "[未翻译][652B2B]点它去交任务！[-]",
	zht = "[未翻译][652B2B]点它去交任务！[-]",
}
LocalizationConfig["loc_tutorials_mission2_5"] =
{
	zh = "[652B2B]点它！[-]",
	en = "[未翻译][652B2B]点它！[-]",
	zht = "[未翻译][652B2B]点它！[-]",
}
LocalizationConfig["loc_tutorials_mission3_1"] =
{
	zh = "[652B2B]报告！收到本地怪物的挑战书，请前往查看[-]",
	en = "[未翻译][652B2B]报告！收到本地怪物的挑战书，请前往查看[-]",
	zht = "[未翻译][652B2B]报告！收到本地怪物的挑战书，请前往查看[-]",
}
LocalizationConfig["loc_tutorials_mission3_2"] =
{
	zh = "[652B2B]先观察一下[-]",
	en = "[未翻译][652B2B]先观察一下[-]",
	zht = "[未翻译][652B2B]先观察一下[-]",
}
LocalizationConfig["loc_tutorials_mission3_3"] =
{
	zh = "[652B2B]让防御型的呜呜先上[-]",
	en = "[未翻译][652B2B]让防御型的呜呜先上[-]",
	zht = "[未翻译][652B2B]让防御型的呜呜先上[-]",
}
LocalizationConfig["loc_tutorials_mission3_4"] =
{
	zh = "[652B2B]怪物会先攻击靠右队员[-]",
	en = "[未翻译][652B2B]怪物会先攻击靠右队员[-]",
	zht = "[未翻译][652B2B]怪物会先攻击靠右队员[-]",
}
LocalizationConfig["loc_tutorials_mission3_5"] =
{
	zh = "[652B2B]让攻击型的漆漆躲在后面[-]",
	en = "[未翻译][652B2B]让攻击型的漆漆躲在后面[-]",
	zht = "[未翻译][652B2B]让攻击型的漆漆躲在后面[-]",
}
LocalizationConfig["loc_tutorials_mission3_6"] =
{
	zh = "[652B2B]准备就绪！\n出发！[-]",
	en = "[未翻译][652B2B]准备就绪！\n出发！[-]",
	zht = "[未翻译][652B2B]准备就绪！\n出发！[-]",
}
LocalizationConfig["loc_tutorials_mission5_1"] =
{
	zh = "[652B2B]已接通空间站，\n请前往打工板！[-]",
	en = "[未翻译][652B2B]已接通空间站，\n请前往打工板！[-]",
	zht = "[未翻译][652B2B]已接通空间站，\n请前往打工板！[-]",
}
LocalizationConfig["loc_tutorials_mission5_2"] =
{
	zh = "[652B2B]道具店招工中，\n请进入查看！[-]",
	en = "[未翻译][652B2B]道具店招工中，\n请进入查看！[-]",
	zht = "[未翻译][652B2B]道具店招工中，\n请进入查看！[-]",
}
LocalizationConfig["loc_tutorials_mission5_3"] =
{
	zh = "[652B2B]让居民NPC进行试工！[-]",
	en = "[未翻译][652B2B]让居民NPC进行试工！[-]",
	zht = "[未翻译][652B2B]让居民NPC进行试工！[-]",
}
LocalizationConfig["loc_tutorials_mission5_4"] =
{
	zh = "[652B2B]试工通过！\n提升评价可获得更多报酬！[-]",
	en = "[未翻译][652B2B]试工通过！\n提升评价可获得更多报酬！[-]",
	zht = "[未翻译][652B2B]试工通过！\n提升评价可获得更多报酬！[-]",
}
LocalizationConfig["loc_tutorials_mission5_5"] =
{
	zh = "[652B2B]人员确认，\n开始干活！[-]",
	en = "[未翻译][652B2B]人员确认，\n开始干活！[-]",
	zht = "[未翻译][652B2B]人员确认，\n开始干活！[-]",
}
LocalizationConfig["loc_tutorials_mission5_6"] =
{
	zh = "[652B2B]打工报酬根据钟点定期结清，请记得查收！[-]",
	en = "[未翻译][652B2B]打工报酬根据钟点定期结清，请记得查收！[-]",
	zht = "[未翻译][652B2B]打工报酬根据钟点定期结清，请记得查收！[-]",
}
LocalizationConfig["loc_tutorials_mission5_7"] =
{
	zh = "[652B2B]使用加班后可直接获得最大工时对应奖励！[-]",
	en = "[未翻译][652B2B]使用加班后可直接获得最大工时对应奖励！[-]",
	zht = "[未翻译][652B2B]使用加班后可直接获得最大工时对应奖励！[-]",
}
LocalizationConfig["loc_tutorials_mission7_1"] =
{
	zh = "[652B2B]请前往舱室进行装备升级作业[-]",
	en = "[未翻译][652B2B]请前往舱室进行装备升级作业[-]",
	zht = "[未翻译][652B2B]请前往舱室进行装备升级作业[-]",
}
LocalizationConfig["loc_tutorials_mission7_2"] =
{
	zh = "[652B2B]检测到项圈可升级！[-]",
	en = "[未翻译][652B2B]检测到项圈可升级！[-]",
	zht = "[未翻译][652B2B]检测到项圈可升级！[-]",
}
LocalizationConfig["loc_tutorials_mission7_3"] =
{
	zh = "[652B2B]检查所需清单，\n物资满足！[-]",
	en = "[未翻译][652B2B]检查所需清单，\n物资满足！[-]",
	zht = "[未翻译][652B2B]检查所需清单，\n物资满足！[-]",
}
LocalizationConfig["loc_tutorials_mission7_4"] =
{
	zh = "[652B2B]升级对象：项圈\n确认升级！[-]",
	en = "[未翻译][652B2B]升级对象：项圈\n确认升级！[-]",
	zht = "[未翻译][652B2B]升级对象：项圈\n确认升级！[-]",
}
LocalizationConfig["loc_tutorials_mission11_1"] =
{
	zh = "[652B2B]实验室修好了，去看看！[-]",
	en = "[未翻译][652B2B]实验室修好了，去看看！[-]",
	zht = "[未翻译][652B2B]实验室修好了，去看看！[-]",
}
LocalizationConfig["loc_tutorials_mission11_2"] =
{
	zh = "[652B2B]实验室可以一次性合成多个道具[-]",
	en = "[未翻译][652B2B]实验室可以一次性合成多个道具[-]",
	zht = "[未翻译][652B2B]实验室可以一次性合成多个道具[-]",
}
LocalizationConfig["loc_tutorials_mission11_3"] =
{
	zh = "[652B2B]素材充足，\n立刻合成！[-]",
	en = "[未翻译][652B2B]素材充足，\n立刻合成！[-]",
	zht = "[未翻译][652B2B]素材充足，\n立刻合成！[-]",
}
LocalizationConfig["loc_tutorials_mission11_4"] =
{
	zh = "[652B2B]直接回任务界面吧~[-]",
	en = "[未翻译][652B2B]直接回任务界面吧~[-]",
	zht = "[未翻译][652B2B]直接回任务界面吧~[-]",
}
LocalizationConfig["loc_tutorials_mission12_1"] =
{
	zh = "[652B2B]请前往空间站考察道具店情况！[-]",
	en = "[未翻译][652B2B]请前往空间站考察道具店情况！[-]",
	zht = "[未翻译][652B2B]请前往空间站考察道具店情况！[-]",
}
LocalizationConfig["loc_tutorials_mission12_2"] =
{
	zh = "[652B2B]道具店开张中，请进入查看！[-]",
	en = "[未翻译][652B2B]道具店开张中，请进入查看！[-]",
	zht = "[未翻译][652B2B]道具店开张中，请进入查看！[-]",
}
LocalizationConfig["loc_tutorials_mission12_3"] =
{
	zh = "[652B2B]店铺急需投资，点击查看详情！[-]",
	en = "[未翻译][652B2B]店铺急需投资，点击查看详情！[-]",
	zht = "[未翻译][652B2B]店铺急需投资，点击查看详情！[-]",
}
LocalizationConfig["loc_tutorials_mission12_4"] =
{
	zh = "[652B2B]扩张后效率将全面提升！[-]",
	en = "[未翻译][652B2B]扩张后效率将全面提升！[-]",
	zht = "[未翻译][652B2B]扩张后效率将全面提升！[-]",
}
LocalizationConfig["loc_tutorials_mission12_5"] =
{
	zh = "[652B2B]经系统评估为优良资产，请放心投资！[-]",
	en = "[未翻译][652B2B]经系统评估为优良资产，请放心投资！[-]",
	zht = "[未翻译][652B2B]经系统评估为优良资产，请放心投资！[-]",
}
LocalizationConfig["loc_tutorials_mission12_6"] =
{
	zh = "[652B2B]直接回任务界面吧~[-]",
	en = "[未翻译][652B2B]直接回任务界面吧~[-]",
	zht = "[未翻译][652B2B]直接回任务界面吧~[-]",
}
LocalizationConfig["loc_tutorials_mission12_7"] =
{
	zh = "[652B2B]点它！[-]",
	en = "[未翻译][652B2B]点它！[-]",
	zht = "[未翻译][652B2B]点它！[-]",
}
LocalizationConfig["loc_tutorials_mission23_1"] =
{
	zh = "[652B2B]似乎是个神秘的地方，去看看！[-]",
	en = "[未翻译][652B2B]似乎是个神秘的地方，去看看！[-]",
	zht = "[未翻译][652B2B]似乎是个神秘的地方，去看看！[-]",
}
LocalizationConfig["loc_tutorials_mission23_2"] =
{
	zh = "[652B2B][-]",
	en = "[未翻译][652B2B][-]",
	zht = "[未翻译][652B2B][-]",
}
LocalizationConfig["loc_tutorials_mission23_3"] =
{
	zh = "[652B2B]指引：完成任务就能获得代币，可用于抽奖噢~[-]",
	en = "[未翻译][652B2B]指引：完成任务就能获得代币，可用于抽奖噢~[-]",
	zht = "[未翻译][652B2B]指引：完成任务就能获得代币，可用于抽奖噢~[-]",
}
LocalizationConfig["loc_tutorials_mission23_4"] =
{
	zh = "[652B2B]指引：来一发试试手气！[-]",
	en = "[未翻译][652B2B]指引：来一发试试手气！[-]",
	zht = "[未翻译][652B2B]指引：来一发试试手气！[-]",
}
LocalizationConfig["loc_tutorials_mission23_5"] =
{
	zh = "[652B2B][-]",
	en = "[未翻译][652B2B][-]",
	zht = "[未翻译][652B2B][-]",
}
LocalizationConfig["loc_tutorials_mission23_6"] =
{
	zh = "[652B2B]指引：似乎获得了一个新伙伴！[-]",
	en = "[未翻译][652B2B]指引：似乎获得了一个新伙伴！[-]",
	zht = "[未翻译][652B2B]指引：似乎获得了一个新伙伴！[-]",
}
LocalizationConfig["loc_tutorials_mission23_7"] =
{
	zh = "[652B2B]指引：直接回任务界面吧~[-]",
	en = "[未翻译][652B2B]指引：直接回任务界面吧~[-]",
	zht = "[未翻译][652B2B]指引：直接回任务界面吧~[-]",
}
LocalizationConfig["loc_tutorials_mission23_8"] =
{
	zh = "[652B2B]指引：点它！[-]",
	en = "[未翻译][652B2B]指引：点它！[-]",
	zht = "[未翻译][652B2B]指引：点它！[-]",
}
LocalizationConfig["loc_workshopquickexchange_getreward"] =
{
	zh = "立刻获得{Time}打工报酬",
	en = "[未翻译]立刻获得{Time}打工报酬",
	zht = "[未翻译]立刻获得{Time}打工报酬",
}
LocalizationConfig["loc_workshop1_quickexchange_confirm_hint"] =
{
	zh = "购买矮人啤酒立刻加速",
	en = "[未翻译]购买矮人啤酒立刻加速",
	zht = "[未翻译]购买矮人啤酒立刻加速",
}
LocalizationConfig["loc_workshop2_quickexchange_confirm_hint"] =
{
	zh = "购买超浓奶茶立刻加速",
	en = "[未翻译]购买超浓奶茶立刻加速",
	zht = "[未翻译]购买超浓奶茶立刻加速",
}
LocalizationConfig["loc_workshop3_quickexchange_confirm_hint"] =
{
	zh = "购买提神茶包立刻加速",
	en = "[未翻译]购买提神茶包立刻加速",
	zht = "[未翻译]购买提神茶包立刻加速",
}
LocalizationConfig["loc_workshop4_quickexchange_confirm_hint"] =
{
	zh = "购买浓缩咖啡立刻加速",
	en = "[未翻译]购买浓缩咖啡立刻加速",
	zht = "[未翻译]购买浓缩咖啡立刻加速",
}
LocalizationConfig["loc_setsupply_item_is_empty"] =
{
	zh = "用完了",
	en = "[未翻译]用完了",
	zht = "[未翻译]用完了",
}
LocalizationConfig["loc_global_ArenaToken_name"] =
{
	zh = "好市民卡",
	en = "[未翻译]好市民卡",
	zht = "[未翻译]好市民卡",
}
LocalizationConfig["loc_global_ArenaToken_des"] =
{
	zh = "只在流亡街流通的货币，是勇气与善良的象征",
	en = "[未翻译]只在流亡街流通的货币，是勇气与善良的象征",
	zht = "[未翻译]只在流亡街流通的货币，是勇气与善良的象征",
}
LocalizationConfig["loc_hint_ArenaToken_not_enough"] =
{
	zh = "不够咯",
	en = "[未翻译]不够咯",
	zht = "[未翻译]不够咯",
}
LocalizationConfig["loc_msg_workshop_not_start"] =
{
	zh = "没有达到最低评价，无法工作，确认出发？",
	en = "[未翻译]没有达到最低评价，无法工作，确认出发？",
	zht = "[未翻译]没有达到最低评价，无法工作，确认出发？",
}
LocalizationConfig["loc_setsupply_eventitem_is_occupy"] =
{
	zh = "已使用",
	en = "[未翻译]已使用",
	zht = "[未翻译]已使用",
}
LocalizationConfig["loc_setsupply_eventitem_is_free"] =
{
	zh = "永久",
	en = "[未翻译]永久",
	zht = "[未翻译]永久",
}
LocalizationConfig["loc_skillhint_fightpower"] =
{
	zh = "战力",
	en = "[未翻译]战力",
	zht = "[未翻译]战力",
}
LocalizationConfig["loc_global_item_source_demand"] =
{
	zh = "订单",
	en = "[未翻译]订单",
	zht = "[未翻译]订单",
}
LocalizationConfig["loc_golbal_postcard_header"] =
{
	zh = "[6B4439FF]对面世界的[-][C64100FF]%s[-][6B4439FF]：[-]",
	en = "[未翻译][6B4439FF]对面世界的[-][C64100FF]%s[-][6B4439FF]：[-]",
	zht = "[未翻译][6B4439FF]对面世界的[-][C64100FF]%s[-][6B4439FF]：[-]",
}
LocalizationConfig["loc_global_tourist_coming"] =
{
	zh = "新的观光团已抵达，客人们正热切等待着有趣的宠物展~",
	en = "[未翻译]新的观光团已抵达，客人们正热切等待着有趣的宠物展~",
	zht = "[未翻译]新的观光团已抵达，客人们正热切等待着有趣的宠物展~",
}
LocalizationConfig["loc_global_new_activity_start"] =
{
	zh = "特别消息！新的活动已经开启！",
	en = "[未翻译]特别消息！新的活动已经开启！",
	zht = "[未翻译]特别消息！新的活动已经开启！",
}
LocalizationConfig["loc_global_new_sommon_pool_start"] =
{
	zh = "特别节日~不夜城新奖池开放了噢~",
	en = "[未翻译]特别节日~不夜城新奖池开放了噢~",
	zht = "[未翻译]特别节日~不夜城新奖池开放了噢~",
}
LocalizationConfig["loc_global_monthcard_not_reach_limit"] =
{
	zh = "抱歉，剩余天数小于等于30天时才能再次购买。",
	en = "[未翻译]抱歉，剩余天数小于等于30天时才能再次购买。",
	zht = "[未翻译]抱歉，剩余天数小于等于30天时才能再次购买。",
}
LocalizationConfig["loc_global_workshop_not_at_work"] =
{
	zh = "人呢",
	en = "[未翻译]人呢",
	zht = "[未翻译]人呢",
}
LocalizationConfig["loc_global_workshop_get_reward"] =
{
	zh = "领取",
	en = "[未翻译]领取",
	zht = "[未翻译]领取",
}
LocalizationConfig["loc_global_package_title_desc"] =
{
	zh = "欢迎来到星际礼包中心。以下商品限时推出，客人只要买了就可以为所欲为了噢！",
	en = "[未翻译]欢迎来到星际礼包中心。以下商品限时推出，客人只要买了就可以为所欲为了噢！",
	zht = "[未翻译]欢迎来到星际礼包中心。以下商品限时推出，客人只要买了就可以为所欲为了噢！",
}
LocalizationConfig["loc_explore_package_lock_hint"] =
{
	zh = "派出更多队员或提升队员阶数可以增加背包格。",
	en = "[未翻译]派出更多队员或提升队员阶数可以增加背包格。",
	zht = "[未翻译]派出更多队员或提升队员阶数可以增加背包格。",
}
LocalizationConfig["loc_hint_account_rename_success"] =
{
	zh = "昵称修改成功",
	en = "[未翻译]昵称修改成功",
	zht = "[未翻译]昵称修改成功",
}
LocalizationConfig["loc_Global_Moment"] =
{
	zh = "社区",
	en = "[未翻译]社区",
	zht = "[未翻译]社区",
}
LocalizationConfig["loc_unlockmodule_arena_hint_001"] =
{
	zh = "完成 主线102 及 支线-流亡者挑战 解锁流亡街挑战功能",
	en = "[未翻译]完成 主线102 及 支线-流亡者挑战 解锁流亡街挑战功能",
	zht = "[未翻译]完成 主线102 及 支线-流亡者挑战 解锁流亡街挑战功能",
}
LocalizationConfig["loc_global_catchfishpoint_name"] =
{
	zh = "能量",
	en = "[未翻译]能量",
	zht = "[未翻译]能量",
}
LocalizationConfig["loc_global_catchfishpoint_desc"] =
{
	zh = "在水獭老板这里，摸鱼所需要消耗的东西",
	en = "[未翻译]在水獭老板这里，摸鱼所需要消耗的东西",
	zht = "[未翻译]在水獭老板这里，摸鱼所需要消耗的东西",
}
