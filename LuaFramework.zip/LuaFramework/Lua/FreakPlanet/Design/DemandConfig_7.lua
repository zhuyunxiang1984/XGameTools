
DemandConfig[DemandID.Id701] =
{
	Id = 701,
	Name = "订购新闻1",
	Desc = "需要一些新闻",
	Value = 321602,
	Active = true,
	Weight = 45600,
	PreGoal = 
	{
		301505,
		301645,
	},
	CloseGoal = 
	{
		301700,
	},
	GoodsId = 7101602,
	Priority = 1602810,
	Num = 28,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 41834,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 355,
				},
				{
					Value = 1,
					Num = 6334,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 355,
				},
				{
					Value = 1,
					Num = 6334,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 71,
				},
				{
					Value = 1,
					Num = 6334,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 71,
				},
				{
					Value = 1,
					Num = 6334,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 14,
				},
				{
					Value = 1,
					Num = 6834,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 14,
				},
				{
					Value = 1,
					Num = 6834,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 2,
				},
				{
					Value = 1,
					Num = 16834,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 2,
				},
				{
					Value = 1,
					Num = 16834,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 251,
				},
				{
					Value = 320051,
					Num = 167,
				},
			},
		},
	},
	DemandID = 410701,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id702] =
{
	Id = 702,
	Name = "订购羽毛1",
	Desc = "需要一些羽毛",
	Value = 321603,
	Active = true,
	Weight = 32805,
	PreGoal = 
	{
		301224,
	},
	CloseGoal = 
	{
		301252,
	},
	GoodsId = 7201603,
	Priority = 1603811,
	Num = 28,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 37679,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 355,
				},
				{
					Value = 1,
					Num = 2179,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 355,
				},
				{
					Value = 1,
					Num = 2179,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 71,
				},
				{
					Value = 1,
					Num = 2179,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 71,
				},
				{
					Value = 1,
					Num = 2179,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 14,
				},
				{
					Value = 1,
					Num = 2679,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 14,
				},
				{
					Value = 1,
					Num = 2679,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 2,
				},
				{
					Value = 1,
					Num = 12679,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 2,
				},
				{
					Value = 1,
					Num = 12679,
				},
			},
		},
	},
	DemandID = 410702,
	DemandGroupList = {
		420002,
		420004,
		420005,
		420006,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id703] =
{
	Id = 703,
	Name = "订购羽毛1",
	Desc = "需要一些羽毛",
	Value = 321603,
	Active = true,
	Weight = 33615,
	PreGoal = 
	{
		301224,
		301232,
	},
	CloseGoal = 
	{
		301260,
	},
	GoodsId = 7201603,
	Priority = 1603812,
	Num = 28,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 37679,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 355,
				},
				{
					Value = 1,
					Num = 2179,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 355,
				},
				{
					Value = 1,
					Num = 2179,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 71,
				},
				{
					Value = 1,
					Num = 2179,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 71,
				},
				{
					Value = 1,
					Num = 2179,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 14,
				},
				{
					Value = 1,
					Num = 2679,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 14,
				},
				{
					Value = 1,
					Num = 2679,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 2,
				},
				{
					Value = 1,
					Num = 12679,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 2,
				},
				{
					Value = 1,
					Num = 12679,
				},
			},
		},
	},
	DemandID = 410703,
	DemandGroupList = {
		420002,
		420004,
		420005,
		420006,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id704] =
{
	Id = 704,
	Name = "订购羽毛1",
	Desc = "需要一些羽毛",
	Value = 321603,
	Active = true,
	Weight = 34425,
	PreGoal = 
	{
		301224,
		301240,
	},
	CloseGoal = 
	{
		301272,
	},
	GoodsId = 7201603,
	Priority = 1603813,
	Num = 30,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 40370,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 381,
				},
				{
					Value = 1,
					Num = 2270,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 381,
				},
				{
					Value = 1,
					Num = 2270,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 76,
				},
				{
					Value = 1,
					Num = 2370,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 76,
				},
				{
					Value = 1,
					Num = 2370,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 15,
				},
				{
					Value = 1,
					Num = 2870,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 15,
				},
				{
					Value = 1,
					Num = 2870,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 3,
				},
				{
					Value = 1,
					Num = 2870,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 3,
				},
				{
					Value = 1,
					Num = 2870,
				},
			},
		},
	},
	DemandID = 410704,
	DemandGroupList = {
		420002,
		420004,
		420005,
		420006,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id705] =
{
	Id = 705,
	Name = "订购羽毛1",
	Desc = "需要一些羽毛",
	Value = 321603,
	Active = true,
	Weight = 35640,
	PreGoal = 
	{
		301224,
		301252,
	},
	CloseGoal = 
	{
		301284,
	},
	GoodsId = 7201603,
	Priority = 1603814,
	Num = 32,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 43061,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 406,
				},
				{
					Value = 1,
					Num = 2461,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 406,
				},
				{
					Value = 1,
					Num = 2461,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 81,
				},
				{
					Value = 1,
					Num = 2561,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 81,
				},
				{
					Value = 1,
					Num = 2561,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 16,
				},
				{
					Value = 1,
					Num = 3061,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 16,
				},
				{
					Value = 1,
					Num = 3061,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 3,
				},
				{
					Value = 1,
					Num = 5561,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 3,
				},
				{
					Value = 1,
					Num = 5561,
				},
			},
		},
	},
	DemandID = 410705,
	DemandGroupList = {
		420002,
		420004,
		420005,
		420006,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id706] =
{
	Id = 706,
	Name = "订购羽毛1",
	Desc = "需要一些羽毛",
	Value = 321603,
	Active = true,
	Weight = 36855,
	PreGoal = 
	{
		301224,
		301264,
	},
	CloseGoal = 
	{
		301301,
	},
	GoodsId = 7201603,
	Priority = 1603815,
	Num = 32,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 43061,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 406,
				},
				{
					Value = 1,
					Num = 2461,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 406,
				},
				{
					Value = 1,
					Num = 2461,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 81,
				},
				{
					Value = 1,
					Num = 2561,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 81,
				},
				{
					Value = 1,
					Num = 2561,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 16,
				},
				{
					Value = 1,
					Num = 3061,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 16,
				},
				{
					Value = 1,
					Num = 3061,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 3,
				},
				{
					Value = 1,
					Num = 5561,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 3,
				},
				{
					Value = 1,
					Num = 5561,
				},
			},
		},
	},
	DemandID = 410706,
	DemandGroupList = {
		420002,
		420004,
		420005,
		420006,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id707] =
{
	Id = 707,
	Name = "订购羽毛1",
	Desc = "需要一些羽毛",
	Value = 321603,
	Active = true,
	Weight = 38475,
	PreGoal = 
	{
		301224,
		301280,
	},
	CloseGoal = 
	{
		301318,
	},
	GoodsId = 7201603,
	Priority = 1603816,
	Num = 32,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 43061,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 406,
				},
				{
					Value = 1,
					Num = 2461,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 406,
				},
				{
					Value = 1,
					Num = 2461,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 81,
				},
				{
					Value = 1,
					Num = 2561,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 81,
				},
				{
					Value = 1,
					Num = 2561,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 16,
				},
				{
					Value = 1,
					Num = 3061,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 16,
				},
				{
					Value = 1,
					Num = 3061,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 3,
				},
				{
					Value = 1,
					Num = 5561,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 3,
				},
				{
					Value = 1,
					Num = 5561,
				},
			},
		},
	},
	DemandID = 410707,
	DemandGroupList = {
		420002,
		420004,
		420005,
		420006,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id708] =
{
	Id = 708,
	Name = "订购羽毛1",
	Desc = "需要一些羽毛",
	Value = 321603,
	Active = true,
	Weight = 40095,
	PreGoal = 
	{
		301224,
		301297,
	},
	CloseGoal = 
	{
		301620,
	},
	GoodsId = 7201603,
	Priority = 1603817,
	Num = 32,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 43061,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 406,
				},
				{
					Value = 1,
					Num = 2461,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 406,
				},
				{
					Value = 1,
					Num = 2461,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 81,
				},
				{
					Value = 1,
					Num = 2561,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 81,
				},
				{
					Value = 1,
					Num = 2561,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 16,
				},
				{
					Value = 1,
					Num = 3061,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 16,
				},
				{
					Value = 1,
					Num = 3061,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 3,
				},
				{
					Value = 1,
					Num = 5561,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 3,
				},
				{
					Value = 1,
					Num = 5561,
				},
			},
		},
	},
	DemandID = 410708,
	DemandGroupList = {
		420002,
		420004,
		420005,
		420006,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id709] =
{
	Id = 709,
	Name = "订购羽毛1",
	Desc = "需要一些羽毛",
	Value = 321603,
	Active = true,
	Weight = 42120,
	PreGoal = 
	{
		301224,
		301318,
	},
	CloseGoal = 
	{
		301645,
	},
	GoodsId = 7201603,
	Priority = 1603818,
	Num = 32,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 43061,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 406,
				},
				{
					Value = 1,
					Num = 2461,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 406,
				},
				{
					Value = 1,
					Num = 2461,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 81,
				},
				{
					Value = 1,
					Num = 2561,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 81,
				},
				{
					Value = 1,
					Num = 2561,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 16,
				},
				{
					Value = 1,
					Num = 3061,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 16,
				},
				{
					Value = 1,
					Num = 3061,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 3,
				},
				{
					Value = 1,
					Num = 5561,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 3,
				},
				{
					Value = 1,
					Num = 5561,
				},
			},
		},
	},
	DemandID = 410709,
	DemandGroupList = {
		420002,
		420004,
		420005,
		420006,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id710] =
{
	Id = 710,
	Name = "订购羽毛1",
	Desc = "需要一些羽毛",
	Value = 321603,
	Active = true,
	Weight = 44145,
	PreGoal = 
	{
		301224,
		301620,
	},
	CloseGoal = 
	{
		301675,
	},
	GoodsId = 7201603,
	Priority = 1603819,
	Num = 32,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 43061,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 406,
				},
				{
					Value = 1,
					Num = 2461,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 406,
				},
				{
					Value = 1,
					Num = 2461,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 81,
				},
				{
					Value = 1,
					Num = 2561,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 81,
				},
				{
					Value = 1,
					Num = 2561,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 16,
				},
				{
					Value = 1,
					Num = 3061,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 16,
				},
				{
					Value = 1,
					Num = 3061,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 3,
				},
				{
					Value = 1,
					Num = 5561,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 3,
				},
				{
					Value = 1,
					Num = 5561,
				},
			},
		},
	},
	DemandID = 410710,
	DemandGroupList = {
		420002,
		420004,
		420005,
		420006,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id711] =
{
	Id = 711,
	Name = "订购羽毛1",
	Desc = "需要一些羽毛",
	Value = 321603,
	Active = true,
	Weight = 46575,
	PreGoal = 
	{
		301224,
		301650,
	},
	CloseGoal = 
	{
		301705,
	},
	GoodsId = 7201603,
	Priority = 1603820,
	Num = 32,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 43061,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 406,
				},
				{
					Value = 1,
					Num = 2461,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 406,
				},
				{
					Value = 1,
					Num = 2461,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 81,
				},
				{
					Value = 1,
					Num = 2561,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 81,
				},
				{
					Value = 1,
					Num = 2561,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 16,
				},
				{
					Value = 1,
					Num = 3061,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 16,
				},
				{
					Value = 1,
					Num = 3061,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 3,
				},
				{
					Value = 1,
					Num = 5561,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 3,
				},
				{
					Value = 1,
					Num = 5561,
				},
			},
		},
	},
	DemandID = 410711,
	DemandGroupList = {
		420002,
		420004,
		420005,
		420006,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id712] =
{
	Id = 712,
	Name = "订购钥匙1",
	Desc = "需要一些钥匙",
	Value = 321604,
	Active = true,
	Weight = 36125,
	PreGoal = 
	{
		301240,
	},
	CloseGoal = 
	{
		301268,
	},
	GoodsId = 7301604,
	Priority = 1604851,
	Num = 28,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 39952,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 199,
				},
				{
					Value = 1,
					Num = 20052,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 199,
				},
				{
					Value = 1,
					Num = 20052,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 39,
				},
				{
					Value = 1,
					Num = 20452,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 39,
				},
				{
					Value = 1,
					Num = 20452,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 7,
				},
				{
					Value = 1,
					Num = 22452,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 7,
				},
				{
					Value = 1,
					Num = 22452,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 1,
				},
				{
					Value = 1,
					Num = 27452,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 1,
				},
				{
					Value = 1,
					Num = 27452,
				},
			},
		},
	},
	DemandID = 410712,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id713] =
{
	Id = 713,
	Name = "订购钥匙1",
	Desc = "需要一些钥匙",
	Value = 321604,
	Active = true,
	Weight = 36975,
	PreGoal = 
	{
		301240,
		301248,
	},
	CloseGoal = 
	{
		301276,
	},
	GoodsId = 7301604,
	Priority = 1604852,
	Num = 30,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 42806,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 214,
				},
				{
					Value = 1,
					Num = 21406,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 214,
				},
				{
					Value = 1,
					Num = 21406,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 42,
				},
				{
					Value = 1,
					Num = 21806,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 42,
				},
				{
					Value = 1,
					Num = 21806,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 8,
				},
				{
					Value = 1,
					Num = 22806,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 8,
				},
				{
					Value = 1,
					Num = 22806,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 1,
				},
				{
					Value = 1,
					Num = 30306,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 1,
				},
				{
					Value = 1,
					Num = 30306,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 256,
				},
				{
					Value = 320051,
					Num = 172,
				},
			},
		},
	},
	DemandID = 410713,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id714] =
{
	Id = 714,
	Name = "订购钥匙1",
	Desc = "需要一些钥匙",
	Value = 321604,
	Active = true,
	Weight = 37825,
	PreGoal = 
	{
		301240,
		301256,
	},
	CloseGoal = 
	{
		301288,
	},
	GoodsId = 7301604,
	Priority = 1604853,
	Num = 30,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 42806,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 214,
				},
				{
					Value = 1,
					Num = 21406,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 214,
				},
				{
					Value = 1,
					Num = 21406,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 42,
				},
				{
					Value = 1,
					Num = 21806,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 42,
				},
				{
					Value = 1,
					Num = 21806,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 8,
				},
				{
					Value = 1,
					Num = 22806,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 8,
				},
				{
					Value = 1,
					Num = 22806,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 1,
				},
				{
					Value = 1,
					Num = 30306,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 1,
				},
				{
					Value = 1,
					Num = 30306,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 256,
				},
				{
					Value = 320051,
					Num = 172,
				},
			},
		},
	},
	DemandID = 410714,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id715] =
{
	Id = 715,
	Name = "订购钥匙1",
	Desc = "需要一些钥匙",
	Value = 321604,
	Active = true,
	Weight = 39100,
	PreGoal = 
	{
		301240,
		301268,
	},
	CloseGoal = 
	{
		301301,
	},
	GoodsId = 7301604,
	Priority = 1604854,
	Num = 30,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 42806,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 214,
				},
				{
					Value = 1,
					Num = 21406,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 214,
				},
				{
					Value = 1,
					Num = 21406,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 42,
				},
				{
					Value = 1,
					Num = 21806,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 42,
				},
				{
					Value = 1,
					Num = 21806,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 8,
				},
				{
					Value = 1,
					Num = 22806,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 8,
				},
				{
					Value = 1,
					Num = 22806,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 1,
				},
				{
					Value = 1,
					Num = 30306,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 1,
				},
				{
					Value = 1,
					Num = 30306,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 256,
				},
				{
					Value = 320051,
					Num = 172,
				},
			},
		},
	},
	DemandID = 410715,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id716] =
{
	Id = 716,
	Name = "订购钥匙1",
	Desc = "需要一些钥匙",
	Value = 321604,
	Active = true,
	Weight = 40375,
	PreGoal = 
	{
		301240,
		301280,
	},
	CloseGoal = 
	{
		301318,
	},
	GoodsId = 7301604,
	Priority = 1604855,
	Num = 30,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 42806,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 214,
				},
				{
					Value = 1,
					Num = 21406,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 214,
				},
				{
					Value = 1,
					Num = 21406,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 42,
				},
				{
					Value = 1,
					Num = 21806,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 42,
				},
				{
					Value = 1,
					Num = 21806,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 8,
				},
				{
					Value = 1,
					Num = 22806,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 8,
				},
				{
					Value = 1,
					Num = 22806,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 1,
				},
				{
					Value = 1,
					Num = 30306,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 1,
				},
				{
					Value = 1,
					Num = 30306,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 256,
				},
				{
					Value = 320051,
					Num = 172,
				},
			},
		},
	},
	DemandID = 410716,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id717] =
{
	Id = 717,
	Name = "订购钥匙1",
	Desc = "需要一些钥匙",
	Value = 321604,
	Active = true,
	Weight = 42075,
	PreGoal = 
	{
		301240,
		301297,
	},
	CloseGoal = 
	{
		301615,
	},
	GoodsId = 7301604,
	Priority = 1604856,
	Num = 30,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 42806,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 214,
				},
				{
					Value = 1,
					Num = 21406,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 214,
				},
				{
					Value = 1,
					Num = 21406,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 42,
				},
				{
					Value = 1,
					Num = 21806,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 42,
				},
				{
					Value = 1,
					Num = 21806,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 8,
				},
				{
					Value = 1,
					Num = 22806,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 8,
				},
				{
					Value = 1,
					Num = 22806,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 1,
				},
				{
					Value = 1,
					Num = 30306,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 1,
				},
				{
					Value = 1,
					Num = 30306,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 256,
				},
				{
					Value = 320051,
					Num = 172,
				},
			},
		},
	},
	DemandID = 410717,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id718] =
{
	Id = 718,
	Name = "订购钥匙1",
	Desc = "需要一些钥匙",
	Value = 321604,
	Active = true,
	Weight = 43775,
	PreGoal = 
	{
		301240,
		301314,
	},
	CloseGoal = 
	{
		301640,
	},
	GoodsId = 7301604,
	Priority = 1604857,
	Num = 30,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 42806,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 214,
				},
				{
					Value = 1,
					Num = 21406,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 214,
				},
				{
					Value = 1,
					Num = 21406,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 42,
				},
				{
					Value = 1,
					Num = 21806,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 42,
				},
				{
					Value = 1,
					Num = 21806,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 8,
				},
				{
					Value = 1,
					Num = 22806,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 8,
				},
				{
					Value = 1,
					Num = 22806,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 1,
				},
				{
					Value = 1,
					Num = 30306,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 1,
				},
				{
					Value = 1,
					Num = 30306,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 256,
				},
				{
					Value = 320051,
					Num = 172,
				},
			},
		},
	},
	DemandID = 410718,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id719] =
{
	Id = 719,
	Name = "订购钥匙1",
	Desc = "需要一些钥匙",
	Value = 321604,
	Active = true,
	Weight = 45900,
	PreGoal = 
	{
		301240,
		301615,
	},
	CloseGoal = 
	{
		301665,
	},
	GoodsId = 7301604,
	Priority = 1604858,
	Num = 30,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 42806,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 214,
				},
				{
					Value = 1,
					Num = 21406,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 214,
				},
				{
					Value = 1,
					Num = 21406,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 42,
				},
				{
					Value = 1,
					Num = 21806,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 42,
				},
				{
					Value = 1,
					Num = 21806,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 8,
				},
				{
					Value = 1,
					Num = 22806,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 8,
				},
				{
					Value = 1,
					Num = 22806,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 1,
				},
				{
					Value = 1,
					Num = 30306,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 1,
				},
				{
					Value = 1,
					Num = 30306,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 256,
				},
				{
					Value = 320051,
					Num = 172,
				},
			},
		},
	},
	DemandID = 410719,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id720] =
{
	Id = 720,
	Name = "订购钥匙1",
	Desc = "需要一些钥匙",
	Value = 321604,
	Active = true,
	Weight = 48025,
	PreGoal = 
	{
		301240,
		301640,
	},
	CloseGoal = 
	{
		301695,
	},
	GoodsId = 7301604,
	Priority = 1604859,
	Num = 30,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 42806,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 214,
				},
				{
					Value = 1,
					Num = 21406,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 214,
				},
				{
					Value = 1,
					Num = 21406,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 42,
				},
				{
					Value = 1,
					Num = 21806,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 42,
				},
				{
					Value = 1,
					Num = 21806,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 8,
				},
				{
					Value = 1,
					Num = 22806,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 8,
				},
				{
					Value = 1,
					Num = 22806,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 1,
				},
				{
					Value = 1,
					Num = 30306,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 1,
				},
				{
					Value = 1,
					Num = 30306,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 256,
				},
				{
					Value = 320051,
					Num = 172,
				},
			},
		},
	},
	DemandID = 410720,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id721] =
{
	Id = 721,
	Name = "订购钥匙1",
	Desc = "需要一些钥匙",
	Value = 321604,
	Active = true,
	Weight = 50575,
	PreGoal = 
	{
		301240,
		301670,
	},
	CloseGoal = 
	{
		301725,
	},
	GoodsId = 7301604,
	Priority = 1604860,
	Num = 30,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 42806,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 214,
				},
				{
					Value = 1,
					Num = 21406,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 214,
				},
				{
					Value = 1,
					Num = 21406,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 42,
				},
				{
					Value = 1,
					Num = 21806,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 42,
				},
				{
					Value = 1,
					Num = 21806,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 8,
				},
				{
					Value = 1,
					Num = 22806,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 8,
				},
				{
					Value = 1,
					Num = 22806,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 1,
				},
				{
					Value = 1,
					Num = 30306,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 1,
				},
				{
					Value = 1,
					Num = 30306,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 256,
				},
				{
					Value = 320051,
					Num = 172,
				},
			},
		},
	},
	DemandID = 410721,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id722] =
{
	Id = 722,
	Name = "订购脚印1",
	Desc = "需要一些脚印",
	Value = 321605,
	Active = true,
	Weight = 39605,
	PreGoal = 
	{
		301518,
		301256,
	},
	CloseGoal = 
	{
		301284,
	},
	GoodsId = 7401605,
	Priority = 1605891,
	Num = 28,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 44570,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 378,
				},
				{
					Value = 1,
					Num = 6770,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 378,
				},
				{
					Value = 1,
					Num = 6770,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 75,
				},
				{
					Value = 1,
					Num = 7070,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 75,
				},
				{
					Value = 1,
					Num = 7070,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 15,
				},
				{
					Value = 1,
					Num = 7070,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 15,
				},
				{
					Value = 1,
					Num = 7070,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 3,
				},
				{
					Value = 1,
					Num = 7070,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 3,
				},
				{
					Value = 1,
					Num = 7070,
				},
			},
		},
	},
	DemandID = 410722,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id723] =
{
	Id = 723,
	Name = "订购脚印1",
	Desc = "需要一些脚印",
	Value = 321605,
	Active = true,
	Weight = 40495,
	PreGoal = 
	{
		301518,
		301264,
	},
	CloseGoal = 
	{
		301292,
	},
	GoodsId = 7401605,
	Priority = 1605892,
	Num = 28,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 44570,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 378,
				},
				{
					Value = 1,
					Num = 6770,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 378,
				},
				{
					Value = 1,
					Num = 6770,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 75,
				},
				{
					Value = 1,
					Num = 7070,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 75,
				},
				{
					Value = 1,
					Num = 7070,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 15,
				},
				{
					Value = 1,
					Num = 7070,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 15,
				},
				{
					Value = 1,
					Num = 7070,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 3,
				},
				{
					Value = 1,
					Num = 7070,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 3,
				},
				{
					Value = 1,
					Num = 7070,
				},
			},
		},
	},
	DemandID = 410723,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id724] =
{
	Id = 724,
	Name = "订购脚印1",
	Desc = "需要一些脚印",
	Value = 321605,
	Active = true,
	Weight = 41385,
	PreGoal = 
	{
		301518,
		301272,
	},
	CloseGoal = 
	{
		301306,
	},
	GoodsId = 7401605,
	Priority = 1605893,
	Num = 28,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 44570,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 378,
				},
				{
					Value = 1,
					Num = 6770,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 378,
				},
				{
					Value = 1,
					Num = 6770,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 75,
				},
				{
					Value = 1,
					Num = 7070,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 75,
				},
				{
					Value = 1,
					Num = 7070,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 15,
				},
				{
					Value = 1,
					Num = 7070,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 15,
				},
				{
					Value = 1,
					Num = 7070,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 3,
				},
				{
					Value = 1,
					Num = 7070,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 3,
				},
				{
					Value = 1,
					Num = 7070,
				},
			},
		},
	},
	DemandID = 410724,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id725] =
{
	Id = 725,
	Name = "订购脚印1",
	Desc = "需要一些脚印",
	Value = 321605,
	Active = true,
	Weight = 42720,
	PreGoal = 
	{
		301518,
		301284,
	},
	CloseGoal = 
	{
		301318,
	},
	GoodsId = 7401605,
	Priority = 1605894,
	Num = 28,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 44570,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 378,
				},
				{
					Value = 1,
					Num = 6770,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 378,
				},
				{
					Value = 1,
					Num = 6770,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 75,
				},
				{
					Value = 1,
					Num = 7070,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 75,
				},
				{
					Value = 1,
					Num = 7070,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 15,
				},
				{
					Value = 1,
					Num = 7070,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 15,
				},
				{
					Value = 1,
					Num = 7070,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 3,
				},
				{
					Value = 1,
					Num = 7070,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 3,
				},
				{
					Value = 1,
					Num = 7070,
				},
			},
		},
	},
	DemandID = 410725,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id726] =
{
	Id = 726,
	Name = "订购脚印1",
	Desc = "需要一些脚印",
	Value = 321605,
	Active = true,
	Weight = 44055,
	PreGoal = 
	{
		301518,
		301297,
	},
	CloseGoal = 
	{
		301615,
	},
	GoodsId = 7401605,
	Priority = 1605895,
	Num = 28,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 44570,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 378,
				},
				{
					Value = 1,
					Num = 6770,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 378,
				},
				{
					Value = 1,
					Num = 6770,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 75,
				},
				{
					Value = 1,
					Num = 7070,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 75,
				},
				{
					Value = 1,
					Num = 7070,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 15,
				},
				{
					Value = 1,
					Num = 7070,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 15,
				},
				{
					Value = 1,
					Num = 7070,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 3,
				},
				{
					Value = 1,
					Num = 7070,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 3,
				},
				{
					Value = 1,
					Num = 7070,
				},
			},
		},
	},
	DemandID = 410726,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id727] =
{
	Id = 727,
	Name = "订购脚印1",
	Desc = "需要一些脚印",
	Value = 321605,
	Active = true,
	Weight = 45835,
	PreGoal = 
	{
		301518,
		301314,
	},
	CloseGoal = 
	{
		301635,
	},
	GoodsId = 7401605,
	Priority = 1605896,
	Num = 28,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 44570,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 378,
				},
				{
					Value = 1,
					Num = 6770,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 378,
				},
				{
					Value = 1,
					Num = 6770,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 75,
				},
				{
					Value = 1,
					Num = 7070,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 75,
				},
				{
					Value = 1,
					Num = 7070,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 15,
				},
				{
					Value = 1,
					Num = 7070,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 15,
				},
				{
					Value = 1,
					Num = 7070,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 3,
				},
				{
					Value = 1,
					Num = 7070,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 3,
				},
				{
					Value = 1,
					Num = 7070,
				},
			},
		},
	},
	DemandID = 410727,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id728] =
{
	Id = 728,
	Name = "订购脚印1",
	Desc = "需要一些脚印",
	Value = 321605,
	Active = true,
	Weight = 47615,
	PreGoal = 
	{
		301518,
		301605,
	},
	CloseGoal = 
	{
		301660,
	},
	GoodsId = 7401605,
	Priority = 1605897,
	Num = 28,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 44570,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 378,
				},
				{
					Value = 1,
					Num = 6770,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 378,
				},
				{
					Value = 1,
					Num = 6770,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 75,
				},
				{
					Value = 1,
					Num = 7070,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 75,
				},
				{
					Value = 1,
					Num = 7070,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 15,
				},
				{
					Value = 1,
					Num = 7070,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 15,
				},
				{
					Value = 1,
					Num = 7070,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 3,
				},
				{
					Value = 1,
					Num = 7070,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 3,
				},
				{
					Value = 1,
					Num = 7070,
				},
			},
		},
	},
	DemandID = 410728,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id729] =
{
	Id = 729,
	Name = "订购脚印1",
	Desc = "需要一些脚印",
	Value = 321605,
	Active = true,
	Weight = 49840,
	PreGoal = 
	{
		301518,
		301635,
	},
	CloseGoal = 
	{
		301685,
	},
	GoodsId = 7401605,
	Priority = 1605898,
	Num = 28,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 44570,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 378,
				},
				{
					Value = 1,
					Num = 6770,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 378,
				},
				{
					Value = 1,
					Num = 6770,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 75,
				},
				{
					Value = 1,
					Num = 7070,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 75,
				},
				{
					Value = 1,
					Num = 7070,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 15,
				},
				{
					Value = 1,
					Num = 7070,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 15,
				},
				{
					Value = 1,
					Num = 7070,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 3,
				},
				{
					Value = 1,
					Num = 7070,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 3,
				},
				{
					Value = 1,
					Num = 7070,
				},
			},
		},
	},
	DemandID = 410729,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id730] =
{
	Id = 730,
	Name = "订购脚印1",
	Desc = "需要一些脚印",
	Value = 321605,
	Active = true,
	Weight = 52065,
	PreGoal = 
	{
		301518,
		301660,
	},
	CloseGoal = 
	{
		301715,
	},
	GoodsId = 7401605,
	Priority = 1605899,
	Num = 28,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 44570,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 378,
				},
				{
					Value = 1,
					Num = 6770,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 378,
				},
				{
					Value = 1,
					Num = 6770,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 75,
				},
				{
					Value = 1,
					Num = 7070,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 75,
				},
				{
					Value = 1,
					Num = 7070,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 15,
				},
				{
					Value = 1,
					Num = 7070,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 15,
				},
				{
					Value = 1,
					Num = 7070,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 3,
				},
				{
					Value = 1,
					Num = 7070,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 3,
				},
				{
					Value = 1,
					Num = 7070,
				},
			},
		},
	},
	DemandID = 410730,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id731] =
{
	Id = 731,
	Name = "订购脚印1",
	Desc = "需要一些脚印",
	Value = 321605,
	Active = true,
	Weight = 54735,
	PreGoal = 
	{
		301518,
		301690,
	},
	GoodsId = 7401605,
	Priority = 1605900,
	Num = 28,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 44570,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 378,
				},
				{
					Value = 1,
					Num = 6770,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 378,
				},
				{
					Value = 1,
					Num = 6770,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 75,
				},
				{
					Value = 1,
					Num = 7070,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 75,
				},
				{
					Value = 1,
					Num = 7070,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 15,
				},
				{
					Value = 1,
					Num = 7070,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 15,
				},
				{
					Value = 1,
					Num = 7070,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 3,
				},
				{
					Value = 1,
					Num = 7070,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 3,
				},
				{
					Value = 1,
					Num = 7070,
				},
			},
		},
	},
	DemandID = 410731,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id732] =
{
	Id = 732,
	Name = "订购烟头1",
	Desc = "需要一些烟头",
	Value = 321606,
	Active = true,
	Weight = 39605,
	PreGoal = 
	{
		301256,
	},
	CloseGoal = 
	{
		301284,
	},
	GoodsId = 7501606,
	Priority = 1606891,
	Num = 28,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 44805,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 380,
				},
				{
					Value = 1,
					Num = 6805,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 380,
				},
				{
					Value = 1,
					Num = 6805,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 76,
				},
				{
					Value = 1,
					Num = 6805,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 76,
				},
				{
					Value = 1,
					Num = 6805,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 15,
				},
				{
					Value = 1,
					Num = 7305,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 15,
				},
				{
					Value = 1,
					Num = 7305,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 3,
				},
				{
					Value = 1,
					Num = 7305,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 3,
				},
				{
					Value = 1,
					Num = 7305,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 268,
				},
				{
					Value = 320051,
					Num = 180,
				},
			},
		},
	},
	DemandID = 410732,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id733] =
{
	Id = 733,
	Name = "订购烟头1",
	Desc = "需要一些烟头",
	Value = 321606,
	Active = true,
	Weight = 40495,
	PreGoal = 
	{
		301256,
		301264,
	},
	CloseGoal = 
	{
		301292,
	},
	GoodsId = 7501606,
	Priority = 1606892,
	Num = 28,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 44805,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 380,
				},
				{
					Value = 1,
					Num = 6805,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 380,
				},
				{
					Value = 1,
					Num = 6805,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 76,
				},
				{
					Value = 1,
					Num = 6805,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 76,
				},
				{
					Value = 1,
					Num = 6805,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 15,
				},
				{
					Value = 1,
					Num = 7305,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 15,
				},
				{
					Value = 1,
					Num = 7305,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 3,
				},
				{
					Value = 1,
					Num = 7305,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 3,
				},
				{
					Value = 1,
					Num = 7305,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 268,
				},
				{
					Value = 320051,
					Num = 180,
				},
			},
		},
	},
	DemandID = 410733,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id734] =
{
	Id = 734,
	Name = "订购烟头1",
	Desc = "需要一些烟头",
	Value = 321606,
	Active = true,
	Weight = 41385,
	PreGoal = 
	{
		301256,
		301272,
	},
	CloseGoal = 
	{
		301306,
	},
	GoodsId = 7501606,
	Priority = 1606893,
	Num = 28,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 44805,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 380,
				},
				{
					Value = 1,
					Num = 6805,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 380,
				},
				{
					Value = 1,
					Num = 6805,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 76,
				},
				{
					Value = 1,
					Num = 6805,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 76,
				},
				{
					Value = 1,
					Num = 6805,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 15,
				},
				{
					Value = 1,
					Num = 7305,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 15,
				},
				{
					Value = 1,
					Num = 7305,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 3,
				},
				{
					Value = 1,
					Num = 7305,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 3,
				},
				{
					Value = 1,
					Num = 7305,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 268,
				},
				{
					Value = 320051,
					Num = 180,
				},
			},
		},
	},
	DemandID = 410734,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id735] =
{
	Id = 735,
	Name = "订购烟头1",
	Desc = "需要一些烟头",
	Value = 321606,
	Active = true,
	Weight = 42720,
	PreGoal = 
	{
		301256,
		301284,
	},
	CloseGoal = 
	{
		301318,
	},
	GoodsId = 7501606,
	Priority = 1606894,
	Num = 28,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 44805,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 380,
				},
				{
					Value = 1,
					Num = 6805,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 380,
				},
				{
					Value = 1,
					Num = 6805,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 76,
				},
				{
					Value = 1,
					Num = 6805,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 76,
				},
				{
					Value = 1,
					Num = 6805,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 15,
				},
				{
					Value = 1,
					Num = 7305,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 15,
				},
				{
					Value = 1,
					Num = 7305,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 3,
				},
				{
					Value = 1,
					Num = 7305,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 3,
				},
				{
					Value = 1,
					Num = 7305,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 268,
				},
				{
					Value = 320051,
					Num = 180,
				},
			},
		},
	},
	DemandID = 410735,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id736] =
{
	Id = 736,
	Name = "订购烟头1",
	Desc = "需要一些烟头",
	Value = 321606,
	Active = true,
	Weight = 44055,
	PreGoal = 
	{
		301256,
		301297,
	},
	CloseGoal = 
	{
		301615,
	},
	GoodsId = 7501606,
	Priority = 1606895,
	Num = 28,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 44805,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 380,
				},
				{
					Value = 1,
					Num = 6805,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 380,
				},
				{
					Value = 1,
					Num = 6805,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 76,
				},
				{
					Value = 1,
					Num = 6805,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 76,
				},
				{
					Value = 1,
					Num = 6805,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 15,
				},
				{
					Value = 1,
					Num = 7305,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 15,
				},
				{
					Value = 1,
					Num = 7305,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 3,
				},
				{
					Value = 1,
					Num = 7305,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 3,
				},
				{
					Value = 1,
					Num = 7305,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 268,
				},
				{
					Value = 320051,
					Num = 180,
				},
			},
		},
	},
	DemandID = 410736,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id737] =
{
	Id = 737,
	Name = "订购烟头1",
	Desc = "需要一些烟头",
	Value = 321606,
	Active = true,
	Weight = 45835,
	PreGoal = 
	{
		301256,
		301314,
	},
	CloseGoal = 
	{
		301635,
	},
	GoodsId = 7501606,
	Priority = 1606896,
	Num = 28,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 44805,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 380,
				},
				{
					Value = 1,
					Num = 6805,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 380,
				},
				{
					Value = 1,
					Num = 6805,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 76,
				},
				{
					Value = 1,
					Num = 6805,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 76,
				},
				{
					Value = 1,
					Num = 6805,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 15,
				},
				{
					Value = 1,
					Num = 7305,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 15,
				},
				{
					Value = 1,
					Num = 7305,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 3,
				},
				{
					Value = 1,
					Num = 7305,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 3,
				},
				{
					Value = 1,
					Num = 7305,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 268,
				},
				{
					Value = 320051,
					Num = 180,
				},
			},
		},
	},
	DemandID = 410737,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id738] =
{
	Id = 738,
	Name = "订购烟头1",
	Desc = "需要一些烟头",
	Value = 321606,
	Active = true,
	Weight = 47615,
	PreGoal = 
	{
		301256,
		301605,
	},
	CloseGoal = 
	{
		301660,
	},
	GoodsId = 7501606,
	Priority = 1606897,
	Num = 28,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 44805,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 380,
				},
				{
					Value = 1,
					Num = 6805,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 380,
				},
				{
					Value = 1,
					Num = 6805,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 76,
				},
				{
					Value = 1,
					Num = 6805,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 76,
				},
				{
					Value = 1,
					Num = 6805,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 15,
				},
				{
					Value = 1,
					Num = 7305,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 15,
				},
				{
					Value = 1,
					Num = 7305,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 3,
				},
				{
					Value = 1,
					Num = 7305,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 3,
				},
				{
					Value = 1,
					Num = 7305,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 268,
				},
				{
					Value = 320051,
					Num = 180,
				},
			},
		},
	},
	DemandID = 410738,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id739] =
{
	Id = 739,
	Name = "订购烟头1",
	Desc = "需要一些烟头",
	Value = 321606,
	Active = true,
	Weight = 49840,
	PreGoal = 
	{
		301256,
		301635,
	},
	CloseGoal = 
	{
		301685,
	},
	GoodsId = 7501606,
	Priority = 1606898,
	Num = 28,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 44805,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 380,
				},
				{
					Value = 1,
					Num = 6805,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 380,
				},
				{
					Value = 1,
					Num = 6805,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 76,
				},
				{
					Value = 1,
					Num = 6805,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 76,
				},
				{
					Value = 1,
					Num = 6805,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 15,
				},
				{
					Value = 1,
					Num = 7305,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 15,
				},
				{
					Value = 1,
					Num = 7305,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 3,
				},
				{
					Value = 1,
					Num = 7305,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 3,
				},
				{
					Value = 1,
					Num = 7305,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 268,
				},
				{
					Value = 320051,
					Num = 180,
				},
			},
		},
	},
	DemandID = 410739,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id740] =
{
	Id = 740,
	Name = "订购烟头1",
	Desc = "需要一些烟头",
	Value = 321606,
	Active = true,
	Weight = 52065,
	PreGoal = 
	{
		301256,
		301660,
	},
	CloseGoal = 
	{
		301715,
	},
	GoodsId = 7501606,
	Priority = 1606899,
	Num = 28,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 44805,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 380,
				},
				{
					Value = 1,
					Num = 6805,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 380,
				},
				{
					Value = 1,
					Num = 6805,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 76,
				},
				{
					Value = 1,
					Num = 6805,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 76,
				},
				{
					Value = 1,
					Num = 6805,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 15,
				},
				{
					Value = 1,
					Num = 7305,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 15,
				},
				{
					Value = 1,
					Num = 7305,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 3,
				},
				{
					Value = 1,
					Num = 7305,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 3,
				},
				{
					Value = 1,
					Num = 7305,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 268,
				},
				{
					Value = 320051,
					Num = 180,
				},
			},
		},
	},
	DemandID = 410740,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id741] =
{
	Id = 741,
	Name = "订购烟头1",
	Desc = "需要一些烟头",
	Value = 321606,
	Active = true,
	Weight = 54735,
	PreGoal = 
	{
		301256,
		301690,
	},
	GoodsId = 7501606,
	Priority = 1606900,
	Num = 28,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 44805,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 380,
				},
				{
					Value = 1,
					Num = 6805,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 380,
				},
				{
					Value = 1,
					Num = 6805,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 76,
				},
				{
					Value = 1,
					Num = 6805,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 76,
				},
				{
					Value = 1,
					Num = 6805,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 15,
				},
				{
					Value = 1,
					Num = 7305,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 15,
				},
				{
					Value = 1,
					Num = 7305,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 3,
				},
				{
					Value = 1,
					Num = 7305,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 3,
				},
				{
					Value = 1,
					Num = 7305,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 268,
				},
				{
					Value = 320051,
					Num = 180,
				},
			},
		},
	},
	DemandID = 410741,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id742] =
{
	Id = 742,
	Name = "订购指纹1",
	Desc = "需要一些指纹",
	Value = 321607,
	Active = true,
	Weight = 43245,
	PreGoal = 
	{
		301272,
	},
	CloseGoal = 
	{
		301301,
	},
	GoodsId = 7601607,
	Priority = 1607931,
	Num = 28,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 46420,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 394,
				},
				{
					Value = 1,
					Num = 7020,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 394,
				},
				{
					Value = 1,
					Num = 7020,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 78,
				},
				{
					Value = 1,
					Num = 7420,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 78,
				},
				{
					Value = 1,
					Num = 7420,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 15,
				},
				{
					Value = 1,
					Num = 8920,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 15,
				},
				{
					Value = 1,
					Num = 8920,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 3,
				},
				{
					Value = 1,
					Num = 8920,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 3,
				},
				{
					Value = 1,
					Num = 8920,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 278,
				},
				{
					Value = 320051,
					Num = 186,
				},
			},
		},
	},
	DemandID = 410742,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id743] =
{
	Id = 743,
	Name = "订购指纹1",
	Desc = "需要一些指纹",
	Value = 321607,
	Active = true,
	Weight = 44175,
	PreGoal = 
	{
		301272,
		301280,
	},
	CloseGoal = 
	{
		301310,
	},
	GoodsId = 7601607,
	Priority = 1607932,
	Num = 28,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 46420,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 394,
				},
				{
					Value = 1,
					Num = 7020,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 394,
				},
				{
					Value = 1,
					Num = 7020,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 78,
				},
				{
					Value = 1,
					Num = 7420,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 78,
				},
				{
					Value = 1,
					Num = 7420,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 15,
				},
				{
					Value = 1,
					Num = 8920,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 15,
				},
				{
					Value = 1,
					Num = 8920,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 3,
				},
				{
					Value = 1,
					Num = 8920,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 3,
				},
				{
					Value = 1,
					Num = 8920,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 278,
				},
				{
					Value = 320051,
					Num = 186,
				},
			},
		},
	},
	DemandID = 410743,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id744] =
{
	Id = 744,
	Name = "订购指纹1",
	Desc = "需要一些指纹",
	Value = 321607,
	Active = true,
	Weight = 45105,
	PreGoal = 
	{
		301272,
		301288,
	},
	CloseGoal = 
	{
		301322,
	},
	GoodsId = 7601607,
	Priority = 1607933,
	Num = 28,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 46420,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 394,
				},
				{
					Value = 1,
					Num = 7020,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 394,
				},
				{
					Value = 1,
					Num = 7020,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 78,
				},
				{
					Value = 1,
					Num = 7420,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 78,
				},
				{
					Value = 1,
					Num = 7420,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 15,
				},
				{
					Value = 1,
					Num = 8920,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 15,
				},
				{
					Value = 1,
					Num = 8920,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 3,
				},
				{
					Value = 1,
					Num = 8920,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 3,
				},
				{
					Value = 1,
					Num = 8920,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 278,
				},
				{
					Value = 320051,
					Num = 186,
				},
			},
		},
	},
	DemandID = 410744,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id745] =
{
	Id = 745,
	Name = "订购指纹1",
	Desc = "需要一些指纹",
	Value = 321607,
	Active = true,
	Weight = 46500,
	PreGoal = 
	{
		301272,
		301301,
	},
	CloseGoal = 
	{
		301615,
	},
	GoodsId = 7601607,
	Priority = 1607934,
	Num = 28,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 46420,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 394,
				},
				{
					Value = 1,
					Num = 7020,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 394,
				},
				{
					Value = 1,
					Num = 7020,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 78,
				},
				{
					Value = 1,
					Num = 7420,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 78,
				},
				{
					Value = 1,
					Num = 7420,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 15,
				},
				{
					Value = 1,
					Num = 8920,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 15,
				},
				{
					Value = 1,
					Num = 8920,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 3,
				},
				{
					Value = 1,
					Num = 8920,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 3,
				},
				{
					Value = 1,
					Num = 8920,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 278,
				},
				{
					Value = 320051,
					Num = 186,
				},
			},
		},
	},
	DemandID = 410745,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id746] =
{
	Id = 746,
	Name = "订购指纹1",
	Desc = "需要一些指纹",
	Value = 321607,
	Active = true,
	Weight = 47895,
	PreGoal = 
	{
		301272,
		301314,
	},
	CloseGoal = 
	{
		301635,
	},
	GoodsId = 7601607,
	Priority = 1607935,
	Num = 28,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 46420,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 394,
				},
				{
					Value = 1,
					Num = 7020,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 394,
				},
				{
					Value = 1,
					Num = 7020,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 78,
				},
				{
					Value = 1,
					Num = 7420,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 78,
				},
				{
					Value = 1,
					Num = 7420,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 15,
				},
				{
					Value = 1,
					Num = 8920,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 15,
				},
				{
					Value = 1,
					Num = 8920,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 3,
				},
				{
					Value = 1,
					Num = 8920,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 3,
				},
				{
					Value = 1,
					Num = 8920,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 278,
				},
				{
					Value = 320051,
					Num = 186,
				},
			},
		},
	},
	DemandID = 410746,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id747] =
{
	Id = 747,
	Name = "订购指纹1",
	Desc = "需要一些指纹",
	Value = 321607,
	Active = true,
	Weight = 49755,
	PreGoal = 
	{
		301272,
		301605,
	},
	CloseGoal = 
	{
		301655,
	},
	GoodsId = 7601607,
	Priority = 1607936,
	Num = 28,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 46420,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 394,
				},
				{
					Value = 1,
					Num = 7020,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 394,
				},
				{
					Value = 1,
					Num = 7020,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 78,
				},
				{
					Value = 1,
					Num = 7420,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 78,
				},
				{
					Value = 1,
					Num = 7420,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 15,
				},
				{
					Value = 1,
					Num = 8920,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 15,
				},
				{
					Value = 1,
					Num = 8920,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 3,
				},
				{
					Value = 1,
					Num = 8920,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 3,
				},
				{
					Value = 1,
					Num = 8920,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 278,
				},
				{
					Value = 320051,
					Num = 186,
				},
			},
		},
	},
	DemandID = 410747,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id748] =
{
	Id = 748,
	Name = "订购指纹1",
	Desc = "需要一些指纹",
	Value = 321607,
	Active = true,
	Weight = 51615,
	PreGoal = 
	{
		301272,
		301630,
	},
	CloseGoal = 
	{
		301680,
	},
	GoodsId = 7601607,
	Priority = 1607937,
	Num = 28,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 46420,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 394,
				},
				{
					Value = 1,
					Num = 7020,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 394,
				},
				{
					Value = 1,
					Num = 7020,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 78,
				},
				{
					Value = 1,
					Num = 7420,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 78,
				},
				{
					Value = 1,
					Num = 7420,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 15,
				},
				{
					Value = 1,
					Num = 8920,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 15,
				},
				{
					Value = 1,
					Num = 8920,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 3,
				},
				{
					Value = 1,
					Num = 8920,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 3,
				},
				{
					Value = 1,
					Num = 8920,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 278,
				},
				{
					Value = 320051,
					Num = 186,
				},
			},
		},
	},
	DemandID = 410748,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id749] =
{
	Id = 749,
	Name = "订购指纹1",
	Desc = "需要一些指纹",
	Value = 321607,
	Active = true,
	Weight = 53940,
	PreGoal = 
	{
		301272,
		301655,
	},
	CloseGoal = 
	{
		301705,
	},
	GoodsId = 7601607,
	Priority = 1607938,
	Num = 28,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 46420,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 394,
				},
				{
					Value = 1,
					Num = 7020,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 394,
				},
				{
					Value = 1,
					Num = 7020,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 78,
				},
				{
					Value = 1,
					Num = 7420,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 78,
				},
				{
					Value = 1,
					Num = 7420,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 15,
				},
				{
					Value = 1,
					Num = 8920,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 15,
				},
				{
					Value = 1,
					Num = 8920,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 3,
				},
				{
					Value = 1,
					Num = 8920,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 3,
				},
				{
					Value = 1,
					Num = 8920,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 278,
				},
				{
					Value = 320051,
					Num = 186,
				},
			},
		},
	},
	DemandID = 410749,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id750] =
{
	Id = 750,
	Name = "订购指纹1",
	Desc = "需要一些指纹",
	Value = 321607,
	Active = true,
	Weight = 56265,
	PreGoal = 
	{
		301272,
		301680,
	},
	GoodsId = 7601607,
	Priority = 1607939,
	Num = 28,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 46420,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 394,
				},
				{
					Value = 1,
					Num = 7020,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 394,
				},
				{
					Value = 1,
					Num = 7020,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 78,
				},
				{
					Value = 1,
					Num = 7420,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 78,
				},
				{
					Value = 1,
					Num = 7420,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 15,
				},
				{
					Value = 1,
					Num = 8920,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 15,
				},
				{
					Value = 1,
					Num = 8920,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 3,
				},
				{
					Value = 1,
					Num = 8920,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 3,
				},
				{
					Value = 1,
					Num = 8920,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 278,
				},
				{
					Value = 320051,
					Num = 186,
				},
			},
		},
	},
	DemandID = 410750,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id751] =
{
	Id = 751,
	Name = "订购指纹1",
	Desc = "需要一些指纹",
	Value = 321607,
	Active = false,
	Weight = 59055,
	PreGoal = 
	{
		301272,
		301710,
	},
	GoodsId = 7601607,
	Priority = 1607940,
	Num = 28,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 46420,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 394,
				},
				{
					Value = 1,
					Num = 7020,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 394,
				},
				{
					Value = 1,
					Num = 7020,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 78,
				},
				{
					Value = 1,
					Num = 7420,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 78,
				},
				{
					Value = 1,
					Num = 7420,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 15,
				},
				{
					Value = 1,
					Num = 8920,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 15,
				},
				{
					Value = 1,
					Num = 8920,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 3,
				},
				{
					Value = 1,
					Num = 8920,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 3,
				},
				{
					Value = 1,
					Num = 8920,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 278,
				},
				{
					Value = 320051,
					Num = 186,
				},
			},
		},
	},
	DemandID = 410751,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id752] =
{
	Id = 752,
	Name = "订购墨水1",
	Desc = "需要一些墨水",
	Value = 321608,
	Active = true,
	Weight = 47045,
	PreGoal = 
	{
		301288,
	},
	CloseGoal = 
	{
		301318,
	},
	GoodsId = 7701608,
	Priority = 1608971,
	Num = 26,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 47687,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 405,
				},
				{
					Value = 1,
					Num = 7187,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 405,
				},
				{
					Value = 1,
					Num = 7187,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 81,
				},
				{
					Value = 1,
					Num = 7187,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 81,
				},
				{
					Value = 1,
					Num = 7187,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 16,
				},
				{
					Value = 1,
					Num = 7687,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 16,
				},
				{
					Value = 1,
					Num = 7687,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 3,
				},
				{
					Value = 1,
					Num = 10187,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 3,
				},
				{
					Value = 1,
					Num = 10187,
				},
			},
		},
	},
	DemandID = 410752,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id753] =
{
	Id = 753,
	Name = "订购墨水1",
	Desc = "需要一些墨水",
	Value = 321608,
	Active = true,
	Weight = 48015,
	PreGoal = 
	{
		301288,
		301297,
	},
	CloseGoal = 
	{
		301327,
	},
	GoodsId = 7701608,
	Priority = 1608972,
	Num = 26,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 47687,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 405,
				},
				{
					Value = 1,
					Num = 7187,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 405,
				},
				{
					Value = 1,
					Num = 7187,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 81,
				},
				{
					Value = 1,
					Num = 7187,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 81,
				},
				{
					Value = 1,
					Num = 7187,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 16,
				},
				{
					Value = 1,
					Num = 7687,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 16,
				},
				{
					Value = 1,
					Num = 7687,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 3,
				},
				{
					Value = 1,
					Num = 10187,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 3,
				},
				{
					Value = 1,
					Num = 10187,
				},
			},
		},
	},
	DemandID = 410753,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id754] =
{
	Id = 754,
	Name = "订购墨水1",
	Desc = "需要一些墨水",
	Value = 321608,
	Active = true,
	Weight = 48985,
	PreGoal = 
	{
		301288,
		301306,
	},
	CloseGoal = 
	{
		301620,
	},
	GoodsId = 7701608,
	Priority = 1608973,
	Num = 26,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 47687,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 405,
				},
				{
					Value = 1,
					Num = 7187,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 405,
				},
				{
					Value = 1,
					Num = 7187,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 81,
				},
				{
					Value = 1,
					Num = 7187,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 81,
				},
				{
					Value = 1,
					Num = 7187,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 16,
				},
				{
					Value = 1,
					Num = 7687,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 16,
				},
				{
					Value = 1,
					Num = 7687,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 3,
				},
				{
					Value = 1,
					Num = 10187,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 3,
				},
				{
					Value = 1,
					Num = 10187,
				},
			},
		},
	},
	DemandID = 410754,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id755] =
{
	Id = 755,
	Name = "订购墨水1",
	Desc = "需要一些墨水",
	Value = 321608,
	Active = true,
	Weight = 50440,
	PreGoal = 
	{
		301288,
		301318,
	},
	CloseGoal = 
	{
		301635,
	},
	GoodsId = 7701608,
	Priority = 1608974,
	Num = 26,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 47687,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 405,
				},
				{
					Value = 1,
					Num = 7187,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 405,
				},
				{
					Value = 1,
					Num = 7187,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 81,
				},
				{
					Value = 1,
					Num = 7187,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 81,
				},
				{
					Value = 1,
					Num = 7187,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 16,
				},
				{
					Value = 1,
					Num = 7687,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 16,
				},
				{
					Value = 1,
					Num = 7687,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 3,
				},
				{
					Value = 1,
					Num = 10187,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 3,
				},
				{
					Value = 1,
					Num = 10187,
				},
			},
		},
	},
	DemandID = 410755,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id756] =
{
	Id = 756,
	Name = "订购墨水1",
	Desc = "需要一些墨水",
	Value = 321608,
	Active = true,
	Weight = 51895,
	PreGoal = 
	{
		301288,
		301605,
	},
	CloseGoal = 
	{
		301655,
	},
	GoodsId = 7701608,
	Priority = 1608975,
	Num = 26,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 47687,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 405,
				},
				{
					Value = 1,
					Num = 7187,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 405,
				},
				{
					Value = 1,
					Num = 7187,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 81,
				},
				{
					Value = 1,
					Num = 7187,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 81,
				},
				{
					Value = 1,
					Num = 7187,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 16,
				},
				{
					Value = 1,
					Num = 7687,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 16,
				},
				{
					Value = 1,
					Num = 7687,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 3,
				},
				{
					Value = 1,
					Num = 10187,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 3,
				},
				{
					Value = 1,
					Num = 10187,
				},
			},
		},
	},
	DemandID = 410756,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id757] =
{
	Id = 757,
	Name = "订购墨水1",
	Desc = "需要一些墨水",
	Value = 321608,
	Active = true,
	Weight = 53835,
	PreGoal = 
	{
		301288,
		301630,
	},
	CloseGoal = 
	{
		301675,
	},
	GoodsId = 7701608,
	Priority = 1608976,
	Num = 26,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 47687,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 405,
				},
				{
					Value = 1,
					Num = 7187,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 405,
				},
				{
					Value = 1,
					Num = 7187,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 81,
				},
				{
					Value = 1,
					Num = 7187,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 81,
				},
				{
					Value = 1,
					Num = 7187,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 16,
				},
				{
					Value = 1,
					Num = 7687,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 16,
				},
				{
					Value = 1,
					Num = 7687,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 3,
				},
				{
					Value = 1,
					Num = 10187,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 3,
				},
				{
					Value = 1,
					Num = 10187,
				},
			},
		},
	},
	DemandID = 410757,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id758] =
{
	Id = 758,
	Name = "订购墨水1",
	Desc = "需要一些墨水",
	Value = 321608,
	Active = true,
	Weight = 55775,
	PreGoal = 
	{
		301288,
		301650,
	},
	CloseGoal = 
	{
		301700,
	},
	GoodsId = 7701608,
	Priority = 1608977,
	Num = 26,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 47687,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 405,
				},
				{
					Value = 1,
					Num = 7187,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 405,
				},
				{
					Value = 1,
					Num = 7187,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 81,
				},
				{
					Value = 1,
					Num = 7187,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 81,
				},
				{
					Value = 1,
					Num = 7187,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 16,
				},
				{
					Value = 1,
					Num = 7687,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 16,
				},
				{
					Value = 1,
					Num = 7687,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 3,
				},
				{
					Value = 1,
					Num = 10187,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 3,
				},
				{
					Value = 1,
					Num = 10187,
				},
			},
		},
	},
	DemandID = 410758,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id759] =
{
	Id = 759,
	Name = "订购墨水1",
	Desc = "需要一些墨水",
	Value = 321608,
	Active = true,
	Weight = 58200,
	PreGoal = 
	{
		301288,
		301675,
	},
	CloseGoal = 
	{
		301725,
	},
	GoodsId = 7701608,
	Priority = 1608978,
	Num = 26,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 47687,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 405,
				},
				{
					Value = 1,
					Num = 7187,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 405,
				},
				{
					Value = 1,
					Num = 7187,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 81,
				},
				{
					Value = 1,
					Num = 7187,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 81,
				},
				{
					Value = 1,
					Num = 7187,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 16,
				},
				{
					Value = 1,
					Num = 7687,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 16,
				},
				{
					Value = 1,
					Num = 7687,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 3,
				},
				{
					Value = 1,
					Num = 10187,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 3,
				},
				{
					Value = 1,
					Num = 10187,
				},
			},
		},
	},
	DemandID = 410759,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id760] =
{
	Id = 760,
	Name = "订购墨水1",
	Desc = "需要一些墨水",
	Value = 321608,
	Active = true,
	Weight = 60625,
	PreGoal = 
	{
		301288,
		301700,
	},
	GoodsId = 7701608,
	Priority = 1608979,
	Num = 26,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 47687,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 405,
				},
				{
					Value = 1,
					Num = 7187,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 405,
				},
				{
					Value = 1,
					Num = 7187,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 81,
				},
				{
					Value = 1,
					Num = 7187,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 81,
				},
				{
					Value = 1,
					Num = 7187,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 16,
				},
				{
					Value = 1,
					Num = 7687,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 16,
				},
				{
					Value = 1,
					Num = 7687,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 3,
				},
				{
					Value = 1,
					Num = 10187,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 3,
				},
				{
					Value = 1,
					Num = 10187,
				},
			},
		},
	},
	DemandID = 410760,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id761] =
{
	Id = 761,
	Name = "订购墨水1",
	Desc = "需要一些墨水",
	Value = 321608,
	Active = false,
	Weight = 63535,
	PreGoal = 
	{
		301288,
		301730,
	},
	GoodsId = 7701608,
	Priority = 1608980,
	Num = 26,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 47687,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 405,
				},
				{
					Value = 1,
					Num = 7187,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 405,
				},
				{
					Value = 1,
					Num = 7187,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 81,
				},
				{
					Value = 1,
					Num = 7187,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 81,
				},
				{
					Value = 1,
					Num = 7187,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 16,
				},
				{
					Value = 1,
					Num = 7687,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 16,
				},
				{
					Value = 1,
					Num = 7687,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 3,
				},
				{
					Value = 1,
					Num = 10187,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 3,
				},
				{
					Value = 1,
					Num = 10187,
				},
			},
		},
	},
	DemandID = 410761,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id762] =
{
	Id = 762,
	Name = "订购皮鞭1",
	Desc = "需要一些皮鞭",
	Value = 321609,
	Active = true,
	Weight = 50000,
	PreGoal = 
	{
		301535,
		301301,
	},
	CloseGoal = 
	{
		301605,
	},
	GoodsId = 7801609,
	Priority = 1610001,
	Num = 25,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 49735,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 469,
				},
				{
					Value = 1,
					Num = 2835,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 93,
				},
				{
					Value = 1,
					Num = 3235,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 18,
				},
				{
					Value = 1,
					Num = 4735,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 3,
				},
				{
					Value = 1,
					Num = 12235,
				},
			},
		},
	},
	DemandID = 410762,
	DemandGroupList = {
		420002,
		420004,
		420005,
		420006,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id763] =
{
	Id = 763,
	Name = "订购皮鞭1",
	Desc = "需要一些皮鞭",
	Value = 321609,
	Active = true,
	Weight = 51000,
	PreGoal = 
	{
		301535,
		301310,
	},
	CloseGoal = 
	{
		301620,
	},
	GoodsId = 7801609,
	Priority = 1610002,
	Num = 25,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 49735,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 469,
				},
				{
					Value = 1,
					Num = 2835,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 93,
				},
				{
					Value = 1,
					Num = 3235,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 18,
				},
				{
					Value = 1,
					Num = 4735,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 3,
				},
				{
					Value = 1,
					Num = 12235,
				},
			},
		},
	},
	DemandID = 410763,
	DemandGroupList = {
		420002,
		420004,
		420005,
		420006,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id764] =
{
	Id = 764,
	Name = "订购皮鞭1",
	Desc = "需要一些皮鞭",
	Value = 321609,
	Active = true,
	Weight = 52000,
	PreGoal = 
	{
		301535,
		301318,
	},
	CloseGoal = 
	{
		301635,
	},
	GoodsId = 7801609,
	Priority = 1610003,
	Num = 25,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 49735,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 469,
				},
				{
					Value = 1,
					Num = 2835,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 93,
				},
				{
					Value = 1,
					Num = 3235,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 18,
				},
				{
					Value = 1,
					Num = 4735,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 3,
				},
				{
					Value = 1,
					Num = 12235,
				},
			},
		},
	},
	DemandID = 410764,
	DemandGroupList = {
		420002,
		420004,
		420005,
		420006,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id765] =
{
	Id = 765,
	Name = "订购皮鞭1",
	Desc = "需要一些皮鞭",
	Value = 321609,
	Active = true,
	Weight = 53500,
	PreGoal = 
	{
		301535,
		301605,
	},
	CloseGoal = 
	{
		301650,
	},
	GoodsId = 7801609,
	Priority = 1610004,
	Num = 25,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 49735,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 469,
				},
				{
					Value = 1,
					Num = 2835,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 93,
				},
				{
					Value = 1,
					Num = 3235,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 18,
				},
				{
					Value = 1,
					Num = 4735,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 3,
				},
				{
					Value = 1,
					Num = 12235,
				},
			},
		},
	},
	DemandID = 410765,
	DemandGroupList = {
		420002,
		420004,
		420005,
		420006,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id766] =
{
	Id = 766,
	Name = "订购皮鞭1",
	Desc = "需要一些皮鞭",
	Value = 321609,
	Active = true,
	Weight = 55000,
	PreGoal = 
	{
		301535,
		301625,
	},
	CloseGoal = 
	{
		301670,
	},
	GoodsId = 7801609,
	Priority = 1610005,
	Num = 25,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 49735,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 469,
				},
				{
					Value = 1,
					Num = 2835,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 93,
				},
				{
					Value = 1,
					Num = 3235,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 18,
				},
				{
					Value = 1,
					Num = 4735,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 3,
				},
				{
					Value = 1,
					Num = 12235,
				},
			},
		},
	},
	DemandID = 410766,
	DemandGroupList = {
		420002,
		420004,
		420005,
		420006,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id767] =
{
	Id = 767,
	Name = "订购皮鞭1",
	Desc = "需要一些皮鞭",
	Value = 321609,
	Active = true,
	Weight = 57000,
	PreGoal = 
	{
		301535,
		301645,
	},
	CloseGoal = 
	{
		301690,
	},
	GoodsId = 7801609,
	Priority = 1610006,
	Num = 25,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 49735,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 469,
				},
				{
					Value = 1,
					Num = 2835,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 93,
				},
				{
					Value = 1,
					Num = 3235,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 18,
				},
				{
					Value = 1,
					Num = 4735,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 3,
				},
				{
					Value = 1,
					Num = 12235,
				},
			},
		},
	},
	DemandID = 410767,
	DemandGroupList = {
		420002,
		420004,
		420005,
		420006,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id768] =
{
	Id = 768,
	Name = "订购皮鞭1",
	Desc = "需要一些皮鞭",
	Value = 321609,
	Active = true,
	Weight = 59000,
	PreGoal = 
	{
		301535,
		301665,
	},
	CloseGoal = 
	{
		301715,
	},
	GoodsId = 7801609,
	Priority = 1610007,
	Num = 25,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 49735,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 469,
				},
				{
					Value = 1,
					Num = 2835,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 93,
				},
				{
					Value = 1,
					Num = 3235,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 18,
				},
				{
					Value = 1,
					Num = 4735,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 3,
				},
				{
					Value = 1,
					Num = 12235,
				},
			},
		},
	},
	DemandID = 410768,
	DemandGroupList = {
		420002,
		420004,
		420005,
		420006,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id769] =
{
	Id = 769,
	Name = "订购皮鞭1",
	Desc = "需要一些皮鞭",
	Value = 321609,
	Active = true,
	Weight = 61500,
	PreGoal = 
	{
		301535,
		301690,
	},
	GoodsId = 7801609,
	Priority = 1610008,
	Num = 25,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 49735,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 469,
				},
				{
					Value = 1,
					Num = 2835,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 93,
				},
				{
					Value = 1,
					Num = 3235,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 18,
				},
				{
					Value = 1,
					Num = 4735,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 3,
				},
				{
					Value = 1,
					Num = 12235,
				},
			},
		},
	},
	DemandID = 410769,
	DemandGroupList = {
		420002,
		420004,
		420005,
		420006,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id770] =
{
	Id = 770,
	Name = "订购皮鞭1",
	Desc = "需要一些皮鞭",
	Value = 321609,
	Active = false,
	Weight = 64000,
	PreGoal = 
	{
		301535,
		301715,
	},
	GoodsId = 7801609,
	Priority = 1610009,
	Num = 25,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 49735,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 469,
				},
				{
					Value = 1,
					Num = 2835,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 93,
				},
				{
					Value = 1,
					Num = 3235,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 18,
				},
				{
					Value = 1,
					Num = 4735,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 3,
				},
				{
					Value = 1,
					Num = 12235,
				},
			},
		},
	},
	DemandID = 410770,
	DemandGroupList = {
		420002,
		420004,
		420005,
		420006,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id771] =
{
	Id = 771,
	Name = "订购皮鞭1",
	Desc = "需要一些皮鞭",
	Value = 321609,
	Active = false,
	Weight = 65500,
	PreGoal = 
	{
		301535,
		301730,
	},
	GoodsId = 7801609,
	Priority = 1610010,
	Num = 25,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 49735,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 469,
				},
				{
					Value = 1,
					Num = 2835,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 93,
				},
				{
					Value = 1,
					Num = 3235,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 18,
				},
				{
					Value = 1,
					Num = 4735,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 3,
				},
				{
					Value = 1,
					Num = 12235,
				},
			},
		},
	},
	DemandID = 410771,
	DemandGroupList = {
		420002,
		420004,
		420005,
		420006,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id772] =
{
	Id = 772,
	Name = "订购黄瓜马赛克1",
	Desc = "需要一些黄瓜马赛克",
	Value = 321610,
	Active = true,
	Weight = 50000,
	PreGoal = 
	{
		301301,
	},
	CloseGoal = 
	{
		301605,
	},
	GoodsId = 7901610,
	Priority = 1611001,
	Num = 25,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 47719,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 405,
				},
				{
					Value = 1,
					Num = 7218,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 405,
				},
				{
					Value = 1,
					Num = 7218,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 81,
				},
				{
					Value = 1,
					Num = 7218,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 81,
				},
				{
					Value = 1,
					Num = 7218,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 16,
				},
				{
					Value = 1,
					Num = 7718,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 16,
				},
				{
					Value = 1,
					Num = 7718,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 3,
				},
				{
					Value = 1,
					Num = 10219,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 3,
				},
				{
					Value = 1,
					Num = 10219,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 286,
				},
				{
					Value = 320051,
					Num = 191,
				},
			},
		},
	},
	DemandID = 410772,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id773] =
{
	Id = 773,
	Name = "订购黄瓜马赛克1",
	Desc = "需要一些黄瓜马赛克",
	Value = 321610,
	Active = true,
	Weight = 51000,
	PreGoal = 
	{
		301301,
		301310,
	},
	CloseGoal = 
	{
		301620,
	},
	GoodsId = 7901610,
	Priority = 1611002,
	Num = 25,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 47719,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 405,
				},
				{
					Value = 1,
					Num = 7218,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 405,
				},
				{
					Value = 1,
					Num = 7218,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 81,
				},
				{
					Value = 1,
					Num = 7218,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 81,
				},
				{
					Value = 1,
					Num = 7218,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 16,
				},
				{
					Value = 1,
					Num = 7718,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 16,
				},
				{
					Value = 1,
					Num = 7718,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 3,
				},
				{
					Value = 1,
					Num = 10219,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 3,
				},
				{
					Value = 1,
					Num = 10219,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 286,
				},
				{
					Value = 320051,
					Num = 191,
				},
			},
		},
	},
	DemandID = 410773,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id774] =
{
	Id = 774,
	Name = "订购黄瓜马赛克1",
	Desc = "需要一些黄瓜马赛克",
	Value = 321610,
	Active = true,
	Weight = 52000,
	PreGoal = 
	{
		301301,
		301318,
	},
	CloseGoal = 
	{
		301635,
	},
	GoodsId = 7901610,
	Priority = 1611003,
	Num = 25,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 47719,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 405,
				},
				{
					Value = 1,
					Num = 7218,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 405,
				},
				{
					Value = 1,
					Num = 7218,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 81,
				},
				{
					Value = 1,
					Num = 7218,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 81,
				},
				{
					Value = 1,
					Num = 7218,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 16,
				},
				{
					Value = 1,
					Num = 7718,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 16,
				},
				{
					Value = 1,
					Num = 7718,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 3,
				},
				{
					Value = 1,
					Num = 10219,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 3,
				},
				{
					Value = 1,
					Num = 10219,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 286,
				},
				{
					Value = 320051,
					Num = 191,
				},
			},
		},
	},
	DemandID = 410774,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id775] =
{
	Id = 775,
	Name = "订购黄瓜马赛克1",
	Desc = "需要一些黄瓜马赛克",
	Value = 321610,
	Active = true,
	Weight = 53500,
	PreGoal = 
	{
		301301,
		301605,
	},
	CloseGoal = 
	{
		301650,
	},
	GoodsId = 7901610,
	Priority = 1611004,
	Num = 25,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 47719,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 405,
				},
				{
					Value = 1,
					Num = 7218,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 405,
				},
				{
					Value = 1,
					Num = 7218,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 81,
				},
				{
					Value = 1,
					Num = 7218,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 81,
				},
				{
					Value = 1,
					Num = 7218,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 16,
				},
				{
					Value = 1,
					Num = 7718,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 16,
				},
				{
					Value = 1,
					Num = 7718,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 3,
				},
				{
					Value = 1,
					Num = 10219,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 3,
				},
				{
					Value = 1,
					Num = 10219,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 286,
				},
				{
					Value = 320051,
					Num = 191,
				},
			},
		},
	},
	DemandID = 410775,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id776] =
{
	Id = 776,
	Name = "订购黄瓜马赛克1",
	Desc = "需要一些黄瓜马赛克",
	Value = 321610,
	Active = true,
	Weight = 55000,
	PreGoal = 
	{
		301301,
		301625,
	},
	CloseGoal = 
	{
		301670,
	},
	GoodsId = 7901610,
	Priority = 1611005,
	Num = 25,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 47719,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 405,
				},
				{
					Value = 1,
					Num = 7218,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 405,
				},
				{
					Value = 1,
					Num = 7218,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 81,
				},
				{
					Value = 1,
					Num = 7218,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 81,
				},
				{
					Value = 1,
					Num = 7218,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 16,
				},
				{
					Value = 1,
					Num = 7718,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 16,
				},
				{
					Value = 1,
					Num = 7718,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 3,
				},
				{
					Value = 1,
					Num = 10219,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 3,
				},
				{
					Value = 1,
					Num = 10219,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 286,
				},
				{
					Value = 320051,
					Num = 191,
				},
			},
		},
	},
	DemandID = 410776,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id777] =
{
	Id = 777,
	Name = "订购黄瓜马赛克1",
	Desc = "需要一些黄瓜马赛克",
	Value = 321610,
	Active = true,
	Weight = 57000,
	PreGoal = 
	{
		301301,
		301645,
	},
	CloseGoal = 
	{
		301690,
	},
	GoodsId = 7901610,
	Priority = 1611006,
	Num = 25,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 47719,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 405,
				},
				{
					Value = 1,
					Num = 7218,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 405,
				},
				{
					Value = 1,
					Num = 7218,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 81,
				},
				{
					Value = 1,
					Num = 7218,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 81,
				},
				{
					Value = 1,
					Num = 7218,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 16,
				},
				{
					Value = 1,
					Num = 7718,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 16,
				},
				{
					Value = 1,
					Num = 7718,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 3,
				},
				{
					Value = 1,
					Num = 10219,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 3,
				},
				{
					Value = 1,
					Num = 10219,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 286,
				},
				{
					Value = 320051,
					Num = 191,
				},
			},
		},
	},
	DemandID = 410777,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id778] =
{
	Id = 778,
	Name = "订购黄瓜马赛克1",
	Desc = "需要一些黄瓜马赛克",
	Value = 321610,
	Active = true,
	Weight = 59000,
	PreGoal = 
	{
		301301,
		301665,
	},
	CloseGoal = 
	{
		301715,
	},
	GoodsId = 7901610,
	Priority = 1611007,
	Num = 25,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 47719,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 405,
				},
				{
					Value = 1,
					Num = 7218,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 405,
				},
				{
					Value = 1,
					Num = 7218,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 81,
				},
				{
					Value = 1,
					Num = 7218,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 81,
				},
				{
					Value = 1,
					Num = 7218,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 16,
				},
				{
					Value = 1,
					Num = 7718,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 16,
				},
				{
					Value = 1,
					Num = 7718,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 3,
				},
				{
					Value = 1,
					Num = 10219,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 3,
				},
				{
					Value = 1,
					Num = 10219,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 286,
				},
				{
					Value = 320051,
					Num = 191,
				},
			},
		},
	},
	DemandID = 410778,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id779] =
{
	Id = 779,
	Name = "订购黄瓜马赛克1",
	Desc = "需要一些黄瓜马赛克",
	Value = 321610,
	Active = true,
	Weight = 61500,
	PreGoal = 
	{
		301301,
		301690,
	},
	GoodsId = 7901610,
	Priority = 1611008,
	Num = 25,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 47719,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 405,
				},
				{
					Value = 1,
					Num = 7218,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 405,
				},
				{
					Value = 1,
					Num = 7218,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 81,
				},
				{
					Value = 1,
					Num = 7218,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 81,
				},
				{
					Value = 1,
					Num = 7218,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 16,
				},
				{
					Value = 1,
					Num = 7718,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 16,
				},
				{
					Value = 1,
					Num = 7718,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 3,
				},
				{
					Value = 1,
					Num = 10219,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 3,
				},
				{
					Value = 1,
					Num = 10219,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 286,
				},
				{
					Value = 320051,
					Num = 191,
				},
			},
		},
	},
	DemandID = 410779,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id780] =
{
	Id = 780,
	Name = "订购黄瓜马赛克1",
	Desc = "需要一些黄瓜马赛克",
	Value = 321610,
	Active = false,
	Weight = 64000,
	PreGoal = 
	{
		301301,
		301715,
	},
	GoodsId = 7901610,
	Priority = 1611009,
	Num = 25,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 47719,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 405,
				},
				{
					Value = 1,
					Num = 7218,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 405,
				},
				{
					Value = 1,
					Num = 7218,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 81,
				},
				{
					Value = 1,
					Num = 7218,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 81,
				},
				{
					Value = 1,
					Num = 7218,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 16,
				},
				{
					Value = 1,
					Num = 7718,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 16,
				},
				{
					Value = 1,
					Num = 7718,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 3,
				},
				{
					Value = 1,
					Num = 10219,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 3,
				},
				{
					Value = 1,
					Num = 10219,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 286,
				},
				{
					Value = 320051,
					Num = 191,
				},
			},
		},
	},
	DemandID = 410780,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id781] =
{
	Id = 781,
	Name = "订购黄瓜马赛克1",
	Desc = "需要一些黄瓜马赛克",
	Value = 321610,
	Active = false,
	Weight = 65500,
	PreGoal = 
	{
		301301,
		301730,
	},
	GoodsId = 7901610,
	Priority = 1611010,
	Num = 25,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 47719,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 405,
				},
				{
					Value = 1,
					Num = 7218,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 405,
				},
				{
					Value = 1,
					Num = 7218,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 81,
				},
				{
					Value = 1,
					Num = 7218,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 81,
				},
				{
					Value = 1,
					Num = 7218,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 16,
				},
				{
					Value = 1,
					Num = 7718,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 16,
				},
				{
					Value = 1,
					Num = 7718,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 3,
				},
				{
					Value = 1,
					Num = 10219,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 3,
				},
				{
					Value = 1,
					Num = 10219,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 286,
				},
				{
					Value = 320051,
					Num = 191,
				},
			},
		},
	},
	DemandID = 410781,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id782] =
{
	Id = 782,
	Name = "订购灵感1",
	Desc = "需要一些灵感",
	Value = 321611,
	Active = true,
	Weight = 53045,
	PreGoal = 
	{
		301314,
	},
	CloseGoal = 
	{
		301625,
	},
	GoodsId = 8001611,
	Priority = 1612031,
	Num = 25,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 49735,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 422,
				},
				{
					Value = 1,
					Num = 7535,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 422,
				},
				{
					Value = 1,
					Num = 7535,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 84,
				},
				{
					Value = 1,
					Num = 7735,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 84,
				},
				{
					Value = 1,
					Num = 7735,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 16,
				},
				{
					Value = 1,
					Num = 9735,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 16,
				},
				{
					Value = 1,
					Num = 9735,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 3,
				},
				{
					Value = 1,
					Num = 12235,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 3,
				},
				{
					Value = 1,
					Num = 12235,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 298,
				},
				{
					Value = 320051,
					Num = 199,
				},
			},
		},
	},
	DemandID = 410782,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id783] =
{
	Id = 783,
	Name = "订购灵感1",
	Desc = "需要一些灵感",
	Value = 321611,
	Active = true,
	Weight = 54075,
	PreGoal = 
	{
		301314,
		301322,
	},
	CloseGoal = 
	{
		301635,
	},
	GoodsId = 8001611,
	Priority = 1612032,
	Num = 25,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 49735,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 422,
				},
				{
					Value = 1,
					Num = 7535,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 422,
				},
				{
					Value = 1,
					Num = 7535,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 84,
				},
				{
					Value = 1,
					Num = 7735,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 84,
				},
				{
					Value = 1,
					Num = 7735,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 16,
				},
				{
					Value = 1,
					Num = 9735,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 16,
				},
				{
					Value = 1,
					Num = 9735,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 3,
				},
				{
					Value = 1,
					Num = 12235,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 3,
				},
				{
					Value = 1,
					Num = 12235,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 298,
				},
				{
					Value = 320051,
					Num = 199,
				},
			},
		},
	},
	DemandID = 410783,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id784] =
{
	Id = 784,
	Name = "订购灵感1",
	Desc = "需要一些灵感",
	Value = 321611,
	Active = true,
	Weight = 55105,
	PreGoal = 
	{
		301314,
		301605,
	},
	CloseGoal = 
	{
		301650,
	},
	GoodsId = 8001611,
	Priority = 1612033,
	Num = 25,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 49735,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 422,
				},
				{
					Value = 1,
					Num = 7535,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 422,
				},
				{
					Value = 1,
					Num = 7535,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 84,
				},
				{
					Value = 1,
					Num = 7735,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 84,
				},
				{
					Value = 1,
					Num = 7735,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 16,
				},
				{
					Value = 1,
					Num = 9735,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 16,
				},
				{
					Value = 1,
					Num = 9735,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 3,
				},
				{
					Value = 1,
					Num = 12235,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 3,
				},
				{
					Value = 1,
					Num = 12235,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 298,
				},
				{
					Value = 320051,
					Num = 199,
				},
			},
		},
	},
	DemandID = 410784,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id785] =
{
	Id = 785,
	Name = "订购灵感1",
	Desc = "需要一些灵感",
	Value = 321611,
	Active = true,
	Weight = 56650,
	PreGoal = 
	{
		301314,
		301625,
	},
	CloseGoal = 
	{
		301665,
	},
	GoodsId = 8001611,
	Priority = 1612034,
	Num = 25,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 49735,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 422,
				},
				{
					Value = 1,
					Num = 7535,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 422,
				},
				{
					Value = 1,
					Num = 7535,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 84,
				},
				{
					Value = 1,
					Num = 7735,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 84,
				},
				{
					Value = 1,
					Num = 7735,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 16,
				},
				{
					Value = 1,
					Num = 9735,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 16,
				},
				{
					Value = 1,
					Num = 9735,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 3,
				},
				{
					Value = 1,
					Num = 12235,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 3,
				},
				{
					Value = 1,
					Num = 12235,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 298,
				},
				{
					Value = 320051,
					Num = 199,
				},
			},
		},
	},
	DemandID = 410785,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id786] =
{
	Id = 786,
	Name = "订购灵感1",
	Desc = "需要一些灵感",
	Value = 321611,
	Active = true,
	Weight = 58195,
	PreGoal = 
	{
		301314,
		301640,
	},
	CloseGoal = 
	{
		301685,
	},
	GoodsId = 8001611,
	Priority = 1612035,
	Num = 25,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 49735,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 422,
				},
				{
					Value = 1,
					Num = 7535,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 422,
				},
				{
					Value = 1,
					Num = 7535,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 84,
				},
				{
					Value = 1,
					Num = 7735,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 84,
				},
				{
					Value = 1,
					Num = 7735,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 16,
				},
				{
					Value = 1,
					Num = 9735,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 16,
				},
				{
					Value = 1,
					Num = 9735,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 3,
				},
				{
					Value = 1,
					Num = 12235,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 3,
				},
				{
					Value = 1,
					Num = 12235,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 298,
				},
				{
					Value = 320051,
					Num = 199,
				},
			},
		},
	},
	DemandID = 410786,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id787] =
{
	Id = 787,
	Name = "订购灵感1",
	Desc = "需要一些灵感",
	Value = 321611,
	Active = true,
	Weight = 60255,
	PreGoal = 
	{
		301314,
		301660,
	},
	CloseGoal = 
	{
		301705,
	},
	GoodsId = 8001611,
	Priority = 1612036,
	Num = 25,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 49735,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 422,
				},
				{
					Value = 1,
					Num = 7535,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 422,
				},
				{
					Value = 1,
					Num = 7535,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 84,
				},
				{
					Value = 1,
					Num = 7735,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 84,
				},
				{
					Value = 1,
					Num = 7735,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 16,
				},
				{
					Value = 1,
					Num = 9735,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 16,
				},
				{
					Value = 1,
					Num = 9735,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 3,
				},
				{
					Value = 1,
					Num = 12235,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 3,
				},
				{
					Value = 1,
					Num = 12235,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 298,
				},
				{
					Value = 320051,
					Num = 199,
				},
			},
		},
	},
	DemandID = 410787,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id788] =
{
	Id = 788,
	Name = "订购灵感1",
	Desc = "需要一些灵感",
	Value = 321611,
	Active = true,
	Weight = 62315,
	PreGoal = 
	{
		301314,
		301680,
	},
	CloseGoal = 
	{
		301730,
	},
	GoodsId = 8001611,
	Priority = 1612037,
	Num = 25,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 49735,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 422,
				},
				{
					Value = 1,
					Num = 7535,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 422,
				},
				{
					Value = 1,
					Num = 7535,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 84,
				},
				{
					Value = 1,
					Num = 7735,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 84,
				},
				{
					Value = 1,
					Num = 7735,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 16,
				},
				{
					Value = 1,
					Num = 9735,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 16,
				},
				{
					Value = 1,
					Num = 9735,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 3,
				},
				{
					Value = 1,
					Num = 12235,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 3,
				},
				{
					Value = 1,
					Num = 12235,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 298,
				},
				{
					Value = 320051,
					Num = 199,
				},
			},
		},
	},
	DemandID = 410788,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id789] =
{
	Id = 789,
	Name = "订购灵感1",
	Desc = "需要一些灵感",
	Value = 321611,
	Active = true,
	Weight = 64890,
	PreGoal = 
	{
		301314,
		301705,
	},
	GoodsId = 8001611,
	Priority = 1612038,
	Num = 25,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 49735,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 422,
				},
				{
					Value = 1,
					Num = 7535,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 422,
				},
				{
					Value = 1,
					Num = 7535,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 84,
				},
				{
					Value = 1,
					Num = 7735,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 84,
				},
				{
					Value = 1,
					Num = 7735,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 16,
				},
				{
					Value = 1,
					Num = 9735,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 16,
				},
				{
					Value = 1,
					Num = 9735,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 3,
				},
				{
					Value = 1,
					Num = 12235,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 3,
				},
				{
					Value = 1,
					Num = 12235,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 298,
				},
				{
					Value = 320051,
					Num = 199,
				},
			},
		},
	},
	DemandID = 410789,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id790] =
{
	Id = 790,
	Name = "订购灵感1",
	Desc = "需要一些灵感",
	Value = 321611,
	Active = false,
	Weight = 67465,
	PreGoal = 
	{
		301314,
		301730,
	},
	GoodsId = 8001611,
	Priority = 1612039,
	Num = 25,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 49735,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 422,
				},
				{
					Value = 1,
					Num = 7535,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 422,
				},
				{
					Value = 1,
					Num = 7535,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 84,
				},
				{
					Value = 1,
					Num = 7735,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 84,
				},
				{
					Value = 1,
					Num = 7735,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 16,
				},
				{
					Value = 1,
					Num = 9735,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 16,
				},
				{
					Value = 1,
					Num = 9735,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 3,
				},
				{
					Value = 1,
					Num = 12235,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 3,
				},
				{
					Value = 1,
					Num = 12235,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 298,
				},
				{
					Value = 320051,
					Num = 199,
				},
			},
		},
	},
	DemandID = 410790,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id791] =
{
	Id = 791,
	Name = "订购灵感1",
	Desc = "需要一些灵感",
	Value = 321611,
	Active = false,
	Weight = 67465,
	PreGoal = 
	{
		301314,
		301730,
	},
	GoodsId = 8001611,
	Priority = 1612040,
	Num = 25,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 49735,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 422,
				},
				{
					Value = 1,
					Num = 7535,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 422,
				},
				{
					Value = 1,
					Num = 7535,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 84,
				},
				{
					Value = 1,
					Num = 7735,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 84,
				},
				{
					Value = 1,
					Num = 7735,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 16,
				},
				{
					Value = 1,
					Num = 9735,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 16,
				},
				{
					Value = 1,
					Num = 9735,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 3,
				},
				{
					Value = 1,
					Num = 12235,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 3,
				},
				{
					Value = 1,
					Num = 12235,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 298,
				},
				{
					Value = 320051,
					Num = 199,
				},
			},
		},
	},
	DemandID = 410791,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id792] =
{
	Id = 792,
	Name = "订购营养液1",
	Desc = "需要一些营养液",
	Value = 321612,
	Active = true,
	Weight = 55125,
	PreGoal = 
	{
		301543,
		301322,
	},
	CloseGoal = 
	{
		301635,
	},
	GoodsId = 8101612,
	Priority = 1613051,
	Num = 24,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 51965,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 490,
				},
				{
					Value = 1,
					Num = 2965,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 98,
				},
				{
					Value = 1,
					Num = 2965,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 19,
				},
				{
					Value = 1,
					Num = 4465,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 3,
				},
				{
					Value = 1,
					Num = 14465,
				},
			},
		},
	},
	DemandID = 410792,
	DemandGroupList = {
		420002,
		420004,
		420005,
		420006,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id793] =
{
	Id = 793,
	Name = "订购营养液1",
	Desc = "需要一些营养液",
	Value = 321612,
	Active = true,
	Weight = 56175,
	PreGoal = 
	{
		301543,
		301605,
	},
	CloseGoal = 
	{
		301645,
	},
	GoodsId = 8101612,
	Priority = 1613052,
	Num = 24,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 51965,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 490,
				},
				{
					Value = 1,
					Num = 2965,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 98,
				},
				{
					Value = 1,
					Num = 2965,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 19,
				},
				{
					Value = 1,
					Num = 4465,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 3,
				},
				{
					Value = 1,
					Num = 14465,
				},
			},
		},
	},
	DemandID = 410793,
	DemandGroupList = {
		420002,
		420004,
		420005,
		420006,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id794] =
{
	Id = 794,
	Name = "订购营养液1",
	Desc = "需要一些营养液",
	Value = 321612,
	Active = true,
	Weight = 57225,
	PreGoal = 
	{
		301543,
		301620,
	},
	CloseGoal = 
	{
		301660,
	},
	GoodsId = 8101612,
	Priority = 1613053,
	Num = 24,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 51965,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 490,
				},
				{
					Value = 1,
					Num = 2965,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 98,
				},
				{
					Value = 1,
					Num = 2965,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 19,
				},
				{
					Value = 1,
					Num = 4465,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 3,
				},
				{
					Value = 1,
					Num = 14465,
				},
			},
		},
	},
	DemandID = 410794,
	DemandGroupList = {
		420002,
		420004,
		420005,
		420006,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id795] =
{
	Id = 795,
	Name = "订购营养液1",
	Desc = "需要一些营养液",
	Value = 321612,
	Active = true,
	Weight = 58800,
	PreGoal = 
	{
		301543,
		301635,
	},
	CloseGoal = 
	{
		301675,
	},
	GoodsId = 8101612,
	Priority = 1613054,
	Num = 24,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 51965,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 490,
				},
				{
					Value = 1,
					Num = 2965,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 98,
				},
				{
					Value = 1,
					Num = 2965,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 19,
				},
				{
					Value = 1,
					Num = 4465,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 3,
				},
				{
					Value = 1,
					Num = 14465,
				},
			},
		},
	},
	DemandID = 410795,
	DemandGroupList = {
		420002,
		420004,
		420005,
		420006,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id796] =
{
	Id = 796,
	Name = "订购营养液1",
	Desc = "需要一些营养液",
	Value = 321612,
	Active = true,
	Weight = 60375,
	PreGoal = 
	{
		301543,
		301650,
	},
	CloseGoal = 
	{
		301695,
	},
	GoodsId = 8101612,
	Priority = 1613055,
	Num = 24,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 51965,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 490,
				},
				{
					Value = 1,
					Num = 2965,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 98,
				},
				{
					Value = 1,
					Num = 2965,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 19,
				},
				{
					Value = 1,
					Num = 4465,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 3,
				},
				{
					Value = 1,
					Num = 14465,
				},
			},
		},
	},
	DemandID = 410796,
	DemandGroupList = {
		420002,
		420004,
		420005,
		420006,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id797] =
{
	Id = 797,
	Name = "订购营养液1",
	Desc = "需要一些营养液",
	Value = 321612,
	Active = true,
	Weight = 62475,
	PreGoal = 
	{
		301543,
		301670,
	},
	CloseGoal = 
	{
		301715,
	},
	GoodsId = 8101612,
	Priority = 1613056,
	Num = 24,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 51965,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 490,
				},
				{
					Value = 1,
					Num = 2965,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 98,
				},
				{
					Value = 1,
					Num = 2965,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 19,
				},
				{
					Value = 1,
					Num = 4465,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 3,
				},
				{
					Value = 1,
					Num = 14465,
				},
			},
		},
	},
	DemandID = 410797,
	DemandGroupList = {
		420002,
		420004,
		420005,
		420006,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id798] =
{
	Id = 798,
	Name = "订购营养液1",
	Desc = "需要一些营养液",
	Value = 321612,
	Active = true,
	Weight = 64575,
	PreGoal = 
	{
		301543,
		301690,
	},
	GoodsId = 8101612,
	Priority = 1613057,
	Num = 24,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 51965,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 490,
				},
				{
					Value = 1,
					Num = 2965,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 98,
				},
				{
					Value = 1,
					Num = 2965,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 19,
				},
				{
					Value = 1,
					Num = 4465,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 3,
				},
				{
					Value = 1,
					Num = 14465,
				},
			},
		},
	},
	DemandID = 410798,
	DemandGroupList = {
		420002,
		420004,
		420005,
		420006,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id799] =
{
	Id = 799,
	Name = "订购营养液1",
	Desc = "需要一些营养液",
	Value = 321612,
	Active = false,
	Weight = 67200,
	PreGoal = 
	{
		301543,
		301715,
	},
	GoodsId = 8101612,
	Priority = 1613058,
	Num = 24,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 51965,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 490,
				},
				{
					Value = 1,
					Num = 2965,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 98,
				},
				{
					Value = 1,
					Num = 2965,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 19,
				},
				{
					Value = 1,
					Num = 4465,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 3,
				},
				{
					Value = 1,
					Num = 14465,
				},
			},
		},
	},
	DemandID = 410799,
	DemandGroupList = {
		420002,
		420004,
		420005,
		420006,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id800] =
{
	Id = 800,
	Name = "订购营养液1",
	Desc = "需要一些营养液",
	Value = 321612,
	Active = false,
	Weight = 68775,
	PreGoal = 
	{
		301543,
		301730,
	},
	GoodsId = 8101612,
	Priority = 1613059,
	Num = 24,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 51965,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 490,
				},
				{
					Value = 1,
					Num = 2965,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 98,
				},
				{
					Value = 1,
					Num = 2965,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 19,
				},
				{
					Value = 1,
					Num = 4465,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 3,
				},
				{
					Value = 1,
					Num = 14465,
				},
			},
		},
	},
	DemandID = 410800,
	DemandGroupList = {
		420002,
		420004,
		420005,
		420006,
		420007,
		420009,
	},
}
