IAPConfig ={};
IAPID = 
{
	Id001 = 700001,
	Id002 = 700002,
	Id003 = 700003,
	Id004 = 700004,
	Id005 = 700005,
	Id006 = 700006,
	Id007 = 700007,
	Id008 = 700008,
	Id009 = 700009,
}
IAPConfig[IAPID.Id001] =
{
	Id = 1,
	Name = "60玉璧",
	Desc = "60枚玉璧\n赠送6枚玉璧",
	Type = 1,
	Rewards = {
		{
			Value = 2,
			Num = 66,
		},
	},
	PackageName = "66玉璧",
	ButtonDesc = "6元",
	Price = 6,
	PriceUSD = 0.99,
	Icon = "IAP_Bth_yubi1",
	IsDouble = true,
	StartupDoubleTime = 1542852000,
	StoreId = {
		ios = "ios.miaoqixingqiu.6",
		tencent = "1061051",
	},
}
IAPConfig[IAPID.Id002] =
{
	Id = 2,
	Name = "300玉璧",
	Desc = "300枚玉璧\n赠送33枚玉璧",
	Type = 1,
	Rewards = {
		{
			Value = 2,
			Num = 333,
		},
	},
	PackageName = "333玉璧",
	ButtonDesc = "30元",
	Price = 30,
	PriceUSD = 4.99,
	Icon = "IAP_Bth_yubi2",
	IsDouble = true,
	StartupDoubleTime = 1542852000,
	StoreId = {
		ios = "ios.miaoqixingqiu.30",
		tencent = "1061052",
	},
}
IAPConfig[IAPID.Id003] =
{
	Id = 3,
	Name = "880玉璧",
	Desc = "880枚玉璧\n赠送110枚玉璧",
	Type = 1,
	Rewards = {
		{
			Value = 2,
			Num = 990,
		},
	},
	PackageName = "990玉璧",
	ButtonDesc = "88元",
	Price = 88,
	PriceUSD = 12.99,
	Icon = "IAP_Bth_yubi3",
	IsDouble = true,
	StartupDoubleTime = 1542852000,
	StoreId = {
		ios = "ios.miaoqixingqiu.88",
		tencent = "1061053",
	},
}
IAPConfig[IAPID.Id004] =
{
	Id = 4,
	Name = "1980玉璧",
	Desc = "1980枚玉璧\n赠送265枚玉璧",
	Type = 1,
	Rewards = {
		{
			Value = 2,
			Num = 2245,
		},
	},
	PackageName = "2245玉璧",
	ButtonDesc = "198元",
	Price = 198,
	PriceUSD = 29.99,
	Icon = "IAP_Bth_yubi4",
	IsDouble = true,
	StartupDoubleTime = 1542852000,
	StoreId = {
		ios = "ios.miaoqixingqiu.198",
		tencent = "1061054",
	},
}
IAPConfig[IAPID.Id005] =
{
	Id = 5,
	Name = "3280玉璧",
	Desc = "3280枚玉璧\n赠送560枚玉璧",
	Type = 1,
	Rewards = {
		{
			Value = 2,
			Num = 3840,
		},
	},
	PackageName = "3840玉璧",
	ButtonDesc = "328元",
	Price = 328,
	PriceUSD = 49.99,
	Icon = "IAP_Bth_yubi5",
	IsDouble = true,
	StartupDoubleTime = 1542852000,
	StoreId = {
		ios = "ios.miaoqixingqiu.328",
		tencent = "1061055",
	},
}
IAPConfig[IAPID.Id006] =
{
	Id = 6,
	Name = "6480玉璧",
	Desc = "6480枚玉璧\n赠送1288枚玉璧",
	Type = 1,
	Rewards = {
		{
			Value = 2,
			Num = 7768,
		},
	},
	PackageName = "7768玉璧",
	ButtonDesc = "648元",
	Price = 648,
	PriceUSD = 99.99,
	Icon = "IAP_Bth_yubi6",
	IsDouble = true,
	StartupDoubleTime = 1542852000,
	StoreId = {
		ios = "ios.miaoqixingqiu.648",
		tencent = "1061056",
	},
}
IAPConfig[IAPID.Id007] =
{
	Id = 7,
	Name = "呜呜月卡",
	Desc = "立刻获得300玉璧\n30天每天可领30玉璧",
	Type = 2,
	Rate = 1100,
	Rewards = {
		{
			Value = 2,
			Num = 300,
		},
		{
			Value = 7,
			Num = 30,
		},
		{
			Value = 252001,
			Num = 1,
		},
	},
	PackageName = "呜呜月卡",
	ButtonDesc = "30元",
	Price = 30,
	PriceUSD = 4.99,
	Icon = "IAP_Character_55",
	IsDouble = false,
	StoreId = {
		ios = "ios.miaoqixingqiu.card.30",
		tencent = "1061057",
	},
}
IAPConfig[IAPID.Id008] =
{
	Id = 8,
	Name = "好运霸符",
	Desc = "立刻获得880玉璧",
	Type = 3,
	ActivityThemeId = 610026,
	Rewards = {
		{
			Value = 2,
			Num = 880,
		},
		{
			Value = 8,
			Num = 1,
		},
	},
	PackageName = "庙会好运符",
	ButtonDesc = "88元",
	Price = 88,
	PriceUSD = 12.99,
	Icon = "IAPMonthlyCard",
	IsDouble = false,
	StoreId = {
		ios = "ios.miaoqixingqiu.card.88",
		tencent = "106132",
	},
}
IAPConfig[IAPID.Id009] =
{
	Id = 9,
	Name = "漆漆月卡",
	Desc = "立刻获得180玉璧\n30天每天可领18玉璧",
	Type = 2,
	Rate = 1100,
	Rewards = {
		{
			Value = 2,
			Num = 180,
		},
		{
			Value = 9,
			Num = 30,
		},
	},
	PackageName = "漆漆月卡",
	ButtonDesc = "30元",
	Price = 30,
	PriceUSD = 4.99,
	Icon = "IAP_Character_77",
	IsDouble = false,
	StoreId = {
		ios = "ios.miaoqixingqiu.card.30",
		tencent = "1061057",
	},
}

