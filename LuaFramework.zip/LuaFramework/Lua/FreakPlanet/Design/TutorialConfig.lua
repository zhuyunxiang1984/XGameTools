TutorialConfig ={};

TutorialConstData = {
	ExploreGoal = 300001,                   --探索教学
	ChallengeGoal = 300002,		            --挑战教学
	CharacterUpgradeGoal = 300003,			--升级教学
	WorkShopGoal = 300006,			        --打工教学
	DemandGoal = 300010,                    --订单教学
	EquipmentUpgradeGoal = 300011,		    --装备升级教学
	WorkShopUpgradeGoal = 300018,		    --打工升级教学
	SummonGoal = 300024,	                --抽卡教学
	CraftGoal = 300026,		                --合成教学

	ExploreAreaId = 130001,		--首次探索地区
	ChallengeAreaId = 130002,	--首次挑战地区
	WuwuId = 220001,			--呜呜id
	QiqiId = 220002,			--漆漆id
	JuminId = 220011,			--居民NPCid
	KouliangId = 320401,		--口粮配方id
}

Tutorials = 
{
	Tutorial_1_1  = "Tutorial_1_1",
	Tutorial_1_2_0  = "Tutorial_1_2_0",
	Tutorial_1_2  = "Tutorial_1_2",
	Tutorial_1_3  = "Tutorial_1_3",
	Tutorial_1_5  = "Tutorial_1_5",
	Tutorial_1_7  = "Tutorial_1_7",
	Tutorial_1_8  = "Tutorial_1_8",
	Tutorial_1_8_1 = "Tutorial_1_8_1",
	Tutorial_1_9  = "Tutorial_1_9",
	Tutorial_1_10 = "Tutorial_1_10",
	Tutorial_1_11 = "Tutorial_1_11",
	Tutorial_1_12 = "Tutorial_1_12",

	Tutorial_2_2_1 = "Tutorial_2_2_1",
	Tutorial_2_2  = "Tutorial_2_2",
	Tutorial_2_4  = "Tutorial_2_4",
	Tutorial_2_6  = "Tutorial_2_6",

	Tutorial_3_1  = "Tutorial_3_1",
	Tutorial_3_2  = "Tutorial_3_2",

	Tutorial_4_1  = "Tutorial_4_1",
	Tutorial_4_1_2  = "Tutorial_4_1_2",
	Tutorial_4_2  = "Tutorial_4_2",
	Tutorial_4_3  = "Tutorial_4_3",
	Tutorial_4_4  = "Tutorial_4_4",
	Tutorial_4_5  = "Tutorial_4_5",

	Tutorial_5_1 = "Tutorial_5_1",
	Tutorial_5_2 = "Tutorial_5_2",
	Tutorial_5_3 = "Tutorial_5_3",
	Tutorial_5_6 = "Tutorial_5_6",

	Tutorial_6_1  = "Tutorial_6_1",
	Tutorial_6_2  = "Tutorial_6_2",
	Tutorial_6_3  = "Tutorial_6_3",

	Tutorial_7_1  = "Tutorial_7_1",
	Tutorial_7_1_2 = "Tutorial_7_1_2",
	Tutorial_7_2  = "Tutorial_7_2",
	Tutorial_7_3  = "Tutorial_7_3",
	Tutorial_7_4  = "Tutorial_7_4",

	Tutorial_8_1  = "Tutorial_8_1",
	Tutorial_8_2  = "Tutorial_8_2",

	Tutorial_9_1  = "Tutorial_9_1",
	Tutorial_9_2  = "Tutorial_9_2",
	Tutorial_9_3  = "Tutorial_9_3",

	Tutorial_10_1  = "Tutorial_10_1",
	Tutorial_10_2  = "Tutorial_10_2",
	Tutorial_10_3  = "Tutorial_10_3",

	Tutorial_Tourist_1 = "Tutorial_Tourist_1",
	Tutorial_Tourist_2 = "Tutorial_Tourist_2",
	Tutorial_Tourist_3 = "Tutorial_Tourist_3",
	Tutorial_Tourist_4 = "Tutorial_Tourist_4",
	Tutorial_Tourist_5 = "Tutorial_Tourist_5",
	-- 全程强制引导，包括领取任务奖励
	Tutorial_ExploreGoalNotify = "Tutorial_ExploreGoalNotify",
	Tutorial_ExploreGoalReward = "Tutorial_ExploreGoalReward",
	Tutorial_ChallengeGoalGo = "Tutorial_ChallengeGoalGo",
	Tutorial_ChallengeGoalReward = "Tutorial_ChallengeGoalReward",
	-- 任务界面强制引导
	Tutorial_EquipmentUpgradeGoalGo = "Tutorial_EquipmentUpgradeGoalGo",
	Tutorial_WorkShopUpgradeGoalGo = "Tutorial_WorkShopUpgradeGoalGo",
	Tutorial_CraftGoalGo = "Tutorial_CraftGoalGo",
	Tutorial_SummonGoalGo = "Tutorial_SummonGoalGo",

	Tutorial_WorkshopRewardHint = "Tutorial_WorkshopRewardHint",
	Tutorial_WorkshopExchange = "Tutorial_WorkshopExchange",
	Tutorial_WorkshopExchangeSpeedUp = "Tutorial_WorkshopExchangeSpeedUp",
	Tutorial_PlanetToGoal = "Tutorial_PlanetToGoal",
	Tutorial_PlanetToCharacterList = "Tutorial_PlanetToCharacterList",
	Tutorial_PlanetToWorkShop = "Tutorial_PlanetToWorkShop",
	Tutorial_EnterMap = "Tutorial_EnterMap",
}

TutorialConfig[Tutorials.Tutorial_1_1] =
{
	Branch = -1,
	Step = -1,
	Width = 140,
	Height = 140,
	ShowHand = true,
	Node = "Tutorial_Bottom_1",
	Text = "[652B2B]点击小牌子~\n立刻[FF5500]出发探索[-]一下吧。[-]",
	ClosePage = false,
}

TutorialConfig[Tutorials.Tutorial_1_2_0] =
{
	Branch = -1,
	Step = -1,
	Width = 140,
	Height = 100,
	ShowHand = true,
	Node = "Tutorial_Bottom_2",
	Text = "[652B2B]漆漆，我们先侦查一下附近吧~[-]",
	ClosePage = false,
}

TutorialConfig[Tutorials.Tutorial_1_2] =
{
	Branch = -1,
	Step = -1,
	Width = 120,
	Height = 65,
	ShowHand = true,
	ClosePage = false,
}

TutorialConfig[Tutorials.Tutorial_1_3] =
{
	Branch = -1,
	Step = -1,
	Width = 150,
	Height = 150,
	ShowHand = true,
	Node = "Tutorial_Bottom_3",
	Text = "[652B2B]准备出发啦~点上面派[FF5500]呜呜[-]上场喵。[-]",
	ClosePage = false,
}

TutorialConfig[Tutorials.Tutorial_1_5] =
{
	Branch = -1,
	Step = -1,
	Width = 150,
	Height = 150,
	ShowHand = true,
	Node = "Tutorial_Bottom_2",
	Text = "[652B2B]漆漆，快来快来~我们一起去探索喵~[-]",
	--派遣漆漆上场
	ClosePage = false,
}

TutorialConfig[Tutorials.Tutorial_1_7] =
{
	Branch = -1,
	Step = -1,
	Width = 180,
	Height = 80,
	ShowHand = true,
	ClosePage = false,
}

TutorialConfig[Tutorials.Tutorial_1_8] =
{
	Branch = -1,
	Step = -1,
	Width = 150,
	Height = 160,
	ShowHand = true,
	Node = "Tutorial_Bottom_6",
	Text = "[652B2B][FF5500]探索时间[-]能通过携带[FF5500]食物[-]来调节。\n先带1个[FF5500]简单口粮[-]喵~[-]",
	ClosePage = false,
}

TutorialConfig[Tutorials.Tutorial_1_8_1] =
{
	Branch = -1,
	Step = -1,
	Width = 260,
	Height = 90,
	ShowHand = true,
	Node = "Tutorial_Bottom_6",
	Text = "[652B2B]看，这样就可以探索[FF5500]1分30秒[-]啦~[-]",
	ClosePage = false,
}

TutorialConfig[Tutorials.Tutorial_1_9] =
{
	Branch = 1,
	Step = 1,
	Width = 180,
	Height = 80,
	ShowHand = true,
	ClosePage = false,
}

TutorialConfig[Tutorials.Tutorial_1_10] =
{
	Branch = -1,
	Step = -1,
	Width = 280,
	Height = 60,
	ShowHand = true,
	Node = "Tutorial_Top_3",
	Text = "[652B2B]点那里可以加速探索噢。[-]",
	ClosePage = false,
}

TutorialConfig[Tutorials.Tutorial_1_11] =
{
	Branch = -1,
	Step = -1,
	Width = 140,
	Height = 110,
	ShowHand = true,
	Node = "Tutorial_Bottom_3",
	Text = "[652B2B]这次探索直接[FF5500]加速[-]完成吧，反正是免费的喵~[-]",
	ClosePage = true,
}

TutorialConfig[Tutorials.Tutorial_1_12] =
{
	Branch = 1,
	Step = 2,
	Width = 600,
	Height = 900,
	ShowHand = true,
	Node = "Tutorial_Bottom_6",
	Text = "[652B2B]探索很顺利，而且打败了一个敌人，拿到了金币喵~[-]",
	ClosePage = true,
}

TutorialConfig[Tutorials.Tutorial_2_2_1] =
{
	Branch = -1,
	Step = -1,
	Width = 150,
	Height = 60,
	ShowHand = true,
	Node = "Tutorial_Bottom_11",
	Text = "[652B2B]喵！对方看起来很嚣张呢，这时候一定要比它更凶喵！[-]",
	ClosePage = false,
}

TutorialConfig[Tutorials.Tutorial_2_2] =
{
	Branch = -1,
	Step = -1,
	Width = 150,
	Height = 150,
	ShowHand = true,
	Node = "Tutorial_Bottom_10",
	Text = "[652B2B]准备作战了喵~\n前排队员会优先承受攻击，让[FF5500]擅长防御[-]的呜呜先上。[-]",
	ClosePage = false,
}

TutorialConfig[Tutorials.Tutorial_2_4] =
{
	Branch = -1,
	Step = -1,
	Width = 150,
	Height = 150,
	ShowHand = true,
	Node = "Tutorial_Bottom_7",
	Text = "[652B2B]后排适合[FF5500]擅长攻击[-]的队员，派遣漆漆上场。[-]",
	ClosePage = false,
}

TutorialConfig[Tutorials.Tutorial_2_6] =
{
	Branch = 2,
	Step = 1,
	Width = 180,
	Height = 80,
	ShowHand = true,
	ClosePage = true,
}

TutorialConfig[Tutorials.Tutorial_3_1] =
{
	Branch = -1,
	Step = -1,
	Width = 200,
	Height = 300,
	ShowHand = true,
	Node = "Tutorial_Bottom_2",
	Text = "[652B2B]这里是船员中心喵~\n选中队员，[FF5500]戳它一下[-]就能升级喵~[-]",
	ClosePage = false,
}

TutorialConfig[Tutorials.Tutorial_3_2] =
{
	Branch = 3,
	Step = 1,
	Width = 200,
	Height = 80,
	ShowHand = true,
	ClosePage = true,
}

TutorialConfig[Tutorials.Tutorial_4_1] =
{
	Branch = -1,
	Step = -1,
	Width = 300,
	Height = 200,
	OffsetX = 0,
	OffsetY = 86,
	ShowHand = true,
	Node = "Tutorial_Bottom_3",
	Text = "[652B2B]漆漆你看，这里有家[FF5500]道具店[-]刚开张，似乎正在[ff5500]招工[-]呢。[-]",
	ClosePage = false,
}

TutorialConfig[Tutorials.Tutorial_4_1_2] =
{
	Branch = -1,
	Step = -1,
	Width = 180,
	Height = 76,
	ShowHand = true,
	ClosePage = false,
}


TutorialConfig[Tutorials.Tutorial_4_2] =
{
	Branch = -1,
	Step = -1,
	MaskIcon = "mask_tutorial_square",
	Width = 150,
	Height = 150,
	ShowHand = true,
	Node = "Tutorial_Bottom_2",
	Text = "[652B2B]道具店要求[FF5500]技巧[-]和[FF5500]亲和[-]，让[FF5500]居民NPC[-]试试看喵~[-]",
	ClosePage = false,
}

TutorialConfig[Tutorials.Tutorial_4_3] =
{
	Branch = -1,
	Step = -1,
	Width = 140,
	Height = 140,
	ShowHand = true,
	Node = "Tutorial_Bottom_1",
	Text = "[652B2B]完全符合要求喵~\n虽然评价是[FF5500]F-[-]，不过队员[FF5500]升级后[-]就会好起来的。[-]",
	ClosePage = false,
}

TutorialConfig[Tutorials.Tutorial_4_4] =
{
	Branch = 4,
	Step = 1,
	Width = 180,
	Height = 80,
	ShowHand = true,
	ClosePage = true,
}

TutorialConfig[Tutorials.Tutorial_5_1] =
{
	Branch = -1,
	Step = -1,
	Width = 100,
	Height = 100,
	ShowHand = true,
	ClosePage = false,
}

TutorialConfig[Tutorials.Tutorial_5_2] =
{
	Branch = -1,
	Step = -1,
	Width = 160,
	Height = 150,
	ShowHand = true,
	Node = "Tutorial_Bottom_2",
	Text = "[652B2B]这里是委托板，会显示收到的请求。\n订单上会写[FF5500]标题[-]和[FF5500]报酬物[-]喵~[-]",
	ClosePage = false,
}

TutorialConfig[Tutorials.Tutorial_5_3] =
{
	Branch = -1,
	Step = -1,
	Width = 360,
	Height = 200,
	ShowHand = true,
	Node = "Tutorial_Top_3",
	Text = "[652B2B]点击订单查看[FF7300]详情[-]。\n觉得要求无理的话，可以[19A4B4]删除订单[-]，2分钟后会[19A4B4]再次刷新[-]的。[-]",
	ClosePage = false,
}

TutorialConfig[Tutorials.Tutorial_5_6] =
{
	Branch = 5,
	Step = 1,
	Width = 110,
	Height = 60,
	ShowHand = true,
	Node = "Tutorial_Top_3",
	Text = "[652B2B]这次对方很着急的样子，似乎还给了额外报酬，先帮他一下喵~[-]",
	ClosePage = true,
}

TutorialConfig[Tutorials.Tutorial_6_1] =
{
	Branch = -1,
	Step = -1,
	Width = 100,
	Height = 100,
	ShowHand = true,
	Node = "Tutorial_Bottom_2",
	Text = "[652B2B]队员都有自己专属的[FF5500]玩具装备[-]，升级后属性会[FF5500]大幅提升[-]喵~[-]",
	ClosePage = false,
}

TutorialConfig[Tutorials.Tutorial_6_2] =
{
	Branch = -1,
	Step = -1,
	Width = 230,
	Height = 130,
	ShowHand = true,
	Node = "Tutorial_Bottom_6",
	Text = "[652B2B]检查所需清单，物资满足喵~[-]",
	ClosePage = false,
}

TutorialConfig[Tutorials.Tutorial_6_3] =
{
	Branch = 6,
	Step = 1,
	Width = 200,
	Height = 80,
	ShowHand = true,
	ClosePage = true,
}

TutorialConfig[Tutorials.Tutorial_7_1] =
{
	Branch = -1,
	Step = -1,
	Width = 300,
	Height = 200,
	OffsetX = 0,
	OffsetY = 86,
	ShowHand = true,
	ClosePage = false,
}

TutorialConfig[Tutorials.Tutorial_7_1_2] =
{
	Branch = -1,
	Step = -1,
	Width = 180,
	Height = 76,
	ShowHand = true,
	ClosePage = false,
}

TutorialConfig[Tutorials.Tutorial_7_2] =
{
	Branch = -1,
	Step = -1,
	Width = 100,
	Height = 100,
	ShowHand = true,
	Node = "Tutorial_Bottom_8",
	Text = "[652B2B]老板说升级的投资回报是[FF5500]95,000%[-]。\n不过这种在蓝星一般叫“庞氏骗局”...[-]",
	ClosePage = false,
}

TutorialConfig[Tutorials.Tutorial_7_3] =
{
	Branch = -1,
	Step = -1,
	Width = 440,
	Height = 320,
	ShowHand = true,
	Node = "Tutorial_Bottom_6",
	Text = "[652B2B]升级后，会解锁[FF5500]新的报酬[-]，打工效果也将[FF5500]全面提升[-]！[-]",
	ClosePage = false,
}

TutorialConfig[Tutorials.Tutorial_7_4] =
{
	Branch = 7,
	Step = 1,
	Width = 160,
	Height = 60,
	ShowHand = true,
	ClosePage = true,
}

TutorialConfig[Tutorials.Tutorial_8_1] =
{
	Branch = -1,
	Step = -1,
	Width = 460,
	Height = 60,
	ShowHand = true,
	Node = "Tutorial_Bottom_2",
	Text = "[652B2B]完成任务获得的代币可以在这里使用喵~[-]",
	ClosePage = false,
}

TutorialConfig[Tutorials.Tutorial_8_2] =
{
	Branch = 8,
	Step = 1,
	Width = 200,
	Height = 260,
	ShowHand = true,
	Node = "Tutorial_Bottom_1",
	Text = "[652B2B]抽一发试试手气吧~[-]",
	ClosePage = true,
}

TutorialConfig[Tutorials.Tutorial_9_1] =
{
	Branch = -1,
	Step = -1,
	Width = 130,
	Height = 130,
	ShowHand = true,
	Node = "Tutorial_Bottom_1",
	Text = "[652B2B]可以合成简单口粮了喵，赶紧试一下~[-]",
	ClosePage = false,
}

TutorialConfig[Tutorials.Tutorial_9_2] =
{
	Branch = -1,
	Step = -1,
	Width = 60,
	Height = 60,
	ShowHand = true,
	Node = "Tutorial_Bottom_1",
	Text = "[652B2B]原料足够的话，可以一次性合成多个道具喵~[-]",
	ClosePage = false,
}

TutorialConfig[Tutorials.Tutorial_9_3] =
{
	Branch = 9,
	Step = 1,
	Width = 180,
	Height = 70,
	ShowHand = true,
	ClosePage = true,
}

TutorialConfig[Tutorials.Tutorial_10_1] =
{
	Branch = -1,
	Step = -1,
	Width = 130,
	Height = 130,
	ShowHand = true,
	Node = "Tutorial_Bottom_1",
	Text = "[652B2B]出现了必须使用特定元素才能击败的敌人！[-]",
	ClosePage = false,
}

TutorialConfig[Tutorials.Tutorial_10_2] =
{
	Branch = -1,
	Step = -1,
	Width = 130,
	Height = 130,
	ShowHand = true,
	Node = "Tutorial_Bottom_1",
	Text = "[652B2B]如果要打败祭祀石的话，队伍中必须有暗元素的队员！[-]",
	ClosePage = false,
}

TutorialConfig[Tutorials.Tutorial_10_3] =
{
	Branch = -1,
	Step = -1,
	Width = 90,
	Height = 60,
	ShowHand = true,
	Node = "Tutorial_Bottom_1",
	Text = "[652B2B]对了~队伍中携带对应元素的宠物也可以噢~[-]",
	ClosePage = true,
}

TutorialConfig[Tutorials.Tutorial_ExploreGoalNotify] =
{
	--探索任务完成后跳转使用，挑战任务完成后挑战没有Node及Text模块
	Branch = -1,
	Step = -1,
	Width = 375,
	Height = 90,
	ShowHand = true,
	Node = "Tutorial_Bottom_2",
	Text = "[652B2B]完成任务，总部发来奖励了喵~[-]",
	ClosePage = true,
}

TutorialConfig[Tutorials.Tutorial_ExploreGoalReward] =
{
	Branch = -1,
	Step = -1,
	Width = 150,
	Height = 50,
	ShowHand = true,
	ClosePage = true,
}

TutorialConfig[Tutorials.Tutorial_ChallengeGoalGo] =
{
	Branch = -1,
	Step = -1,
	Width = 150,
	Height = 50,
	ShowHand = true,
	Node = "Tutorial_Bottom_9",
	Text = "[652B2B]咦？刚刚的怪物约我们村口[FF5500]挑战[-]？感觉是场恶战喵！[-]",
	ClosePage = false,
}

TutorialConfig[Tutorials.Tutorial_ChallengeGoalReward] =
{
	Branch = -1,
	Step = -1,
	Width = 150,
	Height = 50,
	ShowHand = true,
	ClosePage = true,
}

TutorialConfig[Tutorials.Tutorial_EquipmentUpgradeGoalGo] =
{
	Branch = -1,
	Step = -1,
	Width = 150,
	Height = 50,
	ShowHand = true,
	Node = "Tutorial_Bottom_6",
	Text = "[652B2B]刚刚在委托中收到了[FF5500]零件[-]，可以[FF5500]强化装备[-]了喵~[-]",
	ClosePage = false,
}

TutorialConfig[Tutorials.Tutorial_WorkShopUpgradeGoalGo] =
{
	Branch = -1,
	Step = -1,
	Width = 150,
	Height = 50,
	ShowHand = true,
	Node = "Tutorial_Bottom_3",
	Text = "[652B2B]接到了升级道具店的任务，去看一下喵~[-]",
	ClosePage = false,
}

TutorialConfig[Tutorials.Tutorial_CraftGoalGo] =
{
	Branch = -1,
	Step = -1,
	Width = 150,
	Height = 50,
	ShowHand = true,
	Node = "Tutorial_Bottom_1",
	Text = "[652B2B]收到了简单口粮的[FF5500]合成配方[-]，赶紧去[FF5500]实验室[-]看看！[-]",
	ClosePage = false,
}

TutorialConfig[Tutorials.Tutorial_SummonGoalGo] =
{
	Branch = -1,
	Step = -1,
	Width = 150,
	Height = 50,
	ShowHand = true,
	Node = "Tutorial_Bottom_3",
	Text = "[652B2B]似乎可以在那里[FF5500]招募到更多队员[-]呢，赶紧去看一下喵~[-]",
	ClosePage = false,
}

TutorialConfig[Tutorials.Tutorial_WorkshopRewardHint] =
{
	Branch = -1,
	Step = -1,
	Width = 120,
	Height = 60,
	ShowHand = true,
	Node = "Tutorial_Bottom_1",
	Text = "[652B2B]居民先生已经在打工了，[FF5500]时间到了[-]老板就会支付报酬喵。[-]",
	ClosePage = false,
}

TutorialConfig[Tutorials.Tutorial_WorkshopExchange] =
{
	Branch = -1,
	Step = -1,
	Width = 180,
	Height = 80,
	ShowHand = true,
	FingerX = 103,
	FingerY = -205,
	Node = "Tutorial_Bottom_1",
	Text = "[652B2B]不过要[FF5500]立即获得[-]报酬的话，也可以使用[FF5500]加班[-]功能噢~[-]",
	ClosePage = false,
}

TutorialConfig[Tutorials.Tutorial_WorkshopExchangeSpeedUp] =
{
	Branch = -1,
	Step = -1,
	Width = 180,
	Height = 80,
	ShowHand = true,
	Node = "Tutorial_Bottom_1",
	Text = "[652B2B]喵，第一次加班是[FF5500]免费[-]的？\n那就辛苦居民先生了喵~[-]",
	ClosePage = true,
}

TutorialConfig[Tutorials.Tutorial_PlanetToGoal] =
{
	Branch = -1,
	Step = -1,
	Width = 100,
	Height = 100,
	ShowHand = true,
	Node = "Tutorial_Top_2",
	Text = "[652B2B]任务板有情况！[-]",
	ClosePage = false,
}

TutorialConfig[Tutorials.Tutorial_PlanetToCharacterList] =
{
	Branch = -1,
	Step = -1,
	Width = 100,
	Height = 100,
	ShowHand = true,
	ClosePage = false,
	--前往角色升级
}

TutorialConfig[Tutorials.Tutorial_PlanetToWorkShop] =
{
	Branch = -1,
	Step = -1,
	Width = 100,
	Height = 100,
	ShowHand = true,
	Node = "Tutorial_Top_1",
	Text = "[652B2B]道具店开张了，赶紧去看一下~[-]",
	ClosePage = false,
}

TutorialConfig[Tutorials.Tutorial_EnterMap] =
{
	Branch = -1,
	Step = -1,
	Width = 140,
	Height = 140,
	ShowHand = true,
	Node = "Tutorial_Bottom_1",
	Text = "[652B2B]去这里看看[-]",
	--有片树林，侦查一下！
	ClosePage = false,
}

TutorialConfig[Tutorials.Tutorial_Tourist_1] =
{
	Branch = -1,
	Step = -1,
	Width = 100,
	Height = 100,
	ShowHand = true,
	Node = "Tutorial_Bottom_2",
	Text = "[652B2B]报告！一列宇宙巴士正停在星球附近~[-]",
	ClosePage = false,
}

TutorialConfig[Tutorials.Tutorial_Tourist_2] =
{
	Branch = -1,
	Step = -1,
	Width = 480,
	Height = 120,
	ShowHand = true,
	Node = "Tutorial_Bottom_1",
	Text = "[652B2B]是来自外星的观光团~~似乎有想看的宠物表演呢~[-]",
	ClosePage = false,
}

TutorialConfig[Tutorials.Tutorial_Tourist_3] =
{
	Branch = -1,
	Step = -1,
	Width = 600,
	Height = 420,
	ShowHand = true,
	Node = "Tutorial_Bottom_1",
	Text = "[652B2B]如果飞船上有合适的宠物，就展出一下吧~可能会有不错的礼物噢~[-]",
	ClosePage = false,
}

TutorialConfig[Tutorials.Tutorial_Tourist_4] =
{
	Branch = -1,
	Step = -1,
	Width = 200,
	Height = 40,
	ShowHand = true,
	Node = "Tutorial_Bottom_1",
	Text = "[652B2B]客人们过一阵子会离开，不过还会有新的客人来的，所以放心地尝试吧~~[-]",
	ClosePage = false,
}

TutorialConfig[Tutorials.Tutorial_Tourist_5] =
{
	Branch = -1,
	Step = -1,
	Width = 80,
	Height = 80,
	ShowHand = true,
	Node = "Tutorial_Bottom_1",
	Text = "[652B2B]不过实在摸不着头脑的话，也可以看看客人们过去的经历，作为参考噢~~[-]",
	ClosePage = true,
}