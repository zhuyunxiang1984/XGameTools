
EquipmentConfig[EquipmentID.Id483] =
{
	Character = 223041,
	Rarity = 4,
	NeedChallenge = 145193,
	UpgradeId = 930015,
	LevelList = {
		{
			Level = 1,
			Info = 920620,
			Ability = {
				{
					Value = 200002,
					Num = 108,
				},
			},
		},
		{
			Level = 2,
			Info = 920620,
			Ability = {
				{
					Value = 200002,
					Num = 180,
				},
			},
		},
		{
			Level = 3,
			Info = 920620,
			Ability = {
				{
					Value = 200002,
					Num = 252,
				},
			},
		},
		{
			Level = 4,
			Info = 920620,
			Ability = {
				{
					Value = 200002,
					Num = 324,
				},
			},
		},
		{
			Level = 5,
			Info = 920620,
			Ability = {
				{
					Value = 200002,
					Num = 396,
				},
				{
					Value = 200004,
					Num = 25,
				},
			},
		},
		{
			Level = 6,
			Info = 920620,
			Ability = {
				{
					Value = 200002,
					Num = 468,
				},
				{
					Value = 200004,
					Num = 30,
				},
			},
		},
		{
			Level = 7,
			Info = 920620,
			Ability = {
				{
					Value = 200002,
					Num = 540,
				},
				{
					Value = 200004,
					Num = 35,
				},
			},
		},
		{
			Level = 8,
			Info = 920620,
			Ability = {
				{
					Value = 200002,
					Num = 612,
				},
				{
					Value = 200004,
					Num = 40,
				},
			},
			SkillList = {
				{
					Id = 100606,
					Value = -25,
				},
			},
		},
		{
			Level = 9,
			Info = 920620,
			Ability = {
				{
					Value = 200002,
					Num = 684,
				},
				{
					Value = 200004,
					Num = 45,
				},
			},
			SkillList = {
				{
					Id = 100606,
					Value = -25,
				},
			},
		},
		{
			Level = 10,
			Info = 920620,
			Ability = {
				{
					Value = 200002,
					Num = 756,
				},
				{
					Value = 200004,
					Num = 50,
				},
			},
			SkillList = {
				{
					Id = 100606,
					Value = -25,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id484] =
{
	Character = 223042,
	Rarity = 4,
	UpgradeId = 930033,
	LevelList = {
		{
			Level = 1,
			Info = 920621,
			Ability = {
				{
					Value = 200001,
					Num = 69,
				},
				{
					Value = 200006,
					Num = 12,
				},
			},
		},
		{
			Level = 2,
			Info = 920621,
			Ability = {
				{
					Value = 200001,
					Num = 138,
				},
				{
					Value = 200006,
					Num = 24,
				},
			},
		},
		{
			Level = 3,
			Info = 920621,
			Ability = {
				{
					Value = 200001,
					Num = 207,
				},
				{
					Value = 200006,
					Num = 36,
				},
			},
		},
		{
			Level = 4,
			Info = 920621,
			Ability = {
				{
					Value = 200001,
					Num = 276,
				},
				{
					Value = 200006,
					Num = 48,
				},
			},
		},
		{
			Level = 5,
			Info = 920621,
			Ability = {
				{
					Value = 200001,
					Num = 345,
				},
				{
					Value = 200006,
					Num = 60,
				},
			},
		},
		{
			Level = 6,
			Info = 920621,
			Ability = {
				{
					Value = 200001,
					Num = 414,
				},
				{
					Value = 200006,
					Num = 72,
				},
			},
		},
		{
			Level = 7,
			Info = 920621,
			Ability = {
				{
					Value = 200001,
					Num = 483,
				},
				{
					Value = 200006,
					Num = 84,
				},
			},
		},
		{
			Level = 8,
			Info = 920621,
			Ability = {
				{
					Value = 200001,
					Num = 552,
				},
				{
					Value = 200006,
					Num = 96,
				},
			},
			SkillList = {
				{
					Id = 100779,
					Value = 125,
				},
			},
		},
		{
			Level = 9,
			Info = 920621,
			Ability = {
				{
					Value = 200001,
					Num = 621,
				},
				{
					Value = 200006,
					Num = 108,
				},
			},
			SkillList = {
				{
					Id = 100779,
					Value = 125,
				},
			},
		},
		{
			Level = 10,
			Info = 920621,
			Ability = {
				{
					Value = 200001,
					Num = 690,
				},
				{
					Value = 200006,
					Num = 120,
				},
			},
			SkillList = {
				{
					Id = 100779,
					Value = 125,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id485] =
{
	Character = 223042,
	Rarity = 4,
	UpgradeId = 930014,
	LevelList = {
		{
			Level = 1,
			Info = 920622,
			Ability = {
				{
					Value = 200002,
					Num = 57,
				},
				{
					Value = 200008,
					Num = 9,
				},
			},
		},
		{
			Level = 2,
			Info = 920622,
			Ability = {
				{
					Value = 200002,
					Num = 114,
				},
				{
					Value = 200008,
					Num = 18,
				},
			},
		},
		{
			Level = 3,
			Info = 920622,
			Ability = {
				{
					Value = 200002,
					Num = 171,
				},
				{
					Value = 200008,
					Num = 27,
				},
			},
		},
		{
			Level = 4,
			Info = 920622,
			Ability = {
				{
					Value = 200002,
					Num = 228,
				},
				{
					Value = 200008,
					Num = 36,
				},
			},
		},
		{
			Level = 5,
			Info = 920622,
			Ability = {
				{
					Value = 200002,
					Num = 285,
				},
				{
					Value = 200008,
					Num = 45,
				},
			},
		},
		{
			Level = 6,
			Info = 920622,
			Ability = {
				{
					Value = 200002,
					Num = 342,
				},
				{
					Value = 200008,
					Num = 54,
				},
			},
		},
		{
			Level = 7,
			Info = 920622,
			Ability = {
				{
					Value = 200002,
					Num = 399,
				},
				{
					Value = 200008,
					Num = 63,
				},
			},
		},
		{
			Level = 8,
			Info = 920622,
			Ability = {
				{
					Value = 200002,
					Num = 456,
				},
				{
					Value = 200008,
					Num = 72,
				},
			},
			SkillList = {
				{
					Id = 101722,
					Value = 378,
				},
			},
		},
		{
			Level = 9,
			Info = 920622,
			Ability = {
				{
					Value = 200002,
					Num = 513,
				},
				{
					Value = 200008,
					Num = 81,
				},
			},
			SkillList = {
				{
					Id = 101722,
					Value = 378,
				},
			},
		},
		{
			Level = 10,
			Info = 920622,
			Ability = {
				{
					Value = 200002,
					Num = 570,
				},
				{
					Value = 200008,
					Num = 90,
				},
			},
			SkillList = {
				{
					Id = 101722,
					Value = 378,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id486] =
{
	Character = 223042,
	Rarity = 4,
	NeedChallenge = 145194,
	UpgradeId = 930015,
	LevelList = {
		{
			Level = 1,
			Info = 920623,
			Ability = {
				{
					Value = 200002,
					Num = 114,
				},
			},
		},
		{
			Level = 2,
			Info = 920623,
			Ability = {
				{
					Value = 200002,
					Num = 190,
				},
			},
		},
		{
			Level = 3,
			Info = 920623,
			Ability = {
				{
					Value = 200002,
					Num = 266,
				},
			},
		},
		{
			Level = 4,
			Info = 920623,
			Ability = {
				{
					Value = 200002,
					Num = 342,
				},
			},
		},
		{
			Level = 5,
			Info = 920623,
			Ability = {
				{
					Value = 200002,
					Num = 418,
				},
				{
					Value = 200004,
					Num = 25,
				},
			},
		},
		{
			Level = 6,
			Info = 920623,
			Ability = {
				{
					Value = 200002,
					Num = 494,
				},
				{
					Value = 200004,
					Num = 30,
				},
			},
		},
		{
			Level = 7,
			Info = 920623,
			Ability = {
				{
					Value = 200002,
					Num = 570,
				},
				{
					Value = 200004,
					Num = 35,
				},
			},
		},
		{
			Level = 8,
			Info = 920623,
			Ability = {
				{
					Value = 200002,
					Num = 646,
				},
				{
					Value = 200004,
					Num = 40,
				},
			},
			SkillList = {
				{
					Id = 100605,
					Value = 36,
				},
			},
		},
		{
			Level = 9,
			Info = 920623,
			Ability = {
				{
					Value = 200002,
					Num = 722,
				},
				{
					Value = 200004,
					Num = 45,
				},
			},
			SkillList = {
				{
					Id = 100605,
					Value = 36,
				},
			},
		},
		{
			Level = 10,
			Info = 920623,
			Ability = {
				{
					Value = 200002,
					Num = 798,
				},
				{
					Value = 200004,
					Num = 50,
				},
			},
			SkillList = {
				{
					Id = 100605,
					Value = 36,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id487] =
{
	Character = 223043,
	Rarity = 4,
	UpgradeId = 930033,
	LevelList = {
		{
			Level = 1,
			Info = 920624,
			Ability = {
				{
					Value = 200001,
					Num = 69,
				},
				{
					Value = 200008,
					Num = 12,
				},
			},
		},
		{
			Level = 2,
			Info = 920624,
			Ability = {
				{
					Value = 200001,
					Num = 138,
				},
				{
					Value = 200008,
					Num = 24,
				},
			},
		},
		{
			Level = 3,
			Info = 920624,
			Ability = {
				{
					Value = 200001,
					Num = 207,
				},
				{
					Value = 200008,
					Num = 36,
				},
			},
		},
		{
			Level = 4,
			Info = 920624,
			Ability = {
				{
					Value = 200001,
					Num = 276,
				},
				{
					Value = 200008,
					Num = 48,
				},
			},
		},
		{
			Level = 5,
			Info = 920624,
			Ability = {
				{
					Value = 200001,
					Num = 345,
				},
				{
					Value = 200008,
					Num = 60,
				},
			},
		},
		{
			Level = 6,
			Info = 920624,
			Ability = {
				{
					Value = 200001,
					Num = 414,
				},
				{
					Value = 200008,
					Num = 72,
				},
			},
		},
		{
			Level = 7,
			Info = 920624,
			Ability = {
				{
					Value = 200001,
					Num = 483,
				},
				{
					Value = 200008,
					Num = 84,
				},
			},
		},
		{
			Level = 8,
			Info = 920624,
			Ability = {
				{
					Value = 200001,
					Num = 552,
				},
				{
					Value = 200008,
					Num = 96,
				},
			},
			SkillList = {
				{
					Id = 101706,
					Value = 140,
				},
			},
		},
		{
			Level = 9,
			Info = 920624,
			Ability = {
				{
					Value = 200001,
					Num = 621,
				},
				{
					Value = 200008,
					Num = 108,
				},
			},
			SkillList = {
				{
					Id = 101706,
					Value = 155,
				},
			},
		},
		{
			Level = 10,
			Info = 920624,
			Ability = {
				{
					Value = 200001,
					Num = 690,
				},
				{
					Value = 200008,
					Num = 120,
				},
			},
			SkillList = {
				{
					Id = 101706,
					Value = 170,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id488] =
{
	Character = 223043,
	Rarity = 4,
	UpgradeId = 930014,
	LevelList = {
		{
			Level = 1,
			Info = 920625,
			Ability = {
				{
					Value = 200002,
					Num = 57,
				},
				{
					Value = 200005,
					Num = 9,
				},
			},
		},
		{
			Level = 2,
			Info = 920625,
			Ability = {
				{
					Value = 200002,
					Num = 114,
				},
				{
					Value = 200005,
					Num = 18,
				},
			},
		},
		{
			Level = 3,
			Info = 920625,
			Ability = {
				{
					Value = 200002,
					Num = 171,
				},
				{
					Value = 200005,
					Num = 27,
				},
			},
		},
		{
			Level = 4,
			Info = 920625,
			Ability = {
				{
					Value = 200002,
					Num = 228,
				},
				{
					Value = 200005,
					Num = 36,
				},
			},
		},
		{
			Level = 5,
			Info = 920625,
			Ability = {
				{
					Value = 200002,
					Num = 285,
				},
				{
					Value = 200005,
					Num = 45,
				},
			},
		},
		{
			Level = 6,
			Info = 920625,
			Ability = {
				{
					Value = 200002,
					Num = 342,
				},
				{
					Value = 200005,
					Num = 54,
				},
			},
		},
		{
			Level = 7,
			Info = 920625,
			Ability = {
				{
					Value = 200002,
					Num = 399,
				},
				{
					Value = 200005,
					Num = 63,
				},
			},
		},
		{
			Level = 8,
			Info = 920625,
			Ability = {
				{
					Value = 200002,
					Num = 456,
				},
				{
					Value = 200005,
					Num = 72,
				},
			},
			SkillList = {
				{
					Id = 101501,
					Value = -4,
				},
			},
		},
		{
			Level = 9,
			Info = 920625,
			Ability = {
				{
					Value = 200002,
					Num = 513,
				},
				{
					Value = 200005,
					Num = 81,
				},
			},
			SkillList = {
				{
					Id = 101501,
					Value = -4,
				},
			},
		},
		{
			Level = 10,
			Info = 920625,
			Ability = {
				{
					Value = 200002,
					Num = 570,
				},
				{
					Value = 200005,
					Num = 90,
				},
			},
			SkillList = {
				{
					Id = 101501,
					Value = -4,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id489] =
{
	Character = 223043,
	Rarity = 4,
	NeedChallenge = 145195,
	UpgradeId = 930015,
	LevelList = {
		{
			Level = 1,
			Info = 920626,
			Ability = {
				{
					Value = 200002,
					Num = 114,
				},
			},
		},
		{
			Level = 2,
			Info = 920626,
			Ability = {
				{
					Value = 200002,
					Num = 190,
				},
			},
		},
		{
			Level = 3,
			Info = 920626,
			Ability = {
				{
					Value = 200002,
					Num = 266,
				},
			},
		},
		{
			Level = 4,
			Info = 920626,
			Ability = {
				{
					Value = 200002,
					Num = 342,
				},
			},
		},
		{
			Level = 5,
			Info = 920626,
			Ability = {
				{
					Value = 200002,
					Num = 418,
				},
				{
					Value = 200004,
					Num = 25,
				},
			},
		},
		{
			Level = 6,
			Info = 920626,
			Ability = {
				{
					Value = 200002,
					Num = 494,
				},
				{
					Value = 200004,
					Num = 30,
				},
			},
		},
		{
			Level = 7,
			Info = 920626,
			Ability = {
				{
					Value = 200002,
					Num = 570,
				},
				{
					Value = 200004,
					Num = 35,
				},
			},
		},
		{
			Level = 8,
			Info = 920626,
			Ability = {
				{
					Value = 200002,
					Num = 646,
				},
				{
					Value = 200004,
					Num = 40,
				},
			},
			SkillList = {
				{
					Id = 101525,
					Value = -12,
				},
			},
		},
		{
			Level = 9,
			Info = 920626,
			Ability = {
				{
					Value = 200002,
					Num = 722,
				},
				{
					Value = 200004,
					Num = 45,
				},
			},
			SkillList = {
				{
					Id = 101525,
					Value = -12,
				},
			},
		},
		{
			Level = 10,
			Info = 920626,
			Ability = {
				{
					Value = 200002,
					Num = 798,
				},
				{
					Value = 200004,
					Num = 50,
				},
			},
			SkillList = {
				{
					Id = 101525,
					Value = -12,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id490] =
{
	Character = 223044,
	Rarity = 4,
	UpgradeId = 930033,
	LevelList = {
		{
			Level = 1,
			Info = 920627,
			Ability = {
				{
					Value = 200001,
					Num = 75,
				},
				{
					Value = 200005,
					Num = 12,
				},
			},
		},
		{
			Level = 2,
			Info = 920627,
			Ability = {
				{
					Value = 200001,
					Num = 150,
				},
				{
					Value = 200005,
					Num = 24,
				},
			},
		},
		{
			Level = 3,
			Info = 920627,
			Ability = {
				{
					Value = 200001,
					Num = 225,
				},
				{
					Value = 200005,
					Num = 36,
				},
			},
		},
		{
			Level = 4,
			Info = 920627,
			Ability = {
				{
					Value = 200001,
					Num = 300,
				},
				{
					Value = 200005,
					Num = 48,
				},
			},
		},
		{
			Level = 5,
			Info = 920627,
			Ability = {
				{
					Value = 200001,
					Num = 375,
				},
				{
					Value = 200005,
					Num = 60,
				},
			},
		},
		{
			Level = 6,
			Info = 920627,
			Ability = {
				{
					Value = 200001,
					Num = 450,
				},
				{
					Value = 200005,
					Num = 72,
				},
			},
		},
		{
			Level = 7,
			Info = 920627,
			Ability = {
				{
					Value = 200001,
					Num = 525,
				},
				{
					Value = 200005,
					Num = 84,
				},
			},
		},
		{
			Level = 8,
			Info = 920627,
			Ability = {
				{
					Value = 200001,
					Num = 600,
				},
				{
					Value = 200005,
					Num = 96,
				},
			},
			SkillList = {
				{
					Id = 100661,
					Value = 13,
				},
			},
		},
		{
			Level = 9,
			Info = 920627,
			Ability = {
				{
					Value = 200001,
					Num = 675,
				},
				{
					Value = 200005,
					Num = 108,
				},
			},
			SkillList = {
				{
					Id = 100661,
					Value = 13,
				},
			},
		},
		{
			Level = 10,
			Info = 920627,
			Ability = {
				{
					Value = 200001,
					Num = 750,
				},
				{
					Value = 200005,
					Num = 120,
				},
			},
			SkillList = {
				{
					Id = 100661,
					Value = 13,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id491] =
{
	Character = 223044,
	Rarity = 4,
	UpgradeId = 930034,
	LevelList = {
		{
			Level = 1,
			Info = 920628,
			Ability = {
				{
					Value = 200001,
					Num = 75,
				},
				{
					Value = 200006,
					Num = 9,
				},
			},
		},
		{
			Level = 2,
			Info = 920628,
			Ability = {
				{
					Value = 200001,
					Num = 150,
				},
				{
					Value = 200006,
					Num = 18,
				},
			},
		},
		{
			Level = 3,
			Info = 920628,
			Ability = {
				{
					Value = 200001,
					Num = 225,
				},
				{
					Value = 200006,
					Num = 27,
				},
			},
		},
		{
			Level = 4,
			Info = 920628,
			Ability = {
				{
					Value = 200001,
					Num = 300,
				},
				{
					Value = 200006,
					Num = 36,
				},
			},
		},
		{
			Level = 5,
			Info = 920628,
			Ability = {
				{
					Value = 200001,
					Num = 375,
				},
				{
					Value = 200006,
					Num = 45,
				},
			},
		},
		{
			Level = 6,
			Info = 920628,
			Ability = {
				{
					Value = 200001,
					Num = 450,
				},
				{
					Value = 200006,
					Num = 54,
				},
			},
		},
		{
			Level = 7,
			Info = 920628,
			Ability = {
				{
					Value = 200001,
					Num = 525,
				},
				{
					Value = 200006,
					Num = 63,
				},
			},
		},
		{
			Level = 8,
			Info = 920628,
			Ability = {
				{
					Value = 200001,
					Num = 600,
				},
				{
					Value = 200006,
					Num = 72,
				},
			},
			SkillList = {
				{
					Id = 100606,
					Value = -25,
				},
			},
		},
		{
			Level = 9,
			Info = 920628,
			Ability = {
				{
					Value = 200001,
					Num = 675,
				},
				{
					Value = 200006,
					Num = 81,
				},
			},
			SkillList = {
				{
					Id = 100606,
					Value = -25,
				},
			},
		},
		{
			Level = 10,
			Info = 920628,
			Ability = {
				{
					Value = 200001,
					Num = 750,
				},
				{
					Value = 200006,
					Num = 90,
				},
			},
			SkillList = {
				{
					Id = 100606,
					Value = -25,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id492] =
{
	Character = 223044,
	Rarity = 4,
	NeedChallenge = 145196,
	UpgradeId = 930015,
	LevelList = {
		{
			Level = 1,
			Info = 920629,
			Ability = {
				{
					Value = 200002,
					Num = 108,
				},
			},
		},
		{
			Level = 2,
			Info = 920629,
			Ability = {
				{
					Value = 200002,
					Num = 180,
				},
			},
		},
		{
			Level = 3,
			Info = 920629,
			Ability = {
				{
					Value = 200002,
					Num = 252,
				},
			},
		},
		{
			Level = 4,
			Info = 920629,
			Ability = {
				{
					Value = 200002,
					Num = 324,
				},
			},
		},
		{
			Level = 5,
			Info = 920629,
			Ability = {
				{
					Value = 200002,
					Num = 396,
				},
				{
					Value = 200004,
					Num = 25,
				},
			},
		},
		{
			Level = 6,
			Info = 920629,
			Ability = {
				{
					Value = 200002,
					Num = 468,
				},
				{
					Value = 200004,
					Num = 30,
				},
			},
		},
		{
			Level = 7,
			Info = 920629,
			Ability = {
				{
					Value = 200002,
					Num = 540,
				},
				{
					Value = 200004,
					Num = 35,
				},
			},
		},
		{
			Level = 8,
			Info = 920629,
			Ability = {
				{
					Value = 200002,
					Num = 612,
				},
				{
					Value = 200004,
					Num = 40,
				},
			},
			SkillList = {
				{
					Id = 101759,
					Value = 48,
				},
			},
		},
		{
			Level = 9,
			Info = 920629,
			Ability = {
				{
					Value = 200002,
					Num = 684,
				},
				{
					Value = 200004,
					Num = 45,
				},
			},
			SkillList = {
				{
					Id = 101759,
					Value = 48,
				},
			},
		},
		{
			Level = 10,
			Info = 920629,
			Ability = {
				{
					Value = 200002,
					Num = 756,
				},
				{
					Value = 200004,
					Num = 50,
				},
			},
			SkillList = {
				{
					Id = 101759,
					Value = 48,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id493] =
{
	Character = 223045,
	Rarity = 4,
	UpgradeId = 930033,
	LevelList = {
		{
			Level = 1,
			Info = 920630,
			Ability = {
				{
					Value = 200001,
					Num = 69,
				},
				{
					Value = 200008,
					Num = 21,
				},
			},
		},
		{
			Level = 2,
			Info = 920630,
			Ability = {
				{
					Value = 200001,
					Num = 138,
				},
				{
					Value = 200008,
					Num = 42,
				},
			},
		},
		{
			Level = 3,
			Info = 920630,
			Ability = {
				{
					Value = 200001,
					Num = 207,
				},
				{
					Value = 200008,
					Num = 63,
				},
			},
		},
		{
			Level = 4,
			Info = 920630,
			Ability = {
				{
					Value = 200001,
					Num = 276,
				},
				{
					Value = 200008,
					Num = 84,
				},
			},
		},
		{
			Level = 5,
			Info = 920630,
			Ability = {
				{
					Value = 200001,
					Num = 345,
				},
				{
					Value = 200008,
					Num = 105,
				},
			},
		},
		{
			Level = 6,
			Info = 920630,
			Ability = {
				{
					Value = 200001,
					Num = 414,
				},
				{
					Value = 200008,
					Num = 126,
				},
			},
		},
		{
			Level = 7,
			Info = 920630,
			Ability = {
				{
					Value = 200001,
					Num = 483,
				},
				{
					Value = 200008,
					Num = 147,
				},
			},
		},
		{
			Level = 8,
			Info = 920630,
			Ability = {
				{
					Value = 200001,
					Num = 552,
				},
				{
					Value = 200008,
					Num = 168,
				},
			},
			SkillList = {
				{
					Id = 100662,
					Value = 13,
				},
			},
		},
		{
			Level = 9,
			Info = 920630,
			Ability = {
				{
					Value = 200001,
					Num = 621,
				},
				{
					Value = 200008,
					Num = 189,
				},
			},
			SkillList = {
				{
					Id = 100662,
					Value = 13,
				},
			},
		},
		{
			Level = 10,
			Info = 920630,
			Ability = {
				{
					Value = 200001,
					Num = 690,
				},
				{
					Value = 200008,
					Num = 210,
				},
			},
			SkillList = {
				{
					Id = 100662,
					Value = 13,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id494] =
{
	Character = 223045,
	Rarity = 4,
	UpgradeId = 930014,
	LevelList = {
		{
			Level = 1,
			Info = 920631,
			Ability = {
				{
					Value = 200002,
					Num = 57,
				},
				{
					Value = 200008,
					Num = 21,
				},
			},
		},
		{
			Level = 2,
			Info = 920631,
			Ability = {
				{
					Value = 200002,
					Num = 114,
				},
				{
					Value = 200008,
					Num = 42,
				},
			},
		},
		{
			Level = 3,
			Info = 920631,
			Ability = {
				{
					Value = 200002,
					Num = 171,
				},
				{
					Value = 200008,
					Num = 63,
				},
			},
		},
		{
			Level = 4,
			Info = 920631,
			Ability = {
				{
					Value = 200002,
					Num = 228,
				},
				{
					Value = 200008,
					Num = 84,
				},
			},
		},
		{
			Level = 5,
			Info = 920631,
			Ability = {
				{
					Value = 200002,
					Num = 285,
				},
				{
					Value = 200008,
					Num = 105,
				},
			},
		},
		{
			Level = 6,
			Info = 920631,
			Ability = {
				{
					Value = 200002,
					Num = 342,
				},
				{
					Value = 200008,
					Num = 126,
				},
			},
		},
		{
			Level = 7,
			Info = 920631,
			Ability = {
				{
					Value = 200002,
					Num = 399,
				},
				{
					Value = 200008,
					Num = 147,
				},
			},
		},
		{
			Level = 8,
			Info = 920631,
			Ability = {
				{
					Value = 200002,
					Num = 456,
				},
				{
					Value = 200008,
					Num = 168,
				},
			},
			SkillList = {
				{
					Id = 101703,
					Value = 300,
				},
			},
		},
		{
			Level = 9,
			Info = 920631,
			Ability = {
				{
					Value = 200002,
					Num = 513,
				},
				{
					Value = 200008,
					Num = 189,
				},
			},
			SkillList = {
				{
					Id = 101703,
					Value = 300,
				},
			},
		},
		{
			Level = 10,
			Info = 920631,
			Ability = {
				{
					Value = 200002,
					Num = 570,
				},
				{
					Value = 200008,
					Num = 210,
				},
			},
			SkillList = {
				{
					Id = 101703,
					Value = 300,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id495] =
{
	Character = 223045,
	Rarity = 4,
	NeedChallenge = 145197,
	UpgradeId = 930015,
	LevelList = {
		{
			Level = 1,
			Info = 920632,
			Ability = {
				{
					Value = 200002,
					Num = 114,
				},
			},
		},
		{
			Level = 2,
			Info = 920632,
			Ability = {
				{
					Value = 200002,
					Num = 190,
				},
			},
		},
		{
			Level = 3,
			Info = 920632,
			Ability = {
				{
					Value = 200002,
					Num = 266,
				},
			},
		},
		{
			Level = 4,
			Info = 920632,
			Ability = {
				{
					Value = 200002,
					Num = 342,
				},
			},
		},
		{
			Level = 5,
			Info = 920632,
			Ability = {
				{
					Value = 200002,
					Num = 418,
				},
				{
					Value = 200004,
					Num = 25,
				},
			},
		},
		{
			Level = 6,
			Info = 920632,
			Ability = {
				{
					Value = 200002,
					Num = 494,
				},
				{
					Value = 200004,
					Num = 30,
				},
			},
		},
		{
			Level = 7,
			Info = 920632,
			Ability = {
				{
					Value = 200002,
					Num = 570,
				},
				{
					Value = 200004,
					Num = 35,
				},
			},
		},
		{
			Level = 8,
			Info = 920632,
			Ability = {
				{
					Value = 200002,
					Num = 646,
				},
				{
					Value = 200004,
					Num = 40,
				},
			},
			SkillList = {
				{
					Id = 101761,
					Value = 75,
				},
			},
		},
		{
			Level = 9,
			Info = 920632,
			Ability = {
				{
					Value = 200002,
					Num = 722,
				},
				{
					Value = 200004,
					Num = 45,
				},
			},
			SkillList = {
				{
					Id = 101761,
					Value = 75,
				},
			},
		},
		{
			Level = 10,
			Info = 920632,
			Ability = {
				{
					Value = 200002,
					Num = 798,
				},
				{
					Value = 200004,
					Num = 50,
				},
			},
			SkillList = {
				{
					Id = 101761,
					Value = 75,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id496] =
{
	Character = 223046,
	Rarity = 3,
	UpgradeId = 930029,
	LevelList = {
		{
			Level = 1,
			Info = 920633,
			Ability = {
				{
					Value = 200001,
					Num = 57,
				},
				{
					Value = 200006,
					Num = 9,
				},
			},
		},
		{
			Level = 2,
			Info = 920633,
			Ability = {
				{
					Value = 200001,
					Num = 114,
				},
				{
					Value = 200006,
					Num = 18,
				},
			},
		},
		{
			Level = 3,
			Info = 920633,
			Ability = {
				{
					Value = 200001,
					Num = 171,
				},
				{
					Value = 200006,
					Num = 27,
				},
			},
		},
		{
			Level = 4,
			Info = 920633,
			Ability = {
				{
					Value = 200001,
					Num = 228,
				},
				{
					Value = 200006,
					Num = 36,
				},
			},
		},
		{
			Level = 5,
			Info = 920633,
			Ability = {
				{
					Value = 200001,
					Num = 285,
				},
				{
					Value = 200006,
					Num = 45,
				},
			},
		},
		{
			Level = 6,
			Info = 920633,
			Ability = {
				{
					Value = 200001,
					Num = 342,
				},
				{
					Value = 200006,
					Num = 54,
				},
			},
		},
		{
			Level = 7,
			Info = 920633,
			Ability = {
				{
					Value = 200001,
					Num = 399,
				},
				{
					Value = 200006,
					Num = 63,
				},
			},
		},
		{
			Level = 8,
			Info = 920633,
			Ability = {
				{
					Value = 200001,
					Num = 456,
				},
				{
					Value = 200006,
					Num = 72,
				},
			},
			SkillList = {
				{
					Id = 101701,
					Value = 216,
				},
			},
		},
		{
			Level = 9,
			Info = 920633,
			Ability = {
				{
					Value = 200001,
					Num = 513,
				},
				{
					Value = 200006,
					Num = 81,
				},
			},
			SkillList = {
				{
					Id = 101701,
					Value = 216,
				},
			},
		},
		{
			Level = 10,
			Info = 920633,
			Ability = {
				{
					Value = 200001,
					Num = 570,
				},
				{
					Value = 200006,
					Num = 90,
				},
			},
			SkillList = {
				{
					Id = 101701,
					Value = 216,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id497] =
{
	Character = 223046,
	Rarity = 3,
	UpgradeId = 930010,
	LevelList = {
		{
			Level = 1,
			Info = 920634,
			Ability = {
				{
					Value = 200002,
					Num = 42,
				},
				{
					Value = 200005,
					Num = 6,
				},
			},
		},
		{
			Level = 2,
			Info = 920634,
			Ability = {
				{
					Value = 200002,
					Num = 84,
				},
				{
					Value = 200005,
					Num = 12,
				},
			},
		},
		{
			Level = 3,
			Info = 920634,
			Ability = {
				{
					Value = 200002,
					Num = 126,
				},
				{
					Value = 200005,
					Num = 18,
				},
			},
		},
		{
			Level = 4,
			Info = 920634,
			Ability = {
				{
					Value = 200002,
					Num = 168,
				},
				{
					Value = 200005,
					Num = 24,
				},
			},
		},
		{
			Level = 5,
			Info = 920634,
			Ability = {
				{
					Value = 200002,
					Num = 210,
				},
				{
					Value = 200005,
					Num = 30,
				},
			},
		},
		{
			Level = 6,
			Info = 920634,
			Ability = {
				{
					Value = 200002,
					Num = 252,
				},
				{
					Value = 200005,
					Num = 36,
				},
			},
		},
		{
			Level = 7,
			Info = 920634,
			Ability = {
				{
					Value = 200002,
					Num = 294,
				},
				{
					Value = 200005,
					Num = 42,
				},
			},
		},
		{
			Level = 8,
			Info = 920634,
			Ability = {
				{
					Value = 200002,
					Num = 336,
				},
				{
					Value = 200005,
					Num = 48,
				},
			},
			SkillList = {
				{
					Id = 100653,
					Value = 50,
				},
			},
		},
		{
			Level = 9,
			Info = 920634,
			Ability = {
				{
					Value = 200002,
					Num = 378,
				},
				{
					Value = 200005,
					Num = 54,
				},
			},
			SkillList = {
				{
					Id = 100653,
					Value = 50,
				},
			},
		},
		{
			Level = 10,
			Info = 920634,
			Ability = {
				{
					Value = 200002,
					Num = 420,
				},
				{
					Value = 200005,
					Num = 60,
				},
			},
			SkillList = {
				{
					Id = 100653,
					Value = 50,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id498] =
{
	Character = 223046,
	Rarity = 3,
	NeedChallenge = 145198,
	UpgradeId = 930031,
	LevelList = {
		{
			Level = 1,
			Info = 920635,
			Ability = {
				{
					Value = 200001,
					Num = 114,
				},
			},
		},
		{
			Level = 2,
			Info = 920635,
			Ability = {
				{
					Value = 200001,
					Num = 190,
				},
			},
		},
		{
			Level = 3,
			Info = 920635,
			Ability = {
				{
					Value = 200001,
					Num = 266,
				},
			},
		},
		{
			Level = 4,
			Info = 920635,
			Ability = {
				{
					Value = 200001,
					Num = 342,
				},
			},
		},
		{
			Level = 5,
			Info = 920635,
			Ability = {
				{
					Value = 200001,
					Num = 418,
				},
				{
					Value = 200003,
					Num = 25,
				},
			},
		},
		{
			Level = 6,
			Info = 920635,
			Ability = {
				{
					Value = 200001,
					Num = 494,
				},
				{
					Value = 200003,
					Num = 30,
				},
			},
		},
		{
			Level = 7,
			Info = 920635,
			Ability = {
				{
					Value = 200001,
					Num = 570,
				},
				{
					Value = 200003,
					Num = 35,
				},
			},
		},
		{
			Level = 8,
			Info = 920635,
			Ability = {
				{
					Value = 200001,
					Num = 646,
				},
				{
					Value = 200003,
					Num = 40,
				},
			},
			SkillList = {
				{
					Id = 100654,
					Value = 50,
				},
			},
		},
		{
			Level = 9,
			Info = 920635,
			Ability = {
				{
					Value = 200001,
					Num = 722,
				},
				{
					Value = 200003,
					Num = 45,
				},
			},
			SkillList = {
				{
					Id = 100654,
					Value = 50,
				},
			},
		},
		{
			Level = 10,
			Info = 920635,
			Ability = {
				{
					Value = 200001,
					Num = 798,
				},
				{
					Value = 200003,
					Num = 50,
				},
			},
			SkillList = {
				{
					Id = 100654,
					Value = 50,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id499] =
{
	Character = 220501,
	Rarity = 3,
	UpgradeId = 930009,
	LevelList = {
		{
			Level = 1,
			Info = 920422,
			Ability = {
				{
					Value = 200002,
					Num = 42,
				},
				{
					Value = 200006,
					Num = 9,
				},
			},
		},
		{
			Level = 2,
			Info = 920422,
			Ability = {
				{
					Value = 200002,
					Num = 84,
				},
				{
					Value = 200006,
					Num = 18,
				},
			},
		},
		{
			Level = 3,
			Info = 920422,
			Ability = {
				{
					Value = 200002,
					Num = 126,
				},
				{
					Value = 200006,
					Num = 27,
				},
			},
		},
		{
			Level = 4,
			Info = 920422,
			Ability = {
				{
					Value = 200002,
					Num = 168,
				},
				{
					Value = 200006,
					Num = 36,
				},
			},
		},
		{
			Level = 5,
			Info = 920422,
			Ability = {
				{
					Value = 200002,
					Num = 210,
				},
				{
					Value = 200006,
					Num = 45,
				},
			},
		},
		{
			Level = 6,
			Info = 920422,
			Ability = {
				{
					Value = 200002,
					Num = 252,
				},
				{
					Value = 200006,
					Num = 54,
				},
			},
		},
		{
			Level = 7,
			Info = 920422,
			Ability = {
				{
					Value = 200002,
					Num = 294,
				},
				{
					Value = 200006,
					Num = 63,
				},
			},
		},
		{
			Level = 8,
			Info = 920422,
			Ability = {
				{
					Value = 200002,
					Num = 336,
				},
				{
					Value = 200006,
					Num = 72,
				},
			},
			SkillList = {
				{
					Id = 100552,
					Value = 25,
				},
			},
		},
		{
			Level = 9,
			Info = 920422,
			Ability = {
				{
					Value = 200002,
					Num = 378,
				},
				{
					Value = 200006,
					Num = 81,
				},
			},
			SkillList = {
				{
					Id = 100552,
					Value = 25,
				},
			},
		},
		{
			Level = 10,
			Info = 920422,
			Ability = {
				{
					Value = 200002,
					Num = 420,
				},
				{
					Value = 200006,
					Num = 90,
				},
			},
			SkillList = {
				{
					Id = 100552,
					Value = 25,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id500] =
{
	Character = 220501,
	Rarity = 3,
	UpgradeId = 930010,
	LevelList = {
		{
			Level = 1,
			Info = 920423,
			Ability = {
				{
					Value = 200002,
					Num = 42,
				},
				{
					Value = 200005,
					Num = 6,
				},
			},
		},
		{
			Level = 2,
			Info = 920423,
			Ability = {
				{
					Value = 200002,
					Num = 84,
				},
				{
					Value = 200005,
					Num = 12,
				},
			},
		},
		{
			Level = 3,
			Info = 920423,
			Ability = {
				{
					Value = 200002,
					Num = 126,
				},
				{
					Value = 200005,
					Num = 18,
				},
			},
		},
		{
			Level = 4,
			Info = 920423,
			Ability = {
				{
					Value = 200002,
					Num = 168,
				},
				{
					Value = 200005,
					Num = 24,
				},
			},
		},
		{
			Level = 5,
			Info = 920423,
			Ability = {
				{
					Value = 200002,
					Num = 210,
				},
				{
					Value = 200005,
					Num = 30,
				},
			},
		},
		{
			Level = 6,
			Info = 920423,
			Ability = {
				{
					Value = 200002,
					Num = 252,
				},
				{
					Value = 200005,
					Num = 36,
				},
			},
		},
		{
			Level = 7,
			Info = 920423,
			Ability = {
				{
					Value = 200002,
					Num = 294,
				},
				{
					Value = 200005,
					Num = 42,
				},
			},
		},
		{
			Level = 8,
			Info = 920423,
			Ability = {
				{
					Value = 200002,
					Num = 336,
				},
				{
					Value = 200005,
					Num = 48,
				},
			},
			SkillList = {
				{
					Id = 100552,
					Value = 25,
				},
			},
		},
		{
			Level = 9,
			Info = 920423,
			Ability = {
				{
					Value = 200002,
					Num = 378,
				},
				{
					Value = 200005,
					Num = 54,
				},
			},
			SkillList = {
				{
					Id = 100552,
					Value = 25,
				},
			},
		},
		{
			Level = 10,
			Info = 920423,
			Ability = {
				{
					Value = 200002,
					Num = 420,
				},
				{
					Value = 200005,
					Num = 60,
				},
			},
			SkillList = {
				{
					Id = 100552,
					Value = 25,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id501] =
{
	Character = 220501,
	Rarity = 3,
	NeedChallenge = 145199,
	UpgradeId = 930011,
	LevelList = {
		{
			Level = 1,
			Info = 920424,
			Ability = {
				{
					Value = 200002,
					Num = 84,
				},
			},
		},
		{
			Level = 2,
			Info = 920424,
			Ability = {
				{
					Value = 200002,
					Num = 140,
				},
			},
		},
		{
			Level = 3,
			Info = 920424,
			Ability = {
				{
					Value = 200002,
					Num = 196,
				},
			},
		},
		{
			Level = 4,
			Info = 920424,
			Ability = {
				{
					Value = 200002,
					Num = 252,
				},
			},
		},
		{
			Level = 5,
			Info = 920424,
			Ability = {
				{
					Value = 200002,
					Num = 308,
				},
				{
					Value = 200004,
					Num = 25,
				},
			},
		},
		{
			Level = 6,
			Info = 920424,
			Ability = {
				{
					Value = 200002,
					Num = 364,
				},
				{
					Value = 200004,
					Num = 30,
				},
			},
		},
		{
			Level = 7,
			Info = 920424,
			Ability = {
				{
					Value = 200002,
					Num = 420,
				},
				{
					Value = 200004,
					Num = 35,
				},
			},
		},
		{
			Level = 8,
			Info = 920424,
			Ability = {
				{
					Value = 200002,
					Num = 476,
				},
				{
					Value = 200004,
					Num = 40,
				},
			},
		},
		{
			Level = 9,
			Info = 920424,
			Ability = {
				{
					Value = 200002,
					Num = 532,
				},
				{
					Value = 200004,
					Num = 45,
				},
			},
		},
		{
			Level = 10,
			Info = 920424,
			Ability = {
				{
					Value = 200002,
					Num = 588,
				},
				{
					Value = 200004,
					Num = 50,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id502] =
{
	Character = 220502,
	Rarity = 4,
	UpgradeId = 930033,
	LevelList = {
		{
			Level = 1,
			Info = 920425,
			Ability = {
				{
					Value = 200001,
					Num = 69,
				},
				{
					Value = 200007,
					Num = 12,
				},
			},
		},
		{
			Level = 2,
			Info = 920425,
			Ability = {
				{
					Value = 200001,
					Num = 138,
				},
				{
					Value = 200007,
					Num = 24,
				},
			},
		},
		{
			Level = 3,
			Info = 920425,
			Ability = {
				{
					Value = 200001,
					Num = 207,
				},
				{
					Value = 200007,
					Num = 36,
				},
			},
		},
		{
			Level = 4,
			Info = 920425,
			Ability = {
				{
					Value = 200001,
					Num = 276,
				},
				{
					Value = 200007,
					Num = 48,
				},
			},
		},
		{
			Level = 5,
			Info = 920425,
			Ability = {
				{
					Value = 200001,
					Num = 345,
				},
				{
					Value = 200007,
					Num = 60,
				},
			},
		},
		{
			Level = 6,
			Info = 920425,
			Ability = {
				{
					Value = 200001,
					Num = 414,
				},
				{
					Value = 200007,
					Num = 72,
				},
			},
		},
		{
			Level = 7,
			Info = 920425,
			Ability = {
				{
					Value = 200001,
					Num = 483,
				},
				{
					Value = 200007,
					Num = 84,
				},
			},
		},
		{
			Level = 8,
			Info = 920425,
			Ability = {
				{
					Value = 200001,
					Num = 552,
				},
				{
					Value = 200007,
					Num = 96,
				},
			},
			SkillList = {
				{
					Id = 100562,
					Value = -5,
				},
			},
		},
		{
			Level = 9,
			Info = 920425,
			Ability = {
				{
					Value = 200001,
					Num = 621,
				},
				{
					Value = 200007,
					Num = 108,
				},
			},
			SkillList = {
				{
					Id = 100562,
					Value = -5,
				},
			},
		},
		{
			Level = 10,
			Info = 920425,
			Ability = {
				{
					Value = 200001,
					Num = 690,
				},
				{
					Value = 200007,
					Num = 120,
				},
			},
			SkillList = {
				{
					Id = 100562,
					Value = -5,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id503] =
{
	Character = 220502,
	Rarity = 4,
	UpgradeId = 930034,
	LevelList = {
		{
			Level = 1,
			Info = 920426,
			Ability = {
				{
					Value = 200001,
					Num = 69,
				},
				{
					Value = 200008,
					Num = 9,
				},
			},
		},
		{
			Level = 2,
			Info = 920426,
			Ability = {
				{
					Value = 200001,
					Num = 138,
				},
				{
					Value = 200008,
					Num = 18,
				},
			},
		},
		{
			Level = 3,
			Info = 920426,
			Ability = {
				{
					Value = 200001,
					Num = 207,
				},
				{
					Value = 200008,
					Num = 27,
				},
			},
		},
		{
			Level = 4,
			Info = 920426,
			Ability = {
				{
					Value = 200001,
					Num = 276,
				},
				{
					Value = 200008,
					Num = 36,
				},
			},
		},
		{
			Level = 5,
			Info = 920426,
			Ability = {
				{
					Value = 200001,
					Num = 345,
				},
				{
					Value = 200008,
					Num = 45,
				},
			},
		},
		{
			Level = 6,
			Info = 920426,
			Ability = {
				{
					Value = 200001,
					Num = 414,
				},
				{
					Value = 200008,
					Num = 54,
				},
			},
		},
		{
			Level = 7,
			Info = 920426,
			Ability = {
				{
					Value = 200001,
					Num = 483,
				},
				{
					Value = 200008,
					Num = 63,
				},
			},
		},
		{
			Level = 8,
			Info = 920426,
			Ability = {
				{
					Value = 200001,
					Num = 552,
				},
				{
					Value = 200008,
					Num = 72,
				},
			},
			SkillList = {
				{
					Id = 100562,
					Value = -5,
				},
			},
		},
		{
			Level = 9,
			Info = 920426,
			Ability = {
				{
					Value = 200001,
					Num = 621,
				},
				{
					Value = 200008,
					Num = 81,
				},
			},
			SkillList = {
				{
					Id = 100562,
					Value = -5,
				},
			},
		},
		{
			Level = 10,
			Info = 920426,
			Ability = {
				{
					Value = 200001,
					Num = 690,
				},
				{
					Value = 200008,
					Num = 90,
				},
			},
			SkillList = {
				{
					Id = 100562,
					Value = -5,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id504] =
{
	Character = 220502,
	Rarity = 4,
	NeedChallenge = 145200,
	UpgradeId = 930035,
	LevelList = {
		{
			Level = 1,
			Info = 920427,
			Ability = {
				{
					Value = 200001,
					Num = 138,
				},
			},
		},
		{
			Level = 2,
			Info = 920427,
			Ability = {
				{
					Value = 200001,
					Num = 230,
				},
			},
		},
		{
			Level = 3,
			Info = 920427,
			Ability = {
				{
					Value = 200001,
					Num = 322,
				},
			},
		},
		{
			Level = 4,
			Info = 920427,
			Ability = {
				{
					Value = 200001,
					Num = 414,
				},
			},
		},
		{
			Level = 5,
			Info = 920427,
			Ability = {
				{
					Value = 200001,
					Num = 506,
				},
				{
					Value = 200003,
					Num = 25,
				},
			},
		},
		{
			Level = 6,
			Info = 920427,
			Ability = {
				{
					Value = 200001,
					Num = 598,
				},
				{
					Value = 200003,
					Num = 30,
				},
			},
		},
		{
			Level = 7,
			Info = 920427,
			Ability = {
				{
					Value = 200001,
					Num = 690,
				},
				{
					Value = 200003,
					Num = 35,
				},
			},
		},
		{
			Level = 8,
			Info = 920427,
			Ability = {
				{
					Value = 200001,
					Num = 782,
				},
				{
					Value = 200003,
					Num = 40,
				},
			},
		},
		{
			Level = 9,
			Info = 920427,
			Ability = {
				{
					Value = 200001,
					Num = 874,
				},
				{
					Value = 200003,
					Num = 45,
				},
			},
		},
		{
			Level = 10,
			Info = 920427,
			Ability = {
				{
					Value = 200001,
					Num = 966,
				},
				{
					Value = 200003,
					Num = 50,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id505] =
{
	Character = 220503,
	Rarity = 4,
	UpgradeId = 930033,
	LevelList = {
		{
			Level = 1,
			Info = 920428,
			Ability = {
				{
					Value = 200001,
					Num = 69,
				},
				{
					Value = 200007,
					Num = 12,
				},
			},
		},
		{
			Level = 2,
			Info = 920428,
			Ability = {
				{
					Value = 200001,
					Num = 138,
				},
				{
					Value = 200007,
					Num = 24,
				},
			},
		},
		{
			Level = 3,
			Info = 920428,
			Ability = {
				{
					Value = 200001,
					Num = 207,
				},
				{
					Value = 200007,
					Num = 36,
				},
			},
		},
		{
			Level = 4,
			Info = 920428,
			Ability = {
				{
					Value = 200001,
					Num = 276,
				},
				{
					Value = 200007,
					Num = 48,
				},
			},
		},
		{
			Level = 5,
			Info = 920428,
			Ability = {
				{
					Value = 200001,
					Num = 345,
				},
				{
					Value = 200007,
					Num = 60,
				},
			},
		},
		{
			Level = 6,
			Info = 920428,
			Ability = {
				{
					Value = 200001,
					Num = 414,
				},
				{
					Value = 200007,
					Num = 72,
				},
			},
		},
		{
			Level = 7,
			Info = 920428,
			Ability = {
				{
					Value = 200001,
					Num = 483,
				},
				{
					Value = 200007,
					Num = 84,
				},
			},
		},
		{
			Level = 8,
			Info = 920428,
			Ability = {
				{
					Value = 200001,
					Num = 552,
				},
				{
					Value = 200007,
					Num = 96,
				},
			},
			SkillList = {
				{
					Id = 100561,
					Value = -5,
				},
			},
		},
		{
			Level = 9,
			Info = 920428,
			Ability = {
				{
					Value = 200001,
					Num = 621,
				},
				{
					Value = 200007,
					Num = 108,
				},
			},
			SkillList = {
				{
					Id = 100561,
					Value = -5,
				},
			},
		},
		{
			Level = 10,
			Info = 920428,
			Ability = {
				{
					Value = 200001,
					Num = 690,
				},
				{
					Value = 200007,
					Num = 120,
				},
			},
			SkillList = {
				{
					Id = 100561,
					Value = -5,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id506] =
{
	Character = 220503,
	Rarity = 4,
	UpgradeId = 930034,
	LevelList = {
		{
			Level = 1,
			Info = 920429,
			Ability = {
				{
					Value = 200001,
					Num = 69,
				},
				{
					Value = 200008,
					Num = 9,
				},
			},
		},
		{
			Level = 2,
			Info = 920429,
			Ability = {
				{
					Value = 200001,
					Num = 138,
				},
				{
					Value = 200008,
					Num = 18,
				},
			},
		},
		{
			Level = 3,
			Info = 920429,
			Ability = {
				{
					Value = 200001,
					Num = 207,
				},
				{
					Value = 200008,
					Num = 27,
				},
			},
		},
		{
			Level = 4,
			Info = 920429,
			Ability = {
				{
					Value = 200001,
					Num = 276,
				},
				{
					Value = 200008,
					Num = 36,
				},
			},
		},
		{
			Level = 5,
			Info = 920429,
			Ability = {
				{
					Value = 200001,
					Num = 345,
				},
				{
					Value = 200008,
					Num = 45,
				},
			},
		},
		{
			Level = 6,
			Info = 920429,
			Ability = {
				{
					Value = 200001,
					Num = 414,
				},
				{
					Value = 200008,
					Num = 54,
				},
			},
		},
		{
			Level = 7,
			Info = 920429,
			Ability = {
				{
					Value = 200001,
					Num = 483,
				},
				{
					Value = 200008,
					Num = 63,
				},
			},
		},
		{
			Level = 8,
			Info = 920429,
			Ability = {
				{
					Value = 200001,
					Num = 552,
				},
				{
					Value = 200008,
					Num = 72,
				},
			},
			SkillList = {
				{
					Id = 100561,
					Value = -5,
				},
			},
		},
		{
			Level = 9,
			Info = 920429,
			Ability = {
				{
					Value = 200001,
					Num = 621,
				},
				{
					Value = 200008,
					Num = 81,
				},
			},
			SkillList = {
				{
					Id = 100561,
					Value = -5,
				},
			},
		},
		{
			Level = 10,
			Info = 920429,
			Ability = {
				{
					Value = 200001,
					Num = 690,
				},
				{
					Value = 200008,
					Num = 90,
				},
			},
			SkillList = {
				{
					Id = 100561,
					Value = -5,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id507] =
{
	Character = 220503,
	Rarity = 4,
	NeedChallenge = 145201,
	UpgradeId = 930035,
	LevelList = {
		{
			Level = 1,
			Info = 920430,
			Ability = {
				{
					Value = 200001,
					Num = 138,
				},
			},
		},
		{
			Level = 2,
			Info = 920430,
			Ability = {
				{
					Value = 200001,
					Num = 230,
				},
			},
		},
		{
			Level = 3,
			Info = 920430,
			Ability = {
				{
					Value = 200001,
					Num = 322,
				},
			},
		},
		{
			Level = 4,
			Info = 920430,
			Ability = {
				{
					Value = 200001,
					Num = 414,
				},
			},
		},
		{
			Level = 5,
			Info = 920430,
			Ability = {
				{
					Value = 200001,
					Num = 506,
				},
				{
					Value = 200003,
					Num = 25,
				},
			},
		},
		{
			Level = 6,
			Info = 920430,
			Ability = {
				{
					Value = 200001,
					Num = 598,
				},
				{
					Value = 200003,
					Num = 30,
				},
			},
		},
		{
			Level = 7,
			Info = 920430,
			Ability = {
				{
					Value = 200001,
					Num = 690,
				},
				{
					Value = 200003,
					Num = 35,
				},
			},
		},
		{
			Level = 8,
			Info = 920430,
			Ability = {
				{
					Value = 200001,
					Num = 782,
				},
				{
					Value = 200003,
					Num = 40,
				},
			},
		},
		{
			Level = 9,
			Info = 920430,
			Ability = {
				{
					Value = 200001,
					Num = 874,
				},
				{
					Value = 200003,
					Num = 45,
				},
			},
		},
		{
			Level = 10,
			Info = 920430,
			Ability = {
				{
					Value = 200001,
					Num = 966,
				},
				{
					Value = 200003,
					Num = 50,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id508] =
{
	Character = 220504,
	Rarity = 4,
	UpgradeId = 930013,
	LevelList = {
		{
			Level = 1,
			Info = 920431,
			Ability = {
				{
					Value = 200002,
					Num = 54,
				},
				{
					Value = 200006,
					Num = 12,
				},
			},
		},
		{
			Level = 2,
			Info = 920431,
			Ability = {
				{
					Value = 200002,
					Num = 108,
				},
				{
					Value = 200006,
					Num = 24,
				},
			},
		},
		{
			Level = 3,
			Info = 920431,
			Ability = {
				{
					Value = 200002,
					Num = 162,
				},
				{
					Value = 200006,
					Num = 36,
				},
			},
		},
		{
			Level = 4,
			Info = 920431,
			Ability = {
				{
					Value = 200002,
					Num = 216,
				},
				{
					Value = 200006,
					Num = 48,
				},
			},
		},
		{
			Level = 5,
			Info = 920431,
			Ability = {
				{
					Value = 200002,
					Num = 270,
				},
				{
					Value = 200006,
					Num = 60,
				},
			},
		},
		{
			Level = 6,
			Info = 920431,
			Ability = {
				{
					Value = 200002,
					Num = 324,
				},
				{
					Value = 200006,
					Num = 72,
				},
			},
		},
		{
			Level = 7,
			Info = 920431,
			Ability = {
				{
					Value = 200002,
					Num = 378,
				},
				{
					Value = 200006,
					Num = 84,
				},
			},
		},
		{
			Level = 8,
			Info = 920431,
			Ability = {
				{
					Value = 200002,
					Num = 432,
				},
				{
					Value = 200006,
					Num = 96,
				},
			},
			SkillList = {
				{
					Id = 100553,
					Value = 25,
				},
			},
		},
		{
			Level = 9,
			Info = 920431,
			Ability = {
				{
					Value = 200002,
					Num = 486,
				},
				{
					Value = 200006,
					Num = 108,
				},
			},
			SkillList = {
				{
					Id = 100553,
					Value = 25,
				},
			},
		},
		{
			Level = 10,
			Info = 920431,
			Ability = {
				{
					Value = 200002,
					Num = 540,
				},
				{
					Value = 200006,
					Num = 120,
				},
			},
			SkillList = {
				{
					Id = 100553,
					Value = 25,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id509] =
{
	Character = 220504,
	Rarity = 4,
	UpgradeId = 930014,
	LevelList = {
		{
			Level = 1,
			Info = 920432,
			Ability = {
				{
					Value = 200002,
					Num = 54,
				},
				{
					Value = 200007,
					Num = 9,
				},
			},
		},
		{
			Level = 2,
			Info = 920432,
			Ability = {
				{
					Value = 200002,
					Num = 108,
				},
				{
					Value = 200007,
					Num = 18,
				},
			},
		},
		{
			Level = 3,
			Info = 920432,
			Ability = {
				{
					Value = 200002,
					Num = 162,
				},
				{
					Value = 200007,
					Num = 27,
				},
			},
		},
		{
			Level = 4,
			Info = 920432,
			Ability = {
				{
					Value = 200002,
					Num = 216,
				},
				{
					Value = 200007,
					Num = 36,
				},
			},
		},
		{
			Level = 5,
			Info = 920432,
			Ability = {
				{
					Value = 200002,
					Num = 270,
				},
				{
					Value = 200007,
					Num = 45,
				},
			},
		},
		{
			Level = 6,
			Info = 920432,
			Ability = {
				{
					Value = 200002,
					Num = 324,
				},
				{
					Value = 200007,
					Num = 54,
				},
			},
		},
		{
			Level = 7,
			Info = 920432,
			Ability = {
				{
					Value = 200002,
					Num = 378,
				},
				{
					Value = 200007,
					Num = 63,
				},
			},
		},
		{
			Level = 8,
			Info = 920432,
			Ability = {
				{
					Value = 200002,
					Num = 432,
				},
				{
					Value = 200007,
					Num = 72,
				},
			},
			SkillList = {
				{
					Id = 100553,
					Value = 25,
				},
			},
		},
		{
			Level = 9,
			Info = 920432,
			Ability = {
				{
					Value = 200002,
					Num = 486,
				},
				{
					Value = 200007,
					Num = 81,
				},
			},
			SkillList = {
				{
					Id = 100553,
					Value = 25,
				},
			},
		},
		{
			Level = 10,
			Info = 920432,
			Ability = {
				{
					Value = 200002,
					Num = 540,
				},
				{
					Value = 200007,
					Num = 90,
				},
			},
			SkillList = {
				{
					Id = 100553,
					Value = 25,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id510] =
{
	Character = 220504,
	Rarity = 4,
	NeedChallenge = 145202,
	UpgradeId = 930015,
	LevelList = {
		{
			Level = 1,
			Info = 920433,
			Ability = {
				{
					Value = 200002,
					Num = 108,
				},
			},
		},
		{
			Level = 2,
			Info = 920433,
			Ability = {
				{
					Value = 200002,
					Num = 180,
				},
			},
		},
		{
			Level = 3,
			Info = 920433,
			Ability = {
				{
					Value = 200002,
					Num = 252,
				},
			},
		},
		{
			Level = 4,
			Info = 920433,
			Ability = {
				{
					Value = 200002,
					Num = 324,
				},
			},
		},
		{
			Level = 5,
			Info = 920433,
			Ability = {
				{
					Value = 200002,
					Num = 396,
				},
				{
					Value = 200004,
					Num = 25,
				},
			},
		},
		{
			Level = 6,
			Info = 920433,
			Ability = {
				{
					Value = 200002,
					Num = 468,
				},
				{
					Value = 200004,
					Num = 30,
				},
			},
		},
		{
			Level = 7,
			Info = 920433,
			Ability = {
				{
					Value = 200002,
					Num = 540,
				},
				{
					Value = 200004,
					Num = 35,
				},
			},
		},
		{
			Level = 8,
			Info = 920433,
			Ability = {
				{
					Value = 200002,
					Num = 612,
				},
				{
					Value = 200004,
					Num = 40,
				},
			},
		},
		{
			Level = 9,
			Info = 920433,
			Ability = {
				{
					Value = 200002,
					Num = 684,
				},
				{
					Value = 200004,
					Num = 45,
				},
			},
		},
		{
			Level = 10,
			Info = 920433,
			Ability = {
				{
					Value = 200002,
					Num = 756,
				},
				{
					Value = 200004,
					Num = 50,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id511] =
{
	Character = 220505,
	Rarity = 3,
	UpgradeId = 930029,
	LevelList = {
		{
			Level = 1,
			Info = 920434,
			Ability = {
				{
					Value = 200001,
					Num = 54,
				},
				{
					Value = 200005,
					Num = 9,
				},
			},
		},
		{
			Level = 2,
			Info = 920434,
			Ability = {
				{
					Value = 200001,
					Num = 108,
				},
				{
					Value = 200005,
					Num = 18,
				},
			},
		},
		{
			Level = 3,
			Info = 920434,
			Ability = {
				{
					Value = 200001,
					Num = 162,
				},
				{
					Value = 200005,
					Num = 27,
				},
			},
		},
		{
			Level = 4,
			Info = 920434,
			Ability = {
				{
					Value = 200001,
					Num = 216,
				},
				{
					Value = 200005,
					Num = 36,
				},
			},
		},
		{
			Level = 5,
			Info = 920434,
			Ability = {
				{
					Value = 200001,
					Num = 270,
				},
				{
					Value = 200005,
					Num = 45,
				},
			},
			SkillList = {
				{
					Id = 100651,
					Value = 5,
				},
			},
		},
		{
			Level = 6,
			Info = 920434,
			Ability = {
				{
					Value = 200001,
					Num = 324,
				},
				{
					Value = 200005,
					Num = 54,
				},
			},
			SkillList = {
				{
					Id = 100651,
					Value = 5,
				},
			},
		},
		{
			Level = 7,
			Info = 920434,
			Ability = {
				{
					Value = 200001,
					Num = 378,
				},
				{
					Value = 200005,
					Num = 63,
				},
			},
			SkillList = {
				{
					Id = 100651,
					Value = 5,
				},
			},
		},
		{
			Level = 8,
			Info = 920434,
			Ability = {
				{
					Value = 200001,
					Num = 432,
				},
				{
					Value = 200005,
					Num = 72,
				},
			},
			SkillList = {
				{
					Id = 100651,
					Value = 5,
				},
			},
		},
		{
			Level = 9,
			Info = 920434,
			Ability = {
				{
					Value = 200001,
					Num = 486,
				},
				{
					Value = 200005,
					Num = 81,
				},
			},
			SkillList = {
				{
					Id = 100651,
					Value = 5,
				},
			},
		},
		{
			Level = 10,
			Info = 920434,
			Ability = {
				{
					Value = 200001,
					Num = 540,
				},
				{
					Value = 200005,
					Num = 90,
				},
			},
			SkillList = {
				{
					Id = 100651,
					Value = 5,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id512] =
{
	Character = 220505,
	Rarity = 3,
	UpgradeId = 930030,
	LevelList = {
		{
			Level = 1,
			Info = 920435,
			Ability = {
				{
					Value = 200001,
					Num = 54,
				},
				{
					Value = 200006,
					Num = 6,
				},
			},
		},
		{
			Level = 2,
			Info = 920435,
			Ability = {
				{
					Value = 200001,
					Num = 108,
				},
				{
					Value = 200006,
					Num = 12,
				},
			},
		},
		{
			Level = 3,
			Info = 920435,
			Ability = {
				{
					Value = 200001,
					Num = 162,
				},
				{
					Value = 200006,
					Num = 18,
				},
			},
		},
		{
			Level = 4,
			Info = 920435,
			Ability = {
				{
					Value = 200001,
					Num = 216,
				},
				{
					Value = 200006,
					Num = 24,
				},
			},
		},
		{
			Level = 5,
			Info = 920435,
			Ability = {
				{
					Value = 200001,
					Num = 270,
				},
				{
					Value = 200006,
					Num = 30,
				},
			},
		},
		{
			Level = 6,
			Info = 920435,
			Ability = {
				{
					Value = 200001,
					Num = 324,
				},
				{
					Value = 200006,
					Num = 36,
				},
			},
		},
		{
			Level = 7,
			Info = 920435,
			Ability = {
				{
					Value = 200001,
					Num = 378,
				},
				{
					Value = 200006,
					Num = 42,
				},
			},
		},
		{
			Level = 8,
			Info = 920435,
			Ability = {
				{
					Value = 200001,
					Num = 432,
				},
				{
					Value = 200006,
					Num = 48,
				},
			},
			SkillList = {
				{
					Id = 100563,
					Value = -5,
				},
			},
		},
		{
			Level = 9,
			Info = 920435,
			Ability = {
				{
					Value = 200001,
					Num = 486,
				},
				{
					Value = 200006,
					Num = 54,
				},
			},
			SkillList = {
				{
					Id = 100563,
					Value = -5,
				},
			},
		},
		{
			Level = 10,
			Info = 920435,
			Ability = {
				{
					Value = 200001,
					Num = 540,
				},
				{
					Value = 200006,
					Num = 60,
				},
			},
			SkillList = {
				{
					Id = 100563,
					Value = -5,
				},
			},
		},
	},
}
