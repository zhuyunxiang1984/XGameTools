ActivityBattleConfig ={};
ActivityBattleID = 
{
	Id001 = 620001,
	Id002 = 620002,
	Id003 = 620003,
	Id004 = 620004,
	Id005 = 620005,
	Id006 = 620006,
	Id007 = 620007,
	Id008 = 620008,
	Id009 = 620009,
	Id010 = 620010,
	Id011 = 620011,
	Id012 = 620012,
	Id013 = 620013,
	Id014 = 620014,
	Id015 = 620015,
	Id016 = 620016,
	Id017 = 620017,
	Id018 = 620018,
	Id019 = 620019,
	Id020 = 620020,
	Id021 = 620021,
	Id022 = 620022,
	Id023 = 620023,
	Id024 = 620024,
	Id025 = 620025,
	Id026 = 620026,
	Id027 = 620027,
	Id028 = 620028,
	Id029 = 620029,
	Id030 = 620030,
	Id031 = 620031,
	Id032 = 620032,
	Id033 = 620033,
	Id034 = 620034,
	Id035 = 620035,
	Id036 = 620036,
	Id037 = 620037,
	Id038 = 620038,
	Id039 = 620039,
	Id040 = 620040,
	Id041 = 620041,
	Id042 = 620042,
	Id043 = 620043,
	Id044 = 620044,
	Id045 = 620045,
	Id046 = 620046,
	Id047 = 620047,
	Id048 = 620048,
	Id049 = 620049,
	Id050 = 620050,
	Id051 = 620051,
	Id052 = 620052,
	Id053 = 620053,
	Id054 = 620054,
	Id055 = 620055,
	Id056 = 620056,
	Id057 = 620057,
	Id058 = 620058,
	Id059 = 620059,
	Id060 = 620060,
	Id061 = 620061,
	Id062 = 620062,
	Id063 = 620063,
	Id064 = 620064,
	Id065 = 620065,
	Id066 = 620066,
	Id067 = 620067,
	Id068 = 620068,
	Id069 = 620069,
	Id070 = 620070,
}
ActivityBattleConfig[ActivityBattleID.Id001] =
{
	Id = 1,
	Name = "章节1：拒绝加班",
	IntroduceText = "眼看年关渐近，剑士早早完成了工作，打算回家收拾整理一番。然而公会的同伴还在加班打怪，并且向他投来了奇怪的目光。",
	StoryBundle = "packed_activity_2021springfestival",
	StoryAtlas = "2021SpringFestivalStory",
	StoryBG = "ActivityStory_2021SpringFestival_1",
	SupportLevel = 25,
	UnlockCostList = {
		{
			Value = 327304,
			Num = 30,
		},
	},
	RepeatCostList = {
		{
			Value = 2,
			Num = 200,
		},
	},
	Limit = 3,
	AcceptSpeech = 62000101,
	Desc = "不要气馁，继续前进！",
	ResultText = "章节1：拒绝加班已完成",
	Dialog = "我们的友情呢？",
	NumCap = 5,
	LevelBundle = "packed_eventthemebg",
	LevelAtlas = "EventThemeBG",
	LevelBG = "2021SpringFestivalBG01",
	StartScene = "2021SpringFestivalChallenge_StartScene",
	TeamCondition = {
		{
			Condition = "TeamCharacterIdAnd",
			Value = 
			{
				220003,
			},
			Desc = "队伍中必须有剑士",
			Hint = "队伍中必须有剑士",
		},
	},
	Enemy = {
		{
			Value = 241005,
			Level = 25,
		},
	},
	Reward = {
		{
			Value = 327306,
			Num = 300,
		},
	},
	RepeatReward = {
		{
			Value = 327306,
			Num = 50,
		},
	},
}
ActivityBattleConfig[ActivityBattleID.Id002] =
{
	Id = 2,
	Name = "章节2：年末考核",
	IntroduceText = "剑士的最后一项任务，是参加公会的年末考核，而这次的考核官，是他的师父。",
	StoryBundle = "packed_activity_2021springfestival",
	StoryAtlas = "2021SpringFestivalStory",
	StoryBG = "ActivityStory_2021SpringFestival_2",
	SupportLevel = 35,
	UnlockCostList = {
		{
			Value = 327304,
			Num = 30,
		},
	},
	RepeatCostList = {
		{
			Value = 2,
			Num = 200,
		},
	},
	Limit = 3,
	AcceptSpeech = 62000201,
	Desc = "不要气馁，继续前进！",
	ResultText = "章节2：年末考核已完成",
	Dialog = "为师认可你了。",
	NumCap = 5,
	LevelBundle = "packed_eventthemebg",
	LevelAtlas = "EventThemeBG",
	LevelBG = "2021SpringFestivalBG01",
	StartScene = "2021SpringFestivalChallenge_StartScene",
	TeamCondition = {
		{
			Condition = "TeamCharacterIdAnd",
			Value = 
			{
				220003,
			},
			Desc = "队伍中必须有剑士",
			Hint = "队伍中必须有剑士",
		},
	},
	Enemy = {
		{
			Value = 241006,
			Level = 35,
		},
	},
	Reward = {
		{
			Value = 327306,
			Num = 300,
		},
	},
	RepeatReward = {
		{
			Value = 327306,
			Num = 50,
		},
	},
}
ActivityBattleConfig[ActivityBattleID.Id003] =
{
	Id = 3,
	Name = "章节3：送礼就送全家桶",
	IntroduceText = "离出发的日子越来越近了，剑士打算带一点土特产回家。",
	StoryBundle = "packed_activity_2021springfestival",
	StoryAtlas = "2021SpringFestivalStory",
	StoryBG = "ActivityStory_2021SpringFestival_3",
	SupportLevel = 45,
	UnlockCostList = {
		{
			Value = 327304,
			Num = 45,
		},
	},
	RepeatCostList = {
		{
			Value = 2,
			Num = 200,
		},
	},
	Limit = 3,
	AcceptSpeech = 62000301,
	Desc = "不要气馁，继续前进！",
	ResultText = "章节3：送礼就送全家桶已完成",
	Dialog = "我回去把概率再调调。",
	NumCap = 5,
	LevelBundle = "packed_eventthemebg",
	LevelAtlas = "EventThemeBG",
	LevelBG = "2021SpringFestivalBG01",
	StartScene = "2021SpringFestivalChallenge_StartScene",
	TeamCondition = {
		{
			Condition = "TeamCharacterIdAnd",
			Value = 
			{
				220003,
			},
			Desc = "队伍中必须有剑士",
			Hint = "队伍中必须有剑士",
		},
	},
	Enemy = {
		{
			Value = 241007,
			Level = 45,
		},
	},
	Reward = {
		{
			Value = 327306,
			Num = 300,
		},
	},
	RepeatReward = {
		{
			Value = 327306,
			Num = 50,
		},
	},
}
ActivityBattleConfig[ActivityBattleID.Id004] =
{
	Id = 4,
	Name = "章节4：再见，村长！",
	IntroduceText = "买好土特产，再向那位发布任务的老村长告别，就可以踏上回家的旅途了。今年接收到那么多任务，剑士都一笔一划记在了小本本上，真得好好“谢谢”这位老人家。",
	StoryBundle = "packed_activity_2021springfestival",
	StoryAtlas = "2021SpringFestivalStory",
	StoryBG = "ActivityStory_2021SpringFestival_4",
	SupportLevel = 45,
	UnlockCostList = {
		{
			Value = 327304,
			Num = 45,
		},
	},
	RepeatCostList = {
		{
			Value = 2,
			Num = 200,
		},
	},
	Limit = 3,
	AcceptSpeech = 62000401,
	Desc = "不要气馁，继续前进！",
	ResultText = "章节4：再见，村长！已完成",
	Dialog = "路上一定要小心啊！",
	NumCap = 5,
	LevelBundle = "packed_eventthemebg",
	LevelAtlas = "EventThemeBG",
	LevelBG = "2021SpringFestivalBG01",
	StartScene = "2021SpringFestivalChallenge_StartScene",
	TeamCondition = {
		{
			Condition = "TeamCharacterIdAnd",
			Value = 
			{
				220003,
			},
			Desc = "队伍中必须有剑士",
			Hint = "队伍中必须有剑士",
		},
	},
	Enemy = {
		{
			Value = 241008,
			Level = 45,
		},
	},
	Reward = {
		{
			Value = 327306,
			Num = 300,
		},
	},
	RepeatReward = {
		{
			Value = 327306,
			Num = 50,
		},
	},
}
ActivityBattleConfig[ActivityBattleID.Id005] =
{
	Id = 5,
	Name = "章节5：此路是我开",
	IntroduceText = "剑士背上行囊，成为了返乡大队中的一员。本以为可以顺利回家，没想到却被沼泽树精拦住了去路。",
	StoryBundle = "packed_activity_2021springfestival",
	StoryAtlas = "2021SpringFestivalStory",
	StoryBG = "ActivityStory_2021SpringFestival_5",
	SupportLevel = 55,
	UnlockCostList = {
		{
			Value = 327304,
			Num = 60,
		},
	},
	RepeatCostList = {
		{
			Value = 2,
			Num = 200,
		},
	},
	Limit = 3,
	AcceptSpeech = 62000501,
	Desc = "不要气馁，继续前进！",
	ResultText = "章节5：此路是我开已完成",
	Dialog = "大侠饶命。",
	NumCap = 5,
	LevelBundle = "packed_eventthemebg",
	LevelAtlas = "EventThemeBG",
	LevelBG = "2021SpringFestivalBG01",
	StartScene = "2021SpringFestivalChallenge_StartScene",
	TeamCondition = {
		{
			Condition = "TeamCharacterIdAnd",
			Value = 
			{
				220003,
			},
			Desc = "队伍中必须有剑士",
			Hint = "队伍中必须有剑士",
		},
	},
	Enemy = {
		{
			Value = 241009,
			Level = 55,
		},
	},
	Reward = {
		{
			Value = 327306,
			Num = 300,
		},
	},
	RepeatReward = {
		{
			Value = 327306,
			Num = 50,
		},
	},
}
ActivityBattleConfig[ActivityBattleID.Id006] =
{
	Id = 6,
	Name = "章节6：出手相助",
	IntroduceText = "剑士打败树精，穿过布满荆棘的森林，来到航线的起点……似乎一切都很顺利啊。",
	StoryBundle = "packed_activity_2021springfestival",
	StoryAtlas = "2021SpringFestivalStory",
	StoryBG = "ActivityStory_2021SpringFestival_6",
	SupportLevel = 35,
	UnlockCostList = {
		{
			Value = 327304,
			Num = 60,
		},
	},
	RepeatCostList = {
		{
			Value = 2,
			Num = 200,
		},
	},
	Limit = 3,
	AcceptSpeech = 62000601,
	Desc = "不要气馁，继续前进！",
	ResultText = "章节6：出手相助已完成",
	Dialog = "我们再也不敢了。",
	NumCap = 5,
	LevelBundle = "packed_eventthemebg",
	LevelAtlas = "EventThemeBG",
	LevelBG = "2021SpringFestivalBG01",
	StartScene = "2021SpringFestivalChallenge_StartScene",
	TeamCondition = {
		{
			Condition = "TeamCharacterIdAnd",
			Value = 
			{
				220003,
			},
			Desc = "队伍中必须有剑士",
			Hint = "队伍中必须有剑士",
		},
	},
	Enemy = {
		{
			Value = 241010,
			Level = 35,
		},
		{
			Value = 241011,
			Level = 35,
		},
	},
	Reward = {
		{
			Value = 327306,
			Num = 300,
		},
	},
	RepeatReward = {
		{
			Value = 327306,
			Num = 50,
		},
	},
}
ActivityBattleConfig[ActivityBattleID.Id007] =
{
	Id = 7,
	Name = "章节7：身体检测",
	IntroduceText = "听了牧师的话，剑士急急忙忙去星际医院排号，然而医院门口，是无边无际的人海。",
	StoryBundle = "packed_activity_2021springfestival",
	StoryAtlas = "2021SpringFestivalStory",
	StoryBG = "ActivityStory_2021SpringFestival_7",
	SupportLevel = 60,
	UnlockCostList = {
		{
			Value = 327304,
			Num = 75,
		},
	},
	RepeatCostList = {
		{
			Value = 2,
			Num = 200,
		},
	},
	Limit = 3,
	AcceptSpeech = 62000701,
	Desc = "不要气馁，继续前进！",
	ResultText = "章节7：身体检测已完成",
	Dialog = "这次放过你，下次小心点！",
	NumCap = 5,
	LevelBundle = "packed_eventthemebg",
	LevelAtlas = "EventThemeBG",
	LevelBG = "2021SpringFestivalBG01",
	StartScene = "2021SpringFestivalChallenge_StartScene",
	TeamCondition = {
		{
			Condition = "TeamCharacterIdAnd",
			Value = 
			{
				220003,
			},
			Desc = "队伍中必须有剑士",
			Hint = "队伍中必须有剑士",
		},
	},
	Enemy = {
		{
			Value = 241012,
			Level = 60,
		},
	},
	Reward = {
		{
			Value = 327306,
			Num = 300,
		},
	},
	RepeatReward = {
		{
			Value = 327306,
			Num = 50,
		},
	},
}
ActivityBattleConfig[ActivityBattleID.Id008] =
{
	Id = 8,
	Name = "章节8：突遇抢劫",
	IntroduceText = "剑士得知回家无望，沮丧地提着行李回家。没想到，拿着大包小包的他，和别人撞了个满怀。",
	StoryBundle = "packed_activity_2021springfestival",
	StoryAtlas = "2021SpringFestivalStory",
	StoryBG = "ActivityStory_2021SpringFestival_8",
	SupportLevel = 60,
	UnlockCostList = {
		{
			Value = 327304,
			Num = 75,
		},
	},
	RepeatCostList = {
		{
			Value = 2,
			Num = 200,
		},
	},
	Limit = 3,
	AcceptSpeech = 62000801,
	Desc = "不要气馁，继续前进！",
	ResultText = "章节8：突遇抢劫已完成",
	Dialog = "我抗议！",
	NumCap = 5,
	LevelBundle = "packed_eventthemebg",
	LevelAtlas = "EventThemeBG",
	LevelBG = "2021SpringFestivalBG01",
	StartScene = "2021SpringFestivalChallenge_StartScene",
	TeamCondition = {
		{
			Condition = "TeamCharacterIdAnd",
			Value = 
			{
				220003,
			},
			Desc = "队伍中必须有剑士",
			Hint = "队伍中必须有剑士",
		},
	},
	Enemy = {
		{
			Value = 241013,
			Level = 60,
		},
	},
	Reward = {
		{
			Value = 327306,
			Num = 300,
		},
	},
	RepeatReward = {
		{
			Value = 327306,
			Num = 50,
		},
	},
}
ActivityBattleConfig[ActivityBattleID.Id009] =
{
	Id = 9,
	Name = "章节9：接受现实",
	IntroduceText = "剑士终于回到了家，接受了自己无法回家的现实，并决定给父母打一通电话。",
	StoryBundle = "packed_activity_2021springfestival",
	StoryAtlas = "2021SpringFestivalStory",
	StoryBG = "ActivityStory_2021SpringFestival_9",
	SupportLevel = 65,
	UnlockCostList = {
		{
			Value = 327304,
			Num = 90,
		},
	},
	RepeatCostList = {
		{
			Value = 2,
			Num = 200,
		},
	},
	Limit = 3,
	AcceptSpeech = 62000901,
	Desc = "不要气馁，继续前进！",
	ResultText = "章节9：接受现实已完成",
	Dialog = "你的通讯已恢复。",
	NumCap = 5,
	LevelBundle = "packed_eventthemebg",
	LevelAtlas = "EventThemeBG",
	LevelBG = "2021SpringFestivalBG01",
	StartScene = "2021SpringFestivalChallenge_StartScene",
	TeamCondition = {
		{
			Condition = "TeamCharacterIdAnd",
			Value = 
			{
				220003,
			},
			Desc = "队伍中必须有剑士",
			Hint = "队伍中必须有剑士",
		},
	},
	Enemy = {
		{
			Value = 241014,
			Level = 65,
		},
	},
	Reward = {
		{
			Value = 327306,
			Num = 300,
		},
	},
	RepeatReward = {
		{
			Value = 327306,
			Num = 50,
		},
	},
}
ActivityBattleConfig[ActivityBattleID.Id010] =
{
	Id = 10,
	Name = "章节10：大扫除，开始",
	IntroduceText = "为了迎接新年，一次彻底的大扫除是必不可少的。说来，魔法师能把房子变干净吗？要不要请她帮个忙呢？",
	StoryBundle = "packed_activity_2021springfestival",
	StoryAtlas = "2021SpringFestivalStory",
	StoryBG = "ActivityStory_2021SpringFestival_10",
	SupportLevel = 65,
	UnlockCostList = {
		{
			Value = 327304,
			Num = 90,
		},
	},
	RepeatCostList = {
		{
			Value = 2,
			Num = 200,
		},
	},
	Limit = 3,
	AcceptSpeech = 62001001,
	Desc = "不要气馁，继续前进！",
	ResultText = "章节10：大扫除，开始已完成",
	Dialog = "溜了溜了。",
	NumCap = 5,
	LevelBundle = "packed_eventthemebg",
	LevelAtlas = "EventThemeBG",
	LevelBG = "2021SpringFestivalBG01",
	StartScene = "2021SpringFestivalChallenge_StartScene",
	TeamCondition = {
		{
			Condition = "TeamCharacterIdAnd",
			Value = 
			{
				220003,
			},
			Desc = "队伍中必须有剑士",
			Hint = "队伍中必须有剑士",
		},
	},
	Enemy = {
		{
			Value = 241015,
			Level = 65,
		},
	},
	Reward = {
		{
			Value = 327306,
			Num = 300,
		},
	},
	RepeatReward = {
		{
			Value = 327306,
			Num = 50,
		},
	},
}
ActivityBattleConfig[ActivityBattleID.Id011] =
{
	Id = 11,
	Name = "章节11：囤积年货",
	IntroduceText = "打扫完房子，总觉得家里空荡荡的，出发去买一些年货回来吧。",
	StoryBundle = "packed_activity_2021springfestival",
	StoryAtlas = "2021SpringFestivalStory",
	StoryBG = "ActivityStory_2021SpringFestival_11",
	SupportLevel = 70,
	UnlockCostList = {
		{
			Value = 327305,
			Num = 10,
		},
	},
	RepeatCostList = {
		{
			Value = 2,
			Num = 200,
		},
	},
	Limit = 3,
	AcceptSpeech = 62001101,
	Desc = "不要气馁，继续前进！",
	ResultText = "章节11：囤积年货已完成",
	Dialog = "啊~~~~~~~~~",
	NumCap = 5,
	LevelBundle = "packed_eventthemebg",
	LevelAtlas = "EventThemeBG",
	LevelBG = "2021SpringFestivalBG01",
	StartScene = "2021SpringFestivalChallenge_StartScene",
	TeamCondition = {
		{
			Condition = "TeamCharacterIdAnd",
			Value = 
			{
				220003,
			},
			Desc = "队伍中必须有剑士",
			Hint = "队伍中必须有剑士",
		},
	},
	Enemy = {
		{
			Value = 241016,
			Level = 70,
		},
	},
	Reward = {
		{
			Value = 327306,
			Num = 300,
		},
	},
	RepeatReward = {
		{
			Value = 327306,
			Num = 50,
		},
	},
}
ActivityBattleConfig[ActivityBattleID.Id012] =
{
	Id = 12,
	Name = "章节12：亲戚来电",
	IntroduceText = "剑士置办完年货，一回家就收到了七大姑、八大姨的来电。",
	StoryBundle = "packed_activity_2021springfestival",
	StoryAtlas = "2021SpringFestivalStory",
	StoryBG = "ActivityStory_2021SpringFestival_12",
	SupportLevel = 70,
	UnlockCostList = {
		{
			Value = 327305,
			Num = 10,
		},
	},
	RepeatCostList = {
		{
			Value = 2,
			Num = 200,
		},
	},
	Limit = 3,
	AcceptSpeech = 62001201,
	Desc = "不要气馁，继续前进！",
	ResultText = "章节12：亲戚来电已完成",
	Dialog = "小剑剑长大了嘛。",
	NumCap = 5,
	LevelBundle = "packed_eventthemebg",
	LevelAtlas = "EventThemeBG",
	LevelBG = "2021SpringFestivalBG01",
	StartScene = "2021SpringFestivalChallenge_StartScene",
	TeamCondition = {
		{
			Condition = "TeamCharacterIdAnd",
			Value = 
			{
				220003,
			},
			Desc = "队伍中必须有剑士",
			Hint = "队伍中必须有剑士",
		},
	},
	Enemy = {
		{
			Value = 241017,
			Level = 70,
		},
		{
			Value = 241018,
			Level = 75,
		},
	},
	Reward = {
		{
			Value = 327306,
			Num = 300,
		},
	},
	RepeatReward = {
		{
			Value = 327306,
			Num = 50,
		},
	},
}
ActivityBattleConfig[ActivityBattleID.Id013] =
{
	Id = 13,
	Name = "章节13：弗兰辣椒",
	IntroduceText = "一年就要结束了，最后一次去外面下个馆子吧。最近又是打扫，又是置办年货，真是辛苦自己了。",
	StoryBundle = "packed_activity_2021springfestival",
	StoryAtlas = "2021SpringFestivalStory",
	StoryBG = "ActivityStory_2021SpringFestival_13",
	SupportLevel = 75,
	UnlockCostList = {
		{
			Value = 327305,
			Num = 18,
		},
	},
	RepeatCostList = {
		{
			Value = 2,
			Num = 200,
		},
	},
	Limit = 3,
	AcceptSpeech = 62001301,
	Desc = "不要气馁，继续前进！",
	ResultText = "章节13：弗兰辣椒已完成",
	Dialog = "不吃就不吃，干嘛打人。",
	NumCap = 5,
	LevelBundle = "packed_eventthemebg",
	LevelAtlas = "EventThemeBG",
	LevelBG = "2021SpringFestivalBG01",
	StartScene = "2021SpringFestivalChallenge_StartScene",
	TeamCondition = {
		{
			Condition = "TeamCharacterIdAnd",
			Value = 
			{
				220003,
			},
			Desc = "队伍中必须有剑士",
			Hint = "队伍中必须有剑士",
		},
	},
	Enemy = {
		{
			Value = 241019,
			Level = 75,
		},
	},
	Reward = {
		{
			Value = 327306,
			Num = 300,
		},
	},
	RepeatReward = {
		{
			Value = 327306,
			Num = 50,
		},
	},
}
ActivityBattleConfig[ActivityBattleID.Id014] =
{
	Id = 14,
	Name = "章节14：做年夜饭",
	IntroduceText = "终于到了美好的除夕夜，虽然爸爸妈妈不在，但剑士邀请了魔法师、呜呜和漆漆一起来家里做年夜饭，也不会觉得孤单。",
	StoryBundle = "packed_activity_2021springfestival",
	StoryAtlas = "2021SpringFestivalStory",
	StoryBG = "ActivityStory_2021SpringFestival_14",
	SupportLevel = 80,
	UnlockCostList = {
		{
			Value = 327305,
			Num = 18,
		},
	},
	RepeatCostList = {
		{
			Value = 2,
			Num = 100,
		},
	},
	Limit = 3,
	AcceptSpeech = 62001401,
	Desc = "不要气馁，继续前进！",
	ResultText = "章节14：做年夜饭已完成",
	Dialog = "呼呼呼！",
	NumCap = 5,
	LevelBundle = "packed_eventthemebg",
	LevelAtlas = "EventThemeBG",
	LevelBG = "2021SpringFestivalBG01",
	StartScene = "2021SpringFestivalChallenge_StartScene",
	TeamCondition = {
		{
			Condition = "TeamCharacterIdAnd",
			Value = 
			{
				220003,
			},
			Desc = "队伍中必须有剑士",
			Hint = "队伍中必须有剑士",
		},
	},
	Enemy = {
		{
			Value = 241020,
			Level = 80,
		},
	},
	Reward = {
		{
			Value = 327306,
			Num = 300,
		},
	},
	RepeatReward = {
		{
			Value = 327306,
			Num = 50,
		},
	},
}
ActivityBattleConfig[ActivityBattleID.Id015] =
{
	Id = 15,
	Name = "章节15：不如叫外卖",
	IntroduceText = "经过火烧厨房后，剑士和魔法师一致决定，还是点一份星际外卖吧。",
	StoryBundle = "packed_activity_2021springfestival",
	StoryAtlas = "2021SpringFestivalStory",
	StoryBG = "ActivityStory_2021SpringFestival_15",
	SupportLevel = 80,
	UnlockCostList = {
		{
			Value = 327305,
			Num = 25,
		},
	},
	RepeatCostList = {
		{
			Value = 2,
			Num = 100,
		},
	},
	Limit = 3,
	AcceptSpeech = 62001501,
	Desc = "不要气馁，继续前进！",
	ResultText = "章节15：不如叫外卖已完成",
	Dialog = "哈咻哈咻。",
	NumCap = 5,
	LevelBundle = "packed_eventthemebg",
	LevelAtlas = "EventThemeBG",
	LevelBG = "2021SpringFestivalBG01",
	StartScene = "2021SpringFestivalChallenge_StartScene",
	TeamCondition = {
		{
			Condition = "TeamCharacterIdAnd",
			Value = 
			{
				220003,
			},
			Desc = "队伍中必须有剑士",
			Hint = "队伍中必须有剑士",
		},
	},
	Enemy = {
		{
			Value = 241021,
			Level = 80,
		},
	},
	Reward = {
		{
			Value = 327306,
			Num = 300,
		},
	},
	RepeatReward = {
		{
			Value = 327306,
			Num = 50,
		},
	},
}
ActivityBattleConfig[ActivityBattleID.Id016] =
{
	Id = 16,
	Name = "章节16：噼里啪啦",
	IntroduceText = "新年第一天，原计划是睡到自然醒，可没想到被隔壁的鞭炮声吵醒了。",
	StoryBundle = "packed_activity_2021springfestival",
	StoryAtlas = "2021SpringFestivalStory",
	StoryBG = "ActivityStory_2021SpringFestival_16",
	SupportLevel = 85,
	UnlockCostList = {
		{
			Value = 327305,
			Num = 25,
		},
	},
	RepeatCostList = {
		{
			Value = 2,
			Num = 100,
		},
	},
	Limit = 1,
	AcceptSpeech = 62001601,
	Desc = "不要气馁，继续前进！",
	ResultText = "章节16：噼里啪啦已完成",
	Dialog = "呜呜呜，妈妈，有人打我！",
	NumCap = 5,
	LevelBundle = "packed_eventthemebg",
	LevelAtlas = "EventThemeBG",
	LevelBG = "2021SpringFestivalBG01",
	StartScene = "2021SpringFestivalChallenge_StartScene",
	TeamCondition = {
		{
			Condition = "TeamCharacterIdAnd",
			Value = 
			{
				220003,
			},
			Desc = "队伍中必须有剑士",
			Hint = "队伍中必须有剑士",
		},
	},
	Enemy = {
		{
			Value = 241022,
			Level = 85,
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 100,
		},
	},
}
ActivityBattleConfig[ActivityBattleID.Id017] =
{
	Id = 17,
	Name = "章节17：看望旧友",
	IntroduceText = "剑士从亲戚口中得知，小时候的伙伴也在这座城市，虽多年不曾联系，但还是想去看看他。",
	StoryBundle = "packed_activity_2021springfestival",
	StoryAtlas = "2021SpringFestivalStory",
	StoryBG = "ActivityStory_2021SpringFestival_17",
	SupportLevel = 85,
	UnlockCostList = {
		{
			Value = 327305,
			Num = 32,
		},
	},
	RepeatCostList = {
		{
			Value = 2,
			Num = 100,
		},
	},
	Limit = 1,
	AcceptSpeech = 62001701,
	Desc = "不要气馁，继续前进！",
	ResultText = "章节17：看望旧友已完成",
	Dialog = "想不到破了我的醉拳。",
	NumCap = 5,
	LevelBundle = "packed_eventthemebg",
	LevelAtlas = "EventThemeBG",
	LevelBG = "2021SpringFestivalBG01",
	StartScene = "2021SpringFestivalChallenge_StartScene",
	TeamCondition = {
		{
			Condition = "TeamCharacterIdAnd",
			Value = 
			{
				220003,
			},
			Desc = "队伍中必须有剑士",
			Hint = "队伍中必须有剑士",
		},
	},
	Enemy = {
		{
			Value = 241023,
			Level = 85,
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 200,
		},
	},
}
ActivityBattleConfig[ActivityBattleID.Id018] =
{
	Id = 18,
	Name = "章节18：梦中的未来",
	IntroduceText = "似乎喝得有点多，剑士早早沉入了梦境，在梦里，他看到了未来的自己。",
	StoryBundle = "packed_activity_2021springfestival",
	StoryAtlas = "2021SpringFestivalStory",
	StoryBG = "ActivityStory_2021SpringFestival_18",
	SupportLevel = 90,
	UnlockCostList = {
		{
			Value = 327305,
			Num = 32,
		},
	},
	RepeatCostList = {
		{
			Value = 2,
			Num = 100,
		},
	},
	Limit = 1,
	AcceptSpeech = 62001801,
	Desc = "不要气馁，继续前进！",
	ResultText = "章节18：梦中的未来已完成",
	Dialog = "继续前进吧，少年！",
	NumCap = 5,
	LevelBundle = "packed_eventthemebg",
	LevelAtlas = "EventThemeBG",
	LevelBG = "2021SpringFestivalBG01",
	StartScene = "2021SpringFestivalChallenge_StartScene",
	TeamCondition = {
		{
			Condition = "TeamCharacterIdAnd",
			Value = 
			{
				220003,
			},
			Desc = "队伍中必须有剑士",
			Hint = "队伍中必须有剑士",
		},
	},
	Enemy = {
		{
			Value = 241024,
			Level = 90,
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 300,
		},
	},
}
ActivityBattleConfig[ActivityBattleID.Id019] =
{
	Id = 19,
	Name = "章节19：远方的温暖",
	IntroduceText = "对于剑士来说，又是百无聊赖的一天。突然门铃一响，一大箱快递映入眼帘。是谁送的呢？",
	StoryBundle = "packed_activity_2021springfestival",
	StoryAtlas = "2021SpringFestivalStory",
	StoryBG = "ActivityStory_2021SpringFestival_19",
	SupportLevel = 90,
	UnlockCostList = {
		{
			Value = 327305,
			Num = 40,
		},
	},
	RepeatCostList = {
		{
			Value = 2,
			Num = 100,
		},
	},
	Limit = 1,
	AcceptSpeech = 62001901,
	Desc = "不要气馁，继续前进！",
	ResultText = "章节19：远方的温暖已完成",
	Dialog = "没事的，孩子。",
	NumCap = 5,
	LevelBundle = "packed_eventthemebg",
	LevelAtlas = "EventThemeBG",
	LevelBG = "2021SpringFestivalBG01",
	StartScene = "2021SpringFestivalChallenge_StartScene",
	TeamCondition = {
		{
			Condition = "TeamCharacterIdAnd",
			Value = 
			{
				220003,
			},
			Desc = "队伍中必须有剑士",
			Hint = "队伍中必须有剑士",
		},
	},
	Enemy = {
		{
			Value = 241025,
			Level = 90,
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 400,
		},
	},
}
ActivityBattleConfig[ActivityBattleID.Id020] =
{
	Id = 20,
	Name = "章节20：美丽新征途",
	IntroduceText = "一转眼，假期就要结束了，剑士整理好心情，和过去的自己说了再见，踏上全新的旅途。",
	StoryBundle = "packed_activity_2021springfestival",
	StoryAtlas = "2021SpringFestivalStory",
	StoryBG = "ActivityStory_2021SpringFestival_20",
	SupportLevel = 95,
	UnlockCostList = {
		{
			Value = 327305,
			Num = 40,
		},
	},
	RepeatCostList = {
		{
			Value = 2,
			Num = 100,
		},
	},
	Limit = 1,
	AcceptSpeech = 62002001,
	Desc = "不要气馁，继续前进！",
	ResultText = "章节20：美丽新征途已完成",
	Dialog = "嗯，新的一年！",
	NumCap = 5,
	LevelBundle = "packed_eventthemebg",
	LevelAtlas = "EventThemeBG",
	LevelBG = "2021SpringFestivalBG01",
	StartScene = "2021SpringFestivalChallenge_StartScene",
	TeamCondition = {
		{
			Condition = "TeamCharacterIdAnd",
			Value = 
			{
				220003,
			},
			Desc = "队伍中必须有剑士",
			Hint = "队伍中必须有剑士",
		},
	},
	Enemy = {
		{
			Value = 241026,
			Level = 95,
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 500,
		},
	},
}
ActivityBattleConfig[ActivityBattleID.Id021] =
{
	Id = 21,
	Name = "章节1：初入山谷",
	IntroduceText = "到了一年一度的星际冒险节，冒险小队成功报上了名，兴高采烈地走进宝箱山谷。只有村长，看着“山谷集邮”的任务，陷入了沉思……",
	StoryBundle = "packed_activity_staradventure",
	StoryAtlas = "StarAdventureStory",
	StoryBG = "ActivityStory_StarAdventure_1",
	SupportLevel = 15,
	UnlockCostList = {
		{
			Value = 320402,
			Num = 10,
		},
	},
	RepeatCostList = {
		{
			Value = 2,
			Num = 200,
		},
	},
	Limit = 1,
	AcceptSpeech = 62002101,
	Desc = "不要气馁，继续前进！",
	ResultText = "章节1：初入山谷已完成",
	Dialog = "大哥！别丢下我一个！",
	NumCap = 5,
	LevelBundle = "packed_eventthemebg",
	LevelAtlas = "EventThemeBG",
	LevelBG = "StarAdventureBG01",
	StartScene = "RPG_StartScene",
	TeamCondition = {
		{
			Condition = "NeedTagAnd",
			Value = 
			{
				560103,
			},
			Desc = "必须是冒险星的队员",
			Hint = "必须是冒险星的队员",
		},
	},
	Enemy = {
		{
			Value = 241027,
			Level = 15,
		},
	},
	Reward = {
		{
			Value = 330003,
			Num = 1,
		},
	},
}
ActivityBattleConfig[ActivityBattleID.Id022] =
{
	Id = 22,
	Name = "章节2：苦瓜汁挑战",
	IntroduceText = "摆脱了山谷商人，冒险小队马不停蹄地赶往下一个地方。在第二个集邮点等待他们的是叶姬小姐，她说，只有每人喝一杯苦瓜汁，她才会为大家盖章。",
	StoryBundle = "packed_activity_staradventure",
	StoryAtlas = "StarAdventureStory",
	StoryBG = "ActivityStory_StarAdventure_2",
	SupportLevel = 20,
	UnlockCostList = {
		{
			Value = 320402,
			Num = 15,
		},
	},
	RepeatCostList = {
		{
			Value = 2,
			Num = 200,
		},
	},
	Limit = 1,
	AcceptSpeech = 62002201,
	Desc = "不要气馁，继续前进！",
	ResultText = "章节2：苦瓜汁挑战已完成",
	Dialog = "喖，碰上硬茬了。",
	NumCap = 5,
	LevelBundle = "packed_eventthemebg",
	LevelAtlas = "EventThemeBG",
	LevelBG = "StarAdventureBG01",
	StartScene = "RPG_StartScene",
	TeamCondition = {
		{
			Condition = "NeedTagAnd",
			Value = 
			{
				560103,
			},
			Desc = "必须是冒险星的队员",
			Hint = "必须是冒险星的队员",
		},
	},
	Enemy = {
		{
			Value = 241028,
			Level = 20,
		},
	},
	Reward = {
		{
			Value = 330003,
			Num = 1,
		},
	},
}
ActivityBattleConfig[ActivityBattleID.Id023] =
{
	Id = 23,
	Name = "章节3：排队盖章",
	IntroduceText = "冒险小队抵达第三个集邮点，这里的NPC是木制宝箱怪。据说木制宝箱怪非常友善、温和，会给每一支排队的队伍盖章，从不刁难大家。然而，却有人突然插队……",
	StoryBundle = "packed_activity_staradventure",
	StoryAtlas = "StarAdventureStory",
	StoryBG = "ActivityStory_StarAdventure_3",
	SupportLevel = 25,
	UnlockCostList = {
		{
			Value = 327301,
			Num = 15,
		},
	},
	RepeatCostList = {
		{
			Value = 2,
			Num = 200,
		},
	},
	Limit = 1,
	AcceptSpeech = 62002301,
	Desc = "不要气馁，继续前进！",
	ResultText = "章节3：排队盖章已完成",
	Dialog = "就说什么都没有啦！",
	NumCap = 5,
	LevelBundle = "packed_eventthemebg",
	LevelAtlas = "EventThemeBG",
	LevelBG = "StarAdventureBG01",
	StartScene = "RPG_StartScene",
	TeamCondition = {
		{
			Condition = "NeedTagAnd",
			Value = 
			{
				560103,
			},
			Desc = "必须是冒险星的队员",
			Hint = "必须是冒险星的队员",
		},
	},
	Enemy = {
		{
			Value = 241029,
			Level = 25,
		},
	},
	Reward = {
		{
			Value = 330003,
			Num = 2,
		},
	},
}
ActivityBattleConfig[ActivityBattleID.Id024] =
{
	Id = 24,
	Name = "章节4：小龙人快跑",
	IntroduceText = "第四个集邮点的工作人员提出，如果要获得新的印章，需要玩一个小游戏：队伍中任意一位男生，在三十秒之内，背着一位女生绕店铺跑一圈。",
	StoryBundle = "packed_activity_staradventure",
	StoryAtlas = "StarAdventureStory",
	StoryBG = "ActivityStory_StarAdventure_4",
	SupportLevel = 30,
	UnlockCostList = {
		{
			Value = 327301,
			Num = 15,
		},
	},
	RepeatCostList = {
		{
			Value = 2,
			Num = 200,
		},
	},
	Limit = 1,
	AcceptSpeech = 62002401,
	Desc = "不要气馁，继续前进！",
	ResultText = "章节4：小龙人快跑已完成",
	Dialog = "想不到我有血光之灾…",
	NumCap = 5,
	LevelBundle = "packed_eventthemebg",
	LevelAtlas = "EventThemeBG",
	LevelBG = "StarAdventureBG01",
	StartScene = "RPG_StartScene",
	TeamCondition = {
		{
			Condition = "NeedTagAnd",
			Value = 
			{
				560103,
			},
			Desc = "必须是冒险星的队员",
			Hint = "必须是冒险星的队员",
		},
	},
	Enemy = {
		{
			Value = 241030,
			Level = 30,
		},
	},
	Reward = {
		{
			Value = 330003,
			Num = 2,
		},
	},
}
ActivityBattleConfig[ActivityBattleID.Id025] =
{
	Id = 25,
	Name = "章节5：绕口令挑战",
	IntroduceText = "终于到了第五个集邮点！这里的负责人是一只粉色的史莱姆，史莱姆表示，只要你们能说出一段绕口令，我就帮你们盖章。",
	StoryBundle = "packed_activity_staradventure",
	StoryAtlas = "StarAdventureStory",
	StoryBG = "ActivityStory_StarAdventure_5",
	SupportLevel = 35,
	UnlockCostList = {
		{
			Value = 327301,
			Num = 20,
		},
	},
	RepeatCostList = {
		{
			Value = 2,
			Num = 200,
		},
	},
	Limit = 1,
	AcceptSpeech = 62002501,
	Desc = "不要气馁，继续前进！",
	ResultText = "章节5：绕口令挑战已完成",
	Dialog = "哼，坏人！",
	NumCap = 5,
	LevelBundle = "packed_eventthemebg",
	LevelAtlas = "EventThemeBG",
	LevelBG = "StarAdventureBG01",
	StartScene = "RPG_StartScene",
	TeamCondition = {
		{
			Condition = "NeedTagAnd",
			Value = 
			{
				560103,
			},
			Desc = "必须是冒险星的队员",
			Hint = "必须是冒险星的队员",
		},
	},
	Enemy = {
		{
			Value = 241031,
			Level = 35,
		},
	},
	Reward = {
		{
			Value = 330003,
			Num = 3,
		},
	},
}
ActivityBattleConfig[ActivityBattleID.Id026] =
{
	Id = 26,
	Name = "章节6：剪刀石头布",
	IntroduceText = "第六个集邮点，在一个简陋的房间，房间中只有一个奇怪的宝箱，大声嚷嚷着要玩剪刀石头布……",
	StoryBundle = "packed_activity_staradventure",
	StoryAtlas = "StarAdventureStory",
	StoryBG = "ActivityStory_StarAdventure_6",
	SupportLevel = 40,
	UnlockCostList = {
		{
			Value = 327301,
			Num = 20,
		},
	},
	RepeatCostList = {
		{
			Value = 2,
			Num = 200,
		},
	},
	Limit = 1,
	AcceptSpeech = 62002601,
	Desc = "不要气馁，继续前进！",
	ResultText = "章节6：剪刀石头布已完成",
	Dialog = "_(¦3」)_",
	NumCap = 5,
	LevelBundle = "packed_eventthemebg",
	LevelAtlas = "EventThemeBG",
	LevelBG = "StarAdventureBG01",
	StartScene = "RPG_StartScene",
	TeamCondition = {
		{
			Condition = "NeedTagAnd",
			Value = 
			{
				560103,
			},
			Desc = "必须是冒险星的队员",
			Hint = "必须是冒险星的队员",
		},
	},
	Enemy = {
		{
			Value = 241032,
			Level = 40,
		},
	},
	Reward = {
		{
			Value = 330003,
			Num = 3,
		},
	},
}
ActivityBattleConfig[ActivityBattleID.Id027] =
{
	Id = 27,
	Name = "章节7：夹住史莱姆",
	IntroduceText = "冒险小队来到第七个地点，这里有许多史莱姆。听其中一个说，只要能用筷子成功将一只史莱姆夹起来，放入碗里，就算成功。",
	StoryBundle = "packed_activity_staradventure",
	StoryAtlas = "StarAdventureStory",
	StoryBG = "ActivityStory_StarAdventure_7",
	SupportLevel = 45,
	UnlockCostList = {
		{
			Value = 327301,
			Num = 25,
		},
	},
	RepeatCostList = {
		{
			Value = 2,
			Num = 200,
		},
	},
	Limit = 1,
	AcceptSpeech = 62002701,
	Desc = "不要气馁，继续前进！",
	ResultText = "章节7：夹住史莱姆已完成",
	Dialog = "遇到群暴力开箱的了…",
	NumCap = 5,
	LevelBundle = "packed_eventthemebg",
	LevelAtlas = "EventThemeBG",
	LevelBG = "StarAdventureBG01",
	StartScene = "RPG_StartScene",
	TeamCondition = {
		{
			Condition = "NeedTagAnd",
			Value = 
			{
				560103,
			},
			Desc = "必须是冒险星的队员",
			Hint = "必须是冒险星的队员",
		},
	},
	Enemy = {
		{
			Value = 241033,
			Level = 45,
		},
	},
	Reward = {
		{
			Value = 330003,
			Num = 4,
		},
	},
}
ActivityBattleConfig[ActivityBattleID.Id028] =
{
	Id = 28,
	Name = "章节8：堆叠史莱姆",
	IntroduceText = "第八个集邮点内，依然有数不尽的史莱姆。而冒险小队的新任务，就是将房间中的史莱姆堆叠起来，如果成功堆叠到三十层，就能获得第八个印章。",
	StoryBundle = "packed_activity_staradventure",
	StoryAtlas = "StarAdventureStory",
	StoryBG = "ActivityStory_StarAdventure_8",
	SupportLevel = 50,
	UnlockCostList = {
		{
			Value = 327302,
			Num = 10,
		},
	},
	RepeatCostList = {
		{
			Value = 2,
			Num = 200,
		},
	},
	Limit = 1,
	AcceptSpeech = 62002801,
	Desc = "不要气馁，继续前进！",
	ResultText = "章节8：堆叠史莱姆已完成",
	Dialog = "愿圣光与你同在！",
	NumCap = 5,
	LevelBundle = "packed_eventthemebg",
	LevelAtlas = "EventThemeBG",
	LevelBG = "StarAdventureBG01",
	StartScene = "RPG_StartScene",
	TeamCondition = {
		{
			Condition = "NeedTagAnd",
			Value = 
			{
				560103,
			},
			Desc = "必须是冒险星的队员",
			Hint = "必须是冒险星的队员",
		},
	},
	Enemy = {
		{
			Value = 241034,
			Level = 50,
		},
		{
			Value = 241035,
			Level = 50,
		},
		{
			Value = 241036,
			Level = 50,
		},
	},
	Reward = {
		{
			Value = 330003,
			Num = 4,
		},
	},
}
ActivityBattleConfig[ActivityBattleID.Id029] =
{
	Id = 29,
	Name = "章节9：集邮完成",
	IntroduceText = "只剩最后一个集邮点，冒险小队连忙赶去最后一个小屋……小屋的主人是传说中的传奇宝箱怪，史诗宝箱要求他们给自己讲一个史诗级笑话，如果成功逗笑了自己，就给大家盖章。",
	StoryBundle = "packed_activity_staradventure",
	StoryAtlas = "StarAdventureStory",
	StoryBG = "ActivityStory_StarAdventure_9",
	SupportLevel = 55,
	UnlockCostList = {
		{
			Value = 327302,
			Num = 15,
		},
	},
	RepeatCostList = {
		{
			Value = 2,
			Num = 200,
		},
	},
	Limit = 1,
	AcceptSpeech = 62002901,
	Desc = "不要气馁，继续前进！",
	ResultText = "章节9：集邮完成已完成",
	Dialog = "计划失败，溜了！",
	NumCap = 5,
	LevelBundle = "packed_eventthemebg",
	LevelAtlas = "EventThemeBG",
	LevelBG = "StarAdventureBG01",
	StartScene = "RPG_StartScene",
	TeamCondition = {
		{
			Condition = "NeedTagAnd",
			Value = 
			{
				560103,
			},
			Desc = "必须是冒险星的队员",
			Hint = "必须是冒险星的队员",
		},
	},
	Enemy = {
		{
			Value = 241037,
			Level = 55,
		},
	},
	Reward = {
		{
			Value = 330003,
			Num = 5,
		},
	},
}
ActivityBattleConfig[ActivityBattleID.Id030] =
{
	Id = 30,
	Name = "章节10：兑换奖品",
	IntroduceText = "集齐了所有印章，冒险小队兴高采烈地去兑换奖品，然而兑换出来的礼物，却让他们大跌眼镜。",
	StoryBundle = "packed_activity_staradventure",
	StoryAtlas = "StarAdventureStory",
	StoryBG = "ActivityStory_StarAdventure_10",
	SupportLevel = 60,
	UnlockCostList = {
		{
			Value = 327302,
			Num = 20,
		},
	},
	RepeatCostList = {
		{
			Value = 2,
			Num = 200,
		},
	},
	Limit = 1,
	AcceptSpeech = 62003001,
	Desc = "不要气馁，继续前进！",
	ResultText = "章节10：兑换奖品已完成",
	Dialog = "别——给你200玉——",
	NumCap = 5,
	LevelBundle = "packed_eventthemebg",
	LevelAtlas = "EventThemeBG",
	LevelBG = "StarAdventureBG01",
	StartScene = "RPG_StartScene",
	TeamCondition = {
		{
			Condition = "NeedTagAnd",
			Value = 
			{
				560103,
			},
			Desc = "必须是冒险星的队员",
			Hint = "必须是冒险星的队员",
		},
	},
	Enemy = {
		{
			Value = 241038,
			Level = 60,
		},
	},
	Reward = {
		{
			Value = 330003,
			Num = 5,
		},
	},
}
ActivityBattleConfig[ActivityBattleID.Id031] =
{
	Id = 31,
	Name = "章节1：蹭热点",
	IntroduceText = "美食星的汽水王子，收到了一份“黑暗料理试胆大会”的邀请函，据说，届时将有宇宙电视台前来拍摄。为了宣传自己的广告和代言，他决定拉上自己的三位兄弟，踏上前往流亡街的旅程。",
	StoryBundle = "packed_activity_darkfoodfestival",
	StoryAtlas = "DarkFoodFestivalStory",
	StoryBG = "ActivityStory_DarkFoodFestival_1",
	SupportLevel = 15,
	UnlockCostList = {
		{
			Value = 320406,
			Num = 3,
		},
	},
	RepeatCostList = {
		{
			Value = 2,
			Num = 200,
		},
	},
	Limit = 1,
	AcceptSpeech = 62003101,
	Desc = "薯条国王御用侍卫，是国王最放心的部下与伙伴。",
	ResultText = "章节1：蹭热点已完成",
	Dialog = "王子们，不能去啊……",
	NumCap = 5,
	LevelBundle = "packed_eventthemebg",
	LevelAtlas = "EventThemeBG",
	LevelBG = "DarkFoodFestivalBG01",
	StartScene = "DarkFoodFestivalChallenge_StartScene",
	Enemy = {
		{
			Value = 241039,
			Level = 15,
		},
	},
	Reward = {
		{
			Value = 330003,
			Num = 1,
		},
	},
}
ActivityBattleConfig[ActivityBattleID.Id032] =
{
	Id = 32,
	Name = "章节2：保镖已就位",
	IntroduceText = "汽水王子冷静思考后，认为自己与另外三个不靠谱的兄弟去试胆大会并不安全，于是在流亡街向全宇宙发出保镖征集令，每队临时保镖可以获得9999999玉璧的大礼。果然，来报名的人源源不断……",
	StoryBundle = "packed_activity_darkfoodfestival",
	StoryAtlas = "DarkFoodFestivalStory",
	StoryBG = "ActivityStory_DarkFoodFestival_2",
	SupportLevel = 20,
	UnlockCostList = {
		{
			Value = 320406,
			Num = 5,
		},
	},
	RepeatCostList = {
		{
			Value = 2,
			Num = 200,
		},
	},
	Limit = 1,
	AcceptSpeech = 62003201,
	Desc = "来自不知名星球的冒险者，为获得保镖工资，花费了999玉璧乘坐飞船而来。",
	ResultText = "章节2：保镖已就位已完成",
	Dialog = "你们……以多欺少！",
	NumCap = 5,
	LevelBundle = "packed_eventthemebg",
	LevelAtlas = "EventThemeBG",
	LevelBG = "DarkFoodFestivalBG01",
	StartScene = "DarkFoodFestivalChallenge_StartScene",
	Enemy = {
		{
			Value = 241040,
			Level = 20,
		},
	},
	Reward = {
		{
			Value = 330003,
			Num = 1,
		},
	},
}
ActivityBattleConfig[ActivityBattleID.Id033] =
{
	Id = 33,
	Name = "章节3：了解规则",
	IntroduceText = "汽水王子带领众人到达试胆大会现场，每个摊位上都有一架专属摄影机，为了让自己完美出镜，汽水王子支开了大家，自己挤到摊位旁边。然而，还没来得及摆出pose，顶着一头奇怪卷发的摊主就叫住了他。",
	StoryBundle = "packed_activity_darkfoodfestival",
	StoryAtlas = "DarkFoodFestivalStory",
	StoryBG = "ActivityStory_DarkFoodFestival_3",
	SupportLevel = 25,
	UnlockCostList = {
		{
			Value = 327307,
			Num = 5,
		},
	},
	RepeatCostList = {
		{
			Value = 2,
			Num = 200,
		},
	},
	Limit = 1,
	AcceptSpeech = 62003301,
	Desc = "出生于养生世家，曾获泡面养生大赛一等奖。",
	ResultText = "章节3：了解规则已完成",
	Dialog = "这是最养生的泡面了。",
	NumCap = 5,
	LevelBundle = "packed_eventthemebg",
	LevelAtlas = "EventThemeBG",
	LevelBG = "DarkFoodFestivalBG01",
	StartScene = "DarkFoodFestivalChallenge_StartScene",
	Enemy = {
		{
			Value = 241041,
			Level = 25,
		},
	},
	Reward = {
		{
			Value = 330003,
			Num = 2,
		},
	},
}
ActivityBattleConfig[ActivityBattleID.Id034] =
{
	Id = 34,
	Name = "章节4：加入美食星",
	IntroduceText = "汽水王子强装镇定，向大部队方向走了过去，没想到两个家伙挡住了他的去路，还一直嚷嚷着要加入美食星……一心想回归大部队的王子不禁怒从中来。",
	StoryBundle = "packed_activity_darkfoodfestival",
	StoryAtlas = "DarkFoodFestivalStory",
	StoryBG = "ActivityStory_DarkFoodFestival_4",
	SupportLevel = 30,
	UnlockCostList = {
		{
			Value = 327307,
			Num = 8,
		},
	},
	RepeatCostList = {
		{
			Value = 2,
			Num = 200,
		},
	},
	Limit = 1,
	AcceptSpeech = 62003401,
	Desc = "臭豆腐兄弟，为了成功移民美食星付出了巨大努力。",
	ResultText = "章节4：加入美食星已完成",
	Dialog = "我们还有机会吗？",
	NumCap = 5,
	LevelBundle = "packed_eventthemebg",
	LevelAtlas = "EventThemeBG",
	LevelBG = "DarkFoodFestivalBG01",
	StartScene = "DarkFoodFestivalChallenge_StartScene",
	Enemy = {
		{
			Value = 241042,
			Level = 30,
		},
		{
			Value = 241043,
			Level = 30,
		},
	},
	Reward = {
		{
			Value = 330003,
			Num = 2,
		},
	},
}
ActivityBattleConfig[ActivityBattleID.Id035] =
{
	Id = 35,
	Name = "章节5：剑士！用力！",
	IntroduceText = "回到大部队的汽水王子再也不敢轻举妄动，只有小心翼翼地拉着兄弟们，走到下一个摊位。看样子，这次需要吃一块圆圆的、坚硬的，类似面包的东西？",
	StoryBundle = "packed_activity_darkfoodfestival",
	StoryAtlas = "DarkFoodFestivalStory",
	StoryBG = "ActivityStory_DarkFoodFestival_5",
	SupportLevel = 35,
	UnlockCostList = {
		{
			Value = 327307,
			Num = 12,
		},
	},
	RepeatCostList = {
		{
			Value = 2,
			Num = 200,
		},
	},
	Limit = 1,
	AcceptSpeech = 62003501,
	Desc = "非常坚硬的面包，但还是敌不过剑士祖传的大宝剑啊。",
	ResultText = "章节5：剑士！用力！已完成",
	Dialog = "呜！好疼……",
	NumCap = 5,
	LevelBundle = "packed_eventthemebg",
	LevelAtlas = "EventThemeBG",
	LevelBG = "DarkFoodFestivalBG01",
	StartScene = "DarkFoodFestivalChallenge_StartScene",
	Enemy = {
		{
			Value = 241044,
			Level = 35,
		},
	},
	Reward = {
		{
			Value = 330003,
			Num = 3,
		},
	},
}
ActivityBattleConfig[ActivityBattleID.Id036] =
{
	Id = 36,
	Name = "章节6：神奇的魔法",
	IntroduceText = "虽然门牙被磕掉，但剑士的表现令王子们非常满意，一行人来到下个摊位。还未靠近，就看到有人一边吐一边跑出来……王子们疑惑之际，远远看见摊主带着神秘的笑容，拿出了一个饭盒。",
	StoryBundle = "packed_activity_darkfoodfestival",
	StoryAtlas = "DarkFoodFestivalStory",
	StoryBG = "ActivityStory_DarkFoodFestival_6",
	SupportLevel = 40,
	UnlockCostList = {
		{
			Value = 327307,
			Num = 16,
		},
	},
	RepeatCostList = {
		{
			Value = 2,
			Num = 200,
		},
	},
	Limit = 1,
	AcceptSpeech = 62003601,
	Desc = "虽然知道自己的饭团不好闻，但还是坚持了下来。",
	ResultText = "章节6：神奇的魔法已完成",
	Dialog = "唔，习惯就好……",
	NumCap = 5,
	LevelBundle = "packed_eventthemebg",
	LevelAtlas = "EventThemeBG",
	LevelBG = "DarkFoodFestivalBG01",
	StartScene = "DarkFoodFestivalChallenge_StartScene",
	Enemy = {
		{
			Value = 241045,
			Level = 40,
		},
	},
	Reward = {
		{
			Value = 330003,
			Num = 3,
		},
	},
}
ActivityBattleConfig[ActivityBattleID.Id037] =
{
	Id = 37,
	Name = "章节7：猫咪咖啡",
	IntroduceText = "在魔法师的帮助下，四位王子在鲱鱼饭团的气味攻击中顺利存活，正要去下一个摊位时，突然见到摊主跑了过来，热情地抱住了两只小猫。更加可喜的是，摄像机也随之而来……",
	StoryBundle = "packed_activity_darkfoodfestival",
	StoryAtlas = "DarkFoodFestivalStory",
	StoryBG = "ActivityStory_DarkFoodFestival_7",
	SupportLevel = 45,
	UnlockCostList = {
		{
			Value = 327307,
			Num = 20,
		},
	},
	RepeatCostList = {
		{
			Value = 2,
			Num = 200,
		},
	},
	Limit = 1,
	AcceptSpeech = 62003701,
	Desc = "为了做出正宗的咖啡，会诱骗小猫吃下特制咖啡豆生产原料。",
	ResultText = "章节7：猫咪咖啡已完成",
	Dialog = "不喝就不喝，别打人嘛～",
	NumCap = 5,
	LevelBundle = "packed_eventthemebg",
	LevelAtlas = "EventThemeBG",
	LevelBG = "DarkFoodFestivalBG01",
	StartScene = "DarkFoodFestivalChallenge_StartScene",
	Enemy = {
		{
			Value = 241046,
			Level = 45,
		},
	},
	Reward = {
		{
			Value = 330003,
			Num = 4,
		},
	},
}
ActivityBattleConfig[ActivityBattleID.Id038] =
{
	Id = 38,
	Name = "章节8：猎人的勇气",
	IntroduceText = "这个摊位的摊主是辣辣子，据说将要挑战全宇宙最辣的辣椒。看到摊主火热的红发，王子们齐刷刷地看向了猎人……",
	StoryBundle = "packed_activity_darkfoodfestival",
	StoryAtlas = "DarkFoodFestivalStory",
	StoryBG = "ActivityStory_DarkFoodFestival_8",
	SupportLevel = 50,
	UnlockCostList = {
		{
			Value = 327308,
			Num = 5,
		},
	},
	RepeatCostList = {
		{
			Value = 2,
			Num = 200,
		},
	},
	Limit = 1,
	AcceptSpeech = 62003801,
	Desc = "辣味大师，和医院某某科医生关系良好。",
	ResultText = "章节8：猎人的勇气已完成",
	Dialog = "您的身体还好吧？",
	NumCap = 5,
	LevelBundle = "packed_eventthemebg",
	LevelAtlas = "EventThemeBG",
	LevelBG = "DarkFoodFestivalBG01",
	StartScene = "DarkFoodFestivalChallenge_StartScene",
	Enemy = {
		{
			Value = 241047,
			Level = 50,
		},
	},
	Reward = {
		{
			Value = 330003,
			Num = 4,
		},
	},
}
ActivityBattleConfig[ActivityBattleID.Id039] =
{
	Id = 39,
	Name = "章节9：村长的觉悟",
	IntroduceText = "下一个摊位，是这次试胆大会的“甜品站”。据说，这叫“仰望星空派”，小鱼干以脑袋向上的姿势被插入面包中，大大的眼珠给人一种死不瞑目的感觉……",
	StoryBundle = "packed_activity_darkfoodfestival",
	StoryAtlas = "DarkFoodFestivalStory",
	StoryBG = "ActivityStory_DarkFoodFestival_9",
	SupportLevel = 55,
	UnlockCostList = {
		{
			Value = 327308,
			Num = 10,
		},
	},
	RepeatCostList = {
		{
			Value = 2,
			Num = 200,
		},
	},
	Limit = 1,
	AcceptSpeech = 62003901,
	Desc = "又名“死不瞑目”，常因品相不佳而被美食家无情拒绝。",
	ResultText = "章节9：村长的觉悟已完成",
	Dialog = "……",
	NumCap = 5,
	LevelBundle = "packed_eventthemebg",
	LevelAtlas = "EventThemeBG",
	LevelBG = "DarkFoodFestivalBG01",
	StartScene = "DarkFoodFestivalChallenge_StartScene",
	Enemy = {
		{
			Value = 241048,
			Level = 55,
		},
	},
	Reward = {
		{
			Value = 330003,
			Num = 5,
		},
	},
}
ActivityBattleConfig[ActivityBattleID.Id040] =
{
	Id = 40,
	Name = "章节10：汽水王子",
	IntroduceText = "四位王子们迅速赶到了最后一个摊位，而这里的挑战，是要吃下四颗花椒。大家面面相觑之际，汽水王子站了出来……",
	StoryBundle = "packed_activity_darkfoodfestival",
	StoryAtlas = "DarkFoodFestivalStory",
	StoryBG = "ActivityStory_DarkFoodFestival_10",
	SupportLevel = 60,
	UnlockCostList = {
		{
			Value = 327308,
			Num = 15,
		},
	},
	RepeatCostList = {
		{
			Value = 2,
			Num = 200,
		},
	},
	Limit = 1,
	AcceptSpeech = 62004001,
	Desc = "麻醉效果拔群，曾获得医疗界麻醉科offer。",
	ResultText = "章节10：汽水王子已完成",
	Dialog = "一家人就是要整整齐齐。",
	NumCap = 5,
	LevelBundle = "packed_eventthemebg",
	LevelAtlas = "EventThemeBG",
	LevelBG = "DarkFoodFestivalBG01",
	StartScene = "DarkFoodFestivalChallenge_StartScene",
	Enemy = {
		{
			Value = 241049,
			Level = 60,
		},
	},
	Reward = {
		{
			Value = 330003,
			Num = 5,
		},
	},
}
ActivityBattleConfig[ActivityBattleID.Id041] =
{
	Id = 41,
	Name = "章节1：总经理点名",
	IntroduceText = "端午佳节，星际总局举办了面向宇宙的“龙舟大赛”，并邀请各公司参加，魔王集团竟也在邀请行列。小魔王作为总经理，承担起了比赛重任。",
	StoryBundle = "packed_activity_dragonboatfestival",
	StoryAtlas = "DragonBoatFestivalStory",
	StoryBG = "ActivityStory_DragonBoatFestival_1",
	SupportLevel = 15,
	UnlockCostList = {
		{
			Value = 320402,
			Num = 20,
		},
	},
	RepeatCostList = {
		{
			Value = 2,
			Num = 200,
		},
	},
	Limit = 3,
	AcceptSpeech = 62004101,
	Desc = "薯条国王御用侍卫，是国王最放心的部下与伙伴。",
	ResultText = "章节1：总经理点名已完成",
	Dialog = "大人，这算工伤吧？",
	NumCap = 5,
	LevelBundle = "packed_eventthemebg",
	LevelAtlas = "EventThemeBG",
	LevelBG = "DragonBoatFestivalBG01",
	StartScene = "DragonBoatFestivalChallenge_StartScene",
	Enemy = {
		{
			Value = 241050,
			Level = 15,
		},
	},
	Reward = {
		{
			Value = 327311,
			Num = 500,
		},
	},
	RepeatReward = {
		{
			Value = 327311,
			Num = 100,
		},
	},
}
ActivityBattleConfig[ActivityBattleID.Id042] =
{
	Id = 42,
	Name = "章节2：抓阄决定",
	IntroduceText = "由于无人主动报名龙舟赛，小魔王打算通过抓阄的方式选出参赛队员。",
	StoryBundle = "packed_activity_dragonboatfestival",
	StoryAtlas = "DragonBoatFestivalStory",
	StoryBG = "ActivityStory_DragonBoatFestival_2",
	SupportLevel = 20,
	UnlockCostList = {
		{
			Value = 320402,
			Num = 30,
		},
	},
	RepeatCostList = {
		{
			Value = 2,
			Num = 200,
		},
	},
	Limit = 3,
	AcceptSpeech = 62004201,
	Desc = "来自不知名星球的冒险者，为获得保镖工资，花费了999玉璧乘坐飞船而来。",
	ResultText = "章节2：抓阄决定已完成",
	Dialog = "哈哈，不用去划船啦。",
	NumCap = 5,
	LevelBundle = "packed_eventthemebg",
	LevelAtlas = "EventThemeBG",
	LevelBG = "DragonBoatFestivalBG01",
	StartScene = "DragonBoatFestivalChallenge_StartScene",
	Enemy = {
		{
			Value = 241051,
			Level = 20,
		},
	},
	Reward = {
		{
			Value = 327311,
			Num = 500,
		},
	},
	RepeatReward = {
		{
			Value = 327311,
			Num = 100,
		},
	},
}
ActivityBattleConfig[ActivityBattleID.Id043] =
{
	Id = 43,
	Name = "章节3：提升士气",
	IntroduceText = "为了提升员工们的士气，小魔王决定面对公司，发表一番演讲，让大家对这次的比赛充满期待，充满信心。",
	StoryBundle = "packed_activity_dragonboatfestival",
	StoryAtlas = "DragonBoatFestivalStory",
	StoryBG = "ActivityStory_DragonBoatFestival_3",
	SupportLevel = 25,
	UnlockCostList = {
		{
			Value = 327309,
			Num = 8,
		},
	},
	RepeatCostList = {
		{
			Value = 2,
			Num = 200,
		},
	},
	Limit = 3,
	AcceptSpeech = 62004301,
	Desc = "出生于养生世家，曾获泡面养生大赛一等奖。",
	ResultText = "章节3：提升士气已完成",
	Dialog = "唔！不要打我……",
	NumCap = 5,
	LevelBundle = "packed_eventthemebg",
	LevelAtlas = "EventThemeBG",
	LevelBG = "DragonBoatFestivalBG01",
	StartScene = "DragonBoatFestivalChallenge_StartScene",
	Enemy = {
		{
			Value = 241052,
			Level = 25,
		},
	},
	Reward = {
		{
			Value = 327311,
			Num = 500,
		},
	},
	RepeatReward = {
		{
			Value = 327311,
			Num = 100,
		},
	},
}
ActivityBattleConfig[ActivityBattleID.Id044] =
{
	Id = 44,
	Name = "章节4：赛前训练",
	IntroduceText = "小魔王相信，此刻的大家都斗志昂扬，但是为了知道自己的队伍实力究竟如何，小魔王决定，要带领大家去河里操练一番。",
	StoryBundle = "packed_activity_dragonboatfestival",
	StoryAtlas = "DragonBoatFestivalStory",
	StoryBG = "ActivityStory_DragonBoatFestival_4",
	SupportLevel = 30,
	UnlockCostList = {
		{
			Value = 327309,
			Num = 12,
		},
	},
	RepeatCostList = {
		{
			Value = 2,
			Num = 200,
		},
	},
	Limit = 3,
	AcceptSpeech = 62004401,
	Desc = "臭豆腐兄弟，为了成功移民美食星付出了巨大努力。",
	ResultText = "章节4：赛前训练已完成",
	Dialog = "我是合格的╰（‵□′）╯",
	NumCap = 5,
	LevelBundle = "packed_eventthemebg",
	LevelAtlas = "EventThemeBG",
	LevelBG = "DragonBoatFestivalBG01",
	StartScene = "DragonBoatFestivalChallenge_StartScene",
	Enemy = {
		{
			Value = 241053,
			Level = 30,
		},
	},
	Reward = {
		{
			Value = 327311,
			Num = 500,
		},
	},
	RepeatReward = {
		{
			Value = 327311,
			Num = 100,
		},
	},
}
ActivityBattleConfig[ActivityBattleID.Id045] =
{
	Id = 45,
	Name = "章节5：寻求帮助",
	IntroduceText = "小魔王对公司员工有些失望，又听说队伍中可以有2名外援，于是打算带上骨头兵，邀请牧师加入自己的队伍。",
	StoryBundle = "packed_activity_dragonboatfestival",
	StoryAtlas = "DragonBoatFestivalStory",
	StoryBG = "ActivityStory_DragonBoatFestival_5",
	SupportLevel = 35,
	UnlockCostList = {
		{
			Value = 327309,
			Num = 16,
		},
	},
	RepeatCostList = {
		{
			Value = 2,
			Num = 200,
		},
	},
	Limit = 3,
	AcceptSpeech = 62004501,
	Desc = "非常坚硬的面包，但还是敌不过剑士祖传的大宝剑啊。",
	ResultText = "章节5：寻求帮助已完成",
	Dialog = "你打我干啥？",
	NumCap = 5,
	LevelBundle = "packed_eventthemebg",
	LevelAtlas = "EventThemeBG",
	LevelBG = "DragonBoatFestivalBG01",
	StartScene = "DragonBoatFestivalChallenge_StartScene",
	Enemy = {
		{
			Value = 241054,
			Level = 35,
		},
	},
	Reward = {
		{
			Value = 327311,
			Num = 500,
		},
	},
	RepeatReward = {
		{
			Value = 327311,
			Num = 100,
		},
	},
}
ActivityBattleConfig[ActivityBattleID.Id046] =
{
	Id = 46,
	Name = "章节6：上场之前",
	IntroduceText = "由小魔王和骨头兵们组成的队伍正式报名参赛。比赛当天，魔王大队准时到达现场，还拿了一壶雄黄酒，不知是为了壮胆还是抚慰伤心的小魔王。",
	StoryBundle = "packed_activity_dragonboatfestival",
	StoryAtlas = "DragonBoatFestivalStory",
	StoryBG = "ActivityStory_DragonBoatFestival_6",
	SupportLevel = 40,
	UnlockCostList = {
		{
			Value = 327309,
			Num = 20,
		},
	},
	RepeatCostList = {
		{
			Value = 2,
			Num = 200,
		},
	},
	Limit = 3,
	AcceptSpeech = 62004601,
	Desc = "虽然知道自己的饭团不好闻，但还是坚持了下来。",
	ResultText = "章节6：上场之前已完成",
	Dialog = "哎呀，被喝掉啦。",
	NumCap = 5,
	LevelBundle = "packed_eventthemebg",
	LevelAtlas = "EventThemeBG",
	LevelBG = "DragonBoatFestivalBG01",
	StartScene = "DragonBoatFestivalChallenge_StartScene",
	Enemy = {
		{
			Value = 241055,
			Level = 40,
		},
	},
	Reward = {
		{
			Value = 327311,
			Num = 500,
		},
	},
	RepeatReward = {
		{
			Value = 327311,
			Num = 100,
		},
	},
}
ActivityBattleConfig[ActivityBattleID.Id047] =
{
	Id = 47,
	Name = "章节7：加油，小魔王！",
	IntroduceText = "龙舟大赛开始了，小魔王此刻的敌人，不再是勇者，而是来自美食星的王子唱片公司的可乐王子。",
	StoryBundle = "packed_activity_dragonboatfestival",
	StoryAtlas = "DragonBoatFestivalStory",
	StoryBG = "ActivityStory_DragonBoatFestival_7",
	SupportLevel = 45,
	UnlockCostList = {
		{
			Value = 327309,
			Num = 25,
		},
	},
	RepeatCostList = {
		{
			Value = 2,
			Num = 200,
		},
	},
	Limit = 3,
	AcceptSpeech = 62004701,
	Desc = "为了做出正宗的咖啡，会诱骗小猫吃下特制咖啡豆生产原料。",
	ResultText = "章节7：加油，小魔王！已完成",
	Dialog = "扶我起来，我还能唱。",
	NumCap = 5,
	LevelBundle = "packed_eventthemebg",
	LevelAtlas = "EventThemeBG",
	LevelBG = "DragonBoatFestivalBG01",
	StartScene = "DragonBoatFestivalChallenge_StartScene",
	Enemy = {
		{
			Value = 241056,
			Level = 45,
		},
	},
	Reward = {
		{
			Value = 327311,
			Num = 500,
		},
	},
	RepeatReward = {
		{
			Value = 327311,
			Num = 100,
		},
	},
}
ActivityBattleConfig[ActivityBattleID.Id048] =
{
	Id = 48,
	Name = "章节8：无辜遭罪",
	IntroduceText = "通过重重选拔，魔王集团和勇者公司的两支队伍进入决赛，小魔王和剑士展开了最终对决。",
	StoryBundle = "packed_activity_dragonboatfestival",
	StoryAtlas = "DragonBoatFestivalStory",
	StoryBG = "ActivityStory_DragonBoatFestival_8",
	SupportLevel = 50,
	UnlockCostList = {
		{
			Value = 327310,
			Num = 10,
		},
	},
	RepeatCostList = {
		{
			Value = 2,
			Num = 200,
		},
	},
	Limit = 1,
	AcceptSpeech = 62004801,
	Desc = "辣味大师，和医院某某科医生关系良好。",
	ResultText = "章节8：无辜遭罪已完成",
	Dialog = "小的……小的冤枉！！",
	NumCap = 5,
	LevelBundle = "packed_eventthemebg",
	LevelAtlas = "EventThemeBG",
	LevelBG = "DragonBoatFestivalBG01",
	StartScene = "DragonBoatFestivalChallenge_StartScene",
	Enemy = {
		{
			Value = 241057,
			Level = 50,
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 200,
		},
	},
}
ActivityBattleConfig[ActivityBattleID.Id049] =
{
	Id = 49,
	Name = "章节9：第二名的礼物",
	IntroduceText = "魔王大队荣获第二，小魔王平静地接受了这个事实。没有想到，第二名竟然还有奖杯和端午礼品。",
	StoryBundle = "packed_activity_dragonboatfestival",
	StoryAtlas = "DragonBoatFestivalStory",
	StoryBG = "ActivityStory_DragonBoatFestival_9",
	SupportLevel = 55,
	UnlockCostList = {
		{
			Value = 327310,
			Num = 15,
		},
	},
	RepeatCostList = {
		{
			Value = 2,
			Num = 200,
		},
	},
	Limit = 1,
	AcceptSpeech = 62004901,
	Desc = "又名“死不瞑目”，常因品相不佳而被美食家无情拒绝。",
	ResultText = "章节9：第二名的礼物已完成",
	Dialog = "是组委会的主意……",
	NumCap = 5,
	LevelBundle = "packed_eventthemebg",
	LevelAtlas = "EventThemeBG",
	LevelBG = "DragonBoatFestivalBG01",
	StartScene = "DragonBoatFestivalChallenge_StartScene",
	Enemy = {
		{
			Value = 241058,
			Level = 55,
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 300,
		},
	},
}
ActivityBattleConfig[ActivityBattleID.Id050] =
{
	Id = 50,
	Name = "章节10：秋后算账",
	IntroduceText = "龙舟大赛终于结束了，小魔王带领自己的队伍回到了冒险星。还没到太牛门口，就听到村长一边骂骂咧咧一边敲门，似乎是要找小魔王讨个说法。",
	StoryBundle = "packed_activity_dragonboatfestival",
	StoryAtlas = "DragonBoatFestivalStory",
	StoryBG = "ActivityStory_DragonBoatFestival_10",
	SupportLevel = 60,
	UnlockCostList = {
		{
			Value = 327310,
			Num = 20,
		},
	},
	RepeatCostList = {
		{
			Value = 2,
			Num = 200,
		},
	},
	Limit = 1,
	AcceptSpeech = 62005001,
	Desc = "麻醉效果拔群，曾获得医疗界麻醉科offer。",
	ResultText = "章节10：秋后算账已完成",
	Dialog = "果然…长江后浪拍前浪。",
	NumCap = 5,
	LevelBundle = "packed_eventthemebg",
	LevelAtlas = "EventThemeBG",
	LevelBG = "DragonBoatFestivalBG01",
	StartScene = "DragonBoatFestivalChallenge_StartScene",
	Enemy = {
		{
			Value = 241059,
			Level = 60,
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 500,
		},
	},
}
ActivityBattleConfig[ActivityBattleID.Id051] =
{
	Id = 51,
	Name = "章节1：向夏日庙会出发",
	IntroduceText = "纺织女子高中的七位女孩顺利毕业，面对接下来的毕业旅行，她们似乎有了一些想法。",
	StoryBundle = "packed_activity_templefairfestival",
	StoryAtlas = "TempleFairFestivalStory",
	StoryBG = "ActivityStory_TempleFairFestival_1",
	SupportLevel = 15,
	UnlockCostList = {
		{
			Value = 1,
			Num = 1200,
		},
	},
	RepeatCostList = {
		{
			Value = 2,
			Num = 200,
		},
	},
	Limit = 1,
	AcceptSpeech = 62005101,
	SuccessSpeech = 62005151,
	Desc = "夏日庙会冲冲冲！",
	ResultText = "章节1：向夏日庙会出发已完成",
	Dialog = "铁匠：这，这不公平！",
	NumCap = 5,
	LevelBundle = "packed_eventthemebg",
	LevelAtlas = "EventThemeBG",
	LevelBG = "TempleFairFestivalBG01",
	StartScene = "TempleFairFestivalChallenge_StartScene",
	Enemy = {
		{
			Value = 241060,
			Level = 15,
		},
	},
	Reward = {
		{
			Value = 330003,
			Num = 2,
		},
	},
}
ActivityBattleConfig[ActivityBattleID.Id052] =
{
	Id = 52,
	Name = "章节2：热闹的庙会",
	IntroduceText = "庙会现场人来人往，摩肩接踵，还有可恶的飙车王作乱，不过，少女们也并非全无办法。",
	StoryBundle = "packed_activity_templefairfestival",
	StoryAtlas = "TempleFairFestivalStory",
	StoryBG = "ActivityStory_TempleFairFestival_2",
	SupportLevel = 20,
	UnlockCostList = {
		{
			Value = 1,
			Num = 2000,
		},
	},
	RepeatCostList = {
		{
			Value = 2,
			Num = 200,
		},
	},
	Limit = 1,
	AcceptSpeech = 62005201,
	SuccessSpeech = 62005251,
	Desc = "夏日庙会冲冲冲！",
	ResultText = "章节2：热闹的庙会已完成",
	Dialog = "飙车王：这是我让你们的！",
	NumCap = 5,
	LevelBundle = "packed_eventthemebg",
	LevelAtlas = "EventThemeBG",
	LevelBG = "TempleFairFestivalBG01",
	StartScene = "TempleFairFestivalChallenge_StartScene",
	Enemy = {
		{
			Value = 241061,
			Level = 20,
		},
	},
	Reward = {
		{
			Value = 330003,
			Num = 2,
		},
	},
}
ActivityBattleConfig[ActivityBattleID.Id053] =
{
	Id = 53,
	Name = "章节3：金鱼大挑战",
	IntroduceText = "被排得水泄不通的队伍吸引，七织来到了捞金鱼的店铺前。她撸起袖子，抓起网兜，决定和金鱼们决一胜负。",
	StoryBundle = "packed_activity_templefairfestival",
	StoryAtlas = "TempleFairFestivalStory",
	StoryBG = "ActivityStory_TempleFairFestival_3",
	SupportLevel = 25,
	UnlockCostList = {
		{
			Value = 327312,
			Num = 8,
		},
	},
	RepeatCostList = {
		{
			Value = 2,
			Num = 200,
		},
	},
	Limit = 1,
	AcceptSpeech = 62005301,
	SuccessSpeech = 62005351,
	Desc = "小鱼别跑！",
	ResultText = "章节3：金鱼大挑战已完成",
	Dialog = "金鱼：咕唧、咕唧...",
	NumCap = 5,
	LevelBundle = "packed_eventthemebg",
	LevelAtlas = "EventThemeBG",
	LevelBG = "TempleFairFestivalBG01",
	StartScene = "TempleFairFestivalChallenge_StartScene",
	Enemy = {
		{
			Value = 241062,
			Level = 25,
		},
	},
	Reward = {
		{
			Value = 330003,
			Num = 2,
		},
	},
}
ActivityBattleConfig[ActivityBattleID.Id054] =
{
	Id = 54,
	Name = "章节4：离散的少女",
	IntroduceText = "七织久去不回，剩下的六位少女焦急又担心。是继续等下去呢？还是去找她呢？少女们陷入沉思，做出了不同的抉择。",
	StoryBundle = "packed_activity_templefairfestival",
	StoryAtlas = "TempleFairFestivalStory",
	StoryBG = "ActivityStory_TempleFairFestival_4",
	SupportLevel = 30,
	UnlockCostList = {
		{
			Value = 327312,
			Num = 12,
		},
	},
	RepeatCostList = {
		{
			Value = 2,
			Num = 200,
		},
	},
	Limit = 1,
	AcceptSpeech = 62005401,
	SuccessSpeech = 62005451,
	Desc = "希望再也没有挡路的家伙了...",
	ResultText = "章节4：离散的少女已完成",
	Dialog = "占位路障：…不、要、打、人。",
	NumCap = 5,
	LevelBundle = "packed_eventthemebg",
	LevelAtlas = "EventThemeBG",
	LevelBG = "TempleFairFestivalBG01",
	StartScene = "TempleFairFestivalChallenge_StartScene",
	Enemy = {
		{
			Value = 241063,
			Level = 30,
		},
	},
	Reward = {
		{
			Value = 330003,
			Num = 2,
		},
	},
}
ActivityBattleConfig[ActivityBattleID.Id055] =
{
	Id = 55,
	Name = "章节5：寻找同伴的旅程",
	IntroduceText = "一心与五行和大家走散了。二人沿着庙会活动点，寻找离散的同伴们，捞鱼店和服装店排着长队，七织会在其中吗？",
	StoryBundle = "packed_activity_templefairfestival",
	StoryAtlas = "TempleFairFestivalStory",
	StoryBG = "ActivityStory_TempleFairFestival_5",
	SupportLevel = 35,
	UnlockCostList = {
		{
			Value = 327312,
			Num = 16,
		},
	},
	RepeatCostList = {
		{
			Value = 2,
			Num = 200,
		},
	},
	Limit = 1,
	AcceptSpeech = 62005501,
	SuccessSpeech = 62005551,
	Desc = "大家的战斗力真不错呀。",
	ResultText = "章节5：寻找同伴的旅程已完成",
	Dialog = "牵牛：别、别打了...",
	NumCap = 5,
	LevelBundle = "packed_eventthemebg",
	LevelAtlas = "EventThemeBG",
	LevelBG = "TempleFairFestivalBG01",
	StartScene = "TempleFairFestivalChallenge_StartScene",
	Enemy = {
		{
			Value = 241064,
			Level = 35,
		},
	},
	Reward = {
		{
			Value = 330003,
			Num = 2,
		},
	},
}
ActivityBattleConfig[ActivityBattleID.Id056] =
{
	Id = 56,
	Name = "章节6：你在看什么呀",
	IntroduceText = "一心五行终于和七织会合，同时也认识了七织的新朋友牵牛，四人一边谈天说地，一边在庙会闲逛，然而此时的流亡街却下起了雨…",
	StoryBundle = "packed_activity_templefairfestival",
	StoryAtlas = "TempleFairFestivalStory",
	StoryBG = "ActivityStory_TempleFairFestival_6",
	SupportLevel = 40,
	UnlockCostList = {
		{
			Value = 327312,
			Num = 20,
		},
	},
	RepeatCostList = {
		{
			Value = 2,
			Num = 200,
		},
	},
	Limit = 1,
	AcceptSpeech = 62005601,
	SuccessSpeech = 62005651,
	Desc = "快去躲雨吧。",
	ResultText = "章节6：你在看什么呀已完成",
	Dialog = "鬼影树：此路...是我，开...",
	NumCap = 5,
	LevelBundle = "packed_eventthemebg",
	LevelAtlas = "EventThemeBG",
	LevelBG = "TempleFairFestivalBG01",
	StartScene = "TempleFairFestivalChallenge_StartScene",
	Enemy = {
		{
			Value = 241065,
			Level = 40,
		},
	},
	Reward = {
		{
			Value = 330003,
			Num = 2,
		},
	},
}
ActivityBattleConfig[ActivityBattleID.Id057] =
{
	Id = 57,
	Name = "章节7：真实的心意",
	IntroduceText = "脱离大部队的二橘被低气压笼罩，为了让她开心起来，四荔拉着她的手向前奔跑，不管发生什么，都要用乐观和微笑面对！",
	StoryBundle = "packed_activity_templefairfestival",
	StoryAtlas = "TempleFairFestivalStory",
	StoryBG = "ActivityStory_TempleFairFestival_7",
	SupportLevel = 45,
	UnlockCostList = {
		{
			Value = 327312,
			Num = 25,
		},
	},
	RepeatCostList = {
		{
			Value = 2,
			Num = 200,
		},
	},
	Limit = 1,
	AcceptSpeech = 62005701,
	SuccessSpeech = 62005751,
	Desc = "禁止嘲讽别人。",
	ResultText = "章节7：真实的心意已完成",
	Dialog = "吵架石：不会吧，这就要打我？",
	NumCap = 5,
	LevelBundle = "packed_eventthemebg",
	LevelAtlas = "EventThemeBG",
	LevelBG = "TempleFairFestivalBG01",
	StartScene = "TempleFairFestivalChallenge_StartScene",
	Enemy = {
		{
			Value = 241066,
			Level = 45,
		},
	},
	Reward = {
		{
			Value = 330003,
			Num = 2,
		},
	},
}
ActivityBattleConfig[ActivityBattleID.Id058] =
{
	Id = 58,
	Name = "章节8：不是胆小鬼",
	IntroduceText = "迷路的六瑶紧紧抓住三花，与姐妹们走失让她更加害怕了，三花决定要做些什么，让这位胆小的妹妹变得勇敢。",
	StoryBundle = "packed_activity_templefairfestival",
	StoryAtlas = "TempleFairFestivalStory",
	StoryBG = "ActivityStory_TempleFairFestival_8",
	SupportLevel = 50,
	UnlockCostList = {
		{
			Value = 327313,
			Num = 10,
		},
	},
	RepeatCostList = {
		{
			Value = 2,
			Num = 200,
		},
	},
	Limit = 1,
	AcceptSpeech = 62005801,
	SuccessSpeech = 62005851,
	Desc = "不可以欺负小猫咪哦！",
	ResultText = "章节8：不是胆小鬼已完成",
	Dialog = "三花猫：喵呜...",
	NumCap = 5,
	LevelBundle = "packed_eventthemebg",
	LevelAtlas = "EventThemeBG",
	LevelBG = "TempleFairFestivalBG01",
	StartScene = "TempleFairFestivalChallenge_StartScene",
	Enemy = {
		{
			Value = 241067,
			Level = 50,
		},
	},
	Reward = {
		{
			Value = 330003,
			Num = 2,
		},
	},
}
ActivityBattleConfig[ActivityBattleID.Id059] =
{
	Id = 59,
	Name = "章节9：重逢有期",
	IntroduceText = "三花和六瑶抱着流浪的猫咪，在路上缓缓前行。然而，突如其来的降雨打乱了她们的计划，不得不去寻找避雨场所。",
	StoryBundle = "packed_activity_templefairfestival",
	StoryAtlas = "TempleFairFestivalStory",
	StoryBG = "ActivityStory_TempleFairFestival_9",
	SupportLevel = 55,
	UnlockCostList = {
		{
			Value = 327313,
			Num = 15,
		},
	},
	RepeatCostList = {
		{
			Value = 2,
			Num = 200,
		},
	},
	Limit = 1,
	AcceptSpeech = 62005901,
	SuccessSpeech = 62005951,
	Desc = "大概这就是，大水冲了龙王庙吧？",
	ResultText = "章节9：重逢有期已完成",
	Dialog = "黑影：别打了，是自己人！",
	NumCap = 5,
	LevelBundle = "packed_eventthemebg",
	LevelAtlas = "EventThemeBG",
	LevelBG = "TempleFairFestivalBG01",
	StartScene = "TempleFairFestivalChallenge_StartScene",
	Enemy = {
		{
			Value = 241068,
			Level = 55,
		},
	},
	Reward = {
		{
			Value = 330003,
			Num = 3,
		},
	},
}
ActivityBattleConfig[ActivityBattleID.Id060] =
{
	Id = 60,
	Name = "章节10：流萤明灭，星河遥迢",
	IntroduceText = "少女们终于团聚，在皎洁的月光下，七人终于拍下了属于她们的第一张合照。",
	StoryBundle = "packed_activity_templefairfestival",
	StoryAtlas = "TempleFairFestivalStory",
	StoryBG = "ActivityStory_TempleFairFestival_10",
	SupportLevel = 60,
	UnlockCostList = {
		{
			Value = 327313,
			Num = 20,
		},
	},
	RepeatCostList = {
		{
			Value = 2,
			Num = 200,
		},
	},
	Limit = 1,
	AcceptSpeech = 62006001,
	SuccessSpeech = 62006051,
	Desc = "好啦，一起看月亮吧。",
	ResultText = "章节10：流萤明灭，星河遥迢已完成",
	Dialog = "月佬：别...冲动是魔鬼！",
	NumCap = 5,
	LevelBundle = "packed_eventthemebg",
	LevelAtlas = "EventThemeBG",
	LevelBG = "TempleFairFestivalBG01",
	StartScene = "TempleFairFestivalChallenge_StartScene",
	Enemy = {
		{
			Value = 241069,
			Level = 60,
		},
	},
	Reward = {
		{
			Value = 330003,
			Num = 3,
		},
	},
}
ActivityBattleConfig[ActivityBattleID.Id061] =
{
	Id = 61,
	Name = "章节1：温泉别墅",
	IntroduceText = "抽中特等奖的蓝衣小学生获得了去“温泉别墅”度假的资格，在富丽堂皇的别墅里，他认识了许多新朋友。",
	StoryBundle = "packed_activity_winterfestival",
	StoryAtlas = "WinterFestivalStory",
	StoryBG = "ActivityStory_WinterFestival_1",
	SupportLevel = 15,
	UnlockCostList = {
		{
			Value = 1,
			Num = 1200,
		},
	},
	RepeatCostList = {
		{
			Value = 2,
			Num = 200,
		},
	},
	Limit = 1,
	AcceptSpeech = 62006101,
	SuccessSpeech = 62006151,
	Desc = "唔，总算安静下来了。",
	ResultText = "章节1：温泉别墅已完成",
	Dialog = "雪中猎人：狗子，咬他！",
	NumCap = 5,
	LevelBundle = "packed_eventthemebg",
	LevelAtlas = "EventThemeBG",
	LevelBG = "WinterFestivalBG01",
	StartScene = "TempleFairFestivalChallenge_StartScene",
	Enemy = {
		{
			Value = 241070,
			Level = 15,
		},
		{
			Value = 241071,
			Level = 15,
		},
	},
	Reward = {
		{
			Value = 330003,
			Num = 2,
		},
	},
}
ActivityBattleConfig[ActivityBattleID.Id062] =
{
	Id = 62,
	Name = "章节2：可怕传言",
	IntroduceText = "猫眼厨娘在别墅大厅里，绘声绘色地向大家讲述“雪怪的可怕流言”，蓝衣小学生竖起耳朵，不想错过任何一点信息。",
	StoryBundle = "packed_activity_winterfestival",
	StoryAtlas = "WinterFestivalStory",
	StoryBG = "ActivityStory_WinterFestival_2",
	SupportLevel = 20,
	UnlockCostList = {
		{
			Value = 1,
			Num = 2000,
		},
	},
	RepeatCostList = {
		{
			Value = 2,
			Num = 200,
		},
	},
	Limit = 1,
	AcceptSpeech = 62006201,
	SuccessSpeech = 62006251,
	Desc = "讲科学，破迷信。",
	ResultText = "章节2：可怕传言已完成",
	Dialog = "白幽灵：玩笑，一个玩笑……",
	NumCap = 5,
	LevelBundle = "packed_eventthemebg",
	LevelAtlas = "EventThemeBG",
	LevelBG = "WinterFestivalBG01",
	StartScene = "TempleFairFestivalChallenge_StartScene",
	Enemy = {
		{
			Value = 241072,
			Level = 20,
		},
	},
	Reward = {
		{
			Value = 330003,
			Num = 2,
		},
	},
}
ActivityBattleConfig[ActivityBattleID.Id063] =
{
	Id = 63,
	Name = "章节3：幸福温泉",
	IntroduceText = "在温泉鉴赏家的提议下，大家来到露天场所，一同泡温泉。蓝衣小学生向猫眼厨娘打听起了雪怪的消息……",
	StoryBundle = "packed_activity_winterfestival",
	StoryAtlas = "WinterFestivalStory",
	StoryBG = "ActivityStory_WinterFestival_3",
	SupportLevel = 25,
	UnlockCostList = {
		{
			Value = 327318,
			Num = 8,
		},
	},
	RepeatCostList = {
		{
			Value = 2,
			Num = 200,
		},
	},
	Limit = 1,
	AcceptSpeech = 62006301,
	SuccessSpeech = 62006351,
	Desc = "药剂包沉入水底。",
	ResultText = "章节3：幸福温泉已完成",
	Dialog = "药剂包：我什么都……不知道。",
	NumCap = 5,
	LevelBundle = "packed_eventthemebg",
	LevelAtlas = "EventThemeBG",
	LevelBG = "WinterFestivalBG01",
	StartScene = "TempleFairFestivalChallenge_StartScene",
	Enemy = {
		{
			Value = 241073,
			Level = 25,
		},
	},
	Reward = {
		{
			Value = 330003,
			Num = 2,
		},
	},
}
ActivityBattleConfig[ActivityBattleID.Id064] =
{
	Id = 64,
	Name = "章节4：噩梦诅咒",
	IntroduceText = "清晨，大家在餐厅用餐，却不见受害者的踪影，她去哪里了？难道说，她依旧没有逃过名字的诅咒吗？",
	StoryBundle = "packed_activity_winterfestival",
	StoryAtlas = "WinterFestivalStory",
	StoryBG = "ActivityStory_WinterFestival_4",
	SupportLevel = 30,
	UnlockCostList = {
		{
			Value = 327318,
			Num = 12,
		},
	},
	RepeatCostList = {
		{
			Value = 2,
			Num = 200,
		},
	},
	Limit = 1,
	AcceptSpeech = 62006401,
	SuccessSpeech = 62006451,
	Desc = "受害者在哪里？",
	ResultText = "章节4：噩梦诅咒已完成",
	Dialog = "木板：……我烂了。",
	NumCap = 5,
	LevelBundle = "packed_eventthemebg",
	LevelAtlas = "EventThemeBG",
	LevelBG = "WinterFestivalBG01",
	StartScene = "TempleFairFestivalChallenge_StartScene",
	Enemy = {
		{
			Value = 241074,
			Level = 30,
		},
	},
	Reward = {
		{
			Value = 330003,
			Num = 2,
		},
	},
}
ActivityBattleConfig[ActivityBattleID.Id065] =
{
	Id = 65,
	Name = "章节5：第二位受害者",
	IntroduceText = "继受害者之后，第二位受害人又诞生了。编剧妹子也从房间失踪，这到底是人类的阴谋，还是妖怪的诅咒？",
	StoryBundle = "packed_activity_winterfestival",
	StoryAtlas = "WinterFestivalStory",
	StoryBG = "ActivityStory_WinterFestival_5",
	SupportLevel = 35,
	UnlockCostList = {
		{
			Value = 327318,
			Num = 16,
		},
	},
	RepeatCostList = {
		{
			Value = 2,
			Num = 200,
		},
	},
	Limit = 1,
	AcceptSpeech = 62006501,
	SuccessSpeech = 62006551,
	Desc = "什么人？站住！",
	ResultText = "章节5：第二位受害者已完成",
	Dialog = "黑衣人：我溜——！",
	NumCap = 5,
	LevelBundle = "packed_eventthemebg",
	LevelAtlas = "EventThemeBG",
	LevelBG = "WinterFestivalBG01",
	StartScene = "TempleFairFestivalChallenge_StartScene",
	Enemy = {
		{
			Value = 241075,
			Level = 35,
		},
	},
	Reward = {
		{
			Value = 330003,
			Num = 2,
		},
	},
}
ActivityBattleConfig[ActivityBattleID.Id066] =
{
	Id = 66,
	Name = "章节6：冰冰的阴谋",
	IntroduceText = "紧接着，第三位受害人出现了。这次的受害人主动离开别墅，当众人发现他时，他正用诡异的姿势，伫立在冰冰杆身边。",
	StoryBundle = "packed_activity_winterfestival",
	StoryAtlas = "WinterFestivalStory",
	StoryBG = "ActivityStory_WinterFestival_6",
	SupportLevel = 40,
	UnlockCostList = {
		{
			Value = 327318,
			Num = 20,
		},
	},
	RepeatCostList = {
		{
			Value = 2,
			Num = 200,
		},
	},
	Limit = 1,
	AcceptSpeech = 62006601,
	SuccessSpeech = 62006651,
	Desc = "此场面不宜描述。",
	ResultText = "章节6：冰冰的阴谋已完成",
	Dialog = "冰冰杆：你的心，是冰冰的吗？",
	NumCap = 5,
	LevelBundle = "packed_eventthemebg",
	LevelAtlas = "EventThemeBG",
	LevelBG = "WinterFestivalBG01",
	StartScene = "TempleFairFestivalChallenge_StartScene",
	Enemy = {
		{
			Value = 241076,
			Level = 40,
		},
	},
	Reward = {
		{
			Value = 330003,
			Num = 2,
		},
	},
}
ActivityBattleConfig[ActivityBattleID.Id067] =
{
	Id = 67,
	Name = "章节7：暗中调查",
	IntroduceText = "夜晚，别墅边的路灯微微亮，蓝衣小学生在雪地上暗中调查着什么……脚印、狗粮、钓鱼线，真相就在其中吗？",
	StoryBundle = "packed_activity_winterfestival",
	StoryAtlas = "WinterFestivalStory",
	StoryBG = "ActivityStory_WinterFestival_7",
	SupportLevel = 45,
	UnlockCostList = {
		{
			Value = 327318,
			Num = 25,
		},
	},
	RepeatCostList = {
		{
			Value = 2,
			Num = 200,
		},
	},
	Limit = 1,
	AcceptSpeech = 62006701,
	SuccessSpeech = 62006751,
	Desc = "距离真相越来越近了。",
	ResultText = "章节7：暗中调查已完成",
	Dialog = "思诺曼：小厨娘，对不起！",
	NumCap = 5,
	LevelBundle = "packed_eventthemebg",
	LevelAtlas = "EventThemeBG",
	LevelBG = "WinterFestivalBG01",
	StartScene = "TempleFairFestivalChallenge_StartScene",
	Enemy = {
		{
			Value = 241077,
			Level = 45,
		},
	},
	Reward = {
		{
			Value = 330003,
			Num = 2,
		},
	},
}
ActivityBattleConfig[ActivityBattleID.Id068] =
{
	Id = 68,
	Name = "章节8：所谓真相",
	IntroduceText = "别墅大厅里，蓝衣小学生赶到，展示了一场令人叹为观止的推理秀。然而，这就是全部的真相了吗？",
	StoryBundle = "packed_activity_winterfestival",
	StoryAtlas = "WinterFestivalStory",
	StoryBG = "ActivityStory_WinterFestival_8",
	SupportLevel = 50,
	UnlockCostList = {
		{
			Value = 327319,
			Num = 10,
		},
	},
	RepeatCostList = {
		{
			Value = 2,
			Num = 200,
		},
	},
	Limit = 1,
	AcceptSpeech = 62006801,
	SuccessSpeech = 62006851,
	Desc = "但是，这就是全部的真相吗？",
	ResultText = "章节8：所谓真相已完成",
	Dialog = "猫眼厨娘：我竟然……输了。",
	NumCap = 5,
	LevelBundle = "packed_eventthemebg",
	LevelAtlas = "EventThemeBG",
	LevelBG = "WinterFestivalBG01",
	StartScene = "TempleFairFestivalChallenge_StartScene",
	Enemy = {
		{
			Value = 241078,
			Level = 50,
		},
	},
	Reward = {
		{
			Value = 330003,
			Num = 2,
		},
	},
}
ActivityBattleConfig[ActivityBattleID.Id069] =
{
	Id = 69,
	Name = "章节9：风雪乐园",
	IntroduceText = "尘埃落地，大家打算一齐上山游玩，正当嬉戏打闹时，一个白影一闪而过，并向大家发动了攻击。",
	StoryBundle = "packed_activity_winterfestival",
	StoryAtlas = "WinterFestivalStory",
	StoryBG = "ActivityStory_WinterFestival_9",
	SupportLevel = 55,
	UnlockCostList = {
		{
			Value = 327319,
			Num = 15,
		},
	},
	RepeatCostList = {
		{
			Value = 2,
			Num = 200,
		},
	},
	Limit = 1,
	AcceptSpeech = 62006901,
	SuccessSpeech = 62006951,
	Desc = "不好，危险！",
	ResultText = "章节9：风雪乐园已完成",
	Dialog = "雪神：唔——我要吃人——",
	NumCap = 5,
	LevelBundle = "packed_eventthemebg",
	LevelAtlas = "EventThemeBG",
	LevelBG = "WinterFestivalBG01",
	StartScene = "TempleFairFestivalChallenge_StartScene",
	Enemy = {
		{
			Value = 241079,
			Level = 55,
		},
	},
	Reward = {
		{
			Value = 330003,
			Num = 3,
		},
	},
}
ActivityBattleConfig[ActivityBattleID.Id070] =
{
	Id = 70,
	Name = "章节10：最初的案件",
	IntroduceText = "最初案件的幕后真凶、还未揭开的真相，终于在此时大白。受害者昏倒的理由竟然是……",
	StoryBundle = "packed_activity_winterfestival",
	StoryAtlas = "WinterFestivalStory",
	StoryBG = "ActivityStory_WinterFestival_10",
	SupportLevel = 60,
	UnlockCostList = {
		{
			Value = 327319,
			Num = 20,
		},
	},
	RepeatCostList = {
		{
			Value = 2,
			Num = 200,
		},
	},
	Limit = 1,
	AcceptSpeech = 62007001,
	SuccessSpeech = 62007051,
	Desc = "原来罪魁祸首，是你。",
	ResultText = "章节10：最初的案件已完成",
	Dialog = "大侦探：一起玩枕头大战吗？",
	NumCap = 5,
	LevelBundle = "packed_eventthemebg",
	LevelAtlas = "EventThemeBG",
	LevelBG = "WinterFestivalBG01",
	StartScene = "TempleFairFestivalChallenge_StartScene",
	Enemy = {
		{
			Value = 241080,
			Level = 60,
		},
	},
	Reward = {
		{
			Value = 330003,
			Num = 3,
		},
	},
}

