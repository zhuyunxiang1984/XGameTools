
DemandConfig[DemandID.Id2932] =
{
	Id = 2932,
	Name = "惊险旅行",
	Desc = "来到无人岛上旅行，暂时用队员服做一下床单吧。",
	Value = 321810,
	Active = true,
	Weight = 75625,
	PreGoal = 
	{
		301938,
		301700,
	},
	GoodsId = 131810,
	Num = 57,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 156599,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 266,
				},
				{
					Value = 1,
					Num = 23599,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 266,
				},
				{
					Value = 1,
					Num = 23599,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 53,
				},
				{
					Value = 1,
					Num = 24099,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 53,
				},
				{
					Value = 1,
					Num = 24099,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 10,
				},
				{
					Value = 1,
					Num = 31599,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 10,
				},
				{
					Value = 1,
					Num = 31599,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 939,
				},
				{
					Value = 320051,
					Num = 626,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 187,
				},
				{
					Value = 320052,
					Num = 126,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 37,
				},
				{
					Value = 320053,
					Num = 25,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 7,
				},
				{
					Value = 320054,
					Num = 5,
				},
			},
		},
	},
	DemandID = 412932,
	DemandGroupList = {
		420010,
		420011,
		420012,
		420013,
		420014,
		420015,
	},
}
DemandConfig[DemandID.Id2933] =
{
	Id = 2933,
	Name = "惊险旅行",
	Desc = "来到无人岛上旅行，暂时用队员服做一下床单吧。",
	Value = 321810,
	Active = false,
	Weight = 79255,
	PreGoal = 
	{
		301938,
		301730,
	},
	GoodsId = 161810,
	Num = 84,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 230778,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 392,
				},
				{
					Value = 1,
					Num = 34778,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 392,
				},
				{
					Value = 1,
					Num = 34778,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 78,
				},
				{
					Value = 1,
					Num = 35778,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 78,
				},
				{
					Value = 1,
					Num = 35778,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 15,
				},
				{
					Value = 1,
					Num = 43278,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 15,
				},
				{
					Value = 1,
					Num = 43278,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 276,
				},
				{
					Value = 320052,
					Num = 185,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 55,
				},
				{
					Value = 320053,
					Num = 37,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 11,
				},
				{
					Value = 320054,
					Num = 7,
				},
			},
		},
	},
	DemandID = 412933,
	DemandGroupList = {
		420010,
		420011,
		420012,
		420013,
		420014,
		420015,
	},
}
DemandConfig[DemandID.Id2934] =
{
	Id = 2934,
	Name = "惊险旅行",
	Desc = "来到无人岛上旅行，暂时用队员服做一下床单吧。",
	Value = 321810,
	Active = false,
	Weight = 79255,
	PreGoal = 
	{
		301938,
		301730,
	},
	GoodsId = 191810,
	Num = 108,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 296714,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 504,
				},
				{
					Value = 1,
					Num = 44714,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 504,
				},
				{
					Value = 1,
					Num = 44714,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 100,
				},
				{
					Value = 1,
					Num = 46714,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 100,
				},
				{
					Value = 1,
					Num = 46714,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 20,
				},
				{
					Value = 1,
					Num = 46714,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 20,
				},
				{
					Value = 1,
					Num = 46714,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 356,
				},
				{
					Value = 320052,
					Num = 237,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 71,
				},
				{
					Value = 320053,
					Num = 47,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 14,
				},
				{
					Value = 320054,
					Num = 9,
				},
			},
		},
	},
	DemandID = 412934,
	DemandGroupList = {
		420010,
		420011,
		420012,
		420013,
		420014,
		420015,
	},
}
DemandConfig[DemandID.Id2942] =
{
	Id = 2942,
	Name = "洁厕之王",
	Desc = "厕所太脏了，需要用很多强力海绵擦干净。",
	Value = 321811,
	Active = true,
	Weight = 80625,
	PreGoal = 
	{
		301700,
		301720,
	},
	GoodsId = 131811,
	Num = 57,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 152525,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 259,
				},
				{
					Value = 1,
					Num = 23025,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 259,
				},
				{
					Value = 1,
					Num = 23025,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 51,
				},
				{
					Value = 1,
					Num = 25025,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 51,
				},
				{
					Value = 1,
					Num = 25025,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 10,
				},
				{
					Value = 1,
					Num = 27525,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 10,
				},
				{
					Value = 1,
					Num = 27525,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 915,
				},
				{
					Value = 320051,
					Num = 610,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 183,
				},
				{
					Value = 320052,
					Num = 122,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 36,
				},
				{
					Value = 320053,
					Num = 25,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 7,
				},
				{
					Value = 320054,
					Num = 5,
				},
			},
		},
	},
	DemandID = 412942,
	DemandGroupList = {
		420010,
		420011,
		420012,
		420013,
		420014,
		420015,
	},
}
DemandConfig[DemandID.Id2943] =
{
	Id = 2943,
	Name = "洁厕之王",
	Desc = "厕所太脏了，需要用很多强力海绵擦干净。",
	Value = 321811,
	Active = false,
	Weight = 81875,
	PreGoal = 
	{
		301700,
		301730,
	},
	GoodsId = 161811,
	Num = 84,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 224774,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 382,
				},
				{
					Value = 1,
					Num = 33774,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 382,
				},
				{
					Value = 1,
					Num = 33774,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 76,
				},
				{
					Value = 1,
					Num = 34774,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 76,
				},
				{
					Value = 1,
					Num = 34774,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 15,
				},
				{
					Value = 1,
					Num = 37274,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 15,
				},
				{
					Value = 1,
					Num = 37274,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 269,
				},
				{
					Value = 320052,
					Num = 180,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 53,
				},
				{
					Value = 320053,
					Num = 36,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 10,
				},
				{
					Value = 320054,
					Num = 7,
				},
			},
		},
	},
	DemandID = 412943,
	DemandGroupList = {
		420010,
		420011,
		420012,
		420013,
		420014,
		420015,
	},
}
DemandConfig[DemandID.Id2944] =
{
	Id = 2944,
	Name = "洁厕之王",
	Desc = "厕所太脏了，需要用很多强力海绵擦干净。",
	Value = 321811,
	Active = false,
	Weight = 81875,
	PreGoal = 
	{
		301700,
		301730,
	},
	GoodsId = 191811,
	Num = 108,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 288996,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 491,
				},
				{
					Value = 1,
					Num = 43496,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 491,
				},
				{
					Value = 1,
					Num = 43496,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 98,
				},
				{
					Value = 1,
					Num = 43996,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 98,
				},
				{
					Value = 1,
					Num = 43996,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 19,
				},
				{
					Value = 1,
					Num = 51496,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 19,
				},
				{
					Value = 1,
					Num = 51496,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 346,
				},
				{
					Value = 320052,
					Num = 231,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 69,
				},
				{
					Value = 320053,
					Num = 46,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 13,
				},
				{
					Value = 320054,
					Num = 10,
				},
			},
		},
	},
	DemandID = 412944,
	DemandGroupList = {
		420010,
		420011,
		420012,
		420013,
		420014,
		420015,
	},
}
DemandConfig[DemandID.Id2952] =
{
	Id = 2952,
	Name = "偶像的魅力",
	Desc = "见面会就快到了，一定要准备好应援棒。",
	Value = 321812,
	Active = true,
	Weight = 83185,
	PreGoal = 
	{
		301710,
		301730,
	},
	GoodsId = 131812,
	Num = 57,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 157301,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 267,
				},
				{
					Value = 1,
					Num = 23801,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 267,
				},
				{
					Value = 1,
					Num = 23801,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 53,
				},
				{
					Value = 1,
					Num = 24801,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 53,
				},
				{
					Value = 1,
					Num = 24801,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 10,
				},
				{
					Value = 1,
					Num = 32301,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 10,
				},
				{
					Value = 1,
					Num = 32301,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 943,
				},
				{
					Value = 320051,
					Num = 630,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 188,
				},
				{
					Value = 320052,
					Num = 126,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 37,
				},
				{
					Value = 320053,
					Num = 25,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 7,
				},
				{
					Value = 320054,
					Num = 5,
				},
			},
		},
	},
	DemandID = 412952,
	DemandGroupList = {
		420010,
		420011,
		420012,
		420013,
		420014,
		420015,
	},
}
DemandConfig[DemandID.Id2953] =
{
	Id = 2953,
	Name = "偶像的魅力",
	Desc = "见面会就快到了，一定要准备好应援棒。",
	Value = 321812,
	Active = false,
	Weight = 83185,
	PreGoal = 
	{
		301710,
		301730,
	},
	GoodsId = 161812,
	Num = 84,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 231813,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 394,
				},
				{
					Value = 1,
					Num = 34813,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 394,
				},
				{
					Value = 1,
					Num = 34813,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 78,
				},
				{
					Value = 1,
					Num = 36813,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 78,
				},
				{
					Value = 1,
					Num = 36813,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 15,
				},
				{
					Value = 1,
					Num = 44313,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 15,
				},
				{
					Value = 1,
					Num = 44313,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 278,
				},
				{
					Value = 320052,
					Num = 185,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 55,
				},
				{
					Value = 320053,
					Num = 37,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 11,
				},
				{
					Value = 320054,
					Num = 7,
				},
			},
		},
	},
	DemandID = 412953,
	DemandGroupList = {
		420010,
		420011,
		420012,
		420013,
		420014,
		420015,
	},
}
DemandConfig[DemandID.Id2954] =
{
	Id = 2954,
	Name = "偶像的魅力",
	Desc = "见面会就快到了，一定要准备好应援棒。",
	Value = 321812,
	Active = false,
	Weight = 83185,
	PreGoal = 
	{
		301710,
		301730,
	},
	GoodsId = 191812,
	Num = 108,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 298045,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 506,
				},
				{
					Value = 1,
					Num = 45045,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 506,
				},
				{
					Value = 1,
					Num = 45045,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 101,
				},
				{
					Value = 1,
					Num = 45545,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 101,
				},
				{
					Value = 1,
					Num = 45545,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 20,
				},
				{
					Value = 1,
					Num = 48045,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 20,
				},
				{
					Value = 1,
					Num = 48045,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 357,
				},
				{
					Value = 320052,
					Num = 239,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 71,
				},
				{
					Value = 320053,
					Num = 48,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 14,
				},
				{
					Value = 320054,
					Num = 9,
				},
			},
		},
	},
	DemandID = 412954,
	DemandGroupList = {
		420010,
		420011,
		420012,
		420013,
		420014,
		420015,
	},
}
DemandConfig[DemandID.Id2962] =
{
	Id = 2962,
	Name = "选拔结束",
	Desc = "今天选拔就结束了，要准备好属于正式队员们的服装！",
	Value = 321851,
	Active = true,
	Weight = 45375,
	PreGoal = 
	{
		301965,
		301700,
	},
	GoodsId = 131851,
	Num = 18,
	RewardList = {
		{
			Weight = 0,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 418022,
				},
			},
		},
		{
			Weight = 60,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320002,
					Num = 14,
				},
				{
					Value = 1,
					Num = 55142,
				},
			},
		},
		{
			Weight = 40,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320003,
					Num = 4,
				},
				{
					Value = 1,
					Num = 72422,
				},
			},
		},
	},
	DemandID = 412962,
	DemandGroupList = {
		420010,
		420011,
		420012,
		420013,
		420014,
		420015,
	},
}
DemandConfig[DemandID.Id2963] =
{
	Id = 2963,
	Name = "选拔结束",
	Desc = "今天选拔就结束了，要准备好属于正式队员们的服装！",
	Value = 321851,
	Active = false,
	Weight = 47553,
	PreGoal = 
	{
		301965,
		301730,
	},
	GoodsId = 161851,
	Num = 21,
	RewardList = {
		{
			Weight = 0,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 487693,
				},
			},
		},
		{
			Weight = 60,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320002,
					Num = 17,
				},
				{
					Value = 1,
					Num = 47053,
				},
			},
		},
		{
			Weight = 40,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320003,
					Num = 5,
				},
				{
					Value = 1,
					Num = 55693,
				},
			},
		},
	},
	DemandID = 412963,
	DemandGroupList = {
		420010,
		420011,
		420012,
		420013,
		420014,
		420015,
	},
}
DemandConfig[DemandID.Id2964] =
{
	Id = 2964,
	Name = "选拔结束",
	Desc = "今天选拔就结束了，要准备好属于正式队员们的服装！",
	Value = 321851,
	Active = false,
	Weight = 47553,
	PreGoal = 
	{
		301965,
		301730,
	},
	GoodsId = 191851,
	Num = 24,
	RewardList = {
		{
			Weight = 0,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 557363,
				},
			},
		},
		{
			Weight = 60,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320002,
					Num = 19,
				},
				{
					Value = 1,
					Num = 64883,
				},
			},
		},
		{
			Weight = 40,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320003,
					Num = 5,
				},
				{
					Value = 1,
					Num = 125363,
				},
			},
		},
	},
	DemandID = 412964,
	DemandGroupList = {
		420010,
		420011,
		420012,
		420013,
		420014,
		420015,
	},
}
DemandConfig[DemandID.Id2972] =
{
	Id = 2972,
	Name = "纪念礼物",
	Desc = "海洋星来了一批游客，需要准备好售卖的商品。",
	Value = 321852,
	Active = true,
	Weight = 48375,
	PreGoal = 
	{
		301967,
		301720,
	},
	GoodsId = 131852,
	Num = 18,
	RewardList = {
		{
			Weight = 0,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 435128,
				},
			},
		},
		{
			Weight = 60,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320002,
					Num = 15,
				},
				{
					Value = 1,
					Num = 46328,
				},
			},
		},
		{
			Weight = 40,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320003,
					Num = 4,
				},
				{
					Value = 1,
					Num = 89528,
				},
			},
		},
	},
	DemandID = 412972,
	DemandGroupList = {
		420010,
		420011,
		420012,
		420013,
		420014,
		420015,
	},
}
DemandConfig[DemandID.Id2973] =
{
	Id = 2973,
	Name = "纪念礼物",
	Desc = "海洋星来了一批游客，需要准备好售卖的商品。",
	Value = 321852,
	Active = false,
	Weight = 49125,
	PreGoal = 
	{
		301967,
		301730,
	},
	GoodsId = 161852,
	Num = 18,
	RewardList = {
		{
			Weight = 0,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 435128,
				},
			},
		},
		{
			Weight = 60,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320002,
					Num = 15,
				},
				{
					Value = 1,
					Num = 46328,
				},
			},
		},
		{
			Weight = 40,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320003,
					Num = 4,
				},
				{
					Value = 1,
					Num = 89528,
				},
			},
		},
	},
	DemandID = 412973,
	DemandGroupList = {
		420010,
		420011,
		420012,
		420013,
		420014,
		420015,
	},
}
DemandConfig[DemandID.Id2974] =
{
	Id = 2974,
	Name = "纪念礼物",
	Desc = "海洋星来了一批游客，需要准备好售卖的商品。",
	Value = 321852,
	Active = false,
	Weight = 49125,
	PreGoal = 
	{
		301967,
		301730,
	},
	GoodsId = 191852,
	Num = 22,
	RewardList = {
		{
			Weight = 0,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 531823,
				},
			},
		},
		{
			Weight = 60,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320002,
					Num = 18,
				},
				{
					Value = 1,
					Num = 65263,
				},
			},
		},
		{
			Weight = 40,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320003,
					Num = 5,
				},
				{
					Value = 1,
					Num = 99823,
				},
			},
		},
	},
	DemandID = 412974,
	DemandGroupList = {
		420010,
		420011,
		420012,
		420013,
		420014,
		420015,
	},
}
DemandConfig[DemandID.Id2982] =
{
	Id = 2982,
	Name = "胜利的方法",
	Desc = "和粉丝吵起来了？甩出几张签名照让TA们闭嘴吧！",
	Value = 321853,
	Active = true,
	Weight = 49911,
	PreGoal = 
	{
		301968,
		301730,
	},
	GoodsId = 131853,
	Num = 18,
	RewardList = {
		{
			Weight = 0,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 467428,
				},
			},
		},
		{
			Weight = 60,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320002,
					Num = 16,
				},
				{
					Value = 1,
					Num = 52708,
				},
			},
		},
		{
			Weight = 40,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320003,
					Num = 4,
				},
				{
					Value = 1,
					Num = 121828,
				},
			},
		},
	},
	DemandID = 412982,
	DemandGroupList = {
		420010,
		420011,
		420012,
		420013,
		420014,
		420015,
	},
}
DemandConfig[DemandID.Id2983] =
{
	Id = 2983,
	Name = "胜利的方法",
	Desc = "和粉丝吵起来了？甩出几张签名照让TA们闭嘴吧！",
	Value = 321853,
	Active = false,
	Weight = 49911,
	PreGoal = 
	{
		301968,
		301730,
	},
	GoodsId = 161853,
	Num = 18,
	RewardList = {
		{
			Weight = 0,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 467428,
				},
			},
		},
		{
			Weight = 60,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320002,
					Num = 16,
				},
				{
					Value = 1,
					Num = 52708,
				},
			},
		},
		{
			Weight = 40,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320003,
					Num = 4,
				},
				{
					Value = 1,
					Num = 121828,
				},
			},
		},
	},
	DemandID = 412983,
	DemandGroupList = {
		420010,
		420011,
		420012,
		420013,
		420014,
		420015,
	},
}
DemandConfig[DemandID.Id2984] =
{
	Id = 2984,
	Name = "胜利的方法",
	Desc = "和粉丝吵起来了？甩出几张签名照让TA们闭嘴吧！",
	Value = 321853,
	Active = false,
	Weight = 49911,
	PreGoal = 
	{
		301968,
		301730,
	},
	GoodsId = 191853,
	Num = 21,
	RewardList = {
		{
			Weight = 0,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 545333,
				},
			},
		},
		{
			Weight = 60,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320002,
					Num = 19,
				},
				{
					Value = 1,
					Num = 52853,
				},
			},
		},
		{
			Weight = 40,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320003,
					Num = 5,
				},
				{
					Value = 1,
					Num = 113333,
				},
			},
		},
	},
	DemandID = 412984,
	DemandGroupList = {
		420010,
		420011,
		420012,
		420013,
		420014,
		420015,
	},
}
DemandConfig[DemandID.Id2992] =
{
	Id = 2992,
	Name = "保护架子鼓",
	Desc = "有人投诉练习室的声音太大，快把架子鼓们送到安全地方。",
	Value = 321854,
	Active = true,
	Weight = 51090,
	PreGoal = 
	{
		301966,
		301730,
	},
	GoodsId = 131854,
	Num = 15,
	RewardList = {
		{
			Weight = 0,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 421180,
				},
			},
		},
		{
			Weight = 60,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320002,
					Num = 14,
				},
				{
					Value = 1,
					Num = 58300,
				},
			},
		},
		{
			Weight = 40,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320003,
					Num = 4,
				},
				{
					Value = 1,
					Num = 75580,
				},
			},
		},
	},
	DemandID = 412992,
	DemandGroupList = {
		420010,
		420011,
		420012,
		420013,
		420014,
		420015,
	},
}
DemandConfig[DemandID.Id2993] =
{
	Id = 2993,
	Name = "保护架子鼓",
	Desc = "有人投诉练习室的声音太大，快把架子鼓们送到安全地方。",
	Value = 321854,
	Active = false,
	Weight = 51090,
	PreGoal = 
	{
		301966,
		301730,
	},
	GoodsId = 161854,
	Num = 18,
	RewardList = {
		{
			Weight = 0,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 505416,
				},
			},
		},
		{
			Weight = 60,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320002,
					Num = 17,
				},
				{
					Value = 1,
					Num = 64776,
				},
			},
		},
		{
			Weight = 40,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320003,
					Num = 5,
				},
				{
					Value = 1,
					Num = 73416,
				},
			},
		},
	},
	DemandID = 412993,
	DemandGroupList = {
		420010,
		420011,
		420012,
		420013,
		420014,
		420015,
	},
}
DemandConfig[DemandID.Id2994] =
{
	Id = 2994,
	Name = "保护架子鼓",
	Desc = "有人投诉练习室的声音太大，快把架子鼓们送到安全地方。",
	Value = 321854,
	Active = false,
	Weight = 51090,
	PreGoal = 
	{
		301966,
		301730,
	},
	GoodsId = 191854,
	Num = 18,
	RewardList = {
		{
			Weight = 0,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 505416,
				},
			},
		},
		{
			Weight = 60,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320002,
					Num = 17,
				},
				{
					Value = 1,
					Num = 64776,
				},
			},
		},
		{
			Weight = 40,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320003,
					Num = 5,
				},
				{
					Value = 1,
					Num = 73416,
				},
			},
		},
	},
	DemandID = 412994,
	DemandGroupList = {
		420010,
		420011,
		420012,
		420013,
		420014,
		420015,
	},
}
DemandConfig[DemandID.Id5001] =
{
	Id = 5001,
	Name = "寻找左半藏宝图",
	Desc = "只要有半边藏宝图，鄙人的伟大事业就能开始了！",
	Value = 327301,
	Active = true,
	Weight = 3000000,
	PreGoal = 
	{
		307005,
		300058,
	},
	GoodsId = 117301,
	Num = 25,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 18750,
				},
			},
		},
	},
	DemandID = 415001,
	DemandGroupList = {
		420010,
	},
}
DemandConfig[DemandID.Id5002] =
{
	Id = 5002,
	Name = "0",
	Desc = "0",
	Value = 327301,
	Active = false,
	Weight = 3000000,
	PreGoal = 
	{
		307005,
		300066,
	},
	GoodsId = 127301,
	Num = 30,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 22500,
				},
			},
		},
	},
	DemandID = 415002,
	DemandGroupList = {
		420010,
	},
}
DemandConfig[DemandID.Id5003] =
{
	Id = 5003,
	Name = "再寻右半藏宝图",
	Desc = "半边藏宝图竟然找不到宝藏！急求另半边！",
	Value = 327302,
	Active = true,
	Weight = 3000000,
	PreGoal = 
	{
		307008,
		300058,
	},
	GoodsId = 117302,
	Num = 25,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 21875,
				},
			},
		},
	},
	DemandID = 415003,
	DemandGroupList = {
		420010,
	},
}
DemandConfig[DemandID.Id5004] =
{
	Id = 5004,
	Name = "0",
	Desc = "0",
	Value = 327302,
	Active = false,
	Weight = 3000000,
	PreGoal = 
	{
		307008,
		300066,
	},
	GoodsId = 127302,
	Num = 30,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 26250,
				},
			},
		},
	},
	DemandID = 415004,
	DemandGroupList = {
		420010,
	},
}
DemandConfig[DemandID.Id5005] =
{
	Id = 5005,
	Name = "囤积年货",
	Desc = "都已经过年了，才发现没有准备这个！",
	Value = 327304,
	Active = true,
	Weight = 3000000,
	PreGoal = 
	{
		307030,
		300046,
	},
	GoodsId = 117304,
	Num = 20,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 4000,
				},
			},
		},
	},
	DemandID = 415005,
	DemandGroupList = {
		420011,
	},
}
DemandConfig[DemandID.Id5006] =
{
	Id = 5006,
	Name = "准备压岁钱",
	Desc = "打算准备一些礼物给自己的孙子。",
	Value = 327305,
	Active = true,
	Weight = 3000000,
	PreGoal = 
	{
		307032,
		300051,
	},
	GoodsId = 127305,
	Num = 20,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 6000,
				},
			},
		},
	},
	DemandID = 415006,
	DemandGroupList = {
		420011,
	},
}
DemandConfig[DemandID.Id5007] =
{
	Id = 5007,
	Name = "新馆子开张",
	Desc = "客人说菜品味道不够劲，急求秘制酱汁！",
	Value = 327307,
	Active = true,
	Weight = 3000000,
	PreGoal = 
	{
		307047,
		300046,
	},
	GoodsId = 117307,
	Num = 20,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 6000,
				},
			},
		},
	},
	DemandID = 415007,
	DemandGroupList = {
		420012,
	},
}
DemandConfig[DemandID.Id5008] =
{
	Id = 5008,
	Name = "厨神的修行",
	Desc = "一辈子都在做美味的料理，是时候开拓一下眼界了。",
	Value = 327308,
	Active = true,
	Weight = 3000000,
	PreGoal = 
	{
		307049,
		300046,
	},
	GoodsId = 127308,
	Num = 20,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 9100,
				},
			},
		},
	},
	DemandID = 415008,
	DemandGroupList = {
		420012,
	},
}
DemandConfig[DemandID.Id5009] =
{
	Id = 5009,
	Name = "沐浴仪式感",
	Desc = "老是被说洗澡不干净，这次要加点这个试一下！",
	Value = 327309,
	Active = true,
	Weight = 3000000,
	PreGoal = 
	{
		307057,
		300046,
	},
	GoodsId = 117309,
	Num = 20,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 6000,
				},
			},
		},
	},
	DemandID = 415009,
	DemandGroupList = {
		420013,
	},
}
DemandConfig[DemandID.Id5010] =
{
	Id = 5010,
	Name = "包大粽子",
	Desc = "这次的粽子要做史无前例的特大号，急需大量绳子！",
	Value = 327310,
	Active = true,
	Weight = 3000000,
	PreGoal = 
	{
		307059,
		300046,
	},
	GoodsId = 127310,
	Num = 20,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 9100,
				},
			},
		},
	},
	DemandID = 415010,
	DemandGroupList = {
		420013,
	},
}
DemandConfig[DemandID.Id5011] =
{
	Id = 5011,
	Name = "缝制衣裳",
	Desc = "外套破洞了，给我些白丝吧？我自己来缝。",
	Value = 327312,
	Active = true,
	Weight = 3000000,
	PreGoal = 
	{
		307067,
		300046,
	},
	GoodsId = 117312,
	Num = 15,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 4500,
				},
			},
		},
	},
	DemandID = 415011,
	DemandGroupList = {
		420014,
	},
}
DemandConfig[DemandID.Id5012] =
{
	Id = 5012,
	Name = "捞鱼店的请求",
	Desc = "捞鱼店的鱼线用完了，急需白丝作为替代品！",
	Value = 327312,
	Active = false,
	Weight = 3000000,
	PreGoal = 
	{
		307067,
		300046,
	},
	GoodsId = 117312,
	Num = 30,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 9000,
				},
			},
		},
	},
	DemandID = 415012,
	DemandGroupList = {
		420014,
	},
}
DemandConfig[DemandID.Id5013] =
{
	Id = 5013,
	Name = "嗑瓜子的快乐",
	Desc = "想体验嗑瓜子的快乐，只是果壳也行吧？",
	Value = 327313,
	Active = true,
	Weight = 3000000,
	PreGoal = 
	{
		307069,
		300046,
	},
	GoodsId = 127313,
	Num = 15,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 6825,
				},
			},
		},
	},
	DemandID = 415013,
	DemandGroupList = {
		420014,
	},
}
DemandConfig[DemandID.Id5014] =
{
	Id = 5014,
	Name = "打扫地面",
	Desc = "竟然在这儿嗑果子乱扔壳？请帮忙清扫一下！",
	Value = 327313,
	Active = false,
	Weight = 3000000,
	PreGoal = 
	{
		307069,
		300055,
	},
	GoodsId = 127313,
	Num = 30,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 13650,
				},
			},
		},
	},
	DemandID = 415014,
	DemandGroupList = {
		420014,
	},
}
DemandConfig[DemandID.Id5015] =
{
	Id = 5015,
	Name = "呼朋唤友",
	Desc = "我系渣渣灰，系兄弟就来侃我。",
	Value = 327318,
	Active = true,
	Weight = 3000000,
	PreGoal = 
	{
		307077,
		300046,
	},
	GoodsId = 117318,
	Num = 15,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 4500,
				},
			},
		},
	},
	DemandID = 415015,
	DemandGroupList = {
		420015,
	},
}
DemandConfig[DemandID.Id5016] =
{
	Id = 5016,
	Name = "流行美黑术",
	Desc = "听说现在黑皮肤更受女孩子欢迎呢~",
	Value = 327318,
	Active = false,
	Weight = 3000000,
	PreGoal = 
	{
		307077,
		300046,
	},
	GoodsId = 117318,
	Num = 30,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 9000,
				},
			},
		},
	},
	DemandID = 415016,
	DemandGroupList = {
		420015,
	},
}
DemandConfig[DemandID.Id5017] =
{
	Id = 5017,
	Name = "加冰可乐",
	Desc = "可乐就得加冰，加大块冰！",
	Value = 327319,
	Active = true,
	Weight = 3000000,
	PreGoal = 
	{
		307079,
		300046,
	},
	GoodsId = 127319,
	Num = 15,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 6825,
				},
			},
		},
	},
	DemandID = 415017,
	DemandGroupList = {
		420015,
	},
}
DemandConfig[DemandID.Id5018] =
{
	Id = 5018,
	Name = "降温",
	Desc = "最近头脑发热，可以帮我降降温吗？",
	Value = 327319,
	Active = false,
	Weight = 3000000,
	PreGoal = 
	{
		307079,
		300055,
	},
	GoodsId = 127319,
	Num = 30,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 13650,
				},
			},
		},
	},
	DemandID = 415018,
	DemandGroupList = {
		420015,
	},
}
