
EquipmentConfig[EquipmentID.Id693] =
{
	Character = 223131,
	Rarity = 4,
	NeedChallenge = 145271,
	UpgradeId = 930035,
	LevelList = {
		{
			Level = 1,
			Info = 920727,
			Ability = {
				{
					Value = 200001,
					Num = 156,
				},
			},
		},
		{
			Level = 2,
			Info = 920727,
			Ability = {
				{
					Value = 200001,
					Num = 260,
				},
			},
		},
		{
			Level = 3,
			Info = 920727,
			Ability = {
				{
					Value = 200001,
					Num = 364,
				},
			},
		},
		{
			Level = 4,
			Info = 920727,
			Ability = {
				{
					Value = 200001,
					Num = 468,
				},
			},
		},
		{
			Level = 5,
			Info = 920727,
			Ability = {
				{
					Value = 200001,
					Num = 572,
				},
				{
					Value = 200003,
					Num = 25,
				},
			},
		},
		{
			Level = 6,
			Info = 920727,
			Ability = {
				{
					Value = 200001,
					Num = 676,
				},
				{
					Value = 200003,
					Num = 30,
				},
			},
		},
		{
			Level = 7,
			Info = 920727,
			Ability = {
				{
					Value = 200001,
					Num = 780,
				},
				{
					Value = 200003,
					Num = 35,
				},
			},
		},
		{
			Level = 8,
			Info = 920727,
			Ability = {
				{
					Value = 200001,
					Num = 884,
				},
				{
					Value = 200003,
					Num = 40,
				},
			},
			SkillList = {
				{
					Id = 101759,
					Value = 48,
				},
			},
		},
		{
			Level = 9,
			Info = 920727,
			Ability = {
				{
					Value = 200001,
					Num = 988,
				},
				{
					Value = 200003,
					Num = 45,
				},
			},
			SkillList = {
				{
					Id = 101759,
					Value = 48,
				},
			},
		},
		{
			Level = 10,
			Info = 920727,
			Ability = {
				{
					Value = 200001,
					Num = 1092,
				},
				{
					Value = 200003,
					Num = 50,
				},
			},
			SkillList = {
				{
					Id = 101759,
					Value = 48,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id694] =
{
	Character = 223132,
	Rarity = 4,
	UpgradeId = 930013,
	LevelList = {
		{
			Level = 1,
			Info = 920728,
			Ability = {
				{
					Value = 200002,
					Num = 54,
				},
				{
					Value = 200005,
					Num = 12,
				},
			},
		},
		{
			Level = 2,
			Info = 920728,
			Ability = {
				{
					Value = 200002,
					Num = 108,
				},
				{
					Value = 200005,
					Num = 24,
				},
			},
		},
		{
			Level = 3,
			Info = 920728,
			Ability = {
				{
					Value = 200002,
					Num = 162,
				},
				{
					Value = 200005,
					Num = 36,
				},
			},
		},
		{
			Level = 4,
			Info = 920728,
			Ability = {
				{
					Value = 200002,
					Num = 216,
				},
				{
					Value = 200005,
					Num = 48,
				},
			},
		},
		{
			Level = 5,
			Info = 920728,
			Ability = {
				{
					Value = 200002,
					Num = 270,
				},
				{
					Value = 200005,
					Num = 60,
				},
			},
		},
		{
			Level = 6,
			Info = 920728,
			Ability = {
				{
					Value = 200002,
					Num = 324,
				},
				{
					Value = 200005,
					Num = 72,
				},
			},
		},
		{
			Level = 7,
			Info = 920728,
			Ability = {
				{
					Value = 200002,
					Num = 378,
				},
				{
					Value = 200005,
					Num = 84,
				},
			},
		},
		{
			Level = 8,
			Info = 920728,
			Ability = {
				{
					Value = 200002,
					Num = 432,
				},
				{
					Value = 200005,
					Num = 96,
				},
			},
			SkillList = {
				{
					Id = 101745,
					Value = 60,
				},
			},
		},
		{
			Level = 9,
			Info = 920728,
			Ability = {
				{
					Value = 200002,
					Num = 486,
				},
				{
					Value = 200005,
					Num = 108,
				},
			},
			SkillList = {
				{
					Id = 101745,
					Value = 60,
				},
			},
		},
		{
			Level = 10,
			Info = 920728,
			Ability = {
				{
					Value = 200002,
					Num = 540,
				},
				{
					Value = 200005,
					Num = 120,
				},
			},
			SkillList = {
				{
					Id = 101745,
					Value = 60,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id695] =
{
	Character = 223132,
	Rarity = 4,
	UpgradeId = 930034,
	LevelList = {
		{
			Level = 1,
			Info = 920729,
			Ability = {
				{
					Value = 200001,
					Num = 75,
				},
				{
					Value = 200007,
					Num = 9,
				},
			},
		},
		{
			Level = 2,
			Info = 920729,
			Ability = {
				{
					Value = 200001,
					Num = 150,
				},
				{
					Value = 200007,
					Num = 18,
				},
			},
		},
		{
			Level = 3,
			Info = 920729,
			Ability = {
				{
					Value = 200001,
					Num = 225,
				},
				{
					Value = 200007,
					Num = 27,
				},
			},
		},
		{
			Level = 4,
			Info = 920729,
			Ability = {
				{
					Value = 200001,
					Num = 300,
				},
				{
					Value = 200007,
					Num = 36,
				},
			},
		},
		{
			Level = 5,
			Info = 920729,
			Ability = {
				{
					Value = 200001,
					Num = 375,
				},
				{
					Value = 200007,
					Num = 45,
				},
			},
		},
		{
			Level = 6,
			Info = 920729,
			Ability = {
				{
					Value = 200001,
					Num = 450,
				},
				{
					Value = 200007,
					Num = 54,
				},
			},
		},
		{
			Level = 7,
			Info = 920729,
			Ability = {
				{
					Value = 200001,
					Num = 525,
				},
				{
					Value = 200007,
					Num = 63,
				},
			},
		},
		{
			Level = 8,
			Info = 920729,
			Ability = {
				{
					Value = 200001,
					Num = 600,
				},
				{
					Value = 200007,
					Num = 72,
				},
			},
			SkillList = {
				{
					Id = 101528,
					Value = -29,
				},
			},
		},
		{
			Level = 9,
			Info = 920729,
			Ability = {
				{
					Value = 200001,
					Num = 675,
				},
				{
					Value = 200007,
					Num = 81,
				},
			},
			SkillList = {
				{
					Id = 101528,
					Value = -29,
				},
			},
		},
		{
			Level = 10,
			Info = 920729,
			Ability = {
				{
					Value = 200001,
					Num = 750,
				},
				{
					Value = 200007,
					Num = 90,
				},
			},
			SkillList = {
				{
					Id = 101528,
					Value = -29,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id696] =
{
	Character = 223132,
	Rarity = 4,
	NeedChallenge = 145272,
	UpgradeId = 930035,
	LevelList = {
		{
			Level = 1,
			Info = 920730,
			Ability = {
				{
					Value = 200001,
					Num = 150,
				},
			},
		},
		{
			Level = 2,
			Info = 920730,
			Ability = {
				{
					Value = 200001,
					Num = 250,
				},
			},
		},
		{
			Level = 3,
			Info = 920730,
			Ability = {
				{
					Value = 200001,
					Num = 350,
				},
			},
		},
		{
			Level = 4,
			Info = 920730,
			Ability = {
				{
					Value = 200001,
					Num = 450,
				},
			},
		},
		{
			Level = 5,
			Info = 920730,
			Ability = {
				{
					Value = 200001,
					Num = 550,
				},
				{
					Value = 200003,
					Num = 25,
				},
			},
		},
		{
			Level = 6,
			Info = 920730,
			Ability = {
				{
					Value = 200001,
					Num = 650,
				},
				{
					Value = 200003,
					Num = 30,
				},
			},
		},
		{
			Level = 7,
			Info = 920730,
			Ability = {
				{
					Value = 200001,
					Num = 750,
				},
				{
					Value = 200003,
					Num = 35,
				},
			},
		},
		{
			Level = 8,
			Info = 920730,
			Ability = {
				{
					Value = 200001,
					Num = 850,
				},
				{
					Value = 200003,
					Num = 40,
				},
			},
			SkillList = {
				{
					Id = 101529,
					Value = -29,
				},
			},
		},
		{
			Level = 9,
			Info = 920730,
			Ability = {
				{
					Value = 200001,
					Num = 950,
				},
				{
					Value = 200003,
					Num = 45,
				},
			},
			SkillList = {
				{
					Id = 101529,
					Value = -29,
				},
			},
		},
		{
			Level = 10,
			Info = 920730,
			Ability = {
				{
					Value = 200001,
					Num = 1050,
				},
				{
					Value = 200003,
					Num = 50,
				},
			},
			SkillList = {
				{
					Id = 101529,
					Value = -29,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id697] =
{
	Character = 223133,
	Rarity = 4,
	UpgradeId = 930033,
	LevelList = {
		{
			Level = 1,
			Info = 920731,
			Ability = {
				{
					Value = 200001,
					Num = 69,
				},
				{
					Value = 200005,
					Num = 12,
				},
			},
		},
		{
			Level = 2,
			Info = 920731,
			Ability = {
				{
					Value = 200001,
					Num = 138,
				},
				{
					Value = 200005,
					Num = 24,
				},
			},
		},
		{
			Level = 3,
			Info = 920731,
			Ability = {
				{
					Value = 200001,
					Num = 207,
				},
				{
					Value = 200005,
					Num = 36,
				},
			},
		},
		{
			Level = 4,
			Info = 920731,
			Ability = {
				{
					Value = 200001,
					Num = 276,
				},
				{
					Value = 200005,
					Num = 48,
				},
			},
		},
		{
			Level = 5,
			Info = 920731,
			Ability = {
				{
					Value = 200001,
					Num = 345,
				},
				{
					Value = 200005,
					Num = 60,
				},
			},
		},
		{
			Level = 6,
			Info = 920731,
			Ability = {
				{
					Value = 200001,
					Num = 414,
				},
				{
					Value = 200005,
					Num = 72,
				},
			},
		},
		{
			Level = 7,
			Info = 920731,
			Ability = {
				{
					Value = 200001,
					Num = 483,
				},
				{
					Value = 200005,
					Num = 84,
				},
			},
		},
		{
			Level = 8,
			Info = 920731,
			Ability = {
				{
					Value = 200001,
					Num = 552,
				},
				{
					Value = 200005,
					Num = 96,
				},
			},
			SkillList = {
				{
					Id = 100652,
					Value = 7,
				},
			},
		},
		{
			Level = 9,
			Info = 920731,
			Ability = {
				{
					Value = 200001,
					Num = 621,
				},
				{
					Value = 200005,
					Num = 108,
				},
			},
			SkillList = {
				{
					Id = 100652,
					Value = 7,
				},
			},
		},
		{
			Level = 10,
			Info = 920731,
			Ability = {
				{
					Value = 200001,
					Num = 690,
				},
				{
					Value = 200005,
					Num = 120,
				},
			},
			SkillList = {
				{
					Id = 100652,
					Value = 7,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id698] =
{
	Character = 223133,
	Rarity = 4,
	UpgradeId = 930014,
	LevelList = {
		{
			Level = 1,
			Info = 920732,
			Ability = {
				{
					Value = 200002,
					Num = 63,
				},
			},
		},
		{
			Level = 2,
			Info = 920732,
			Ability = {
				{
					Value = 200002,
					Num = 126,
				},
			},
		},
		{
			Level = 3,
			Info = 920732,
			Ability = {
				{
					Value = 200002,
					Num = 189,
				},
			},
		},
		{
			Level = 4,
			Info = 920732,
			Ability = {
				{
					Value = 200002,
					Num = 252,
				},
			},
		},
		{
			Level = 5,
			Info = 920732,
			Ability = {
				{
					Value = 200002,
					Num = 315,
				},
			},
			SkillList = {
				{
					Id = 100798,
					Value = 2,
				},
			},
		},
		{
			Level = 6,
			Info = 920732,
			Ability = {
				{
					Value = 200002,
					Num = 378,
				},
			},
			SkillList = {
				{
					Id = 100798,
					Value = 2,
				},
			},
		},
		{
			Level = 7,
			Info = 920732,
			Ability = {
				{
					Value = 200002,
					Num = 441,
				},
			},
			SkillList = {
				{
					Id = 100798,
					Value = 2,
				},
			},
		},
		{
			Level = 8,
			Info = 920732,
			Ability = {
				{
					Value = 200002,
					Num = 504,
				},
			},
			SkillList = {
				{
					Id = 100798,
					Value = 2,
				},
				{
					Id = 100800,
					Value = 16,
				},
			},
		},
		{
			Level = 9,
			Info = 920732,
			Ability = {
				{
					Value = 200002,
					Num = 567,
				},
			},
			SkillList = {
				{
					Id = 100798,
					Value = 2,
				},
				{
					Id = 100800,
					Value = 16,
				},
			},
		},
		{
			Level = 10,
			Info = 920732,
			Ability = {
				{
					Value = 200002,
					Num = 630,
				},
			},
			SkillList = {
				{
					Id = 100798,
					Value = 2,
				},
				{
					Id = 100800,
					Value = 16,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id699] =
{
	Character = 223133,
	Rarity = 4,
	NeedChallenge = 145273,
	UpgradeId = 930015,
	LevelList = {
		{
			Level = 1,
			Info = 920733,
			Ability = {
				{
					Value = 200002,
					Num = 126,
				},
			},
		},
		{
			Level = 2,
			Info = 920733,
			Ability = {
				{
					Value = 200002,
					Num = 210,
				},
			},
		},
		{
			Level = 3,
			Info = 920733,
			Ability = {
				{
					Value = 200002,
					Num = 294,
				},
			},
		},
		{
			Level = 4,
			Info = 920733,
			Ability = {
				{
					Value = 200002,
					Num = 378,
				},
			},
		},
		{
			Level = 5,
			Info = 920733,
			Ability = {
				{
					Value = 200002,
					Num = 462,
				},
				{
					Value = 200004,
					Num = 25,
				},
			},
		},
		{
			Level = 6,
			Info = 920733,
			Ability = {
				{
					Value = 200002,
					Num = 546,
				},
				{
					Value = 200004,
					Num = 30,
				},
			},
		},
		{
			Level = 7,
			Info = 920733,
			Ability = {
				{
					Value = 200002,
					Num = 630,
				},
				{
					Value = 200004,
					Num = 35,
				},
			},
		},
		{
			Level = 8,
			Info = 920733,
			Ability = {
				{
					Value = 200002,
					Num = 714,
				},
				{
					Value = 200004,
					Num = 40,
				},
			},
			SkillList = {
				{
					Id = 101738,
					Value = 15,
				},
			},
		},
		{
			Level = 9,
			Info = 920733,
			Ability = {
				{
					Value = 200002,
					Num = 798,
				},
				{
					Value = 200004,
					Num = 45,
				},
			},
			SkillList = {
				{
					Id = 101738,
					Value = 15,
				},
			},
		},
		{
			Level = 10,
			Info = 920733,
			Ability = {
				{
					Value = 200002,
					Num = 882,
				},
				{
					Value = 200004,
					Num = 50,
				},
			},
			SkillList = {
				{
					Id = 101738,
					Value = 15,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id700] =
{
	Character = 223134,
	Rarity = 4,
	UpgradeId = 930013,
	LevelList = {
		{
			Level = 1,
			Info = 920734,
			Ability = {
				{
					Value = 200002,
					Num = 60,
				},
				{
					Value = 200008,
					Num = 12,
				},
			},
		},
		{
			Level = 2,
			Info = 920734,
			Ability = {
				{
					Value = 200002,
					Num = 120,
				},
				{
					Value = 200008,
					Num = 24,
				},
			},
		},
		{
			Level = 3,
			Info = 920734,
			Ability = {
				{
					Value = 200002,
					Num = 180,
				},
				{
					Value = 200008,
					Num = 36,
				},
			},
		},
		{
			Level = 4,
			Info = 920734,
			Ability = {
				{
					Value = 200002,
					Num = 240,
				},
				{
					Value = 200008,
					Num = 48,
				},
			},
		},
		{
			Level = 5,
			Info = 920734,
			Ability = {
				{
					Value = 200002,
					Num = 300,
				},
				{
					Value = 200008,
					Num = 60,
				},
			},
		},
		{
			Level = 6,
			Info = 920734,
			Ability = {
				{
					Value = 200002,
					Num = 360,
				},
				{
					Value = 200008,
					Num = 72,
				},
			},
		},
		{
			Level = 7,
			Info = 920734,
			Ability = {
				{
					Value = 200002,
					Num = 420,
				},
				{
					Value = 200008,
					Num = 84,
				},
			},
		},
		{
			Level = 8,
			Info = 920734,
			Ability = {
				{
					Value = 200002,
					Num = 480,
				},
				{
					Value = 200008,
					Num = 96,
				},
			},
			SkillList = {
				{
					Id = 100553,
					Value = 25,
				},
			},
		},
		{
			Level = 9,
			Info = 920734,
			Ability = {
				{
					Value = 200002,
					Num = 540,
				},
				{
					Value = 200008,
					Num = 108,
				},
			},
			SkillList = {
				{
					Id = 100553,
					Value = 25,
				},
			},
		},
		{
			Level = 10,
			Info = 920734,
			Ability = {
				{
					Value = 200002,
					Num = 600,
				},
				{
					Value = 200008,
					Num = 120,
				},
			},
			SkillList = {
				{
					Id = 100553,
					Value = 25,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id701] =
{
	Character = 223134,
	Rarity = 4,
	UpgradeId = 930014,
	LevelList = {
		{
			Level = 1,
			Info = 920735,
			Ability = {
				{
					Value = 200002,
					Num = 60,
				},
				{
					Value = 200005,
					Num = 9,
				},
			},
		},
		{
			Level = 2,
			Info = 920735,
			Ability = {
				{
					Value = 200002,
					Num = 120,
				},
				{
					Value = 200005,
					Num = 18,
				},
			},
		},
		{
			Level = 3,
			Info = 920735,
			Ability = {
				{
					Value = 200002,
					Num = 180,
				},
				{
					Value = 200005,
					Num = 27,
				},
			},
		},
		{
			Level = 4,
			Info = 920735,
			Ability = {
				{
					Value = 200002,
					Num = 240,
				},
				{
					Value = 200005,
					Num = 36,
				},
			},
		},
		{
			Level = 5,
			Info = 920735,
			Ability = {
				{
					Value = 200002,
					Num = 300,
				},
				{
					Value = 200005,
					Num = 45,
				},
			},
		},
		{
			Level = 6,
			Info = 920735,
			Ability = {
				{
					Value = 200002,
					Num = 360,
				},
				{
					Value = 200005,
					Num = 54,
				},
			},
		},
		{
			Level = 7,
			Info = 920735,
			Ability = {
				{
					Value = 200002,
					Num = 420,
				},
				{
					Value = 200005,
					Num = 63,
				},
			},
		},
		{
			Level = 8,
			Info = 920735,
			Ability = {
				{
					Value = 200002,
					Num = 480,
				},
				{
					Value = 200005,
					Num = 72,
				},
			},
			SkillList = {
				{
					Id = 100553,
					Value = 25,
				},
			},
		},
		{
			Level = 9,
			Info = 920735,
			Ability = {
				{
					Value = 200002,
					Num = 540,
				},
				{
					Value = 200005,
					Num = 81,
				},
			},
			SkillList = {
				{
					Id = 100553,
					Value = 25,
				},
			},
		},
		{
			Level = 10,
			Info = 920735,
			Ability = {
				{
					Value = 200002,
					Num = 600,
				},
				{
					Value = 200005,
					Num = 90,
				},
			},
			SkillList = {
				{
					Id = 100553,
					Value = 25,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id702] =
{
	Character = 223134,
	Rarity = 4,
	NeedChallenge = 145274,
	UpgradeId = 930015,
	LevelList = {
		{
			Level = 1,
			Info = 920736,
			Ability = {
				{
					Value = 200002,
					Num = 120,
				},
			},
		},
		{
			Level = 2,
			Info = 920736,
			Ability = {
				{
					Value = 200002,
					Num = 200,
				},
			},
		},
		{
			Level = 3,
			Info = 920736,
			Ability = {
				{
					Value = 200002,
					Num = 280,
				},
			},
		},
		{
			Level = 4,
			Info = 920736,
			Ability = {
				{
					Value = 200002,
					Num = 360,
				},
			},
		},
		{
			Level = 5,
			Info = 920736,
			Ability = {
				{
					Value = 200002,
					Num = 440,
				},
				{
					Value = 200004,
					Num = 25,
				},
			},
		},
		{
			Level = 6,
			Info = 920736,
			Ability = {
				{
					Value = 200002,
					Num = 520,
				},
				{
					Value = 200004,
					Num = 30,
				},
			},
		},
		{
			Level = 7,
			Info = 920736,
			Ability = {
				{
					Value = 200002,
					Num = 600,
				},
				{
					Value = 200004,
					Num = 35,
				},
			},
		},
		{
			Level = 8,
			Info = 920736,
			Ability = {
				{
					Value = 200002,
					Num = 680,
				},
				{
					Value = 200004,
					Num = 40,
				},
			},
			SkillList = {
				{
					Id = 101513,
					Value = -5,
				},
			},
		},
		{
			Level = 9,
			Info = 920736,
			Ability = {
				{
					Value = 200002,
					Num = 760,
				},
				{
					Value = 200004,
					Num = 45,
				},
			},
			SkillList = {
				{
					Id = 101513,
					Value = -5,
				},
			},
		},
		{
			Level = 10,
			Info = 920736,
			Ability = {
				{
					Value = 200002,
					Num = 840,
				},
				{
					Value = 200004,
					Num = 50,
				},
			},
			SkillList = {
				{
					Id = 101513,
					Value = -5,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id703] =
{
	Character = 223135,
	Rarity = 3,
	UpgradeId = 930029,
	LevelList = {
		{
			Level = 1,
			Info = 920737,
			Ability = {
				{
					Value = 200001,
					Num = 63,
				},
				{
					Value = 200008,
					Num = 15,
				},
			},
		},
		{
			Level = 2,
			Info = 920737,
			Ability = {
				{
					Value = 200001,
					Num = 126,
				},
				{
					Value = 200008,
					Num = 30,
				},
			},
		},
		{
			Level = 3,
			Info = 920737,
			Ability = {
				{
					Value = 200001,
					Num = 189,
				},
				{
					Value = 200008,
					Num = 45,
				},
			},
		},
		{
			Level = 4,
			Info = 920737,
			Ability = {
				{
					Value = 200001,
					Num = 252,
				},
				{
					Value = 200008,
					Num = 60,
				},
			},
		},
		{
			Level = 5,
			Info = 920737,
			Ability = {
				{
					Value = 200001,
					Num = 315,
				},
				{
					Value = 200008,
					Num = 75,
				},
			},
		},
		{
			Level = 6,
			Info = 920737,
			Ability = {
				{
					Value = 200001,
					Num = 378,
				},
				{
					Value = 200008,
					Num = 90,
				},
			},
		},
		{
			Level = 7,
			Info = 920737,
			Ability = {
				{
					Value = 200001,
					Num = 441,
				},
				{
					Value = 200008,
					Num = 105,
				},
			},
		},
		{
			Level = 8,
			Info = 920737,
			Ability = {
				{
					Value = 200001,
					Num = 504,
				},
				{
					Value = 200008,
					Num = 120,
				},
			},
			SkillList = {
				{
					Id = 100562,
					Value = -5,
				},
			},
		},
		{
			Level = 9,
			Info = 920737,
			Ability = {
				{
					Value = 200001,
					Num = 567,
				},
				{
					Value = 200008,
					Num = 135,
				},
			},
			SkillList = {
				{
					Id = 100562,
					Value = -5,
				},
			},
		},
		{
			Level = 10,
			Info = 920737,
			Ability = {
				{
					Value = 200001,
					Num = 630,
				},
				{
					Value = 200008,
					Num = 150,
				},
			},
			SkillList = {
				{
					Id = 100562,
					Value = -5,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id704] =
{
	Character = 223135,
	Rarity = 3,
	UpgradeId = 930030,
	LevelList = {
		{
			Level = 1,
			Info = 920738,
			Ability = {
				{
					Value = 200001,
					Num = 63,
				},
				{
					Value = 200008,
					Num = 15,
				},
			},
		},
		{
			Level = 2,
			Info = 920738,
			Ability = {
				{
					Value = 200001,
					Num = 126,
				},
				{
					Value = 200008,
					Num = 30,
				},
			},
		},
		{
			Level = 3,
			Info = 920738,
			Ability = {
				{
					Value = 200001,
					Num = 189,
				},
				{
					Value = 200008,
					Num = 45,
				},
			},
		},
		{
			Level = 4,
			Info = 920738,
			Ability = {
				{
					Value = 200001,
					Num = 252,
				},
				{
					Value = 200008,
					Num = 60,
				},
			},
		},
		{
			Level = 5,
			Info = 920738,
			Ability = {
				{
					Value = 200001,
					Num = 315,
				},
				{
					Value = 200008,
					Num = 75,
				},
			},
		},
		{
			Level = 6,
			Info = 920738,
			Ability = {
				{
					Value = 200001,
					Num = 378,
				},
				{
					Value = 200008,
					Num = 90,
				},
			},
		},
		{
			Level = 7,
			Info = 920738,
			Ability = {
				{
					Value = 200001,
					Num = 441,
				},
				{
					Value = 200008,
					Num = 105,
				},
			},
		},
		{
			Level = 8,
			Info = 920738,
			Ability = {
				{
					Value = 200001,
					Num = 504,
				},
				{
					Value = 200008,
					Num = 120,
				},
			},
			SkillList = {
				{
					Id = 100658,
					Value = 10,
				},
			},
		},
		{
			Level = 9,
			Info = 920738,
			Ability = {
				{
					Value = 200001,
					Num = 567,
				},
				{
					Value = 200008,
					Num = 135,
				},
			},
			SkillList = {
				{
					Id = 100658,
					Value = 10,
				},
			},
		},
		{
			Level = 10,
			Info = 920738,
			Ability = {
				{
					Value = 200001,
					Num = 630,
				},
				{
					Value = 200008,
					Num = 150,
				},
			},
			SkillList = {
				{
					Id = 100658,
					Value = 10,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id705] =
{
	Character = 223135,
	Rarity = 3,
	NeedChallenge = 145275,
	UpgradeId = 930031,
	LevelList = {
		{
			Level = 1,
			Info = 920739,
			Ability = {
				{
					Value = 200001,
					Num = 126,
				},
			},
		},
		{
			Level = 2,
			Info = 920739,
			Ability = {
				{
					Value = 200001,
					Num = 210,
				},
			},
		},
		{
			Level = 3,
			Info = 920739,
			Ability = {
				{
					Value = 200001,
					Num = 294,
				},
			},
		},
		{
			Level = 4,
			Info = 920739,
			Ability = {
				{
					Value = 200001,
					Num = 378,
				},
			},
		},
		{
			Level = 5,
			Info = 920739,
			Ability = {
				{
					Value = 200001,
					Num = 462,
				},
				{
					Value = 200003,
					Num = 25,
				},
			},
		},
		{
			Level = 6,
			Info = 920739,
			Ability = {
				{
					Value = 200001,
					Num = 546,
				},
				{
					Value = 200003,
					Num = 30,
				},
			},
		},
		{
			Level = 7,
			Info = 920739,
			Ability = {
				{
					Value = 200001,
					Num = 630,
				},
				{
					Value = 200003,
					Num = 35,
				},
			},
		},
		{
			Level = 8,
			Info = 920739,
			Ability = {
				{
					Value = 200001,
					Num = 714,
				},
				{
					Value = 200003,
					Num = 40,
				},
			},
			SkillList = {
				{
					Id = 100779,
					Value = 100,
				},
			},
		},
		{
			Level = 9,
			Info = 920739,
			Ability = {
				{
					Value = 200001,
					Num = 798,
				},
				{
					Value = 200003,
					Num = 45,
				},
			},
			SkillList = {
				{
					Id = 100779,
					Value = 100,
				},
			},
		},
		{
			Level = 10,
			Info = 920739,
			Ability = {
				{
					Value = 200001,
					Num = 882,
				},
				{
					Value = 200003,
					Num = 50,
				},
			},
			SkillList = {
				{
					Id = 100779,
					Value = 100,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id706] =
{
	Character = 223136,
	Rarity = 3,
	UpgradeId = 930009,
	LevelList = {
		{
			Level = 1,
			Info = 920740,
			Ability = {
				{
					Value = 200002,
					Num = 45,
				},
				{
					Value = 200005,
					Num = 9,
				},
			},
		},
		{
			Level = 2,
			Info = 920740,
			Ability = {
				{
					Value = 200002,
					Num = 90,
				},
				{
					Value = 200005,
					Num = 18,
				},
			},
		},
		{
			Level = 3,
			Info = 920740,
			Ability = {
				{
					Value = 200002,
					Num = 135,
				},
				{
					Value = 200005,
					Num = 27,
				},
			},
		},
		{
			Level = 4,
			Info = 920740,
			Ability = {
				{
					Value = 200002,
					Num = 180,
				},
				{
					Value = 200005,
					Num = 36,
				},
			},
		},
		{
			Level = 5,
			Info = 920740,
			Ability = {
				{
					Value = 200002,
					Num = 225,
				},
				{
					Value = 200005,
					Num = 45,
				},
			},
		},
		{
			Level = 6,
			Info = 920740,
			Ability = {
				{
					Value = 200002,
					Num = 270,
				},
				{
					Value = 200005,
					Num = 54,
				},
			},
		},
		{
			Level = 7,
			Info = 920740,
			Ability = {
				{
					Value = 200002,
					Num = 315,
				},
				{
					Value = 200005,
					Num = 63,
				},
			},
		},
		{
			Level = 8,
			Info = 920740,
			Ability = {
				{
					Value = 200002,
					Num = 360,
				},
				{
					Value = 200005,
					Num = 72,
				},
			},
			SkillList = {
				{
					Id = 100501,
					Value = 10,
				},
			},
		},
		{
			Level = 9,
			Info = 920740,
			Ability = {
				{
					Value = 200002,
					Num = 405,
				},
				{
					Value = 200005,
					Num = 81,
				},
			},
			SkillList = {
				{
					Id = 100501,
					Value = 10,
				},
			},
		},
		{
			Level = 10,
			Info = 920740,
			Ability = {
				{
					Value = 200002,
					Num = 450,
				},
				{
					Value = 200005,
					Num = 90,
				},
			},
			SkillList = {
				{
					Id = 100501,
					Value = 10,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id707] =
{
	Character = 223136,
	Rarity = 3,
	UpgradeId = 930010,
	LevelList = {
		{
			Level = 1,
			Info = 920741,
			Ability = {
				{
					Value = 200002,
					Num = 45,
				},
				{
					Value = 200008,
					Num = 6,
				},
			},
		},
		{
			Level = 2,
			Info = 920741,
			Ability = {
				{
					Value = 200002,
					Num = 90,
				},
				{
					Value = 200008,
					Num = 12,
				},
			},
		},
		{
			Level = 3,
			Info = 920741,
			Ability = {
				{
					Value = 200002,
					Num = 135,
				},
				{
					Value = 200008,
					Num = 18,
				},
			},
		},
		{
			Level = 4,
			Info = 920741,
			Ability = {
				{
					Value = 200002,
					Num = 180,
				},
				{
					Value = 200008,
					Num = 24,
				},
			},
		},
		{
			Level = 5,
			Info = 920741,
			Ability = {
				{
					Value = 200002,
					Num = 225,
				},
				{
					Value = 200008,
					Num = 30,
				},
			},
		},
		{
			Level = 6,
			Info = 920741,
			Ability = {
				{
					Value = 200002,
					Num = 270,
				},
				{
					Value = 200008,
					Num = 36,
				},
			},
		},
		{
			Level = 7,
			Info = 920741,
			Ability = {
				{
					Value = 200002,
					Num = 315,
				},
				{
					Value = 200008,
					Num = 42,
				},
			},
		},
		{
			Level = 8,
			Info = 920741,
			Ability = {
				{
					Value = 200002,
					Num = 360,
				},
				{
					Value = 200008,
					Num = 48,
				},
			},
			SkillList = {
				{
					Id = 100101,
					Value = -7,
				},
			},
		},
		{
			Level = 9,
			Info = 920741,
			Ability = {
				{
					Value = 200002,
					Num = 405,
				},
				{
					Value = 200008,
					Num = 54,
				},
			},
			SkillList = {
				{
					Id = 100101,
					Value = -7,
				},
			},
		},
		{
			Level = 10,
			Info = 920741,
			Ability = {
				{
					Value = 200002,
					Num = 450,
				},
				{
					Value = 200008,
					Num = 60,
				},
			},
			SkillList = {
				{
					Id = 100101,
					Value = -7,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id708] =
{
	Character = 223136,
	Rarity = 3,
	NeedChallenge = 145276,
	UpgradeId = 930031,
	LevelList = {
		{
			Level = 1,
			Info = 920742,
			Ability = {
				{
					Value = 200001,
					Num = 108,
				},
			},
		},
		{
			Level = 2,
			Info = 920742,
			Ability = {
				{
					Value = 200001,
					Num = 180,
				},
			},
		},
		{
			Level = 3,
			Info = 920742,
			Ability = {
				{
					Value = 200001,
					Num = 252,
				},
			},
		},
		{
			Level = 4,
			Info = 920742,
			Ability = {
				{
					Value = 200001,
					Num = 324,
				},
			},
		},
		{
			Level = 5,
			Info = 920742,
			Ability = {
				{
					Value = 200001,
					Num = 396,
				},
				{
					Value = 200003,
					Num = 25,
				},
			},
		},
		{
			Level = 6,
			Info = 920742,
			Ability = {
				{
					Value = 200001,
					Num = 468,
				},
				{
					Value = 200003,
					Num = 30,
				},
			},
		},
		{
			Level = 7,
			Info = 920742,
			Ability = {
				{
					Value = 200001,
					Num = 540,
				},
				{
					Value = 200003,
					Num = 35,
				},
			},
		},
		{
			Level = 8,
			Info = 920742,
			Ability = {
				{
					Value = 200001,
					Num = 612,
				},
				{
					Value = 200003,
					Num = 40,
				},
			},
			SkillList = {
				{
					Id = 100015,
					Value = -25,
				},
			},
		},
		{
			Level = 9,
			Info = 920742,
			Ability = {
				{
					Value = 200001,
					Num = 684,
				},
				{
					Value = 200003,
					Num = 45,
				},
			},
			SkillList = {
				{
					Id = 100015,
					Value = -25,
				},
			},
		},
		{
			Level = 10,
			Info = 920742,
			Ability = {
				{
					Value = 200001,
					Num = 756,
				},
				{
					Value = 200003,
					Num = 50,
				},
			},
			SkillList = {
				{
					Id = 100015,
					Value = -25,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id709] =
{
	Character = 223137,
	Rarity = 3,
	UpgradeId = 930009,
	LevelList = {
		{
			Level = 1,
			Info = 920743,
			Ability = {
				{
					Value = 200002,
					Num = 48,
				},
				{
					Value = 200005,
					Num = 9,
				},
			},
		},
		{
			Level = 2,
			Info = 920743,
			Ability = {
				{
					Value = 200002,
					Num = 96,
				},
				{
					Value = 200005,
					Num = 18,
				},
			},
		},
		{
			Level = 3,
			Info = 920743,
			Ability = {
				{
					Value = 200002,
					Num = 144,
				},
				{
					Value = 200005,
					Num = 27,
				},
			},
		},
		{
			Level = 4,
			Info = 920743,
			Ability = {
				{
					Value = 200002,
					Num = 192,
				},
				{
					Value = 200005,
					Num = 36,
				},
			},
		},
		{
			Level = 5,
			Info = 920743,
			Ability = {
				{
					Value = 200002,
					Num = 240,
				},
				{
					Value = 200005,
					Num = 45,
				},
			},
		},
		{
			Level = 6,
			Info = 920743,
			Ability = {
				{
					Value = 200002,
					Num = 288,
				},
				{
					Value = 200005,
					Num = 54,
				},
			},
		},
		{
			Level = 7,
			Info = 920743,
			Ability = {
				{
					Value = 200002,
					Num = 336,
				},
				{
					Value = 200005,
					Num = 63,
				},
			},
		},
		{
			Level = 8,
			Info = 920743,
			Ability = {
				{
					Value = 200002,
					Num = 384,
				},
				{
					Value = 200005,
					Num = 72,
				},
			},
			SkillList = {
				{
					Id = 100655,
					Value = 10,
				},
			},
		},
		{
			Level = 9,
			Info = 920743,
			Ability = {
				{
					Value = 200002,
					Num = 432,
				},
				{
					Value = 200005,
					Num = 81,
				},
			},
			SkillList = {
				{
					Id = 100655,
					Value = 10,
				},
			},
		},
		{
			Level = 10,
			Info = 920743,
			Ability = {
				{
					Value = 200002,
					Num = 480,
				},
				{
					Value = 200005,
					Num = 90,
				},
			},
			SkillList = {
				{
					Id = 100655,
					Value = 10,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id710] =
{
	Character = 223137,
	Rarity = 3,
	UpgradeId = 930010,
	LevelList = {
		{
			Level = 1,
			Info = 920744,
			Ability = {
				{
					Value = 200002,
					Num = 48,
				},
				{
					Value = 200006,
					Num = 6,
				},
			},
		},
		{
			Level = 2,
			Info = 920744,
			Ability = {
				{
					Value = 200002,
					Num = 96,
				},
				{
					Value = 200006,
					Num = 12,
				},
			},
		},
		{
			Level = 3,
			Info = 920744,
			Ability = {
				{
					Value = 200002,
					Num = 144,
				},
				{
					Value = 200006,
					Num = 18,
				},
			},
		},
		{
			Level = 4,
			Info = 920744,
			Ability = {
				{
					Value = 200002,
					Num = 192,
				},
				{
					Value = 200006,
					Num = 24,
				},
			},
		},
		{
			Level = 5,
			Info = 920744,
			Ability = {
				{
					Value = 200002,
					Num = 240,
				},
				{
					Value = 200006,
					Num = 30,
				},
			},
		},
		{
			Level = 6,
			Info = 920744,
			Ability = {
				{
					Value = 200002,
					Num = 288,
				},
				{
					Value = 200006,
					Num = 36,
				},
			},
		},
		{
			Level = 7,
			Info = 920744,
			Ability = {
				{
					Value = 200002,
					Num = 336,
				},
				{
					Value = 200006,
					Num = 42,
				},
			},
		},
		{
			Level = 8,
			Info = 920744,
			Ability = {
				{
					Value = 200002,
					Num = 384,
				},
				{
					Value = 200006,
					Num = 48,
				},
			},
			SkillList = {
				{
					Id = 100658,
					Value = 10,
				},
			},
		},
		{
			Level = 9,
			Info = 920744,
			Ability = {
				{
					Value = 200002,
					Num = 432,
				},
				{
					Value = 200006,
					Num = 54,
				},
			},
			SkillList = {
				{
					Id = 100658,
					Value = 10,
				},
			},
		},
		{
			Level = 10,
			Info = 920744,
			Ability = {
				{
					Value = 200002,
					Num = 480,
				},
				{
					Value = 200006,
					Num = 60,
				},
			},
			SkillList = {
				{
					Id = 100658,
					Value = 10,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id711] =
{
	Character = 223137,
	Rarity = 3,
	NeedChallenge = 145277,
	UpgradeId = 930011,
	LevelList = {
		{
			Level = 1,
			Info = 920745,
			Ability = {
				{
					Value = 200002,
					Num = 96,
				},
			},
		},
		{
			Level = 2,
			Info = 920745,
			Ability = {
				{
					Value = 200002,
					Num = 160,
				},
			},
		},
		{
			Level = 3,
			Info = 920745,
			Ability = {
				{
					Value = 200002,
					Num = 224,
				},
			},
		},
		{
			Level = 4,
			Info = 920745,
			Ability = {
				{
					Value = 200002,
					Num = 288,
				},
			},
		},
		{
			Level = 5,
			Info = 920745,
			Ability = {
				{
					Value = 200002,
					Num = 352,
				},
				{
					Value = 200004,
					Num = 25,
				},
			},
		},
		{
			Level = 6,
			Info = 920745,
			Ability = {
				{
					Value = 200002,
					Num = 416,
				},
				{
					Value = 200004,
					Num = 30,
				},
			},
		},
		{
			Level = 7,
			Info = 920745,
			Ability = {
				{
					Value = 200002,
					Num = 480,
				},
				{
					Value = 200004,
					Num = 35,
				},
			},
		},
		{
			Level = 8,
			Info = 920745,
			Ability = {
				{
					Value = 200002,
					Num = 544,
				},
				{
					Value = 200004,
					Num = 40,
				},
			},
			SkillList = {
				{
					Id = 101903,
					Value = 12,
				},
			},
		},
		{
			Level = 9,
			Info = 920745,
			Ability = {
				{
					Value = 200002,
					Num = 608,
				},
				{
					Value = 200004,
					Num = 45,
				},
			},
			SkillList = {
				{
					Id = 101903,
					Value = 12,
				},
			},
		},
		{
			Level = 10,
			Info = 920745,
			Ability = {
				{
					Value = 200002,
					Num = 672,
				},
				{
					Value = 200004,
					Num = 50,
				},
			},
			SkillList = {
				{
					Id = 101903,
					Value = 12,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id712] =
{
	Character = 223138,
	Rarity = 5,
	UpgradeId = 930037,
	LevelList = {
		{
			Level = 1,
			Info = 920746,
			Ability = {
				{
					Value = 200001,
					Num = 87,
				},
				{
					Value = 200007,
					Num = 12,
				},
			},
		},
		{
			Level = 2,
			Info = 920746,
			Ability = {
				{
					Value = 200001,
					Num = 174,
				},
				{
					Value = 200007,
					Num = 24,
				},
			},
		},
		{
			Level = 3,
			Info = 920746,
			Ability = {
				{
					Value = 200001,
					Num = 261,
				},
				{
					Value = 200007,
					Num = 36,
				},
			},
		},
		{
			Level = 4,
			Info = 920746,
			Ability = {
				{
					Value = 200001,
					Num = 348,
				},
				{
					Value = 200007,
					Num = 48,
				},
			},
		},
		{
			Level = 5,
			Info = 920746,
			Ability = {
				{
					Value = 200001,
					Num = 435,
				},
				{
					Value = 200007,
					Num = 60,
				},
			},
		},
		{
			Level = 6,
			Info = 920746,
			Ability = {
				{
					Value = 200001,
					Num = 522,
				},
				{
					Value = 200007,
					Num = 72,
				},
			},
		},
		{
			Level = 7,
			Info = 920746,
			Ability = {
				{
					Value = 200001,
					Num = 609,
				},
				{
					Value = 200007,
					Num = 84,
				},
			},
		},
		{
			Level = 8,
			Info = 920746,
			Ability = {
				{
					Value = 200001,
					Num = 696,
				},
				{
					Value = 200007,
					Num = 96,
				},
			},
			SkillList = {
				{
					Id = 100564,
					Value = -5,
				},
			},
		},
		{
			Level = 9,
			Info = 920746,
			Ability = {
				{
					Value = 200001,
					Num = 783,
				},
				{
					Value = 200007,
					Num = 108,
				},
			},
			SkillList = {
				{
					Id = 100564,
					Value = -5,
				},
			},
		},
		{
			Level = 10,
			Info = 920746,
			Ability = {
				{
					Value = 200001,
					Num = 870,
				},
				{
					Value = 200007,
					Num = 120,
				},
			},
			SkillList = {
				{
					Id = 100564,
					Value = -5,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id713] =
{
	Character = 223138,
	Rarity = 5,
	UpgradeId = 930018,
	LevelList = {
		{
			Level = 1,
			Info = 920747,
			Ability = {
				{
					Value = 200002,
					Num = 63,
				},
				{
					Value = 200005,
					Num = 15,
				},
			},
		},
		{
			Level = 2,
			Info = 920747,
			Ability = {
				{
					Value = 200002,
					Num = 126,
				},
				{
					Value = 200005,
					Num = 30,
				},
			},
		},
		{
			Level = 3,
			Info = 920747,
			Ability = {
				{
					Value = 200002,
					Num = 189,
				},
				{
					Value = 200005,
					Num = 45,
				},
			},
		},
		{
			Level = 4,
			Info = 920747,
			Ability = {
				{
					Value = 200002,
					Num = 252,
				},
				{
					Value = 200005,
					Num = 60,
				},
			},
		},
		{
			Level = 5,
			Info = 920747,
			Ability = {
				{
					Value = 200002,
					Num = 315,
				},
				{
					Value = 200005,
					Num = 75,
				},
			},
		},
		{
			Level = 6,
			Info = 920747,
			Ability = {
				{
					Value = 200002,
					Num = 378,
				},
				{
					Value = 200005,
					Num = 90,
				},
			},
		},
		{
			Level = 7,
			Info = 920747,
			Ability = {
				{
					Value = 200002,
					Num = 441,
				},
				{
					Value = 200005,
					Num = 105,
				},
			},
		},
		{
			Level = 8,
			Info = 920747,
			Ability = {
				{
					Value = 200002,
					Num = 504,
				},
				{
					Value = 200005,
					Num = 120,
				},
			},
			SkillList = {
				{
					Id = 100606,
					Value = -25,
				},
			},
		},
		{
			Level = 9,
			Info = 920747,
			Ability = {
				{
					Value = 200002,
					Num = 567,
				},
				{
					Value = 200005,
					Num = 135,
				},
			},
			SkillList = {
				{
					Id = 100606,
					Value = -25,
				},
			},
		},
		{
			Level = 10,
			Info = 920747,
			Ability = {
				{
					Value = 200002,
					Num = 630,
				},
				{
					Value = 200005,
					Num = 150,
				},
			},
			SkillList = {
				{
					Id = 100606,
					Value = -25,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id714] =
{
	Character = 223138,
	Rarity = 5,
	NeedChallenge = 145278,
	UpgradeId = 930039,
	LevelList = {
		{
			Level = 1,
			Info = 920748,
			Ability = {
				{
					Value = 200001,
					Num = 174,
				},
			},
		},
		{
			Level = 2,
			Info = 920748,
			Ability = {
				{
					Value = 200001,
					Num = 290,
				},
			},
		},
		{
			Level = 3,
			Info = 920748,
			Ability = {
				{
					Value = 200001,
					Num = 406,
				},
			},
		},
		{
			Level = 4,
			Info = 920748,
			Ability = {
				{
					Value = 200001,
					Num = 522,
				},
			},
		},
		{
			Level = 5,
			Info = 920748,
			Ability = {
				{
					Value = 200001,
					Num = 638,
				},
				{
					Value = 200003,
					Num = 25,
				},
			},
		},
		{
			Level = 6,
			Info = 920748,
			Ability = {
				{
					Value = 200001,
					Num = 754,
				},
				{
					Value = 200003,
					Num = 30,
				},
			},
		},
		{
			Level = 7,
			Info = 920748,
			Ability = {
				{
					Value = 200001,
					Num = 870,
				},
				{
					Value = 200003,
					Num = 35,
				},
			},
		},
		{
			Level = 8,
			Info = 920748,
			Ability = {
				{
					Value = 200001,
					Num = 986,
				},
				{
					Value = 200003,
					Num = 40,
				},
			},
			SkillList = {
				{
					Id = 101787,
					Value = 2,
				},
			},
		},
		{
			Level = 9,
			Info = 920748,
			Ability = {
				{
					Value = 200001,
					Num = 1102,
				},
				{
					Value = 200003,
					Num = 45,
				},
			},
			SkillList = {
				{
					Id = 101787,
					Value = 2,
				},
			},
		},
		{
			Level = 10,
			Info = 920748,
			Ability = {
				{
					Value = 200001,
					Num = 1218,
				},
				{
					Value = 200003,
					Num = 50,
				},
			},
			SkillList = {
				{
					Id = 101787,
					Value = 2,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id715] =
{
	Character = 223138,
	Rarity = 5,
	NeedChallenge = 145279,
	UpgradeId = 930040,
	LevelList = {
		{
			Level = 1,
			Info = 920749,
			Ability = {
				{
					Value = 200001,
					Num = 261,
				},
			},
		},
		{
			Level = 2,
			Info = 920749,
			Ability = {
				{
					Value = 200001,
					Num = 406,
				},
			},
		},
		{
			Level = 3,
			Info = 920749,
			Ability = {
				{
					Value = 200001,
					Num = 551,
				},
			},
		},
		{
			Level = 4,
			Info = 920749,
			Ability = {
				{
					Value = 200001,
					Num = 696,
				},
			},
		},
		{
			Level = 5,
			Info = 920749,
			Ability = {
				{
					Value = 200001,
					Num = 841,
				},
				{
					Value = 200003,
					Num = 25,
				},
			},
		},
		{
			Level = 6,
			Info = 920749,
			Ability = {
				{
					Value = 200001,
					Num = 986,
				},
				{
					Value = 200003,
					Num = 30,
				},
			},
		},
		{
			Level = 7,
			Info = 920749,
			Ability = {
				{
					Value = 200001,
					Num = 1131,
				},
				{
					Value = 200003,
					Num = 35,
				},
			},
		},
		{
			Level = 8,
			Info = 920749,
			Ability = {
				{
					Value = 200001,
					Num = 1276,
				},
				{
					Value = 200003,
					Num = 40,
				},
			},
			SkillList = {
				{
					Id = 101788,
					Value = 2,
				},
			},
		},
		{
			Level = 9,
			Info = 920749,
			Ability = {
				{
					Value = 200001,
					Num = 1421,
				},
				{
					Value = 200003,
					Num = 45,
				},
			},
			SkillList = {
				{
					Id = 101788,
					Value = 2,
				},
			},
		},
		{
			Level = 10,
			Info = 920749,
			Ability = {
				{
					Value = 200001,
					Num = 1566,
				},
				{
					Value = 200003,
					Num = 50,
				},
			},
			SkillList = {
				{
					Id = 101788,
					Value = 2,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id716] =
{
	Character = 221007,
	Rarity = 3,
	UpgradeId = 930109,
	LevelList = {
		{
			Level = 1,
			Info = 920529,
			Ability = {
				{
					Value = 200001,
					Num = 54,
				},
				{
					Value = 200005,
					Num = 9,
				},
			},
		},
		{
			Level = 2,
			Info = 920529,
			Ability = {
				{
					Value = 200001,
					Num = 108,
				},
				{
					Value = 200005,
					Num = 18,
				},
			},
		},
		{
			Level = 3,
			Info = 920529,
			Ability = {
				{
					Value = 200001,
					Num = 162,
				},
				{
					Value = 200005,
					Num = 27,
				},
			},
		},
		{
			Level = 4,
			Info = 920529,
			Ability = {
				{
					Value = 200001,
					Num = 216,
				},
				{
					Value = 200005,
					Num = 36,
				},
			},
		},
		{
			Level = 5,
			Info = 920529,
			Ability = {
				{
					Value = 200001,
					Num = 270,
				},
				{
					Value = 200005,
					Num = 45,
				},
			},
		},
		{
			Level = 6,
			Info = 920529,
			Ability = {
				{
					Value = 200001,
					Num = 324,
				},
				{
					Value = 200005,
					Num = 54,
				},
			},
		},
		{
			Level = 7,
			Info = 920529,
			Ability = {
				{
					Value = 200001,
					Num = 378,
				},
				{
					Value = 200005,
					Num = 63,
				},
			},
		},
		{
			Level = 8,
			Info = 920529,
			Ability = {
				{
					Value = 200001,
					Num = 432,
				},
				{
					Value = 200005,
					Num = 72,
				},
			},
			SkillList = {
				{
					Id = 100554,
					Value = 25,
				},
			},
		},
		{
			Level = 9,
			Info = 920529,
			Ability = {
				{
					Value = 200001,
					Num = 486,
				},
				{
					Value = 200005,
					Num = 81,
				},
			},
			SkillList = {
				{
					Id = 100554,
					Value = 25,
				},
			},
		},
		{
			Level = 10,
			Info = 920529,
			Ability = {
				{
					Value = 200001,
					Num = 540,
				},
				{
					Value = 200005,
					Num = 90,
				},
			},
			SkillList = {
				{
					Id = 100554,
					Value = 25,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id717] =
{
	Character = 221007,
	Rarity = 3,
	UpgradeId = 930090,
	LevelList = {
		{
			Level = 1,
			Info = 920530,
			Ability = {
				{
					Value = 200002,
					Num = 51,
				},
				{
					Value = 200006,
					Num = 6,
				},
			},
		},
		{
			Level = 2,
			Info = 920530,
			Ability = {
				{
					Value = 200002,
					Num = 102,
				},
				{
					Value = 200006,
					Num = 12,
				},
			},
		},
		{
			Level = 3,
			Info = 920530,
			Ability = {
				{
					Value = 200002,
					Num = 153,
				},
				{
					Value = 200006,
					Num = 18,
				},
			},
		},
		{
			Level = 4,
			Info = 920530,
			Ability = {
				{
					Value = 200002,
					Num = 204,
				},
				{
					Value = 200006,
					Num = 24,
				},
			},
		},
		{
			Level = 5,
			Info = 920530,
			Ability = {
				{
					Value = 200002,
					Num = 255,
				},
				{
					Value = 200006,
					Num = 30,
				},
			},
		},
		{
			Level = 6,
			Info = 920530,
			Ability = {
				{
					Value = 200002,
					Num = 306,
				},
				{
					Value = 200006,
					Num = 36,
				},
			},
		},
		{
			Level = 7,
			Info = 920530,
			Ability = {
				{
					Value = 200002,
					Num = 357,
				},
				{
					Value = 200006,
					Num = 42,
				},
			},
		},
		{
			Level = 8,
			Info = 920530,
			Ability = {
				{
					Value = 200002,
					Num = 408,
				},
				{
					Value = 200006,
					Num = 48,
				},
			},
			SkillList = {
				{
					Id = 101901,
					Value = 12,
				},
			},
		},
		{
			Level = 9,
			Info = 920530,
			Ability = {
				{
					Value = 200002,
					Num = 459,
				},
				{
					Value = 200006,
					Num = 54,
				},
			},
			SkillList = {
				{
					Id = 101901,
					Value = 12,
				},
			},
		},
		{
			Level = 10,
			Info = 920530,
			Ability = {
				{
					Value = 200002,
					Num = 510,
				},
				{
					Value = 200006,
					Num = 60,
				},
			},
			SkillList = {
				{
					Id = 101901,
					Value = 12,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id718] =
{
	Character = 221007,
	Rarity = 3,
	NeedChallenge = 145280,
	UpgradeId = 930091,
	LevelList = {
		{
			Level = 1,
			Info = 920528,
			Ability = {
				{
					Value = 200002,
					Num = 102,
				},
			},
		},
		{
			Level = 2,
			Info = 920528,
			Ability = {
				{
					Value = 200002,
					Num = 170,
				},
			},
		},
		{
			Level = 3,
			Info = 920528,
			Ability = {
				{
					Value = 200002,
					Num = 238,
				},
			},
		},
		{
			Level = 4,
			Info = 920528,
			Ability = {
				{
					Value = 200002,
					Num = 306,
				},
			},
		},
		{
			Level = 5,
			Info = 920528,
			Ability = {
				{
					Value = 200002,
					Num = 374,
				},
				{
					Value = 200004,
					Num = 25,
				},
			},
			SkillList = {
				{
					Id = 100261,
					Value = -5,
				},
			},
		},
		{
			Level = 6,
			Info = 920528,
			Ability = {
				{
					Value = 200002,
					Num = 442,
				},
				{
					Value = 200004,
					Num = 30,
				},
			},
			SkillList = {
				{
					Id = 100261,
					Value = -5,
				},
			},
		},
		{
			Level = 7,
			Info = 920528,
			Ability = {
				{
					Value = 200002,
					Num = 510,
				},
				{
					Value = 200004,
					Num = 35,
				},
			},
			SkillList = {
				{
					Id = 100261,
					Value = -5,
				},
			},
		},
		{
			Level = 8,
			Info = 920528,
			Ability = {
				{
					Value = 200002,
					Num = 578,
				},
				{
					Value = 200004,
					Num = 40,
				},
			},
			SkillList = {
				{
					Id = 100261,
					Value = -5,
				},
			},
		},
		{
			Level = 9,
			Info = 920528,
			Ability = {
				{
					Value = 200002,
					Num = 646,
				},
				{
					Value = 200004,
					Num = 45,
				},
			},
			SkillList = {
				{
					Id = 100261,
					Value = -5,
				},
			},
		},
		{
			Level = 10,
			Info = 920528,
			Ability = {
				{
					Value = 200002,
					Num = 714,
				},
				{
					Value = 200004,
					Num = 50,
				},
			},
			SkillList = {
				{
					Id = 100261,
					Value = -5,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id719] =
{
	Character = 223139,
	Rarity = 3,
	UpgradeId = 930009,
	LevelList = {
		{
			Level = 1,
			Info = 920752,
			Ability = {
				{
					Value = 200002,
					Num = 48,
				},
				{
					Value = 200005,
					Num = 9,
				},
			},
		},
		{
			Level = 2,
			Info = 920752,
			Ability = {
				{
					Value = 200002,
					Num = 96,
				},
				{
					Value = 200005,
					Num = 18,
				},
			},
		},
		{
			Level = 3,
			Info = 920752,
			Ability = {
				{
					Value = 200002,
					Num = 144,
				},
				{
					Value = 200005,
					Num = 27,
				},
			},
		},
		{
			Level = 4,
			Info = 920752,
			Ability = {
				{
					Value = 200002,
					Num = 192,
				},
				{
					Value = 200005,
					Num = 36,
				},
			},
		},
		{
			Level = 5,
			Info = 920752,
			Ability = {
				{
					Value = 200002,
					Num = 240,
				},
				{
					Value = 200005,
					Num = 45,
				},
			},
		},
		{
			Level = 6,
			Info = 920752,
			Ability = {
				{
					Value = 200002,
					Num = 288,
				},
				{
					Value = 200005,
					Num = 54,
				},
			},
		},
		{
			Level = 7,
			Info = 920752,
			Ability = {
				{
					Value = 200002,
					Num = 336,
				},
				{
					Value = 200005,
					Num = 63,
				},
			},
		},
		{
			Level = 8,
			Info = 920752,
			Ability = {
				{
					Value = 200002,
					Num = 384,
				},
				{
					Value = 200005,
					Num = 72,
				},
			},
			SkillList = {
				{
					Id = 100652,
					Value = 7,
				},
			},
		},
		{
			Level = 9,
			Info = 920752,
			Ability = {
				{
					Value = 200002,
					Num = 432,
				},
				{
					Value = 200005,
					Num = 81,
				},
			},
			SkillList = {
				{
					Id = 100652,
					Value = 7,
				},
			},
		},
		{
			Level = 10,
			Info = 920752,
			Ability = {
				{
					Value = 200002,
					Num = 480,
				},
				{
					Value = 200005,
					Num = 90,
				},
			},
			SkillList = {
				{
					Id = 100652,
					Value = 7,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id720] =
{
	Character = 223139,
	Rarity = 3,
	UpgradeId = 930030,
	LevelList = {
		{
			Level = 1,
			Info = 920751,
			Ability = {
				{
					Value = 200001,
					Num = 54,
				},
				{
					Value = 200006,
					Num = 6,
				},
			},
		},
		{
			Level = 2,
			Info = 920751,
			Ability = {
				{
					Value = 200001,
					Num = 108,
				},
				{
					Value = 200006,
					Num = 12,
				},
			},
		},
		{
			Level = 3,
			Info = 920751,
			Ability = {
				{
					Value = 200001,
					Num = 162,
				},
				{
					Value = 200006,
					Num = 18,
				},
			},
		},
		{
			Level = 4,
			Info = 920751,
			Ability = {
				{
					Value = 200001,
					Num = 216,
				},
				{
					Value = 200006,
					Num = 24,
				},
			},
		},
		{
			Level = 5,
			Info = 920751,
			Ability = {
				{
					Value = 200001,
					Num = 270,
				},
				{
					Value = 200006,
					Num = 30,
				},
			},
		},
		{
			Level = 6,
			Info = 920751,
			Ability = {
				{
					Value = 200001,
					Num = 324,
				},
				{
					Value = 200006,
					Num = 36,
				},
			},
		},
		{
			Level = 7,
			Info = 920751,
			Ability = {
				{
					Value = 200001,
					Num = 378,
				},
				{
					Value = 200006,
					Num = 42,
				},
			},
		},
		{
			Level = 8,
			Info = 920751,
			Ability = {
				{
					Value = 200001,
					Num = 432,
				},
				{
					Value = 200006,
					Num = 48,
				},
			},
			SkillList = {
				{
					Id = 101902,
					Value = 12,
				},
			},
		},
		{
			Level = 9,
			Info = 920751,
			Ability = {
				{
					Value = 200001,
					Num = 486,
				},
				{
					Value = 200006,
					Num = 54,
				},
			},
			SkillList = {
				{
					Id = 101902,
					Value = 12,
				},
			},
		},
		{
			Level = 10,
			Info = 920751,
			Ability = {
				{
					Value = 200001,
					Num = 540,
				},
				{
					Value = 200006,
					Num = 60,
				},
			},
			SkillList = {
				{
					Id = 101902,
					Value = 12,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id721] =
{
	Character = 223139,
	Rarity = 3,
	NeedChallenge = 145281,
	UpgradeId = 930011,
	LevelList = {
		{
			Level = 1,
			Info = 920750,
			Ability = {
				{
					Value = 200002,
					Num = 96,
				},
			},
		},
		{
			Level = 2,
			Info = 920750,
			Ability = {
				{
					Value = 200002,
					Num = 160,
				},
			},
		},
		{
			Level = 3,
			Info = 920750,
			Ability = {
				{
					Value = 200002,
					Num = 224,
				},
			},
		},
		{
			Level = 4,
			Info = 920750,
			Ability = {
				{
					Value = 200002,
					Num = 288,
				},
			},
		},
		{
			Level = 5,
			Info = 920750,
			Ability = {
				{
					Value = 200002,
					Num = 352,
				},
				{
					Value = 200004,
					Num = 25,
				},
			},
		},
		{
			Level = 6,
			Info = 920750,
			Ability = {
				{
					Value = 200002,
					Num = 416,
				},
				{
					Value = 200004,
					Num = 30,
				},
			},
		},
		{
			Level = 7,
			Info = 920750,
			Ability = {
				{
					Value = 200002,
					Num = 480,
				},
				{
					Value = 200004,
					Num = 35,
				},
			},
		},
		{
			Level = 8,
			Info = 920750,
			Ability = {
				{
					Value = 200002,
					Num = 544,
				},
				{
					Value = 200004,
					Num = 40,
				},
			},
			SkillList = {
				{
					Id = 100260,
					Value = 5,
				},
			},
		},
		{
			Level = 9,
			Info = 920750,
			Ability = {
				{
					Value = 200002,
					Num = 608,
				},
				{
					Value = 200004,
					Num = 45,
				},
			},
			SkillList = {
				{
					Id = 100260,
					Value = 5,
				},
			},
		},
		{
			Level = 10,
			Info = 920750,
			Ability = {
				{
					Value = 200002,
					Num = 672,
				},
				{
					Value = 200004,
					Num = 50,
				},
			},
			SkillList = {
				{
					Id = 100260,
					Value = 5,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id722] =
{
	Character = 223140,
	Rarity = 4,
	UpgradeId = 930033,
	LevelList = {
		{
			Level = 1,
			Info = 920753,
			Ability = {
				{
					Value = 200001,
					Num = 75,
				},
				{
					Value = 200005,
					Num = 12,
				},
			},
		},
		{
			Level = 2,
			Info = 920753,
			Ability = {
				{
					Value = 200001,
					Num = 150,
				},
				{
					Value = 200005,
					Num = 24,
				},
			},
		},
		{
			Level = 3,
			Info = 920753,
			Ability = {
				{
					Value = 200001,
					Num = 225,
				},
				{
					Value = 200005,
					Num = 36,
				},
			},
		},
		{
			Level = 4,
			Info = 920753,
			Ability = {
				{
					Value = 200001,
					Num = 300,
				},
				{
					Value = 200005,
					Num = 48,
				},
			},
		},
		{
			Level = 5,
			Info = 920753,
			Ability = {
				{
					Value = 200001,
					Num = 375,
				},
				{
					Value = 200005,
					Num = 60,
				},
			},
		},
		{
			Level = 6,
			Info = 920753,
			Ability = {
				{
					Value = 200001,
					Num = 450,
				},
				{
					Value = 200005,
					Num = 72,
				},
			},
		},
		{
			Level = 7,
			Info = 920753,
			Ability = {
				{
					Value = 200001,
					Num = 525,
				},
				{
					Value = 200005,
					Num = 84,
				},
			},
		},
		{
			Level = 8,
			Info = 920753,
			Ability = {
				{
					Value = 200001,
					Num = 600,
				},
				{
					Value = 200005,
					Num = 96,
				},
			},
			SkillList = {
				{
					Id = 100561,
					Value = -5,
				},
			},
		},
		{
			Level = 9,
			Info = 920753,
			Ability = {
				{
					Value = 200001,
					Num = 675,
				},
				{
					Value = 200005,
					Num = 108,
				},
			},
			SkillList = {
				{
					Id = 100561,
					Value = -5,
				},
			},
		},
		{
			Level = 10,
			Info = 920753,
			Ability = {
				{
					Value = 200001,
					Num = 750,
				},
				{
					Value = 200005,
					Num = 120,
				},
			},
			SkillList = {
				{
					Id = 100561,
					Value = -5,
				},
			},
		},
	},
}
