
ChallengeConfig[ChallengeID.Id5001] =
{
	Id = 5001,
	Name = "装备挑战：对讲机",
	Character = 220001,
	Desc = "由猫博士发明的通讯设备，呜呜专用配色，可以快速传递信息，但是干扰很大。\n“漆漆~这里是呜呜！收到请回复！”",
	RewardUnlock = 340002,
	ResultText = "呜呜的对讲机解锁了",
	NumCap = 2,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG01",
	StartScene = "ARENA_StartScene",
	TeamCondition = {
		{
			Condition = "NeedTagOr",
			Value = 
			{
				560110,
			},
			Desc = "必须是星际流民的队员",
			Hint = "必须是星际流民的队员",
		},
	},
	Enemy = {
		{
			Value = 245001,
			Level = 20,
		},
	},
}
ChallengeConfig[ChallengeID.Id5002] =
{
	Id = 5002,
	Name = "装备挑战：对讲机",
	Character = 220002,
	Desc = "由猫博士发明的通讯设备，漆漆专用配色，可以快速传递信息，但是干扰很大。\n“收到，收到，这里是漆漆~”",
	RewardUnlock = 340004,
	ResultText = "漆漆的对讲机解锁了",
	NumCap = 2,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG01",
	StartScene = "ARENA_StartScene",
	TeamCondition = {
		{
			Condition = "NeedTagOr",
			Value = 
			{
				560110,
			},
			Desc = "必须是星际流民的队员",
			Hint = "必须是星际流民的队员",
		},
	},
	Enemy = {
		{
			Value = 245002,
			Level = 20,
		},
	},
}
ChallengeConfig[ChallengeID.Id5003] =
{
	Id = 5003,
	Name = "装备挑战：家传宝剑",
	Character = 220003,
	Desc = "出门在外，以和为贵。遇到分歧，也要争取打成共识。",
	RewardUnlock = 340006,
	ResultText = "剑士的家传宝剑解锁了",
	NumCap = 3,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG01",
	StartScene = "RPG_StartScene",
	TeamCondition = {
		{
			Condition = "NeedTagOr",
			Value = 
			{
				560103,
			},
			Desc = "必须是冒险星的队员",
			Hint = "必须是冒险星的队员",
		},
	},
	Enemy = {
		{
			Value = 245003,
			Level = 20,
		},
	},
}
ChallengeConfig[ChallengeID.Id5004] =
{
	Id = 5004,
	Name = "装备挑战：射膝弓",
	Character = 220004,
	Desc = "由仁慈精灵制作的魔弓，射出来的箭会自动飞向敌人的膝盖，帮他提前退休。",
	RewardUnlock = 340008,
	ResultText = "弓箭手的射膝弓解锁了",
	NumCap = 3,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG01",
	StartScene = "RPG_StartScene",
	TeamCondition = {
		{
			Condition = "NeedTagOr",
			Value = 
			{
				560103,
			},
			Desc = "必须是冒险星的队员",
			Hint = "必须是冒险星的队员",
		},
	},
	Enemy = {
		{
			Value = 245004,
			Level = 20,
		},
	},
}
ChallengeConfig[ChallengeID.Id5005] =
{
	Id = 5005,
	Name = "装备挑战：陷阱",
	Character = 220005,
	Desc = "猎人自制的陷阱，是捕获白狼的重要工具，诱饵是猎人爱吃的蜂蜜肉脯，因此有时会捕获自己。",
	RewardUnlock = 340010,
	ResultText = "猎人的陷阱解锁了",
	NumCap = 3,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG01",
	StartScene = "RPG_StartScene",
	TeamCondition = {
		{
			Condition = "NeedTagOr",
			Value = 
			{
				560103,
			},
			Desc = "必须是冒险星的队员",
			Hint = "必须是冒险星的队员",
		},
	},
	Enemy = {
		{
			Value = 245005,
			Level = 20,
		},
	},
}
ChallengeConfig[ChallengeID.Id5006] =
{
	Id = 5006,
	Name = "装备挑战：地城工作证",
	Character = 220006,
	Desc = "打败了300名同族竞争者后才获得的工作，是骨头兵非常珍惜的证件，背面印着它开心地笑着的照片，看上去十分惊悚。",
	RewardUnlock = 340012,
	ResultText = "骨头兵的地城工作证解锁了",
	NumCap = 3,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG01",
	StartScene = "RPG_StartScene",
	TeamCondition = {
		{
			Condition = "NeedTagOr",
			Value = 
			{
				560103,
			},
			Desc = "必须是冒险星的队员",
			Hint = "必须是冒险星的队员",
		},
	},
	Enemy = {
		{
			Value = 245006,
			Level = 20,
		},
	},
}
ChallengeConfig[ChallengeID.Id5007] =
{
	Id = 5007,
	Name = "装备挑战：匹奇",
	Character = 220007,
	Desc = "心爱的宠物猪，自从被指路NPC路见不平救了以后，就和指路NPC一直进行着指路的事业。对于那些饥肠辘辘的冒险家们来说则起到了望梅止渴的作用。",
	RewardUnlock = 340014,
	ResultText = "指路NPC的匹奇解锁了",
	NumCap = 3,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG01",
	StartScene = "RPG_StartScene",
	TeamCondition = {
		{
			Condition = "NeedTagOr",
			Value = 
			{
				560103,
			},
			Desc = "必须是冒险星的队员",
			Hint = "必须是冒险星的队员",
		},
	},
	Enemy = {
		{
			Value = 245007,
			Level = 20,
		},
	},
}
ChallengeConfig[ChallengeID.Id5008] =
{
	Id = 5008,
	Name = "装备挑战：免责声明",
	Character = 220008,
	Desc = "铁匠通过一系列手段才拿到的政府公文，里面明确指出因委托需要造成的装备损坏，铁匠不需要承担任何责任。",
	RewardUnlock = 340016,
	ResultText = "铁匠的免责声明解锁了",
	NumCap = 3,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG01",
	StartScene = "RPG_StartScene",
	TeamCondition = {
		{
			Condition = "NeedTagOr",
			Value = 
			{
				560103,
			},
			Desc = "必须是冒险星的队员",
			Hint = "必须是冒险星的队员",
		},
	},
	Enemy = {
		{
			Value = 245008,
			Level = 20,
		},
	},
}
ChallengeConfig[ChallengeID.Id5009] =
{
	Id = 5009,
	Name = "装备挑战：玩家墓碑",
	Character = 220009,
	Desc = "败倒在小魔王手中的冒险者的墓碑，小魔王挑了最好看的一座，一直带在身边，提醒自己要设计出更好更难的副本。",
	RewardUnlock = 340019,
	ResultText = "小魔王的玩家墓碑解锁了",
	NumCap = 3,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG01",
	StartScene = "RPG_StartScene",
	TeamCondition = {
		{
			Condition = "NeedTagOr",
			Value = 
			{
				560103,
			},
			Desc = "必须是冒险星的队员",
			Hint = "必须是冒险星的队员",
		},
	},
	Enemy = {
		{
			Value = 245009,
			Level = 28,
		},
	},
}
ChallengeConfig[ChallengeID.Id5010] =
{
	Id = 5010,
	Name = "装备挑战：魔法卷轴",
	Character = 220010,
	Desc = "记录了古代神秘魔法的羊皮卷，只有被魔法之神认可的人才能使用其中的力量，不然就得花钱买许可证了。",
	RewardUnlock = 340022,
	ResultText = "魔法师的魔法卷轴解锁了",
	NumCap = 3,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG01",
	StartScene = "RPG_StartScene",
	TeamCondition = {
		{
			Condition = "NeedTagOr",
			Value = 
			{
				560103,
			},
			Desc = "必须是冒险星的队员",
			Hint = "必须是冒险星的队员",
		},
	},
	Enemy = {
		{
			Value = 245010,
			Level = 28,
		},
	},
}
ChallengeConfig[ChallengeID.Id5011] =
{
	Id = 5011,
	Name = "装备挑战：家当包裹",
	Character = 220011,
	Desc = "塞下了全副家当的重要包裹，即使带在身边，偶尔还是会被路过的剑士询问能不能打开看看。",
	RewardUnlock = 340024,
	ResultText = "居民NPC的家当包裹解锁了",
	NumCap = 3,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG01",
	StartScene = "RPG_StartScene",
	TeamCondition = {
		{
			Condition = "NeedTagOr",
			Value = 
			{
				560103,
			},
			Desc = "必须是冒险星的队员",
			Hint = "必须是冒险星的队员",
		},
	},
	Enemy = {
		{
			Value = 245011,
			Level = 12,
		},
	},
}
ChallengeConfig[ChallengeID.Id5012] =
{
	Id = 5012,
	Name = "装备挑战：主线任务-交",
	Character = 220012,
	Desc = "必须与主线接取卷轴配套使用的主线提交卷轴，如果不配套使用一定会被冒险者打。",
	RewardUnlock = 340026,
	ResultText = "村长的主线任务-交解锁了",
	NumCap = 3,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG01",
	StartScene = "RPG_StartScene",
	TeamCondition = {
		{
			Condition = "NeedTagOr",
			Value = 
			{
				560103,
			},
			Desc = "必须是冒险星的队员",
			Hint = "必须是冒险星的队员",
		},
	},
	Enemy = {
		{
			Value = 245012,
			Level = 12,
		},
	},
}
ChallengeConfig[ChallengeID.Id5013] =
{
	Id = 5013,
	Name = "装备挑战：支线任务-交",
	Character = 220013,
	Desc = "必须与支线接取卷轴配套使用的支线提交卷轴，如果不配套使用可能会被冒险者打。",
	RewardUnlock = 340028,
	ResultText = "村长夫人的支线任务-交解锁了",
	NumCap = 3,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG01",
	StartScene = "RPG_StartScene",
	TeamCondition = {
		{
			Condition = "NeedTagOr",
			Value = 
			{
				560103,
			},
			Desc = "必须是冒险星的队员",
			Hint = "必须是冒险星的队员",
		},
	},
	Enemy = {
		{
			Value = 245013,
			Level = 12,
		},
	},
}
ChallengeConfig[ChallengeID.Id5014] =
{
	Id = 5014,
	Name = "装备挑战：保暖护膝",
	Character = 220014,
	Desc = "断送冒险生涯的有时候不是英勇牺牲，而是扭伤。卫兵找了认识的人做了一下简单处理，从此以后就落下了病根。",
	RewardUnlock = 340030,
	ResultText = "城镇卫兵的保暖护膝解锁了",
	NumCap = 3,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG01",
	StartScene = "RPG_StartScene",
	TeamCondition = {
		{
			Condition = "NeedTagOr",
			Value = 
			{
				560103,
			},
			Desc = "必须是冒险星的队员",
			Hint = "必须是冒险星的队员",
		},
	},
	Enemy = {
		{
			Value = 245014,
			Level = 20,
		},
	},
}
ChallengeConfig[ChallengeID.Id5015] =
{
	Id = 5015,
	Name = "装备挑战：营业执照",
	Character = 220015,
	Desc = "行商必备的资质证书，如果被警察问话的时候拿不出来，那么可能会遭到巨额罚款。",
	RewardUnlock = 340032,
	ResultText = "旅行商人的营业执照解锁了",
	NumCap = 3,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG01",
	StartScene = "RPG_StartScene",
	TeamCondition = {
		{
			Condition = "NeedTagOr",
			Value = 
			{
				560103,
			},
			Desc = "必须是冒险星的队员",
			Hint = "必须是冒险星的队员",
		},
	},
	Enemy = {
		{
			Value = 245015,
			Level = 20,
		},
	},
}
ChallengeConfig[ChallengeID.Id5016] =
{
	Id = 5016,
	Name = "装备挑战：狼牙棒",
	Character = 220016,
	Desc = "布满尖刺的笨重铁棒，打到身上一定很疼。",
	RewardUnlock = 340034,
	ResultText = "小队长的狼牙棒解锁了",
	NumCap = 3,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG01",
	StartScene = "RPG_StartScene",
	TeamCondition = {
		{
			Condition = "NeedTagOr",
			Value = 
			{
				560103,
			},
			Desc = "必须是冒险星的队员",
			Hint = "必须是冒险星的队员",
		},
	},
	Enemy = {
		{
			Value = 245016,
			Level = 20,
		},
	},
}
ChallengeConfig[ChallengeID.Id5017] =
{
	Id = 5017,
	Name = "装备挑战：全自动测试机",
	Character = 220017,
	Desc = "由程序猿制作的性能强悍的自动测试机，能够自动筛选出99.99%的问题，极大地提升了寻找异虫霸格的效率，不过相传这个测试机本身也藏着霸格。",
	RewardUnlock = 340036,
	ResultText = "除虫者的全自动测试机解锁了",
	NumCap = 3,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG01",
	StartScene = "RPG_StartScene",
	TeamCondition = {
		{
			Condition = "NeedTagOr",
			Value = 
			{
				560103,
			},
			Desc = "必须是冒险星的队员",
			Hint = "必须是冒险星的队员",
		},
	},
	Enemy = {
		{
			Value = 245017,
			Level = 20,
		},
	},
}
ChallengeConfig[ChallengeID.Id5018] =
{
	Id = 5018,
	Name = "装备挑战：死循环",
	Character = 220018,
	Desc = "即使其内部也充满了矛盾。制造死循环，必须击败程序猿；击败程序猿，必须先制造死循环。",
	RewardUnlock = 340038,
	ResultText = "异虫霸格的死循环解锁了",
	NumCap = 3,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG01",
	StartScene = "RPG_StartScene",
	TeamCondition = {
		{
			Condition = "NeedTagOr",
			Value = 
			{
				560103,
			},
			Desc = "必须是冒险星的队员",
			Hint = "必须是冒险星的队员",
		},
	},
	Enemy = {
		{
			Value = 245018,
			Level = 20,
		},
	},
}
ChallengeConfig[ChallengeID.Id5019] =
{
	Id = 5019,
	Name = "装备挑战：黄金子弹",
	Character = 220019,
	Desc = "拥有超强威力的黄金子弹，需要对火器进行改造后才能发射。因为造价非常昂贵，所以每次战斗结束后火枪手都会去回收这颗子弹。",
	RewardUnlock = 340041,
	ResultText = "火枪手的黄金子弹解锁了",
	NumCap = 3,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG01",
	StartScene = "RPG_StartScene",
	TeamCondition = {
		{
			Condition = "NeedTagOr",
			Value = 
			{
				560103,
			},
			Desc = "必须是冒险星的队员",
			Hint = "必须是冒险星的队员",
		},
	},
	Enemy = {
		{
			Value = 245019,
			Level = 28,
		},
	},
}
ChallengeConfig[ChallengeID.Id5020] =
{
	Id = 5020,
	Name = "装备挑战：狼族的证明",
	Character = 220020,
	Desc = "狼族独特的配饰，戴上以后听觉会倍增，能够轻易发现附近的敌人,但也会下意识地对着月亮发出吼叫。",
	RewardUnlock = 340044,
	ResultText = "刺客的狼族的证明解锁了",
	NumCap = 3,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG01",
	StartScene = "RPG_StartScene",
	TeamCondition = {
		{
			Condition = "NeedTagOr",
			Value = 
			{
				560103,
			},
			Desc = "必须是冒险星的队员",
			Hint = "必须是冒险星的队员",
		},
	},
	Enemy = {
		{
			Value = 245020,
			Level = 28,
		},
	},
}
ChallengeConfig[ChallengeID.Id5021] =
{
	Id = 5021,
	Name = "装备挑战：爱心十字章",
	Character = 220021,
	Desc = "能够给与人们爱与希望的圣物，在修道院中代代传承。据说，十字章会根据主人的性格变换中间的图案。",
	RewardUnlock = 340047,
	ResultText = "牧师的爱心十字章解锁了",
	NumCap = 3,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG01",
	StartScene = "RPG_StartScene",
	TeamCondition = {
		{
			Condition = "NeedTagOr",
			Value = 
			{
				560103,
			},
			Desc = "必须是冒险星的队员",
			Hint = "必须是冒险星的队员",
		},
	},
	Enemy = {
		{
			Value = 245021,
			Level = 28,
		},
	},
}
ChallengeConfig[ChallengeID.Id5022] =
{
	Id = 5022,
	Name = "装备挑战：2dmax",
	Character = 220022,
	Desc = "动画制作的高级软件，使用了立体的骨骼系统，因此能够制作出更为复杂的立体动画，也能穿更复杂的模。",
	RewardUnlock = 340050,
	ResultText = "动画师的2dmax解锁了",
	NumCap = 3,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG01",
	StartScene = "RPG_StartScene",
	TeamCondition = {
		{
			Condition = "NeedTagOr",
			Value = 
			{
				560103,
			},
			Desc = "必须是冒险星的队员",
			Hint = "必须是冒险星的队员",
		},
	},
	Enemy = {
		{
			Value = 245022,
			Level = 28,
		},
	},
}
ChallengeConfig[ChallengeID.Id5023] =
{
	Id = 5023,
	Name = "装备挑战：金音量勋章",
	Character = 220023,
	Desc = "“谁是音量王”大赛中的冠军奖品，获奖者同时将获得了一百万元的配音合同，并由经纪公司帮忙推出一张专辑，专辑名为《为什么不奶我》。",
	RewardUnlock = 340053,
	ResultText = "配音演员的金音量勋章解锁了",
	NumCap = 3,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG01",
	StartScene = "RPG_StartScene",
	TeamCondition = {
		{
			Condition = "NeedTagOr",
			Value = 
			{
				560103,
			},
			Desc = "必须是冒险星的队员",
			Hint = "必须是冒险星的队员",
		},
	},
	Enemy = {
		{
			Value = 245023,
			Level = 28,
		},
	},
}
ChallengeConfig[ChallengeID.Id5024] =
{
	Id = 5024,
	Name = "装备挑战：再改就死刀",
	Character = 220024,
	Desc = "一种以威慑为主的社交型武器，在面对游戏策划反复无常的提案修改时，可以有效减少其修改次数。\n“谁也别拉我，我今天一定要捅死这个策划！”",
	RewardUnlock = 340056,
	ResultText = "程序猿的再改就死刀解锁了",
	NumCap = 3,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG01",
	StartScene = "RPG_StartScene",
	TeamCondition = {
		{
			Condition = "NeedTagOr",
			Value = 
			{
				560103,
			},
			Desc = "必须是冒险星的队员",
			Hint = "必须是冒险星的队员",
		},
	},
	Enemy = {
		{
			Value = 245024,
			Level = 28,
		},
	},
}
ChallengeConfig[ChallengeID.Id5025] =
{
	Id = 5025,
	Name = "装备挑战：灵感",
	Character = 220025,
	Desc = "看不见的小灯泡，需要依靠阅读及细心的生活体验才能累积的艺术感，感觉对了的时候脑中会忽然亮起来。有了它就可以同时瞧不起用手绘板和手写笔的人。",
	RewardUnlock = 340059,
	ResultText = "美术妹子的灵感解锁了",
	NumCap = 3,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG01",
	StartScene = "RPG_StartScene",
	TeamCondition = {
		{
			Condition = "NeedTagOr",
			Value = 
			{
				560103,
			},
			Desc = "必须是冒险星的队员",
			Hint = "必须是冒险星的队员",
		},
	},
	Enemy = {
		{
			Value = 245025,
			Level = 28,
		},
	},
}
ChallengeConfig[ChallengeID.Id5026] =
{
	Id = 5026,
	Name = "装备挑战：祖辈的项链",
	Character = 220026,
	Desc = "传奇的龙骑士一族世代传承的龙牙项链，只有经历过长老的考验，才能够获得。",
	RewardUnlock = 340062,
	ResultText = "龙骑士的祖辈的项链解锁了",
	NumCap = 3,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG01",
	StartScene = "RPG_StartScene",
	TeamCondition = {
		{
			Condition = "NeedTagOr",
			Value = 
			{
				560103,
			},
			Desc = "必须是冒险星的队员",
			Hint = "必须是冒险星的队员",
		},
	},
	Enemy = {
		{
			Value = 245026,
			Level = 36,
		},
	},
}
ChallengeConfig[ChallengeID.Id5027] =
{
	Id = 5027,
	Name = "装备挑战：便携游戏机",
	Character = 220027,
	Desc = "内置了大量小游戏的便携式游戏机，黑龙王子一看到就爱不释手。他的目标是所有游戏全白金奖杯。",
	RewardUnlock = 340065,
	ResultText = "黑龙王子的便携游戏机解锁了",
	NumCap = 3,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG01",
	StartScene = "RPG_StartScene",
	TeamCondition = {
		{
			Condition = "NeedTagOr",
			Value = 
			{
				560103,
			},
			Desc = "必须是冒险星的队员",
			Hint = "必须是冒险星的队员",
		},
	},
	Enemy = {
		{
			Value = 245027,
			Level = 36,
		},
	},
}
ChallengeConfig[ChallengeID.Id5028] =
{
	Id = 5028,
	Name = "装备挑战：旺财",
	Character = 220028,
	Desc = "和女王非常投缘的小狗旺财，虽然没有血统证明，但是女王还是非常宠爱它，到哪里都会带着它。但似乎和来福关系不太好，两只狗一见面就打架。",
	RewardUnlock = 340068,
	ResultText = "女王大人的旺财解锁了",
	NumCap = 3,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG01",
	StartScene = "RPG_StartScene",
	TeamCondition = {
		{
			Condition = "NeedTagOr",
			Value = 
			{
				560103,
			},
			Desc = "必须是冒险星的队员",
			Hint = "必须是冒险星的队员",
		},
	},
	Enemy = {
		{
			Value = 245028,
			Level = 36,
		},
	},
}
ChallengeConfig[ChallengeID.Id5029] =
{
	Id = 5029,
	Name = "装备挑战：game over",
	Character = 220029,
	Desc = "记录了冒险者圆满通关的录像带，每次看的时候大魔王都会为勇者们历经艰辛最后通关而感动，然后想办法提升魔王城堡的攻略难度。",
	RewardUnlock = 340071,
	ResultText = "大魔王的game over解锁了",
	NumCap = 3,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG01",
	StartScene = "RPG_StartScene",
	TeamCondition = {
		{
			Condition = "NeedTagOr",
			Value = 
			{
				560103,
			},
			Desc = "必须是冒险星的队员",
			Hint = "必须是冒险星的队员",
		},
	},
	Enemy = {
		{
			Value = 245029,
			Level = 44,
		},
	},
}
ChallengeConfig[ChallengeID.Id5030] =
{
	Id = 5030,
	Name = "装备挑战：隐藏结局",
	Character = 220029,
	Desc = "记录了隐藏故事线的录像带，只有当冒险者做对了所有选择时，大魔王才能和冒险者一同观看。",
	RewardUnlock = 340072,
	ResultText = "大魔王的隐藏结局解锁了",
	NumCap = 3,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG01",
	StartScene = "RPG_StartScene",
	TeamCondition = {
		{
			Condition = "NeedTagOr",
			Value = 
			{
				560103,
			},
			Desc = "必须是冒险星的队员",
			Hint = "必须是冒险星的队员",
		},
	},
	Enemy = {
		{
			Value = 245030,
			Level = 60,
		},
	},
}
ChallengeConfig[ChallengeID.Id5031] =
{
	Id = 5031,
	Name = "装备挑战：公牛小跑",
	Character = 220101,
	Desc = "仿照公牛豪车制作的玩具车，造型优美，是奶茶王子身份的象征。",
	RewardUnlock = 340075,
	ResultText = "奶茶王子的公牛小跑解锁了",
	NumCap = 3,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG01",
	StartScene = "FAT_StartScene",
	TeamCondition = {
		{
			Condition = "NeedTagOr",
			Value = 
			{
				560104,
			},
			Desc = "必须是美食星的队员",
			Hint = "必须是美食星的队员",
		},
	},
	Enemy = {
		{
			Value = 245031,
			Level = 28,
		},
	},
}
ChallengeConfig[ChallengeID.Id5032] =
{
	Id = 5032,
	Name = "装备挑战：波子小跑",
	Character = 220102,
	Desc = "仿照超级赛车制作的玩具车，性能强悍，是汽水王子身份的象征。",
	RewardUnlock = 340078,
	ResultText = "汽水王子的波子小跑解锁了",
	NumCap = 3,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG01",
	StartScene = "FAT_StartScene",
	TeamCondition = {
		{
			Condition = "NeedTagOr",
			Value = 
			{
				560104,
			},
			Desc = "必须是美食星的队员",
			Hint = "必须是美食星的队员",
		},
	},
	Enemy = {
		{
			Value = 245032,
			Level = 28,
		},
	},
}
ChallengeConfig[ChallengeID.Id5033] =
{
	Id = 5033,
	Name = "装备挑战：捷猫小跑",
	Character = 220103,
	Desc = "仿照奔马豪车制作的玩具车，奢华高调，是可乐王子身份的象征。",
	RewardUnlock = 340081,
	ResultText = "可乐王子的捷猫小跑解锁了",
	NumCap = 3,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG01",
	StartScene = "FAT_StartScene",
	TeamCondition = {
		{
			Condition = "NeedTagOr",
			Value = 
			{
				560104,
			},
			Desc = "必须是美食星的队员",
			Hint = "必须是美食星的队员",
		},
	},
	Enemy = {
		{
			Value = 245033,
			Level = 28,
		},
	},
}
ChallengeConfig[ChallengeID.Id5034] =
{
	Id = 5034,
	Name = "装备挑战：龙标小跑",
	Character = 220104,
	Desc = "仿照最新式赛车制作的玩具车，采用了最新技术，是啤酒王子身份的象征。",
	RewardUnlock = 340084,
	ResultText = "啤酒王子的龙标小跑解锁了",
	NumCap = 3,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG01",
	StartScene = "FAT_StartScene",
	TeamCondition = {
		{
			Condition = "NeedTagOr",
			Value = 
			{
				560104,
			},
			Desc = "必须是美食星的队员",
			Hint = "必须是美食星的队员",
		},
	},
	Enemy = {
		{
			Value = 245034,
			Level = 28,
		},
	},
}
ChallengeConfig[ChallengeID.Id5035] =
{
	Id = 5035,
	Name = "装备挑战：运动短裤",
	Character = 220105,
	Desc = "红色运动短裤，散发着苹果的香气，然而没有人会去闻。",
	RewardUnlock = 340086,
	ResultText = "小红的运动短裤解锁了",
	NumCap = 3,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG01",
	StartScene = "FAT_StartScene",
	TeamCondition = {
		{
			Condition = "NeedTagOr",
			Value = 
			{
				560104,
			},
			Desc = "必须是美食星的队员",
			Hint = "必须是美食星的队员",
		},
	},
	Enemy = {
		{
			Value = 245035,
			Level = 12,
		},
		{
			Value = 245036,
			Level = 12,
		},
	},
}
ChallengeConfig[ChallengeID.Id5036] =
{
	Id = 5036,
	Name = "装备挑战：运动短裤",
	Character = 220106,
	Desc = "橙色运动短裤，散发着橙子的香气，然而没有人会去闻。",
	RewardUnlock = 340088,
	ResultText = "小橙的运动短裤解锁了",
	NumCap = 3,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG01",
	StartScene = "FAT_StartScene",
	TeamCondition = {
		{
			Condition = "NeedTagOr",
			Value = 
			{
				560104,
			},
			Desc = "必须是美食星的队员",
			Hint = "必须是美食星的队员",
		},
	},
	Enemy = {
		{
			Value = 245037,
			Level = 12,
		},
		{
			Value = 245038,
			Level = 12,
		},
		{
			Value = 245039,
			Level = 12,
		},
	},
}
ChallengeConfig[ChallengeID.Id5037] =
{
	Id = 5037,
	Name = "装备挑战：运动短裤",
	Character = 220107,
	Desc = "黄色运动短裤，散发着柠檬的香气，然而没有人会去闻。",
	RewardUnlock = 340090,
	ResultText = "小黄的运动短裤解锁了",
	NumCap = 3,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG01",
	StartScene = "FAT_StartScene",
	TeamCondition = {
		{
			Condition = "NeedTagOr",
			Value = 
			{
				560104,
			},
			Desc = "必须是美食星的队员",
			Hint = "必须是美食星的队员",
		},
	},
	Enemy = {
		{
			Value = 245040,
			Level = 12,
		},
		{
			Value = 245041,
			Level = 12,
		},
	},
}
ChallengeConfig[ChallengeID.Id5038] =
{
	Id = 5038,
	Name = "装备挑战：运动短裤",
	Character = 220108,
	Desc = "绿色运动短裤，散发着奇异果的香气，然而没有人会去闻。",
	RewardUnlock = 340092,
	ResultText = "小绿的运动短裤解锁了",
	NumCap = 3,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG01",
	StartScene = "FAT_StartScene",
	TeamCondition = {
		{
			Condition = "NeedTagOr",
			Value = 
			{
				560104,
			},
			Desc = "必须是美食星的队员",
			Hint = "必须是美食星的队员",
		},
	},
	Enemy = {
		{
			Value = 245042,
			Level = 12,
		},
		{
			Value = 245043,
			Level = 12,
		},
	},
}
ChallengeConfig[ChallengeID.Id5039] =
{
	Id = 5039,
	Name = "装备挑战：运动短裤",
	Character = 220109,
	Desc = "青色运动短裤，散发着蓝莓的香气，然而没有人会去闻。",
	RewardUnlock = 340094,
	ResultText = "小青的运动短裤解锁了",
	NumCap = 3,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG01",
	StartScene = "FAT_StartScene",
	TeamCondition = {
		{
			Condition = "NeedTagOr",
			Value = 
			{
				560104,
			},
			Desc = "必须是美食星的队员",
			Hint = "必须是美食星的队员",
		},
	},
	Enemy = {
		{
			Value = 245044,
			Level = 12,
		},
		{
			Value = 245045,
			Level = 12,
		},
	},
}
ChallengeConfig[ChallengeID.Id5040] =
{
	Id = 5040,
	Name = "装备挑战：运动短裤",
	Character = 220110,
	Desc = "蓝色运动短裤，散发着薄荷的香气，然而没有人会去闻。",
	RewardUnlock = 340096,
	ResultText = "小蓝的运动短裤解锁了",
	NumCap = 3,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG01",
	StartScene = "FAT_StartScene",
	TeamCondition = {
		{
			Condition = "NeedTagOr",
			Value = 
			{
				560104,
			},
			Desc = "必须是美食星的队员",
			Hint = "必须是美食星的队员",
		},
	},
	Enemy = {
		{
			Value = 245046,
			Level = 12,
		},
		{
			Value = 245047,
			Level = 12,
		},
	},
}
ChallengeConfig[ChallengeID.Id5041] =
{
	Id = 5041,
	Name = "装备挑战：运动短裤",
	Character = 220111,
	Desc = "紫色运动短裤，散发着葡萄的香气，然而没有人会去闻。",
	RewardUnlock = 340098,
	ResultText = "小紫的运动短裤解锁了",
	NumCap = 3,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG01",
	StartScene = "FAT_StartScene",
	TeamCondition = {
		{
			Condition = "NeedTagOr",
			Value = 
			{
				560104,
			},
			Desc = "必须是美食星的队员",
			Hint = "必须是美食星的队员",
		},
	},
	Enemy = {
		{
			Value = 245048,
			Level = 12,
		},
		{
			Value = 245049,
			Level = 12,
		},
	},
}
ChallengeConfig[ChallengeID.Id5042] =
{
	Id = 5042,
	Name = "装备挑战：高级行李箱",
	Character = 220112,
	Desc = "棒棒糖女仆的全副家当，自从家里的豪宅被查封后，只能带着它到处流浪。必要的时候棒棒糖女仆自己可以住进去。",
	RewardUnlock = 340100,
	ResultText = "棒棒糖女仆的高级行李箱解锁了",
	NumCap = 3,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG01",
	StartScene = "FAT_StartScene",
	TeamCondition = {
		{
			Condition = "NeedTagOr",
			Value = 
			{
				560104,
			},
			Desc = "必须是美食星的队员",
			Hint = "必须是美食星的队员",
		},
	},
	Enemy = {
		{
			Value = 245050,
			Level = 20,
		},
	},
}
ChallengeConfig[ChallengeID.Id5043] =
{
	Id = 5043,
	Name = "装备挑战：咖啡伴侣",
	Character = 220113,
	Desc = "为想要提神但又怕苦的人专门准备的咖啡添加剂，使用奶精制成。",
	RewardUnlock = 340102,
	ResultText = "咖啡女仆的咖啡伴侣解锁了",
	NumCap = 3,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG01",
	StartScene = "FAT_StartScene",
	TeamCondition = {
		{
			Condition = "NeedTagOr",
			Value = 
			{
				560104,
			},
			Desc = "必须是美食星的队员",
			Hint = "必须是美食星的队员",
		},
	},
	Enemy = {
		{
			Value = 245051,
			Level = 20,
		},
	},
}
ChallengeConfig[ChallengeID.Id5044] =
{
	Id = 5044,
	Name = "装备挑战：魔力打蛋器",
	Character = 220114,
	Desc = "能够完美地将蛋液打匀的打蛋器，是仙子们通过考验后才能获得的礼物，上面还粘着没来得及撕下来的网购爆款商标。",
	RewardUnlock = 340104,
	ResultText = "华夫饼仙子的魔力打蛋器解锁了",
	NumCap = 3,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG01",
	StartScene = "FAT_StartScene",
	TeamCondition = {
		{
			Condition = "NeedTagOr",
			Value = 
			{
				560104,
			},
			Desc = "必须是美食星的队员",
			Hint = "必须是美食星的队员",
		},
	},
	Enemy = {
		{
			Value = 245052,
			Level = 20,
		},
	},
}
ChallengeConfig[ChallengeID.Id5045] =
{
	Id = 5045,
	Name = "装备挑战：魔力酒精",
	Character = 220115,
	Desc = "能够完美地去除食物中的腥味的酒精，是仙子们通过考验后才能获得的礼物。未成年人不能参加挑战。",
	RewardUnlock = 340106,
	ResultText = "松饼仙子的魔力酒精解锁了",
	NumCap = 3,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG01",
	StartScene = "FAT_StartScene",
	TeamCondition = {
		{
			Condition = "NeedTagOr",
			Value = 
			{
				560104,
			},
			Desc = "必须是美食星的队员",
			Hint = "必须是美食星的队员",
		},
	},
	Enemy = {
		{
			Value = 245053,
			Level = 20,
		},
	},
}
ChallengeConfig[ChallengeID.Id5046] =
{
	Id = 5046,
	Name = "装备挑战：布丁瓶",
	Character = 220116,
	Desc = "把价值一百金币的布丁用价值两金币的瓶子包装起来，就可以以五百金币的价格卖出。",
	RewardUnlock = 340108,
	ResultText = "布丁仙子的布丁瓶解锁了",
	NumCap = 3,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG01",
	StartScene = "FAT_StartScene",
	TeamCondition = {
		{
			Condition = "NeedTagOr",
			Value = 
			{
				560104,
			},
			Desc = "必须是美食星的队员",
			Hint = "必须是美食星的队员",
		},
	},
	Enemy = {
		{
			Value = 245054,
			Level = 20,
		},
	},
}
ChallengeConfig[ChallengeID.Id5047] =
{
	Id = 5047,
	Name = "装备挑战：干燥剂",
	Character = 220117,
	Desc = "薯片夫人为女儿准备的干燥剂包，能够保持女儿松脆的口感，避免受潮。但也有一部分喜欢软绵绵口感的人和老年人对此表示不满。",
	RewardUnlock = 340110,
	ResultText = "虾条小姐的干燥剂解锁了",
	NumCap = 3,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG01",
	StartScene = "FAT_StartScene",
	TeamCondition = {
		{
			Condition = "NeedTagOr",
			Value = 
			{
				560104,
			},
			Desc = "必须是美食星的队员",
			Hint = "必须是美食星的队员",
		},
	},
	Enemy = {
		{
			Value = 245055,
			Level = 20,
		},
	},
}
ChallengeConfig[ChallengeID.Id5048] =
{
	Id = 5048,
	Name = "装备挑战：调味包",
	Character = 220118,
	Desc = "薯片夫人为女儿特别制作的小粉包，能够满足女儿各种各样的香味需要，有时也会诞生出一些非常魔幻的味道。",
	RewardUnlock = 340112,
	ResultText = "妙脆角小姐的调味包解锁了",
	NumCap = 3,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG01",
	StartScene = "FAT_StartScene",
	TeamCondition = {
		{
			Condition = "NeedTagOr",
			Value = 
			{
				560104,
			},
			Desc = "必须是美食星的队员",
			Hint = "必须是美食星的队员",
		},
	},
	Enemy = {
		{
			Value = 245056,
			Level = 20,
		},
	},
}
ChallengeConfig[ChallengeID.Id5049] =
{
	Id = 5049,
	Name = "装备挑战：大片生菜",
	Character = 220119,
	Desc = "可以有效缓解五花肉油腻口感的大片蔬菜，是烤肉自助后期强行吃肉不可或缺的利器，但也是某些高级肉食主义者眼中最为下贱的存在。",
	RewardUnlock = 340115,
	ResultText = "培根女巫的大片生菜解锁了",
	NumCap = 3,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG01",
	StartScene = "FAT_StartScene",
	TeamCondition = {
		{
			Condition = "NeedTagOr",
			Value = 
			{
				560104,
			},
			Desc = "必须是美食星的队员",
			Hint = "必须是美食星的队员",
		},
	},
	Enemy = {
		{
			Value = 245057,
			Level = 28,
		},
	},
}
ChallengeConfig[ChallengeID.Id5050] =
{
	Id = 5050,
	Name = "装备挑战：优质土豆",
	Character = 220120,
	Desc = "被薯条国王保管的顶级土豆，据说在遥远的世界被当作服务器使用。",
	RewardUnlock = 340118,
	ResultText = "薯片夫人的优质土豆解锁了",
	NumCap = 3,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG01",
	StartScene = "FAT_StartScene",
	TeamCondition = {
		{
			Condition = "NeedTagOr",
			Value = 
			{
				560104,
			},
			Desc = "必须是美食星的队员",
			Hint = "必须是美食星的队员",
		},
	},
	Enemy = {
		{
			Value = 245058,
			Level = 28,
		},
	},
}
ChallengeConfig[ChallengeID.Id5051] =
{
	Id = 5051,
	Name = "装备挑战：懂事魔镜",
	Character = 220121,
	Desc = "黑巧克力皇后从女巫那里取得的另一面魔镜，相比诚实魔镜，这面镜子的回答总是非常得体，哪怕说出来的话它自己都不信。",
	RewardUnlock = 340121,
	ResultText = "黑巧克力皇后的懂事魔镜解锁了",
	NumCap = 3,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG01",
	StartScene = "FAT_StartScene",
	TeamCondition = {
		{
			Condition = "NeedTagOr",
			Value = 
			{
				560104,
			},
			Desc = "必须是美食星的队员",
			Hint = "必须是美食星的队员",
		},
	},
	Enemy = {
		{
			Value = 245059,
			Level = 28,
		},
	},
}
ChallengeConfig[ChallengeID.Id5052] =
{
	Id = 5052,
	Name = "装备挑战：魔力糖浆",
	Character = 220122,
	Desc = "能够赋予食物一种快乐力量的糖浆，是仙子们送给棉花糖公主的礼物，一口能把血糖拉高两个数。",
	RewardUnlock = 340124,
	ResultText = "棉花糖公主的魔力糖浆解锁了",
	NumCap = 3,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG01",
	StartScene = "FAT_StartScene",
	TeamCondition = {
		{
			Condition = "NeedTagOr",
			Value = 
			{
				560104,
			},
			Desc = "必须是美食星的队员",
			Hint = "必须是美食星的队员",
		},
	},
	Enemy = {
		{
			Value = 245060,
			Level = 28,
		},
	},
}
ChallengeConfig[ChallengeID.Id5053] =
{
	Id = 5053,
	Name = "装备挑战：缺角苹果",
	Character = 220123,
	Desc = "冰淇淋公主最喜欢的水果，缺掉的那块卡在了喉咙里。",
	RewardUnlock = 340127,
	ResultText = "冰淇淋公主的缺角苹果解锁了",
	NumCap = 3,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG01",
	StartScene = "FAT_StartScene",
	TeamCondition = {
		{
			Condition = "NeedTagOr",
			Value = 
			{
				560104,
			},
			Desc = "必须是美食星的队员",
			Hint = "必须是美食星的队员",
		},
	},
	Enemy = {
		{
			Value = 245061,
			Level = 28,
		},
	},
}
ChallengeConfig[ChallengeID.Id5054] =
{
	Id = 5054,
	Name = "装备挑战：水晶托盘",
	Character = 220124,
	Desc = "蛋糕卷公主自制的水晶托盘，每次参加舞会都会带上，不过因为一直弄丢，所以被薯片夫人没收保管了起来。",
	RewardUnlock = 340130,
	ResultText = "蛋糕卷公主的水晶托盘解锁了",
	NumCap = 3,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG01",
	StartScene = "FAT_StartScene",
	TeamCondition = {
		{
			Condition = "NeedTagOr",
			Value = 
			{
				560104,
			},
			Desc = "必须是美食星的队员",
			Hint = "必须是美食星的队员",
		},
	},
	Enemy = {
		{
			Value = 245062,
			Level = 28,
		},
	},
}
ChallengeConfig[ChallengeID.Id5055] =
{
	Id = 5055,
	Name = "装备挑战：吹风机",
	Character = 220125,
	Desc = "可以加速慕斯黏在头发上的吹风机，让清洗更加困难。",
	RewardUnlock = 340133,
	ResultText = "栗子蛋糕公主的吹风机解锁了",
	NumCap = 3,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG01",
	StartScene = "FAT_StartScene",
	TeamCondition = {
		{
			Condition = "NeedTagOr",
			Value = 
			{
				560104,
			},
			Desc = "必须是美食星的队员",
			Hint = "必须是美食星的队员",
		},
	},
	Enemy = {
		{
			Value = 245063,
			Level = 28,
		},
	},
}
ChallengeConfig[ChallengeID.Id5056] =
{
	Id = 5056,
	Name = "装备挑战：肉饼",
	Character = 220126,
	Desc = "使用碎肉制作而成的牛肉汉堡，即使单独拿出来吃味道也非常鲜美。任性一点加三片的话，会更让人满足。",
	RewardUnlock = 340136,
	ResultText = "汉堡小姐的肉饼解锁了",
	NumCap = 3,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG01",
	StartScene = "FAT_StartScene",
	TeamCondition = {
		{
			Condition = "NeedTagOr",
			Value = 
			{
				560104,
			},
			Desc = "必须是美食星的队员",
			Hint = "必须是美食星的队员",
		},
	},
	Enemy = {
		{
			Value = 245064,
			Level = 28,
		},
	},
}
ChallengeConfig[ChallengeID.Id5057] =
{
	Id = 5057,
	Name = "装备挑战：芥末酱",
	Character = 220127,
	Desc = "与热狗肠在一起简直是绝配的芥末酱料，不仅使食物外观看起来更诱人，在口味上也让人感到不可思议。\n这是他被女孩子们拒绝的根本原因。",
	RewardUnlock = 340139,
	ResultText = "热狗先生的芥末酱解锁了",
	NumCap = 3,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG01",
	StartScene = "FAT_StartScene",
	TeamCondition = {
		{
			Condition = "NeedTagOr",
			Value = 
			{
				560104,
			},
			Desc = "必须是美食星的队员",
			Hint = "必须是美食星的队员",
		},
	},
	Enemy = {
		{
			Value = 245065,
			Level = 28,
		},
	},
}
ChallengeConfig[ChallengeID.Id5058] =
{
	Id = 5058,
	Name = "装备挑战：皇家商标",
	Character = 220128,
	Desc = "皇家认证的商标，听说必须得到薯条国王的认可，才能拥有。认证很难，但伪造很容易。",
	RewardUnlock = 340142,
	ResultText = "番茄酱侍卫的皇家商标解锁了",
	NumCap = 3,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG01",
	StartScene = "FAT_StartScene",
	TeamCondition = {
		{
			Condition = "NeedTagOr",
			Value = 
			{
				560104,
			},
			Desc = "必须是美食星的队员",
			Hint = "必须是美食星的队员",
		},
	},
	Enemy = {
		{
			Value = 245066,
			Level = 28,
		},
	},
}
ChallengeConfig[ChallengeID.Id5059] =
{
	Id = 5059,
	Name = "装备挑战：美味炸鸡",
	Character = 220129,
	Desc = "经过大量调味粉腌制过的鸡翅，使用上等木炭烧烤时会散发浓烈的香味。",
	RewardUnlock = 340145,
	ResultText = "炸鸡魔后的美味炸鸡解锁了",
	NumCap = 3,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG01",
	StartScene = "FAT_StartScene",
	TeamCondition = {
		{
			Condition = "NeedTagOr",
			Value = 
			{
				560104,
			},
			Desc = "必须是美食星的队员",
			Hint = "必须是美食星的队员",
		},
	},
	Enemy = {
		{
			Value = 245067,
			Level = 36,
		},
	},
}
ChallengeConfig[ChallengeID.Id5060] =
{
	Id = 5060,
	Name = "装备挑战：套餐兑换券",
	Character = 220130,
	Desc = "为了挽救王子电影的销量而制作的爆米花套餐兑换券，不成想却增加了爆米花的销量。",
	RewardUnlock = 340148,
	ResultText = "爆米花女王的套餐兑换券解锁了",
	NumCap = 3,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG01",
	StartScene = "FAT_StartScene",
	TeamCondition = {
		{
			Condition = "NeedTagOr",
			Value = 
			{
				560104,
			},
			Desc = "必须是美食星的队员",
			Hint = "必须是美食星的队员",
		},
	},
	Enemy = {
		{
			Value = 245068,
			Level = 36,
		},
	},
}
ChallengeConfig[ChallengeID.Id5061] =
{
	Id = 5061,
	Name = "装备挑战：杠铃",
	Character = 220131,
	Desc = "薯条国王唯一的健身器材，不过依靠杠铃，薯条国王就能锻炼到全身所有的肌肉。\n不过薯条身上为什么会有这么多肌肉呢？",
	RewardUnlock = 340151,
	ResultText = "薯条国王的杠铃解锁了",
	NumCap = 3,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG01",
	StartScene = "FAT_StartScene",
	TeamCondition = {
		{
			Condition = "NeedTagOr",
			Value = 
			{
				560104,
			},
			Desc = "必须是美食星的队员",
			Hint = "必须是美食星的队员",
		},
	},
	Enemy = {
		{
			Value = 245069,
			Level = 44,
		},
	},
}
ChallengeConfig[ChallengeID.Id5062] =
{
	Id = 5062,
	Name = "装备挑战：杠铃替换箱",
	Character = 220131,
	Desc = "存放了薯条国王替换用的杠铃铁饼，听说连举重运动员也无法搬动。\n因为上面太油了，抓不住。",
	RewardUnlock = 340152,
	ResultText = "薯条国王的杠铃替换箱解锁了",
	NumCap = 3,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG01",
	StartScene = "FAT_StartScene",
	TeamCondition = {
		{
			Condition = "NeedTagOr",
			Value = 
			{
				560104,
			},
			Desc = "必须是美食星的队员",
			Hint = "必须是美食星的队员",
		},
	},
	Enemy = {
		{
			Value = 245070,
			Level = 60,
		},
	},
}
ChallengeConfig[ChallengeID.Id5063] =
{
	Id = 5063,
	Name = "装备挑战：保温杯",
	Character = 220201,
	Desc = "人过中年，远离父母，生活无依无靠，至今仍然单身，还要守夜。世态炎凉，只有这保温杯里的菊花茶还有点温度。",
	RewardUnlock = 340155,
	ResultText = "保安的保温杯解锁了",
	NumCap = 3,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG01",
	StartScene = "MUS_StartScene",
	TeamCondition = {
		{
			Condition = "NeedTagOr",
			Value = 
			{
				560105,
			},
			Desc = "必须是博物馆星的队员",
			Hint = "必须是博物馆星的队员",
		},
	},
	Enemy = {
		{
			Value = 245071,
			Level = 28,
		},
	},
}
ChallengeConfig[ChallengeID.Id5064] =
{
	Id = 5064,
	Name = "装备挑战：侦探风衣",
	Character = 220202,
	Desc = "侦探的基本装备，男女都不例外。如果不穿的话，那不说话时和普通人就没有区别了。",
	RewardUnlock = 340158,
	ResultText = "侦探小姐的侦探风衣解锁了",
	NumCap = 3,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG01",
	StartScene = "MUS_StartScene",
	TeamCondition = {
		{
			Condition = "NeedTagOr",
			Value = 
			{
				560105,
			},
			Desc = "必须是博物馆星的队员",
			Hint = "必须是博物馆星的队员",
		},
	},
	Enemy = {
		{
			Value = 245072,
			Level = 28,
		},
	},
}
ChallengeConfig[ChallengeID.Id5065] =
{
	Id = 5065,
	Name = "装备挑战：铲子",
	Character = 220203,
	Desc = "轻便的工兵铲，无论挖地道或是砸箱子都能完美胜任。是开始爆窃事业必备的工具。",
	RewardUnlock = 340161,
	ResultText = "浣熊大哥的铲子解锁了",
	NumCap = 3,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG01",
	StartScene = "MUS_StartScene",
	TeamCondition = {
		{
			Condition = "NeedTagOr",
			Value = 
			{
				560105,
			},
			Desc = "必须是博物馆星的队员",
			Hint = "必须是博物馆星的队员",
		},
	},
	Enemy = {
		{
			Value = 245073,
			Level = 28,
		},
	},
}
ChallengeConfig[ChallengeID.Id5066] =
{
	Id = 5066,
	Name = "装备挑战：钳子",
	Character = 220204,
	Desc = "装有特殊机械臂的超长钳子，可以从天花板的通风口轻松地将展柜内的珠宝夹走，但如果力量太大的话会把珠宝夹碎。",
	RewardUnlock = 340164,
	ResultText = "浣熊二哥的钳子解锁了",
	NumCap = 3,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG01",
	StartScene = "MUS_StartScene",
	TeamCondition = {
		{
			Condition = "NeedTagOr",
			Value = 
			{
				560105,
			},
			Desc = "必须是博物馆星的队员",
			Hint = "必须是博物馆星的队员",
		},
	},
	Enemy = {
		{
			Value = 245074,
			Level = 28,
		},
	},
}
ChallengeConfig[ChallengeID.Id5067] =
{
	Id = 5067,
	Name = "装备挑战：焊枪",
	Character = 220205,
	Desc = "即使面对全钢板封锁的顶级保险库也能完全搞定的超高温喷枪，稍有不慎，可能保险柜里的东西也不复存在了……",
	RewardUnlock = 340167,
	ResultText = "浣熊小弟的焊枪解锁了",
	NumCap = 3,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG01",
	StartScene = "MUS_StartScene",
	TeamCondition = {
		{
			Condition = "NeedTagOr",
			Value = 
			{
				560105,
			},
			Desc = "必须是博物馆星的队员",
			Hint = "必须是博物馆星的队员",
		},
	},
	Enemy = {
		{
			Value = 245075,
			Level = 28,
		},
	},
}
ChallengeConfig[ChallengeID.Id5068] =
{
	Id = 5068,
	Name = "装备挑战：防晒霜",
	Character = 220206,
	Desc = "石像就不要面子的嘛？",
	RewardUnlock = 340169,
	ResultText = "默艾的防晒霜解锁了",
	NumCap = 3,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG01",
	StartScene = "MUS_StartScene",
	TeamCondition = {
		{
			Condition = "NeedTagOr",
			Value = 
			{
				560105,
			},
			Desc = "必须是博物馆星的队员",
			Hint = "必须是博物馆星的队员",
		},
	},
	Enemy = {
		{
			Value = 245076,
			Level = 12,
		},
	},
}
ChallengeConfig[ChallengeID.Id5069] =
{
	Id = 5069,
	Name = "装备挑战：出土照片",
	Character = 220207,
	Desc = "能够大幅提升文物待遇级别的证书，上面记载着兵马俑的出土日期、出土户籍、出土陵墓以及出土证号。",
	RewardUnlock = 340171,
	ResultText = "兵马俑的出土照片解锁了",
	NumCap = 3,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG01",
	StartScene = "MUS_StartScene",
	TeamCondition = {
		{
			Condition = "NeedTagOr",
			Value = 
			{
				560105,
			},
			Desc = "必须是博物馆星的队员",
			Hint = "必须是博物馆星的队员",
		},
	},
	Enemy = {
		{
			Value = 245077,
			Level = 12,
		},
	},
}
ChallengeConfig[ChallengeID.Id5070] =
{
	Id = 5070,
	Name = "装备挑战：保鲜膜",
	Character = 220208,
	Desc = "为了避免风蚀而卷在身上的保鲜膜，但是保鲜膜所保护的东西的保质期比它自己还长。",
	RewardUnlock = 340173,
	ResultText = "石柱人的保鲜膜解锁了",
	NumCap = 3,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG01",
	StartScene = "MUS_StartScene",
	TeamCondition = {
		{
			Condition = "NeedTagOr",
			Value = 
			{
				560105,
			},
			Desc = "必须是博物馆星的队员",
			Hint = "必须是博物馆星的队员",
		},
	},
	Enemy = {
		{
			Value = 245078,
			Level = 12,
		},
	},
}
ChallengeConfig[ChallengeID.Id5071] =
{
	Id = 5071,
	Name = "装备挑战：轮滑",
	Character = 220209,
	Desc = "你以为石像就不能动吗？",
	RewardUnlock = 340175,
	ResultText = "半人马石像的轮滑解锁了",
	NumCap = 3,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG01",
	StartScene = "MUS_StartScene",
	TeamCondition = {
		{
			Condition = "NeedTagOr",
			Value = 
			{
				560105,
			},
			Desc = "必须是博物馆星的队员",
			Hint = "必须是博物馆星的队员",
		},
	},
	Enemy = {
		{
			Value = 245079,
			Level = 12,
		},
	},
}
ChallengeConfig[ChallengeID.Id5072] =
{
	Id = 5072,
	Name = "装备挑战：灵气",
	Character = 220210,
	Desc = "与神圣接触的那一刹，灵气来到了这个世界。\n它其实只是个会发光的球。",
	RewardUnlock = 340177,
	ResultText = "亚当的灵气解锁了",
	NumCap = 3,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG01",
	StartScene = "MUS_StartScene",
	TeamCondition = {
		{
			Condition = "NeedTagOr",
			Value = 
			{
				560105,
			},
			Desc = "必须是博物馆星的队员",
			Hint = "必须是博物馆星的队员",
		},
	},
	Enemy = {
		{
			Value = 245080,
			Level = 20,
		},
	},
}
ChallengeConfig[ChallengeID.Id5073] =
{
	Id = 5073,
	Name = "装备挑战：小天使",
	Character = 220211,
	Desc = "飞翔在天神周围的小天使，会叽叽喳喳地说个不停。因为语言不通，大家都以为他们在背诵教条，其实只是在讨论明天中午吃什么。",
	RewardUnlock = 340179,
	ResultText = "创造之神的小天使解锁了",
	NumCap = 3,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG01",
	StartScene = "MUS_StartScene",
	TeamCondition = {
		{
			Condition = "NeedTagOr",
			Value = 
			{
				560105,
			},
			Desc = "必须是博物馆星的队员",
			Hint = "必须是博物馆星的队员",
		},
	},
	Enemy = {
		{
			Value = 245081,
			Level = 20,
		},
	},
}
ChallengeConfig[ChallengeID.Id5074] =
{
	Id = 5074,
	Name = "装备挑战：错乱几何",
	Character = 220212,
	Desc = "扭曲了真实形象的几何图形，错乱排列造成了各种不同的解读。某些考生看到这种图案就会条件反射的头痛。",
	RewardUnlock = 340181,
	ResultText = "哭泣的女人的错乱几何解锁了",
	NumCap = 3,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG01",
	StartScene = "MUS_StartScene",
	TeamCondition = {
		{
			Condition = "NeedTagOr",
			Value = 
			{
				560105,
			},
			Desc = "必须是博物馆星的队员",
			Hint = "必须是博物馆星的队员",
		},
	},
	Enemy = {
		{
			Value = 245082,
			Level = 20,
		},
	},
}
ChallengeConfig[ChallengeID.Id5075] =
{
	Id = 5075,
	Name = "装备挑战：/恐惧",
	Character = 220213,
	Desc = "看到后就会不自觉地想要喊出来的表情\n啊~~~~~~~~~~~~",
	RewardUnlock = 340183,
	ResultText = "呐喊家的/恐惧解锁了",
	NumCap = 3,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG01",
	StartScene = "MUS_StartScene",
	TeamCondition = {
		{
			Condition = "NeedTagOr",
			Value = 
			{
				560105,
			},
			Desc = "必须是博物馆星的队员",
			Hint = "必须是博物馆星的队员",
		},
	},
	Enemy = {
		{
			Value = 245083,
			Level = 20,
		},
	},
}
ChallengeConfig[ChallengeID.Id5076] =
{
	Id = 5076,
	Name = "装备挑战：私房钱",
	Character = 220214,
	Desc = "原始人爸爸无意间得到的储蓄罐，不过用这种储蓄罐子也藏不了多少钱。",
	RewardUnlock = 340185,
	ResultText = "原始人爸爸的私房钱解锁了",
	NumCap = 3,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG01",
	StartScene = "MUS_StartScene",
	TeamCondition = {
		{
			Condition = "NeedTagOr",
			Value = 
			{
				560105,
			},
			Desc = "必须是博物馆星的队员",
			Hint = "必须是博物馆星的队员",
		},
	},
	Enemy = {
		{
			Value = 245084,
			Level = 20,
		},
	},
}
ChallengeConfig[ChallengeID.Id5077] =
{
	Id = 5077,
	Name = "装备挑战：工资卡",
	Character = 220215,
	Desc = "原始人爸爸的工资卡，每月发工资时，原始人妈妈会拿出50块钱给爸爸当生活费。",
	RewardUnlock = 340187,
	ResultText = "原始人妈妈的工资卡解锁了",
	NumCap = 3,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG01",
	StartScene = "MUS_StartScene",
	TeamCondition = {
		{
			Condition = "NeedTagOr",
			Value = 
			{
				560105,
			},
			Desc = "必须是博物馆星的队员",
			Hint = "必须是博物馆星的队员",
		},
	},
	Enemy = {
		{
			Value = 245085,
			Level = 20,
		},
	},
}
ChallengeConfig[ChallengeID.Id5078] =
{
	Id = 5078,
	Name = "装备挑战：假发",
	Character = 220216,
	Desc = "游客参观时留下来的假发，原始人儿子捡到后就一直戴在头上。\n那其实是胡子。",
	RewardUnlock = 340189,
	ResultText = "原始人儿子的假发解锁了",
	NumCap = 3,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG01",
	StartScene = "MUS_StartScene",
	TeamCondition = {
		{
			Condition = "NeedTagOr",
			Value = 
			{
				560105,
			},
			Desc = "必须是博物馆星的队员",
			Hint = "必须是博物馆星的队员",
		},
	},
	Enemy = {
		{
			Value = 245086,
			Level = 20,
		},
	},
}
ChallengeConfig[ChallengeID.Id5079] =
{
	Id = 5079,
	Name = "装备挑战：防腐涂料",
	Character = 220217,
	Desc = "特殊的防腐涂料，能够保持尸体始终新鲜，这样就能在末日来临那天重获新生。\n不可食用，请放在幼儿够不到的地方。",
	RewardUnlock = 340191,
	ResultText = "木乃伊的防腐涂料解锁了",
	NumCap = 3,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG01",
	StartScene = "MUS_StartScene",
	TeamCondition = {
		{
			Condition = "NeedTagOr",
			Value = 
			{
				560105,
			},
			Desc = "必须是博物馆星的队员",
			Hint = "必须是博物馆星的队员",
		},
	},
	Enemy = {
		{
			Value = 245087,
			Level = 20,
		},
	},
}
ChallengeConfig[ChallengeID.Id5080] =
{
	Id = 5080,
	Name = "装备挑战：珍珠耳环",
	Character = 220218,
	Desc = "在黑暗中若隐若现的珍珠耳环，为整幅画作增添了一种安静祥和的气氛。",
	RewardUnlock = 340194,
	ResultText = "带珍珠的少女的珍珠耳环解锁了",
	NumCap = 3,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG01",
	StartScene = "MUS_StartScene",
	TeamCondition = {
		{
			Condition = "NeedTagOr",
			Value = 
			{
				560105,
			},
			Desc = "必须是博物馆星的队员",
			Hint = "必须是博物馆星的队员",
		},
	},
	Enemy = {
		{
			Value = 245088,
			Level = 28,
		},
	},
}
ChallengeConfig[ChallengeID.Id5081] =
{
	Id = 5081,
	Name = "装备挑战：撩人鸟玉牌",
	Character = 220219,
	Desc = "古老又神秘的玉佩，能够读懂主人的心意，自动搜索附近可能合主人心意的女孩子。成功发现以后，会对着那边不停地发出口哨声，被打概率高达百分之九十。",
	RewardUnlock = 340197,
	ResultText = "猪蹄古董的撩人鸟玉牌解锁了",
	NumCap = 3,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG01",
	StartScene = "MUS_StartScene",
	TeamCondition = {
		{
			Condition = "NeedTagOr",
			Value = 
			{
				560105,
			},
			Desc = "必须是博物馆星的队员",
			Hint = "必须是博物馆星的队员",
		},
	},
	Enemy = {
		{
			Value = 245089,
			Level = 28,
		},
	},
}
ChallengeConfig[ChallengeID.Id5082] =
{
	Id = 5082,
	Name = "装备挑战：风暴图腾",
	Character = 220220,
	Desc = "标志着世界之风的符号，在特定地点画出这个符文，就能引来剧烈的风暴，但也会把画符文的人卷进去。",
	RewardUnlock = 340200,
	ResultText = "赛特的风暴图腾解锁了",
	NumCap = 3,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG01",
	StartScene = "MUS_StartScene",
	TeamCondition = {
		{
			Condition = "NeedTagOr",
			Value = 
			{
				560105,
			},
			Desc = "必须是博物馆星的队员",
			Hint = "必须是博物馆星的队员",
		},
	},
	Enemy = {
		{
			Value = 245090,
			Level = 28,
		},
	},
}
ChallengeConfig[ChallengeID.Id5083] =
{
	Id = 5083,
	Name = "装备挑战：四元素图腾",
	Character = 220221,
	Desc = "绘制着构成世界的四大元素，水、火、风、还有一个已经看不清了。",
	RewardUnlock = 340203,
	ResultText = "索贝克的四元素图腾解锁了",
	NumCap = 3,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG01",
	StartScene = "MUS_StartScene",
	TeamCondition = {
		{
			Condition = "NeedTagOr",
			Value = 
			{
				560105,
			},
			Desc = "必须是博物馆星的队员",
			Hint = "必须是博物馆星的队员",
		},
	},
	Enemy = {
		{
			Value = 245091,
			Level = 28,
		},
	},
}
ChallengeConfig[ChallengeID.Id5084] =
{
	Id = 5084,
	Name = "装备挑战：安卡的图腾",
	Character = 220222,
	Desc = "形状像眼睛的符号，表示着来自未知空间的注视者，让法老王恢复记忆的关键道具。",
	RewardUnlock = 340206,
	ResultText = "荷鲁斯的安卡的图腾解锁了",
	NumCap = 3,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG01",
	StartScene = "MUS_StartScene",
	TeamCondition = {
		{
			Condition = "NeedTagOr",
			Value = 
			{
				560105,
			},
			Desc = "必须是博物馆星的队员",
			Hint = "必须是博物馆星的队员",
		},
	},
	Enemy = {
		{
			Value = 245092,
			Level = 28,
		},
	},
}
ChallengeConfig[ChallengeID.Id5085] =
{
	Id = 5085,
	Name = "装备挑战：冥神的图腾",
	Character = 220223,
	Desc = "以未知力量连接着凡间与冥界的符号，正确地绘制能够引导幽冥重返人间。\n好了，哪里是头？",
	RewardUnlock = 340209,
	ResultText = "阿努比斯的冥神的图腾解锁了",
	NumCap = 3,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG01",
	StartScene = "MUS_StartScene",
	TeamCondition = {
		{
			Condition = "NeedTagOr",
			Value = 
			{
				560105,
			},
			Desc = "必须是博物馆星的队员",
			Hint = "必须是博物馆星的队员",
		},
	},
	Enemy = {
		{
			Value = 245093,
			Level = 28,
		},
		{
			Value = 245094,
			Level = 28,
		},
		{
			Value = 245095,
			Level = 28,
		},
	},
}
ChallengeConfig[ChallengeID.Id5086] =
{
	Id = 5086,
	Name = "装备挑战：耳朵",
	Character = 220224,
	Desc = "每个人的心情是他人很难感受到的，无论情绪有多么强烈，他人或许都会误读，或许这就是这只耳朵被割下来的原因。",
	RewardUnlock = 340212,
	ResultText = "独耳画像的耳朵解锁了",
	NumCap = 3,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG01",
	StartScene = "MUS_StartScene",
	TeamCondition = {
		{
			Condition = "NeedTagOr",
			Value = 
			{
				560105,
			},
			Desc = "必须是博物馆星的队员",
			Hint = "必须是博物馆星的队员",
		},
	},
	Enemy = {
		{
			Value = 245096,
			Level = 36,
		},
	},
}
ChallengeConfig[ChallengeID.Id5087] =
{
	Id = 5087,
	Name = "装备挑战：超粗眉笔",
	Character = 220225,
	Desc = "每天出门前，在眉毛上只需画上一笔就能搞定的特制眉笔，不过一字眉的造型好看吗？",
	RewardUnlock = 340215,
	ResultText = "弗里达的超粗眉笔解锁了",
	NumCap = 3,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG01",
	StartScene = "MUS_StartScene",
	TeamCondition = {
		{
			Condition = "NeedTagOr",
			Value = 
			{
				560105,
			},
			Desc = "必须是博物馆星的队员",
			Hint = "必须是博物馆星的队员",
		},
	},
	Enemy = {
		{
			Value = 245097,
			Level = 36,
		},
	},
}
ChallengeConfig[ChallengeID.Id5088] =
{
	Id = 5088,
	Name = "装备挑战：达芬奇的遗书",
	Character = 220226,
	Desc = "致最美的夫人，这是完美微笑的秘诀：\nA*(S+T+F)-(W+L)",
	RewardUnlock = 340218,
	ResultText = "微笑女神的达芬奇的遗书解锁了",
	NumCap = 3,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG01",
	StartScene = "MUS_StartScene",
	TeamCondition = {
		{
			Condition = "NeedTagOr",
			Value = 
			{
				560105,
			},
			Desc = "必须是博物馆星的队员",
			Hint = "必须是博物馆星的队员",
		},
	},
	Enemy = {
		{
			Value = 245098,
			Level = 36,
		},
	},
}
ChallengeConfig[ChallengeID.Id5089] =
{
	Id = 5089,
	Name = "装备挑战：绽放玫瑰",
	Character = 220227,
	Desc = "由魔术师亲自种植的红玫瑰。象征着爱情，也代表着怪盗的浪漫。一般都会叼在嘴里，然后被刺伤。",
	RewardUnlock = 340221,
	ResultText = "魔术师的绽放玫瑰解锁了",
	NumCap = 3,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG01",
	StartScene = "MUS_StartScene",
	TeamCondition = {
		{
			Condition = "NeedTagOr",
			Value = 
			{
				560105,
			},
			Desc = "必须是博物馆星的队员",
			Hint = "必须是博物馆星的队员",
		},
	},
	Enemy = {
		{
			Value = 245099,
			Level = 36,
		},
	},
}
ChallengeConfig[ChallengeID.Id5090] =
{
	Id = 5090,
	Name = "装备挑战：武士刀",
	Character = 220228,
	Desc = "由名匠带着恶意制作的诅咒之刃，活人持有就会遭到厄运，据说是无上大快刀。",
	RewardUnlock = 340224,
	ResultText = "武士的武士刀解锁了",
	NumCap = 3,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG01",
	StartScene = "MUS_StartScene",
	TeamCondition = {
		{
			Condition = "NeedTagOr",
			Value = 
			{
				560105,
			},
			Desc = "必须是博物馆星的队员",
			Hint = "必须是博物馆星的队员",
		},
	},
	Enemy = {
		{
			Value = 245100,
			Level = 36,
		},
	},
}
ChallengeConfig[ChallengeID.Id5091] =
{
	Id = 5091,
	Name = "装备挑战：增高鞋垫",
	Character = 220229,
	Desc = "我人生的遗憾之一，将依靠这件器物来消弭。\n“如果你再出言不逊，我将高高跳起痛击你的膝盖！”",
	RewardUnlock = 340227,
	ResultText = "名人蜡像的增高鞋垫解锁了",
	NumCap = 3,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG01",
	StartScene = "MUS_StartScene",
	TeamCondition = {
		{
			Condition = "NeedTagOr",
			Value = 
			{
				560105,
			},
			Desc = "必须是博物馆星的队员",
			Hint = "必须是博物馆星的队员",
		},
	},
	Enemy = {
		{
			Value = 245101,
			Level = 44,
		},
	},
}
ChallengeConfig[ChallengeID.Id5092] =
{
	Id = 5092,
	Name = "装备挑战：小马",
	Character = 220229,
	Desc = "很懂得主人心意的小白马，在主人成为博物馆的蜡像后，它也被人做成了蜡像，陪伴在主人身边。偶尔会被人跟另个馆区的和尚的坐骑搞混。",
	RewardUnlock = 340228,
	ResultText = "名人蜡像的小马解锁了",
	NumCap = 3,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG01",
	StartScene = "MUS_StartScene",
	TeamCondition = {
		{
			Condition = "NeedTagOr",
			Value = 
			{
				560105,
			},
			Desc = "必须是博物馆星的队员",
			Hint = "必须是博物馆星的队员",
		},
	},
	Enemy = {
		{
			Value = 245102,
			Level = 60,
		},
	},
}
ChallengeConfig[ChallengeID.Id5093] =
{
	Id = 5093,
	Name = "装备挑战：自行车",
	Character = 220301,
	Desc = "跟某个小学生那边借来的核动力自行车。最高时速为400km/h，过弯需承受10G重力。\n为什么骑着这种车的人会去送报纸呢？",
	RewardUnlock = 340230,
	ResultText = "报童的自行车解锁了",
	NumCap = 3,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG01",
	StartScene = "SUS_StartScene",
	TeamCondition = {
		{
			Condition = "NeedTagOr",
			Value = 
			{
				560106,
			},
			Desc = "必须是悬疑星的队员",
			Hint = "必须是悬疑星的队员",
		},
	},
	Enemy = {
		{
			Value = 245103,
			Level = 12,
		},
	},
}
ChallengeConfig[ChallengeID.Id5094] =
{
	Id = 5094,
	Name = "装备挑战：超低剂量毒药",
	Character = 220302,
	Desc = "对于严谨的作家而言，要确保小说中新颖的作案手法切实可行。那么有时候，就需要亲自验证一下了。\n我来喝，我上了保险。",
	RewardUnlock = 340233,
	ResultText = "阿加莎的超低剂量毒药解锁了",
	NumCap = 3,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG01",
	StartScene = "SUS_StartScene",
	TeamCondition = {
		{
			Condition = "NeedTagOr",
			Value = 
			{
				560106,
			},
			Desc = "必须是悬疑星的队员",
			Hint = "必须是悬疑星的队员",
		},
	},
	Enemy = {
		{
			Value = 245104,
			Level = 28,
		},
	},
}
ChallengeConfig[ChallengeID.Id5095] =
{
	Id = 5095,
	Name = "装备挑战：心脏起搏器",
	Character = 220303,
	Desc = "强力心脏起搏器，有强烈求生欲的人一般都会被救回来，一天内不能死超过3次",
	RewardUnlock = 340236,
	ResultText = "死者的心脏起搏器解锁了",
	NumCap = 3,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG01",
	StartScene = "SUS_StartScene",
	TeamCondition = {
		{
			Condition = "NeedTagOr",
			Value = 
			{
				560106,
			},
			Desc = "必须是悬疑星的队员",
			Hint = "必须是悬疑星的队员",
		},
	},
	Enemy = {
		{
			Value = 245105,
			Level = 28,
		},
	},
}
ChallengeConfig[ChallengeID.Id5096] =
{
	Id = 5096,
	Name = "装备挑战：侦探小说",
	Character = 220304,
	Desc = "畅销推理周刊，目前正连载《新日命四郎》。证人能够背出每一集的剧情。\n好了，你还有什么好说的？",
	RewardUnlock = 340239,
	ResultText = "证人的侦探小说解锁了",
	NumCap = 3,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG01",
	StartScene = "SUS_StartScene",
	TeamCondition = {
		{
			Condition = "NeedTagOr",
			Value = 
			{
				560106,
			},
			Desc = "必须是悬疑星的队员",
			Hint = "必须是悬疑星的队员",
		},
	},
	Enemy = {
		{
			Value = 245106,
			Level = 28,
		},
	},
}
ChallengeConfig[ChallengeID.Id5097] =
{
	Id = 5097,
	Name = "装备挑战：动机",
	Character = 220305,
	Desc = "凶手隐藏武器，但杀伤力却很小。通常都是些鸡毛蒜皮的原因，往往有其他人的动机会有更大的威力。",
	RewardUnlock = 340242,
	ResultText = "凶手的动机解锁了",
	NumCap = 3,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG01",
	StartScene = "SUS_StartScene",
	TeamCondition = {
		{
			Condition = "NeedTagOr",
			Value = 
			{
				560106,
			},
			Desc = "必须是悬疑星的队员",
			Hint = "必须是悬疑星的队员",
		},
	},
	Enemy = {
		{
			Value = 245107,
			Level = 28,
		},
	},
}
ChallengeConfig[ChallengeID.Id5098] =
{
	Id = 5098,
	Name = "装备挑战：好人卡",
	Character = 220306,
	Desc = "行窃成功后，会撒在案发现场作为签名，据说会让捡到的男性立刻大哭不止。",
	RewardUnlock = 340244,
	ResultText = "小泪的好人卡解锁了",
	NumCap = 3,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG01",
	StartScene = "SUS_StartScene",
	TeamCondition = {
		{
			Condition = "NeedTagOr",
			Value = 
			{
				560106,
			},
			Desc = "必须是悬疑星的队员",
			Hint = "必须是悬疑星的队员",
		},
	},
	Enemy = {
		{
			Value = 245108,
			Level = 20,
		},
	},
}
ChallengeConfig[ChallengeID.Id5099] =
{
	Id = 5099,
	Name = "装备挑战：伸缩腰带",
	Character = 220307,
	Desc = "看似普通腰带，实际上可以垂降100米高度。\n并不能延长腰围。",
	RewardUnlock = 340246,
	ResultText = "小瞳的伸缩腰带解锁了",
	NumCap = 3,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG01",
	StartScene = "SUS_StartScene",
	TeamCondition = {
		{
			Condition = "NeedTagOr",
			Value = 
			{
				560106,
			},
			Desc = "必须是悬疑星的队员",
			Hint = "必须是悬疑星的队员",
		},
	},
	Enemy = {
		{
			Value = 245109,
			Level = 20,
		},
	},
}
ChallengeConfig[ChallengeID.Id5100] =
{
	Id = 5100,
	Name = "装备挑战：磁力钱包",
	Character = 220308,
	Desc = "内置了悬浮材料的钱包，无论如何行动，钱包内的物品都不会洒出来。\n并不是真正的磁铁，不要妄想用吸铁石偷钱包。",
	RewardUnlock = 340248,
	ResultText = "小爱的磁力钱包解锁了",
	NumCap = 3,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG01",
	StartScene = "SUS_StartScene",
	TeamCondition = {
		{
			Condition = "NeedTagOr",
			Value = 
			{
				560106,
			},
			Desc = "必须是悬疑星的队员",
			Hint = "必须是悬疑星的队员",
		},
	},
	Enemy = {
		{
			Value = 245110,
			Level = 20,
		},
	},
}
ChallengeConfig[ChallengeID.Id5101] =
{
	Id = 5101,
	Name = "装备挑战：飞镖钢笔",
	Character = 220309,
	Desc = "为了工作减压而网购的多功能钢笔。编辑长会一边在办公室打电话催稿，一边丢这个飞镖来排解压力。玩着玩着用的时候就没有墨水了。",
	RewardUnlock = 340250,
	ResultText = "编辑长的飞镖钢笔解锁了",
	NumCap = 3,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG01",
	StartScene = "SUS_StartScene",
	TeamCondition = {
		{
			Condition = "NeedTagOr",
			Value = 
			{
				560106,
			},
			Desc = "必须是悬疑星的队员",
			Hint = "必须是悬疑星的队员",
		},
	},
	Enemy = {
		{
			Value = 245111,
			Level = 20,
		},
	},
}
ChallengeConfig[ChallengeID.Id5102] =
{
	Id = 5102,
	Name = "装备挑战：限量版书签",
	Character = 220310,
	Desc = "编辑部发售的限量版书签，只有杂志订阅满10年的读者才有机会获得，然而连载到现在也只有8年。",
	RewardUnlock = 340252,
	ResultText = "读者的限量版书签解锁了",
	NumCap = 3,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG01",
	StartScene = "SUS_StartScene",
	TeamCondition = {
		{
			Condition = "NeedTagOr",
			Value = 
			{
				560106,
			},
			Desc = "必须是悬疑星的队员",
			Hint = "必须是悬疑星的队员",
		},
	},
	Enemy = {
		{
			Value = 245112,
			Level = 20,
		},
	},
}
ChallengeConfig[ChallengeID.Id5103] =
{
	Id = 5103,
	Name = "装备挑战：平安符",
	Character = 220311,
	Desc = "上面写着：“大难不死”。\n因为时间太长，上面写着的内容有些模糊了，那个大原来是太字。",
	RewardUnlock = 340254,
	ResultText = "受害者的平安符解锁了",
	NumCap = 3,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG01",
	StartScene = "SUS_StartScene",
	TeamCondition = {
		{
			Condition = "NeedTagOr",
			Value = 
			{
				560106,
			},
			Desc = "必须是悬疑星的队员",
			Hint = "必须是悬疑星的队员",
		},
	},
	Enemy = {
		{
			Value = 245113,
			Level = 20,
		},
	},
}
ChallengeConfig[ChallengeID.Id5104] =
{
	Id = 5104,
	Name = "装备挑战：律师函",
	Character = 220312,
	Desc = "希望通过警告震慑对方的信件！发放数量直接与每月绩效考核相关，不过发出去后通常只会使对方更生气。",
	RewardUnlock = 340256,
	ResultText = "律师的律师函解锁了",
	NumCap = 3,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG01",
	StartScene = "SUS_StartScene",
	TeamCondition = {
		{
			Condition = "NeedTagOr",
			Value = 
			{
				560106,
			},
			Desc = "必须是悬疑星的队员",
			Hint = "必须是悬疑星的队员",
		},
	},
	Enemy = {
		{
			Value = 245114,
			Level = 20,
		},
	},
}
ChallengeConfig[ChallengeID.Id5105] =
{
	Id = 5105,
	Name = "装备挑战：超大串钥匙",
	Character = 220313,
	Desc = "房东太太别的不多，就是房子多，有时候忘记钥匙是哪个，开门得开个半小时。现在正在考虑把全部门锁换成密码锁。",
	RewardUnlock = 340258,
	ResultText = "房东太太的超大串钥匙解锁了",
	NumCap = 3,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG01",
	StartScene = "SUS_StartScene",
	TeamCondition = {
		{
			Condition = "NeedTagOr",
			Value = 
			{
				560106,
			},
			Desc = "必须是悬疑星的队员",
			Hint = "必须是悬疑星的队员",
		},
	},
	Enemy = {
		{
			Value = 245115,
			Level = 20,
		},
	},
}
ChallengeConfig[ChallengeID.Id5106] =
{
	Id = 5106,
	Name = "装备挑战：杯垫",
	Character = 220314,
	Desc = "确认客人是接头人后，酒保意味深长地将酒杯推过去，并用手指敲了敲杯垫。客人小心翼翼地拿起杯垫，只见反面写道：“你拉链没拉。”",
	RewardUnlock = 340260,
	ResultText = "调酒师的杯垫解锁了",
	NumCap = 3,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG01",
	StartScene = "SUS_StartScene",
	TeamCondition = {
		{
			Condition = "NeedTagOr",
			Value = 
			{
				560106,
			},
			Desc = "必须是悬疑星的队员",
			Hint = "必须是悬疑星的队员",
		},
	},
	Enemy = {
		{
			Value = 245116,
			Level = 20,
		},
	},
}
ChallengeConfig[ChallengeID.Id5107] =
{
	Id = 5107,
	Name = "装备挑战：空投装置",
	Character = 220315,
	Desc = "因为行动舱有些大，博士额外研发了一个空投装置，避免去某些地方过于显眼。目前用来放喝了一半的饮料。",
	RewardUnlock = 340263,
	ResultText = "博士的空投装置解锁了",
	NumCap = 3,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG01",
	StartScene = "SUS_StartScene",
	TeamCondition = {
		{
			Condition = "NeedTagOr",
			Value = 
			{
				560106,
			},
			Desc = "必须是悬疑星的队员",
			Hint = "必须是悬疑星的队员",
		},
	},
	Enemy = {
		{
			Value = 245117,
			Level = 28,
		},
	},
}
ChallengeConfig[ChallengeID.Id5108] =
{
	Id = 5108,
	Name = "装备挑战：防弹背心",
	Character = 220316,
	Desc = "由悬疑星上最好的防弹材料做成，能防御各种子弹，弱点是对猫毛过敏。",
	RewardUnlock = 340266,
	ResultText = "豆豆警官的防弹背心解锁了",
	NumCap = 3,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG01",
	StartScene = "SUS_StartScene",
	TeamCondition = {
		{
			Condition = "NeedTagOr",
			Value = 
			{
				560106,
			},
			Desc = "必须是悬疑星的队员",
			Hint = "必须是悬疑星的队员",
		},
	},
	Enemy = {
		{
			Value = 245118,
			Level = 28,
		},
	},
}
ChallengeConfig[ChallengeID.Id5109] =
{
	Id = 5109,
	Name = "装备挑战：青蛙",
	Character = 220317,
	Desc = "到现在都没有舍得解刨的小青蛙，是法医小时候的好朋友，但它已经快老死了。",
	RewardUnlock = 340269,
	ResultText = "法医的青蛙解锁了",
	NumCap = 3,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG01",
	StartScene = "SUS_StartScene",
	TeamCondition = {
		{
			Condition = "NeedTagOr",
			Value = 
			{
				560106,
			},
			Desc = "必须是悬疑星的队员",
			Hint = "必须是悬疑星的队员",
		},
	},
	Enemy = {
		{
			Value = 245119,
			Level = 28,
		},
	},
}
ChallengeConfig[ChallengeID.Id5110] =
{
	Id = 5110,
	Name = "装备挑战：关键证据",
	Character = 220318,
	Desc = "只要拿出这个，庭上就会一片嘘声，对方就会面如土色。但如果律师在对面，关键证据就会变成假的。",
	RewardUnlock = 340272,
	ResultText = "检察官的关键证据解锁了",
	NumCap = 3,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG01",
	StartScene = "SUS_StartScene",
	TeamCondition = {
		{
			Condition = "NeedTagOr",
			Value = 
			{
				560106,
			},
			Desc = "必须是悬疑星的队员",
			Hint = "必须是悬疑星的队员",
		},
	},
	Enemy = {
		{
			Value = 245120,
			Level = 28,
		},
	},
}
ChallengeConfig[ChallengeID.Id5111] =
{
	Id = 5111,
	Name = "装备挑战：正义天平",
	Character = 220319,
	Desc = "法理与公义，究竟孰轻孰重？每当法官遇到棘手的案件时，就会不停地拨弄这个天平秤，直到它坏掉。",
	RewardUnlock = 340275,
	ResultText = "法官的正义天平解锁了",
	NumCap = 3,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG01",
	StartScene = "SUS_StartScene",
	TeamCondition = {
		{
			Condition = "NeedTagOr",
			Value = 
			{
				560106,
			},
			Desc = "必须是悬疑星的队员",
			Hint = "必须是悬疑星的队员",
		},
	},
	Enemy = {
		{
			Value = 245121,
			Level = 28,
		},
	},
}
ChallengeConfig[ChallengeID.Id5112] =
{
	Id = 5112,
	Name = "装备挑战：放大镜",
	Character = 220320,
	Desc = "现在很少看到侦探本人拿着放大镜四处看来看去的情形了，侦探助理却一直很喜欢放大镜，据说是学画画留下来的习惯。",
	RewardUnlock = 340278,
	ResultText = "侦探助理的放大镜解锁了",
	NumCap = 3,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG01",
	StartScene = "SUS_StartScene",
	TeamCondition = {
		{
			Condition = "NeedTagOr",
			Value = 
			{
				560106,
			},
			Desc = "必须是悬疑星的队员",
			Hint = "必须是悬疑星的队员",
		},
	},
	Enemy = {
		{
			Value = 245122,
			Level = 28,
		},
	},
}
ChallengeConfig[ChallengeID.Id5113] =
{
	Id = 5113,
	Name = "装备挑战：开膛剪",
	Character = 220321,
	Desc = "手术用具中，能用来做武器的东西实在是太多了，因此千万不要惹医生。",
	RewardUnlock = 340281,
	ResultText = "杰克瑞波的开膛剪解锁了",
	NumCap = 3,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG01",
	StartScene = "SUS_StartScene",
	TeamCondition = {
		{
			Condition = "NeedTagOr",
			Value = 
			{
				560106,
			},
			Desc = "必须是悬疑星的队员",
			Hint = "必须是悬疑星的队员",
		},
	},
	Enemy = {
		{
			Value = 245123,
			Level = 36,
		},
	},
}
ChallengeConfig[ChallengeID.Id5114] =
{
	Id = 5114,
	Name = "装备挑战：高出力跑鞋",
	Character = 220322,
	Desc = "博士制造的核动力跑鞋，调整至最大档后，可以一脚把易拉罐踢到外太空去，是没有物理规律可言的可怕设备。",
	RewardUnlock = 340284,
	ResultText = "蓝衣小学生的高出力跑鞋解锁了",
	NumCap = 3,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG01",
	StartScene = "SUS_StartScene",
	TeamCondition = {
		{
			Condition = "NeedTagOr",
			Value = 
			{
				560106,
			},
			Desc = "必须是悬疑星的队员",
			Hint = "必须是悬疑星的队员",
		},
	},
	Enemy = {
		{
			Value = 245124,
			Level = 36,
		},
	},
}
ChallengeConfig[ChallengeID.Id5115] =
{
	Id = 5115,
	Name = "装备挑战：大脑增强装置",
	Character = 220323,
	Desc = "这个增强装置可以使得人脑的活性提高数倍，用在最强大脑上更是如虎添翼，副作用就是会突然犯困",
	RewardUnlock = 340287,
	ResultText = "迈克罗夫特的大脑增强装置解锁了",
	NumCap = 3,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG01",
	StartScene = "SUS_StartScene",
	TeamCondition = {
		{
			Condition = "NeedTagOr",
			Value = 
			{
				560106,
			},
			Desc = "必须是悬疑星的队员",
			Hint = "必须是悬疑星的队员",
		},
	},
	Enemy = {
		{
			Value = 245125,
			Level = 36,
		},
	},
}
ChallengeConfig[ChallengeID.Id5116] =
{
	Id = 5116,
	Name = "装备挑战：百科全书",
	Character = 220324,
	Desc = "只要联网，就能查到任何信息的电子屏幕。不过在某些地方会显示404，此时案件的侦破将陷入绝境。",
	RewardUnlock = 340290,
	ResultText = "大侦探的百科全书解锁了",
	NumCap = 3,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG01",
	StartScene = "SUS_StartScene",
	TeamCondition = {
		{
			Condition = "NeedTagOr",
			Value = 
			{
				560106,
			},
			Desc = "必须是悬疑星的队员",
			Hint = "必须是悬疑星的队员",
		},
	},
	Enemy = {
		{
			Value = 245126,
			Level = 44,
		},
	},
}
ChallengeConfig[ChallengeID.Id5117] =
{
	Id = 5117,
	Name = "装备挑战：大侦探风衣",
	Character = 220324,
	Desc = "作为侦探的基本要素之一是要有型，这就是为什么大部分侦探都有件风衣了，男女都不例外。\n小心骑车时别卷到轮子里。",
	RewardUnlock = 340291,
	ResultText = "大侦探的大侦探风衣解锁了",
	NumCap = 3,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG01",
	StartScene = "SUS_StartScene",
	TeamCondition = {
		{
			Condition = "NeedTagOr",
			Value = 
			{
				560106,
			},
			Desc = "必须是悬疑星的队员",
			Hint = "必须是悬疑星的队员",
		},
	},
	Enemy = {
		{
			Value = 245127,
			Level = 60,
		},
	},
}
ChallengeConfig[ChallengeID.Id5118] =
{
	Id = 5118,
	Name = "装备挑战：变身胸针",
	Character = 220325,
	Desc = "只要滴入目标血液，就可以立刻变身成指定目标的神奇道具，连声音也会自动模仿。",
	RewardUnlock = 340294,
	ResultText = "教授的变身胸针解锁了",
	NumCap = 3,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG01",
	StartScene = "SUS_StartScene",
	TeamCondition = {
		{
			Condition = "NeedTagOr",
			Value = 
			{
				560106,
			},
			Desc = "必须是悬疑星的队员",
			Hint = "必须是悬疑星的队员",
		},
	},
	Enemy = {
		{
			Value = 245128,
			Level = 44,
		},
	},
}
ChallengeConfig[ChallengeID.Id5119] =
{
	Id = 5119,
	Name = "装备挑战：一发倒地枪",
	Character = 220325,
	Desc = "超高浓度麻醉枪，只要被射中，哪怕是史前猛犸巨象也会立刻倒地。",
	RewardUnlock = 340295,
	ResultText = "教授的一发倒地枪解锁了",
	NumCap = 3,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG01",
	StartScene = "SUS_StartScene",
	TeamCondition = {
		{
			Condition = "NeedTagOr",
			Value = 
			{
				560106,
			},
			Desc = "必须是悬疑星的队员",
			Hint = "必须是悬疑星的队员",
		},
	},
	Enemy = {
		{
			Value = 245129,
			Level = 60,
		},
	},
}
ChallengeConfig[ChallengeID.Id5120] =
{
	Id = 5120,
	Name = "装备挑战：初级金币箱",
	Character = 221001,
	Desc = "装有各种素材和人员情报的大箱子，有时会跟垃圾箱搞混，因此里面也会有一些纸屑。",
	RewardUnlock = 340298,
	ResultText = "史莱姆大王的初级金币箱解锁了",
	NumCap = 3,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG01",
	StartScene = "ARENA_StartScene",
	TeamCondition = {
		{
			Condition = "NeedTagOr",
			Value = 
			{
				560110,
			},
			Desc = "必须是星际流民的队员",
			Hint = "必须是星际流民的队员",
		},
	},
	Enemy = {
		{
			Value = 245130,
			Level = 28,
		},
	},
}
ChallengeConfig[ChallengeID.Id5121] =
{
	Id = 5121,
	Name = "装备挑战：中级金币箱",
	Character = 221002,
	Desc = "装有各种素材和人员情报的大箱子，里面有精灵王子在各地收集的宝物，但基本都在星际鉴宝节目中被告知为赝品。",
	RewardUnlock = 340301,
	ResultText = "精灵王子的中级金币箱解锁了",
	NumCap = 3,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG01",
	StartScene = "ARENA_StartScene",
	TeamCondition = {
		{
			Condition = "NeedTagOr",
			Value = 
			{
				560110,
			},
			Desc = "必须是星际流民的队员",
			Hint = "必须是星际流民的队员",
		},
	},
	Enemy = {
		{
			Value = 245131,
			Level = 36,
		},
	},
}
ChallengeConfig[ChallengeID.Id5122] =
{
	Id = 5122,
	Name = "装备挑战：玉璧箱",
	Character = 221003,
	Desc = "装有各种素材和人员情报的豪华箱子，不过里面还有一个装了超大量低档素材的暗格。",
	RewardUnlock = 340304,
	ResultText = "玉璧女王的玉璧箱解锁了",
	NumCap = 3,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG01",
	StartScene = "ARENA_StartScene",
	TeamCondition = {
		{
			Condition = "NeedTagOr",
			Value = 
			{
				560110,
			},
			Desc = "必须是星际流民的队员",
			Hint = "必须是星际流民的队员",
		},
	},
	Enemy = {
		{
			Value = 245132,
			Level = 44,
		},
	},
}
ChallengeConfig[ChallengeID.Id5123] =
{
	Id = 5123,
	Name = "装备挑战：元气充电宝",
	Character = 221003,
	Desc = "能够自制元气电量的强力工具，经常会自制一些元气电池卖给不知情的顾客，从中赚取差价。",
	RewardUnlock = 340305,
	ResultText = "玉璧女王的元气充电宝解锁了",
	NumCap = 3,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG01",
	StartScene = "ARENA_StartScene",
	TeamCondition = {
		{
			Condition = "NeedTagOr",
			Value = 
			{
				560110,
			},
			Desc = "必须是星际流民的队员",
			Hint = "必须是星际流民的队员",
		},
	},
	Enemy = {
		{
			Value = 245133,
			Level = 60,
		},
	},
}
ChallengeConfig[ChallengeID.Id5124] =
{
	Id = 5124,
	Name = "装备挑战：泥土",
	Character = 221004,
	Desc = "酋长随身携带的食物，无论做什么投资都会失败，最后落到吃土果腹的下场。\n别说，他家的土挺好吃的。",
	RewardUnlock = 340308,
	ResultText = "部落酋长的泥土解锁了",
	NumCap = 3,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG01",
	StartScene = "ARENA_StartScene",
	TeamCondition = {
		{
			Condition = "NeedTagOr",
			Value = 
			{
				560110,
			},
			Desc = "必须是星际流民的队员",
			Hint = "必须是星际流民的队员",
		},
	},
	Enemy = {
		{
			Value = 245134,
			Level = 28,
		},
	},
}
ChallengeConfig[ChallengeID.Id5125] =
{
	Id = 5125,
	Name = "装备挑战：种子",
	Character = 221005,
	Desc = "除了重量单位之外，有时也能用字节单位衡量。",
	RewardUnlock = 340310,
	ResultText = "叶姬的种子解锁了",
	NumCap = 3,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG01",
	StartScene = "ARENA_StartScene",
	TeamCondition = {
		{
			Condition = "NeedTagOr",
			Value = 
			{
				560110,
			},
			Desc = "必须是星际流民的队员",
			Hint = "必须是星际流民的队员",
		},
	},
	Enemy = {
		{
			Value = 245135,
			Level = 20,
		},
	},
}
ChallengeConfig[ChallengeID.Id5126] =
{
	Id = 5126,
	Name = "装备挑战：系统公告",
	Character = 221006,
	Desc = "一旦代言的产品遇到技术性故障，就会立刻发布的告文，在抱歉的同时，往往还会送一些玉璧作为补偿，如果不行就再送点。",
	RewardUnlock = 340313,
	ResultText = "桃几小姐的系统公告解锁了",
	NumCap = 3,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG01",
	StartScene = "ARENA_StartScene",
	TeamCondition = {
		{
			Condition = "NeedTagOr",
			Value = 
			{
				560110,
			},
			Desc = "必须是星际流民的队员",
			Hint = "必须是星际流民的队员",
		},
	},
	Enemy = {
		{
			Value = 245136,
			Level = 20,
		},
	},
}
ChallengeConfig[ChallengeID.Id5127] =
{
	Id = 5127,
	Name = "装备挑战：魔鬼焖烧锅",
	Character = 222001,
	Desc = "会把任何食材都焖得稀烂的超高压锅，如果素材本身不够强大，就会被魔鬼焖烧锅焖成汤水。",
	RewardUnlock = 340317,
	ResultText = "黑暗料理大师的魔鬼焖烧锅解锁了",
	NumCap = 3,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG01",
	StartScene = "ARENA_StartScene",
	TeamCondition = {
		{
			Condition = "NeedTagOr",
			Value = 
			{
				560110,
			},
			Desc = "必须是星际流民的队员",
			Hint = "必须是星际流民的队员",
		},
	},
	Enemy = {
		{
			Value = 245137,
			Level = 36,
		},
	},
}
ChallengeConfig[ChallengeID.Id5128] =
{
	Id = 5128,
	Name = "装备挑战：封印手环",
	Character = 222021,
	Desc = "封印了超能少女力量的科技产品，一旦解开，超能少女将释放可怕的力量。",
	RewardUnlock = 340320,
	ResultText = "超能少女的封印手环解锁了",
	NumCap = 3,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG01",
	StartScene = "ARENA_StartScene",
	TeamCondition = {
		{
			Condition = "NeedTagOr",
			Value = 
			{
				560110,
			},
			Desc = "必须是星际流民的队员",
			Hint = "必须是星际流民的队员",
		},
	},
	Enemy = {
		{
			Value = 245138,
			Level = 36,
		},
	},
}
ChallengeConfig[ChallengeID.Id5129] =
{
	Id = 5129,
	Name = "装备挑战：自制刹车装置",
	Character = 222041,
	Desc = "由复合材料制成的手刹棒，载具停不下来时，只要打开车门，用这根棒子插住地面减速，拖行一段距离就能成功刹车了。",
	RewardUnlock = 340323,
	ResultText = "飙车王的自制刹车装置解锁了",
	NumCap = 3,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG01",
	StartScene = "ARENA_StartScene",
	TeamCondition = {
		{
			Condition = "NeedTagOr",
			Value = 
			{
				560110,
			},
			Desc = "必须是星际流民的队员",
			Hint = "必须是星际流民的队员",
		},
	},
	Enemy = {
		{
			Value = 245139,
			Level = 36,
		},
	},
}
ChallengeConfig[ChallengeID.Id5130] =
{
	Id = 5130,
	Name = "装备挑战：破碎的心",
	Character = 222042,
	Desc = "经过复杂手术才取出的破碎的心。代表了百变怪人过去的悲伤经历，不过从此以后，他就开朗多了。",
	RewardUnlock = 340326,
	ResultText = "百变怪人的破碎的心解锁了",
	NumCap = 3,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG01",
	StartScene = "ARENA_StartScene",
	TeamCondition = {
		{
			Condition = "NeedTagOr",
			Value = 
			{
				560110,
			},
			Desc = "必须是星际流民的队员",
			Hint = "必须是星际流民的队员",
		},
	},
	Enemy = {
		{
			Value = 245140,
			Level = 36,
		},
	},
}
ChallengeConfig[ChallengeID.Id5131] =
{
	Id = 5131,
	Name = "装备挑战：雷神之锤",
	Character = 222043,
	Desc = "组织从某个超级英雄手中抢来的古代神话装备，超能铁匠因为第三季度业绩良好，得到了这件奖品。",
	RewardUnlock = 340329,
	ResultText = "超能铁匠的雷神之锤解锁了",
	NumCap = 3,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG01",
	StartScene = "ARENA_StartScene",
	TeamCondition = {
		{
			Condition = "NeedTagOr",
			Value = 
			{
				560110,
			},
			Desc = "必须是星际流民的队员",
			Hint = "必须是星际流民的队员",
		},
	},
	Enemy = {
		{
			Value = 245141,
			Level = 36,
		},
	},
}
ChallengeConfig[ChallengeID.Id5132] =
{
	Id = 5132,
	Name = "装备挑战：黄金烟斗",
	Character = 222044,
	Desc = "仿造第三代大侦探随身物品制作的镀金烟斗，每个细节都丝毫不差，不过暗黑波罗并不喜欢抽烟斗。",
	RewardUnlock = 340332,
	ResultText = "波罗的黄金烟斗解锁了",
	NumCap = 3,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG01",
	StartScene = "ARENA_StartScene",
	TeamCondition = {
		{
			Condition = "NeedTagOr",
			Value = 
			{
				560110,
			},
			Desc = "必须是星际流民的队员",
			Hint = "必须是星际流民的队员",
		},
	},
	Enemy = {
		{
			Value = 245142,
			Level = 36,
		},
	},
}
ChallengeConfig[ChallengeID.Id5133] =
{
	Id = 5133,
	Name = "装备挑战：巨大船锚",
	Character = 222045,
	Desc = "可以随意放大及缩小的超科技船锚，是鲨鱼老大在沉船海沟找到的。不过将其缩放为1/100大小时，鲨鱼老大觉得挥动起来最顺手。",
	RewardUnlock = 340335,
	ResultText = "鲨鱼老大的巨大船锚解锁了",
	NumCap = 3,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG01",
	StartScene = "ARENA_StartScene",
	TeamCondition = {
		{
			Condition = "NeedTagOr",
			Value = 
			{
				560110,
			},
			Desc = "必须是星际流民的队员",
			Hint = "必须是星际流民的队员",
		},
	},
	Enemy = {
		{
			Value = 245143,
			Level = 36,
		},
	},
}
ChallengeConfig[ChallengeID.Id5134] =
{
	Id = 5134,
	Name = "装备挑战：瓶中船",
	Character = 222046,
	Desc = "因违法捕捞而被海洋星扣押的黑牡蛎号风帆船，通过质效重组技术被封存在了玻璃瓶中，解禁时间是一千二百年。",
	RewardUnlock = 340338,
	ResultText = "罗曼船长的瓶中船解锁了",
	NumCap = 3,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG01",
	StartScene = "ARENA_StartScene",
	TeamCondition = {
		{
			Condition = "NeedTagOr",
			Value = 
			{
				560110,
			},
			Desc = "必须是星际流民的队员",
			Hint = "必须是星际流民的队员",
		},
	},
	Enemy = {
		{
			Value = 245144,
			Level = 36,
		},
	},
}
ChallengeConfig[ChallengeID.Id5135] =
{
	Id = 5135,
	Name = "装备挑战：古老魔戒",
	Character = 222047,
	Desc = "伯爵世代相传的魔法戒指，镶嵌着不像是来自这个世界的宝石，听说可以用来打开特别地区的大门。",
	RewardUnlock = 340341,
	ResultText = "“伯爵”的古老魔戒解锁了",
	NumCap = 3,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG01",
	StartScene = "ARENA_StartScene",
	TeamCondition = {
		{
			Condition = "NeedTagOr",
			Value = 
			{
				560110,
			},
			Desc = "必须是星际流民的队员",
			Hint = "必须是星际流民的队员",
		},
	},
	Enemy = {
		{
			Value = 245145,
			Level = 36,
		},
	},
}
ChallengeConfig[ChallengeID.Id5136] =
{
	Id = 5136,
	Name = "装备挑战：反物质手枪",
	Character = 222048,
	Desc = "“博士”费了不少心血，使用了自然界中根本不村在的粒子的反状态物制成的高科技手枪，暂时还不能产生湮灭反应。",
	RewardUnlock = 340344,
	ResultText = "“博士”的反物质手枪解锁了",
	NumCap = 3,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG01",
	StartScene = "ARENA_StartScene",
	TeamCondition = {
		{
			Condition = "NeedTagOr",
			Value = 
			{
				560110,
			},
			Desc = "必须是星际流民的队员",
			Hint = "必须是星际流民的队员",
		},
	},
	Enemy = {
		{
			Value = 245146,
			Level = 36,
		},
	},
}
ChallengeConfig[ChallengeID.Id5137] =
{
	Id = 5137,
	Name = "装备挑战：动力心脏",
	Character = 222049,
	Desc = "使用新能源制作的超级心脏，能够源源不绝地为黑客剑士产生能量。",
	RewardUnlock = 340347,
	ResultText = "黑客剑士的动力心脏解锁了",
	NumCap = 3,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG01",
	StartScene = "ARENA_StartScene",
	TeamCondition = {
		{
			Condition = "NeedTagOr",
			Value = 
			{
				560110,
			},
			Desc = "必须是星际流民的队员",
			Hint = "必须是星际流民的队员",
		},
	},
	Enemy = {
		{
			Value = 245147,
			Level = 44,
		},
	},
}
ChallengeConfig[ChallengeID.Id5138] =
{
	Id = 5138,
	Name = "装备挑战：火之核心",
	Character = 222049,
	Desc = "散落在星系之中的元素核心，能够为持有者提供强大的元素加持。",
	RewardUnlock = 340348,
	ResultText = "黑客剑士的火之核心解锁了",
	NumCap = 3,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG01",
	StartScene = "ARENA_StartScene",
	TeamCondition = {
		{
			Condition = "NeedTagOr",
			Value = 
			{
				560110,
			},
			Desc = "必须是星际流民的队员",
			Hint = "必须是星际流民的队员",
		},
	},
	Enemy = {
		{
			Value = 245148,
			Level = 60,
		},
	},
}
ChallengeConfig[ChallengeID.Id5139] =
{
	Id = 5139,
	Name = "装备挑战：封魔符",
	Character = 222050,
	Desc = "书写了封魔文的黄符，贴在魔物的额头后，魔物就只能听命于你了。",
	RewardUnlock = 340351,
	ResultText = "苍青驱魔师的封魔符解锁了",
	NumCap = 3,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG01",
	StartScene = "ARENA_StartScene",
	TeamCondition = {
		{
			Condition = "NeedTagOr",
			Value = 
			{
				560110,
			},
			Desc = "必须是星际流民的队员",
			Hint = "必须是星际流民的队员",
		},
	},
	Enemy = {
		{
			Value = 245149,
			Level = 44,
		},
	},
}
ChallengeConfig[ChallengeID.Id5140] =
{
	Id = 5140,
	Name = "装备挑战：镇魔铃",
	Character = 222050,
	Desc = "驱魔师的终极武器，需要以自己的血作为媒介才能激活，专门用来封印大黑天级的魔物。",
	RewardUnlock = 340352,
	ResultText = "苍青驱魔师的镇魔铃解锁了",
	NumCap = 3,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG01",
	StartScene = "ARENA_StartScene",
	TeamCondition = {
		{
			Condition = "NeedTagOr",
			Value = 
			{
				560110,
			},
			Desc = "必须是星际流民的队员",
			Hint = "必须是星际流民的队员",
		},
	},
	Enemy = {
		{
			Value = 245150,
			Level = 60,
		},
	},
}
ChallengeConfig[ChallengeID.Id5141] =
{
	Id = 5141,
	Name = "装备挑战：神圣法典",
	Character = 223001,
	Desc = "由至高庭订立的神圣法典，规范了神职人员的一切行为。\n喉咙有痰只能咽下去噢！",
	RewardUnlock = 340355,
	ResultText = "圣骑士的神圣法典解锁了",
	NumCap = 3,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG01",
	StartScene = "RPG_StartScene",
	TeamCondition = {
		{
			Condition = "NeedTagOr",
			Value = 
			{
				560103,
			},
			Desc = "必须是冒险星的队员",
			Hint = "必须是冒险星的队员",
		},
	},
	Enemy = {
		{
			Value = 245151,
			Level = 36,
		},
	},
}
ChallengeConfig[ChallengeID.Id5142] =
{
	Id = 5142,
	Name = "装备挑战：战吼喇叭",
	Character = 223002,
	Desc = "很多人好奇为什么野蛮人的呐喊如此震撼，其实是因为他们有特制的超级扩音大声公。",
	RewardUnlock = 340358,
	ResultText = "野蛮人的战吼喇叭解锁了",
	NumCap = 3,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG01",
	StartScene = "RPG_StartScene",
	TeamCondition = {
		{
			Condition = "NeedTagOr",
			Value = 
			{
				560103,
			},
			Desc = "必须是冒险星的队员",
			Hint = "必须是冒险星的队员",
		},
	},
	Enemy = {
		{
			Value = 245152,
			Level = 36,
		},
	},
}
ChallengeConfig[ChallengeID.Id5143] =
{
	Id = 5143,
	Name = "装备挑战：暗影斗篷",
	Character = 223003,
	Desc = "盗贼从粗心的精灵那里偷来的魔法斗篷，披着它就能随意进入别人家里盗窃了",
	RewardUnlock = 340361,
	ResultText = "盗贼的暗影斗篷解锁了",
	NumCap = 3,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG01",
	StartScene = "RPG_StartScene",
	TeamCondition = {
		{
			Condition = "NeedTagOr",
			Value = 
			{
				560103,
			},
			Desc = "必须是冒险星的队员",
			Hint = "必须是冒险星的队员",
		},
	},
	Enemy = {
		{
			Value = 245153,
			Level = 36,
		},
	},
}
ChallengeConfig[ChallengeID.Id5144] =
{
	Id = 5144,
	Name = "装备挑战：魔律铃",
	Character = 223004,
	Desc = "流传在这个世界的魔法铃铛的一种。当舞娘起舞时，其受到晃动而发出的音律会让人不自觉地沉迷于舞娘的身姿。",
	RewardUnlock = 340364,
	ResultText = "舞娘的魔律铃解锁了",
	NumCap = 3,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG01",
	StartScene = "RPG_StartScene",
	TeamCondition = {
		{
			Condition = "NeedTagOr",
			Value = 
			{
				560103,
			},
			Desc = "必须是冒险星的队员",
			Hint = "必须是冒险星的队员",
		},
	},
	Enemy = {
		{
			Value = 245154,
			Level = 36,
		},
	},
}
ChallengeConfig[ChallengeID.Id5145] =
{
	Id = 5145,
	Name = "装备挑战：万能书",
	Character = 223005,
	Desc = "只有得到皇家学位证书的学者才能获得的全知之书，使用古老文字记录了宇宙奥秘，学者目前也没有全部看懂。",
	RewardUnlock = 340367,
	ResultText = "学者的万能书解锁了",
	NumCap = 3,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG01",
	StartScene = "RPG_StartScene",
	TeamCondition = {
		{
			Condition = "NeedTagOr",
			Value = 
			{
				560103,
			},
			Desc = "必须是冒险星的队员",
			Hint = "必须是冒险星的队员",
		},
	},
	Enemy = {
		{
			Value = 245155,
			Level = 36,
		},
	},
}
ChallengeConfig[ChallengeID.Id5146] =
{
	Id = 5146,
	Name = "装备挑战：万灵解毒草",
	Character = 223006,
	Desc = "每个药师都有自己的万灵解毒药配方，当药师因意外中毒时，这颗灵丹往往可以起到救命的功效。",
	RewardUnlock = 340370,
	ResultText = "药师的万灵解毒草解锁了",
	NumCap = 3,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG01",
	StartScene = "RPG_StartScene",
	TeamCondition = {
		{
			Condition = "NeedTagOr",
			Value = 
			{
				560103,
			},
			Desc = "必须是冒险星的队员",
			Hint = "必须是冒险星的队员",
		},
	},
	Enemy = {
		{
			Value = 245156,
			Level = 36,
		},
	},
}
ChallengeConfig[ChallengeID.Id5147] =
{
	Id = 5147,
	Name = "装备挑战：新秀奖杯",
	Character = 220426,
	Desc = "出道时获得的偶像新秀奖杯，这么多年一直好好保存着，看到它全身就会充满力量。",
	RewardUnlock = 340373,
	ResultText = "白鲨牙牙的新秀奖杯解锁了",
	NumCap = 3,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG01",
	StartScene = "SEA_StartScene",
	TeamCondition = {
		{
			Condition = "NeedTagOr",
			Value = 
			{
				560107,
			},
			Desc = "必须是海洋星的队员",
			Hint = "必须是海洋星的队员",
		},
	},
	Enemy = {
		{
			Value = 245157,
			Level = 36,
		},
	},
}
ChallengeConfig[ChallengeID.Id5148] =
{
	Id = 5148,
	Name = "装备挑战：特制玻璃杯",
	Character = 220401,
	Desc = "为了控制音量，特意买来练习的玻璃杯，口号是“绝对不能碎”！",
	RewardUnlock = 340382,
	ResultText = "海豚凛的特制玻璃杯解锁了",
	NumCap = 3,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG01",
	StartScene = "SEA_StartScene",
	TeamCondition = {
		{
			Condition = "NeedTagOr",
			Value = 
			{
				560107,
			},
			Desc = "必须是海洋星的队员",
			Hint = "必须是海洋星的队员",
		},
	},
	Enemy = {
		{
			Value = 245158,
			Level = 28,
		},
	},
}
ChallengeConfig[ChallengeID.Id5149] =
{
	Id = 5149,
	Name = "装备挑战：鹅卵石",
	Character = 220407,
	Desc = "遇到强盗打劫时，珍会迅速扔出一枚鹅卵石：“看，珍珠！”",
	RewardUnlock = 340385,
	ResultText = "扇贝珍的鹅卵石解锁了",
	NumCap = 3,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG01",
	StartScene = "SEA_StartScene",
	TeamCondition = {
		{
			Condition = "NeedTagOr",
			Value = 
			{
				560107,
			},
			Desc = "必须是海洋星的队员",
			Hint = "必须是海洋星的队员",
		},
	},
	Enemy = {
		{
			Value = 245159,
			Level = 28,
		},
	},
}
ChallengeConfig[ChallengeID.Id5150] =
{
	Id = 5150,
	Name = "装备挑战：男装清单",
	Character = 220408,
	Desc = "清单上记录着将要购买的男装，几乎都是当下最流行的款式。",
	RewardUnlock = 340388,
	ResultText = "海螺美莎的男装清单解锁了",
	NumCap = 3,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG01",
	StartScene = "SEA_StartScene",
	TeamCondition = {
		{
			Condition = "NeedTagOr",
			Value = 
			{
				560107,
			},
			Desc = "必须是海洋星的队员",
			Hint = "必须是海洋星的队员",
		},
	},
	Enemy = {
		{
			Value = 245160,
			Level = 28,
		},
	},
}
ChallengeConfig[ChallengeID.Id5151] =
{
	Id = 5151,
	Name = "装备挑战：海贝手镯",
	Character = 220428,
	Desc = "从记事起就佩戴上的手镯，据说可以带来好运。",
	RewardUnlock = 340379,
	ResultText = "琵琶映冬的海贝手镯解锁了",
	NumCap = 3,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG01",
	StartScene = "SEA_StartScene",
	TeamCondition = {
		{
			Condition = "NeedTagOr",
			Value = 
			{
				560107,
			},
			Desc = "必须是海洋星的队员",
			Hint = "必须是海洋星的队员",
		},
	},
	Enemy = {
		{
			Value = 245161,
			Level = 36,
		},
	},
}
ChallengeConfig[ChallengeID.Id5152] =
{
	Id = 5152,
	Name = "装备挑战：《笑林广sea》",
	Character = 220427,
	Desc = "在大家生气的时候，讲笑话是缓解气氛最好的办法，因此依伶买来《笑林广sea》，要求自己熟读并背诵全书。",
	RewardUnlock = 340376,
	ResultText = "鲸鲨依伶的《笑林广sea》解锁了",
	NumCap = 3,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG01",
	StartScene = "SEA_StartScene",
	TeamCondition = {
		{
			Condition = "NeedTagOr",
			Value = 
			{
				560107,
			},
			Desc = "必须是海洋星的队员",
			Hint = "必须是海洋星的队员",
		},
	},
	Enemy = {
		{
			Value = 245162,
			Level = 36,
		},
	},
}
ChallengeConfig[ChallengeID.Id5153] =
{
	Id = 5153,
	Name = "装备挑战：信号发射器",
	Character = 220404,
	Desc = "离开家乡时，家人们送给自己的唯一一件礼物，据说启动发射器，即便身在远方，也可以和他们说话。",
	RewardUnlock = 340629,
	ResultText = "鲎椰子的信号发射器解锁了",
	NumCap = 3,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG01",
	StartScene = "SEA_StartScene",
	TeamCondition = {
		{
			Condition = "NeedTagOr",
			Value = 
			{
				560107,
			},
			Desc = "必须是海洋星的队员",
			Hint = "必须是海洋星的队员",
		},
	},
	Enemy = {
		{
			Value = 245163,
			Level = 28,
		},
	},
}
ChallengeConfig[ChallengeID.Id5154] =
{
	Id = 5154,
	Name = "装备挑战：钱包",
	Character = 220409,
	Desc = "因为“有钳”，所以自称是一只“有钱蟹”，并且为了让有钱这一设定深入人心，不管在哪里出现，都要拿出厚厚的钱包。",
	RewardUnlock = 340630,
	ResultText = "蟹香菜的钱包解锁了",
	NumCap = 3,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG01",
	StartScene = "SEA_StartScene",
	TeamCondition = {
		{
			Condition = "NeedTagOr",
			Value = 
			{
				560107,
			},
			Desc = "必须是海洋星的队员",
			Hint = "必须是海洋星的队员",
		},
	},
	Enemy = {
		{
			Value = 245164,
			Level = 28,
		},
	},
}
ChallengeConfig[ChallengeID.Id5155] =
{
	Id = 5155,
	Name = "装备挑战：电线保护套",
	Character = 220410,
	Desc = "曾经失手夹断了键盘的电线，因此无法上台演出。为了避免悲剧再次发生，每次演出都会自带保护套。",
	RewardUnlock = 340631,
	ResultText = "虾伊洛的电线保护套解锁了",
	NumCap = 3,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG01",
	StartScene = "SEA_StartScene",
	TeamCondition = {
		{
			Condition = "NeedTagOr",
			Value = 
			{
				560107,
			},
			Desc = "必须是海洋星的队员",
			Hint = "必须是海洋星的队员",
		},
	},
	Enemy = {
		{
			Value = 245165,
			Level = 28,
		},
	},
}
ChallengeConfig[ChallengeID.Id5156] =
{
	Id = 5156,
	Name = "装备挑战：笔刷",
	Character = 220411,
	Desc = "当变成奇怪的颜色时，幻然只好使用笔刷，把自己涂抹成另一种颜色。",
	RewardUnlock = 340632,
	ResultText = "海兔幻然的笔刷解锁了",
	NumCap = 3,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG01",
	StartScene = "SEA_StartScene",
	TeamCondition = {
		{
			Condition = "NeedTagOr",
			Value = 
			{
				560107,
			},
			Desc = "必须是海洋星的队员",
			Hint = "必须是海洋星的队员",
		},
	},
	Enemy = {
		{
			Value = 245166,
			Level = 28,
		},
	},
}
ChallengeConfig[ChallengeID.Id5157] =
{
	Id = 5157,
	Name = "装备挑战：黑色披风",
	Character = 220412,
	Desc = "因为红白相间的醒目纹理，在海洋中能被狗仔第一时间发现，为了躲避他们，特意购买了一件黑色的披风遮挡自己。",
	RewardUnlock = 340633,
	ResultText = "小丑遥的黑色披风解锁了",
	NumCap = 3,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG01",
	StartScene = "SEA_StartScene",
	TeamCondition = {
		{
			Condition = "NeedTagOr",
			Value = 
			{
				560107,
			},
			Desc = "必须是海洋星的队员",
			Hint = "必须是海洋星的队员",
		},
	},
	Enemy = {
		{
			Value = 245167,
			Level = 28,
		},
	},
}
ChallengeConfig[ChallengeID.Id5158] =
{
	Id = 5158,
	Name = "装备挑战：降噪耳机",
	Character = 220413,
	Desc = "戴上耳机，听不见外界的声音，独坐的小茨就不会被任何事打扰。",
	RewardUnlock = 340634,
	ResultText = "海胆小茨的降噪耳机解锁了",
	NumCap = 3,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG01",
	StartScene = "SEA_StartScene",
	TeamCondition = {
		{
			Condition = "NeedTagOr",
			Value = 
			{
				560107,
			},
			Desc = "必须是海洋星的队员",
			Hint = "必须是海洋星的队员",
		},
	},
	Enemy = {
		{
			Value = 245168,
			Level = 28,
		},
	},
}
ChallengeConfig[ChallengeID.Id5159] =
{
	Id = 5159,
	Name = "装备挑战：FLAG",
	Character = 220406,
	Desc = "插旗就是生活最大的乐趣！如果flag倒了也没关系，换一个就好了！",
	RewardUnlock = 340403,
	ResultText = "鱼不翻的FLAG解锁了",
	NumCap = 3,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG01",
	StartScene = "SEA_StartScene",
	TeamCondition = {
		{
			Condition = "NeedTagOr",
			Value = 
			{
				560107,
			},
			Desc = "必须是海洋星的队员",
			Hint = "必须是海洋星的队员",
		},
	},
	Enemy = {
		{
			Value = 245169,
			Level = 28,
		},
	},
}
ChallengeConfig[ChallengeID.Id5160] =
{
	Id = 5160,
	Name = "装备挑战：尖头皮鞋",
	Character = 220414,
	Desc = "虽然不建议穿着皮鞋运动，但在凉风看来，这是TA最喜欢的一双舞鞋。",
	RewardUnlock = 340406,
	ResultText = "蝠鲼凉风的尖头皮鞋解锁了",
	NumCap = 3,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG01",
	StartScene = "SEA_StartScene",
	TeamCondition = {
		{
			Condition = "NeedTagOr",
			Value = 
			{
				560107,
			},
			Desc = "必须是海洋星的队员",
			Hint = "必须是海洋星的队员",
		},
	},
	Enemy = {
		{
			Value = 245170,
			Level = 28,
		},
	},
}
ChallengeConfig[ChallengeID.Id5161] =
{
	Id = 5161,
	Name = "装备挑战：神秘的袋子",
	Character = 220415,
	Desc = "据说当小孩不听话的时候，希波就会把TA装进这个神秘的袋子里。",
	RewardUnlock = 340409,
	ResultText = "海马希波的神秘的袋子解锁了",
	NumCap = 3,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG01",
	StartScene = "SEA_StartScene",
	TeamCondition = {
		{
			Condition = "NeedTagOr",
			Value = 
			{
				560107,
			},
			Desc = "必须是海洋星的队员",
			Hint = "必须是海洋星的队员",
		},
	},
	Enemy = {
		{
			Value = 245171,
			Level = 28,
		},
	},
}
ChallengeConfig[ChallengeID.Id5162] =
{
	Id = 5162,
	Name = "装备挑战：瘦身皮带",
	Character = 220405,
	Desc = "如果带上瘦身皮带，就不会动不动变胖了吧？",
	RewardUnlock = 340412,
	ResultText = "刺豚茉白的瘦身皮带解锁了",
	NumCap = 3,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG01",
	StartScene = "SEA_StartScene",
	TeamCondition = {
		{
			Condition = "NeedTagOr",
			Value = 
			{
				560107,
			},
			Desc = "必须是海洋星的队员",
			Hint = "必须是海洋星的队员",
		},
	},
	Enemy = {
		{
			Value = 245172,
			Level = 28,
		},
	},
}
ChallengeConfig[ChallengeID.Id5163] =
{
	Id = 5163,
	Name = "装备挑战：自制学生证",
	Character = 220416,
	Desc = "由于不羁的发型，上学时经常被门卫以不符合学生规范为由拦在门外，于是自己做了一本学生证，可以达到以假乱真的地步。",
	RewardUnlock = 340415,
	ResultText = "海葵彩雅的自制学生证解锁了",
	NumCap = 3,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG01",
	StartScene = "SEA_StartScene",
	TeamCondition = {
		{
			Condition = "NeedTagOr",
			Value = 
			{
				560107,
			},
			Desc = "必须是海洋星的队员",
			Hint = "必须是海洋星的队员",
		},
	},
	Enemy = {
		{
			Value = 245173,
			Level = 28,
		},
	},
}
ChallengeConfig[ChallengeID.Id5164] =
{
	Id = 5164,
	Name = "装备挑战：信号增强器",
	Character = 220417,
	Desc = "屡屡受到“你挡着我信号了”的指控，因此被迫随身携带信号增强器，似乎让周围的人安心了许多。",
	RewardUnlock = 340418,
	ResultText = "斗鱼希的信号增强器解锁了",
	NumCap = 3,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG01",
	StartScene = "SEA_StartScene",
	TeamCondition = {
		{
			Condition = "NeedTagOr",
			Value = 
			{
				560107,
			},
			Desc = "必须是海洋星的队员",
			Hint = "必须是海洋星的队员",
		},
	},
	Enemy = {
		{
			Value = 245174,
			Level = 28,
		},
	},
}
ChallengeConfig[ChallengeID.Id5165] =
{
	Id = 5165,
	Name = "装备挑战：墨色水枪",
	Character = 220402,
	Desc = "墨最喜欢的玩具，因为被禁止参加喷水节，只好自己用它在家喷个痛快。",
	RewardUnlock = 340421,
	ResultText = "乌贼墨的墨色水枪解锁了",
	NumCap = 3,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG01",
	StartScene = "SEA_StartScene",
	TeamCondition = {
		{
			Condition = "NeedTagOr",
			Value = 
			{
				560107,
			},
			Desc = "必须是海洋星的队员",
			Hint = "必须是海洋星的队员",
		},
	},
	Enemy = {
		{
			Value = 245175,
			Level = 28,
		},
	},
}
ChallengeConfig[ChallengeID.Id5166] =
{
	Id = 5166,
	Name = "装备挑战：环保保证书",
	Character = 220418,
	Desc = "因为惊慌失措时喷射了几次内脏，被环保局的人勒令写下了一份保证书。",
	RewardUnlock = 340424,
	ResultText = "海参橘的环保保证书解锁了",
	NumCap = 3,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG01",
	StartScene = "SEA_StartScene",
	TeamCondition = {
		{
			Condition = "NeedTagOr",
			Value = 
			{
				560107,
			},
			Desc = "必须是海洋星的队员",
			Hint = "必须是海洋星的队员",
		},
	},
	Enemy = {
		{
			Value = 245176,
			Level = 28,
		},
	},
}
ChallengeConfig[ChallengeID.Id5167] =
{
	Id = 5167,
	Name = "装备挑战：牙齿矫正器",
	Character = 220419,
	Desc = "由于牙齿凌乱，被经纪公司勒令整牙，只好天天戴上矫正器。",
	RewardUnlock = 340427,
	ResultText = "鮟鱇明的牙齿矫正器解锁了",
	NumCap = 3,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG01",
	StartScene = "SEA_StartScene",
	TeamCondition = {
		{
			Condition = "NeedTagOr",
			Value = 
			{
				560107,
			},
			Desc = "必须是海洋星的队员",
			Hint = "必须是海洋星的队员",
		},
	},
	Enemy = {
		{
			Value = 245177,
			Level = 28,
		},
	},
}
ChallengeConfig[ChallengeID.Id5168] =
{
	Id = 5168,
	Name = "装备挑战：代抽小广告",
	Character = 220420,
	Desc = "作为一个抽卡欧皇，海豹彩开展了代抽业务，据说不夜城的人已经听闻此事，正在调查TA的踪迹。",
	RewardUnlock = 340430,
	ResultText = "海豹彩的代抽小广告解锁了",
	NumCap = 3,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG01",
	StartScene = "SEA_StartScene",
	TeamCondition = {
		{
			Condition = "NeedTagOr",
			Value = 
			{
				560107,
			},
			Desc = "必须是海洋星的队员",
			Hint = "必须是海洋星的队员",
		},
	},
	Enemy = {
		{
			Value = 245178,
			Level = 36,
		},
	},
}
ChallengeConfig[ChallengeID.Id5169] =
{
	Id = 5169,
	Name = "装备挑战：发电机",
	Character = 220403,
	Desc = "通过伊俄自己发电才能向其他电器发电的发电器。",
	RewardUnlock = 340433,
	ResultText = "电鳗伊俄的发电机解锁了",
	NumCap = 3,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG01",
	StartScene = "SEA_StartScene",
	TeamCondition = {
		{
			Condition = "NeedTagOr",
			Value = 
			{
				560107,
			},
			Desc = "必须是海洋星的队员",
			Hint = "必须是海洋星的队员",
		},
	},
	Enemy = {
		{
			Value = 245179,
			Level = 36,
		},
	},
}
ChallengeConfig[ChallengeID.Id5170] =
{
	Id = 5170,
	Name = "装备挑战：金色手套",
	Character = 220421,
	Desc = "粉丝握手会时的必备之物，只有戴着它，和粉丝握手时才会安心。",
	RewardUnlock = 340436,
	ResultText = "黄金纱纱的金色手套解锁了",
	NumCap = 3,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG01",
	StartScene = "SEA_StartScene",
	TeamCondition = {
		{
			Condition = "NeedTagOr",
			Value = 
			{
				560107,
			},
			Desc = "必须是海洋星的队员",
			Hint = "必须是海洋星的队员",
		},
	},
	Enemy = {
		{
			Value = 245180,
			Level = 36,
		},
	},
}
ChallengeConfig[ChallengeID.Id5171] =
{
	Id = 5171,
	Name = "装备挑战：旧相册",
	Character = 220422,
	Desc = "珍藏的旧相册，不轻易向别人展示，直到有一次，朋友无意中看到了几十年前的丝丝，竟然……",
	RewardUnlock = 340439,
	ResultText = "灯塔丝丝的旧相册解锁了",
	NumCap = 3,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG01",
	StartScene = "SEA_StartScene",
	TeamCondition = {
		{
			Condition = "NeedTagOr",
			Value = 
			{
				560107,
			},
			Desc = "必须是海洋星的队员",
			Hint = "必须是海洋星的队员",
		},
	},
	Enemy = {
		{
			Value = 245181,
			Level = 36,
		},
	},
}
ChallengeConfig[ChallengeID.Id5172] =
{
	Id = 5172,
	Name = "装备挑战：吸盘鞋",
	Character = 220423,
	Desc = "吸力异常强大的鞋子，当寻沙想躺下休息时，没有任何人能拖动TA.",
	RewardUnlock = 340442,
	ResultText = "海星寻沙的吸盘鞋解锁了",
	NumCap = 3,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG01",
	StartScene = "SEA_StartScene",
	TeamCondition = {
		{
			Condition = "NeedTagOr",
			Value = 
			{
				560107,
			},
			Desc = "必须是海洋星的队员",
			Hint = "必须是海洋星的队员",
		},
	},
	Enemy = {
		{
			Value = 245182,
			Level = 36,
		},
	},
}
ChallengeConfig[ChallengeID.Id5173] =
{
	Id = 5173,
	Name = "装备挑战：六棵海草",
	Character = 220424,
	Desc = "为什么舞妍这么聪明？当然是因为TA从小就喝“六棵海草”啦！",
	RewardUnlock = 340445,
	ResultText = "章鱼舞妍的六棵海草解锁了",
	NumCap = 3,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG01",
	StartScene = "SEA_StartScene",
	TeamCondition = {
		{
			Condition = "NeedTagOr",
			Value = 
			{
				560107,
			},
			Desc = "必须是海洋星的队员",
			Hint = "必须是海洋星的队员",
		},
	},
	Enemy = {
		{
			Value = 245183,
			Level = 36,
		},
	},
}
ChallengeConfig[ChallengeID.Id5174] =
{
	Id = 5174,
	Name = "装备挑战：珊瑚笛",
	Character = 220425,
	Desc = "神奇的笛子，只要吹响就可以召唤海蛇，海蛇们把拥有珊瑚笛的人看做神明，完全不觉得自己被控制了。",
	RewardUnlock = 340448,
	ResultText = "海蛇莱斯莉的珊瑚笛解锁了",
	NumCap = 3,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG01",
	StartScene = "SEA_StartScene",
	TeamCondition = {
		{
			Condition = "NeedTagOr",
			Value = 
			{
				560107,
			},
			Desc = "必须是海洋星的队员",
			Hint = "必须是海洋星的队员",
		},
	},
	Enemy = {
		{
			Value = 245184,
			Level = 36,
		},
	},
}
ChallengeConfig[ChallengeID.Id5175] =
{
	Id = 5175,
	Name = "装备挑战：银行支票",
	Character = 220429,
	Desc = "据说珊瑚家族和所有银行都有密切的联系，因此购物时只用开一张发票就好了。",
	RewardUnlock = 340451,
	ResultText = "珊瑚阿卡的银行支票解锁了",
	NumCap = 3,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG01",
	StartScene = "SEA_StartScene",
	TeamCondition = {
		{
			Condition = "NeedTagOr",
			Value = 
			{
				560107,
			},
			Desc = "必须是海洋星的队员",
			Hint = "必须是海洋星的队员",
		},
	},
	Enemy = {
		{
			Value = 245185,
			Level = 44,
		},
	},
}
ChallengeConfig[ChallengeID.Id5176] =
{
	Id = 5176,
	Name = "装备挑战：珊瑚勋章",
	Character = 220429,
	Desc = "家族的勋章，代表家族至高无上的荣耀。",
	RewardUnlock = 340452,
	ResultText = "珊瑚阿卡的珊瑚勋章解锁了",
	NumCap = 3,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG01",
	StartScene = "SEA_StartScene",
	TeamCondition = {
		{
			Condition = "NeedTagOr",
			Value = 
			{
				560107,
			},
			Desc = "必须是海洋星的队员",
			Hint = "必须是海洋星的队员",
		},
	},
	Enemy = {
		{
			Value = 245186,
			Level = 60,
		},
	},
}
ChallengeConfig[ChallengeID.Id5177] =
{
	Id = 5177,
	Name = "装备挑战：鲸嗓子喉宝",
	Character = 220430,
	Desc = "因为总是唱歌，声带难免有所损伤，只有靠吃药来缓解嗓子的疼痛。",
	RewardUnlock = 340455,
	ResultText = "虎鲸京的鲸嗓子喉宝解锁了",
	NumCap = 3,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG01",
	StartScene = "SEA_StartScene",
	TeamCondition = {
		{
			Condition = "NeedTagOr",
			Value = 
			{
				560107,
			},
			Desc = "必须是海洋星的队员",
			Hint = "必须是海洋星的队员",
		},
	},
	Enemy = {
		{
			Value = 245187,
			Level = 44,
		},
	},
}
ChallengeConfig[ChallengeID.Id5178] =
{
	Id = 5178,
	Name = "装备挑战：过去的CD",
	Character = 220430,
	Desc = "小时候和朋友一起录的歌，至今都被完好保存着。",
	RewardUnlock = 340456,
	ResultText = "虎鲸京的过去的CD解锁了",
	NumCap = 3,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG01",
	StartScene = "SEA_StartScene",
	TeamCondition = {
		{
			Condition = "NeedTagOr",
			Value = 
			{
				560107,
			},
			Desc = "必须是海洋星的队员",
			Hint = "必须是海洋星的队员",
		},
	},
	Enemy = {
		{
			Value = 245188,
			Level = 60,
		},
	},
}
ChallengeConfig[ChallengeID.Id5179] =
{
	Id = 5179,
	Name = "装备挑战：残疾证",
	Character = 223021,
	Desc = "流浪在外，铁拐李为了方便才在联邦政府办理的相关证明，凭此证，坐宇宙巴士可以优先坐座位，排队时也可以走快速通道。",
	RewardUnlock = 340459,
	ResultText = "铁拐李的残疾证解锁了",
	NumCap = 3,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG01",
	StartScene = "ARENA_StartScene",
	TeamCondition = {
		{
			Condition = "NeedTagOr",
			Value = 
			{
				560110,
			},
			Desc = "必须是星际流民的队员",
			Hint = "必须是星际流民的队员",
		},
	},
	Enemy = {
		{
			Value = 245189,
			Level = 36,
		},
	},
}
ChallengeConfig[ChallengeID.Id5180] =
{
	Id = 5180,
	Name = "装备挑战：飘带",
	Character = 223022,
	Desc = "仙风傲然的光丝飘带，事实上是免水洗的高效吸水汗巾，可以瞬间吸走汗渍，保持干爽。",
	RewardUnlock = 340462,
	ResultText = "汉钟离的飘带解锁了",
	NumCap = 3,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG01",
	StartScene = "ARENA_StartScene",
	TeamCondition = {
		{
			Condition = "NeedTagOr",
			Value = 
			{
				560110,
			},
			Desc = "必须是星际流民的队员",
			Hint = "必须是星际流民的队员",
		},
	},
	Enemy = {
		{
			Value = 245190,
			Level = 36,
		},
	},
}
ChallengeConfig[ChallengeID.Id5181] =
{
	Id = 5181,
	Name = "装备挑战：后视镜",
	Character = 223023,
	Desc = "和人打赌失败，张果老只能倒骑毛驴，为了交通安全，特地拿在手里的后视镜，可以清楚看到前方路况。",
	RewardUnlock = 340465,
	ResultText = "张果老的后视镜解锁了",
	NumCap = 3,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG01",
	StartScene = "ARENA_StartScene",
	TeamCondition = {
		{
			Condition = "NeedTagOr",
			Value = 
			{
				560110,
			},
			Desc = "必须是星际流民的队员",
			Hint = "必须是星际流民的队员",
		},
	},
	Enemy = {
		{
			Value = 245191,
			Level = 36,
		},
	},
}
ChallengeConfig[ChallengeID.Id5182] =
{
	Id = 5182,
	Name = "装备挑战：快干晾衣架",
	Character = 223024,
	Desc = "配合便携式洗衣机使用的快干晾衣架，既要风度，也不能着凉。",
	RewardUnlock = 340468,
	ResultText = "吕洞宾的快干晾衣架解锁了",
	NumCap = 3,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG01",
	StartScene = "ARENA_StartScene",
	TeamCondition = {
		{
			Condition = "NeedTagOr",
			Value = 
			{
				560110,
			},
			Desc = "必须是星际流民的队员",
			Hint = "必须是星际流民的队员",
		},
	},
	Enemy = {
		{
			Value = 245192,
			Level = 36,
		},
	},
}
ChallengeConfig[ChallengeID.Id5183] =
{
	Id = 5183,
	Name = "装备挑战：仙桃",
	Character = 223025,
	Desc = "只要吃一口就能让人三天三夜不知饿不知困的强力提神仙果。一次食用太多可能会过度亢奋。",
	RewardUnlock = 340471,
	ResultText = "何仙姑的仙桃解锁了",
	NumCap = 3,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG01",
	StartScene = "ARENA_StartScene",
	TeamCondition = {
		{
			Condition = "NeedTagOr",
			Value = 
			{
				560110,
			},
			Desc = "必须是星际流民的队员",
			Hint = "必须是星际流民的队员",
		},
	},
	Enemy = {
		{
			Value = 245193,
			Level = 28,
		},
	},
}
ChallengeConfig[ChallengeID.Id5184] =
{
	Id = 5184,
	Name = "装备挑战：另一只鞋",
	Character = 223026,
	Desc = "蓝采和没穿的那只鞋，不知道是不是因为尺码不对才一直收起来不穿的。",
	RewardUnlock = 340474,
	ResultText = "蓝采和的另一只鞋解锁了",
	NumCap = 3,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG01",
	StartScene = "ARENA_StartScene",
	TeamCondition = {
		{
			Condition = "NeedTagOr",
			Value = 
			{
				560110,
			},
			Desc = "必须是星际流民的队员",
			Hint = "必须是星际流民的队员",
		},
	},
	Enemy = {
		{
			Value = 245194,
			Level = 28,
		},
	},
}
ChallengeConfig[ChallengeID.Id5185] =
{
	Id = 5185,
	Name = "装备挑战：入耳式耳机",
	Character = 223027,
	Desc = "韩湘子在科技产品店定制的高端耳机，戴上它，仿佛徜徉在音乐的海洋之中。",
	RewardUnlock = 340477,
	ResultText = "韩湘子的入耳式耳机解锁了",
	NumCap = 3,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG01",
	StartScene = "ARENA_StartScene",
	TeamCondition = {
		{
			Condition = "NeedTagOr",
			Value = 
			{
				560110,
			},
			Desc = "必须是星际流民的队员",
			Hint = "必须是星际流民的队员",
		},
	},
	Enemy = {
		{
			Value = 245195,
			Level = 28,
		},
	},
}
ChallengeConfig[ChallengeID.Id5186] =
{
	Id = 5186,
	Name = "装备挑战：大哥大",
	Character = 223028,
	Desc = "国舅爷从电器城买回来的二手电话，虽然以一折价200元入手，但是维修费目前已超6000元。",
	RewardUnlock = 340480,
	ResultText = "曹国舅的大哥大解锁了",
	NumCap = 3,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG01",
	StartScene = "ARENA_StartScene",
	TeamCondition = {
		{
			Condition = "NeedTagOr",
			Value = 
			{
				560110,
			},
			Desc = "必须是星际流民的队员",
			Hint = "必须是星际流民的队员",
		},
	},
	Enemy = {
		{
			Value = 245196,
			Level = 28,
		},
	},
}
ChallengeConfig[ChallengeID.Id5193] =
{
	Id = 5193,
	Name = "装备挑战：小白旗",
	Character = 223041,
	Desc = "当自己移动后就会被将死时，只要挥动小白旗就能立刻达成和解。从而使对方立刻退兵，且无法得分。",
	RewardUnlock = 340483,
	ResultText = "白国王的小白旗解锁了",
	NumCap = 3,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG01",
	StartScene = "ARENA_StartScene",
	TeamCondition = {
		{
			Condition = "NeedTagOr",
			Value = 
			{
				560110,
			},
			Desc = "必须是星际流民的队员",
			Hint = "必须是星际流民的队员",
		},
	},
	Enemy = {
		{
			Value = 245197,
			Level = 36,
		},
	},
}
ChallengeConfig[ChallengeID.Id5194] =
{
	Id = 5194,
	Name = "装备挑战：地图炮",
	Character = 223042,
	Desc = "相传是来自娘家的超必杀武器，能够在战场上对横直交叉路径上的任意敌军进行强力打击。",
	RewardUnlock = 340486,
	ResultText = "白皇后的地图炮解锁了",
	NumCap = 3,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG01",
	StartScene = "ARENA_StartScene",
	TeamCondition = {
		{
			Condition = "NeedTagOr",
			Value = 
			{
				560110,
			},
			Desc = "必须是星际流民的队员",
			Hint = "必须是星际流民的队员",
		},
	},
	Enemy = {
		{
			Value = 245198,
			Level = 36,
		},
	},
}
ChallengeConfig[ChallengeID.Id5195] =
{
	Id = 5195,
	Name = "装备挑战：权戒",
	Character = 223043,
	Desc = "刻有主教签字的印戒，用来封印签署的官方文件。当主教去世后，权戒会由国王回收并礼仪性地压碎，不过国王好像每次都会偷梁换柱，自己留下真的权戒。",
	RewardUnlock = 340489,
	ResultText = "白主教的权戒解锁了",
	NumCap = 3,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG01",
	StartScene = "ARENA_StartScene",
	TeamCondition = {
		{
			Condition = "NeedTagOr",
			Value = 
			{
				560110,
			},
			Desc = "必须是星际流民的队员",
			Hint = "必须是星际流民的队员",
		},
	},
	Enemy = {
		{
			Value = 245199,
			Level = 36,
		},
	},
}
ChallengeConfig[ChallengeID.Id5196] =
{
	Id = 5196,
	Name = "装备挑战：钢刺车轮",
	Character = 223044,
	Desc = "能够使战车一路上畅通无阻前进的装备。不过依然无法穿过己方棋子。",
	RewardUnlock = 340492,
	ResultText = "白城堡的钢刺车轮解锁了",
	NumCap = 3,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG01",
	StartScene = "ARENA_StartScene",
	TeamCondition = {
		{
			Condition = "NeedTagOr",
			Value = 
			{
				560110,
			},
			Desc = "必须是星际流民的队员",
			Hint = "必须是星际流民的队员",
		},
	},
	Enemy = {
		{
			Value = 245200,
			Level = 36,
		},
	},
}
ChallengeConfig[ChallengeID.Id5197] =
{
	Id = 5197,
	Name = "装备挑战：撑杆",
	Character = 223045,
	Desc = "长达3米的撑杆，是骑士能够越子的关键装备。每一个好的骑士，都有一手过硬的撑杆跳本领。",
	RewardUnlock = 340495,
	ResultText = "白骑士的撑杆解锁了",
	NumCap = 3,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG01",
	StartScene = "ARENA_StartScene",
	TeamCondition = {
		{
			Condition = "NeedTagOr",
			Value = 
			{
				560110,
			},
			Desc = "必须是星际流民的队员",
			Hint = "必须是星际流民的队员",
		},
	},
	Enemy = {
		{
			Value = 245201,
			Level = 36,
		},
	},
}
ChallengeConfig[ChallengeID.Id5198] =
{
	Id = 5198,
	Name = "装备挑战：骑士头冠",
	Character = 223046,
	Desc = "禁卫兵随身携带的骑士头冠，一旦触底后便能按照国王命令掏出来戴上，从此就能跳着走了。",
	RewardUnlock = 340498,
	ResultText = "白卫兵的骑士头冠解锁了",
	NumCap = 3,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG01",
	StartScene = "ARENA_StartScene",
	TeamCondition = {
		{
			Condition = "NeedTagOr",
			Value = 
			{
				560110,
			},
			Desc = "必须是星际流民的队员",
			Hint = "必须是星际流民的队员",
		},
	},
	Enemy = {
		{
			Value = 245202,
			Level = 28,
		},
	},
}
ChallengeConfig[ChallengeID.Id5199] =
{
	Id = 5199,
	Name = "装备挑战：黑桃K",
	Character = 220501,
	Desc = "约定之日紫弦月抽到的牌，他并不理解其中的含义，只是当作护身符一样带在身边。",
	RewardUnlock = 340501,
	ResultText = "紫弦月的黑桃K解锁了",
	NumCap = 3,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG01",
	StartScene = "ARENA_StartScene",
	Enemy = {
		{
			Value = 245203,
			Level = 28,
		},
	},
}
ChallengeConfig[ChallengeID.Id5200] =
{
	Id = 5200,
	Name = "装备挑战：珍珠吊兰的令牌",
	Character = 220502,
	Desc = "与珍珠吊兰交换身份后得到的身份证明，性别处有修改的痕迹。",
	RewardUnlock = 340504,
	ResultText = "琉璃兜的珍珠吊兰的令牌解锁了",
	NumCap = 3,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG01",
	StartScene = "ARENA_StartScene",
	Enemy = {
		{
			Value = 245204,
			Level = 36,
		},
	},
}
ChallengeConfig[ChallengeID.Id5201] =
{
	Id = 5201,
	Name = "装备挑战：琉璃兜的ID卡",
	Character = 220503,
	Desc = "与琉璃兜交换身份后得到的身份证明，为了防止被人怀疑而把上面的照片刮花了。",
	RewardUnlock = 340507,
	ResultText = "珍珠吊兰的琉璃兜的ID卡解锁了",
	NumCap = 3,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG01",
	StartScene = "ARENA_StartScene",
	Enemy = {
		{
			Value = 245205,
			Level = 36,
		},
	},
}
ChallengeConfig[ChallengeID.Id5202] =
{
	Id = 5202,
	Name = "装备挑战：红心J",
	Character = 220504,
	Desc = "约定之日爱之蔓抽到的牌，无论怎样，他都接受了这个结局。如果还能再来一次的话，一定要抽到王。",
	RewardUnlock = 340510,
	ResultText = "爱之蔓的红心J解锁了",
	NumCap = 3,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG01",
	StartScene = "ARENA_StartScene",
	Enemy = {
		{
			Value = 245206,
			Level = 36,
		},
	},
}
ChallengeConfig[ChallengeID.Id5203] =
{
	Id = 5203,
	Name = "装备挑战：猫粮",
	Character = 220505,
	Desc = "经过无数次实验后发现的最能适配神秘机械的道具，至于原理还在研究中。",
	RewardUnlock = 340513,
	ResultText = "高砂之翁的猫粮解锁了",
	NumCap = 3,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG01",
	StartScene = "ARENA_StartScene",
	Enemy = {
		{
			Value = 245207,
			Level = 28,
		},
	},
}
ChallengeConfig[ChallengeID.Id5204] =
{
	Id = 5204,
	Name = "装备挑战：萧",
	Character = 220506,
	Desc = "遥远国度的乐器，能发出悠扬缠绵的声音。但没人知道，其实这是根笛子。",
	RewardUnlock = 340515,
	ResultText = "仙人球的萧解锁了",
	NumCap = 3,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG01",
	StartScene = "ARENA_StartScene",
	Enemy = {
		{
			Value = 245208,
			Level = 20,
		},
	},
}
ChallengeConfig[ChallengeID.Id5205] =
{
	Id = 5205,
	Name = "装备挑战：草裙",
	Character = 220507,
	Desc = "垂盆草身上唯一的衣物，也是他的工作服，要消毒的话就直接在叶子上擦擦。",
	RewardUnlock = 340517,
	ResultText = "垂盆草的草裙解锁了",
	NumCap = 3,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG01",
	StartScene = "ARENA_StartScene",
	Enemy = {
		{
			Value = 245209,
			Level = 20,
		},
	},
}
ChallengeConfig[ChallengeID.Id5206] =
{
	Id = 5206,
	Name = "装备挑战：横幅",
	Character = 220508,
	Desc = "条纹蛇卷专门定制的横幅，用来抨击族长和手下官员的无作为。",
	RewardUnlock = 340519,
	ResultText = "条纹蛇卷的横幅解锁了",
	NumCap = 3,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG01",
	StartScene = "ARENA_StartScene",
	Enemy = {
		{
			Value = 245210,
			Level = 20,
		},
	},
}
ChallengeConfig[ChallengeID.Id5207] =
{
	Id = 5207,
	Name = "装备挑战：房产簿",
	Character = 220509,
	Desc = "满满一册的房产，令人深感羡慕。福寿玉每过一段时间就会愁眉苦脸地翻看，并纠结究竟该换到哪里住。",
	RewardUnlock = 340521,
	ResultText = "福寿玉的房产簿解锁了",
	NumCap = 3,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG01",
	StartScene = "ARENA_StartScene",
	Enemy = {
		{
			Value = 245211,
			Level = 20,
		},
	},
}
ChallengeConfig[ChallengeID.Id5208] =
{
	Id = 5208,
	Name = "装备挑战：假期作业",
	Character = 220510,
	Desc = "学校布置的作业，碧光环的本子上永远都是空白，因为寒暑假的时候他在休眠。",
	RewardUnlock = 340523,
	ResultText = "碧光环的假期作业解锁了",
	NumCap = 3,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG01",
	StartScene = "ARENA_StartScene",
	Enemy = {
		{
			Value = 245212,
			Level = 20,
		},
	},
}
ChallengeConfig[ChallengeID.Id5209] =
{
	Id = 5209,
	Name = "装备挑战：胶水",
	Character = 220511,
	Desc = "涂在脸上就变成了芦荟胶。哇哦，太厉害了。",
	RewardUnlock = 340525,
	ResultText = "芦荟的胶水解锁了",
	NumCap = 3,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG01",
	StartScene = "ARENA_StartScene",
	Enemy = {
		{
			Value = 245213,
			Level = 20,
		},
	},
}
ChallengeConfig[ChallengeID.Id5210] =
{
	Id = 5210,
	Name = "装备挑战：星之花",
	Character = 220512,
	Desc = "被视为神力的象征，受到地表居民崇拜，其实只是虹之玉自己开出来的花。",
	RewardUnlock = 340528,
	ResultText = "虹之玉的星之花解锁了",
	NumCap = 3,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG01",
	StartScene = "ARENA_StartScene",
	Enemy = {
		{
			Value = 245214,
			Level = 28,
		},
	},
}
ChallengeConfig[ChallengeID.Id5211] =
{
	Id = 5211,
	Name = "装备挑战：手鼓",
	Character = 220513,
	Desc = "祭祀过程中不可或缺的乐器，会发出“咚咚”的声响，用来吵醒睡懒觉的神明。",
	RewardUnlock = 340531,
	ResultText = "熊童子的手鼓解锁了",
	NumCap = 3,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG01",
	StartScene = "ARENA_StartScene",
	Enemy = {
		{
			Value = 245215,
			Level = 28,
		},
	},
}
ChallengeConfig[ChallengeID.Id5212] =
{
	Id = 5212,
	Name = "装备挑战：钱袋",
	Character = 220514,
	Desc = "黄丽辛苦工作数年攒下来的嫁妆钱，可以买下整整三瓶小血瓶。",
	RewardUnlock = 340534,
	ResultText = "黄丽的钱袋解锁了",
	NumCap = 3,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG01",
	StartScene = "ARENA_StartScene",
	Enemy = {
		{
			Value = 245216,
			Level = 28,
		},
	},
}
ChallengeConfig[ChallengeID.Id5213] =
{
	Id = 5213,
	Name = "装备挑战：一沓身份证",
	Character = 220515,
	Desc = "用于伪造身份的证件，姬秋丽已经至少有五十个假名了。",
	RewardUnlock = 340537,
	ResultText = "姬秋丽的一沓身份证解锁了",
	NumCap = 3,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG01",
	StartScene = "ARENA_StartScene",
	Enemy = {
		{
			Value = 245217,
			Level = 28,
		},
	},
}
ChallengeConfig[ChallengeID.Id5214] =
{
	Id = 5214,
	Name = "装备挑战：计算器",
	Character = 220516,
	Desc = "做生意时会用到的便利工具，用来帮碰碰香计算复杂的十以内的加减法。",
	RewardUnlock = 340540,
	ResultText = "碰碰香的计算器解锁了",
	NumCap = 3,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG01",
	StartScene = "ARENA_StartScene",
	Enemy = {
		{
			Value = 245218,
			Level = 28,
		},
	},
}
ChallengeConfig[ChallengeID.Id5215] =
{
	Id = 5215,
	Name = "装备挑战：通讯簿",
	Character = 220517,
	Desc = "上面扭扭曲曲地记载着各种渠道的货源，甚至可以看到很多意想不到的名字。",
	RewardUnlock = 340543,
	ResultText = "玉吊钟的通讯簿解锁了",
	NumCap = 3,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG01",
	StartScene = "ARENA_StartScene",
	Enemy = {
		{
			Value = 245219,
			Level = 28,
		},
	},
}
ChallengeConfig[ChallengeID.Id5216] =
{
	Id = 5216,
	Name = "装备挑战：地图",
	Character = 220518,
	Desc = "在蜿蜒曲折的地底指明道路的地图，对于邮差来说是最好的帮手。因为地底没信号，不能用GPS。",
	RewardUnlock = 340546,
	ResultText = "金钱木的地图解锁了",
	NumCap = 3,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG01",
	StartScene = "ARENA_StartScene",
	Enemy = {
		{
			Value = 245220,
			Level = 28,
		},
	},
}
ChallengeConfig[ChallengeID.Id5217] =
{
	Id = 5217,
	Name = "装备挑战：社会实践表",
	Character = 220519,
	Desc = "学生的假期作业，上面刻着不知道从哪个企业搞来的印章。",
	RewardUnlock = 340549,
	ResultText = "宝草的社会实践表解锁了",
	NumCap = 3,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG01",
	StartScene = "ARENA_StartScene",
	Enemy = {
		{
			Value = 245221,
			Level = 28,
		},
	},
}
ChallengeConfig[ChallengeID.Id5218] =
{
	Id = 5218,
	Name = "装备挑战：令箭口香糖",
	Character = 220520,
	Desc = "令箭荷花用自己的花蜜制造出的口香糖，意外的在地底开始流行。",
	RewardUnlock = 340552,
	ResultText = "令箭荷花的令箭口香糖解锁了",
	NumCap = 3,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG01",
	StartScene = "ARENA_StartScene",
	Enemy = {
		{
			Value = 245222,
			Level = 28,
		},
	},
}
ChallengeConfig[ChallengeID.Id5219] =
{
	Id = 5219,
	Name = "装备挑战：Kp4-2芯片",
	Character = 220521,
	Desc = "小球玫瑰小时偶然间在星核捡到的芯片，直到现在她也没能研究清它的构造。",
	RewardUnlock = 340555,
	ResultText = "小球玫瑰的Kp4-2芯片解锁了",
	NumCap = 3,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG01",
	StartScene = "ARENA_StartScene",
	Enemy = {
		{
			Value = 245223,
			Level = 28,
		},
	},
}
ChallengeConfig[ChallengeID.Id5220] =
{
	Id = 5220,
	Name = "装备挑战：启示",
	Character = 220522,
	Desc = "神所恩赐的智慧，每当冥思苦想之际，神明就会帮助虔诚的信徒，把启示在他们的脑海中点亮。",
	RewardUnlock = 340558,
	ResultText = "茜之塔的启示解锁了",
	NumCap = 3,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG01",
	StartScene = "ARENA_StartScene",
	Enemy = {
		{
			Value = 245224,
			Level = 28,
		},
	},
}
ChallengeConfig[ChallengeID.Id5221] =
{
	Id = 5221,
	Name = "装备挑战：巫女服",
	Character = 220523,
	Desc = "鹿角海棠的工作服，怕麻烦的她也拿来当便服穿。",
	RewardUnlock = 340561,
	ResultText = "鹿角海棠的巫女服解锁了",
	NumCap = 3,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG01",
	StartScene = "ARENA_StartScene",
	Enemy = {
		{
			Value = 245225,
			Level = 36,
		},
	},
}
ChallengeConfig[ChallengeID.Id5222] =
{
	Id = 5222,
	Name = "装备挑战：假眼",
	Character = 220524,
	Desc = "用马克笔画在眼皮上的假眼，虎刺梅因为疲劳而打盹时反而能彰显出比平时更恐怖的威慑力。",
	RewardUnlock = 340564,
	ResultText = "虎刺梅的假眼解锁了",
	NumCap = 3,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG01",
	StartScene = "ARENA_StartScene",
	Enemy = {
		{
			Value = 245226,
			Level = 36,
		},
	},
}
ChallengeConfig[ChallengeID.Id5223] =
{
	Id = 5223,
	Name = "装备挑战：抹布",
	Character = 220525,
	Desc = "擦桌收拾的抹布，忙不过来的时候雅乐之舞就会亲自来服务客人。现在知道为什么客栈只有一个雇员了。",
	RewardUnlock = 340567,
	ResultText = "雅乐之舞的抹布解锁了",
	NumCap = 3,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG01",
	StartScene = "ARENA_StartScene",
	Enemy = {
		{
			Value = 245227,
			Level = 36,
		},
	},
}
ChallengeConfig[ChallengeID.Id5224] =
{
	Id = 5224,
	Name = "装备挑战：竖琴",
	Character = 220526,
	Desc = "来自外星的乐器，能演奏出柔美动听的旋律，让人昏昏欲睡。从来没有人能清醒地听完玉露演奏一曲。",
	RewardUnlock = 340570,
	ResultText = "玉露的竖琴解锁了",
	NumCap = 3,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG01",
	StartScene = "ARENA_StartScene",
	Enemy = {
		{
			Value = 245228,
			Level = 36,
		},
	},
}
ChallengeConfig[ChallengeID.Id5225] =
{
	Id = 5225,
	Name = "装备挑战：神杖",
	Character = 220527,
	Desc = "黑法师从地摊奸商那买来的伪装成神杖的木棍，但它其实真的是神杖。所以，到底是谁上当了？",
	RewardUnlock = 340573,
	ResultText = "黑法师的神杖解锁了",
	NumCap = 3,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG01",
	StartScene = "ARENA_StartScene",
	Enemy = {
		{
			Value = 245229,
			Level = 36,
		},
	},
}
ChallengeConfig[ChallengeID.Id5226] =
{
	Id = 5226,
	Name = "装备挑战：阳炎之环",
	Character = 220528,
	Desc = "火祭戴在无名指的戒指，具有阳光的能量，直接注视会被闪瞎双眼。",
	RewardUnlock = 340576,
	ResultText = "火祭的阳炎之环解锁了",
	NumCap = 3,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG01",
	StartScene = "ARENA_StartScene",
	Enemy = {
		{
			Value = 245230,
			Level = 36,
		},
	},
}
ChallengeConfig[ChallengeID.Id5227] =
{
	Id = 5227,
	Name = "装备挑战：神话故事",
	Character = 220529,
	Desc = "雷神消遣时的读物，他非常喜欢看凡人描述自己的生活，但也对那些不怎么光彩的部分感到不满。",
	RewardUnlock = 340579,
	ResultText = "雷神的神话故事解锁了",
	NumCap = 3,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG01",
	StartScene = "ARENA_StartScene",
	Enemy = {
		{
			Value = 245231,
			Level = 44,
		},
	},
}
ChallengeConfig[ChallengeID.Id5228] =
{
	Id = 5228,
	Name = "装备挑战：尖刺",
	Character = 220529,
	Desc = "红色的针刺类暗器，用于偷偷进行攻击，每当雷神听到有凡人在说自己的坏话时，就会用这东西悄悄扎他们的屁股。",
	RewardUnlock = 340580,
	ResultText = "雷神的尖刺解锁了",
	NumCap = 3,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG01",
	StartScene = "ARENA_StartScene",
	Enemy = {
		{
			Value = 245232,
			Level = 60,
		},
	},
}
ChallengeConfig[ChallengeID.Id5229] =
{
	Id = 5229,
	Name = "装备挑战：金手指",
	Character = 220530,
	Desc = "电子游戏作弊的道具，就是因为这个，没人愿意和她一起玩游戏。",
	RewardUnlock = 340583,
	ResultText = "金手指的金手指解锁了",
	NumCap = 3,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG01",
	StartScene = "ARENA_StartScene",
	Enemy = {
		{
			Value = 245233,
			Level = 44,
		},
	},
}
ChallengeConfig[ChallengeID.Id5230] =
{
	Id = 5230,
	Name = "装备挑战：排笛",
	Character = 220530,
	Desc = "异国的乐器，能够演奏出空灵的音乐，在贵族之间很有人气。但她吹反了。",
	RewardUnlock = 340584,
	ResultText = "金手指的排笛解锁了",
	NumCap = 3,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG01",
	StartScene = "ARENA_StartScene",
	Enemy = {
		{
			Value = 245234,
			Level = 60,
		},
	},
}
ChallengeConfig[ChallengeID.Id5231] =
{
	Id = 5231,
	Name = "装备挑战：南",
	Character = 223061,
	Desc = "（拼音：nán），笔画数9，部首十。——蓝星《新华字典》",
	RewardUnlock = 340587,
	ResultText = "松芊芊的南解锁了",
	NumCap = 3,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG01",
	StartScene = "ARENA_StartScene",
	TeamCondition = {
		{
			Condition = "NeedTagOr",
			Value = 
			{
				560110,
			},
			Desc = "必须是星际流民的队员",
			Hint = "必须是星际流民的队员",
		},
	},
	Enemy = {
		{
			Value = 245235,
			Level = 28,
		},
	},
}
ChallengeConfig[ChallengeID.Id5232] =
{
	Id = 5232,
	Name = "装备挑战：山",
	Character = 223061,
	Desc = "（拼音：shān），笔画数3，部首山。——蓝星《新华字典》",
	RewardUnlock = 340588,
	ResultText = "松芊芊的山解锁了",
	NumCap = 3,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG01",
	StartScene = "ARENA_StartScene",
	TeamCondition = {
		{
			Condition = "NeedTagOr",
			Value = 
			{
				560110,
			},
			Desc = "必须是星际流民的队员",
			Hint = "必须是星际流民的队员",
		},
	},
	Enemy = {
		{
			Value = 245236,
			Level = 36,
		},
	},
}
ChallengeConfig[ChallengeID.Id5233] =
{
	Id = 5233,
	Name = "装备挑战：发",
	Character = 223062,
	Desc = "（拼音：fā），笔画数5，部首又。——蓝星《新华字典》",
	RewardUnlock = 340591,
	ResultText = "休休的发解锁了",
	NumCap = 3,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG01",
	StartScene = "ARENA_StartScene",
	TeamCondition = {
		{
			Condition = "NeedTagOr",
			Value = 
			{
				560110,
			},
			Desc = "必须是星际流民的队员",
			Hint = "必须是星际流民的队员",
		},
	},
	Enemy = {
		{
			Value = 245237,
			Level = 28,
		},
	},
}
ChallengeConfig[ChallengeID.Id5234] =
{
	Id = 5234,
	Name = "装备挑战：财",
	Character = 223062,
	Desc = "（拼音：cái），笔画数7，部首贝。——蓝星《新华字典》",
	RewardUnlock = 340592,
	ResultText = "休休的财解锁了",
	NumCap = 3,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG01",
	StartScene = "ARENA_StartScene",
	TeamCondition = {
		{
			Condition = "NeedTagOr",
			Value = 
			{
				560110,
			},
			Desc = "必须是星际流民的队员",
			Hint = "必须是星际流民的队员",
		},
	},
	Enemy = {
		{
			Value = 245238,
			Level = 36,
		},
	},
}
ChallengeConfig[ChallengeID.Id5235] =
{
	Id = 5235,
	Name = "装备挑战：安",
	Character = 223063,
	Desc = "（拼音：ān），笔画数6，部首宀。——蓝星《新华字典》",
	RewardUnlock = 340595,
	ResultText = "阿宁的安解锁了",
	NumCap = 3,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG01",
	StartScene = "ARENA_StartScene",
	TeamCondition = {
		{
			Condition = "NeedTagOr",
			Value = 
			{
				560110,
			},
			Desc = "必须是星际流民的队员",
			Hint = "必须是星际流民的队员",
		},
	},
	Enemy = {
		{
			Value = 245239,
			Level = 28,
		},
	},
}
ChallengeConfig[ChallengeID.Id5236] =
{
	Id = 5236,
	Name = "装备挑战：宁",
	Character = 223063,
	Desc = "（拼音：níng），笔画数5，部首宀。——蓝星《新华字典》",
	RewardUnlock = 340596,
	ResultText = "阿宁的宁解锁了",
	NumCap = 3,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG01",
	StartScene = "ARENA_StartScene",
	TeamCondition = {
		{
			Condition = "NeedTagOr",
			Value = 
			{
				560110,
			},
			Desc = "必须是星际流民的队员",
			Hint = "必须是星际流民的队员",
		},
	},
	Enemy = {
		{
			Value = 245240,
			Level = 36,
		},
	},
}
ChallengeConfig[ChallengeID.Id5237] =
{
	Id = 5237,
	Name = "装备挑战：高",
	Character = 223064,
	Desc = "（拼音：gāo），笔画数10，部首高。——蓝星《新华字典》",
	RewardUnlock = 340599,
	ResultText = "倪不染的高解锁了",
	NumCap = 3,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG01",
	StartScene = "ARENA_StartScene",
	TeamCondition = {
		{
			Condition = "NeedTagOr",
			Value = 
			{
				560110,
			},
			Desc = "必须是星际流民的队员",
			Hint = "必须是星际流民的队员",
		},
	},
	Enemy = {
		{
			Value = 245241,
			Level = 28,
		},
	},
}
ChallengeConfig[ChallengeID.Id5238] =
{
	Id = 5238,
	Name = "装备挑战：尚",
	Character = 223064,
	Desc = "（拼音：shàng），笔画数8，部首小。——蓝星《新华字典》",
	RewardUnlock = 340600,
	ResultText = "倪不染的尚解锁了",
	NumCap = 3,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG01",
	StartScene = "ARENA_StartScene",
	TeamCondition = {
		{
			Condition = "NeedTagOr",
			Value = 
			{
				560110,
			},
			Desc = "必须是星际流民的队员",
			Hint = "必须是星际流民的队员",
		},
	},
	Enemy = {
		{
			Value = 245242,
			Level = 36,
		},
	},
}
ChallengeConfig[ChallengeID.Id5239] =
{
	Id = 5239,
	Name = "装备挑战：有",
	Character = 223065,
	Desc = "（拼音：yǒu），笔画数6，部首月。——蓝星《新华字典》",
	RewardUnlock = 340603,
	ResultText = "小始小终的有解锁了",
	NumCap = 3,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG01",
	StartScene = "ARENA_StartScene",
	TeamCondition = {
		{
			Condition = "NeedTagOr",
			Value = 
			{
				560110,
			},
			Desc = "必须是星际流民的队员",
			Hint = "必须是星际流民的队员",
		},
	},
	Enemy = {
		{
			Value = 245243,
			Level = 36,
		},
	},
}
ChallengeConfig[ChallengeID.Id5240] =
{
	Id = 5240,
	Name = "装备挑战：终",
	Character = 223065,
	Desc = "（拼音：zhōng），笔画数8，部首纟。——蓝星《新华字典》",
	RewardUnlock = 340604,
	ResultText = "小始小终的终解锁了",
	NumCap = 3,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG01",
	StartScene = "ARENA_StartScene",
	TeamCondition = {
		{
			Condition = "NeedTagOr",
			Value = 
			{
				560110,
			},
			Desc = "必须是星际流民的队员",
			Hint = "必须是星际流民的队员",
		},
	},
	Enemy = {
		{
			Value = 245244,
			Level = 48,
		},
	},
}
ChallengeConfig[ChallengeID.Id5241] =
{
	Id = 5241,
	Name = "装备挑战：自制火箭",
	Character = 223066,
	Desc = "进入宇宙纪元后，鲤鱼族前往龙门空间站的必备载具，由每个鲤鱼阅读完《火箭制作速成》后自行制造。",
	RewardUnlock = 340607,
	ResultText = "锦鲤鲤的自制火箭解锁了",
	NumCap = 3,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG01",
	StartScene = "ARENA_StartScene",
	TeamCondition = {
		{
			Condition = "NeedTagOr",
			Value = 
			{
				560110,
			},
			Desc = "必须是星际流民的队员",
			Hint = "必须是星际流民的队员",
		},
	},
	Enemy = {
		{
			Value = 245245,
			Level = 36,
		},
	},
}
ChallengeConfig[ChallengeID.Id5242] =
{
	Id = 5242,
	Name = "装备挑战：滋水枪",
	Character = 223067,
	Desc = "年大人苦思多年自制的远距离对烟花武器，射程长达25厘米。",
	RewardUnlock = 340610,
	ResultText = "年大人的滋水枪解锁了",
	NumCap = 3,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG01",
	StartScene = "ARENA_StartScene",
	TeamCondition = {
		{
			Condition = "NeedTagOr",
			Value = 
			{
				560110,
			},
			Desc = "必须是星际流民的队员",
			Hint = "必须是星际流民的队员",
		},
	},
	Enemy = {
		{
			Value = 245246,
			Level = 44,
		},
	},
}
ChallengeConfig[ChallengeID.Id5243] =
{
	Id = 5243,
	Name = "装备挑战：年历",
	Character = 223067,
	Desc = "画满“正”的台历，听其他年大人说，只要画满73个，就可以坐飞船去其他星球胡闹了。说起来，闰年好像要多画一笔才行。",
	RewardUnlock = 340611,
	ResultText = "年大人的年历解锁了",
	NumCap = 3,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG01",
	StartScene = "ARENA_StartScene",
	TeamCondition = {
		{
			Condition = "NeedTagOr",
			Value = 
			{
				560110,
			},
			Desc = "必须是星际流民的队员",
			Hint = "必须是星际流民的队员",
		},
	},
	Enemy = {
		{
			Value = 245247,
			Level = 60,
		},
	},
}
ChallengeConfig[ChallengeID.Id5244] =
{
	Id = 5244,
	Name = "装备挑战：恶魔之角",
	Character = 223007,
	Desc = "从黑市买来的恶魔之角，卖家说是很了不起的法器，如果不是和术士特别投缘的话，是绝不会出售的。",
	RewardUnlock = 340614,
	ResultText = "术士的恶魔之角解锁了",
	NumCap = 3,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG01",
	StartScene = "RPG_StartScene",
	TeamCondition = {
		{
			Condition = "NeedTagOr",
			Value = 
			{
				560103,
			},
			Desc = "必须是冒险星的队员",
			Hint = "必须是冒险星的队员",
		},
	},
	Enemy = {
		{
			Value = 245248,
			Level = 36,
		},
	},
}
ChallengeConfig[ChallengeID.Id5245] =
{
	Id = 5245,
	Name = "装备挑战：百花香水",
	Character = 223008,
	Desc = "拥有芬芳气味的香水，一旦打开，就会吸引附近的精灵来到自己身边。",
	RewardUnlock = 340617,
	ResultText = "德鲁伊的百花香水解锁了",
	NumCap = 3,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG01",
	StartScene = "RPG_StartScene",
	TeamCondition = {
		{
			Condition = "NeedTagOr",
			Value = 
			{
				560103,
			},
			Desc = "必须是冒险星的队员",
			Hint = "必须是冒险星的队员",
		},
	},
	Enemy = {
		{
			Value = 245249,
			Level = 44,
		},
	},
}
ChallengeConfig[ChallengeID.Id5246] =
{
	Id = 5246,
	Name = "装备挑战：枯荣树枝",
	Character = 223008,
	Desc = "由世界之树上折落的魔法树枝，蕴含其中的魔法力量让这一节树枝永远在枯荣之间轮回。象征着生命的盛放与衰败。",
	RewardUnlock = 340618,
	ResultText = "德鲁伊的枯荣树枝解锁了",
	NumCap = 3,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG01",
	StartScene = "RPG_StartScene",
	TeamCondition = {
		{
			Condition = "NeedTagOr",
			Value = 
			{
				560103,
			},
			Desc = "必须是冒险星的队员",
			Hint = "必须是冒险星的队员",
		},
	},
	Enemy = {
		{
			Value = 245250,
			Level = 60,
		},
	},
}
ChallengeConfig[ChallengeID.Id5247] =
{
	Id = 5247,
	Name = "装备挑战：巧克力食谱",
	Character = 223081,
	Desc = "美食星最详细的巧克力食谱，其中包含了88种奇妙口味，酸甜苦辣，总有一款适合你。",
	RewardUnlock = 340621,
	ResultText = "白可可的巧克力食谱解锁了",
	NumCap = 3,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG01",
	StartScene = "FAT_StartScene",
	TeamCondition = {
		{
			Condition = "NeedTagOr",
			Value = 
			{
				560104,
			},
			Desc = "必须是美食星的队员",
			Hint = "必须是美食星的队员",
		},
	},
	Enemy = {
		{
			Value = 245251,
			Level = 28,
		},
	},
}
ChallengeConfig[ChallengeID.Id5248] =
{
	Id = 5248,
	Name = "装备挑战：2×2魔方",
	Character = 223082,
	Desc = "鱼罐头小时候路过文具店被老板哄骗着买下的益智玩具，不过玩了超过1200个小时，目前也没有能够还原。",
	RewardUnlock = 340624,
	ResultText = "鱼罐头的2×2魔方解锁了",
	NumCap = 3,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG01",
	StartScene = "ARENA_StartScene",
	TeamCondition = {
		{
			Condition = "NeedTagOr",
			Value = 
			{
				560110,
			},
			Desc = "必须是星际流民的队员",
			Hint = "必须是星际流民的队员",
		},
	},
	Enemy = {
		{
			Value = 245252,
			Level = 28,
		},
	},
}
ChallengeConfig[ChallengeID.Id5249] =
{
	Id = 5249,
	Name = "装备挑战：捣辣椒罐",
	Character = 223101,
	Desc = "因常年使用，罐子周边布满辣椒，碰一下就会喊「好辣好辣」，需要戴手套才能安全捧起。",
	RewardUnlock = 340637,
	ResultText = "辣辣子的捣辣椒罐解锁了",
	NumCap = 3,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG01",
	StartScene = "FAT_StartScene",
	TeamCondition = {
		{
			Condition = "NeedTagOr",
			Value = 
			{
				560104,
			},
			Desc = "必须是美食星的队员",
			Hint = "必须是美食星的队员",
		},
	},
	Enemy = {
		{
			Value = 245253,
			Level = 28,
		},
	},
}
ChallengeConfig[ChallengeID.Id5250] =
{
	Id = 5250,
	Name = "装备挑战：温泉蛋",
	Character = 223102,
	Desc = "适合搭配泡面，目前在和火腿肠争夺「泡面伴侣」的位置。",
	RewardUnlock = 340640,
	ResultText = "板蓝根泡面的温泉蛋解锁了",
	NumCap = 3,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG01",
	StartScene = "FAT_StartScene",
	TeamCondition = {
		{
			Condition = "NeedTagOr",
			Value = 
			{
				560104,
			},
			Desc = "必须是美食星的队员",
			Hint = "必须是美食星的队员",
		},
	},
	Enemy = {
		{
			Value = 245254,
			Level = 28,
		},
	},
}
ChallengeConfig[ChallengeID.Id5251] =
{
	Id = 5251,
	Name = "装备挑战：腌蛋泥",
	Character = 223103,
	Desc = "均匀地抹在鸭蛋上的泥，有配方的，不要随便从地上弄点泥就乱涂啊！",
	RewardUnlock = 340643,
	ResultText = "皮蛋披萨的腌蛋泥解锁了",
	NumCap = 3,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG01",
	StartScene = "FAT_StartScene",
	TeamCondition = {
		{
			Condition = "NeedTagOr",
			Value = 
			{
				560104,
			},
			Desc = "必须是美食星的队员",
			Hint = "必须是美食星的队员",
		},
	},
	Enemy = {
		{
			Value = 245255,
			Level = 28,
		},
	},
}
ChallengeConfig[ChallengeID.Id5252] =
{
	Id = 5252,
	Name = "装备挑战：鼻夹子",
	Character = 223104,
	Desc = "自己做饭团时会用的夹子，对外宣称是为了防止自己患上鼻炎。",
	RewardUnlock = 340646,
	ResultText = "鲱鱼饭团的鼻夹子解锁了",
	NumCap = 3,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG01",
	StartScene = "FAT_StartScene",
	TeamCondition = {
		{
			Condition = "NeedTagOr",
			Value = 
			{
				560104,
			},
			Desc = "必须是美食星的队员",
			Hint = "必须是美食星的队员",
		},
	},
	Enemy = {
		{
			Value = 245256,
			Level = 36,
		},
	},
}
ChallengeConfig[ChallengeID.Id5253] =
{
	Id = 5253,
	Name = "装备挑战：小海燕",
	Character = 223105,
	Desc = "这个小海燕栩栩如生、惟妙惟肖、活灵活现——从描述看出什么异常了吗？",
	RewardUnlock = 340649,
	ResultText = "基维燕克的小海燕解锁了",
	NumCap = 3,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG01",
	StartScene = "FAT_StartScene",
	TeamCondition = {
		{
			Condition = "NeedTagOr",
			Value = 
			{
				560104,
			},
			Desc = "必须是美食星的队员",
			Hint = "必须是美食星的队员",
		},
	},
	Enemy = {
		{
			Value = 245257,
			Level = 36,
		},
	},
}
ChallengeConfig[ChallengeID.Id5254] =
{
	Id = 5254,
	Name = "装备挑战：防滑筷",
	Character = 223106,
	Desc = "夹起食物后可让食物不再滑落，但是不能防止手滑导致的食物滑落。",
	RewardUnlock = 340652,
	ResultText = "猪猪包的防滑筷解锁了",
	NumCap = 3,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG01",
	StartScene = "FAT_StartScene",
	TeamCondition = {
		{
			Condition = "NeedTagOr",
			Value = 
			{
				560104,
			},
			Desc = "必须是美食星的队员",
			Hint = "必须是美食星的队员",
		},
	},
	Enemy = {
		{
			Value = 245258,
			Level = 36,
		},
	},
}
ChallengeConfig[ChallengeID.Id5255] =
{
	Id = 5255,
	Name = "装备挑战：手磨咖啡器",
	Character = 223107,
	Desc = "将咖啡豆研磨成粉的工具。不要被名字骗了，手动只是需要按下开关。",
	RewardUnlock = 340655,
	ResultText = "史卡的手磨咖啡器解锁了",
	NumCap = 3,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG01",
	StartScene = "FAT_StartScene",
	TeamCondition = {
		{
			Condition = "NeedTagOr",
			Value = 
			{
				560104,
			},
			Desc = "必须是美食星的队员",
			Hint = "必须是美食星的队员",
		},
	},
	Enemy = {
		{
			Value = 245259,
			Level = 36,
		},
	},
}
ChallengeConfig[ChallengeID.Id5256] =
{
	Id = 5256,
	Name = "装备挑战：夜光杯",
	Character = 223108,
	Desc = "利用太阳能板制作的杯子，需要在户外放一段时间才能在夜里发光。开关在杯底。",
	RewardUnlock = 340658,
	ResultText = "拜兰帝的夜光杯解锁了",
	NumCap = 3,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG01",
	StartScene = "FAT_StartScene",
	TeamCondition = {
		{
			Condition = "NeedTagOr",
			Value = 
			{
				560104,
			},
			Desc = "必须是美食星的队员",
			Hint = "必须是美食星的队员",
		},
	},
	Enemy = {
		{
			Value = 245260,
			Level = 44,
		},
	},
}
ChallengeConfig[ChallengeID.Id5257] =
{
	Id = 5257,
	Name = "装备挑战：酒精检测仪",
	Character = 223108,
	Desc = "被用来检测酒精度是否达标的仪器，喝一口吹一口气，只有数值爆表才表示这批酒合格。",
	RewardUnlock = 340659,
	ResultText = "拜兰帝的酒精检测仪解锁了",
	NumCap = 3,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG01",
	StartScene = "FAT_StartScene",
	TeamCondition = {
		{
			Condition = "NeedTagOr",
			Value = 
			{
				560104,
			},
			Desc = "必须是美食星的队员",
			Hint = "必须是美食星的队员",
		},
	},
	Enemy = {
		{
			Value = 245261,
			Level = 60,
		},
	},
}
ChallengeConfig[ChallengeID.Id5258] =
{
	Id = 5258,
	Name = "装备挑战：异次元尘袋",
	Character = 223121,
	Desc = "据说会把放进去的垃圾传送到另一个次元，自从有了它，扫地鸡就拥有了随手捡垃圾的良好习惯。",
	RewardUnlock = 340662,
	ResultText = "扫地鸡的异次元尘袋解锁了",
	NumCap = 3,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG01",
	StartScene = "ARENA_StartScene",
	TeamCondition = {
		{
			Condition = "NeedTagOr",
			Value = 
			{
				560110,
			},
			Desc = "必须是星际流民的队员",
			Hint = "必须是星际流民的队员",
		},
	},
	Enemy = {
		{
			Value = 245262,
			Level = 28,
		},
	},
}
ChallengeConfig[ChallengeID.Id5259] =
{
	Id = 5259,
	Name = "装备挑战：蔷薇种子",
	Character = 223122,
	Desc = "刺破自己的身体前，白蔷薇向土地撒下了一把希望的种子。",
	RewardUnlock = 340665,
	ResultText = "白蔷薇的蔷薇种子解锁了",
	NumCap = 3,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG01",
	StartScene = "ARENA_StartScene",
	TeamCondition = {
		{
			Condition = "NeedTagOr",
			Value = 
			{
				560110,
			},
			Desc = "必须是星际流民的队员",
			Hint = "必须是星际流民的队员",
		},
	},
	Enemy = {
		{
			Value = 245263,
			Level = 28,
		},
	},
}
ChallengeConfig[ChallengeID.Id5260] =
{
	Id = 5260,
	Name = "装备挑战：平民卡牌",
	Character = 223123,
	Desc = "据说至今为止，小红帽已经抽过1197次平民卡牌了，当抽到它时，小红帽总会唉声叹气。",
	RewardUnlock = 340668,
	ResultText = "小红帽的平民卡牌解锁了",
	NumCap = 3,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG01",
	StartScene = "ARENA_StartScene",
	TeamCondition = {
		{
			Condition = "NeedTagOr",
			Value = 
			{
				560110,
			},
			Desc = "必须是星际流民的队员",
			Hint = "必须是星际流民的队员",
		},
	},
	Enemy = {
		{
			Value = 245264,
			Level = 28,
		},
	},
}
ChallengeConfig[ChallengeID.Id5261] =
{
	Id = 5261,
	Name = "装备挑战：三叉戟",
	Character = 220431,
	Desc = "当遇到敌人时，TA也会拿起武器迎战，保卫海洋。",
	RewardUnlock = 340627,
	ResultText = "人鱼清音的三叉戟解锁了",
	NumCap = 3,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG01",
	StartScene = "SEA_StartScene",
	TeamCondition = {
		{
			Condition = "NeedTagOr",
			Value = 
			{
				560107,
			},
			Desc = "必须是海洋星的队员",
			Hint = "必须是海洋星的队员",
		},
	},
	Enemy = {
		{
			Value = 245265,
			Level = 44,
		},
	},
}
ChallengeConfig[ChallengeID.Id5262] =
{
	Id = 5262,
	Name = "装备挑战：梳子",
	Character = 220431,
	Desc = "每天要梳头300次，才能对得起这一头美丽的秀发。",
	RewardUnlock = 340628,
	ResultText = "人鱼清音的梳子解锁了",
	NumCap = 3,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG01",
	StartScene = "SEA_StartScene",
	TeamCondition = {
		{
			Condition = "NeedTagOr",
			Value = 
			{
				560107,
			},
			Desc = "必须是海洋星的队员",
			Hint = "必须是海洋星的队员",
		},
	},
	Enemy = {
		{
			Value = 245266,
			Level = 60,
		},
	},
}
ChallengeConfig[ChallengeID.Id5263] =
{
	Id = 5263,
	Name = "装备挑战：玉佩",
	Character = 223124,
	Desc = "挂在腰间的玉佩，当灵均在各地行走时，经常和其他物品发生碰撞，发出叮当叮当的响声。",
	RewardUnlock = 340671,
	ResultText = "灵均的玉佩解锁了",
	NumCap = 3,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG01",
	StartScene = "ARENA_StartScene",
	TeamCondition = {
		{
			Condition = "NeedTagOr",
			Value = 
			{
				560110,
			},
			Desc = "必须是星际流民的队员",
			Hint = "必须是星际流民的队员",
		},
	},
	Enemy = {
		{
			Value = 245267,
			Level = 44,
		},
	},
}
ChallengeConfig[ChallengeID.Id5264] =
{
	Id = 5264,
	Name = "装备挑战：诗集",
	Character = 223124,
	Desc = "灵均写下的诗赋合集，是宇宙中的宝物，常常引来外人争抢。",
	RewardUnlock = 340672,
	ResultText = "灵均的诗集解锁了",
	NumCap = 3,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG01",
	StartScene = "ARENA_StartScene",
	TeamCondition = {
		{
			Condition = "NeedTagOr",
			Value = 
			{
				560110,
			},
			Desc = "必须是星际流民的队员",
			Hint = "必须是星际流民的队员",
		},
	},
	Enemy = {
		{
			Value = 245268,
			Level = 60,
		},
	},
}
ChallengeConfig[ChallengeID.Id5265] =
{
	Id = 5265,
	Name = "装备挑战：修理工具箱",
	Character = 223125,
	Desc = "作为应急课程100分的龙头老大，不管去哪里都要带上工具箱，以免龙舟突然出现故障。",
	RewardUnlock = 340675,
	ResultText = "龙头老大的修理工具箱解锁了",
	NumCap = 3,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG01",
	StartScene = "ARENA_StartScene",
	TeamCondition = {
		{
			Condition = "NeedTagOr",
			Value = 
			{
				560110,
			},
			Desc = "必须是星际流民的队员",
			Hint = "必须是星际流民的队员",
		},
	},
	Enemy = {
		{
			Value = 245269,
			Level = 36,
		},
	},
}
ChallengeConfig[ChallengeID.Id5266] =
{
	Id = 5266,
	Name = "装备挑战：红布",
	Character = 223126,
	Desc = "当鼓不被使用的时候，总是被一块红布好好地遮盖着。",
	RewardUnlock = 340678,
	ResultText = "抬鼓达人的红布解锁了",
	NumCap = 3,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG01",
	StartScene = "ARENA_StartScene",
	TeamCondition = {
		{
			Condition = "NeedTagOr",
			Value = 
			{
				560110,
			},
			Desc = "必须是星际流民的队员",
			Hint = "必须是星际流民的队员",
		},
	},
	Enemy = {
		{
			Value = 245270,
			Level = 36,
		},
	},
}
ChallengeConfig[ChallengeID.Id5267] =
{
	Id = 5267,
	Name = "装备挑战：计算器",
	Character = 223127,
	Desc = "当获得了船只速度、风力等级等多个信息后，再运用它算出龙头朝向和角度，是帮助队伍获胜最强大的武器。",
	RewardUnlock = 340681,
	ResultText = "桨手一号的计算器解锁了",
	NumCap = 3,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG01",
	StartScene = "ARENA_StartScene",
	TeamCondition = {
		{
			Condition = "NeedTagOr",
			Value = 
			{
				560110,
			},
			Desc = "必须是星际流民的队员",
			Hint = "必须是星际流民的队员",
		},
	},
	Enemy = {
		{
			Value = 245271,
			Level = 28,
		},
	},
}
ChallengeConfig[ChallengeID.Id5268] =
{
	Id = 5268,
	Name = "装备挑战：墨镜",
	Character = 223128,
	Desc = "不喜欢划龙舟时被太阳照射，于是每次上船时都会带上一副黑色墨镜。",
	RewardUnlock = 340684,
	ResultText = "桨手二号的墨镜解锁了",
	NumCap = 3,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG01",
	StartScene = "ARENA_StartScene",
	TeamCondition = {
		{
			Condition = "NeedTagOr",
			Value = 
			{
				560110,
			},
			Desc = "必须是星际流民的队员",
			Hint = "必须是星际流民的队员",
		},
	},
	Enemy = {
		{
			Value = 245272,
			Level = 28,
		},
	},
}
ChallengeConfig[ChallengeID.Id5269] =
{
	Id = 5269,
	Name = "装备挑战：饭盒",
	Character = 223129,
	Desc = "热气腾腾的饭盒，据说里面装着龙舟饭和龙舟面。\n不吃饱，哪来的力气干活呢？",
	RewardUnlock = 340687,
	ResultText = "龙尾小弟的饭盒解锁了",
	NumCap = 3,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG01",
	StartScene = "ARENA_StartScene",
	TeamCondition = {
		{
			Condition = "NeedTagOr",
			Value = 
			{
				560110,
			},
			Desc = "必须是星际流民的队员",
			Hint = "必须是星际流民的队员",
		},
	},
	Enemy = {
		{
			Value = 245273,
			Level = 28,
		},
	},
}
ChallengeConfig[ChallengeID.Id5270] =
{
	Id = 5270,
	Name = "装备挑战：服装店工牌",
	Character = 223130,
	Desc = "服装店员工的证明，只有带上工牌刷卡，才能在店中的各个房间穿梭自如。",
	RewardUnlock = 340690,
	ResultText = "牵牛的服装店工牌解锁了",
	NumCap = 3,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG01",
	StartScene = "ARENA_StartScene",
	TeamCondition = {
		{
			Condition = "NeedTagOr",
			Value = 
			{
				560110,
			},
			Desc = "必须是星际流民的队员",
			Hint = "必须是星际流民的队员",
		},
	},
	Enemy = {
		{
			Value = 245274,
			Level = 28,
		},
	},
}
ChallengeConfig[ChallengeID.Id5271] =
{
	Id = 5271,
	Name = "装备挑战：红色三角巾",
	Character = 223131,
	Desc = "方块领结的备用品，当领结上沾上了墨水或油渍，就是红色三角巾出场的时刻了。",
	RewardUnlock = 340693,
	ResultText = "一心的红色三角巾解锁了",
	NumCap = 3,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG01",
	StartScene = "ARENA_StartScene",
	TeamCondition = {
		{
			Condition = "NeedTagOr",
			Value = 
			{
				560110,
			},
			Desc = "必须是星际流民的队员",
			Hint = "必须是星际流民的队员",
		},
	},
	Enemy = {
		{
			Value = 245275,
			Level = 36,
		},
	},
}
ChallengeConfig[ChallengeID.Id5272] =
{
	Id = 5272,
	Name = "装备挑战：调焦手电筒",
	Character = 223132,
	Desc = "虽然只是一把普通的调焦手电，但据说可以为摄影带来光照上的大改变。",
	RewardUnlock = 340696,
	ResultText = "二橘的调焦手电筒解锁了",
	NumCap = 3,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG01",
	StartScene = "ARENA_StartScene",
	TeamCondition = {
		{
			Condition = "NeedTagOr",
			Value = 
			{
				560110,
			},
			Desc = "必须是星际流民的队员",
			Hint = "必须是星际流民的队员",
		},
	},
	Enemy = {
		{
			Value = 245276,
			Level = 36,
		},
	},
}
ChallengeConfig[ChallengeID.Id5273] =
{
	Id = 5273,
	Name = "装备挑战：棕黄眼影盘",
	Character = 223133,
	Desc = "在看到网络主播教学“猫眼化妆术”后，三花买了主播推荐的眼影盘，并对猫眼的画法进行了深度学习。",
	RewardUnlock = 340699,
	ResultText = "三花的棕黄眼影盘解锁了",
	NumCap = 3,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG01",
	StartScene = "ARENA_StartScene",
	TeamCondition = {
		{
			Condition = "NeedTagOr",
			Value = 
			{
				560110,
			},
			Desc = "必须是星际流民的队员",
			Hint = "必须是星际流民的队员",
		},
	},
	Enemy = {
		{
			Value = 245277,
			Level = 36,
		},
	},
}
ChallengeConfig[ChallengeID.Id5274] =
{
	Id = 5274,
	Name = "装备挑战：假蜘蛛",
	Character = 223134,
	Desc = "整蛊姐妹的必备道具，屡试不爽，不过总是被受到惊吓的姐妹们扔掉，这已经是四荔买的第284个蜘蛛了。",
	RewardUnlock = 340702,
	ResultText = "四荔的假蜘蛛解锁了",
	NumCap = 3,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG01",
	StartScene = "ARENA_StartScene",
	TeamCondition = {
		{
			Condition = "NeedTagOr",
			Value = 
			{
				560110,
			},
			Desc = "必须是星际流民的队员",
			Hint = "必须是星际流民的队员",
		},
	},
	Enemy = {
		{
			Value = 245278,
			Level = 36,
		},
	},
}
ChallengeConfig[ChallengeID.Id5275] =
{
	Id = 5275,
	Name = "装备挑战：公文包",
	Character = 223135,
	Desc = "和其他侦探一样，五行也有一个公文包，唯一区别是，其他侦探携带的是文件和证据，而五行的包里只有文具和作业。",
	RewardUnlock = 340705,
	ResultText = "五行的公文包解锁了",
	NumCap = 3,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG01",
	StartScene = "ARENA_StartScene",
	TeamCondition = {
		{
			Condition = "NeedTagOr",
			Value = 
			{
				560110,
			},
			Desc = "必须是星际流民的队员",
			Hint = "必须是星际流民的队员",
		},
	},
	Enemy = {
		{
			Value = 245279,
			Level = 28,
		},
	},
}
ChallengeConfig[ChallengeID.Id5276] =
{
	Id = 5276,
	Name = "装备挑战：玉佛吊坠",
	Character = 223136,
	Desc = "小时候收到的礼物，被家人要求一直戴着，据说找大师开过光，可以保佑自己平安顺遂。",
	RewardUnlock = 340708,
	ResultText = "六瑶的玉佛吊坠解锁了",
	NumCap = 3,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG01",
	StartScene = "ARENA_StartScene",
	TeamCondition = {
		{
			Condition = "NeedTagOr",
			Value = 
			{
				560110,
			},
			Desc = "必须是星际流民的队员",
			Hint = "必须是星际流民的队员",
		},
	},
	Enemy = {
		{
			Value = 245280,
			Level = 28,
		},
	},
}
ChallengeConfig[ChallengeID.Id5277] =
{
	Id = 5277,
	Name = "装备挑战：棒针",
	Character = 223137,
	Desc = "运用各种针法技巧，能够创造出各种精美的纺织品，七织对此颇有研究。",
	RewardUnlock = 340711,
	ResultText = "七织的棒针解锁了",
	NumCap = 3,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG01",
	StartScene = "ARENA_StartScene",
	TeamCondition = {
		{
			Condition = "NeedTagOr",
			Value = 
			{
				560110,
			},
			Desc = "必须是星际流民的队员",
			Hint = "必须是星际流民的队员",
		},
	},
	Enemy = {
		{
			Value = 245281,
			Level = 28,
		},
	},
}
ChallengeConfig[ChallengeID.Id5278] =
{
	Id = 5278,
	Name = "装备挑战：红线",
	Character = 223138,
	Desc = "据说被牵上红线的两人，会对对方产生好感，但真相是，红线本身并没有魔力，“好感”只来源于心理暗示而已。",
	RewardUnlock = 340714,
	ResultText = "月佬的红线解锁了",
	NumCap = 3,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG01",
	StartScene = "ARENA_StartScene",
	TeamCondition = {
		{
			Condition = "NeedTagOr",
			Value = 
			{
				560110,
			},
			Desc = "必须是星际流民的队员",
			Hint = "必须是星际流民的队员",
		},
	},
	Enemy = {
		{
			Value = 245282,
			Level = 44,
		},
	},
}
ChallengeConfig[ChallengeID.Id5279] =
{
	Id = 5279,
	Name = "装备挑战：姻缘簿",
	Character = 223138,
	Desc = "被月佬凑成一对的人，会被他开心地记录在姻缘簿上，待到二人分手后，他们的名字会被划掉。",
	RewardUnlock = 340715,
	ResultText = "月佬的姻缘簿解锁了",
	NumCap = 3,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG01",
	StartScene = "ARENA_StartScene",
	TeamCondition = {
		{
			Condition = "NeedTagOr",
			Value = 
			{
				560110,
			},
			Desc = "必须是星际流民的队员",
			Hint = "必须是星际流民的队员",
		},
	},
	Enemy = {
		{
			Value = 245283,
			Level = 60,
		},
	},
}
ChallengeConfig[ChallengeID.Id5280] =
{
	Id = 5280,
	Name = "装备挑战：罗盘",
	Character = 221007,
	Desc = "酋长妹妹从家乡带来的道具，据说根据自己的玄学知识正确使用后，可以触发一些神奇的事件。",
	RewardUnlock = 340718,
	ResultText = "酋长妹妹的罗盘解锁了",
	NumCap = 3,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG01",
	StartScene = "ARENA_StartScene",
	TeamCondition = {
		{
			Condition = "NeedTagOr",
			Value = 
			{
				560110,
			},
			Desc = "必须是星际流民的队员",
			Hint = "必须是星际流民的队员",
		},
	},
	Enemy = {
		{
			Value = 245284,
			Level = 28,
		},
	},
}
ChallengeConfig[ChallengeID.Id5281] =
{
	Id = 5281,
	Name = "装备挑战：邮包",
	Character = 223139,
	Desc = "干净的方形邮包，里面装着大大小小的信件，和漂泊者沉甸甸的思乡之心。",
	RewardUnlock = 340721,
	ResultText = "团圆圆的邮包解锁了",
	NumCap = 3,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG01",
	StartScene = "ARENA_StartScene",
	TeamCondition = {
		{
			Condition = "NeedTagOr",
			Value = 
			{
				560110,
			},
			Desc = "必须是星际流民的队员",
			Hint = "必须是星际流民的队员",
		},
	},
	Enemy = {
		{
			Value = 245285,
			Level = 28,
		},
	},
}
ChallengeConfig[ChallengeID.Id5282] =
{
	Id = 5282,
	Name = "装备挑战：乌头草标本",
	Character = 223140,
	Desc = "第一次变成狼时候，迪斯科野狼在狂暴之下，踩碎了盛开的乌头草。他把乌头草做成标本，作为自己变狼的纪念。",
	RewardUnlock = 340724,
	ResultText = "迪斯科野狼的乌头草标本解锁了",
	NumCap = 3,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG01",
	StartScene = "ARENA_StartScene",
	TeamCondition = {
		{
			Condition = "NeedTagOr",
			Value = 
			{
				560110,
			},
			Desc = "必须是星际流民的队员",
			Hint = "必须是星际流民的队员",
		},
	},
	Enemy = {
		{
			Value = 245286,
			Level = 36,
		},
	},
}
ChallengeConfig[ChallengeID.Id5283] =
{
	Id = 5283,
	Name = "装备挑战：风雪扇",
	Character = 223141,
	Desc = "可以控制风雪的器具。只需打开扇子，山上将立刻风雪大作；相反，将扇子合上，风雪便会停息。",
	RewardUnlock = 340727,
	ResultText = "雪神的风雪扇解锁了",
	NumCap = 3,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG01",
	StartScene = "ARENA_StartScene",
	TeamCondition = {
		{
			Condition = "NeedTagOr",
			Value = 
			{
				560110,
			},
			Desc = "必须是星际流民的队员",
			Hint = "必须是星际流民的队员",
		},
	},
	Enemy = {
		{
			Value = 245287,
			Level = 44,
		},
	},
}
ChallengeConfig[ChallengeID.Id5284] =
{
	Id = 5284,
	Name = "装备挑战：蓝色蝴蝶",
	Character = 223141,
	Desc = "蓝色的蝴蝶，常在冰雪中飞舞盘旋，象征着残酷冰雪下却生机勃勃的顽强生命。",
	RewardUnlock = 340728,
	ResultText = "雪神的蓝色蝴蝶解锁了",
	NumCap = 3,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG01",
	StartScene = "ARENA_StartScene",
	TeamCondition = {
		{
			Condition = "NeedTagOr",
			Value = 
			{
				560110,
			},
			Desc = "必须是星际流民的队员",
			Hint = "必须是星际流民的队员",
		},
	},
	Enemy = {
		{
			Value = 245288,
			Level = 60,
		},
	},
}
ChallengeConfig[ChallengeID.Id5285] =
{
	Id = 5285,
	Name = "装备挑战：发圈收纳盒",
	Character = 223142,
	Desc = "放在房间中的收纳盒，里面装满了各种各样的发圈，不过这些发圈总会莫名其妙消失。",
	RewardUnlock = 340731,
	ResultText = "猫眼厨娘的发圈收纳盒解锁了",
	NumCap = 3,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG01",
	StartScene = "ARENA_StartScene",
	TeamCondition = {
		{
			Condition = "NeedTagOr",
			Value = 
			{
				560110,
			},
			Desc = "必须是星际流民的队员",
			Hint = "必须是星际流民的队员",
		},
	},
	Enemy = {
		{
			Value = 245289,
			Level = 44,
		},
	},
}
ChallengeConfig[ChallengeID.Id5286] =
{
	Id = 5286,
	Name = "装备挑战：鎏金高脚杯",
	Character = 223142,
	Desc = "一看就知不同凡响的高脚杯，是第二十八届酒酿厨艺大赛冠军的奖品。\n据说获胜的菜品名为：酒酿豆腐圆子。",
	RewardUnlock = 340732,
	ResultText = "猫眼厨娘的鎏金高脚杯解锁了",
	NumCap = 3,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG01",
	StartScene = "ARENA_StartScene",
	TeamCondition = {
		{
			Condition = "NeedTagOr",
			Value = 
			{
				560110,
			},
			Desc = "必须是星际流民的队员",
			Hint = "必须是星际流民的队员",
		},
	},
	Enemy = {
		{
			Value = 245290,
			Level = 60,
		},
	},
}
ChallengeConfig[ChallengeID.Id5287] =
{
	Id = 5287,
	Name = "装备挑战：特制搓澡巾",
	Character = 223143,
	Desc = "据说可以把身上所有死皮全部搓下来的特制搓澡巾，会有疼痛，但也很享受。\n不是每一个人都能从它身上获得快乐。",
	RewardUnlock = 340735,
	ResultText = "温泉鉴赏家的特制搓澡巾解锁了",
	NumCap = 3,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG01",
	StartScene = "ARENA_StartScene",
	TeamCondition = {
		{
			Condition = "NeedTagOr",
			Value = 
			{
				560110,
			},
			Desc = "必须是星际流民的队员",
			Hint = "必须是星际流民的队员",
		},
	},
	Enemy = {
		{
			Value = 245291,
			Level = 36,
		},
	},
}
ChallengeConfig[ChallengeID.Id5288] =
{
	Id = 5288,
	Name = "装备挑战：好爸爸奶瓶",
	Character = 223144,
	Desc = "“好爸爸”牌奶瓶，奶瓶上画着一个壮硕的肌肉猛男父亲，和一个崇拜他的小婴儿。",
	RewardUnlock = 340738,
	ResultText = "健身教练的好爸爸奶瓶解锁了",
	NumCap = 3,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG01",
	StartScene = "ARENA_StartScene",
	TeamCondition = {
		{
			Condition = "NeedTagOr",
			Value = 
			{
				560110,
			},
			Desc = "必须是星际流民的队员",
			Hint = "必须是星际流民的队员",
		},
	},
	Enemy = {
		{
			Value = 245292,
			Level = 36,
		},
	},
}
ChallengeConfig[ChallengeID.Id5289] =
{
	Id = 5289,
	Name = "装备挑战：小熊雕像",
	Character = 223145,
	Desc = "断耳熊的朋友们以她为原型，雕刻出的镂空小金人。栩栩如生，让断耳熊爱不释手。",
	RewardUnlock = 340741,
	ResultText = "断耳熊的小熊雕像解锁了",
	NumCap = 3,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG01",
	StartScene = "ARENA_StartScene",
	TeamCondition = {
		{
			Condition = "NeedTagOr",
			Value = 
			{
				560110,
			},
			Desc = "必须是星际流民的队员",
			Hint = "必须是星际流民的队员",
		},
	},
	Enemy = {
		{
			Value = 245293,
			Level = 28,
		},
	},
}
ChallengeConfig[ChallengeID.Id5290] =
{
	Id = 5290,
	Name = "装备挑战：高倍速猎枪",
	Character = 223146,
	Desc = "发射子弹速度极快的猎枪，据生产商家表示，设计速度是火枪手武器的0.25倍。",
	RewardUnlock = 340744,
	ResultText = "雪中猎人的高倍速猎枪解锁了",
	NumCap = 3,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG01",
	StartScene = "ARENA_StartScene",
	TeamCondition = {
		{
			Condition = "NeedTagOr",
			Value = 
			{
				560110,
			},
			Desc = "必须是星际流民的队员",
			Hint = "必须是星际流民的队员",
		},
	},
	Enemy = {
		{
			Value = 245294,
			Level = 36,
		},
	},
}
ChallengeConfig[ChallengeID.Id5291] =
{
	Id = 5291,
	Name = "装备挑战：危险的刀片",
	Character = 223147,
	Desc = "粉丝寄来的礼物，寄来时被放在粉色礼品盒中，还有一张贺卡：\n作者大大，我要给你寄刀片！\n危险行为，请勿模仿。",
	RewardUnlock = 340747,
	ResultText = "编剧妹子的危险的刀片解锁了",
	NumCap = 3,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG01",
	StartScene = "ARENA_StartScene",
	TeamCondition = {
		{
			Condition = "NeedTagOr",
			Value = 
			{
				560110,
			},
			Desc = "必须是星际流民的队员",
			Hint = "必须是星际流民的队员",
		},
	},
	Enemy = {
		{
			Value = 245295,
			Level = 36,
		},
	},
}
ChallengeConfig[ChallengeID.Id5292] =
{
	Id = 5292,
	Name = "装备挑战：方格围巾",
	Character = 223148,
	Desc = "思诺曼一定要戴上的东西，据他所说，如果自己不戴围巾，在视觉上就和裸体出门无异，有伤风化。",
	RewardUnlock = 340750,
	ResultText = "思诺曼的方格围巾解锁了",
	NumCap = 3,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG01",
	StartScene = "ARENA_StartScene",
	TeamCondition = {
		{
			Condition = "NeedTagOr",
			Value = 
			{
				560110,
			},
			Desc = "必须是星际流民的队员",
			Hint = "必须是星际流民的队员",
		},
	},
	Enemy = {
		{
			Value = 245296,
			Level = 28,
		},
	},
}
