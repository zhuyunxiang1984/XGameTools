SummonConfig ={};
SummonID = 
{
	Id001 = 500001,
	Id002 = 500002,
	Id003 = 500003,
	Id004 = 500004,
	Id005 = 500005,
	Id006 = 500006,
	Id007 = 500007,
	Id008 = 500008,
	Id009 = 500009,
}
require "FreakPlanet/Design/SummonConfig_1"
require "FreakPlanet/Design/SummonConfig_2"
require "FreakPlanet/Design/SummonConfig_3"
require "FreakPlanet/Design/SummonConfig_4"
require "FreakPlanet/Design/SummonConfig_5"
require "FreakPlanet/Design/SummonConfig_6"
require "FreakPlanet/Design/SummonConfig_7"
require "FreakPlanet/Design/SummonConfig_8"
require "FreakPlanet/Design/SummonConfig_9"

