MapAvatarConfig ={};
MapAvatarConfig["RPG_map_01_node_01"] =
{
	Weight = 20,
}
MapAvatarConfig["RPG_map_01_node_02"] =
{
	PreCondition = {
		ExploreRequire = {
			Value = 130001,
			ExploreTime = 30,
		},
	},
	Weight = 20,
}
MapAvatarConfig["RPG_map_02_node_01"] =
{
	PreCondition = {
		PreChallengeList = {
			140001,
		},
		ExploreRequire = {
			Value = 130002,
			ExploreTime = 120,
		},
	},
	Weight = 20,
}
MapAvatarConfig["RPG_map_02_node_02"] =
{
	PreCondition = {
		PreChallengeList = {
			140002,
		},
		ExploreRequire = {
			Value = 130002,
			ExploreTime = 300,
		},
	},
	Weight = 20,
}
MapAvatarConfig["RPG_map_02_node_03"] =
{
	PreCondition = {
		PreChallengeList = {
			140003,
		},
		ExploreRequire = {
			Value = 130002,
			ExploreTime = 480,
		},
	},
	Weight = 20,
}
MapAvatarConfig["RPG_map_02_node_sp01"] =
{
	PreCondition = {
		PreGoalList = {
			300335,
		},
		ExploreRequire = {
			Value = 130002,
			ExploreTime = 0,
		},
	},
	Weight = 20,
}
MapAvatarConfig["RPG_map_03_node_01"] =
{
	PreCondition = {
		PreChallengeList = {
			140005,
		},
		ExploreRequire = {
			Value = 130003,
			ExploreTime = 600,
		},
	},
	Weight = 20,
}
MapAvatarConfig["RPG_map_03_node_02"] =
{
	PreCondition = {
		PreChallengeList = {
			140006,
		},
		ExploreRequire = {
			Value = 130003,
			ExploreTime = 1200,
		},
	},
	Weight = 20,
}
MapAvatarConfig["RPG_map_03_node_03"] =
{
	PreCondition = {
		PreChallengeList = {
			140007,
		},
		ExploreRequire = {
			Value = 130003,
			ExploreTime = 2100,
		},
	},
	Weight = 20,
}
MapAvatarConfig["RPG_map_03_node_04"] =
{
	PreCondition = {
		PreChallengeList = {
			140007,
		},
		ExploreRequire = {
			Value = 130003,
			ExploreTime = 900,
		},
	},
	Weight = 20,
}
MapAvatarConfig["RPG_map_03_node_sp01"] =
{
	PreCondition = {
		PreGoalList = {
			300336,
		},
		ExploreRequire = {
			Value = 130003,
			ExploreTime = 0,
		},
	},
	Weight = 20,
}
MapAvatarConfig["RPG_map_04_node_01"] =
{
	PreCondition = {
		PreChallengeList = {
			140008,
		},
		ExploreRequire = {
			Value = 130004,
			ExploreTime = 1200,
		},
	},
	Weight = 20,
}
MapAvatarConfig["RPG_map_04_node_02"] =
{
	PreCondition = {
		PreChallengeList = {
			140009,
		},
		ExploreRequire = {
			Value = 130004,
			ExploreTime = 3000,
		},
	},
	Weight = 20,
}
MapAvatarConfig["RPG_map_04_node_03"] =
{
	PreCondition = {
		PreChallengeList = {
			140010,
		},
		ExploreRequire = {
			Value = 130004,
			ExploreTime = 6600,
		},
	},
	Weight = 20,
}
MapAvatarConfig["RPG_map_04_node_sp01"] =
{
	PreCondition = {
		PreGoalList = {
			300337,
		},
		ExploreRequire = {
			Value = 130004,
			ExploreTime = 0,
		},
	},
	Weight = 20,
}
MapAvatarConfig["RPG_map_05_node_01"] =
{
	PreCondition = {
		PreChallengeList = {
			140011,
		},
		ExploreRequire = {
			Value = 130005,
			ExploreTime = 1800,
		},
	},
	Weight = 20,
}
MapAvatarConfig["RPG_map_05_node_02"] =
{
	PreCondition = {
		PreChallengeList = {
			140012,
		},
		ExploreRequire = {
			Value = 130005,
			ExploreTime = 5400,
		},
	},
	Weight = 20,
}
MapAvatarConfig["RPG_map_05_node_03"] =
{
	PreCondition = {
		PreChallengeList = {
			140013,
		},
		ExploreRequire = {
			Value = 130005,
			ExploreTime = 9000,
		},
	},
	Weight = 20,
}
MapAvatarConfig["RPG_map_05_node_sp01"] =
{
	PreCondition = {
		PreGoalList = {
			300338,
		},
		ExploreRequire = {
			Value = 130005,
			ExploreTime = 0,
		},
	},
	Weight = 20,
}
MapAvatarConfig["RPG_map_06_node_01"] =
{
	PreCondition = {
		PreChallengeList = {
			140015,
		},
		ExploreRequire = {
			Value = 130006,
			ExploreTime = 7200,
		},
	},
	Weight = 20,
}
MapAvatarConfig["RPG_map_06_node_02"] =
{
	PreCondition = {
		PreChallengeList = {
			140016,
		},
		ExploreRequire = {
			Value = 130006,
			ExploreTime = 14400,
		},
	},
	Weight = 20,
}
MapAvatarConfig["RPG_map_06_node_03"] =
{
	PreCondition = {
		PreChallengeList = {
			140017,
		},
		ExploreRequire = {
			Value = 130006,
			ExploreTime = 28800,
		},
	},
	Weight = 20,
}
MapAvatarConfig["RPG_map_06_node_sp01"] =
{
	PreCondition = {
		PreGoalList = {
			300339,
		},
		ExploreRequire = {
			Value = 130006,
			ExploreTime = 0,
		},
	},
	Weight = 20,
}
MapAvatarConfig["RPG_map_07_node_01"] =
{
	PreCondition = {
		PreChallengeList = {
			140018,
		},
		ExploreRequire = {
			Value = 130007,
			ExploreTime = 7200,
		},
	},
	Weight = 20,
}
MapAvatarConfig["RPG_map_07_node_02"] =
{
	PreCondition = {
		PreChallengeList = {
			140019,
		},
		ExploreRequire = {
			Value = 130007,
			ExploreTime = 21600,
		},
	},
	Weight = 20,
}
MapAvatarConfig["RPG_map_07_node_03"] =
{
	PreCondition = {
		PreChallengeList = {
			140020,
		},
		ExploreRequire = {
			Value = 130007,
			ExploreTime = 36000,
		},
	},
	Weight = 20,
}
MapAvatarConfig["RPG_map_07_node_sp01"] =
{
	PreCondition = {
		PreGoalList = {
			300340,
		},
		ExploreRequire = {
			Value = 130007,
			ExploreTime = 0,
		},
	},
	Weight = 20,
}
MapAvatarConfig["RPG_map_08_node_01"] =
{
	PreCondition = {
		PreChallengeList = {
			140023,
		},
		ExploreRequire = {
			Value = 130008,
			ExploreTime = 43200,
		},
	},
	Weight = 20,
}
MapAvatarConfig["RPG_map_08_node_02"] =
{
	PreCondition = {
		PreChallengeList = {
			140024,
		},
		ExploreRequire = {
			Value = 130008,
			ExploreTime = 129600,
		},
	},
	Weight = 20,
}
MapAvatarConfig["RPG_map_08_node_03"] =
{
	PreCondition = {
		PreChallengeList = {
			140024,
		},
		ExploreRequire = {
			Value = 130008,
			ExploreTime = 86400,
		},
	},
	Weight = 20,
}
MapAvatarConfig["RPG_map_08_node_sp01"] =
{
	PreCondition = {
		PreGoalList = {
			300341,
		},
		ExploreRequire = {
			Value = 130008,
			ExploreTime = 0,
		},
	},
	Weight = 20,
}
MapAvatarConfig["RPG_map_09_node_01"] =
{
	PreCondition = {
		PreChallengeList = {
			140025,
		},
		ExploreRequire = {
			Value = 130009,
			ExploreTime = 14400,
		},
	},
	Weight = 20,
}
MapAvatarConfig["RPG_map_09_node_02"] =
{
	PreCondition = {
		PreChallengeList = {
			140026,
		},
		ExploreRequire = {
			Value = 130009,
			ExploreTime = 43200,
		},
	},
	Weight = 20,
}
MapAvatarConfig["RPG_map_09_node_03"] =
{
	PreCondition = {
		PreChallengeList = {
			140027,
		},
		ExploreRequire = {
			Value = 130009,
			ExploreTime = 86400,
		},
	},
	Weight = 20,
}
MapAvatarConfig["RPG_map_09_node_sp01"] =
{
	PreCondition = {
		PreGoalList = {
			300342,
		},
		ExploreRequire = {
			Value = 130009,
			ExploreTime = 0,
		},
	},
	Weight = 20,
}
MapAvatarConfig["RPG_map_10_node_01"] =
{
	PreCondition = {
		PreChallengeList = {
			140029,
		},
		ExploreRequire = {
			Value = 130010,
			ExploreTime = 28800,
		},
	},
	Weight = 20,
}
MapAvatarConfig["RPG_map_10_node_02"] =
{
	PreCondition = {
		PreChallengeList = {
			140030,
		},
		ExploreRequire = {
			Value = 130010,
			ExploreTime = 57600,
		},
	},
	Weight = 20,
}
MapAvatarConfig["RPG_map_10_node_03"] =
{
	PreCondition = {
		PreChallengeList = {
			140031,
		},
		ExploreRequire = {
			Value = 130010,
			ExploreTime = 100800,
		},
	},
	Weight = 20,
}
MapAvatarConfig["RPG_map_10_node_04"] =
{
	PreCondition = {
		PreChallengeList = {
			140032,
		},
		ExploreRequire = {
			Value = 130010,
			ExploreTime = 187200,
		},
	},
	Weight = 20,
}
MapAvatarConfig["RPG_map_10_node_sp01"] =
{
	PreCondition = {
		PreGoalList = {
			300343,
		},
		ExploreRequire = {
			Value = 130010,
			ExploreTime = 0,
		},
	},
	Weight = 20,
}
MapAvatarConfig["RPG_map_10_node_sp02"] =
{
	PreCondition = {
		PreGoalList = {
			300344,
		},
		ExploreRequire = {
			Value = 130010,
			ExploreTime = 0,
		},
	},
	Weight = 20,
}
MapAvatarConfig["RPG_map_11_node_01"] =
{
	PreCondition = {
		PreChallengeList = {
			140033,
		},
		ExploreRequire = {
			Value = 130011,
			ExploreTime = 43200,
		},
	},
	Weight = 20,
}
MapAvatarConfig["RPG_map_11_node_02"] =
{
	PreCondition = {
		PreChallengeList = {
			140034,
		},
		ExploreRequire = {
			Value = 130011,
			ExploreTime = 172800,
		},
	},
	Weight = 20,
}
MapAvatarConfig["RPG_map_11_node_sp01"] =
{
	PreCondition = {
		PreGoalList = {
			300345,
		},
		ExploreRequire = {
			Value = 130011,
			ExploreTime = 0,
		},
	},
	Weight = 20,
}
MapAvatarConfig["FAT_map_01_node_01"] =
{
	PreCondition = {
		PreChallengeList = {
			140201,
		},
		ExploreRequire = {
			Value = 130051,
			ExploreTime = 1800,
		},
	},
	Weight = 20,
}
MapAvatarConfig["FAT_map_02_node_01"] =
{
	PreCondition = {
		PreChallengeList = {
			140202,
		},
		ExploreRequire = {
			Value = 130052,
			ExploreTime = 28800,
		},
	},
	Weight = 20,
}
MapAvatarConfig["FAT_map_02_node_02"] =
{
	PreCondition = {
		PreChallengeList = {
			140203,
		},
		ExploreRequire = {
			Value = 130052,
			ExploreTime = 57600,
		},
	},
	Weight = 20,
}
MapAvatarConfig["FAT_map_02_node_03"] =
{
	PreCondition = {
		PreChallengeList = {
			140203,
		},
		ExploreRequire = {
			Value = 130052,
			ExploreTime = 28800,
		},
	},
	Weight = 20,
}
MapAvatarConfig["FAT_map_02_node_sp01"] =
{
	PreCondition = {
		PreGoalList = {
			300744,
		},
		ExploreRequire = {
			Value = 130052,
			ExploreTime = 0,
		},
	},
	Weight = 20,
}
MapAvatarConfig["FAT_map_03_node_01"] =
{
	PreCondition = {
		PreChallengeList = {
			140204,
		},
		ExploreRequire = {
			Value = 130053,
			ExploreTime = 43200,
		},
	},
	Weight = 20,
}
MapAvatarConfig["FAT_map_03_node_02"] =
{
	PreCondition = {
		PreChallengeList = {
			140205,
		},
		ExploreRequire = {
			Value = 130053,
			ExploreTime = 86400,
		},
	},
	Weight = 20,
}
MapAvatarConfig["FAT_map_03_node_03"] =
{
	PreCondition = {
		PreChallengeList = {
			140206,
		},
		ExploreRequire = {
			Value = 130053,
			ExploreTime = 129600,
		},
	},
	Weight = 20,
}
MapAvatarConfig["FAT_map_03_node_04"] =
{
	PreCondition = {
		PreChallengeList = {
			140207,
		},
		ExploreRequire = {
			Value = 130053,
			ExploreTime = 194400,
		},
	},
	Weight = 20,
}
MapAvatarConfig["FAT_map_03_node_sp01"] =
{
	PreCondition = {
		PreGoalList = {
			300745,
		},
		ExploreRequire = {
			Value = 130053,
			ExploreTime = 0,
		},
	},
	Weight = 20,
}
MapAvatarConfig["FAT_map_04_node_01"] =
{
	PreCondition = {
		PreChallengeList = {
			140208,
		},
		ExploreRequire = {
			Value = 130054,
			ExploreTime = 28800,
		},
	},
	Weight = 20,
}
MapAvatarConfig["FAT_map_04_node_02"] =
{
	PreCondition = {
		PreChallengeList = {
			140209,
		},
		ExploreRequire = {
			Value = 130054,
			ExploreTime = 57600,
		},
	},
	Weight = 20,
}
MapAvatarConfig["FAT_map_04_node_03"] =
{
	PreCondition = {
		PreChallengeList = {
			140210,
		},
		ExploreRequire = {
			Value = 130054,
			ExploreTime = 100800,
		},
	},
	Weight = 20,
}
MapAvatarConfig["FAT_map_04_node_04"] =
{
	PreCondition = {
		PreChallengeList = {
			140210,
		},
		ExploreRequire = {
			Value = 130054,
			ExploreTime = 43200,
		},
	},
	Weight = 20,
}
MapAvatarConfig["FAT_map_04_node_sp01"] =
{
	PreCondition = {
		PreGoalList = {
			300746,
		},
		ExploreRequire = {
			Value = 130054,
			ExploreTime = 0,
		},
	},
	Weight = 20,
}
MapAvatarConfig["FAT_map_05_node_01"] =
{
	PreCondition = {
		PreChallengeList = {
			140211,
		},
		ExploreRequire = {
			Value = 130055,
			ExploreTime = 43200,
		},
	},
	Weight = 20,
}
MapAvatarConfig["FAT_map_05_node_02"] =
{
	PreCondition = {
		PreChallengeList = {
			140212,
		},
		ExploreRequire = {
			Value = 130055,
			ExploreTime = 86400,
		},
	},
	Weight = 20,
}
MapAvatarConfig["FAT_map_05_node_03"] =
{
	PreCondition = {
		PreChallengeList = {
			140213,
		},
		ExploreRequire = {
			Value = 130055,
			ExploreTime = 129600,
		},
	},
	Weight = 20,
}
MapAvatarConfig["FAT_map_05_node_sp01"] =
{
	PreCondition = {
		PreGoalList = {
			300747,
		},
		ExploreRequire = {
			Value = 130055,
			ExploreTime = 0,
		},
	},
	Weight = 20,
}
MapAvatarConfig["FAT_map_06_node_01"] =
{
	PreCondition = {
		PreChallengeList = {
			140215,
		},
		ExploreRequire = {
			Value = 130056,
			ExploreTime = 43200,
		},
	},
	Weight = 20,
}
MapAvatarConfig["FAT_map_06_node_02"] =
{
	PreCondition = {
		PreChallengeList = {
			140216,
		},
		ExploreRequire = {
			Value = 130056,
			ExploreTime = 86400,
		},
	},
	Weight = 20,
}
MapAvatarConfig["FAT_map_06_node_03"] =
{
	PreCondition = {
		PreChallengeList = {
			140217,
		},
		ExploreRequire = {
			Value = 130056,
			ExploreTime = 151200,
		},
	},
	Weight = 20,
}
MapAvatarConfig["FAT_map_06_node_sp01"] =
{
	PreCondition = {
		PreGoalList = {
			300748,
		},
		ExploreRequire = {
			Value = 130056,
			ExploreTime = 0,
		},
	},
	Weight = 20,
}
MapAvatarConfig["FAT_map_07_node_01"] =
{
	PreCondition = {
		PreChallengeList = {
			140219,
		},
		ExploreRequire = {
			Value = 130057,
			ExploreTime = 43200,
		},
	},
	Weight = 20,
}
MapAvatarConfig["FAT_map_07_node_02"] =
{
	PreCondition = {
		PreChallengeList = {
			140220,
		},
		ExploreRequire = {
			Value = 130057,
			ExploreTime = 86400,
		},
	},
	Weight = 20,
}
MapAvatarConfig["FAT_map_07_node_03"] =
{
	PreCondition = {
		PreChallengeList = {
			140221,
		},
		ExploreRequire = {
			Value = 130057,
			ExploreTime = 129600,
		},
	},
	Weight = 20,
}
MapAvatarConfig["FAT_map_07_node_sp01"] =
{
	PreCondition = {
		PreGoalList = {
			300749,
		},
		ExploreRequire = {
			Value = 130057,
			ExploreTime = 0,
		},
	},
	Weight = 20,
}
MapAvatarConfig["FAT_map_08_node_01"] =
{
	PreCondition = {
		PreChallengeList = {
			140224,
		},
		ExploreRequire = {
			Value = 130058,
			ExploreTime = 50400,
		},
	},
	Weight = 20,
}
MapAvatarConfig["FAT_map_08_node_02"] =
{
	PreCondition = {
		PreChallengeList = {
			140225,
		},
		ExploreRequire = {
			Value = 130058,
			ExploreTime = 100800,
		},
	},
	Weight = 20,
}
MapAvatarConfig["FAT_map_08_node_03"] =
{
	PreCondition = {
		PreChallengeList = {
			140226,
		},
		ExploreRequire = {
			Value = 130058,
			ExploreTime = 172800,
		},
	},
	Weight = 20,
}
MapAvatarConfig["FAT_map_08_node_sp01"] =
{
	PreCondition = {
		PreGoalList = {
			300750,
		},
		ExploreRequire = {
			Value = 130058,
			ExploreTime = 0,
		},
	},
	Weight = 20,
}
MapAvatarConfig["FAT_map_09_node_01"] =
{
	PreCondition = {
		PreChallengeList = {
			140227,
		},
		ExploreRequire = {
			Value = 130059,
			ExploreTime = 57600,
		},
	},
	Weight = 20,
}
MapAvatarConfig["FAT_map_09_node_02"] =
{
	PreCondition = {
		PreChallengeList = {
			140228,
		},
		ExploreRequire = {
			Value = 130059,
			ExploreTime = 115200,
		},
	},
	Weight = 20,
}
MapAvatarConfig["FAT_map_09_node_03"] =
{
	PreCondition = {
		PreChallengeList = {
			140229,
		},
		ExploreRequire = {
			Value = 130059,
			ExploreTime = 172800,
		},
	},
	Weight = 20,
}
MapAvatarConfig["FAT_map_09_node_sp01"] =
{
	PreCondition = {
		PreGoalList = {
			300751,
		},
		ExploreRequire = {
			Value = 130059,
			ExploreTime = 0,
		},
	},
	Weight = 20,
}
MapAvatarConfig["FAT_map_10_node_01"] =
{
	PreCondition = {
		PreChallengeList = {
			140231,
		},
		ExploreRequire = {
			Value = 130060,
			ExploreTime = 57600,
		},
	},
	Weight = 20,
}
MapAvatarConfig["FAT_map_10_node_02"] =
{
	PreCondition = {
		PreChallengeList = {
			140232,
		},
		ExploreRequire = {
			Value = 130060,
			ExploreTime = 122400,
		},
	},
	Weight = 20,
}
MapAvatarConfig["FAT_map_10_node_03"] =
{
	PreCondition = {
		PreChallengeList = {
			140233,
		},
		ExploreRequire = {
			Value = 130060,
			ExploreTime = 187200,
		},
	},
	Weight = 20,
}
MapAvatarConfig["FAT_map_10_node_sp01"] =
{
	PreCondition = {
		PreGoalList = {
			300752,
		},
		ExploreRequire = {
			Value = 130060,
			ExploreTime = 0,
		},
	},
	Weight = 20,
}
MapAvatarConfig["FAT_map_11_node_01"] =
{
	PreCondition = {
		PreChallengeList = {
			140235,
		},
		ExploreRequire = {
			Value = 130061,
			ExploreTime = 64800,
		},
	},
	Weight = 20,
}
MapAvatarConfig["FAT_map_11_node_02"] =
{
	PreCondition = {
		PreChallengeList = {
			140236,
		},
		ExploreRequire = {
			Value = 130061,
			ExploreTime = 151200,
		},
	},
	Weight = 20,
}
MapAvatarConfig["FAT_map_11_node_03"] =
{
	PreCondition = {
		PreChallengeList = {
			140236,
		},
		ExploreRequire = {
			Value = 130061,
			ExploreTime = 86400,
		},
	},
	Weight = 20,
}
MapAvatarConfig["FAT_map_11_node_04"] =
{
	PreCondition = {
		PreChallengeList = {
			140236,
		},
		ExploreRequire = {
			Value = 130061,
			ExploreTime = 86400,
		},
	},
	Weight = 20,
}
MapAvatarConfig["FAT_map_11_node_sp01"] =
{
	PreCondition = {
		PreGoalList = {
			300753,
		},
		ExploreRequire = {
			Value = 130061,
			ExploreTime = 0,
		},
	},
	Weight = 20,
}
MapAvatarConfig["MUS_map_01_node_01"] =
{
	PreCondition = {
		PreChallengeList = {
			140401,
		},
		ExploreRequire = {
			Value = 130101,
			ExploreTime = 14400,
		},
	},
	Weight = 20,
}
MapAvatarConfig["MUS_map_02_node_01"] =
{
	PreCondition = {
		PreChallengeList = {
			140402,
		},
		ExploreRequire = {
			Value = 130102,
			ExploreTime = 64800,
		},
	},
	Weight = 20,
}
MapAvatarConfig["MUS_map_02_node_02"] =
{
	PreCondition = {
		PreChallengeList = {
			140403,
		},
		ExploreRequire = {
			Value = 130102,
			ExploreTime = 129600,
		},
	},
	Weight = 20,
}
MapAvatarConfig["MUS_map_02_node_sp01"] =
{
	PreCondition = {
		PreGoalList = {
			301147,
		},
		ExploreRequire = {
			Value = 130102,
			ExploreTime = 0,
		},
	},
	Weight = 20,
}
MapAvatarConfig["MUS_map_03_node_01"] =
{
	PreCondition = {
		PreChallengeList = {
			140405,
		},
		ExploreRequire = {
			Value = 130103,
			ExploreTime = 72000,
		},
	},
	Weight = 20,
}
MapAvatarConfig["MUS_map_03_node_02"] =
{
	PreCondition = {
		PreChallengeList = {
			140406,
		},
		ExploreRequire = {
			Value = 130103,
			ExploreTime = 144000,
		},
	},
	Weight = 20,
}
MapAvatarConfig["MUS_map_03_node_03"] =
{
	PreCondition = {
		PreChallengeList = {
			140407,
		},
		ExploreRequire = {
			Value = 130103,
			ExploreTime = 230400,
		},
	},
	Weight = 20,
}
MapAvatarConfig["MUS_map_03_node_sp01"] =
{
	PreCondition = {
		PreGoalList = {
			301148,
		},
		ExploreRequire = {
			Value = 130103,
			ExploreTime = 0,
		},
	},
	Weight = 20,
}
MapAvatarConfig["MUS_map_04_node_01"] =
{
	PreCondition = {
		PreChallengeList = {
			140408,
		},
		ExploreRequire = {
			Value = 130104,
			ExploreTime = 72000,
		},
	},
	Weight = 20,
}
MapAvatarConfig["MUS_map_04_node_02"] =
{
	PreCondition = {
		PreChallengeList = {
			140409,
		},
		ExploreRequire = {
			Value = 130104,
			ExploreTime = 144000,
		},
	},
	Weight = 20,
}
MapAvatarConfig["MUS_map_04_node_03"] =
{
	PreCondition = {
		PreChallengeList = {
			140410,
		},
		ExploreRequire = {
			Value = 130104,
			ExploreTime = 216000,
		},
	},
	Weight = 20,
}
MapAvatarConfig["MUS_map_04_node_sp01"] =
{
	PreCondition = {
		PreGoalList = {
			301149,
		},
		ExploreRequire = {
			Value = 130104,
			ExploreTime = 0,
		},
	},
	Weight = 20,
}
MapAvatarConfig["MUS_map_05_node_01"] =
{
	PreCondition = {
		PreChallengeList = {
			140411,
		},
		ExploreRequire = {
			Value = 130105,
			ExploreTime = 86400,
		},
	},
	Weight = 20,
}
MapAvatarConfig["MUS_map_05_node_02"] =
{
	PreCondition = {
		PreChallengeList = {
			140412,
		},
		ExploreRequire = {
			Value = 130105,
			ExploreTime = 172800,
		},
	},
	Weight = 20,
}
MapAvatarConfig["MUS_map_05_node_03"] =
{
	PreCondition = {
		PreChallengeList = {
			140413,
		},
		ExploreRequire = {
			Value = 130105,
			ExploreTime = 259200,
		},
	},
	Weight = 20,
}
MapAvatarConfig["MUS_map_05_node_sp01"] =
{
	PreCondition = {
		PreGoalList = {
			301150,
		},
		ExploreRequire = {
			Value = 130105,
			ExploreTime = 0,
		},
	},
	Weight = 20,
}
MapAvatarConfig["MUS_map_06_node_01"] =
{
	PreCondition = {
		PreChallengeList = {
			140416,
		},
		ExploreRequire = {
			Value = 130106,
			ExploreTime = 79200,
		},
	},
	Weight = 20,
}
MapAvatarConfig["MUS_map_06_node_02"] =
{
	PreCondition = {
		PreChallengeList = {
			140417,
		},
		ExploreRequire = {
			Value = 130106,
			ExploreTime = 158400,
		},
	},
	Weight = 20,
}
MapAvatarConfig["MUS_map_06_node_03"] =
{
	PreCondition = {
		PreChallengeList = {
			140418,
		},
		ExploreRequire = {
			Value = 130106,
			ExploreTime = 237600,
		},
	},
	Weight = 20,
}
MapAvatarConfig["MUS_map_06_node_sp01"] =
{
	PreCondition = {
		PreGoalList = {
			301151,
		},
		ExploreRequire = {
			Value = 130106,
			ExploreTime = 0,
		},
	},
	Weight = 20,
}
MapAvatarConfig["MUS_map_07_node_01"] =
{
	PreCondition = {
		PreChallengeList = {
			140419,
		},
		ExploreRequire = {
			Value = 130107,
			ExploreTime = 93600,
		},
	},
	Weight = 20,
}
MapAvatarConfig["MUS_map_07_node_02"] =
{
	PreCondition = {
		PreChallengeList = {
			140420,
		},
		ExploreRequire = {
			Value = 130107,
			ExploreTime = 187200,
		},
	},
	Weight = 20,
}
MapAvatarConfig["MUS_map_07_node_03"] =
{
	PreCondition = {
		PreChallengeList = {
			140421,
		},
		ExploreRequire = {
			Value = 130107,
			ExploreTime = 316800,
		},
	},
	Weight = 20,
}
MapAvatarConfig["MUS_map_07_node_sp01"] =
{
	PreCondition = {
		PreGoalList = {
			301152,
		},
		ExploreRequire = {
			Value = 130107,
			ExploreTime = 0,
		},
	},
	Weight = 20,
}
MapAvatarConfig["MUS_map_08_node_01"] =
{
	PreCondition = {
		PreChallengeList = {
			140422,
		},
		ExploreRequire = {
			Value = 130108,
			ExploreTime = 79200,
		},
	},
	Weight = 20,
}
MapAvatarConfig["MUS_map_08_node_02"] =
{
	PreCondition = {
		PreChallengeList = {
			140423,
		},
		ExploreRequire = {
			Value = 130108,
			ExploreTime = 165600,
		},
	},
	Weight = 20,
}
MapAvatarConfig["MUS_map_08_node_03"] =
{
	PreCondition = {
		PreChallengeList = {
			140424,
		},
		ExploreRequire = {
			Value = 130108,
			ExploreTime = 252000,
		},
	},
	Weight = 20,
}
MapAvatarConfig["MUS_map_08_node_sp01"] =
{
	PreCondition = {
		PreGoalList = {
			301153,
		},
		ExploreRequire = {
			Value = 130108,
			ExploreTime = 0,
		},
	},
	Weight = 20,
}
MapAvatarConfig["MUS_map_09_node_01"] =
{
	PreCondition = {
		PreChallengeList = {
			140426,
		},
		ExploreRequire = {
			Value = 130109,
			ExploreTime = 86400,
		},
	},
	Weight = 20,
}
MapAvatarConfig["MUS_map_09_node_02"] =
{
	PreCondition = {
		PreChallengeList = {
			140427,
		},
		ExploreRequire = {
			Value = 130109,
			ExploreTime = 172800,
		},
	},
	Weight = 20,
}
MapAvatarConfig["MUS_map_09_node_03"] =
{
	PreCondition = {
		PreChallengeList = {
			140428,
		},
		ExploreRequire = {
			Value = 130109,
			ExploreTime = 288000,
		},
	},
	Weight = 20,
}
MapAvatarConfig["MUS_map_09_node_sp01"] =
{
	PreCondition = {
		PreGoalList = {
			301154,
		},
		ExploreRequire = {
			Value = 130109,
			ExploreTime = 0,
		},
	},
	Weight = 20,
}
MapAvatarConfig["MUS_map_10_node_01"] =
{
	PreCondition = {
		PreChallengeList = {
			140429,
		},
		ExploreRequire = {
			Value = 130110,
			ExploreTime = 93600,
		},
	},
	Weight = 20,
}
MapAvatarConfig["MUS_map_10_node_02"] =
{
	PreCondition = {
		PreChallengeList = {
			140430,
		},
		ExploreRequire = {
			Value = 130110,
			ExploreTime = 187200,
		},
	},
	Weight = 20,
}
MapAvatarConfig["MUS_map_10_node_03"] =
{
	PreCondition = {
		PreChallengeList = {
			140430,
		},
		ExploreRequire = {
			Value = 130110,
			ExploreTime = 93600,
		},
	},
	Weight = 20,
}
MapAvatarConfig["MUS_map_10_node_sp01"] =
{
	PreCondition = {
		PreGoalList = {
			301155,
		},
		ExploreRequire = {
			Value = 130110,
			ExploreTime = 0,
		},
	},
	Weight = 20,
}
MapAvatarConfig["MUS_map_11_node_01"] =
{
	PreCondition = {
		PreChallengeList = {
			140431,
		},
		ExploreRequire = {
			Value = 130111,
			ExploreTime = 100800,
		},
	},
	Weight = 20,
}
MapAvatarConfig["MUS_map_11_node_02"] =
{
	PreCondition = {
		PreChallengeList = {
			140432,
		},
		ExploreRequire = {
			Value = 130111,
			ExploreTime = 201600,
		},
	},
	Weight = 20,
}
MapAvatarConfig["MUS_map_11_node_sp01"] =
{
	PreCondition = {
		PreGoalList = {
			301156,
		},
		ExploreRequire = {
			Value = 130111,
			ExploreTime = 0,
		},
	},
	Weight = 20,
}
MapAvatarConfig["MUS_map_12_node_01"] =
{
	PreCondition = {
		PreChallengeList = {
			140434,
		},
		ExploreRequire = {
			Value = 130112,
			ExploreTime = 108000,
		},
	},
	Weight = 20,
}
MapAvatarConfig["MUS_map_12_node_02"] =
{
	PreCondition = {
		PreChallengeList = {
			140435,
		},
		ExploreRequire = {
			Value = 130112,
			ExploreTime = 237600,
		},
	},
	Weight = 20,
}
MapAvatarConfig["MUS_map_12_node_sp01"] =
{
	PreCondition = {
		PreGoalList = {
			301157,
		},
		ExploreRequire = {
			Value = 130112,
			ExploreTime = 0,
		},
	},
	Weight = 20,
}
MapAvatarConfig["SUS_map_01_node_01"] =
{
	PreCondition = {
		PreChallengeList = {
			140601,
		},
		ExploreRequire = {
			Value = 130151,
			ExploreTime = 27000,
		},
	},
	Weight = 20,
}
MapAvatarConfig["SUS_map_02_node_01"] =
{
	PreCondition = {
		PreChallengeList = {
			140602,
		},
		ExploreRequire = {
			Value = 130152,
			ExploreTime = 108000,
		},
	},
	Weight = 20,
}
MapAvatarConfig["SUS_map_02_node_02"] =
{
	PreCondition = {
		PreChallengeList = {
			140603,
		},
		ExploreRequire = {
			Value = 130152,
			ExploreTime = 216000,
		},
	},
	Weight = 20,
}
MapAvatarConfig["SUS_map_02_node_sp01"] =
{
	PreCondition = {
		PreGoalList = {
			301560,
		},
		ExploreRequire = {
			Value = 130152,
			ExploreTime = 0,
		},
	},
	Weight = 20,
}
MapAvatarConfig["SUS_map_03_node_01"] =
{
	PreCondition = {
		PreChallengeList = {
			140606,
		},
		ExploreRequire = {
			Value = 130153,
			ExploreTime = 129600,
		},
	},
	Weight = 20,
}
MapAvatarConfig["SUS_map_03_node_02"] =
{
	PreCondition = {
		PreChallengeList = {
			140607,
		},
		ExploreRequire = {
			Value = 130153,
			ExploreTime = 259200,
		},
	},
	Weight = 20,
}
MapAvatarConfig["SUS_map_03_node_03"] =
{
	PreCondition = {
		PreChallengeList = {
			140608,
		},
		ExploreRequire = {
			Value = 130153,
			ExploreTime = 410400,
		},
	},
	Weight = 20,
}
MapAvatarConfig["SUS_map_03_node_sp01"] =
{
	PreCondition = {
		PreGoalList = {
			301561,
		},
		ExploreRequire = {
			Value = 130153,
			ExploreTime = 0,
		},
	},
	Weight = 20,
}
MapAvatarConfig["SUS_map_04_node_01"] =
{
	PreCondition = {
		PreChallengeList = {
			140609,
		},
		ExploreRequire = {
			Value = 130154,
			ExploreTime = 136800,
		},
	},
	Weight = 20,
}
MapAvatarConfig["SUS_map_04_node_02"] =
{
	PreCondition = {
		PreChallengeList = {
			140610,
		},
		ExploreRequire = {
			Value = 130154,
			ExploreTime = 273600,
		},
	},
	Weight = 20,
}
MapAvatarConfig["SUS_map_04_node_03"] =
{
	PreCondition = {
		PreChallengeList = {
			140611,
		},
		ExploreRequire = {
			Value = 130154,
			ExploreTime = 410400,
		},
	},
	Weight = 20,
}
MapAvatarConfig["SUS_map_04_node_sp01"] =
{
	PreCondition = {
		PreGoalList = {
			301562,
		},
		ExploreRequire = {
			Value = 130154,
			ExploreTime = 0,
		},
	},
	Weight = 20,
}
MapAvatarConfig["SUS_map_05_node_01"] =
{
	PreCondition = {
		PreChallengeList = {
			140613,
		},
		ExploreRequire = {
			Value = 130155,
			ExploreTime = 144000,
		},
	},
	Weight = 20,
}
MapAvatarConfig["SUS_map_05_node_02"] =
{
	PreCondition = {
		PreChallengeList = {
			140614,
		},
		ExploreRequire = {
			Value = 130155,
			ExploreTime = 288000,
		},
	},
	Weight = 20,
}
MapAvatarConfig["SUS_map_05_node_03"] =
{
	PreCondition = {
		PreChallengeList = {
			140615,
		},
		ExploreRequire = {
			Value = 130155,
			ExploreTime = 432000,
		},
	},
	Weight = 20,
}
MapAvatarConfig["SUS_map_05_node_sp01"] =
{
	PreCondition = {
		PreGoalList = {
			301563,
		},
		ExploreRequire = {
			Value = 130155,
			ExploreTime = 0,
		},
	},
	Weight = 20,
}
MapAvatarConfig["SUS_map_06_node_01"] =
{
	PreCondition = {
		PreChallengeList = {
			140617,
		},
		ExploreRequire = {
			Value = 130156,
			ExploreTime = 151200,
		},
	},
	Weight = 20,
}
MapAvatarConfig["SUS_map_06_node_02"] =
{
	PreCondition = {
		PreChallengeList = {
			140618,
		},
		ExploreRequire = {
			Value = 130156,
			ExploreTime = 302400,
		},
	},
	Weight = 20,
}
MapAvatarConfig["SUS_map_06_node_03"] =
{
	PreCondition = {
		PreChallengeList = {
			140619,
		},
		ExploreRequire = {
			Value = 130156,
			ExploreTime = 453600,
		},
	},
	Weight = 20,
}
MapAvatarConfig["SUS_map_06_node_sp01"] =
{
	PreCondition = {
		PreGoalList = {
			301564,
		},
		ExploreRequire = {
			Value = 130156,
			ExploreTime = 0,
		},
	},
	Weight = 20,
}
MapAvatarConfig["SUS_map_07_node_01"] =
{
	PreCondition = {
		PreChallengeList = {
			140621,
		},
		ExploreRequire = {
			Value = 130157,
			ExploreTime = 158400,
		},
	},
	Weight = 20,
}
MapAvatarConfig["SUS_map_07_node_02"] =
{
	PreCondition = {
		PreChallengeList = {
			140622,
		},
		ExploreRequire = {
			Value = 130157,
			ExploreTime = 316800,
		},
	},
	Weight = 20,
}
MapAvatarConfig["SUS_map_07_node_03"] =
{
	PreCondition = {
		PreChallengeList = {
			140623,
		},
		ExploreRequire = {
			Value = 130157,
			ExploreTime = 475200,
		},
	},
	Weight = 20,
}
MapAvatarConfig["SUS_map_07_node_sp01"] =
{
	PreCondition = {
		PreGoalList = {
			301565,
		},
		ExploreRequire = {
			Value = 130157,
			ExploreTime = 0,
		},
	},
	Weight = 20,
}
MapAvatarConfig["SUS_map_08_node_01"] =
{
	PreCondition = {
		PreChallengeList = {
			140625,
		},
		ExploreRequire = {
			Value = 130158,
			ExploreTime = 165600,
		},
	},
	Weight = 20,
}
MapAvatarConfig["SUS_map_08_node_02"] =
{
	PreCondition = {
		PreChallengeList = {
			140626,
		},
		ExploreRequire = {
			Value = 130158,
			ExploreTime = 331200,
		},
	},
	Weight = 20,
}
MapAvatarConfig["SUS_map_08_node_03"] =
{
	PreCondition = {
		PreChallengeList = {
			140627,
		},
		ExploreRequire = {
			Value = 130158,
			ExploreTime = 496800,
		},
	},
	Weight = 20,
}
MapAvatarConfig["SUS_map_08_node_sp01"] =
{
	PreCondition = {
		PreGoalList = {
			301566,
		},
		ExploreRequire = {
			Value = 130158,
			ExploreTime = 0,
		},
	},
	Weight = 20,
}
MapAvatarConfig["SUS_map_09_node_01"] =
{
	PreCondition = {
		PreChallengeList = {
			140629,
		},
		ExploreRequire = {
			Value = 130159,
			ExploreTime = 172800,
		},
	},
	Weight = 20,
}
MapAvatarConfig["SUS_map_09_node_02"] =
{
	PreCondition = {
		PreChallengeList = {
			140630,
		},
		ExploreRequire = {
			Value = 130159,
			ExploreTime = 345600,
		},
	},
	Weight = 20,
}
MapAvatarConfig["SUS_map_09_node_03"] =
{
	PreCondition = {
		PreChallengeList = {
			140631,
		},
		ExploreRequire = {
			Value = 130159,
			ExploreTime = 561600,
		},
	},
	Weight = 20,
}
MapAvatarConfig["SUS_map_09_node_sp01"] =
{
	PreCondition = {
		PreGoalList = {
			301567,
		},
		ExploreRequire = {
			Value = 130159,
			ExploreTime = 0,
		},
	},
	Weight = 20,
}
MapAvatarConfig["SUS_map_10_node_01"] =
{
	PreCondition = {
		PreChallengeList = {
			140632,
		},
		ExploreRequire = {
			Value = 130160,
			ExploreTime = 187200,
		},
	},
	Weight = 20,
}
MapAvatarConfig["SUS_map_10_node_02"] =
{
	PreCondition = {
		PreChallengeList = {
			140633,
		},
		ExploreRequire = {
			Value = 130160,
			ExploreTime = 374400,
		},
	},
	Weight = 20,
}
MapAvatarConfig["SUS_map_10_node_03"] =
{
	PreCondition = {
		PreChallengeList = {
			140633,
		},
		ExploreRequire = {
			Value = 130160,
			ExploreTime = 187200,
		},
	},
	Weight = 20,
}
MapAvatarConfig["SUS_map_10_node_sp01"] =
{
	PreCondition = {
		PreGoalList = {
			301568,
		},
		ExploreRequire = {
			Value = 130160,
			ExploreTime = 0,
		},
	},
	Weight = 20,
}
MapAvatarConfig["SUS_map_11_node_01"] =
{
	PreCondition = {
		PreChallengeList = {
			140634,
		},
		ExploreRequire = {
			Value = 130161,
			ExploreTime = 180000,
		},
	},
	Weight = 20,
}
MapAvatarConfig["SUS_map_11_node_02"] =
{
	PreCondition = {
		PreChallengeList = {
			140635,
		},
		ExploreRequire = {
			Value = 130161,
			ExploreTime = 360000,
		},
	},
	Weight = 20,
}
MapAvatarConfig["SUS_map_11_node_sp01"] =
{
	PreCondition = {
		PreGoalList = {
			301569,
		},
		ExploreRequire = {
			Value = 130161,
			ExploreTime = 0,
		},
	},
	Weight = 20,
}
MapAvatarConfig["SUS_map_12_node_01"] =
{
	PreCondition = {
		PreChallengeList = {
			140637,
		},
		ExploreRequire = {
			Value = 130162,
			ExploreTime = 187200,
		},
	},
	Weight = 20,
}
MapAvatarConfig["SUS_map_12_node_02"] =
{
	PreCondition = {
		PreChallengeList = {
			140638,
		},
		ExploreRequire = {
			Value = 130162,
			ExploreTime = 374400,
		},
	},
	Weight = 20,
}
MapAvatarConfig["SUS_map_12_node_sp01"] =
{
	PreCondition = {
		PreGoalList = {
			301570,
		},
		ExploreRequire = {
			Value = 130162,
			ExploreTime = 0,
		},
	},
	Weight = 20,
}
MapAvatarConfig["SUS_map_13_node_01"] =
{
	PreCondition = {
		PreChallengeList = {
			140641,
		},
		ExploreRequire = {
			Value = 130163,
			ExploreTime = 216000,
		},
	},
	Weight = 20,
}
MapAvatarConfig["SUS_map_13_node_02"] =
{
	PreCondition = {
		PreChallengeList = {
			140642,
		},
		ExploreRequire = {
			Value = 130163,
			ExploreTime = 432000,
		},
	},
	Weight = 20,
}
MapAvatarConfig["SUS_map_13_node_sp01"] =
{
	PreCondition = {
		PreGoalList = {
			301571,
		},
		ExploreRequire = {
			Value = 130163,
			ExploreTime = 0,
		},
	},
	Weight = 20,
}
MapAvatarConfig["SEA_map_01_node_01"] =
{
	PreCondition = {
		PreGoalList = {
			301610,
		},
		PreChallengeList = {
			140801,
		},
		ExploreRequire = {
			Value = 130201,
			ExploreTime = 0,
		},
	},
	Weight = 20,
}
MapAvatarConfig["SEA_map_02_node_01"] =
{
	PreCondition = {
		PreChallengeList = {
			140803,
		},
		ExploreRequire = {
			Value = 130202,
			ExploreTime = 43200,
		},
	},
	Weight = 20,
}
MapAvatarConfig["SEA_map_02_node_02"] =
{
	PreCondition = {
		PreChallengeList = {
			140804,
		},
		ExploreRequire = {
			Value = 130202,
			ExploreTime = 86400,
		},
	},
	Weight = 20,
}
MapAvatarConfig["SEA_map_02_node_sp01"] =
{
	PreCondition = {
		PreGoalList = {
			301969,
		},
		ExploreRequire = {
			Value = 130202,
			ExploreTime = 0,
		},
	},
	Weight = 20,
}
MapAvatarConfig["SEA_map_03_node_01"] =
{
	PreCondition = {
		PreChallengeList = {
			140805,
		},
		ExploreRequire = {
			Value = 130203,
			ExploreTime = 43200,
		},
	},
	Weight = 20,
}
MapAvatarConfig["SEA_map_03_node_02"] =
{
	PreCondition = {
		PreChallengeList = {
			140806,
		},
		ExploreRequire = {
			Value = 130203,
			ExploreTime = 129600,
		},
	},
	Weight = 20,
}
MapAvatarConfig["SEA_map_03_node_sp01"] =
{
	PreCondition = {
		PreGoalList = {
			301970,
		},
		ExploreRequire = {
			Value = 130203,
			ExploreTime = 0,
		},
	},
	Weight = 20,
}
MapAvatarConfig["SEA_map_04_node_01"] =
{
	PreCondition = {
		PreChallengeList = {
			140807,
		},
		ExploreRequire = {
			Value = 130204,
			ExploreTime = 43200,
		},
	},
	Weight = 20,
}
MapAvatarConfig["SEA_map_04_node_02"] =
{
	PreCondition = {
		PreChallengeList = {
			140808,
		},
		ExploreRequire = {
			Value = 130204,
			ExploreTime = 216000,
		},
	},
	Weight = 20,
}
MapAvatarConfig["SEA_map_04_node_sp01"] =
{
	PreCondition = {
		PreGoalList = {
			301971,
		},
		ExploreRequire = {
			Value = 130204,
			ExploreTime = 0,
		},
	},
	Weight = 20,
}
MapAvatarConfig["SEA_map_05_node_01"] =
{
	PreCondition = {
		PreChallengeList = {
			140810,
		},
		ExploreRequire = {
			Value = 130205,
			ExploreTime = 21600,
		},
	},
	Weight = 20,
}
MapAvatarConfig["SEA_map_05_node_02"] =
{
	PreCondition = {
		PreChallengeList = {
			140811,
		},
		ExploreRequire = {
			Value = 130205,
			ExploreTime = 64800,
		},
	},
	Weight = 20,
}
MapAvatarConfig["SEA_map_05_node_03"] =
{
	PreCondition = {
		PreChallengeList = {
			140812,
		},
		ExploreRequire = {
			Value = 130205,
			ExploreTime = 151200,
		},
	},
	Weight = 20,
}
MapAvatarConfig["SEA_map_05_node_sp01"] =
{
	PreCondition = {
		PreGoalList = {
			301972,
		},
		ExploreRequire = {
			Value = 130205,
			ExploreTime = 0,
		},
	},
	Weight = 20,
}
MapAvatarConfig["SEA_map_06_node_01"] =
{
	PreCondition = {
		PreChallengeList = {
			140814,
		},
		ExploreRequire = {
			Value = 130206,
			ExploreTime = 43200,
		},
	},
	Weight = 20,
}
MapAvatarConfig["SEA_map_06_node_02"] =
{
	PreCondition = {
		PreChallengeList = {
			140815,
		},
		ExploreRequire = {
			Value = 130206,
			ExploreTime = 129600,
		},
	},
	Weight = 20,
}
MapAvatarConfig["SEA_map_06_node_sp01"] =
{
	PreCondition = {
		PreGoalList = {
			301973,
		},
		ExploreRequire = {
			Value = 130206,
			ExploreTime = 0,
		},
	},
	Weight = 20,
}
MapAvatarConfig["SEA_map_07_node_01"] =
{
	PreCondition = {
		PreChallengeList = {
			140816,
		},
		ExploreRequire = {
			Value = 130207,
			ExploreTime = 43200,
		},
	},
	Weight = 20,
}
MapAvatarConfig["SEA_map_07_node_02"] =
{
	PreCondition = {
		PreChallengeList = {
			140817,
		},
		ExploreRequire = {
			Value = 130207,
			ExploreTime = 129600,
		},
	},
	Weight = 20,
}
MapAvatarConfig["SEA_map_07_node_03"] =
{
	PreCondition = {
		PreChallengeList = {
			140818,
		},
		ExploreRequire = {
			Value = 130207,
			ExploreTime = 302400,
		},
	},
	Weight = 20,
}
MapAvatarConfig["SEA_map_07_node_sp01"] =
{
	PreCondition = {
		PreGoalList = {
			301974,
		},
		ExploreRequire = {
			Value = 130207,
			ExploreTime = 0,
		},
	},
	Weight = 20,
}
MapAvatarConfig["SEA_map_08_node_01"] =
{
	PreCondition = {
		PreChallengeList = {
			140819,
		},
		ExploreRequire = {
			Value = 130208,
			ExploreTime = 43200,
		},
	},
	Weight = 20,
}
MapAvatarConfig["SEA_map_08_node_02"] =
{
	PreCondition = {
		PreChallengeList = {
			140820,
		},
		ExploreRequire = {
			Value = 130208,
			ExploreTime = 129600,
		},
	},
	Weight = 20,
}
MapAvatarConfig["SEA_map_08_node_03"] =
{
	PreCondition = {
		PreChallengeList = {
			140821,
		},
		ExploreRequire = {
			Value = 130208,
			ExploreTime = 302400,
		},
	},
	Weight = 20,
}
MapAvatarConfig["SEA_map_08_node_sp01"] =
{
	PreCondition = {
		PreGoalList = {
			301975,
		},
		ExploreRequire = {
			Value = 130208,
			ExploreTime = 0,
		},
	},
	Weight = 20,
}
MapAvatarConfig["SEA_map_09_node_01"] =
{
	PreCondition = {
		PreChallengeList = {
			140822,
		},
		ExploreRequire = {
			Value = 130209,
			ExploreTime = 43200,
		},
	},
	Weight = 20,
}
MapAvatarConfig["SEA_map_09_node_02"] =
{
	PreCondition = {
		PreChallengeList = {
			140823,
		},
		ExploreRequire = {
			Value = 130209,
			ExploreTime = 216000,
		},
	},
	Weight = 20,
}
MapAvatarConfig["SEA_map_09_node_02"] =
{
	PreCondition = {
		PreChallengeList = {
			140824,
		},
		ExploreRequire = {
			Value = 130209,
			ExploreTime = 561600,
		},
	},
	Weight = 20,
}
MapAvatarConfig["SEA_map_09_node_sp01"] =
{
	PreCondition = {
		PreGoalList = {
			301976,
		},
		ExploreRequire = {
			Value = 130209,
			ExploreTime = 0,
		},
	},
	Weight = 20,
}
MapAvatarConfig["SEA_map_10_node_01"] =
{
	PreCondition = {
		PreChallengeList = {
			140825,
		},
		ExploreRequire = {
			Value = 130210,
			ExploreTime = 43200,
		},
	},
	Weight = 20,
}
MapAvatarConfig["SEA_map_10_node_02"] =
{
	PreCondition = {
		PreChallengeList = {
			140826,
		},
		ExploreRequire = {
			Value = 130210,
			ExploreTime = 216000,
		},
	},
	Weight = 20,
}
MapAvatarConfig["SEA_map_10_node_sp01"] =
{
	PreCondition = {
		PreGoalList = {
			301977,
		},
		ExploreRequire = {
			Value = 130210,
			ExploreTime = 0,
		},
	},
	Weight = 20,
}
MapAvatarConfig["SEA_map_11_node_01"] =
{
	PreCondition = {
		PreChallengeList = {
			140827,
		},
		ExploreRequire = {
			Value = 130211,
			ExploreTime = 21600,
		},
	},
	Weight = 20,
}
MapAvatarConfig["SEA_map_11_node_02"] =
{
	PreCondition = {
		PreChallengeList = {
			140828,
		},
		ExploreRequire = {
			Value = 130211,
			ExploreTime = 64800,
		},
	},
	Weight = 20,
}
MapAvatarConfig["SEA_map_11_node_02"] =
{
	PreCondition = {
		PreChallengeList = {
			140829,
		},
		ExploreRequire = {
			Value = 130211,
			ExploreTime = 151200,
		},
	},
	Weight = 20,
}
MapAvatarConfig["SEA_map_11_node_sp01"] =
{
	PreCondition = {
		PreGoalList = {
			301978,
		},
		ExploreRequire = {
			Value = 130211,
			ExploreTime = 0,
		},
	},
	Weight = 20,
}
MapAvatarConfig["SEA_map_12_node_01"] =
{
	PreCondition = {
		PreChallengeList = {
			140830,
		},
		ExploreRequire = {
			Value = 130212,
			ExploreTime = 43200,
		},
	},
	Weight = 20,
}
MapAvatarConfig["SEA_map_12_node_02"] =
{
	PreCondition = {
		PreChallengeList = {
			140831,
		},
		ExploreRequire = {
			Value = 130212,
			ExploreTime = 86400,
		},
	},
	Weight = 20,
}
MapAvatarConfig["SEA_map_12_node_sp01"] =
{
	PreCondition = {
		PreGoalList = {
			301979,
		},
		ExploreRequire = {
			Value = 130212,
			ExploreTime = 0,
		},
	},
	Weight = 20,
}
MapAvatarConfig["SEA_map_13_node_01"] =
{
	PreCondition = {
		PreChallengeList = {
			140833,
		},
		ExploreRequire = {
			Value = 130213,
			ExploreTime = 86400,
		},
	},
	Weight = 20,
}
MapAvatarConfig["SEA_map_13_node_02"] =
{
	PreCondition = {
		PreChallengeList = {
			140834,
		},
		ExploreRequire = {
			Value = 130213,
			ExploreTime = 259200,
		},
	},
	Weight = 20,
}
MapAvatarConfig["SEA_map_13_node_sp01"] =
{
	PreCondition = {
		PreGoalList = {
			301980,
		},
		ExploreRequire = {
			Value = 130213,
			ExploreTime = 0,
		},
	},
	Weight = 20,
}
MapAvatarConfig["SEA_map_14_node_01"] =
{
	PreCondition = {
		PreChallengeList = {
			140835,
		},
		ExploreRequire = {
			Value = 130214,
			ExploreTime = 43200,
		},
	},
	Weight = 20,
}
MapAvatarConfig["SEA_map_14_node_02"] =
{
	PreCondition = {
		PreChallengeList = {
			140836,
		},
		ExploreRequire = {
			Value = 130214,
			ExploreTime = 129600,
		},
	},
	Weight = 20,
}
MapAvatarConfig["SEA_map_14_node_02"] =
{
	PreCondition = {
		PreChallengeList = {
			140837,
		},
		ExploreRequire = {
			Value = 130214,
			ExploreTime = 302400,
		},
	},
	Weight = 20,
}
MapAvatarConfig["SEA_map_14_node_sp01"] =
{
	PreCondition = {
		PreGoalList = {
			301981,
		},
		ExploreRequire = {
			Value = 130214,
			ExploreTime = 0,
		},
	},
	Weight = 20,
}

