
EquipmentConfig[EquipmentID.Id031] =
{
	Character = 220015,
	Rarity = 2,
	UpgradeId = 930025,
	LevelList = {
		{
			Level = 1,
			Info = 920052,
			Ability = {
				{
					Value = 200001,
					Num = 39,
				},
				{
					Value = 200007,
					Num = 6,
				},
			},
		},
		{
			Level = 2,
			Info = 920052,
			Ability = {
				{
					Value = 200001,
					Num = 78,
				},
				{
					Value = 200007,
					Num = 12,
				},
			},
		},
		{
			Level = 3,
			Info = 920052,
			Ability = {
				{
					Value = 200001,
					Num = 117,
				},
				{
					Value = 200007,
					Num = 18,
				},
			},
		},
		{
			Level = 4,
			Info = 920052,
			Ability = {
				{
					Value = 200001,
					Num = 156,
				},
				{
					Value = 200007,
					Num = 24,
				},
			},
		},
		{
			Level = 5,
			Info = 920052,
			Ability = {
				{
					Value = 200001,
					Num = 195,
				},
				{
					Value = 200007,
					Num = 30,
				},
			},
			SkillList = {
				{
					Id = 100651,
					Value = 5,
				},
			},
		},
		{
			Level = 6,
			Info = 920052,
			Ability = {
				{
					Value = 200001,
					Num = 234,
				},
				{
					Value = 200007,
					Num = 36,
				},
			},
			SkillList = {
				{
					Id = 100651,
					Value = 5,
				},
			},
		},
		{
			Level = 7,
			Info = 920052,
			Ability = {
				{
					Value = 200001,
					Num = 273,
				},
				{
					Value = 200007,
					Num = 42,
				},
			},
			SkillList = {
				{
					Id = 100651,
					Value = 5,
				},
			},
		},
		{
			Level = 8,
			Info = 920052,
			Ability = {
				{
					Value = 200001,
					Num = 312,
				},
				{
					Value = 200007,
					Num = 48,
				},
			},
			SkillList = {
				{
					Id = 100651,
					Value = 5,
				},
			},
		},
		{
			Level = 9,
			Info = 920052,
			Ability = {
				{
					Value = 200001,
					Num = 351,
				},
				{
					Value = 200007,
					Num = 54,
				},
			},
			SkillList = {
				{
					Id = 100651,
					Value = 5,
				},
			},
		},
		{
			Level = 10,
			Info = 920052,
			Ability = {
				{
					Value = 200001,
					Num = 390,
				},
				{
					Value = 200007,
					Num = 60,
				},
			},
			SkillList = {
				{
					Id = 100651,
					Value = 5,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id032] =
{
	Character = 220015,
	Rarity = 2,
	NeedChallenge = 145015,
	UpgradeId = 930026,
	LevelList = {
		{
			Level = 1,
			Info = 920053,
			Ability = {
				{
					Value = 200001,
					Num = 39,
				},
				{
					Value = 200008,
					Num = 3,
				},
			},
		},
		{
			Level = 2,
			Info = 920053,
			Ability = {
				{
					Value = 200001,
					Num = 78,
				},
				{
					Value = 200008,
					Num = 6,
				},
			},
		},
		{
			Level = 3,
			Info = 920053,
			Ability = {
				{
					Value = 200001,
					Num = 117,
				},
				{
					Value = 200008,
					Num = 9,
				},
			},
		},
		{
			Level = 4,
			Info = 920053,
			Ability = {
				{
					Value = 200001,
					Num = 156,
				},
				{
					Value = 200008,
					Num = 12,
				},
			},
		},
		{
			Level = 5,
			Info = 920053,
			Ability = {
				{
					Value = 200001,
					Num = 195,
				},
				{
					Value = 200008,
					Num = 15,
				},
			},
		},
		{
			Level = 6,
			Info = 920053,
			Ability = {
				{
					Value = 200001,
					Num = 234,
				},
				{
					Value = 200008,
					Num = 18,
				},
			},
		},
		{
			Level = 7,
			Info = 920053,
			Ability = {
				{
					Value = 200001,
					Num = 273,
				},
				{
					Value = 200008,
					Num = 21,
				},
			},
		},
		{
			Level = 8,
			Info = 920053,
			Ability = {
				{
					Value = 200001,
					Num = 312,
				},
				{
					Value = 200008,
					Num = 24,
				},
			},
			SkillList = {
				{
					Id = 100201,
					Value = 25,
				},
			},
		},
		{
			Level = 9,
			Info = 920053,
			Ability = {
				{
					Value = 200001,
					Num = 351,
				},
				{
					Value = 200008,
					Num = 27,
				},
			},
			SkillList = {
				{
					Id = 100201,
					Value = 25,
				},
			},
		},
		{
			Level = 10,
			Info = 920053,
			Ability = {
				{
					Value = 200001,
					Num = 390,
				},
				{
					Value = 200008,
					Num = 30,
				},
			},
			SkillList = {
				{
					Id = 100201,
					Value = 25,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id033] =
{
	Character = 220016,
	Rarity = 2,
	UpgradeId = 930025,
	LevelList = {
		{
			Level = 1,
			Info = 920055,
			Ability = {
				{
					Value = 200001,
					Num = 42,
				},
				{
					Value = 200007,
					Num = 6,
				},
			},
		},
		{
			Level = 2,
			Info = 920055,
			Ability = {
				{
					Value = 200001,
					Num = 84,
				},
				{
					Value = 200007,
					Num = 12,
				},
			},
		},
		{
			Level = 3,
			Info = 920055,
			Ability = {
				{
					Value = 200001,
					Num = 126,
				},
				{
					Value = 200007,
					Num = 18,
				},
			},
		},
		{
			Level = 4,
			Info = 920055,
			Ability = {
				{
					Value = 200001,
					Num = 168,
				},
				{
					Value = 200007,
					Num = 24,
				},
			},
		},
		{
			Level = 5,
			Info = 920055,
			Ability = {
				{
					Value = 200001,
					Num = 210,
				},
				{
					Value = 200007,
					Num = 30,
				},
			},
			SkillList = {
				{
					Id = 100651,
					Value = 5,
				},
			},
		},
		{
			Level = 6,
			Info = 920055,
			Ability = {
				{
					Value = 200001,
					Num = 252,
				},
				{
					Value = 200007,
					Num = 36,
				},
			},
			SkillList = {
				{
					Id = 100651,
					Value = 5,
				},
			},
		},
		{
			Level = 7,
			Info = 920055,
			Ability = {
				{
					Value = 200001,
					Num = 294,
				},
				{
					Value = 200007,
					Num = 42,
				},
			},
			SkillList = {
				{
					Id = 100651,
					Value = 5,
				},
			},
		},
		{
			Level = 8,
			Info = 920055,
			Ability = {
				{
					Value = 200001,
					Num = 336,
				},
				{
					Value = 200007,
					Num = 48,
				},
			},
			SkillList = {
				{
					Id = 100651,
					Value = 5,
				},
			},
		},
		{
			Level = 9,
			Info = 920055,
			Ability = {
				{
					Value = 200001,
					Num = 378,
				},
				{
					Value = 200007,
					Num = 54,
				},
			},
			SkillList = {
				{
					Id = 100651,
					Value = 5,
				},
			},
		},
		{
			Level = 10,
			Info = 920055,
			Ability = {
				{
					Value = 200001,
					Num = 420,
				},
				{
					Value = 200007,
					Num = 60,
				},
			},
			SkillList = {
				{
					Id = 100651,
					Value = 5,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id034] =
{
	Character = 220016,
	Rarity = 2,
	NeedChallenge = 145016,
	UpgradeId = 930006,
	LevelList = {
		{
			Level = 1,
			Info = 920056,
			Ability = {
				{
					Value = 200002,
					Num = 33,
				},
				{
					Value = 200005,
					Num = 3,
				},
			},
		},
		{
			Level = 2,
			Info = 920056,
			Ability = {
				{
					Value = 200002,
					Num = 66,
				},
				{
					Value = 200005,
					Num = 6,
				},
			},
		},
		{
			Level = 3,
			Info = 920056,
			Ability = {
				{
					Value = 200002,
					Num = 99,
				},
				{
					Value = 200005,
					Num = 9,
				},
			},
		},
		{
			Level = 4,
			Info = 920056,
			Ability = {
				{
					Value = 200002,
					Num = 132,
				},
				{
					Value = 200005,
					Num = 12,
				},
			},
		},
		{
			Level = 5,
			Info = 920056,
			Ability = {
				{
					Value = 200002,
					Num = 165,
				},
				{
					Value = 200005,
					Num = 15,
				},
			},
		},
		{
			Level = 6,
			Info = 920056,
			Ability = {
				{
					Value = 200002,
					Num = 198,
				},
				{
					Value = 200005,
					Num = 18,
				},
			},
		},
		{
			Level = 7,
			Info = 920056,
			Ability = {
				{
					Value = 200002,
					Num = 231,
				},
				{
					Value = 200005,
					Num = 21,
				},
			},
		},
		{
			Level = 8,
			Info = 920056,
			Ability = {
				{
					Value = 200002,
					Num = 264,
				},
				{
					Value = 200005,
					Num = 24,
				},
			},
			SkillList = {
				{
					Id = 100554,
					Value = 25,
				},
			},
		},
		{
			Level = 9,
			Info = 920056,
			Ability = {
				{
					Value = 200002,
					Num = 297,
				},
				{
					Value = 200005,
					Num = 27,
				},
			},
			SkillList = {
				{
					Id = 100554,
					Value = 25,
				},
			},
		},
		{
			Level = 10,
			Info = 920056,
			Ability = {
				{
					Value = 200002,
					Num = 330,
				},
				{
					Value = 200005,
					Num = 30,
				},
			},
			SkillList = {
				{
					Id = 100554,
					Value = 25,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id035] =
{
	Character = 220017,
	Rarity = 2,
	UpgradeId = 930025,
	LevelList = {
		{
			Level = 1,
			Info = 920058,
			Ability = {
				{
					Value = 200001,
					Num = 45,
				},
				{
					Value = 200007,
					Num = 6,
				},
			},
		},
		{
			Level = 2,
			Info = 920058,
			Ability = {
				{
					Value = 200001,
					Num = 90,
				},
				{
					Value = 200007,
					Num = 12,
				},
			},
		},
		{
			Level = 3,
			Info = 920058,
			Ability = {
				{
					Value = 200001,
					Num = 135,
				},
				{
					Value = 200007,
					Num = 18,
				},
			},
		},
		{
			Level = 4,
			Info = 920058,
			Ability = {
				{
					Value = 200001,
					Num = 180,
				},
				{
					Value = 200007,
					Num = 24,
				},
			},
		},
		{
			Level = 5,
			Info = 920058,
			Ability = {
				{
					Value = 200001,
					Num = 225,
				},
				{
					Value = 200007,
					Num = 30,
				},
			},
			SkillList = {
				{
					Id = 100651,
					Value = 5,
				},
			},
		},
		{
			Level = 6,
			Info = 920058,
			Ability = {
				{
					Value = 200001,
					Num = 270,
				},
				{
					Value = 200007,
					Num = 36,
				},
			},
			SkillList = {
				{
					Id = 100651,
					Value = 5,
				},
			},
		},
		{
			Level = 7,
			Info = 920058,
			Ability = {
				{
					Value = 200001,
					Num = 315,
				},
				{
					Value = 200007,
					Num = 42,
				},
			},
			SkillList = {
				{
					Id = 100651,
					Value = 5,
				},
			},
		},
		{
			Level = 8,
			Info = 920058,
			Ability = {
				{
					Value = 200001,
					Num = 360,
				},
				{
					Value = 200007,
					Num = 48,
				},
			},
			SkillList = {
				{
					Id = 100651,
					Value = 5,
				},
			},
		},
		{
			Level = 9,
			Info = 920058,
			Ability = {
				{
					Value = 200001,
					Num = 405,
				},
				{
					Value = 200007,
					Num = 54,
				},
			},
			SkillList = {
				{
					Id = 100651,
					Value = 5,
				},
			},
		},
		{
			Level = 10,
			Info = 920058,
			Ability = {
				{
					Value = 200001,
					Num = 450,
				},
				{
					Value = 200007,
					Num = 60,
				},
			},
			SkillList = {
				{
					Id = 100651,
					Value = 5,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id036] =
{
	Character = 220017,
	Rarity = 2,
	NeedChallenge = 145017,
	UpgradeId = 930006,
	LevelList = {
		{
			Level = 1,
			Info = 920059,
			Ability = {
				{
					Value = 200002,
					Num = 33,
				},
				{
					Value = 200008,
					Num = 3,
				},
			},
		},
		{
			Level = 2,
			Info = 920059,
			Ability = {
				{
					Value = 200002,
					Num = 66,
				},
				{
					Value = 200008,
					Num = 6,
				},
			},
		},
		{
			Level = 3,
			Info = 920059,
			Ability = {
				{
					Value = 200002,
					Num = 99,
				},
				{
					Value = 200008,
					Num = 9,
				},
			},
		},
		{
			Level = 4,
			Info = 920059,
			Ability = {
				{
					Value = 200002,
					Num = 132,
				},
				{
					Value = 200008,
					Num = 12,
				},
			},
		},
		{
			Level = 5,
			Info = 920059,
			Ability = {
				{
					Value = 200002,
					Num = 165,
				},
				{
					Value = 200008,
					Num = 15,
				},
			},
			SkillList = {
				{
					Id = 101523,
					Value = -20,
				},
			},
		},
		{
			Level = 6,
			Info = 920059,
			Ability = {
				{
					Value = 200002,
					Num = 198,
				},
				{
					Value = 200008,
					Num = 18,
				},
			},
			SkillList = {
				{
					Id = 101523,
					Value = -20,
				},
			},
		},
		{
			Level = 7,
			Info = 920059,
			Ability = {
				{
					Value = 200002,
					Num = 231,
				},
				{
					Value = 200008,
					Num = 21,
				},
			},
			SkillList = {
				{
					Id = 101523,
					Value = -20,
				},
			},
		},
		{
			Level = 8,
			Info = 920059,
			Ability = {
				{
					Value = 200002,
					Num = 264,
				},
				{
					Value = 200008,
					Num = 24,
				},
			},
			SkillList = {
				{
					Id = 101523,
					Value = -20,
				},
			},
		},
		{
			Level = 9,
			Info = 920059,
			Ability = {
				{
					Value = 200002,
					Num = 297,
				},
				{
					Value = 200008,
					Num = 27,
				},
			},
			SkillList = {
				{
					Id = 101523,
					Value = -20,
				},
			},
		},
		{
			Level = 10,
			Info = 920059,
			Ability = {
				{
					Value = 200002,
					Num = 330,
				},
				{
					Value = 200008,
					Num = 30,
				},
			},
			SkillList = {
				{
					Id = 101523,
					Value = -20,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id037] =
{
	Character = 220018,
	Rarity = 2,
	UpgradeId = 930005,
	LevelList = {
		{
			Level = 1,
			Info = 920060,
			Ability = {
				{
					Value = 200002,
					Num = 36,
				},
				{
					Value = 200005,
					Num = 6,
				},
			},
		},
		{
			Level = 2,
			Info = 920060,
			Ability = {
				{
					Value = 200002,
					Num = 72,
				},
				{
					Value = 200005,
					Num = 12,
				},
			},
		},
		{
			Level = 3,
			Info = 920060,
			Ability = {
				{
					Value = 200002,
					Num = 108,
				},
				{
					Value = 200005,
					Num = 18,
				},
			},
		},
		{
			Level = 4,
			Info = 920060,
			Ability = {
				{
					Value = 200002,
					Num = 144,
				},
				{
					Value = 200005,
					Num = 24,
				},
			},
		},
		{
			Level = 5,
			Info = 920060,
			Ability = {
				{
					Value = 200002,
					Num = 180,
				},
				{
					Value = 200005,
					Num = 30,
				},
			},
			SkillList = {
				{
					Id = 100652,
					Value = 5,
				},
			},
		},
		{
			Level = 6,
			Info = 920060,
			Ability = {
				{
					Value = 200002,
					Num = 216,
				},
				{
					Value = 200005,
					Num = 36,
				},
			},
			SkillList = {
				{
					Id = 100652,
					Value = 5,
				},
			},
		},
		{
			Level = 7,
			Info = 920060,
			Ability = {
				{
					Value = 200002,
					Num = 252,
				},
				{
					Value = 200005,
					Num = 42,
				},
			},
			SkillList = {
				{
					Id = 100652,
					Value = 5,
				},
			},
		},
		{
			Level = 8,
			Info = 920060,
			Ability = {
				{
					Value = 200002,
					Num = 288,
				},
				{
					Value = 200005,
					Num = 48,
				},
			},
			SkillList = {
				{
					Id = 100652,
					Value = 5,
				},
			},
		},
		{
			Level = 9,
			Info = 920060,
			Ability = {
				{
					Value = 200002,
					Num = 324,
				},
				{
					Value = 200005,
					Num = 54,
				},
			},
			SkillList = {
				{
					Id = 100652,
					Value = 5,
				},
			},
		},
		{
			Level = 10,
			Info = 920060,
			Ability = {
				{
					Value = 200002,
					Num = 360,
				},
				{
					Value = 200005,
					Num = 60,
				},
			},
			SkillList = {
				{
					Id = 100652,
					Value = 5,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id038] =
{
	Character = 220018,
	Rarity = 2,
	NeedChallenge = 145018,
	UpgradeId = 930006,
	LevelList = {
		{
			Level = 1,
			Info = 920061,
			Ability = {
				{
					Value = 200002,
					Num = 36,
				},
				{
					Value = 200008,
					Num = 3,
				},
			},
		},
		{
			Level = 2,
			Info = 920061,
			Ability = {
				{
					Value = 200002,
					Num = 72,
				},
				{
					Value = 200008,
					Num = 6,
				},
			},
		},
		{
			Level = 3,
			Info = 920061,
			Ability = {
				{
					Value = 200002,
					Num = 108,
				},
				{
					Value = 200008,
					Num = 9,
				},
			},
		},
		{
			Level = 4,
			Info = 920061,
			Ability = {
				{
					Value = 200002,
					Num = 144,
				},
				{
					Value = 200008,
					Num = 12,
				},
			},
		},
		{
			Level = 5,
			Info = 920061,
			Ability = {
				{
					Value = 200002,
					Num = 180,
				},
				{
					Value = 200008,
					Num = 15,
				},
			},
		},
		{
			Level = 6,
			Info = 920061,
			Ability = {
				{
					Value = 200002,
					Num = 216,
				},
				{
					Value = 200008,
					Num = 18,
				},
			},
		},
		{
			Level = 7,
			Info = 920061,
			Ability = {
				{
					Value = 200002,
					Num = 252,
				},
				{
					Value = 200008,
					Num = 21,
				},
			},
		},
		{
			Level = 8,
			Info = 920061,
			Ability = {
				{
					Value = 200002,
					Num = 288,
				},
				{
					Value = 200008,
					Num = 24,
				},
			},
			SkillList = {
				{
					Id = 101761,
					Value = 75,
				},
			},
		},
		{
			Level = 9,
			Info = 920061,
			Ability = {
				{
					Value = 200002,
					Num = 324,
				},
				{
					Value = 200008,
					Num = 27,
				},
			},
			SkillList = {
				{
					Id = 101761,
					Value = 75,
				},
			},
		},
		{
			Level = 10,
			Info = 920061,
			Ability = {
				{
					Value = 200002,
					Num = 360,
				},
				{
					Value = 200008,
					Num = 30,
				},
			},
			SkillList = {
				{
					Id = 101761,
					Value = 75,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id039] =
{
	Character = 220019,
	Rarity = 3,
	UpgradeId = 930009,
	LevelList = {
		{
			Level = 1,
			Info = 920062,
			Ability = {
				{
					Value = 200002,
					Num = 30,
				},
				{
					Value = 200005,
					Num = 9,
				},
			},
		},
		{
			Level = 2,
			Info = 920062,
			Ability = {
				{
					Value = 200002,
					Num = 60,
				},
				{
					Value = 200005,
					Num = 18,
				},
			},
		},
		{
			Level = 3,
			Info = 920062,
			Ability = {
				{
					Value = 200002,
					Num = 90,
				},
				{
					Value = 200005,
					Num = 27,
				},
			},
		},
		{
			Level = 4,
			Info = 920062,
			Ability = {
				{
					Value = 200002,
					Num = 120,
				},
				{
					Value = 200005,
					Num = 36,
				},
			},
		},
		{
			Level = 5,
			Info = 920062,
			Ability = {
				{
					Value = 200002,
					Num = 150,
				},
				{
					Value = 200005,
					Num = 45,
				},
			},
			SkillList = {
				{
					Id = 100652,
					Value = 5,
				},
			},
		},
		{
			Level = 6,
			Info = 920062,
			Ability = {
				{
					Value = 200002,
					Num = 180,
				},
				{
					Value = 200005,
					Num = 54,
				},
			},
			SkillList = {
				{
					Id = 100652,
					Value = 5,
				},
			},
		},
		{
			Level = 7,
			Info = 920062,
			Ability = {
				{
					Value = 200002,
					Num = 210,
				},
				{
					Value = 200005,
					Num = 63,
				},
			},
			SkillList = {
				{
					Id = 100652,
					Value = 5,
				},
			},
		},
		{
			Level = 8,
			Info = 920062,
			Ability = {
				{
					Value = 200002,
					Num = 240,
				},
				{
					Value = 200005,
					Num = 72,
				},
			},
			SkillList = {
				{
					Id = 100652,
					Value = 5,
				},
			},
		},
		{
			Level = 9,
			Info = 920062,
			Ability = {
				{
					Value = 200002,
					Num = 270,
				},
				{
					Value = 200005,
					Num = 81,
				},
			},
			SkillList = {
				{
					Id = 100652,
					Value = 5,
				},
			},
		},
		{
			Level = 10,
			Info = 920062,
			Ability = {
				{
					Value = 200002,
					Num = 300,
				},
				{
					Value = 200005,
					Num = 90,
				},
			},
			SkillList = {
				{
					Id = 100652,
					Value = 5,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id040] =
{
	Character = 220019,
	Rarity = 3,
	UpgradeId = 930030,
	LevelList = {
		{
			Level = 1,
			Info = 920063,
			Ability = {
				{
					Value = 200001,
					Num = 54,
				},
				{
					Value = 200008,
					Num = 6,
				},
			},
		},
		{
			Level = 2,
			Info = 920063,
			Ability = {
				{
					Value = 200001,
					Num = 108,
				},
				{
					Value = 200008,
					Num = 12,
				},
			},
		},
		{
			Level = 3,
			Info = 920063,
			Ability = {
				{
					Value = 200001,
					Num = 162,
				},
				{
					Value = 200008,
					Num = 18,
				},
			},
		},
		{
			Level = 4,
			Info = 920063,
			Ability = {
				{
					Value = 200001,
					Num = 216,
				},
				{
					Value = 200008,
					Num = 24,
				},
			},
		},
		{
			Level = 5,
			Info = 920063,
			Ability = {
				{
					Value = 200001,
					Num = 270,
				},
				{
					Value = 200008,
					Num = 30,
				},
			},
		},
		{
			Level = 6,
			Info = 920063,
			Ability = {
				{
					Value = 200001,
					Num = 324,
				},
				{
					Value = 200008,
					Num = 36,
				},
			},
		},
		{
			Level = 7,
			Info = 920063,
			Ability = {
				{
					Value = 200001,
					Num = 378,
				},
				{
					Value = 200008,
					Num = 42,
				},
			},
		},
		{
			Level = 8,
			Info = 920063,
			Ability = {
				{
					Value = 200001,
					Num = 432,
				},
				{
					Value = 200008,
					Num = 48,
				},
			},
			SkillList = {
				{
					Id = 100563,
					Value = -5,
				},
			},
		},
		{
			Level = 9,
			Info = 920063,
			Ability = {
				{
					Value = 200001,
					Num = 486,
				},
				{
					Value = 200008,
					Num = 54,
				},
			},
			SkillList = {
				{
					Id = 100563,
					Value = -5,
				},
			},
		},
		{
			Level = 10,
			Info = 920063,
			Ability = {
				{
					Value = 200001,
					Num = 540,
				},
				{
					Value = 200008,
					Num = 60,
				},
			},
			SkillList = {
				{
					Id = 100563,
					Value = -5,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id041] =
{
	Character = 220019,
	Rarity = 3,
	NeedChallenge = 145019,
	UpgradeId = 930011,
	LevelList = {
		{
			Level = 1,
			Info = 920064,
			Ability = {
				{
					Value = 200002,
					Num = 60,
				},
			},
		},
		{
			Level = 2,
			Info = 920064,
			Ability = {
				{
					Value = 200002,
					Num = 100,
				},
			},
		},
		{
			Level = 3,
			Info = 920064,
			Ability = {
				{
					Value = 200002,
					Num = 140,
				},
			},
		},
		{
			Level = 4,
			Info = 920064,
			Ability = {
				{
					Value = 200002,
					Num = 180,
				},
			},
		},
		{
			Level = 5,
			Info = 920064,
			Ability = {
				{
					Value = 200002,
					Num = 220,
				},
				{
					Value = 200004,
					Num = 25,
				},
			},
		},
		{
			Level = 6,
			Info = 920064,
			Ability = {
				{
					Value = 200002,
					Num = 260,
				},
				{
					Value = 200004,
					Num = 30,
				},
			},
		},
		{
			Level = 7,
			Info = 920064,
			Ability = {
				{
					Value = 200002,
					Num = 300,
				},
				{
					Value = 200004,
					Num = 35,
				},
			},
		},
		{
			Level = 8,
			Info = 920064,
			Ability = {
				{
					Value = 200002,
					Num = 340,
				},
				{
					Value = 200004,
					Num = 40,
				},
			},
			SkillList = {
				{
					Id = 100605,
					Value = 36,
				},
			},
		},
		{
			Level = 9,
			Info = 920064,
			Ability = {
				{
					Value = 200002,
					Num = 380,
				},
				{
					Value = 200004,
					Num = 45,
				},
			},
			SkillList = {
				{
					Id = 100605,
					Value = 36,
				},
			},
		},
		{
			Level = 10,
			Info = 920064,
			Ability = {
				{
					Value = 200002,
					Num = 420,
				},
				{
					Value = 200004,
					Num = 50,
				},
			},
			SkillList = {
				{
					Id = 100605,
					Value = 36,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id042] =
{
	Character = 220020,
	Rarity = 3,
	UpgradeId = 930009,
	LevelList = {
		{
			Level = 1,
			Info = 920065,
			Ability = {
				{
					Value = 200002,
					Num = 42,
				},
				{
					Value = 200005,
					Num = 9,
				},
			},
		},
		{
			Level = 2,
			Info = 920065,
			Ability = {
				{
					Value = 200002,
					Num = 84,
				},
				{
					Value = 200005,
					Num = 18,
				},
			},
		},
		{
			Level = 3,
			Info = 920065,
			Ability = {
				{
					Value = 200002,
					Num = 126,
				},
				{
					Value = 200005,
					Num = 27,
				},
			},
		},
		{
			Level = 4,
			Info = 920065,
			Ability = {
				{
					Value = 200002,
					Num = 168,
				},
				{
					Value = 200005,
					Num = 36,
				},
			},
		},
		{
			Level = 5,
			Info = 920065,
			Ability = {
				{
					Value = 200002,
					Num = 210,
				},
				{
					Value = 200005,
					Num = 45,
				},
			},
		},
		{
			Level = 6,
			Info = 920065,
			Ability = {
				{
					Value = 200002,
					Num = 252,
				},
				{
					Value = 200005,
					Num = 54,
				},
			},
		},
		{
			Level = 7,
			Info = 920065,
			Ability = {
				{
					Value = 200002,
					Num = 294,
				},
				{
					Value = 200005,
					Num = 63,
				},
			},
		},
		{
			Level = 8,
			Info = 920065,
			Ability = {
				{
					Value = 200002,
					Num = 336,
				},
				{
					Value = 200005,
					Num = 72,
				},
			},
			SkillList = {
				{
					Id = 100551,
					Value = 25,
				},
			},
		},
		{
			Level = 9,
			Info = 920065,
			Ability = {
				{
					Value = 200002,
					Num = 378,
				},
				{
					Value = 200005,
					Num = 81,
				},
			},
			SkillList = {
				{
					Id = 100551,
					Value = 25,
				},
			},
		},
		{
			Level = 10,
			Info = 920065,
			Ability = {
				{
					Value = 200002,
					Num = 420,
				},
				{
					Value = 200005,
					Num = 90,
				},
			},
			SkillList = {
				{
					Id = 100551,
					Value = 25,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id043] =
{
	Character = 220020,
	Rarity = 3,
	UpgradeId = 930010,
	LevelList = {
		{
			Level = 1,
			Info = 920066,
			Ability = {
				{
					Value = 200002,
					Num = 42,
				},
				{
					Value = 200007,
					Num = 6,
				},
			},
		},
		{
			Level = 2,
			Info = 920066,
			Ability = {
				{
					Value = 200002,
					Num = 84,
				},
				{
					Value = 200007,
					Num = 12,
				},
			},
		},
		{
			Level = 3,
			Info = 920066,
			Ability = {
				{
					Value = 200002,
					Num = 126,
				},
				{
					Value = 200007,
					Num = 18,
				},
			},
		},
		{
			Level = 4,
			Info = 920066,
			Ability = {
				{
					Value = 200002,
					Num = 168,
				},
				{
					Value = 200007,
					Num = 24,
				},
			},
		},
		{
			Level = 5,
			Info = 920066,
			Ability = {
				{
					Value = 200002,
					Num = 210,
				},
				{
					Value = 200007,
					Num = 30,
				},
			},
			SkillList = {
				{
					Id = 101738,
					Value = 10,
				},
			},
		},
		{
			Level = 6,
			Info = 920066,
			Ability = {
				{
					Value = 200002,
					Num = 252,
				},
				{
					Value = 200007,
					Num = 36,
				},
			},
			SkillList = {
				{
					Id = 101738,
					Value = 10,
				},
			},
		},
		{
			Level = 7,
			Info = 920066,
			Ability = {
				{
					Value = 200002,
					Num = 294,
				},
				{
					Value = 200007,
					Num = 42,
				},
			},
			SkillList = {
				{
					Id = 101738,
					Value = 10,
				},
			},
		},
		{
			Level = 8,
			Info = 920066,
			Ability = {
				{
					Value = 200002,
					Num = 336,
				},
				{
					Value = 200007,
					Num = 48,
				},
			},
			SkillList = {
				{
					Id = 101738,
					Value = 10,
				},
			},
		},
		{
			Level = 9,
			Info = 920066,
			Ability = {
				{
					Value = 200002,
					Num = 378,
				},
				{
					Value = 200007,
					Num = 54,
				},
			},
			SkillList = {
				{
					Id = 101738,
					Value = 10,
				},
			},
		},
		{
			Level = 10,
			Info = 920066,
			Ability = {
				{
					Value = 200002,
					Num = 420,
				},
				{
					Value = 200007,
					Num = 60,
				},
			},
			SkillList = {
				{
					Id = 101738,
					Value = 10,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id044] =
{
	Character = 220020,
	Rarity = 3,
	NeedChallenge = 145020,
	UpgradeId = 930011,
	LevelList = {
		{
			Level = 1,
			Info = 920067,
			Ability = {
				{
					Value = 200002,
					Num = 84,
				},
			},
		},
		{
			Level = 2,
			Info = 920067,
			Ability = {
				{
					Value = 200002,
					Num = 140,
				},
			},
		},
		{
			Level = 3,
			Info = 920067,
			Ability = {
				{
					Value = 200002,
					Num = 196,
				},
			},
		},
		{
			Level = 4,
			Info = 920067,
			Ability = {
				{
					Value = 200002,
					Num = 252,
				},
			},
		},
		{
			Level = 5,
			Info = 920067,
			Ability = {
				{
					Value = 200002,
					Num = 308,
				},
				{
					Value = 200004,
					Num = 25,
				},
			},
		},
		{
			Level = 6,
			Info = 920067,
			Ability = {
				{
					Value = 200002,
					Num = 364,
				},
				{
					Value = 200004,
					Num = 30,
				},
			},
		},
		{
			Level = 7,
			Info = 920067,
			Ability = {
				{
					Value = 200002,
					Num = 420,
				},
				{
					Value = 200004,
					Num = 35,
				},
			},
		},
		{
			Level = 8,
			Info = 920067,
			Ability = {
				{
					Value = 200002,
					Num = 476,
				},
				{
					Value = 200004,
					Num = 40,
				},
			},
			SkillList = {
				{
					Id = 101744,
					Value = 7,
				},
			},
		},
		{
			Level = 9,
			Info = 920067,
			Ability = {
				{
					Value = 200002,
					Num = 532,
				},
				{
					Value = 200004,
					Num = 45,
				},
			},
			SkillList = {
				{
					Id = 101744,
					Value = 7,
				},
			},
		},
		{
			Level = 10,
			Info = 920067,
			Ability = {
				{
					Value = 200002,
					Num = 588,
				},
				{
					Value = 200004,
					Num = 50,
				},
			},
			SkillList = {
				{
					Id = 101744,
					Value = 7,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id045] =
{
	Character = 220021,
	Rarity = 3,
	UpgradeId = 930009,
	LevelList = {
		{
			Level = 1,
			Info = 920068,
			Ability = {
				{
					Value = 200002,
					Num = 42,
				},
				{
					Value = 200006,
					Num = 9,
				},
			},
		},
		{
			Level = 2,
			Info = 920068,
			Ability = {
				{
					Value = 200002,
					Num = 84,
				},
				{
					Value = 200006,
					Num = 18,
				},
			},
		},
		{
			Level = 3,
			Info = 920068,
			Ability = {
				{
					Value = 200002,
					Num = 126,
				},
				{
					Value = 200006,
					Num = 27,
				},
			},
		},
		{
			Level = 4,
			Info = 920068,
			Ability = {
				{
					Value = 200002,
					Num = 168,
				},
				{
					Value = 200006,
					Num = 36,
				},
			},
		},
		{
			Level = 5,
			Info = 920068,
			Ability = {
				{
					Value = 200002,
					Num = 210,
				},
				{
					Value = 200006,
					Num = 45,
				},
			},
		},
		{
			Level = 6,
			Info = 920068,
			Ability = {
				{
					Value = 200002,
					Num = 252,
				},
				{
					Value = 200006,
					Num = 54,
				},
			},
		},
		{
			Level = 7,
			Info = 920068,
			Ability = {
				{
					Value = 200002,
					Num = 294,
				},
				{
					Value = 200006,
					Num = 63,
				},
			},
		},
		{
			Level = 8,
			Info = 920068,
			Ability = {
				{
					Value = 200002,
					Num = 336,
				},
				{
					Value = 200006,
					Num = 72,
				},
			},
			SkillList = {
				{
					Id = 100555,
					Value = 25,
				},
			},
		},
		{
			Level = 9,
			Info = 920068,
			Ability = {
				{
					Value = 200002,
					Num = 378,
				},
				{
					Value = 200006,
					Num = 81,
				},
			},
			SkillList = {
				{
					Id = 100555,
					Value = 25,
				},
			},
		},
		{
			Level = 10,
			Info = 920068,
			Ability = {
				{
					Value = 200002,
					Num = 420,
				},
				{
					Value = 200006,
					Num = 90,
				},
			},
			SkillList = {
				{
					Id = 100555,
					Value = 25,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id046] =
{
	Character = 220021,
	Rarity = 3,
	UpgradeId = 930010,
	LevelList = {
		{
			Level = 1,
			Info = 920069,
			Ability = {
				{
					Value = 200002,
					Num = 42,
				},
				{
					Value = 200008,
					Num = 6,
				},
			},
		},
		{
			Level = 2,
			Info = 920069,
			Ability = {
				{
					Value = 200002,
					Num = 84,
				},
				{
					Value = 200008,
					Num = 12,
				},
			},
		},
		{
			Level = 3,
			Info = 920069,
			Ability = {
				{
					Value = 200002,
					Num = 126,
				},
				{
					Value = 200008,
					Num = 18,
				},
			},
		},
		{
			Level = 4,
			Info = 920069,
			Ability = {
				{
					Value = 200002,
					Num = 168,
				},
				{
					Value = 200008,
					Num = 24,
				},
			},
		},
		{
			Level = 5,
			Info = 920069,
			Ability = {
				{
					Value = 200002,
					Num = 210,
				},
				{
					Value = 200008,
					Num = 30,
				},
			},
			SkillList = {
				{
					Id = 101710,
					Value = 149,
				},
			},
		},
		{
			Level = 6,
			Info = 920069,
			Ability = {
				{
					Value = 200002,
					Num = 252,
				},
				{
					Value = 200008,
					Num = 36,
				},
			},
			SkillList = {
				{
					Id = 101710,
					Value = 161,
				},
			},
		},
		{
			Level = 7,
			Info = 920069,
			Ability = {
				{
					Value = 200002,
					Num = 294,
				},
				{
					Value = 200008,
					Num = 42,
				},
			},
			SkillList = {
				{
					Id = 101710,
					Value = 173,
				},
			},
		},
		{
			Level = 8,
			Info = 920069,
			Ability = {
				{
					Value = 200002,
					Num = 336,
				},
				{
					Value = 200008,
					Num = 48,
				},
			},
			SkillList = {
				{
					Id = 101710,
					Value = 185,
				},
			},
		},
		{
			Level = 9,
			Info = 920069,
			Ability = {
				{
					Value = 200002,
					Num = 378,
				},
				{
					Value = 200008,
					Num = 54,
				},
			},
			SkillList = {
				{
					Id = 101710,
					Value = 197,
				},
			},
		},
		{
			Level = 10,
			Info = 920069,
			Ability = {
				{
					Value = 200002,
					Num = 420,
				},
				{
					Value = 200008,
					Num = 60,
				},
			},
			SkillList = {
				{
					Id = 101710,
					Value = 209,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id047] =
{
	Character = 220021,
	Rarity = 3,
	NeedChallenge = 145021,
	UpgradeId = 930031,
	LevelList = {
		{
			Level = 1,
			Info = 920070,
			Ability = {
				{
					Value = 200001,
					Num = 108,
				},
			},
		},
		{
			Level = 2,
			Info = 920070,
			Ability = {
				{
					Value = 200001,
					Num = 180,
				},
			},
		},
		{
			Level = 3,
			Info = 920070,
			Ability = {
				{
					Value = 200001,
					Num = 252,
				},
			},
		},
		{
			Level = 4,
			Info = 920070,
			Ability = {
				{
					Value = 200001,
					Num = 324,
				},
			},
		},
		{
			Level = 5,
			Info = 920070,
			Ability = {
				{
					Value = 200001,
					Num = 396,
				},
				{
					Value = 200003,
					Num = 25,
				},
			},
		},
		{
			Level = 6,
			Info = 920070,
			Ability = {
				{
					Value = 200001,
					Num = 468,
				},
				{
					Value = 200003,
					Num = 30,
				},
			},
		},
		{
			Level = 7,
			Info = 920070,
			Ability = {
				{
					Value = 200001,
					Num = 540,
				},
				{
					Value = 200003,
					Num = 35,
				},
			},
		},
		{
			Level = 8,
			Info = 920070,
			Ability = {
				{
					Value = 200001,
					Num = 612,
				},
				{
					Value = 200003,
					Num = 40,
				},
			},
			SkillList = {
				{
					Id = 101718,
					Value = 241,
				},
			},
		},
		{
			Level = 9,
			Info = 920070,
			Ability = {
				{
					Value = 200001,
					Num = 684,
				},
				{
					Value = 200003,
					Num = 45,
				},
			},
			SkillList = {
				{
					Id = 101718,
					Value = 261,
				},
			},
		},
		{
			Level = 10,
			Info = 920070,
			Ability = {
				{
					Value = 200001,
					Num = 756,
				},
				{
					Value = 200003,
					Num = 50,
				},
			},
			SkillList = {
				{
					Id = 101718,
					Value = 281,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id048] =
{
	Character = 220022,
	Rarity = 3,
	UpgradeId = 930009,
	LevelList = {
		{
			Level = 1,
			Info = 920071,
			Ability = {
				{
					Value = 200002,
					Num = 42,
				},
				{
					Value = 200005,
					Num = 9,
				},
			},
		},
		{
			Level = 2,
			Info = 920071,
			Ability = {
				{
					Value = 200002,
					Num = 84,
				},
				{
					Value = 200005,
					Num = 18,
				},
			},
		},
		{
			Level = 3,
			Info = 920071,
			Ability = {
				{
					Value = 200002,
					Num = 126,
				},
				{
					Value = 200005,
					Num = 27,
				},
			},
		},
		{
			Level = 4,
			Info = 920071,
			Ability = {
				{
					Value = 200002,
					Num = 168,
				},
				{
					Value = 200005,
					Num = 36,
				},
			},
		},
		{
			Level = 5,
			Info = 920071,
			Ability = {
				{
					Value = 200002,
					Num = 210,
				},
				{
					Value = 200005,
					Num = 45,
				},
			},
			SkillList = {
				{
					Id = 100652,
					Value = 5,
				},
			},
		},
		{
			Level = 6,
			Info = 920071,
			Ability = {
				{
					Value = 200002,
					Num = 252,
				},
				{
					Value = 200005,
					Num = 54,
				},
			},
			SkillList = {
				{
					Id = 100652,
					Value = 5,
				},
			},
		},
		{
			Level = 7,
			Info = 920071,
			Ability = {
				{
					Value = 200002,
					Num = 294,
				},
				{
					Value = 200005,
					Num = 63,
				},
			},
			SkillList = {
				{
					Id = 100652,
					Value = 5,
				},
			},
		},
		{
			Level = 8,
			Info = 920071,
			Ability = {
				{
					Value = 200002,
					Num = 336,
				},
				{
					Value = 200005,
					Num = 72,
				},
			},
			SkillList = {
				{
					Id = 100652,
					Value = 5,
				},
			},
		},
		{
			Level = 9,
			Info = 920071,
			Ability = {
				{
					Value = 200002,
					Num = 378,
				},
				{
					Value = 200005,
					Num = 81,
				},
			},
			SkillList = {
				{
					Id = 100652,
					Value = 5,
				},
			},
		},
		{
			Level = 10,
			Info = 920071,
			Ability = {
				{
					Value = 200002,
					Num = 420,
				},
				{
					Value = 200005,
					Num = 90,
				},
			},
			SkillList = {
				{
					Id = 100652,
					Value = 5,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id049] =
{
	Character = 220022,
	Rarity = 3,
	UpgradeId = 930010,
	LevelList = {
		{
			Level = 1,
			Info = 920072,
			Ability = {
				{
					Value = 200002,
					Num = 42,
				},
				{
					Value = 200008,
					Num = 6,
				},
			},
		},
		{
			Level = 2,
			Info = 920072,
			Ability = {
				{
					Value = 200002,
					Num = 84,
				},
				{
					Value = 200008,
					Num = 12,
				},
			},
		},
		{
			Level = 3,
			Info = 920072,
			Ability = {
				{
					Value = 200002,
					Num = 126,
				},
				{
					Value = 200008,
					Num = 18,
				},
			},
		},
		{
			Level = 4,
			Info = 920072,
			Ability = {
				{
					Value = 200002,
					Num = 168,
				},
				{
					Value = 200008,
					Num = 24,
				},
			},
		},
		{
			Level = 5,
			Info = 920072,
			Ability = {
				{
					Value = 200002,
					Num = 210,
				},
				{
					Value = 200008,
					Num = 30,
				},
			},
		},
		{
			Level = 6,
			Info = 920072,
			Ability = {
				{
					Value = 200002,
					Num = 252,
				},
				{
					Value = 200008,
					Num = 36,
				},
			},
		},
		{
			Level = 7,
			Info = 920072,
			Ability = {
				{
					Value = 200002,
					Num = 294,
				},
				{
					Value = 200008,
					Num = 42,
				},
			},
		},
		{
			Level = 8,
			Info = 920072,
			Ability = {
				{
					Value = 200002,
					Num = 336,
				},
				{
					Value = 200008,
					Num = 48,
				},
			},
			SkillList = {
				{
					Id = 100554,
					Value = 25,
				},
			},
		},
		{
			Level = 9,
			Info = 920072,
			Ability = {
				{
					Value = 200002,
					Num = 378,
				},
				{
					Value = 200008,
					Num = 54,
				},
			},
			SkillList = {
				{
					Id = 100554,
					Value = 25,
				},
			},
		},
		{
			Level = 10,
			Info = 920072,
			Ability = {
				{
					Value = 200002,
					Num = 420,
				},
				{
					Value = 200008,
					Num = 60,
				},
			},
			SkillList = {
				{
					Id = 100554,
					Value = 25,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id050] =
{
	Character = 220022,
	Rarity = 3,
	NeedChallenge = 145022,
	UpgradeId = 930011,
	LevelList = {
		{
			Level = 1,
			Info = 920073,
			Ability = {
				{
					Value = 200002,
					Num = 84,
				},
			},
		},
		{
			Level = 2,
			Info = 920073,
			Ability = {
				{
					Value = 200002,
					Num = 140,
				},
			},
		},
		{
			Level = 3,
			Info = 920073,
			Ability = {
				{
					Value = 200002,
					Num = 196,
				},
			},
		},
		{
			Level = 4,
			Info = 920073,
			Ability = {
				{
					Value = 200002,
					Num = 252,
				},
			},
		},
		{
			Level = 5,
			Info = 920073,
			Ability = {
				{
					Value = 200002,
					Num = 308,
				},
				{
					Value = 200004,
					Num = 25,
				},
			},
		},
		{
			Level = 6,
			Info = 920073,
			Ability = {
				{
					Value = 200002,
					Num = 364,
				},
				{
					Value = 200004,
					Num = 30,
				},
			},
		},
		{
			Level = 7,
			Info = 920073,
			Ability = {
				{
					Value = 200002,
					Num = 420,
				},
				{
					Value = 200004,
					Num = 35,
				},
			},
		},
		{
			Level = 8,
			Info = 920073,
			Ability = {
				{
					Value = 200002,
					Num = 476,
				},
				{
					Value = 200004,
					Num = 40,
				},
			},
			SkillList = {
				{
					Id = 101738,
					Value = 15,
				},
			},
		},
		{
			Level = 9,
			Info = 920073,
			Ability = {
				{
					Value = 200002,
					Num = 532,
				},
				{
					Value = 200004,
					Num = 45,
				},
			},
			SkillList = {
				{
					Id = 101738,
					Value = 15,
				},
			},
		},
		{
			Level = 10,
			Info = 920073,
			Ability = {
				{
					Value = 200002,
					Num = 588,
				},
				{
					Value = 200004,
					Num = 50,
				},
			},
			SkillList = {
				{
					Id = 101738,
					Value = 15,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id051] =
{
	Character = 220023,
	Rarity = 3,
	UpgradeId = 930009,
	LevelList = {
		{
			Level = 1,
			Info = 920074,
			Ability = {
				{
					Value = 200002,
					Num = 42,
				},
				{
					Value = 200006,
					Num = 9,
				},
			},
		},
		{
			Level = 2,
			Info = 920074,
			Ability = {
				{
					Value = 200002,
					Num = 84,
				},
				{
					Value = 200006,
					Num = 18,
				},
			},
		},
		{
			Level = 3,
			Info = 920074,
			Ability = {
				{
					Value = 200002,
					Num = 126,
				},
				{
					Value = 200006,
					Num = 27,
				},
			},
		},
		{
			Level = 4,
			Info = 920074,
			Ability = {
				{
					Value = 200002,
					Num = 168,
				},
				{
					Value = 200006,
					Num = 36,
				},
			},
		},
		{
			Level = 5,
			Info = 920074,
			Ability = {
				{
					Value = 200002,
					Num = 210,
				},
				{
					Value = 200006,
					Num = 45,
				},
			},
			SkillList = {
				{
					Id = 100652,
					Value = 5,
				},
			},
		},
		{
			Level = 6,
			Info = 920074,
			Ability = {
				{
					Value = 200002,
					Num = 252,
				},
				{
					Value = 200006,
					Num = 54,
				},
			},
			SkillList = {
				{
					Id = 100652,
					Value = 5,
				},
			},
		},
		{
			Level = 7,
			Info = 920074,
			Ability = {
				{
					Value = 200002,
					Num = 294,
				},
				{
					Value = 200006,
					Num = 63,
				},
			},
			SkillList = {
				{
					Id = 100652,
					Value = 5,
				},
			},
		},
		{
			Level = 8,
			Info = 920074,
			Ability = {
				{
					Value = 200002,
					Num = 336,
				},
				{
					Value = 200006,
					Num = 72,
				},
			},
			SkillList = {
				{
					Id = 100652,
					Value = 5,
				},
			},
		},
		{
			Level = 9,
			Info = 920074,
			Ability = {
				{
					Value = 200002,
					Num = 378,
				},
				{
					Value = 200006,
					Num = 81,
				},
			},
			SkillList = {
				{
					Id = 100652,
					Value = 5,
				},
			},
		},
		{
			Level = 10,
			Info = 920074,
			Ability = {
				{
					Value = 200002,
					Num = 420,
				},
				{
					Value = 200006,
					Num = 90,
				},
			},
			SkillList = {
				{
					Id = 100652,
					Value = 5,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id052] =
{
	Character = 220023,
	Rarity = 3,
	UpgradeId = 930030,
	LevelList = {
		{
			Level = 1,
			Info = 920075,
			Ability = {
				{
					Value = 200001,
					Num = 54,
				},
				{
					Value = 200005,
					Num = 6,
				},
			},
		},
		{
			Level = 2,
			Info = 920075,
			Ability = {
				{
					Value = 200001,
					Num = 108,
				},
				{
					Value = 200005,
					Num = 12,
				},
			},
		},
		{
			Level = 3,
			Info = 920075,
			Ability = {
				{
					Value = 200001,
					Num = 162,
				},
				{
					Value = 200005,
					Num = 18,
				},
			},
		},
		{
			Level = 4,
			Info = 920075,
			Ability = {
				{
					Value = 200001,
					Num = 216,
				},
				{
					Value = 200005,
					Num = 24,
				},
			},
		},
		{
			Level = 5,
			Info = 920075,
			Ability = {
				{
					Value = 200001,
					Num = 270,
				},
				{
					Value = 200005,
					Num = 30,
				},
			},
		},
		{
			Level = 6,
			Info = 920075,
			Ability = {
				{
					Value = 200001,
					Num = 324,
				},
				{
					Value = 200005,
					Num = 36,
				},
			},
		},
		{
			Level = 7,
			Info = 920075,
			Ability = {
				{
					Value = 200001,
					Num = 378,
				},
				{
					Value = 200005,
					Num = 42,
				},
			},
		},
		{
			Level = 8,
			Info = 920075,
			Ability = {
				{
					Value = 200001,
					Num = 432,
				},
				{
					Value = 200005,
					Num = 48,
				},
			},
			SkillList = {
				{
					Id = 100561,
					Value = -5,
				},
			},
		},
		{
			Level = 9,
			Info = 920075,
			Ability = {
				{
					Value = 200001,
					Num = 486,
				},
				{
					Value = 200005,
					Num = 54,
				},
			},
			SkillList = {
				{
					Id = 100561,
					Value = -5,
				},
			},
		},
		{
			Level = 10,
			Info = 920075,
			Ability = {
				{
					Value = 200001,
					Num = 540,
				},
				{
					Value = 200005,
					Num = 60,
				},
			},
			SkillList = {
				{
					Id = 100561,
					Value = -5,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id053] =
{
	Character = 220023,
	Rarity = 3,
	NeedChallenge = 145023,
	UpgradeId = 930011,
	LevelList = {
		{
			Level = 1,
			Info = 920076,
			Ability = {
				{
					Value = 200002,
					Num = 84,
				},
			},
		},
		{
			Level = 2,
			Info = 920076,
			Ability = {
				{
					Value = 200002,
					Num = 140,
				},
			},
		},
		{
			Level = 3,
			Info = 920076,
			Ability = {
				{
					Value = 200002,
					Num = 196,
				},
			},
		},
		{
			Level = 4,
			Info = 920076,
			Ability = {
				{
					Value = 200002,
					Num = 252,
				},
			},
		},
		{
			Level = 5,
			Info = 920076,
			Ability = {
				{
					Value = 200002,
					Num = 308,
				},
				{
					Value = 200004,
					Num = 25,
				},
			},
		},
		{
			Level = 6,
			Info = 920076,
			Ability = {
				{
					Value = 200002,
					Num = 364,
				},
				{
					Value = 200004,
					Num = 30,
				},
			},
		},
		{
			Level = 7,
			Info = 920076,
			Ability = {
				{
					Value = 200002,
					Num = 420,
				},
				{
					Value = 200004,
					Num = 35,
				},
			},
		},
		{
			Level = 8,
			Info = 920076,
			Ability = {
				{
					Value = 200002,
					Num = 476,
				},
				{
					Value = 200004,
					Num = 40,
				},
			},
			SkillList = {
				{
					Id = 101502,
					Value = -4,
				},
			},
		},
		{
			Level = 9,
			Info = 920076,
			Ability = {
				{
					Value = 200002,
					Num = 532,
				},
				{
					Value = 200004,
					Num = 45,
				},
			},
			SkillList = {
				{
					Id = 101502,
					Value = -4,
				},
			},
		},
		{
			Level = 10,
			Info = 920076,
			Ability = {
				{
					Value = 200002,
					Num = 588,
				},
				{
					Value = 200004,
					Num = 50,
				},
			},
			SkillList = {
				{
					Id = 101502,
					Value = -4,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id054] =
{
	Character = 220024,
	Rarity = 3,
	UpgradeId = 930029,
	LevelList = {
		{
			Level = 1,
			Info = 920077,
			Ability = {
				{
					Value = 200001,
					Num = 54,
				},
				{
					Value = 200008,
					Num = 9,
				},
			},
		},
		{
			Level = 2,
			Info = 920077,
			Ability = {
				{
					Value = 200001,
					Num = 108,
				},
				{
					Value = 200008,
					Num = 18,
				},
			},
		},
		{
			Level = 3,
			Info = 920077,
			Ability = {
				{
					Value = 200001,
					Num = 162,
				},
				{
					Value = 200008,
					Num = 27,
				},
			},
		},
		{
			Level = 4,
			Info = 920077,
			Ability = {
				{
					Value = 200001,
					Num = 216,
				},
				{
					Value = 200008,
					Num = 36,
				},
			},
		},
		{
			Level = 5,
			Info = 920077,
			Ability = {
				{
					Value = 200001,
					Num = 270,
				},
				{
					Value = 200008,
					Num = 45,
				},
			},
		},
		{
			Level = 6,
			Info = 920077,
			Ability = {
				{
					Value = 200001,
					Num = 324,
				},
				{
					Value = 200008,
					Num = 54,
				},
			},
		},
		{
			Level = 7,
			Info = 920077,
			Ability = {
				{
					Value = 200001,
					Num = 378,
				},
				{
					Value = 200008,
					Num = 63,
				},
			},
		},
		{
			Level = 8,
			Info = 920077,
			Ability = {
				{
					Value = 200001,
					Num = 432,
				},
				{
					Value = 200008,
					Num = 72,
				},
			},
			SkillList = {
				{
					Id = 100561,
					Value = -5,
				},
			},
		},
		{
			Level = 9,
			Info = 920077,
			Ability = {
				{
					Value = 200001,
					Num = 486,
				},
				{
					Value = 200008,
					Num = 81,
				},
			},
			SkillList = {
				{
					Id = 100561,
					Value = -5,
				},
			},
		},
		{
			Level = 10,
			Info = 920077,
			Ability = {
				{
					Value = 200001,
					Num = 540,
				},
				{
					Value = 200008,
					Num = 90,
				},
			},
			SkillList = {
				{
					Id = 100561,
					Value = -5,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id055] =
{
	Character = 220024,
	Rarity = 3,
	UpgradeId = 930030,
	LevelList = {
		{
			Level = 1,
			Info = 920078,
			Ability = {
				{
					Value = 200001,
					Num = 54,
				},
				{
					Value = 200005,
					Num = 6,
				},
			},
		},
		{
			Level = 2,
			Info = 920078,
			Ability = {
				{
					Value = 200001,
					Num = 108,
				},
				{
					Value = 200005,
					Num = 12,
				},
			},
		},
		{
			Level = 3,
			Info = 920078,
			Ability = {
				{
					Value = 200001,
					Num = 162,
				},
				{
					Value = 200005,
					Num = 18,
				},
			},
		},
		{
			Level = 4,
			Info = 920078,
			Ability = {
				{
					Value = 200001,
					Num = 216,
				},
				{
					Value = 200005,
					Num = 24,
				},
			},
		},
		{
			Level = 5,
			Info = 920078,
			Ability = {
				{
					Value = 200001,
					Num = 270,
				},
				{
					Value = 200005,
					Num = 30,
				},
			},
		},
		{
			Level = 6,
			Info = 920078,
			Ability = {
				{
					Value = 200001,
					Num = 324,
				},
				{
					Value = 200005,
					Num = 36,
				},
			},
		},
		{
			Level = 7,
			Info = 920078,
			Ability = {
				{
					Value = 200001,
					Num = 378,
				},
				{
					Value = 200005,
					Num = 42,
				},
			},
		},
		{
			Level = 8,
			Info = 920078,
			Ability = {
				{
					Value = 200001,
					Num = 432,
				},
				{
					Value = 200005,
					Num = 48,
				},
			},
			SkillList = {
				{
					Id = 100561,
					Value = -5,
				},
			},
		},
		{
			Level = 9,
			Info = 920078,
			Ability = {
				{
					Value = 200001,
					Num = 486,
				},
				{
					Value = 200005,
					Num = 54,
				},
			},
			SkillList = {
				{
					Id = 100561,
					Value = -5,
				},
			},
		},
		{
			Level = 10,
			Info = 920078,
			Ability = {
				{
					Value = 200001,
					Num = 540,
				},
				{
					Value = 200005,
					Num = 60,
				},
			},
			SkillList = {
				{
					Id = 100561,
					Value = -5,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id056] =
{
	Character = 220024,
	Rarity = 3,
	NeedChallenge = 145024,
	UpgradeId = 930011,
	LevelList = {
		{
			Level = 1,
			Info = 920079,
			Ability = {
				{
					Value = 200002,
					Num = 84,
				},
			},
		},
		{
			Level = 2,
			Info = 920079,
			Ability = {
				{
					Value = 200002,
					Num = 140,
				},
			},
		},
		{
			Level = 3,
			Info = 920079,
			Ability = {
				{
					Value = 200002,
					Num = 196,
				},
			},
		},
		{
			Level = 4,
			Info = 920079,
			Ability = {
				{
					Value = 200002,
					Num = 252,
				},
			},
		},
		{
			Level = 5,
			Info = 920079,
			Ability = {
				{
					Value = 200002,
					Num = 308,
				},
				{
					Value = 200004,
					Num = 25,
				},
			},
		},
		{
			Level = 6,
			Info = 920079,
			Ability = {
				{
					Value = 200002,
					Num = 364,
				},
				{
					Value = 200004,
					Num = 30,
				},
			},
		},
		{
			Level = 7,
			Info = 920079,
			Ability = {
				{
					Value = 200002,
					Num = 420,
				},
				{
					Value = 200004,
					Num = 35,
				},
			},
		},
		{
			Level = 8,
			Info = 920079,
			Ability = {
				{
					Value = 200002,
					Num = 476,
				},
				{
					Value = 200004,
					Num = 40,
				},
			},
			SkillList = {
				{
					Id = 101769,
					Value = 100,
				},
			},
		},
		{
			Level = 9,
			Info = 920079,
			Ability = {
				{
					Value = 200002,
					Num = 532,
				},
				{
					Value = 200004,
					Num = 45,
				},
			},
			SkillList = {
				{
					Id = 101769,
					Value = 100,
				},
			},
		},
		{
			Level = 10,
			Info = 920079,
			Ability = {
				{
					Value = 200002,
					Num = 588,
				},
				{
					Value = 200004,
					Num = 50,
				},
			},
			SkillList = {
				{
					Id = 101769,
					Value = 100,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id057] =
{
	Character = 220025,
	Rarity = 3,
	UpgradeId = 930009,
	LevelList = {
		{
			Level = 1,
			Info = 920080,
			Ability = {
				{
					Value = 200002,
					Num = 45,
				},
				{
					Value = 200006,
					Num = 9,
				},
			},
		},
		{
			Level = 2,
			Info = 920080,
			Ability = {
				{
					Value = 200002,
					Num = 90,
				},
				{
					Value = 200006,
					Num = 18,
				},
			},
		},
		{
			Level = 3,
			Info = 920080,
			Ability = {
				{
					Value = 200002,
					Num = 135,
				},
				{
					Value = 200006,
					Num = 27,
				},
			},
		},
		{
			Level = 4,
			Info = 920080,
			Ability = {
				{
					Value = 200002,
					Num = 180,
				},
				{
					Value = 200006,
					Num = 36,
				},
			},
		},
		{
			Level = 5,
			Info = 920080,
			Ability = {
				{
					Value = 200002,
					Num = 225,
				},
				{
					Value = 200006,
					Num = 45,
				},
			},
		},
		{
			Level = 6,
			Info = 920080,
			Ability = {
				{
					Value = 200002,
					Num = 270,
				},
				{
					Value = 200006,
					Num = 54,
				},
			},
		},
		{
			Level = 7,
			Info = 920080,
			Ability = {
				{
					Value = 200002,
					Num = 315,
				},
				{
					Value = 200006,
					Num = 63,
				},
			},
		},
		{
			Level = 8,
			Info = 920080,
			Ability = {
				{
					Value = 200002,
					Num = 360,
				},
				{
					Value = 200006,
					Num = 72,
				},
			},
			SkillList = {
				{
					Id = 100551,
					Value = 25,
				},
			},
		},
		{
			Level = 9,
			Info = 920080,
			Ability = {
				{
					Value = 200002,
					Num = 405,
				},
				{
					Value = 200006,
					Num = 81,
				},
			},
			SkillList = {
				{
					Id = 100551,
					Value = 25,
				},
			},
		},
		{
			Level = 10,
			Info = 920080,
			Ability = {
				{
					Value = 200002,
					Num = 450,
				},
				{
					Value = 200006,
					Num = 90,
				},
			},
			SkillList = {
				{
					Id = 100551,
					Value = 25,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id058] =
{
	Character = 220025,
	Rarity = 3,
	UpgradeId = 930010,
	LevelList = {
		{
			Level = 1,
			Info = 920081,
			Ability = {
				{
					Value = 200002,
					Num = 45,
				},
				{
					Value = 200005,
					Num = 6,
				},
			},
		},
		{
			Level = 2,
			Info = 920081,
			Ability = {
				{
					Value = 200002,
					Num = 90,
				},
				{
					Value = 200005,
					Num = 12,
				},
			},
		},
		{
			Level = 3,
			Info = 920081,
			Ability = {
				{
					Value = 200002,
					Num = 135,
				},
				{
					Value = 200005,
					Num = 18,
				},
			},
		},
		{
			Level = 4,
			Info = 920081,
			Ability = {
				{
					Value = 200002,
					Num = 180,
				},
				{
					Value = 200005,
					Num = 24,
				},
			},
		},
		{
			Level = 5,
			Info = 920081,
			Ability = {
				{
					Value = 200002,
					Num = 225,
				},
				{
					Value = 200005,
					Num = 30,
				},
			},
		},
		{
			Level = 6,
			Info = 920081,
			Ability = {
				{
					Value = 200002,
					Num = 270,
				},
				{
					Value = 200005,
					Num = 36,
				},
			},
		},
		{
			Level = 7,
			Info = 920081,
			Ability = {
				{
					Value = 200002,
					Num = 315,
				},
				{
					Value = 200005,
					Num = 42,
				},
			},
		},
		{
			Level = 8,
			Info = 920081,
			Ability = {
				{
					Value = 200002,
					Num = 360,
				},
				{
					Value = 200005,
					Num = 48,
				},
			},
			SkillList = {
				{
					Id = 100551,
					Value = 25,
				},
			},
		},
		{
			Level = 9,
			Info = 920081,
			Ability = {
				{
					Value = 200002,
					Num = 405,
				},
				{
					Value = 200005,
					Num = 54,
				},
			},
			SkillList = {
				{
					Id = 100551,
					Value = 25,
				},
			},
		},
		{
			Level = 10,
			Info = 920081,
			Ability = {
				{
					Value = 200002,
					Num = 450,
				},
				{
					Value = 200005,
					Num = 60,
				},
			},
			SkillList = {
				{
					Id = 100551,
					Value = 25,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id059] =
{
	Character = 220025,
	Rarity = 3,
	NeedChallenge = 145025,
	UpgradeId = 930011,
	LevelList = {
		{
			Level = 1,
			Info = 920082,
			Ability = {
				{
					Value = 200002,
					Num = 90,
				},
			},
		},
		{
			Level = 2,
			Info = 920082,
			Ability = {
				{
					Value = 200002,
					Num = 150,
				},
			},
		},
		{
			Level = 3,
			Info = 920082,
			Ability = {
				{
					Value = 200002,
					Num = 210,
				},
			},
		},
		{
			Level = 4,
			Info = 920082,
			Ability = {
				{
					Value = 200002,
					Num = 270,
				},
			},
		},
		{
			Level = 5,
			Info = 920082,
			Ability = {
				{
					Value = 200002,
					Num = 330,
				},
				{
					Value = 200004,
					Num = 25,
				},
			},
			SkillList = {
				{
					Id = 101705,
					Value = 22,
				},
			},
		},
		{
			Level = 6,
			Info = 920082,
			Ability = {
				{
					Value = 200002,
					Num = 390,
				},
				{
					Value = 200004,
					Num = 30,
				},
			},
			SkillList = {
				{
					Id = 101705,
					Value = 22,
				},
			},
		},
		{
			Level = 7,
			Info = 920082,
			Ability = {
				{
					Value = 200002,
					Num = 450,
				},
				{
					Value = 200004,
					Num = 35,
				},
			},
			SkillList = {
				{
					Id = 101705,
					Value = 22,
				},
			},
		},
		{
			Level = 8,
			Info = 920082,
			Ability = {
				{
					Value = 200002,
					Num = 510,
				},
				{
					Value = 200004,
					Num = 40,
				},
			},
			SkillList = {
				{
					Id = 101705,
					Value = 22,
				},
			},
		},
		{
			Level = 9,
			Info = 920082,
			Ability = {
				{
					Value = 200002,
					Num = 570,
				},
				{
					Value = 200004,
					Num = 45,
				},
			},
			SkillList = {
				{
					Id = 101705,
					Value = 22,
				},
			},
		},
		{
			Level = 10,
			Info = 920082,
			Ability = {
				{
					Value = 200002,
					Num = 630,
				},
				{
					Value = 200004,
					Num = 50,
				},
			},
			SkillList = {
				{
					Id = 101705,
					Value = 22,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id060] =
{
	Character = 220026,
	Rarity = 4,
	UpgradeId = 930013,
	LevelList = {
		{
			Level = 1,
			Info = 920083,
			Ability = {
				{
					Value = 200002,
					Num = 54,
				},
				{
					Value = 200007,
					Num = 21,
				},
			},
		},
		{
			Level = 2,
			Info = 920083,
			Ability = {
				{
					Value = 200002,
					Num = 108,
				},
				{
					Value = 200007,
					Num = 42,
				},
			},
		},
		{
			Level = 3,
			Info = 920083,
			Ability = {
				{
					Value = 200002,
					Num = 162,
				},
				{
					Value = 200007,
					Num = 63,
				},
			},
		},
		{
			Level = 4,
			Info = 920083,
			Ability = {
				{
					Value = 200002,
					Num = 216,
				},
				{
					Value = 200007,
					Num = 84,
				},
			},
		},
		{
			Level = 5,
			Info = 920083,
			Ability = {
				{
					Value = 200002,
					Num = 270,
				},
				{
					Value = 200007,
					Num = 105,
				},
			},
		},
		{
			Level = 6,
			Info = 920083,
			Ability = {
				{
					Value = 200002,
					Num = 324,
				},
				{
					Value = 200007,
					Num = 126,
				},
			},
		},
		{
			Level = 7,
			Info = 920083,
			Ability = {
				{
					Value = 200002,
					Num = 378,
				},
				{
					Value = 200007,
					Num = 147,
				},
			},
		},
		{
			Level = 8,
			Info = 920083,
			Ability = {
				{
					Value = 200002,
					Num = 432,
				},
				{
					Value = 200007,
					Num = 168,
				},
			},
			SkillList = {
				{
					Id = 100553,
					Value = 25,
				},
			},
		},
		{
			Level = 9,
			Info = 920083,
			Ability = {
				{
					Value = 200002,
					Num = 486,
				},
				{
					Value = 200007,
					Num = 189,
				},
			},
			SkillList = {
				{
					Id = 100553,
					Value = 25,
				},
			},
		},
		{
			Level = 10,
			Info = 920083,
			Ability = {
				{
					Value = 200002,
					Num = 540,
				},
				{
					Value = 200007,
					Num = 210,
				},
			},
			SkillList = {
				{
					Id = 100553,
					Value = 25,
				},
			},
		},
	},
}
