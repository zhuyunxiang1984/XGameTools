HomeFurnitureGashaponConfig ={};
HomeFurnitureGashaponID = 
{
	Id001 = 1230001,
	Id002 = 1230002,
	Id003 = 1230003,
	Id004 = 1230004,
	Id005 = 1230005,
	Id006 = 1230006,
	Id007 = 1230007,
	Id008 = 1230008,
	Id009 = 1230009,
	Id010 = 1230010,
	Id011 = 1230011,
	Id012 = 1230012,
	Id013 = 1230013,
	Id014 = 1230014,
	Id015 = 1230015,
	Id016 = 1230016,
	Id017 = 1230017,
	Id018 = 1230018,
	Id019 = 1230019,
	Id020 = 1230020,
	Id021 = 1230021,
	Id022 = 1230022,
	Id023 = 1230023,
	Id024 = 1230024,
	Id025 = 1230025,
	Id026 = 1230026,
	Id027 = 1230027,
	Id028 = 1230028,
	Id029 = 1230029,
	Id030 = 1230030,
	Id031 = 1230031,
	Id032 = 1230032,
	Id033 = 1230033,
	Id034 = 1230034,
	Id035 = 1230035,
	Id036 = 1230036,
	Id037 = 1230037,
	Id038 = 1230038,
	Id039 = 1230039,
	Id040 = 1230040,
	Id041 = 1230041,
	Id042 = 1230042,
	Id043 = 1230043,
	Id044 = 1230044,
	Id045 = 1230045,
	Id046 = 1230046,
	Id047 = 1230047,
	Id048 = 1230048,
	Id049 = 1230049,
	Id050 = 1230050,
	Id051 = 1230051,
	Id052 = 1230052,
	Id053 = 1230053,
	Id054 = 1230054,
}
HomeFurnitureGashaponConfig[HomeFurnitureGashaponID.Id001] =
{
	Id = 1,
	StartTime = 1610899201,
	EndTime = 1642435200,
	GashaponList = {
		{
			Rank = 1,
			Id = 1210001,
			Num = 1,
			Weight = 100,
		},
		{
			Rank = 2,
			Id = 1210002,
			Num = 1,
			Weight = 100,
		},
		{
			Rank = 3,
			Id = 1210003,
			Num = 1,
			Weight = 100,
		},
		{
			Rank = 3,
			Id = 1210004,
			Num = 1,
			Weight = 100,
		},
		{
			Rank = 3,
			Id = 1210005,
			Num = 1,
			Weight = 100,
		},
		{
			Rank = 3,
			Id = 1210006,
			Num = 1,
			Weight = 100,
		},
		{
			Rank = 4,
			Id = 1210007,
			Num = 1,
			Weight = 100,
		},
		{
			Rank = 4,
			Id = 1210008,
			Num = 1,
			Weight = 100,
		},
		{
			Rank = 4,
			Id = 1210009,
			Num = 1,
			Weight = 100,
		},
		{
			Rank = 4,
			Id = 1210010,
			Num = 1,
			Weight = 100,
		},
	},
	CostList = {
		{
			Id = 2,
			Num = 50,
		},
	},
	TagList = {
		560103,
	},
}
HomeFurnitureGashaponConfig[HomeFurnitureGashaponID.Id002] =
{
	Id = 2,
	StartTime = 1642435201,
	EndTime = 1643558400,
	GashaponList = {
		{
			Rank = 1,
			Id = 1210001,
			Num = 1,
			Weight = 100,
		},
		{
			Rank = 2,
			Id = 1210002,
			Num = 1,
			Weight = 100,
		},
		{
			Rank = 3,
			Id = 1210003,
			Num = 1,
			Weight = 100,
		},
		{
			Rank = 3,
			Id = 1210004,
			Num = 1,
			Weight = 100,
		},
		{
			Rank = 3,
			Id = 1210005,
			Num = 1,
			Weight = 100,
		},
		{
			Rank = 3,
			Id = 1210006,
			Num = 1,
			Weight = 100,
		},
		{
			Rank = 4,
			Id = 1210007,
			Num = 1,
			Weight = 100,
		},
		{
			Rank = 4,
			Id = 1210008,
			Num = 1,
			Weight = 100,
		},
		{
			Rank = 4,
			Id = 1210009,
			Num = 1,
			Weight = 100,
		},
		{
			Rank = 4,
			Id = 1210010,
			Num = 1,
			Weight = 100,
		},
	},
	CostList = {
		{
			Id = 2,
			Num = 50,
		},
	},
	TagList = {
		560103,
	},
}
HomeFurnitureGashaponConfig[HomeFurnitureGashaponID.Id003] =
{
	Id = 3,
	StartTime = 1643558401,
	EndTime = 1644163200,
	GashaponList = {
		{
			Rank = 1,
			Id = 1210001,
			Num = 1,
			Weight = 100,
		},
		{
			Rank = 2,
			Id = 1210002,
			Num = 1,
			Weight = 100,
		},
		{
			Rank = 3,
			Id = 1210003,
			Num = 1,
			Weight = 100,
		},
		{
			Rank = 3,
			Id = 1210004,
			Num = 1,
			Weight = 100,
		},
		{
			Rank = 3,
			Id = 1210005,
			Num = 1,
			Weight = 100,
		},
		{
			Rank = 3,
			Id = 1210006,
			Num = 1,
			Weight = 100,
		},
		{
			Rank = 4,
			Id = 1210007,
			Num = 1,
			Weight = 100,
		},
		{
			Rank = 4,
			Id = 1210008,
			Num = 1,
			Weight = 100,
		},
		{
			Rank = 4,
			Id = 1210009,
			Num = 1,
			Weight = 100,
		},
		{
			Rank = 4,
			Id = 1210010,
			Num = 1,
			Weight = 100,
		},
	},
	CostList = {
		{
			Id = 2,
			Num = 50,
		},
	},
	TagList = {
		560103,
	},
}
HomeFurnitureGashaponConfig[HomeFurnitureGashaponID.Id004] =
{
	Id = 4,
	StartTime = 1644163201,
	EndTime = 1644768000,
	GashaponList = {
		{
			Rank = 1,
			Id = 1210001,
			Num = 1,
			Weight = 100,
		},
		{
			Rank = 2,
			Id = 1210002,
			Num = 1,
			Weight = 100,
		},
		{
			Rank = 3,
			Id = 1210003,
			Num = 1,
			Weight = 100,
		},
		{
			Rank = 3,
			Id = 1210004,
			Num = 1,
			Weight = 100,
		},
		{
			Rank = 3,
			Id = 1210005,
			Num = 1,
			Weight = 100,
		},
		{
			Rank = 3,
			Id = 1210006,
			Num = 1,
			Weight = 100,
		},
		{
			Rank = 4,
			Id = 1210007,
			Num = 1,
			Weight = 100,
		},
		{
			Rank = 4,
			Id = 1210008,
			Num = 1,
			Weight = 100,
		},
		{
			Rank = 4,
			Id = 1210009,
			Num = 1,
			Weight = 100,
		},
		{
			Rank = 4,
			Id = 1210010,
			Num = 1,
			Weight = 100,
		},
	},
	CostList = {
		{
			Id = 2,
			Num = 50,
		},
	},
	TagList = {
		560103,
	},
}
HomeFurnitureGashaponConfig[HomeFurnitureGashaponID.Id005] =
{
	Id = 5,
	StartTime = 1644768001,
	EndTime = 1645372800,
	GashaponList = {
		{
			Rank = 1,
			Id = 1210001,
			Num = 1,
			Weight = 100,
		},
		{
			Rank = 2,
			Id = 1210002,
			Num = 1,
			Weight = 100,
		},
		{
			Rank = 3,
			Id = 1210003,
			Num = 1,
			Weight = 100,
		},
		{
			Rank = 3,
			Id = 1210004,
			Num = 1,
			Weight = 100,
		},
		{
			Rank = 3,
			Id = 1210005,
			Num = 1,
			Weight = 100,
		},
		{
			Rank = 3,
			Id = 1210006,
			Num = 1,
			Weight = 100,
		},
		{
			Rank = 4,
			Id = 1210007,
			Num = 1,
			Weight = 100,
		},
		{
			Rank = 4,
			Id = 1210008,
			Num = 1,
			Weight = 100,
		},
		{
			Rank = 4,
			Id = 1210009,
			Num = 1,
			Weight = 100,
		},
		{
			Rank = 4,
			Id = 1210010,
			Num = 1,
			Weight = 100,
		},
	},
	CostList = {
		{
			Id = 2,
			Num = 50,
		},
	},
	TagList = {
		560103,
	},
}
HomeFurnitureGashaponConfig[HomeFurnitureGashaponID.Id006] =
{
	Id = 6,
	StartTime = 1645372801,
	EndTime = 1645977600,
	GashaponList = {
		{
			Rank = 1,
			Id = 1210001,
			Num = 1,
			Weight = 100,
		},
		{
			Rank = 2,
			Id = 1210002,
			Num = 1,
			Weight = 100,
		},
		{
			Rank = 3,
			Id = 1210003,
			Num = 1,
			Weight = 100,
		},
		{
			Rank = 3,
			Id = 1210004,
			Num = 1,
			Weight = 100,
		},
		{
			Rank = 3,
			Id = 1210005,
			Num = 1,
			Weight = 100,
		},
		{
			Rank = 3,
			Id = 1210006,
			Num = 1,
			Weight = 100,
		},
		{
			Rank = 4,
			Id = 1210007,
			Num = 1,
			Weight = 100,
		},
		{
			Rank = 4,
			Id = 1210008,
			Num = 1,
			Weight = 100,
		},
		{
			Rank = 4,
			Id = 1210009,
			Num = 1,
			Weight = 100,
		},
		{
			Rank = 4,
			Id = 1210010,
			Num = 1,
			Weight = 100,
		},
	},
	CostList = {
		{
			Id = 2,
			Num = 50,
		},
	},
	TagList = {
		560103,
	},
}
HomeFurnitureGashaponConfig[HomeFurnitureGashaponID.Id007] =
{
	Id = 7,
	StartTime = 1645977601,
	EndTime = 1646582400,
	GashaponList = {
		{
			Rank = 1,
			Id = 1210001,
			Num = 1,
			Weight = 100,
		},
		{
			Rank = 2,
			Id = 1210002,
			Num = 1,
			Weight = 100,
		},
		{
			Rank = 3,
			Id = 1210003,
			Num = 1,
			Weight = 100,
		},
		{
			Rank = 3,
			Id = 1210004,
			Num = 1,
			Weight = 100,
		},
		{
			Rank = 3,
			Id = 1210005,
			Num = 1,
			Weight = 100,
		},
		{
			Rank = 3,
			Id = 1210006,
			Num = 1,
			Weight = 100,
		},
		{
			Rank = 4,
			Id = 1210007,
			Num = 1,
			Weight = 100,
		},
		{
			Rank = 4,
			Id = 1210008,
			Num = 1,
			Weight = 100,
		},
		{
			Rank = 4,
			Id = 1210009,
			Num = 1,
			Weight = 100,
		},
		{
			Rank = 4,
			Id = 1210010,
			Num = 1,
			Weight = 100,
		},
	},
	CostList = {
		{
			Id = 2,
			Num = 50,
		},
	},
	TagList = {
		560103,
	},
}
HomeFurnitureGashaponConfig[HomeFurnitureGashaponID.Id008] =
{
	Id = 8,
	StartTime = 1646582401,
	EndTime = 1647187200,
	GashaponList = {
		{
			Rank = 1,
			Id = 1210001,
			Num = 1,
			Weight = 100,
		},
		{
			Rank = 2,
			Id = 1210002,
			Num = 1,
			Weight = 100,
		},
		{
			Rank = 3,
			Id = 1210003,
			Num = 1,
			Weight = 100,
		},
		{
			Rank = 3,
			Id = 1210004,
			Num = 1,
			Weight = 100,
		},
		{
			Rank = 3,
			Id = 1210005,
			Num = 1,
			Weight = 100,
		},
		{
			Rank = 3,
			Id = 1210006,
			Num = 1,
			Weight = 100,
		},
		{
			Rank = 4,
			Id = 1210007,
			Num = 1,
			Weight = 100,
		},
		{
			Rank = 4,
			Id = 1210008,
			Num = 1,
			Weight = 100,
		},
		{
			Rank = 4,
			Id = 1210009,
			Num = 1,
			Weight = 100,
		},
		{
			Rank = 4,
			Id = 1210010,
			Num = 1,
			Weight = 100,
		},
	},
	CostList = {
		{
			Id = 2,
			Num = 50,
		},
	},
	TagList = {
		560103,
	},
}
HomeFurnitureGashaponConfig[HomeFurnitureGashaponID.Id009] =
{
	Id = 9,
	StartTime = 1647187201,
	EndTime = 1647792000,
	GashaponList = {
		{
			Rank = 1,
			Id = 1210001,
			Num = 1,
			Weight = 100,
		},
		{
			Rank = 2,
			Id = 1210002,
			Num = 1,
			Weight = 100,
		},
		{
			Rank = 3,
			Id = 1210003,
			Num = 1,
			Weight = 100,
		},
		{
			Rank = 3,
			Id = 1210004,
			Num = 1,
			Weight = 100,
		},
		{
			Rank = 3,
			Id = 1210005,
			Num = 1,
			Weight = 100,
		},
		{
			Rank = 3,
			Id = 1210006,
			Num = 1,
			Weight = 100,
		},
		{
			Rank = 4,
			Id = 1210007,
			Num = 1,
			Weight = 100,
		},
		{
			Rank = 4,
			Id = 1210008,
			Num = 1,
			Weight = 100,
		},
		{
			Rank = 4,
			Id = 1210009,
			Num = 1,
			Weight = 100,
		},
		{
			Rank = 4,
			Id = 1210010,
			Num = 1,
			Weight = 100,
		},
	},
	CostList = {
		{
			Id = 2,
			Num = 50,
		},
	},
	TagList = {
		560103,
	},
}
HomeFurnitureGashaponConfig[HomeFurnitureGashaponID.Id010] =
{
	Id = 10,
	StartTime = 1647792001,
	EndTime = 1648396800,
	GashaponList = {
		{
			Rank = 1,
			Id = 1210001,
			Num = 1,
			Weight = 100,
		},
		{
			Rank = 2,
			Id = 1210002,
			Num = 1,
			Weight = 100,
		},
		{
			Rank = 3,
			Id = 1210003,
			Num = 1,
			Weight = 100,
		},
		{
			Rank = 3,
			Id = 1210004,
			Num = 1,
			Weight = 100,
		},
		{
			Rank = 3,
			Id = 1210005,
			Num = 1,
			Weight = 100,
		},
		{
			Rank = 3,
			Id = 1210006,
			Num = 1,
			Weight = 100,
		},
		{
			Rank = 4,
			Id = 1210007,
			Num = 1,
			Weight = 100,
		},
		{
			Rank = 4,
			Id = 1210008,
			Num = 1,
			Weight = 100,
		},
		{
			Rank = 4,
			Id = 1210009,
			Num = 1,
			Weight = 100,
		},
		{
			Rank = 4,
			Id = 1210010,
			Num = 1,
			Weight = 100,
		},
	},
	CostList = {
		{
			Id = 2,
			Num = 50,
		},
	},
	TagList = {
		560103,
	},
}
HomeFurnitureGashaponConfig[HomeFurnitureGashaponID.Id011] =
{
	Id = 11,
	StartTime = 1648396801,
	EndTime = 1649001600,
	GashaponList = {
		{
			Rank = 1,
			Id = 1210001,
			Num = 1,
			Weight = 100,
		},
		{
			Rank = 2,
			Id = 1210002,
			Num = 1,
			Weight = 100,
		},
		{
			Rank = 3,
			Id = 1210003,
			Num = 1,
			Weight = 100,
		},
		{
			Rank = 3,
			Id = 1210004,
			Num = 1,
			Weight = 100,
		},
		{
			Rank = 3,
			Id = 1210005,
			Num = 1,
			Weight = 100,
		},
		{
			Rank = 3,
			Id = 1210006,
			Num = 1,
			Weight = 100,
		},
		{
			Rank = 4,
			Id = 1210007,
			Num = 1,
			Weight = 100,
		},
		{
			Rank = 4,
			Id = 1210008,
			Num = 1,
			Weight = 100,
		},
		{
			Rank = 4,
			Id = 1210009,
			Num = 1,
			Weight = 100,
		},
		{
			Rank = 4,
			Id = 1210010,
			Num = 1,
			Weight = 100,
		},
	},
	CostList = {
		{
			Id = 2,
			Num = 50,
		},
	},
	TagList = {
		560103,
	},
}
HomeFurnitureGashaponConfig[HomeFurnitureGashaponID.Id012] =
{
	Id = 12,
	StartTime = 1649001601,
	EndTime = 1649606400,
	GashaponList = {
		{
			Rank = 1,
			Id = 1210001,
			Num = 1,
			Weight = 100,
		},
		{
			Rank = 2,
			Id = 1210002,
			Num = 1,
			Weight = 100,
		},
		{
			Rank = 3,
			Id = 1210003,
			Num = 1,
			Weight = 100,
		},
		{
			Rank = 3,
			Id = 1210004,
			Num = 1,
			Weight = 100,
		},
		{
			Rank = 3,
			Id = 1210005,
			Num = 1,
			Weight = 100,
		},
		{
			Rank = 3,
			Id = 1210006,
			Num = 1,
			Weight = 100,
		},
		{
			Rank = 4,
			Id = 1210007,
			Num = 1,
			Weight = 100,
		},
		{
			Rank = 4,
			Id = 1210008,
			Num = 1,
			Weight = 100,
		},
		{
			Rank = 4,
			Id = 1210009,
			Num = 1,
			Weight = 100,
		},
		{
			Rank = 4,
			Id = 1210010,
			Num = 1,
			Weight = 100,
		},
	},
	CostList = {
		{
			Id = 2,
			Num = 50,
		},
	},
	TagList = {
		560103,
	},
}
HomeFurnitureGashaponConfig[HomeFurnitureGashaponID.Id013] =
{
	Id = 13,
	StartTime = 1649606401,
	EndTime = 1650211200,
	GashaponList = {
		{
			Rank = 1,
			Id = 1210001,
			Num = 1,
			Weight = 100,
		},
		{
			Rank = 2,
			Id = 1210002,
			Num = 1,
			Weight = 100,
		},
		{
			Rank = 3,
			Id = 1210003,
			Num = 1,
			Weight = 100,
		},
		{
			Rank = 3,
			Id = 1210004,
			Num = 1,
			Weight = 100,
		},
		{
			Rank = 3,
			Id = 1210005,
			Num = 1,
			Weight = 100,
		},
		{
			Rank = 3,
			Id = 1210006,
			Num = 1,
			Weight = 100,
		},
		{
			Rank = 4,
			Id = 1210007,
			Num = 1,
			Weight = 100,
		},
		{
			Rank = 4,
			Id = 1210008,
			Num = 1,
			Weight = 100,
		},
		{
			Rank = 4,
			Id = 1210009,
			Num = 1,
			Weight = 100,
		},
		{
			Rank = 4,
			Id = 1210010,
			Num = 1,
			Weight = 100,
		},
	},
	CostList = {
		{
			Id = 2,
			Num = 50,
		},
	},
	TagList = {
		560103,
	},
}
HomeFurnitureGashaponConfig[HomeFurnitureGashaponID.Id014] =
{
	Id = 14,
	StartTime = 1650211201,
	EndTime = 1650816000,
	GashaponList = {
		{
			Rank = 1,
			Id = 1210001,
			Num = 1,
			Weight = 100,
		},
		{
			Rank = 2,
			Id = 1210002,
			Num = 1,
			Weight = 100,
		},
		{
			Rank = 3,
			Id = 1210003,
			Num = 1,
			Weight = 100,
		},
		{
			Rank = 3,
			Id = 1210004,
			Num = 1,
			Weight = 100,
		},
		{
			Rank = 3,
			Id = 1210005,
			Num = 1,
			Weight = 100,
		},
		{
			Rank = 3,
			Id = 1210006,
			Num = 1,
			Weight = 100,
		},
		{
			Rank = 4,
			Id = 1210007,
			Num = 1,
			Weight = 100,
		},
		{
			Rank = 4,
			Id = 1210008,
			Num = 1,
			Weight = 100,
		},
		{
			Rank = 4,
			Id = 1210009,
			Num = 1,
			Weight = 100,
		},
		{
			Rank = 4,
			Id = 1210010,
			Num = 1,
			Weight = 100,
		},
	},
	CostList = {
		{
			Id = 2,
			Num = 50,
		},
	},
	TagList = {
		560103,
	},
}
HomeFurnitureGashaponConfig[HomeFurnitureGashaponID.Id015] =
{
	Id = 15,
	StartTime = 1650816001,
	EndTime = 1651420800,
	GashaponList = {
		{
			Rank = 1,
			Id = 1210001,
			Num = 1,
			Weight = 100,
		},
		{
			Rank = 2,
			Id = 1210002,
			Num = 1,
			Weight = 100,
		},
		{
			Rank = 3,
			Id = 1210003,
			Num = 1,
			Weight = 100,
		},
		{
			Rank = 3,
			Id = 1210004,
			Num = 1,
			Weight = 100,
		},
		{
			Rank = 3,
			Id = 1210005,
			Num = 1,
			Weight = 100,
		},
		{
			Rank = 3,
			Id = 1210006,
			Num = 1,
			Weight = 100,
		},
		{
			Rank = 4,
			Id = 1210007,
			Num = 1,
			Weight = 100,
		},
		{
			Rank = 4,
			Id = 1210008,
			Num = 1,
			Weight = 100,
		},
		{
			Rank = 4,
			Id = 1210009,
			Num = 1,
			Weight = 100,
		},
		{
			Rank = 4,
			Id = 1210010,
			Num = 1,
			Weight = 100,
		},
	},
	CostList = {
		{
			Id = 2,
			Num = 50,
		},
	},
	TagList = {
		560103,
	},
}
HomeFurnitureGashaponConfig[HomeFurnitureGashaponID.Id016] =
{
	Id = 16,
	StartTime = 1651420801,
	EndTime = 1652025600,
	GashaponList = {
		{
			Rank = 1,
			Id = 1210001,
			Num = 1,
			Weight = 100,
		},
		{
			Rank = 2,
			Id = 1210002,
			Num = 1,
			Weight = 100,
		},
		{
			Rank = 3,
			Id = 1210003,
			Num = 1,
			Weight = 100,
		},
		{
			Rank = 3,
			Id = 1210004,
			Num = 1,
			Weight = 100,
		},
		{
			Rank = 3,
			Id = 1210005,
			Num = 1,
			Weight = 100,
		},
		{
			Rank = 3,
			Id = 1210006,
			Num = 1,
			Weight = 100,
		},
		{
			Rank = 4,
			Id = 1210007,
			Num = 1,
			Weight = 100,
		},
		{
			Rank = 4,
			Id = 1210008,
			Num = 1,
			Weight = 100,
		},
		{
			Rank = 4,
			Id = 1210009,
			Num = 1,
			Weight = 100,
		},
		{
			Rank = 4,
			Id = 1210010,
			Num = 1,
			Weight = 100,
		},
	},
	CostList = {
		{
			Id = 2,
			Num = 50,
		},
	},
	TagList = {
		560103,
	},
}
HomeFurnitureGashaponConfig[HomeFurnitureGashaponID.Id017] =
{
	Id = 17,
	StartTime = 1652025601,
	EndTime = 1652630400,
	GashaponList = {
		{
			Rank = 1,
			Id = 1210001,
			Num = 1,
			Weight = 100,
		},
		{
			Rank = 2,
			Id = 1210002,
			Num = 1,
			Weight = 100,
		},
		{
			Rank = 3,
			Id = 1210003,
			Num = 1,
			Weight = 100,
		},
		{
			Rank = 3,
			Id = 1210004,
			Num = 1,
			Weight = 100,
		},
		{
			Rank = 3,
			Id = 1210005,
			Num = 1,
			Weight = 100,
		},
		{
			Rank = 3,
			Id = 1210006,
			Num = 1,
			Weight = 100,
		},
		{
			Rank = 4,
			Id = 1210007,
			Num = 1,
			Weight = 100,
		},
		{
			Rank = 4,
			Id = 1210008,
			Num = 1,
			Weight = 100,
		},
		{
			Rank = 4,
			Id = 1210009,
			Num = 1,
			Weight = 100,
		},
		{
			Rank = 4,
			Id = 1210010,
			Num = 1,
			Weight = 100,
		},
	},
	CostList = {
		{
			Id = 2,
			Num = 50,
		},
	},
	TagList = {
		560103,
	},
}
HomeFurnitureGashaponConfig[HomeFurnitureGashaponID.Id018] =
{
	Id = 18,
	StartTime = 1652630401,
	EndTime = 1653235200,
	GashaponList = {
		{
			Rank = 1,
			Id = 1210001,
			Num = 1,
			Weight = 100,
		},
		{
			Rank = 2,
			Id = 1210002,
			Num = 1,
			Weight = 100,
		},
		{
			Rank = 3,
			Id = 1210003,
			Num = 1,
			Weight = 100,
		},
		{
			Rank = 3,
			Id = 1210004,
			Num = 1,
			Weight = 100,
		},
		{
			Rank = 3,
			Id = 1210005,
			Num = 1,
			Weight = 100,
		},
		{
			Rank = 3,
			Id = 1210006,
			Num = 1,
			Weight = 100,
		},
		{
			Rank = 4,
			Id = 1210007,
			Num = 1,
			Weight = 100,
		},
		{
			Rank = 4,
			Id = 1210008,
			Num = 1,
			Weight = 100,
		},
		{
			Rank = 4,
			Id = 1210009,
			Num = 1,
			Weight = 100,
		},
		{
			Rank = 4,
			Id = 1210010,
			Num = 1,
			Weight = 100,
		},
	},
	CostList = {
		{
			Id = 2,
			Num = 50,
		},
	},
	TagList = {
		560103,
	},
}
HomeFurnitureGashaponConfig[HomeFurnitureGashaponID.Id019] =
{
	Id = 19,
	StartTime = 1653235201,
	EndTime = 1653840000,
	GashaponList = {
		{
			Rank = 1,
			Id = 1210001,
			Num = 1,
			Weight = 100,
		},
		{
			Rank = 2,
			Id = 1210002,
			Num = 1,
			Weight = 100,
		},
		{
			Rank = 3,
			Id = 1210003,
			Num = 1,
			Weight = 100,
		},
		{
			Rank = 3,
			Id = 1210004,
			Num = 1,
			Weight = 100,
		},
		{
			Rank = 3,
			Id = 1210005,
			Num = 1,
			Weight = 100,
		},
		{
			Rank = 3,
			Id = 1210006,
			Num = 1,
			Weight = 100,
		},
		{
			Rank = 4,
			Id = 1210007,
			Num = 1,
			Weight = 100,
		},
		{
			Rank = 4,
			Id = 1210008,
			Num = 1,
			Weight = 100,
		},
		{
			Rank = 4,
			Id = 1210009,
			Num = 1,
			Weight = 100,
		},
		{
			Rank = 4,
			Id = 1210010,
			Num = 1,
			Weight = 100,
		},
	},
	CostList = {
		{
			Id = 2,
			Num = 50,
		},
	},
	TagList = {
		560103,
	},
}
HomeFurnitureGashaponConfig[HomeFurnitureGashaponID.Id020] =
{
	Id = 20,
	StartTime = 1653840001,
	EndTime = 1654444800,
	GashaponList = {
		{
			Rank = 1,
			Id = 1210001,
			Num = 1,
			Weight = 100,
		},
		{
			Rank = 2,
			Id = 1210002,
			Num = 1,
			Weight = 100,
		},
		{
			Rank = 3,
			Id = 1210003,
			Num = 1,
			Weight = 100,
		},
		{
			Rank = 3,
			Id = 1210004,
			Num = 1,
			Weight = 100,
		},
		{
			Rank = 3,
			Id = 1210005,
			Num = 1,
			Weight = 100,
		},
		{
			Rank = 3,
			Id = 1210006,
			Num = 1,
			Weight = 100,
		},
		{
			Rank = 4,
			Id = 1210007,
			Num = 1,
			Weight = 100,
		},
		{
			Rank = 4,
			Id = 1210008,
			Num = 1,
			Weight = 100,
		},
		{
			Rank = 4,
			Id = 1210009,
			Num = 1,
			Weight = 100,
		},
		{
			Rank = 4,
			Id = 1210010,
			Num = 1,
			Weight = 100,
		},
	},
	CostList = {
		{
			Id = 2,
			Num = 50,
		},
	},
	TagList = {
		560103,
	},
}
HomeFurnitureGashaponConfig[HomeFurnitureGashaponID.Id021] =
{
	Id = 21,
	StartTime = 1654444801,
	EndTime = 1655049600,
	GashaponList = {
		{
			Rank = 1,
			Id = 1210001,
			Num = 1,
			Weight = 100,
		},
		{
			Rank = 2,
			Id = 1210002,
			Num = 1,
			Weight = 100,
		},
		{
			Rank = 3,
			Id = 1210003,
			Num = 1,
			Weight = 100,
		},
		{
			Rank = 3,
			Id = 1210004,
			Num = 1,
			Weight = 100,
		},
		{
			Rank = 3,
			Id = 1210005,
			Num = 1,
			Weight = 100,
		},
		{
			Rank = 3,
			Id = 1210006,
			Num = 1,
			Weight = 100,
		},
		{
			Rank = 4,
			Id = 1210007,
			Num = 1,
			Weight = 100,
		},
		{
			Rank = 4,
			Id = 1210008,
			Num = 1,
			Weight = 100,
		},
		{
			Rank = 4,
			Id = 1210009,
			Num = 1,
			Weight = 100,
		},
		{
			Rank = 4,
			Id = 1210010,
			Num = 1,
			Weight = 100,
		},
	},
	CostList = {
		{
			Id = 2,
			Num = 50,
		},
	},
	TagList = {
		560103,
	},
}
HomeFurnitureGashaponConfig[HomeFurnitureGashaponID.Id022] =
{
	Id = 22,
	StartTime = 1655049601,
	EndTime = 1655654400,
	GashaponList = {
		{
			Rank = 1,
			Id = 1210001,
			Num = 1,
			Weight = 100,
		},
		{
			Rank = 2,
			Id = 1210002,
			Num = 1,
			Weight = 100,
		},
		{
			Rank = 3,
			Id = 1210003,
			Num = 1,
			Weight = 100,
		},
		{
			Rank = 3,
			Id = 1210004,
			Num = 1,
			Weight = 100,
		},
		{
			Rank = 3,
			Id = 1210005,
			Num = 1,
			Weight = 100,
		},
		{
			Rank = 3,
			Id = 1210006,
			Num = 1,
			Weight = 100,
		},
		{
			Rank = 4,
			Id = 1210007,
			Num = 1,
			Weight = 100,
		},
		{
			Rank = 4,
			Id = 1210008,
			Num = 1,
			Weight = 100,
		},
		{
			Rank = 4,
			Id = 1210009,
			Num = 1,
			Weight = 100,
		},
		{
			Rank = 4,
			Id = 1210010,
			Num = 1,
			Weight = 100,
		},
	},
	CostList = {
		{
			Id = 2,
			Num = 50,
		},
	},
	TagList = {
		560103,
	},
}
HomeFurnitureGashaponConfig[HomeFurnitureGashaponID.Id023] =
{
	Id = 23,
	StartTime = 1655654401,
	EndTime = 1656259200,
	GashaponList = {
		{
			Rank = 1,
			Id = 1210001,
			Num = 1,
			Weight = 100,
		},
		{
			Rank = 2,
			Id = 1210002,
			Num = 1,
			Weight = 100,
		},
		{
			Rank = 3,
			Id = 1210003,
			Num = 1,
			Weight = 100,
		},
		{
			Rank = 3,
			Id = 1210004,
			Num = 1,
			Weight = 100,
		},
		{
			Rank = 3,
			Id = 1210005,
			Num = 1,
			Weight = 100,
		},
		{
			Rank = 3,
			Id = 1210006,
			Num = 1,
			Weight = 100,
		},
		{
			Rank = 4,
			Id = 1210007,
			Num = 1,
			Weight = 100,
		},
		{
			Rank = 4,
			Id = 1210008,
			Num = 1,
			Weight = 100,
		},
		{
			Rank = 4,
			Id = 1210009,
			Num = 1,
			Weight = 100,
		},
		{
			Rank = 4,
			Id = 1210010,
			Num = 1,
			Weight = 100,
		},
	},
	CostList = {
		{
			Id = 2,
			Num = 50,
		},
	},
	TagList = {
		560103,
	},
}
HomeFurnitureGashaponConfig[HomeFurnitureGashaponID.Id024] =
{
	Id = 24,
	StartTime = 1656259201,
	EndTime = 1656864000,
	GashaponList = {
		{
			Rank = 1,
			Id = 1210001,
			Num = 1,
			Weight = 100,
		},
		{
			Rank = 2,
			Id = 1210002,
			Num = 1,
			Weight = 100,
		},
		{
			Rank = 3,
			Id = 1210003,
			Num = 1,
			Weight = 100,
		},
		{
			Rank = 3,
			Id = 1210004,
			Num = 1,
			Weight = 100,
		},
		{
			Rank = 3,
			Id = 1210005,
			Num = 1,
			Weight = 100,
		},
		{
			Rank = 3,
			Id = 1210006,
			Num = 1,
			Weight = 100,
		},
		{
			Rank = 4,
			Id = 1210007,
			Num = 1,
			Weight = 100,
		},
		{
			Rank = 4,
			Id = 1210008,
			Num = 1,
			Weight = 100,
		},
		{
			Rank = 4,
			Id = 1210009,
			Num = 1,
			Weight = 100,
		},
		{
			Rank = 4,
			Id = 1210010,
			Num = 1,
			Weight = 100,
		},
	},
	CostList = {
		{
			Id = 2,
			Num = 50,
		},
	},
	TagList = {
		560103,
	},
}
HomeFurnitureGashaponConfig[HomeFurnitureGashaponID.Id025] =
{
	Id = 25,
	StartTime = 1656864001,
	EndTime = 1657468800,
	GashaponList = {
		{
			Rank = 1,
			Id = 1210001,
			Num = 1,
			Weight = 100,
		},
		{
			Rank = 2,
			Id = 1210002,
			Num = 1,
			Weight = 100,
		},
		{
			Rank = 3,
			Id = 1210003,
			Num = 1,
			Weight = 100,
		},
		{
			Rank = 3,
			Id = 1210004,
			Num = 1,
			Weight = 100,
		},
		{
			Rank = 3,
			Id = 1210005,
			Num = 1,
			Weight = 100,
		},
		{
			Rank = 3,
			Id = 1210006,
			Num = 1,
			Weight = 100,
		},
		{
			Rank = 4,
			Id = 1210007,
			Num = 1,
			Weight = 100,
		},
		{
			Rank = 4,
			Id = 1210008,
			Num = 1,
			Weight = 100,
		},
		{
			Rank = 4,
			Id = 1210009,
			Num = 1,
			Weight = 100,
		},
		{
			Rank = 4,
			Id = 1210010,
			Num = 1,
			Weight = 100,
		},
	},
	CostList = {
		{
			Id = 2,
			Num = 50,
		},
	},
	TagList = {
		560103,
	},
}
HomeFurnitureGashaponConfig[HomeFurnitureGashaponID.Id026] =
{
	Id = 26,
	StartTime = 1657468801,
	EndTime = 1658073600,
	GashaponList = {
		{
			Rank = 1,
			Id = 1210001,
			Num = 1,
			Weight = 100,
		},
		{
			Rank = 2,
			Id = 1210002,
			Num = 1,
			Weight = 100,
		},
		{
			Rank = 3,
			Id = 1210003,
			Num = 1,
			Weight = 100,
		},
		{
			Rank = 3,
			Id = 1210004,
			Num = 1,
			Weight = 100,
		},
		{
			Rank = 3,
			Id = 1210005,
			Num = 1,
			Weight = 100,
		},
		{
			Rank = 3,
			Id = 1210006,
			Num = 1,
			Weight = 100,
		},
		{
			Rank = 4,
			Id = 1210007,
			Num = 1,
			Weight = 100,
		},
		{
			Rank = 4,
			Id = 1210008,
			Num = 1,
			Weight = 100,
		},
		{
			Rank = 4,
			Id = 1210009,
			Num = 1,
			Weight = 100,
		},
		{
			Rank = 4,
			Id = 1210010,
			Num = 1,
			Weight = 100,
		},
	},
	CostList = {
		{
			Id = 2,
			Num = 50,
		},
	},
	TagList = {
		560103,
	},
}
HomeFurnitureGashaponConfig[HomeFurnitureGashaponID.Id027] =
{
	Id = 27,
	StartTime = 1658073601,
	EndTime = 1658678400,
	GashaponList = {
		{
			Rank = 1,
			Id = 1210001,
			Num = 1,
			Weight = 100,
		},
		{
			Rank = 2,
			Id = 1210002,
			Num = 1,
			Weight = 100,
		},
		{
			Rank = 3,
			Id = 1210003,
			Num = 1,
			Weight = 100,
		},
		{
			Rank = 3,
			Id = 1210004,
			Num = 1,
			Weight = 100,
		},
		{
			Rank = 3,
			Id = 1210005,
			Num = 1,
			Weight = 100,
		},
		{
			Rank = 3,
			Id = 1210006,
			Num = 1,
			Weight = 100,
		},
		{
			Rank = 4,
			Id = 1210007,
			Num = 1,
			Weight = 100,
		},
		{
			Rank = 4,
			Id = 1210008,
			Num = 1,
			Weight = 100,
		},
		{
			Rank = 4,
			Id = 1210009,
			Num = 1,
			Weight = 100,
		},
		{
			Rank = 4,
			Id = 1210010,
			Num = 1,
			Weight = 100,
		},
	},
	CostList = {
		{
			Id = 2,
			Num = 50,
		},
	},
	TagList = {
		560103,
	},
}
HomeFurnitureGashaponConfig[HomeFurnitureGashaponID.Id028] =
{
	Id = 28,
	StartTime = 1658678401,
	EndTime = 1659283200,
	GashaponList = {
		{
			Rank = 1,
			Id = 1210001,
			Num = 1,
			Weight = 100,
		},
		{
			Rank = 2,
			Id = 1210002,
			Num = 1,
			Weight = 100,
		},
		{
			Rank = 3,
			Id = 1210003,
			Num = 1,
			Weight = 100,
		},
		{
			Rank = 3,
			Id = 1210004,
			Num = 1,
			Weight = 100,
		},
		{
			Rank = 3,
			Id = 1210005,
			Num = 1,
			Weight = 100,
		},
		{
			Rank = 3,
			Id = 1210006,
			Num = 1,
			Weight = 100,
		},
		{
			Rank = 4,
			Id = 1210007,
			Num = 1,
			Weight = 100,
		},
		{
			Rank = 4,
			Id = 1210008,
			Num = 1,
			Weight = 100,
		},
		{
			Rank = 4,
			Id = 1210009,
			Num = 1,
			Weight = 100,
		},
		{
			Rank = 4,
			Id = 1210010,
			Num = 1,
			Weight = 100,
		},
	},
	CostList = {
		{
			Id = 2,
			Num = 50,
		},
	},
	TagList = {
		560103,
	},
}
HomeFurnitureGashaponConfig[HomeFurnitureGashaponID.Id029] =
{
	Id = 29,
	StartTime = 1659283201,
	EndTime = 1659888000,
	GashaponList = {
		{
			Rank = 1,
			Id = 1210001,
			Num = 1,
			Weight = 100,
		},
		{
			Rank = 2,
			Id = 1210002,
			Num = 1,
			Weight = 100,
		},
		{
			Rank = 3,
			Id = 1210003,
			Num = 1,
			Weight = 100,
		},
		{
			Rank = 3,
			Id = 1210004,
			Num = 1,
			Weight = 100,
		},
		{
			Rank = 3,
			Id = 1210005,
			Num = 1,
			Weight = 100,
		},
		{
			Rank = 3,
			Id = 1210006,
			Num = 1,
			Weight = 100,
		},
		{
			Rank = 4,
			Id = 1210007,
			Num = 1,
			Weight = 100,
		},
		{
			Rank = 4,
			Id = 1210008,
			Num = 1,
			Weight = 100,
		},
		{
			Rank = 4,
			Id = 1210009,
			Num = 1,
			Weight = 100,
		},
		{
			Rank = 4,
			Id = 1210010,
			Num = 1,
			Weight = 100,
		},
	},
	CostList = {
		{
			Id = 2,
			Num = 50,
		},
	},
	TagList = {
		560103,
	},
}
HomeFurnitureGashaponConfig[HomeFurnitureGashaponID.Id030] =
{
	Id = 30,
	StartTime = 1659888001,
	EndTime = 1660492800,
	GashaponList = {
		{
			Rank = 1,
			Id = 1210001,
			Num = 1,
			Weight = 100,
		},
		{
			Rank = 2,
			Id = 1210002,
			Num = 1,
			Weight = 100,
		},
		{
			Rank = 3,
			Id = 1210003,
			Num = 1,
			Weight = 100,
		},
		{
			Rank = 3,
			Id = 1210004,
			Num = 1,
			Weight = 100,
		},
		{
			Rank = 3,
			Id = 1210005,
			Num = 1,
			Weight = 100,
		},
		{
			Rank = 3,
			Id = 1210006,
			Num = 1,
			Weight = 100,
		},
		{
			Rank = 4,
			Id = 1210007,
			Num = 1,
			Weight = 100,
		},
		{
			Rank = 4,
			Id = 1210008,
			Num = 1,
			Weight = 100,
		},
		{
			Rank = 4,
			Id = 1210009,
			Num = 1,
			Weight = 100,
		},
		{
			Rank = 4,
			Id = 1210010,
			Num = 1,
			Weight = 100,
		},
	},
	CostList = {
		{
			Id = 2,
			Num = 50,
		},
	},
	TagList = {
		560103,
	},
}
HomeFurnitureGashaponConfig[HomeFurnitureGashaponID.Id031] =
{
	Id = 31,
	StartTime = 1660492801,
	EndTime = 1661097600,
	GashaponList = {
		{
			Rank = 1,
			Id = 1210001,
			Num = 1,
			Weight = 100,
		},
		{
			Rank = 2,
			Id = 1210002,
			Num = 1,
			Weight = 100,
		},
		{
			Rank = 3,
			Id = 1210003,
			Num = 1,
			Weight = 100,
		},
		{
			Rank = 3,
			Id = 1210004,
			Num = 1,
			Weight = 100,
		},
		{
			Rank = 3,
			Id = 1210005,
			Num = 1,
			Weight = 100,
		},
		{
			Rank = 3,
			Id = 1210006,
			Num = 1,
			Weight = 100,
		},
		{
			Rank = 4,
			Id = 1210007,
			Num = 1,
			Weight = 100,
		},
		{
			Rank = 4,
			Id = 1210008,
			Num = 1,
			Weight = 100,
		},
		{
			Rank = 4,
			Id = 1210009,
			Num = 1,
			Weight = 100,
		},
		{
			Rank = 4,
			Id = 1210010,
			Num = 1,
			Weight = 100,
		},
	},
	CostList = {
		{
			Id = 2,
			Num = 50,
		},
	},
	TagList = {
		560103,
	},
}
HomeFurnitureGashaponConfig[HomeFurnitureGashaponID.Id032] =
{
	Id = 32,
	StartTime = 1661097601,
	EndTime = 1661702400,
	GashaponList = {
		{
			Rank = 1,
			Id = 1210001,
			Num = 1,
			Weight = 100,
		},
		{
			Rank = 2,
			Id = 1210002,
			Num = 1,
			Weight = 100,
		},
		{
			Rank = 3,
			Id = 1210003,
			Num = 1,
			Weight = 100,
		},
		{
			Rank = 3,
			Id = 1210004,
			Num = 1,
			Weight = 100,
		},
		{
			Rank = 3,
			Id = 1210005,
			Num = 1,
			Weight = 100,
		},
		{
			Rank = 3,
			Id = 1210006,
			Num = 1,
			Weight = 100,
		},
		{
			Rank = 4,
			Id = 1210007,
			Num = 1,
			Weight = 100,
		},
		{
			Rank = 4,
			Id = 1210008,
			Num = 1,
			Weight = 100,
		},
		{
			Rank = 4,
			Id = 1210009,
			Num = 1,
			Weight = 100,
		},
		{
			Rank = 4,
			Id = 1210010,
			Num = 1,
			Weight = 100,
		},
	},
	CostList = {
		{
			Id = 2,
			Num = 50,
		},
	},
	TagList = {
		560103,
	},
}
HomeFurnitureGashaponConfig[HomeFurnitureGashaponID.Id033] =
{
	Id = 33,
	StartTime = 1661702401,
	EndTime = 1662307200,
	GashaponList = {
		{
			Rank = 1,
			Id = 1210001,
			Num = 1,
			Weight = 100,
		},
		{
			Rank = 2,
			Id = 1210002,
			Num = 1,
			Weight = 100,
		},
		{
			Rank = 3,
			Id = 1210003,
			Num = 1,
			Weight = 100,
		},
		{
			Rank = 3,
			Id = 1210004,
			Num = 1,
			Weight = 100,
		},
		{
			Rank = 3,
			Id = 1210005,
			Num = 1,
			Weight = 100,
		},
		{
			Rank = 3,
			Id = 1210006,
			Num = 1,
			Weight = 100,
		},
		{
			Rank = 4,
			Id = 1210007,
			Num = 1,
			Weight = 100,
		},
		{
			Rank = 4,
			Id = 1210008,
			Num = 1,
			Weight = 100,
		},
		{
			Rank = 4,
			Id = 1210009,
			Num = 1,
			Weight = 100,
		},
		{
			Rank = 4,
			Id = 1210010,
			Num = 1,
			Weight = 100,
		},
	},
	CostList = {
		{
			Id = 2,
			Num = 50,
		},
	},
	TagList = {
		560103,
	},
}
HomeFurnitureGashaponConfig[HomeFurnitureGashaponID.Id034] =
{
	Id = 34,
	StartTime = 1662307201,
	EndTime = 1662912000,
	GashaponList = {
		{
			Rank = 1,
			Id = 1210001,
			Num = 1,
			Weight = 100,
		},
		{
			Rank = 2,
			Id = 1210002,
			Num = 1,
			Weight = 100,
		},
		{
			Rank = 3,
			Id = 1210003,
			Num = 1,
			Weight = 100,
		},
		{
			Rank = 3,
			Id = 1210004,
			Num = 1,
			Weight = 100,
		},
		{
			Rank = 3,
			Id = 1210005,
			Num = 1,
			Weight = 100,
		},
		{
			Rank = 3,
			Id = 1210006,
			Num = 1,
			Weight = 100,
		},
		{
			Rank = 4,
			Id = 1210007,
			Num = 1,
			Weight = 100,
		},
		{
			Rank = 4,
			Id = 1210008,
			Num = 1,
			Weight = 100,
		},
		{
			Rank = 4,
			Id = 1210009,
			Num = 1,
			Weight = 100,
		},
		{
			Rank = 4,
			Id = 1210010,
			Num = 1,
			Weight = 100,
		},
	},
	CostList = {
		{
			Id = 2,
			Num = 50,
		},
	},
	TagList = {
		560103,
	},
}
HomeFurnitureGashaponConfig[HomeFurnitureGashaponID.Id035] =
{
	Id = 35,
	StartTime = 1662912001,
	EndTime = 1663516800,
	GashaponList = {
		{
			Rank = 1,
			Id = 1210001,
			Num = 1,
			Weight = 100,
		},
		{
			Rank = 2,
			Id = 1210002,
			Num = 1,
			Weight = 100,
		},
		{
			Rank = 3,
			Id = 1210003,
			Num = 1,
			Weight = 100,
		},
		{
			Rank = 3,
			Id = 1210004,
			Num = 1,
			Weight = 100,
		},
		{
			Rank = 3,
			Id = 1210005,
			Num = 1,
			Weight = 100,
		},
		{
			Rank = 3,
			Id = 1210006,
			Num = 1,
			Weight = 100,
		},
		{
			Rank = 4,
			Id = 1210007,
			Num = 1,
			Weight = 100,
		},
		{
			Rank = 4,
			Id = 1210008,
			Num = 1,
			Weight = 100,
		},
		{
			Rank = 4,
			Id = 1210009,
			Num = 1,
			Weight = 100,
		},
		{
			Rank = 4,
			Id = 1210010,
			Num = 1,
			Weight = 100,
		},
	},
	CostList = {
		{
			Id = 2,
			Num = 50,
		},
	},
	TagList = {
		560103,
	},
}
HomeFurnitureGashaponConfig[HomeFurnitureGashaponID.Id036] =
{
	Id = 36,
	StartTime = 1663516801,
	EndTime = 1664121600,
	GashaponList = {
		{
			Rank = 1,
			Id = 1210001,
			Num = 1,
			Weight = 100,
		},
		{
			Rank = 2,
			Id = 1210002,
			Num = 1,
			Weight = 100,
		},
		{
			Rank = 3,
			Id = 1210003,
			Num = 1,
			Weight = 100,
		},
		{
			Rank = 3,
			Id = 1210004,
			Num = 1,
			Weight = 100,
		},
		{
			Rank = 3,
			Id = 1210005,
			Num = 1,
			Weight = 100,
		},
		{
			Rank = 3,
			Id = 1210006,
			Num = 1,
			Weight = 100,
		},
		{
			Rank = 4,
			Id = 1210007,
			Num = 1,
			Weight = 100,
		},
		{
			Rank = 4,
			Id = 1210008,
			Num = 1,
			Weight = 100,
		},
		{
			Rank = 4,
			Id = 1210009,
			Num = 1,
			Weight = 100,
		},
		{
			Rank = 4,
			Id = 1210010,
			Num = 1,
			Weight = 100,
		},
	},
	CostList = {
		{
			Id = 2,
			Num = 50,
		},
	},
	TagList = {
		560103,
	},
}
HomeFurnitureGashaponConfig[HomeFurnitureGashaponID.Id037] =
{
	Id = 37,
	StartTime = 1664121601,
	EndTime = 1664726400,
	GashaponList = {
		{
			Rank = 1,
			Id = 1210001,
			Num = 1,
			Weight = 100,
		},
		{
			Rank = 2,
			Id = 1210002,
			Num = 1,
			Weight = 100,
		},
		{
			Rank = 3,
			Id = 1210003,
			Num = 1,
			Weight = 100,
		},
		{
			Rank = 3,
			Id = 1210004,
			Num = 1,
			Weight = 100,
		},
		{
			Rank = 3,
			Id = 1210005,
			Num = 1,
			Weight = 100,
		},
		{
			Rank = 3,
			Id = 1210006,
			Num = 1,
			Weight = 100,
		},
		{
			Rank = 4,
			Id = 1210007,
			Num = 1,
			Weight = 100,
		},
		{
			Rank = 4,
			Id = 1210008,
			Num = 1,
			Weight = 100,
		},
		{
			Rank = 4,
			Id = 1210009,
			Num = 1,
			Weight = 100,
		},
		{
			Rank = 4,
			Id = 1210010,
			Num = 1,
			Weight = 100,
		},
	},
	CostList = {
		{
			Id = 2,
			Num = 50,
		},
	},
	TagList = {
		560103,
	},
}
HomeFurnitureGashaponConfig[HomeFurnitureGashaponID.Id038] =
{
	Id = 38,
	StartTime = 1664726401,
	EndTime = 1665331200,
	GashaponList = {
		{
			Rank = 1,
			Id = 1210001,
			Num = 1,
			Weight = 100,
		},
		{
			Rank = 2,
			Id = 1210002,
			Num = 1,
			Weight = 100,
		},
		{
			Rank = 3,
			Id = 1210003,
			Num = 1,
			Weight = 100,
		},
		{
			Rank = 3,
			Id = 1210004,
			Num = 1,
			Weight = 100,
		},
		{
			Rank = 3,
			Id = 1210005,
			Num = 1,
			Weight = 100,
		},
		{
			Rank = 3,
			Id = 1210006,
			Num = 1,
			Weight = 100,
		},
		{
			Rank = 4,
			Id = 1210007,
			Num = 1,
			Weight = 100,
		},
		{
			Rank = 4,
			Id = 1210008,
			Num = 1,
			Weight = 100,
		},
		{
			Rank = 4,
			Id = 1210009,
			Num = 1,
			Weight = 100,
		},
		{
			Rank = 4,
			Id = 1210010,
			Num = 1,
			Weight = 100,
		},
	},
	CostList = {
		{
			Id = 2,
			Num = 50,
		},
	},
	TagList = {
		560103,
	},
}
HomeFurnitureGashaponConfig[HomeFurnitureGashaponID.Id039] =
{
	Id = 39,
	StartTime = 1665331201,
	EndTime = 1665936000,
	GashaponList = {
		{
			Rank = 1,
			Id = 1210001,
			Num = 1,
			Weight = 100,
		},
		{
			Rank = 2,
			Id = 1210002,
			Num = 1,
			Weight = 100,
		},
		{
			Rank = 3,
			Id = 1210003,
			Num = 1,
			Weight = 100,
		},
		{
			Rank = 3,
			Id = 1210004,
			Num = 1,
			Weight = 100,
		},
		{
			Rank = 3,
			Id = 1210005,
			Num = 1,
			Weight = 100,
		},
		{
			Rank = 3,
			Id = 1210006,
			Num = 1,
			Weight = 100,
		},
		{
			Rank = 4,
			Id = 1210007,
			Num = 1,
			Weight = 100,
		},
		{
			Rank = 4,
			Id = 1210008,
			Num = 1,
			Weight = 100,
		},
		{
			Rank = 4,
			Id = 1210009,
			Num = 1,
			Weight = 100,
		},
		{
			Rank = 4,
			Id = 1210010,
			Num = 1,
			Weight = 100,
		},
	},
	CostList = {
		{
			Id = 2,
			Num = 50,
		},
	},
	TagList = {
		560103,
	},
}
HomeFurnitureGashaponConfig[HomeFurnitureGashaponID.Id040] =
{
	Id = 40,
	StartTime = 1665936001,
	EndTime = 1666540800,
	GashaponList = {
		{
			Rank = 1,
			Id = 1210001,
			Num = 1,
			Weight = 100,
		},
		{
			Rank = 2,
			Id = 1210002,
			Num = 1,
			Weight = 100,
		},
		{
			Rank = 3,
			Id = 1210003,
			Num = 1,
			Weight = 100,
		},
		{
			Rank = 3,
			Id = 1210004,
			Num = 1,
			Weight = 100,
		},
		{
			Rank = 3,
			Id = 1210005,
			Num = 1,
			Weight = 100,
		},
		{
			Rank = 3,
			Id = 1210006,
			Num = 1,
			Weight = 100,
		},
		{
			Rank = 4,
			Id = 1210007,
			Num = 1,
			Weight = 100,
		},
		{
			Rank = 4,
			Id = 1210008,
			Num = 1,
			Weight = 100,
		},
		{
			Rank = 4,
			Id = 1210009,
			Num = 1,
			Weight = 100,
		},
		{
			Rank = 4,
			Id = 1210010,
			Num = 1,
			Weight = 100,
		},
	},
	CostList = {
		{
			Id = 2,
			Num = 50,
		},
	},
	TagList = {
		560103,
	},
}
HomeFurnitureGashaponConfig[HomeFurnitureGashaponID.Id041] =
{
	Id = 41,
	StartTime = 1666540801,
	EndTime = 1667145600,
	GashaponList = {
		{
			Rank = 1,
			Id = 1210001,
			Num = 1,
			Weight = 100,
		},
		{
			Rank = 2,
			Id = 1210002,
			Num = 1,
			Weight = 100,
		},
		{
			Rank = 3,
			Id = 1210003,
			Num = 1,
			Weight = 100,
		},
		{
			Rank = 3,
			Id = 1210004,
			Num = 1,
			Weight = 100,
		},
		{
			Rank = 3,
			Id = 1210005,
			Num = 1,
			Weight = 100,
		},
		{
			Rank = 3,
			Id = 1210006,
			Num = 1,
			Weight = 100,
		},
		{
			Rank = 4,
			Id = 1210007,
			Num = 1,
			Weight = 100,
		},
		{
			Rank = 4,
			Id = 1210008,
			Num = 1,
			Weight = 100,
		},
		{
			Rank = 4,
			Id = 1210009,
			Num = 1,
			Weight = 100,
		},
		{
			Rank = 4,
			Id = 1210010,
			Num = 1,
			Weight = 100,
		},
	},
	CostList = {
		{
			Id = 2,
			Num = 50,
		},
	},
	TagList = {
		560103,
	},
}
HomeFurnitureGashaponConfig[HomeFurnitureGashaponID.Id042] =
{
	Id = 42,
	StartTime = 1667145601,
	EndTime = 1667750400,
	GashaponList = {
		{
			Rank = 1,
			Id = 1210001,
			Num = 1,
			Weight = 100,
		},
		{
			Rank = 2,
			Id = 1210002,
			Num = 1,
			Weight = 100,
		},
		{
			Rank = 3,
			Id = 1210003,
			Num = 1,
			Weight = 100,
		},
		{
			Rank = 3,
			Id = 1210004,
			Num = 1,
			Weight = 100,
		},
		{
			Rank = 3,
			Id = 1210005,
			Num = 1,
			Weight = 100,
		},
		{
			Rank = 3,
			Id = 1210006,
			Num = 1,
			Weight = 100,
		},
		{
			Rank = 4,
			Id = 1210007,
			Num = 1,
			Weight = 100,
		},
		{
			Rank = 4,
			Id = 1210008,
			Num = 1,
			Weight = 100,
		},
		{
			Rank = 4,
			Id = 1210009,
			Num = 1,
			Weight = 100,
		},
		{
			Rank = 4,
			Id = 1210010,
			Num = 1,
			Weight = 100,
		},
	},
	CostList = {
		{
			Id = 2,
			Num = 50,
		},
	},
	TagList = {
		560103,
	},
}
HomeFurnitureGashaponConfig[HomeFurnitureGashaponID.Id043] =
{
	Id = 43,
	StartTime = 1667750401,
	EndTime = 1668355200,
	GashaponList = {
		{
			Rank = 1,
			Id = 1210001,
			Num = 1,
			Weight = 100,
		},
		{
			Rank = 2,
			Id = 1210002,
			Num = 1,
			Weight = 100,
		},
		{
			Rank = 3,
			Id = 1210003,
			Num = 1,
			Weight = 100,
		},
		{
			Rank = 3,
			Id = 1210004,
			Num = 1,
			Weight = 100,
		},
		{
			Rank = 3,
			Id = 1210005,
			Num = 1,
			Weight = 100,
		},
		{
			Rank = 3,
			Id = 1210006,
			Num = 1,
			Weight = 100,
		},
		{
			Rank = 4,
			Id = 1210007,
			Num = 1,
			Weight = 100,
		},
		{
			Rank = 4,
			Id = 1210008,
			Num = 1,
			Weight = 100,
		},
		{
			Rank = 4,
			Id = 1210009,
			Num = 1,
			Weight = 100,
		},
		{
			Rank = 4,
			Id = 1210010,
			Num = 1,
			Weight = 100,
		},
	},
	CostList = {
		{
			Id = 2,
			Num = 50,
		},
	},
	TagList = {
		560103,
	},
}
HomeFurnitureGashaponConfig[HomeFurnitureGashaponID.Id044] =
{
	Id = 44,
	StartTime = 1668355201,
	EndTime = 1668960000,
	GashaponList = {
		{
			Rank = 1,
			Id = 1210001,
			Num = 1,
			Weight = 100,
		},
		{
			Rank = 2,
			Id = 1210002,
			Num = 1,
			Weight = 100,
		},
		{
			Rank = 3,
			Id = 1210003,
			Num = 1,
			Weight = 100,
		},
		{
			Rank = 3,
			Id = 1210004,
			Num = 1,
			Weight = 100,
		},
		{
			Rank = 3,
			Id = 1210005,
			Num = 1,
			Weight = 100,
		},
		{
			Rank = 3,
			Id = 1210006,
			Num = 1,
			Weight = 100,
		},
		{
			Rank = 4,
			Id = 1210007,
			Num = 1,
			Weight = 100,
		},
		{
			Rank = 4,
			Id = 1210008,
			Num = 1,
			Weight = 100,
		},
		{
			Rank = 4,
			Id = 1210009,
			Num = 1,
			Weight = 100,
		},
		{
			Rank = 4,
			Id = 1210010,
			Num = 1,
			Weight = 100,
		},
	},
	CostList = {
		{
			Id = 2,
			Num = 50,
		},
	},
	TagList = {
		560103,
	},
}
HomeFurnitureGashaponConfig[HomeFurnitureGashaponID.Id045] =
{
	Id = 45,
	StartTime = 1668960001,
	EndTime = 1669564800,
	GashaponList = {
		{
			Rank = 1,
			Id = 1210001,
			Num = 1,
			Weight = 100,
		},
		{
			Rank = 2,
			Id = 1210002,
			Num = 1,
			Weight = 100,
		},
		{
			Rank = 3,
			Id = 1210003,
			Num = 1,
			Weight = 100,
		},
		{
			Rank = 3,
			Id = 1210004,
			Num = 1,
			Weight = 100,
		},
		{
			Rank = 3,
			Id = 1210005,
			Num = 1,
			Weight = 100,
		},
		{
			Rank = 3,
			Id = 1210006,
			Num = 1,
			Weight = 100,
		},
		{
			Rank = 4,
			Id = 1210007,
			Num = 1,
			Weight = 100,
		},
		{
			Rank = 4,
			Id = 1210008,
			Num = 1,
			Weight = 100,
		},
		{
			Rank = 4,
			Id = 1210009,
			Num = 1,
			Weight = 100,
		},
		{
			Rank = 4,
			Id = 1210010,
			Num = 1,
			Weight = 100,
		},
	},
	CostList = {
		{
			Id = 2,
			Num = 50,
		},
	},
	TagList = {
		560103,
	},
}
HomeFurnitureGashaponConfig[HomeFurnitureGashaponID.Id046] =
{
	Id = 46,
	StartTime = 1669564801,
	EndTime = 1670169600,
	GashaponList = {
		{
			Rank = 1,
			Id = 1210001,
			Num = 1,
			Weight = 100,
		},
		{
			Rank = 2,
			Id = 1210002,
			Num = 1,
			Weight = 100,
		},
		{
			Rank = 3,
			Id = 1210003,
			Num = 1,
			Weight = 100,
		},
		{
			Rank = 3,
			Id = 1210004,
			Num = 1,
			Weight = 100,
		},
		{
			Rank = 3,
			Id = 1210005,
			Num = 1,
			Weight = 100,
		},
		{
			Rank = 3,
			Id = 1210006,
			Num = 1,
			Weight = 100,
		},
		{
			Rank = 4,
			Id = 1210007,
			Num = 1,
			Weight = 100,
		},
		{
			Rank = 4,
			Id = 1210008,
			Num = 1,
			Weight = 100,
		},
		{
			Rank = 4,
			Id = 1210009,
			Num = 1,
			Weight = 100,
		},
		{
			Rank = 4,
			Id = 1210010,
			Num = 1,
			Weight = 100,
		},
	},
	CostList = {
		{
			Id = 2,
			Num = 50,
		},
	},
	TagList = {
		560103,
	},
}
HomeFurnitureGashaponConfig[HomeFurnitureGashaponID.Id047] =
{
	Id = 47,
	StartTime = 1670169601,
	EndTime = 1670774400,
	GashaponList = {
		{
			Rank = 1,
			Id = 1210001,
			Num = 1,
			Weight = 100,
		},
		{
			Rank = 2,
			Id = 1210002,
			Num = 1,
			Weight = 100,
		},
		{
			Rank = 3,
			Id = 1210003,
			Num = 1,
			Weight = 100,
		},
		{
			Rank = 3,
			Id = 1210004,
			Num = 1,
			Weight = 100,
		},
		{
			Rank = 3,
			Id = 1210005,
			Num = 1,
			Weight = 100,
		},
		{
			Rank = 3,
			Id = 1210006,
			Num = 1,
			Weight = 100,
		},
		{
			Rank = 4,
			Id = 1210007,
			Num = 1,
			Weight = 100,
		},
		{
			Rank = 4,
			Id = 1210008,
			Num = 1,
			Weight = 100,
		},
		{
			Rank = 4,
			Id = 1210009,
			Num = 1,
			Weight = 100,
		},
		{
			Rank = 4,
			Id = 1210010,
			Num = 1,
			Weight = 100,
		},
	},
	CostList = {
		{
			Id = 2,
			Num = 50,
		},
	},
	TagList = {
		560103,
	},
}
HomeFurnitureGashaponConfig[HomeFurnitureGashaponID.Id048] =
{
	Id = 48,
	StartTime = 1670774401,
	EndTime = 1671379200,
	GashaponList = {
		{
			Rank = 1,
			Id = 1210001,
			Num = 1,
			Weight = 100,
		},
		{
			Rank = 2,
			Id = 1210002,
			Num = 1,
			Weight = 100,
		},
		{
			Rank = 3,
			Id = 1210003,
			Num = 1,
			Weight = 100,
		},
		{
			Rank = 3,
			Id = 1210004,
			Num = 1,
			Weight = 100,
		},
		{
			Rank = 3,
			Id = 1210005,
			Num = 1,
			Weight = 100,
		},
		{
			Rank = 3,
			Id = 1210006,
			Num = 1,
			Weight = 100,
		},
		{
			Rank = 4,
			Id = 1210007,
			Num = 1,
			Weight = 100,
		},
		{
			Rank = 4,
			Id = 1210008,
			Num = 1,
			Weight = 100,
		},
		{
			Rank = 4,
			Id = 1210009,
			Num = 1,
			Weight = 100,
		},
		{
			Rank = 4,
			Id = 1210010,
			Num = 1,
			Weight = 100,
		},
	},
	CostList = {
		{
			Id = 2,
			Num = 50,
		},
	},
	TagList = {
		560103,
	},
}
HomeFurnitureGashaponConfig[HomeFurnitureGashaponID.Id049] =
{
	Id = 49,
	StartTime = 1671379201,
	EndTime = 1671984000,
	GashaponList = {
		{
			Rank = 1,
			Id = 1210001,
			Num = 1,
			Weight = 100,
		},
		{
			Rank = 2,
			Id = 1210002,
			Num = 1,
			Weight = 100,
		},
		{
			Rank = 3,
			Id = 1210003,
			Num = 1,
			Weight = 100,
		},
		{
			Rank = 3,
			Id = 1210004,
			Num = 1,
			Weight = 100,
		},
		{
			Rank = 3,
			Id = 1210005,
			Num = 1,
			Weight = 100,
		},
		{
			Rank = 3,
			Id = 1210006,
			Num = 1,
			Weight = 100,
		},
		{
			Rank = 4,
			Id = 1210007,
			Num = 1,
			Weight = 100,
		},
		{
			Rank = 4,
			Id = 1210008,
			Num = 1,
			Weight = 100,
		},
		{
			Rank = 4,
			Id = 1210009,
			Num = 1,
			Weight = 100,
		},
		{
			Rank = 4,
			Id = 1210010,
			Num = 1,
			Weight = 100,
		},
	},
	CostList = {
		{
			Id = 2,
			Num = 50,
		},
	},
	TagList = {
		560103,
	},
}
HomeFurnitureGashaponConfig[HomeFurnitureGashaponID.Id050] =
{
	Id = 50,
	StartTime = 1671984001,
	EndTime = 1672588800,
	GashaponList = {
		{
			Rank = 1,
			Id = 1210001,
			Num = 1,
			Weight = 100,
		},
		{
			Rank = 2,
			Id = 1210002,
			Num = 1,
			Weight = 100,
		},
		{
			Rank = 3,
			Id = 1210003,
			Num = 1,
			Weight = 100,
		},
		{
			Rank = 3,
			Id = 1210004,
			Num = 1,
			Weight = 100,
		},
		{
			Rank = 3,
			Id = 1210005,
			Num = 1,
			Weight = 100,
		},
		{
			Rank = 3,
			Id = 1210006,
			Num = 1,
			Weight = 100,
		},
		{
			Rank = 4,
			Id = 1210007,
			Num = 1,
			Weight = 100,
		},
		{
			Rank = 4,
			Id = 1210008,
			Num = 1,
			Weight = 100,
		},
		{
			Rank = 4,
			Id = 1210009,
			Num = 1,
			Weight = 100,
		},
		{
			Rank = 4,
			Id = 1210010,
			Num = 1,
			Weight = 100,
		},
	},
	CostList = {
		{
			Id = 2,
			Num = 50,
		},
	},
	TagList = {
		560103,
	},
}
HomeFurnitureGashaponConfig[HomeFurnitureGashaponID.Id051] =
{
	Id = 51,
	StartTime = 1672588801,
	EndTime = 1673193600,
	GashaponList = {
		{
			Rank = 1,
			Id = 1210001,
			Num = 1,
			Weight = 100,
		},
		{
			Rank = 2,
			Id = 1210002,
			Num = 1,
			Weight = 100,
		},
		{
			Rank = 3,
			Id = 1210003,
			Num = 1,
			Weight = 100,
		},
		{
			Rank = 3,
			Id = 1210004,
			Num = 1,
			Weight = 100,
		},
		{
			Rank = 3,
			Id = 1210005,
			Num = 1,
			Weight = 100,
		},
		{
			Rank = 3,
			Id = 1210006,
			Num = 1,
			Weight = 100,
		},
		{
			Rank = 4,
			Id = 1210007,
			Num = 1,
			Weight = 100,
		},
		{
			Rank = 4,
			Id = 1210008,
			Num = 1,
			Weight = 100,
		},
		{
			Rank = 4,
			Id = 1210009,
			Num = 1,
			Weight = 100,
		},
		{
			Rank = 4,
			Id = 1210010,
			Num = 1,
			Weight = 100,
		},
	},
	CostList = {
		{
			Id = 2,
			Num = 50,
		},
	},
	TagList = {
		560103,
	},
}
HomeFurnitureGashaponConfig[HomeFurnitureGashaponID.Id052] =
{
	Id = 52,
	StartTime = 1673193601,
	EndTime = 1673798400,
	GashaponList = {
		{
			Rank = 1,
			Id = 1210001,
			Num = 1,
			Weight = 100,
		},
		{
			Rank = 2,
			Id = 1210002,
			Num = 1,
			Weight = 100,
		},
		{
			Rank = 3,
			Id = 1210003,
			Num = 1,
			Weight = 100,
		},
		{
			Rank = 3,
			Id = 1210004,
			Num = 1,
			Weight = 100,
		},
		{
			Rank = 3,
			Id = 1210005,
			Num = 1,
			Weight = 100,
		},
		{
			Rank = 3,
			Id = 1210006,
			Num = 1,
			Weight = 100,
		},
		{
			Rank = 4,
			Id = 1210007,
			Num = 1,
			Weight = 100,
		},
		{
			Rank = 4,
			Id = 1210008,
			Num = 1,
			Weight = 100,
		},
		{
			Rank = 4,
			Id = 1210009,
			Num = 1,
			Weight = 100,
		},
		{
			Rank = 4,
			Id = 1210010,
			Num = 1,
			Weight = 100,
		},
	},
	CostList = {
		{
			Id = 2,
			Num = 50,
		},
	},
	TagList = {
		560103,
	},
}
HomeFurnitureGashaponConfig[HomeFurnitureGashaponID.Id053] =
{
	Id = 53,
	StartTime = 1673798401,
	EndTime = 1674403200,
	GashaponList = {
		{
			Rank = 1,
			Id = 1210001,
			Num = 1,
			Weight = 100,
		},
		{
			Rank = 2,
			Id = 1210002,
			Num = 1,
			Weight = 100,
		},
		{
			Rank = 3,
			Id = 1210003,
			Num = 1,
			Weight = 100,
		},
		{
			Rank = 3,
			Id = 1210004,
			Num = 1,
			Weight = 100,
		},
		{
			Rank = 3,
			Id = 1210005,
			Num = 1,
			Weight = 100,
		},
		{
			Rank = 3,
			Id = 1210006,
			Num = 1,
			Weight = 100,
		},
		{
			Rank = 4,
			Id = 1210007,
			Num = 1,
			Weight = 100,
		},
		{
			Rank = 4,
			Id = 1210008,
			Num = 1,
			Weight = 100,
		},
		{
			Rank = 4,
			Id = 1210009,
			Num = 1,
			Weight = 100,
		},
		{
			Rank = 4,
			Id = 1210010,
			Num = 1,
			Weight = 100,
		},
	},
	CostList = {
		{
			Id = 2,
			Num = 50,
		},
	},
	TagList = {
		560103,
	},
}
HomeFurnitureGashaponConfig[HomeFurnitureGashaponID.Id054] =
{
	Id = 54,
	StartTime = 1674403201,
	EndTime = 1675008000,
	GashaponList = {
		{
			Rank = 1,
			Id = 1210001,
			Num = 1,
			Weight = 100,
		},
		{
			Rank = 2,
			Id = 1210002,
			Num = 1,
			Weight = 100,
		},
		{
			Rank = 3,
			Id = 1210003,
			Num = 1,
			Weight = 100,
		},
		{
			Rank = 3,
			Id = 1210004,
			Num = 1,
			Weight = 100,
		},
		{
			Rank = 3,
			Id = 1210005,
			Num = 1,
			Weight = 100,
		},
		{
			Rank = 3,
			Id = 1210006,
			Num = 1,
			Weight = 100,
		},
		{
			Rank = 4,
			Id = 1210007,
			Num = 1,
			Weight = 100,
		},
		{
			Rank = 4,
			Id = 1210008,
			Num = 1,
			Weight = 100,
		},
		{
			Rank = 4,
			Id = 1210009,
			Num = 1,
			Weight = 100,
		},
		{
			Rank = 4,
			Id = 1210010,
			Num = 1,
			Weight = 100,
		},
	},
	CostList = {
		{
			Id = 2,
			Num = 50,
		},
	},
	TagList = {
		560103,
	},
}

