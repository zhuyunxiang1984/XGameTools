HideSeekObjectConfig ={};
HideSeekObjectID = 
{
	Id001 = 890001,
	Id002 = 890002,
	Id003 = 890003,
	Id004 = 890004,
	Id005 = 890005,
	Id006 = 890006,
	Id007 = 890007,
	Id008 = 890008,
	Id009 = 890009,
	Id010 = 890010,
	Id011 = 890011,
	Id012 = 890012,
	Id013 = 890013,
	Id014 = 890014,
	Id015 = 890015,
	Id016 = 890016,
	Id017 = 890017,
	Id018 = 890018,
	Id019 = 890019,
	Id020 = 890020,
	Id021 = 890021,
	Id022 = 890022,
	Id023 = 890023,
	Id024 = 890024,
	Id025 = 890025,
	Id026 = 890026,
	Id027 = 890027,
	Id028 = 890028,
	Id029 = 890029,
	Id030 = 890030,
	Id031 = 890031,
	Id032 = 890032,
	Id033 = 890033,
	Id034 = 890034,
	Id035 = 890035,
	Id036 = 890036,
	Id037 = 890037,
	Id038 = 890038,
	Id039 = 890039,
	Id040 = 890040,
	Id041 = 890041,
	Id042 = 890042,
	Id043 = 890043,
	Id044 = 890044,
	Id045 = 890045,
	Id046 = 890046,
	Id047 = 890047,
	Id048 = 890048,
	Id049 = 890049,
	Id050 = 890050,
	Id051 = 890051,
	Id052 = 890052,
	Id053 = 890053,
	Id054 = 890054,
	Id055 = 890055,
	Id056 = 890056,
	Id057 = 890057,
	Id058 = 890058,
	Id059 = 890059,
	Id060 = 890060,
	Id061 = 890061,
	Id062 = 890062,
	Id063 = 890063,
	Id064 = 890064,
	Id065 = 890065,
	Id066 = 890066,
	Id067 = 890067,
	Id068 = 890068,
	Id069 = 890069,
	Id070 = 890070,
	Id071 = 890071,
	Id072 = 890072,
	Id073 = 890073,
	Id074 = 890074,
	Id075 = 890075,
	Id076 = 890076,
	Id077 = 890077,
	Id078 = 890078,
	Id079 = 890079,
	Id080 = 890080,
	Id081 = 890081,
	Id082 = 890082,
	Id083 = 890083,
	Id084 = 890084,
	Id085 = 890085,
	Id086 = 890086,
	Id087 = 890087,
	Id088 = 890088,
	Id089 = 890089,
	Id090 = 890090,
	Id091 = 890091,
	Id092 = 890092,
	Id093 = 890093,
	Id094 = 890094,
	Id095 = 890095,
	Id096 = 890096,
	Id097 = 890097,
	Id098 = 890098,
	Id099 = 890099,
	Id100 = 890100,
	Id101 = 890101,
	Id102 = 890102,
	Id103 = 890103,
	Id104 = 890104,
	Id105 = 890105,
	Id106 = 890106,
	Id107 = 890107,
	Id108 = 890108,
	Id109 = 890109,
	Id110 = 890110,
	Id111 = 890111,
	Id112 = 890112,
	Id113 = 890113,
	Id114 = 890114,
	Id115 = 890115,
	Id116 = 890116,
	Id117 = 890117,
}
HideSeekObjectConfig[HideSeekObjectID.Id001] =
{
	Id = 1,
	Node = "rabbit01",
	PreCondition = {
		PreGoalList = {
			300040,
		},
	},
	Weight = 1000,
	RewardList = {
		{
			Id = 2,
			Num = 50,
		},
		{
			Id = 320424,
			Num = 2,
		},
	},
	HintText = "听说，兔子在流亡街呢？",
}
HideSeekObjectConfig[HideSeekObjectID.Id002] =
{
	Id = 2,
	Node = "rabbit02",
	PreCondition = {
		PreGoalList = {
			300040,
		},
	},
	Weight = 1000,
	RewardList = {
		{
			Id = 2,
			Num = 50,
		},
		{
			Id = 320424,
			Num = 2,
		},
	},
	HintText = "听说，兔子在流亡街呢？",
}
HideSeekObjectConfig[HideSeekObjectID.Id003] =
{
	Id = 3,
	Node = "rabbit03",
	PreCondition = {
		PreGoalList = {
			300040,
		},
	},
	Weight = 1000,
	RewardList = {
		{
			Id = 2,
			Num = 50,
		},
		{
			Id = 320424,
			Num = 2,
		},
	},
	HintText = "听说，兔子在流亡街呢？",
}
HideSeekObjectConfig[HideSeekObjectID.Id004] =
{
	Id = 4,
	Node = "rabbit04",
	PreCondition = {
		PreGoalList = {
			300040,
		},
	},
	Weight = 1000,
	RewardList = {
		{
			Id = 2,
			Num = 50,
		},
		{
			Id = 320424,
			Num = 2,
		},
	},
	HintText = "听说，兔子在流亡街呢？",
}
HideSeekObjectConfig[HideSeekObjectID.Id005] =
{
	Id = 5,
	Node = "rabbit05",
	PreCondition = {
		PreGoalList = {
			300040,
		},
	},
	Weight = 1000,
	RewardList = {
		{
			Id = 2,
			Num = 50,
		},
		{
			Id = 320424,
			Num = 2,
		},
	},
	HintText = "听说，兔子在流亡街呢？",
}
HideSeekObjectConfig[HideSeekObjectID.Id006] =
{
	Id = 6,
	Node = "rabbit06",
	PreCondition = {
		PreGoalList = {
			300040,
		},
	},
	Weight = 1000,
	RewardList = {
		{
			Id = 2,
			Num = 50,
		},
		{
			Id = 320424,
			Num = 2,
		},
	},
	HintText = "听说，兔子在流亡街呢？",
}
HideSeekObjectConfig[HideSeekObjectID.Id007] =
{
	Id = 7,
	Node = "rabbit07",
	PreCondition = {
		PreGoalList = {
			300040,
		},
	},
	Weight = 1000,
	RewardList = {
		{
			Id = 2,
			Num = 50,
		},
		{
			Id = 320424,
			Num = 2,
		},
	},
	HintText = "听说，兔子在流亡街呢？",
}
HideSeekObjectConfig[HideSeekObjectID.Id008] =
{
	Id = 8,
	Node = "rabbit08",
	PreCondition = {
		PreGoalList = {
			300040,
		},
	},
	Weight = 1000,
	RewardList = {
		{
			Id = 2,
			Num = 50,
		},
		{
			Id = 320424,
			Num = 2,
		},
	},
	HintText = "听说，兔子在流亡街呢？",
}
HideSeekObjectConfig[HideSeekObjectID.Id009] =
{
	Id = 9,
	Node = "rabbit09",
	PreCondition = {
		PreGoalList = {
			300040,
		},
	},
	Weight = 1000,
	RewardList = {
		{
			Id = 2,
			Num = 50,
		},
		{
			Id = 320424,
			Num = 2,
		},
	},
	HintText = "听说，兔子在流亡街呢？",
}
HideSeekObjectConfig[HideSeekObjectID.Id010] =
{
	Id = 10,
	Node = "rabbit10",
	PreCondition = {
		PreGoalList = {
			300040,
		},
	},
	Weight = 1000,
	RewardList = {
		{
			Id = 2,
			Num = 50,
		},
		{
			Id = 320424,
			Num = 2,
		},
	},
	HintText = "听说，兔子在流亡街呢？",
}
HideSeekObjectConfig[HideSeekObjectID.Id011] =
{
	Id = 11,
	Node = "rabbit11",
	PreCondition = {
		PreGoalList = {
			300040,
		},
	},
	Weight = 1000,
	RewardList = {
		{
			Id = 2,
			Num = 50,
		},
		{
			Id = 320424,
			Num = 2,
		},
	},
	HintText = "听说，兔子在流亡街呢？",
}
HideSeekObjectConfig[HideSeekObjectID.Id012] =
{
	Id = 12,
	Node = "rabbit12",
	PreCondition = {
		PreGoalList = {
			300040,
		},
	},
	Weight = 1000,
	RewardList = {
		{
			Id = 2,
			Num = 50,
		},
		{
			Id = 320424,
			Num = 2,
		},
	},
	HintText = "听说，兔子在流亡街呢？",
}
HideSeekObjectConfig[HideSeekObjectID.Id013] =
{
	Id = 13,
	Node = "rabbit13",
	PreCondition = {
		PreGoalList = {
			300040,
		},
	},
	Weight = 1000,
	RewardList = {
		{
			Id = 2,
			Num = 50,
		},
		{
			Id = 320424,
			Num = 2,
		},
	},
	HintText = "听说，兔子在流亡街呢？",
}
HideSeekObjectConfig[HideSeekObjectID.Id014] =
{
	Id = 14,
	Node = "rabbit14",
	PreCondition = {
		PreGoalList = {
			300040,
		},
	},
	Weight = 1000,
	RewardList = {
		{
			Id = 2,
			Num = 50,
		},
		{
			Id = 320424,
			Num = 2,
		},
	},
	HintText = "听说，兔子在流亡街呢？",
}
HideSeekObjectConfig[HideSeekObjectID.Id015] =
{
	Id = 15,
	Node = "rabbit15",
	PreCondition = {
		PreGoalList = {
			300040,
		},
	},
	Weight = 1000,
	RewardList = {
		{
			Id = 2,
			Num = 50,
		},
		{
			Id = 320424,
			Num = 2,
		},
	},
	HintText = "听说，兔子在流亡街呢？",
}
HideSeekObjectConfig[HideSeekObjectID.Id016] =
{
	Id = 16,
	Node = "rabbit16",
	PreCondition = {
		PreGoalList = {
			300040,
		},
	},
	Weight = 1000,
	RewardList = {
		{
			Id = 2,
			Num = 50,
		},
		{
			Id = 320424,
			Num = 2,
		},
	},
	HintText = "听说，兔子在流亡街呢？",
}
HideSeekObjectConfig[HideSeekObjectID.Id017] =
{
	Id = 17,
	Node = "rabbit17",
	PreCondition = {
		PreGoalList = {
			300040,
		},
	},
	Weight = 1000,
	RewardList = {
		{
			Id = 2,
			Num = 50,
		},
		{
			Id = 320424,
			Num = 2,
		},
	},
	HintText = "听说，兔子在流亡街呢？",
}
HideSeekObjectConfig[HideSeekObjectID.Id018] =
{
	Id = 18,
	Node = "rabbit18",
	PreCondition = {
		PreGoalList = {
			300040,
		},
	},
	Weight = 1000,
	RewardList = {
		{
			Id = 2,
			Num = 50,
		},
		{
			Id = 320424,
			Num = 2,
		},
	},
	HintText = "听说，兔子在流亡街呢？",
}
HideSeekObjectConfig[HideSeekObjectID.Id019] =
{
	Id = 19,
	Node = "rabbit19",
	PreCondition = {
		PreGoalList = {
			300040,
		},
	},
	Weight = 1000,
	RewardList = {
		{
			Id = 2,
			Num = 50,
		},
		{
			Id = 320424,
			Num = 2,
		},
	},
	HintText = "听说，兔子在流亡街呢？",
}
HideSeekObjectConfig[HideSeekObjectID.Id020] =
{
	Id = 20,
	Node = "rabbit20",
	PreCondition = {
		PreGoalList = {
			300040,
		},
	},
	Weight = 1000,
	RewardList = {
		{
			Id = 2,
			Num = 50,
		},
		{
			Id = 320424,
			Num = 2,
		},
	},
	HintText = "听说，兔子在流亡街呢？",
}
HideSeekObjectConfig[HideSeekObjectID.Id021] =
{
	Id = 21,
	Node = "rabbit21",
	PreCondition = {
		PreGoalList = {
			300040,
		},
	},
	Weight = 1000,
	RewardList = {
		{
			Id = 2,
			Num = 50,
		},
		{
			Id = 320424,
			Num = 2,
		},
	},
	HintText = "听说，兔子在流亡街呢？",
}
HideSeekObjectConfig[HideSeekObjectID.Id022] =
{
	Id = 22,
	Node = "rabbit22",
	PreCondition = {
		PreGoalList = {
			300040,
		},
	},
	Weight = 1000,
	RewardList = {
		{
			Id = 2,
			Num = 50,
		},
		{
			Id = 320424,
			Num = 2,
		},
	},
	HintText = "听说，兔子在流亡街呢？",
}
HideSeekObjectConfig[HideSeekObjectID.Id023] =
{
	Id = 23,
	Node = "rabbit23",
	PreCondition = {
		PreGoalList = {
			300040,
		},
	},
	Weight = 1000,
	RewardList = {
		{
			Id = 2,
			Num = 50,
		},
		{
			Id = 320424,
			Num = 2,
		},
	},
	HintText = "听说，兔子在流亡街呢？",
}
HideSeekObjectConfig[HideSeekObjectID.Id024] =
{
	Id = 24,
	Node = "rabbit24",
	PreCondition = {
		PreGoalList = {
			300040,
		},
	},
	Weight = 1000,
	RewardList = {
		{
			Id = 2,
			Num = 50,
		},
		{
			Id = 320424,
			Num = 2,
		},
	},
	HintText = "听说，兔子在流亡街呢？",
}
HideSeekObjectConfig[HideSeekObjectID.Id025] =
{
	Id = 25,
	Node = "rabbit25",
	PreCondition = {
		PreGoalList = {
			300040,
		},
	},
	Weight = 1000,
	RewardList = {
		{
			Id = 2,
			Num = 50,
		},
		{
			Id = 320424,
			Num = 2,
		},
	},
	HintText = "听说，兔子在流亡街呢？",
}
HideSeekObjectConfig[HideSeekObjectID.Id026] =
{
	Id = 26,
	Node = "rabbit26",
	PreCondition = {
		PreGoalList = {
			300040,
		},
	},
	Weight = 1000,
	RewardList = {
		{
			Id = 2,
			Num = 50,
		},
		{
			Id = 320424,
			Num = 2,
		},
	},
	HintText = "听说，兔子在流亡街呢？",
}
HideSeekObjectConfig[HideSeekObjectID.Id027] =
{
	Id = 27,
	Node = "rabbit27",
	PreCondition = {
		PreGoalList = {
			300040,
		},
	},
	Weight = 1000,
	RewardList = {
		{
			Id = 2,
			Num = 50,
		},
		{
			Id = 320424,
			Num = 2,
		},
	},
	HintText = "听说，兔子在流亡街呢？",
}
HideSeekObjectConfig[HideSeekObjectID.Id028] =
{
	Id = 28,
	Node = "rabbit28",
	PreCondition = {
		PreGoalList = {
			300040,
		},
	},
	Weight = 1000,
	RewardList = {
		{
			Id = 2,
			Num = 50,
		},
		{
			Id = 320424,
			Num = 2,
		},
	},
	HintText = "听说，兔子在流亡街呢？",
}
HideSeekObjectConfig[HideSeekObjectID.Id029] =
{
	Id = 29,
	Node = "rabbit29",
	PreCondition = {
		PreGoalList = {
			300040,
		},
	},
	Weight = 1000,
	RewardList = {
		{
			Id = 2,
			Num = 50,
		},
		{
			Id = 320424,
			Num = 2,
		},
	},
	HintText = "听说，兔子在流亡街呢？",
}
HideSeekObjectConfig[HideSeekObjectID.Id030] =
{
	Id = 30,
	Node = "rabbit30",
	PreCondition = {
		PreGoalList = {
			300040,
		},
	},
	Weight = 1000,
	RewardList = {
		{
			Id = 2,
			Num = 50,
		},
		{
			Id = 320424,
			Num = 2,
		},
	},
	HintText = "听说，兔子在流亡街呢？",
}
HideSeekObjectConfig[HideSeekObjectID.Id031] =
{
	Id = 31,
	Node = "rabbit31",
	PreCondition = {
		PreGoalList = {
			300040,
		},
	},
	Weight = 1000,
	RewardList = {
		{
			Id = 2,
			Num = 50,
		},
		{
			Id = 320424,
			Num = 2,
		},
	},
	HintText = "听说，兔子在流亡街呢？",
}
HideSeekObjectConfig[HideSeekObjectID.Id032] =
{
	Id = 32,
	Node = "rabbit32",
	PreCondition = {
		PreGoalList = {
			300040,
		},
	},
	Weight = 1000,
	RewardList = {
		{
			Id = 2,
			Num = 50,
		},
		{
			Id = 320424,
			Num = 2,
		},
	},
	HintText = "听说，兔子在流亡街呢？",
}
HideSeekObjectConfig[HideSeekObjectID.Id033] =
{
	Id = 33,
	Node = "rabbit33",
	PreCondition = {
		PreGoalList = {
			300040,
		},
	},
	Weight = 1000,
	RewardList = {
		{
			Id = 2,
			Num = 50,
		},
		{
			Id = 320424,
			Num = 2,
		},
	},
	HintText = "听说，兔子在流亡街呢？",
}
HideSeekObjectConfig[HideSeekObjectID.Id034] =
{
	Id = 34,
	Node = "rabbit34",
	PreCondition = {
		PreGoalList = {
			300040,
		},
	},
	Weight = 1000,
	RewardList = {
		{
			Id = 2,
			Num = 50,
		},
		{
			Id = 320424,
			Num = 2,
		},
	},
	HintText = "听说，兔子在流亡街呢？",
}
HideSeekObjectConfig[HideSeekObjectID.Id035] =
{
	Id = 35,
	Node = "rabbit35",
	PreCondition = {
		PreGoalList = {
			300040,
		},
	},
	Weight = 1000,
	RewardList = {
		{
			Id = 2,
			Num = 50,
		},
		{
			Id = 320424,
			Num = 2,
		},
	},
	HintText = "听说，兔子在流亡街呢？",
}
HideSeekObjectConfig[HideSeekObjectID.Id036] =
{
	Id = 36,
	Node = "rabbit36",
	PreCondition = {
		PreGoalList = {
			300040,
		},
	},
	Weight = 1000,
	RewardList = {
		{
			Id = 2,
			Num = 50,
		},
		{
			Id = 320424,
			Num = 2,
		},
	},
	HintText = "听说，兔子在流亡街呢？",
}
HideSeekObjectConfig[HideSeekObjectID.Id037] =
{
	Id = 37,
	Node = "rabbit37",
	PreCondition = {
		PreGoalList = {
			300040,
		},
	},
	Weight = 1000,
	RewardList = {
		{
			Id = 2,
			Num = 50,
		},
		{
			Id = 320424,
			Num = 2,
		},
	},
	HintText = "听说，兔子在冒险星呢？",
}
HideSeekObjectConfig[HideSeekObjectID.Id038] =
{
	Id = 38,
	Node = "rabbit38",
	PreCondition = {
		PreGoalList = {
			300040,
		},
	},
	Weight = 1000,
	RewardList = {
		{
			Id = 2,
			Num = 50,
		},
		{
			Id = 320424,
			Num = 2,
		},
	},
	HintText = "听说，兔子在冒险星呢？",
}
HideSeekObjectConfig[HideSeekObjectID.Id039] =
{
	Id = 39,
	Node = "rabbit39",
	PreCondition = {
		PreGoalList = {
			300040,
		},
	},
	Weight = 1000,
	RewardList = {
		{
			Id = 2,
			Num = 50,
		},
		{
			Id = 320424,
			Num = 2,
		},
	},
	HintText = "听说，兔子在冒险星呢？",
}
HideSeekObjectConfig[HideSeekObjectID.Id040] =
{
	Id = 40,
	Node = "rabbit40",
	PreCondition = {
		PreGoalList = {
			300040,
		},
	},
	Weight = 1000,
	RewardList = {
		{
			Id = 2,
			Num = 50,
		},
		{
			Id = 320424,
			Num = 2,
		},
	},
	HintText = "听说，兔子在冒险星呢？",
}
HideSeekObjectConfig[HideSeekObjectID.Id041] =
{
	Id = 41,
	Node = "rabbit41",
	PreCondition = {
		PreGoalList = {
			300040,
		},
	},
	Weight = 1000,
	RewardList = {
		{
			Id = 2,
			Num = 50,
		},
		{
			Id = 320424,
			Num = 2,
		},
	},
	HintText = "听说，兔子在冒险星呢？",
}
HideSeekObjectConfig[HideSeekObjectID.Id042] =
{
	Id = 42,
	Node = "rabbit42",
	PreCondition = {
		PreGoalList = {
			300040,
		},
	},
	Weight = 1000,
	RewardList = {
		{
			Id = 2,
			Num = 50,
		},
		{
			Id = 320424,
			Num = 2,
		},
	},
	HintText = "听说，兔子在冒险星呢？",
}
HideSeekObjectConfig[HideSeekObjectID.Id043] =
{
	Id = 43,
	Node = "rabbit43",
	PreCondition = {
		PreGoalList = {
			300040,
		},
	},
	Weight = 1000,
	RewardList = {
		{
			Id = 2,
			Num = 50,
		},
		{
			Id = 320424,
			Num = 2,
		},
	},
	HintText = "听说，兔子在冒险星呢？",
}
HideSeekObjectConfig[HideSeekObjectID.Id044] =
{
	Id = 44,
	Node = "rabbit44",
	PreCondition = {
		PreGoalList = {
			300040,
		},
	},
	Weight = 1000,
	RewardList = {
		{
			Id = 2,
			Num = 50,
		},
		{
			Id = 320424,
			Num = 2,
		},
	},
	HintText = "听说，兔子在冒险星呢？",
}
HideSeekObjectConfig[HideSeekObjectID.Id045] =
{
	Id = 45,
	Node = "rabbit45",
	PreCondition = {
		PreGoalList = {
			300040,
		},
	},
	Weight = 1000,
	RewardList = {
		{
			Id = 2,
			Num = 50,
		},
		{
			Id = 320424,
			Num = 2,
		},
	},
	HintText = "听说，兔子在冒险星呢？",
}
HideSeekObjectConfig[HideSeekObjectID.Id046] =
{
	Id = 46,
	Node = "rabbit46",
	PreCondition = {
		PreGoalList = {
			300040,
		},
	},
	Weight = 1000,
	RewardList = {
		{
			Id = 2,
			Num = 50,
		},
		{
			Id = 320424,
			Num = 2,
		},
	},
	HintText = "听说，兔子在冒险星呢？",
}
HideSeekObjectConfig[HideSeekObjectID.Id047] =
{
	Id = 47,
	Node = "rabbit47",
	PreCondition = {
		PreGoalList = {
			300040,
		},
	},
	Weight = 1000,
	RewardList = {
		{
			Id = 2,
			Num = 50,
		},
		{
			Id = 320424,
			Num = 2,
		},
	},
	HintText = "听说，兔子在冒险星呢？",
}
HideSeekObjectConfig[HideSeekObjectID.Id048] =
{
	Id = 48,
	Node = "rabbit48",
	PreCondition = {
		PreGoalList = {
			300040,
		},
	},
	Weight = 1000,
	RewardList = {
		{
			Id = 2,
			Num = 50,
		},
		{
			Id = 320424,
			Num = 2,
		},
	},
	HintText = "听说，兔子在冒险星呢？",
}
HideSeekObjectConfig[HideSeekObjectID.Id049] =
{
	Id = 49,
	Node = "rabbit49",
	PreCondition = {
		PreGoalList = {
			300040,
		},
	},
	Weight = 1000,
	RewardList = {
		{
			Id = 2,
			Num = 50,
		},
		{
			Id = 320424,
			Num = 2,
		},
	},
	HintText = "听说，兔子在冒险星呢？",
}
HideSeekObjectConfig[HideSeekObjectID.Id050] =
{
	Id = 50,
	Node = "rabbit50",
	PreCondition = {
		PreGoalList = {
			300040,
		},
	},
	Weight = 1000,
	RewardList = {
		{
			Id = 2,
			Num = 50,
		},
		{
			Id = 320424,
			Num = 2,
		},
	},
	HintText = "听说，兔子在冒险星呢？",
}
HideSeekObjectConfig[HideSeekObjectID.Id051] =
{
	Id = 51,
	Node = "rabbit51",
	PreCondition = {
		PreGoalList = {
			300040,
		},
	},
	Weight = 1000,
	RewardList = {
		{
			Id = 2,
			Num = 50,
		},
		{
			Id = 320424,
			Num = 2,
		},
	},
	HintText = "听说，兔子在冒险星呢？",
}
HideSeekObjectConfig[HideSeekObjectID.Id052] =
{
	Id = 52,
	Node = "rabbit52",
	PreCondition = {
		PreGoalList = {
			300040,
		},
	},
	Weight = 1000,
	RewardList = {
		{
			Id = 2,
			Num = 50,
		},
		{
			Id = 320424,
			Num = 2,
		},
	},
	HintText = "听说，兔子在冒险星呢？",
}
HideSeekObjectConfig[HideSeekObjectID.Id053] =
{
	Id = 53,
	Node = "rabbit53",
	PreCondition = {
		PreGoalList = {
			300040,
		},
	},
	Weight = 1000,
	RewardList = {
		{
			Id = 2,
			Num = 50,
		},
		{
			Id = 320424,
			Num = 2,
		},
	},
	HintText = "听说，兔子在冒险星呢？",
}
HideSeekObjectConfig[HideSeekObjectID.Id054] =
{
	Id = 54,
	Node = "rabbit54",
	PreCondition = {
		PreGoalList = {
			300040,
		},
	},
	Weight = 1000,
	RewardList = {
		{
			Id = 2,
			Num = 50,
		},
		{
			Id = 320424,
			Num = 2,
		},
	},
	HintText = "听说，兔子在冒险星呢？",
}
HideSeekObjectConfig[HideSeekObjectID.Id055] =
{
	Id = 55,
	Node = "rabbit55",
	PreCondition = {
		PreGoalList = {
			300040,
		},
	},
	Weight = 1000,
	RewardList = {
		{
			Id = 2,
			Num = 50,
		},
		{
			Id = 320424,
			Num = 2,
		},
	},
	HintText = "听说，兔子在冒险星呢？",
}
HideSeekObjectConfig[HideSeekObjectID.Id056] =
{
	Id = 56,
	Node = "rabbit56",
	PreCondition = {
		PreGoalList = {
			300040,
		},
	},
	Weight = 1000,
	RewardList = {
		{
			Id = 2,
			Num = 50,
		},
		{
			Id = 320424,
			Num = 2,
		},
	},
	HintText = "听说，兔子在冒险星呢？",
}
HideSeekObjectConfig[HideSeekObjectID.Id057] =
{
	Id = 57,
	Node = "Ghost01",
	PreCondition = {
		PreGoalList = {
			300040,
		},
	},
	Weight = 1000,
	RewardList = {
		{
			Id = 2,
			Num = 25,
		},
		{
			Id = 252002,
			Num = 1,
		},
	},
	HintText = "幽灵雷达显示在流亡街呢~",
}
HideSeekObjectConfig[HideSeekObjectID.Id058] =
{
	Id = 58,
	Node = "Ghost02",
	PreCondition = {
		PreGoalList = {
			300040,
		},
	},
	Weight = 1000,
	RewardList = {
		{
			Id = 2,
			Num = 25,
		},
		{
			Id = 252002,
			Num = 1,
		},
	},
	HintText = "幽灵雷达显示在流亡街呢~",
}
HideSeekObjectConfig[HideSeekObjectID.Id059] =
{
	Id = 59,
	Node = "Ghost03",
	PreCondition = {
		PreGoalList = {
			300040,
		},
	},
	Weight = 1000,
	RewardList = {
		{
			Id = 2,
			Num = 25,
		},
		{
			Id = 252002,
			Num = 1,
		},
	},
	HintText = "幽灵雷达显示在流亡街呢~",
}
HideSeekObjectConfig[HideSeekObjectID.Id060] =
{
	Id = 60,
	Node = "Ghost04",
	PreCondition = {
		PreGoalList = {
			300040,
		},
	},
	Weight = 1000,
	RewardList = {
		{
			Id = 2,
			Num = 25,
		},
		{
			Id = 252002,
			Num = 1,
		},
	},
	HintText = "幽灵雷达显示在流亡街呢~",
}
HideSeekObjectConfig[HideSeekObjectID.Id061] =
{
	Id = 61,
	Node = "Ghost05",
	PreCondition = {
		PreGoalList = {
			300040,
		},
	},
	Weight = 1000,
	RewardList = {
		{
			Id = 2,
			Num = 25,
		},
		{
			Id = 252002,
			Num = 1,
		},
	},
	HintText = "幽灵雷达显示在流亡街呢~",
}
HideSeekObjectConfig[HideSeekObjectID.Id062] =
{
	Id = 62,
	Node = "Ghost06",
	PreCondition = {
		PreGoalList = {
			300040,
		},
	},
	Weight = 1000,
	RewardList = {
		{
			Id = 2,
			Num = 25,
		},
		{
			Id = 252002,
			Num = 1,
		},
	},
	HintText = "幽灵雷达显示在流亡街呢~",
}
HideSeekObjectConfig[HideSeekObjectID.Id063] =
{
	Id = 63,
	Node = "Ghost07",
	PreCondition = {
		PreGoalList = {
			300040,
		},
	},
	Weight = 1000,
	RewardList = {
		{
			Id = 2,
			Num = 25,
		},
		{
			Id = 252002,
			Num = 1,
		},
	},
	HintText = "幽灵雷达显示在流亡街呢~",
}
HideSeekObjectConfig[HideSeekObjectID.Id064] =
{
	Id = 64,
	Node = "Ghost08",
	PreCondition = {
		PreGoalList = {
			300040,
		},
	},
	Weight = 1000,
	RewardList = {
		{
			Id = 2,
			Num = 25,
		},
		{
			Id = 252002,
			Num = 1,
		},
	},
	HintText = "幽灵雷达显示在流亡街呢~",
}
HideSeekObjectConfig[HideSeekObjectID.Id065] =
{
	Id = 65,
	Node = "Ghost09",
	PreCondition = {
		PreGoalList = {
			300040,
		},
	},
	Weight = 1000,
	RewardList = {
		{
			Id = 2,
			Num = 25,
		},
		{
			Id = 252002,
			Num = 1,
		},
	},
	HintText = "幽灵雷达显示在流亡街呢~",
}
HideSeekObjectConfig[HideSeekObjectID.Id066] =
{
	Id = 66,
	Node = "Ghost10",
	PreCondition = {
		PreGoalList = {
			300040,
		},
	},
	Weight = 1000,
	RewardList = {
		{
			Id = 2,
			Num = 25,
		},
		{
			Id = 252002,
			Num = 1,
		},
	},
	HintText = "幽灵雷达显示在流亡街呢~",
}
HideSeekObjectConfig[HideSeekObjectID.Id067] =
{
	Id = 67,
	Node = "Ghost11",
	PreCondition = {
		PreGoalList = {
			300040,
		},
	},
	Weight = 1000,
	RewardList = {
		{
			Id = 2,
			Num = 25,
		},
		{
			Id = 252002,
			Num = 1,
		},
	},
	HintText = "幽灵雷达显示在流亡街呢~",
}
HideSeekObjectConfig[HideSeekObjectID.Id068] =
{
	Id = 68,
	Node = "Ghost12",
	PreCondition = {
		PreGoalList = {
			300040,
		},
	},
	Weight = 1000,
	RewardList = {
		{
			Id = 2,
			Num = 25,
		},
		{
			Id = 252002,
			Num = 1,
		},
	},
	HintText = "幽灵雷达显示在流亡街呢~",
}
HideSeekObjectConfig[HideSeekObjectID.Id069] =
{
	Id = 69,
	Node = "Ghost13",
	PreCondition = {
		PreGoalList = {
			300040,
		},
	},
	Weight = 1000,
	RewardList = {
		{
			Id = 2,
			Num = 25,
		},
		{
			Id = 252002,
			Num = 1,
		},
	},
	HintText = "幽灵雷达显示在流亡街呢~",
}
HideSeekObjectConfig[HideSeekObjectID.Id070] =
{
	Id = 70,
	Node = "Ghost14",
	PreCondition = {
		PreGoalList = {
			300040,
		},
	},
	Weight = 1000,
	RewardList = {
		{
			Id = 2,
			Num = 25,
		},
		{
			Id = 252002,
			Num = 1,
		},
	},
	HintText = "幽灵雷达显示在流亡街呢~",
}
HideSeekObjectConfig[HideSeekObjectID.Id071] =
{
	Id = 71,
	Node = "Ghost15",
	PreCondition = {
		PreGoalList = {
			300040,
		},
	},
	Weight = 1000,
	RewardList = {
		{
			Id = 2,
			Num = 25,
		},
		{
			Id = 252002,
			Num = 1,
		},
	},
	HintText = "幽灵雷达显示在流亡街呢~",
}
HideSeekObjectConfig[HideSeekObjectID.Id072] =
{
	Id = 72,
	Node = "Ghost16",
	PreCondition = {
		PreGoalList = {
			300040,
		},
	},
	Weight = 1000,
	RewardList = {
		{
			Id = 2,
			Num = 25,
		},
		{
			Id = 252002,
			Num = 1,
		},
	},
	HintText = "幽灵雷达显示在流亡街呢~",
}
HideSeekObjectConfig[HideSeekObjectID.Id073] =
{
	Id = 73,
	Node = "Ghost17",
	PreCondition = {
		PreGoalList = {
			300040,
		},
	},
	Weight = 1000,
	RewardList = {
		{
			Id = 2,
			Num = 25,
		},
		{
			Id = 252002,
			Num = 1,
		},
	},
	HintText = "幽灵雷达显示在流亡街呢~",
}
HideSeekObjectConfig[HideSeekObjectID.Id074] =
{
	Id = 74,
	Node = "Ghost18",
	PreCondition = {
		PreGoalList = {
			300040,
		},
	},
	Weight = 1000,
	RewardList = {
		{
			Id = 2,
			Num = 25,
		},
		{
			Id = 252002,
			Num = 1,
		},
	},
	HintText = "幽灵雷达显示在流亡街呢~",
}
HideSeekObjectConfig[HideSeekObjectID.Id075] =
{
	Id = 75,
	Node = "Ghost19",
	PreCondition = {
		PreGoalList = {
			300040,
		},
	},
	Weight = 1000,
	RewardList = {
		{
			Id = 2,
			Num = 25,
		},
		{
			Id = 252002,
			Num = 1,
		},
	},
	HintText = "幽灵雷达显示在流亡街呢~",
}
HideSeekObjectConfig[HideSeekObjectID.Id076] =
{
	Id = 76,
	Node = "Ghost20",
	PreCondition = {
		PreGoalList = {
			300040,
		},
	},
	Weight = 1000,
	RewardList = {
		{
			Id = 2,
			Num = 25,
		},
		{
			Id = 252002,
			Num = 1,
		},
	},
	HintText = "幽灵雷达显示在流亡街呢~",
}
HideSeekObjectConfig[HideSeekObjectID.Id077] =
{
	Id = 77,
	Node = "Ghost21",
	PreCondition = {
		PreGoalList = {
			300040,
		},
	},
	Weight = 1000,
	RewardList = {
		{
			Id = 2,
			Num = 25,
		},
		{
			Id = 252002,
			Num = 1,
		},
	},
	HintText = "幽灵雷达显示在流亡街呢~",
}
HideSeekObjectConfig[HideSeekObjectID.Id078] =
{
	Id = 78,
	Node = "Ghost22",
	PreCondition = {
		PreGoalList = {
			300040,
		},
	},
	Weight = 1000,
	RewardList = {
		{
			Id = 2,
			Num = 25,
		},
		{
			Id = 252002,
			Num = 1,
		},
	},
	HintText = "幽灵雷达显示在流亡街呢~",
}
HideSeekObjectConfig[HideSeekObjectID.Id079] =
{
	Id = 79,
	Node = "Ghost23",
	PreCondition = {
		PreGoalList = {
			300040,
		},
	},
	Weight = 1000,
	RewardList = {
		{
			Id = 2,
			Num = 25,
		},
		{
			Id = 252002,
			Num = 1,
		},
	},
	HintText = "幽灵雷达显示在流亡街呢~",
}
HideSeekObjectConfig[HideSeekObjectID.Id080] =
{
	Id = 80,
	Node = "Ghost24",
	PreCondition = {
		PreGoalList = {
			300040,
		},
	},
	Weight = 1000,
	RewardList = {
		{
			Id = 2,
			Num = 25,
		},
		{
			Id = 252002,
			Num = 1,
		},
	},
	HintText = "听说冒险星闹鬼了？",
}
HideSeekObjectConfig[HideSeekObjectID.Id081] =
{
	Id = 81,
	Node = "Ghost25",
	PreCondition = {
		PreGoalList = {
			300040,
		},
	},
	Weight = 1000,
	RewardList = {
		{
			Id = 2,
			Num = 25,
		},
		{
			Id = 252002,
			Num = 1,
		},
	},
	HintText = "听说冒险星闹鬼了？",
}
HideSeekObjectConfig[HideSeekObjectID.Id082] =
{
	Id = 82,
	Node = "Ghost26",
	PreCondition = {
		PreGoalList = {
			300040,
		},
	},
	Weight = 1000,
	RewardList = {
		{
			Id = 2,
			Num = 25,
		},
		{
			Id = 252002,
			Num = 1,
		},
	},
	HintText = "听说冒险星闹鬼了？",
}
HideSeekObjectConfig[HideSeekObjectID.Id083] =
{
	Id = 83,
	Node = "Ghost27",
	PreCondition = {
		PreGoalList = {
			300040,
		},
	},
	Weight = 1000,
	RewardList = {
		{
			Id = 2,
			Num = 25,
		},
		{
			Id = 252002,
			Num = 1,
		},
	},
	HintText = "听说冒险星闹鬼了？",
}
HideSeekObjectConfig[HideSeekObjectID.Id084] =
{
	Id = 84,
	Node = "Ghost28",
	PreCondition = {
		PreGoalList = {
			300040,
		},
	},
	Weight = 1000,
	RewardList = {
		{
			Id = 2,
			Num = 25,
		},
		{
			Id = 252002,
			Num = 1,
		},
	},
	HintText = "听说冒险星闹鬼了？",
}
HideSeekObjectConfig[HideSeekObjectID.Id085] =
{
	Id = 85,
	Node = "Ghost29",
	PreCondition = {
		PreGoalList = {
			300040,
		},
	},
	Weight = 1000,
	RewardList = {
		{
			Id = 2,
			Num = 25,
		},
		{
			Id = 252002,
			Num = 1,
		},
	},
	HintText = "听说冒险星闹鬼了？",
}
HideSeekObjectConfig[HideSeekObjectID.Id086] =
{
	Id = 86,
	Node = "Ghost30",
	PreCondition = {
		PreGoalList = {
			300040,
		},
	},
	Weight = 1000,
	RewardList = {
		{
			Id = 2,
			Num = 25,
		},
		{
			Id = 252002,
			Num = 1,
		},
	},
	HintText = "听说冒险星闹鬼了？",
}
HideSeekObjectConfig[HideSeekObjectID.Id087] =
{
	Id = 87,
	Node = "Ghost31",
	PreCondition = {
		PreGoalList = {
			300040,
		},
	},
	Weight = 1000,
	RewardList = {
		{
			Id = 2,
			Num = 25,
		},
		{
			Id = 252002,
			Num = 1,
		},
	},
	HintText = "听说冒险星闹鬼了？",
}
HideSeekObjectConfig[HideSeekObjectID.Id088] =
{
	Id = 88,
	Node = "Ghost32",
	PreCondition = {
		PreGoalList = {
			300040,
		},
	},
	Weight = 1000,
	RewardList = {
		{
			Id = 2,
			Num = 25,
		},
		{
			Id = 252002,
			Num = 1,
		},
	},
	HintText = "听说冒险星闹鬼了？",
}
HideSeekObjectConfig[HideSeekObjectID.Id089] =
{
	Id = 89,
	Node = "Ghost33",
	PreCondition = {
		PreGoalList = {
			300040,
		},
	},
	Weight = 1000,
	RewardList = {
		{
			Id = 2,
			Num = 25,
		},
		{
			Id = 252002,
			Num = 1,
		},
	},
	HintText = "听说冒险星闹鬼了？",
}
HideSeekObjectConfig[HideSeekObjectID.Id090] =
{
	Id = 90,
	Node = "Ghost34",
	PreCondition = {
		PreGoalList = {
			300040,
		},
	},
	Weight = 1000,
	RewardList = {
		{
			Id = 2,
			Num = 25,
		},
		{
			Id = 252002,
			Num = 1,
		},
	},
	HintText = "听说冒险星闹鬼了？",
}
HideSeekObjectConfig[HideSeekObjectID.Id091] =
{
	Id = 91,
	Node = "Ghost35",
	PreCondition = {
		PreGoalList = {
			300040,
		},
	},
	Weight = 1000,
	RewardList = {
		{
			Id = 2,
			Num = 25,
		},
		{
			Id = 252002,
			Num = 1,
		},
	},
	HintText = "听说冒险星闹鬼了？",
}
HideSeekObjectConfig[HideSeekObjectID.Id092] =
{
	Id = 92,
	Node = "Ghost36",
	PreCondition = {
		PreGoalList = {
			300040,
		},
	},
	Weight = 1000,
	RewardList = {
		{
			Id = 2,
			Num = 25,
		},
		{
			Id = 252002,
			Num = 1,
		},
	},
	HintText = "听说冒险星闹鬼了？",
}
HideSeekObjectConfig[HideSeekObjectID.Id093] =
{
	Id = 93,
	Node = "Ghost37",
	PreCondition = {
		PreGoalList = {
			300040,
		},
	},
	Weight = 1000,
	RewardList = {
		{
			Id = 2,
			Num = 25,
		},
		{
			Id = 252002,
			Num = 1,
		},
	},
	HintText = "听说冒险星闹鬼了？",
}
HideSeekObjectConfig[HideSeekObjectID.Id094] =
{
	Id = 94,
	Node = "Ghost38",
	PreCondition = {
		PreGoalList = {
			300040,
		},
	},
	Weight = 1000,
	RewardList = {
		{
			Id = 2,
			Num = 25,
		},
		{
			Id = 252002,
			Num = 1,
		},
	},
	HintText = "听说冒险星闹鬼了？",
}
HideSeekObjectConfig[HideSeekObjectID.Id095] =
{
	Id = 95,
	Node = "Ghost39",
	PreCondition = {
		PreGoalList = {
			300040,
		},
	},
	Weight = 1000,
	RewardList = {
		{
			Id = 2,
			Num = 25,
		},
		{
			Id = 252002,
			Num = 1,
		},
	},
	HintText = "听说冒险星闹鬼了？",
}
HideSeekObjectConfig[HideSeekObjectID.Id096] =
{
	Id = 96,
	Node = "Ghost40",
	PreCondition = {
		PreGoalList = {
			300040,
		},
	},
	Weight = 1000,
	RewardList = {
		{
			Id = 2,
			Num = 25,
		},
		{
			Id = 252002,
			Num = 1,
		},
	},
	HintText = "听说冒险星闹鬼了？",
}
HideSeekObjectConfig[HideSeekObjectID.Id097] =
{
	Id = 97,
	Node = "Ghost41",
	PreCondition = {
		PreGoalList = {
			300040,
		},
	},
	Weight = 1000,
	RewardList = {
		{
			Id = 2,
			Num = 25,
		},
		{
			Id = 252002,
			Num = 1,
		},
	},
	HintText = "听说冒险星闹鬼了？",
}
HideSeekObjectConfig[HideSeekObjectID.Id098] =
{
	Id = 98,
	Node = "Ghost42",
	PreCondition = {
		PreGoalList = {
			300103,
		},
	},
	Weight = 1000,
	RewardList = {
		{
			Id = 2,
			Num = 25,
		},
		{
			Id = 252002,
			Num = 1,
		},
	},
	HintText = "贪吃鬼们可能在美食星呢~",
}
HideSeekObjectConfig[HideSeekObjectID.Id099] =
{
	Id = 99,
	Node = "Ghost43",
	PreCondition = {
		PreGoalList = {
			300103,
		},
	},
	Weight = 1000,
	RewardList = {
		{
			Id = 2,
			Num = 25,
		},
		{
			Id = 252002,
			Num = 1,
		},
	},
	HintText = "贪吃鬼们可能在美食星呢~",
}
HideSeekObjectConfig[HideSeekObjectID.Id100] =
{
	Id = 100,
	Node = "Ghost44",
	PreCondition = {
		PreGoalList = {
			300103,
		},
	},
	Weight = 1000,
	RewardList = {
		{
			Id = 2,
			Num = 25,
		},
		{
			Id = 252002,
			Num = 1,
		},
	},
	HintText = "贪吃鬼们可能在美食星呢~",
}
HideSeekObjectConfig[HideSeekObjectID.Id101] =
{
	Id = 101,
	Node = "Ghost45",
	PreCondition = {
		PreGoalList = {
			300103,
		},
	},
	Weight = 1000,
	RewardList = {
		{
			Id = 2,
			Num = 25,
		},
		{
			Id = 252002,
			Num = 1,
		},
	},
	HintText = "贪吃鬼们可能在美食星呢~",
}
HideSeekObjectConfig[HideSeekObjectID.Id102] =
{
	Id = 102,
	Node = "Ghost46",
	PreCondition = {
		PreGoalList = {
			300103,
		},
	},
	Weight = 1000,
	RewardList = {
		{
			Id = 2,
			Num = 25,
		},
		{
			Id = 252002,
			Num = 1,
		},
	},
	HintText = "贪吃鬼们可能在美食星呢~",
}
HideSeekObjectConfig[HideSeekObjectID.Id103] =
{
	Id = 103,
	Node = "Ghost47",
	PreCondition = {
		PreGoalList = {
			300103,
		},
	},
	Weight = 1000,
	RewardList = {
		{
			Id = 2,
			Num = 25,
		},
		{
			Id = 252002,
			Num = 1,
		},
	},
	HintText = "贪吃鬼们可能在美食星呢~",
}
HideSeekObjectConfig[HideSeekObjectID.Id104] =
{
	Id = 104,
	Node = "Ghost48",
	PreCondition = {
		PreGoalList = {
			300103,
		},
	},
	Weight = 1000,
	RewardList = {
		{
			Id = 2,
			Num = 25,
		},
		{
			Id = 252002,
			Num = 1,
		},
	},
	HintText = "贪吃鬼们可能在美食星呢~",
}
HideSeekObjectConfig[HideSeekObjectID.Id105] =
{
	Id = 105,
	Node = "Ghost49",
	PreCondition = {
		PreGoalList = {
			300103,
		},
	},
	Weight = 1000,
	RewardList = {
		{
			Id = 2,
			Num = 25,
		},
		{
			Id = 252002,
			Num = 1,
		},
	},
	HintText = "贪吃鬼们可能在美食星呢~",
}
HideSeekObjectConfig[HideSeekObjectID.Id106] =
{
	Id = 106,
	Node = "Ghost50",
	PreCondition = {
		PreGoalList = {
			300103,
		},
	},
	Weight = 1000,
	RewardList = {
		{
			Id = 2,
			Num = 25,
		},
		{
			Id = 252002,
			Num = 1,
		},
	},
	HintText = "贪吃鬼们可能在美食星呢~",
}
HideSeekObjectConfig[HideSeekObjectID.Id107] =
{
	Id = 107,
	Node = "Ghost51",
	PreCondition = {
		PreGoalList = {
			300103,
		},
	},
	Weight = 1000,
	RewardList = {
		{
			Id = 2,
			Num = 25,
		},
		{
			Id = 252002,
			Num = 1,
		},
	},
	HintText = "贪吃鬼们可能在美食星呢~",
}
HideSeekObjectConfig[HideSeekObjectID.Id108] =
{
	Id = 108,
	Node = "Ghost52",
	PreCondition = {
		PreGoalList = {
			300103,
		},
	},
	Weight = 1000,
	RewardList = {
		{
			Id = 2,
			Num = 25,
		},
		{
			Id = 252002,
			Num = 1,
		},
	},
	HintText = "贪吃鬼们可能在美食星呢~",
}
HideSeekObjectConfig[HideSeekObjectID.Id109] =
{
	Id = 109,
	Node = "Ghost53",
	PreCondition = {
		PreGoalList = {
			300103,
		},
	},
	Weight = 1000,
	RewardList = {
		{
			Id = 2,
			Num = 25,
		},
		{
			Id = 252002,
			Num = 1,
		},
	},
	HintText = "贪吃鬼们可能在美食星呢~",
}
HideSeekObjectConfig[HideSeekObjectID.Id110] =
{
	Id = 110,
	Node = "Ghost54",
	PreCondition = {
		PreGoalList = {
			300103,
		},
	},
	Weight = 1000,
	RewardList = {
		{
			Id = 2,
			Num = 25,
		},
		{
			Id = 252002,
			Num = 1,
		},
	},
	HintText = "贪吃鬼们可能在美食星呢~",
}
HideSeekObjectConfig[HideSeekObjectID.Id111] =
{
	Id = 111,
	Node = "Ghost55",
	PreCondition = {
		PreGoalList = {
			300103,
		},
	},
	Weight = 1000,
	RewardList = {
		{
			Id = 2,
			Num = 25,
		},
		{
			Id = 252002,
			Num = 1,
		},
	},
	HintText = "贪吃鬼们可能在美食星呢~",
}
HideSeekObjectConfig[HideSeekObjectID.Id112] =
{
	Id = 112,
	Node = "Ghost56",
	PreCondition = {
		PreGoalList = {
			300103,
		},
	},
	Weight = 1000,
	RewardList = {
		{
			Id = 2,
			Num = 25,
		},
		{
			Id = 252002,
			Num = 1,
		},
	},
	HintText = "贪吃鬼们可能在美食星呢~",
}
HideSeekObjectConfig[HideSeekObjectID.Id113] =
{
	Id = 113,
	Node = "Ghost57",
	PreCondition = {
		PreGoalList = {
			300103,
		},
	},
	Weight = 1000,
	RewardList = {
		{
			Id = 2,
			Num = 25,
		},
		{
			Id = 252002,
			Num = 1,
		},
	},
	HintText = "贪吃鬼们可能在美食星呢~",
}
HideSeekObjectConfig[HideSeekObjectID.Id114] =
{
	Id = 114,
	Node = "Ghost58",
	PreCondition = {
		PreGoalList = {
			300103,
		},
	},
	Weight = 1000,
	RewardList = {
		{
			Id = 2,
			Num = 25,
		},
		{
			Id = 252002,
			Num = 1,
		},
	},
	HintText = "贪吃鬼们可能在美食星呢~",
}
HideSeekObjectConfig[HideSeekObjectID.Id115] =
{
	Id = 115,
	Node = "Ghost59",
	PreCondition = {
		PreGoalList = {
			300103,
		},
	},
	Weight = 1000,
	RewardList = {
		{
			Id = 2,
			Num = 25,
		},
		{
			Id = 252002,
			Num = 1,
		},
	},
	HintText = "贪吃鬼们可能在美食星呢~",
}
HideSeekObjectConfig[HideSeekObjectID.Id116] =
{
	Id = 116,
	Node = "Ghost60",
	PreCondition = {
		PreGoalList = {
			300103,
		},
	},
	Weight = 1000,
	RewardList = {
		{
			Id = 2,
			Num = 25,
		},
		{
			Id = 252002,
			Num = 1,
		},
	},
	HintText = "贪吃鬼们可能在美食星呢~",
}
HideSeekObjectConfig[HideSeekObjectID.Id117] =
{
	Id = 117,
	Node = "Ghost61",
	PreCondition = {
		PreGoalList = {
			300103,
		},
	},
	Weight = 1000,
	RewardList = {
		{
			Id = 2,
			Num = 25,
		},
		{
			Id = 252002,
			Num = 1,
		},
	},
	HintText = "贪吃鬼们可能在美食星呢~",
}

