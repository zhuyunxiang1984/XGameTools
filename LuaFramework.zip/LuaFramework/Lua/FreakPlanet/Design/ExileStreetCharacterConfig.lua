ExileStreetCharacterConfig ={};
ExileStreetCharacterConfig["All_Penguin"] =
{
	DialogList = {
		{
			{
				Text = "我是未来协会的负责人P…不，是D先生。",
				Position = 1,
			},
			{
				Text = "协会致力于维护街道和谐。",
				Position = 1,
			},
			{
				Text = "但绝不姑息街道内的不法分子！",
				Position = 1,
			},
			{
				Text = "阁下想协助治安的话，至少…",
				Position = 1,
			},
			{
				Text = "完成主线102吧！",
				Position = 1,
			},
		},
		{
			{
				Text = "安详的街道下暗流涌动！",
				Position = 1,
			},
			{
				Text = "探险家，不要松懈！",
				Position = 1,
			},
		},
		{
			{
				Text = "只要协助抓捕通缉犯，就能拿到协会的奖励。",
				Position = 1,
			},
			{
				Text = "你问有什么用？",
				Position = 1,
			},
			{
				Text = "你看到右下角的商店了吗？",
				Position = 1,
			},
			{
				Text = "那里有不少好东西，只收协会指定的货币噢~",
				Position = 1,
			},
		},
	},
}
ExileStreetCharacterConfig["SPDraw_01_SlimeKing"] =
{
	PreCondition = {
		UnlockCharacterList = {
			221001,
		},
	},
	DialogList = {
		{
			{
				Text = "终于放假啦，哇哈！",
				Position = 1,
			},
			{
				Text = "赚了好多金币，可以随便花咧~",
				Position = 1,
			},
		},
		{
			{
				Text = "不知道会不会有以前的买家来寻仇。",
				Position = 1,
			},
			{
				Text = "还是先拿赚到的金币买份医疗保险比较好。",
				Position = 1,
			},
		},
	},
}
ExileStreetCharacterConfig["SPDraw_02_ElvenPrince"] =
{
	PreCondition = {
		UnlockCharacterList = {
			221002,
		},
	},
	DialogList = {
		{
			{
				Text = "终于有自己的果汁店了！",
				Position = 1,
			},
			{
				Text = "下个目标是，再开100家分店！",
				Position = 1,
			},
		},
		{
			{
				Text = "竟然真的会抽空金币池…",
				Position = 1,
			},
			{
				Text = "倒是有点出乎意料呢！",
				Position = 1,
			},
		},
		{
			{
				Text = "哎，这里的人好像都不喝果汁啊…",
				Position = 1,
			},
			{
				Text = "不是喝酒就是喝茶…",
				Position = 1,
			},
		},
		{
			{
				Text = "都是外星的高档进口果汁，大家来看一看啊。",
				Position = 1,
			},
			{
				Text = "蓝星鲜橙汁，只要5400一杯噢~",
				Position = 1,
			},
			{
				Text = "除了外星进口化工品，不加任何本地添加剂噢~",
				Position = 1,
			},
		},
	},
}
ExileStreetCharacterConfig["SPDraw_03_DiamondQueen"] =
{
	PreCondition = {
		UnlockCharacterList = {
			221003,
		},
	},
	DialogList = {
		{
			{
				Text = "哎呀，有点怀念不夜城了呀~",
				Position = 1,
			},
			{
				Text = "得想办法再物色点商品回去卖。",
				Position = 1,
			},
		},
		{
			{
				Text = "玉璧对我而言也只是一个数字而已噢~",
				Position = 1,
			},
		},
		{
			{
				Text = "哎，好无聊，抽璧池打发一下时间。",
				Position = 1,
			},
			{
				Text = "哇，抽了1万次十连终于抽到水逆券了！",
				Position = 1,
			},
		},
	},
}
ExileStreetCharacterConfig["SPDraw_04_UnlockChief2"] =
{
	PreCondition = {
		UnlockCharacterList = {
			221004,
		},
	},
	DialogList = {
		{
			{
				Text = "不想出走半生，归来仍是酋长。",
				Position = 1,
			},
		},
		{
			{
				Text = "等领了今天的工资，又可以去抽奖了！",
				Position = 1,
			},
			{
				Text = "这次一定要来一把十连十彩！",
				Position = 1,
			},
		},
		{
			{
				Text = "怎么整个街区就我一个人在打扫？",
				Position = 1,
			},
			{
				Text = "不过也好，竞争压力小一点。",
				Position = 1,
			},
		},
		{
			{
				Text = "不能再抽奖了，再抽下去这辈子都回不去了。",
				Position = 1,
			},
			{
				Text = "除非出彩，否则最多再抽10万把十连就收手。",
				Position = 1,
			},
			{
				Text = "算了算了，最多再抽100万把吧。",
				Position = 1,
			},
		},
	},
}
ExileStreetCharacterConfig["SPBUS_01_yeji"] =
{
	PreCondition = {
		UnlockCharacterList = {
			221005,
		},
	},
	DialogList = {
		{
			{
				Text = "咕嘟咕嘟咕嘟咕嘟…",
				Position = 1,
			},
			{
				Text = "哈————",
				Position = 1,
			},
			{
				Text = "这里的生活好悠闲啊。",
				Position = 1,
			},
		},
		{
			{
				Text = "探索累了，可以来这里喝茶放松一下噢~",
				Position = 1,
			},
			{
				Text = "劳逸结合嘛~",
				Position = 1,
			},
		},
	},
}
ExileStreetCharacterConfig["SPBus_01_MissPeach"] =
{
	PreCondition = {
		UnlockCharacterList = {
			221006,
		},
	},
	DialogList = {
		{
			{
				Text = "亲，有空记得5星好评噢~",
				Position = 1,
			},
		},
		{
			{
				Text = "每天上线要记得签到噢。",
				Position = 1,
			},
		},
		{
			{
				Text = "欢迎加入游戏Q群，有问题可以群里直接问哒。",
				Position = 1,
			},
		},
		{
			{
				Text = "游戏遇到问题，可以在设置界面里找客服解答。",
				Position = 1,
			},
		},
		{
			{
				Text = "修改昵称后，账号会更安全的。",
				Position = 1,
			},
		},
	},
}
ExileStreetCharacterConfig["Pir_01_DarkCooker"] =
{
	PreCondition = {
		UnlockCharacterList = {
			222001,
		},
	},
	DialogList = {
		{
			{
				Text = "卖榴莲，调味榴莲，都来买啊！",
				Position = 1,
			},
		},
		{
			{
				Text = "只卖摆着的这些，头上的不卖！",
				Position = 1,
			},
		},
		{
			{
				Text = "不保新鲜，不保甜，只保臭。",
				Position = 1,
			},
		},
	},
}
ExileStreetCharacterConfig["Pir_02_SuperGirl"] =
{
	PreCondition = {
		UnlockCharacterList = {
			222021,
		},
	},
	DialogList = {
		{
			{
				Text = "咦，下一页被黏住了？",
				Position = 1,
			},
			{
				Text = "嗯，用超能力翻开来！",
				Position = 1,
			},
			{
				Text = "诶~直接透视好像更方便！",
				Position = 1,
			},
		},
		{
			{
				Text = "咦，少爷要向书童告白了？",
				Position = 1,
			},
			{
				Text = "哎呀，怎么会有这种剧情啊？",
				Position = 1,
			},
			{
				Text = "不过好像很有趣的样子。",
				Position = 1,
			},
		},
	},
}
ExileStreetCharacterConfig["Pir_03_RacingDriver"] =
{
	PreCondition = {
		UnlockCharacterList = {
			222041,
		},
	},
	DialogList = {
		{
			{
				Text = "哇~V型十二缸水冷，1600马~",
				Position = 1,
			},
			{
				Text = "怠速至少2400转了。",
				Position = 1,
			},
			{
				Text = "哎，可惜驾照吊销了…",
				Position = 1,
			},
		},
	},
}
ExileStreetCharacterConfig["Pir_04_ChangeableMan"] =
{
	PreCondition = {
		UnlockCharacterList = {
			222042,
		},
	},
	DialogList = {
		{
			{
				Text = "最新的无重力抛球表演~",
				Position = 1,
			},
			{
				Text = "你看，小球的运动几乎是匀速的！",
				Position = 1,
			},
			{
				Text = "大家觉得好笑一定要笑出来啊！",
				Position = 1,
			},
			{
				Text = "这都不好笑吗？客人你的笑点也太奇怪了！",
				Position = 1,
			},
		},
		{
			{
				Text = "我可不是小丑！我是表演家！",
				Position = 1,
			},
			{
				Text = "虽然档案上还写着危险分子…",
				Position = 1,
			},
		},
		{
			{
				Text = "我也不知道我为什么被通缉。",
				Position = 1,
			},
			{
				Text = "明明只是给陌生人寄了惊悚礼物而已。",
				Position = 1,
			},
			{
				Text = "所以，没有你想的那么危险。",
				Position = 1,
			},
		},
		{
			{
				Text = "我的愿望是什么？",
				Position = 1,
			},
			{
				Text = "如果能开一个自己的马戏团就好啦~",
				Position = 1,
			},
			{
				Text = "到时候一定会给大家献上爆笑的表演的。",
				Position = 1,
			},
		},
	},
}
ExileStreetCharacterConfig["Pir_05_SuperBlacksmith"] =
{
	PreCondition = {
		UnlockCharacterList = {
			222043,
		},
	},
	DialogList = {
		{
			{
				Text = "雷神之锤充电宝低价甩卖！",
				Position = 1,
			},
			{
				Text = "渴望拯救世界的你值得拥有！",
				Position = 1,
			},
		},
		{
			{
				Text = "哎，现在生意真是不好做啊。",
				Position = 1,
			},
		},
		{
			{
				Text = "有人要改装身体吗？",
				Position = 1,
			},
			{
				Text = "装一条机械臂送一条机械臂啦！",
				Position = 1,
			},
			{
				Text = "你右手好好的不用装？",
				Position = 1,
			},
			{
				Text = "打断不就好了嘛！",
				Position = 1,
			},
		},
		{
			{
				Text = "这两天身体有点锈，得加点润滑油了。",
				Position = 1,
			},
		},
	},
}
ExileStreetCharacterConfig["Pir_06_DarkPolo"] =
{
	PreCondition = {
		UnlockCharacterList = {
			222044,
		},
	},
	DialogList = {
		{
			{
				Text = "偶尔在温暖的午后，在阳台喝杯茶也不错啊。",
				Position = 1,
			},
			{
				Text = "嚯嚯，新奇的作案手法一不留神就冒出来了。",
				Position = 1,
			},
			{
				Text = "嗯，再喝一杯就去实践一下。",
				Position = 1,
			},
		},
		{
			{
				Text = "嘿嘿嘿，正义？",
				Position = 1,
			},
			{
				Text = "这种狭隘的东西我才不需要呢。",
				Position = 1,
			},
		},
		{
			{
				Text = "人心是何等的奇妙啊。",
				Position = 1,
			},
			{
				Text = "相识的人作案率可能出乎你意料的高噢~",
				Position = 1,
			},
			{
				Text = "所以，要时刻有防范罪案的意识噢~",
				Position = 1,
			},
		},
		{
			{
				Text = "我最喜欢那些扭曲的现场了！",
				Position = 1,
			},
		},
	},
}
ExileStreetCharacterConfig["Pir_07_SharkBoss"] =
{
	PreCondition = {
		UnlockCharacterList = {
			222045,
		},
	},
	DialogList = {
		{
			{
				Text = "呼啊！老子的音乐会马上要开始了啊！",
				Position = 1,
			},
			{
				Text = "这次要好好展示一下什么是爆炸摇滚！",
				Position = 1,
			},
		},
		{
			{
				Text = "为什么要铁杆子？",
				Position = 1,
			},
			{
				Text = "走在路上就看见它横在我面前。",
				Position = 1,
			},
			{
				Text = "等我回过神来的时候，已经咬住了。",
				Position = 1,
			},
		},
		{
			{
				Text = "今天不咬断这个铁杆子，总觉得气不顺啊！",
				Position = 1,
			},
			{
				Text = "说起来，这铁杆子很硬嘛！",
				Position = 1,
			},
		},
	},
}
ExileStreetCharacterConfig["Pir_08_CaptainRoamn"] =
{
	PreCondition = {
		UnlockCharacterList = {
			222046,
		},
	},
	DialogList = {
		{
			{
				Text = "即使被困瓶中，也散发着海洋的气息。",
				Position = 1,
			},
			{
				Text = "不愧是本船长的深海珍珠号。",
				Position = 1,
			},
			{
				Text = "千年后，将又是我们征服海洋的时刻了！",
				Position = 1,
			},
		},
		{
			{
				Text = "果然还是海滨小镇的风最让人舒服啊。",
				Position = 1,
			},
			{
				Text = "凉凉的风吹过吸盘，感觉就像在海边。",
				Position = 1,
			},
		},
	},
}
ExileStreetCharacterConfig["Pir_09_DarkCount"] =
{
	PreCondition = {
		UnlockCharacterList = {
			222047,
		},
	},
	DialogList = {
		{
			{
				Text = "只要涂了防晒霜，白天也能出来创作了。",
				Position = 1,
			},
			{
				Text = "哼哼哼，真是不错的体验啊！",
				Position = 1,
			},
			{
				Text = "红色不够鲜艳？如果有那个的话…",
				Position = 1,
			},
			{
				Text = "等晚上吧，嘿嘿嘿，到时候会有鲜艳的红色的！",
				Position = 1,
			},
		},
		{
			{
				Text = "等保释期过了，就能去博物馆星了，嘿嘿嘿嘿。",
				Position = 1,
			},
		},
		{
			{
				Text = "不知道这个社区什么时候能办个博物馆？",
				Position = 1,
			},
			{
				Text = "到时候我一定会亲临指导的。",
				Position = 1,
			},
		},
	},
}
ExileStreetCharacterConfig["Pir_10_DarkDoctor"] =
{
	PreCondition = {
		UnlockCharacterList = {
			222048,
		},
	},
	DialogList = {
		{
			{
				Text = "47号宇宙发现新的组织样本。",
				Position = 1,
			},
			{
				Text = "似乎是某种生物的携带物？",
				Position = 1,
			},
			{
				Text = "咦，感觉背后有什么东西！",
				Position = 1,
			},
		},
		{
			{
				Text = "嘿嘿，竟然是罕见的喵星人。",
				Position = 1,
			},
			{
				Text = "真想抓起来好好研究一下啊。",
				Position = 1,
			},
			{
				Text = "能知道很多有趣的事情吧，嘿嘿嘿嘿。",
				Position = 1,
			},
			{
				Text = "咦，总觉得背后有东西拍我！",
				Position = 1,
			},
		},
		{
			{
				Text = "从数据上来看，这里有一个多维宇宙的奇点。",
				Position = 1,
			},
			{
				Text = "可能会有异世界生物出现！",
				Position = 1,
			},
			{
				Text = "到底在哪里呢？",
				Position = 1,
			},
			{
				Text = "啊！！到底是谁在拍我！！！",
				Position = 1,
			},
		},
	},
}
ExileStreetCharacterConfig["Pir_11_HackerSwordsman"] =
{
	PreCondition = {
		UnlockCharacterList = {
			222049,
		},
	},
	DialogList = {
		{
			{
				Text = "噢哆！喔哒！唔恰恰恰恰恰！",
				Position = 1,
			},
			{
				Text = "看我的究极-无敌-狂霸-超限-终末超必杀！",
				Position = 1,
			},
			{
				Text = "咦？",
				Position = 1,
			},
			{
				Text = "被怪摸了一下打断了…",
				Position = 1,
			},
			{
				Text = "又要投币了…",
				Position = 1,
			},
		},
		{
			{
				Text = "听说新的卡带马上要到了。",
				Position = 1,
			},
			{
				Text = "到时候要第一时间打到最高分！",
				Position = 1,
			},
		},
		{
			{
				Text = "最近买币花了好多钱…",
				Position = 1,
			},
			{
				Text = "下次要想办法把投币箱撬开来。",
				Position = 1,
			},
		},
	},
}
ExileStreetCharacterConfig["Pir_12_PaleBlueExorcist"] =
{
	PreCondition = {
		UnlockCharacterList = {
			222050,
		},
	},
	DialogList = {
		{
			{
				Text = "想告诉我什么，小狐狸？",
				Position = 1,
			},
			{
				Text = "新的秘祝，九字真言吗？",
				Position = 1,
			},
			{
				Text = "临兵斗者，皆阵列在前？",
				Position = 1,
			},
			{
				Text = "啊，果然能感受到强大的咒力。",
				Position = 1,
			},
		},
		{
			{
				Text = "祥和的海边小镇…",
				Position = 1,
			},
			{
				Text = "感觉像是故事开始的地方呢。",
				Position = 1,
			},
		},
		{
			{
				Text = "喂，小狐狸，别去招惹居酒屋家的猫咪啦！",
				Position = 1,
			},
			{
				Text = "上次被抓破脸忘了吗！",
				Position = 1,
			},
			{
				Text = "你还想报仇？别想了…",
				Position = 1,
			},
		},
	},
}
ExileStreetCharacterConfig["All_EightImmortal_TieGuaiLi"] =
{
	PreCondition = {
		UnlockCharacterList = {
			223021,
		},
	},
	DialogList = {
		{
			{
				Text = "摸张三万就是清一色了，看我一把自摸！",
				Position = 1,
			},
			{
				Text = "噢哟！摸着感觉不像啊，换一张换一张。",
				Position = 1,
			},
			{
				Text = "还是不对，再换张再换张。",
				Position = 1,
			},
		},
		{
			{
				Text = "明明带了作弊用的麻将牌。",
				Position = 1,
			},
			{
				Text = "但是背面图案竟然不一样…",
				Position = 1,
			},
			{
				Text = "太粗心了。",
				Position = 1,
			},
		},
		{
			{
				Text = "今天这把一定要自摸！",
				Position = 1,
			},
			{
				Text = "不过我胡牌，他们肯定会找借口溜走…",
				Position = 1,
			},
			{
				Text = "对了，胡牌后先来个扫堂腿把他们都放倒！",
				Position = 1,
			},
		},
	},
}
ExileStreetCharacterConfig["All_EightImmortal_HanZhongLi"] =
{
	PreCondition = {
		UnlockCharacterList = {
			223022,
		},
	},
	DialogList = {
		{
			{
				Text = "看这牌路子，上下家都在等我的四张三万啊。",
				Position = 1,
			},
			{
				Text = "嘿嘿，我到最后再暗杠！",
				Position = 1,
			},
		},
		{
			{
				Text = "啷个哩个啷~",
				Position = 1,
			},
			{
				Text = "眼看他起高楼。",
				Position = 1,
			},
			{
				Text = "眼看他宴宾客。",
				Position = 1,
			},
			{
				Text = "眼看他楼塌了。",
				Position = 1,
			},
		},
		{
			{
				Text = "啷个哩个啷~",
				Position = 1,
			},
		},
	},
}
ExileStreetCharacterConfig["All_EightImmortal_ZhangGuoLao"] =
{
	PreCondition = {
		UnlockCharacterList = {
			223023,
		},
	},
	DialogList = {
		{
			{
				Text = "啊哈，早就想试试看骑电驴了！",
				Position = 1,
			},
			{
				Text = "嘿嘿，感觉自己一下子年轻了三百岁啊~",
				Position = 1,
			},
		},
		{
			{
				Text = "啊呀，这个油怎么倒不进去啊…",
				Position = 1,
			},
			{
				Text = "上次的卖油翁明明离口1米远就倒进去了。",
				Position = 1,
			},
			{
				Text = "我一个仙人怎么可能不如一个凡人！",
				Position = 1,
			},
			{
				Text = "还是倒不进去…算了，不弄了。",
				Position = 1,
			},
		},
		{
			{
				Text = "好想去前面那个居酒屋喝酒啊。",
				Position = 1,
			},
			{
				Text = "听说那家烤鸟串也很有特色哪。",
				Position = 1,
			},
			{
				Text = "可惜还要收费…可惜，真可惜…",
				Position = 1,
			},
		},
	},
}
ExileStreetCharacterConfig["All_EightImmortal_LvDongBin"] =
{
	PreCondition = {
		UnlockCharacterList = {
			223024,
		},
	},
	DialogList = {
		{
			{
				Text = "现代的科技果然进步。",
				Position = 1,
			},
			{
				Text = "质量这么好的磁悬浮拂尘包邮价只要50块。",
				Position = 1,
			},
			{
				Text = "看来很快就要进入科技修仙的时代了。",
				Position = 1,
			},
		},
		{
			{
				Text = "最近一直觉得很冷，是不是得狂犬病了？",
				Position = 1,
			},
			{
				Text = "下次要问问二郎神，哮天犬打没打过狂犬疫苗。",
				Position = 1,
			},
		},
		{
			{
				Text = "这个飞行器真不错，怎么跳也没事。",
				Position = 1,
			},
			{
				Text = "下次挂在地锁上面，看能不能拖动空间站。",
				Position = 1,
			},
		},
	},
}
ExileStreetCharacterConfig["All_EightImmortal_HeXianGu"] =
{
	PreCondition = {
		UnlockCharacterList = {
			223025,
		},
	},
	DialogList = {
		{
			{
				Text = "就差边三万胡牌了，怎么到现在还不来？",
				Position = 1,
			},
			{
				Text = "不能太着急，先假装看手机麻痹他们！",
				Position = 1,
			},
		},
		{
			{
				Text = "等他们一胡牌，我就假装接电话溜走！",
				Position = 1,
			},
			{
				Text = "完美的计划！",
				Position = 1,
			},
		},
		{
			{
				Text = "万一我胡牌了，他们肯定会掀桌子！",
				Position = 1,
			},
			{
				Text = "嗯，胡牌前先拍视频，这样他们就赖不掉了！",
				Position = 1,
			},
		},
	},
}
ExileStreetCharacterConfig["All_EightImmortal_LanCaiHe"] =
{
	PreCondition = {
		UnlockCharacterList = {
			223026,
		},
	},
	DialogList = {
		{
			{
				Text = "好无聊啊，点个烟花热闹热闹。",
				Position = 1,
			},
			{
				Text = "诶，怎么点不着啊？",
				Position = 1,
			},
			{
				Text = "这个破花篮，连变个烟花出来都不行！",
				Position = 1,
			},
		},
	},
}
ExileStreetCharacterConfig["All_EightImmortal_HanXiangZi"] =
{
	PreCondition = {
		UnlockCharacterList = {
			223027,
		},
	},
	DialogList = {
		{
			{
				Text = "习习谷风，以阴以雨。",
				Position = 1,
			},
			{
				Text = "黾勉同心，不宜有怒。",
				Position = 1,
			},
		},
	},
}
ExileStreetCharacterConfig["All_EightImmortal_CaoGuoJiu"] =
{
	PreCondition = {
		UnlockCharacterList = {
			223028,
		},
	},
	DialogList = {
		{
			{
				Text = "这次炒股亏太多了，赶紧卖点字画填补填补。",
				Position = 1,
			},
		},
	},
}
ExileStreetCharacterConfig["All_Chess_WhiteKing"] =
{
	PreCondition = {
		UnlockCharacterList = {
			223041,
		},
	},
	DialogList = {
		{
			{
				Text = "没人可以在我的棋盘上战胜我！",
				Position = 1,
			},
		},
		{
			{
				Text = "最好的策略就是进攻，再进攻！",
				Position = 1,
			},
			{
				Text = "如果进攻失利，就攻击棋手！",
				Position = 1,
			},
			{
				Text = "如果打不过，就掀桌子再逃！",
				Position = 1,
			},
			{
				Text = "总之，我们不接受失败！",
				Position = 1,
			},
		},
		{
			{
				Text = "棋品就是人品，棋品好人品才能好。",
				Position = 1,
			},
		},
	},
}
ExileStreetCharacterConfig["All_Chess_WhiteQueen"] =
{
	PreCondition = {
		UnlockCharacterList = {
			223042,
		},
	},
	DialogList = {
		{
			{
				Text = "啊哈，我一下子将死你！",
				Position = 1,
			},
		},
		{
			{
				Text = "哎，皇后的生活真是苦闷。",
				Position = 1,
			},
			{
				Text = "何时才能摆脱这无聊的一切？",
				Position = 1,
			},
		},
		{
			{
				Text = "玫瑰绚丽，不过也终将凋零。",
				Position = 1,
			},
			{
				Text = "我又何尝能逃过这般命运？",
				Position = 1,
			},
		},
	},
}
ExileStreetCharacterConfig["All_Chess_WhiteBishop"] =
{
	PreCondition = {
		UnlockCharacterList = {
			223043,
		},
	},
	DialogList = {
		{
			{
				Text = "棋盘上的战局，终究还是孩子们的玩意。",
				Position = 1,
			},
			{
				Text = "我的目标是征服一切！",
				Position = 1,
			},
		},
		{
			{
				Text = "洁白的颜色象征着高贵。",
				Position = 1,
			},
			{
				Text = "我是最高贵的主教。",
				Position = 1,
			},
		},
		{
			{
				Text = "终有一天，我也将戴上那顶宝冠！",
				Position = 1,
			},
			{
				Text = "成为权力的巅峰！",
				Position = 1,
			},
			{
				Text = "带领信徒征服一切！",
				Position = 1,
			},
		},
	},
}
ExileStreetCharacterConfig["All_Chess_WhiteRook"] =
{
	PreCondition = {
		UnlockCharacterList = {
			223044,
		},
	},
	DialogList = {
		{
			{
				Text = "哎，好久都没有比赛了。",
				Position = 1,
			},
		},
		{
			{
				Text = "今年的象棋大赛一定要赢！",
				Position = 1,
			},
			{
				Text = "先把旗子插在这里！",
				Position = 1,
			},
		},
		{
			{
				Text = "这次在旗子上写什么好呢？",
				Position = 1,
			},
			{
				Text = "对，就是这个！",
				Position = 1,
			},
			{
				Text = "我们的城堡无坚可摧！",
				Position = 1,
			},
		},
	},
}
ExileStreetCharacterConfig["All_Chess_WhiteKnight"] =
{
	PreCondition = {
		UnlockCharacterList = {
			223045,
		},
	},
	DialogList = {
		{
			{
				Text = "啊，今晚吃什么呢？",
				Position = 1,
			},
			{
				Text = "咦？后槽牙里还有片菜叶！",
				Position = 1,
			},
			{
				Text = "就当点心吧。",
				Position = 1,
			},
		},
		{
			{
				Text = "偶尔有点怀念大赛的日子了。",
				Position = 1,
			},
			{
				Text = "上次输给对面那匹马…",
				Position = 1,
			},
			{
				Text = "还是有点生气…",
				Position = 1,
			},
		},
		{
			{
				Text = "哞？趾甲长了？",
				Position = 1,
			},
			{
				Text = "工资发了去打个新铁掌吧，哎。",
				Position = 1,
			},
		},
		{
			{
				Text = "人生苦短，何必留长。",
				Position = 1,
			},
			{
				Text = "我们不过是有一天终将被忘记的尘埃。",
				Position = 1,
			},
			{
				Text = "所以,我们过去做了什么并不重要。",
				Position = 1,
			},
			{
				Text = "我们将被如何记住也不…",
				Position = 1,
			},
		},
	},
}
ExileStreetCharacterConfig["All_Chess_WhitePawn"] =
{
	PreCondition = {
		UnlockCharacterList = {
			223046,
		},
	},
	DialogList = {
		{
			{
				Text = "陛下请放心，主教大人挂了我能顶上的！",
				Position = 1,
			},
			{
				Text = "城堡大人挂了我也能顶上！",
				Position = 1,
			},
			{
				Text = "骑士大人挂了我也能顶上的！",
				Position = 1,
			},
			{
				Text = "悄悄说一句，其实皇后大人挂了我也能顶上的…",
				Position = 1,
			},
		},
	},
}
ExileStreetCharacterConfig["SPBUS_03_yuren"] =
{
	PreCondition = {
		UnlockCharacterList = {
			223082,
		},
	},
	DialogList = {
		{
			{
				Text = "鱼罐头！好吃的鱼罐头！",
				Position = 1,
			},
			{
				Text = "一罐提神醒脑，两罐永不疲劳，三罐长生不老！",
				Position = 1,
			},
		},
		{
			{
				Text = "这位先生，要看下能提升智力的深海鱼罐头吗？",
				Position = 1,
			},
			{
				Text = "每天一罐，就能和本鱼一样~",
				Position = 1,
			},
			{
				Text = "拥有超过同类几倍的IQ！",
				Position = 1,
			},
			{
				Text = "在下同类的IQ是多少？上次听说是负数来着！",
				Position = 1,
			},
		},
		{
			{
				Text = "在下出售的是超级下饭鱼罐头！",
				Position = 1,
			},
			{
				Text = "只要一勺，立刻就会获得和在下一样的记忆力。",
				Position = 1,
			},
			{
				Text = "无论吃了多少碗饭，都会立刻忘记！",
				Position = 1,
			},
			{
				Text = "一下子就能吃掉好几斤米饭！",
				Position = 1,
			},
		},
	},
}
ExileStreetCharacterConfig["SPBUS_04_saodiji"] =
{
	PreCondition = {
		UnlockCharacterList = {
			223121,
		},
	},
	DialogList = {
		{
			{
				Text = "加油，扫地鸡！",
				Position = 1,
			},
			{
				Text = "今天也要好好工作鸭！",
				Position = 1,
			},
		},
		{
			{
				Text = "我是一只扫地鸡，打扫本领强~",
				Position = 1,
			},
			{
				Text = "我要把那流亡街，扫得很漂亮~",
				Position = 1,
			},
			{
				Text = "刷了街道又扫墙，扫帚飞舞忙。",
				Position = 1,
			},
			{
				Text = "……哎呀，忘词了。",
				Position = 1,
			},
		},
		{
			{
				Text = "糟糕，出门太急，忘记穿鞋了。",
				Position = 1,
			},
			{
				Text = "这样脚会变脏的……",
				Position = 1,
			},
		},
		{
			{
				Text = "这里的地好脏鸭。",
				Position = 1,
			},
			{
				Text = "之前都没有人来这里打扫吗？",
				Position = 1,
			},
			{
				Text = "好奇怪鸭。",
				Position = 1,
			},
		},
	},
}
ExileStreetCharacterConfig["SPBUS_05_baiqiangwei"] =
{
	PreCondition = {
		UnlockCharacterList = {
			223122,
		},
	},
	DialogList = {
		{
			{
				Text = "那个，请问……",
				Position = 1,
			},
			{
				Text = "你有看到一位，头戴心形帽子的园丁吗？",
				Position = 1,
			},
		},
		{
			{
				Text = "啊，就是你在戳我吗？",
				Position = 1,
			},
			{
				Text = "是找到那位园丁的下落了吗？",
				Position = 1,
			},
		},
		{
			{
				Text = "他曾夸赞我……",
				Position = 1,
			},
			{
				Text = "是花园里最洁白，最美丽的蔷薇。",
				Position = 1,
			},
			{
				Text = "不知道变成人形后……",
				Position = 1,
			},
			{
				Text = "他还能不能认出我。",
				Position = 1,
			},
		},
		{
			{
				Text = "如果以后可以……",
				Position = 1,
			},
			{
				Text = "我也想用我手中的这把伞。",
				Position = 1,
			},
			{
				Text = "为他遮风挡雨。",
				Position = 1,
			},
		},
	},
}
ExileStreetCharacterConfig["SPBUS_06_xiaohongmao"] =
{
	PreCondition = {
		UnlockCharacterList = {
			223123,
		},
	},
	DialogList = {
		{
			{
				Text = "已经过去好几个月了。",
				Position = 1,
			},
			{
				Text = "这里的警察，还没有找到猎狼的凶手吗？",
				Position = 1,
			},
			{
				Text = "是不是太慢了呢？",
				Position = 1,
			},
		},
		{
			{
				Text = "哎？你戳我干什么？",
				Position = 1,
			},
			{
				Text = "就算戳我，我也不会告诉你真相的哦。",
				Position = 1,
			},
		},
		{
			{
				Text = "你也来猜猜吧？",
				Position = 1,
			},
			{
				Text = "那个叫做电锯的凶器……",
				Position = 1,
			},
			{
				Text = "被藏在哪里了呢？",
				Position = 1,
			},
		},
		{
			{
				Text = "平民证……",
				Position = 1,
			},
			{
				Text = "这就把我的嫌疑排除了吗？",
				Position = 1,
			},
			{
				Text = "也对，我这样的女孩子……",
				Position = 1,
			},
			{
				Text = "和血腥的案件，根本不可能相关啦。",
				Position = 1,
			},
		},
	},
}
ExileStreetCharacterConfig["SPBUS_13_QianNiu_1"] =
{
	PreCondition = {
		UnlockCharacterList = {
			223130,
		},
		LockCharacterList = {
			223137,
		},
	},
	DialogList = {
		{
			{
				Text = "这里是算命的摊位吗...",
				Position = 1,
			},
			{
				Text = "想算一算健康，求个平安符。",
				Position = 1,
			},
			{
				Text = "不，还是算一算财运。",
				Position = 1,
			},
			{
				Text = "姻缘…？",
				Position = 1,
			},
			{
				Text = "不，还是算算事业和学业吧。",
				Position = 1,
			},
		},
		{
			{
				Text = "听说在事务所打工，时薪很可观。",
				Position = 1,
			},
			{
				Text = "冒险星道具店似乎也不错。",
				Position = 1,
			},
			{
				Text = "还有美食星的超市...",
				Position = 1,
			},
			{
				Text = "要不要辞职，去其他星球打工呢？",
				Position = 1,
			},
		},
		{
			{
				Text = "戴着牛头面具的大佬，今天又来找我了。",
				Position = 1,
			},
			{
				Text = "这个大佬，到底是何方神圣呢？",
				Position = 1,
			},
			{
				Text = "是我人生中的贵人吗？",
				Position = 1,
			},
		},
		{
			{
				Text = "店长今天有事...唉。",
				Position = 1,
			},
			{
				Text = "等会儿又要回到服装店打工了。",
				Position = 1,
			},
			{
				Text = "真想继续逛庙会呀。",
				Position = 1,
			},
		},
	},
}
ExileStreetCharacterConfig["SPBUS_13_QianNiu_2"] =
{
	PreCondition = {
		UnlockCharacterList = {
			223130,
			223137,
		},
	},
	DialogList = {
		{
			{
				Text = "小哥，我们去哪里玩呀！",
				Position = 2,
			},
			{
				Text = "我，我都可以...",
				Position = 1,
			},
			{
				Text = "去隔壁的金鱼店？",
				Position = 2,
			},
			{
				Text = "但是会把你好看的衣服打湿..",
				Position = 1,
			},
			{
				Text = "那我们去吃炸鸡排！",
				Position = 2,
			},
			{
				Text = "但是，你的衣服上，可能会被溅上难以清洗的油渍。",
				Position = 1,
			},
			{
				Text = "那我们去哪里玩呀...",
				Position = 2,
			},
			{
				Text = "我都可以。",
				Position = 1,
			},
		},
		{
			{
				Text = "喂喂，那边有打怪挑战诶！",
				Position = 2,
			},
			{
				Text = "难道...你想去吗？",
				Position = 1,
			},
			{
				Text = "是啊！去打怪，难道不是很刺激吗！",
				Position = 2,
			},
			{
				Text = "那个，啊，是的…看来要抓紧时间摇人。",
				Position = 1,
			},
		},
		{
			{
				Text = "牵牛小哥，我想去居酒屋里玩！",
				Position = 2,
			},
			{
				Text = "嘘，我老板说，那个地方很诡异的...",
				Position = 1,
			},
			{
				Text = "诡异？为什么呀？",
				Position = 2,
			},
			{
				Text = "听说里面关着一头年兽，还有长着绿毛鹿角的怪兽，还有盗贼...",
				Position = 1,
			},
			{
				Text = "好刺激！我想去看！",
				Position = 2,
			},
		},
		{
			{
				Text = "肚子饿了...",
				Position = 2,
			},
			{
				Text = "那边有鲷鱼烧、克林姆、雪花冰、糖葫芦...",
				Position = 1,
			},
			{
				Text = "糖葫芦？！！我冲了！！",
				Position = 2,
			},
			{
				Text = "哎，七织，等等我呀！",
				Position = 1,
			},
		},
	},
}
ExileStreetCharacterConfig["SPBUS_20_QiZhi_1"] =
{
	PreCondition = {
		UnlockCharacterList = {
			223137,
		},
		LockCharacterList = {
			223130,
		},
	},
	DialogList = {
		{
			{
				Text = "哇！！这里好热闹！！",
				Position = 1,
			},
			{
				Text = "我想吃那边的章鱼丸子！！",
				Position = 1,
			},
			{
				Text = "还想喝可乐！！",
				Position = 1,
			},
			{
				Text = "还有奶茶、啤酒！！",
				Position = 1,
			},
		},
		{
			{
				Text = "真想再玩一次捞金鱼呀。",
				Position = 1,
			},
			{
				Text = "这里除了捞金鱼，还有其他的活动吗？",
				Position = 1,
			},
			{
				Text = "什么？有打怪？",
				Position = 1,
			},
			{
				Text = "我想去我想去！",
				Position = 1,
			},
		},
		{
			{
				Text = "喂喂，你见过一心她们吗？",
				Position = 1,
			},
			{
				Text = "什么，居酒屋里？",
				Position = 1,
			},
			{
				Text = "就是那边那个小小…居酒屋？",
				Position = 1,
			},
			{
				Text = "看起来很拥挤的样子啊...",
				Position = 1,
			},
			{
				Text = "她们为什么不出来找我玩呢？",
				Position = 1,
			},
		},
		{
			{
				Text = "嘿，听说那边有打怪闯关的活动！",
				Position = 1,
			},
			{
				Text = "难道真的可以，帮警察抓捕犯人吗？",
				Position = 1,
			},
			{
				Text = "好刺激呀~",
				Position = 1,
			},
		},
	},
}
ExileStreetCharacterConfig["SPBUS_21_YueLao"] =
{
	PreCondition = {
		UnlockCharacterList = {
			223138,
		},
	},
	DialogList = {
		{
			{
				Text = "客人来啦？您算什么东西。",
				Position = 1,
			},
			{
				Text = "哈，我没骂你啊。",
				Position = 1,
			},
			{
				Text = "你到底算什么东西？",
				Position = 1,
			},
			{
				Text = "喂，别走啊...",
				Position = 1,
			},
		},
		{
			{
				Text = "算命，算姻缘，不准不要钱...",
				Position = 1,
			},
			{
				Text = "客官，算命吗？",
				Position = 1,
			},
			{
				Text = "哈？不算姻缘，也不算事业，只算财运？",
				Position = 1,
			},
			{
				Text = "喂喂，客官，留步啊，财运也可以算！",
				Position = 1,
			},
		},
		{
			{
				Text = "昨日凑成姻缘...0对。",
				Position = 1,
			},
			{
				Text = "前日，0对。",
				Position = 1,
			},
			{
				Text = "本月，0对。",
				Position = 1,
			},
			{
				Text = "果然，大家都没有那种世俗的欲望了吗？",
				Position = 1,
			},
			{
				Text = "那我的kpi可怎么办啊...",
				Position = 1,
			},
		},
		{
			{
				Text = "什么时候才能把面具摘下来呢？",
				Position = 1,
			},
			{
				Text = "面具太重，压得鼻骨生疼。",
				Position = 1,
			},
			{
				Text = "早知道就不乱画红线了...",
				Position = 1,
			},
			{
				Text = "悔矣。悔矣...",
				Position = 1,
			},
		},
	},
}
ExileStreetCharacterConfig["SPBUS_22_TuanYuan"] =
{
	PreCondition = {
		UnlockCharacterList = {
			223139,
		},
	},
	DialogList = {
		{
			{
				Text = "你好，我这里有一封给你的信~",
				Position = 1,
			},
			{
				Text = "是两只小猫托我送来的哦。",
				Position = 1,
			},
			{
				Text = "他们是你的好朋友吗？",
				Position = 1,
			},
		},
		{
			{
				Text = "我是宇宙邮差团圆圆！",
				Position = 1,
			},
			{
				Text = "这是我的铭牌…哎？",
				Position = 1,
			},
			{
				Text = "我的铭牌呢？！",
				Position = 1,
			},
			{
				Text = "是不是掉地上了…",
				Position = 1,
			},
		},
		{
			{
				Text = "告诉你一个秘密。",
				Position = 1,
			},
			{
				Text = "很多人都以为我是一只兔子。",
				Position = 1,
			},
			{
				Text = "什么…你也这么觉得吗？",
				Position = 1,
			},
			{
				Text = "我头上的耳朵是帽子的装饰啦。",
				Position = 1,
			},
			{
				Text = "我是如假包换的人类！",
				Position = 1,
			},
		},
		{
			{
				Text = "送完这一封信…",
				Position = 1,
			},
			{
				Text = "就可以去其他星球旅游啦！",
				Position = 1,
			},
			{
				Text = "虽然有些危险，但还是想去悬疑星。",
				Position = 1,
			},
			{
				Text = "想要亲眼见证大侦探的推理！",
				Position = 1,
			},
		},
	},
}
ExileStreetCharacterConfig["SPDraw_06_UnlockChiefSister"] =
{
	PreCondition = {
		UnlockCharacterList = {
			221007,
		},
	},
	DialogList = {
		{
			{
				Text = "那个…我和哥哥谁更非呢？",
				Position = 1,
			},
			{
				Text = "哎，你不知道吗？",
				Position = 1,
			},
		},
		{
			{
				Text = "这次一定要出彩卡。",
				Position = 1,
			},
			{
				Text = "彩的不行…金的也可以。",
				Position = 1,
			},
		},
		{
			{
				Text = "悄悄告诉你哦，我掌握了新的抽卡技巧。",
				Position = 1,
			},
			{
				Text = "这次一定能出货。",
				Position = 1,
			},
			{
				Text = "玄能改命，拜托了。",
				Position = 1,
			},
		},
		{
			{
				Text = "再抽十连！",
				Position = 1,
			},
			{
				Text = "再来十连！",
				Position = 1,
			},
			{
				Text = "再来！..",
				Position = 1,
			},
			{
				Text = "再…哎？我的钱呢？",
				Position = 1,
			},
		},
	},
}
ExileStreetCharacterConfig["SPBUS_23_LangRen"] =
{
	PreCondition = {
		UnlockCharacterList = {
			223140,
		},
	},
	DialogList = {
		{
			{
				Text = "我想，也许应该改一个名称。",
				Position = 1,
			},
			{
				Text = "AKA狼人……不好，太容易暴露我的真实身份了。",
				Position = 1,
			},
		},
		{
			{
				Text = "小红帽她……在试探我吗？",
				Position = 1,
			},
			{
				Text = "如果她发现我的真实身份……",
				Position = 1,
			},
			{
				Text = "或许，她就不会再与我做朋友了。",
				Position = 1,
			},
		},
		{
			{
				Text = "最近因为连续几天的演出，总是忘记时间。",
				Position = 1,
			},
			{
				Text = "月圆之夜那天，你可以提醒我吗？",
				Position = 1,
			},
			{
				Text = "到时候，我会乖乖把我自己…锁在房间里。",
				Position = 1,
			},
		},
		{
			{
				Text = "我第一次变狼的那晚，踩碎了一朵花。",
				Position = 1,
			},
			{
				Text = "紫色的乌头草，盛开在月光映照着的大地上。",
				Position = 1,
			},
			{
				Text = "那时候我就下定决心，虽然变狼是不可改变的事实。",
				Position = 1,
			},
			{
				Text = "但我要用尽全力，阻止失去理智的自己。",
				Position = 1,
			},
		},
	},
}
ExileStreetCharacterConfig["All_NewYearBeast"] =
{
	PreCondition = {
		UnlockCharacterList = {
			223067,
		},
	},
	DialogList = {
		{
			{
				Text = "哈欠！什么时候可以回去嗷！",
				Position = 1,
			},
			{
				Text = "算了，留在这里也挺清闲的。",
				Position = 1,
			},
			{
				Text = "呼呼，房间暖呼呼的~",
				Position = 1,
			},
		},
		{
			{
				Text = "等等你们不要看春晚噢！",
				Position = 1,
			},
			{
				Text = "这种节目我从来不看的！",
				Position = 1,
			},
			{
				Text = "噢，有小品嗷？那稍微看一下。",
				Position = 1,
			},
		},
		{
			{
				Text = "不想吃年夜饭！想吃小朋友！",
				Position = 1,
			},
			{
				Text = "嘿嘿嘿！怕了吧？",
				Position = 1,
			},
			{
				Text = "怕的话就把糖葫芦都交出来！",
				Position = 1,
			},
		},
		{
			{
				Text = "明年一定要好好闹个年！",
				Position = 1,
			},
			{
				Text = "嗯，现在开始就要计划起来了！",
				Position = 1,
			},
		},
	},
}
ExileStreetCharacterConfig["All_LuckyFish"] =
{
	PreCondition = {
		UnlockCharacterList = {
			223066,
		},
	},
	DialogList = {
		{
			{
				Text = "其实偶尔想说…",
				Position = 1,
			},
			{
				Text = "转发锦鲤可能是迷信行为呢~",
				Position = 1,
			},
			{
				Text = "不过如果只是图个好意头，就无所谓啦。",
				Position = 1,
			},
			{
				Text = "你转发了吗？",
				Position = 1,
			},
		},
		{
			{
				Text = "哇，今天的蚯蚓好新鲜。",
				Position = 1,
			},
			{
				Text = "等等偷偷放两条涮一下~",
				Position = 1,
			},
			{
				Text = "咦，怎么还在动的样子？",
				Position = 1,
			},
		},
		{
			{
				Text = "啊，不要先烫蔬菜啊！",
				Position = 1,
			},
			{
				Text = "先烫肉再烫菜，味道才好的！",
				Position = 1,
			},
		},
		{
			{
				Text = "还是第一次吃糖葫芦呢~~",
				Position = 1,
			},
			{
				Text = "甜甜的，嗯！好吃！",
				Position = 1,
			},
		},
	},
}
ExileStreetCharacterConfig["All_Longevity"] =
{
	PreCondition = {
		UnlockCharacterList = {
			223061,
		},
	},
	DialogList = {
		{
			{
				Text = "小喵喵好可爱~",
				Position = 1,
			},
			{
				Text = "嚯嚯，起飞咯！",
				Position = 1,
			},
			{
				Text = "又降落咯~",
				Position = 1,
			},
			{
				Text = "咦，小喵喵是不是不太舒服的样子？",
				Position = 1,
			},
		},
		{
			{
				Text = "为什么老是有人把我和长命百岁搞混？",
				Position = 1,
			},
			{
				Text = "明明寿比南山比长命百岁活得更长啊。",
				Position = 1,
			},
			{
				Text = "哎，我太南了。",
				Position = 1,
			},
			{
				Text = "咦，又发现一个谐音梗~",
				Position = 1,
			},
		},
		{
			{
				Text = "虽然我年纪大，但是我很懂时髦的~",
				Position = 1,
			},
			{
				Text = "保持一颗年轻的心，才是真的年轻嘛~",
				Position = 1,
			},
		},
	},
}
ExileStreetCharacterConfig["All_GetRich"] =
{
	PreCondition = {
		UnlockCharacterList = {
			223062,
		},
	},
	DialogList = {
		{
			{
				Text = "烫元宝，烫点元宝嘛~",
				Position = 1,
			},
			{
				Text = "嗯？你们不吃烫元宝的吗？",
				Position = 1,
			},
			{
				Text = "那…烫红包，烫红包！",
				Position = 1,
			},
			{
				Text = "红包也不吃？哼！那还吃什么火锅嘛！",
				Position = 1,
			},
		},
		{
			{
				Text = "哎，只能吃自己带的铜板了。",
				Position = 1,
			},
			{
				Text = "咳，咳，咳。",
				Position = 1,
			},
			{
				Text = "呛到了嗷！",
				Position = 1,
			},
			{
				Text = "赶紧喝口茶~",
				Position = 1,
			},
		},
		{
			{
				Text = "咦，好像听到有人祈福？",
				Position = 1,
			},
			{
				Text = "嗯，嗯，是想来年发财呢~",
				Position = 1,
			},
			{
				Text = "不过好像应该求财神嗷，我只会吞金嘛~",
				Position = 1,
			},
		},
		{
			{
				Text = "多放点辣，多放点辣！",
				Position = 1,
			},
			{
				Text = "担心拉肚子吗？",
				Position = 1,
			},
			{
				Text = "貔貅从来不上厕所的嗷~",
				Position = 1,
			},
		},
	},
}
ExileStreetCharacterConfig["All_Healthy"] =
{
	PreCondition = {
		UnlockCharacterList = {
			223063,
		},
	},
	DialogList = {
		{
			{
				Text = "心态好，身体就健康了。",
				Position = 1,
			},
			{
				Text = "心态不好，就调整好。",
				Position = 1,
			},
			{
				Text = "调整不好，就想办法调整好。",
				Position = 1,
			},
			{
				Text = "想不到办法，就休息一会儿。",
				Position = 1,
			},
		},
		{
			{
				Text = "哎，天气冷，外面的河里都钓不到鱼了。",
				Position = 1,
			},
			{
				Text = "嗯，嗯，放宽心态，等明年开春就好了。",
				Position = 1,
			},
		},
		{
			{
				Text = "呼，换季了，要不要迁徙呢？",
				Position = 1,
			},
		},
		{
			{
				Text = "小鱼，小鱼，你怎么不去找你的家人呀？",
				Position = 1,
			},
			{
				Text = "噢，因为咬着鱼钩，逃不回去？",
				Position = 1,
			},
			{
				Text = "下次不会再吃天上掉下来的食物了吧？",
				Position = 1,
			},
		},
		{
			{
				Text = "大家都集了几个福了呀~",
				Position = 1,
			},
		},
	},
}
ExileStreetCharacterConfig["All_Morality"] =
{
	PreCondition = {
		UnlockCharacterList = {
			223064,
		},
	},
	DialogList = {
		{
			{
				Text = "吃点藕片",
				Position = 1,
			},
			{
				Text = "吃什么补什么~",
				Position = 1,
			},
		},
		{
			{
				Text = "我给大家背一段《爱莲说》吧~",
				Position = 1,
			},
			{
				Text = "啊，真的没有夸耀自己的意思~",
				Position = 1,
			},
			{
				Text = "凡尔赛？那是什么？",
				Position = 1,
			},
		},
		{
			{
				Text = "这片三文鱼没人吃，我就吃啦。",
				Position = 1,
			},
			{
				Text = "偶尔吃点生食也不错嘛~",
				Position = 1,
			},
			{
				Text = "不过平时我都只吃蔬菜的~",
				Position = 1,
			},
		},
	},
}
ExileStreetCharacterConfig["All_BeginEnd"] =
{
	PreCondition = {
		UnlockCharacterList = {
			223065,
		},
	},
	DialogList = {
		{
			{
				Text = "姐姐，帮我涮肉片！",
				Position = 1,
			},
			{
				Text = "好，好，马上给我们小始弄~",
				Position = 2,
			},
			{
				Text = "姐姐，我要吃烫得老一点的！",
				Position = 1,
			},
			{
				Text = "-_-！",
				Position = 2,
			},
		},
		{
			{
				Text = "姐姐，帮我调酱料！",
				Position = 1,
			},
			{
				Text = "我们小始想要什么味道的?",
				Position = 2,
			},
			{
				Text = "想用皮蛋酱混麻油吃~",
				Position = 1,
			},
			{
				Text = "小始会吃坏肚子的！",
				Position = 2,
			},
		},
		{
			{
				Text = "来，小始也吃点蔬菜。",
				Position = 2,
			},
			{
				Text = "不！我要吃肉，还要吃糖葫芦！",
				Position = 1,
			},
			{
				Text = "小始乖，吃完蔬菜，姐姐给小始买糖葫芦！",
				Position = 2,
			},
			{
				Text = "O(∩_∩)O\n姐姐最好了~",
				Position = 1,
			},
		},
	},
}
ExileStreetCharacterConfig["RPG_101_Paladin_1"] =
{
	PreCondition = {
		UnlockCharacterList = {
			223001,
		},
	},
	DialogList = {
		{
			{
				Text = "得再确认一遍当地的行为规范。",
				Position = 1,
			},
		},
		{
			{
				Text = "好复杂的文字——嗯…拿反了……",
				Position = 1,
			},
		},
		{
			{
				Text = "……原来如此，学到很多，必可活用于下一次。",
				Position = 1,
			},
		},
		{
			{
				Text = "圣光会指引我！",
				Position = 1,
			},
			{
				Text = "……那我为什么要看地图呢？",
				Position = 1,
			},
		},
		{
			{
				Text = "原来还有这么多地方都被魔王掌控在手里！",
				Position = 1,
			},
			{
				Text = "可恶，我要去用圣光之力净化他们！",
				Position = 1,
			},
		},
	},
}
ExileStreetCharacterConfig["RPG_102_Barbarian_1"] =
{
	PreCondition = {
		UnlockCharacterList = {
			223002,
		},
	},
	DialogList = {
		{
			{
				Text = "咦，昨晚吃了金针菇啊？",
				Position = 1,
			},
		},
		{
			{
				Text = "身体挺健康的。",
				Position = 1,
			},
		},
		{
			{
				Text = "这个形状！这个质地！这个味道！",
				Position = 1,
			},
			{
				Text = "错不了，这一定是屎！！！",
				Position = 1,
			},
		},
		{
			{
				Text = "这……真是好胃口！",
				Position = 1,
			},
		},
		{
			{
				Text = "看的俺都饿了……",
				Position = 1,
			},
		},
	},
}
ExileStreetCharacterConfig["RPG_103_Thief_1"] =
{
	PreCondition = {
		UnlockCharacterList = {
			223003,
		},
	},
	DialogList = {
		{
			{
				Text = "这里的气氛很活跃呢~",
				Position = 1,
			},
		},
		{
			{
				Text = "啊，没电了……去偷块电池~",
				Position = 1,
			},
		},
		{
			{
				Text = "这里应该没有警察吧……？",
				Position = 1,
			},
		},
		{
			{
				Text = "别戳了，好烦啊……",
				Position = 1,
			},
			{
				Text = "……等等，你怎么看到我的！？",
				Position = 1,
			},
			{
				Text = "坏了！忘开潜行了！",
				Position = 1,
			},
		},
		{
			{
				Text = "啊，其实这个相机也是我偷来的~",
				Position = 1,
			},
		},
	},
}
ExileStreetCharacterConfig["RPG_104_DancingGirl_1"] =
{
	PreCondition = {
		UnlockCharacterList = {
			223004,
		},
	},
	DialogList = {
		{
			{
				Text = "嘻嘻~我给大家跳个舞吧~~",
				Position = 1,
			},
			{
				Text = "啊……不小心上了个BUFF。",
				Position = 1,
			},
		},
		{
			{
				Text = "旋转，跳跃，我闭着眼~~",
				Position = 1,
			},
			{
				Text = "尘嚣看不见，你沉醉了没？",
				Position = 1,
			},
		},
		{
			{
				Text = "BMI……还要再降一点……",
				Position = 1,
			},
		},
		{
			{
				Text = "管住嘴！迈开腿！",
				Position = 1,
			},
		},
		{
			{
				Text = "101……102……",
				Position = 1,
			},
			{
				Text = "103……104……",
				Position = 1,
			},
			{
				Text = "105……106……",
				Position = 1,
			},
			{
				Text = "……1000个！太棒了，跳了1000个！",
				Position = 1,
			},
		},
	},
}
ExileStreetCharacterConfig["RPG_106_Pharmacist_1"] =
{
	PreCondition = {
		UnlockCharacterList = {
			223006,
		},
	},
	DialogList = {
		{
			{
				Text = "这里有很多新的药草呢！",
				Position = 1,
			},
		},
		{
			{
				Text = "这是药草……这是毒草……",
				Position = 1,
			},
			{
				Text = "啊……哪个是来着？",
				Position = 1,
			},
		},
		{
			{
				Text = "什么！？这个居然是毒草——",
				Position = 1,
			},
			{
				Text = "呜啊——肚子好疼——！",
				Position = 1,
			},
			{
				Text = "要死了——这是断肠——！",
				Position = 1,
			},
			{
				Text = "……",
				Position = 1,
			},
			{
				Text = "……我去趟卫生间。",
				Position = 1,
			},
		},
		{
			{
				Text = "这是……没见过的药草呢。",
				Position = 1,
			},
		},
		{
			{
				Text = "这本书可是我爷爷的爷爷传下来的！",
				Position = 1,
			},
		},
	},
}
ExileStreetCharacterConfig["RPG_108_Warlock"] =
{
	PreCondition = {
		UnlockCharacterList = {
			223007,
		},
	},
	DialogList = {
		{
			{
				Text = "哇，好多新的朋友~",
				Position = 1,
			},
			{
				Text = "嘿嘿嘿嘿，这下总算不用一个人啦~",
				Position = 1,
			},
		},
		{
			{
				Text = "摇一下铃，就会有恶魔出来吧？",
				Position = 1,
			},
			{
				Text = "啊，不行不行，会吓到别人的。",
				Position = 1,
			},
		},
		{
			{
				Text = "还有好几个问题想问学者大人。",
				Position = 1,
			},
			{
				Text = "可是他不愿意搭理我吧？",
				Position = 1,
			},
		},
	},
}
ExileStreetCharacterConfig["RPG_107_Druid"] =
{
	PreCondition = {
		UnlockCharacterList = {
			223008,
		},
	},
	DialogList = {
		{
			{
				Text = "导演，拍完这辑特写就派盒饭，是吗？",
				Position = 1,
			},
			{
				Text = "小熊，听到吗？等等就有盒饭~",
				Position = 1,
			},
			{
				Text = "我没骗你吧~",
				Position = 1,
			},
		},
		{
			{
				Text = "哎，这里的空气好浑浊。",
				Position = 1,
			},
			{
				Text = "等等要去外面大口吸新鲜空气！",
				Position = 1,
			},
		},
		{
			{
				Text = "鱼和熊掌如何兼得？",
				Position = 1,
			},
			{
				Text = "养一头会抓鱼的熊咯~",
				Position = 1,
			},
		},
	},
}
ExileStreetCharacterConfig["Fat_103_GhostChili"] =
{
	PreCondition = {
		UnlockCharacterList = {
			223101,
		},
	},
	DialogList = {
		{
			{
				Text = "你好，请问你想要微重辣吗？",
				Position = 1,
			},
			{
				Text = "还是中重辣呢？",
				Position = 1,
			},
			{
				Text = "还是重重辣呢？",
				Position = 1,
			},
		},
		{
			{
				Text = "这个辣度非常平淡啊。",
				Position = 1,
			},
			{
				Text = "再加一串干辣椒吧？",
				Position = 1,
			},
		},
		{
			{
				Text = "（通话中）喂，是那个医院吗？",
				Position = 1,
			},
			{
				Text = "今天那个科室的人，都是我介绍来的~",
				Position = 1,
			},
			{
				Text = "一定要给他们VIP待遇哦~",
				Position = 1,
			},
		},
		{
			{
				Text = "如果真的不能进军美食界。",
				Position = 1,
			},
			{
				Text = "去美妆界也是不错的选择~",
				Position = 1,
			},
			{
				Text = "让你拥有最自然的火热红唇~",
				Position = 1,
			},
		},
	},
}
ExileStreetCharacterConfig["Fat_104_IsatisNoodle"] =
{
	PreCondition = {
		UnlockCharacterList = {
			223102,
		},
	},
	DialogList = {
		{
			{
				Text = "怎么办，蛋黄要滑下来了……",
				Position = 1,
			},
		},
		{
			{
				Text = "我可是泡面界，养生大赛第一名。",
				Position = 1,
			},
		},
		{
			{
				Text = "虽然这碗面，看上去黑漆漆的。",
				Position = 1,
			},
			{
				Text = "闻着有点薄荷的味道。",
				Position = 1,
			},
			{
				Text = "吃起来还有中药味和甜味……",
				Position = 1,
			},
			{
				Text = "但我还是推荐你尝一尝。",
				Position = 1,
			},
		},
		{
			{
				Text = "“泡面大家庭”里又有消息了。",
				Position = 1,
			},
			{
				Text = "《9条养生口诀，远离癌症》",
				Position = 1,
			},
			{
				Text = "收藏一下，等会儿深度阅读。",
				Position = 1,
			},
		},
	},
}
ExileStreetCharacterConfig["Fat_106_PreservedEggPizza"] =
{
	PreCondition = {
		UnlockCharacterList = {
			223103,
		},
	},
	DialogList = {
		{
			{
				Text = "皮蛋披萨的销量又创新低。",
				Position = 1,
			},
			{
				Text = "看来，还是需要蹭蹭大会热度。",
				Position = 1,
			},
			{
				Text = "再好好宣传一下。",
				Position = 1,
			},
		},
		{
			{
				Text = "这个皮蛋没有花纹……",
				Position = 1,
			},
			{
				Text = "等会儿我用小刀去雕刻一下。",
				Position = 1,
			},
			{
				Text = "还要加上特制调味品……",
				Position = 1,
			},
		},
		{
			{
				Text = "要不要和别人交换一下食物呢？",
				Position = 1,
			},
			{
				Text = "让他们吃我的披萨，我吃他们的……",
				Position = 1,
			},
			{
				Text = "不行，我吃不下。",
				Position = 1,
			},
		},
		{
			{
				Text = "别戳​我了……",
				Position = 1,
			},
			{
				Text = "再戳下去，头上的西兰花就要掉了。",
				Position = 1,
			},
		},
	},
}
ExileStreetCharacterConfig["Fat_105_HerringRiceBall"] =
{
	PreCondition = {
		UnlockCharacterList = {
			223104,
		},
	},
	DialogList = {
		{
			{
				Text = "刚做好的鲱鱼罐头，看一看——",
				Position = 1,
			},
			{
				Text = "一个9.9金，两个20金~",
				Position = 1,
			},
			{
				Text = "买不了吃亏，买不了上当~",
				Position = 1,
			},
		},
		{
			{
				Text = "卖完饭团就回去打游戏。",
				Position = 1,
			},
			{
				Text = "来看看饭团~很好吃的~",
				Position = 1,
			},
			{
				Text = "我吃给你们看……yue！",
				Position = 1,
			},
		},
		{
			{
				Text = "什么？问我为什么做饭团时会带上鼻夹子？",
				Position = 1,
			},
			{
				Text = "当然是为了防鼻炎啦，哈哈哈……",
				Position = 1,
			},
		},
		{
			{
				Text = "为了降低客人的投诉率。",
				Position = 1,
			},
			{
				Text = "必须每小时喷两次除臭剂，yue……",
				Position = 1,
			},
		},
	},
}
ExileStreetCharacterConfig["Fat_107_Kiviac"] =
{
	PreCondition = {
		UnlockCharacterList = {
			223105,
		},
	},
	DialogList = {
		{
			{
				Text = "小海燕，小海燕~",
				Position = 1,
			},
			{
				Text = "快到我这里来~",
				Position = 1,
			},
			{
				Text = "我的身体里很温暖~",
				Position = 1,
			},
		},
		{
			{
				Text = "出去玩一会儿吧~",
				Position = 1,
			},
			{
				Text = "要记得按时回来哦。",
				Position = 1,
			},
			{
				Text = "海豹定位器都打开了吗？",
				Position = 1,
			},
		},
		{
			{
				Text = "I'm coming……",
				Position = 1,
			},
			{
				Text = "歪比巴卜——",
				Position = 1,
			},
		},
		{
			{
				Text = "客官，想吸一口，已经发酵的海燕吗？",
				Position = 1,
			},
			{
				Text = "……好吧，你似乎不太愿意。",
				Position = 1,
			},
		},
	},
}
ExileStreetCharacterConfig["Fat_108_SteamedBun"] =
{
	PreCondition = {
		UnlockCharacterList = {
			223106,
		},
	},
	DialogList = {
		{
			{
				Text = "脑子凉凉的……",
				Position = 1,
			},
			{
				Text = "啊，原来是我露馅儿了。",
				Position = 1,
			},
		},
		{
			{
				Text = "不要错过，新鲜的猪猪包~",
				Position = 1,
			},
			{
				Text = "三层笼屉，层层惊喜~",
				Position = 1,
			},
			{
				Text = "童叟无欺，非常便宜~",
				Position = 1,
			},
		},
		{
			{
				Text = "本店主正式辟谣~",
				Position = 1,
			},
			{
				Text = "本店猪脑包不含胆固醇。",
				Position = 1,
			},
			{
				Text = "非常健康，老少皆宜~",
				Position = 1,
			},
		},
		{
			{
				Text = "又捏好了一个。",
				Position = 1,
			},
			{
				Text = "这可是我抓破脑袋……",
				Position = 1,
			},
			{
				Text = "才创造出来的美食。",
				Position = 1,
			},
		},
	},
}
ExileStreetCharacterConfig["Fat_102_KopiLuwak"] =
{
	PreCondition = {
		UnlockCharacterList = {
			223107,
		},
	},
	DialogList = {
		{
			{
				Text = "特制咖啡豆，要来尝一尝吗？",
				Position = 1,
			},
			{
				Text = "有特殊功效哦。",
				Position = 1,
			},
		},
		{
			{
				Text = "快把我的材料生产出来吧。",
				Position = 1,
			},
			{
				Text = "我要新鲜又热乎的~",
				Position = 1,
			},
		},
		{
			{
				Text = "地上什么也没有。",
				Position = 1,
			},
			{
				Text = "白带两个铲子来了。",
				Position = 1,
			},
		},
		{
			{
				Text = "喵~喵~",
				Position = 1,
			},
			{
				Text = "这里没有小猫吗？",
				Position = 1,
			},
		},
	},
}
ExileStreetCharacterConfig["SPBUS_07_quyuan_1"] =
{
	PreCondition = {
		UnlockCharacterList = {
			223124,
		},
	},
	DialogList = {
		{
			{
				Text = "这些报名龙舟赛的队伍，名字真有趣啊。",
				Position = 1,
			},
			{
				Text = "“这河里吗”队。",
				Position = 1,
			},
			{
				Text = "“感觉不对”队。",
				Position = 1,
			},
			{
				Text = "还有“浪里个浪里个浪里个浪”队……",
				Position = 1,
			},
		},
		{
			{
				Text = "龙舟赛报名，10元一人。",
				Position = 1,
			},
			{
				Text = "输了锻炼身体，赢了还有奖品。",
				Position = 1,
			},
			{
				Text = "大家瞧一瞧看一看，童叟无欺。",
				Position = 1,
			},
		},
		{
			{
				Text = "干完报名的活，就可以回家，准备旅游了。",
				Position = 1,
			},
			{
				Text = "我的朋友们还在等着我呢。",
				Position = 1,
			},
		},
		{
			{
				Text = "10元一人，什么时候才能赚到足够的钱呢？",
				Position = 1,
			},
			{
				Text = "要不要提升一下价格……",
				Position = 1,
			},
			{
				Text = "改成70一人，应该没人能发现吧？",
				Position = 1,
			},
		},
	},
}
ExileStreetCharacterConfig["SPBUS_08_longtoulaoda_1"] =
{
	PreCondition = {
		UnlockCharacterList = {
			223125,
		},
	},
	DialogList = {
		{
			{
				Text = "这个头套真紧啊。",
				Position = 1,
			},
			{
				Text = "好想把它松一松……",
				Position = 1,
			},
			{
				Text = "不行，作为龙头，一定不能松懈啊！",
				Position = 1,
			},
		},
		{
			{
				Text = "这个头套的眼睛画得真好。",
				Position = 1,
			},
			{
				Text = "可能这就叫做画龙点睛吧。",
				Position = 1,
			},
			{
				Text = "感觉一下子，队伍就有气势了。",
				Position = 1,
			},
		},
		{
			{
				Text = "还有人上舟吗？",
				Position = 1,
			},
			{
				Text = "还有没有上舟的？",
				Position = 1,
			},
			{
				Text = "赶紧报名，过时不候了。",
				Position = 1,
			},
		},
		{
			{
				Text = "哇，这个泡泡好大啊。",
				Position = 1,
			},
			{
				Text = "比龙头上的鼻孔还大。",
				Position = 1,
			},
			{
				Text = "比我头上的龙眼还大。",
				Position = 1,
			},
			{
				Text = "不玩了，我要去划龙舟了。",
				Position = 1,
			},
		},
	},
}
ExileStreetCharacterConfig["SPBUS_12_longweixiaodi_1"] =
{
	PreCondition = {
		UnlockCharacterList = {
			223129,
		},
	},
	DialogList = {
		{
			{
				Text = "来了，来了！",
				Position = 1,
			},
			{
				Text = "别开船，等等我！",
				Position = 1,
			},
			{
				Text = "我已经来了！",
				Position = 1,
			},
		},
		{
			{
				Text = "哇，还好没有迟到。",
				Position = 1,
			},
			{
				Text = "差点就赶不上了……",
				Position = 1,
			},
		},
		{
			{
				Text = "还好没有晚到。",
				Position = 1,
			},
			{
				Text = "不然老大又会生气了。",
				Position = 1,
			},
			{
				Text = "老大不会还没到吧，老大呢？",
				Position = 1,
			},
		},
		{
			{
				Text = "嗯？你戳我干嘛呀？",
				Position = 1,
			},
			{
				Text = "轻一点戳啊，太重了我会掉下去的。",
				Position = 1,
			},
		},
	},
}
ExileStreetCharacterConfig["SPBUS_09_taigudaren_1"] =
{
	PreCondition = {
		UnlockCharacterList = {
			223126,
		},
	},
	DialogList = {
		{
			{
				Text = "该下河的下河，该开船的开船。",
				Position = 1,
			},
			{
				Text = "哎呀，我还没上去呢。",
				Position = 1,
			},
			{
				Text = "差点把自己忘记了。",
				Position = 1,
			},
		},
		{
			{
				Text = "你看我的鼓又大又圆。",
				Position = 1,
			},
			{
				Text = "像不像一个大月饼？",
				Position = 1,
			},
		},
		{
			{
				Text = "刚刚有个家伙问我。",
				Position = 1,
			},
			{
				Text = "敲鼓的时候，是不是只用捶自己的脸就好了。",
				Position = 1,
			},
			{
				Text = "真是没有礼貌啊。",
				Position = 1,
			},
		},
		{
			{
				Text = "为了避免敲鼓的时候脸疼。",
				Position = 1,
			},
			{
				Text = "我涂上了特制的面霜。",
				Position = 1,
			},
			{
				Text = "还有特制的透明头套保护。",
				Position = 1,
			},
			{
				Text = "不过，只有聪明的人才能看见。",
				Position = 1,
			},
		},
	},
}
ExileStreetCharacterConfig["SPBUS_10_jiangshou01_1"] =
{
	PreCondition = {
		UnlockCharacterList = {
			223127,
		},
		LockCharacterList = {
			223128,
		},
	},
	DialogList = {
		{
			{
				Text = "水流的速度是1.2m/s。",
				Position = 1,
			},
			{
				Text = "今天吹的是三级西北风。",
				Position = 1,
			},
			{
				Text = "根据公式得出，船头应该向左调整5°。",
				Position = 1,
			},
		},
		{
			{
				Text = "根据计算，这里水深不超过1.5米。",
				Position = 1,
			},
			{
				Text = "把航道深浅乘系数，再套入函数中……",
				Position = 1,
			},
			{
				Text = "最后的答案就出来了。",
				Position = 1,
			},
		},
		{
			{
				Text = "我那个白痴弟弟又在划水了。",
				Position = 1,
			},
			{
				Text = "那桨划水的时候，不可以划水啊！",
				Position = 1,
			},
		},
		{
			{
				Text = "今天的风儿甚是喧嚣。",
				Position = 1,
			},
			{
				Text = "看来，忽强忽弱的风，会成为这次比赛的变数。",
				Position = 1,
			},
			{
				Text = "但也不是完全不能预测……",
				Position = 1,
			},
		},
	},
}
ExileStreetCharacterConfig["SPBUS_10_jiangshou01_2"] =
{
	PreCondition = {
		UnlockCharacterList = {
			223127,
			223128,
		},
	},
	DialogList = {
		{
			{
				Text = "你刚刚又想逃跑了吧？",
				Position = 1,
			},
			{
				Text = "我没有。",
				Position = 2,
			},
			{
				Text = "我已经看到你准备跑的姿势了。",
				Position = 1,
			},
			{
				Text = "你看错了，姐姐。",
				Position = 2,
			},
		},
		{
			{
				Text = "你今天居然带了船桨？",
				Position = 1,
			},
			{
				Text = "哦，找主办方借的。",
				Position = 2,
			},
			{
				Text = "……",
				Position = 1,
			},
			{
				Text = "我还自己付了租赁费。",
				Position = 2,
			},
		},
		{
			{
				Text = "不准划水。",
				Position = 1,
			},
			{
				Text = "为什么？明明你也在划水。",
				Position = 2,
			},
			{
				Text = "我在拿桨划水，和你不一样。",
				Position = 1,
			},
			{
				Text = "你看，你承认了，你在划水。",
				Position = 2,
			},
			{
				Text = "……",
				Position = 1,
			},
		},
		{
			{
				Text = "你在嘟囔些什么？",
				Position = 1,
			},
			{
				Text = "我想回家。",
				Position = 2,
			},
			{
				Text = "为什么？",
				Position = 1,
			},
			{
				Text = "和比赛比起来，我的家更重要。",
				Position = 2,
			},
			{
				Text = "……",
				Position = 1,
			},
		},
	},
}
ExileStreetCharacterConfig["SPBUS_11_jiangshou02_1"] =
{
	PreCondition = {
		UnlockCharacterList = {
			223128,
		},
		LockCharacterList = {
			223127,
		},
	},
	DialogList = {
		{
			{
				Text = "不想划船。",
				Position = 1,
			},
			{
				Text = "不想上班。",
				Position = 1,
			},
			{
				Text = "不想干活。",
				Position = 1,
			},
			{
				Text = "只想被丢下船。",
				Position = 1,
			},
		},
		{
			{
				Text = "我是谁？",
				Position = 1,
			},
			{
				Text = "我在哪？",
				Position = 1,
			},
			{
				Text = "我在干什么？",
				Position = 1,
			},
		},
		{
			{
				Text = "反正都是划水比赛。",
				Position = 1,
			},
			{
				Text = "那我划水怎么了。",
				Position = 1,
			},
			{
				Text = "我只想拥有比赛时的自由。",
				Position = 1,
			},
		},
		{
			{
				Text = "姐姐竟然也没有来。",
				Position = 1,
			},
			{
				Text = "看来这个比赛也不是很重要。",
				Position = 1,
			},
			{
				Text = "这不是正是我偷偷跑掉的好机会吗？",
				Position = 1,
			},
		},
	},
}
ExileStreetCharacterConfig["SPBUS_14_YiXin"] =
{
	PreCondition = {
		UnlockCharacterList = {
			223131,
		},
	},
	DialogList = {
		{
			{
				Text = "文化课分数占60%。",
				Position = 1,
			},
			{
				Text = "目前基本没有什么问题。",
				Position = 1,
			},
			{
				Text = "剩下40%，就是专业分数了。",
				Position = 1,
			},
			{
				Text = "还是要在织布上多下功夫。",
				Position = 1,
			},
		},
		{
			{
				Text = "完成度59%。",
				Position = 1,
			},
			{
				Text = "预计三小时十五分钟后可以完成。",
				Position = 1,
			},
		},
		{
			{
				Text = "这块红布上的星星花纹真好看。",
				Position = 1,
			},
			{
				Text = "就叫它布星吧。",
				Position = 1,
			},
			{
				Text = "那块绿布的花茎，绣得也很好看。",
				Position = 1,
			},
			{
				Text = "不如叫它布茎云。",
				Position = 1,
			},
		},
		{
			{
				Text = "我的棒针哪去了？",
				Position = 1,
			},
			{
				Text = "奇怪，我记得就在这里。",
				Position = 1,
			},
			{
				Text = "难道是我记错了吗？",
				Position = 1,
			},
			{
				Text = "可我的记忆，出错的几率，不超过21.6%…",
				Position = 1,
			},
		},
	},
}
ExileStreetCharacterConfig["SPBUS_15_ErJv"] =
{
	PreCondition = {
		UnlockCharacterList = {
			223132,
		},
	},
	DialogList = {
		{
			{
				Text = "已知边长为1的正方形ABCD.",
				Position = 1,
			},
			{
				Text = "沿BC旋转一周得到圆柱体。",
				Position = 1,
			},
			{
				Text = "求圆柱体的表面积。",
				Position = 1,
			},
			{
				Text = "送分题。",
				Position = 1,
			},
		},
		{
			{
				Text = "女子纺织中学之所以有名的原因...",
				Position = 1,
			},
			{
				Text = "是因为这里的老师，在不断探索先进的教学制度...",
				Position = 1,
			},
			{
				Text = "这个病句太明显了。",
				Position = 1,
			},
			{
				Text = "叉掉。",
				Position = 1,
			},
		},
		{
			{
				Text = "积土成山，风雨兴焉；积水成渊，蛟龙生焉...",
				Position = 1,
			},
			{
				Text = "积善成德，而神明自得，圣心备焉。",
				Position = 1,
			},
			{
				Text = "故不积跬步，无以至千里。",
				Position = 1,
			},
			{
				Text = "不积小流，无以成江海。",
				Position = 1,
			},
			{
				Text = "骐...鸡...骑…卡壳了。",
				Position = 1,
			},
		},
		{
			{
				Text = "虽然是下课时间...",
				Position = 1,
			},
			{
				Text = "但大家真吵。",
				Position = 1,
			},
			{
				Text = "Rome can be pricey for…for tra…",
				Position = 1,
			},
			{
				Text = "算了，不做了。",
				Position = 1,
			},
		},
	},
}
ExileStreetCharacterConfig["SPBUS_16_SanHua"] =
{
	PreCondition = {
		UnlockCharacterList = {
			223133,
		},
	},
	DialogList = {
		{
			{
				Text = "这个帽子很适合你喵！",
				Position = 1,
			},
			{
				Text = "也很适合我…",
				Position = 1,
			},
			{
				Text = "所以我说喵，我们一定是异父异母的亲姐妹！",
				Position = 1,
			},
		},
		{
			{
				Text = "你家在哪里喵？",
				Position = 1,
			},
			{
				Text = "为什么会出现在我们教室喵？",
				Position = 1,
			},
			{
				Text = "等下课了，我带你回家好不好。",
				Position = 1,
			},
			{
				Text = "还是说你不想回家，想和我走喵？",
				Position = 1,
			},
		},
		{
			{
				Text = "啊，你的毛毛好软啊...",
				Position = 1,
			},
			{
				Text = "太可爱了喵！！",
				Position = 1,
			},
			{
				Text = "我这里有小鱼玩具，你喜欢吗？",
				Position = 1,
			},
		},
		{
			{
				Text = "其实，我有一个朋友...",
				Position = 1,
			},
			{
				Text = "想让你跟她回家，做她的猫咪。",
				Position = 1,
			},
			{
				Text = "好吧，我说的这个朋友就是我自己。",
				Position = 1,
			},
		},
	},
}
ExileStreetCharacterConfig["SPBUS_17_SiLi"] =
{
	PreCondition = {
		UnlockCharacterList = {
			223134,
		},
	},
	DialogList = {
		{
			{
				Text = "这次在黑板上画什么呢...",
				Position = 1,
			},
			{
				Text = "画个老师吧！",
				Position = 1,
			},
			{
				Text = "嘻嘻，你们不要告状哦。",
				Position = 1,
			},
		},
		{
			{
				Text = "唔哇哇哇，玩过头了。",
				Position = 1,
			},
			{
				Text = "我的铅笔呢...",
				Position = 1,
			},
			{
				Text = "二橘，六瑶，看到我的铅笔了吗？",
				Position = 1,
			},
			{
				Text = "喂喂，你们理一理我啦。",
				Position = 1,
			},
		},
		{
			{
				Text = "我的小蜘蛛们去哪儿了？",
				Position = 1,
			},
			{
				Text = "算了，今天给小蜘蛛们放个假。",
				Position = 1,
			},
			{
				Text = "要不要把粉笔换成奇怪的东西呢？",
				Position = 1,
			},
			{
				Text = "我有计划了，嘿嘿嘿...",
				Position = 1,
			},
		},
		{
			{
				Text = "今天老师说要去开会。",
				Position = 1,
			},
			{
				Text = "好耶，大家嗨起来！",
				Position = 1,
			},
			{
				Text = "这就是自由的气息~",
				Position = 1,
			},
			{
				Text = "嘘！不好，门外有脚步声！",
				Position = 1,
			},
		},
	},
}
ExileStreetCharacterConfig["SPBUS_18_WuXing"] =
{
	PreCondition = {
		UnlockCharacterList = {
			223135,
		},
	},
	DialogList = {
		{
			{
				Text = "这些课程很简单嘛。",
				Position = 1,
			},
			{
				Text = "还有三页就看完了。",
				Position = 1,
			},
			{
				Text = "看来过几天的考试，问题不大。",
				Position = 1,
			},
		},
		{
			{
				Text = "果然我还是最喜欢地理天文了。",
				Position = 1,
			},
			{
				Text = "这些星星真好看...",
				Position = 1,
			},
			{
				Text = "毕业之后，一定要去外星旅游！",
				Position = 1,
			},
		},
		{
			{
				Text = "今天的错题集就整理到这里吧。",
				Position = 1,
			},
			{
				Text = "不过，整理这些真的有意义吗？",
				Position = 1,
			},
			{
				Text = "感觉下次也会犯这样的错误...",
				Position = 1,
			},
			{
				Text = "这是，这是...对！",
				Position = 1,
			},
			{
				Text = "这就是人性的弱点。",
				Position = 1,
			},
		},
		{
			{
				Text = "左手写字，右手翻书。",
				Position = 1,
			},
			{
				Text = "配合下来，感觉很丝滑。",
				Position = 1,
			},
			{
				Text = "大概这就是左撇子的好处。",
				Position = 1,
			},
		},
	},
}
ExileStreetCharacterConfig["SPBUS_19_LiuYao"] =
{
	PreCondition = {
		UnlockCharacterList = {
			223136,
		},
	},
	DialogList = {
		{
			{
				Text = "老师不在，兔兔。",
				Position = 1,
			},
			{
				Text = "你可以从包里出来啦。",
				Position = 1,
			},
			{
				Text = "不怕不怕，这里没有坏人。",
				Position = 1,
			},
		},
		{
			{
				Text = "教室里好吵的样子...",
				Position = 1,
			},
			{
				Text = "如果老师来了怎么办？",
				Position = 1,
			},
			{
				Text = "又要被罚写检讨，抄课文了...",
				Position = 1,
			},
			{
				Text = "我不想被罚，呜呜呜。",
				Position = 1,
			},
		},
		{
			{
				Text = "课文、课文还没有背下来...",
				Position = 1,
			},
			{
				Text = "兔兔，你说我可以背下来吗？",
				Position = 1,
			},
			{
				Text = "嗯，你说没问题的？",
				Position = 1,
			},
			{
				Text = "那我再努力背一背！",
				Position = 1,
			},
		},
		{
			{
				Text = "怎么办，还有几天就要考试了...",
				Position = 1,
			},
			{
				Text = "感觉，什么都没有准备好...",
				Position = 1,
			},
			{
				Text = "如果没有考好...",
				Position = 1,
			},
			{
				Text = "呼，好紧张…",
				Position = 1,
			},
		},
	},
}
ExileStreetCharacterConfig["SPBUS_24_XueShen_1"] =
{
	PreCondition = {
		UnlockCharacterList = {
			223141,
		},
	},
	DialogList = {
		{
			{
				Text = "看不见我，看不见我……",
				Position = 1,
			},
			{
				Text = "只要我不出声，他们就看不见我看不见我。",
				Position = 1,
			},
			{
				Text = "别和我打招呼，拜托拜托。",
				Position = 1,
			},
			{
				Text = "我是透明的，别和我说话啊。",
				Position = 1,
			},
		},
		{
			{
				Text = "这就是人们说的“社交恐惧症”吗……",
				Position = 1,
			},
			{
				Text = "有时候真羡慕小厨娘呀。",
				Position = 1,
			},
			{
				Text = "为什么她总是可以和别人自然地聊天呢？",
				Position = 1,
			},
			{
				Text = "这算是“社交牛X症”吗？",
				Position = 1,
			},
		},
		{
			{
				Text = "感觉我和这里的气氛格格不入。",
				Position = 1,
			},
			{
				Text = "好想回山上。",
				Position = 1,
			},
			{
				Text = "山上才是我的归宿。",
				Position = 1,
			},
		},
		{
			{
				Text = "这个角落的气温似乎变热了。",
				Position = 1,
			},
			{
				Text = "不知道小雪人能不能撑住。",
				Position = 1,
			},
			{
				Text = "要我说，他就应该和我一起待在山上。",
				Position = 1,
			},
			{
				Text = "而不是在这里凑人类的热闹，呜呜呜……",
				Position = 1,
			},
			{
				Text = "……这时候我应该在山上跳舞。",
				Position = 1,
			},
		},
	},
}
ExileStreetCharacterConfig["SPBUS_25_MaoYanChuNiang_1"] =
{
	PreCondition = {
		UnlockCharacterList = {
			223142,
		},
		LockCharacterList = {
			223143,
		},
	},
	DialogList = {
		{
			{
				Text = "在这里泡热汤太舒服啦！",
				Position = 1,
			},
			{
				Text = "如果明天不用上班就好了。",
				Position = 1,
			},
			{
				Text = "不对，我是这里的老板呀！",
				Position = 1,
			},
			{
				Text = "嗯，明天我要给自己放假，不用上班啦！",
				Position = 1,
			},
		},
		{
			{
				Text = "想吃温泉蛋了。",
				Position = 1,
			},
			{
				Text = "还想喝汽水、吃冰淇淋。",
				Position = 1,
			},
			{
				Text = "对了，以后可以为客人们设置一个套餐。",
				Position = 1,
			},
			{
				Text = "就叫“温泉幸福单人餐”吧。",
				Position = 1,
			},
		},
		{
			{
				Text = "盐少许、胡椒粉少许、糖少许，用油炸香。",
				Position = 1,
			},
			{
				Text = "这个攻略是对的吗？",
				Position = 1,
			},
			{
				Text = "为什么刚刚我一炸，就变成了黑乎乎的东西呢？",
				Position = 1,
			},
		},
		{
			{
				Text = "那个人还来不来泡温泉呀？",
				Position = 1,
			},
			{
				Text = "哼，我可不想等他。",
				Position = 1,
			},
			{
				Text = "如果不来，我泡一会儿就回去睡觉了。",
				Position = 1,
			},
		},
	},
}
ExileStreetCharacterConfig["SPBUS_26_WenQuanJianShanJia_1"] =
{
	PreCondition = {
		UnlockCharacterList = {
			223143,
		},
		LockCharacterList = {
			223142,
		},
	},
	DialogList = {
		{
			{
				Text = "居酒屋太挤了！",
				Position = 1,
			},
			{
				Text = "这个底层逻辑到底是什么样的？",
				Position = 1,
			},
			{
				Text = "顶层设计又在哪里？",
				Position = 1,
			},
			{
				Text = "我看不到它最终交付的价值。",
				Position = 1,
			},
		},
		{
			{
				Text = "《梦幻的温泉之旅》。",
				Position = 1,
			},
			{
				Text = "《一定要和男女朋友去看一次的雪景》。",
				Position = 1,
			},
			{
				Text = "《学生党也能住别墅？性价比超高别墅温泉》。",
				Position = 1,
			},
			{
				Text = "以上就是这三篇推文的标题。",
				Position = 1,
			},
			{
				Text = "我可算是把推文给整明白了。",
				Position = 1,
			},
		},
		{
			{
				Text = "小厨娘怎么还不来？",
				Position = 1,
			},
			{
				Text = "我们约好了一起泡温泉的呀。",
				Position = 1,
			},
			{
				Text = "难道……她打算把我鸽了吗！！",
				Position = 1,
			},
		},
		{
			{
				Text = "一波还未平息~一波又来侵袭~",
				Position = 1,
			},
			{
				Text = "茫茫人海~狂风暴雨~",
				Position = 1,
			},
			{
				Text = "一波还来不及~一波早过去~",
				Position = 1,
			},
			{
				Text = "再来一杯~加冰生啤~",
				Position = 1,
			},
			{
				Text = "深深温泉池里~深深开心~",
				Position = 1,
			},
		},
	},
}
ExileStreetCharacterConfig["SPBUS_26_WenQuanJianShanJia_2"] =
{
	PreCondition = {
		UnlockCharacterList = {
			223142,
			223143,
		},
	},
	DialogList = {
		{
			{
				Text = "水温合适吗？",
				Position = 1,
			},
			{
				Text = "挺好的，舒服。",
				Position = 2,
			},
			{
				Text = "和高尔夫球场旁边的那家比呢？",
				Position = 1,
			},
			{
				Text = "那还是我们更舒服，那家水太凉了。",
				Position = 2,
			},
			{
				Text = "好啊，我就知道你瞒着我去那家玩了。",
				Position = 1,
			},
			{
				Text = "宝贝，不是……你听我狡辩！",
				Position = 2,
			},
		},
		{
			{
				Text = "我想在你这个角落坐着，你能让让我吗？",
				Position = 1,
			},
			{
				Text = "Zzzz…",
				Position = 2,
			},
			{
				Text = "真的睡着了？",
				Position = 1,
			},
			{
				Text = "Zzzz...",
				Position = 2,
			},
			{
				Text = "……你再装，这个月就没有零花钱了哦。",
				Position = 1,
			},
			{
				Text = "对不起！！我错了。",
				Position = 2,
			},
		},
		{
			{
				Text = "你有什么想吃的吗？",
				Position = 1,
			},
			{
				Text = "有！炸鸡、冰淇凌、可乐、还有啤酒……",
				Position = 2,
			},
			{
				Text = "那你去买吧，顺便帮我带一瓶红茶。",
				Position = 1,
			},
			{
				Text = "什么？我？",
				Position = 2,
			},
			{
				Text = "嗯？你不愿意？",
				Position = 1,
			},
		},
		{
			{
				Text = "你能不能往下坐一点。",
				Position = 1,
			},
			{
				Text = "怎么了？",
				Position = 2,
			},
			{
				Text = "在客人面前，露出一个巨大的肚子，不太好吧？",
				Position = 1,
			},
			{
				Text = "呜呜，你嫌弃我的大肚子，是不是？",
				Position = 2,
			},
			{
				Text = "别哭了，再哭我就亲手把你拽进池子里。",
				Position = 1,
			},
		},
	},
}
ExileStreetCharacterConfig["SPBUS_27_JianShenJiaoLian_1"] =
{
	PreCondition = {
		UnlockCharacterList = {
			223144,
		},
	},
	DialogList = {
		{
			{
				Text = "儿子，锻炼你水性的时候到了！",
				Position = 1,
			},
			{
				Text = "别怕，爸爸永远是你最坚强的后盾。",
				Position = 1,
			},
			{
				Text = "与你的游泳圈一起，开始这段冒险吧！",
				Position = 1,
			},
			{
				Text = "儿子，加油！",
				Position = 1,
			},
		},
		{
			{
				Text = "嚯——哈！",
				Position = 1,
			},
			{
				Text = "儿子，你看爸爸的腹肌。",
				Position = 1,
			},
			{
				Text = "还有坚硬的肱二头肌。",
				Position = 1,
			},
			{
				Text = "你一定要像爸爸一样，成为一个健康的男人。",
				Position = 1,
			},
			{
				Text = "爸爸看好你哟。",
				Position = 1,
			},
		},
		{
			{
				Text = "儿子，你平时坐着的杠铃去哪儿了？",
				Position = 1,
			},
			{
				Text = "什么？在温泉池底！！",
				Position = 1,
			},
			{
				Text = "不行，我们得在别人不发现的情况下……",
				Position = 1,
			},
			{
				Text = "把它偷偷地带出来。",
				Position = 1,
			},
			{
				Text = "否则，老板会投诉我们的！",
				Position = 1,
			},
		},
		{
			{
				Text = "什么？儿子你说什么？",
				Position = 1,
			},
			{
				Text = "啊，想吃冰淇凌和可乐啊……",
				Position = 1,
			},
			{
				Text = "你、你大声点，爸爸听不见。",
				Position = 1,
			},
			{
				Text = "儿子，你说啥？想要啥？爸爸都给买。",
				Position = 1,
			},
		},
	},
}
ExileStreetCharacterConfig["SPBUS_28_DuanErXiong_1"] =
{
	PreCondition = {
		UnlockCharacterList = {
			223145,
		},
		LockCharacterList = {
			223148,
		},
	},
	DialogList = {
		{
			{
				Text = "温泉！",
				Position = 1,
			},
			{
				Text = "泡泡！",
				Position = 1,
			},
			{
				Text = "想去。",
				Position = 1,
			},
		},
		{
			{
				Text = "抱抱。",
				Position = 1,
			},
			{
				Text = "抱抱。",
				Position = 1,
			},
			{
				Text = "……",
				Position = 1,
			},
			{
				Text = "有人抱抱吗？",
				Position = 1,
			},
			{
				Text = "呜呜……",
				Position = 1,
			},
		},
		{
			{
				Text = "如果，下水……",
				Position = 1,
			},
			{
				Text = "身体，变重。",
				Position = 1,
			},
			{
				Text = "要烘干，难受。",
				Position = 1,
			},
			{
				Text = "不玩水了。",
				Position = 1,
			},
		},
		{
			{
				Text = "有雪？",
				Position = 1,
			},
			{
				Text = "他要进来吗？",
				Position = 1,
			},
			{
				Text = "吉祥物要……",
				Position = 1,
			},
			{
				Text = "乖乖坐好。",
				Position = 1,
			},
			{
				Text = "等人来。",
				Position = 1,
			},
		},
	},
}
ExileStreetCharacterConfig["SPBUS_29_XueZhongLieRen_1"] =
{
	PreCondition = {
		UnlockCharacterList = {
			223146,
		},
	},
	DialogList = {
		{
			{
				Text = "嘘，狗子，你就悄悄躲在这里。",
				Position = 1,
			},
			{
				Text = "我拿帽子担保，不会被别人发现的。",
				Position = 1,
			},
			{
				Text = "这个位置……应该很隐蔽吧？",
				Position = 1,
			},
			{
				Text = "如果有危险，我就直接把你摁进水里。",
				Position = 1,
			},
			{
				Text = "咱俩配合，亲密无间！",
				Position = 1,
			},
		},
		{
			{
				Text = "嘘，不要发出声音。",
				Position = 1,
			},
			{
				Text = "我以你主人的身份警告你。",
				Position = 1,
			},
			{
				Text = "啊！不要蹬我的腿啊！",
				Position = 1,
			},
			{
				Text = "爪子！疼！嗷！",
				Position = 1,
			},
		},
		{
			{
				Text = "这水里有药剂和硫磺。",
				Position = 1,
			},
			{
				Text = "好吧，希望你不要把它喝下去。",
				Position = 1,
			},
			{
				Text = "什么？你已经喝过了？",
				Position = 1,
			},
			{
				Text = "唉，你这只不让人省心的狗子！",
				Position = 1,
			},
		},
		{
			{
				Text = "这里真舒服。",
				Position = 1,
			},
			{
				Text = "你看，你也很享受，是吧？",
				Position = 1,
			},
			{
				Text = "不过我们泡的时间不能太长。",
				Position = 1,
			},
			{
				Text = "否则按照热胀冷缩原理，你就钻不进套圈了。",
				Position = 1,
			},
		},
	},
}
ExileStreetCharacterConfig["SPBUS_30_BianJuMeiZi_1"] =
{
	PreCondition = {
		UnlockCharacterList = {
			223147,
		},
	},
	DialogList = {
		{
			{
				Text = "哇，好多人呀。",
				Position = 1,
			},
			{
				Text = "真热闹。",
				Position = 1,
			},
		},
		{
			{
				Text = "我看过你哭，一滴明亮的泪涌上你蓝色的眼珠。",
				Position = 1,
			},
			{
				Text = "那时候我心想，这不就是一朵紫罗兰上垂着露。",
				Position = 1,
			},
			{
				Text = "我看过你笑，宝石的火焰在你之前也不再闪耀。",
				Position = 1,
			},
			{
				Text = "啊，宝石的闪烁怎比得上你那灵活一瞥的光线。",
				Position = 1,
			},
		},
		{
			{
				Text = "这次的旅行，宛如欣赏一册生活画卷。",
				Position = 1,
			},
			{
				Text = "我该把他们记录下来，成为永恒的回忆。",
				Position = 1,
			},
			{
				Text = "他为何带着儿子前来，二人一起越过山脉。",
				Position = 1,
			},
			{
				Text = "他为何带着宠物入水，又不允他肆意狂吠？",
				Position = 1,
			},
		},
		{
			{
				Text = "多么温暖的地方！",
				Position = 1,
			},
			{
				Text = "袅袅烟雾升起，伴着点点梅花。",
				Position = 1,
			},
			{
				Text = "这副景象值得用文字记录下来。",
				Position = 1,
			},
			{
				Text = "《当轻烟遇上红梅》。",
				Position = 1,
			},
			{
				Text = "真是个好名字。",
				Position = 1,
			},
		},
	},
}
ExileStreetCharacterConfig["SPBUS_31_SiNuoMan_1"] =
{
	PreCondition = {
		UnlockCharacterList = {
			223148,
		},
		LockCharacterList = {
			223145,
		},
	},
	DialogList = {
		{
			{
				Text = "哎？我们的吉祥物呢？",
				Position = 1,
			},
			{
				Text = "不知道她今天，会不会好看的裙子。",
				Position = 1,
			},
			{
				Text = "不过就算没有，她也是最可爱的小家伙。",
				Position = 1,
			},
		},
		{
			{
				Text = "这里真暖和啊。",
				Position = 1,
			},
			{
				Text = "只有这一角有雪的气息。",
				Position = 1,
			},
			{
				Text = "我就好好待在这里，一定不会融化。",
				Position = 1,
			},
			{
				Text = "如果融化了，就找雪神告状去！",
				Position = 1,
			},
		},
		{
			{
				Text = "如果我不是雪人就好了。",
				Position = 1,
			},
			{
				Text = "这样就不用总是待在山上了。",
				Position = 1,
			},
			{
				Text = "山上一点烟火气也没有，有什么好的呢？",
				Position = 1,
			},
		},
		{
			{
				Text = "等会儿吉祥物来了，我要怎么和她打招呼呢？",
				Position = 1,
			},
			{
				Text = "你也来这里？好巧啊！",
				Position = 1,
			},
			{
				Text = "不行，太不自然了。",
				Position = 1,
			},
			{
				Text = "怎么办，完全没想好台词啊。",
				Position = 1,
			},
		},
	},
}
ExileStreetCharacterConfig["SPBUS_31_SiNuoMan_2"] =
{
	PreCondition = {
		UnlockCharacterList = {
			223148,
			223145,
		},
	},
	DialogList = {
		{
			{
				Text = "你、你也来这里啊。",
				Position = 1,
			},
			{
				Text = "嗯，抱抱。",
				Position = 2,
			},
			{
				Text = "怎么一上来就抱啊？太亲热了，不行。",
				Position = 1,
			},
			{
				Text = "抱抱。",
				Position = 2,
			},
			{
				Text = "哼，好吧……真拿你没办法。",
				Position = 1,
			},
		},
		{
			{
				Text = "我……其实，一直在等着和你见面。",
				Position = 1,
			},
			{
				Text = "嗯嗯！",
				Position = 2,
			},
			{
				Text = "你是说……你也是？",
				Position = 1,
			},
			{
				Text = "嗯嗯！",
				Position = 2,
			},
			{
				Text = "你、你这个不会好好说话的、可爱的吉祥物！",
				Position = 1,
			},
		},
		{
			{
				Text = "气温上升了……",
				Position = 1,
			},
			{
				Text = "怕怕。",
				Position = 2,
			},
			{
				Text = "嗯？你怕什么？怕我融化？",
				Position = 1,
			},
			{
				Text = "嗯嗯！回去！",
				Position = 2,
			},
			{
				Text = "哼，瞎操心……我不会化掉，有人在保佑我们。",
				Position = 1,
			},
		},
		{
			{
				Text = "你现在……也不是每句话都听得清，对吧？",
				Position = 1,
			},
			{
				Text = "厨娘，你。",
				Position = 2,
			},
			{
				Text = "只能听清我和小厨娘说话？为什么？",
				Position = 1,
			},
			{
				Text = "你们，好人！",
				Position = 2,
			},
			{
				Text = "……说话也不利索，算了，给你一个抱抱。",
				Position = 1,
			},
		},
	},
}

