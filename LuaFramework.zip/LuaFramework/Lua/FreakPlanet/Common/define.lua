Util = LuaFramework.Util;
AppConst = LuaFramework.AppConst;
LuaHelper = LuaFramework.LuaHelper;
ByteBuffer = LuaFramework.ByteBuffer;

resMgr = LuaHelper.GetResManager();
panelMgr = LuaHelper.GetPanelManager();
soundMgr = LuaHelper.GetSoundManager();
networkMgr = LuaHelper.GetNetManager();
httpMgr = LuaHelper.GetHttpManager();

UnityWebRequest = UnityEngine.UnityWebRequest;
GameObject = UnityEngine.GameObject;
AudioSource = UnityEngine.AudioSource
Input = UnityEngine.Input;
SceneManager = UnityEngine.SceneManagement.SceneManager
Screen = UnityEngine.Screen
DictString = System.Collections.Generic.DictString

INVALID_ID = -1
INVALID_ID_0 = 0
EXPLORE_NUM_LIMIT = 5
MAX_ABILITY_NUM = 8
VCODE_COOLDOWN = 30
MAX_TEAM_COUNT = 10
CHALLENGE_MAX_STAR = 5

LOCK_ICON_COLOR = Color.New(40 / 255, 40 / 255, 40 / 255, 1)

PRIVACY_NOTICE_URL = "https://imqxq.saiyunyx.com/xy/privacy_policy.html"
USER_NOTICE_URL = "https://imqxq.saiyunyx.com/xy/user_notice.html"
SUMMON_PROBABILITY_URL = "https://imqxq.saiyunyx.com/xy/probability_notice.html"
WEIBO_URL = "https://weibo.com/u/6979653518"
AGE_NOTICE_URL = "http://freakplanettest.pook.com.cn/news/mobileNEWS20210914145925.html"

Const = {
	-- bundle
	CommonBundleName = 'common',
	FontBundleName = 'font',
	SoundBundleName = 'sound',
	PlanetsBundleName = "planets",
	NpcBundleName = "character_npc",
	PlanetBundleName = "planet",
	MapBundleName = "map",
	RoomBundleName = "room",
	SkillEffectBundleName = "skilleffect",
	RoomTextureBundleName = "packed_furniture",
	Room2TextureBundleName = "packed_furniture2",
	Room3TextureBundleName = "packed_furniture3",
	TravelBundleName = "travel",
	TravelWorldBGBundleName = "packed_spacetravelbg",
	EventBGBundleName = "packed_eventbg",
	CoupeAvatarBundleName = "packed_couple",
	ArenaStreetBundleName = "packed_exilestreet",
	StartSceneBundleName = "startscene",
	ArenaBuildingBundleName = "arenabuilding",
	HideSeekBundleName = "packed_hideseek",
	HideSeekComicBundleName = "packed_comic",	             -- hide seek comic
	-- atlas
	AccountAtlasBundleName = "atlas_account",                -- account
	Activity1AtlasBundleName = "atlas_activity_1",           -- activity 1
    AiAtlasBundleName = "atlas_ai",                          -- tutorial ai
    ArenaAtlasBundleName = "atlas_arena",	                 -- arena icon
    CampEnemyIconAtlasBundleName = "atlas_campenemyicon",    -- camp enemy icon
	ComicAtlasBundleName = "atlas_comic",            	     -- comic
	EventBGIconAtlasBundleName = "atlas_eventbgicon",	     -- event bg icon
	ExploreAtlasBundleName = "atlas_explore",			     -- explore
	RoomPieceAtlasBundleName = "atlas_furnitureicon",        -- room piece icon
	GalleryIconAtlasBundleName = "atlas_galleryicon",        -- gallery icon
	GoodsAtlasBundleName = "atlas_goods",					 -- goods icon
	IapAtlasBundleName = "atlas_iapshop",                    -- iap
	LaboratoryAtlasBundleName = "atlas_laboratory",			 -- laboratory
	MarketAtlasBundleName = "atlas_market",                  -- market
	MapAtlasBundleName = "atlas_map",                        -- map
	PackageAtlasBundleName = "atlas_package",                -- package icon
	PlanetIconAtlasBundleName = "atlas_planeticon",			 -- planet icon
	PortraitIconAtlasBundleName = "atlas_portraiticon",      -- portrait icon
	ReportErrorAtlasBundleName = "atlas_reporterror",        -- report error icon
	SignInAtlasBundleName = "atlas_signinreward",            -- sign in reward
	--SpaceTravelAtlasBundleName = "atlas_spacetravel",        -- space travel icon
	--SpaceTravelEventAtlasBundleName = "atlas_spacetravelevent", -- space travel event
	--SpaceTravelGoodsAtlasBundleName = "atlas_spacetravelgoods", -- space travel goods
	StartSceneAtlasBundleName = "atlas_startscene",          -- start scene
	SummonAtlasBundleName = "atlas_summon",            	     -- summon
	TutorialGuideAtlasBundleName = "atlas_tutorialguide",    -- tutorial guide
	UIGeneralAtlasBundleName = "atlas_uigeneral",            -- ui general
	WorkShopAtlasBundleName = "atlas_workshop",				 -- workshop
	TouristAtlasBundleName = "atlas_zoo",                    -- tourist
	CatchFishAtlasBundleName = "atlas_catchfish",            -- account


}
----------------------------------------------------------
