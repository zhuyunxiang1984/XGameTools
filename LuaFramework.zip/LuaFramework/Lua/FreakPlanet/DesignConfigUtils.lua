require "FreakPlanet/Design/MiscConfig"
require "FreakPlanet/Design/AbilityConfig"
require "FreakPlanet/Design/GoodsConfig"
require "FreakPlanet/Design/PlanetConfig"
require "FreakPlanet/Design/CharacterConfig"
require "FreakPlanet/Design/GoalConfig"
require "FreakPlanet/Design/HomeAchievementConfig"

local this = ConfigUtils
-----------------------------------------------------------------------------
function ConfigUtils.GetFirstAvailableSourceAreaOfItem(itemId)
	local sources = ConfigUtils.GetItemSource(itemId)
	for idx = 1, #sources do
		if sources[idx].source == SourceType.Explore then
			if GameData.IsPlanetAreaUnlocked(sources[idx].value) then
				return sources[idx].value
			end
		end
	end

	return nil
end

function ConfigUtils.GetFirstAvailableSourceAreaOfEnemy(enemyId)
	local areas = ConfigUtils.GetPlanetAreaOfEnemy(enemyId)
	for idx = 1, #areas do
		local areaId = areas[idx]
		if GameData.IsPlanetAreaUnlocked(areaId) then
			return areaId
		end
	end

	return nil
end

function ConfigUtils.GetFirstAvailableSourceAreaOfPet(petId)
	local areas = ConfigUtils.GetPlanetAreaOfPet(petId)
	for idx = 1, #areas do
		local areaId = areas[idx]
		if GameData.IsPlanetAreaUnlocked(areaId) then
			return areaId
		end
	end

	return nil
end
-----------------------------------------------------------------------------
-- do some filters
function ConfigUtils.GetGoalActualRewards(goalId)
	local rewards = ConfigUtils.GetGoalReward(goalId)

	local ret = {}
	for idx = 1, #rewards do
		local rewardId = rewards[idx].Value
		local rewardNum = rewards[idx].Num
		local rewardType = ConfigUtils.GetItemTypeFromId(rewardId)
		local isPlanetArea = (rewardType == ItemType.PlanetArea)
		local unlocked = GameData.IsItemUnlocked(rewardId)
		local shouldReward = (not isPlanetArea or not unlocked)
		-- planet area: may have more than one planet area configed in goals
		-- planet area only add once; if unlocked just skip it
		if shouldReward then
			table.insert(ret, {Value = rewardId, Num = rewardNum})
		end
	end

	return ret
end
-----------------------------------------------------------------------------
function ConfigUtils.CheckEquipments(characterId, equipIds)
	equipIds = equipIds or {}
	
	local equipLevelMap = {}
	for idx = 1, #equipIds do
		local equipId = equipIds[idx][1]
		local equipLevel = equipIds[idx][2]
		equipLevel = math.max(equipLevel, 1)
		equipLevelMap[equipId] = equipLevel
	end

	local equipmentList = this.GetCharacterEquipmentList(characterId)
	local ret = {}
	for idx = 1, #equipmentList do
		local equipmentId = equipmentList[idx]
		local level = equipLevelMap[equipmentId] or 1
		ret[idx] = {id = equipmentId, level = level}
	end

	return ret
end
-------------------------------------------------
-- HomeAchievement
function ConfigUtils.GetHomeAchievementConfig(idx)
	local config = HomeAchievementConfig[idx]
	return config
end

function ConfigUtils.GetHomeAchievementsCount()
	return #HomeAchievementConfig
end

function ConfigUtils.GetHomeAchievementsGoalList(idx)
	local config = HomeAchievementConfig[idx]
	return config.GoalList or {}
end
-------------------------------------------------
CoupleFailReason = {
	CharacterLocked = 1,
	SkinLocked = 2,
	StageLocked = 3,
	LevelLocked = 4,
}

function ConfigUtils.IsCoupleUnlocked(coupleId, strict)
	local conditions = ConfigUtils.GetCoupleConditions(coupleId)
	strict = strict or false

	for idx = 1, #conditions do
		local matched = this.IsCoupleConditionMatched(conditions[idx], strict)
		if not matched then
			return false
		end
	end

	return true
end

function ConfigUtils.IsCoupleConditionMatched(condtion, strict)
	local characterId = condtion.Id
	local skinId = condtion.SkinId
	local characterStage = condtion.Stage
	local characterLevel = condtion.Level

	strict = strict or false

	if not GameData.IsCharacterUnlocked(characterId) then
		return false, CoupleFailReason.CharacterLocked
	end

	if skinId ~= nil then
		local skinUnlocked = GameData.IsSkinUnlocked(skinId)
		if not skinUnlocked then
			return false, CoupleFailReason.SkinLocked
		end

		if strict then
			local currentSkin = GameData.GetCharacterSkin(characterId)
			if currentSkin ~= skinId then
				return false, CoupleFailReason.SkinLocked
			end
		end
	end

	if characterStage ~= nil then
		local currentStage = GameData.GetCharacterCurrentStage(characterId)
		if currentStage < characterStage then
			return false, CoupleFailReason.StageLocked
		end
	end

	if characterLevel ~= nil then
		local currentLevel = GameData.GetCharacterLevel(characterId)
		if currentLevel < characterLevel then
			return false, CoupleFailReason.LevelLocked
		end
	end

	return true
end
-------------------------------------------------
function ConfigUtils.CalculateCharacterUnlock(galleryId)
	local progress = 0
	local characters = this.GetCharactersOfGallery(galleryId)
	local totalNum = #characters
	local unlockNum = 0
	for idx = 1, totalNum do
		local characterId = characters[idx]
		if GameData.IsCharacterUnlocked(characterId) then
			unlockNum = unlockNum + 1
		end
	end

	if totalNum > 0 then
		progress = unlockNum / totalNum
	end

	return progress, unlockNum, totalNum
end

function ConfigUtils.CalculateGoodsUnlock(galleryId)
	local progress = 0
	local goods = this.GetGalleryGoodsOfGallery(galleryId)
	local totalNum = #goods
	local unlockNum = 0
	for idx = 1, totalNum do
		local goodsId = goods[idx]
		if GameData.IsGoodsUnlocked(goodsId) then
			unlockNum = unlockNum + 1
		end
	end

	if totalNum > 0 then
		progress = unlockNum / totalNum
	end

	return progress, unlockNum, totalNum
end

function ConfigUtils.CalculateEquipmentUnlock(galleryId)
	local progress = 0
	local totalNum = 0
	local unlockNum = 0

	local characters = this.GetCharactersOfGallery(galleryId)
	for idx = 1, #characters do
		local equipmentList = ConfigUtils.GetCharacterEquipmentList(characters[idx])
		totalNum = totalNum + #equipmentList
		for equipIdx = 1, #equipmentList do
			local equipmentId = equipmentList[equipIdx]
			if GameData.IsEquipmentUnlocked(equipmentId) then
				unlockNum = unlockNum + 1
			end
		end
	end

	if totalNum > 0 then
		progress = unlockNum / totalNum
	end

	return progress, unlockNum, totalNum
end

function ConfigUtils.CalculateSkinUnlock(galleryId)
	local progress = 0
	local totalNum = 0
	local unlockNum = 0

	local characters = this.GetCharactersOfGallery(galleryId)
	for idx = 1, #characters do
		local skinList = ConfigUtils.GetCharacterSkinList(characters[idx])
		totalNum = totalNum + #skinList
		for skinIdx = 1, #skinList do
			local skinId = skinList[skinIdx]
			if GameData.IsSkinUnlocked(skinId) then
				unlockNum = unlockNum + 1
			end
		end
	end

	if totalNum > 0 then
		progress = unlockNum / totalNum
	end

	return progress, unlockNum, totalNum
end

function ConfigUtils.CalculatePetsUnlock(galleryId)
	local progress = 0
	local pets = this.GetPetsOfGallery(galleryId)
	local totalNum = #pets
	local unlockNum = 0
	for idx = 1, totalNum do
		local petsId = pets[idx]
		if GameData.IsPetUnlocked(petsId) then
			unlockNum = unlockNum + 1
		end
	end

	if totalNum > 0 then
		progress = unlockNum / totalNum
	end

	return progress, unlockNum, totalNum
end

function ConfigUtils.CalculatePostcardUnlock(galleryId)
	local progress = 0
	local cards = this.GetPostcardList(galleryId)
	local totalNum = #cards
	-- 仅用于显示;成就明信片直接显示，活动明信片只有在拥有的情况下才显示
	local onlyShowNum = 0
	local unlockNum = 0
	for idx = 1, totalNum do
		local cardId = cards[idx]
		local type = ConfigUtils.GetPostcardType(cardId)
		if type == EnumPostcardType.Achievement then
			onlyShowNum = onlyShowNum + 1
			local goalId = ConfigUtils.GetGoalOfPostcard(cardId)
			local unlocked = GameData.IsGoalFinished(goalId)
			if unlocked then
				unlockNum = unlockNum + 1
			end
		elseif type == EnumPostcardType.Activity then
			local unlocked = GameData.IsUnlockPoscard(cardId)
			if unlocked then
				unlockNum = unlockNum + 1
				onlyShowNum = onlyShowNum + 1
			end
		end

	end

	if onlyShowNum > 0 then
		progress = unlockNum / onlyShowNum
	end

	return progress, unlockNum, onlyShowNum
end

function ConfigUtils.CalculateEventUnlock(galleryId)
	local progress = 0
	local events = this.GetEventList(galleryId)
	local totalNum = #events
	local unlockNum = 0
	for idx = 1, totalNum do
		local eventId = events[idx]
		if GameData.IsEventUnlocked(eventId) then
			unlockNum = unlockNum + 1
		end
	end

	if totalNum > 0 then
		progress = unlockNum / totalNum
	end

	return progress, unlockNum, totalNum
end

function ConfigUtils.CalculateRoomPieceUnlock(galleryId)
	local progress = 0
	local roomPieces = this.GetRoomPiecesOfGallery(galleryId)
	local totalNum = #roomPieces
	local unlockNum = 0
	for idx = 1, totalNum do
		local roomPieceId = roomPieces[idx]
		if GameData.IsRoomPieceUnlocked(roomPieceId) then
			unlockNum = unlockNum + 1
		end
	end

	if totalNum > 0 then
		progress = unlockNum / totalNum
	end

	return progress, unlockNum, totalNum
end

function ConfigUtils.CalculateCoupleUnlock(galleryId)
	local progress = 0
	local couples = this.GetCouplesOfGallery(galleryId)
	local totalNum = #couples
	local unlockNum = 0
	for idx = 1, totalNum do
		local coupleId = couples[idx]
		if this.IsCoupleUnlocked(coupleId) then
			unlockNum = unlockNum + 1
		end
	end

	if totalNum > 0 then
		progress = unlockNum / totalNum
	end

	return progress, unlockNum, totalNum
end

function ConfigUtils.CalculateGalleryUnlock(galleryId)
	local characterCollection, _, characterTotalNum = this.CalculateCharacterUnlock(galleryId)
	local skinCollection, _, skinTotalNum = this.CalculateSkinUnlock(galleryId)
	local equipCollection, _, equipTotalNum = this.CalculateEquipmentUnlock(galleryId)
	local goodsCollection, _, goodsTotalNum = this.CalculateGoodsUnlock(galleryId)

	local postcardCollection, _, cardTotalNum = ConfigUtils.CalculatePostcardUnlock(galleryId)
	local eventCollection, _, eventTotalNum = ConfigUtils.CalculateEventUnlock(galleryId)
	local petCollection, _, petTotalNum = this.CalculatePetsUnlock(galleryId)
	local roomPieceCollection, _, roomPieceTotalNum = this.CalculateRoomPieceUnlock(galleryId)
	local coupleCollection, _, coupleTotalNum = this.CalculateCoupleUnlock(galleryId)

	local totalWeight = 0
	if characterTotalNum > 0 then totalWeight = totalWeight + CollectionWeight.Character end
	if skinTotalNum > 0 then totalWeight = totalWeight + CollectionWeight.Skin end
	if equipTotalNum > 0 then totalWeight = totalWeight + CollectionWeight.Equipment end
	if goodsTotalNum > 0 then totalWeight = totalWeight + CollectionWeight.Goods end
	if cardTotalNum > 0 then totalWeight = totalWeight + CollectionWeight.Postcard end
	if eventTotalNum > 0 then totalWeight = totalWeight + CollectionWeight.Event end
	if petTotalNum > 0 then totalWeight = totalWeight + CollectionWeight.Pet end
	if roomPieceTotalNum > 0 then totalWeight = totalWeight + CollectionWeight.RoomPiece end
	if coupleTotalNum > 0 then totalWeight = totalWeight + CollectionWeight.Couple end

	local totalCollection = 0
	totalCollection = totalCollection + characterCollection * CollectionWeight.Character / totalWeight
	totalCollection = totalCollection + skinCollection * CollectionWeight.Skin / totalWeight
	totalCollection = totalCollection + equipCollection * CollectionWeight.Equipment / totalWeight
	totalCollection = totalCollection + goodsCollection * CollectionWeight.Goods / totalWeight
	totalCollection = totalCollection + postcardCollection * CollectionWeight.Postcard / totalWeight
	totalCollection = totalCollection + eventCollection * CollectionWeight.Event / totalWeight
	totalCollection = totalCollection + petCollection * CollectionWeight.Pet / totalWeight
	totalCollection = totalCollection + roomPieceCollection * CollectionWeight.RoomPiece / totalWeight
	totalCollection = totalCollection + coupleCollection * CollectionWeight.Couple / totalWeight

	return totalCollection
end
-----------------------------------------------------------------------------
function ConfigUtils.GetPowerOfAbilityMap(abilityMap)
	local ret = 0

	for k, v in pairs(abilityMap) do
		ret = ret + ConfigUtils.GetAbilityPowerFactor(k) * v
	end

	return ret
end

function ConfigUtils.GetPowerOfCharacters(charactersAbilityMap)
	local ret = 0
	for k, abilityMap in pairs(charactersAbilityMap) do
		ret = ret + this.GetPowerOfAbilityMap(abilityMap)
	end

	return ret
end
-----------------------------------------------------------------------------
function ConfigUtils.IsItemMatchTagList(itemId, tagList)
	local tagMap = ConfigUtils.GetItemTagMap(itemId)
	for idx = 1, #tagList do
		local tagId = tagList[idx]
		if tagMap[tagId] == nil then
			return false
		end
	end

	return true
end
-----------------------------------------------------------------------------
function ConfigUtils.CheckNeedTagAnd(needTagList, tagMap)
	needTagList = needTagList or {}
	for idx = 1, #needTagList do
		local tagId = needTagList[idx]
		if tagMap[tagId] == nil then
			return false
		end
	end

	return true
end

function ConfigUtils.CheckNeedTagOr(needTagList, tagMap)
	needTagList = needTagList or {}

	-- empty tag list, always true
	if #needTagList == 0 then
		return true
	end

	for idx = 1, #needTagList do
		local tagId = needTagList[idx]
		if tagMap[tagId] ~= nil then
			return true
		end
	end

	return false
end

function ConfigUtils.CheckBanTagAnd(banTagList, tagMap)
	banTagList = banTagList or {}

	-- empty tag list, always true
	if #banTagList == 0 then
		return true
	end

	for idx = 1, #banTagList do
		local tagId = banTagList[idx]
		if tagMap[tagId] == nil then
			return true
		end
	end

	return false
end

function ConfigUtils.CheckBanTagOr(banTagList, tagMap)
	banTagList = banTagList or {}

	for idx = 1, #banTagList do
		local tagId = banTagList[idx]
		if tagMap[tagId] ~= nil then
			return false
		end
	end

	return true
end

function ConfigUtils.CheckCharacterIdOr(needCharacterList, characterId)
	needCharacterList = needCharacterList or {}
	return Helper.TableContains(needCharacterList, characterId)
end

function ConfigUtils.GetSkinMapOfCharacters(characterList)
	local ret = {}

	for idx = 1, #characterList do
		local characterId = characterList[idx]
		local skinId = GameData.GetCharacterSkin(characterId)
		if ConfigUtils.IsValidItem(skinId) then
			ret[skinId] = 1
		end
	end

	return ret
end

function ConfigUtils.IsCharacterMatchExploreRules(exploreRules, characterId)
	-- no rules
	exploreRules = exploreRules or {}
	if #exploreRules == 0 then
		return true
	end

	local characterTagMap = ConfigUtils.GetItemTagMap(characterId)

	for idx = 1, #exploreRules do
		local ruleType = exploreRules[idx].Condition
		local ruleValues = exploreRules[idx].Value

		local match = true
		if ruleType == ExploreRuleType.NeedTagAnd then
			match = this.CheckNeedTagAnd(ruleValues, characterTagMap)
		elseif ruleType == ExploreRuleType.NeedTagOr then
			match = this.CheckNeedTagOr(ruleValues, characterTagMap)
		elseif ruleType == ExploreRuleType.BanTagAnd then
			match = this.CheckBanTagAnd(ruleValues, characterTagMap)
		elseif ruleType == ExploreRuleType.BanTagOr then
			match = this.CheckBanTagOr(ruleValues, characterTagMap)
		elseif ruleType == ExploreRuleType.NeedCharacterLevel then
			local thisLevel = GameData.GetCharacterLevel(characterId)
			local needLevel = ruleValues[1]
			match = (thisLevel >= needLevel)
		elseif ruleType == ExploreRuleType.NeedCharacterIdOr then
			match = this.CheckCharacterIdOr(ruleValues, characterId)
		end

		if not match then
			return false
		end
	end

	return true
end

function ConfigUtils.GetNeedCharacterMap(exploreRules)
	local ret = {}

	for idx = 1, #exploreRules do
		local ruleType = exploreRules[idx].Condition

		if ruleType == ExploreRuleType.NeedCharacterIdOr or 
			ruleType == ExploreRuleType.TeamCharacterIdOr or 
			ruleType == ExploreRuleType.TeamCharacterIdAnd then
			
			local ruleValues = exploreRules[idx].Value
			for k, v in pairs(ruleValues) do
				ret[v] = 1
			end
		end
	end

	return ret
end

function ConfigUtils.CheckTeamExploreRules(exploreRules, characterList, fightPower)
	-- no rules
	exploreRules = exploreRules or {}
	if #exploreRules == 0 then
		return true
	end

	for idx = 1, #exploreRules do
		local rule = exploreRules[idx]
		local match = this.CheckOneExploreRule(rule, characterList, fightPower)
		if not match then
			local hintText = UIHelper.GetExploreRuleShowText(rule, true)
			return false, hintText
		end
	end

	return true
end

function ConfigUtils.CheckOneExploreRule(rule, characterList, fightPower)
	local characterNum = #characterList
	local ruleType = rule.Condition

	local needValues = rule.Value or {}
	if ruleType == ExploreRuleType.TeamFightPower then
		-- always have one value
		if fightPower < needValues[1] then
			return false
		end
	elseif ruleType == ExploreRuleType.TeamerCount then
		if not Helper.TableContains(needValues, characterNum) then
			return false
		end
	elseif ruleType == ExploreRuleType.TeamLeaderLevel then
		local needLevel = needValues[1]
		local thisMatch = false
		for idx = 1, #characterList do
			local characterId = characterList[idx]
			local characterLevel = GameData.GetCharacterLevel(characterId)
			if characterLevel >= needLevel then
				thisMatch = true
				break
			end
		end

		return thisMatch
	elseif ruleType == ExploreRuleType.TeamCharacterIdOr then
		local thisMatch = false
		for idx = 1, #needValues do
			local needCharacterId = needValues[idx]
			if Helper.TableContains(characterList, needCharacterId) then
				thisMatch = true
				break
			end
		end

		return thisMatch
	elseif ruleType == ExploreRuleType.TeamCharacterIdAnd then
		local thisMatch = (#characterList > 0)
		for idx = 1, #needValues do
			local needCharacterId = needValues[idx]
			if not Helper.TableContains(characterList, needCharacterId) then
				thisMatch = false
				break
			end
		end

		return thisMatch
	elseif ruleType == ExploreRuleType.TeamCharacterSkinOr then
		local skinMap = this.GetSkinMapOfCharacters(characterList)
		local thisMatch = false
		for idx = 1, #needValues do
			local needSkinId = needValues[idx]
			if skinMap[needSkinId] ~= nil then
				thisMatch = true
				break
			end
		end

		return thisMatch
	elseif ruleType == ExploreRuleType.TeamCharacterSkinAnd then
		local skinMap = this.GetSkinMapOfCharacters(characterList)
		local thisMatch = (#characterList > 0)
		for idx = 1, #needValues do
			local needSkinId = needValues[idx]
			if skinMap[needSkinId] == nil then
				thisMatch = false
				break
			end
		end

		return thisMatch
	end

	-- the other rule type always match
	return true
end
-----------------------------------------------------------------------------
function ConfigUtils.GetAreaUnlockedEnemyList(areaId)
	local enemyList = ConfigUtils.GetAreaEnemyList(areaId)
	local endIdx = #enemyList
	for idx = 1, #enemyList do
		local needChallengeId = enemyList[idx].NeedChallenge
		if not ConfigUtils.IsValidItem(needChallengeId) or GameData.IsChallengeCompleted(needChallengeId) then
			endIdx = idx
			break
		end
	end

	local ret = {}
	local firstEnemyIndexNeedElement = nil
	local handledEnemies = {}
	for idx = endIdx, 1, -1 do
		local needChallengeId = enemyList[idx].NeedChallenge
		local unlocked = (not ConfigUtils.IsValidItem(needChallengeId) or GameData.IsChallengeCompleted(needChallengeId))
		local enemyListOfThisLevel = enemyList[idx].Enemy or {}
		for enemyIdx = 1, #enemyListOfThisLevel do
			local enemyId = enemyListOfThisLevel[enemyIdx].Value
            local enemyNeedChallenge = enemyListOfThisLevel[enemyIdx].NeedChallenge
            -- match to show
            local canShow = true
            -- enemy challenge match
            if canShow and enemyNeedChallenge ~= nil then
                canShow = GameData.IsChallengeCompleted(enemyNeedChallenge)
            end

			if canShow and handledEnemies[enemyId] == nil then
				local enemyLevel = enemyListOfThisLevel[enemyIdx].Level
				local enemyPower = enemyListOfThisLevel[enemyIdx].FightPower
                local needElementList = enemyListOfThisLevel[enemyIdx].NeedElementList or {}
                local elementMap = {}
                local elementCount = 0 
                for elementIdx = 1, #needElementList do
                    local needElementId = needElementList[elementIdx].Element
                    local needElementNum = needElementList[elementIdx].Count
                    elementMap[needElementId] = needElementNum
                    elementCount = elementCount + needElementNum
                end

				table.insert(ret, {
                    id = enemyId, 
                    level = enemyLevel, 
                    power = enemyPower, 
                    unlocked = unlocked,
                    elementMap = elementMap,
                    elementCount = elementCount,
                })
				handledEnemies[enemyId] = 1

                if unlocked and elementCount > 0 and firstEnemyIndexNeedElement == nil then
                    firstEnemyIndexNeedElement = #ret
                end
			end
		end
	end

	return ret, firstEnemyIndexNeedElement
end

function ConfigUtils.GetActivityExploreUnlockedEnemyList(exploreId)
	-- curent stage
	local currentBattleStage = GameData.GetActivityBattleStage()

	local enemyList = ConfigUtils.GetActivityExploreEnemyList(exploreId)
	local endIdx = #enemyList
	for idx = 1, #enemyList do
		local needBattleStage = enemyList[idx].NeedActivityBattle or 0
		if currentBattleStage >= needBattleStage then
			endIdx = idx
			break
		end
	end

	local ret = {}
	local handledEnemies = {}
	for idx = endIdx, 1, -1 do
		local needBattleStage = enemyList[idx].NeedActivityBattle or 0
		local unlocked = (currentBattleStage >= needBattleStage)
		local enemyListOfThisLevel = enemyList[idx].Enemy or {}
		for enemyIdx = 1, #enemyListOfThisLevel do
			local enemyId = enemyListOfThisLevel[enemyIdx].Value
            local enemyNeedBattleStage = enemyListOfThisLevel[enemyIdx].NeedActivityBattle or 0
            -- match to show
            local canShow = true
            -- enemy challenge match
            if canShow then
                canShow = (currentBattleStage >= enemyNeedBattleStage)
            end

			if canShow and handledEnemies[enemyId] == nil then
				local enemyLevel = enemyListOfThisLevel[enemyIdx].Level
				local enemyPower = enemyListOfThisLevel[enemyIdx].FightPower
                local needElementList = enemyListOfThisLevel[enemyIdx].NeedElementList or {}
                local elementMap = {}
                local elementCount = 0 
                for elementIdx = 1, #needElementList do
                    local needElementId = needElementList[elementIdx].Element
                    local needElementNum = needElementList[elementIdx].Count
                    elementMap[needElementId] = needElementNum
                    elementCount = elementCount + needElementNum
                end

				table.insert(ret, {
                    id = enemyId, 
                    level = enemyLevel, 
                    power = enemyPower, 
                    unlocked = unlocked,
                    elementMap = elementMap,
                    elementCount = elementCount,
                })
				handledEnemies[enemyId] = 1
			end
		end
	end

	return ret
end
-----------------------------------------------------------------------------
function ConfigUtils.ConstructBattleVerityData(characters, petId)
	local ret = {}

	ret.CharList = {}
	ret.PetLevel  = 0
	
	for idx = 1, #characters do
		ret.CharList[idx] = {}

		local characterId = characters[idx]
		ret.CharList[idx].Id = characterId
		ret.CharList[idx].Level = GameData.GetCharacterLevel(characterId)
		
		local characterEquipments = GameData.GetCharacterUnlockedEquipments(characterId)
		if #characterEquipments == 0 then
			ret.CharList[idx].EquipIds = nil
		else
			ret.CharList[idx].EquipIds = {}
			for m = 1, #characterEquipments do
				local equipmentId = characterEquipments[m].id
				local equipmentLevel = characterEquipments[m].level
				ret.CharList[idx].EquipIds[m] = {equipmentId, equipmentLevel}
			end
		end
	end

	if ConfigUtils.IsValidItem(petId) then
		ret.PetLevel = GameData.GetPetLevel(petId)
	end

	return ret
end
-----------------------------------------------------------------------------
function ConfigUtils.IsAllGoalFinished(goals)
	for idx = 1, #goals do
		local closed = GameData.IsGoalFinished(goals[idx])
		if not closed then
			return false
		end
	end

	return true
end

function ConfigUtils.IsRewardContainItem(rewardList, rewardItemId)
	-- any reward is ok
	if not ConfigUtils.IsValidItem(rewardItemId) then
		return true
	end

	for idx = 1, #rewardList do
		local rewardItem = rewardList[idx]
		local rewardWeight = rewardItem.Weight or 0
		if rewardWeight > 0 then
			local rewardDrops = rewardItem.Reward or {}
			for m = 1, #rewardDrops do
				local dropId = rewardDrops[m].Value
				if dropId == rewardItemId then
					return true
				end
			end
		end
	end

	return false
end

function ConfigUtils.GetDemandAvailableRewards(submitItemId)
	local ret = {}
	local itemMap = {}

	for k, v in pairs(DemandConfig) do
		local priority = v.Priority or 0
		local active = v.Active or false
		local preGoals = v.PreGoal or {}
		local isSubmitMatch = not ConfigUtils.IsValidItem(submitItemId) or (submitItemId == v.Value)
		if isSubmitMatch and priority > 0 and active and ConfigUtils.IsAllGoalFinished(preGoals) then
			local rewardList = v.RewardList or {}
			for idx = 1, #rewardList do
				local rewardItem = rewardList[idx]
				local rewardWeight = rewardItem.Weight or 0
				if rewardWeight > 0 then
					local rewardDrops = rewardItem.Reward or {}
					for m = 1, #rewardDrops do
						local dropId = rewardDrops[m].Value
						if itemMap[dropId] == nil then
							table.insert(ret, dropId)
							itemMap[dropId] = 1
						end
					end
				end
			end
		end
	end

	return ret
end

function ConfigUtils.GetDemandAvailableSubmits(rewardItemId)
	local ret = {}
	local itemMap = {}

	for k, v in pairs(DemandConfig) do
		local priority = v.Priority or 0
		local active = v.Active or false
		local preGoals = v.PreGoal or {}
		local rewardList = v.RewardList or {}
		if priority > 0 and active and 
		   ConfigUtils.IsAllGoalFinished(preGoals) and 
		   ConfigUtils.IsRewardContainItem(rewardList, rewardItemId) then
		   	local submitItemId = v.Value
			if itemMap[submitItemId] == nil then
				table.insert(ret, submitItemId)
				itemMap[submitItemId] = 1
			end
		end
	end

	return ret
end
-----------------------------------------------------------------------------