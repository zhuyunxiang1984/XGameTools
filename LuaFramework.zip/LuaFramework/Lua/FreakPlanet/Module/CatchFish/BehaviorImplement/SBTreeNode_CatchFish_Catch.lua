--捞鱼动画
SBTreeNode_CatchFish_Catch = class("SBTreeNode_CatchFish_Catch", SBTree_Node)
function SBTreeNode_CatchFish_Catch:initialize(netObj, srcPos, dstPos, duration)
    self.NetObj = netObj
    self.NetObjTrans = netObj.transform
    self.NetObjSkeleton = netObj:GetComponent("skeleton")
    self.SrcPos = srcPos
    self.DstPos = dstPos
    self.Duration = duration
end
function SBTreeNode_CatchFish_Catch:EnterImpl()
    self.TimeCounter = 0
end
function SBTreeNode_CatchFish_Catch:ExitImpl()

end
function SBTreeNode_CatchFish_Catch:TickImpl(deltaTime)
    self.TimeCounter = self.TimeCounter + deltaTime
    self.NetObjTrans.localPosition = Vector3.Lerp(self.SrcPos, self.DstPos, math.Clamp01(self.TimeCounter / self.Duration))

    return self.TimeCounter >= self.Duration and EnumSBTreeNodeExecuteResult.Success or EnumSBTreeNodeExecuteResult.Process
end