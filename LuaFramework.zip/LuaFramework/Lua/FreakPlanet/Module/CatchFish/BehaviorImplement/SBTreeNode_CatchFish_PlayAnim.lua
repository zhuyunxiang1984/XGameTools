--捞鱼动画
SBTreeNode_CatchFish_PlayAnim = class("SBTreeNode_CatchFish_PlayAnim", SBTree_Node)
function SBTreeNode_CatchFish_PlayAnim:initialize(skeleton, animName, animLoop, animTime)
    self.Skeleton = skeleton
    self.AnimName = animName
    self.AnimLoop = animLoop or false
    self.AnimTime = animTime or 0

end
function SBTreeNode_CatchFish_PlayAnim:EnterImpl()
    self.TimeCounter = 0
    Helper.PlayAnimation(self.Skeleton, self.AnimName, self.AnimLoop)
end
function SBTreeNode_CatchFish_PlayAnim:ExitImpl()

end
function SBTreeNode_CatchFish_PlayAnim:TickImpl(deltaTime)
    if self.AnimTime > 0 then
        self.TimeCounter = self.TimeCounter + deltaTime
        return self.TimeCounter >= self.AnimTime and EnumSBTreeNodeExecuteResult.Success or EnumSBTreeNodeExecuteResult.Process
    end
    if Helper.IsAnimationEnd(self.Skeleton, self.AnimName) then
        return EnumSBTreeNodeExecuteResult.Success
    end
    return EnumSBTreeNodeExecuteResult.Process
end