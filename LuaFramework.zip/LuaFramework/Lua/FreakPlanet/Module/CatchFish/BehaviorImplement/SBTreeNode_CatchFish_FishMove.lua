--鱼儿游动
SBTreeNode_CatchFish_FishMove = class("SBTreeNode_CatchFish_FishMove", SBTree_Node)
function SBTreeNode_CatchFish_FishMove:initialize(fishView, dstPos, duration)
    self.class.super.initialize(self)
    self.FishView = fishView

    self.DstPos = dstPos
    self.Duration = duration or 1

end
function SBTreeNode_CatchFish_FishMove:EnterImpl()
    local trans = self.FishView.Trans
    self.TimeCounter = 0
    self.SrcPos = trans.localPosition
    Helper.PlayAnimation(self.FishView.Skeleton, "Move", true)
    local dir = self.DstPos - self.SrcPos
    dir.z = 0
    trans.right = dir
end
function SBTreeNode_CatchFish_FishMove:ExitImpl()
    Helper.PlayAnimation(self.FishView.Skeleton, "Idle", true)
    local trans = self.FishView.Trans
    trans.right = Vector3.right
end
function SBTreeNode_CatchFish_FishMove:TickImpl(deltaTime)
    self.TimeCounter = self.TimeCounter + deltaTime

    local trans = self.FishView.Trans
    local position = Vector3.Lerp(self.SrcPos, self.DstPos, math.Clamp01(self.TimeCounter / self.Duration))
    position.z = trans.localPosition.z
    trans.localPosition = position
    --XDebug.Log('GGYY', trans.localPosition.x, trans.localPosition.y)
    return self.TimeCounter >= self.Duration and EnumSBTreeNodeExecuteResult.Success or EnumSBTreeNodeExecuteResult.Process
end