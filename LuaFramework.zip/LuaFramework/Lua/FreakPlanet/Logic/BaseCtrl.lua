local class = require "FreakPlanet/Utils/middleclass"

BaseCtrl  = class("BaseCtrl")

local TOOLTIP_DELAY = 0.2
local CAMERA_OFFSET = 100

-- constructor
function BaseCtrl:initialize(parameter, depth, async)
	self._parameter = parameter or {}
	self._gameObject = nil
	self._depth = depth
	if  async == false then
		self._async = false
	else
		self._async = true
	end

	self._dynamicBundles = {}
	--
	self._LayoutObjs = {}
	self._SubAppLayoutObjs = {}
    
    
    --手势操作相关
    self.m_bPress = false
    self.m_objPressGo = nil
    self.m_v3PressPos = Vector3.zero
    self.m_bDrag = false

	-- start load panel
	--mark for ggyy aa
	self._assetLoader = AssetLoader:new()

	-- panel in stack
	self._requestSuccess = false
	if self._depth ~= nil then
		self._requestSuccess = CtrlManager.RequestLoad()
	end

	--加载界面资源
	self:LoadPanel()
end

function BaseCtrl:IsLoaded()
	return self._gameObject ~= nil
end

-- destructor 
function BaseCtrl:OnDestroy()
	if self._gameObject ~= nil then
		
		if self._createTime ~= nil then
			local destroyTime = os.time()
			local userId = -1
			local safeUserId = GameData.GetSafeDefaultAccountUserId()
			if safeUserId ~= nil then
				userId = safeUserId
			end
			ChannelHelper.ReportToBokeAd(BokeAdEventType.PanelEvent, {
				uid = userId,
				panel = self.class.name, 
				create = self._createTime, 
				destroy = destroyTime,
			})
		end

		for i,v in ipairs(self._LayoutObjs) do
			v:Hide()
		end

		for i, v in ipairs(self._SubAppLayoutObjs)do
			v:Hide()
		end
		--for idx = 1, #
		self:DestroyImpl()
		self:ReleaseDynamicBundles()
		destroy(self._gameObject)
		self._gameObject = nil
	end
end

-- destroy implementation
function BaseCtrl:DestroyImpl()
	-- override
end

-- return the panel name
function BaseCtrl:CtrlName()
	return self.class.name
end

-- base module name, actually the asset bundle name
function BaseCtrl:GetBaseModuleName()
	return CtrlManager.GetModuleOfCtrl(self)
end

function BaseCtrl:IsBaseCtrl()
	local base, me = CtrlManager.GetModuleOfCtrl(self)
	return base and base == me
end

-- load the ui prefab
function BaseCtrl:LoadPanel()

end

function BaseCtrl:CreatePanel(panelName)
	panelName = panelName .. "Panel"
	if self._async then
		self:LoadAssetAsync(panelName, function(prefab)
			self:OnLoadedPanel(panelName, prefab)
		end)
	else
		local prefab = self:LoadAsset(panelName)
		self:OnLoadedPanel(panelName, prefab)
	end
end

function BaseCtrl:OnLoadedPanel(panelName, prefab)
	local panelObj = GameObject.Instantiate(prefab);
	panelObj.name = panelName
	panelObj.layer = 0
	panelObj.transform.localScale = Vector3.New(1, 1, 1)
	panelObj.transform.localPosition = Vector3.zero

	local uiRoot = panelObj:GetComponent("UIRoot")
	if uiRoot then
		uiRoot.fitWidth = Global.fitWidth
		uiRoot.fitHeight = Global.fitHeight
		uiRoot:UpdateScale()
	end
	--local type = typeof("LuaBehaviour")
	panelObj:AddComponent(typeof(LuaFramework.LuaBehaviour))

	self:OnCreate(panelObj)
end

-- after ui prefab is loaded
function BaseCtrl:OnCreate(obj)
	self._createTime = os.time()

	self._LayoutObjs = {}
	self._SubAppLayoutObjs = {}

    --
    local pCameraNode = obj.transform:Find("Camera")
    self.m_pCamera = pCameraNode:GetComponent("Camera")
    self.m_pUICamera = pCameraNode:GetComponent("UICamera")

	self:ConstructUI(obj)
	self:PreSetupUI(obj)
	--检测触发引导
	TutorialManager.TriggerTutorialByCheckTime(TutorialManager.EnumTriggerCheckTime.OpenPanel)
    self:CallRegisterUIEvent()
	self:SetupUI()

	-- panel in stack
	if self._requestSuccess then
		CtrlManager.FinishLoad(self:CtrlName())
	end
end

--
function BaseCtrl:AddLayout(layoutObj)
	table.insert(self._LayoutObjs, layoutObj)
end


function BaseCtrl:AddSubAppLayout(layoutObj)
	table.insert(self._SubAppLayoutObjs, layoutObj)
end

function BaseCtrl:RemoveSubAppLayout()
	table.remove(self._SubAppLayoutObjs)
end

function BaseCtrl:EnableSecondUpdate()
	self._IsEnableSecondUpdate = true
	self._SecondUpdateTimeCounter = 0
end

-- construct ui panel data
function BaseCtrl:ConstructUI(obj)
	
end

-- set parameters for camera
function BaseCtrl:LocateCamera()
	local uiCamera = self._ui.Camera:GetComponent("UICamera")

	if self._depth ~= nil then
		self._ui.Camera.depth = self._depth
		if uiCamera ~= nil then
			uiCamera.enabled = false
			uiCamera.enabled = true
		end
	end

	if uiCamera ~= nil then
		uiCamera.tooltipDelay = TOOLTIP_DELAY
	end
	self._ui.Camera.transform.parent.localPosition = Vector3.New(0, self._ui.Camera.depth * CAMERA_OFFSET, 0)
end

-- do something before setup ui
function BaseCtrl:PreSetupUI(obj)
	self:LocateCamera()
	self._gameObject = obj
	self._transform = obj.transform
	self._panel = self._transform:GetComponent('UIPanel')
	self._luaBehaviour = self._transform:GetComponent('LuaBehaviour')
	-- refresh positions
	PositionAdapter.RefreshAllPositions(self._transform)
end

--
function BaseCtrl:CallRegisterUIEvent()
    self:RegisterUIEvent()
    for i,v in ipairs(self._LayoutObjs) do
        v:RegisterUIEvent();
    end
end
function BaseCtrl:RegisterUIEvent()
    
end
-- fill ui with the data
function BaseCtrl:SetupUI()
	
end

-- update per frame
function BaseCtrl:Update(deltaTime)
	self._assetLoader:Tick()
	if self._ui == nil then
		return
	end
	if self._IsEnableSecondUpdate then
		self._SecondUpdateTimeCounter = self._SecondUpdateTimeCounter + deltaTime
		if self._SecondUpdateTimeCounter >= 1 then
			self._SecondUpdateTimeCounter = 0
			self:UpdateImplBySecond(deltaTime)

			for i,v in ipairs(self._LayoutObjs) do
				if v:IsShow() then
					v:UpdateImplBySeconds(deltaTime);
				end
			end

			for k,v in ipairs(self._SubAppLayoutObjs) do
				if v:IsShow() then
					v:UpdateImplBySeconds(deltaTime)
				end
			end
		end
	end
	self:UpdateImpl(deltaTime)

	for i,v in ipairs(self._LayoutObjs) do
		if v:IsShow() then
			v:UpdateImpl(deltaTime);
		end
	end

	for k,v in ipairs(self._SubAppLayoutObjs) do
		if v:IsShow() then
			v:Tick(deltaTime)
		end
	end
    --
    if self.m_bPress then
        if not self.m_bDrag then
            local offset = Input.mousePosition - self.m_v3PressPos
            if offset.magnitude > 10 then
                self.m_bDrag = true
                self.m_v3LastPos = self.m_v3PressPos
                self:CallOnDragBegin(self.m_objPressGo, Input.mousePosition, offset)
            end
        end
        if self.m_bDrag then
            local offset = Input.mousePosition - self.m_v3LastPos
            self:CallOnDrag(deltaTime, Input.mousePosition, offset)
            self.m_v3LastPos = Input.mousePosition
        end
    end
end

-- update implementation
function BaseCtrl:UpdateImpl(deltaTime)

end

-- update implementation per second
function BaseCtrl:UpdateImplBySecond(deltaTime)

end

-- notity it has been focused
function BaseCtrl:CallNotifyFocus()
	-- do nothing
	self:NotifyFocus()
	for i,v in ipairs(self._LayoutObjs) do
		if v:IsShow() then
			v:NotifyFocus()
		end
	end

	for i, v in ipairs(self._SubAppLayoutObjs) do
		if v:IsShow() then
			v:NotifyFocus()
		end
	end
end

function BaseCtrl:NotifyFocus()
	-- do nothing
end

-- notity it has been focused
function BaseCtrl:CallOnResume()
	self:OnResume()
	for i,v in ipairs(self._LayoutObjs) do
		if v:IsShow() then
			v:OnResume()
		end
	end
	for i,v in ipairs(self._SubAppLayoutObjs) do
		if v:IsShow() then
			v:OnResume()
		end
	end
end
function BaseCtrl:OnResume()
	-- do nothing
end

-- handle the escapse button
function BaseCtrl:CallHandleEscape()
	self:HandleEscape()
	for i,v in ipairs(self._LayoutObjs) do
		if v:IsShow() then
			v:HandleEscape()
		end
	end

	for i,v in ipairs(self._SubAppLayoutObjs) do
		if v:IsShow() then
			v:HandleEscape()
		end
	end
end
function BaseCtrl:HandleEscape()
	SoundSystem.PlayUICancelSound()
	CtrlManager:PopPanel()
end

-- can do jump or not
function BaseCtrl:CanJump()
	return true
end

function BaseCtrl:DoJump(jumpParameter)
	-- do nothing
end

-- convert point from screen to world
function BaseCtrl:ScreenToWorld(point)
	local p = self._ui.Camera:ScreenToWorldPoint(point)
	return p
end

-- convert point from world to screen
function BaseCtrl:WorldToScreen(point)
	local p = self._ui.Camera:WorldToScreenPoint(point)
	return p
end

-- 将世界坐标转换到UI坐标
function BaseCtrl:ScreenToUIPos(parent, point)
    point = self:ScreenToWorld(point)
    return parent:InverseTransformPoint(point)
end

--------------------------------------------------------
-- on clicked
function BaseCtrl:CallOnClicked(go)
	if not self:OnClicked(go) then
		return false
	end
	for i,v in ipairs(self._LayoutObjs) do
		if v:IsShow() then
			v:OnClicked(go)
		end
	end

	for i,v in ipairs(self._SubAppLayoutObjs) do
		if v:IsShow() then
			v:OnClicked(go)
		end
	end
	return true
end
function BaseCtrl:OnClicked(go)
	-- not handled
	return false
end

-- on pressed
function BaseCtrl:CallOnPressed(go, pressed, isLong)
	self:OnPressed(go, pressed, isLong)
	for i,v in ipairs(self._LayoutObjs) do
		if v:IsShow() then
			v:OnPressed(go, pressed, isLong)
		end
	end

	for i,v in ipairs(self._SubAppLayoutObjs) do
		if v:IsShow() then
			v:OnPressed(go, pressed, isLong)
		end
	end
    --
    if pressed then
        self.m_bPress = true
        self.m_objPressGo = go
        self.m_v3PressPos = Input.mousePosition
    else
        self.m_bPress = false
        if self.m_bDrag then
            self:CallOnDragEnd(Input.mousePosition)
            self.m_bDrag = false
        end
    end
end
function BaseCtrl:OnPressed(go, pressed, isLong)
	-- implement in child class
end
---拖动屏幕支持----------------------------------------------------------
function BaseCtrl:CallOnDragBegin(go, point, offset)
    for i,v in ipairs(self._LayoutObjs) do
        if v:IsShow() then
            v:OnDragBegin(go, point, offset)
        end
    end
    self:OnDragBegin(go, point, offset)
end
function BaseCtrl:CallOnDrag(deltaTime, point, offset)
    for i,v in ipairs(self._LayoutObjs) do
        if v:IsShow() then
            v:OnDrag(deltaTime, point, offset)
        end
    end
    self:OnDrag(deltaTime, point, offset)
end
function BaseCtrl:CallOnDragEnd(point)
    for i,v in ipairs(self._LayoutObjs) do
        if v:IsShow() then
            v:OnDragEnd(point)
        end
    end
    self:OnDragEnd(point)
end

function BaseCtrl:OnDragBegin(go, point, offset)
end
function BaseCtrl:OnDrag(deltaTime, point, offset)
end
function BaseCtrl:OnDragEnd(point)
end
--------------------------------------------------------
-- dynamic bundle
function BaseCtrl:DynamicLoadBundle(bundleName)

end

function BaseCtrl:PreloadBundle(bundleName)
	self._assetLoader:PreloadBundle(bundleName)
end

function BaseCtrl:DynamicLoadAsset(bundleName, assetName)
	return self._assetLoader:LoadAsset(assetName)
end

function BaseCtrl:DynamicLoadSprite(bundleName, assetName, spriteName)
	assetName = "pt_" .. assetName
	return self._assetLoader:LoadSprite(assetName, spriteName)
end

function BaseCtrl:LoadAsset(assetName)
	return self._assetLoader:LoadAsset(assetName)
end
function BaseCtrl:LoadSprite(assetName, spriteName)
	assetName = "pt_" .. assetName
	return self._assetLoader:LoadSprite(assetName, spriteName)
end

function BaseCtrl:ReleaseDynamicBundles()
	self._assetLoader:ReleaseAll()
end

--mark for ggyy aa
function BaseCtrl:LoadAssetAsync(prefabName, onComplete)
	self._assetLoader:LoadAssetAsync(prefabName, onComplete)
end

--------------------------------------------------------
-- tutorial
function BaseCtrl:CheckTutorial()
	return false
end

function BaseCtrl:OnTutorialClicked(tutorial)
	-- do nothing here
end
--------------------------------------------------------
function BaseCtrl:GetLuaBehaviour()
	return self._luaBehaviour
end

--关闭自己
function BaseCtrl:Close()
	CtrlManager.PopPanelByName(self:CtrlName())
end

function BaseCtrl:GetSubAppLayout()
	return self._SubAppLayoutObjs
end

--设置ngui icon
function BaseCtrl:SetIconWithAtlas(sprite, iconName, atlasName, isSnapSize)
	atlasName = "atlas_p_" .. atlasName
	local atlasObj = self:LoadAsset(atlasName):GetComponent("UIAtlas")
	if atlasObj and sprite.atlas ~= atlasObj then
		sprite.atlas = atlasObj
	end
	sprite.spriteName = iconName
	if isSnapSize then
		sprite:MakePixelPerfect()
	end
end

-------------------------------------------------------------
---设置成不可见且不可点击的,但是逻辑依然存在
function BaseCtrl:SetVisible(show)
    self.m_pCamera.enabled = show
    self.m_pUICamera.enabled = show
end

function BaseCtrl:SetTouch(go)
    CtrlManager.AddPress(self, go)
end

