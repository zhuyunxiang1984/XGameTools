require "FreakPlanet/Logic/CtrlDefine"
require "FreakPlanet/Logic/BaseCtrl"
require "FreakPlanet/Logic/BaseLayout"
require "FreakPlanet/Utils/Stack"
require "FreakPlanet/UI/Common/require"

require "FreakPlanet/SubApp/SubAppLayout"
require "FreakPlanet/SubApp/require"

CtrlManager = {}

local TAG = "UI";
local this = CtrlManager
local _ctrlFactories = {}
local _ctrlList = {}
local _uiStack = {}
local _requestCount = 0
local _ctrlModuleMap = {}

local _lockClick

local _transitionOn
local _transitionReceiver
local _screenObscuredCallback
local _screenObscuredParameter
local _transitionCompletedCallback
local _transitionCompletedParameter
local _transitionCheckCtrlName

local _topPanelName

-- init ctrl manager
function CtrlManager.Init()
    for k, name in pairs(CtrlNames) do
        require("FreakPlanet/Controller/" .. tostring(name))
    end

    _requestCount = 0
    _ctrlList = {}
    _uiStack = {}
    _lockClick = false
    _ctrlFactories = InitCtrlFactory()
    _topPanelName = nil
    _ctrlModuleMap = {}

    _transitionOn = false
    _transitionReceiver = nil
    _screenObscuredCallback = nil
    _screenObscuredParameter = nil
    _transitionCompletedCallback = nil
    _transitionCompletedParameter = nil
    _transitionCheckCtrlName = nil

    -- hide the navigation bar
    Screen.fullScreen = true

    --topPanel 打开的时间
    this.TopPanelStayTimeCounter = 0
    --是否需要检测新手引导
    this.IsCheckStayPanelTime3s = false
end

-----------------------------------------------------------------------
-- open an stackable panel
function CtrlManager.OpenPanel(ctrlName, parameter, async)
    local ctrl = _ctrlFactories[ctrlName];
    if ctrl ~= nil then
        local depth = 1
        if #_uiStack > 0 then
            depth = _uiStack[#_uiStack].depth + 1
        end

        local instance = ctrl:new(parameter, depth, async)
        _ctrlList[ctrlName] = instance
		-- start load panel
        _uiStack[#_uiStack + 1] = { panel = instance, depth = depth }
        -- set the top panel
        _topPanelName = ctrlName
        this.TopPanelStayTimeCounter = 0
        this.IsCheckStayPanelTime3s = true
    end
end

--Debug
function CtrlManager.Debug()
    if #_uiStack > 0 then
        XDebug.LogCustom(TAG, function()
            local str = '====界面stack====\n'
            for i = #_uiStack, 1, -1 do
                local panel = _uiStack[i].panel
                str = str .. string.format("[%s]%s\n", i, panel:CtrlName())
            end
            return str
        end)
    else
        XDebug.Log(TAG, "没有stack界面")
    end
end

--pop an stackable panel
function CtrlManager.PopPanel()
    assert(#_uiStack > 0, "no ctrl in the ui stack")
    this.PopPanelByName(nil)
end

--如果ctrlName为nil,则表示弹出最上层
function CtrlManager.PopPanelByName(ctrlName)
    assert(#_uiStack > 0, "no ctrl in the ui stack")
    for i = #_uiStack, 1, -1 do
        local panel = _uiStack[i].panel
        if not ctrlName or panel:CtrlName() == ctrlName then
            this._CloseStackPanel(panel:CtrlName(), i)
            return
        end
    end
end

function CtrlManager._CloseStackPanel(ctrlName, index)
    local panel = this.GetCtrlByName(ctrlName)
    if not panel then
        return
    end
    panel:OnDestroy()
    _ctrlList[ctrlName] = nil
    JumpManager.Closing(panel)
    table.remove(_uiStack, index)
    GameNotifier.Notify(GameEvent.PanelClosed, ctrlName)
end

function CtrlManager.GetTopPanel()
    if #_uiStack < 1 then
        return nil
    end
    return _uiStack[#_uiStack].panel
end

-- open an un-stackable panel
function CtrlManager.LaunchPanel(ctrlName, parameter, async)
    local ctrl = _ctrlFactories[ctrlName]
    if ctrl ~= nil then
        local instance = ctrl:new(parameter, nil, async)
        _ctrlList[ctrlName] = instance
    end
end

--close an un-stackable panel
function CtrlManager.ClosePanel(ctrlName)
    local ctrl = _ctrlList[ctrlName]
    if ctrl ~= nil then
        ctrl:OnDestroy()
        _ctrlList[ctrlName] = nil

        GameNotifier.Notify(GameEvent.PanelClosed, ctrlName)
    end
end

-- panel prefab loaded
function CtrlManager.OnPanelLoaded(ctrlName, obj)
    if _ctrlList[ctrlName] ~= nil then
        _ctrlList[ctrlName]:OnCreate(obj)
    end
end

-- update per frame
function CtrlManager.Update(deltaTime)

    if Util.IsEditor then
        if Input.GetKeyDown(UnityEngine.KeyCode.F12) then
            this.Debug()
        end
    end

    if #_uiStack > 0 then
        -- do notify focus
        local top = _uiStack[#_uiStack].panel
        if top ~= nil and top:CtrlName() ~= _topPanelName then
            top:CallNotifyFocus()
            _topPanelName = top:CtrlName()
            this.TopPanelStayTimeCounter = 0
            this.IsCheckStayPanelTime3s = true
            --检测触发引导
            TutorialManager.TriggerTutorialByCheckTime(TutorialManager.EnumTriggerCheckTime.NotifyFocus)
        end
        this.TopPanelStayTimeCounter = this.TopPanelStayTimeCounter + deltaTime
        if this.IsCheckStayPanelTime3s and this.TopPanelStayTimeCounter > 3 then
            TutorialManager.TriggerTutorialByCheckTime(TutorialManager.EnumTriggerCheckTime.StayPanelTime3s)
            this.IsCheckStayPanelTime3s = false
        end
    end

    for name, ctrl in pairs(_ctrlList) do
        ctrl:Update(deltaTime)
    end
end

-- get panel by name
function CtrlManager.GetCtrlByName(ctrlName)
    return _ctrlList[ctrlName]
end

function CtrlManager.IsCtrlOpen(ctrlName)
    return this.GetCtrlByName(ctrlName) ~= nil
end

function CtrlManager.IsTopPanel(ctrlName)
    return ctrlName ~= nil and ctrlName == _topPanelName
end

function CtrlManager.GetModuleOfCtrl(ctrl)
    local ctrlName = ctrl:CtrlName()
    if not _ctrlModuleMap[ctrlName] then
        return nil
    end
    return _ctrlModuleMap[ctrlName].base, _ctrlModuleMap[ctrlName].me
end
-----------------------------------------------------------------------
local function GetCtrlByGameObject(ctrlGameObj)
    for name, ctrl in pairs(_ctrlList) do
        if ctrl._gameObject == ctrlGameObj then
            return ctrl
        end
    end

    return nil
end

local function UnlockClick()
    _lockClick = false
end

local function LockClick()
    _lockClick = true
    GlobalScheduler:DoActionAfterTime(0.15, UnlockClick)
end

function CtrlManager.AddClick(ctrl, go)
    ctrl._luaBehaviour:AddClick(go, this.OnClicked)
end

---自带回调的Click方法
---@param ctrl table
---@param go GameObject
---@param func 回调方法
function CtrlManager.AddClickWithFunc(ctrl, go, func)
    ctrl._luaBehaviour:AddClick(go, function()
        if _lockClick or not this.AcceptInput() then
            return
        end
        LockClick()
        func(go)
    end)
end

function CtrlManager.AddPress(ctrl, go)
    ctrl._luaBehaviour:AddPress(go, this.OnPressed)
end

function CtrlManager.AcceptInput()
    if _requestCount > 0 or _transitionOn then
        return false
    end

    -- connect with server
    if not NetManager.AcceptInput() then
        return false
    end

    if not this.IsValidInput() then
        return false
    end

    return true
end

function CtrlManager.OnClicked(ctrlGameObj, go)
    if _lockClick or not this.AcceptInput() then
        return
    end

    LockClick()
    local ctrl = GetCtrlByGameObject(ctrlGameObj)
    if ctrl then
        ctrl:CallOnClicked(go)
    end
end

function CtrlManager.OnPressed(ctrlGameObj, go, pressed, isLong)
    if _lockClick or not this.AcceptInput() then
        return
    end

    local ctrl = GetCtrlByGameObject(ctrlGameObj)
    if ctrl then
        ctrl:CallOnPressed(go, pressed, isLong)
    end
end

function CtrlManager.IsValidInput()
    local mousePos = Input.mousePosition
    if mousePos.x < 0 or mousePos.x > Screen.width then
        return false
    end

    if mousePos.y < 0 or mousePos.y > Screen.height then
        return false
    end

    return true
end
-----------------------------------------------------------------------
-- escape
function CtrlManager.AcceptEscape()
    local ctrl = this.GetCtrlByName(CtrlNames.TutorialGuide)
    if ctrl ~= nil and ctrl:IsOn() then
        return false
    end

    ctrl = this.GetCtrlByName(CtrlNames.AlertBox)
    if ctrl ~= nil and ctrl:IsOn() then
        return false
    end

    ctrl = this.GetCtrlByName(CtrlNames.GoalDialog)
    if ctrl ~= nil then
        return false
    end

    if not this.AcceptInput() then
        return false
    end

    -- TODO, need check more conditions

    return true
end

function CtrlManager.OnEscapePressed()
    if _lockClick or not this.AcceptEscape() then
        return
    end

    LockClick()

    if #_uiStack > 0 then
        local topPanel = _uiStack[#_uiStack].panel
        topPanel:CallHandleEscape()
    end
end
-----------------------------------------------------------------------
function CtrlManager.ShowItemDetail(params)
    this.OpenPanel(CtrlNames.ItemDetail, params)
end

function CtrlManager.ShowGoalHint(goalId)
    local ctrl = this.GetCtrlByName(CtrlNames.Notify)
    if ctrl then
        ctrl:OnGoalConditionCompleted(goalId)
    end

    GameNotifier.Notify(GameEvent.GoalConditionCompleted, goalId)
end

function CtrlManager.ShowTutorials(tutorials)
    local ctrl = this.GetCtrlByName(CtrlNames.TutorialGuide)
    if ctrl then
        ctrl:ShowTutorials(tutorials)
    end
end

function CtrlManager.ShowAlert(msg, callback)
    local ctrl = this.GetCtrlByName(CtrlNames.AlertBox)
    if ctrl ~= nil then
        ctrl:ShowAlert(msg, callback)
    end
end

--[[
params = {
message = ""   内容
single = true    是否只有确认按钮
onConfirm = nil  确认时的回调
}

--]]
function CtrlManager.ShowMessageBox(params)
    local ctrl = this.GetCtrlByName(CtrlNames.MessageBox)
    if ctrl ~= nil then
        ctrl:Show(params)
    else
        this.OpenPanel(CtrlNames.MessageBox, params)
    end
end

function CtrlManager.CheckSpaceTravelSeasonValid(seasonId, forceQuit, muteSound)
    if GameData.IsSpaceTravelSeasonStillValid(seasonId) then
        return true
    end
    -- sound
    muteSound = muteSound or false
    if not muteSound then
        SoundSystem.PlayWarningSound()
    end
    -- message box
    forceQuit = forceQuit or false
    if forceQuit then
        CtrlManager.ShowMessageBox({ message = SAFE_LOC("太空旅行已结束"), single = true, onConfirm = this.PopToPlanet })
    else
        CtrlManager.ShowMessageBox({ message = SAFE_LOC("太空旅行已结束"), single = true })
    end
    return false
end

function CtrlManager.RequestLoad()
    _requestCount = _requestCount + 1
    return true
end

function CtrlManager.FinishLoad(ctrlName)
    if _transitionOn and not TransitionKit.isCompleted and _transitionCheckCtrlName == ctrlName then
        TransitionKit.isCompleted = true
    end

    _requestCount = _requestCount - 1
    assert(_requestCount >= 0, "request count should always be greater than 0")
end

function CtrlManager.IsLoading()
    return _requestCount > 0
end

function CtrlManager.IsTutorialGuideOn()
    local ctrl = this.GetCtrlByName(CtrlNames.TutorialGuide)
    if ctrl ~= nil and ctrl:IsOn() then
        return true
    end

    return false
end

function CtrlManager.ForceHideTutorialGuide()
    local ctrl = this.GetCtrlByName(CtrlNames.TutorialGuide)
    if ctrl ~= nil and ctrl:IsOn() then
        ctrl:ForceHide()
    end
end

function CtrlManager.DoWaitTransition(targetCtrlName, receiver, obscuredCallback, obscruredParameter, completedCallback, completedParameter)
    assert(not _transitionOn, "transition is on now")

    _transitionReceiver = receiver
    _screenObscuredCallback = obscuredCallback
    _screenObscuredParameter = obscruredParameter
    _transitionCompletedCallback = completedCallback
    _transitionCompletedParameter = completedParameter
    _transitionOn = true
    _transitionCheckCtrlName = targetCtrlName

    local wind = WindTransition.New()
    wind.reverse = Helper.RandBool()
    TransitionKit.isCompleted = false
    TransitionKit.instance:transitionWithDelegate(wind, this.OnScreenObscured, this.OnTransitionCompleteCallback)

    --local fader = FadeTransition.New()
    --TransitionKit.instance:transitionWithDelegate(fader, this.OnScreenObscured, this.OnTransitionCompleteCallback)
end

function CtrlManager.OnScreenObscured()
    if _screenObscuredCallback ~= nil then
        if _transitionReceiver ~= nil then
            if _screenObscuredParameter ~= nil then
                _screenObscuredCallback(_transitionReceiver, _screenObscuredParameter)
            else
                _screenObscuredCallback(_transitionReceiver)
            end
        else
            if _screenObscuredParameter ~= nil then
                _screenObscuredCallback(_screenObscuredParameter)
            else
                _screenObscuredCallback()
            end
        end
    end
end

function CtrlManager.OnTransitionCompleteCallback()
    _transitionOn = false
    _transitionCheckCtrlName = nil
    if _transitionCompletedCallback ~= nil then
        if _transitionReceiver ~= nil then
            if _transitionCompletedParameter ~= nil then
                _transitionCompletedCallback(_transitionReceiver, _transitionCompletedParameter)
            else
                _transitionCompletedCallback(_transitionReceiver)
            end
        else
            if _transitionCompletedParameter ~= nil then
                _transitionCompletedCallback(_transitionCompletedParameter)
            else
                _transitionCompletedCallback()
            end
        end
    end
end
-----------------------------------------------------------------------
function CtrlManager.CanJump()
    for idx = #_uiStack, 1, -1 do
        local panel = _uiStack[idx].panel
        if not panel:CanJump() then
            return false
        end
    end

    if not this.AcceptInput() then
        return false
    end

    return true
end

function CtrlManager.PopToPlanet()
    this.PopToPanel(CtrlNames.Planet)
end

function CtrlManager.PopToPanel(ctrlName)
    if _ctrlList[ctrlName] == nil then
        assert(false, "ctrl name not exist in the stack: " .. tostring(ctrlName))
        return
    end

    -- pop to planet panel
    local count = #_uiStack
    while count > 0 do
        local top = _uiStack[count].panel
        if top:CtrlName() == ctrlName then
            break
        else
            this.PopPanel()
        end

        count = #_uiStack
    end

    assert(#_uiStack >= 1, "at least should have one panel left")
end

function CtrlManager.PanelDepth()
    return #_uiStack
end

function CtrlManager.OnResume()
    if #_uiStack > 0 then
        local top = _uiStack[#_uiStack].panel
        top:CallOnResume()
    end
end
------------------------------------
function CtrlManager.SetVisible(ctrlName, flag)
    local ctrl = _ctrlList[ctrlName]
    if not ctrl then
        return
    end
    ctrl:SetVisible(flag)
end