DynamicBundleManager = {}

local this = DynamicBundleManager

local _requestedBundles = nil

function DynamicBundleManager.Init()
	_requestedBundles = {}
end

function DynamicBundleManager.RequestBundle(bundleName)
	--[[ mark for ggyy 更新AA
	local preNum = _requestedBundles[bundleName] or 0
	if preNum == 0 then
		log("load bundle: "..tostring(bundleName))
		resMgr:LoadBundle(bundleName)
	end

	_requestedBundles[bundleName] = preNum + 1
	--]]
end

function DynamicBundleManager.UnrequestBundle(bundleName)
	--[[ mark for ggyy 更新AA
	local preNum = _requestedBundles[bundleName] or 0
	assert(preNum > 0, "bundle hasn't been requested: "..tostring(bundleName))
	_requestedBundles[bundleName] = preNum - 1
	if _requestedBundles[bundleName] == 0 then
		log("un-load bundle: "..tostring(bundleName))
		resMgr:UnloadBundle(bundleName, true)
	end
	--]]
end