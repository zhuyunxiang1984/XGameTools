class = require "FreakPlanet/Utils/middleclass"
require "FreakPlanet/Common/define"
require "FreakPlanet/Common/functions"
require "FreakPlanet/Module/Common/require"
require "FreakPlanet/Utils/Helper"
require "FreakPlanet/Utils/UIHelper"
require "FreakPlanet/Utils/Scheduler"
require "FreakPlanet/Version"

require "FreakPlanet/DesignConfig"
require "FreakPlanet/DesignConfigUtils"
require "FreakPlanet/Sound/SoundSystem"
require "FreakPlanet/LocalizationSystem"
require "FreakPlanet/GameData/GameData"
require "FreakPlanet/GameNotifier"
require "FreakPlanet/CharacterSelector"
require "FreakPlanet/JumpManager"
require "FreakPlanet/GameLocalNotification"

require "FreakPlanet/Logic/CtrlManager"
require "FreakPlanet/Logic/DynamicBundleManager"
require "FreakPlanet/SimulationState"

require "FreakPlanet/Network/NetManager"
require "FreakPlanet/Network/ProtocolManager"
require "FreakPlanet/IAP/IAPManager"
require "FreakPlanet/NodeHelper"
require "FreakPlanet/ChannelHelper"
require "FreakPlanet/Tutorial/require"

-- short name
DBM = DynamicBundleManager

--管理器--
Game = {};
local this = Game;

local _canUpdate = false
local _isNewAccount = false
local _accountLogined = false

--未成年玩家检测间隔
local _CheckUnderAge = false
local _IsUnderAgeDialogExist = false
local _CheckUnderAgeAvailableInterval = 30
local _CheckUnderAgeAvailableIntervalCounter = 0

GlobalScheduler = nil

function Game.OnInitOK()
    _canUpdate = true
    _isNewAccount = false
    _accountLogined = false
    _CheckUnderAge = false
    _IsUnderAgeDialogExist = false
    GlobalScheduler = ActionScheduler:new()

    -- pre-load bundle files
    --resMgr:PreloadBundle(Const.CommonBundleName)
    --resMgr:PreloadBundle(Const.SoundBundleName)
    --resMgr:PreloadBundle(Const.PlanetsBundleName)
    --resMgr:PreloadBundle(Const.ArenaStreetBundleName)
    --resMgr:PreloadBundle(Const.HideSeekBundleName)
    --[[


    for k, v in pairs(Const) do
        if Helper.StartWith(v, "atlas_") then
            resMgr:PreloadBundle(v)
        end
    end
    --]]

    ---常驻内存资源---------------------------------------
    resMgr:LoadBundle("shader")
    ---通用ui元素
    resMgr:LoadBundle("atlas_p_uigeneral")
    resMgr:LoadBundle("atlas_p_uigeneral2")
    ---预载角色头像
    resMgr:LoadBundle("atlas_p_fat")
    resMgr:LoadBundle("atlas_p_mus")
    resMgr:LoadBundle("atlas_p_rpg")
    resMgr:LoadBundle("atlas_p_sea")
    resMgr:LoadBundle("atlas_p_sp")
    resMgr:LoadBundle("atlas_p_sus")
    resMgr:LoadBundle("atlas_p_activitycharactericon")
    resMgr:LoadBundle("atlas_p_equipment")

    --mark for ggyy
    WordFilterHelper.RequestWordFilter();

    --register ui
    CtrlManager.Init()

    -- local game data
    local success = GameData.Load()
    if not success then
        GameData.Init()
        GameData.Save()
    else
        GameData.VersionUpdate()
    end

    Game.SetAutoLock()
    LocalizationManager.Init()
    DynamicBundleManager.Init()
    GameNotifier.Init()
    SoundSystem.Init()
    SoundSystem.PlayAccountMusic()
    JumpManager.Init()
    NetManager.Init()
    GameLocalNotification.Init()
    ChannelHelper.Init()

    SAFE_LOC = LocalizationManager.CheckGet
    LANGUAGE = LocalizationManager.Get

    -- set rand seed at start
    Helper.RandSeed()

    TutorialManager.Init()

    -- persistent panels
    CtrlManager.LaunchPanel(CtrlNames.NetworkLoading)           -- depth = 70
    -- account panel
    CtrlManager.OpenPanel(CtrlNames.Account)


end

function Game.SetAutoLock()
    if GameData.IsAutoLockOn() then
        Screen.sleepTimeout = -2 --按照系统设置的时间锁屏
    else
        Screen.sleepTimeout = -1 --永不锁屏
    end
end

function Game.MarkNewAccount()
    _isNewAccount = true
end

function Game.HasAccount()
    return _accountLogined
end

function Game.OnAccountLogined()
    -- persistent panels
    CtrlManager.LaunchPanel(CtrlNames.Navigation, nil, false)              -- depth = 50
    CtrlManager.LaunchPanel(CtrlNames.Notify, nil, false)                  -- depth = 60
    CtrlManager.LaunchPanel(CtrlNames.TutorialGuide, nil, false)           -- depth = 55
    CtrlManager.LaunchPanel(CtrlNames.AlertBox, nil, false)                -- depth = 65

    _accountLogined = true
    -- switch music
    SoundSystem.PlayMusic()
    -- need account
    IAPManager.Init()
    -- node helper
    NodeHelper.Init()
    -- channel helper
    ChannelHelper.UploadRoleToSdk()
    
    if _isNewAccount then
        if not Util.IsSkipComic then
            CtrlManager.LaunchPanel(CtrlNames.Comic, {callback = function()
                Game.OpenPlanetPanel()
            end})  -- depth = 65
        else
            Game.OpenPlanetPanel()
        end
        _isNewAccount = false
    else
        Game.OpenPlanetPanel()
    end
end

function Game.OpenPlanetPanel()
    --CtrlManager.OpenPanel(CtrlNames.Planet)
    CtrlManager.OpenPanel(CtrlNames.Home)
end

function Game.Update(deltaTime, unscaledDeltaTime)
    if not _canUpdate then
        return
    end

    NetManager.Update(deltaTime)
    IAPManager.Update(deltaTime)
    SoundSystem.Update(deltaTime)
    if GlobalScheduler ~= nil then
        GlobalScheduler:Tick(deltaTime)
    end
    TutorialManager.Tick(deltaTime)

    CtrlManager.Update(deltaTime)

    if Input.GetKeyDown(UnityEngine.KeyCode.Escape) then
        CtrlManager.OnEscapePressed()
    end

    -- 从后台切回的时候unscaledDeltaTime是真实间隔时间
    if unscaledDeltaTime < 1.0 then
        --这里PlayTime不希望受到战斗的speedup影响 所以使用 unscaledDeltaTime
        --同时也不希望因为切到后台计算现实的流逝时间 所以只有unscaledDeltaTime < 1.0 的时候才累计游玩时间
        GameData.StepPlayTime(unscaledDeltaTime)
    end
    GameData.StepServerTime(unscaledDeltaTime)

    --对于未成年玩家需要检测是否在可游玩时间段
    if _CheckUnderAge and not _IsUnderAgeDialogExist then
        _CheckUnderAgeAvailableIntervalCounter = _CheckUnderAgeAvailableIntervalCounter + deltaTime
        if _CheckUnderAgeAvailableIntervalCounter >= _CheckUnderAgeAvailableInterval then
            _CheckUnderAgeAvailableIntervalCounter = 0

            if not GameData.IsAllowUnderAgeToPlay(GameData.GetServerTime()) then
                CtrlManager.ShowMessageBox({message = "您好，根据国家相关法律法规和政策要求，当前时间段非法定节假日允许登录时间。您无法正常登录游戏，请在法定节假日规定时间内登录。", single = true, onConfirm = Game.Restart})
                _IsUnderAgeDialogExist = true
                return
            end
        end
    end
end

function Game.OnApplicationPause(paused)
    if paused then
        _canUpdate = false
        if this.HasAccount() then
            GameLocalNotification.DoSchedule()
            NetManager.SendHeart(false)
        end
    else
        GameLocalNotification.CancelAll()

        if this.HasAccount() then
            NetManager.OnResume()
            CtrlManager.OnResume()
            IAPManager.OnResume()
        end

        _canUpdate = true
    end
end

function Game.OnApplicationQuit()
    
end

function Game.OnDestroy()
	
end

function Game.Restart()
    _canUpdate = false
    ChannelHelper.ReportRestartToSdk()
    SceneManager.LoadScene("LoadingScene")
end

function Game.Quit()
    UnityEngine.Application.Quit()
end

function Game.CurrentPlatformId()
    if Global.currentPlatform == GamePlatform.APPLE then
        return 1
    else
        return 2
    end
end

function Game.CurrentGameVersion()
    local gameVersion = tostring(Global.MajorVersion).."."..tostring(Global.MinorVersion)
    return gameVersion
end

function Game.IsDistributeVersion()
    return Global.ProductMode == 3
end

function Game.GetServerType()
    if Global.ProductMode == 1 then
        -- develop
        return 1
    elseif Global.ProductMode == 2 then
        -- qa
        return 2
    end

    -- distribute
    return 0
end

function Game.OpenService()
    local url = "https://bkchat.pook.com/client/index.html?pid=10030&source=game&pic=false"
    -- gme version
    url = url.."&clientVersion"..Game.CurrentGameVersion()
    -- device id
    url = url.."&deviceId"..Global.deviceIdentifier

    if _accountLogined then
        url = url.."&userId=".. GameData.GetDefaultAccountUserId()
        url = url.."&userToken="..NetManager.GetLoginSession()
    end

    log("service url: "..tostring(url))

    Global.OpenURL(url)
end

function Game.OpenReview()
    if not Game.CanReview() then
        return
    end

    if Global.currentPlatform == GamePlatform.APPLE then
        UnityEngine.Application.OpenURL("itms-apps://itunes.apple.com/app/id1447328814?action=write-review")
    else
        UnityEngine.Application.OpenURL("https://www.taptap.com/app/162127/review")
    end
end

function Game.CanReview()
    -- 官包, taptap和iOS
    if Global.ChannelId == GameChannels.APPSTORE or
        Global.ChannelId == GameChannels.ANDROID_POOK or
        Global.ChannelId == GameChannels.ANDROID_TAPTAP then
        return true
    end

    return false
end

function Game.ShowService()
    return Global.ChannelId ~= GameChannels.ANDROID_MI and Global.ChannelId ~= GameChannels.ANDROID_BILIBILI
end

function Game.ShowSocial()
    if Global.HasChannelAccount then
        return false
    end

    if Global.ChannelId == GameChannels.ANDROID_4399 then
        return false
    end

    return true
end

--是否未成年标记
function Game.SetUnderAge(flag)
    _CheckUnderAge = flag
end