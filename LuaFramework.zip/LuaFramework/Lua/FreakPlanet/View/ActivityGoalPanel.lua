ActivityGoalPanel  = {}

--init--
function ActivityGoalPanel.Init(obj)
	local transform = obj.transform
	local ui = {}
	
	ui.Camera = transform:Find("Camera"):GetComponent("Camera")
    ui.Blocker = transform:Find("Panel/Blocker").gameObject

    ui.LeftTime = transform:Find("Panel/LeftTime"):GetComponent("UILabel")
    ui.GoalEmpty = transform:Find("Panel/GoalEmpty").gameObject
    ui.GoalItem = transform:Find("Panel/GoalItem")
    ui.DemandGrid = transform:Find("Panel/DemandGrid")
    ui.DemandSelectionRoot = transform:Find("Panel/DemandSelection").gameObject
    ui.DemandSelectionDesc = transform:Find("Panel/DemandSelection/Desc"):GetComponent("UILabel")
    ui.DemandSelectionNum = transform:Find("Panel/DemandSelection/Num"):GetComponent("UILabel")
    ui.DemandSelectionCollider = transform:Find("Panel/DemandSelection/Icons").gameObject

    ui.ButtonDemandSubmit = transform:Find("Panel/DemandSelection/ButtonSubmit").gameObject
    ui.ButtonDemandGo = transform:Find("Panel/DemandSelection/ButtonGo").gameObject
    ui.ButtonDemandCancel = transform:Find("Panel/DemandSelection/ButtoCancel").gameObject

    ui.DemandItemPool = transform:Find("Panel/DemandItemPool")
    ui.DemandItemTemplate = transform:Find("Panel/Template/DemandItem").gameObject
	
	return ui
end
