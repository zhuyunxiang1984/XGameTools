CatchFishMainResultPanel  = {}

--init--
function CatchFishMainResultPanel.Init(obj)
	local transform = obj.transform
	local ui = {}
	
	ui.Camera = transform:Find("Camera"):GetComponent("Camera")

	--blocker
	ui.Blocker = transform:Find("Panel/Blocker").gameObject

	--胜利title
	ui.SuccessObj = transform:Find("Panel/BG/Success").gameObject
	--失败title
	ui.FailureObj = transform:Find("Panel/BG/Fail").gameObject

	ui.Title = transform:Find("Panel/BG/Success/Banner/Title"):GetComponent("UILabel")
	--星星
	ui.Stars = {}
	ui.StarLayout = transform:Find("Panel/StarLayout")
	for idx = 1, ui.StarLayout.childCount do
		local starItem = ui.StarLayout:GetChild(idx - 1)
		local grayStar = starItem:Find("Icon1").gameObject
		local brightStar = starItem:Find("Icon2").gameObject
		table.insert(ui.Stars, { star = starItem.gameObject, gray = grayStar, bright = brightStar })
	end

	ui.SubTitle = transform:Find("Panel/Details/Subtitle"):GetComponent("UILabel")
	--排名
	ui.RankLayout = transform:Find("Panel/Ranking").gameObject
	ui.txtRank = transform:Find("Panel/Ranking/txtRank"):GetComponent("UILabel")

	--分数
	ui.ScoreRoot = transform:Find("Panel/ScoreRoot"):GetComponent("UIGrid")
	ui.ScoreTxt = transform:Find("Panel/ScoreRoot/Score"):GetComponent("UILabel")
	ui.HistoryScore = transform:Find("Panel/ScoreRoot/ScoreBG").gameObject
	ui.HistoryScoreTxt = transform:Find("Panel/ScoreRoot/ScoreBG/HistoryScore"):GetComponent("UILabel")

	--按钮
	ui.ButtonRoot = transform:Find("Panel/ButtonRoot"):GetComponent("UITable")
	ui.btnMap = transform:Find("Panel/ButtonRoot/btnMap").gameObject
	ui.btnRetry = transform:Find("Panel/ButtonRoot/btnRetry").gameObject
	ui.btnNext = transform:Find("Panel/ButtonRoot/btnNext").gameObject

	-- 奖励
	ui.ChallengeExchangeObj = transform:Find("Panel/ChallengeExchange").gameObject
	ui.ChallengeExchangeScoreTxt = transform:Find("Panel/ChallengeExchange/Score"):GetComponent("UILabel")

	ui.NormalAwardObj = transform:Find("Panel/NormalAward").gameObject
	ui.NormalAwardRoot = transform:Find("Panel/NormalAward/Root")

	ui.RewardTemplate = transform:Find("Panel/Template/RewardItem").gameObject

	-- 金鱼展示
	ui.EmptyScrollView = transform:Find("Panel/Details/EmptyScrollView"):GetComponent("UIScrollView")
	ui.FishScrollView = transform:Find("Panel/Details/ScrollView"):GetComponent("UIScrollView")
	ui.FishUIGrid = transform:Find("Panel/Details/ScrollView/UIGrid"):GetComponent("UIGrid")
	ui.FishItemTemplate = transform:Find("Panel/Template/FishItem").gameObject


	return ui
end
