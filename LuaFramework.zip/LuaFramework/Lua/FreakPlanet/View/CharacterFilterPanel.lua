CharacterFilterPanel  = {}

--init--
function CharacterFilterPanel.Init(obj)
	local transform = obj.transform
	local ui = {}
	
	ui.Camera = transform:Find("Camera"):GetComponent("Camera")
    ui.Blocker = transform:Find("Panel/Blocker").gameObject

    ui.ButtonFilterTable = transform:Find("Panel/FilterTable").gameObject
    ui.ButtonChallenge = transform:Find("Panel/FilterTable/ButtonChallenge").gameObject
    ui.ButtonExplore = transform:Find("Panel/FilterTable/ButtonExplore").gameObject
    ui.ButtonWorkShop = transform:Find("Panel/FilterTable/ButtonWorkShop").gameObject

    ui.ButtonReset = transform:Find("Panel/ButtonReset").gameObject

    ui.SearchName = transform:Find("Panel/SearchName"):GetComponent("UIInput")
    ui.SearchNameSafeInput = UISafeInput:new(ui.SearchName)
    ui.ButtonSearch = transform:Find("Panel/ButtonSearch").gameObject

    ui.MatchResult = transform:Find("Panel/MatchResult"):GetComponent("UILabel")
    ui.SkillItemTemplate = transform:Find("Panel/Template/SkillItem").gameObject

    ui.ElementItemsRoot = transform:Find("Panel/Element/Items")
    ui.ElementItems = {}
    for idx = 1, ui.ElementItemsRoot.childCount do
        local item = ui.ElementItemsRoot:GetChild(idx - 1)
        local elementId = tonumber(item.gameObject.name)
        local selected = item:Find("Selected").gameObject
        local unselected = item:Find("UnSelected").gameObject
        ui.ElementItems[elementId] = {item = item.gameObject, selected = selected, unselected = unselected}
    end

    ui.RarityItemsRoot = transform:Find("Panel/Rarity/Items")
    ui.RarityItems = {}
    for idx = 1, ui.RarityItemsRoot.childCount do
        local item = ui.RarityItemsRoot:GetChild(idx - 1)
        local selected = item:Find("Selected").gameObject
        local unselected = item:Find("UnSelected").gameObject
        ui.RarityItems[idx] = {item = item.gameObject, selected = selected, unselected = unselected}
    end

    ui.TagItemsRoot = transform:Find("Panel/Tag/Items")
    ui.TagItems = {}
    for idx = 1, ui.TagItemsRoot.childCount do
        local item = ui.TagItemsRoot:GetChild(idx - 1)
        local tagId = tonumber(item.gameObject.name)
        local selected = item:Find("Selected").gameObject
        local unselected = item:Find("UnSelected").gameObject
        ui.TagItems[tagId] = {item = item.gameObject, selected = selected, unselected = unselected}
    end

    ui.StageItemsRoot = transform:Find("Panel/Stage/Items")
    ui.StageItems = {}
    for idx = 1, ui.StageItemsRoot.childCount do
        local item = ui.StageItemsRoot:GetChild(idx - 1)
        local selected = item:Find("Selected").gameObject
        local unselected = item:Find("UnSelected").gameObject
        ui.StageItems[idx] = {item = item.gameObject, selected = selected, unselected = unselected}
    end

    ui.SkillItemsScrollView = transform:Find("Panel/Skill/ScrollView"):GetComponent("UIScrollView")
    ui.SkillItemsRoot = transform:Find("Panel/Skill/ScrollView/Items")
    ui.SkillItemPool = transform:Find("Panel/SkillItemPool")

    ui.SkillPanel = transform:Find("SkillPanel").gameObject
    ui.SkillBlocker = transform:Find("SkillPanel/Blocker").gameObject
    ui.SkillItems = {}

    ui.ExploreSkillRoot = transform:Find("SkillPanel/Explore")
    for idx = 1, ui.ExploreSkillRoot.childCount do
        local root = ui.ExploreSkillRoot:GetChild(idx - 1)
        local rootItems = root:Find("Items")
        if rootItems ~= nil then
            for m = 1, rootItems.childCount do
                local skillItem = rootItems:GetChild(m - 1)
                local skillName = skillItem.gameObject.name
                local sprite = skillItem:GetComponent("UISprite")
                ui.SkillItems[skillName] = {item = skillItem.gameObject, sprite = sprite}
            end
        end
    end

    ui.ChallengeSkillRoot = transform:Find("SkillPanel/Challenge")
    for idx = 1, ui.ChallengeSkillRoot.childCount do
        local root = ui.ChallengeSkillRoot:GetChild(idx - 1)
        local rootItems = root:Find("Items")
        if rootItems ~= nil then
            for m = 1, rootItems.childCount do
                local skillItem = rootItems:GetChild(m - 1)
                local skillName = skillItem.gameObject.name
                local sprite = skillItem:GetComponent("UISprite")
                ui.SkillItems[skillName] = {item = skillItem.gameObject, sprite = sprite}
            end
        end
    end

    ui.WorkShopSkillRoot = transform:Find("SkillPanel/WorkShop")
    for idx = 1, ui.WorkShopSkillRoot.childCount do
        local root = ui.WorkShopSkillRoot:GetChild(idx - 1)
        local rootItems = root:Find("Items")
        if rootItems ~= nil then
            for m = 1, rootItems.childCount do
                local skillItem = rootItems:GetChild(m - 1)
                local skillName = skillItem.gameObject.name
                local sprite = skillItem:GetComponent("UISprite")
                ui.SkillItems[skillName] = {item = skillItem.gameObject, sprite = sprite}
            end
        end
    end

	
	return ui
end
