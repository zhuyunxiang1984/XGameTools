AccountPasswordResetPanel  = {}

--init--
function AccountPasswordResetPanel.Init(obj)
	local transform = obj.transform
	local ui = {}
	
	ui.Camera = transform:Find("Camera"):GetComponent("Camera")
	ui.Blocker = transform:Find("Panel/Blocker").gameObject
	ui.ButtonConfirm = transform:Find("Panel/ButtonConfirm").gameObject
	ui.ButtonVCode = transform:Find("Panel/ButtonVCode"):GetComponent("UIButton")
	ui.VCodeLeftTime = transform:Find("Panel/VCodeLeftTime"):GetComponent("UILabel")

	ui.NickName = transform:Find("Panel/InputName"):GetComponent("UIInput")
	ui.NickNameSafeInput = UISafeInput:new(ui.NickName)
	ui.NewPassword = transform:Find("Panel/InputNewPassword"):GetComponent("UIInput")
	ui.ConfirmPassword = transform:Find("Panel/InputConfirmPassword"):GetComponent("UIInput")
	ui.Phone = transform:Find("Panel/InputPhone"):GetComponent("UIInput")
	ui.VCode = transform:Find("Panel/InputVCode"):GetComponent("UIInput")
	
	return ui
end
