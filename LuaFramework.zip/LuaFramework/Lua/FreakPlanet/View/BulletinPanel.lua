BulletinPanel = {}

--init--
function BulletinPanel.Init(obj)
    local transform = obj.transform
    local ui = {}

    ui.Camera = transform:Find("Camera"):GetComponent("Camera")
    ui.Blocker = transform:Find("Panel/Blocker").gameObject
    ui.ScrollView = transform:Find("Panel/ScrollView"):GetComponent("UIScrollView")

    ui.BulletinTitle = transform:Find("Panel/Title/Sprite/Label"):GetComponent("UILabel")
    ui.BulletinAnima = transform:Find("Panel/Title/Sprite"):GetComponent("Animator")
    ui.MenuUIGrid = transform:Find("Panel/Menu"):GetComponent("UITable")
    ui.TextBG = transform:Find("Panel/TextBG"):GetComponent("UISprite")

    ui.Social = transform:Find("Panel/Social").gameObject
    ui.ButtonQQ = transform:Find("Panel/Social/ButtonQQ").gameObject
    ui.ButtonWeibo = transform:Find("Panel/Social/ButtonWeibo").gameObject
    ui.ButtonTap = transform:Find("Panel/Social/ButtonTap").gameObject

    ui.TextPrefab = transform:Find("Template/Text").gameObject
    ui.Content = transform:Find("Panel/ScrollView/Contents"):GetComponent("UITable")
    ui.ImagePrefab = transform:Find("Template/Image").gameObject

    ui.Menu = {}
    ui.MenuRoot = transform:Find("Panel/Menu")
    for idx = 1, ui.MenuRoot.childCount do
        local item = ui.MenuRoot:GetChild(idx - 1)
        local menuTitle = item:Find("title"):GetComponent("UILabel")
        local menuHit = item:Find("Hit").gameObject
        table.insert(ui.Menu, { item = item.gameObject, title = menuTitle, hit = menuHit })
    end

    ui.EmptyRoot = transform:Find("Panel/EmptyRoot").gameObject
    return ui
end
