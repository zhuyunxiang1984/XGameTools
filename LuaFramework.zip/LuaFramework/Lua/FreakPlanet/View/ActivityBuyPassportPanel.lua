ActivityBuyPassportPanel = {}

--init--
function ActivityBuyPassportPanel.Init(obj)
	local transform = obj.transform
	local ui = UIView:new()
	ui:Bind(obj, {
		{"Camera","Camera","Camera"},
		{"Blocker","Panel/Blocker"},
		{"btnBuy","Panel/GameObject/btnBuy"},
		{"txtLeftTime", "Panel/GameObject/btnBuy/txtLeftTime", "UILabel"},
		{"objPurchasedTips", "Panel/GameObject/objPurchasedTips"},
		{"objTimeoutTips", "Panel/GameObject/objTimeoutTips"},
	})
	return ui
end
