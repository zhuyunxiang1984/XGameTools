ArenaMarketPanel  = {}

--init--
function ArenaMarketPanel.Init(obj)
	local transform = obj.transform
	local ui = {}
	
	ui.Camera = transform:Find("Camera"):GetComponent("Camera")
	ui.Blocker = transform:Find("Panel/Blocker").gameObject
	ui.ButtonClose = transform:Find("TopPanel/ConstraintBottom/ButtonClose").gameObject

	ui.CharacterRoot = transform:Find("Panel/CharacterRoot")
	ui.BasicRoot = transform:Find("Panel/BasicRoot")
	ui.LimitedRoot = transform:Find("Panel/LimitedRoot")

	ui.MarketItemTemplate = transform:Find("Panel/Template/MarketItem").gameObject
	ui.CharacterItemTemplate = transform:Find("Panel/Template/CharacterItem").gameObject

	ui.MarketCostItems = {}
	ui.MarketCostItemRoot = transform:Find("TopPanel/CostItems")
	for idx = 1, ui.MarketCostItemRoot.childCount do
		local item = ui.MarketCostItemRoot:GetChild(idx - 1)
		local icon = item:Find("Icon"):GetComponent("UISprite")
		local num = item:Find("Num"):GetComponent("UILabel")
		ui.MarketCostItems[idx] = {item = item.gameObject, icon = icon, num = num}
	end
	
	return ui
end
