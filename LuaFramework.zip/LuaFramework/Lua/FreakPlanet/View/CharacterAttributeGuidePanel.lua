CharacterAttributeGuidePanel  = {}

--init--
function CharacterAttributeGuidePanel.Init(obj)
	local transform = obj.transform
	local ui = {}

	ui.Camera = transform:Find("Camera"):GetComponent("Camera")
	ui.Blocker = transform:Find("Panel/Blocker").gameObject

	return ui
end
