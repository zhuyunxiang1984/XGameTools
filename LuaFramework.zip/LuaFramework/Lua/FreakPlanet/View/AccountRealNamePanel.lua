AccountRealNamePanel  = {}

--init--
function AccountRealNamePanel.Init(obj)
	local transform = obj.transform
	local ui = {}
	
	ui.Camera = transform:Find("Camera"):GetComponent("Camera")
    ui.Blocker = transform:Find("Panel/Blocker").gameObject
    ui.RuleBlocker = transform:Find("RulePanel/Blocker").gameObject
    ui.ButtonConfirm = transform:Find("Panel/ButtonConfirm").gameObject
    ui.ButtonVCode = transform:Find("Panel/ButtonVCode"):GetComponent("UIButton")
    ui.ButtonRule = transform:Find("Panel/ButtonRule").gameObject

    ui.RulePanel = transform:Find("RulePanel").gameObject

    ui.RealName = transform:Find("Panel/InputName"):GetComponent("UIInput")
    ui.Identity = transform:Find("Panel/InputIdentity"):GetComponent("UIInput")
    ui.Phone = transform:Find("Panel/InputPhone"):GetComponent("UIInput")
    ui.VCode = transform:Find("Panel/InputVCode"):GetComponent("UIInput")
    ui.VCodeLeftTime = transform:Find("Panel/VCodeLeftTime"):GetComponent("UILabel")
	
	return ui
end
