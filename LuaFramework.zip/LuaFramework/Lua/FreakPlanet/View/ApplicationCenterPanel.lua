ApplicationCenterPanel  = {}

--init--
function ApplicationCenterPanel.Init(obj)
	local transform = obj.transform
	local ui = {}
	ui.Camera = transform:Find("Camera"):GetComponent("Camera")
	ui.m_pBlockObj = transform:Find("Panel/Blocker").gameObject

	ui.m_pReturnBtn = transform:Find("Panel/MenuRoot/ReturnBtn").gameObject
	ui.m_pHomeBtn = transform:Find("Panel/MenuRoot/HomeBtn").gameObject

	ui.m_pMainRootTrans = transform:Find("Panel/MainRoot")
	ui.m_pSubRootTrans = transform:Find("Panel/MainRoot/SubRoot")

	ui.m_pAppEntrancePanel = transform:Find("Panel/MainRoot/AppEntrancePanel").gameObject
	ui.m_pAppMenuRoot = transform:Find("Panel/MainRoot/AppEntrancePanel/AppMenuRoot"):GetComponent("UIGrid")
	ui.m_pMenuItemTemplate = transform:Find("Template/Items").gameObject

	return ui
end
