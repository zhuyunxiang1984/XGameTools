AccountPanel  = {}

--init--
function AccountPanel.Init(obj)
	local transform = obj.transform
	local ui = {}
	
	ui.Camera = transform:Find("Camera"):GetComponent("Camera")
	ui.Blocker = transform:Find("Panel/Blocker").gameObject
	ui.ButtonRule = transform:Find("TopPanel/ConstraintRightBottom/Rule").gameObject
	ui.ButtonPrivacy = transform:Find("TopPanel/ConstraintRightBottom/Privacy").gameObject
	ui.Version = transform:Find("TopPanel/ConstraintBottom/Version"):GetComponent("UILabel")
	ui.ButtonAge = transform:Find("TopPanel/ConstraintBottom/ButtonAge").gameObject
	
	ui.OfficalPanel = transform:Find("OfficalPanel").gameObject
	ui.ButtonStart = transform:Find("OfficalPanel/LaunchPage/ButtonStart").gameObject
	ui.ButtonNickName = transform:Find("OfficalPanel/LaunchPage/ButtonNickName").gameObject
	ui.AccountCollider = transform:Find("OfficalPanel/LaunchPage/CurrentAccount").gameObject
	ui.CurrentAccountId = transform:Find("OfficalPanel/LaunchPage/CurrentAccount/UserId"):GetComponent("UILabel")
	
	ui.ChannelPanel = transform:Find("ChannelPanel").gameObject
	ui.ButtonChannelStart = transform:Find("ChannelPanel/LaunchPage/ButtonStart").gameObject

	ui.TencentPanel = transform:Find("TecentPanel").gameObject
	ui.ButtonQQ = transform:Find("TecentPanel/LaunchPage/ButtonQQ").gameObject
	ui.ButtonWeixin = transform:Find("TecentPanel/LaunchPage/ButtonWeixin").gameObject

	ui.LoginHint = transform:Find("TopPanel/Hint").gameObject

	return ui
end
