BattleResultPanel  = {}

--init--
function BattleResultPanel.Init(obj)
	local transform = obj.transform
	local ui = {}
	
	ui.Camera = transform:Find("Camera"):GetComponent("Camera")
	ui.Blocker = transform:Find("Panel/Blocker").gameObject
	ui.ResultSuccess = transform:Find("Panel/Result/Success").gameObject
	ui.ResultFail = transform:Find("Panel/Result/Fail").gameObject
	ui.ResultSuccessFront = transform:Find("FrontPanel/Success").gameObject
	ui.GeneralFailRoot = transform:Find("Panel/Result/Fail/Banner/GeneralFail").gameObject
	ui.SpaceTravelFailRoot = transform:Find("Panel/Result/Fail/Banner/SpaceTravelFail").gameObject
	ui.ChallengeAvatarRoot = transform:Find("Panel/Result/Success/Challenge/Avatar")
	ui.ChallengeUnlockEquipment = transform:Find("Panel/Result/Success/Challenge/Equipment"):GetComponent("UISprite")
	ui.ChallengeResultText = transform:Find("FrontPanel/Success/ResultText"):GetComponent("UILabel")
	ui.ChallengeDailogRoot = transform:Find("FrontPanel/Success/Bubble").gameObject
	ui.ChallengeDailog = transform:Find("FrontPanel/Success/Bubble/Dialog"):GetComponent("UILabel")

	ui.ButtonContinueSpaceTravel = transform:Find("Panel/Result/Fail/Banner/SpaceTravelFail/ButtoContinue").gameObject
	ui.ContinueSpaceTravelHint = transform:Find("Panel/Result/Fail/Banner/SpaceTravelFail/ButtoContinue/Label"):GetComponent("UILabel")
	ui.ButtonCancelSpaceTravel = transform:Find("Panel/Result/Fail/Banner/SpaceTravelFail/ButtoCancel").gameObject
	ui.CancelSpaceTravelHint = transform:Find("Panel/Result/Fail/Banner/SpaceTravelFail/ButtoCancel/Label"):GetComponent("UILabel")

	ui.FullStarRoot = transform:Find("Panel/Result/Success/Challenge/FullStar").gameObject
	ui.FullStarStarRoot = transform:Find("Panel/Result/Success/Challenge/FullStar/Stars")
	ui.FullStarNewRoundRecord = transform:Find("Panel/Result/Success/Challenge/FullStar/NewRoundRecrod").gameObject
	ui.FullStarRoundNum = transform:Find("Panel/Result/Success/Challenge/FullStar/RoundNum"):GetComponent("UILabel")
	ui.FullStarDeadNum = transform:Find("Panel/Result/Success/Challenge/FullStar/DeadNum"):GetComponent("UILabel")
	ui.FullStarRewardNum = transform:Find("Panel/Result/Success/Challenge/FullStar/Reward/Num"):GetComponent("UILabel")
	ui.FullStarRewardRewarded = transform:Find("Panel/Result/Success/Challenge/FullStar/Reward/Rewarded").gameObject
	ui.FullStarRewardFirstReward = transform:Find("Panel/Result/Success/Challenge/FullStar/Reward/FirstReward").gameObject
	ui.FullStarRewardToReward = transform:Find("Panel/Result/Success/Challenge/FullStar/Reward/ToReward").gameObject

	ui.ChallengeDescRoot = transform:Find("Panel/Result/Success/Challenge/Desc").gameObject
	ui.ChallengeDesc = transform:Find("Panel/Result/Success/Challenge/Desc/Label"):GetComponent("UILabel")
	
	return ui
end
