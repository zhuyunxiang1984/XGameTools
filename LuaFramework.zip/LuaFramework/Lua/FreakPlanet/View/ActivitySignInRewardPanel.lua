---
--- Created by lizheng.
--- DateTime: 2021-07-20 11:39:38
---

ActivitySignInRewardPanel  = {}

--init--
function ActivitySignInRewardPanel.Init(obj)
	local transform = obj.transform
	local ui = {}
	
	ui.Camera = transform:Find("Camera"):GetComponent("Camera")
	ui.Blocker = transform:Find("Panel/Blocker").gameObject

	ui.SignInPanel = transform:Find("Panel/SingInPanel")
	ui.SignInBGKuang = transform:Find("Panel/SingInPanel/BG/BGKuang")
	ui.Cat = transform:Find("Panel/SingInPanel/BG/BGKuang/Cat").gameObject
	ui.SignInDays = transform:Find("Panel/SingInPanel/Hint/Days"):GetComponent("UILabel")
	ui.RewardRoot = transform:Find("Panel/SingInPanel/RewardRoot")
	ui.RewardItemTemplate = transform:Find("Panel/SingInPanel/Template/Item").gameObject

	ui.PassTitle = transform:Find("Panel/SingInPanel/Title/PassTitle"):GetComponent("UILabel")
	ui.ButtonPurchase = transform:Find("Panel/SingInPanel/ExtraPass/Paper/ButtonBuy").gameObject
	ui.ButtonGet = transform:Find("Panel/SingInPanel/ButtonGet").gameObject
	ui.ExtraPass = transform:Find("Panel/SingInPanel/ExtraPass").gameObject
	ui.ExtraPassItem = {}
	local PassRewardRoot = transform:Find("Panel/SingInPanel/ExtraPass/Paper/PassRewardRoot")
	for idx = 1, PassRewardRoot.childCount do
		local item = PassRewardRoot:GetChild(idx - 1)
		local bg = item:Find("Round/BG"):GetComponent("UISprite")
		local lock = item:Find("Lock").gameObject
		table.insert(ui.ExtraPassItem, { item = item, bg = bg, lock = lock })
	end
	ui.ExtraPassTitle = transform:Find("Panel/SingInPanel/ExtraPass/Paper/ButtonBuy/Title"):GetComponent("UILabel")

	return ui
end
