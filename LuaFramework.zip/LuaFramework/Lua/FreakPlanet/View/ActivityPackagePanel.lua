ActivityPackagePanel  = {}

--init--
function ActivityPackagePanel.Init(obj)
	local transform = obj.transform
	local ui = {}
	
	ui.Camera = transform:Find("Camera"):GetComponent("Camera")
    ui.Blocker = transform:Find("Panel/Blocker").gameObject
    ui.PurchasingHint = transform:Find("Panel/Purchasing").gameObject

    ui.PackageItemRoot = transform:Find("Panel/PackageItems")
    ui.PackageItems = {}
    for idx = 1, ui.PackageItemRoot.childCount do
        local item = ui.PackageItemRoot:GetChild(idx - 1)
        local buttonConfirm = item:Find("ButtonConfirm").gameObject
        local buttonDesc = item:Find("ButtonConfirm/Desc"):GetComponent("UILabel")
        local completed = item:Find("Completed").gameObject
        local title = item:Find("Title"):GetComponent("UILabel")
        local leftTime = item:Find("LeftTime"):GetComponent("UILabel")
        local desc = item:Find("Desc"):GetComponent("UILabel")
        local collider = item:Find("Collider").gameObject

        ui.PackageItems[idx] = {
            item = item.gameObject,
            button = buttonConfirm,
            buttonDesc = buttonDesc,
            completed = completed,
            title = title,
            leftTime = leftTime,
            desc = desc,
            collider = collider,
        }
    end
	
	return ui
end
