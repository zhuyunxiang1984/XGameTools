---
--- Created by lizheng.
--- DateTime: 2021-07-12 18:06:33
---

CatchFishStagePreparePanel  = {}

--init--
function CatchFishStagePreparePanel.Init(obj)
	local transform = obj.transform
	local ui = {}
	
	ui.Camera = transform:Find("Camera"):GetComponent("Camera")
	ui.Blocker = transform:Find("Panel/Blocker").gameObject

	ui.StageTitle = transform:Find("Panel/Title"):GetComponent("UILabel")
	ui.CurFishEnergy = transform:Find("Panel/Energy"):GetComponent("UILabel")
	ui.TeamLimitInfo = transform:Find("Panel/LimitInfo"):GetComponent("UILabel")

	ui.ButtonClose = transform:Find("RolePanel/ConstraintBottom/ButtonClose").gameObject
	ui.ButtonGo = transform:Find("RolePanel/ConstraintBottom/ButtonGo").gameObject
	ui.ButtonFilter = transform:Find("RolePanel/ButtonFilter").gameObject

	ui.CharacterRoot = transform:Find("Panel/Characters")
	ui.CharacterPool = transform:Find("Panel/CharacterPool")
	ui.CharacterItemPool = transform:Find("Panel/CharacterItemPool")

	ui.GlobalSkillHintAnimator = transform:Find("Panel/GlobalSkillHint"):GetComponent("Animator")
	ui.GlobalSkillValue = transform:Find("Panel/GlobalSkillHint/Value"):GetComponent("UILabel")

	ui.CharacterObjectTemplate = transform:Find("Panel/Template/CharacterObject").gameObject
	ui.CharacterObjectTemplate:SetActive(false)
	ui.SkillDialogObjectTemplate = transform:Find("Panel/Template/SkillDialog").gameObject
	ui.SkillDialogObjectTemplate:SetActive(false)
	ui.CharacterItemTemplate = transform:Find("Panel/Template/CharacterItem").gameObject
	ui.CharacterItemTemplate:SetActive(false)

	ui.MemberSkillDialogRoot =transform:Find("Panel/MemberSkillDialogRoot")
	ui.MemberSkillDialogPool = transform:Find("Panel/MemberSkillDialogPool")

	ui.MemberSkillHintRoot = transform:Find("RolePanel/MemberSkillHintRoot")
	ui.MemberSkillHintPool = transform:Find("RolePanel/MemberSkillHintPool")

	ui.CharacterPositions = {}
	ui.DragHints = {}
	local positionRoot = transform:Find("Panel/Positions")
	for idx = 1, positionRoot.childCount do
		local positionItem = positionRoot:GetChild(idx - 1)
		local posRelativeToCharacterRoot = ui.CharacterRoot:InverseTransformPoint(positionItem.position)
		posRelativeToCharacterRoot.z = 0
		ui.CharacterPositions[idx] = posRelativeToCharacterRoot
		ui.DragHints[idx] = positionItem:Find("Hint").gameObject
	end

	ui.CharacterPositionHint = {}
	ui.CharacterPositionHintRoot = transform:Find("Panel/PositionHint")
	for idx = 1, ui.CharacterPositionHintRoot.childCount do
		local hintItem = ui.CharacterPositionHintRoot:GetChild(idx - 1)
		local animator = hintItem:GetComponent("Animator")
		local activeMark = hintItem:Find("Active").gameObject
		table.insert(ui.CharacterPositionHint, { item = hintItem, mark = activeMark, animator = animator })
	end
	ui.CharacterPositionHintUIGrid = ui.CharacterPositionHintRoot:GetComponent("UIGrid")

	ui.ItemScrollView = transform:Find("Panel/ScrollView"):GetComponent("UIScrollView")
	ui.ItemGrid = transform:Find("Panel/ScrollView/Grid")
	ui.ItemGridWrap = ui.ItemGrid:GetComponent("WrapVerticalGrid")

	-- ability
	ui.WorkShopAbilities = {}
	ui.WorkShopAbilityRoot = transform:Find("Panel/WorkShopAbility/Abilities")
	for idx = 1, ui.WorkShopAbilityRoot.childCount do
		local abilityItem = ui.WorkShopAbilityRoot:GetChild(idx - 1)
		local name = abilityItem:Find("Name"):GetComponent("UILabel")
		local icon = abilityItem:Find("Icon"):GetComponent("UISprite")
		local currentValue = abilityItem:Find("CurrentValue"):GetComponent("UILabel")
		local selected = abilityItem:Find("SelectMark").gameObject
		local rankRoot = abilityItem:Find("Rank")
		local rankBar = abilityItem:Find("Rank/Bar"):GetComponent("UISprite")
		local hintBar = abilityItem:Find("Rank/HintBar"):GetComponent("UISprite")
		local bgBar = abilityItem:Find("Rank/BGBar"):GetComponent("UISprite")
		local rankElementRoot = abilityItem:Find("Rank/Elements")
		ui.WorkShopAbilities[idx] = {
			item = abilityItem.gameObject,
			name = name,
			icon = icon,
			currentValue = currentValue,
			selected = selected,
			rankRoot = rankRoot,
			rankBar = rankBar,
			hintBar = hintBar,
			bgBar = bgBar,
			rankElementRoot = rankElementRoot,
		}

		if ui.RankOriginPosition == nil then
			ui.RankOriginPosition = rankRoot.localPosition.x
		end
	end

	ui.AbilityRankElementTemplate = transform:Find("Panel/Template/RankElement").gameObject

	-- tabs
	ui.ButtonCharacter = transform:Find("RolePanel/Tabs/Character"):GetComponent("UIButton")
	ui.ButtonTeam = transform:Find("RolePanel/Tabs/Team"):GetComponent("UIButton")
	ui.ButtonCouple = transform:Find("RolePanel/Tabs/Couple"):GetComponent("UIButton")

	-- team
	ui.TeamScrollView = transform:Find("Panel/TeamScrollView"):GetComponent("UIScrollView")
	ui.TeamGrid = transform:Find("Panel/TeamScrollView/Grid")
	ui.ButtonTeamSort = transform:Find("RolePanel/ButtonTeamSort").gameObject
	ui.ButtonTeamSortConfirm = transform:Find("RolePanel/ButtonTeamSortConfirm").gameObject
	ui.ButtonTeamDelete = transform:Find("RolePanel/ButtonTeamDelete").gameObject
	ui.ButtonTeamDeleteConfirm = transform:Find("RolePanel/ButtonTeamDeleteConfirm").gameObject

	-- drag limit
	local leftLimit = transform:Find("Panel/PositionLimit/Left")
	local rightLimit = transform:Find("Panel/PositionLimit/Right")

	local leftLimitPosition = ui.CharacterRoot:InverseTransformPoint(leftLimit.position)
	local rightLimitPosition = ui.CharacterRoot:InverseTransformPoint(rightLimit.position)

	ui.LimitMin = leftLimitPosition.x
	ui.LimitMax = rightLimitPosition.x

	-- couple
	ui.CoupleHintRoot = transform:Find("RolePanel/CoupleHintRoot")
	ui.CoupleHintPool = transform:Find("RolePanel/CoupleHintPool")

	ui.CoupleScrollView = transform:Find("Panel/CoupleScrollView"):GetComponent("UIScrollView")
	ui.CoupleGrid = transform:Find("Panel/CoupleScrollView/Grid")
	ui.CoupleAvatarPool = transform:Find("RolePanel/CoupleAvatarPool")
	return ui
end
