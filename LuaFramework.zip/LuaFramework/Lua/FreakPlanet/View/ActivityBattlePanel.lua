ActivityBattlePanel  = {}

--init--
function ActivityBattlePanel.Init(obj)
	local transform = obj.transform
	local ui = {}
	
	ui.Camera = transform:Find("Camera"):GetComponent("Camera")
    ui.Blocker = transform:Find("Panel/Blocker").gameObject
    ui.LineRoot = transform:Find("Panel/Detail/Lines")
    ui.Name = transform:Find("Panel/Name"):GetComponent("UILabel")
    ui.LeftTime = transform:Find("Panel/LeftTime"):GetComponent("UILabel")
    ui.StoryBG = transform:Find("Panel/StoryBG"):GetComponent("UI2DSprite")

    ui.ActivityBattles = {}
    ui.ActivityBattleRoot = transform:Find("Panel/Detail/Battles")
    for idx = 1, ui.ActivityBattleRoot.childCount do
        local item = ui.ActivityBattleRoot:GetChild(idx - 1)
        ui.ActivityBattles[idx] = {item = item.gameObject, root = item}
    end

    ui.BattleItemTemplate = transform:Find("Panel/Template/BattleItem").gameObject
	
	return ui
end
