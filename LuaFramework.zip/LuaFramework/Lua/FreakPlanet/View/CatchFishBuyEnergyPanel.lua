CatchFishBuyEnergyPanel  = {}

--init--
function CatchFishBuyEnergyPanel.Init(obj)
	local transform = obj.transform
	local ui = UIView:new()
	ui:Bind(obj, {
		{"Camera", "Camera", "Camera"},
		{"Blocker", "Panel/Blocker"},

		{"btnConfirm", "Panel/btnConfirm"},
		{"btnReturn", "Panel/btnReturn"},

		{"imgCostIcon", "Panel/Details1/imgCostIcon", "UISprite"},
		{"txtCostNum", "Panel/Details1/txtCostNum", "UILabel"},

		{"imgItemIcon", "Panel/Details2/imgItemIcon", "UISprite"},
		{"txtItemNum", "Panel/Details2/txtItemNum", "UILabel"},
		{"txtLabel", "Panel/Tips/txtLabel", "UILabel"},
	})

	return ui
end
