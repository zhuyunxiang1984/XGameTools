CatchFishHelpPanel  = {}

--init--
function CatchFishHelpPanel.Init(obj)
	local description = {
		{"Camera", "Camera", "Camera"},
		{"Blocker", "Panel/Blocker"},
	}
	local ui = UIView:new()
	ui:Bind(obj, description)

	return ui
end
