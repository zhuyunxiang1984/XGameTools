AccountRegisterConfirmPanel  = {}

--init--
function AccountRegisterConfirmPanel.Init(obj)
	local transform = obj.transform
	local ui = {}
	
    ui.Camera = transform:Find("Camera"):GetComponent("Camera")
    ui.ButtonRule = transform:Find("Panel/Rule").gameObject
    ui.ButtonPrivacy = transform:Find("Panel/Privacy").gameObject
    ui.ButtonConfirm = transform:Find("Panel/ButtonConfirm").gameObject
    ui.ButtonCancel= transform:Find("Panel/ButtonCancel").gameObject
	
	return ui
end
