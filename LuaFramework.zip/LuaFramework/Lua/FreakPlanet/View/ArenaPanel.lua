ArenaPanel  = {}

--init--
function ArenaPanel.Init(obj)
	local transform = obj.transform
	local ui = {}
	
	ui.Camera = transform:Find("Camera"):GetComponent("Camera")
    ui.Blocker = transform:Find("BackPanel/Blocker").gameObject
    ui.ButtonClose = transform:Find("TopPanel/LeftBottom/ButtonClose").gameObject
    --ui.ButtonMarket = transform:Find("TopPanel/RightBottom/ButtonMarket").gameObject
    ui.ButtonArena = transform:Find("Panel/Root/ButtonArena").gameObject
    ui.ButtonActivity = transform:Find("Panel/Root/ButtonActivity").gameObject
    ui.ButtonExplore = transform:Find("Panel/Root/ButtonExplore").gameObject
    ui.ButtonCatchFish = transform:Find("Panel/Root/ButtonCatchFish").gameObject
    ui.ButtonExploreSpeedUp = transform:Find("Panel/Root/ButtonExploreSpeedUp").gameObject
    ui.ExploreFinishHint = transform:Find("Panel/Root/ButtonExploreSpeedUp/Hint").gameObject
    ui.ButtonClothesShop = transform:Find("Panel/Root/ButtonClothesShop").gameObject
    ui.btnActivityDailyReward = transform:Find("TopPanel/LeftBottom/btnActivityDailyReward").gameObject
    ui.btnActivityPassport = transform:Find("TopPanel/LeftBottom/btnActivityPassport").gameObject

    ui.ExploreBus = transform:Find("Panel/Root/Bus/Bus").gameObject
    ui.ExploreBusAnimator = ui.ExploreBus:GetComponent("Animator")

    ui.ArenaLeftTime = transform:Find("Panel/Root/ButtonArena/Time"):GetComponent("UILabel")
    ui.ActivityLeftTime = transform:Find("Panel/Root/ButtonActivity/Time"):GetComponent("UILabel")
    ui.ExploreLeftTime = transform:Find("Panel/Root/ButtonExploreSpeedUp/ScrollView/Time"):GetComponent("UILabel")

    ui.ActivityHint = transform:Find("Panel/Root/ActivityHint").gameObject
    ui.ActivityGoalHint = transform:Find("Panel/Root/ActivityGoalHint").gameObject

    ui.SceneRoot = transform:Find("Panel/Root")
    ui.BuildingRoot = transform:Find("Panel/Root/BuildingPos")
    ui.CharacterRoot = transform:Find("Panel/Root/Character")

    ui.DialogRoot = transform:Find("TopPanel/DialogRoot")
    ui.DialogItem = transform:Find("TopPanel/DialogRoot/DialogItem")
    ui.DialogBG = transform:Find("TopPanel/DialogRoot/DialogItem/DialogBG"):GetComponent("UI2DSprite")
    ui.DialogLabel = transform:Find("TopPanel/DialogRoot/DialogItem/Label"):GetComponent("UILabel")
    ui.DialogTypeEffect = transform:Find("TopPanel/DialogRoot/DialogItem/Label"):GetComponent("TypewriterEffect")

    local root = GameDataHideSeek.GetHideSeekGameObjectRoot()
    if root then
        ui.RabbitRoot = transform:Find(string.format("Panel/Root/%s", root))
    end
    ui.HideSeekColliderRoot = transform:Find("Panel/Root/HideSeekColliderRoot")
    ui.HideSeekColliderTemplate = transform:Find("Panel/Root/Template/HideSeekColliderItem").gameObject

    ui.m_pAppCenterBtn = transform:Find("TopPanel/MenuRoot/AppCenter").gameObject
    ui.m_pPlanetBtn = transform:Find("TopPanel/MenuRoot/Planet").gameObject

    --ui.m_pWorkShopBtn = transform:Find("Panel/Root/ButtonWorkShop").gameObject
    --ui.m_pSummonBtn = transform:Find("Panel/Root/ButtonSummon").gameObject
    ui.m_pHideSeekEntranceObj = transform:Find("TopPanel/LeftBottom/HideSeekEntrance").gameObject

    ui.m_pTouristBtn = transform:Find("TopPanel/RightBottom/ButtonTourist").gameObject
    ui.m_pTouristAnimator = ui.m_pTouristBtn.transform:Find("Icon"):GetComponent("Animator")

    ui.pBtnWorkShop = transform:Find("Panel/Root/ButtonWorkShop").gameObject
    ui.pBtnSummon = transform:Find("Panel/Root/ButtonSummon").gameObject
    ui.pBtnMarket = transform:Find("Panel/Root/ButtonMarket").gameObject
    ui.pBtnHome = transform:Find("Panel/Root/ButtonHome").gameObject
	return ui
end
