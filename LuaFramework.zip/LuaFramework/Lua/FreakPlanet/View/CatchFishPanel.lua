CatchFishPanel = {}

--init--
function CatchFishPanel.Init(obj)
    local transform = obj.transform
    local ui = {}

    ui.Camera = transform:Find("Camera"):GetComponent("Camera")
    ui.Blocker = transform:Find("Panel/Blocker").gameObject
    ui.FishPoolScrollView = transform:Find("Panel/FishPoolScrollView"):GetComponent("UIScrollView")
    ui.FishPoolContent = transform:Find("Panel/FishPoolScrollView/Content").gameObject
    ui.StageButtons = {}
    ui.TotalStarNum = transform:Find("Panel/BG/TotalStar/StarNum"):GetComponent("UILabel")
    ui.StageButtonRoot = transform:Find("Panel/FishPoolScrollView/Content/ButtonRoot")
    -- 普通关卡
    for i = 1, ui.StageButtonRoot.childCount - 1 do
        local node = ui.StageButtonRoot:GetChild(i - 1)
        local name = node:Find("name"):GetComponent("UILabel")
        local buttonStar = {}
        for idx = 1, 3 do
            local starName = "Star" .. tostring(idx)
            local star = node:Find(starName)
            local brightIcon = star:Find("Icon1").gameObject
            local grayIcon = star:Find("Icon2").gameObject
            table.insert(buttonStar, { star = star.gameObject, bright = brightIcon, gray = grayIcon })
        end
        table.insert(ui.StageButtons, { node = node.gameObject, name = name, star = buttonStar })
    end

    local challengeButton = ui.StageButtonRoot:GetChild(ui.StageButtonRoot.childCount - 1)
    local challengeButtonName = challengeButton:Find("name"):GetComponent("UILabel")
    local limitLabel = challengeButton:Find("Limit"):GetComponent("UILabel")
    ui.ChallengeButtons = { node = challengeButton.gameObject, name = challengeButtonName, limit = limitLabel }

    ui.StageLines = {}
    local stageLineRoot = transform:Find("Panel/FishPoolScrollView/Content/LineRoot")
    for idx = 1, stageLineRoot.childCount do
        local line = stageLineRoot:GetChild(idx - 1):GetComponent("UISprite")
        table.insert(ui.StageLines, line)
    end

    ui.RewardScrollView = transform:Find("Panel/ScrollView"):GetComponent("UIScrollView")
    ui.RewardUIGrid = transform:Find("Panel/ScrollView/UIGrid"):GetComponent("UIGrid")

    ui.CommonRewardItemTemplate = transform:Find("Panel/Template/CommonRewardItem").gameObject
    ui.PassRewardItemTemplate = transform:Find("Panel/Template/PassRewardItem").gameObject

    ui.progressStarTemplate = transform:Find("Panel/Template/ProgressStar").gameObject
    ui.progressBarTemplate = transform:Find("Panel/Template/RewardProgressBar").gameObject

    return ui
end
