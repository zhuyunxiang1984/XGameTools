AccountPasswordModifyPanel  = {}

--init--
function AccountPasswordModifyPanel.Init(obj)
	local transform = obj.transform
	local ui = {}
	
	ui.Camera = transform:Find("Camera"):GetComponent("Camera")
	ui.Blocker = transform:Find("Panel/Blocker").gameObject
	ui.ButtonConfirm = transform:Find("Panel/ButtonConfirm").gameObject
	ui.ResultHint = transform:Find("Panel/ResultHint"):GetComponent("UILabel")

	ui.NickName = transform:Find("Panel/InputName"):GetComponent("UIInput")
	ui.NickNameSafeInput = UISafeInput:new(ui.NickName)
	ui.Password = transform:Find("Panel/InputPassword"):GetComponent("UIInput")
	ui.NewPassword = transform:Find("Panel/InputNewPassword"):GetComponent("UIInput")
	ui.ConfirmPassword = transform:Find("Panel/InputConfirmPassword"):GetComponent("UIInput")
	
	return ui
end
