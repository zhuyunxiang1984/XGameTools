CatchFishStageDetailPanel  = {}

--init--
function CatchFishStageDetailPanel.Init(obj)
	local transform = obj.transform
	local ui = {}
	
	ui.Camera = transform:Find("Camera"):GetComponent("Camera")
	ui.Blocker = transform:Find("Panel/Blocker").gameObject
	ui.ButtonRank = transform:Find("Panel/Ranking").gameObject
	ui.StageTitle = transform:Find("Panel/CheckTitleBanner/Title"):GetComponent("UILabel")
	ui.StageLimitTxt = transform:Find("Panel/Details/Info"):GetComponent("UILabel")

	ui.ButtonStart = transform:Find("Panel/ButtonStart").gameObject

	ui.NoAwardRoot = transform:Find("Panel/NoAward").gameObject
	ui.AwardRoot = transform:Find("Panel/Award").gameObject
	ui.AwardGrid = transform:Find("Panel/Award/AwardGrid"):GetComponent("UIGrid")
	ui.AwardItemTemplate = transform:Find("Panel/Template/AwardItem").gameObject

	ui.RankNum = transform:Find("Panel/Ranking/RankNum"):GetComponent("UILabel")

	ui.StarRoot = transform:Find("Panel/StarRoot")


	ui.NormalTickets = transform:Find("Panel/Tickets1").gameObject
	ui.NormalTicketsConsumeIcon = transform:Find("Panel/Tickets1/ConsumeIcon"):GetComponent("UISprite")
	ui.NormalTicketsConsumeNum = transform:Find("Panel/Tickets1/ConsumeNum"):GetComponent("UILabel")

	ui.PassTickets = transform:Find("Panel/Tickets2").gameObject
	ui.PassTicketsConsumeIcon = transform:Find("Panel/Tickets2/ConsumeIcon"):GetComponent("UISprite")
	ui.PassTicketsConsumeNum = transform:Find("Panel/Tickets2/ConsumeNum"):GetComponent("UILabel")

	ui.StageStar = {}
	for idx = 1, ui.StarRoot.childCount do
		local starItem = ui.StarRoot:GetChild(idx - 1)
		ui.StageStar[idx] = starItem:GetComponent("UISprite")
	end

	return ui
end
