ActivityBattleDetailPanel  = {}

--init--
function ActivityBattleDetailPanel.Init(obj)
	local transform = obj.transform
	local ui = {}
	
	ui.Camera = transform:Find("Camera"):GetComponent("Camera")
    ui.Blocker = transform:Find("Panel/Blocker").gameObject
    ui.ButtonUnlockConfirm = transform:Find("Panel/ButtonUnlockConfirm").gameObject
    ui.ButtonConfirm = transform:Find("Panel/ButtonConfirm").gameObject
    ui.ButtonRepeatConfirm = transform:Find("Panel/ButtonRepeatConfirm").gameObject

    ui.Title = transform:Find("Panel/Title"):GetComponent("UILabel")
    ui.Introduce = transform:Find("Panel/Introduce"):GetComponent("UILabel")
    ui.SupportLevel = transform:Find("Panel/SupportLevel"):GetComponent("UILabel")
    ui.BattleFinished = transform:Find("Panel/Finished").gameObject

    ui.EnemyCollider = transform:Find("Panel/Enemy").gameObject
    ui.EnemyIcon = transform:Find("Panel/Enemy/Icon"):GetComponent("UISprite")
    ui.EnemyName = transform:Find("Panel/Enemy/Name"):GetComponent("UILabel")
    ui.EnemyPower = transform:Find("Panel/Enemy/Power"):GetComponent("UILabel")
    ui.EnemyElement = transform:Find("Panel/Enemy/Element"):GetComponent("UISprite")

    ui.StoryBG = transform:Find("Panel/StoryBG"):GetComponent("UI2DSprite")

    ui.RewardItems = {}
    local rewardRoot = transform:Find("Panel/Rewards")
    for idx = 1, rewardRoot.childCount do
        local item = rewardRoot:GetChild(idx - 1)
        ui.RewardItems[idx] = {item = item.gameObject, root = item}
    end
	
	return ui
end
