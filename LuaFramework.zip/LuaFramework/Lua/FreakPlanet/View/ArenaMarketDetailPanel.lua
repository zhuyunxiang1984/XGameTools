ArenaMarketDetailPanel  = {}

--init--
function ArenaMarketDetailPanel.Init(obj)
	local transform = obj.transform
	local ui = {}
	
	ui.Camera = transform:Find("Camera"):GetComponent("Camera")
    ui.Blocker = transform:Find("Panel/Blocker").gameObject
    ui.ButtonCharacterConfirm = transform:Find("Panel/Character/ButtonConfirm").gameObject
    ui.ButtonNormalConfirm = transform:Find("Panel/Normal/ButtonConfirm").gameObject

    ui.LeftTime = transform:Find("Panel/LeftTime"):GetComponent("UILabel")

    ui.CharacterRoot = transform:Find("Panel/Character").gameObject
    ui.CharacterGeneralBG = transform:Find("Panel/Character/GeneralBG").gameObject
    ui.CharacterActivityBG = transform:Find("Panel/Character/ActivityBG").gameObject
    ui.CharacterCostRoot = transform:Find("Panel/Character/Cost")
    ui.CharacterCostNum = transform:Find("Panel/Character/Cost/Num"):GetComponent("UILabel")
    ui.CharacterSoldOut = transform:Find("Panel/Character/SoldOut").gameObject
    ui.CharacterItemRoot = transform:Find("Panel/Character/Root")
    ui.CharacterItemPool = transform:Find("Panel/CharacterItemPool")
    ui.CharacterItemTemplate = transform:Find("Panel/Template/CharacterItem").gameObject

    ui.NormalRoot = transform:Find("Panel/Normal").gameObject
    ui.NormalName = transform:Find("Panel/Normal/Name"):GetComponent("UILabel")
    ui.NormalIcon = transform:Find("Panel/Normal/Icon"):GetComponent("UISprite")
    ui.NormalNum = transform:Find("Panel/Normal/Num"):GetComponent("UILabel")
    ui.NormalDesc = transform:Find("Panel/Normal/Desc"):GetComponent("UILabel")
    ui.NormalCostRoot = transform:Find("Panel/Normal/Cost")
    ui.NormalCostNum = transform:Find("Panel/Normal/Cost/Num"):GetComponent("UILabel")
    ui.NormalSoldOut = transform:Find("Panel/Normal/SoldOut").gameObject

    ui.HintPanel = transform:Find("HintPanel").gameObject
    ui.HintAnimator = transform:Find("HintPanel/BlindboxOpen"):GetComponent("Animator")
    ui.HintSprite = transform:Find("HintPanel/BlindboxOpen/BlindboxFG"):GetComponent("UISprite")

    ui.OwnItemRoot = transform:Find("Panel/OwnItem")
    ui.OwnItemNum = transform:Find("Panel/OwnItem/Num"):GetComponent("UILabel")
	
	return ui
end
