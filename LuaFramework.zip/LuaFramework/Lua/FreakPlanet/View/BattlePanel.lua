BattlePanel  = {}

--init--
function BattlePanel.Init(obj)
	local transform = obj.transform
	local ui = {}
	
	ui.Camera = transform:Find("Camera"):GetComponent("Camera")
	ui.Blocker = transform:Find("Panel/Blocker").gameObject
	ui.ButtonSkip = transform:Find("TopPanel/ButtonSkip").gameObject
	ui.ButtonSpeedUp = transform:Find("TopPanel/ButtonSpeedUp").gameObject

	ui.RoundRoot = transform:Find("TopPanel/Round").gameObject
	ui.RoundLabel = transform:Find("TopPanel/Round/Label"):GetComponent("UILabel")
	ui.SpeedUpLabel = transform:Find("TopPanel/ButtonSpeedUp/Label"):GetComponent("UILabel")
	
	ui.AttackHintRoot = transform:Find("FrontPanel/AttackHintRoot")
	ui.AttackHintPool = transform:Find("FrontPanel/AttackHintPool")
	ui.AttackHintTemplate = transform:Find("FrontPanel/Template/AttackHint").gameObject

	ui.CharacterAvatarRoot = transform:Find("Panel/Character/Avatars")
	ui.CharacterAvatarPool = transform:Find("Panel/CharacterAvatarPool")
	ui.CharacterAvatarTemplate = transform:Find("Panel/Template/CharacterAvatar").gameObject
	ui.ChallengeBG = transform:Find("Panel/LevelBG"):GetComponent("UI2DSprite")
	ui.LevelTween = transform:Find("Panel/LevelBG"):GetComponent("TweenPosition")

	-- character slot positions
	ui.CharacterSlotPositions = {}
	local positionRoot = transform:Find("Panel/Character/Positions")
	for idx = 1, positionRoot.childCount do
		local item = positionRoot:GetChild(idx - 1)
		-- real world position
		local worldPosition = item.position
		-- local to character avatar root
		local localPosition = ui.CharacterAvatarRoot:InverseTransformPoint(worldPosition)
		ui.CharacterSlotPositions[idx] = {worldPosition = worldPosition, localPosition = localPosition}
	end

	-- enemy
	ui.EnemyRoot = transform:Find("Panel/Enemy").gameObject
	ui.EnemyAvatarRoot = transform:Find("Panel/Enemy/Avatar")
	ui.EnemySpawnMark = transform:Find("Panel/Enemy/SpawnMark")
	ui.EnemyBattleMark = transform:Find("Panel/Enemy/BattleMark")
	ui.EnemyAvatarRoot = transform:Find("Panel/Enemy/Avatar")
	ui.EnemyAvatarPool = transform:Find("Panel/EnemyAvatarPool")
	ui.EnemyAvatarTemplate = transform:Find("Panel/Template/EnemyAvatar").gameObject

	ui.BattleEffectPool = transform:Find("Panel/BattleFffectPool")

	-- effect pool - battle and skill effect
	ui.SkillEffectPool = transform:Find("FrontPanel/SkillEffectPool")
	ui.SkillEffectRoot = transform:Find("FrontPanel/SkillEffectRoot")

	ui.DialogRoot = transform:Find("FrontPanel/DialogRoot")
	ui.DialogPool = transform:Find("FrontPanel/DialogPool")
	ui.DialogTemplate = transform:Find("FrontPanel/Template/Dialog").gameObject

	return ui
end
