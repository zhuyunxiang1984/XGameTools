ActivityPanel  = {}

--init--
function ActivityPanel.Init(obj)
	local transform = obj.transform
	local ui = {}
	
	ui.Camera = transform:Find("Camera"):GetComponent("Camera")
    ui.Blocker = transform:Find("Panel/Blocker").gameObject
    ui.Border = transform:Find("Panel/Border").gameObject
    ui.GoalHint = transform:Find("TopPanel/Table/ButtonGoal/Hint").gameObject

    ui.ButtonTable = transform:Find("TopPanel/Table"):GetComponent("UITable")
    ui.ButtonPackage = transform:Find("TopPanel/Table/ButtonPackage").gameObject
    ui.ButtonBattle = transform:Find("TopPanel/Table/ButtonBattle").gameObject
    ui.ButtonBox = transform:Find("TopPanel/Table/ButtonBox").gameObject
    ui.ButtonGoal = transform:Find("TopPanel/Table/ButtonGoal").gameObject

    ui.ButtonPrev = transform:Find("TopPanel/ButtonPrev").gameObject
    ui.ButtonNext = transform:Find("TopPanel/ButtonNext").gameObject
    
    ui.ActivityName = transform:Find("TopPanel/ActivityName"):GetComponent("UILabel")
    ui.ActivityRoot = transform:Find("Panel/Root")
    ui.ActivityPool = transform:Find("Panel/Pool")

    ui.Door = transform:Find("Panel/ScrollView/Door").gameObject
    ui.DoorAnimator = transform:Find("Panel/ScrollView/Door"):GetComponent("Animator")

    ui.EmptyMark = transform:Find("TopPanel/Empty").gameObject

    ui.DialogRoot = transform:Find("TopPanel/DialogRoot")
    ui.DialogItem = transform:Find("TopPanel/DialogRoot/DialogItem")
    ui.DialogBG = transform:Find("TopPanel/DialogRoot/DialogItem/DialogBG"):GetComponent("UI2DSprite")
    ui.DialogLabel = transform:Find("TopPanel/DialogRoot/DialogItem/Label"):GetComponent("UILabel")
    ui.DialogTypeEffect = transform:Find("TopPanel/DialogRoot/DialogItem/Label"):GetComponent("TypewriterEffect")
    
	return ui
end
