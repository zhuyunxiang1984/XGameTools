---
--- Created by lizheng.
--- DateTime: 2021-07-28 10:00:28
---

CatchFishRankPanel  = {}

--init--
function CatchFishRankPanel.Init(obj)
	local transform = obj.transform
	local ui = {}
	
	ui.Camera = transform:Find("Camera"):GetComponent("Camera")
	ui.Blocker = transform:Find("Panel/Blocker").gameObject

	ui.ButtonDetails = transform:Find("Panel/Myself/ButtonDetails").gameObject
	ui.RankItemTemplate = transform:Find("Panel/Template/RankItem").gameObject

	ui.RankPoolRoot = transform:Find("Panel/RankPoolRoot")
	ui.RankScrollView = transform:Find("Panel/ScrollView"):GetComponent("UIScrollView")
	ui.RankGrid = transform:Find("Panel/ScrollView/Grid")
	ui.RankGridWrap = ui.RankGrid:GetComponent("WrapVerticalGrid")

	ui.MyRankRoot = transform:Find("Panel/Myself")
	local myRankScore = ui.MyRankRoot:Find("Score"):GetComponent("UILabel")
	local myRankName = ui.MyRankRoot:Find("Name"):GetComponent("UILabel")
	local myRankNum = ui.MyRankRoot:Find("Number/Rank"):GetComponent("UILabel")
	ui.MyRank = { score = myRankScore, name = myRankName, num = myRankNum }

	return ui
end
