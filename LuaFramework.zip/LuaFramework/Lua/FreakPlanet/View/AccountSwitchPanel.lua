AccountSwitchPanel  = {}

--init--
function AccountSwitchPanel.Init(obj)
	local transform = obj.transform
	local ui = {}
	
	ui.Camera = transform:Find("Camera"):GetComponent("Camera")
	ui.Blocker = transform:Find("Panel/Blocker").gameObject
	
	ui.ButtonCreate = transform:Find("Panel/ButtonCreate").gameObject
	ui.ButtonService = transform:Find("Panel/Table/ButtonService").gameObject
	ui.ButtonModifyPassword = transform:Find("Panel/Table/ButtonModifyPassword").gameObject
	ui.ButtonResetPassword = transform:Find("Panel/Table/ButtonResetPassword").gameObject

	ui.AccountScrollView = transform:Find("Panel/ScrollView"):GetComponent("UIScrollView")
	ui.AccountGrid = transform:Find("Panel/ScrollView/Grid")

	ui.AccountItemTemplate = transform:Find("Panel/Template/AccountItem").gameObject
	ui.Table = transform:Find("Panel/Table"):GetComponent("UITable")

	return ui
end
