ArenaEnemyPanel  = {}

--init--
function ArenaEnemyPanel.Init(obj)
	local transform = obj.transform
	local ui = {}
	
	ui.Camera = transform:Find("Camera"):GetComponent("Camera")
	ui.Blocker = transform:Find("Panel/Blocker").gameObject
	ui.ArenaTheme = transform:Find("Panel/Theme/Label"):GetComponent("UILabel")
	ui.ArenaLineRoot = transform:Find("Panel/Arenas/Lines")

	ui.ArenaBattles = {}
	ui.ArenaBattleRoot = transform:Find("Panel/Arenas/Battles")
	for idx = 1, ui.ArenaBattleRoot.childCount do
		local item = ui.ArenaBattleRoot:GetChild(idx - 1)
		ui.ArenaBattles[idx] = {item = item.gameObject, root = item}
	end

	ui.NormalArenaItemTemplate = transform:Find("Panel/Template/NormalItem").gameObject
	ui.BossArenaItemTemplate = transform:Find("Panel/Template/BossItem").gameObject
	
	return ui
end
