AccountInvitationPanel  = {}

--init--
function AccountInvitationPanel.Init(obj)
	local transform = obj.transform
	local ui = {}
	
	ui.Camera = transform:Find("Camera"):GetComponent("Camera")
	ui.Blocker = transform:Find("Panel/Blocker").gameObject
	ui.ButtonConfirm = transform:Find("Panel/ButtonConfirm").gameObject
	ui.InvitationCode = transform:Find("Panel/Code"):GetComponent("UIInput")
	ui.InvitationCodeSafeInput = UISafeInput:new(ui.SearchName)
	return ui
end
