CatchFishMainPanel  = {}

--init--
function CatchFishMainPanel.Init(obj)
	local transform = obj.transform
	local ui = {}

	ui.Camera = transform:Find("Camera"):GetComponent("Camera")

	ui.btnDone = transform:Find("Panel/BottomLayout/btnDone").gameObject
	ui.btnQuit = transform:Find("Panel/BottomLayout/btnQuit").gameObject

	local transCatchCardContent = transform:Find("Panel/CatchCardLayout")
	ui.CatchCardContent = transCatchCardContent:GetComponent("UITable")
	ui.btnCatchItem1 = transCatchCardContent:Find("CatchItem1/Bg").gameObject
	ui.btnCatchItem2 = transCatchCardContent:Find("CatchItem2/Bg").gameObject
	ui.btnCatchItem3 = transCatchCardContent:Find("CatchItem3/Bg").gameObject
	ui.btnCatchItem4 = transCatchCardContent:Find("CatchItem4/Bg").gameObject

	ui.objCatchItem1 = transCatchCardContent:Find("CatchItem1")
	ui.objCatchItem2 = transCatchCardContent:Find("CatchItem2")
	ui.objCatchItem3 = transCatchCardContent:Find("CatchItem3")
	ui.objCatchItem4 = transCatchCardContent:Find("CatchItem4")

	ui.Obstacles = {}
	ui.ObstaclesRoot = transform:Find("Panel/FishPool/Content/Obstacles")
	ui.ObstaclesRoot.gameObject:SetActive(false)
	for i = 1, ui.ObstaclesRoot.childCount do
		table.insert(ui.Obstacles, ui.ObstaclesRoot:GetChild(i - 1).gameObject)
	end

	ui.Grids = {}
	ui.GridsRoot = transform:Find("Panel/FishPool/Content/Grids")
	ui.GridsRoot.gameObject:SetActive(false)

	for i = 1, ui.GridsRoot.childCount do
		table.insert(ui.Grids, ui.GridsRoot:GetChild(i - 1):GetComponent("UISprite"))
	end
	ui.GetGridPos = function(ui, index)
		return ui.Grids[index].transform.localPosition
	end

	ui.FishesRoot = transform:Find("Panel/FishPool/Content/Fishes")
	ui.PerviewObjsRoot = transform:Find("Panel/FishPool/Content/PerviewObjs")
	ui.SortLayer3 = transform:Find("Panel/FishPool/Content/SortLayer3")


	--能量面板
	ui.EnergyLayout = transform:Find("Panel/EnergyLayout")
	ui.txtEnergy = ui.EnergyLayout:Find("txtEnergy"):GetComponent("UILabel")
	ui.btnAddEnergy = ui.EnergyLayout:Find("btnAddEnergy").gameObject

	--
	ui.ObjectPool = transform:Find("Panel/FishPool/Content/ObjectPool")
	ui.ObjectPool.gameObject:SetActive(false)
	ui.FishPrefab1_1 = ui.ObjectPool:Find("CatchFish_Fish1_1").gameObject
	ui.FishPrefab2_1 = ui.ObjectPool:Find("CatchFish_Fish2_1").gameObject
	ui.FishPrefab2_2 = ui.ObjectPool:Find("CatchFish_Fish2_2").gameObject
	ui.FishPrefab3_1 = ui.ObjectPool:Find("CatchFish_Fish3_1").gameObject
	ui.FishPrefab3_2 = ui.ObjectPool:Find("CatchFish_Fish3_2").gameObject
	ui.FishPrefab3_3 = ui.ObjectPool:Find("CatchFish_Fish3_3").gameObject
	ui.GoldFishPrefab = ui.ObjectPool:Find("CatchFish_GoldFish").gameObject

	ui.ArrowPrefab = ui.ObjectPool:Find("Arrow").gameObject
	ui.ScorePrefab = ui.ObjectPool:Find("Score").gameObject
	ui.CatchNet1 = ui.ObjectPool:Find("CatchNet1").gameObject
	ui.CatchNet2 = ui.ObjectPool:Find("CatchNet2").gameObject
	ui.CatchNet3 = ui.ObjectPool:Find("CatchNet3").gameObject
	ui.CatchNet4 = ui.ObjectPool:Find("CatchNet4").gameObject

	ui.ScoreAnimPrefab = ui.ObjectPool:Find("ScoreAnim").gameObject
	ui.ScoreSpecialAnimPrefab = ui.ObjectPool:Find("ScoreSpecialAnim").gameObject
	ui.EffectRipplePrefab = ui.ObjectPool:Find("EffectRipple").gameObject

	ui.EnumPrefabType = {
		None = 0,
		Fish1_1 = 1,
		Fish2_1 = 2,
		Fish2_2 = 3,
		Fish3_1 = 4,
		Fish3_2 = 5,
		Fish3_3 = 6,
		Arrow = 7,
		Score = 8,
	}

	ui.ObjPool = ObjectPool:new(ui.ObjectPool)
	ui.ObjPool:AddPrefab(EnumPrefabName.CatchFish_Fish1_1, ui.FishPrefab1_1)
	ui.ObjPool:AddPrefab(EnumPrefabName.CatchFish_Fish2_1, ui.FishPrefab2_1)
	ui.ObjPool:AddPrefab(EnumPrefabName.CatchFish_Fish2_2, ui.FishPrefab2_2)
	ui.ObjPool:AddPrefab(EnumPrefabName.CatchFish_Fish3_1, ui.FishPrefab3_1)
	ui.ObjPool:AddPrefab(EnumPrefabName.CatchFish_Fish3_2, ui.FishPrefab3_2)
	ui.ObjPool:AddPrefab(EnumPrefabName.CatchFish_Fish3_3, ui.FishPrefab3_3)
	ui.ObjPool:AddPrefab(EnumPrefabName.CatchFish_GoldFish_1, ui.GoldFishPrefab)

	ui.ObjPool:AddPrefab(EnumPrefabName.CatchFish_Net1, ui.CatchNet1)
	ui.ObjPool:AddPrefab(EnumPrefabName.CatchFish_Net2, ui.CatchNet2)
	ui.ObjPool:AddPrefab(EnumPrefabName.CatchFish_Net3, ui.CatchNet3)
	ui.ObjPool:AddPrefab(EnumPrefabName.CatchFish_Net4, ui.CatchNet4)

	ui.ObjPool:AddPrefab(EnumPrefabName.CatchFish_Arrow, ui.ArrowPrefab)
	ui.ObjPool:AddPrefab(EnumPrefabName.CatchFish_Score, ui.ScorePrefab)

	ui.ObjPool:AddPrefab(EnumPrefabName.CatchFish_ScoreAnim, ui.ScoreAnimPrefab)
	ui.ObjPool:AddPrefab(EnumPrefabName.CatchFish_SpecialScoreAnim, ui.ScoreSpecialAnimPrefab)
	ui.ObjPool:AddPrefab(EnumPrefabName.CatchFish_EffectRipple, ui.EffectRipplePrefab)

	--计分板(普通模式)
	ui.NormalScoreLayout = transform:Find("Panel/NormalScoreLayout").gameObject
	ui.NormalScoreLayoutView = UIView:new()
	ui.NormalScoreLayoutView:Bind(ui.NormalScoreLayout, {
		{"txtScore", "txtScore", "UILabel"},
		{"ProgressBarBG","ProgressBarBG"},
		{"imgProgressBar", "imgProgressBar", "UISprite"},
		{"StarContainer", "StarContainer", "UIWidget"},
		{"objStar1", "StarContainer/Star1"},
		{"objStar2", "StarContainer/Star2"},
		{"objStar3", "StarContainer/Star3"},
	})
	ui.NormalScoreLayoutView.InitStar = function(view, ratio1, ratio2, ratio3)
		local length = view.StarContainer.width
		local position = nil
		position = view.objStar1.transform.localPosition
		position.x = length * ratio1
		view.objStar1.transform.localPosition = position

		position = view.objStar2.transform.localPosition
		position.x = length * ratio2
		view.objStar2.transform.localPosition = position

		position = view.objStar3.transform.localPosition
		position.x = length * ratio3
		view.objStar3.transform.localPosition = position
	end
	ui.NormalScoreLayoutView.ShowStar = function(view, index, lighted)
		local trans = view["objStar" .. index].transform
		if not trans then
			return
		end
		trans:Find("Icon1").gameObject:SetActive(lighted)
		trans:Find("Icon2").gameObject:SetActive(not lighted)
	end
	ui.NormalScoreLayoutView.SetMode = function(view, type)
		if type == EnumCatchFishStageType.Normal then
			view.ProgressBarBG:SetActive(true)
			view.imgProgressBar.gameObject:SetActive(true)
			view.StarContainer.gameObject:SetActive(true)
		end
		if type == EnumCatchFishStageType.Challenge then
			view.ProgressBarBG:SetActive(false)
			view.imgProgressBar.gameObject:SetActive(false)
			view.StarContainer.gameObject:SetActive(false)
		end

	end

	--
	local description = {
		{"Boss", "Panel/Boss", "Animator"},
		{"BossDialog", "Panel/Effect/Effect_Dialog1", "Animator"},
		{"btnHelp", "Panel/btnHelp",},
	}
	ui.View = UIView:new()
	ui.View:Bind(obj, description)

	return ui
	end
