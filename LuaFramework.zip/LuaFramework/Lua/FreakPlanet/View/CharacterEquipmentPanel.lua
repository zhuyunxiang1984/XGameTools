CharacterEquipmentPanel  = {}

--init--
function CharacterEquipmentPanel.Init(obj)
	local transform = obj.transform
	local ui = {}
	
	ui.Camera = transform:Find("Camera"):GetComponent("Camera")
	ui.Blocker = transform:Find("Panel/Blocker").gameObject
	ui.ButtonChallenge = transform:Find("Panel/ButtonChallenge").gameObject
	ui.ButtonUpLevel = transform:Find("Panel/ButtonUpLevel").gameObject
	ui.PositionMark = transform:Find("Panel/PositionMark")

	ui.EquipmentIcon = transform:Find("Panel/Equipment/Icon"):GetComponent("UISprite")
	ui.EquipmentName = transform:Find("Panel/Equipment/Name"):GetComponent("UILabel")
	ui.EquipmentLevel = transform:Find("Panel/Equipment/Level"):GetComponent("UILabel")
	ui.EquipmentDesc = transform:Find("Panel/Equipment/Desc"):GetComponent("UILabel")
	ui.EquipmentRoot = transform:Find("Panel/Equipment/Root")

	ui.ItemPool = transform:Find("Panel/ItemPool")
	ui.SkillItemTemplate = transform:Find("Panel/Template/SkillItem").gameObject
	ui.AbilityItemTemplate = transform:Find("Panel/Template/AbilityItem").gameObject
	ui.LevelUpEffectAnimator = transform:Find("Panel/UpLevelEffect"):GetComponent("Animator")

	ui.EquipmentSlots = {}
	local slotRoot = transform:Find("Panel/Slots")
	for idx = 1, slotRoot.childCount do
		local item = slotRoot:GetChild(idx - 1)
		local icon = item:GetComponent("UISprite")
		ui.EquipmentSlots[idx] = {item = item.gameObject, icon = icon}
	end

	ui.UpLevelItems = {}
	ui.UpLevelItemRoot = transform:Find("Panel/UpLevelItems")
	for idx = 1, ui.UpLevelItemRoot.childCount do
		local item = ui.UpLevelItemRoot:GetChild(idx - 1)
		local num = item:Find("Num"):GetComponent("UILabel")
		ui.UpLevelItems[idx] = {item = item.gameObject, root = item, num = num}
	end

	return ui
end
