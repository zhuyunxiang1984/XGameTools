AlertBoxPanel  = {}

--init--
function AlertBoxPanel.Init(obj)
	local transform = obj.transform
	local ui = {}
	
	ui.Camera = transform:Find("Camera"):GetComponent("Camera")
	ui.Panel = transform:Find("Panel").gameObject
	ui.Message = transform:Find("Panel/Message"):GetComponent("UILabel")
	ui.ButtonConfirm = transform:Find("Panel/ButtonConfirm").gameObject

	return ui
end
