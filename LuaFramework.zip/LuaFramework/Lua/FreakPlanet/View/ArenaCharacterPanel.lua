ArenaCharacterPanel  = {}

--init--
function ArenaCharacterPanel.Init(obj)
	local transform = obj.transform
	local ui = {}
	
	ui.Camera = transform:Find("Camera"):GetComponent("Camera")
	ui.ButtonGo = transform:Find("TopPanel/ConstraintBottom/ButtonGo").gameObject
	ui.ButtonClose = transform:Find("TopPanel/ConstraintBottom/ButtonClose").gameObject
	ui.ButtonFilter = transform:Find("TopPanel/ButtonFilter").gameObject

	ui.ButtonCharacter = transform:Find("RolePanel/Tabs/Character"):GetComponent("UIButton")
	ui.ButtonPet = transform:Find("RolePanel/Tabs/Pet"):GetComponent("UIButton")
    ui.ButtonTeam = transform:Find("RolePanel/Tabs/Team"):GetComponent("UIButton")
    ui.ButtonCouple = transform:Find("RolePanel/Tabs/Couple"):GetComponent("UIButton")

	ui.CharacterPower = transform:Find("Panel/Power/Value"):GetComponent("UILabel")

	ui.ArenaInfoRoot = transform:Find("Panel/ArenaInfo")
	ui.ArenaEnemyIcon = transform:Find("Panel/ArenaInfo/EnemyIcon"):GetComponent("UISprite")
	ui.ArenaEnemyNameLabel = transform:Find("Panel/ArenaInfo/EnemyName"):GetComponent("UILabel")
	ui.ArenaEnemyElementIcon = transform:Find("Panel/ArenaInfo/EnemyElement"):GetComponent("UISprite")

	ui.ArenaBuffRoot = transform:Find("Panel/Buff").gameObject
	ui.ArenaBuffDesc = transform:Find("Panel/Buff/Label"):GetComponent("UILabel")

	ui.CharacterRoot = transform:Find("Panel/Characters")
	ui.CharacterPool = transform:Find("Panel/CharacterPool")
	ui.CharacterItemPool = transform:Find("RolePanel/CharacterItemPool")

	ui.PetRoot = transform:Find("Panel/Pet")
	ui.PetPool = transform:Find("Panel/PetPool")
	ui.PetItemPool = transform:Find("RolePanel/PetItemPool")

	ui.GlobalSkillHintAnimator = transform:Find("RolePanel/GlobalSkillHint"):GetComponent("Animator")
	ui.GlobalSkillValue = transform:Find("RolePanel/GlobalSkillHint/Value"):GetComponent("UILabel")

	ui.CharacterObjectTemplate = transform:Find("Panel/Template/CharacterObject").gameObject
	ui.SkillDialogObjectTemplate = transform:Find("RolePanel/Template/SkillDialog").gameObject
	ui.MemberSkillHintRoot = transform:Find("TopPanel/MemberSkillHintRoot")
	ui.MemberSkillHintPool = transform:Find("TopPanel/MemberSkillHintPool")
	ui.MemberSkillDialogRoot = transform:Find("RolePanel/MemberSkillDialogRoot")
	ui.MemberSkillDialogPool = transform:Find("RolePanel/MemberSkillDialogPool")

	ui.CharacterPositions = {}
	ui.DragHints = {}
	local positionRoot = transform:Find("Panel/Positions")
	for idx = 1, positionRoot.childCount do
		local positionItem = positionRoot:GetChild(idx - 1)
		local posRelativeToCharacterRoot = ui.CharacterRoot:InverseTransformPoint(positionItem.position)
		posRelativeToCharacterRoot.z = 0
		ui.CharacterPositions[idx] = posRelativeToCharacterRoot
		ui.DragHints[idx] = positionItem:Find("Hint").gameObject
	end

	ui.CharacterPositionHint = {}
	ui.CharacterPositionHintRoot = transform:Find("Panel/PositionHint")
	for idx = 1, ui.CharacterPositionHintRoot.childCount do
		local hintItem = ui.CharacterPositionHintRoot:GetChild(idx - 1)
		local animator = hintItem:GetComponent("Animator")
		local activeMark = hintItem:Find("Active").gameObject
		table.insert(ui.CharacterPositionHint, {item = hintItem, mark = activeMark, animator = animator})
	end
	ui.CharacterPositionHintUIGrid = ui.CharacterPositionHintRoot:GetComponent("UIGrid")

	-- role panel
	ui.ItemScrollView = transform:Find("RolePanel/ScrollView"):GetComponent("UIScrollView")
	ui.ItemGrid = transform:Find("RolePanel/ScrollView/Grid")
	ui.ItemGridWrap = ui.ItemGrid:GetComponent("WrapVerticalGrid")

    -- team
    ui.TeamScrollView = transform:Find("RolePanel/TeamScrollView"):GetComponent("UIScrollView")
    ui.TeamGrid = transform:Find("RolePanel/TeamScrollView/Grid")
    ui.ButtonTeamSort = transform:Find("RolePanel/ButtonTeamSort").gameObject
    ui.ButtonTeamSortConfirm = transform:Find("RolePanel/ButtonTeamSortConfirm").gameObject
    ui.ButtonTeamDelete = transform:Find("RolePanel/ButtonTeamDelete").gameObject
    ui.ButtonTeamDeleteConfirm = transform:Find("RolePanel/ButtonTeamDeleteConfirm").gameObject

    -- couple
    ui.CoupleScrollView = transform:Find("RolePanel/CoupleScrollView"):GetComponent("UIScrollView")
    ui.CoupleGrid = transform:Find("RolePanel/CoupleScrollView/Grid")

	-- drag limit
	local leftLimit = transform:Find("Panel/PositionLimit/Left")
	local rightLimit = transform:Find("Panel/PositionLimit/Right")

	local leftLimitPosition = ui.CharacterRoot:InverseTransformPoint(leftLimit.position)
	local rightLimitPosition = ui.CharacterRoot:InverseTransformPoint(rightLimit.position)
	
	ui.LimitMin = leftLimitPosition.x
	ui.LimitMax = rightLimitPosition.x

	-- sort
    ui.ButtonSort = transform:Find("TopPanel/ButtonSort").gameObject
    ui.SortRoot = transform:Find("TopPanel/SortRoot").gameObject
    ui.SortAbilityRoot = transform:Find("TopPanel/SortRoot/Abilities")
    ui.SortAbilityItems = {}
    for idx = 1, ui.SortAbilityRoot.childCount do
        local item = ui.SortAbilityRoot:GetChild(idx - 1)
        local abilityId = tonumber(item.gameObject.name)
        local selected = item:Find("Selected").gameObject
        local unselected = item:Find("UnSelected").gameObject
        ui.SortAbilityItems[abilityId] = {item = item.gameObject, selected = selected, unselected = unselected}
    end
    ui.SortPower = transform:Find("TopPanel/SortRoot/Power").gameObject
    ui.SortPowerSelected = transform:Find("TopPanel/SortRoot/Power/Selected").gameObject
    ui.SortPowerUnselected = transform:Find("TopPanel/SortRoot/Power/UnSelected").gameObject

    -- couple
    ui.CoupleHintRoot = transform:Find("TopPanel/CoupleHintRoot")
    ui.CoupleHintPool = transform:Find("TopPanel/CoupleHintPool")
    ui.CoupleAvatarPool = transform:Find("TopPanel/CoupleAvatarPool")

    return ui
end
