CharacterAppearancePanel  = {}

--init--
function CharacterAppearancePanel.Init(obj)
	local ui = UIView:new()
	ui:Bind(obj, {
		{"Camera", "Camera", "Camera"},
		{"Blocker", "BackPanel/Blocker"},

		{"AvatarRoot", "Panel/AvatarRoot", "Transform"},
		{"AvatarRootInMirror", "Panel/AvatarRootInMirror", "Transform"},
		{"ScrollViewObj", "Panel/ScrollView"},

		{"btnDressUp", "Panel/btnDressUp"},
		{"btnDressDown", "Panel/btnDressDown"},

		{"dressUpLayout", "Panel/btnDressUp/Layout", "UITable"},
		{"txtCostText1", "Panel/btnDressUp/Layout/txtCostText1", "UILabel"},
		{"imgCostIcon", "Panel/btnDressUp/Layout/imgCostIcon", "UISprite"},
		{"txtCostText2", "Panel/btnDressUp/Layout/txtCostText2", "UILabel"},

		{"ObjectPool"	, "Panel/ObjectPool"},
		{"RowPrefab"		, "Panel/ObjectPool/RowPrefab"},
		{"AppearancePrefab", "Panel/ObjectPool/AppearancePrefab"},
	})

	ui.ScrollView = UIScrollView:new(ui.ScrollViewObj, false)

	ui.EnumPrefabType = {
		None = 0,
		Row = 1,
		Appearance = 2,
	}
	ui.ObjPool = ObjectPool:new()
	ui.ObjPool:AddPrefab(ui.EnumPrefabType.Row, ui.RowPrefab)
	ui.ObjPool:AddPrefab(ui.EnumPrefabType.Appearance, ui.AppearancePrefab)

	ui.ViewManager = UIViewManager:new()
	ui.ViewManager:AddDescription(ui.EnumPrefabType.Appearance, {
		{"BG", "BG", "UISprite"},
		{"txtName", "txtName", "UILabel"},
		{"imgIcon", "imgIcon", "UISprite"},
		{"Select", "Select"},
		{"Addressed", "Addressed"},
	})

	return ui
end
