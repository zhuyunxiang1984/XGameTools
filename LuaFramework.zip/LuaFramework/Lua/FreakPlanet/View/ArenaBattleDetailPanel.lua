ArenaBattleDetailPanel  = {}

--init--
function ArenaBattleDetailPanel.Init(obj)
	local transform = obj.transform
	local ui = {}
	
	ui.Camera = transform:Find("Camera"):GetComponent("Camera")
	ui.Blocker = transform:Find("Panel/Blocker").gameObject
	ui.ButtonConfirm = transform:Find("Panel/ButtonConfirm").gameObject
	ui.EnemyCollider = transform:Find("Panel/Enemy").gameObject

	ui.DoneMark = transform:Find("Panel/Done").gameObject
	ui.RecommendLevel = transform:Find("Panel/RecommendLevel"):GetComponent("UILabel")
	ui.BattleDesc = transform:Find("Panel/BattleDesc"):GetComponent("UILabel")
	ui.BattleRewards = {}
	local rewardRoot = transform:Find("Panel/Rewards")
	for idx = 1, rewardRoot.childCount do
		local item = rewardRoot:GetChild(idx - 1)
		ui.BattleRewards[idx] = {item = item.gameObject, root = item}
	end

	ui.EnemyIcon = transform:Find("Panel/Enemy/Icon"):GetComponent("UISprite")
	ui.EnemyName = transform:Find("Panel/Enemy/Name"):GetComponent("UILabel")
	ui.EnemyPower = transform:Find("Panel/Enemy/Power"):GetComponent("UILabel")
	ui.EnemyElement = transform:Find("Panel/Enemy/Element"):GetComponent("UISprite")

	ui.SelectedDifficulty = transform:Find("Panel/SelectedDifficulty"):GetComponent("UILabel")
	ui.BattleDifficulties = {}
	ui.BattleDifficultyRoot = transform:Find("Panel/Difficulty")
	for idx = 1, ui.BattleDifficultyRoot.childCount do
		local item = ui.BattleDifficultyRoot:GetChild(idx - 1)
		local selected = item:Find("Selected").gameObject
		local unlocked = item:Find("Unlocked").gameObject

		ui.BattleDifficulties[idx] = {item = item.gameObject, selected = selected, unlocked = unlocked}
	end
	
	return ui
end
