local class = require "FreakPlanet/Utils/middleclass"

-----------------------------------------------------------------
-- base state
State = class("State")

function State:Enter()
	if self._enterAction ~= nil then
		if self._enterReceiver ~= nil then
			if self._enterParameter == nil then
				self._enterAction(self._enterReceiver)
			else
				self._enterAction(self._enterReceiver, self._enterParameter)
			end
		else
			if self._enterParameter == nil then
				self._enterAction()
			else
				self._enterAction(self._enterParameter)
			end
		end
	end

	self:EnterImpl()
end

function State:EnterImpl()

end

function State:Tick(deltaTime)
	local entered = self._entered or false
	if not entered then
		self:Enter()
		self._entered = true
	end

	local finished = self:TickImpl(deltaTime)

	if finished then
		local exited = self._exited or false
		if not exited then
			self:Exit()
			self._exited = true
		end
	end

	return finished
end

function State:TickImpl(deltaTime)
	return false
end

function State:Exit()
	self:ExitImpl()

	if self._exitAction ~= nil then
		if self._exitReceiver ~= nil then
			if self._exitParameter == nil then
				self._exitAction(self._exitReceiver)
			else
				self._exitAction(self._exitReceiver, self._exitParameter)
			end
		else
			if self._exitParameter == nil then
				self._exitAction()
			else
				self._exitAction(self._exitParameter)
			end
		end
	end
end

function State:ExitImpl()

end

function State:ActionOnEnter(action, receiver, parameter)
	self._enterAction = action
	self._enterReceiver = receiver
	self._enterParameter = parameter
end

function State:ActionOnExit(action, receiver, parameter)
	self._exitAction = action
	self._exitReceiver = receiver
	self._exitParameter = parameter
end

function State:GetName()
	return self.class.name
end

function State:Dump()
	return self:GetName()
end

-----------------------------------------------------------------
-- timer state
TimerState = class("TimerState", State)

function TimerState:initialize(duration)
	self._leftTime = duration
end

function TimerState:TickImpl(deltaTime)
	self._leftTime = self._leftTime - deltaTime
	return (self._leftTime <= 0)
end

-----------------------------------------------------------------
-- parallel state: grouped by the other states in parallel
ParallelState = class("ParallelState", State)

function ParallelState:initialize(...)
	self._states = {}
	local states = {...}
	for idx = 1, #states do
		self._states[idx] = states[idx]
	end
end

function ParallelState:Push(state)
	table.insert(self._states, state)
end

function ParallelState:TickImpl(deltaTime)
	for idx = #self._states, 1, -1 do
		local stateFinished = self._states[idx]:Tick(deltaTime)
		if stateFinished then
			table.remove(self._states, idx)
		end
	end

	return #self._states == 0
end

function ParallelState:Dump()
	local str = self:GetName()..": Count = "..tostring(#self._states)..": "
	for idx = 1, #self._states do
		str = str..self._states[idx]:Dump()

		if idx < #self._states then
			str = str..", "
		end
	end

	return str
end
-----------------------------------------------------------------
-- Sequence state: grouped by the other states in a sequence
SequenceState = class("SequenceState", State)

function SequenceState:initialize(...)
	self._states = {}
	local states = {...}
	for idx = 1, #states do
		self._states[idx] = states[idx]
	end
end

function SequenceState:Push(state)
	table.insert(self._states, state)
end

function SequenceState:TickImpl(deltaTime)
	local state = self._states[1]
	local stateFinished = state:Tick(deltaTime)

	if stateFinished then
		table.remove(self._states, 1)
	end

	return #self._states == 0
end

function SequenceState:Dump()
	local str = self:GetName()..": Count = "..tostring(#self._states)..": "
	for idx = 1, #self._states do
		str = str..self._states[idx]:Dump()

		if idx < #self._states then
			str = str..", "
		end
	end

	return str
end
-----------------------------------------------------------------
SkeletonAnimationState = class("SkeletonAnimationState", State)

function SkeletonAnimationState:initialize(skeletonAnimation, animationName, nextAnimationName, go)
	self._skeletonAnimation = skeletonAnimation
	self._animationName = animationName
	self._nextAnimationName = nextAnimationName
	self._gameObject = go
end

function SkeletonAnimationState:EnterImpl()
	if self._gameObject ~= nil then
		self._gameObject:SetActive(true)
	end
	Helper.PlayAnimation(self._skeletonAnimation, self._animationName, false)
end

function SkeletonAnimationState:TickImpl(deltaTime)
	local finished = false
	if Helper.IsAnimationEnd(self._skeletonAnimation) then
		finished = true
	end

	return finished
end

function SkeletonAnimationState:ExitImpl()
	if self._nextAnimationName ~= nil then
		Helper.PlayAnimation(self._skeletonAnimation, self._nextAnimationName, true)
	end
end

-----------------------------------------------------------------
AnimatorState = class("AnimatorState", State)

function AnimatorState:initialize(animator, animationName, nextAnimationName, go)
	self._animator = animator
	self._animationName = animationName
	self._nextAnimationName = nextAnimationName
	self._gameObject = go
end

function AnimatorState:EnterImpl()
	if self._gameObject ~= nil then
		self._gameObject:SetActive(true)
	end
	
	self._animator:Play(self._animationName, 0, 0)
end

function AnimatorState:TickImpl(deltaTime)
	local finished = false
	if Helper.IsUnityAnimationEndWithName(self._animator, self._animationName, 0) then
		finished = true
	end

	return finished
end

function AnimatorState:ExitImpl()
	if self._nextAnimationName ~= nil then
		self._animator:Play(self._nextAnimationName, 0, 0)
	end
end

-----------------------------------------------------------------
MoveInXState = class("MoveInXState", State)

function MoveInXState:initialize(mover, targetX, moveSpeed, skeleton, moveAnimationName, idleAnimationName)
	self._mover = mover
	self._startX = self._mover.localPosition.x
	self._targetX = targetX
	self._moveDuration = math.abs((self._targetX - self._startX) / moveSpeed)
	self._skeleton = skeleton
	self._moveAnimation = moveAnimationName
	self._idleAnimation = idleAnimationName
end

function MoveInXState:EnterImpl()
	self._movedTime = 0
	if self._skeleton ~= nil and self._moveAnimation ~= nil then
		Helper.PlayAnimation(self._skeleton, self._moveAnimation, true)
	end
end

function MoveInXState:TickImpl(deltaTime)
	self._movedTime = self._movedTime + deltaTime
	self._movedTime = math.min(self._movedTime, self._moveDuration)

	local currentPos = self._mover.localPosition
	currentPos.x = self._startX + (self._targetX - self._startX) * self._movedTime / self._moveDuration
	self._mover.localPosition = currentPos

	return (self._movedTime >= self._moveDuration)
end

function MoveInXState:ExitImpl()
	if self._skeleton ~= nil and self._idleAnimation ~= nil then
		Helper.PlayAnimation(self._skeleton, self._idleAnimation, true)
	end
end

-----------------------------------------------------------------
LerpMoveState = class("LerpMoveState", State)

function LerpMoveState:initialize(mover, startPositon, endPosition, moveTime)
	self._mover = mover
	self._startPosition = startPositon
	self._endPosition = endPosition
	self._moveTime = moveTime

	local diff = (endPosition - startPositon)
	Helper.CheckDirection(mover, diff.x)
end

function LerpMoveState:EnterImpl()
	self._currentTime = 0
end

function LerpMoveState:TickImpl(deltaTime)
	self._currentTime = self._currentTime + deltaTime
	local t = self._currentTime / self._moveTime
	t = math.min(1, t)
	t = math.max(0, t)

	local currentPos = self._mover.localPosition
	currentPos.x = self._startPosition.x * (1 - t) + self._endPosition.x * t
	currentPos.y = self._startPosition.y * (1 - t) + self._endPosition.y * t
	currentPos.z = currentPos.y
	self._mover.localPosition = currentPos

	return self._currentTime >= self._moveTime
end

-----------------------------------------------------------------
TransformState = class("TransformState", State)

function TransformState:initialize(mover, target, speed, acceleration, checkX, checkY)
	self._mover = mover
	self._target = target
	self._speed = speed
	self._acceleration = acceleration

	self._checkX = checkX or false
	self._checkY = checkY or false

	if not self._checkX and not self._checkY then
		self._checkY = true
	end
end

function TransformState:EnterImpl()
	local currentX = self._mover.localPosition.x
	if currentX < self._target.x then
		self._directionX = 1
	else
		self._directionX = -1
	end

	local currentY = self._mover.localPosition.y
	if currentY < self._target.y then
		self._directionY = 1
	else
		self._directionY = -1
	end
	self._finishedInX = false
	self._finishedInY = false
end

function TransformState:TickImpl(deltaTime)
	local currentPos = self._mover.localPosition
	local speed = self._speed
	local targetX = self._target.x
	local targetY = self._target.y

	if not self._finishedInX then
		if (currentPos.x - targetX) * self._directionX >= 0 then
			currentPos.x = self._target.x
			self._finishedInX = true
		else
			speed.x = speed.x + self._acceleration.x * deltaTime
			currentPos.x = currentPos.x + speed.x * deltaTime
		end
	end

	if not self._finishedInY then
		if (currentPos.y - targetY) * self._directionY >= 0 then
			currentPos.y = self._target.y
			self._finishedInY = true
		else
			speed.y = speed.y + self._acceleration.y * deltaTime
			currentPos.y = currentPos.y + speed.y * deltaTime
		end
	end

	self._speed = speed
	self._mover.localPosition = currentPos

	return (not self._checkX or self._finishedInX) and (not self._checkY or self._finishedInY)
end

-----------------------------------------------------------------
ScaleState = class("ScaleState", State)

function ScaleState:initialize(transform, from, to, duration)
	self._transform = transform
	self._from = from
	self._to = to
	self._duration = duration
end

function ScaleState:EnterImpl()
	self._currentTime = 0
end

function ScaleState:TickImpl(deltaTime)
	self._currentTime = self._currentTime + deltaTime
	self._currentTime = math.min(self._currentTime, self._duration)
	local f = self._currentTime / self._duration
	local scaleFactor = Helper.Lerp(self._from, self._to, f)
	self._transform.localScale = Vector3.one * scaleFactor

	return self._currentTime >= self._duration
end

-----------------------------------------------------------------
WorkShopDialogState = class("WorkShopDialogState", State)

function WorkShopDialogState:initialize(workShopId, dialogId, charcterIdx, showTime, enterFunc, exitFunc, receiver)
	self._workShopId = workShopId
	self._dialogId = dialogId
	self._characterIdx = charcterIdx
	self._showTime = showTime

	self._enterFunc = enterFunc
	self._exitFunc = exitFunc
	self._funcReceiver = receiver
end

function WorkShopDialogState:EnterImpl()
	self._currentTime = 0
	if self._funcReceiver == nil then
		self._dialogItem = self._enterFunc( self._workShopId, self._dialogId, self._characterIdx)
	else
		self._dialogItem = self._enterFunc(self._funcReceiver, self._workShopId, self._dialogId, self._characterIdx)
	end
end

function WorkShopDialogState:TickImpl(deltaTime)
	self._currentTime = self._currentTime + deltaTime
	return self._currentTime >= self._showTime
end

function WorkShopDialogState:ExitImpl()
	if self._funcReceiver == nil then
		self._exitFunc(self._dialogItem)
	else
		self._exitFunc(self._funcReceiver, self._dialogItem)
	end
end

-----------------------------------------------------------------
CallMethodState = class("CallMethodState", State)
function CallMethodState:initialize(method)
	self.Method = method
end
function CallMethodState:EnterImpl()

end
function CallMethodState:TickImpl(deltaTime)
	self.Method()
	return true
end
function CallMethodState:ExitImpl()

end


TweenState = class("TweenState", State)

function TweenState:initialize(mover,initPos,targetPos, speed)
	self._mover = mover
	self._initPos = initPos
	self._targetPos = targetPos
	self._speed = speed
end

function TweenState:EnterImpl()
	self._Finished = false
	self._Angle = self._targetPos - self._initPos
	self._mover.transform.localPosition = self._initPos
end

function TweenState:TickImpl(deltaTime)
	local currentPos = self._mover.localPosition
	local speed = self._speed
	if not self._Finished then
		self._mover.transform:Translate(self._Angle * deltaTime *speed* 0.01)
	end
	if math.abs(currentPos.x - self._targetPos.x) < 0.1 and math.abs(currentPos.y - self._targetPos.y) < 0.1  then
		self._Finished = true
		return true
	end
	return false
end