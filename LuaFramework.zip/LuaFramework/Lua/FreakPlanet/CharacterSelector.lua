CharacterSelector = {}

local this = CharacterSelector

CharacterStatus = {
	Idle = "Idle",
	Explore = "Explore",
	WorkShop = "WorkShop",
	ActivityExplore = "ActivityExplore",
}

CharacterSelectMode = {
	Explore = "Explore",
	Challenge = "Challenge",
	WorkShop = "WorkShop",
	Arena = "Arena",
	SpaceTravelChat = "SpaceTravelChat",
	ActivityExplore = "ActivityExplore",
	ActivityBattle = "ActivityBattle",
	CatchFish = "CatchFish",
}

--------------------------------------------------------------------------------------
function CharacterSelector.CheckSelectedCharacters(areaId, numLimit)
	-- saved characters
	local savedCharacters = GameData.GetPlanetAreaExploreCharacters(areaId)

	for idx = #savedCharacters, 1, -1 do
		local characterId = savedCharacters[idx]
		local keepCharacter = true

		if keepCharacter then
			keepCharacter = GameData.IsCharacterUnlocked(characterId)
		end

		if keepCharacter then
			keepCharacter = not GameData.IsBusyCharacter(characterId, CharacterSelectMode.Explore)
		end

		if not keepCharacter then
			table.remove(savedCharacters, idx)
		end
	end

	-- exceed the num limit
	for idx = #savedCharacters, numLimit + 1, -1 do
		table.remove(savedCharacters, idx)
	end

	return savedCharacters
end

function CharacterSelector.CheckSelectedPet(areaId)
	-- saved pet
	local savedPet = GameData.GetPlanetAreaExplorePet(areaId)
	
	if ConfigUtils.IsValidItem(savedPet) then
		local unlocked = GameData.IsPetUnlocked(savedPet)
		local isBusy = GameData.IsBusyPet(savedPet, CharacterSelectMode.Explore)
		if not unlocked or isBusy then
			savedPet = nil
		end
	else
		savedPet = nil
	end

	return savedPet
end

--------------------------------------------------------------------------------------
function CharacterSelector.CheckActivityExploreSelectedCharacters(themeId, numLimit)
	local savedCharacters = GameData.GetActivityExploreCharacters(themeId)

	for idx = #savedCharacters, 1, -1 do
		local characterId = savedCharacters[idx]
		local keepCharacter = true

		if keepCharacter then
			keepCharacter = GameData.IsCharacterUnlocked(characterId)
		end

		if keepCharacter then
			keepCharacter = not GameData.IsBusyCharacter(characterId, CharacterSelectMode.ActivityExplore)
		end

		if not keepCharacter then
			table.remove(savedCharacters, idx)
		end
	end

	-- exceed the num limit
	for idx = #savedCharacters, numLimit + 1, -1 do
		table.remove(savedCharacters, idx)
	end

	return savedCharacters
end

function CharacterSelector.GetActivityExploreSelectedPet(themeId)
	-- saved pet
	local savedPet = GameData.GetActivityExplorePet(themeId)

	if ConfigUtils.IsValidItem(savedPet) then
		local unlocked = GameData.IsPetUnlocked(savedPet)
		local isBusy = GameData.IsBusyPet(savedPet, CharacterSelectMode.ActivityExplore)
		if not unlocked or isBusy then
			savedPet = nil
		end
	else
		savedPet = nil
	end

	return savedPet
end
--------------------------------------------------------------------------------------
function CharacterSelector.CheckActivityBattleSelectedCharacters(battleId, numLimit)
	local savedCharacters = GameData.GetActivityBattleCharacters(battleId)
	local exploreRules = ConfigUtils.GetActivityBattleRules(battleId)

	for idx = #savedCharacters, 1, -1 do
		local characterId = savedCharacters[idx]
		local keepCharacter = true

		if keepCharacter then
			keepCharacter = GameData.IsCharacterUnlocked(characterId)
		end

		if keepCharacter then
			keepCharacter = ConfigUtils.IsCharacterMatchExploreRules(exploreRules, characterId)
		end

		if not keepCharacter then
			table.remove(savedCharacters, idx)
		end
	end

	-- exceed the num limit
	for idx = #savedCharacters, numLimit + 1, -1 do
		table.remove(savedCharacters, idx)
	end

	return savedCharacters
end

function CharacterSelector.GetActivityBattleSelectedPet(battleId)
	-- saved pet
	local savedPet = GameData.GetActivityBattlePet(battleId)

	if ConfigUtils.IsValidItem(savedPet) then
		if not GameData.IsPetUnlocked(savedPet) then
			savedPet = nil
		end
	else
		savedPet = nil
	end

	return savedPet
end
--------------------------------------------------------------------------------------
function CharacterSelector.CheckArenaSelectedCharacters(battleId, numLimit)
	local savedCharacters = GameData.GetArenaBattleCharacters(battleId)

	for idx = #savedCharacters, 1, -1 do
		local characterId = savedCharacters[idx]
		local keepCharacter = true

		if keepCharacter then
			keepCharacter = GameData.IsCharacterUnlocked(characterId)
		end

		if not keepCharacter then
			table.remove(savedCharacters, idx)
		end
	end

	-- exceed the num limit
	for idx = #savedCharacters, numLimit + 1, -1 do
		table.remove(savedCharacters, idx)
	end

	return savedCharacters
end

function CharacterSelector.GetAreanaSelectedPet(battleId)
	-- saved pet
	local savedPet = GameData.GetArenaBattlePet(battleId)

	if ConfigUtils.IsValidItem(savedPet) then
		if not GameData.IsPetUnlocked(savedPet) then
			savedPet = nil
		end
	else
		savedPet = nil
	end

	return savedPet
end
--------------------------------------------------------------------------------------
function CharacterSelector.CheckChallengeSelectedCharacters(challengeId, numLimit)
	local savedCharacters = GameData.GetChallengeBattleCharacters(challengeId)
	local exploreRules = ConfigUtils.GetChallengeExploreRules(challengeId)

	for idx = #savedCharacters, 1, -1 do
		local characterId = savedCharacters[idx]
		local keepCharacter = true

		if keepCharacter then
			keepCharacter = GameData.IsCharacterUnlocked(characterId)
		end

		if keepCharacter then
			keepCharacter = ConfigUtils.IsCharacterMatchExploreRules(exploreRules, characterId)
		end

		if not keepCharacter then
			table.remove(savedCharacters, idx)
		end
	end

	-- exceed the num limit
	for idx = #savedCharacters, numLimit + 1, -1 do
		table.remove(savedCharacters, idx)
	end

	return savedCharacters
end

function CharacterSelector.GetChallengeSelectedPet(challengeId)
	-- saved pet
	local savedPet = GameData.GetChallengeBattlePet(challengeId)

	if ConfigUtils.IsValidItem(savedPet) then
		if not GameData.IsPetUnlocked(savedPet) then
			savedPet = nil
		end
	else
		savedPet = nil
	end

	return savedPet
end
--------------------------------------------------------------------------------------