local json = require "cjson"

local HEART_INTERVAL = 120 --seconds
local GENERAL_PRIORITY = 5
local REQUEST_RETRY_LIMIT = 1
local NO_RESPONSE_STATUS_CODE = -100
local LOG_TAG = "NetManager"

local ErrorCode = {
	None = 0,
	HintError = 1,
	FatalError = 2,
	SessionOutdateError = 3,
	NoResponse = 4,
	IapError = 5,
}

NetManager = {}

local this = NetManager

local _requestList = nil
local _requesting = false
local _suspended = false
local _heartTime = 0
local _singleDialog = true --强制重新开始

local _loginSession = nil

--------------------------------------------------------------------------------------------
-- remark: 一旦触发错误并弹出对话框，这个时候网络传输是停止的；除非对话框关掉，才会开始下一条协议
-- remakr: to use gzip, add header content-encoding = "gzip"

local function SetBestHttpParameter()
	--BestHTTP.HTTPManager.IsCookiesEnabled = true
	--BestHTTP.HTTPManager.KeepAliveDefaultValue = true
	--BestHTTP.HTTPManager.IsCachingDisabled = true
	--BestHTTP.HTTPManager.Proxy = BestHTTP.HTTPProxy.New(System.Uri.New("https://baidu.com"))
end

local function GenerateGuid()
	local seed = {'e','1','2','3','4','5','6','7','8','9','a','b','c','d','e','f'}
    local tb = {}
    for i = 1,32 do
        table.insert(tb, seed[math.random(1,16)])
    end
    local sid = table.concat(tb)
    return string.format('%s-%s-%s-%s-%s',
        string.sub(sid,1,8),
        string.sub(sid,9,12),
        string.sub(sid,13,16),
        string.sub(sid,17,20),
        string.sub(sid,21,32)
    )
end

local function JsonConvert(obj)
	local t = type(obj)
	if t == "table" then
        for k, v in pairs(obj) do
        	if v == nil or v == json.null then
        		obj[k] = {}
        	else
        		JsonConvert(v)
        	end
        end
    end
end

local function GetUrlAndHostByProto(proto)
	if proto == "ServerInfoSimple" then
		local gateSever = Global.GateAddress
		local url = Global.GateUrlOf(gateSever)
		return url, Global.GateHost, Global.ShouldUseProxy(Global.ServerType.Gate)
	end

	return Global.GameUrl, Global.GameHost, Global.ShouldUseProxy(Global.ServerType.Game)
end

local function GetHttpMethodByProto(proto)
	if proto == "ServerInfoSimple" then
		return BestHTTP.HTTPMethods.Post
	end

	return BestHTTP.HTTPMethods.Post
end

local function PackData(proto, rawData)
	local guid = GenerateGuid()
	rawData.Guid = guid
	local protoUrl, protoHost, useProxy = GetUrlAndHostByProto(proto)
	local uri = protoUrl.."PlanetGame/"..proto
	local encodedData = json.encode(rawData)
	log("pack proto: "..proto.."; uri: "..uri.."; json data: "..encodedData)
	-- gzip and encrypt
	encodedData = DataDecode.EncryptLuaProto(encodedData, false, ScriptBridge.EntryP)

	local fields = DictString.New()
	fields:Add("m", encodedData)
	fields:Add("guid", guid)

	local headers = DictString.New()
	headers:Add("Host", protoHost)
	headers:Add("gzip", "0")
	-- used id
	if _loginSession ~= nil then
		local _, _, usedId = GameData.GetDefaultAccountInfo()
		headers:Add("Userid", usedId)
		headers:Add("Session", _loginSession)
		fields:Add("Userid", usedId)
		fields:Add("Session", _loginSession)
	end

	return uri, fields, headers, useProxy
end

local function UnpackData(proto, rawData)
	local decodedData = DataDecode.DecryptLuaProto(rawData, false, ScriptBridge.EntryP)
	if Helper.IsEmptyOrNull(decodedData) then
		return {StatusCode = NO_RESPONSE_STATUS_CODE}
	end

	log("unpack proto: "..proto.."; data: "..decodedData)
	decodedData = json.decode(decodedData)
	JsonConvert(decodedData)
	return decodedData
end

function NetManager.Init()
	_heartTime = HEART_INTERVAL
	_requesting = false
	_suspended = false
	_requestList = {}
	_loginSession = nil

	SetBestHttpParameter()

end

function NetManager.SetLoginSession(session)
	_loginSession = session
end

function NetManager.GetLoginSession()
	return _loginSession
end

function NetManager.Update(deltaTime)
	if _suspended then
		return
	end

	-- update heart after logined
	if _loginSession ~= nil then
		_heartTime = _heartTime - deltaTime
		if _heartTime <= 0 then
			this.SendHeart(false)
		end
	end

	if not _requesting and #_requestList > 0 then
		this.PeekNextRequest()
	end
end

function NetManager.Clear()
	_requestList = {}
end

function NetManager.AcceptInput()
	return _suspended or not _requesting
end

function NetManager.OnResume()
	assert(_loginSession ~= nil, "net manager on resume only can be called when has account logined")

	this.SendHeart(true)
	this.SendServerTime(true)
end

function NetManager.SendServerTime(force)
	local proto = "ServerTime"
	local protoIdx = this.FindProtoIndex(proto)
	if protoIdx ~= nil then
		this.ForceRemoveProto(proto)
	end

	local data = {Force = force}
	this.Send(proto, data, NetManager.OnHandleServerTime, nil)
end

function NetManager.SendMailList()
	local proto = "MailList"
	local protoIdx = this.FindProtoIndex(proto)
	if protoIdx ~= nil then
		return
	end

	this.Send(proto, {}, this.OnHandleHeart, nil)
end

function NetManager.SendHeart(force)
	_heartTime = HEART_INTERVAL

	local proto = "Heart"
	local protoIdx = this.FindProtoIndex(proto)
	if not force and protoIdx ~= nil then
		return
	end

	if protoIdx ~= nil then
		this.ForceRemoveProto(proto)
	end

	local playTime = math.floor(GameData.GetCurrentPlayTime())
	local data = {PlayTime = playTime}
	this.Send(proto, data, NetManager.OnHandleHeart, nil)
end

function NetManager.Send(proto, data, callback, receiver, forceRestart)
	data = data or {}
	local req = {proto = proto, data = data, callback = callback, receiver = receiver, retry = 0, forceRestart = forceRestart}
	table.insert(_requestList, req)

	-- successed
	return true
end

function NetManager.DownloadTexture(uri, callback)
	httpMgr:DoDownloadTexture(uri, nil, BestHTTP.HTTPMethods.Get, callback)
end

function NetManager.ForceSend(proto, data, callback, receiver)
	data = data or {}
	local req = {proto = proto, data = data, callback = callback, receiver = receiver, retry = 0}
	table.insert(_requestList, 1, req)

	-- successed
	return true
end

function NetManager.PeekNextRequest()
	NetworkLoadingCtrl.Show()
	local proto = _requestList[1].proto
	local data = _requestList[1].data
	local method = GetHttpMethodByProto(proto)
	_requestList[1].retry = _requestList[1].retry + 1
	_requesting = true
	if _requestList[1].forceRestart == nil then
		_singleDialog = true
	else
		_singleDialog = _requestList[1].forceRestart
	end
	local uri, fields, headers, useProxy = PackData(proto, data)
	XDebug.LogTable(LOG_TAG, "发送协议 " .. tostring(proto), data)
	httpMgr:SendRequest(proto, uri, method, useProxy, fields, headers, this.OnRequestResult, GENERAL_PRIORITY)
end

function NetManager.FinishRequest(proto, decodedData)
	local protoIdx = this.FindProtoIndex(proto)
	assert(protoIdx ~= nil, "no proto in the request list: "..tostring(proto))

	local callback = _requestList[protoIdx].callback
	if callback ~= nil then
		local requestData = _requestList[protoIdx].data
		local receiver = _requestList[protoIdx].receiver
		if receiver ~= nil then
			callback(receiver, proto, decodedData, requestData)
		else
			callback(proto, decodedData, requestData)
		end
	end

	table.remove(_requestList, protoIdx)
	_requesting = false
end

function NetManager.FindProtoIndex(proto)
	for idx = 1, #_requestList do
		if _requestList[idx].proto == proto then
			return idx
		end
	end

	return nil
end

function NetManager.ForceRemoveProto(proto)
	local protoIdx = nil
	for idx = #_requestList, 1, -1 do
		if proto == _requestList[idx].proto then
			protoIdx = idx
			break
		end
	end

	if protoIdx ~= nil then
		table.remove(_requestList, protoIdx)
	end
end

local function CheckRequestResult(request)
	local state = request.State
	local errorMsg = "<Unknow>"
	if state == BestHTTP.HTTPRequestStates.Finished then
		local response = request.Response
		if response.IsSuccess then
			return true
		else
			local info = string.format("request finished successfully, but the server sent an error. status code:%s-%s, message:%s", 
				response.StatusCode,
				response.Message,
				response.DataAsText)
			log(info)
			errorMsg = "服务器连接出错，错误码："..tostring(response.StatusCode)
		end
	elseif state == BestHTTP.HTTPRequestStates.Error then
		if request.Exception ~= nil then
			log("request finished with error: "..tostring(request.Exception.Message).."\n"..tostring(request.Exception.StackTrace))
			errorMsg = "服务器连接出现异常:\n"..tostring(request.Exception.Message)
		else
			log("request finished with error, but no exception")
			errorMsg = "服务器连接出错"
		end
	elseif state == BestHTTP.HTTPRequestStates.Aborted then
		log("request aborted!!")
		errorMsg = "服务器连接被中止"
	elseif state == BestHTTP.HTTPRequestStates.ConnectionTimedOut then
		log("request connection timed out!!")
		errorMsg = "服务器连接超时"
	elseif state == BestHTTP.HTTPRequestStates.TimedOut then
		log("request processing timed out!!")
		errorMsg = "服务器连接处理超时"
	else
		log("un-handled state: "..tostring(state))
		errorMsg = "服务器连接失败"
	end

	errorMsg = errorMsg.."\n游戏将重启"

	return false, errorMsg
end

-----------------------------------------------------------------------
local function CheckStatusCode(proto, data)
	local code = data.StatusCode
	local message = ""

	if code == 0 then
		return ErrorCode.None, message
	else
		local ret = ErrorCode.HintError
		if code == 201 then
			ret = ErrorCode.SessionOutdateError
		elseif code == 301 then
			message = SAFE_LOC("loc_global_id_password_error")
		elseif code == 302 then
			message = SAFE_LOC("loc_global_id_password_deactivated")
		elseif code == 304 then
			message = SAFE_LOC("loc_global_id_nickname_used")
		elseif code == 308 then
			message = SAFE_LOC("loc_global_id_password_noexists")
		elseif code == 309 then
			message = SAFE_LOC("手机号与账号不匹配")
		elseif code == 320 then
			message = SAFE_LOC("身份证号与姓名不匹配")
		elseif code == 311 then
			message = SAFE_LOC("无效的邀请码")
		elseif code == 313 then
			message = SAFE_LOC("今日注册人数已满")
		elseif code == 314 then
			message = SAFE_LOC("本次测试注册人数已满")
		elseif code == 103 then
			message = SAFE_LOC("loc_global_error_code_103")
		elseif code == 1503 then
			message = SAFE_LOC("队伍名字包含敏感词")
		elseif code == 2005 then
			message = SAFE_LOC("对不起，充值系统正在维护中，无法充值，请稍后重试")
		elseif code == 10001 then
			message = SAFE_LOC("身份证重复绑定")
		elseif code == 11001 then
			message = SAFE_LOC("您已超出当日上限啦，1天之内只能发送3次短信哦")
		elseif code == 11002 then
			message = SAFE_LOC("很抱歉，验证码有误，请重新检查手机号和收到的短信息")
		elseif code == 101 then
			message = SAFE_LOC("很抱歉，一台设备在15天内只能创建一个游客账号")
		elseif code == 31001 then
			message = SAFE_LOC("家具待领取数量达到上限")
		elseif code == 21001 then
			message = SAFE_LOC("loc_global_sensitive_words")
		elseif code == 30001 then
			ret = ErrorCode.FatalError
			message = "服务器响应缓慢，请1分钟后再试"
		elseif code == NO_RESPONSE_STATUS_CODE then
			ret = ErrorCode.NoResponse
		else
			-- special for iap
			if proto == "SubmitPookIAPReceipt" or proto == "SubmitHuaWeiReceipt" or proto == "GetPookOrderStatus" then
				return ErrorCode.IapError
			end

			ret = ErrorCode.FatalError
			message = SAFE_LOC("loc_global_error_code").."："..tostring(code).."，"..SAFE_LOC("loc_global_error_code_game_reset")
		end

		return ret, message
	end
end

function NetManager.OnRequestResult(proto, request)
	local forceHideWaiting = false
	local result, resultMsg = CheckRequestResult(request)
	XDebug.Log(LOG_TAG, string.format("==协议回复状态==%s state:%s", tostring(proto), tostring(request.State)))
	if result then
		local data = request.Response.DataAsText
		local decodedData = UnpackData(proto, data)
		XDebug.LogTable(LOG_TAG, "==协议回复数据== " .. proto, decodedData)
		local errorCode, errorMsg = CheckStatusCode(proto, decodedData)
		if errorCode == ErrorCode.None then
			this.FinishRequest(proto, decodedData)
		elseif errorCode == ErrorCode.IapError then
			-- special for iap
			decodedData.HasIapError = true
			this.FinishRequest(proto, decodedData)
		elseif errorCode == ErrorCode.HintError then
			_suspended = true
			forceHideWaiting = true
			this.ShowMessageBox({message = errorMsg, single = true, data = proto, onConfirm = NetManager.OnHintConfirm})
		elseif errorCode == ErrorCode.FatalError then
			-- must restart
			_suspended = true
			forceHideWaiting = true
			this.ShowMessageBox({message = errorMsg, single = true, data = proto, onConfirm = NetManager.OnQuitConfirm})
		elseif errorCode == ErrorCode.SessionOutdateError then
			if not Global.HasChannelAccount and GameData.GetDefaultNickName() == nil then
				_suspended = true
				-- return from here, so hide the network loading directly
				NetworkLoadingCtrl.Hide()
				this.ShowMessageBox({message = SAFE_LOC("无法读取本地存档\n请重新登录"), single = true, data = proto, onConfirm = NetManager.OnQuitConfirm})
				return
			end

			_requesting = false
			_suspended = false
			-- no heart anymore
			this.ForceRemoveProto("Heart")
			if not Global.HasChannelAccount then
				local nickname, password = GameData.GetDefaultAccountInfo()
				local loginData = this.ConstructLoginData(nickname, password)
				this.ForceSend("Login", loginData, NetManager.OnHandleReLogin, nil)
			else
				local loginData = this.ConstructChannelLoginData()
				this.ForceSend("Login3rd", loginData, NetManager.OnHandleReLogin, nil)
			end
			-- maintenance and update
			this.ForceSend("ServerInfoSimple", {}, NetManager.OnHandleServerInfo, nil)
		elseif errorCode == ErrorCode.NoResponse then
			_suspended = true
			forceHideWaiting = true
			local msg =  SAFE_LOC("loc_global_error_code").."："..proto
			this.ShowMessageBox({message = msg, single = true, data = proto, onConfirm = NetManager.OnQuitConfirm})
		end
	else
		_suspended = true
		forceHideWaiting = true
		this.ShowMessageBox({message = resultMsg, single = true, data = proto, onConfirm = NetManager.OnQuitConfirm})
	end

	if not forceHideWaiting then
		forceHideWaiting = (#_requestList == 0)

		if #_requestList > 0 then
			XDebug.LogCustom(LOG_TAG, function()
				local str = "还有其他协议需要处理\n"
				for _,v in ipairs(_requestList) do
					str = str .. v.proto .. "\n"
				end
				return str
			end)
		end
	end

	if forceHideWaiting then
		NetworkLoadingCtrl.Hide()
	end
end

function NetManager.ShowMessageBox(params)
	if _singleDialog then
		CtrlManager.ShowMessageBox(params)
	else
		--取消的时候,抛弃当前的协议
		CtrlManager.ShowMessageBox({message = params.message, single = false, data = params.data, onConfirm = params.onConfirm, onCancel = function()
			this.OnHintConfirm(params.data)
		end})
	end
end

-----------------------------------------------------------------------
function NetManager.OnHintConfirm(data)
	this.ForceRemoveProto(data)
	_requesting = false
	_suspended = false
end

function NetManager.OnQuitConfirm()
	_requestList = {}
	_requesting = false
	_suspended = false
	Game.Restart()
end

function NetManager.OnRetryConfirm()
	_requesting = false
	_suspended = false
end
-----------------------------------------------------------------------
-- proto handled by netmanager
function NetManager.OnHandleServerTime(proto, data, requestData)
	GameData.SetServerTime(data.Time)

	local isForce = requestData.Force or false
	if isForce then
		GameData.RefreshSysArenaConfig()
	end
end

function NetManager.OnHandleHeart(proto, data, requestData)
	if proto == "Heart" then
		-- settle play time
		local playTime = requestData.PlayTime
		GameData.SettleCurrentPlayTime(playTime)
		local protoList = data.ProtocolList or {}
		for idx = 1, #protoList do
			this.Send(protoList[idx], {}, this.OnHandleHeart, nil)
		end
		-- weely report data
		this.Send("WeeklyReport", {}, this.OnHandleHeart, nil)
		-- only the module is unlocked and has no tourist, then re-fetch the data
		if GameData.NeedUpdateTourist() then
			this.Send("ZooStatus", {}, this.OnHandleHeart, nil)
		end
	elseif proto == "Notice" then
		GameData.InitBulletinData(data.NoticeList)
	elseif proto == "MailList" then
		GameData.InitMail(data.MailList)
	elseif proto == "WeeklyReport" then
		GameData.InitWeeklyReport(data)
	elseif proto == "PackageTimeConfig" then
		GameData.SetIapPackageList(data.PackageTimeConfigList)
	elseif proto == "GetIAPCustomPackage" then
		GameData.SetCustomPackage(data.IAPCustomPackageObj)
	--elseif proto == "ActivityPackageTimeConfig" then
		--GameData.SetActivityPackageList(data.PackageTimeConfigList)
	elseif proto == "ZooStatus" then
		GameData.InitTouristData(data.ZooObj)
	elseif proto == "DrawTimeConfig" then
		GameData.SetSummonPoolList(data.DrawTimeConfigList)
	elseif proto == "ActivityGoalTimeConfig" then
		GameData.SetTimeLimitedActivity(data.ActivityGoalTimeConfig)
	elseif proto == "STSeasonConfig" then
		GameData.InitSpaceTravelSeasonConfig(data.ConfigList)
	else
		assert(false, "un-handled heart proto: "..tostring(proto))
	end
end

function NetManager.OnHandleReLogin(proto, data, requestData)
	if proto == "Login" or proto == "Login3rd" then
		local lastMac = data.LastLoginMac
		if lastMac ~= Global.deviceIdentifier then
			_suspended = true
			-- force to hide
			NetworkLoadingCtrl.Hide()
			CtrlManager.ShowMessageBox({message = SAFE_LOC("loc_account_DifferentPlaces"), single = true, onConfirm = NetManager.OnQuitConfirm})
		else
			local session = data.Session
			NetManager.SetLoginSession(session)
			-----------------------------------------------------
			-- same with heart proto list
			this.Send("Notice", {}, this.OnHandleHeart, nil)
			this.Send("MailList", {}, this.OnHandleHeart, nil)
			this.Send("WeeklyReport", {}, this.OnHandleHeart, nil)
			-----------------------------------------------------
			-- arena config
			this.Send("SysArenaConfig", {}, GameData.OnSysArenaConfigRefreshed, nil)
			-- iap packages
			this.Send("PackageTimeConfig", {}, this.OnHandleHeart, nil)
			-- custom package
			this.Send("GetIAPCustomPackage", {}, this.OnHandleHeart, nil)
			-- activity package
			--this.Send("ActivityPackageTimeConfig", {}, this.OnHandleHeart, nil)
			-- tourist data
			this.Send("ZooStatus", {}, this.OnHandleHeart, nil)
			-- activity summons
			this.Send("DrawTimeConfig", {}, this.OnHandleHeart, nil)
			-- time limited activity
			this.Send("ActivityGoalTimeConfig", {}, this.OnHandleHeart, nil)
			-- space travel season config
			this.Send("STSeasonConfig", {}, this.OnHandleHeart, nil)
			-- refresh server time
			this.SendServerTime(true)
		end
	end
end

function NetManager.CheckAndFetchCustomPackage()
	local customPackageId = GameData.GetActiveCustomPackage()
	if customPackageId == nil then
		this.Send("GetIAPCustomPackage", {}, this.OnHandleHeart, nil)
	end
end

function NetManager.OnHandleServerInfo(proto, data, requestData)
	local currentSvnVersion = Global.SvnVersion
	local currentBigVersion = Global.CurrentBigVersion()
	log("current svn version: "..tostring(currentSvnVersion))
	local serverList = data.ServerInfo.ServerList

	local gameClosed = false
	local gameNeedUpdate = false
	local currentServerData = nil

	for k, v in pairs(serverList) do
		if v.Platform == Global.currentPlatform then
			currentServerData = v
			if v.Status == 4 and not ScriptBridge.UseThis() then
				gameClosed = true
			elseif AppConst.UpdateMode then
				local versions = Helper.StringSplit(v.GameVersion, ":")
				if #versions >= 4 then
					-- lua index start from 1
					local minServerVersion = Global.GetBigVersion(versions[1])
					local maxServerVersion = Global.GetBigVersion(versions[2])
					local serverSvnVersion = tonumber(versions[4])
					log("server svn version: "..tostring(serverSvnVersion))
					-- no hint when currentBigVersion > maxServerVersion
					if currentBigVersion < minServerVersion or (currentBigVersion <= maxServerVersion and currentSvnVersion ~= serverSvnVersion) then
						gameNeedUpdate = true
					end
				end
			end

			break
		end
	end

	if gameClosed then
		_suspended = true
		CtrlManager.ForceHideTutorialGuide()
		-- force to hide
		NetworkLoadingCtrl.Hide()
		CtrlManager.ShowMessageBox({message = currentServerData.MaintainDesc, single = true, onConfirm = NetManager.OnQuitConfirm})
	elseif gameNeedUpdate then
		_suspended = true
		CtrlManager.ForceHideTutorialGuide()
		-- force to hide
		NetworkLoadingCtrl.Hide()
		CtrlManager.ShowMessageBox({message = SAFE_LOC("loc_global_update_restart"), single = true, onConfirm = NetManager.OnQuitConfirm})
	else
		if currentServerData ~= nil then
			Global.SpecialSwitch = currentServerData.SpecialSwitch
			GameData.CheckRealNameSwitch()
		end
	end
end
-----------------------------------------------------------------------
function NetManager.ConstructLoginData(nickname, password)
	local platform = Game.CurrentPlatformId()
	local gameVersion = Game.CurrentGameVersion()
	local data = {
		Nickname = nickname, 
		Password = Helper.CheckMd5(password), 
		Mac = Global.deviceIdentifier,
		Platformid = platform,
		ClientVersion = gameVersion,
		PackageChannelid = Global.ChannelId,
	}

	return data
end

function NetManager.ConstructChannelLoginData()
	local platform = Game.CurrentPlatformId()
	local gameVersion = Game.CurrentGameVersion()
	local data = {
		Channelid = Global.ChannelId,
		ChannelUid = ScriptBridge.ChannelUid,
		Mac = Global.deviceIdentifier,
		Platformid = platform,
		ClientVersion = gameVersion,
	}

	return data
end