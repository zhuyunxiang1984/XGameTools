local BattleCalculator = {}

local MAX_ROUND = 233

function BattleCalculator:new(characterList, petId, enemyList, challengeData, globalBuffs)
	local instance = {}

	instance._characterList = characterList
	instance._petId = petId
	-- enemy list
	instance._enemyList = {}
	for idx = 1, #enemyList do
		local enemyId = enemyList[idx].id
		local enemyLevel = enemyList[idx].level
		instance._enemyList[idx] = {id = enemyId, level = enemyLevel}
	end
	-- enemy level skill
	instance._enemyLevelSkillId = nil
	instance._effectToEnemyLevel = 0
	if ConfigUtils.IsValidItem(challengeData.EnemyLevelSkillId) then
		instance._enemyLevelSkillId = challengeData.EnemyLevelSkillId
		instance._effectToEnemyLevel = challengeData.EffectToEnemyLevel
	end
	-- enemy ability
	instance._effectToEnemyAbility = {}
	local effectToEnemyAbility = challengeData.EffectToEnemyAbility or {}
	for idx = 1, #effectToEnemyAbility do
		local abilityId = effectToEnemyAbility[idx][1]
		local absValue = effectToEnemyAbility[idx][2]
		local percentValue = effectToEnemyAbility[idx][3]

		instance._effectToEnemyAbility[abilityId] = {abs = absValue, percent = percentValue * 0.01}
	end
	-- group data
	instance._groupData = {}
	instance._groupRuntimeData = {}
	
	-- all the values no battle round skills
	local groupAbilityMap = GameData.GetGroupAbilityMap(characterList, petId, globalBuffs)
	local groupDamageToElement = GameData.GetGroupDamageToElement(characterList, petId, globalBuffs)
	local groupDamageFromElement = GameData.GetGroupDamageFromElement(characterList, petId, globalBuffs)
	local groupCritChance = GameData.GetGroupPercentValueMapOf(characterList, petId, EffectAttribute.CritChance, globalBuffs)
	local groupCritDamage = GameData.GetGroupPercentValueMapOf(characterList, petId, EffectAttribute.CritDamage, globalBuffs)
	local groupCritDamageDefend = GameData.GetGroupPercentValueMapOf(characterList, petId, EffectAttribute.DamageFromCritDamage, globalBuffs)
	local groupExtraAttack = GameData.GetGroupExtraAttackMap(characterList, petId, globalBuffs)
	local groupDodge = GameData.GetGroupDodgeMap(characterList, petId, globalBuffs)
	local groupDodgeIgnore = GameData.GetGroupDodgeIgnoreMap(characterList, petId, globalBuffs)
	local groupSpecificEnemySkills = GameData.GetGroupSpecificEnemySkillMap(characterList, petId, globalBuffs)
	local groupBattleRoundSkills = GameData.GetGroupSkillMap(characterList, petId, {skillType = FilterSkillType.OnlyBattleRoundSkill, globalSkills = globalBuffs})

	local groupMembers = {}
	Helper.CopyTable(groupMembers, characterList)
	if ConfigUtils.IsValidItem(petId) then
		table.insert(groupMembers, petId)
	end

	for idx = 1, #groupMembers do
		local memberId = groupMembers[idx]
		local abilityMap = groupAbilityMap[memberId]
		local critChance = groupCritChance[memberId] or 0
		local critDamage = groupCritDamage[memberId] or 0
		local critDamageDefend = groupCritDamageDefend[memberId] or 0
		local damageToElement = groupDamageToElement[memberId] or {}
		local damageFromElement = groupDamageFromElement[memberId] or {}
		local dodge = groupDodge[memberId] or {}
		local dodgeIgnore = groupDodgeIgnore[memberId] or {}
		local extraAttack = groupExtraAttack[memberId] or {}
		local specificSkills = groupSpecificEnemySkills[memberId] or {}

		-- data of members
		instance._groupData[memberId] = {
			abilityMap = abilityMap,
			specificSkills = specificSkills,
		}

		-- runtime data of members, will change as time goes on
		instance._groupRuntimeData[memberId] = {
			abilityMap = Helper.CloneMap(abilityMap),
			damageToElement = damageToElement,
			damageFromElement = damageFromElement,
			-- may have round data
			critChance = critChance,
			critDamage = critDamage,
			critDamageDefend = critDamageDefend,
			dodge = dodge,
			dodgeIgnore = dodgeIgnore,
			extraAttack = extraAttack,
			-- clear every round
			roundCritChance = 0,
			roundCritDamage = 0,
			roundCritDamageDefend = 0,
			roundDodge = {},
			roundDodgeIgnore = {},
			roundExtraAttack = {},
			roundHpAttack = {},
			roundDefendIgnore = {},
			-- receive hurt count per round
			roundHurtCount = 0,
		}
	end

	instance._dataOfBattleRoundSkills= {}
	for memberId, memberSkills in pairs(groupBattleRoundSkills) do
		for idx = 1, #memberSkills do
			local skillId = memberSkills[idx].id
			local skillValue = memberSkills[idx].value
			-- who contibutes this skill
			local skillSource = memberSkills[idx].source
			local battleParameter = ConfigUtils.GetSkillEffectBattleParameter(skillId)
			local effectStartRound = battleParameter.StartRound or 1
			local effectRoundInterval = battleParameter.IntervalRound or 1
			local effectRoundLimit = battleParameter.Limited or 100000

			table.insert(instance._dataOfBattleRoundSkills, {
				id = skillId,
				value = skillValue,
				member = memberId,
				start = effectStartRound,
				interval = effectRoundInterval,
				limit = effectRoundLimit,
				used = 0,
				source = skillSource,
			})
		end
	end

	setmetatable(instance, {__index = BattleCalculator})

	return instance
end

function BattleCalculator:Start(seed)
	self._battleData = {}
	self._isGroupWin = true
	-- decide the order in the team
	self._orderedGroup = self:ConstructOrderGroup()
	-- 总回合数
	local totalRound = 0
	-- set the seed
	Helper.RandSeed(seed)
	for idx = 1, #self._enemyList do
		self:ResetBattleRoundSkillsData()
		local thisEnemyRoundSkills = nil
		self._enemyId = self._enemyList[idx].id
		self._enemyData, self._enemyRuntimeData, thisEnemyRoundSkills = self:ConstructEnemyDataAt(idx)
		-- initial element, it can be changed by skill
		self._enemyElement = ConfigUtils.GetEnemyElement(self._enemyId)
		self._enemyHp = self._enemyData.abilityMap[AbilityType.HP]
		self._enemyMaxHp = self._enemyHp
		-- enemy battle round skills
		self._dataOfEnemyBattleRoundSkills = {}
		self._dataOfEnemyRangeAttackSkills = {}

		for m = 1, #thisEnemyRoundSkills do
			local skillId = thisEnemyRoundSkills[m].id
			local skillValue = thisEnemyRoundSkills[m].value
			local battleParameter = ConfigUtils.GetSkillEffectBattleParameter(skillId)
			local effectStartRound = battleParameter.StartRound or 1
			local effectRoundInterval = battleParameter.IntervalRound or 1
			local effectRoundLimit = battleParameter.Limited or 100000

			local enemyRoundSkillData = {
				id = skillId,
				value = skillValue,
				start = effectStartRound,
				interval = effectRoundInterval,
				limit = effectRoundLimit,
				used = 0,
			}

			local effectParameter = ConfigUtils.GetSkillEffectParameter(skillId)
			local effectAttribute = effectParameter.EffectAttribute
			if effectAttribute == EffectAttribute.RangeAttack then
				table.insert(self._dataOfEnemyRangeAttackSkills, enemyRoundSkillData)
			else
				table.insert(self._dataOfEnemyBattleRoundSkills, enemyRoundSkillData)
			end
		end

		local thisBattleData, isEnemyWin, round = self:GenerateBattleDataOfEnemy(idx == #self._enemyList)
		totalRound = totalRound + round
		table.insert(self._battleData, {enemy = self._enemyData, battle = thisBattleData})

		if isEnemyWin then
			self._isGroupWin = false
			break
		end
	end
	-- reset the seed
	Helper.RandSeed()

	return self._battleData, self._isGroupWin, totalRound
end

function BattleCalculator:GetEnemyList()
	return self._enemyList
end

function BattleCalculator:ConstructOrderGroup()
	local orderGroup = {}
	-- characters
	for idx = 1, #self._characterList do
		local characterId = self._characterList[idx]
		local hp = self._groupData[characterId].abilityMap[AbilityType.HP] or 0
		orderGroup[idx] = {id = characterId, hp = hp, maxHp = hp, isPet = false}
	end
	-- pet
	if self._petId ~= nil then
		local hp = 1
		orderGroup[#orderGroup + 1] = {id = self._petId, hp = hp, maxHp = hp, isPet = true}
	end

	return orderGroup
end

function BattleCalculator:GetEnemyLevelAndAbilityMapAt(idx)
	local enemyId = self._enemyList[idx].id
	local enemyOriginalLevel = self._enemyList[idx].level

	-- 全局敌人减等级
	local globalEnemyLevelSkillId = self._enemyLevelSkillId
	local globalEnemyLevel = self._effectToEnemyLevel
	-- 特定敌人减等级
	local specificEnemyLevelSkillId = nil
	local specificEnemyLevel = 0
	-- 玩家英雄身上的影响敌人能力的技能
	local specificAbilitySkillsToThisEnemy = {}
	for k, v in pairs(self._groupData) do
		local specificSkills = v.specificSkills
		for idx = 1, #specificSkills do
			local skillId = specificSkills[idx].id
			local skillValue = specificSkills[idx].value
			if GameData.IsEnemyMatchSkill(skillId, enemyId) then
				local skillEffectAttribute = ConfigUtils.GetSkillEffectAttribute(skillId)
				if skillEffectAttribute == EffectAttribute.SpecificEnemyLevel then
					specificEnemyLevel = specificEnemyLevel + skillValue
					if specificEnemyLevelSkillId == nil then
						specificEnemyLevelSkillId = skillId
					end
				elseif skillEffectAttribute == EffectAttribute.SpecificEnemyAbility then
					table.insert(specificAbilitySkillsToThisEnemy, {id = skillId, value = skillValue})
				end
			end
		end
	end

	-- 敌人需要被降的等级(负数)
	local enemyFinalSkillLevel = (globalEnemyLevel + specificEnemyLevel)
	-- 敌人无视降低等级的参数 (正数)
	local ignoreLevelAbs, ignoreLevelPercent = GameData.GetEnemyLevelIgnore(enemyId)
	-- 敌人最终被降的等级
	local enemyLevelEffectedValue = (ignoreLevelAbs + enemyFinalSkillLevel) * (1 - ignoreLevelPercent)
	-- 敌人等级最终不可能加
	enemyLevelEffectedValue = math.min(0, math.ceil(enemyLevelEffectedValue))
	-- 计算(无视了多少降智打击)
	local enemyFinalIgnoreLevel = math.max(0, enemyLevelEffectedValue - enemyFinalSkillLevel)
	-- 敌人的最终等级
	local enemyFinalLevel = math.max(enemyOriginalLevel + enemyLevelEffectedValue, 1)
	local enemyFinalLevelSkillId = globalEnemyLevelSkillId
	if enemyFinalLevelSkillId == nil then
		enemyFinalLevelSkillId = specificEnemyLevelSkillId
	end
	
	local originalAbilityMap = ConfigUtils.GetEnemyAbilityMap(enemyId, enemyFinalLevel)
	local skillAbilityMap = GameData.GetEnemySkillAbilityMap(enemyId)
	local specificAbilityMap = GameData.ConstructAbilityMapOfSkills(specificAbilitySkillsToThisEnemy)
	local enemyFinalAbilityMap = {}
	for abilityId, abilityValue in pairs(originalAbilityMap) do
		local globalEffectAbilityValue = self._effectToEnemyAbility[abilityId]
		local specificEffectAbilityValue = specificAbilityMap[abilityId]
		local skillEffectAbilityValue = skillAbilityMap[abilityId]
		if globalEffectAbilityValue ~= nil or specificEffectAbilityValue ~= nil or skillEffectAbilityValue ~= nil then
			local globalAbsValue = 0
			local globalPercentValue = 0
			local specificAbsValue = 0
			local specificPercentValue = 0
			local skillAbsValue = 0
			local skillPercentValue = 0

			if globalEffectAbilityValue ~= nil then
				globalAbsValue = globalEffectAbilityValue.abs
				globalPercentValue  = globalEffectAbilityValue.percent
			end

			if specificEffectAbilityValue ~= nil then
				specificAbsValue = specificEffectAbilityValue.abs
				specificPercentValue  = specificEffectAbilityValue.percent
			end

			if skillEffectAbilityValue ~= nil then
				skillAbsValue = skillEffectAbilityValue.abs
				skillPercentValue = skillEffectAbilityValue.percent
			end

			local finalValue = (abilityValue + globalAbsValue + specificAbsValue + skillAbsValue) * (1 + globalPercentValue + specificPercentValue + skillPercentValue)
			finalValue = Helper.RoundAndCeil(finalValue)
			finalValue = math.max(finalValue, 0)
			enemyFinalAbilityMap[abilityId] = finalValue
		else
			enemyFinalAbilityMap[abilityId] = abilityValue
		end
	end

	return enemyFinalLevel, enemyFinalLevelSkillId, enemyFinalSkillLevel, enemyFinalIgnoreLevel, enemyFinalAbilityMap
end

function BattleCalculator:ConstructEnemyDataAt(idx)
	local enemyId = self._enemyList[idx].id
	local enemyLevel, enemyLevelSkillId, enemySkillLevel, enemyIgnoreLevel, enemyAbilityMap = self:GetEnemyLevelAndAbilityMapAt(idx)

	local data = {
		id = enemyId, 
		level = enemyLevel,
		enemyLevelSkill = enemyLevelSkillId,
		enemySkillLevel = enemySkillLevel,
		enemyIgnoreLevel = enemyIgnoreLevel,
		abilityMap = enemyAbilityMap,
	}

	local runtimeData = {
		abilityMap = Helper.CloneMap(enemyAbilityMap),
		damageToElement = GameData.GetEnemyDamageToElement(enemyId),
		damageFromElement = GameData.GetEnemyDamageFromElement(enemyId),
		-- may have round data
		critChance = GameData.GetEnemyCritChance(enemyId),
		critDamage = GameData.GetEnemyCritDamage(enemyId),
		critDamageDefend = GameData.GetEnemyCritDamageDefend(enemyId),
		dodge = GameData.GetEnemyDodge(enemyId),
		dodgeIgnore = GameData.GetEnemyDodgeIngore(enemyId),
		extraAttack = GameData.GetEnemyExtraAttack(enemyId),
		---------------------------------------
		-- clear every round
		roundCritChance = 0,
		roundCritDamage = 0,
		roundCritDamageDefend = 0,
		roundDodge = {},
		roundDodgeIgnore = {},
		roundExtraAttack = {},
		roundHpAttack = {},
		roundDefendIgnore = {},
		---------------------------------------
		roundHurtCount = 0,
	}

	log("enemy: "..tostring(idx).."; data: "..Helper.Format(runtimeData))

	local roundSkills = GameData.GetEnemySkillList(enemyId, {skillType = FilterSkillType.OnlyBattleRoundSkill})

	return data, runtimeData, roundSkills
end

function BattleCalculator:GenerateBattleDataOfEnemy(lastEnemy)
	local battleData = {}
	local isGroupWin = false
	local isEnemyWin = false
	local currentRound = 1
	local enemyId = self._enemyId

	while true do
		self:ResetDataAtRoundStart()
		local roundData = {}
		roundData.sideData = {}
		local groupSideData = {}
		for idx = 1, #self._orderedGroup do
			local memberId = self._orderedGroup[idx].id
			local attackNum = self:CalculateAttackNum(memberId)

			local memberAttackData = {}
			for attackIdx = 1, attackNum do
				local damageData = self:CalculateDamageData(memberId, enemyId)
				local finalAttack = damageData.damage

				self._enemyHp = self._enemyHp - finalAttack
				self._enemyHp = math.max(self._enemyHp, 0)
				-- enemy get hurt
				self:IncreaseEnemyHurtNum()

				table.insert(memberAttackData, damageData)

				if self._enemyHp <= 0 then
					isGroupWin = true
					break
				end
			end

			local targets = {}
			targets[1] = {id = enemyId, attack = memberAttackData}
			table.insert(groupSideData, {source = memberId, rangeAttack = false, targets = targets})

			if isGroupWin then
				break
			end
		end

		table.insert(roundData.sideData, {isEnemy = false, data = groupSideData})

		-- enemy dead, this battle is finished
		if isGroupWin then
			-- no need do skill settle as all enemies are dead
			if not lastEnemy then
				roundData.skillData = self:SettleBattleRoundSkills(currentRound, false)
			end
			table.insert(battleData, roundData)
			break
		end

		local targetSlots, isRangeAttack, damageFactor = self:GetEnemyAttackTarget(currentRound)
		-- range attack can so have extra attacks
		local attackNum = self:CalculateAttackNum(enemyId)

		local enemyTargets = {}
		-- the target slots must be ordered by descending
		for idx = 1, #targetSlots do
			local slot = targetSlots[idx]
			local targetMemberId = self._orderedGroup[slot].id
			local targetMemberHp = self._orderedGroup[slot].hp

			local enemyAttackData = {}
			for attackIdx = 1, attackNum do
				local damageData = self:CalculateDamageData(enemyId, targetMemberId, isRangeAttack, damageFactor)
				local finalAttack = damageData.damage

				targetMemberHp = targetMemberHp - finalAttack
				targetMemberHp = math.max(targetMemberHp, 0)
				self._orderedGroup[slot].hp = targetMemberHp
				self:IncreaseMemberHurtNum(targetMemberId)

				table.insert(enemyAttackData, damageData)
				-- target is dead now, quit this one
				if targetMemberHp == 0 then
					break
				end
			end

			table.insert(enemyTargets, {id = targetMemberId, attack = enemyAttackData})
		end

		local enemySideData = {}
		enemySideData[1] = {source = enemyId, rangeAttack = isRangeAttack, targets = enemyTargets}

		table.insert(roundData.sideData, {isEnemy = true, data = enemySideData})

		-- remove the dead ones
		self:CleanDeadMember()
		-- all character dead, battle finished
		if self:IsAllCharacterDead() then
			table.insert(battleData, roundData)
			isEnemyWin = true
			break
		end

		roundData.skillData = self:SettleBattleRoundSkills(currentRound, true)
		table.insert(battleData, roundData)
		currentRound = currentRound + 1

		-- too much round, just end
		if currentRound > MAX_ROUND then
			isEnemyWin = true
			break
		end
	end

	return battleData, isEnemyWin, currentRound
end

function BattleCalculator:CalculateDamageData(sourceId, targetId, isRangeAttack, damageFactor)
	isRangeAttack = isRangeAttack or false

	local baseDamage = self:CalculateBaseDamage(sourceId)
	local sourceElement = self:GetElementOfItem(sourceId)
	local targetElement = self:GetElementOfItem(targetId)
	local baseElementFactor = ConfigUtils.GetElementFactor(sourceElement, targetElement)
	local isDodge = self:IsDodge(targetId)
	local isDodgeIgnore = false
	if isDodge then
		isDodgeIgnore = self:IsDodgeIgnore(sourceId)
		if not isDodgeIgnore then
			return {
				damage = 0, 
				baseDamage = baseDamage,
				isCrit = false,
				isDodge = true,
				isDodgeIgnore = false,
				elementFactor = baseElementFactor, 
			}
		end
	end

	local isCrit = false
	local critFactor = 1
	local critDefend = 1
	-- range attack no crit
	if not isRangeAttack then
		isCrit = self:IsCrit(sourceId)
		damageFactor = 1
	end

	if isCrit then
		critFactor, critDefend = self:CalculateCritFactor(sourceId, targetId)
	end

	local elementFactor = self:CalculateElementFactor(baseElementFactor, sourceId, sourceElement, targetId, targetElement)
	local defendFactor = self:CalculateDefendFactor(targetId, sourceId)
	local finalDamage = Helper.RoundAndCeil(baseDamage * critFactor * elementFactor * defendFactor * critDefend) * damageFactor
	finalDamage = math.max(math.ceil(finalDamage), 1)

	return {
		damage = finalDamage, 
		baseDamage = baseDamage,
		isCrit = isCrit,
		isDodge = false,
		isDodgeIgnore = isDodgeIgnore,
		critFactor = critFactor, 
		elementFactor = elementFactor, 
		defendFactor = defendFactor, 
	}
end

function BattleCalculator:GetEnemyAttackTarget(currentRound)
	for idx = 1, #self._dataOfEnemyRangeAttackSkills do
		local skillData = self._dataOfEnemyRangeAttackSkills[idx]
		if self:IsRoundSkillActivated(skillData, currentRound) then
			skillData.used = skillData.used + 1
			local skillId = skillData.id
			local damageFactor = skillData.value * 0.01
			local effectParameter = ConfigUtils.GetSkillEffectParameter(skillId)
			local effectChance = effectParameter.Chance or 100
			local randChance = Helper.RandInt(0, 100)
			-- consider chance
			if randChance <= effectChance then
				local targetSlots = {}
				local effectValue = effectParameter.EffectValue
				local startIndex = nil
				local endIndex = nil
				local leftCharacterNum = self:GetLeftCharacterNum()
				if effectValue > 0 then
					startIndex = math.min(effectValue, leftCharacterNum)
					endIndex = 1
				else
					startIndex = leftCharacterNum
					endIndex = math.max(leftCharacterNum + effectValue + 1, 1)
				end

				-- always attack the one that has bigger index first
				for m = startIndex, endIndex, -1 do
					table.insert(targetSlots, m)
				end

				return targetSlots, true, damageFactor
			end
		end
	end

	return {1}, false, 1
end

function BattleCalculator:ResetBattleRoundSkillsData()
	for idx = 1, #self._dataOfBattleRoundSkills do
		self._dataOfBattleRoundSkills[idx].used = 0
	end
end

function BattleCalculator:ResetRoundData(data)
	data.roundCritChance = 0
	data.roundCritDamage = 0
	data.roundCritDamageDefend = 0
	data.roundDodge = {}
	data.roundDodgeIgnore = {}
	data.roundExtraAttack = {}
	data.roundHpAttack = {}
	data.roundDefendIgnore = {}
end

function BattleCalculator:ResetDataAtRoundStart()
	for k, v in pairs(self._groupRuntimeData) do
		v.roundHurtCount = 0
	end
	self._enemyRuntimeData.roundHurtCount = 0
end

function BattleCalculator:IncreaseMemberHurtNum(memberId)
	local data = self._groupRuntimeData[memberId]
	data.roundHurtCount = data.roundHurtCount + 1
end

function BattleCalculator:IncreaseEnemyHurtNum()
	self._enemyRuntimeData.roundHurtCount = self._enemyRuntimeData.roundHurtCount + 1
end

function BattleCalculator:SettleBattleRoundSkills(currentRound, checkEnemy)
	local sourceMemberSkills = {}
	----------------------------------------------
	local memberToRecover = {}
	local memberToAbility = {}
	----------------------------------------------
	local memberToRecoverExtra = {}
	local memberToAbilityExtra = {}
	----------------------------------------------
	local memberToCritChance = {}
	local memberToDodgeIgnore = {}
	local memberToDodge = {}
	local memberToExtraAttack = {}
	----------------------------------------------
	local roundMemberToCritChance = {}
	local roundMemberToCritDamage = {}
	local roundMemberToCritDamageDefend = {}
	local roundMemberToExtraAttack = {}
	local roundMemberToDodge = {}
	local roundMemberToDodgeIgnore = {}
	local roundMemberToHpAttack = {}
	local roundMemberToDefendIgnore = {}
	----------------------------------------------

	-- reset round data first
	for k, v in pairs(self._groupRuntimeData) do
		self:ResetRoundData(v)
	end

	-- 获取所有削弱效果
	local reduceTable = {}
	if self._enemyHp > 0 then
		reduceTable = self:CollectEnemyReduceEffect(currentRound)
	end

	for idx = 1, #self._dataOfBattleRoundSkills do
		local skillData = self._dataOfBattleRoundSkills[idx]
		local sourceId = skillData.source
		-- global skill or source member still alive
		local skillCanWork = (not ConfigUtils.IsValidItem(sourceId) or self:GetSlotInGroup(sourceId) ~= nil)
		if skillCanWork and self:IsRoundSkillActivated(skillData, currentRound) then
			local skillId = skillData.id
			local skillValue = skillData.value
			local memberId = skillData.member
			local effectParameter = ConfigUtils.GetSkillEffectParameter(skillId)
			local effectAttribute = effectParameter.EffectAttribute
			local effectCalcType = effectParameter.CalculateType
			local skillAdded = false
			if effectAttribute == EffectAttribute.Recovery and not memberId ~= self._petId then
				local worked = false
				if effectParameter.Chance ~= nil then
					local randValue = Helper.RandFloat()
					if randValue < effectParameter.Chance * 0.01 then
						worked = true
					end
				end

				if worked then
					if memberToRecover[memberId] == nil then
						memberToRecover[memberId] = {abs = 0, percent = 0}
					end

					if effectCalcType == CalculateType.Abs then
						memberToRecover[memberId].abs = memberToRecover[memberId].abs + skillValue
					elseif effectCalcType == CalculateType.Percent then
						memberToRecover[memberId].percent = memberToRecover[memberId].percent + skillValue * 0.01
					end
					skillAdded = true
				end
			elseif effectAttribute == EffectAttribute.RecoveryWithAtk and not memberId ~= self._petId then
				local worked = false
				if effectParameter.Chance ~= nil then
					local randValue = Helper.RandFloat()
					if randValue < effectParameter.Chance * 0.01 then
						worked = true
					end
				end

				if worked then
					if memberToRecoverExtra[memberId] == nil then
						memberToRecoverExtra[memberId] = { abs = 0, percent = 0}
					end

					if effectCalcType == CalculateType.Percent then
						local atk = self._groupRuntimeData[memberId].abilityMap[AbilityType.ATK] or 0
						memberToRecoverExtra[memberId].abs = memberToRecoverExtra[memberId].abs + math.ceil(skillValue * 0.01 * atk)
					else
						assert(false, "recovery with attack only support percent")
					end

					skillAdded = true
				end
			elseif effectAttribute == EffectAttribute.Ability then
				if memberToAbility[memberId] == nil then
					memberToAbility[memberId] = {}
				end

				local abilityMap = GameData.ConstructAbilityMapOfSkills({{id = skillId, value = skillValue}})
				for abilityId, v in pairs(abilityMap) do
					if memberToAbility[memberId][abilityId] == nil then
						memberToAbility[memberId][abilityId] = {abs = 0, percent = 0}
					end

					memberToAbility[memberId][abilityId].abs = memberToAbility[memberId][abilityId].abs + v.abs
					memberToAbility[memberId][abilityId].percent = memberToAbility[memberId][abilityId].percent + v.percent
				end
				skillAdded = true
			elseif effectAttribute == EffectAttribute.CritChance then
				local preValue = memberToCritChance[memberId] or 0
				memberToCritChance[memberId] = preValue + skillValue * 0.01
				skillAdded = true
			elseif effectAttribute == EffectAttribute.DodgeIgnore then
				if memberToDodgeIgnore[memberId] == nil then
					memberToDodgeIgnore[memberId] = {}
				end
				table.insert(memberToDodgeIgnore[memberId], skillValue * 0.01)
				skillAdded = true
			elseif effectAttribute == EffectAttribute.Dodge then
				if memberToDodge[memberId] == nil then
					memberToDodge[memberId] = {}
				end
				table.insert(memberToDodge[memberId], skillValue * 0.01)
				skillAdded = true
			elseif effectAttribute == EffectAttribute.ExtraAttack then
				if memberToExtraAttack[memberId] == nil then
					memberToExtraAttack[memberId] = {}
				end
				local attackNum = ConfigUtils.GetSkillEffectValue(skillId)
				table.insert(memberToExtraAttack[memberId], {extraAttackNum = attackNum, chance = skillValue * 0.01})
				skillAdded = true
			elseif effectAttribute == EffectAttribute.CritChanceOnce then
				local preValue = roundMemberToCritChance[memberId] or 0
				roundMemberToCritChance[memberId] = preValue + skillValue * 0.01
				skillAdded = true
			elseif effectAttribute == EffectAttribute.CritDamageOnce then
				local preValue = roundMemberToCritDamage[memberId] or 0
				roundMemberToCritDamage[memberId] = preValue + skillValue * 0.01
				skillAdded = true
			elseif effectAttribute == EffectAttribute.ExtraAttackOnce then
				if roundMemberToExtraAttack[memberId] == nil then
					roundMemberToExtraAttack[memberId] = {}
				end

				local attackNum = ConfigUtils.GetSkillEffectValue(skillId)
				table.insert(roundMemberToExtraAttack[memberId], {extraAttackNum = attackNum, chance = skillValue * 0.01})
				skillAdded = true
			elseif effectAttribute == EffectAttribute.DodgeOnce then
				if roundMemberToDodge[memberId] == nil then
					roundMemberToDodge[memberId] = {}
				end

				table.insert(roundMemberToDodge[memberId], skillValue * 0.01)
				skillAdded = true
			elseif effectAttribute == EffectAttribute.DodgeIgnoreOnce then
				if roundMemberToDodgeIgnore[memberId] == nil then
					roundMemberToDodgeIgnore[memberId] = {}
				end

				table.insert(roundMemberToDodgeIgnore[memberId], skillValue * 0.01)
				skillAdded = true
			elseif effectAttribute == EffectAttribute.DamageFromCritDamageOnce then
				local preValue = roundMemberToCritDamageDefend[memberId] or 0
				roundMemberToCritDamageDefend[memberId] = preValue + skillValue * 0.01
				skillAdded = true
			elseif effectAttribute == EffectAttribute.HpAttackOnce then
				if roundMemberToHpAttack[memberId] == nil then
					roundMemberToHpAttack[memberId] = {abs = 0, percent = 0}
				end

				if effectCalcType == CalculateType.Abs then
					roundMemberToHpAttack[memberId].abs = roundMemberToHpAttack[memberId].abs + skillValue
				elseif effectCalcType == CalculateType.Percent then
					roundMemberToHpAttack[memberId].percent = roundMemberToHpAttack[memberId].percent + skillValue * 0.01
				end
				skillAdded = true
			elseif effectAttribute == EffectAttribute.DefendIgnoreOnce then
				if roundMemberToDefendIgnore[memberId] == nil then
					roundMemberToDefendIgnore[memberId] = {abs = 0, percent = 0}
				end

				if effectCalcType == CalculateType.Abs then
					roundMemberToDefendIgnore[memberId].abs = roundMemberToDefendIgnore[memberId].abs + skillValue
				elseif effectCalcType == CalculateType.Percent then
					roundMemberToDefendIgnore[memberId].percent = roundMemberToDefendIgnore[memberId].percent + skillValue * 0.01
				end
				skillAdded = true
			elseif effectAttribute == EffectAttribute.RecoveryWithHurt then
				local hurtCount = self._groupRuntimeData[memberId].roundHurtCount
				if hurtCount > 0 then
					if memberToRecoverExtra[memberId] == nil then
						memberToRecoverExtra[memberId] = { abs = 0, percent = 0}
					end

					
					if effectCalcType == CalculateType.Abs then
						memberToRecoverExtra[memberId].abs = memberToRecoverExtra[memberId].abs + skillValue * hurtCount
					elseif effectCalcType == CalculateType.Percent then
						memberToRecoverExtra[memberId].percent = memberToRecoverExtra[memberId].percent + skillValue * hurtCount * 0.01
					end
					skillAdded = true
				end
			elseif effectAttribute == EffectAttribute.AttributeWithHurt then
				local hurtCount = self._groupRuntimeData[memberId].roundHurtCount
				if hurtCount > 0 then
					if memberToAbilityExtra[memberId] == nil then
						memberToAbilityExtra[memberId] = {}
					end

					local abilityMap = GameData.ConstructAbilityMapOfSkills({{id = skillId, value = skillValue * hurtCount}})
					for abilityId, v in pairs(abilityMap) do
						if memberToAbilityExtra[memberId][abilityId] == nil then
							memberToAbilityExtra[memberId][abilityId] = {abs = 0, percent = 0}
						end

						memberToAbilityExtra[memberId][abilityId].abs = memberToAbilityExtra[memberId][abilityId].abs + v.abs
						memberToAbilityExtra[memberId][abilityId].percent = memberToAbilityExtra[memberId][abilityId].percent + v.percent
					end

					skillAdded = true
				end
			else
				assert(false, "un-handled effect attribute of battle round skill: "..tostring(effectAttribute))
			end

			if skillAdded and ConfigUtils.IsValidItem(sourceId) then
				if sourceMemberSkills[sourceId] == nil then
					sourceMemberSkills[sourceId] = {}
				end

				sourceMemberSkills[sourceId][skillId] = 1
			end

			skillData.used = skillData.used + 1
		end
	end

	local finalMemberRecover = nil
	local finalMemberAbilityMap = nil
	local finalMemberElement = nil
	local finalMemberCritChance = nil
	---{[id]={recover = 1, ability = 1}}
	local finalMemberReduce = nil

	-- recover
	for k, v in pairs(memberToRecover) do
		local slot = self:GetSlotInGroup(k)
		-- still alive or pet
		if slot ~= nil then
			local maxHp = self._orderedGroup[slot].maxHp
			local addHp = Helper.RoundAndCeil(maxHp * v.percent) + v.abs

			--削弱 EffectAttribute.Recovery
			if reduceTable[EffectAttribute.Recovery] then
				addHp = math.max(0, (addHp - reduceTable[EffectAttribute.Recovery].abs) * (1 - reduceTable[EffectAttribute.Recovery].per))
				addHp =  Helper.RoundAndCeil(addHp)

				finalMemberReduce = finalMemberReduce or {}
				finalMemberReduce[k] = finalMemberReduce[k] or {}
				finalMemberReduce[k].recover = 1
			end

			local currentHp = self._orderedGroup[slot].hp
			currentHp = currentHp + addHp
			currentHp = math.min(currentHp, maxHp)
			self._orderedGroup[slot].hp = currentHp
			-- recover data
			finalMemberRecover = finalMemberRecover or {}
			finalMemberRecover[k] = finalMemberRecover[k] or 0
			finalMemberRecover[k] = finalMemberRecover[k] + addHp
		end
	end
	-- recover extra
	for k, v in pairs(memberToRecoverExtra) do
		local slot = self:GetSlotInGroup(k)
		-- still alive or pet
		if slot ~= nil then
			local maxHp = self._orderedGroup[slot].maxHp
			local addHp = Helper.RoundAndCeil(maxHp * v.percent) + v.abs
			local currentHp = self._orderedGroup[slot].hp
			currentHp = currentHp + addHp
			currentHp = math.min(currentHp, maxHp)
			self._orderedGroup[slot].hp = currentHp
			-- recover data
			finalMemberRecover = finalMemberRecover or {}
			finalMemberRecover[k] = finalMemberRecover[k] or 0
			finalMemberRecover[k] = finalMemberRecover[k] + addHp
		end
	end
	-- ability
	for k, v in pairs(memberToAbility) do
		local slot = self:GetSlotInGroup(k)
		-- still alive or pet
		if slot ~= nil then
			for abilityId, data in pairs(v) do
				local runtimeAbilityMap = self._groupRuntimeData[k].abilityMap
				local initialAbilityMap = self._groupData[k].abilityMap
				local preValue = runtimeAbilityMap[abilityId] or 0
				local initialValue = initialAbilityMap[abilityId] or 0
				local addValue = Helper.RoundAndCeil(initialValue * data.percent + data.abs)
				--削弱 EffectAttribute.Ability
				if reduceTable[EffectAttribute.Ability] and reduceTable[EffectAttribute.Ability][abilityId] then
					local t = reduceTable[EffectAttribute.Ability][abilityId]
					addValue = math.max(0, (addValue - t.abs) * (1 - t.per))

					finalMemberReduce = finalMemberReduce or {}
					finalMemberReduce[k] = finalMemberReduce[k] or {}
					finalMemberReduce[k].ability = 1
				end
				runtimeAbilityMap[abilityId] = preValue + addValue

				-- ability map
				finalMemberAbilityMap = finalMemberAbilityMap or {}
				finalMemberAbilityMap[k] = finalMemberAbilityMap[k] or {}
				finalMemberAbilityMap[k][abilityId] = finalMemberAbilityMap[k][abilityId] or 0
				finalMemberAbilityMap[k][abilityId] = finalMemberAbilityMap[k][abilityId] + addValue
			end
		end
	end
	-- ability extra memberToAbilityExtra
	for k, v in pairs(memberToAbilityExtra) do
		local slot = self:GetSlotInGroup(k)
		-- still alive or pet
		if slot ~= nil then
			for abilityId, data in pairs(v) do
				local runtimeAbilityMap = self._groupRuntimeData[k].abilityMap
				local initialAbilityMap = self._groupData[k].abilityMap
				local preValue = runtimeAbilityMap[abilityId] or 0
				local initialValue = initialAbilityMap[abilityId] or 0
				local addValue = Helper.RoundAndCeil(initialValue * data.percent + data.abs)
				runtimeAbilityMap[abilityId] = preValue + addValue

				-- ability map
				finalMemberAbilityMap = finalMemberAbilityMap or {}
				finalMemberAbilityMap[k] = finalMemberAbilityMap[k] or {}
				finalMemberAbilityMap[k][abilityId] = finalMemberAbilityMap[k][abilityId] or 0
				finalMemberAbilityMap[k][abilityId] = finalMemberAbilityMap[k][abilityId] + addValue
			end
		end
	end

	-- crit chance
	for k, v in pairs(memberToCritChance) do
		local slot = self:GetSlotInGroup(k)
		-- still alive or pet
		if slot ~= nil then
			local preValue = self._groupRuntimeData[k].critChance or 0
			self._groupRuntimeData[k].critChance = preValue + v
			-- crit chance
			if finalMemberCritChance == nil then
				finalMemberCritChance = {}
			end
			finalMemberCritChance[k] = v
		end
	end
	-- dodge ignore
	for k, v in pairs(memberToDodgeIgnore) do
		local slot = self:GetSlotInGroup(k)
		-- still alive or pet
		if slot ~= nil then
			for valueIdx = 1, #v do
				table.insert(self._groupRuntimeData[k].dodgeIgnore, v[valueIdx])
			end
		end
	end
	-- dodge
	for k, v in pairs(memberToDodge) do
		local slot = self:GetSlotInGroup(k)
		-- still alive or pet
		if slot ~= nil then
			for valueIdx = 1, #v do
				table.insert(self._groupRuntimeData[k].dodge, v[valueIdx])
			end
		end
	end
	-- extra attack
	for k, v in pairs(memberToExtraAttack) do
		local slot = self:GetSlotInGroup(k)
		-- still alive or pet
		if slot ~= nil then
			for valueIdx = 1, #v do
				table.insert(self._groupRuntimeData[k].extraAttack, {extraAttackNum = v[valueIdx].extraAttackNum, chance = v[valueIdx].chance})
			end
			-- do sort when data changed
			if #v > 0 then
				table.sort(self._groupRuntimeData[k].extraAttack, GameData.ExtraAttackSortFunc)
			end
		end
	end
	---------------------------------------------------------------------------------------
	-- round crit chance
	for k, v in pairs(roundMemberToCritChance) do
		local slot = self:GetSlotInGroup(k)
		-- still alive or pet
		if slot ~= nil then
			self._groupRuntimeData[k].roundCritChance = v
		end
	end
	-- round crit damage
	for k, v in pairs(roundMemberToCritDamage) do
		local slot = self:GetSlotInGroup(k)
		-- still alive or pet
		if slot ~= nil then
			self._groupRuntimeData[k].roundCritDamage = v
		end
	end
	-- round crit damage defend
	for k, v in pairs(roundMemberToCritDamageDefend) do
		local slot = self:GetSlotInGroup(k)
		-- still alive or pet
		if slot ~= nil then
			self._groupRuntimeData[k].roundCritDamageDefend = v
		end
	end
	-- round extra attack
	for k, v in pairs(roundMemberToExtraAttack) do
		local slot = self:GetSlotInGroup(k)
		-- still alive or pet
		if slot ~= nil then
			self._groupRuntimeData[k].roundExtraAttack = v
		end
	end
	-- round dodge
	for k, v in pairs(roundMemberToDodge) do
		local slot = self:GetSlotInGroup(k)
		-- still alive or pet
		if slot ~= nil then
			self._groupRuntimeData[k].roundDodge = v
		end
	end
	-- round dodge ignore
	for k, v in pairs(roundMemberToDodgeIgnore) do
		local slot = self:GetSlotInGroup(k)
		-- still alive or pet
		if slot ~= nil then
			self._groupRuntimeData[k].roundDodgeIgnore = v
		end
	end
	-- round hp attack
	for k, v in pairs(roundMemberToHpAttack) do
		local slot = self:GetSlotInGroup(k)
		-- still alive or pet
		if slot ~= nil then
			self._groupRuntimeData[k].roundHpAttack = v
		end
	end
	-- round defend ignore
	for k, v in pairs(roundMemberToDefendIgnore) do
		local slot = self:GetSlotInGroup(k)
		-- still alive or pet
		if slot ~= nil then
			self._groupRuntimeData[k].roundDefendIgnore = v
		end
	end
	---------------------------------------------------------------------------------------

	if checkEnemy then
		sourceMemberSkills, finalMemberRecover, finalMemberAbilityMap, finalMemberCritChance, finalMemberElement = self:SettleEnemyBattleRoundSkills(
			currentRound,
			sourceMemberSkills,
			finalMemberRecover,
			finalMemberAbilityMap,
			finalMemberCritChance,
			finalMemberElement)
	end

	if finalMemberRecover == nil and 
		finalMemberAbilityMap == nil and 
		finalMemberCritChance == nil and 
		finalMemberElement == nil then
		return nil
	end

	return {
		sourceMembers = sourceMemberSkills, 
		recover = finalMemberRecover, 
		ability = finalMemberAbilityMap, 
		critChance = finalMemberCritChance,
		element = finalMemberElement,
		reduce = finalMemberReduce,
	}
end

function BattleCalculator:SettleEnemyBattleRoundSkills(currentRound, sourceMemberSkills, finalMemberRecover, finalMemberAbilityMap, finalMemberCritChance, finalElement)
	local enemyId = self._enemyId
	----------------------------------------------
	local recoverAbs = 0
	local recoverPercent = 0
	local abilityAdd = {}
	local changeElementId = nil
	----------------------------------------------
	local totalCritChance = 0
	local totalDodgeIgnore = {}
	local totalDodge = {}
	local totalExtraAttack = {}
	----------------------------------------------
	local roundCritChance = 0
	local roundCritDamage = 0
	local roundCritDamageDefend = 0
	local roundExtraAttack = {}
	local roundDodge = {}
	local roundDodgeIgnore = {}
	local roundHpAttack = {}
	local roundDefendIgnore = {}
	----------------------------------------------
	-- reset round data first
	self:ResetRoundData(self._enemyRuntimeData)

	for idx = 1, #self._dataOfEnemyBattleRoundSkills do
		local skillData = self._dataOfEnemyBattleRoundSkills[idx]
		if self:IsRoundSkillActivated(skillData, currentRound) then
			local skillId = skillData.id
			local skillValue = skillData.value
			local effectParameter = ConfigUtils.GetSkillEffectParameter(skillId)
			local effectAttribute = effectParameter.EffectAttribute
			local effectCalcType = effectParameter.CalculateType
			local skillAdded = false
			if effectAttribute == EffectAttribute.Recovery then
				local worked = false
				if effectParameter.Chance ~= nil then
					local randValue = Helper.RandFloat()
					if randValue < effectParameter.Chance * 0.01 then
						worked = true
					end
				end

				if worked then
					if effectCalcType == CalculateType.Abs then
						recoverAbs = recoverAbs + skillValue
					elseif effectCalcType == CalculateType.Percent then
						recoverPercent = recoverPercent + skillValue * 0.01
					end

					skillAdded = true
				end
			elseif effectAttribute == EffectAttribute.RecoveryWithAtk then
				local worked = false
				if effectParameter.Chance ~= nil then
					local randValue = Helper.RandFloat()
					if randValue < effectParameter.Chance * 0.01 then
						worked = true
					end
				end

				if worked then
					if effectCalcType == CalculateType.Percent then
						local atk = self._enemyRuntimeData.abilityMap[AbilityType.ATK] or 0
						recoverAbs = recoverAbs + math.ceil(skillValue * 0.01 * atk)
					else
						assert(false, "recovery with attack only support percent")
					end

					skillAdded = true
				end
			elseif effectAttribute == EffectAttribute.Ability then
				local abilityMap = GameData.ConstructAbilityMapOfSkills({{id = skillId, value = skillValue}})
				for abilityId, v in pairs(abilityMap) do
					if abilityAdd[abilityId] == nil then
						abilityAdd[abilityId] = {abs = 0, percent = 0}
					end

					abilityAdd[abilityId].abs = abilityAdd[abilityId].abs + v.abs
					abilityAdd[abilityId].percent = abilityAdd[abilityId].percent + v.percent
				end
				skillAdded = true
			elseif effectAttribute == EffectAttribute.ChangeElement then
				local elementId = skillValue
				if ConfigUtils.IsValidItem(elementId) then
					changeElementId = elementId
				else
					changeElementId = ConfigUtils.RandNewElement()
				end
				skillAdded = true
			elseif effectAttribute == EffectAttribute.CritChance then
				totalCritChance = totalCritChance + skillValue * 0.01
				skillAdded = true
			elseif effectAttribute == EffectAttribute.DodgeIgnore then
				table.insert(totalDodgeIgnore, skillValue * 0.01)
				skillAdded = true
			elseif effectAttribute == EffectAttribute.Dodge then
				table.insert(totalDodge, skillValue * 0.01)
				skillAdded = true
			elseif effectAttribute == EffectAttribute.ExtraAttack then
				local attackNum = ConfigUtils.GetSkillEffectValue(skillId)
				table.insert(totalExtraAttack, {extraAttackNum = attackNum, chance = skillValue * 0.01})
				skillAdded = true
			elseif effectAttribute == EffectAttribute.CritChanceOnce then
				roundCritChance = roundCritChance + skillValue * 0.01
				skillAdded = true
			elseif effectAttribute == EffectAttribute.CritDamageOnce then
				roundCritDamage = roundCritDamage + skillValue * 0.01
				skillAdded = true
			elseif effectAttribute == EffectAttribute.ExtraAttackOnce then
				local attackNum = ConfigUtils.GetSkillEffectValue(skillId)
				table.insert(roundExtraAttack, {extraAttackNum = attackNum, chance = skillValue * 0.01})
				skillAdded = true
			elseif effectAttribute == EffectAttribute.DodgeOnce then
				table.insert(roundDodge, skillValue * 0.01)
				skillAdded = true
			elseif effectAttribute == EffectAttribute.DodgeIgnoreOnce then
				table.insert(roundDodgeIgnore, skillValue * 0.01)
				skillAdded = true
			elseif effectAttribute == EffectAttribute.DamageFromCritDamageOnce then
				roundCritDamageDefend = roundCritDamageDefend + skillValue * 0.01
				skillAdded = true
			elseif effectAttribute == EffectAttribute.HpAttackOnce then
				if effectCalcType == CalculateType.Abs then
					local preValue = roundHpAttack.abs or 0
					roundHpAttack.abs = preValue + skillValue
				elseif effectCalcType == CalculateType.Percent then
					local preValue = roundHpAttack.percent or 0
					roundHpAttack.percent = preValue + skillValue * 0.01
				end
				skillAdded = true
			elseif effectAttribute == EffectAttribute.DefendIgnoreOnce then
				if effectCalcType == CalculateType.Abs then
					local preValue = roundDefendIgnore.abs or 0
					roundDefendIgnore.abs = preValue + skillValue
				elseif effectCalcType == CalculateType.Percent then
					local preValue = roundDefendIgnore.percent or 0
					roundDefendIgnore.percent = preValue + skillValue * 0.01
				end
				skillAdded = true
			elseif effectAttribute == EffectAttribute.RecoveryWithHurt then
				local hurtCount = self._enemyRuntimeData.roundHurtCount
				if hurtCount > 0 then
					if effectCalcType == CalculateType.Abs then
						recoverAbs = recoverAbs + skillValue * hurtCount
					elseif effectCalcType == CalculateType.Percent then
						recoverPercent = recoverPercent + skillValue * hurtCount * 0.01
					end
					skillAdded = true
				end
			elseif effectAttribute == EffectAttribute.AttributeWithHurt then
				local hurtCount = self._enemyRuntimeData.roundHurtCount
				if hurtCount > 0 then
					local abilityMap = GameData.ConstructAbilityMapOfSkills({{id = skillId, value = skillValue * hurtCount}})
					for abilityId, v in pairs(abilityMap) do
						if abilityAdd[abilityId] == nil then
							abilityAdd[abilityId] = {abs = 0, percent = 0}
						end

						abilityAdd[abilityId].abs = abilityAdd[abilityId].abs + v.abs
						abilityAdd[abilityId].percent = abilityAdd[abilityId].percent + v.percent
					end
					skillAdded = true
				end
			elseif effectAttribute == EffectAttribute.ReduceAbilityOnce then

			elseif effectAttribute == EffectAttribute.ReduceRecoveryOnce then

			else
				assert(false, "un-handled effect attribute of battle round skill: "..tostring(effectAttribute))
			end

			if skillAdded then
				if sourceMemberSkills[enemyId] == nil then
					sourceMemberSkills[enemyId] = {}
				end

				sourceMemberSkills[enemyId][skillId] = 1
			end

			skillData.used = skillData.used + 1
		end
	end

	-- recover
	local addHp = Helper.RoundAndCeil(self._enemyMaxHp * recoverPercent) + recoverAbs
	if addHp > 0 then
		self._enemyHp = self._enemyHp + addHp
		self._enemyHp = math.min(self._enemyHp, self._enemyMaxHp)
		-- recover
		if finalMemberRecover == nil then
			finalMemberRecover = {}
		end
		finalMemberRecover[enemyId] = addHp
	end
	-- ability
	for abilityId, data in pairs(abilityAdd) do
		local preValue = self._enemyRuntimeData.abilityMap[abilityId] or 0
		local initialValue = self._enemyData.abilityMap[abilityId] or 0
		local addValue = Helper.RoundAndCeil(initialValue * data.percent + data.abs)
		self._enemyRuntimeData.abilityMap[abilityId] = preValue + addValue
		-- ability map
		if finalMemberAbilityMap == nil then
			finalMemberAbilityMap = {}
		end
		if finalMemberAbilityMap[enemyId] == nil then
			finalMemberAbilityMap[enemyId] = {}
		end
		finalMemberAbilityMap[enemyId][abilityId] = addValue
	end
	-- element 
	if changeElementId ~= nil then
		self._enemyElement = changeElementId
		-- element
		if finalElement == nil then
			finalElement = {}
		end
		finalElement[enemyId] = changeElementId
	end
	------------------------------------------------------------------------------------------------
	-- crit chance
	if totalCritChance > 0 then
		self._enemyRuntimeData.critChance = self._enemyRuntimeData.critChance + totalCritChance
		-- crit chance
		if finalMemberCritChance == nil then
			finalMemberCritChance = {}
		end
		finalMemberCritChance[enemyId] = v
	end
	-- dodge ignore
	for k, v in pairs(totalDodgeIgnore) do
		table.insert(self._enemyRuntimeData.dodgeIgnore, v)
	end
	-- dodge
	for k, v in pairs(totalDodge) do
		table.insert(self._enemyRuntimeData.dodge, v)
	end
	-- extra attack
	for k, v in pairs(totalExtraAttack) do
		table.insert(self._enemyRuntimeData.extraAttack, {extraAttackNum = v.extraAttackNum, chance = v.chance})
	end
	-- do sort when data changed
	if #totalExtraAttack > 0 then
		table.sort(self._enemyRuntimeData.extraAttack, GameData.ExtraAttackSortFunc)
	end
	------------------------------------------------------------------------------------------------
	-- round crit chance
	self._enemyRuntimeData.roundCritChance = roundCritChance
	self._enemyRuntimeData.roundCritDamage = roundCritDamage
	self._enemyRuntimeData.roundCritDamageDefend = roundCritDamageDefend
	self._enemyRuntimeData.roundExtraAttack = roundExtraAttack
	self._enemyRuntimeData.roundDodge = roundDodge
	self._enemyRuntimeData.roundDodgeIgnore = roundDodgeIgnore
	self._enemyRuntimeData.roundHpAttack = roundHpAttack
	self._enemyRuntimeData.roundDefendIgnore = roundDefendIgnore
	------------------------------------------------------------------------------------------------

	return sourceMemberSkills, finalMemberRecover, finalMemberAbilityMap, finalMemberCritChance, finalElement
end
-------------------------------------------------------------------------------
function BattleCalculator:IsDodge(targetId)
	local dodgeList = {}
	local roundDodgeList = {}
	if targetId == self._enemyId then
		dodgeList = self._enemyRuntimeData.dodge
		roundDodgeList = self._enemyRuntimeData.roundDodge or {}
	else
		dodgeList = self._groupRuntimeData[targetId].dodge
		roundDodgeList = self._groupRuntimeData[targetId].roundDodge or {}
	end

	for idx = 1, #dodgeList do
		local randValue = Helper.RandFloat()
		if randValue < dodgeList[idx] then
			return true
		end
	end

	for idx = 1, #roundDodgeList do
		local randValue = Helper.RandFloat()
		if randValue < roundDodgeList[idx] then
			return true
		end
	end

	return false
end

function BattleCalculator:IsDodgeIgnore(sourceId)
	local dodgeIgnoreList = {}
	local roundDodgeIgnoreList = {}
	if sourceId == self._enemyId then
		dodgeIgnoreList = self._enemyRuntimeData.dodgeIgnore
		roundDodgeIgnoreList = self._enemyRuntimeData.roundDodgeIgnore or {}
	else
		dodgeIgnoreList = self._groupRuntimeData[sourceId].dodgeIgnore
		roundDodgeIgnoreList = self._groupRuntimeData[sourceId].roundDodgeIgnore or {}
	end

	for idx = 1, #dodgeIgnoreList do
		local randValue = Helper.RandFloat()
		if randValue < dodgeIgnoreList[idx] then
			return true
		end
	end

	for idx = 1, #roundDodgeIgnoreList do
		local randValue = Helper.RandFloat()
		if randValue < roundDodgeIgnoreList[idx] then
			return true
		end
	end

	return false
end

function BattleCalculator:IsCrit(sourceId)
	local critChance = 0
	if sourceId == self._enemyId then
		critChance = self:GetEnemyCritChance()
	else
		critChance = self:GetMemberCritChance(sourceId)
	end

	local randValue = Helper.RandFloat()
	return randValue < critChance
end

function BattleCalculator:CalculateBaseDamage(sourceId)
	if sourceId == self._enemyId then
		local baseValue = self._enemyRuntimeData.abilityMap[AbilityType.ATK] or 0
		local lostHp = math.max(self._enemyMaxHp - self._enemyHp, 0)
		local roundHpAttack = self._enemyRuntimeData.roundHpAttack
		local finalValue = baseValue
		-- has value
		if roundHpAttack.abs ~= nil or roundHpAttack.percent ~= nil then
			local hpAttackAbs = roundHpAttack.abs or 0
			local hpAttackPercent = roundHpAttack.percent or 0
			finalValue = finalValue + Helper.RoundAndCeil((hpAttackAbs + lostHp) * (1 + hpAttackPercent))
		end

		return finalValue
	else
		local baseValue = self._groupRuntimeData[sourceId].abilityMap[AbilityType.ATK] or 0
		local sourceSlot = self:GetSlotInGroup(sourceId)
		local finalValue = baseValue
		if sourceSlot ~= nil then
			local currentHp = self._orderedGroup[sourceSlot].hp
			local fullHp = self._orderedGroup[sourceSlot].maxHp
			local lostHp = math.max(fullHp - currentHp, 0)
			local roundHpAttack = self._groupRuntimeData[sourceId].roundHpAttack
			-- has value
			if roundHpAttack.abs ~= nil or roundHpAttack.percent ~= nil then
				local hpAttackAbs = roundHpAttack.abs or 0
				local hpAttackPercent = roundHpAttack.percent or 0
				finalValue = finalValue + Helper.RoundAndCeil((hpAttackAbs + lostHp) * (1 + hpAttackPercent))
			end
		end
		
		return finalValue
	end
end

function BattleCalculator:GetElementOfItem(itemId)
	if itemId == self._enemyId then
		return self._enemyElement
	else
		return ConfigUtils.GetElementOfItem(itemId)
	end
end

function BattleCalculator:CalculateCritFactor(sourceId, targetId)
	local critDamage = 0
	local critDamageDefend = 0

	if sourceId == self._enemyId then
		critDamage = self._enemyRuntimeData.critDamage + self._enemyRuntimeData.roundCritDamage
		local roundCritDamageDefend = self._groupRuntimeData[targetId].roundCritDamageDefend or 0
		critDamageDefend = self._groupRuntimeData[targetId].critDamageDefend + roundCritDamageDefend
	else
		critDamage = self._groupRuntimeData[sourceId].critDamage + self._groupRuntimeData[sourceId].roundCritDamage
		local roundCritDamageDefend = self._enemyRuntimeData.roundCritDamageDefend or 0
		critDamageDefend = self._enemyRuntimeData.critDamageDefend + roundCritDamageDefend
	end

	local critFactor = 2 + critDamage
	critDamageDefend = math.max(0, 1 + critDamageDefend)
	return critFactor, critDamageDefend
end

function BattleCalculator:CalculateElementFactor(baseElementFactor, sourceId, sourceElement, targetId, targetElement)
	local elementDamage = 0
	local elementDamageDefend = 0

	if sourceId == self._enemyId then
		elementDamage = self._enemyRuntimeData.damageToElement[targetElement] or 0
		elementDamageDefend = self._groupRuntimeData[targetId].damageFromElement[sourceElement] or 0
	else
		elementDamage = self._groupRuntimeData[sourceId].damageToElement[targetElement] or 0
		elementDamageDefend = self._enemyRuntimeData.damageFromElement[sourceElement] or 0
	end

	local elementFactor = (baseElementFactor + elementDamage) * (1 + elementDamageDefend)
	return elementFactor
end

function BattleCalculator:CalculateDefendFactor(targetId, sourceId)
	if targetId == self._enemyId then
		local defendIgnore = self._groupRuntimeData[sourceId].roundDefendIgnore
		return self:GetDefendFactor(self._enemyRuntimeData.abilityMap, defendIgnore)
	else
		local defendIgnore = self._enemyRuntimeData.roundDefendIgnore
		return self:GetDefendFactor(self._groupRuntimeData[targetId].abilityMap, defendIgnore)
	end
end

function BattleCalculator:CalculateAttackNum(sourceId)
	local extraAttackList = {}
	local roundExtraAttackList = {}
	if sourceId == self._enemyId then
		extraAttackList = self._enemyRuntimeData.extraAttack
		roundExtraAttackList = self._enemyRuntimeData.roundExtraAttack or {}
	else
		extraAttackList = self._groupRuntimeData[sourceId].extraAttack
		roundExtraAttackList = self._groupRuntimeData[sourceId].roundExtraAttack or {}
	end

	local finalExtraAttackList = {}
	if #roundExtraAttackList == 0 then
		finalExtraAttackList = extraAttackList
	else
		local ldx = 1
		local rdx = 1

		while ldx <= #extraAttackList or rdx <= #roundExtraAttackList do
			local numL = 0
			local chanceL = 0
			if ldx <= #extraAttackList then
				numL = extraAttackList[ldx].extraAttackNum
				chanceL = extraAttackList[ldx].chance
			end

			local numR = 0
			local chanceR = 0
			if rdx <= #roundExtraAttackList then
				numR = roundExtraAttackList[ldx].extraAttackNum
				chanceR = roundExtraAttackList[ldx].chance
			end

			local useL = ((numL > numR) or (numL == numR and chanceL >= chanceR))
			if useL then
				table.insert(finalExtraAttackList, {extraAttackNum = numL, chance = chanceL})
				ldx = ldx + 1
			else
				table.insert(finalExtraAttackList, {extraAttackNum = numR, chance = chanceR})
				rdx = rdx + 1
			end
		end
	end

	for idx = 1, #finalExtraAttackList do
		local randValue = Helper.RandFloat()
		if randValue < finalExtraAttackList[idx].chance then
			return finalExtraAttackList[idx].extraAttackNum + 1
		end
	end

	return 1
end

function BattleCalculator:IsAllCharacterDead()
	for idx = 1, #self._orderedGroup do
		local memberId = self._orderedGroup[idx].id
		-- not pet
		if memberId ~= self._petId then
			if self._orderedGroup[idx].hp > 0 then
				return false
			end
		end
	end

	return true
end

function BattleCalculator:GetLeftCharacterNum()
	local num = 0
	for idx = 1, #self._orderedGroup do
		local memberId = self._orderedGroup[idx].id
		-- not pet
		if memberId ~= self._petId then
			if self._orderedGroup[idx].hp > 0 then
				num = num + 1
			end
		end
	end

	return num
end

function BattleCalculator:CleanDeadMember()
	for idx = #self._orderedGroup, 1, -1 do
		local memberId = self._orderedGroup[idx].id
		-- not pet
		if memberId ~= self._petId then
			if self._orderedGroup[idx].hp <= 0 then
				table.remove(self._orderedGroup, idx)
			end
		end
	end
end
-------------------------------------------------------------------------------
function BattleCalculator:IsRoundSkillActivated(skillData, currentRound)
	local roundLimit = skillData.limit
	local roundUsed = skillData.used
	if roundUsed >= roundLimit then
		return false
	end

	local roundStart = skillData.start
	if currentRound < roundStart then
		return false
	end

	local roundInterval = skillData.interval
	local roundDiff = currentRound - roundStart
	local intValue = math.floor(roundDiff / roundInterval)
	local mod = currentRound - intValue * roundInterval - roundStart
	return mod == 0
end
-------------------------------------------------------------------------------
function BattleCalculator:GetSlotInGroup(memberId)
	for idx = 1, #self._orderedGroup do
		if self._orderedGroup[idx].id == memberId then
			return idx
		end
	end

	return nil
end

function BattleCalculator:GetDefendFactor(abilityMap, defendIgnore)
	local defendIgnoreAbs = defendIgnore.abs or 0
	local defendIgnorePercent = defendIgnore.percent or 0
	-- 伤害减免 = 防御 / (防御 + Value1)
	local defendValue = abilityMap[AbilityType.DEF] or 0
	-- 这个技能策划的数值是大于0，这里做减法处理
	defendValue = (defendValue - defendIgnoreAbs) * (1 - defendIgnorePercent)
	if defendValue <= 0 then
		defendValue = 0
	else
		defendValue = Helper.RoundAndCeil(defendValue)
	end

	return 1 - defendValue / (defendValue + BattleFactor.Value1)
end

function BattleCalculator:GetBaseCritChance(abilityMap)
	-- 暴击概率 = 幸运 / (幸运 + Value2)
	local luckValue = abilityMap[AbilityType.LUK] or 0
	local baseCritChance = luckValue / (luckValue + BattleFactor.Value2)
	return baseCritChance
end

function BattleCalculator:GetMemberCritChance(memberId)
	local v = self._groupRuntimeData[memberId]
	local abilityMap = v.abilityMap
	local baseCritChance = self:GetBaseCritChance(abilityMap)
	local addCritChance = v.critChance
	local roundAddCritChance = v.roundCritChance or 0
	return baseCritChance + addCritChance + roundAddCritChance
end

function BattleCalculator:GetEnemyCritChance()
	local abilityMap = self._enemyRuntimeData.abilityMap
	local baseCritChance = self:GetBaseCritChance(abilityMap)
	local addCritChance = self._enemyRuntimeData.critChance
	local roundAddCritChance = self._enemyRuntimeData.roundCritChance or 0
	return baseCritChance + addCritChance + roundAddCritChance
end
-------------------------------------------------------------------------------

--查找怪物身上的削减技能
function BattleCalculator:CollectEnemyReduceEffect(currentRound)
	local ret = {}
	for idx = 1, #self._dataOfEnemyBattleRoundSkills do
		local skillData = self._dataOfEnemyBattleRoundSkills[idx]
		if not self:IsRoundSkillActivated(skillData, currentRound) then
			goto continue
		end
		local skillId = skillData.id
		local skillValue = skillData.value
		local effectParameter = ConfigUtils.GetSkillEffectParameter(skillId)
		local effectAttribute = effectParameter.EffectAttribute
		local effectCalcType = effectParameter.CalculateType
		local effectValue = effectParameter.EffectValue
		if effectAttribute == EffectAttribute.ReduceRecoveryOnce then
			local chance = effectParameter.Chance or 0
			if Helper.RandFloat() < chance * 0.01 then
				--不允许为负数
				skillValue = math.abs(skillValue)
				ret[EffectAttribute.Recovery] = ret[EffectAttribute.Recovery] or {abs=0,per=0}
				local temp = ret[EffectAttribute.Recovery]
				if effectCalcType == CalculateType.Abs then
					temp.abs = temp.abs + skillValue
				end
				if effectCalcType == CalculateType.Percent then
					temp.per = temp.per + skillValue * 0.01
				end
			end
		elseif effectAttribute == EffectAttribute.ReduceAbilityOnce then
			local chance = effectParameter.Chance or 0
			if Helper.RandFloat() < chance * 0.01 then
				--不允许为负数
				skillValue = math.abs(skillValue)
				ret[EffectAttribute.Ability] = ret[EffectAttribute.Ability] or {}
				ret[EffectAttribute.Ability][effectValue] = ret[EffectAttribute.Ability][effectValue] or {abs=0,per=0}
				local temp = ret[EffectAttribute.Ability][effectValue]
				if effectCalcType == CalculateType.Abs then
					temp.abs = temp.abs + skillValue
				end
				if effectCalcType == CalculateType.Percent then
					temp.per = temp.per + skillValue * 0.01
				end
			end
		end
		::continue::
	end
	return ret
end


return BattleCalculator