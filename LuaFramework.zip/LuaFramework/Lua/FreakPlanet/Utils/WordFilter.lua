local utf8 = require("FreakPlanet/Utils/Utf8")
local class = require("FreakPlanet/Utils/middleclass")

WordFilter = class("WordFilter")

local utf8Len = utf8.len
local utf8Sub = utf8.sub
local strSub = string.sub
local strLen = string.len
local strByte = string.byte
local strGsub = string.gsub

local _maskWord = '*'

local function _word2Tree(root, word)
	if strLen(word) == 0 then
        return
    end

	local function _byte2Tree(r, ch, tail)
		if tail then
            if type(r[ch]) == 'table' then
                r[ch].isTail = true
            else
                r[ch] = true
            end
		else
            if r[ch] == true then
                r[ch] = { isTail = true }
            else
			    r[ch] = r[ch] or {}
            end
		end
		return r[ch]
	end

	local tmpparent = root
	local len = utf8Len(word)
    for i=1, len do
    	if tmpparent == true then
    	   tmpparent = { isTail = true }
    	end
    	tmpparent = _byte2Tree(tmpparent, utf8Sub(word, i, i), i==len)
    end
end

local function _detect(parent, word, idx)
    local len = utf8Len(word)

	local ch = utf8Sub(word, 1, 1)
	local child = parent[ch]

    if not child then
    elseif type(child) == 'table' then
        if len > 1 then
            if child.isTail then
	            return _detect(child, utf8Sub(word, 2), idx+1) or idx
            else
                return _detect(child, utf8Sub(word, 2), idx+1)
            end
        elseif len == 1 then
            if child.isTail == true then
                return idx
            end
        end
    elseif (child == true) then
    	return idx
    end
    return false
end

function WordFilter:initialize(illegalWords, specialWords)
	self._tree = {}
	for _, illegalWord in ipairs(illegalWords) do
		_word2Tree(self._tree, illegalWord)
	end
	self._specialWords = specialWords
end

function WordFilter:FilterIllegalWord(s)
	local word, idx, illegals, tmps
	local i = 1
	local len = utf8Len(s)

	while true do
    	word = utf8Sub(s, i)
    	idx = _detect(self._tree, word, i)

    	if idx then
    		illegals = utf8Sub(s, i, idx)
    		tmps = ''
    		for j=1, utf8Len(illegals) do
    			tmps = tmps .. _maskWord
    		end
    		s = strGsub(s, illegals, tmps)
    		i = idx+1
    	else
    		i = i + 1
    	end
    	if i > len then
    		break
    	end
    end
    return s
end

function WordFilter:FilterSpecialWord(inputStr)
	if not self._specialWords then
		return inputStr
	end
	local myWord = string.upper(inputStr)
	for i, specialWord in ipairs(self._specialWords) do
		local normalHits = {}
		local pinyinHits = {}
		local tongyinHits = {}

		--统计myWord中命中的敏感字
		local specialWordCount = utf8Len(specialWord)
		for i = 1, specialWordCount do
			local specialChar = utf8Sub(specialWord, i, i)
			if string.find(myWord, specialChar) then
				table.insert(normalHits, specialChar)
			end
		end

		--统计myWord中命中的拼音(输入本身就是拼音)
		local specialPinyin = PinyinHelper.GetPinyinTable(specialWord)
		for i = 1, #specialPinyin do
			local specialChar = specialPinyin[i]
			if string.find(myWord, specialChar) then
				table.insert(pinyinHits, specialChar)
			end
		end

		--将myWord转成拼音比较(输入的是同音字,转换成拼音比较)
		local myWordPinyin = PinyinHelper.GetPinyinTable(myWord)
		for i = 1, #myWordPinyin do
			local myChar = utf8Sub(myWord, i, i)
			local myPinyinChar = myWordPinyin[i]
			for j = 1, #specialPinyin do
				local specialChar = specialPinyin[j]
				if myPinyinChar == specialChar then
					table.insert(tongyinHits, myChar)
					break
				end
			end
		end

		--
		if #normalHits >= 2 or #pinyinHits + #tongyinHits >= 2 then
			for i,v in ipairs(normalHits) do
				myWord = string.gsub(myWord, v, _maskWord)
			end
			for i,v in ipairs(pinyinHits) do
				--因为是拼音,所以需要相同长度的*来填充
				local mask = ""
				for j = 1, #v do
					mask = mask .. _maskWord
				end
				myWord = string.gsub(myWord, v, mask)
			end
			for i,v in ipairs(tongyinHits) do
				myWord = string.gsub(myWord, v, _maskWord)
			end
		end
	end

	--恢复合法字母的大小写
	local myWordTable = utf8.toTable(myWord)
	local inputStrTable = utf8.toTable(inputStr)
	local count = math.min(#myWordTable, #inputStrTable)
	for i = 1, count do
		if myWordTable[i] ~= _maskWord then
			myWordTable[i] = inputStrTable[i]
		end
	end
	myWord = table.concat(myWordTable)

	return myWord
end

function WordFilter:FilterSensitiveWordWithColor(s)
	local word, idx, illegals, tmps
	local i = 1
	local len = utf8Len(s)

	local result = s
	local count = 0

	while true do
    	word = utf8Sub(s, i)
    	idx = _detect(self._tree, word, i)

    	if idx then
			illegals = utf8Sub(s, i, idx)
			illegalsWithColor = "[E54747][s]" .. illegals .. "[/s][-]"
    		result = strGsub(result, illegals, illegalsWithColor)
			count = count + 1
			i = idx+1
    	else
    		i = i + 1
    	end
    	if i > len then
    		break
    	end
    end
    return result, count
end

function WordFilter:ContainsSensitiveWord(s)
    local word, idx, illegals, tmps
    local i = 1
    local len = utf8Len(s)

    while true do
        word = utf8Sub(s, i)
        idx = _detect(self._tree, word, i)

        if idx then
           return true
        else
            i = i + 1
        end
        if i > len then
            break
        end
    end
    return false
end

