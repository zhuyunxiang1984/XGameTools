UIHelper = {}

local this = UIHelper

RetCode = {
    OK = "OK",
    ModuleLocked = "ModuleLocked",
    PlanetAreaLocked = "PlanetAreaLocked",
    PlanetLocked = "PlanetLocked",
    SummonLocked = "SummonLocked",
    CharacterLocked = "CharacterLocked",
    WorkShopLocked = "WorkShopLocked",
    LabRecipeLocked = "LabRecipeLocked",
    ArenaNotOpen = "ArenaNotOpen",
    ActivityBattleInvalid = "ActivityBattleInvalid",
    Unknow = "Unknow",
}

-----------------------------------------------------------------------------------
local function GetItemBorderAndBgInternal(rarity)
    local borderName = ""
    local bgName = ""

    if rarity == 1 then
        bgName = "ItemIconBG_Bronze"
        borderName = "ItemIconFG_Bronze"
    elseif rarity == 2 then
        bgName = "ItemIconBG_Silver"
        borderName = "ItemIconFG_Silver"
    elseif rarity == 3 then
        bgName = "ItemIconBG_Purple"
        borderName = "ItemIconFG_Gold"
    elseif rarity == 4 then
        bgName = "ItemIconBG_Gold"
        borderName = "ItemIconFG_Gold"
    elseif rarity == 5 then
        bgName = "ItemIconBG_Special"
        borderName = "ItemIconFG_Special"
    else
        assert(false, "un-handled item rarity: "..tostring(rarity))
    end

    return bgName, borderName
end

local function GetRoleBorderAndBgInternal(rarity)
    local borderName = ""
    local bgName = ""

    if rarity == 1 then
        bgName = "ItemIconBG_Bronze"
        borderName = "RoleIconFG_Bronze"
    elseif rarity == 2 then
        bgName = "ItemIconBG_Silver"
        borderName = "RoleIconFG_Silver"
    elseif rarity == 3 then
        bgName = "ItemIconBG_Purple"
        borderName = "RoleIconFG_Gold"
    elseif rarity == 4 then
        bgName = "ItemIconBG_Gold"
        borderName = "RoleIconFG_Gold"
    elseif rarity == 5 then
        bgName = "ItemIconBG_Special"
        borderName = "RoleIconFG_Special"
    else
        assert(false, "un-handled item rarity: "..tostring(rarity))
    end

    return bgName, borderName
end

local function GetItemDetailBorderInternal(rarity)
    local borderName = ""

    if rarity == 1 then
        borderName = "PhotoBG_Bronze"
    elseif rarity == 2 then
        borderName = "PhotoBG_Silver"
    elseif rarity == 3 then
        borderName = "PhotoBG_Purple"
    elseif rarity == 4 then
        borderName = "PhotoBG_Gold"
    elseif rarity == 5 then
        borderName = "PhotoBG_Special"
    else
        assert(false, "un-handled item rarity: "..tostring(rarity))
    end

    return borderName
end

function UIHelper.GetItemDetailBorder(itemId)
    local itemType = ConfigUtils.GetItemTypeFromId(itemId)
    if itemType == ItemType.Character then
        local rarity = ConfigUtils.GetCharacterRarity(itemId)
        return GetItemDetailBorderInternal(rarity)
    elseif itemType == ItemType.Enemy then
        local rarity = ConfigUtils.GetEnemyRarity(itemId)
        return GetItemDetailBorderInternal(rarity)
    elseif itemType == ItemType.Pet then
        local rarity = ConfigUtils.GetPetRarity(itemId)
        return GetItemDetailBorderInternal(rarity)
    else
        return GetItemDetailBorderInternal(1)
    end
end

function UIHelper.GetBorderAndBgByItemId(itemId)
    local itemType = ConfigUtils.GetItemTypeFromId(itemId)
    if itemType == ItemType.Goods then
        local rarity = ConfigUtils.GetGoodsRarity(itemId)
        return GetItemBorderAndBgInternal(rarity)
    elseif itemType == ItemType.Equipment then
        local rarity = ConfigUtils.GetEquipmentRarity(itemId)
        return GetItemBorderAndBgInternal(rarity)
    elseif itemType == ItemType.Character then
        local rarity = ConfigUtils.GetCharacterRarity(itemId)
        return GetRoleBorderAndBgInternal(rarity)
    elseif itemType == ItemType.Skin then
        local rarity = ConfigUtils.GetSkinRarity(itemId)
        return GetItemBorderAndBgInternal(rarity)
    elseif itemType == ItemType.Enemy then
        local rarity = ConfigUtils.GetEnemyRarity(itemId)
        return GetItemBorderAndBgInternal(rarity)
    elseif itemType == ItemType.RoomPiece then
        local rarity = ConfigUtils.GetRoomPieceRarity(itemId)
        return GetItemBorderAndBgInternal(rarity)
    elseif itemType == ItemType.Pet then
        local rarity = ConfigUtils.GetPetRarity(itemId)
        return GetItemBorderAndBgInternal(rarity)
    else
        return GetItemBorderAndBgInternal(1)
    end
end

function UIHelper.GetItemIconAndNodeName(itemId)
    local itemType = ConfigUtils.GetItemTypeFromId(itemId)

    local iconName = nil
    local nodeName = nil
    local showNum = true
    if itemType == ItemType.Gold then
        nodeName = "General"
        iconName = "icon_money"
    elseif itemType == ItemType.Diamond then
        nodeName = "General"
        iconName = "icon_yuanbao"
    elseif itemType == ItemType.Token then
        nodeName = "General"
        iconName = ConfigUtils.GetTokenIcon(itemId)
    elseif itemType == ItemType.Time then
        nodeName = "General"
        iconName = "MissionIconTime"
    elseif itemType == ItemType.Character or 
        itemType == ItemType.Enemy or 
        itemType == ItemType.Pet then
        -- no icon name here
        nodeName = "Character"
        showNum = false
    elseif itemType == ItemType.Skin then
        nodeName = "CharacterSkin"
        showNum = false
    elseif itemType == ItemType.Food then
        nodeName = "SpaceTravel"
        iconName = "SpaceTravelIcon_1"

    elseif itemType == ItemType.FoodMax then
        nodeName = "SpaceTravel"
        iconName = "SpaceTravelIcon_1"
    elseif itemType == ItemType.Fuel then
        nodeName = "SpaceTravel"
        iconName = "SpaceTravelIcon_2"
    elseif itemType == ItemType.FuelMax then
        nodeName = "SpaceTravel"
        iconName = "SpaceTravelIcon_2"
    elseif itemType == ItemType.CapacityMax then
        nodeName = "SpaceTravel"
        iconName = "SpaceTravelIcon_3"
    elseif itemType == ItemType.SpaceTravelScore then
        nodeName = "SpaceTravel"
        iconName = "SpaceTravelIcon_5"
    elseif itemType == ItemType.SpaceTravelFriendliness then
        nodeName = "SpaceTravel"
        iconName = ConfigUtils.GetSpaceTravelFriendlinessIcon(itemId)
    elseif itemType == ItemType.Goods then
        nodeName = "Goods"
        iconName = ConfigUtils.GetGoodsIcon(itemId)
    elseif itemType == ItemType.Equipment then
        nodeName = "Equipment"
        iconName = ConfigUtils.GetEquipmentIcon(itemId)
    elseif itemType == ItemType.Planet then
        nodeName = "Planet"
        iconName = ConfigUtils.GetPlanetIcon(itemId)
        showNum = false
    elseif itemType == ItemType.LabRecipe then
        nodeName = "Goods"
        iconName = ConfigUtils.GetLabRecipeIcon(itemId)
        showNum = false
    elseif itemType == ItemType.WorkShop then
        nodeName = "WorkShop"
        iconName = ConfigUtils.GetWorkShopIcon(itemId)
        showNum = false
    elseif itemType == ItemType.PlanetArea then
        nodeName = "Area"
        iconName = ConfigUtils.GetAreaIcon(itemId)
        showNum = false
    elseif itemType == ItemType.RoomPiece then
        nodeName = "RoomPiece"
        iconName = ConfigUtils.GetRoomPieceIcon(itemId)
        showNum = false
    elseif itemType == ItemType.SpaceTravelGoods then
        nodeName = "Goods"
        iconName = ConfigUtils.GetSpaceTravelGoodsIcon(itemId)
    elseif itemType == ItemType.CatchFishPoint then
        nodeName = "General"
        iconName = "GoldFish_Energy"
    elseif itemType == ItemType.ActivityPassport then
        nodeName = "General"
        iconName = "icon_goodluck"
    elseif itemType == ItemType.Postcard then
        nodeName = "Postcard"
        showNum = false
    else
        assert(false, "un-handled item type: "..tostring(itemType))
    end

    return iconName, nodeName, showNum
end

function UIHelper.ConstructItemIconAndNum(ctrl, root, itemId, itemNum, isShowNum)
    if isShowNum == nil then
        isShowNum = true
    end
    local icons = root:Find("Icons")
    local itemType = ConfigUtils.GetItemTypeFromId(itemId)
    local nodeName = ConfigUtils.GetGeneralItemNode(itemType)
    local showNum = ConfigUtils.IsGeneralItemShowNum(itemType)

    local selectedSprite = nil
    for idx = 1, icons.childCount do
        local item = icons:GetChild(idx - 1).gameObject
        local match = (item.name == nodeName)
        item:SetActive(match)
        if match then
            local sp = item:GetComponent("UISprite")
            selectedSprite = sp
            this.SetItemIcon(ctrl, sp, itemId)
        end
    end

    local numRoot = root:Find("Num")
    if numRoot ~= nil then
        itemNum = itemNum or 0
        local numLabel = numRoot:GetComponent("UILabel")
        if showNum and itemNum > 0 then
            numLabel.text = "x"..tostring(itemNum)
        else
            numLabel.text = ""
        end
        numRoot.gameObject:SetActive(isShowNum)
    end

    return selectedSprite
end

local function GetReturnCodeOfModule(moduleName)
    local code = RetCode.OK
    if not GameData.IsModuleUnlocked(moduleName) then
        code = RetCode.ModuleLocked
    end

    return code
end
-----------------------------------------------------------------------------------
function UIHelper.PlaceHorizontalItemPosition(item, itemIdx, totalCount, itemGap)
    local pos = item.localPosition
    pos.x = this.CalculateItemOffset(itemIdx, totalCount, itemGap)
    pos.y = 0
    item.localPosition = pos
end

function UIHelper.PlaceVerticalItemPosition(item, itemIdx, totalCount, itemGap)
    local pos = item.localPosition
    pos.x = 0
    pos.y = -this.CalculateItemOffset(itemIdx, totalCount, itemGap)
    item.localPosition = pos
end

-- calculate item offset based on the count, width and gap
function UIHelper.CalculateItemOffset(itemIdx, totalCount, itemGap)
    local totalWidth = (totalCount - 1) * itemGap
    local halfWidth = totalWidth / 2

    local offset = (itemIdx - 1) * itemGap
    offset = offset - halfWidth

    return offset
end

function UIHelper.CalculateItemPosition(itemIdx, itemGap, initpos)
    local position = initpos + (itemIdx - 1) * itemGap
    return position
end

function UIHelper.SetHorizontalItemPosition(item, itemIdx, itemGap, initpos)
    local pos = item.localPosition
    pos.x = this.CalculateItemPosition(itemIdx, itemGap, initpos)
    pos.y = 0
    item.localPosition = pos
end

-----------------------------------------------------------------------------------
function UIHelper.GetCharacterSimpleShowLevel(roleId)
    local level = GameData.GetCharacterLevel(roleId)
    return string.format(SAFE_LOC("loc_SimpleLevel"), level)
end

function UIHelper.GetCharacterShowLevel(roleId)
    local level = GameData.GetCharacterLevel(roleId)
    return string.format(SAFE_LOC('loc_SimpleLevel'), level)
end

function UIHelper.ConstructCharacterItem(ctrl, item, roleId, abilityMap, sortAbilityId, sortPower)
    sortPower = sortPower or false
    local icon = item:Find("Icon"):GetComponent("UISprite")
    this.SetCharacterIcon(ctrl, icon, roleId)
    icon.color = Color.white

    local rarity = ConfigUtils.GetCharacterRarity(roleId)
    local bgName = GetRoleBorderAndBgInternal(rarity)

    local bg = item:Find("BG"):GetComponent("UISprite")
    bg.spriteName = bgName
    -- level
    local levelLabel = item:Find("Level"):GetComponent("UILabel")
    levelLabel.text = this.GetCharacterShowLevel(roleId)
    -- name
    local nameLabel = item:Find("Name"):GetComponent("UILabel")
    nameLabel.text = ConfigUtils.GetCharacterName(roleId)
    -- element
    local elementIcon = item:Find("Element"):GetComponent("UISprite")
    local elementId = ConfigUtils.GetElementOfItem(roleId)
    elementIcon.spriteName = ConfigUtils.GetElementIconOfItem(roleId, true)
    -- style
    local styleIcon = item:Find("Style"):GetComponent("UISprite")
    local style = ConfigUtils.GetStyleOfItem(roleId)
    styleIcon.spriteName = ConfigUtils.GetStyleIcon(style)
    styleIcon.color = ConfigUtils.GetStyleIconColor(elementId)
    -- ability
    local abilityRoot = item:Find("Ability").gameObject
    abilityRoot:SetActive(sortAbilityId ~= nil)
    -- ability
    if sortAbilityId ~= nil then
        -- icon
        local abilityIcon = item:Find("Ability/Icon"):GetComponent("UISprite")
        abilityIcon.spriteName = ConfigUtils.GetAbilityIcon(sortAbilityId)
        -- value
        local abilityValue = abilityMap[sortAbilityId] or 0
        local abilityValueLabel = item:Find("Ability/Value"):GetComponent("UILabel")
        abilityValueLabel.text = tostring(abilityValue)
    end
    -- power
    local showPower = (sortAbilityId == nil and sortPower)
    local powerRoot = item:Find("Power")
    if powerRoot ~= nil then
        powerRoot.gameObject:SetActive(showPower)
        if showPower then
            -- power
            local powerLabel = item:Find("Power/Value"):GetComponent("UILabel")
            local powerNum = ConfigUtils.GetPowerOfAbilityMap(abilityMap)
            powerLabel.text = tostring(powerNum)
        end
    end
    --外观定制标识
    local appearanceNode = item:Find("Appearance")
    if appearanceNode then
        appearanceNode.gameObject:SetActive(GameData.GetCharacterAppearance(roleId) > 0)
    end
end

function UIHelper.ConstructExploreItemPositionHint(positionHint, active, ItemId)
    if positionHint then
        local bgItem = positionHint.item:Find("BG").gameObject
        local activeMark =  positionHint.mark
        local elementSprite = activeMark:GetComponent("UISprite")
        if active then
            activeMark:SetActive(true)
            bgItem:SetActive(false)
            if ItemId then
                UIHelper.ConstructExploreItemElement(ItemId, elementSprite)
            end
        else
            activeMark:SetActive(false)
            bgItem:SetActive(true)
        end

    end

end

function UIHelper.ConstructExploreItemElement(id, sprite)
    if ConfigUtils.IsValidItem(id) then
        local elementId = ConfigUtils.GetElementOfItem(id)
        sprite.spriteName = ConfigUtils.GetActiveElementIcon(elementId)
    end
end

function UIHelper.ConstructWorkShopCharacterItem(ctrl, item, roleId, abilityMap, ablityList)
    local icon = item:Find("Icon"):GetComponent("UISprite")
    this.SetCharacterIcon(ctrl, icon, roleId)
    icon.color = Color.white

    local rarity = ConfigUtils.GetCharacterRarity(roleId)
    local bgName = GetRoleBorderAndBgInternal(rarity)

    local bg = item:Find("BG"):GetComponent("UISprite")
    bg.spriteName = bgName
    -- level
    local levelLabel = item:Find("Level"):GetComponent("UILabel")
    levelLabel.text = this.GetCharacterShowLevel(roleId)
    -- name
    local nameLabel = item:Find("Name"):GetComponent("UILabel")
    nameLabel.text = ConfigUtils.GetCharacterName(roleId)
    -- ability
    local abilityRoot = item:Find("AbilityRoot")
    for idx = 1, abilityRoot.childCount do
        local abilityItem = abilityRoot:GetChild(idx - 1)
        local hasAbility = (idx <= #ablityList)
        abilityItem.gameObject:SetActive(hasAbility)
        if hasAbility then
            local abilityId = ablityList[idx]
            local abilityIcon = abilityItem:Find("Icon"):GetComponent("UISprite")
            local abilityValueLabel = abilityItem:Find("Value"):GetComponent("UILabel")
            abilityIcon.spriteName = ConfigUtils.GetAbilityIcon(abilityId)
            abilityValueLabel.text = tostring(abilityMap[abilityId] or 0)
        end
    end
    --外观定制标识
    local appearanceNode = item:Find("Appearance")
    if appearanceNode then
        appearanceNode.gameObject:SetActive(GameData.GetCharacterAppearance(roleId) > 0)
    end
end

function UIHelper.ConstructGalleryCharacterItem(ctrl, item, roleId)
    local icon = item:Find("Icon"):GetComponent("UISprite")
    this.SetCharacterIcon(ctrl, icon, roleId, true)
    icon.color = Color.white

    local rarity = ConfigUtils.GetCharacterRarity(roleId)
    local bgName = GetRoleBorderAndBgInternal(rarity)

    local bg = item:Find("BG"):GetComponent("UISprite")
    bg.spriteName = bgName
    -- level
    local levelLabel = item:Find("Level"):GetComponent("UILabel")
    levelLabel.text = this.GetCharacterShowLevel(roleId)
    -- name
    local nameLabel = item:Find("Name"):GetComponent("UILabel")
    nameLabel.text = ConfigUtils.GetCharacterName(roleId)
     -- element
    local elementIcon = item:Find("Element"):GetComponent("UISprite")
    local elementId = ConfigUtils.GetElementOfItem(roleId)
    elementIcon.spriteName = ConfigUtils.GetElementIconWithStyle(elementId)
    -- style
    local styleIcon = item:Find("Style"):GetComponent("UISprite")
    local style = ConfigUtils.GetStyleOfItem(roleId)
    styleIcon.spriteName = ConfigUtils.GetStyleIcon(style)
    styleIcon.color = ConfigUtils.GetStyleIconColor(elementId)

    --外观定制标识
    local appearanceNode = item:Find("Appearance")
    if appearanceNode then
        appearanceNode.gameObject:SetActive(false)
    end
end

function UIHelper.ConstructLockedCharacterItem(ctrl, item, roleId, useDefaultIcon)
    useDefaultIcon = useDefaultIcon or false

    local icon = item:Find("Icon"):GetComponent("UISprite")
    this.SetCharacterIcon(ctrl, icon, roleId, useDefaultIcon)
    icon.color = LOCK_ICON_COLOR

    local rarity = ConfigUtils.GetCharacterRarity(roleId)
    local bgName = GetRoleBorderAndBgInternal(rarity)

    local bg = item:Find("BG"):GetComponent("UISprite")
    bg.spriteName = bgName
    -- level
    local levelLabel = item:Find("Level"):GetComponent("UILabel")
    levelLabel.text = "??"
    -- name
    local nameLabel = item:Find("Name"):GetComponent("UILabel")
    nameLabel.text = ConfigUtils.GetCharacterName(roleId)
     -- element
    local elementIcon = item:Find("Element"):GetComponent("UISprite")
    local elementId = ConfigUtils.GetElementOfItem(roleId)
    elementIcon.spriteName = ConfigUtils.GetElementIconWithStyle(elementId)
    -- style
    local styleIcon = item:Find("Style"):GetComponent("UISprite")
    local style = ConfigUtils.GetStyleOfItem(roleId)
    styleIcon.spriteName = ConfigUtils.GetStyleIcon(style)
    styleIcon.color = ConfigUtils.GetStyleIconColor(elementId)

    --外观定制标识
    local appearanceNode = item:Find("Appearance")
    if appearanceNode then
        appearanceNode.gameObject:SetActive(false)
    end
end

function UIHelper.ConstructCoupleCharacterItem(ctrl, item, roleId, skinId)
    local icon = item:Find("Icon"):GetComponent("UISprite")
    this.SetCharacterIconWithSkin(ctrl, icon, skinId)
    icon.color = Color.white
    -- level
    local levelLabel = item:Find("Level"):GetComponent("UILabel")
    levelLabel.text = this.GetCharacterShowLevel(roleId)
    -- element
    local elementIcon = item:Find("Element"):GetComponent("UISprite")
    elementIcon.spriteName = ConfigUtils.GetElementIconOfItem(roleId)
end
-----------------------------------------------------------------------------------
function UIHelper.ConstructGoodsItem(ctrl, item, itemId, showTypeIcon)
    local iconSprite = item:Find("Icon"):GetComponent("UISprite")
    UIHelper.SetItemIcon(ctrl, iconSprite, itemId)
    iconSprite.color = Color.white

    local numLabel = item:Find("Num"):GetComponent("UILabel")
    numLabel.text = ""

    local nameLabel = item:Find("Name"):GetComponent("UILabel")
    nameLabel.text = ConfigUtils.GetGoodsName(itemId)

    local nameBG = item:Find("NameBG"):GetComponent("UISprite")
    nameBG.spriteName = ConfigUtils.GetGoodsNameBG(itemId)

    showTypeIcon = showTypeIcon or false
    local typeIconName = ConfigUtils.GetGoodsTypeIcon(itemId)
    local typeSprite = item:Find("Type"):GetComponent("UISprite")
    local finalShowType = (showTypeIcon and typeIconName ~= nil)
    typeSprite.gameObject:SetActive(finalShowType)
    if finalShowType then
        typeSprite.spriteName = typeIconName
    end
end

function UIHelper.ConstructLockedGoodsItem(ctrl, item, itemId, showTypeIcon)
    local iconSprite = item:Find("Icon"):GetComponent("UISprite")
    UIHelper.SetItemIcon(ctrl, iconSprite, itemId)
    iconSprite.color = LOCK_ICON_COLOR

    local numLabel = item:Find("Num"):GetComponent("UILabel")
    numLabel.text = ""

    local nameLabel = item:Find("Name"):GetComponent("UILabel")
    nameLabel.text = ConfigUtils.GetGoodsName(itemId)

    local nameBG = item:Find("NameBG"):GetComponent("UISprite")
    nameBG.spriteName = ConfigUtils.GetGoodsNameBG(itemId)

    showTypeIcon = showTypeIcon or false
    local typeIconName = ConfigUtils.GetGoodsTypeIcon(itemId)
    local typeSprite = item:Find("Type"):GetComponent("UISprite")
    local finalShowType = (showTypeIcon and typeIconName ~= nil)
    typeSprite.gameObject:SetActive(finalShowType)
    if finalShowType then
        typeSprite.spriteName = typeIconName
    end
end

-----------------------------------------------------------------------------------
function UIHelper.ConstructPetItem(ctrl, item, itemId, sortAbilityId, sortPower)
    local unlocked = GameData.IsPetUnlocked(itemId)

    local name = ConfigUtils.GetPetName(itemId)
    local rarity = ConfigUtils.GetPetRarity(itemId)
    local bgName = GetItemBorderAndBgInternal(rarity)

    local iconSprite = item:Find("Icon"):GetComponent("UISprite")
    this.SetCharacterIcon(ctrl, iconSprite, itemId)

    local bgSprite = item:Find("BG"):GetComponent("UISprite")
    bgSprite.spriteName = bgName

    local nameLabel = item:Find("Name"):GetComponent("UILabel")
    nameLabel.text = name

    local levelLabel = item:Find("Level")
    if levelLabel ~= nil then
        levelLabel = levelLabel:GetComponent("UILabel")
        levelLabel.text = ""
    end

    local elementSprite = item:Find("Element"):GetComponent("UISprite")
    elementSprite.spriteName = ConfigUtils.GetElementIconOfItem(itemId, false)

    if unlocked then
        iconSprite.color = Color.white
    else
        iconSprite.color = LOCK_ICON_COLOR
    end
    -- ability
    local abilityRoot = item:Find("Ability")
    if abilityRoot ~= nil then
        abilityRoot.gameObject:SetActive(sortAbilityId ~= nil)
        if sortAbilityId ~= nil then
            local abilityIcon = item:Find("Ability/Icon"):GetComponent("UISprite")
            abilityIcon.spriteName = ConfigUtils.GetAbilityIcon(sortAbilityId)

            local abilityValue = GameData.GetPetAbilityOf(itemId, sortAbilityId)
            local abilityValueLabel = item:Find("Ability/Value"):GetComponent("UILabel")
            abilityValueLabel.text = tostring(abilityValue)
        end
    end
    -- power
    local powerRoot = item:Find("Power")
    if powerRoot ~= nil then
        sortPower = sortPower or false
        local showPower = (sortAbilityId == nil and sortPower)
        powerRoot.gameObject:SetActive(showPower)
        if showPower then
            local powerLabel = item:Find("Power/Value"):GetComponent("UILabel")
            local abilityMap = GameData.GetPetAbilityMap(itemId)
            local powerNum = ConfigUtils.GetPowerOfAbilityMap(abilityMap)
            powerLabel.text = tostring(powerNum)
        end
    end
end

function UIHelper.ConstructTouristRankPetItem(ctrl, item, itemId, itemNum)
    local name = ConfigUtils.GetPetName(itemId)
    local rarity = ConfigUtils.GetPetRarity(itemId)
    local bgName = GetItemBorderAndBgInternal(rarity)

    local iconSprite = item:Find("Icon"):GetComponent("UISprite")
    this.SetCharacterIcon(ctrl, iconSprite, itemId)

    local bgSprite = item:Find("BG"):GetComponent("UISprite")
    bgSprite.spriteName = bgName

    local nameLabel = item:Find("Name"):GetComponent("UILabel")
    nameLabel.text = name

    local levelLabel = item:Find("Level"):GetComponent("UILabel")
    local level = ConfigUtils.GetPetLevelByNum(itemId, itemNum)
    levelLabel.text = string.format(SAFE_LOC("loc_SimpleLevel"), level)
end

-----------------------------------------------------------------------------------
function UIHelper.GetGoalIconShowInfo(triggers, itemType, itemId, itemRecipe, itemCharacter)
    local iconName = nil
    local nodeName = nil
    -- for adventure battle, final show item is character or npc
    local finalShowId = itemId

    if Helper.TableContains(triggers, TriggerType.UsingCostume) then
        nodeName = "General"
        iconName = "MissionIconUsingCostume"
    elseif Helper.TableContains(triggers, TriggerType.Arena) then
        nodeName = "General"
        iconName = "MissionIconArena"
    elseif Helper.TableContains(triggers, TriggerType.ActivityBattle) then
        nodeName = "Activity"
        iconName = "ActivityStoryBotton"
    elseif Helper.TableContains(triggers, TriggerType.CompleteDemand) or 
           Helper.TableContains(triggers, TriggerType.DemandReward) or 
           Helper.TableContains(triggers, TriggerType.DemandCost) then
        nodeName = "General"
        iconName = "HelpButton2"
    elseif Helper.TableContains(triggers, TriggerType.UnlockSkill) then
        if ConfigUtils.IsValidItem(itemId) then
            nodeName = "Character"
        else
            nodeName = "General"
            iconName = "MissionIconUnlockSkill"
        end
    elseif itemType == ItemType.Equipment then
        if ConfigUtils.IsValidItem(itemId) then
            nodeName = "Equipment"
        else
            if itemCharacter ~= nil then
                nodeName = "Character"
                finalShowId = itemCharacter[1]
            else
                nodeName = "General"
                iconName = "MissionIconGoods"
            end
        end
    elseif itemType == ItemType.Gold then
        nodeName = "General"
        iconName = "icon_money"
    elseif itemType == ItemType.Diamond then
        nodeName = "General"
        iconName = "icon_yuanbao"
    elseif itemType == ItemType.Time then
        nodeName = "General"
        iconName = "MissionIconTime"
    elseif itemType == ItemType.Skin then
        nodeName = "General"
        iconName = "MissionIconUsingCostume"
    elseif itemType == ItemType.Character then
        if ConfigUtils.IsValidItem(itemId) then
            nodeName = "Character"
        else
            nodeName = "General"
            iconName = "MissionIconCharacter"
        end
    elseif itemType == ItemType.Goods then
        if ConfigUtils.IsValidItem(itemId) then
            nodeName = "Goods"
        else
            if ConfigUtils.IsValidItem(itemRecipe) then
                local recipeType = ConfigUtils.GetItemTypeFromId(itemRecipe)
                assert(recipeType == ItemType.Goods, "recipe of goods should be goods: "..tostring(recipeType))
                nodeName = "Goods"
                finalShowId = itemRecipe
            else
                nodeName = "General"
                if Helper.TableContains(triggers, TriggerType.Explore) or
                        Helper.TableContains(triggers, TriggerType.StartExplore)then
                    iconName = "MissionIconArea"
                else
                    iconName = "MissionIconGoods"
                end
            end
        end
    elseif itemType == ItemType.Planet then
        if ConfigUtils.IsValidItem(itemId) then
            nodeName = "Planet"
            iconName = ConfigUtils.GetPlanetIcon(itemId)
        else
            nodeName = "General"
            iconName = "MissionIconPlanet"
        end
    elseif itemType == ItemType.PlanetArea then
        nodeName = "General"
        iconName = "MissionIconArea"
    elseif itemType == ItemType.Enemy then
        if ConfigUtils.IsValidItem(itemId) then
            nodeName = "Character"
        else
            nodeName = "General"
            iconName = "MissionIconArea"
        end
    elseif itemType == ItemType.Challenge then
        if ConfigUtils.IsValidItem(itemId) then
            nodeName = "Character"
            finalShowId = ConfigUtils.GetLastEnemyOfChallenge(itemId)
        else
            if itemCharacter ~= nil then
                nodeName = "Character"
                finalShowId = itemCharacter[1]
            else
                nodeName = "General"
                if Helper.TableContains(triggers, TriggerType.Challenge) then
                    iconName = "MissionIconArea"
                else
                    iconName = "MissionIconEquip"
                end
            end
        end
    elseif itemType == ItemType.WorkShop then
        if ConfigUtils.IsValidItem(itemId) then
            nodeName = "WorkShop"
            iconName = ConfigUtils.GetWorkShopIcon(itemId)
        else
            nodeName = "General"
            iconName = "MissionIconUpgrade"
        end
    elseif itemType == ItemType.Pet then
        if ConfigUtils.IsValidItem(itemId) then
            nodeName = "Character"
        else
            nodeName = "General"
            iconName = "MissionIconArea"
        end
    else
        assert(false, "un-handled item type: "..tostring(itemType))
    end

    return iconName, nodeName, finalShowId
end

function UIHelper.ConstructGoalIcon(ctrl, item, goalId, goalCondition)
    local icons = item:Find("Icons")

    local triggers = ConfigUtils.GetGoalTriggers(goalId)
    local itemType = goalCondition.Type
    local itemId = goalCondition.Value
    local itemRecipe = goalCondition.Recipe
    local itemCharacter = goalCondition.Character

    local iconSpriteName, nodeName, showItemId = this.GetGoalIconShowInfo(triggers, itemType, itemId, itemRecipe, itemCharacter)
    XDebug.Log("LZ", "showItemId:", showItemId)
    for idx = 1, icons.childCount do
        local node = icons:GetChild(idx - 1):GetComponent("UISprite")
        local match = (node.gameObject.name == nodeName)
        node.gameObject:SetActive(match)
        if match then
            if nodeName == "Character" then
                this.SetCharacterIcon(ctrl, node, showItemId)
            elseif nodeName == "Goods" then
                --this.SetGoodsIcon(ctrl, node, showItemId)
                this.SetItemIcon(ctrl, node, showItemId)
            elseif nodeName == "Equipment" then
                this.SetEquipmentIcon(ctrl, node, showItemId)
            else
                node.spriteName = iconSpriteName
            end
            --this.SetItemIcon(ctrl, node, showItemId)
        end
    end
end

function UIHelper.ConstructGoalRewardContent(itemId, itemNum)
    local name = nil
    local itemType = ConfigUtils.GetItemTypeFromId(itemId)
    if itemType == ItemType.LabRecipe then
        name = SAFE_LOC("loc_global_item_detail_3")
    elseif itemType == ItemType.Diamond or itemType == ItemType.Gold then
        name = ""
    else
        name = ConfigUtils.GetItemNameByType(itemType, itemId)
    end

    local content = name
    if ConfigUtils.IsGeneralItemShowNum(itemType) then
        content = name.."x"..tostring(itemNum)
    end

    return content
end

-----------------------------------------------------------------------------------
function UIHelper.SetCharacterSkin(skeletonAnimation, characterId, useDefaultSkin)
    useDefaultSkin = useDefaultSkin or false
    local skinId = nil
    if useDefaultSkin then
        skinId = GameData.GetCharacterDefaultSkin(characterId)
    else
        local appearanceId = GameData.GetCharacterAppearance(characterId)
        if appearanceId > 0 then
            skinId = appearanceId
        else
            skinId = GameData.GetCharacterSkin(characterId)
        end
    end
    this.SetCharacterSkinWithSkin(skeletonAnimation, skinId)
end

function UIHelper.SetCharacterSkinWithSkin(skeletonAnimation, skinId)
    local skinName = ConfigUtils.GetSkinNameInSpine(skinId)
    Helper.SetSkin(skeletonAnimation, skinName)
end


function UIHelper.SetGrayUISpriteOrLabel(transform, color)
    local UISprite = transform:GetComponent("UISprite")
    local UILabel = transform:GetComponent("UILabel")
    if UISprite then
        UISprite.color = color
    elseif UILabel then
        UILabel.color = color
    else
        local childCount = transform.childCount
        if childCount > 0 then
            for idx = 1, childCount do
                this.SetGrayUISpriteOrLabel(transform:GetChild(idx - 1), color)
            end
        end
    end
end

function UIHelper.SetCharacterIcon(ctrl, characterSprite, itemId, useDefaultIcon)
    local iconName, atlasName
    local itemType = ConfigUtils.GetItemTypeFromId(itemId)
    if itemType == ItemType.Character then
        useDefaultIcon = useDefaultIcon or false
        iconName, atlasName = GameData.GetCharacterIcon(itemId, useDefaultIcon)
    else
        iconName, atlasName = this.GetItemIcon(itemId)
    end
    ctrl:SetIconWithAtlas(characterSprite, iconName, atlasName)
end

function UIHelper.SetCharacterIconWithSkin(ctrl, characterSprite, skinId)
    local iconName, iconAtlasName, iconBundleName = ConfigUtils.GetSkinCharacterIcon(skinId)
    ctrl:SetIconWithAtlas(characterSprite, iconName, iconAtlasName)
end

function UIHelper.SetEquipmentIcon(ctrl, sprite, equipId, equipLevel)
    equipLevel = equipLevel or 1
    local iconName, iconAtlasName, iconBundleName = ConfigUtils.GetEquipmentIcon(equipId, equipLevel)
    ctrl:SetIconWithAtlas(sprite, iconName, iconAtlasName)
end

-------------------------------------------------------------------------------------
--获取道具的iconName, atlasName
function UIHelper.GetItemIcon(itemId)
    local itemType = ConfigUtils.GetItemTypeFromId(itemId)
    if itemType == ItemType.Character then
        return GameData.GetCharacterIcon(itemId)
    end
    if itemType == ItemType.Enemy then
        return ConfigUtils.GetEnemyIcon(itemId)
    end
    if itemType == ItemType.Pet then
        return ConfigUtils.GetPetIcon(itemId)
    end
    if itemType == ItemType.Goods then
        return ConfigUtils.GetGoodsIcon(itemId)
    end
    if itemType == ItemType.LabRecipe then
        return ConfigUtils.GetLabRecipeIcon(itemId)
    end
    if itemType == ItemType.WorkShop then
        return ConfigUtils.GetWorkShopIcon(itemId)
    end
    if itemType == ItemType.Token then
        return ConfigUtils.GetTokenIcon(itemId)
    end
    if itemType == ItemType.Equipment then
        return ConfigUtils.GetEquipmentIcon(itemId)
    end
    if itemType == ItemType.Planet then
        return ConfigUtils.GetPlanetIcon(itemId)
    end
    if itemType == ItemType.PlanetArea then
        return ConfigUtils.GetAreaIcon(itemId)
    end
    if itemType == ItemType.RoomPiece then
        return ConfigUtils.GetRoomPieceIcon(itemId)
    end
    if itemType == ItemType.Skin then
        return ConfigUtils.GetSkinCharacterIcon(itemId)
    end
    if itemType == ItemType.Postcard then
        return ConfigUtils.GetPostcardIcon(itemId)
    end
    if itemType == ItemType.HomeFurniture then
        return ConfigUtils.GetHomeFurnitureIcon(itemId)
    end
    return ConfigUtils.GetGeneralItemIcon(itemType), "UIGeneral"
end

function UIHelper.SetItemIcon(ctrl, sprite, itemId, isSnapSize)
    local iconName, atlasName = this.GetItemIcon(itemId)
    ctrl:SetIconWithAtlas(sprite, iconName, atlasName, isSnapSize)
end

--设置NGUI图标
function UIHelper.SetIconWithAtlas(assetLoader, sprite, iconName, atlasName, isSnapSize)
    atlasName = "atlas_p_" .. atlasName
    local atlasObj = assetLoader:LoadAsset(atlasName):GetComponent("UIAtlas")
    if atlasObj and sprite.atlas ~= atlasObj then
        sprite.atlas = atlasObj
    end
    sprite.spriteName = iconName
    if isSnapSize then
        sprite:MakePixelPerfect()
    end
end

--
function UIHelper.AdjustSpriteSize(sprite)
    local texture = sprite.mainTexture
end


function UIHelper.GetSkillShowText(skillId, skillValue)
    assert(skillId ~= nil, "skill id should not be nil")
    local skillDesc = ConfigUtils.GetSkillDesc(skillId)

    local absValue = math.abs(skillValue)
    local str = skillDesc
    if string.find(str, "{Value}") ~= nil then
        str = string.gsub(str, "{Value}", tostring(absValue))
    elseif string.find(str, "{ValueDivide}") ~= nil then
        absValue = absValue / 100
        absValue = Helper.Round(absValue, 2)
        str = string.gsub(str, "{ValueDivide}", tostring(absValue))
    end

    return str
end

function UIHelper.GetSkillHintWithIcon(skillId, skillValue)
    local effectAttribute = ConfigUtils.GetSkillEffectAttribute(skillId)
    local effectParameter = ConfigUtils.GetSkillEffectParameter(skillId)
    local effectValue = effectParameter.EffectValue
    assert(effectValue ~= nil, "effect value is not allowed to be nil: "..tostring(skillId))
    local itemType = ConfigUtils.GetItemTypeFromId(effectValue)

    local iconName = ""
    if itemType == ItemType.Ability then
        iconName = ConfigUtils.GetAbilityIcon(effectValue)
    elseif itemType == ItemType.Element then
        local elementCode = ConfigUtils.GetElementCode(effectValue)
        if effectAttribute == EffectAttribute.DamageToElement then
            iconName = "DamageToElement_"..elementCode
        elseif effectAttribute == EffectAttribute.DamageFromElement then
            iconName = "DamageFromElement_"..elementCode
        else
            assert(false, "un-handled effect attribute: "..tostring(effectAttribute).." of skill: "..tostring(skillId))
        end
    else
        assert(false, "un-handled item type: "..tostring(effectValue).." of skill: "..tostring(skillId))
    end

    local valueText = ""

    local calcType = ConfigUtils.GetSkillEffectCalculateType(skillId)
    if calcType == CalculateType.Percent then
        if skillValue > 0 then
            valueText = " +"..tostring(skillValue).."%"
        else
            valueText = " "..tostring(skillValue).."%"
        end
    elseif calcType == CalculateType.Abs then
        if skillValue > 0 then
            valueText = " +"..tostring(skillValue)
        else
            valueText = " "..tostring(skillValue)
        end
    else
        assert(false, "un-handled calculate type: "..tostring(calcType).." of skill: "..tostring(skillId))
    end

    return iconName, valueText
end

function UIHelper.GetSkillHintValueOnly(skillId, skillValue)
    local valueText = ""
    local calcType = ConfigUtils.GetSkillEffectCalculateType(skillId)
    if calcType == CalculateType.Percent then
        if skillValue > 0 then
            valueText = " +"..tostring(skillValue).."%"
        else
            valueText = " "..tostring(skillValue).."%"
        end
    elseif calcType == CalculateType.Abs then
        if skillValue > 0 then
            valueText = " +"..tostring(skillValue)
        else
            valueText = " "..tostring(skillValue)
        end
    else
        assert(false, "un-handled calculate type: "..tostring(calcType).." of skill: "..tostring(skillId))
    end

    return valueText
end

function UIHelper.GetShowPercentText(percent)
    local value = math.floor(percent * 100 + 0.1)

    return string.format("%d%%", value)
end

function UIHelper.GetShowIntPercentText(percent)
    return string.format("%d%%", percent)
end

function UIHelper.GetShowMoneyText(num)
    if num > 10000 then
        local showNum = math.floor(num / 1000)
        return tostring(showNum).."K"
    end

    return tostring(num)
end

function UIHelper.GetGameVersion()
    local str = ""
    if not Global.IsCheckVersion() then
        if Global.ProductMode == 1 then
            str = SAFE_LOC("loc_global_server_dev")
        elseif Global.ProductMode == 2 then
            str = SAFE_LOC("loc_global_server_qa")
        elseif Global.ProductMode == 3 then
            str = SAFE_LOC("loc_global_server_online")
        end
        str = str..tostring(Global.MajorVersion).."."..tostring(Global.MinorVersion).."."..tostring(SvnVersion).."-"..tostring(Global.ChannelId)
    end

    return str
end

function UIHelper.GetExploreRuleShowText(rule, isHint)
    local ret = ""
    if isHint then
        ret = SAFE_LOC(rule.Hint)
    else
        ret = SAFE_LOC(rule.Desc)
    end

    local values = rule.Value or {}
    local ruleType = rule.Condition
    local isTag = (ruleType == ExploreRuleType.NeedTagAnd or
        ruleType == ExploreRuleType.NeedTagOr or
        ruleType == ExploreRuleType.BanTagAnd or
        ruleType == ExploreRuleType.BanTagOr)

    for idx = 1, #values do
        local replaceText = tostring(values[idx])
        if isTag then
            replaceText = ConfigUtils.GetTagName(values[idx])
        end

        if not isHint then
            replaceText = "[ffde27]"..replaceText.."[-]"
        end

        ret = Helper.StringFindAndReplace(ret, "{Value"..tostring(idx).."}", replaceText)
    end

    return ret
end
-----------------------------------------------------------------------------------
function UIHelper.GetStatusShowText(status)
    if status == CharacterStatus.Explore then
        return SAFE_LOC("loc_Exploring")
    elseif status == CharacterStatus.WorkShop then
        return SAFE_LOC("打工中 ")
    elseif status == CharacterStatus.ActivityExplore then
        return SAFE_LOC("活动探索中")
    end

    return nil
end

function UIHelper.GetSelectionFailReasonShowText(status)
    if status == SelectionFailReason.BreakRule then
        return SAFE_LOC("条件不符")
    elseif status == SelectionFailReason.ExploreMember then
        return SAFE_LOC("loc_Exploring")
    elseif status == SelectionFailReason.ActivityExploreMember then
        return SAFE_LOC("活动探索中")
    elseif status == SelectionFailReason.WorkShopMember then
        return SAFE_LOC("打工中")
    end

    return nil
end

function UIHelper.GetReturnCodeShowText(retCode)
    if retCode == RetCode.ModuleLocked then
        return SAFE_LOC("loc_global_need_finish_mission")
    elseif retCode == RetCode.PlanetAreaLocked then
        return SAFE_LOC("关卡未解锁")
    elseif retCode == RetCode.PlanetLocked then
        return SAFE_LOC("星球未解锁")
    elseif retCode == RetCode.SummonLocked then
        return SAFE_LOC("loc_global_lottery_lock")
    elseif retCode == RetCode.CharacterLocked then
        return SAFE_LOC("角色未解锁")
    elseif retCode == RetCode.WorkShopLocked then
        return SAFE_LOC("打工点未解锁")
    elseif retCode == RetCode.LabRecipeLocked then
        return SAFE_LOC("合成配方未解锁")
    elseif retCode == RetCode.Unknow then
        return SAFE_LOC("无法跳转")
    elseif retCode == RetCode.ArenaNotOpen then
        return SAFE_LOC("竞技场暂未开放")
    elseif retCode == RetCode.ActivityBattleInvalid then
        return SAFE_LOC("活动挑战暂未开放")
    else
        assert(false, "un-handled return code: "..tostring(retCode))
    end
end

function UIHelper.GetSourceShowText(sourceType, sourceValue)
    if sourceType == SourceType.Explore then
        if ConfigUtils.IsValidItem(sourceValue) then
            return ConfigUtils.GetAreaName(sourceValue)
        else
            return SAFE_LOC("loc_global_item_source_explore")
        end
    elseif sourceType == SourceType.Craft then
        return SAFE_LOC("loc_global_item_source_craft")
    elseif sourceType == SourceType.Mission then
        return SAFE_LOC("loc_global_item_source_mission")
    elseif sourceType == SourceType.Demand then
        return SAFE_LOC("loc_global_item_source_demand")
    elseif sourceType == SourceType.Summon then
        if ConfigUtils.IsValidItem(sourceValue) then
            return ConfigUtils.GetSummonName(sourceValue)
        else
            return SAFE_LOC("loc_global_item_source_summon")
        end
    elseif sourceType == SourceType.SignIn then
        return SAFE_LOC("loc_global_item_source_signin")
    elseif sourceType == SourceType.WorkShop then
        return SAFE_LOC("loc_global_item_source_workshop")
    elseif sourceType == SourceType.Challenge then
        return SAFE_LOC("loc_global_item_source_challenge")
    elseif sourceType == SourceType.Event then
        return SAFE_LOC("loc_global_item_source_event")
    elseif sourceType == SourceType.ArenaMarket then
        return SAFE_LOC("loc_global_item_source_arenamarket")
    elseif sourceType == SourceType.Arena then
        return SAFE_LOC("loc_global_item_source_arena")
    else
        assert(false, "un-handled source type: "..tostring(sourceType))
    end
end

function UIHelper.GetSourceCtrlByItemSource(sourceType, sourceValue)
    local ret = {code = RetCode.OK}
    local moduleName = nil

    if sourceType == SourceType.Explore then
        -- source value should always be planet level id
        moduleName = ModuleNames.Explore
        ret.ctrlName = CtrlNames.ExploreGuide
        ret.ctrlParameter = sourceValue
        if not GameData.IsPlanetAreaUnlocked(sourceValue) then
            ret.code = RetCode.PlanetAreaLocked
        end
    elseif sourceType == SourceType.Craft then
        -- source value should always be lib recipe id
        moduleName = ModuleNames.Lab
        ret.ctrlName = CtrlNames.Laboratory
        ret.ctrlParameter = sourceValue
        if not GameData.IsLabRecipeUnlocked(sourceValue) then
            ret.code = RetCode.LabRecipeLocked
        end
    elseif sourceType == SourceType.Mission then
        -- source value should always be goal id
        moduleName = ModuleNames.Mission
        ret.ctrlName = CtrlNames.Goal
    elseif sourceType == SourceType.Demand then
        moduleName = ModuleNames.Demand
        ret.ctrlName = CtrlNames.Goal
        ret.ctrlParameter = GoalMode.Demand
    elseif sourceType == SourceType.Summon then
        -- source value should always be summon id
        moduleName = ModuleNames.Summon
        ret.ctrlName = CtrlNames.Summon
        ret.ctrlParameter = sourceValue
        if ConfigUtils.IsValidItem(sourceValue) and not GameData.IsSummonPoolOpen(sourceValue) then
            ret.code = RetCode.SummonLocked
        end
    elseif sourceType == SourceType.WorkShop then
        -- source value should always be workshop id
        moduleName = ModuleNames.WorkShop
        ret.ctrlName = CtrlNames.WorkShop
        ret.hintParameter = sourceValue
        if not GameData.IsWorkShopUnlocked(sourceValue) then
            ret.code = RetCode.WorkShopLocked
        end
    elseif sourceType == SourceType.Challenge then
        -- source value should always be challenge id
        local challengeCharacter = ConfigUtils.GetCharacterOfChallenge(sourceValue)
        if challengeCharacter ~= nil then
            moduleName = ModuleNames.CharacterList
            ret.ctrlName = CtrlNames.CharacterList
            ret.ctrlParameter = challengeCharacter
            if not GameData.IsCharacterUnlocked(challengeCharacter) then
                ret.code = RetCode.CharacterLocked
            end
        else
            moduleName = ModuleNames.Explore
            local planetArea = ConfigUtils.GetAreaOfChallenge(sourceValue)
            local activeChallengeId = GameData.GetActiveChallengeOfArea(planetArea)
            -- current active challenge
            if sourceValue == activeChallengeId then
                ret.ctrlName = CtrlNames.ExploreChallenge
                ret.ctrlParameter = sourceValue
            else
                ret.ctrlName = CtrlNames.ExploreGuide
                ret.ctrlParameter = planetArea
                ret.hintParameter = sourceValue
            end

            if not GameData.IsPlanetAreaUnlocked(planetArea) then
                ret.code = RetCode.PlanetAreaLocked
            end
        end
    elseif sourceType == SourceType.Arena then
        -- 活动模块比任务模块先开
        moduleName = ModuleNames.Activity
        ret.ctrlName = CtrlNames.Arena
    elseif sourceType == SourceType.ArenaMarket then
        -- 活动模块比任务模块先开
        moduleName = ModuleNames.Activity
        ret.ctrlName = CtrlNames.Arena
    elseif sourceType == SourceType.SignIn or sourceType == SourceType.Event then
        assert(false, "source type sign-in should not get here")
    else
        assert(false, "un-handled source type: "..tostring(sourceType))
    end

    if ret.code == RetCode.OK and not GameData.IsModuleUnlocked(moduleName) then
        ret.code = RetCode.ModuleLocked
    end

    return ret
end

function UIHelper.GetSourceCtrlByGoalId(goalId)
    local trigger = ConfigUtils.GetGoalTriggers(goalId)[1]
    -- the first one
    local goalConditions = ConfigUtils.GetGoalConditions(goalId)
    local itemId = goalConditions[1].Value
    local itemType = goalConditions[1].Type
    local goalArea = goalConditions[1].Area

    local ret = {code = RetCode.OK}
    local moduleName = nil

    if ConfigUtils.IsValidItem(goalArea) then
        moduleName = ModuleNames.Explore
        -- if the area is exploring or no team, can't jump to explore character
        if not JumpManager.CanJumpToPlanetArea(goalArea) then
            ret.ctrlName = CtrlNames.ExploreGuide
            ret.ctrlParameter = goalArea
        else
            ret.ctrlName = CtrlNames.ExploreCharacter
            ret.ctrlParameter = goalArea
        end

        if not GameData.IsPlanetAreaUnlocked(goalArea) then
            ret.code = RetCode.PlanetAreaLocked
        end
    elseif trigger == TriggerType.ActivityExplore or trigger == TriggerType.ActivityExploreCost then
        -- 活动模块比任务模块先开
        moduleName = ModuleNames.Activity
        ret.ctrlName = CtrlNames.Arena
    elseif trigger == TriggerType.Arena then
        moduleName = ModuleNames.Arena
        ret.ctrlName = CtrlNames.Arena
        if not GameData.HasActivatedArena() then
            ret.code = RetCode.ArenaNotOpen
        end
    elseif trigger == TriggerType.CompleteDemand or trigger == TriggerType.DemandReward or trigger == TriggerType.DemandCost then
        moduleName = ModuleNames.Demand
        ret.ctrlName = CtrlNames.Goal
        ret.ctrlParameter = GoalMode.Demand
    -- equipment and skin just go to character list
    elseif itemType == ItemType.Equipment or itemType == ItemType.Skin then
        moduleName = ModuleNames.CharacterList
        ret.ctrlName = CtrlNames.CharacterList
    elseif trigger == TriggerType.Explore or trigger == TriggerType.StartExplore then
        moduleName = ModuleNames.Explore
        if itemType == ItemType.Time then
            if ConfigUtils.IsValidItem(itemId) then
                local itemRealType = ConfigUtils.GetItemTypeFromId(itemId)
                if itemRealType == ItemType.PlanetArea then
                    -- if the area is exploring or no team, can't jump to explore character
                    if not JumpManager.CanJumpToPlanetArea(itemId) then
                        ret.ctrlName = CtrlNames.ExploreGuide
                        ret.ctrlParameter = itemId
                    else
                        ret.ctrlName = CtrlNames.ExploreCharacter
                        ret.ctrlParameter = itemId
                    end

                    if not GameData.IsPlanetAreaUnlocked(itemId) then
                        ret.code = RetCode.PlanetAreaLocked
                    end
                elseif itemRealType == ItemType.Planet then
                    ret.ctrlName = CtrlNames.ExploreGuide
                    ret.ctrlParameter = itemId
                    if not GameData.IsPlanetUnlocked(itemId) then
                        ret.code = RetCode.PlanetLocked
                    end
                else
                    assert(false, "un-handled item type for time: "..tostring(itemId))
                end
            else
                assert(false, "for ItemType.Time, the goal value should always have value")
            end
        elseif itemType == ItemType.Goods then
            if ConfigUtils.IsValidItem(itemId) then
                local areaId = ConfigUtils.GetFirstAvailableSourceAreaOfItem(itemId)
                ret.ctrlName = CtrlNames.ExploreGuide
                ret.ctrlParameter = areaId
                if areaId == nil then
                    ret.code = RetCode.PlanetAreaLocked
                end
            else
                ret.ctrlName = CtrlNames.Planet
                -- any planet is ok
                ret.ctrlParameter = nil
            end
        elseif itemType == ItemType.Enemy then
            if ConfigUtils.IsValidItem(itemId) then
                ret.ctrlName = CtrlNames.ExploreGuide
                local areaId = ConfigUtils.GetFirstAvailableSourceAreaOfEnemy(itemId)
                ret.ctrlParameter = areaId
                if areaId == nil then
                    ret.code = RetCode.PlanetAreaLocked
                end
            else
                -- any planet is ok
                ret.ctrlName = CtrlNames.Planet
                ret.ctrlParameter = nil
            end
        elseif itemType == ItemType.Pet then
            if ConfigUtils.IsValidItem(itemId) then
                ret.ctrlName = CtrlNames.ExploreGuide
                local areaId = ConfigUtils.GetFirstAvailableSourceAreaOfPet(itemId)
                ret.ctrlParameter = areaId
                if areaId == nil then
                    ret.code = RetCode.PlanetAreaLocked
                end
            else
                -- any planet is ok
                ret.ctrlName = CtrlNames.Planet
                ret.ctrlParameter = nil
            end
        else
            ret.ctrlName = CtrlNames.Planet
            -- any planet is ok
            ret.ctrlParameter = nil
        end
    elseif trigger == TriggerType.ExploreCost then
        moduleName = ModuleNames.Explore
        local areaId = goalConditions[1].Area
        if areaId ~= nil then
            -- if the area is exploring or no team, can't jump to explore character
            if not JumpManager.CanJumpToPlanetArea(areaId) then
                ret.ctrlName = CtrlNames.ExploreGuide
                ret.ctrlParameter = areaId
            else
                ret.ctrlName = CtrlNames.ExploreCharacter
                ret.ctrlParameter = areaId
            end
            
            if not GameData.IsPlanetAreaUnlocked(areaId) then
                ret.code = RetCode.PlanetAreaLocked
            end
        else
            ret.ctrlName = CtrlNames.Planet
            -- any planet is ok
            ret.ctrlParameter = nil
        end
    elseif trigger == TriggerType.Challenge then
        moduleName = ModuleNames.Explore
        if ConfigUtils.IsValidItem(itemId) then
            local areaId = ConfigUtils.GetAreaOfChallenge(itemId)
            local activeChallengeId = GameData.GetActiveChallengeOfArea(areaId)
            -- current active challenge
            if itemId == activeChallengeId then
                ret.ctrlName = CtrlNames.ExploreChallenge
                ret.ctrlParameter = itemId
            else
                ret.ctrlName = CtrlNames.ExploreGuide
                ret.ctrlParameter = areaId
            end
            -- planet area unlocked or not
            if not GameData.IsPlanetAreaUnlocked(areaId) then
                ret.code = RetCode.PlanetAreaLocked
            end
        else
            ret.ctrlName = CtrlNames.Planet
            -- any planet is ok
            ret.ctrlParameter = nil
        end
    elseif trigger == TriggerType.CharacterChallenge then
        moduleName = ModuleNames.CharacterList
        ret.ctrlName = CtrlNames.CharacterList
    elseif trigger == TriggerType.ActivityChallenge then
        assert(ConfigUtils.IsValidItem(itemId), "value of activity challenge must be valid")
        moduleName = ModuleNames.Explore
        ret.ctrlName = CtrlNames.ExploreCharacter
        ret.ctrlParameter = itemId
    elseif trigger == TriggerType.Craft or trigger == TriggerType.CraftUse then
        moduleName = ModuleNames.Lab
        ret.ctrlName = CtrlNames.Laboratory
    elseif trigger == TriggerType.SubmitGoods then
        -- module name handled in this function
        ret = this.GetSourceCtrlByItemId(itemId)
    elseif trigger == TriggerType.CollectItem then
        local level = goalConditions[1].Level
        local stage = goalConditions[1].Stage
        if ConfigUtils.IsValidItem(itemId) then
            if itemType == ItemType.Character and (level ~= nil or stage ~= nil) then
                -- upgrade character
                moduleName = ModuleNames.CharacterList
                ret.ctrlName = CtrlNames.CharacterList
            elseif itemType == ItemType.WorkShop then
                moduleName = ModuleNames.WorkShop
                ret.ctrlName = CtrlNames.WorkShop
            elseif itemType == ItemType.Pet then
                moduleName = ModuleNames.Explore
                ret.ctrlName = CtrlNames.ExploreGuide
                local areaId = ConfigUtils.GetFirstAvailableSourceAreaOfPet(itemId)
                ret.ctrlParameter = areaId
                if areaId == nil then
                    ret.code = RetCode.PlanetAreaLocked
                end
            else
                -- module name handled in this function
                ret = this.GetSourceCtrlByItemId(itemId)
            end
        else
            if itemType == ItemType.Character and (level ~= nil or stage ~= nil) then
                moduleName = ModuleNames.CharacterList
                ret.ctrlName = CtrlNames.CharacterList
            elseif itemType == ItemType.WorkShop then
                moduleName = ModuleNames.WorkShop
                ret.ctrlName = CtrlNames.WorkShop
            elseif itemType == ItemType.Pet then
                moduleName = ModuleNames.Explore
                ret.ctrlName = CtrlNames.Planet
                -- any planet is ok
                ret.ctrlParameter = nil
            else
                moduleName = ModuleNames.Summon
                ret.ctrlName = CtrlNames.Summon
            end
        end
    elseif trigger == TriggerType.UnlockSkill or trigger == TriggerType.UsingCostume then
        moduleName = ModuleNames.CharacterList
        ret.ctrlName = CtrlNames.CharacterList
    elseif trigger == TriggerType.WorkShop or trigger == TriggerType.WorkShopRank then
        moduleName = ModuleNames.WorkShop
        ret.ctrlName = CtrlNames.WorkShop
    else
        assert(false, "un-handled trigger type: "..tostring(trigger))
    end

    if ret.code == RetCode.OK and not GameData.IsModuleUnlocked(moduleName) then
        ret.code = RetCode.ModuleLocked
    end

    return ret
end

function UIHelper.GetSourceCtrlByItemId(itemId)
    local sources = ConfigUtils.GetItemSource(itemId)
    local failCode = nil

    for idx = 1, #sources do
        local sourceType = sources[idx].source
        local sourceValue = sources[idx].value

        local ret = this.GetSourceCtrlByItemSource(sourceType, sourceValue)
        if ret.code == RetCode.OK then
            return ret
        else
            failCode = ret.code
        end
    end

    failCode = failCode or RetCode.Unknow
    return {code = failCode}
end
-----------------------------------------------------------------------------------
function UIHelper.GetItemNumShowText(num, maxNum)
    maxNum = maxNum or 1000
    
    if num >= maxNum then
        local showNum = math.floor(num / 1000)
        return tostring(showNum).."K"
    end

    return tostring(num)
end

function UIHelper.GetGoalFinalName(conditionData)
    local name = SAFE_LOC(conditionData.Name)
    return name
end

function UIHelper.GetGoalShowTextWithNum(curNum, needNum)
    if curNum >= needNum then
        return "[2B3F76]"..tostring(curNum).."/"..tostring(needNum).."[-]"
    else
        return "[FF0000]"..tostring(curNum).."[-][2B3F76]/"..tostring(needNum).."[-]"
    end
end

function UIHelper.GetHomeAchievementGoalShowTextWithNum(curNum, needNum)
    if curNum >= needNum then
        return "[FFEDC4]"..tostring(curNum).."/"..tostring(needNum).."[-]"
    else
        return "[FD7216]"..tostring(curNum).."[-][FFEDC4]/"..tostring(needNum).."[-]"
    end
end

function UIHelper.GetGoalShowNum(conditionData, curNum, triggers, isHomeAchievement)
    if isHomeAchievement == nil then
        isHomeAchievement = false
    end
    triggers = triggers or {}
    local itemType = conditionData.Type
    local needNum = conditionData.Num
    if not Helper.TableContains(triggers, TriggerType.Signin) then -- 每周任务的签到特殊处理
        if itemType == ItemType.Time then
            if needNum > 3600 then
                curNum = math.floor(curNum / 3600)
                needNum = math.floor(needNum / 3600)
            else
                curNum = math.floor(curNum / 60)
                needNum = math.floor(needNum / 60)
            end
        end
    end
    if isHomeAchievement then
        return this.GetHomeAchievementGoalShowTextWithNum(curNum, needNum)
    else
        return this.GetGoalShowTextWithNum(curNum, needNum)
    end

end

function UIHelper.GetAchievementGoalNum(goalConditions, goalNumbers)
    local currentNum = 0
    local totalNum = 0
    for idx = 1, #goalConditions do
        totalNum = totalNum + goalConditions[idx].Num
        currentNum = currentNum + goalNumbers[idx]
    end

    local goalItemType = goalConditions[1].Type
    if goalItemType == ItemType.Time then
        if totalNum > 3600 then
            currentNum = math.floor(currentNum / 3600)
            totalNum = math.floor(totalNum / 3600)
        else
            currentNum = math.floor(currentNum / 60)
            totalNum = math.floor(totalNum / 60)
        end
    end

    return currentNum, totalNum
end
-----------------------------------------------------------------------------------
function UIHelper.GetCoupleShowTextOfType(key)
    if key == CoupleNodeKey.Explore then
        return SAFE_LOC("loc_global_item_source_explore")
    elseif key == CoupleNodeKey.Challenge then
        return SAFE_LOC("loc_global_item_source_challenge")
    elseif key == CoupleNodeKey.WorkShop then
        return SAFE_LOC("loc_global_item_source_workshop")
    else
        return ""
    end
end

--设置购买按钮上的资源数量
function UIHelper.SetIconAndNumForBuyButton(ctrl, imgIcon, txtNum, costId, costNum, ownNum)
    this.SetItemIcon(ctrl, imgIcon, costId)
    local type = ConfigUtils.GetItemTypeFromId(costId)
    local isEnough = ownNum >= costNum
    if type == ItemType.Gold or type == ItemType.Diamond then
        if isEnough then
            txtNum.text = costNum
        else
            txtNum.text = string.format("[ff0000]%s[-]", costNum)
        end

    else
        if isEnough then
            txtNum.text = string.format("%d/%d", ownNum, costNum)
        else
            txtNum.text = string.format("[ff0000]%d[-]/%d", ownNum, costNum)
        end
    end

end

function UIHelper.ConstructCharacterSkinItem(ctrl, item, skinId, active)

    local empty = item:Find("Empty").gameObject
    local root = item:Find("Root").gameObject
    local icon = item:Find("Root/Icon"):GetComponent("UISprite")
    local hint = item:Find("Root/Hint").gameObject
    local goal = item:Find("Root/Goal").gameObject
    local bg = item:Find("Root/BG"):GetComponent("UISprite")
    if active then
        empty:SetActive(false)
        root:SetActive(true)
        local unlockChallenge = ConfigUtils.GetSkinUnlockChallenge(skinId)
        local skinUnlocked = GameData.IsSkinUnlocked(skinId)
        this.SetCharacterIconWithSkin(ctrl, icon, skinId)
        if not skinUnlocked then
            icon.color = LOCK_ICON_COLOR
            local showSkinHint = GameData.IsSkinChallengeMatch(skinId)
            hint:SetActive(showSkinHint)
        else
            icon.color = Color.white
            hint:SetActive(false)
        end
        bg.spriteName = this.GetBorderAndBgByItemId(skinId)
        local matchGoal = JumpManager.MatchSkinGoal(skinId)
        goal:SetActive(matchGoal)
    else
        empty:SetActive(true)
        root:SetActive(false)
    end
end

---获取家具类型图标
function UIHelper.GetHomeFurnitureCategoryIcon(iCategory)
    if iCategory == EnumHomeFurnitureCategory.BiGua then
        
    end
    if iCategory == EnumHomeFurnitureCategory.ZhuangShi then

    end
    if iCategory == EnumHomeFurnitureCategory.DianQi then

    end
    if iCategory == EnumHomeFurnitureCategory.BaiJian then

    end
    if iCategory == EnumHomeFurnitureCategory.TanZi then

    end
    if iCategory == EnumHomeFurnitureCategory.QiangZhi then

    end
    if iCategory == EnumHomeFurnitureCategory.DiBan then
    
    end
    return ""
end 