Stack = {}

function Stack:Create()
	-- stack table
	local t = {}
	-- entry table
	t._et = {}

	-- push a value to the stack
	function t:Push(...)
		local args = {...}
		for i, v in ipairs(args) do
			table.insert(self._et, v)
		end
	end
	
	-- pop a value from the stack
	function t:Pop(num)
		local num = num or 1
		local entries = {}

		for i = 1, num do
			if #self._et ~= 0 then
				table.insert(entries, self._et[#self._et])
				table.remove(self._et)
			else
				break
			end
		end
	end

	-- get length
	function t:Length()
		return #self._et
	end

	-- get last one
	function t:Last()
		if #self._et > 0 then
			return self._et[#self._et]
		end

		return nil
	end

	-- list all the values
	function t:List()
		for i, v in pairs(self._et) do
			print(i, v)
		end
	end

	return t
end