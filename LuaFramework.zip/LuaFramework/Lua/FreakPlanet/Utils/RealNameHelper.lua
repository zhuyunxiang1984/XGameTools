PhoneError = {
    None = 0,
    NotNumber = 1,
    InvalidLength = 2,
    UnknowOperator = 3,
}

IdentityError = {
    None = 0,
    InvalidLength = 1,
    InvalidFormat = 2,
    InvalidProvince = 3,
    InvalidBirthDate = 4,
    InvalidSum = 5,
    InvalidGender = 6,
}

-- // wi =2(n-1)(mod 11) 
local wi = { 7, 9, 10, 5, 8, 4, 2, 1, 6, 3, 7, 9, 10, 5, 8, 4, 2, 1 }; 
-- // verify digit 
local vi= { '1', '0', 'X', '9', '8', '7', '6', '5', '4', '3', '2' };

local function MapAlphabeteToNumber_HK(alphabete)
    if (alphabete == "a" or alphabete == "A") then
        return 1
    elseif (alphabete == "b" or alphabete == "B") then
        return 2
    elseif (alphabete == "c" or alphabete == "C") then
        return 3
    elseif (alphabete == "d" or alphabete == "D") then
        return 4
    elseif (alphabete == "e" or alphabete == "E") then
        return 5
    elseif (alphabete == "f" or alphabete == "F") then
        return 6
    elseif (alphabete == "g" or alphabete == "G") then
        return 7
    elseif (alphabete == "h" or alphabete == "H") then
        return 8
    elseif (alphabete == "i" or alphabete == "I") then
        return 9
    elseif (alphabete == "j" or alphabete == "J") then
        return 10
    elseif (alphabete == "k" or alphabete == "K") then
        return 11
    elseif (alphabete == "l" or alphabete == "L") then
        return 12
    elseif (alphabete == "m" or alphabete == "M") then
        return 13
    elseif (alphabete == "n" or alphabete == "N") then
        return 14
    elseif (alphabete == "o" or alphabete == "O") then
        return 15
    elseif (alphabete == "p" or alphabete == "P") then
        return 16
    elseif (alphabete == "q" or alphabete == "Q") then
        return 17
    elseif (alphabete == "r" or alphabete == "R") then
        return 18
    elseif (alphabete == "s" or alphabete == "S") then
        return 19
    elseif (alphabete == "t" or alphabete == "T") then
        return 20
    elseif (alphabete == "u" or alphabete == "U") then
        return 21
    elseif (alphabete == "v" or alphabete == "V") then
        return 22
    elseif (alphabete == "w" or alphabete == "W") then
        return 23
    elseif (alphabete == "x" or alphabete == "X") then
        return 24
    elseif (alphabete == "y" or alphabete == "Y") then
        return 25
    elseif (alphabete == "z" or alphabete == "Z") then
        return 26
    end
end

local function MapAlphabeteToNumber_TW(alphabete)
    if (alphabete == "a" or alphabete == "A") then
        return 10
    elseif (alphabete == "b" or alphabete == "B") then
        return 11
    elseif (alphabete == "c" or alphabete == "C") then
        return 12
    elseif (alphabete == "d" or alphabete == "D") then
        return 13
    elseif (alphabete == "e" or alphabete == "E") then
        return 14
    elseif (alphabete == "f" or alphabete == "F") then
        return 15
    elseif (alphabete == "g" or alphabete == "G") then
        return 16
    elseif (alphabete == "h" or alphabete == "H") then
        return 17
    elseif (alphabete == "i" or alphabete == "I") then
        return 34
    elseif (alphabete == "j" or alphabete == "J") then
        return 18
    elseif (alphabete == "k" or alphabete == "K") then
        return 19
    elseif (alphabete == "l" or alphabete == "L") then
        return 20
    elseif (alphabete == "m" or alphabete == "M") then
        return 21
    elseif (alphabete == "n" or alphabete == "N") then
        return 22
    elseif (alphabete == "o" or alphabete == "O") then
        return 35
    elseif (alphabete == "p" or alphabete == "P") then
        return 23
    elseif (alphabete == "q" or alphabete == "Q") then
        return 24
    elseif (alphabete == "r" or alphabete == "R") then
        return 25
    elseif (alphabete == "s" or alphabete == "S") then
        return 26
    elseif (alphabete == "t" or alphabete == "T") then
        return 27
    elseif (alphabete == "u" or alphabete == "U") then
        return 28
    elseif (alphabete == "v" or alphabete == "V") then
        return 29
    elseif (alphabete == "w" or alphabete == "W") then
        return 30
    elseif (alphabete == "x" or alphabete == "X") then
        return 31
    elseif (alphabete == "y" or alphabete == "Y") then
        return 32
    elseif (alphabete == "z" or alphabete == "Z") then
        return 33
    end
end

function Helper.GetPhoneErrorText(errorState)
    if errorState == PhoneError.NotNumber then
        return SAFE_LOC("手机号码必须全部为数字")
    elseif errorState == PhoneError.InvalidLength then
        return SAFE_LOC("手机号码位数不对")
    elseif errorState == PhoneError.UnknowOperator then
        return SAFE_LOC("请填写正确的手机号码")
    end

    return ""
end

function Helper.GetIdentityErrorText(errorState)
    if errorState == IdentityError.InvalidLength then
        return SAFE_LOC("身份证号长度有误")
    elseif errorState == IdentityError.InvalidFormat or 
        errorState == IdentityError.InvalidProvince or 
        errorState == IdentityError.InvalidBirthDate or 
        errorState == IdentityError.InvalidSum or
        errorState == IdentityError.InvalidGender then
        return SAFE_LOC("身份证号格式有误")
    end

    return ""
end

function Helper.CheckPhone(phone)
    local number = tonumber(phone)
    if number == nil then
        return PhoneError.NotNumber
    end

    if #phone ~= 11 then
        return PhoneError.InvalidLength
    end

    local validOperators =
    {
        "133","153","180","181","189","193", --电信
        "173","177","199","174","191",
        "130","131","132","145", --联通
        "155","156","186","175",
        "176","185","166","171",
        "145","167","168","169",
        "134","135","136","137", --移动
        "138","139","147","150",
        "151","152","157","158",
        "159","182","187","188",
        "178","183","184","198",
        "170","172","195","192",
    }

    local prefix = string.sub(phone, 0, 3)
    if not Helper.TableContains(validOperators, prefix) then
        return PhoneError.UnknowOperator
    end

    return PhoneError.None
end

function Helper.IsValidProvince(province)
    if province >= 11 or province <= 65 then
        return true
    end

    return false
end

function Helper.IsValidBirthDate(d)
    local year = tonumber(d:sub(1,4))
    local month = tonumber(d:sub(5,6))
    local day = tonumber(d:sub(7,8))
    -- check year and month
    if year < 1900 or year > 2100 or month >12 or month < 1 then
        return false
    end
    -- check day
    local monthDays = {31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31}
    local leapYear = (year % 4 == 0 and year % 100 ~= 0) or (year % 400 == 0)
    if leapYear  then
        monthDays[2] = 29
    end

    if day > monthDays[month] or day < 1 then
        return false
    end

    return true
end

function Helper.IsValidSum(id)
    -- http://stackoverflow.com/questions/829063/how-to-iterate-individual-characters-in-lua-string
    local nums = {}
    local tmpId = id:sub(1,17)
    for ch in tmpId:gmatch"." do
        table.insert(nums,tonumber(ch))
    end

    local sum = 0
    for i, k in ipairs(nums) do
        sum = sum + k * wi[i]
    end

    return vi [sum % 11+1] == id:sub(18,18 )
end

function Helper.IsValidSum_HK(id)
    local numbers = {}
    table.insert(numbers, MapAlphabeteToNumber_HK(id:sub(1,1)))
    for i = 2, 7 do
        table.insert(numbers, tonumber(id:sub(i, i)))
    end

    local sum = 0
    for i = 1,7 do
        sum = sum + numbers[i] * (9 - i)
    end

    local mod = math.fmod(sum, 11)
    local finalCheck = ""
    if mod == 0 then
        finalCheck = "0"
    elseif mod == 1 then
        finalCheck = "A"
    else
        finalCheck = tostring(11 - mod)
    end
    
    return finalCheck == id:sub(8, 8)
end

function Helper.IsValidSum_TW(id)
    local numbers = {}
    for i = 2, 9 do
        table.insert(numbers, tonumber(id:sub(i,i)))
    end

    local X = tostring(MapAlphabeteToNumber_TW(id:sub(1, 1)))
    local Y = tonumber(X:sub(1, 1)) + tonumber(X:sub(2, 2) * 9)
    for i = 1, 8 do
        Y = Y + numbers[i] * (9 - i)
    end

    local finalCheck = tostring(10 - math.fmod(Y, 10))
    return finalCheck == id:sub(10, 10)
end

function Helper.CheckIdentity(id)
    local len = string.len(id)
    
    if len == 18 then
        -- 大陆身份证
        return Helper.CheckIdentity_MainLand(id)
    elseif len == 8 then
        -- 香港身份证
        return Helper.CheckIdentity_HK(id)
    elseif len == 10 then
        -- 台湾身份证
        return Helper.CheckIdentity_TW(id)
    end

    return IdentityError.InvalidLength
end

function Helper.IsMainlandIdentity(id)
    return string.len(id) == 18
end

function Helper.CheckIdentity_MainLand(id)
    local tmpId = id:match("%d+X?") 
    if tmpId ~= id then
        return IdentityError.InvalidFormat
    end
    -- province
    -- 第1-2位为省级行政区划代码，[11, 65] (第一位华北区1，东北区2，华东区3，中南区4，西南区5，西北区6)
    local province = tonumber(id:sub(1, 2))
    if not Helper.IsValidProvince(province) then
        return IdentityError.InvalidProvince
    end
    -- birth date
    local birth = id:sub(7,14)
    if not Helper.IsValidBirthDate(birth) then
        return IdentityError.InvalidBirthDate
    end
    -- sum
    if not Helper.IsValidSum(id) then
        return IdentityError.InvalidSum
    end

    return IdentityError.None
end

function Helper.CheckIdentity_HK(id)
    local tmpId = id:match("%a%d+%a?") 
    if tmpId ~= id then
        return IdentityError.InvalidFormat
    end

    if not Helper.IsValidSum_HK(id) then
        return IdentityError.InvalidSum
    end

    return IdentityError.None
end

function Helper.CheckIdentity_TW(id)
    local tmpId = id:match("%a%d+") 
    if tmpId ~= id then
        return IdentityError.InvalidFormat
    end

    local gender = id:sub(2, 2)
    if gender ~= "1" and gender ~= "2" then
        return IdentityError.InvalidGender
    end

    if not Helper.IsValidSum_TW(id) then
        return IdentityError.InvalidSum
    end

    return IdentityError.None
end

--通过身份证获取年龄
function Helper.CalcAge(idcard)
    -- not mainland 不是大陆身份证,则返回18岁,属于成人(港澳台)
    if not Helper.IsMainlandIdentity(idcard) then
        return RealNameData.UnderAge1
    end

    local birthDayStr = idcard:sub(7,14)
    local year = tonumber(birthDayStr:sub(1,4))
    local month = tonumber(birthDayStr:sub(5,6))
    local day = tonumber(birthDayStr:sub(7,8))
    
    local todayStr = os.date("%Y%m%d", GameData.GetServerTime())

    local year_today = tonumber(todayStr:sub(1,4))
    local month_today = tonumber(todayStr:sub(5,6))
    local day_today = tonumber(todayStr:sub(7,8))
    
    local age = year_today - year
    if month_today < month or (month_today == month and day_today < day) then
        age = age - 1
    end
    
    return age
end

-- 过滤特殊字符，保留UTF-8的中文、英文、数字
function Helper.FilterSpecialChars(s)
    local ss = {}
    local k = 1
    while true do
        if k > #s then break end
        local c = string.byte(s,k)
        if not c then break end
        if c<192 then
            if (c>=48 and c<=57) or (c>= 65 and c<=90) or (c>=97 and c<=122) then
                table.insert(ss, string.char(c))
            end
            k = k + 1
        elseif c<224 then
            k = k + 2
        elseif c<240 then
            if c>=228 and c<=233 then
                local c1 = string.byte(s,k+1)
                local c2 = string.byte(s,k+2)
                if c1 and c2 then
                    local a1,a2,a3,a4 = 128,191,128,191
                    if c == 228 then a1 = 184
                    elseif c == 233 then a2,a4 = 190,c1 ~= 190 and 191 or 165
                    end
                    if c1>=a1 and c1<=a2 and c2>=a3 and c2<=a4 then
                        table.insert(ss, string.char(c,c1,c2))
                    end
                end
            end
            k = k + 3
        elseif c<248 then
            k = k + 4
        elseif c<252 then
            k = k + 5
        elseif c<254 then
            k = k + 6
        end
    end
    return table.concat(ss)
end

-- 保留UTF-8的中文
function Helper.FilterSpecChinese(s)
    local ss = {}
    local k = 1
    while true do
        if (k > #s) then break end
        local c = string.byte(s, k)
        if not c then break end
        if c>=228 and c<=233 then
            local c1 = string.byte(s,k+1)
            local c2 = string.byte(s,k+2)
            if c1 and c2 then
                local a1,a2,a3,a4 = 128,191,128,191
                if c == 228 then a1 = 184
                elseif c == 233 then a2,a4 = 190,c1 ~= 190 and 191 or 165
                end
                if c1>=a1 and c1<=a2 and c2>=a3 and c2<=a4 then
                    table.insert(ss, string.char(c,c1,c2))
                end
            end
        end
        k = k + 3
    end
    
    return table.concat(ss)
end