-- serialize data to string
function Serialize(obj)
	local str = ""
	local t = type(obj)
	if t == "number" then
		str = str..obj
	elseif t == "boolean" then
		str = str..tostring(obj)
	elseif t == "string" then
		str = str..string.format("%q", obj)
	elseif t == "table" then
		str = str.."{\n"
		for k, v in pairs(obj) do
			str = str.."["..Serialize(k).."]="..Serialize(v)..",\n"
		end

		local metatable = getmetatable(obj)
		if metatable ~= nil and type(metatable.__index) == "table" then
			for k, v in pairs(metatable.__index) do
				str = str.."["..Serialize(k).."]="..Serialize(v)..",\n" 
			end
		end

		str = str.."}"
	elseif t == "nil" then
		return nil
	else
		error("can't serialize a "..t.." type.")
	end

	return str;
end

-- de-serialize string to a object
function Deserialize(data)
	local t = type(data)
	-- empty
	if t == "nil" or data == "" then
		return nil
	elseif t == "number" or t == "string" or t == "boolean" then
		data = tostring(data)
	else
		error("can't de-serialize a "..t.." type.")
	end

	data = "return "..data
	local func = loadstring(data)
	if func == nil then
		return nil
	end

	return func()
end