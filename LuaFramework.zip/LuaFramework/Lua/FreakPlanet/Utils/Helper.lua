Helper = {}

local utf8 = require("FreakPlanet/Utils/Utf8")
require("FreakPlanet/Utils/WordFilter")

-- new an object and initialize the transform
function Helper.NewObject(prefab, parentTransform, scale)
    scale = scale or 1
	local obj = GameObject.Instantiate(prefab)
	obj.transform.parent = parentTransform
	obj.transform.localScale = Vector3.New(scale, scale, 1)
	obj.transform.localPosition = Vector3.zero
    obj.transform.localRotation = Vector3.zero

	return obj
end

-- new an object and keep the local position, rotation and scale
function Helper.NewObjectKeepTransform(prefab, parentTransform)
    local obj = GameObject.Instantiate(prefab, parentTransform);

    return obj
end

-- split string to string array
function Helper.StringSplit(inputstr, sep)
    sep = sep or "_"

    local t={}
    local i=1
    for str in string.gmatch(inputstr, "([^"..sep.."]+)") do
        t[i] = str
        i = i + 1
    end

    return t
end

function Helper.StringFindAndReplace(str, toReplace, replace)
    if string.find(str, toReplace) ~= nil then
        str = string.gsub(str, toReplace, replace)
    end

    return str
end

function Helper.PointCloseEnough(p0, p1, sqrTolerance)
    sqrTolerance = sqrTolerance or 0.01
    return (p0.x - p1.x) * (p0.x - p1.x) + (p0.y - p1.y) * (p0.y - p1.y) <= sqrTolerance
end

function Helper.StartWith(str, subStr)
    return string.sub(str, 1, string.len(subStr)) == subStr
end

function Helper.EndWith(str, subStr)
    return subStr == "" or string.sub(str, -string.len(subStr)) == subStr
end

function Helper.LenOfUtf8(str)
    if str == nil then
        return 0
    end

    return utf8.len(str)
end

function Helper.ContainsBothLetterAndNumber(str)
    local alphabetFit = false
    local numberFit = false
    local bothFit = false
    local sub, count = string.gsub(str, "[%a]", "_")
    if count > 0 then
        alphabetFit = true
    end

    sub, count = string.gsub(str, "[%d]", "_")
    if count > 0 then
        numberFit = true
    end

    sub, count = string.gsub(str, "[%w]", "_")
    if count == string.len(str) then
        bothFit = true
    end

    if not alphabetFit or not numberFit or not bothFit then
        return false
    end

    return true
end

-- reverse a table
function Helper.ReverseTable(tbl)
	local len = #tbl
	local start = 1
	local last = len
	while start < last do
		local tmp = tbl[start]
		tbl[start] = tbl[last]
		tbl[last] = tmp
		start = start + 1
		last = last - 1
	end
end

-- is unity animation end
function Helper.IsUnityAnimationEnd(animator, layer)
    layer = layer or 0
    local state = animator:GetCurrentAnimatorStateInfo(layer)
    return state.normalizedTime >= 0.99
end

function Helper.IsUnityAnimationLoopEnd(animator, layer)
    layer = layer or 0
    local state = animator:GetCurrentAnimatorStateInfo(layer)
    local t = state.normalizedTime
    local int_t = math.floor(t)
    return (math.abs(t - int_t) <= 0.02)
end

function Helper.IsUnityAnimationEndWithName(animator, name, layer)
    layer = layer or 0
    local state = animator:GetCurrentAnimatorStateInfo(layer)
    return state:IsName(name) and state.normalizedTime >= 0.95
end

function Helper.GetAnimationNormalizedTime(animator, layer)
    local ret = 0
    layer = layer or 0
    local state = animator:GetCurrentAnimatorStateInfo(layer)
    if state ~= nil then
        ret = state.normalizedTime
    end

    return ret
end

function Helper.IsPlayingAnimation(animator, animationName, layer)
    layer = layer or 0
    local state = animator:GetCurrentAnimatorStateInfo(layer)
    if state ~= nil then
        return state:IsName(animationName)
    end

    return false
end

-- skeleton animation is end or not
function Helper.IsAnimationEnd(skeletonAnimation, animationName)
    if skeletonAnimation == nil then
        log("skeletonAnimation")
        return false
    end

    if skeletonAnimation.state == nil then
        log("skeletonAnimation.state")
        return false
    end

    if skeletonAnimation.state:GetCurrent(0)== nil then
        log("skeletonAnimation.state:GetCurrent(0)")
        return false
    end

    if animationName then
        if skeletonAnimation.state:GetCurrent(0).Animation.Name ~= animationName then
            return true
        end
    end

    return skeletonAnimation.state:GetCurrent(0).IsComplete
end

-- 检测动画是否存在
function Helper.HasAnimation(skeletonAnimation, animationName)
    return skeletonAnimation.state:HasAnimation(animationName)
end

-- play animation
function Helper.PlayAnimation(skeletonAnimation, animationName, loop, timeScale)
    if skeletonAnimation == nil or skeletonAnimation.state == nil then
        return
    end

    timeScale = timeScale or 1
	skeletonAnimation.state:SetAnimation(0, animationName, loop)
    skeletonAnimation.state.TimeScale = timeScale
end

-- add animation
function Helper.AddAnimation(skeletonAnimation, animationName, loop)
    if skeletonAnimation == nil or skeletonAnimation.state == nil then
        return
    end

    skeletonAnimation.state:AddAnimation(0, animationName, loop, 0)
end

function Helper.SafePlayAnimation(skeletonAnimation, animationName, loop, timeScale)
    if skeletonAnimation == nil then
        return
    end

    timeScale = timeScale or 1
    skeletonAnimation.loop = loop
    skeletonAnimation.AnimationName = animationName
    skeletonAnimation.timeScale = timeScale
end

-- set skin
function Helper.SetSkin(skeletonAnimation, skinName)
	if skinName == nil or skeletonAnimation == nil or skeletonAnimation.Skeleton == nil then
		return
	end

	skeletonAnimation.Skeleton:SetSkin(skinName)
    skeletonAnimation.Skeleton:SetSlotsToSetupPose()
end

-- convert seconds to hours
function Helper.SecondsToHours(seconds)
	local hours = seconds / (60 * 60)
	return math.floor(hours)
end

-- convert an object to formated string
function Helper.Format(obj)
    local t = type(obj)
    if t == "number" then
        return tostring(obj)
    elseif t == "string" then
        return obj
    elseif t == "boolean" then
        return tostring(obj)
    elseif t == "table" then
        local str = "{"
        local hasItem = false
        for k, v in pairs(obj) do
        	hasItem = true
            local keyType = type(k)
            if keyType == "number" or keyType == "string" then
                -- map
                str = str .. k .. " = " .. Helper.Format(v) .. ", "
            else
                error("unhandled key type "..keyType)
            end
        end
        if hasItem then
        	str = string.sub(str, 1, -3)
    	end
        str = str .. "}"
        return str
    elseif t == "nil" then
        return t
    else
        error("unhandled type " .. t)
    end
end

-- set random seed
function Helper.RandSeed(seed)
    local finalSeed = seed or os.time()
    math.randomseed(finalSeed)
end

-- generate a random value
function Helper.RandInt(...)
    local arg = {...}
    if #arg == 0 then
        return math.random()
    elseif #arg == 1 then
        return math.random(arg[1])
    else
        if arg[1] == arg[2] then
            return arg[1]
        end
        return math.random(arg[1], arg[2])
    end
end

-- generate a random float value
function Helper.RandFloat(...)
    local randValue = math.random()

    local arg = {...}
    if #arg == 0 then
        return randValue
    elseif #arg == 1 then
        local n = 0
        local m = arg[1]

        return (m - n) * randValue + n
    else
        local n = arg[1]
        local m = arg[2]

        return (m - n) * randValue + n
    end
end

-- generate a random float value
function Helper.RandBool()
    local var = Helper.RandInt(1, 2)
    return var == 1
end

-- get the time info
function Helper.TimeInfo(timeInSeconds)
    local days = math.floor(timeInSeconds / 86400)
    local hours = math.floor((timeInSeconds - 86400 * days) / 3600)
    local minutes = math.floor((timeInSeconds - days * 86400 - hours * 3600) / 60)
    local seconds = math.floor(timeInSeconds - days * 86400  - hours * 3600 - minutes * 60)
    return days, hours, minutes, seconds
end

function Helper.GetShortTimeString(timeInSeconds, showDay)
    timeInSeconds = timeInSeconds or 0
    showDay = showDay or false

    local days, hours, minutes, seconds = Helper.TimeInfo(timeInSeconds)

    if days > 0 and showDay then
        return tostring(days)..SAFE_LOC("loc_global_time_day")
    end

    hours = hours + days * 24
    if hours > 0 then
        return tostring(hours)..SAFE_LOC("loc_global_time_hour")
    end

    if minutes > 0 then
        return tostring(minutes)..SAFE_LOC("loc_global_time_minite")
    end

    return tostring(seconds)..SAFE_LOC("loc_global_time_second")
end

function Helper.GetLongTimeString(timeInSeconds)
    timeInSeconds = timeInSeconds or 0

    local days, hours, minutes, seconds = Helper.TimeInfo(timeInSeconds)
    local str = ""
    if days > 0 then
        str = str..string.format("%02d", days)..SAFE_LOC("loc_global_time_day")
        str = str..string.format("%02d", hours)..SAFE_LOC("loc_global_time_hour")
    elseif hours > 0 then
        str = str..string.format("%02d", hours)..SAFE_LOC("loc_global_time_hour")
        str = str..string.format("%02d", minutes)..SAFE_LOC("loc_global_time_minite")
    else
        str = str..string.format("%02d", minutes)..SAFE_LOC("loc_global_time_minite")
        str = str..string.format("%02d", seconds)..SAFE_LOC("loc_global_time_second")
    end

    return str
end

-- get time string
function Helper.FormatTime(timeInSeconds)
    local days, hours, minutes, seconds = Helper.TimeInfo(timeInSeconds)
    local str = string.format("%02d:%02d:%02d", hours + days * 24, minutes, seconds)
    return str
end

--时间戳转换成日期
function Helper.TimestampToDate(timestamp)
    return os.date("%Y-%m-%d %H:%M:%S", timestamp)
end

function Helper.GetDayOfTime(time)
    return math.floor(time / (24 * 3600))
end


---时间戳转换年月日时分秒
---@param timestamp 时间戳
function Helper.FormatTimeStamp2Date(timestamp)
    local _timeTable = {}
    if timestamp and timestamp >0 then
        _timeTable.year = tonumber(os.date("%Y", timestamp))
        _timeTable.month = tonumber(os.date("%m", timestamp))
        _timeTable.week = tonumber(os.date("%w", timestamp))  -- [ 0 -> 6 = Sunday -> Saturday ]
        _timeTable.day = tonumber(os.date("%d", timestamp))
        _timeTable.hour = tonumber(os.date("%H", timestamp))
        _timeTable.minute = tonumber(os.date("%M", timestamp))
        _timeTable.second = tonumber(os.date("%S", timestamp))
        return _timeTable
    end
end

function Helper.GetRemainTodaySeconds()
    local curTime = GameData.GetServerTime()
    local timeTable = Helper.FormatTimeStamp2Date(curTime)
    local todayTime = os.time({year = timeTable.year, month = timeTable.month, day = timeTable.day, hour = 23, min = 59, sec = 59})
    return todayTime - curTime + 1
end

function Helper.GetHourFromTimeStamp(timestamp)
    return tonumber(os.date("%H", timestamp))
end

function Helper.GetDayAndMonthFromTimeStamp(timestamp)
    return string.format("%s.%s", os.date("%m", timestamp), os.date("%d", timestamp))
end
-- get table length
function Helper.TableLength(tbl)
    local count = 0
    for k, v in pairs(tbl) do
        count = count + 1
    end

    return count
end

-- is table empty or not
function Helper.IsEmpty(tbl)
    if tbl == nil then
        return true
    end

    for k, v in pairs(tbl) do
       return false
    end

    return true
end

-- get n-th element in table
function Helper.GetTableElement(tbl, idx)
    local count = 0
    for k, v in pairs(tbl) do
        count = count + 1
        if count == idx then
            return v
        end
    end

    return nil
end

-- list contains element or not
function Helper.TableContains(tbl, element)
    for idx = 1, #tbl do
        if tbl[idx] == element then
            return true
        end
    end

    return false
end

-- copy table
function Helper.CopyTable(dst, src)
    for idx = 1, #src do
        table.insert(dst, src[idx])
    end
end

-- clone map
function Helper.CloneMap(map)
    local ret = {}

    for k, v in pairs(map) do
        ret[k] = v
    end

    return ret
end

-- get element index in a list
function Helper.IndexOfArray(tbl, element)
    for idx = 1, #tbl do
        if tbl[idx] == element then
            return idx
        end
    end

    return nil
end

function Helper.IsSubsetTable(tbl, sub)
    if tbl == nil or #tbl == 0 or sub == nil or #sub == 0 then
        return false
    end

    if #sub > #tbl then
        return false
    end

    for idx = 1, #sub do
        local e = sub[idx]
        if not Helper.TableContains(tbl, e) then
            return false
        end
    end

    return true
end

function Helper.IsSameTable(lhs, rhs)
    assert(lhs ~= nil, "left table should not be nil")
    assert(rhs ~= nil, "right table should not be nil")

    if #lhs ~= #rhs then
        return false
    end

    for idx = 1, #lhs do
        if not Helper.TableContains(rhs, lhs[idx]) then
            return false
        end
    end

    return true
end

function Helper.RandomSelectIndices(tableLen, num)
    num = math.min(num, tableLen)
    local indices = {}
    for idx = 1, tableLen do
        table.insert(indices, idx)
    end

    local result = {}

    for idx = 1, num do
        local selectIdx = Helper.RandInt(1, #indices)
        table.insert(result, indices[selectIdx])
        table.remove(indices, selectIdx)
    end

    return result
end

function Helper.RandomIndexExcept(tableLen, exclude)
    local indices = {}
    for idx = 1, tableLen do
        if idx ~= exclude then
            table.insert(indices, idx)
        end
    end

    local selectIdx = Helper.RandInt(1, #indices)
    return indices[selectIdx]
end

function Helper.Round(number, n)
    local val = math.pow(10, n)
    local up = math.floor(number * val + 0.1)
    return up / val
end

function Helper.RoundAndCeil(number, n)
    n = n or 2
    local roundNum = Helper.Round(number, n)
    return math.ceil(roundNum)
end

function Helper.IsEvenNumber(num)
    local val = math.floor(num / 2)
    return (num - val * 2 == 0)
end

function Helper.CheckDirection(transform, dirX)
    local scale = transform.localScale
    if dirX * scale.x < 0 then
        scale.x = scale.x * -1
        transform.localScale = scale
    end
end

function Helper.IsEmptyOrNull(str)
    if str == nil then
        return true
    end

    if string.len(str) == 0 then
        return true
    end

    return false
end

function Helper.DecodeURI(str)
    local s = string.gsub(str, '%%(%x%x)', function(h) return string.char(tonumber(h, 16)) end)
    return s
end

function Helper.EncodeURI(str)
    local s = string.gsub(str, "([^%w%.%- ])", function(c) return string.format("%%%02X", string.byte(c)) end)
    return string.gsub(s, " ", "+")
end

function Helper.Lerp(a, b, f)
    return a * (1 - f) + b * f
end

function Helper.CheckMd5(str)
    if Helper.IsEmptyOrNull(str) or string.len(str) == 32 then
        return str
    end

    local md5 = require "FreakPlanet/Utils/md5"
    return md5.calc(str)
end

function Helper.GetSign(val)
    if val == 0 then
        return 0
    end

    if val > 0 then
        return 1
    end

    return -1
end

--获取后台配置的ExtraData
function Helper.GetFromExtraData(key)
    local json = require "cjson"
    local extraInfo = json.decode(Global.ExtraData)
    return extraInfo[key]
end

require "FreakPlanet/Utils/RealNameHelper"
require "FreakPlanet/Utils/WJWHelper"
require "FreakPlanet/Utils/WordFilterHelper"