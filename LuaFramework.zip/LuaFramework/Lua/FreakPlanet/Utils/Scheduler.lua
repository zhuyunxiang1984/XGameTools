local class = require "FreakPlanet/Utils/middleclass"

Action = class("Action")

function Action:initialize()

end

function Action:Start()

end

function Action:Tick(deltaTime)
    -- finished
    return true
end

function Action:End()

end

TimeAction = class("TimeAction", Action)

function TimeAction:initialize(duration)
    self._duration = duration
    self._currentTime = 0
end

function TimeAction:Start()
    self._currentTime = 0
end

function TimeAction:Tick(deltaTime)
    self._currentTime = self._currentTime + deltaTime
    return self._currentTime >= self._duration
end

FunctionAction = class("FunctionAction", Action)

function FunctionAction:initialize(func, param, receiver)
	self._func = func
	self._param = param
    self._receiver = receiver
end

function FunctionAction:Start()
    if self._receiver == nil then
		if self._param == nil then
			self._func()
		else
			self._func(self._param)
		end
    else
		if self._param == nil then
			self._func(self._receiver)
		else
			self._func(self._receiver, self._param)
		end
    end
end

ActionSequence = class("ActionSequence", Action)

function ActionSequence:initialize(...)
    self._actions = {}
    local actions = {...}
    for idx, action in pairs(actions) do
        self._actions[idx] = action
    end
    self._currentActionIdx = nil
end

function ActionSequence:AddAction(action)
    table.insert(self._actions, action)
end

function ActionSequence:Start()
    self._currentActionIdx = nil
    if #self._actions > 0 then
        self._currentActionIdx = 1
    end
end

function ActionSequence:Tick(deltaTime)
    if self._currentActionIdx == nil or self._currentActionIdx > #self._actions then
        self._currentActionIdx = nil
        return true
    end

    local curAction = self._actions[self._currentActionIdx]
    local finished = curAction:Tick(deltaTime)
    if finished then
        curAction:End()
        if self._currentActionIdx == #self._actions then
            self._currentActionIdx = nil
            return true
        else
            self._currentActionIdx = self._currentActionIdx + 1
            curAction = self._actions[self._currentActionIdx]
            curAction:Start()
            return false
        end
    else
        return false
    end
end

function ActionSequence:End()

end

ActionScheduler = class("ActionScheduler")

function ActionScheduler:initialize()
    self._actionSequences = {}
    self._lastHandle = 0
end

function ActionScheduler:DoActionAfterTime(time, func, receiver, param)
    local action1 = TimeAction:new(time)
    local action2 = FunctionAction:new(func, param, receiver)
    local seq = ActionSequence:new(action1, action2)
    return GlobalScheduler:Schedule(seq)
end

function ActionScheduler:Schedule(seq)
    self._lastHandle = self._lastHandle + 1
    self._actionSequences[self._lastHandle] = seq
    seq:Start()
    return self._lastHandle
end

function ActionScheduler:Cancel(seqHandle)
    local seq = self._actionSequences[seqHandle]
    if seq ~= nil then
        seq:End()
        self._actionSequences[seqHandle] = nil
    end
end

local _RemoveList = {}

function ActionScheduler:Tick(deltaTime)
    for h, seq in pairs(self._actionSequences) do
        local finished = seq:Tick(deltaTime)
        if finished then
            seq:End()
            table.insert(_RemoveList, h)
        end
    end

    if #_RemoveList > 1 then
        for idx, h in ipairs(_RemoveList) do
            self._actionSequences[h] = nil
        end
        _RemoveList = {}
    end

end