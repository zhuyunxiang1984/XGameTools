﻿using System;
using UnityEditor;
using UnityEngine;
using System.IO;
using System.Text;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using LuaFramework;
using System.Security.Cryptography;
using XGameKit.XAssetManager;
using Object = UnityEngine.Object;

public class Packager
{
    static string launchFileName = "gamelaunchfiles.dat";
    static string gameFileName = "gamefiles.dat";
    static string descriptionName = "aaxdescription.dat";

    //----------------------------------------------------

    [MenuItem("Build Resource/打 包 资 源 窗 口", false, 99)]
    public static void OpenPackagerWindow()
    {
        EditorPackagerWindow.OpenWindow();
    }

    //[MenuItem("Build Resource/Build iPhone Resource", false, 100)]
    public static void BuildiPhoneResource()
    {
        GenerateSvnVersion();
        GenerateBundle();
        BuildAssetResource(BuildTarget.iOS, false);
    }

    //[MenuItem("Build Resource/Build Android Resource", false, 101)]
    public static void BuildAndroidResource()
    {
        GenerateSvnVersion();
        GenerateBundle();
        BuildAssetResource(BuildTarget.Android, false);
    }


    //[MenuItem("Build Resource/Build iPhone Resource（压缩）", false, 102)]
    public static void BuildiPhoneCompressResource()
    {
        GenerateSvnVersion();
        GenerateBundle();
        BuildAssetResource(BuildTarget.iOS, true);
    }

    //[MenuItem("Build Resource/Build Android Resource（压缩）", false, 103)]
    public static void BuildAndroidCompressResource()
    {
        GenerateSvnVersion();
        GenerateBundle();
        BuildAssetResource(BuildTarget.Android, true);
    }

    public static ulong GetSvnVersion()
    {
        var output = string.Empty;
#if UNITY_EDITOR_OSX
        var shellFile = Path.Combine(Application.dataPath, "../../AutoBuild/SvnVersion.sh");
        output = EditorToolsUtil.RunBatInBackground("/bin/sh", shellFile);
        //XDebug.Log("GGYY", $"{output} svn version is {output}");
#endif
#if UNITY_EDITOR_WIN
        var batFile = Path.Combine(Application.dataPath, "../../AutoBuild/SvnVersion.bat");
        output = EditorToolsUtil.RunBatInBackground(batFile);
        //XDebug.Log("GGYY", $"{output} svn version is {output}");
#endif
        if (string.IsNullOrEmpty(output))
            return 0;
        return ulong.Parse(output);
    }
    public static void GenerateSvnVersion()
    {
        string versionFile = Path.Combine(Application.dataPath, "LuaFramework/Lua/FreakPlanet/Version.lua");
        if (!File.Exists(versionFile))
        {
            FileStream fs = File.Create(versionFile);
            fs.Close();
        }

        var svnVersion = GetSvnVersion();
        XDebug.Log("GGYY", $"project svn version is: {svnVersion}");
        if (svnVersion > 0)
        {
            File.WriteAllText(versionFile, $"SvnVersion = {svnVersion}");
        }
    }

    /// <summary>
    /// 生成绑定素材
    /// </summary>
    public static void BuildAssetResource(BuildTarget target, bool compress)
    {
        var watcher = TimeWatcher.Start();
        
        string streamingAssetsPath = $"{Application.dataPath}/StreamingAssets";
        if (Directory.Exists(streamingAssetsPath))
        {
            Directory.Delete(streamingAssetsPath, true);
        }
        string output = $"{Application.dataPath}/../BuildBundles/{target}";
        if (!Directory.Exists(output))
        {
            Directory.CreateDirectory(output);
        }
        //打包资源
        BuildAssetBundles(output, target, compress);
        
        //将Bundle资源拷入StreamingAssets
        var resPath = $"{streamingAssetsPath}/res";
        if (!Directory.Exists(resPath))
        {
            Directory.CreateDirectory(resPath);
        }
        CopyAssetBundles(output, resPath);
        
        //
        var luaPath = $"{streamingAssetsPath}/lua";
        if (!Directory.Exists(luaPath))
        {
            Directory.CreateDirectory(luaPath);
        }
        //处理lua文件
        HandleLuaFile(luaPath, (datas) =>
        {
            if (target == BuildTarget.Android)
             {
                 for (int i = 0; i < datas.Length; ++i)
                 {
                     datas[i] = (byte) ~datas[i];
                 }
             }
            return datas;
        });
        
        //生成清单文件
        GenerateFileList();
        
        //编辑器更新数据
        AssetDatabase.Refresh();

        watcher.Stop();
#if UNITY_EDITOR_WIN
        EditorUtility.DisplayDialog("妙奇星球", $"资源打包完成 耗时{watcher.TimeSpan.Minutes}分{watcher.TimeSpan.Seconds}秒", "确定");
#endif
    }
    
    //打包资源
    static void BuildAssetBundles(string output, BuildTarget target, bool compress)
    {
        BuildAssetBundleOptions options = BuildAssetBundleOptions.DeterministicAssetBundle;

        if (compress)
        {
            //LZ4压缩
            options |= BuildAssetBundleOptions.ChunkBasedCompression; 
        }
        else
        {
            //默认压缩
            options |= BuildAssetBundleOptions.UncompressedAssetBundle;
        }
        var watcher = TimeWatcher.Start();
        
        //unity打包
        var manifest = BuildPipeline.BuildAssetBundles(output, options, target);
        
        //生成依赖数据
        var bundleConfig = XBundleConfig.LoadBundleConfig();
        
        XAssetDescription description = new XAssetDescription();
        var bundleNames = manifest.GetAllAssetBundles();
        foreach (var bundleName in bundleNames)
        {
            var simpleBundleName = GetSimpleBundleName(bundleName);
            simpleBundleName = simpleBundleName.ToLower();
            //记录包依赖关系
            var dependencies = manifest.GetDirectDependencies(bundleName);
            if (dependencies != null && dependencies.Length > 0)
            {
                var tempList = new List<string>();
                foreach (var dependency in dependencies)
                {
                    tempList.Add(GetSimpleBundleName(dependency).ToLower());
                }
                description.AddDependencies(simpleBundleName, tempList);
            } 
            //记录资源名与包名的关系
            var strategy = bundleConfig.GetBundleStrategy(simpleBundleName);
            if (strategy.addressable)
            {
                var assetPaths = AssetDatabase.GetAssetPathsFromAssetBundle(bundleName);
                if (assetPaths != null && assetPaths.Length > 0)
                {
                    foreach (var assetPath in assetPaths)
                    {
                        var assetName = Path.GetFileNameWithoutExtension(assetPath);
                        if (!string.IsNullOrEmpty(strategy.prefix))
                        {
                            assetName = $"{strategy.prefix}{assetName}";
                        }
                        assetName = assetName.ToLower();
                        description.AddAsset(assetName, simpleBundleName);
                    }
                }
                //记录资源名前缀
                if (!string.IsNullOrEmpty(strategy.prefix))
                {
                    description.AddAssetPrefix(strategy.prefix);
                }
            }
        }
        
        var descriptionData = Convert.ToBase64String(description.Serialize());
        File.WriteAllText($"{output}/{descriptionName}", descriptionData);
        
        watcher.Stop();
        XDebug.Log($"资源编译完成! 耗时{watcher.TimeSpan.Minutes}分{watcher.TimeSpan.Seconds}秒");
    }
    
    //拷贝资源
    static void CopyAssetBundles(string srcPath, string dstPath)
    {
        //依赖文件
        FileUtil.CopyFileOrDirectory($"{srcPath}/{descriptionName}", $"{dstPath}/{descriptionName}");
        
        //资源文件
        var bundleFiles = Directory.GetFiles(srcPath, "*.unity3d", SearchOption.AllDirectories);
        for (int i = 0; i < bundleFiles.Length; ++i)
        {
            var bundleFile = bundleFiles[i];
            var bundleFileName = Path.GetFileName(bundleFile);
            if (EditorUtility.DisplayCancelableProgressBar("正在复制...", bundleFileName, (i + 1.0f) / bundleFiles.Length))
                break;
            FileUtil.CopyFileOrDirectory(bundleFile, $"{dstPath}/{bundleFileName}");
        }
        EditorUtility.ClearProgressBar();
    }
    
    /// <summary>
    /// 处理Lua文件
    /// </summary>
    static void HandleLuaFile(string output, Func<byte[], byte[]> HandleBytes = null)
    {
        string luaPlainTextPath = $"{Application.dataPath}/~lua_plaintext~";

        //清理原内容
        if (!Directory.Exists(output))
        {
            Directory.CreateDirectory(output); 
        }

        if (Directory.Exists(luaPlainTextPath))
        {
            Directory.Delete(luaPlainTextPath, true);
        }
        Directory.CreateDirectory(luaPlainTextPath);

        string[] luaPaths = 
        {
            $"{Application.dataPath}/LuaFramework/lua/", 
            $"{Application.dataPath}/LuaFramework/Tolua/lua/",
        };
        var totalLuaFiles = new List<(string, string)>();
        var tempList = new List<string>();
        var tempFolder = string.Empty;
        foreach (var luaPath in luaPaths)
        {
            tempList.Clear();
            XPackagerUtil.CollectFiles(ref tempList, luaPath, "*.lua");
            for (int i = 0; i < tempList.Count; ++i)
            {
                var srcPath = tempList[i];
                var newPath = srcPath.Replace(luaPath, string.Empty);
                totalLuaFiles.Add((srcPath, newPath));
            }
        }
        for (int i = 0; i < totalLuaFiles.Count; ++i)
        {
            var couple = totalLuaFiles[i];
            var srcPath = couple.Item1;
            var newPath = couple.Item2;
            
            EditorUtility.DisplayCancelableProgressBar("正在处理...", newPath, (i + 1.0f) / totalLuaFiles.Count);
            //复制加密lua
            var content = EncryptLua(srcPath, HandleBytes);
            var encrpytFile = $"{output}/{newPath}";
            EnsureFilePath(encrpytFile);
            File.WriteAllText(encrpytFile, content);
            
            //复制明文lua
            string plaintextFile = $"{luaPlainTextPath}/{newPath}";
            EnsureFilePath(plaintextFile);
            FileUtil.CopyFileOrDirectory(srcPath, plaintextFile);
        }
        EditorUtility.ClearProgressBar();
    }

    static void EnsureFilePath(string fullPath)
    {
        var directory = Path.GetDirectoryName(fullPath);
        if (Directory.Exists(directory))
            return;
        Directory.CreateDirectory(directory);
    }
    
    //加密字串
    static string EncryptData(string content, string key, Func<byte[], byte[]> HandleBytes = null)
    {
        try
        {
            byte[] keyArray = Encoding.UTF8.GetBytes(key);
            RijndaelManaged rDel = new RijndaelManaged();
            rDel.Key = keyArray;
            rDel.Mode = CipherMode.CBC;
            rDel.Padding = PaddingMode.PKCS7;
            rDel.IV = Encoding.UTF8.GetBytes("7612123405345689");
            ICryptoTransform cTransform = rDel.CreateEncryptor();

            byte[] toEncryptArray = Encoding.UTF8.GetBytes(content);
            if (HandleBytes != null)
            {
                toEncryptArray = HandleBytes(toEncryptArray);
            }
            byte[] resultArray = cTransform.TransformFinalBlock(toEncryptArray, 0, toEncryptArray.Length);
            string resultStr = System.Convert.ToBase64String(resultArray, 0, resultArray.Length);
            return resultStr;
        }
        catch (System.Exception e)
        {
            UnityEngine.Debug.Log("EncryptWithKey - catch exception: " + e.ToString());
            return content;
        }
    }

    
    //加密lua
    static string EncryptLua(string luaFile, Func<byte[], byte[]> HandleBytes = null)
    {
        var content = File.ReadAllText(luaFile);
        return EncryptData(content, ScriptBridge.EntryL, HandleBytes);
    }
    
    //生成文件清单
    static void GenerateFileList()
    {
        var launchFiles = GenerateFileListForLaunch();
        GenerateFileListForGame(launchFiles);
    }
    static List<string> GenerateFileListForLaunch()
    {
        var rootPath = Application.streamingAssetsPath;
        var resPath = $"{rootPath}/res";
        var luaPath = $"{rootPath}/lua";
        
        var lstTotalFile = new List<string>();
        
        //res
        string[] bundleNames = {"font", "prefab_ui_launch", "prefab_ui_userpermission", "atlas_a_userpermission", "shader", };
        foreach (var bundleName in bundleNames)
        {
            XPackagerUtil.CollectFiles(ref lstTotalFile, resPath, $"{bundleName}.unity3d");
        }
        //res 描述文件
        XPackagerUtil.CollectFiles(ref lstTotalFile, resPath, "*.dat");
        //lua
        var lstIgnoreFile = new List<string>();
        XPackagerUtil.CollectFiles(ref lstIgnoreFile, $"{luaPath}/FreakPlanet", "*.lua");
        XPackagerUtil.CollectFiles(ref lstTotalFile, rootPath, "*.lua",
            (filePath) => !lstIgnoreFile.Contains(filePath));
        
        //
        XPackagerUtil.GenerateFileList(rootPath, lstTotalFile, $"{rootPath}/{launchFileName}");
        return lstTotalFile;
    }
    static List<string> GenerateFileListForGame(List<string> lstIgnoreFile)
    {
        var rootPath = Application.streamingAssetsPath;

        var lstTotalFile = new List<string>();
        XPackagerUtil.CollectFiles(ref lstTotalFile, rootPath, "*.*",
            (filePath) => !lstIgnoreFile.Contains(filePath));

        XPackagerUtil.GenerateFileList(rootPath, lstTotalFile, $"{rootPath}/{gameFileName}");
        return lstTotalFile;
    }

    static string GetSimpleBundleName(string bundleName)
    {
        return bundleName.Replace(AppConst.ExtName, string.Empty);
    }

    #region 打包策略

    public static void GenerateBundle()
    {
        var bundleConfig = XBundleConfig.LoadBundleConfig();
        if (bundleConfig == null)
        {
            EditorUtility.DisplayDialog("提示", $"未找到分包策略\n路径{XBundleConfig.BUNDLE_CONFIG_ASSETPATH}", "OK");
            return;
        }
        
        //
        var dicCurBundleDatas = CollectBundleDataFromProject();
        var dicDstBundleDatas = CollectBundleDataByStrategy(bundleConfig.strategies);

        //设置包名
        var dicUseBundleNames = new Dictionary<string, bool>();

        //设置包名
        int iCurNum = 0;
        int iMaxNum = dicDstBundleDatas.Count;
        foreach (var pairs in dicDstBundleDatas)
        {
            var strAssetPath = pairs.Key;
            var strBundleName = pairs.Value;
            if (!dicUseBundleNames.ContainsKey(strBundleName))
            {
                dicUseBundleNames.Add(strBundleName, true);
            }
            //已经存在的相同包名的,不做修改
            if (dicCurBundleDatas.ContainsKey(strAssetPath) &&
                dicCurBundleDatas[strAssetPath] == strBundleName)
            {
                continue;
            }
            
            if (EditorUtility.DisplayCancelableProgressBar(strBundleName, strAssetPath, (iCurNum++ + 1.0f) / iMaxNum))
                break;
            
            SetBundleName(strAssetPath, strBundleName);
        }
        EditorUtility.ClearProgressBar();
        
        //移除包名
        var arrCurBundleNames = AssetDatabase.GetAllAssetBundleNames();
        foreach (var bundleName in arrCurBundleNames)
        {
            if (dicUseBundleNames.ContainsKey(bundleName))
                continue;
            AssetDatabase.RemoveAssetBundleName(bundleName, true);
        }
        
        //保存修改
        AssetDatabase.SaveAssets();
        
    }

    public static Dictionary<string, string> CollectBundleDataFromProject()
    {
        var result = new Dictionary<string, string>();
        var bundleNames = AssetDatabase.GetAllAssetBundleNames();
        foreach (var bundleName in bundleNames)
        {
            var assetPaths = AssetDatabase.GetAssetPathsFromAssetBundle(bundleName);

            foreach (var assetPath in assetPaths)
            {
                result.Add(assetPath, bundleName);
            }
        }
        return result;
    }

    //根据分包策略统计包名
    public static Dictionary<string, string> CollectBundleDataByStrategy(List<XBundleConfig.BundleStrategy> strategies)
    {
        var result = new Dictionary<string, string>();
        
        foreach (var strategy in strategies)
        {
            if (string.IsNullOrEmpty(strategy.bundleName) || strategy.folderPath == null)
                continue;
            var rootPath = AssetDatabase.GetAssetPath(strategy.folderPath);
            var bundleName = strategy.bundleName.ToLower();
            switch (strategy.filterMode)
            {
                case XBundleConfig.EnumFilterMode.One:
                    CollectBundleData(result, bundleName, new string[]{rootPath}, false);
                    break;
                case XBundleConfig.EnumFilterMode.File:
                {
                    if (!AssetDatabase.IsValidFolder(rootPath))
                        continue;
                    var assetPaths = Directory.GetFiles(rootPath, strategy.pattern, strategy.searchOption);
                    CollectBundleData(result, bundleName, assetPaths, strategy.individual);
                }
                    break;
                case XBundleConfig.EnumFilterMode.Folder:
                {
                    if (!AssetDatabase.IsValidFolder(rootPath))
                        continue;
                    var assetPaths = Directory.GetDirectories(rootPath, strategy.pattern, strategy.searchOption);
                    CollectBundleData(result, bundleName, assetPaths, strategy.individual);

                }
                    break;
                case XBundleConfig.EnumFilterMode.PerFolder:
                {
                    if (!AssetDatabase.IsValidFolder(rootPath))
                        continue;
                    CollectPerFolder(result, bundleName, rootPath);
                }
                    break;
            }
        }
        return result;
    }

    public static void CollectBundleData(Dictionary<string, string> result, string bundleName, ICollection<string> assetPaths, bool individual)
    {
        foreach (var assetPath in assetPaths)
        {
            var realAssetPath = assetPath.Replace("\\", "/");
            var realBundleName = bundleName;
            if (individual)
            {
                realBundleName = $"{bundleName}_{Path.GetFileNameWithoutExtension(realAssetPath)}".ToLower();
            }
            //加上标准后缀
            realBundleName += AppConst.ExtName;
            if (result.ContainsKey(realAssetPath))
            {
                //EditorUtility.DisplayDialog("提示", $"资源{realAssetPath}已有包名 包名:{result[realAssetPath]}", "OK");
                result[realAssetPath] = realBundleName;
            }
            else
            {
                result.Add(realAssetPath, realBundleName);
            }
        }
    }
    
    private static void CollectPerFolder(Dictionary<string, string> result, string bundleName, string folderPath)
    {
        var files = new List<string>();
        XPackagerUtil.CollectFiles(ref files, folderPath, "*", (string path) =>
        {
            return !path.EndsWith(".meta");
        }, SearchOption.TopDirectoryOnly);
        if (files.Count > 0)
        {
            var realAssetPath = folderPath.Replace("\\", "/");;
            var realBundleName = bundleName.ToLower();
            //加上标准后缀
            realBundleName += AppConst.ExtName;
            if (result.ContainsKey(realAssetPath))
            {
                //EditorUtility.DisplayDialog("提示", $"资源{realAssetPath}已有包名 包名:{result[realAssetPath]}", "OK");
                result[realAssetPath] = realBundleName;
            }
            else
            {
                result.Add(realAssetPath, realBundleName);
            }
        }
        var assetPaths = Directory.GetDirectories(folderPath, "*", SearchOption.TopDirectoryOnly);
        foreach (var assetPath in assetPaths)
        {
            CollectPerFolder(result, $"{bundleName}_{Path.GetFileNameWithoutExtension(assetPath)}", assetPath);
        }
    }
    
    public static void SetBundleName(string assetPath, string bundleName)
    {
        AssetImporter importer = AssetImporter.GetAtPath(assetPath);
        if (importer == null)
            return;
        importer.assetBundleName = bundleName;
    }
    
    #endregion
}