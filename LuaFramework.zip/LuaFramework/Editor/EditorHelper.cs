﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEditor;

public static class EditorHelper
{
    
}

public class TimeWatcher
{
    public TimeSpan TimeSpan { get; protected set; }
    private System.Diagnostics.Stopwatch _watch;

    public static TimeWatcher Start()
    {
        var watcher = new TimeWatcher();
        return watcher;
    }

    private TimeWatcher()
    {
        _watch = new System.Diagnostics.Stopwatch();
        _watch.Start();
    }

    public void Restart()
    {
        _watch.Restart();
    }

    public void Stop()
    {
        _watch.Stop();
        TimeSpan = new System.TimeSpan(_watch.ElapsedTicks);
    }
}