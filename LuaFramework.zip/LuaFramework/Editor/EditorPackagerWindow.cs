﻿using System.Collections;
using System.Collections.Generic;
using LuaFramework;
using UnityEngine;
using UnityEditor;
using UnityEditor.Build;
using Sirenix.OdinInspector;
using Sirenix.OdinInspector.Editor;
using XGameKit.XAssetManager;

public class EditorPackagerWindow : OdinEditorWindow
{
    public static void OpenWindow()
    {
        var window = GetWindow<EditorPackagerWindow>("打包资源窗口");
        window.minSize = new Vector2(300, 500);
        window.Show();
    }

    protected override void Initialize()
    {
        base.Initialize();

        EnableDevResMode = XAssetUtil.IsDevMode;

    }

    [BoxGroup]
    [LabelText("启用开发者模式"), OnValueChanged("_OnEnableDevResModeChanged")]
    public bool EnableDevResMode;

    void _OnEnableDevResModeChanged()
    {
        XAssetUtil.EnableDevMode(EnableDevResMode);
    }
    
    [BoxGroup]
    [Button("分 包 策 略", ButtonSizes.Large), GUIColor(0.0f, 0.5f, 0.8f)]
    void SelectBundleConfig()
    {
        XBundleConfig.SelectBundleConfig();
    }

    [BoxGroup]
    [Button("更 新 包 名", ButtonSizes.Large), GUIColor(0.0f, 1.0f, 0.0f)]
    void UpdateBundleName()
    {
        if (!EditorUtility.DisplayDialog("提示", "正在准备更新包名，是否确认？", "确认", "取消"))
            return;
        Packager.GenerateSvnVersion();
        //Packager.UpdateGameBundleName();
        Packager.GenerateBundle();
    }
    
    [BoxGroup("打包资源")]
    [Button("编 译 资 源 包( 不 压 缩 )", ButtonSizes.Large), GUIColor(0.0f, 0.5f, 0.8f)]
    void BuildResource()
    {
        var target = EditorUserBuildSettings.activeBuildTarget;
        switch (target)
        {
            case BuildTarget.iOS:
                if (EditorUtility.DisplayDialog("提示", "正在准备打包iOS资源（不压缩），是否确认？", "确认", "取消"))
                {
                    Packager.BuildiPhoneResource();
                }
                break;
            case BuildTarget.Android:
                if (EditorUtility.DisplayDialog("提示", "正在准备打包Android资源（不压缩），是否确认？", "确认", "取消"))
                {
                    Packager.BuildAndroidResource();
                }
                break;
        }
        
    }
    [BoxGroup("打包资源")]
    [Button("编 译 资 源 包( 压 缩 )", ButtonSizes.Large), GUIColor(0.0f, 1.0f, 0.0f)]
    void BuildCompressResource()
    {
        var target = EditorUserBuildSettings.activeBuildTarget;
        switch (target)
        {
            case BuildTarget.iOS:
                if (EditorUtility.DisplayDialog("提示", "正在准备打包iOS资源(压缩)，是否确认？", "确认", "取消"))
                {
                    Packager.BuildiPhoneCompressResource();
                }
                break;
            case BuildTarget.Android:
                if (EditorUtility.DisplayDialog("提示", "正在准备打包Android资源(压缩)，是否确认？", "确认", "取消"))
                {
                    Packager.BuildAndroidCompressResource();
                }
                break;
        }
    }

    [BoxGroup("资源调试")]
    [Button("资 源 使 用 日 志(必须非开发者模式)", ButtonSizes.Large), GUIColor(0.0f, 1.0f, 0.0f)]
    void PrintAssetLog()
    {
        if (Application.isPlaying)
        {
            var text = AppFacade.Instance.GetManager<ResourceManager>(ManagerName.Resource).GetBundleLog();
            XDebug.Log("GGYY", text);
        }
    }
}
