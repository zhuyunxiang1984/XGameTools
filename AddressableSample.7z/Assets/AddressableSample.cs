using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.AddressableAssets;
using UnityEngine.ResourceManagement.AsyncOperations;
using UnityEngine.ResourceManagement.ResourceProviders;

public class AddressableSample : MonoBehaviour
{
    public Transform Root;
    List<object> _UpdateKeys = new List<object>();
    // Start is called before the first frame update
    void Start()
    {
        Debug.Log($"RuntimePath {Addressables.RuntimePath}");
        Debug.Log($"PlayerBuildDataPath {Addressables.PlayerBuildDataPath}");
        Debug.Log($"BuildPath {Addressables.BuildPath}");
        Debug.Log($"LibraryPath {Addressables.LibraryPath}");
    }

    // Update is called once per frame
    void Update()
    {
        
    }


    public void UpdateCatelog()
    {
        StartCoroutine(_UpdateCatelog());
    }
    IEnumerator _UpdateCatelog()
    {
        yield return Addressables.InitializeAsync();
        Debug.Log("��ʼ�����");

        var catelogupdateAsync = Addressables.CheckForCatalogUpdates(false);
        yield return catelogupdateAsync;
        Debug.Log("������catelog��� " + catelogupdateAsync.Status);

        if (catelogupdateAsync.Status == AsyncOperationStatus.Succeeded && catelogupdateAsync.Result.Count > 0)
        {
            var catelogs = catelogupdateAsync.Result;
            foreach (var catelog in catelogs)
            {
                Debug.Log("catalog  " + catelog);
            }
            var updateHandle = Addressables.UpdateCatalogs(catelogs, false);
            yield return updateHandle;
            Debug.Log($"����catelog��� " + updateHandle.Status);

            if (updateHandle.Status == AsyncOperationStatus.Succeeded)
            {
                _UpdateKeys.Clear();
                foreach (var item in updateHandle.Result)
                {
                    Debug.Log("catalog result " + item.LocatorId);
                    foreach (var key in item.Keys)
                    {
                        Debug.Log("catalog key " + key);
                    }
                    _UpdateKeys.AddRange(item.Keys);
                }
            }
        }
        Addressables.Release(catelogupdateAsync);
    }

    public void DownloadAssets()
    {
        if (_UpdateKeys.Count < 1)
            return;
        StartCoroutine(_DownloadAssets());
    }
    IEnumerator _DownloadAssets()
    {
        
        var downloadSize = Addressables.GetDownloadSizeAsync(_UpdateKeys);
        yield return downloadSize;
        Debug.Log($"downloadSize = {downloadSize.Result}");

        if (downloadSize.Result > 0)
        {
            foreach (var key in _UpdateKeys)
            {
                var download = Addressables.DownloadDependenciesAsync(key, false);

                yield return download;
                Debug.Log("��Դ������� " + download.Status);

                if (download.Status == AsyncOperationStatus.Succeeded)
                {
                    foreach (var item in download.Result as List<IAssetBundleResource>)
                    {
                        var ab = item.GetAssetBundle();
                        Debug.Log("ab name " + ab.name);
                        foreach (var name in ab.GetAllAssetNames())
                        {
                            Debug.Log("asset name " + name);
                        }
                    }
                }               

                Addressables.Release(download);
            }
        }

        Addressables.Release(downloadSize);
        _UpdateKeys.Clear();
    }

    public void Create()
    {
        Addressables.LoadAssetAsync<GameObject>("Image").Completed += (go)=>
        {
            Instantiate(go.Result, Root, false);
        };
    }
}
