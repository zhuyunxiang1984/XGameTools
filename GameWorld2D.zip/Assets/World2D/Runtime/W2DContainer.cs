﻿using System.Collections;
using System.Collections.Generic;
using Sirenix.Utilities;
using UnityEngine;

public class W2DContainer : W2DObject
{
    public List<W2DRect> forbiddenZones = new List<W2DRect>();
    
    public struct ItemData
    {
        public int iGridX;
        public int iGridY;
        public W2DItem data;
    }
    private List<ItemData> m_lstItems = new List<ItemData>();

    protected override void GenerateGridData()
    {
        base.GenerateGridData();
        
        SetGriData(new W2DRect(0,0,colCount, rowCount), 0);
        foreach (var forbiddenZone in forbiddenZones)
        {
            SetGriData(forbiddenZone, 1);
        }
    }
    
    //计算摆放位置
    public void FindAvaliableGird(W2DItem target, Vector2 world2dPoint, out int iGridX, out int iGridY)
    {
        var point = World2DUtil.ConvertToNormalPoint(ConvertToLocal(world2dPoint));
        iGridX = Mathf.FloorToInt(point.x / World2DUtil.GRID_WIDTH);
        iGridY = Mathf.FloorToInt(point.y / World2DUtil.GRID_WIDTH);
        iGridX = Mathf.Clamp(iGridX, 0, colCount - target.colCount);
        iGridY = Mathf.Clamp(iGridY, 0, rowCount - target.rowCount);
    }
    
    //
    public void FillHintGrid(W2DGridHint gridHint, W2DItem item, int iGridX, int iGridY)
    {
        gridHint.SetData(item.rowCount, item.colCount);
        for (int row = 0; row < item.rowCount; ++row)
        {
            for (int col = 0; col < item.colCount; ++col)
            {
                if (item.GetGridFlag(col, row) == 1)
                {
                    if (GetGridFlag(iGridX + col, iGridY + row) == 1)
                    {
                        gridHint.SetFlag(col,row,1);
                    }
                    else
                    {
                        gridHint.SetFlag(col,row,0);
                    }
                }
            }
        }
        gridHint.UpdateGrid();
    }
    
    //摆放物件
    public void AppendItem(W2DItem item, int iGridX, int iGridY)
    {
        var itemData = new ItemData();
        itemData.iGridX = iGridX;
        itemData.iGridY = iGridY;
        itemData.data = item;
        m_lstItems.Add(itemData);

        for (int row = 0; row < item.rowCount; ++row)
        {
            for (int col = 0; col < item.colCount; ++col)
            {
                if (item.GetGridFlag(col, row) == 1)
                {
                    SetGriData(iGridX + col, iGridY + row, 1);
                }
            }
        }

        
    }
    
    //移除物件
    public void RemoveItem(W2DItem item)
    {
        for (int i = 0; i < m_lstItems.Count; ++i)
        {
            if (m_lstItems[i].data == item)
            {
                m_lstItems.RemoveAt(i);
                break;
            }
        }
    }
    
    //绘制排序
    public List<RenderData> SortRenders()
    {
        var lstRenderDatas = new List<RenderData>();
        GetRenderDatas(ref lstRenderDatas);
        lstRenderDatas.Sort(SortRenderDataCompareMethod);
        return lstRenderDatas;
    }
    
    public override void SetSortingOrder(int sortingOrder)
    {
        base.SetSortingOrder(sortingOrder);
    }
    public void GetRenderDatas(ref List<RenderData> lstRenderDatas)
    {
        foreach (var itemData in m_lstItems)
        {
            itemData.data.GetRenderDatas(itemData.iGridX, itemData.iGridY , ref lstRenderDatas);
        }
    }

    private int SortRenderDataCompareMethod(RenderData obj1, RenderData obj2)
    {
        var result = 0;
        if (obj1.rect.y >= obj2.rect.y + obj2.rect.h)
            result = -1;
        else if (obj1.rect.y + obj1.rect.h <= obj2.rect.y)
            result = 1;
        else if (obj1.rect.x + obj1.rect.w <= obj2.rect.x)
            result = -1;
        else if (obj1.rect.x >= obj2.rect.x + obj2.rect.w)
            result = 1;
        Debug.Log($"{obj1.renderer.name} {obj2.renderer.name} = {result}");
        return result;
    }

    protected override void DrawGizmosGrid()
    {
        base.DrawGizmosGrid();

        DrawGizmosGrid(new W2DRect(0, 0, colCount, rowCount), gridColor);
        foreach (var forbiddenZone in forbiddenZones)
        {
            DrawGizmosGrid(forbiddenZone, Color.red);
        }
    }
}
