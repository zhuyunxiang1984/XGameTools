﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class W2DItem : W2DObject
{
    public List<W2DRect> spriteZones = new List<W2DRect>();
    public W2DContainer plane;
    
    private SpriteRenderer[] m_arrRenders; 
    protected override void Awake()
    {
        base.Awake();
        m_arrRenders = GetComponentsInChildren<SpriteRenderer>();
    }

    protected override void GenerateGridData()
    {
        base.GenerateGridData();

        if (spriteZones.Count > 0)
        {
            foreach (var spriteZone in spriteZones)
            {
                SetGriData(spriteZone, 1);
            }
        }
        else
        {
            SetGriData(new W2DRect(0,0,colCount,rowCount), 1);
        }
    }

    public override void SetSortingOrder(int sortingOrder)
    {
        foreach (var render in m_arrRenders)
        {
            render.sortingOrder = sortingOrder++;
        }
    }

    private static int s_tempId;
    public void GetRenderDatas(int iGridX, int iGridY, ref List<RenderData> lstRenderDatas)
    {
        if (spriteZones.Count > 0)
        {
            for (int i = 0; i < m_arrRenders.Length && i < spriteZones.Count; ++i)
            {
                var rect = spriteZones[i];
                rect.x += iGridX;
                rect.y += iGridY;
                m_arrRenders[i].name = s_tempId++.ToString();
                lstRenderDatas.Add(new RenderData(rect, m_arrRenders[i]));
            }
        }
        else
        {
            for (int i = 0; i < m_arrRenders.Length; ++i)
            {
                m_arrRenders[i].name = s_tempId++.ToString();
                lstRenderDatas.Add(new RenderData(new W2DRect(iGridX,iGridY,colCount, rowCount), m_arrRenders[i]));
            }
        }
        
    }

    protected override void DrawGizmosGrid()
    {
        base.DrawGizmosGrid();
        
        DrawGizmosGrid(new W2DRect(0, 0, colCount, rowCount), gridColor);
        foreach (var spriteZone in spriteZones)
        {
            DrawGizmosGrid(spriteZone, Color.green);
        }
    }
}
