﻿using System;
using System.Collections;
using System.Collections.Generic;
using Sirenix.OdinInspector;
using UnityEngine;

public abstract class W2DObject : MonoBehaviour
{
    [System.Serializable]
    public struct W2DRect
    {
        [HorizontalGroup, LabelWidth(20)]
        public int x;
        [HorizontalGroup, LabelWidth(20)]
        public int y;
        [HorizontalGroup, LabelWidth(20)]
        public int w;
        [HorizontalGroup, LabelWidth(20)]
        public int h;

        public W2DRect(int x, int y, int w, int h)
        {
            this.x = x;
            this.y = y;
            this.w = w;
            this.h = h;
        }
    }
    public struct RenderData
    {
        public W2DRect rect;
        public SpriteRenderer renderer;

        public RenderData(W2DRect rect, SpriteRenderer renderer)
        {
            this.rect = rect;
            this.renderer = renderer;
        }
    }

    public bool showGizmos = false;
    public Color gridColor = Color.black;

    public int rowCount;
    public int colCount;
    public Vector2 offset;

    public Vector2 Center
    {
        get { return new Vector2(colCount * World2DUtil.GRID_WIDTH, rowCount * World2DUtil.GRID_WIDTH) * 0.5f;}
    }
    public Vector2 CenterInSkew
    {
        get
        {
            return World2DUtil.ConvertToSkewPoint(Center) + offset * 0.5f;
        }
    }
    
    protected int[,] m_arrGrids;

    protected virtual void Awake()
    {
        GenerateGridData();
    }

    public int GetGridFlag(int iGridX, int iGridY)
    {
        return m_arrGrids[iGridY, iGridX];
    }
    
    //
    public Vector2 GetPositionByGridIndex(int iGridX, int iGridY, bool isCenter = false)
    {
        if (isCenter)
        {
            new Vector2((iGridX + 0.5f) * World2DUtil.GRID_WIDTH, (iGridY + 0.5f) * World2DUtil.GRID_WIDTH);
        }
        return new Vector2(iGridX * World2DUtil.GRID_WIDTH, iGridY * World2DUtil.GRID_WIDTH);
    }

    //
    public Vector2 CalcSkewPoint(int iGridX, int iGridY, bool isCenter = false)
    {
        return CalcSkewPoint(GetPositionByGridIndex(iGridX, iGridY, isCenter));
    }
    //
    public Vector2 CalcSkewPoint(Vector2 point)
    {
        point = World2DUtil.ConvertToSkewPoint(point);
        return point + (Vector2)transform.position - CenterInSkew + offset;
    }
    
    
    //转换到本地坐标,原点在左下
    public Vector2 ConvertToLocal(Vector2 world2dPoint)
    {
        return world2dPoint - (Vector2) transform.position + CenterInSkew - offset;
    }
    
    //获取grid索引
    public void GetGridIndex(Vector2 world2dPoint, out int x, out int y)
    {
        var point = World2DUtil.ConvertToNormalPoint(ConvertToLocal(world2dPoint));
        x = Mathf.FloorToInt(point.x / World2DUtil.GRID_WIDTH);
        y = Mathf.FloorToInt(point.y / World2DUtil.GRID_WIDTH);
    }
    
    //
    public bool IsInside(int iGridX, int iGridY)
    {
        return iGridX >= 0 && iGridX < colCount && iGridY >= 0 && iGridY < rowCount;
    }

    public virtual void SetPosition(Vector2 position)
    {
        transform.position = position;
    }
    public void SetPosition(W2DObject target, int iGridX, int iGridY)
    {
        var position = target.CalcSkewPoint(iGridX, iGridY) + CenterInSkew;
        SetPosition(position);
    }

    //设置绘制层级
    public virtual void SetSortingOrder(int sortingOrder)
    {
        
    }

    protected virtual void GenerateGridData()
    {
        m_arrGrids = new int[rowCount, colCount];
        
    }

    public void ResetGridData()
    {
        for (var row = rowCount; row < rowCount; ++row)
        {
            for (var col = colCount; col < colCount; ++col)
            {
                m_arrGrids[row, col] = 0;
            }
        }
    }
    public void SetGriData(W2DRect rect, int value)
    {
        int colCount = rect.x + rect.w;
        int rowCount = rect.y + rect.h;
        for (var row = rect.y; row < rowCount; ++row)
        {
            for (var col = rect.x; col < colCount; ++col)
            {
                m_arrGrids[row, col] = value;
            }
        }
    }

    public void SetGriData(int iGridX, int iGridY, int value)
    {
        m_arrGrids[iGridY, iGridX] = value;
    }

    private void OnDrawGizmos()
    {
        if (!showGizmos)
            return;
        DrawGizmosGrid();
    }

    protected virtual void DrawGizmosGrid()
    {
    }

    protected void DrawGizmosGrid(W2DRect rect, Color color)
    {
        int colCount = rect.x + rect.w;
        int rowCount = rect.y + rect.h;
        for (var row = rect.y; row < rowCount; ++row)
        {
            for (var col = rect.x; col < colCount; ++col)
            {
                DrawGizmosGrid(col, row, color);
            }
        }
    }
    
    protected void DrawGizmosGrid(int x, int y, Color color)
    {
        var point1 = CalcSkewPoint(new Vector2(x * World2DUtil.GRID_WIDTH, y * World2DUtil.GRID_WIDTH));
        var point2 = CalcSkewPoint(new Vector2((x + 1) * World2DUtil.GRID_WIDTH, y * World2DUtil.GRID_WIDTH));
        var point3 = CalcSkewPoint(new Vector2((x + 1) * World2DUtil.GRID_WIDTH, (y + 1) * World2DUtil.GRID_WIDTH));
        var point4 = CalcSkewPoint(new Vector2(x * World2DUtil.GRID_WIDTH, (y + 1) * World2DUtil.GRID_WIDTH));

        Gizmos.color = color;
        Gizmos.DrawLine(point1, point2);
        Gizmos.DrawLine(point1, point4);
        Gizmos.DrawLine(point2, point3);
        Gizmos.DrawLine(point3, point4);
        
        Gizmos.color = color;
        Gizmos.DrawSphere(point1, World2DUtil.GRID_WIDTH * 0.1f);
        Gizmos.DrawSphere(point2, World2DUtil.GRID_WIDTH * 0.1f);
        Gizmos.DrawSphere(point4, World2DUtil.GRID_WIDTH * 0.1f);
        Gizmos.DrawSphere(point3, World2DUtil.GRID_WIDTH * 0.1f);
    }
}
