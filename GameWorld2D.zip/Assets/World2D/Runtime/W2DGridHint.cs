﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class W2DGridHint : W2DObject
{
    public GameObject prefab;
    public Color[] colors;

    private const int ROW_MAX = 50;
    private const int COL_MAX = 50;

    private int[,] m_arrFlags = new int[ROW_MAX, COL_MAX];

    private int m_iSortingOrder;
    private List<GameObject> m_lstRenders = new List<GameObject>();

    protected override void Awake()
    {
        base.Awake();
        prefab.SetActive(false);
    }

    public override void SetSortingOrder(int sortingOrder)
    {
        base.SetSortingOrder(sortingOrder);

        m_iSortingOrder = sortingOrder;
        foreach (var render in m_lstRenders)
        {
            render.GetComponentInChildren<SpriteRenderer>().sortingOrder = m_iSortingOrder;
        }
    }

    public void Reset()
    {
        for (int row = 0; row < ROW_MAX; ++row)
        {
            for (int col = 0; col < COL_MAX; ++col)
            {
                m_arrFlags[row, col] = -1;
            }
        }
    }
    
    public void SetData(int iRowCount, int iColCount)
    {
        rowCount = iRowCount;
        colCount = iColCount;
        Reset();
    }

    public void SetFlag(int iGridX, int iGridY, int iFlag)
    {
        if (iGridX < 0 || iGridX >= COL_MAX)
            return;
        if (iGridY < 0 || iGridY >= ROW_MAX)
            return;
        m_arrFlags[iGridY, iGridX] = iFlag;
    }

    public bool IsAvaliable()
    {
        for (int row = 0; row < ROW_MAX; ++row)
        {
            for (int col = 0; col < COL_MAX; ++col)
            {
                if (m_arrFlags[row, col] == 1)
                    return false;
            }
        }
        return true;
    }

    public void UpdateGrid()
    {
        int count = colCount * rowCount;
        if (count > m_lstRenders.Count)
        {
            int number = count - m_lstRenders.Count;
            for (int i = 0; i < number; ++i)
            {
                var objRender = GameObject.Instantiate(prefab);
                objRender.transform.SetParent(transform);
                objRender.GetComponentInChildren<SpriteRenderer>().sortingOrder = m_iSortingOrder;
                m_lstRenders.Add(objRender);
            }
        }
        for (int i = 0; i < m_lstRenders.Count; ++i)
        {
            var objRender = m_lstRenders[i];
            int col = i % colCount;
            int row = i / colCount;
            var flag = m_arrFlags[row, col];
            if (i < count && flag >= 0)
            {
                int index = flag;
                if (index >= 0 && index < colors.Length)
                {
                    objRender.GetComponentInChildren<SpriteRenderer>().color = colors[index];
                }
                var point = new Vector2((col + 0.5f) * World2DUtil.GRID_WIDTH, (row + 0.5f) * World2DUtil.GRID_WIDTH);
                objRender.transform.position = CalcSkewPoint(point);
                objRender.gameObject.SetActive(true);
            }
            else
            {
                objRender.gameObject.SetActive(false);
            }
        }
        
    }
}
