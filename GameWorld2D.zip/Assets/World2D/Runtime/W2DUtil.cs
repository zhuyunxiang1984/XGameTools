﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Matrix3x2 = System.Numerics.Matrix3x2;

public static class W2DUtil
{
    //水平偏移角
    public const float DEGREE_H = 30;
    //垂直偏移角
    public const float DEGREE_V = 60;
    //
    public const float GRID_WIDTH = 0.25f;

    public static Matrix3x2 s_matrix;
    public static Matrix3x2 s_invertMatrix;

    static W2DUtil()
    {
        var radiansH = -DEGREE_H * Mathf.Deg2Rad;
        var radiansV = -DEGREE_V * Mathf.Deg2Rad;
        s_matrix = new Matrix3x2()
        {
            M11 = Mathf.Cos(radiansH),
            M12 = -Mathf.Sin(radiansV),
            M21 = Mathf.Sin(radiansH),
            M22 = Mathf.Cos(radiansV),
            M31 = 0,
            M32 = 0,
        };
        Matrix3x2.Invert(s_matrix, out s_invertMatrix);
    }
    
    //转换到倾斜坐标
    public static Vector2 ConvertToSkewPoint(Vector2 point)
    {
        return TransformPoint(s_matrix, point);
    }
    //转换到普通坐标
    public static Vector2 ConvertToNormalPoint(Vector2 point)
    {
        return TransformPoint(s_invertMatrix, point);
    }
    private static Vector2 TransformPoint(Matrix3x2 matrix, Vector2 point)
    {
        return new Vector2(point.x * matrix.M11 + point.y * matrix.M12, point.x * matrix.M21 + point.y * matrix.M22);
    }
}
