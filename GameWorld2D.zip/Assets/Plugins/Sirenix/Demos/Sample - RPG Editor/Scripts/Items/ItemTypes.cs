#if UNITY_EDITOR

namespace Sirenix.OdinInspector.Demos.RPGEditor
{
    public enum ItemTypes
    {
        None,
        MainHand,
        OffHand,
        Body,
        Head,
        Ring,
        Amulet,
        Boots,
        Consumable,
        Flask
    }
}
#endif
