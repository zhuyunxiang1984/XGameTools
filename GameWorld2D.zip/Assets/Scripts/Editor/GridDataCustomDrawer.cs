﻿using System.Collections;
using System.Collections.Generic;
using Sirenix.OdinInspector.Editor;
using UnityEngine;
using UnityEditor;
using UnityEngine.Experimental.UIElements;


public class GridDataAttributeDrawer : OdinAttributeDrawer<World2DGrid.GridDataDrawerAttribute, World2DGrid.GridData>
{
    private static Vector2 s_scrollview;
    protected override void DrawPropertyLayout(GUIContent label)
    {
        var value = this.ValueEntry.SmartValue;

        EditorGUILayout.BeginHorizontal();
        EditorGUILayout.LabelField("col:",GUILayout.Width(30));
        value.gridx = EditorGUILayout.IntField(value.gridx,GUILayout.Width(50));
        EditorGUILayout.LabelField("row:",GUILayout.Width(30));
        value.gridy = EditorGUILayout.IntField(value.gridy,GUILayout.Width(50));
        EditorGUILayout.EndHorizontal();

        int total = value.gridx * value.gridy;
        while (total < value.datas.Count)
        {
            value.datas.RemoveAt(value.datas.Count - 1);
        }
        while (total > value.datas.Count)
        {
            value.datas.Add(0);
        }
        s_scrollview = EditorGUILayout.BeginScrollView(s_scrollview);
        for (int y = value.gridy - 1; y >= 0; --y)
        {
            
            EditorGUILayout.BeginHorizontal();
            for (int x = 0; x < value.gridx; ++x)
            {
                var index = y * value.gridx + x;
                value.datas[index] = EditorGUILayout.IntField(value.datas[index], GUILayout.Width(50));
            }
            EditorGUILayout.EndHorizontal();
        }
        EditorGUILayout.EndScrollView();
        // if (GUILayout.Button("重置数据"))
        // {
        //     value.datas.Clear();
        // }
        // if (GUI.changed)
        // {
        //     Debug.Log("changed");
        // }
        this.ValueEntry.SmartValue = value;
    }
}