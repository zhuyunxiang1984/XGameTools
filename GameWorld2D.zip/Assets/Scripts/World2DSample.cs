using System;
using System.Collections;
using System.Collections.Generic;
using System.Numerics;
using TMPro;
using UnityEngine;
using UnityEngine.Serialization;
using Matrix4x4 = UnityEngine.Matrix4x4;
using Object = System.Object;
using Quaternion = UnityEngine.Quaternion;
using Vector2 = UnityEngine.Vector2;
using Vector3 = UnityEngine.Vector3;

#if UNITY_EDITOR
using UnityEditor;
#endif

[ExecuteInEditMode]
public class World2DSample : MonoBehaviour
{
    public W2DContainer ground;
    public W2DGridHint gridHint;
    public GameObject[] furnitures;
    
    private enum EnumState
    {
        None = 0,
        Drag = 1,
    }
    private EnumState m_state;
    private W2DItem m_selectObj;
    private int m_iDragGridX;
    private int m_iDragGridY;
    
    void Start()
    {
        
    }

    void Update()
    {
        UpdateInput();

        if (m_state == EnumState.Drag)
        {
            var ray = Camera.main.ScreenPointToRay(Input.mousePosition);
            int iGridX;
            int iGridY;
            //ground.GetGridIndex(ray.origin, out iGridX, out iGridY);
            //if (ground.IsInside(iGridX, iGridY))
            {
                ground.FindAvaliableGird(m_selectObj, ray.origin, out iGridX, out iGridY);
                //Debug.Log($"x:{iGridX} y:{iGridY}");
                m_iDragGridX = iGridX;
                m_iDragGridY = iGridY;
                //
                m_selectObj.SetPosition(ground, iGridX, iGridY);
                //
                ground.FillHintGrid(gridHint, m_selectObj, iGridX, iGridY);
                gridHint.transform.position = m_selectObj.transform.position;
            }
        }
    }

    private void UpdateInput()
    {
        if (Input.GetKey(KeyCode.W))
        {
            Camera.main.transform.position = Camera.main.transform.position + Vector3.up * Time.deltaTime;
        }
        if (Input.GetKey(KeyCode.S))
        {
            Camera.main.transform.position = Camera.main.transform.position - Vector3.up * Time.deltaTime;
        }
        if (Input.GetKey(KeyCode.A))
        {
            Camera.main.transform.position = Camera.main.transform.position - Vector3.right * Time.deltaTime;
        }
        if (Input.GetKey(KeyCode.D))
        {
            Camera.main.transform.position = Camera.main.transform.position + Vector3.right * Time.deltaTime;
        }
        if (Input.GetKeyDown(KeyCode.Alpha1))
        {
            HandleClickNum(1);
        }
        if (Input.GetKeyDown(KeyCode.Alpha2))
        {
            HandleClickNum(2);
        }
        if (Input.GetKeyDown(KeyCode.Alpha3))
        {
            HandleClickNum(3);
        }
        if (Input.GetKeyDown(KeyCode.Alpha4))
        {
            HandleClickNum(4);
        }
        
        if (Input.GetMouseButtonDown(0))
        {
            if (m_state == EnumState.Drag)
            {
                if (gridHint.IsAvaliable())
                {
                    ground.AppendItem(m_selectObj, m_iDragGridX, m_iDragGridY);
                    m_selectObj.SetPosition(ground, m_iDragGridX, m_iDragGridY);
                }
                else
                {
                    GameObject.Destroy(m_selectObj.gameObject);
                }
                m_state = EnumState.None;
                m_selectObj = null;
                gridHint.gameObject.SetActive(false);
                UpdateRenderSortingOrder();
            }
        }
        if (Input.GetMouseButtonDown(1))
        {
            if (m_state == EnumState.Drag)
            {
                GameObject.Destroy(m_selectObj.gameObject);
                m_state = EnumState.None;
                m_selectObj = null;
                gridHint.gameObject.SetActive(false);
                UpdateRenderSortingOrder();
            }
        }
    }

    private void HandleClickNum(int num)
    {
        if (num < 1)
            return;
        if (m_state == EnumState.Drag)
        {
            m_state = EnumState.None;
            GameObject.Destroy(m_selectObj.gameObject);
            m_selectObj = null;
            gridHint.gameObject.SetActive(false);
        }
        else
        {
            m_selectObj = CreateFurniture(num - 1);
            if (m_selectObj != null)
            {
                m_state = EnumState.Drag;
                m_selectObj.SetSortingOrder(5000);
                gridHint.gameObject.SetActive(true);
                gridHint.SetSortingOrder(5010);
            }
        }
    }

    private GameObject GetSelectFurniture(int index)
    {
        if (index < 0 || index >= furnitures.Length)
            return null;
        return furnitures[index];
    }

    private W2DItem CreateFurniture(int index)
    {
        var prefab = GetSelectFurniture(index);
        if (prefab == null)
            return null;
        var go = GameObject.Instantiate(prefab);
        var w2dItem = go.GetComponent<W2DItem>();
        return w2dItem;
    }

    private void RemoveFurniture()
    {
        
    }
    
    private void UpdateRenderSortingOrder()
    {
        var sortedRenders = ground.SortRenders();
        int startSortingOrder = 0;
        foreach (var renderData in sortedRenders)
        {
            //Debug.Log($"flag:{renderObj.flag}");
            renderData.renderer.sortingOrder = startSortingOrder++;
        }
    }
    //
    // private int SortingOrderMethod(World2DGrid.RenderObj obj1, World2DGrid.RenderObj obj2)
    // {
    //     var girdIndex1 = _renderObjPoss[obj1];
    //     var girdIndex2 = _renderObjPoss[obj2];
    //     var minx1 = girdIndex1.x + obj1.minX;
    //     var maxx1 = girdIndex1.x + obj1.maxX;
    //     var miny1 = girdIndex1.y + obj1.minY;
    //     var maxy1 = girdIndex1.y + obj1.maxY;
    //     
    //     var minx2 = girdIndex2.x + obj2.minX;
    //     var maxx2 = girdIndex2.x + obj2.maxX;
    //     var miny2 = girdIndex2.y + obj2.minY;
    //     var maxy2 = girdIndex2.y + obj2.maxY;
    //     
    //     //Debug.Log($"flag:{obj1.flag} minx1:{minx1} maxx1:{maxx1} miny1:{miny1} maxy1:{maxy1}");
    //     //Debug.Log($"flag:{obj2.flag} minx2:{minx2} maxx2:{maxx2} miny2:{miny2} maxy2:{maxy2}");
    //     if (miny1 >= maxy2)
    //         return -1;
    //     if (maxy1 <= miny2)
    //         return 1;
    //     if (maxx1 <= minx2)
    //         return -1;
    //     if (minx1 >= maxx2)
    //         return 1;
    //     //Debug.Log($"flag:{obj1.flag} flag:{obj2.flag} {result}");
    //     return 0;
    // }

    
}
