﻿using System;
using System.Collections;
using System.Collections.Generic;
using Sirenix.OdinInspector;
using Sirenix.OdinInspector.Editor;
using Sirenix.Utilities;
using UnityEditor;
using UnityEngine;
using UnityEngine.Experimental.UIElements;
using Vector2 = UnityEngine.Vector2;

[ExecuteInEditMode]
public class World2DGrid : MonoBehaviour
{
    [AttributeUsage(AttributeTargets.Field)]
    public class GridDataDrawerAttribute : Attribute
    {
    }

    [Serializable]
    public class GridData
    {
        public int gridx;
        public int gridy;
        public List<int> datas = new List<int>();

        public int GetFlag(int x, int y)
        {
            var index = y * gridx + x;
            if (index < 0 || index >= datas.Count)
                return 0;
            return datas[index];
        }

        public bool IsMutiSprite()
        {
            foreach (var data in datas)
            {
                if (data > 0)
                    return true;
            }
            return false;
        }
    }

    public bool showGizmos = false;
    public Color gridColor = Color.black;
    [GridDataDrawer]
    public GridData data;

    #if UNITY_EDITOR
    [Button("脏数据", ButtonSizes.Medium)]
    void EditorSetDirty()
    {
        EditorUtility.SetDirty(gameObject);
    }
    #endif
    
    public class RenderObj
    {
        public int minX = -1;
        public int minY = -1;
        public int maxX = -1;
        public int maxY = -1;
        public int flag;
        public SpriteRenderer renderer;
    }
    private List<RenderObj> _renderObjs = new List<RenderObj>();

    public List<RenderObj> RenderObjs => _renderObjs;

    private void Awake()
    {
        _renderObjs.Clear();
        var renderers = GetComponentsInChildren<SpriteRenderer>();
        var temp = new Dictionary<int, RenderObj>();
        for (int i = 0; i < data.datas.Count; ++i)
        {
            var flag = data.datas[i];
            if (flag < 1)
                continue;
            RenderObj renderObj = null;
            if (temp.ContainsKey(flag))
            {
                renderObj = temp[flag];
            }
            else
            {
                renderObj = new RenderObj();
                renderObj.renderer = renderers[flag - 1];
                renderObj.flag = flag;
                temp.Add(flag, renderObj);
                _renderObjs.Add(renderObj);
            }
            int x = i % data.gridx;
            int y = i / data.gridx;
            if (renderObj.minX > x || renderObj.minX == -1)
            {
                renderObj.minX = x;
            }
            if (renderObj.maxX < x || renderObj.maxX == -1)
            {
                renderObj.maxX = x;
            }
            if (renderObj.minY > y || renderObj.minY == -1)
            {
                renderObj.minY = y;
            }
            if (renderObj.maxY < y || renderObj.maxY == -1)
            {
                renderObj.maxY = y;
            }
        }
        if (_renderObjs.Count < 1)
        {
            foreach (var renderer in renderers)
            {
                var renderObj = new RenderObj();
                renderObj.minX = 0;
                renderObj.minY = 0;
                renderObj.maxX = data.gridx;
                renderObj.maxY = data.gridy;
                renderObj.renderer = renderer;
                renderObj.flag = 0;
                _renderObjs.Add(renderObj);
            }
        }
        
    }
    
    private void OnDrawGizmos()
    {
        if (!showGizmos)
            return;
        for (int y = 0; y < data.gridy; ++y)
        {
            for (int x = 0; x < data.gridx; ++x)
            {
                /*
                 * 4 3
                 * 1 2
                 */
                DrawGizmosGrid(x, y, gridColor, data.gridx, data.gridy);

                Handles.color = gridColor;
                var flag = data.GetFlag(x, y);
                if (flag != 0)
                {
                    switch (flag)
                    {
                        case -1:
                            DrawGizmosGridCross(x, y, Color.red);
                            break;
                        default:
                        {
                            var pos = CalcSkewPoint(new Vector2((x + 0.5f) * World2DUtil.GRID_WIDTH,
                                (y + 0.5f) * World2DUtil.GRID_WIDTH));
                            Handles.Label(new Vector3(pos.x, pos.y, 0f), flag.ToString());
                        }
                            break;
                    }
                }
            }
        }
    }

    public void DrawGizmosGridCross(int x, int y, Color color)
    {
        var point1 = CalcSkewPoint(new Vector2(x * World2DUtil.GRID_WIDTH, y * World2DUtil.GRID_WIDTH));
        var point2 = CalcSkewPoint(new Vector2(x * World2DUtil.GRID_WIDTH + World2DUtil.GRID_WIDTH, y * World2DUtil.GRID_WIDTH));
        var point3 = CalcSkewPoint(new Vector2(x * World2DUtil.GRID_WIDTH + World2DUtil.GRID_WIDTH, y * World2DUtil.GRID_WIDTH + World2DUtil.GRID_WIDTH));
        var point4 = CalcSkewPoint(new Vector2(x * World2DUtil.GRID_WIDTH, y * World2DUtil.GRID_WIDTH + World2DUtil.GRID_WIDTH));
        Gizmos.color = color;
        Gizmos.DrawLine(point1, point3);
        Gizmos.DrawLine(point4, point2);
    }
    
    public void DrawGizmosGrid(int x, int y, Color color, int totalX = -1, int totalY = -1)
    {
        var point1 = CalcSkewPoint(new Vector2(x * World2DUtil.GRID_WIDTH, y * World2DUtil.GRID_WIDTH));
        var point2 = CalcSkewPoint(new Vector2(x * World2DUtil.GRID_WIDTH + World2DUtil.GRID_WIDTH, y * World2DUtil.GRID_WIDTH));
        var point3 = CalcSkewPoint(new Vector2(x * World2DUtil.GRID_WIDTH + World2DUtil.GRID_WIDTH, y * World2DUtil.GRID_WIDTH + World2DUtil.GRID_WIDTH));
        var point4 = CalcSkewPoint(new Vector2(x * World2DUtil.GRID_WIDTH, y * World2DUtil.GRID_WIDTH + World2DUtil.GRID_WIDTH));
        
        var lastX = totalX == -1 || x == totalX - 1;
        var lastY = totalY == -1 || y == totalY - 1;
        
        Gizmos.color = color;
        Gizmos.DrawLine(point1, point2);
        Gizmos.DrawLine(point1, point4);
        if (lastX)
        {
            Gizmos.DrawLine(point2, point3);
        }
        if (lastY)
        {
            Gizmos.DrawLine(point3, point4);
        }
        Gizmos.color = color;
        Gizmos.DrawSphere(point1, World2DUtil.GRID_WIDTH * 0.1f);
        if (lastX)
        {
            Gizmos.DrawSphere(point2, World2DUtil.GRID_WIDTH * 0.1f);
        }
        if (lastY)
        {
            Gizmos.DrawSphere(point4, World2DUtil.GRID_WIDTH * 0.1f);
        }
        if (lastX && lastY)
        {
            Gizmos.DrawSphere(point3, World2DUtil.GRID_WIDTH * 0.1f);
        }
    }
    
    public Vector2 Center
    {
        get { return new Vector2(data.gridx * World2DUtil.GRID_WIDTH, data.gridy * World2DUtil.GRID_WIDTH) * 0.5f;}
    }
    public Vector2 CenterInSkew
    {
        get
        {
            return World2DUtil.ConvertToSkewPoint(Center);
        }
    }
    
    //
    public Vector2 CalcSkewPoint(int x, int y)
    {
        return CalcSkewPoint(new Vector2(x * World2DUtil.GRID_WIDTH, y * World2DUtil.GRID_WIDTH));
    }
    //
    public Vector2 CalcSkewPoint(Vector2 point)
    {
        point = World2DUtil.ConvertToSkewPoint(point);
        return point + (Vector2)transform.position - CenterInSkew;
    }
    
    //转换到本地坐标,原点在左下
    public Vector2 ConvertToLocal(Vector2 world2dPoint)
    {
        return world2dPoint - (Vector2) transform.position + CenterInSkew;
    }
    
    //射线检测
    public bool Raycast(Vector2 world2dPoint, out int x, out int y)
    {
        var point = World2DUtil.ConvertToNormalPoint(ConvertToLocal(world2dPoint));
        x = Mathf.FloorToInt(point.x / World2DUtil.GRID_WIDTH);
        y = Mathf.FloorToInt(point.y / World2DUtil.GRID_WIDTH);
        
        if (x < 0 || x > data.gridx - 1)
            return false;
        if (y < 0 || y > data.gridy - 1)
            return false;
        return true;
    }
    
    //计算摆放位置
    public void FindPlacement(World2DGrid plane, Vector2 world2dPoint, out int x, out int y)
    {
        var point = World2DUtil.ConvertToNormalPoint(plane.ConvertToLocal(world2dPoint));
        point = point - Center;
        x = Mathf.FloorToInt(point.x / World2DUtil.GRID_WIDTH);
        y = Mathf.FloorToInt(point.y / World2DUtil.GRID_WIDTH);
        x = Mathf.Clamp(x, 0, plane.data.gridx - data.gridx);
        y = Mathf.Clamp(y, 0, plane.data.gridy - data.gridy);
    }
    
    //设置摆放位置
    public void SetPosition(World2DGrid plane, int x, int y)
    {
        transform.position = plane.CalcSkewPoint(x, y) + CenterInSkew;
    }
    
    
    //更新绘制层级
    public void UpdateSortingOrder(int sortingOrder)
    {
        foreach (var renderObj in _renderObjs)
        {
            renderObj.renderer.sortingOrder = sortingOrder;
        }
    }
}